
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_CKD.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   29-10-2018
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 29/10/2018   	 Manoj Kumar			    Base Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>




////

#include <fclasses/tc_string.h>
#include <tc/tc.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tccore/item.h>



#include <fclasses/tc_string.h>
#include <tc/tc.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>

#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>


#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>

#include <tccore/grm.h>
#include <tccore/grmtype.h>

//////

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPICKD(expr)ITK_CALL_CKD(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL_CKD(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define ITK_err (EMH_USER_error_base+3)
#define	t5CKDSerialNum (EMH_USER_error_base+1000)
#define	t5CKDDummyPart (EMH_USER_error_base+10001)

using namespace std;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void  getAllPlantDetails( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"APLD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
	  }else  if(strcmp(PlantName,"APLP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }else  if(strcmp(PlantName,"APLC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
	  }else  if((strcmp(PlantName,"APLJ")==0))
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
	  }else  if(strcmp(PlantName,"APLL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
	  }else  if(strcmp(PlantName,"APLA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
	  }else  if(strcmp(PlantName,"APLU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
	  }else  if(strcmp(PlantName,"APLS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
	  }
}
	
	

/* CHARACTER ARRAY */

	void setAddStr(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = (char *)malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr character found===%s",(*strset)[*count-1]);fflush(stdout);



	}
	
/*********************************/

/* FUNCTION TO GET ITEM REVISION */

 int getQueryItemRevision_AllType( const char *val,char *type,tag_t** items,int *n_found)
{
           int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryItemRevision_AllType......");fflush(stdout);

           printf("\n\n RowsVal object==%s",val);fflush(stdout);
           printf("\n RowsVal type==%s \n",type);fflush(stdout);
		  
           tag_t        query           = NULLTAG;
          
           char
                   *qry_entries3[] = {(char *)"Item ID",(char *)"Type"},
                   *qry_values3[]  = {(char *)val,type};

        

                     
            QRY_find2("Item Revision...", &query);

               
      

            QRY_execute(query,2, qry_entries3, qry_values3, n_found, items);

            printf("\n\n getQueryItemRevision_AllType Rows555==%s \n",val);fflush(stdout);



                 return ifail;


} 

/* FUNCTION TO GET BARRELS */

 int getQueryCKDBARREL( const char *val,char *attr,tag_t** items,int *n_found)
{
           int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryCKDBARREL......");fflush(stdout);

           printf("\n\n RowsVal object==%s",attr);fflush(stdout);
           printf("\n RowsVal type==%s \n",val);fflush(stdout);
		  
           tag_t        query           = NULLTAG;
          
           char
                   *qry_entries3[] = {(char *)attr},
                   *qry_values3[]  = {(char *)val};

        

                     
            QRY_find2("CKD BARREL", &query);

               
      

            QRY_execute(query,1, qry_entries3, qry_values3, n_found, items);

            printf("\n\n getQueryCKDBARREL final==%s \n",val);fflush(stdout);



                 return ifail;


} 


/* FUNCTION TO CREATE CKD TASK */
int tm_create_ckdTask( METHOD_message_t *msg, va_list args )
{
	int ifail=ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	printf("\n DML Revision Created ");fflush(stdout);
	printf("\n Is DML New %d ",isnew);fflush(stdout);
	
	if(new_item != NULLTAG && isnew ==1)
	{
		char *item_id 	   = NULL;
		char *DML_no 	   = NULL;
		char **DesignGroupList;
		char **DMLMdAddList;
		char *DMLrlstype   = NULL;
		char *DMLObjName   = NULL;
		char *DMLObjDesc   = NULL;
		int	 num,mad	   = 0;
		printf("\n inside class ChangeRequestRevision......\n");fflush(stdout);
		CALLAPICKD(AOM_ask_value_string( new_item, "item_id", &item_id));
		CALLAPICKD(AOM_ask_value_string( new_item, "current_id", &DML_no));
		CALLAPICKD(AOM_ask_value_strings( new_item,"t5_crdesigngroup",&num,&DesignGroupList));
		CALLAPICKD(AOM_ask_value_string( new_item, "t5_rlstype", &DMLrlstype));
		CALLAPICKD(AOM_ask_value_strings(new_item,"t5_MdAddress",&mad,&DMLMdAddList));
		CALLAPICKD(AOM_ask_value_string( new_item, "object_name", &DMLObjName));
		CALLAPICKD(AOM_ask_value_string( new_item, "object_desc", &DMLObjDesc));
	
		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n DMLrlstype : %s\n",DMLrlstype);fflush(stdout);
		printf("\n num is : %d\n",num);fflush(stdout);
		printf("\n ModuleAddress Count : %d\n",mad);fflush(stdout);
		printf("\n DMLObjName :%s\n",DMLObjName);fflush(stdout);
		printf("\n DMLObjDesc : %s\n",DMLObjDesc);fflush(stdout);
		
		
		if(num > 0)
		{
			int number_found;
			int	status;
			tag_t *list_of_WSO_tags=NULLTAG;
			WSO_search_criteria_t  	criteria;
			char *item_id_dup = (char *)MEM_alloc(80 * sizeof(char));
			strcpy(item_id_dup,item_id);
			strcat (item_id_dup,"_");
			strcat (item_id_dup,DesignGroupList[0]);
			printf("\n Task count in DB :: %s\n",item_id_dup);fflush(stdout);
			
			WSOM_clear_search_criteria(&criteria);
			strcpy(criteria.name,item_id_dup);
			strcpy(criteria.class_name,"T5_ChangeTaskRevision");
			status	= WSOM_search(criteria, &number_found, &list_of_WSO_tags);			
			
			printf("\n\n\t\t Item_id count in DB is : %d\n",number_found);fflush(stdout);

			if(number_found == 0)
			{
				tag_t item=NULLTAG;
				tag_t rev=NULLTAG;
				tag_t relation_type,relation = NULLTAG;
				printf("\n item_id : %s and DML_no : %s\n ",item_id,DML_no);fflush(stdout);
				
				char**                  stringArrayInput                       =       NULL;
                char**                  stringArrInput                        =       NULL;
                int                     n_strings                              =       1;
                int                     l_strings                              =       300;
				int                     index                                  =       0;
				tag_t                   ObjectTag                              =       NULLTAG;
				tag_t                   ObTag                                  =       NULLTAG;
                tag_t                   ObTagRev                               =       NULLTAG;
				char*                   tempString                             =       NULL;
				tag_t                   createInputTag                         =       NULLTAG;
                tag_t                   createInputTagRev                      =       NULLTAG;
				
				stringArrayInput = (char**)malloc( n_strings * sizeof *stringArrayInput );
                stringArrInput = (char**)malloc( n_strings * sizeof *stringArrInput );
				
				
                for( index=0; index<n_strings; index++ )
                {
                    stringArrayInput[index] = (char*)malloc( l_strings + 1 );
                }
                for( index=0; index<n_strings; index++ )
                {
                    stringArrInput[index] = (char*)malloc( l_strings + 1 );
                }
				
				ITKCALL(TCTYPE_ask_type("T5_ChangeTask",&ObTag));
                ITKCALL(TCTYPE_construct_create_input(ObTag,&createInputTag));
                ITKCALL( TCTYPE_find_type("T5_ChangeTaskRevision", NULL, &ObTagRev) );
                ITKCALL( TCTYPE_construct_create_input(ObTagRev, &createInputTagRev) );
				
				tc_strcpy( stringArrInput[0], item_id_dup);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag, "item_id", 1, (const char**)stringArrInput));
				
				tc_strcpy( stringArrInput[0], DMLObjName);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag, "object_name", 1, (const char**)stringArrInput));
				
				tc_strcpy( stringArrInput[0], DMLObjDesc);
				ITKCALL( TCTYPE_set_create_display_value( createInputTag, "object_desc", 1, (const char**)stringArrInput));
				
				ITKCALL( AOM_tag_to_string(createInputTagRev, &tempString) );
                tc_strcpy( stringArrInput[0], tempString);
                ITKCALL( TCTYPE_set_create_display_value( createInputTag, "revision", 1,(const char**)stringArrInput) );
				
				//tc_strcpy( stringArrayInput[0], DesignGroupList[0]);
                //ITKCALL( TCTYPE_set_create_display_value( createInputTagRev, "t5_crdesigngroup", 1, (const char**)stringArrayInput) );
				
				ITKCALL( TCTYPE_create_object(createInputTag, &item) );
                AOM_save_with_extensions(item);  
                if(AOM_refresh(item,TRUE));
				
				ITK_CALL_CKD(ITEM_ask_latest_rev(item,&rev));
				
				//CALLAPICKD(ITEM_create_item(item_id_dup,item_id_dup,"T5_ChangeTask",NULL,&item,&rev));
				printf("\n Item created first time only with item_id \n");fflush(stdout);

				//CALLAPICKD(AOM_save_with_extensions(item));
				//CALLAPICKD(AOM_save_with_extensions(rev));
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
				GRM_create_relation(new_item, rev, relation_type,  NULLTAG, &relation);
				GRM_save_relation(relation);

				if(mad>0)
				 {
					int m=0;
					for(m=0;m<mad;m++)
					{
						printf("\nSetting..DML Module Address : %s\n",DMLMdAddList[m]);
						CALLAPICKD(AOM_set_value_string_at(rev,"t5_ModuleAddress",m,DMLMdAddList[m]));
					}
					CALLAPICKD(AOM_save_with_extensions(rev));
					CALLAPICKD(AOM_refresh(rev,0));
				 }

			}
			else 
			{ 
				printf("\n Required item_id already in DB....  \n");fflush(stdout); 
			}
			MEM_free(list_of_WSO_tags);
		}
	}
	return 0;
}

/* FUNCTION TO CREATE CKD DML */
int tm_ckddml_set_init_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
//	tag_t new_item         = NULLTAG;
//	int isnew              = 0;
	
/*	
	@param const char* item_id
    @param const char* item_name
    @param const char* type_name
    @param const char* rev_id
    @param tag_t*      new_item
    @param tag_t*      new_rev
    @param tag_t       item_master_form
    @param tag_t       item_rev_master_form
*/	
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
//	new_item               = va_arg(args, tag_t);
//	isnew                  = va_arg(args, int);
	printf("\n--->>>>>Inside new  >> ");fflush(stdout);
	printf("\n Entering tm_ckddml_set_init_val()");fflush(stdout);
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	SmlChckStr1		= NULL;
	char*	BscDmlA			= NULL;
	char*	BscDml			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[100]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s",CurrYear);fflush(stdout);
	
	SmlChckStr1 = (char *) MEM_alloc( 5000 * sizeof(char) );
	BscDmlA = (char *) MEM_alloc( 5000 * sizeof(char) );
	BscDml = (char *) MEM_alloc( 5000 * sizeof(char) );
	tc_strcpy(SmlChckStr1,CurrYear);
	tc_strcat(SmlChckStr1,"SM");
	tc_strcpy(BscDmlA, SmlChckStr1);	
	tc_strcpy(BscDml, SmlChckStr1);
	tc_strcat(BscDml,"%");	
	
	printf("\n--->>>>> Current DML String >> %s",BscDml);fflush(stdout);
	//if(*new_item != NULLTAG )//&& isnew==1)
	{
		char *value                     = NULL;
		char *DmlName                   = NULL;

		char *newid;
		char *item_idval=NULL;

		newid=(char *) MEM_alloc (20);

		
		tc_strcpy(newid,"*");

		const char *moduletype={newid};
		const char *attr="item_id";

		POM_enquiry_create("ckd_dml_enq");

		const char *sel_attrs[1] = {"puid"};

		POM_enquiry_add_select_attrs("ckd_dml_enq", "t5_CkdDml", 1, sel_attrs);
		POM_enquiry_set_string_value("ckd_dml_enq", "value", 1, &moduletype,POM_enquiry_bind_value);
		POM_enquiry_set_attr_expr ("ckd_dml_enq", "expression", "t5_CkdDml", attr, POM_enquiry_like, "value");
		POM_enquiry_set_where_expr ( "ckd_dml_enq", "expression" );

		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		POM_enquiry_add_order_attr ( "ckd_dml_enq","t5_CkdDml","item_id",POM_enquiry_desc_order);

		POM_enquiry_execute("ckd_dml_enq", &rows, &columns, &report);

		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			AOM_ask_value_string(objtag,"item_id",&item_idval);
			printf("\n The DmlName is : %s \n",item_idval);fflush(stdout);			
						
			int		runningSrl;
			/*
			char *CkdRSrlNo;
			CkdRSrlNo=(char *) MEM_alloc (20);
			tc_strcpy(CkdRSrlNo,subString(item_idval,5,10));
			*/
			//const char* from = "1000010100";  
			char* from = item_idval;  
			char *CkdRSrlNo = (char*) malloc(10);
			strncpy(CkdRSrlNo, from+4, 10); 


			printf("\n \n Recieved running serial :  %s \n",CkdRSrlNo);fflush(stdout);	
			runningSrl = atoi(CkdRSrlNo);
			runningSrl = runningSrl + 1;
			
			printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
			char runningSrlChar[10];	
			sprintf(runningSrlChar, "%06d", runningSrl);
			char *FinalRSrl = (char*) malloc(10);
			strncpy(FinalRSrl, runningSrlChar+1, 6);
		//	tc_strcat(BscDmlA,FinalRSrl);		
			tc_strcat(BscDmlA,runningSrlChar);		
		}
		else
		{		
			tc_strcat(BscDmlA,"000001");
		}
		POM_enquiry_delete("ckd_dml_enq");
		//item_id=BscDmlA;
		printf("\n \n Final Build DML ID will be :  %s \n",BscDmlA);fflush(stdout);	
		
		if(BscDmlA!= NULL)
		{
			if(*new_item != NULLTAG )
			{
			CALLAPICKD(AOM_lock(*new_item));
			CALLAPICKD(AOM_set_value_string(*new_item,"item_id", BscDmlA));
			CALLAPICKD(AOM_save_with_extensions(*new_item));						
			CALLAPICKD(AOM_unlock(*new_item));
      
			CALLAPICKD(AOM_lock(item_master_form));
			CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", BscDmlA));
			CALLAPICKD(AOM_save_with_extensions(item_master_form));						
			CALLAPICKD(AOM_unlock(item_master_form));

			char *rev_master_form_id=NULL;
			rev_master_form_id=(char *)MEM_alloc(30);
		    tc_strcpy(rev_master_form_id,BscDmlA); 
		    tc_strcat(rev_master_form_id,"/"); 
		    tc_strcat(rev_master_form_id,rev_id); 

			CALLAPICKD(AOM_lock(item_rev_master_form));
            CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
            CALLAPICKD(AOM_save_with_extensions(item_rev_master_form));
            CALLAPICKD(AOM_unlock(item_rev_master_form));

			printf("\n DML Item ID Updated With %s",BscDmlA);fflush(stdout);			

			MEM_free(rev_master_form_id);
			MEM_free(BscDmlA);

			}
			else
			{

		//	item_id=BscDmlA;	
                        printf("\n NULLTAG new_item");fflush(stdout);
			}

		}	
		
	}	

	
	return 0;
}


int tm_set_erc_dmlval_ckddml( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	tag_t new_item         = NULLTAG;
	int isnew              = 0;
	new_item               = va_arg(args, tag_t);
	isnew                  = va_arg(args, int);
	printf("\n DML Revision IMANTYPE_init_intl_props invoked ");fflush(stdout);

	
	return 0;
}


/* FUNCTION TO CREATE ASSIGN BARREL TO COUNTRY CODE */

int CKDBarrelAssignFunc( void *return_data )
{
	int status;
	int				ifail 						= ITK_ok;
	printf("\n I am in CKDBarrelAssignFunc function");fflush(stdout);

	char			*PartNum					= NULL;
	char			*FastIncVal					= NULL;
	char			*RevIncVal					= NULL;
	char			*CountryVal					= NULL;
	char			*BarrelNum					= NULL;
	char			*output						= NULL;
	tag_t  			ObTag                     = NULLTAG;
	tag_t  			createInputTag              = NULLTAG;
	tag_t  			boTag			            = NULLTAG;
	char**                  stringArrInput                        =       NULL;
	int n_strings=5;
	int index = 0;
	USERARG_get_string_argument(&PartNum);
	USERARG_get_string_argument(&FastIncVal);
	USERARG_get_string_argument(&RevIncVal);
	USERARG_get_string_argument(&CountryVal);
	USERARG_get_string_argument(&BarrelNum);
	
	printf("\n Recieved Input argument in ITK CKDBarrelAssignFunc(): %s | %s | %s | %s | %s ",PartNum,FastIncVal,RevIncVal,CountryVal,BarrelNum);fflush(stdout);

	stringArrInput = (char**)malloc( n_strings * sizeof *stringArrInput );        
    for( index=0; index<n_strings; index++ )
    {
        stringArrInput[index] = (char*)malloc( 40 + 1 );
    }

	TCTYPE_ask_type("T5_AltBrl",&ObTag);
	TCTYPE_construct_create_input(ObTag,&createInputTag);
	tc_strcpy( stringArrInput[0], BarrelNum);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_BrlNum",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], PartNum);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_ErcEsNo",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], FastIncVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_FstnrInc",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], CountryVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_PlcCode",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], RevIncVal);
	TCTYPE_set_create_display_value(createInputTag,(char *)"t5_RvtInc",1,(const char**)stringArrInput);
	tc_strcpy( stringArrInput[0], BarrelNum);
	TCTYPE_set_create_display_value( createInputTag, (char *)"object_name", 1, (const char**)stringArrInput);

	TCTYPE_create_object(createInputTag,&boTag);
	printf("\n Auto Task created successfully \n");fflush(stdout);
	AOM_save_with_extensions(boTag);
	printf("\n Task saved \n");fflush(stdout);

	
	
	printf("\n End of program.....!!\n\n");fflush(stdout);
	
	output = (char *)"NULL";	
	*((char **) return_data) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) return_data), output); 
	
	return ifail;
	/* Program Logic End*/
}


/* FUNCTION TO CREATE LOT NUMBER */

int tm_lot_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	//tag_t new_item         = NULLTAG;
	//int isnew              = 0;
	
	/*
	@param const char* item_id
    @param const char* item_name
    @param const char* type_name
    @param const char* rev_id
    @param tag_t*      new_item
    @param tag_t*      new_rev
    @param tag_t       item_master_form
    @param tag_t       item_rev_master_form
	*/
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//new_item               = va_arg(args, tag_t);
//	isnew                  = va_arg(args, int);
	printf("\n--->>>>>Inside new  >> ");fflush(stdout);
	printf("\n Entering tm_lot_num_gen_val()");fflush(stdout);
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	CkdDml			= NULL;
	char	*ESorDS			= NULL;
	char	*VcNo			= NULL;
	char*	TotQty			= NULL;
	char*	unitQty			= NULL;
	char 	Data[100]			= "";
	char 	CurrYear[6]		= "";
	time_t 	now;
	struct 	tm	when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(CurrYear,100,"%y",&when);
	
	printf("\n--->>>>> Current Year >> %s",CurrYear);fflush(stdout);
	
	
	CkdDml =  (char *)MEM_alloc(50);
	VcNo =  (char *)MEM_alloc(50);
	TotQty =  (char *)MEM_alloc(50);
	unitQty = (char *)MEM_alloc(50);
	
	int lotTotQty=0;
	int lotQty=0;
	int ModNumOfLots=0;
	
	
	if(*new_item != NULLTAG)
	{
		char *value                     = NULL;
		
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_WbsID",&CkdDml));
		printf("\n The the CKD DMl is :  %s \n",CkdDml);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_PartNumber",&VcNo));
		printf("\n The the CKD DMl VC is :  %s \n",VcNo);fflush(stdout);	

		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_LotTotQty",&TotQty));
		printf("\n The the CKD DMl TotQty is :  %s \n",TotQty);fflush(stdout);
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_LotQty",&unitQty));
		printf("\n The the CKD DMl unitQty is :  %s \n",unitQty);fflush(stdout);
		
		lotTotQty=atoi(TotQty);
		lotQty=atoi(unitQty);
		
		ModNumOfLots = lotTotQty%lotQty;
		printf("\n The the CKD DMl ModNumOfLots is :  %d , Hence both the Quantity are divisible \n",ModNumOfLots);fflush(stdout);
		
		
		char* VcNoDup = VcNo;  
		printf("\n The VcNo:  %s \n",VcNo);fflush(stdout);
		char *CountryCode = (char *)MEM_alloc(10);
		tc_strcpy(CountryCode,"");
		printf("\n The CountryCode:  %s \n",CountryCode);fflush(stdout);
		strncpy(CountryCode, VcNoDup,2); 
		CountryCode[2]='\0';
		printf("\n The first 2 character of  CountryCode:  %s \n",CountryCode);fflush(stdout);
		
	/* 	char* from2 = CurrYear;  
		char *YearCode = MEM_alloc(4);
		tc_strcpy(CountryCode,"");
		strncpy(YearCode, from2+2,2);
		printf("\n The last 2 digit of YearCode :  %s \n",YearCode);fflush(stdout); */
		
		
		char *Lotnumber = (char*) malloc(10);
		tc_strcpy(Lotnumber,CountryCode);
		tc_strcat(Lotnumber,CurrYear);
		printf("\n The temporary Lotnumber :  %s \n",Lotnumber);fflush(stdout);
			
		
		char *newid;
		char *item_idval=NULL;

		newid=(char *) MEM_alloc (20);

		
		tc_strcpy(newid,Lotnumber);
		tc_strcat(newid,"*");
		printf("\n The query value :  %s \n",newid);fflush(stdout);

		const char *new_id_val={newid};
		const char *attr="item_id";

		CALLAPICKD(POM_enquiry_create("ckd_lot_num_enq"));

		const char *sel_attrs[1] = {"puid"};

		CALLAPICKD(POM_enquiry_add_select_attrs("ckd_lot_num_enq", "T5_LotNum", 1, sel_attrs));
		CALLAPICKD(POM_enquiry_set_string_value("ckd_lot_num_enq", "value", 1, &new_id_val,POM_enquiry_bind_value));
		CALLAPICKD(POM_enquiry_set_attr_expr ("ckd_lot_num_enq", "expression", "T5_LotNum", attr, POM_enquiry_like, "value"));
		CALLAPICKD(POM_enquiry_set_where_expr ( "ckd_lot_num_enq", "expression" ));
		CALLAPICKD(POM_enquiry_add_order_attr ( "ckd_lot_num_enq","T5_LotNum","creation_date",POM_enquiry_desc_order));
		
		tag_t objtag=NULLTAG;

		int  rows = 0, columns = 0;
		void ***report;

		CALLAPICKD(POM_enquiry_execute("ckd_lot_num_enq", &rows, &columns, &report));

		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			CALLAPICKD(AOM_ask_value_string(objtag,"item_id",&item_idval));
			printf("\n The previous Lotnumber is : %s \n",item_idval);fflush(stdout);		

			
						
			int		runningSrl;
			
			char* from = item_idval;  
			char *lotSrlNo = (char *)MEM_alloc(4);
			char *appndSrlNo = (char *)MEM_alloc(6);
			strncpy(lotSrlNo, from+4, 4); 
            lotSrlNo[4] ='\0';
			
			printf("\n \n Received running serial :  %s \n",lotSrlNo);fflush(stdout);	
			runningSrl = atoi(lotSrlNo);
			runningSrl = runningSrl + 1;
			
			printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
			
			char* runningSrlChar=(char *)MEM_alloc(4);
			tc_strcpy(newid,runningSrlChar);
			sprintf(runningSrlChar, "%04d", runningSrl);
			
					
			printf("\n \n runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
		
			tc_strcat(Lotnumber,runningSrlChar);			
		}
		else
		{		
			tc_strcat(Lotnumber,"0001");
		
		}
		
		POM_enquiry_delete("ckd_lot_num_enq");
		
		printf("\n \n Final Build Lot Number will be :  %s \n",Lotnumber);fflush(stdout);	
		
		
		
		if(Lotnumber!= NULL)
		{
			CALLAPICKD(AOM_lock(*new_item));
			CALLAPICKD(AOM_set_value_string(*new_item,"item_id", Lotnumber));
            printf("\n \n In Item master lot number built %s \n",Lotnumber);fflush(stdout);	
			
			CALLAPICKD(AOM_set_value_string(*new_item,"object_name", Lotnumber));
			printf("\n set the object_name_lotnum iin new item created :");fflush(stdout);
      
			CALLAPICKD(AOM_save_with_extensions(*new_item));						
			CALLAPICKD(AOM_unlock(*new_item));
			
			CALLAPICKD(AOM_lock(*new_rev));
			CALLAPICKD(AOM_set_value_string(*new_rev,"object_name", Lotnumber));
			printf("\n set the object_name_lotnum iin new item revision created : ");fflush(stdout);
			CALLAPICKD(AOM_save_with_extensions(*new_rev));						
			CALLAPICKD(AOM_unlock(*new_rev));
			
			CALLAPICKD(AOM_lock(item_master_form));
			CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", Lotnumber));
			CALLAPICKD(AOM_save_with_extensions(item_master_form));						
			CALLAPICKD(AOM_unlock(item_master_form));
			
			char *rev_master_form_id=NULL;
			rev_master_form_id=(char *)MEM_alloc(30);
			tc_strcpy(rev_master_form_id,Lotnumber); 
			tc_strcat(rev_master_form_id,"/"); 
			tc_strcat(rev_master_form_id,rev_id); 

			CALLAPICKD(AOM_lock(item_rev_master_form));
			CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
			CALLAPICKD(AOM_save_with_extensions(item_rev_master_form));
			CALLAPICKD(AOM_unlock(item_rev_master_form));

			printf("\n Lotnumber Updated With %s",Lotnumber);fflush(stdout);			

			MEM_free(rev_master_form_id);
      
		}
		else
		{

		
					printf("\n NULLTAG new_item");fflush(stdout);
		}
		
	
	return ifail;
}

}

/* FUNCTION TO CREATE BOX NUMBER */
int tm_Boxqty_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	//tag_t new_item         = NULLTAG;
	//int isnew              = 0;
	
	/*
	@param const char* item_id
    @param const char* item_name
    @param const char* type_name
    @param const char* rev_id
    @param tag_t*      new_item
    @param tag_t*      new_rev
    @param tag_t       item_master_form
    @param tag_t       item_rev_master_form
	*/
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//new_item               = va_arg(args, tag_t);
//	isnew                  = va_arg(args, int);
	printf("\n--->>>>>Inside new  >> ");fflush(stdout);
	printf("\n Entering tm_Boxqty_num_gen_val()");fflush(stdout);
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	lotnumber			= NULL;
	char*	casecode			= NULL;
	
	
	
	lotnumber =  (char *)MEM_alloc(20);
	casecode =  (char *)MEM_alloc(10);
	
	
	
	if(*new_item != NULLTAG)
	{
		char *value                     = NULL;
		
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_Cscd",&casecode));
		printf("\n The casecode is :  %s \n",casecode);fflush(stdout);	
		
		if (casecode!=NULL)
		{
		 
		}
		else
		{
		 tc_strdup("EM",&casecode); 
		}
		
		
		
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_LotVal",&lotnumber));
		printf("\n The lotnumber is :  %s \n",lotnumber);fflush(stdout);	

		char *BoxQtyNo = (char *)MEM_alloc(20);
		
		tc_strcpy(BoxQtyNo,"");
		tc_strcat(BoxQtyNo,lotnumber);
		tc_strcat(BoxQtyNo,"_");
		tc_strcat(BoxQtyNo,casecode);
		
		
		
		
		
		printf("\n \n Final Build Lot Number will be :  %s \n",BoxQtyNo);fflush(stdout);	
		
		
		if(BoxQtyNo!= NULL)
		{
			CALLAPICKD(AOM_lock(*new_item));
			CALLAPICKD(AOM_set_value_string(*new_item,"item_id", BoxQtyNo));
			printf("\n \n In Item master BoxQtyNo built %s \n",BoxQtyNo);fflush(stdout);	
		
					
			CALLAPICKD(AOM_set_value_string(*new_item,"object_name", BoxQtyNo));
			printf("\n set the object_name_BoxQtyNo iin new item created : ");fflush(stdout);
			
			CALLAPICKD(AOM_save_with_extensions(*new_item));						
			CALLAPICKD(AOM_unlock(*new_item));
      
			CALLAPICKD(AOM_lock(*new_rev));
			CALLAPICKD(AOM_set_value_string(*new_rev,"object_name", BoxQtyNo));
			printf("\n set the object_name_BoxQtyNo iin new item revision created ");fflush(stdout);
			CALLAPICKD(AOM_save_with_extensions(*new_rev));						
			CALLAPICKD(AOM_unlock(*new_rev));
			
			
			CALLAPICKD(AOM_lock(item_master_form));
			CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", BoxQtyNo));
			CALLAPICKD(AOM_save_with_extensions(item_master_form));						
			CALLAPICKD(AOM_unlock(item_master_form));
			
			char *rev_master_form_id=NULL;
			rev_master_form_id=(char *)MEM_alloc(30);
			tc_strcpy(rev_master_form_id,BoxQtyNo); 
			tc_strcat(rev_master_form_id,"/"); 
			tc_strcat(rev_master_form_id,rev_id); 

			CALLAPICKD(AOM_lock(item_rev_master_form));
			CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
			CALLAPICKD(AOM_save_with_extensions(item_rev_master_form));
			CALLAPICKD(AOM_unlock(item_rev_master_form));

			printf("\n BOX Quantity Updated With %s",BoxQtyNo);fflush(stdout);			

			MEM_free(rev_master_form_id);
      
		}
		else
			{

	
                        printf("\n NULLTAG new_item");fflush(stdout);
			}
		
	
	return ifail;
}

}

/*CKD DUMMY PART NUMBER GENRATION */

int tm_ckdDmyPrt_num_gen_val( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;

	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	

	printf("\n--->>>>>Inside new  >> ");fflush(stdout);
	printf("\n Entering tm_ckdDmyPrt_num_gen_val()");fflush(stdout);
	tag_t object = NULLTAG;
	object  = msg->object_tag;
	char*	itemid			= NULL;
	char*	partnumber		= NULL;
	char*	phantom			= NULL;
	char*	LRindi			= NULL;
	char*	ckdDML			= NULL;
	char*	ckdCS			= NULL;
	char*	colourIndi		= NULL;
	char*	item_idval		= NULL;
	char*	item_idseq		= NULL;
	char*	item_projcode	= NULL;
	char*	item_desgnGrp	= NULL;
	char*	partnumberQry	= NULL;
	double objWeight=0.0;
	
	int allowCreate=0;
	
	partnumber 	=  (char *)MEM_alloc(20);
	phantom 	=  (char *)MEM_alloc(20);
	LRindi 		=  (char *)MEM_alloc(20);
	ckdDML	 	=  (char *)MEM_alloc(20);
	ckdCS	 	=  (char *)MEM_alloc(20);
	item_idval 	=  (char *)MEM_alloc(10);
	item_idseq  =  (char *)MEM_alloc(10);
	item_projcode =  (char *)MEM_alloc(10);
	item_desgnGrp =  (char *)MEM_alloc(10);
	partnumberQry =  (char *)MEM_alloc(20);tc_strcpy(partnumberQry,"");
	
	
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char *rolename=NULL;
	
    rolename =  (char *)MEM_alloc(100);
    tag_t  CurrentRoleTag = NULLTAG;
    char*       roleName=NULL;//[SA_name_size_c+1]  ;
    ITK_CALL_CKD(SA_ask_current_role(&CurrentRoleTag));
    ITK_CALL_CKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
    printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

	
	getAllPlantDetails(roleName,PlantCS,PlantOptCS,PlantIA,PlantStore,UserAgency);
	
	
	if(*new_item != NULLTAG)
	{
		char *value                     = NULL;

		
		bool isNull=false;
		string itemid;
		
		
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_TmpPrt",&partnumber));
		printf("\n The tempory partnumber is :  %s \n",partnumber);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_CkdDmyPH",&phantom));
		printf("\n The phantom is :  %s \n",phantom);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_Pos",&LRindi));
		printf("\n The LRindi is :  %s \n",LRindi);fflush(stdout);	
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_WbsID",&ckdDML));
		printf("\n The ckdDML is :  %s \n",ckdDML);fflush(stdout);
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_ClCKDVCInd",&colourIndi));
		printf("\n The colourIndi is :  %s \n",colourIndi);fflush(stdout);
		
		if (strcmp(colourIndi,"NO")==0)
		{
		tc_strdup("N",&colourIndi);
		}
		else
		{
		tc_strdup("Y",&colourIndi);
		}
		
		
		CALLAPICKD(AOM_ask_value_string(*new_rev,"t5_CkdDmyCS",&ckdCS));
		printf("\n The ckdCS is :  %s \n",ckdCS);fflush(stdout);
		
		
		
		
	
		char *dmyInitial = subString(partnumber,0,2);
		char *dmyInitialDup = (char *)MEM_alloc(2);
		tc_strcpy(dmyInitialDup,"");
		
		printf("\n The first 2 digit of dmyInitial :  %s \n",dmyInitial);fflush(stdout); 
		
		tc_strdup(dmyInitial,&dmyInitialDup);
		
		if (strcmp(dmyInitialDup,"99")==0)
		{
		 printf("\n ERROR :::The Part is already a CKD dummy part :  %s \n",partnumber);fflush(stdout); 
		 allowCreate=0;
		 ifail=t5CKDDummyPart;
		 printf("\n  Validation ERROR !! t5CKD.c::t5CKDDummyPart =%d",ifail);fflush(stdout);
		 EMH_store_error_s1(EMH_severity_error,ifail,"You are not allowed to add for Dummy created Part.");

		return ifail;
		}
		else
		{	
		printf("\n starting query the selected part number :::The P :  %s",partnumber);fflush(stdout);
		}
		
		 

	
		tag_t *part_rev_tag = NULLTAG;
		int partcount=0,i=0;
		ITK_CALL_CKD(getQueryItemRevision_AllType(partnumber,(char *)"Design Revision",&part_rev_tag,&partcount));
		printf("\n number of the Part queried is [%d]",partcount);fflush(stdout);
		if(partcount>0 && part_rev_tag!=NULLTAG )
		{
		 allowCreate=1;
		for (i=0;i<partcount;i++)
		{
				
			tag_t Part_tag =NULLTAG;
			Part_tag = part_rev_tag[i];
					
			 CALLAPICKD(AOM_ask_value_string(Part_tag,"item_id",&item_idval));
			 printf("\n The partnumber is valid: %s \n",item_idval);fflush(stdout);	
			
			 CALLAPICKD(AOM_ask_value_string(Part_tag,"t5_ProjectCode",&item_projcode));
			 printf("\n The partnumber item_projcode: %s \n",item_projcode);fflush(stdout);	
			 
			 CALLAPICKD(AOM_ask_value_string(Part_tag,"t5_DesignGrp",&item_desgnGrp));
			 printf("\n The partnumber item_desgnGrp: %s \n",item_desgnGrp);fflush(stdout);	
		 
		}
		
				if (strlen(item_projcode)==0)
				 {
				 EMH_store_error_s1(EMH_severity_error, ITK_err,"Please Select the Revision which has a Project code.");
				 return ITK_err;
				 }
				 else
				 {
				 printf("\n The error item_projcode: %s %d \n",item_projcode, strlen(item_projcode));fflush(stdout);	
				 }
				 
				 if (strlen(item_desgnGrp)==0)
				 {
				 EMH_store_error_s1(EMH_severity_error, ITK_err,"Please Select the Revision which has a Design Group.");
				 return ITK_err;
				 }else
				 {
				 printf("\n The error item_desgnGrp: %s  %d\n",item_desgnGrp , strlen(item_desgnGrp));fflush(stdout);	
				 }
		
		}
		else
		{
		printf("\n NO OBJECT QUERIED\n");fflush(stdout);	
		allowCreate=0;
		}
		
		
	
		
		if (allowCreate==1)
		{
			char *CkdDmyPrtNo = (char *)MEM_alloc(20);
			
			if(((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0) || (strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )) //(strcmp(roleName,"DBA")==0) || 
			{
				tc_strcpy(CkdDmyPrtNo,"");
				tc_strcat(CkdDmyPrtNo,partnumber);
				tc_strcat(CkdDmyPrtNo,phantom);
				if((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0)) //(strcmp(roleName,"DBA")==0) || 
				{
					tc_strcat(CkdDmyPrtNo,"J");
				}
				if((strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )
				{
					tc_strcat(CkdDmyPrtNo,"L");
				}
				
				printf("\n The CkdDmyPrtNo Before: %s \n",CkdDmyPrtNo);fflush(stdout);	
				tc_strcat(partnumberQry,CkdDmyPrtNo);
				tc_strcat(partnumberQry,"*");
				printf("\n The partnumberQry : %s \n",partnumberQry);fflush(stdout);	
				 
							
				
				const char *new_id_val1={partnumberQry};
				const char *attr1="item_id";

				CALLAPICKD(POM_enquiry_create("ckd_partnum_enq"));

				const char *sel_attrs1[1] = {"puid"};

				CALLAPICKD(POM_enquiry_add_select_attrs("ckd_partnum_enq", "T5_CkdDmy", 1, sel_attrs1));
				CALLAPICKD(POM_enquiry_set_string_value("ckd_partnum_enq", "value", 1, &new_id_val1,POM_enquiry_bind_value));
				CALLAPICKD(POM_enquiry_set_attr_expr   ("ckd_partnum_enq", "expression", "T5_CkdDmy", attr1, POM_enquiry_like, "value"));
				CALLAPICKD(POM_enquiry_set_where_expr  ( "ckd_partnum_enq", "expression" ));
				CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","creation_date",POM_enquiry_desc_order));
			
				tag_t gettag=NULLTAG;
				int row1=0,column1=0;
				void ***report1;
				CALLAPICKD(POM_enquiry_execute("ckd_partnum_enq",&row1,&column1,&report1));
				
				 printf("\n Number of rows queried for T5_CkdDmy %d",row1);fflush(stdout); 
				
			    
				if(row1!=0)
				{
					gettag=*(tag_t*)(report1[0][0]);
					
					int lenght=0;
					int incValue=0;
					char*   Getnum;
					char*   Getlast= (char *)MEM_alloc(1);
					
					char*	bufLastSerial	= NULL;
					char*	GetDummyNum	= NULL;
					
					
					CALLAPICKD(AOM_ask_value_string(gettag,"item_id",&GetDummyNum));
					printf("\n The GetDummyNumJSR/LKO is valid: %s \n",GetDummyNum);fflush(stdout);	
					
					char* dupvalue = GetDummyNum;  
					lenght=tc_strlen(GetDummyNum)-1;
					tc_strcpy(Getlast,"");
					strncpy(Getlast, dupvalue+lenght,1);
					Getlast[1]='\0';
					printf("\n The first  digit of Getlast :  %s \n",Getlast);fflush(stdout);
					
					
					incValue=atoi(Getlast);
					printf("\n incValue = %d",incValue);fflush(stdout);
				
					allowCreate=1;
					bufLastSerial = (char *)MEM_alloc(2);
					tc_strcpy(bufLastSerial,"");
			        incValue=incValue+1;
					printf("\n incValue = %d",incValue);fflush(stdout);
			
			        if (incValue>9)
					{
					 allowCreate=0;
					 ifail=t5CKDSerialNum;
					 printf("\n  Validation ERROR !! t5CKD.c::t5CKDSerialNum =%d",ifail);fflush(stdout);
					 EMH_store_error_s1(EMH_severity_error,ifail,"Dummy Part cannot be created.");

					return ifail;
					}
					else
					{
					sprintf(bufLastSerial,"%01d",incValue);
					printf("\n bufLastSerial = %s",bufLastSerial);fflush(stdout);
					
					tc_strcat(CkdDmyPrtNo,bufLastSerial);
					}
					
				}	
				else
				{
				
				 tc_strcat(CkdDmyPrtNo,"0");
				
				}
				
				
			}
			else
			{
				tc_strcpy(CkdDmyPrtNo,"");
				tc_strcat(CkdDmyPrtNo,"99");
				tc_strcat(CkdDmyPrtNo,item_projcode);
				tc_strcat(CkdDmyPrtNo,item_desgnGrp);
				printf("\n The CkdDmyPrtNo Before: %s \n",CkdDmyPrtNo);fflush(stdout);	
				tc_strcat(partnumberQry,CkdDmyPrtNo);
				tc_strcat(partnumberQry,"*");
				printf("\n The partnumberQry : %s \n",partnumberQry);fflush(stdout);	
				 
				const char *new_id_val1={partnumberQry};
				const char *attr1="item_id";

				CALLAPICKD(POM_enquiry_create("ckd_partnum_enq"));

				const char *sel_attrs1[1] = {"puid"};

				CALLAPICKD(POM_enquiry_add_select_attrs("ckd_partnum_enq", "T5_CkdDmy", 1, sel_attrs1));
				CALLAPICKD(POM_enquiry_set_string_value("ckd_partnum_enq", "value", 1, &new_id_val1,POM_enquiry_bind_value));
				CALLAPICKD(POM_enquiry_set_attr_expr   ("ckd_partnum_enq", "expression", "T5_CkdDmy", attr1, POM_enquiry_like, "value"));
				CALLAPICKD(POM_enquiry_set_where_expr  ( "ckd_partnum_enq", "expression" ));
				CALLAPICKD(POM_enquiry_add_order_attr  ( "ckd_partnum_enq","T5_CkdDmy","creation_date",POM_enquiry_desc_order));
				
				tag_t gettag=NULLTAG;
				int row1=0,column1=0;
				void ***report1;
				CALLAPICKD(POM_enquiry_execute("ckd_partnum_enq",&row1,&column1,&report1));
			    
				if(row1!=0)
				{
				gettag=*(tag_t*)(report1[0][0]);
				CALLAPICKD(AOM_ask_value_string(gettag,"item_id",&item_idseq));
				printf("\n The partnumber seq is valid: %s \n",item_idseq);fflush(stdout);	
				 
				char* dmylst = item_idseq;  
				char *dmyLast = (char *)MEM_alloc(4);
				tc_strcpy(dmyLast,"");
				strncpy(dmyLast, dmylst+8,4);
				dmyLast[4]='\0';
				printf("\n The first 2 digit of dmyLast :  %s \n",dmyLast);fflush(stdout); 
				
				int runningSrl =0;
				char runningSrlChar[10];
				
				runningSrl = atoi(dmyLast);
				runningSrl = runningSrl + 1;
				
				printf("\n \n converted to int:  %d \n",runningSrl);fflush(stdout);	
				
				if (runningSrl<101)
				{
				 tc_strcat(CkdDmyPrtNo,"101");
				}
				else
				{
					
				sprintf(runningSrlChar, "%02d", runningSrl);
				}
				
						
				printf("\n \n runningSrlChar:  %s \n",runningSrlChar);fflush(stdout);	
			    tc_strcat(CkdDmyPrtNo,runningSrlChar);
				 
				}
				else
				{
				 tc_strcat(CkdDmyPrtNo,"101");
				}
				
				tc_strcat(CkdDmyPrtNo,LRindi);
			}
			
			CALLAPICKD(POM_enquiry_delete("ckd_partnum_enq"));

			printf("\n \n Final Build CKD DUMMY PART Number will be :  %s \n",CkdDmyPrtNo);fflush(stdout);	
			
			
			if(CkdDmyPrtNo!= NULL)
			{
				CALLAPICKD(AOM_lock(*new_item));
				CALLAPICKD(AOM_set_value_string(*new_item,"item_id", CkdDmyPrtNo));
				printf("\n \n In Item master ckdDmyPart built %s \n",CkdDmyPrtNo);fflush(stdout);	
				
						
				CALLAPICKD(AOM_set_value_string(*new_item,"object_name", CkdDmyPrtNo));
				CALLAPICKD(AOM_save_with_extensions(*new_item));						
				CALLAPICKD(AOM_unlock(*new_item));
        
				CALLAPICKD(AOM_lock(*new_rev));
				CALLAPICKD(AOM_set_value_string(*new_rev,"object_name", CkdDmyPrtNo));
				printf("\n set the object_name_ckdDmyPart of new item revision created ");fflush(stdout);
				
				
			
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_ColourInd", colourIndi));
				CALLAPICKD(AOM_set_value_string(*new_rev,PlantCS, ckdCS));
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_DrawingInd", "N"));
				CALLAPICKD(AOM_set_value_double(*new_rev,"t5_Weight",objWeight));
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_PartType","D"));
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_DenisPart",false));
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_HazardousContents",false)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_Recyclability",false)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_Recoverable",false)); 
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_SpareInd",false)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_ListRecSpares",false)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_Dismantable",false)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_CMVRCertificationReqd",false));  	 
				//CALLAPICKD(AOM_set_value_string(*new_rev,"t5_SpareCriteria","NAR")) 			
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_DesignGrp","00")) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_SamplesToAppr",false)) ;
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_HomologationReqd","N")) ;
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_MatlClass","")) ;
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_ProjectCode",item_projcode)) ;
				CALLAPICKD(AOM_set_value_logical(*new_rev,"t5_ConvDoc",false)) ;
				CALLAPICKD(AOM_set_value_string(*new_rev,"t5_Coated","N")) ;
				
			    printf("\n set the attribute_ckdDmyPart of new item created : ");fflush(stdout);
				CALLAPICKD(AOM_save_with_extensions(*new_rev));						
				CALLAPICKD(AOM_unlock(*new_rev));
				
				CALLAPICKD(AOM_lock(item_master_form));
				CALLAPICKD(AOM_set_value_string(item_master_form,"object_name", CkdDmyPrtNo));
				CALLAPICKD(AOM_save_with_extensions(item_master_form));						
				CALLAPICKD(AOM_unlock(item_master_form));
				
				char *rev_master_form_id=NULL;
				rev_master_form_id=(char *)MEM_alloc(30);
				tc_strcpy(rev_master_form_id,CkdDmyPrtNo); 
				tc_strcat(rev_master_form_id,"/"); 
				tc_strcat(rev_master_form_id,rev_id); 

				CALLAPICKD(AOM_lock(item_rev_master_form));
				CALLAPICKD(AOM_set_value_string(item_rev_master_form,"object_name", rev_master_form_id));
				CALLAPICKD(AOM_save_with_extensions(item_rev_master_form));
				CALLAPICKD(AOM_unlock(item_rev_master_form));

			
				
				printf("\n Ckd Dmy Part Updated With %s",CkdDmyPrtNo);fflush(stdout);			

				
		  
		        char* tasknumber_DML=NULL;
		       /*CREATING RELATION */
		        tag_t *dml_rev_tag = NULLTAG;
		        tag_t *task_obj_tag = NULLTAG;
				
				int dmlcount=0,j=0,n_tasksFnd=0,l=0;
				ITK_CALL_CKD(getQueryItemRevision_AllType(ckdDML,(char *)"Ckd Dml Revision",&dml_rev_tag,&dmlcount));
				printf("\n number of the dml queried is [%d]",dmlcount);fflush(stdout);
				if(dml_rev_tag!=NULLTAG && dmlcount>0)
				{
				 printf("\n inside dml");
				 for (j=0;j<dmlcount;j++)
				 {
							
			      CALLAPICKD(AOM_ask_value_string(dml_rev_tag[j] ,"item_id", &tasknumber_DML));
				  printf("\n The DML number is %s",tasknumber_DML);fflush(stdout);
				  
				  tag_t relatnType_tag = NULLTAG;
				  GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag);
				  printf("\n number of the T5_DMLTaskRelation");
				  
					if (relatnType_tag!=NULLTAG)
					{
						if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag[j], relatnType_tag, &n_tasksFnd, &task_obj_tag )) != ITK_ok )
						{
								return ifail;
						}
						printf("\n DMLTaskRel : No of Tasks are : %d \n",n_tasksFnd); fflush(stdout);
					
						if (n_tasksFnd>0 && task_obj_tag!=NULLTAG)
						{
						    tag_t task_rev_tag = NULLTAG;
						    task_rev_tag=task_obj_tag[0];
						
						 /* CREATING RELATION BETWEEN CKD DMY PART WITH CKD DML */
							
							tag_t relation_type,relation = NULLTAG;
							GRM_find_relation_type("CMHasSolutionItem",&relation_type);
							//GRM_create_relation(task_rev_tag,*new_item, relation_type,  NULLTAG, &relation);
							GRM_create_relation(task_rev_tag,*new_rev, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
						
						}
						
				    }
					
				 }
				
				}
				else
				{
				printf("\n NO dml");
				}
				
				
				MEM_free(rev_master_form_id);
		  
			}
			else
			{

	
						printf("\n NULLTAG new_item");fflush(stdout);
			}
		}
		else
		{


					printf("\n creation not allowed");fflush(stdout);
		}		
    }
return ifail;
}


/* FUNCTION TO CREATE ASSIGN BARREL PRE ACTION */
int tm_AltBrl_num_save( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
	
    Teamcenter::CreateInput *creInput= va_arg(args, Teamcenter::CreateInput *);
    
	//new_item               = va_arg(args, tag_t);
//	isnew                  = va_arg(args, int);
	printf("\n--->>>>>Inside new  >> ");fflush(stdout);
	printf("\n Entering AltBrl_iman_saveer()");fflush(stdout);
	
	bool isNull=false;
    tag_t *barrel_rev_tag = NULLTAG;
	int barrelcount=0;

	std::string item_id;
	std::string partnumber;
	
	 
	 creInput->getString("t5_PartNumber", partnumber, isNull ); ///get properties from the obj
	 creInput->getString("t5_BrlNum", item_id, isNull ); ///get properties from the obj
	 
	 
	 printf("The barrelnumber %s",item_id.c_str());fflush(stdout);
	 ITK_CALL_CKD(getQueryCKDBARREL(item_id.c_str(),(char *)"Barrel Number",&barrel_rev_tag,&barrelcount));
	 if (barrelcount>0 && barrel_rev_tag!=NULLTAG)
	 {
	  printf (" There is alraedy a barrel for this barrel number");;fflush(stdout);
	  printf("\n  Validation ERROR !! t5CKD.c::AltBrl_iman_saveer =%d",ifail);fflush(stdout);
	  EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not allowed to create Barrel Number,given Barrel number already exists");
	  return ITK_err;
	 } 
	 else
	 {
	   printf ("barrel not assigned for this part number");fflush(stdout);
	 }
	 
	 
	 
	 barrel_rev_tag = NULLTAG;
	 barrelcount=0;
	 
	 printf("The partnumber %s",partnumber.c_str());fflush(stdout);
	 ITK_CALL_CKD(getQueryCKDBARREL(partnumber.c_str(),(char *)"Part Number",&barrel_rev_tag,&barrelcount));
	 
	 printf ("The count of the barrel is %d",barrelcount);
	 if (barrelcount>0 && barrel_rev_tag!=NULLTAG)
	 {
	  printf (" There is alraedy a barrel for this part number");;fflush(stdout);
	  printf("\n  Validation ERROR !! t5CKD.c::AltBrl_iman_saveer =%d",ifail);fflush(stdout);
	  EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not allowed to create Barrel Number on same Part Number.Already Barrel number exists on the part");
	  return ITK_err;
	 } 
	 else
	 {
	  creInput->setString("object_name", item_id, isNull ); ///get properties from the obj
	  printf ("barrel not assigned for this part number");fflush(stdout);
	 
	 }
	
	
	return ifail;


}




/*LR indicator For CKD Dummy*/
/****************************************************************************
Function:       dynamic_pos_LOV
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_pos_LOV( char*** LR_LovValue  ) 
{

/* va_list for LOV_ask_values_msg */

 
    char   *user_name_string = NULL;
  
 
    char  ***values = NULL;
  
    int  
        ifail = ITK_ok;
      
      char *rolename=NULL;
      rolename =  (char *)MEM_alloc(100);

 	 tag_t  user = NULLTAG;
 
     int Lov_cnt=0;
  
	   printf("\n dynamic_pos_LOV");fflush(stdout);

	   CALLAPICKD(SA_init_module());
	   printf("\n SA_init_module");fflush(stdout);
	   CALLAPICKD(POM_get_user(&user_name_string, &user));
	   printf("\n POM_get_user");fflush(stdout);
	  
		tag_t  CurrentRoleTag = NULLTAG;
		char*       roleName = NULL ;//[SA_name_size_c+1]  ;
		ITK_CALL_CKD(SA_ask_current_role(&CurrentRoleTag));
		ITK_CALL_CKD(SA_ask_role_name2(CurrentRoleTag,&roleName));
		printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
		
		if(strcmp(roleName,"DBA")==0)
		{
		printf("\n\n  Inside DBA role : %s\n",roleName); fflush(stdout);
		setAddStr(&Lov_cnt,LR_LovValue,(char *)"L");
		
		setAddStr(&Lov_cnt,LR_LovValue,(char *)"R");
		
		}
		else if((strstr(roleName,"STDJ")!=0) || (strstr(roleName,"APLJ")!=0) || (strstr(roleName,"APLL")!=0) || (strstr(roleName,"STDL")!=0) )
		{
		printf("\n\n  Inside JSR/LKN role : %s\n",roleName); fflush(stdout);
		setAddStr(&Lov_cnt,LR_LovValue,(char *)"R");
		}
		else
		{
		printf("\n\n  Inside other role : %s\n",roleName); fflush(stdout);
		setAddStr(&Lov_cnt,LR_LovValue,(char *)"L");
		}

    return Lov_cnt;
}


/****************************************************************************
Function:       dynamic_pos_LengthsMethod
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_pos_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **LR_LovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n dynamic_pos_LengthsMethod");fflush(stdout);
  
  *length=dynamic_pos_LOV(&LR_LovValue);
  printf("\n dynamic_pos_LengthsMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_pos_ValuesMethod
Description:    This function used while creating CKD Dummy Part to populate L/R indicator
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_pos_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
	int Lov_cnt=0;
   
  
	 printf("\n dynamic_pos_ValuesMethod");fflush(stdout);
	  
	 *n_values=dynamic_pos_LOV(&LR_LovValue);
	 printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);

	 *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	 memset (*values, 0,  *n_values * sizeof(char*));

	 for (ii = 0; ii < *n_values; ii++)
	{ 
						
		(*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
		tc_strcpy ((*values)[ii], LR_LovValue[ii]);
				   
	  } 
	  
    return ifail; 
}


/*******************************SCHEDULE YEAR FOR LOT NUMBER */
	
/****************************************************************************
Function:       dynamic_SchYear_LOV
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_SchYear_LOV( char*** SchYear_LovValue  ) 
{

/* va_list for LOV_ask_values_msg */
  
   
    char  ***values = NULL;
  
    int   ifail = ITK_ok;
    
    int SchYear_cnt=0;
  
    printf("\n dynamic_SchYear_LOV");fflush(stdout);
	
	char TodayCurrYear[5] = {'\0'};
	time_t now;
	struct tm* now_tm;
    time(&now);
	now_tm = localtime(&now);

	strftime (TodayCurrYear, 5,"%Y", now_tm);
	printf("\n TodayCurrYear is===>[%s]",TodayCurrYear);fflush(stdout);
	
	setAddStr(&SchYear_cnt,SchYear_LovValue,TodayCurrYear);
	
	
    return SchYear_cnt;
}


/****************************************************************************
Function:       dynamic_SchYear_LengthsMethod
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_SchYear_LengthsMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 

  
	
    char  **SchYear_LovValue=NULL;
  
    int  ifail = ITK_ok;
   
  
   printf("\n dynamic_pos_LengthsMethod");fflush(stdout);
  
  *length=dynamic_SchYear_LOV(&SchYear_LovValue);
  printf("\n dynamic_SchYear_LengthsMethod===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_SchYear_ValuesMethod
Description:    This function used while creating CKD Lot Number to populate Schedule Year
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_SchYear_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 
 
    
    int    ifail = ITK_ok, ii = 0;
   
    char** SchYear_LovValue;
	int SchYear_cnt=0;
   
  
	  printf("\n dynamic_SchYear_ValuesMethod");fflush(stdout);
	  
	  *n_values=dynamic_SchYear_LOV(&SchYear_LovValue);
	  printf("\n dynamic_SchYear_ValuesMethod==>[%d]",*n_values);fflush(stdout);

	  *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	  memset (*values, 0,  *n_values * sizeof(char*));

		int m =0;
		printf("\n count=%d\n",*n_values);fflush(stdout);
		int array_size = *n_values;
		for(m=0;m<array_size;m++)
		{
			
			printf("\n SchYear_LovValue wt  %s",SchYear_LovValue[m]);fflush(stdout);
			*values[m] = SchYear_LovValue[m];
		   
		}
		
		 for (ii = 0; ii < array_size; ii++)
		{ 
		   printf("\n values attached %s",*values[ii]);fflush(stdout);
		}
  
  
    return ifail; 
}

/*******************************/

extern int CKDinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  ckddml_iman_save;
	METHOD_id_t  ckddml_rev_iman_save;
	METHOD_id_t  ckddml_rev_imantype_init_intl_props;
	METHOD_id_t  lot_number_iman_save;
	METHOD_id_t  BoxQty_number_iman_save;
	METHOD_id_t  ckddmy_partnumber_iman_save;
	METHOD_id_t  AltBrl_iman_save;
	METHOD_id_t methodpos;
	METHOD_id_t methodSchYear;
	
	printf("\n ############ After Rigister CKDinitmodule");fflush(stdout);
	
	
	/* Overriding IMAN_Save of DML Master for setting the nomenclature while creation */
	//CALLAPICKD(METHOD_find_method("T5_CkdDml", "IMAN_save", &ckddml_iman_save));
	CALLAPICKD(METHOD_find_method("T5_CkdDml", "ITEM_create", &ckddml_iman_save));
	if (ckddml_iman_save.id != NULLTAG)
    {	
	//	printf("\n before Rigister tm_ckddml_set_init_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddml_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_ckddml_set_init_val ,NULL));
		//CALLAPICKD(METHOD_add_action(ckddml_iman_save, METHOD_pre_action_type,(METHOD_function_t)tm_ckddml_set_init_val ,NULL));
		//printf("\n IN After Rigister tm_ckddml_set_init_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_ckddml_set_init_val  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	/* Overriding IMAN_Save of DML Revision for creating the task and releation with DML while creation */	
	CALLAPICKD(METHOD_find_method("T5_CkdDmlRevision", "IMAN_save", &ckddml_rev_iman_save));		
	if (ckddml_rev_iman_save.id != NULLTAG)
    {	
		//printf("\n before Rigister tm_create_ckdTask");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddml_rev_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_create_ckdTask,NULL));
		//printf("\n  After Rigister tm_create_ckdTask");fflush(stdout);
    }
	else
	{
		printf("\n After Rigister tm_create_ckdTask  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	/* Overriding IMANTYPE_init_intl_props of DML Revision for setting the ERC DML default value while creation */
	/*
	CALLAPICKD(METHOD_find_method("T5_CkdDmlRevision", "IMANTYPE_init_intl_props", &ckddml_rev_imantype_init_intl_props));		
	if (ckddml_rev_imantype_init_intl_props.id != NULLTAG)
    {		
		printf("\n  before Rigister tm_set_erc_dmlval_ckddml");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddml_rev_imantype_init_intl_props, METHOD_post_action_type,(METHOD_function_t)tm_set_erc_dmlval_ckddml,NULL));
		printf("\n  After Rigister tm_create_ckdTask");fflush(stdout);
    }
	else
	{
		printf("\n After Rigister tm_set_erc_dmlval_ckddml  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	
	/* Overriding IMAN_Save of Lot Number dialog Box */
	CALLAPICKD(METHOD_find_method("T5_LotNum", "ITEM_create", &lot_number_iman_save));
	if (lot_number_iman_save.id != NULLTAG)
    {	
		//printf("\n before Rigister tm_lot_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(lot_number_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_lot_num_gen_val ,NULL));
		//printf("\n IN After Rigister tm_lot_num_gen_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_lot_num_gen_val  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	
	/* Overriding IMAN_Save of BOX QUANTITY dialog Box */
	CALLAPICKD(METHOD_find_method("T5_BoxQty", "ITEM_create", &BoxQty_number_iman_save));
	if (BoxQty_number_iman_save.id != NULLTAG)
    {	
		//printf("\n before Rigister tm_Boxqty_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(BoxQty_number_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_Boxqty_num_gen_val ,NULL));
		//printf("\n IN After Rigister tm_Boxqty_num_gen_val");fflush(stdout);
    }
	else
	{
		//printf("\n IN After Rigister tm_Boxqty_num_gen_val  == NULL");fflush(stdout);
	}
	/* End overriden */
	
	
	/* Overriding IMAN_Save of CKD DUMMY dialog Box */
	CALLAPICKD(METHOD_find_method("T5_CkdDmy", "ITEM_create", &ckddmy_partnumber_iman_save));
	if (ckddmy_partnumber_iman_save.id != NULLTAG)
    {	
		//printf("\n before Rigister tm_ckdDmyPrt_num_gen_val");fflush(stdout);
		CALLAPICKD(METHOD_add_action(ckddmy_partnumber_iman_save, METHOD_post_action_type,(METHOD_function_t)tm_ckdDmyPrt_num_gen_val ,NULL));
	//	printf("\n IN After Rigister tm_ckdDmyPrt_num_gen_val");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_ckdDmyPrt_num_gen_val  == NULL");fflush(stdout);
	}
	/* End overriden */
	

	
	/* Overriding IMAN_Save of BARREL dialog Box */
	/*CALLAPICKD(METHOD_find_method("T5_AltBrl", "create#Teamcenter::CreateInput,*", &AltBrl_iman_save));
	if (AltBrl_iman_save.id != NULLTAG)
    {	
		printf("\n before Rigister tm_AltBrl_num_save");fflush(stdout);
		CALLAPICKD(METHOD_add_action(AltBrl_iman_save, METHOD_pre_action_type,(METHOD_function_t)tm_AltBrl_num_save ,NULL));
		printf("\n IN After Rigister tm_AltBrl_num_save");fflush(stdout);
    }
	else
	{
		printf("\n IN After Rigister tm_AltBrl_num_save  == NULL");fflush(stdout);
	}*/
	/* End overriden */
	

	/*L/R INDICATOR DYNAMIC LIST OF VALUES POPULATE FOR CKD DUMMY PART CREATION*/
	CALLAPICKD(METHOD_register_method( "T5_CkdDmyPosLov",LOV_ask_values_msg,&dynamic_pos_ValuesMethod, 0,&methodpos));
    CALLAPICKD(METHOD_register_method( "T5_CkdDmyPosLov",LOV_ask_num_of_values_msg,&dynamic_pos_LengthsMethod,0,&methodpos));
	//printf("\n IN ******************************dynamic_pos_Method == REGISTER");fflush(stdout);	
   /* End  */
               
    
	/* SCHEDULE YEAR DYNAMIC LIST OF VALUES POPULATE FOR LOT NUMBER CREATION DIALOG */
	CALLAPICKD(METHOD_register_method( "T5_LotNumSchYrLov",LOV_ask_values_msg,&dynamic_SchYear_ValuesMethod, 0,&methodSchYear));
    CALLAPICKD(METHOD_register_method( "T5_LotNumSchYrLov",LOV_ask_num_of_values_msg,&dynamic_SchYear_LengthsMethod,0,&methodSchYear));
	//printf("\n IN ******************************dynamic_SchYear_Method == REGISTER");fflush(stdout);	
   /* End  */

	
	return ifail;
	
}






//

extern int CKDServiceinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	int nargs = 5;
	int retValueType;
	int inputArgTypes[5] = {0};
	
	//printf("\n ############ After Rigister CKDinitmodule");fflush(stdout);	
	
	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE; 
	inputArgTypes[2] = USERARG_STRING_TYPE;
	inputArgTypes[3] = USERARG_STRING_TYPE;
	inputArgTypes[4] = USERARG_STRING_TYPE;
	retValueType = USERARG_STRING_TYPE ; 
	
	//printf("\n CKDinitmodule__CKDBarrelAssignFunc before....CKDBarrelAssignFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method((char *)"CKDBarrelAssignFunc",(USER_function_t)CKDBarrelAssignFunc,nargs,inputArgTypes,retValueType);	

	return ifail;	
}


extern "C" DLLAPI int tm_CKD_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registoring userservice....tm_CKD");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_CKD", "USER_init_module", (CUSTOM_EXIT_ftn_t)CKDinitmodule);
	ifail=CUSTOM_register_exit ( "tm_CKD", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)CKDServiceinitmodule);
//	printf("\n After registoring userservice....tm_CKD");fflush(stdout);
	return ( ITK_ok );
}


