
#include <time.h>
		#include <stdio.h>
		#include <stdlib.h>
		#include <string.h>
		#include <tc/tc.h>
		#include <tc/emh.h>
		#include <bom/bom.h>
		#include <tc/folder.h>
		#include <tccore/aom.h>
		#include <tccore/grm.h>
		#include <tccore/item.h>
		#include <pom/pom/pom.h>
		#include <tc/tc_macros.h>
		#include <bom/bom_attr.h>
		#include <tc/tc_startup.h> 
		#include <pie/pie.h>
		#include <tcinit/tcinit.h>
		#include <tc/preferences.h>
		#include <tccore/aom_prop.h>
		#include <fclasses/tc_string.h>
		#include <tccore/workspaceobject.h>
		#include <ss/ss_errors.h>
		#include <sa/user.h>
		#include <stdarg.h>
		#include <tccore/custom.h>
		#include <ict/ict_userservice.h>
		#include <ug_va_copy.h>
		#include <itk/mem.h>
		#include <user_exits/user_exits.h>
		#include <user_exits/user_exit_msg.h>
		#include <pom/enq/enq.h>
        #include <ae/ae.h>	
	    #include <unistd.h>
		

        #define ITK_err 919002
		#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
		#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

		#define ITK_CALL(x) {           \
			int stat;                     \
			char *err_string;             \
			if( (stat = (x)) != ITK_ok)   \
			{                             \
			EMH_get_error_string (NULLTAG, stat, &err_string);                 \
			printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
			if(err_string) MEM_free(err_string);                                \
			exit (EXIT_FAILURE);                                                   \
			}                                                                    \
		}
		
void setAddTagP1(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}

void setAddStrP1(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n VVVVVVVVVVVVVV1===%s",(*strset)[*count-1]);fflush(stdout);


	}

int queryobject(char* propName ,char* value, int* n_found, tag_t** items)
		{
			int ifail = ITK_ok;
			

			printf("\n\n Inside queryobject......");fflush(stdout);

			tag_t        query           = NULLTAG;

			char
			   *qry_entries[] = {"Type","Name"},
			   *qry_values[]  = {(char *)propName, (char *)value};
			   
			ITK_CALL(QRY_find2("General...", &query));

			ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, n_found, items));

			printf("\n queryobject n_found==%d",*n_found);fflush(stdout);
			

			return ifail;


		} 
int queryobject1(char* propName ,char* value, int* n_found, tag_t** items)
                {
                        int ifail = ITK_ok;


                        printf("\n\n Inside queryobject......");fflush(stdout);

                        tag_t        query           = NULLTAG;

                        char
                           *qry_entries[] = {"Type","Item ID"},
                           *qry_values[]  = {(char *)propName, (char *)value};

                        ITK_CALL(QRY_find2("Item Revision...", &query));

                        ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, n_found, items));

                        printf("\n queryobject n_found==%d",*n_found);fflush(stdout);


                        return ifail;


                }

char* removeChar_SVRBOMCompare(char *in) 
{	
	printf("\n Test Inside Function removeChar \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\n' && in[j] != '\r' )
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

 

return tmp;
}

void t5AddStrToSVR(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void trimTrailing_SVRBOMComp(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}


int FindOrCreateDatasetAndAttachInWF_SVRBOMComp(tag_t ERCDmlName,char *datasetName, char *datasetLocation)
{
	int	status	=	ITK_ok;
	int ifail=0;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t dml_Ref_Rel       = NULLTAG;
	tag_t dml_Ref_Rel_t     = NULLTAG;
    char* dmlNameTest = NULL;
	printf("\n\n\n Inside FindOrCreateDatasetAndAttachInWF  got datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);
	WSOM_ask_name2(ERCDmlName,&dmlNameTest);
   	printf("\n\n\n dml nUMBER = %s ",dmlNameTest);fflush(stdout);
   if(access(datasetLocation,F_OK)!=-1)
	{
		printf("\n [%s] access ok\n",datasetLocation);fflush(stdout);
		ITK_CALL(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		printf("\n IMAN_reference found\n");fflush(stdout);
		TC_write_syslog("datasetfile accessed\n");
		ITK_CALL(AE_find_datasettype2("MSExcelX",&msWordType));//MSExcelx
		printf("\n datasetType Fetched\n");fflush(stdout);
		if(msWordType == NULLTAG)
		{
				printf("\n datasetType refrences not found\n");fflush(stdout);
				TC_write_syslog("Could not find Dataset Type Text. Please check data model\n");
				//continue;
		}
		else
		{
			printf("\n datasetType refrences found\n");fflush(stdout);
			int datasetExistsFlag = 0;
			tag_t * DatasetObj = NULL;
			int datasetCount = 0;
			char *ERCDmlDatasetName = NULL;
			//Expand the task to check if dataset is already present
			ITK_CALL(GRM_list_secondary_objects_only(ERCDmlName,dml_Ref_Rel,&datasetCount,&DatasetObj));
			if(datasetCount>0)
			{
				int k = 0;
				for(k=0;k<datasetCount;k++)
				{
					/*Check if Dataset already present or not*/
					ITK_CALL(AOM_ask_value_string(DatasetObj[k],"object_name",&ERCDmlDatasetName));
					printf("\n ERCDmlDatasetName[%s] \n",ERCDmlDatasetName);fflush(stdout);
					if(strcmp(ERCDmlDatasetName,datasetName)==0)
					{
						datasetExistsFlag=1;
						wordDataset = DatasetObj[k];
						printf("\n ERCDmlDatasetName[%s] already exists\n",ERCDmlDatasetName);fflush(stdout);
						break;
					}
				}
				
			}
			//End Expand the task to check if dataset is already present
			if(wordDataset==NULLTAG)
			{
				ITK_CALL(AE_create_dataset_with_id(msWordType,datasetName,"","","",&wordDataset));
				printf("\n Dataset[%s] Created\n",datasetName);fflush(stdout);
				ITK_CALL(AE_save_myself(wordDataset));
				printf("\n DataSet Saved\n");fflush(stdout);
				ITK_CALL(GRM_create_relation(ERCDmlName,wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
				printf("\n Relation Between DML and dataset created\n");fflush(stdout);
				ITK_CALL(AOM_load(dml_Ref_Rel_t));
				printf("\n Relation loaded\n");fflush(stdout);
				ITK_CALL(GRM_save_relation(dml_Ref_Rel_t));
				printf("\n Relation of DML and dataset saved\n");fflush(stdout);
				
			}
			//	ITK_CALL(AE_find_dataset2(datasetName,&wordLatestDat_t));
			ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
			printf("\n Fetched already existing dataset\n");fflush(stdout);
			ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
			printf("\n Refreshing Dataset\n");fflush(stdout);
			ITK_CALL(AOM_lock(wordDataset));
			if(datasetExistsFlag==1)
			{
				ITK_CALL(AE_remove_dataset_named_ref2(wordLatestDat_t,"excel"));
				printf("\n Refrence Removed\n");fflush(stdout);
			}

			/*
			//only refreshing of the object
			ITK_CALL(AE_import_named_ref(wordLatestDat_t,"excel",datasetLocation,NULL,SS_BINARY));
			//if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok);
			printf("\n File Updated\n");fflush(stdout);
			ITK_CALL(AE_save_myself(wordLatestDat_t));
			printf("\n Saved all things\n");fflush(stdout);
			ITK_CALL(AOM_unlock(wordDataset));
			remove(datasetLocation);
			printf("\n File removed\n");fflush(stdout);*/
			//Modification for TC12 Upgradation
			int ref_count;
                char **ref_list;
                tag_t filetag   = NULL;
                IMF_file_t fileDescriptor;

                ITK_CALL(AE_ask_datasettype_refs(msWordType, &ref_count, &ref_list));
                                                                

                ITK_CALL(IMF_import_file(datasetLocation,NULL, SS_BINARY, &filetag, &fileDescriptor));
                printf("\nFile Imported--->");fflush(stdout);
                ITK_CALL(AOM_save(filetag));
                printf("\nFile saved--->");fflush(stdout);

                ITK_CALL(AE_add_dataset_named_ref2(wordLatestDat_t,ref_list[0],AE_PART_OF ,filetag));
                printf("\n DatesetName44\n");fflush(stdout);
                ITK_CALL(AOM_save(wordLatestDat_t));
                printf("\n DatesetName55 \n");fflush(stdout);			
		//END Modification for TC12 Upgradation
		   // if(docFile) MEM_free(docFile);

		}
	}
	else
	{
		printf("\n Dataset location not presewnt[%s]" , datasetLocation);fflush(stdout);
	}
	return ITK_ok;
}


	int ITK_user_main( int argc , char* argv[] )
		{
			int 	Z 					= 0;
			int 	childCount			= 0;
			int 	varientCount			= 0;
			int 	count			= 0;
			int 	i;
			int		n;
			FILE *svrfile		= NULL;
			FILE *bomfile		= NULL;
			char	*name;
			tag_t   *varient=NULLTAG;
			tag_t 	rule=NULLTAG;
			tag_t 	*children=NULLTAG;
		 tag_t   bom_window=NULLTAG;
        tag_t   top_line=NULLTAG;
        int     n_saved_variant_rules=0;
        tag_t  *saved_variant_rules=NULL;
        tag_t   bom_variant_rule=NULLTAG;
        logical list_changed=FALSE;
        int     n_options=0;
        tag_t  *options=NULL;
        tag_t  *option_revs=NULL;
		int str_count=0;
	char **bom_list=NULL;
	char *rev_rule_name=NULL;
	char *closure_rule_name=NULL;
	char *bl_item_name=NULL;
	int k;
	int x;
	char *parent_child;
	tag_t platformRevTag=NULLTAG;
			int rule_count;	
			int rulefound;
			
			tag_t   close_tag=NULLTAG;
	tag_t   *bom_variant_rules=NULLTAG;
	//tag_t variantRuleTag=NULLTAG;
	
	tag_t *closurerule=NULLTAG;
	
	
	
	char *svrfilename=NULL;
	char *bomfilename=NULL;
	
	parent_child=(char *)MEM_alloc( 200 );
	svrfilename=(char *)MEM_alloc( 50 );
	bomfilename=(char *)MEM_alloc( 50 );
	
				 tag_t* svrtags = NULLTAG;		
				 tag_t* platformtags = NULLTAG;		
				 tag_t svrtag = NULLTAG;		
				 tag_t platformtag = NULLTAG;		
				 tag_t topline = NULLTAG;		
				int count1;

                
			FILE* dmlFile =NULL; /*added by Palash*/
			
			
			ITK_set_journalling (TRUE);
			char* platform = ITK_ask_cli_argument("-l=");
			char* svrs = ITK_ask_cli_argument("-v=");
			char* filedetails = ITK_ask_cli_argument("-f=");
			printf("svrs==%s platform==%s\n",svrs,platform);
			
			char* svrs1 = NULL;
			tc_strdup(svrs,&svrs1);
			
			ITK_CALL(ITK_auto_login());


			
			//ITK_CALL(queryobject1("T5_Platform",platform, &count1, &platformtags));
			
			/*added by Palash*/
			char *dmlToken = (char*) malloc(100);
            char *tmpFileName = (char*) malloc(100);
            tmpFileName = tc_strcpy(tmpFileName,filedetails);
            printf("\nFile Name = %s\n", tmpFileName);
            dmlToken = strtok(tmpFileName, "/tmp/");
            dmlToken = strtok(dmlToken, "_");
            printf("\ndmlToken Number = %s\n", dmlToken);
    		
            /*added by Palash*/
			
			const char *attrs2[2];
		const char *values2[2];
		attrs2[0] ="item_id";
		attrs2[1] ="object_type";
		values2[0] = (char *)platform;
		values2[1] = "T5_Platform";
		
		ITK_CALL(ITEM_find_items_by_key_attributes(2,attrs2, values2, &count1, &platformtags));
		
		platformtag=platformtags[count1-1];
		
	
			printf("\n count1=============%d", count1);fflush(stdout);
			
			char *svr1;
			char* svr;
			
			int strCnt=0;
			char** strBuff=NULL;
			char* tmpsvr = tc_strtok(svrs1, ",");
    // Keep printing tokens while one of the
    // delimiters present in str[].

	 while (tmpsvr != NULL) {
	t5AddStrToSVR(&strCnt,&strBuff,tmpsvr);
          tmpsvr = tc_strtok(NULL, ",");
}
int g;
    for(g=0;g<strCnt-1;g++) {
	svr=strBuff[g];
        printf("\n SVR== % s\n", svr);
	
	printf("\n new SVR== %s\n", svr );
		sprintf(svrfilename,"/tmp/%s.svr",svr);
		sprintf(bomfilename,"/tmp/%s.bom",svr);
		
		svrfile=fopen(svrfilename,"w");
		bomfile=fopen(bomfilename,"w");
      	
			ITK_CALL(queryobject("VariantRule",svr, &count, &svrtags));

				svrtag=svrtags[count-1];
				
				
				ITK_CALL(ITEM_ask_latest_rev(platformtag,&platformRevTag));

	char* expression=NULL;
	char* formula=NULL;
	int countV;
	tag_t* secondary_objects=NULLTAG;
	tag_t relation_dep=NULLTAG;
    ITK_CALL(BSLV_get_variant_expression(NULLTAG,svrtag,&expression ));
	printf("\n expression=%s",expression);fflush(stdout);
	fprintf(svrfile,"%s\n",expression);fflush(svrfile);
	fclose(svrfile);
		if(svrtag)
	{

		printf("\n inside the variant rule condition");fflush(stdout);

		
		ITK_CALL(CFM_find( "ERC Release and above", &rule ));
		


		printf("\n after revisionRule find=[%u] ",rule);fflush(stdout);
		
		

		ITK_CALL(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
			printf ("rule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("closure rule found \n");fflush(stdout);
			// MEM_free(tags_found);
		}
		ITK_CALL(BOM_create_window (&bom_window)); 
		ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, platformRevTag, NULLTAG, &top_line));
		ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
		ITK_CALL(BOM_window_set_closure_rule(bom_window,close_tag,0,NULL,NULL));
		if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
		char *vname;
		if(bom_variant_rule==NULLTAG)
		{
			printf("\n  bom_variant_rule==NULLTAG");fflush(stdout);

		} 
		else 
		{
			printf("\n  bom_variant_rule NOT NULLTAG");fflush(stdout);
		}
		printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);
		tag_t varrule_tags[]={svrtag};
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));
		ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,varrule_tags))   ;
		ITK_CALL(BOM_window_hide_variants (bom_window));
		ITK_CALL(BOM_window_hide_unconfigured(bom_window));

		int var_list_count;
		tag_t *variant_rule_list=NULLTAG;
		BOM_window_ask_variant_rules(bom_window,&rule_count,&bom_variant_rules);

		printf("\n RULE COUNT===%d", rule_count); fflush(stdout);

		for(k=0;k<rule_count;k++)
		{
			svrtag=bom_variant_rules[k];
			ITK_CALL(AOM_ask_value_string(svrtag,"object_string", &vname));
			printf("\n VR2[%d]=%s",k,vname);fflush(stdout);
		}
		printf("\n After inside bom_window-----\n"); fflush(stdout);			
		int n_lines1;
		tag_t *lines;
		int x;

		if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
		printf("\n Child LIne1=%d",n_lines1);fflush(stdout);
		for(x=0;x<n_lines1;x++)
		{

			tag_t childline=lines[x];
			
		//	setAddTagP1(&moduleTagList_cnt,&retModules,lines[x]);
			
			//retModules=lines;               //Returning the modules of CCV
			tag_t child_item;
			char *bl_item_id;
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_item_id", &bl_item_id ));
			ITK_CALL(AOM_ask_value_string(childline, "bl_item_object_name", &bl_item_name ));
			printf("\n [%d] bl_item_id1=%s bl_item_name==%s",x,bl_item_id,bl_item_name);fflush(stdout);
			tag_t bom_window1;
			tag_t top_line1;
			int n_lines2;
			tag_t *lines2;
			if(BOM_line_ask_child_lines(childline, &n_lines2, &lines2));
			printf("\n Child LIne2=%d",n_lines2);fflush(stdout);
			int y;
			for(y=0;y<   n_lines2;y++)
			{

				tag_t childline2=lines2[y];
				char *bl_item_id2;
				ITK_CALL(AOM_ask_value_string(childline2, "bl_item_item_id", &bl_item_id2 ));
				
				tc_strcpy(parent_child,"");
				tc_strcat(parent_child,bl_item_id);
				tc_strcat(parent_child,"-");
				tc_strcat(parent_child,bl_item_name);
				tc_strcat(parent_child,"#");
				tc_strcat(parent_child,bl_item_id2);
				
				//collection_add(&v, parent_child);
				
				setAddStrP1(&str_count,&bom_list,parent_child);
				
				printf("\n[%d] bl_item_id2=%s %s",y,bl_item_id2, parent_child);fflush(stdout);
			}

		}                                                                                                      
		

		for (x=0;x<str_count; x++)
		{
		fprintf(bomfile,"%s\n",removeChar_SVRBOMCompare(bom_list[x]));
		}
		fclose(bomfile);

		if(bom_window!=NULLTAG)
				{
				ITK_CALL(BOM_close_window(bom_window));
				bom_window=NULLTAG;
				}
	}

	
    }


char cmd[200];
		  //cvprod 
//sprintf(cmd,"$JAVA_HOME/bin/java -jar /user/dkk04042/report/svrcmp/TCReportConfigurator.jar %s %s %s",platform,svrs,filedetails);
		//uaprod
		   sprintf(cmd,"$JAVA_HOME/bin/java -jar /home/dkk04042/report/svrcmp/TCReportConfigurator.jar %s %s %s",platform,svrs,filedetails);
		   system(cmd);


/*added by Palash*/

            char OneRowData[500];
            /*char *dmlToken = (char*) malloc(100);
            char *tmpFileName = (char*) malloc(100);
            tmpFileName = tc_strcpy(tmpFileName,filedetails);
            printf("\nFile Name = %s\n", tmpFileName);
            dmlToken = tc_strtok(tmpFileName, "/tmp/");
            dmlToken = tc_strtok(dmlToken, "_");
            printf("\ndmlToken Number = %s\n", dmlToken); //22cu72653*/
            tag_t dmlNumber = NULLTAG;
            tag_t dmlNumberRev = NULLTAG;
            ITEM_find_item(dmlToken,&dmlNumber);
            ITEM_ask_latest_rev(dmlNumber,&dmlNumberRev)	;
			dmlFile=fopen(filedetails,"r");
					printf("\n filedetails=[%s] opened\n",filedetails);fflush(stdout);
					if(dmlFile == NULL) 
						{
							printf("\n Error opening file");fflush(stdout);

							printf("\nSVRReport: SVR Report is not Generated for : %s \n",dmlToken);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR-SVRReport: SVR Report is not Generated, Kindly Raise Ticket in DML Support Catagory.");
							return ITK_err;
						  //return(-1);
						}
					while(fgets(OneRowData,500,dmlFile)!=NULL)
					{
						printf("\n OneRowData:[%s]",OneRowData);fflush(stdout);
						char * datasetName = NULL;
						char * datasetLocation = NULL;
						datasetName = tc_strtok(OneRowData,":");
						datasetLocation = tc_strtok(NULL,":");
						trimTrailing_SVRBOMComp(datasetLocation);
						trimTrailing_SVRBOMComp(datasetName);
						
						printf("\n datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);
						ITK_CALL(FindOrCreateDatasetAndAttachInWF_SVRBOMComp(dmlNumberRev,datasetName,datasetLocation));
						printf("\n FindOrCreateDatasetAndAttachInWF_SVRBOMComp called successfully \n");fflush(stdout);
					}


                    /*added above by Palash*/


		
	/*ITK_CALL(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
						if(relation_dep != NULLTAG)
						{
							printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);	
						}			

						ITK_CALL(GRM_list_secondary_objects_only(platformtag,relation_dep,&countV,&secondary_objects));
						printf("\n Smc0HasVariantConfigContext countV :%d ..\n",countV); fflush(stdout);
	
	
	ITK_CALL(BSLV_convert_variant_expression_to_formula(secondary_objects[0],NULLTAG,expression,&formula ));
	printf("\n formula=%s",formula);fflush(stdout);
	*/
	/*
	
	

    tag_t opt_tag = options[0];
    tag_t opt_rev_tag = option_revs[0];
    
    if(options) MEM_free(options);
    if(option_revs) MEM_free(option_revs);
  
    int n_values = 0; 
    int *index = NULL;



    ITK_CALL( BOM_list_option_rev_values(opt_rev_tag, &n_values, &index));
   int ii; 
    for( ii = 0; ii < n_values; ii++)
    {                             
        char *value = NULL;
        ITK_CALL( BOM_ask_option_rev_value(opt_rev_tag, index[ii], &value));
printf("\n value==%s",value);		
		
	}
*/			
           
			ITK_CALL(POM_logout(false))	;
			return 0;
		}
