/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_CreateCabBom.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for generating UPLMBOM Object and Reports.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   30-11-2022
* ENVIRONMENT	:   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 30/11/2022   	 Manish Kumar						    Base Code
* 			

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>

#define ITK_errStore 91900002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#include <epm/epm_task_template_itk.h>
#define ITK_err 919002
#define ERROR_919005 919005




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


//Global Variables
char 	*ClosureRule	    =	NULL;
char 	*ClosureRev	        =	NULL;
tag_t 	D9Z01UnderVeh	=	NULL;

void autoresizestrAdd(char **src,char* dest)
{
        // char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
         char * desc = dest ? dest : "NA";
        //printf("\n autoresizestrAdd src len==%d",strlen(*src));
        //printf("\n autoresizestrAdd desc len==%d",strlen(desc));
        const size_t a = strlen(*src);
        const size_t b = strlen(desc);
        const size_t size_ab = a + b + 2;
   // src = MEM_realloc(src, size_ab);
        *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
        tc_strcat(*src , desc);
}

void autoresizeTagAdd(int *count,tag_t **objlist,tag_t obj )
{
	printf("\n 1234 [%d]",*count);fflush(stdout);
	char* childItemName =NULL;
	*count=*count+1;
	if(*count==1)
	{
		printf("\n hajdbjashchjhd [%d]",*count);fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		printf("\n else [%d]",*count);fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	printf("\n 9999999999 : [%d]",*count);fflush(stdout);
	(*objlist)[*count-1] = obj; 
	ITKCALL(AOM_ask_value_string((*objlist)[*count-1],"item_id",&childItemName));
	//printf("\n hello dear :[%s]",childItemName);fflush(stdout);
}

char* subString(char* mainStringf ,int fromCharf , int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) MEM_alloc(1*sizeof(char*));
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}
/*
char* currentViewMask(char* plantName)
{
	char *retPlant;
	retPlant = (char*) MEM_alloc(20*sizeof(char*));
	 tc_strcpy(retPlant,"");
	if(tc_strcmp(plantName,"APLA")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskA");
	else if(tc_strcmp(plantName,"APLC")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskC");
	else if(tc_strcmp(plantName,"APLD")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskD");
	else if(tc_strcmp(plantName,"APLJ")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskJ");
	else if(tc_strcmp(plantName,"APLL")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskL");
	else if(tc_strcmp(plantName,"APLP")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskP");
	else if(tc_strcmp(plantName,"APLS")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskS");
	else if(tc_strcmp(plantName,"APLU")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskV");
	else if(tc_strcmp(plantName,"APLV")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskV");
	else if(tc_strcmp(plantName,"MBOM")==0)
		tc_strcpy(retPlant,"bl_occ_t5_CurrentViewMaskM");
	printf("\n currentViewMask is [%s]",retPlant);fflush(stdout);	
	return retPlant;
}

char* getView(char* plantName)
{
	char *retPlant;
	retPlant = (char*) MEM_alloc(4*sizeof(char*));
	 tc_strcpy(retPlant,"");
	if(tc_strcmp(plantName,"APLA")==0)
		tc_strcpy(retPlant,"T5_APLAView");
	else if(tc_strcmp(plantName,"APLC")==0)
		tc_strcpy(retPlant,"T5_APLCView");
	else if(tc_strcmp(plantName,"APLD")==0)
		tc_strcpy(retPlant,"T5_APLDView");
	else if(tc_strcmp(plantName,"APLJ")==0)
		tc_strcpy(retPlant,"T5_APLJView");
	else if(tc_strcmp(plantName,"APLL")==0)
		tc_strcpy(retPlant,"T5_APLLView");
	else if(tc_strcmp(plantName,"APLP")==0)
		tc_strcpy(retPlant,"T5_APLPView");
	else if(tc_strcmp(plantName,"APLS")==0)
		tc_strcpy(retPlant,"T5_APLSView");
	else if(tc_strcmp(plantName,"APLU")==0)
		tc_strcpy(retPlant,"T5_APLUView");
	else if(tc_strcmp(plantName,"APLV")==0)
		tc_strcpy(retPlant,"T5_APLVView");
	else if(tc_strcmp(plantName,"MBOM")==0)
		tc_strcpy(retPlant,"T5_MBOMView");
	printf("\n View is [%s]",retPlant);fflush(stdout);	
	return retPlant;
}

void printTagLoop(tag_t* childList, int count)
{
	int i=0;
	tag_t childPtr = NULLTAG;
	char* partNumber = NULL;
	for(i=0;i<count;i++)
	{
		childPtr = childList[i];
		ITKCALL(AOM_ask_value_string(childPtr,"item_id",&partNumber));
		printf("\n %d.child ItemName:[%s]",i,partNumber);fflush(stdout);
	}
	
}


void getCharArrey( char* input, int len ,char**plant)
{
	int 	 A				 = 0;
	int      index			 = 0;
	char* 	 tokvalue        = NULL;
	char*	 token			 = NULL;
	char value[len+1];	
	strcpy(value,input);
	token=strtok(value,",");
	while(token!=NULL)
	{
		printf("\n token : [%s]\n",token);fflush(stdout);
		plant[index]=token;
		index=index+1;
		token=strtok(NULL,",");
	} 
}


void get_Plant(char* taskInput, char** retPlant)
{
	printf("\n selectedTask : [%s]\n",taskInput);fflush(stdout);
	char* temp1 = NULL;
	char* temp2 = NULL;
	char* temp3 = NULL;
	tc_strcpy(*retPlant,"");
	temp1 = strtok(taskInput,"_");
	temp2 = strtok(NULL,"_");
	temp3 = strtok(NULL,"_");
	printf("\n temp3 :[%s]\n",temp3);fflush(stdout);
	autoresizestrAdd(&*retPlant,temp3);
	//ITKCALL(tc_strtok_and_delimiter(taskInput,"_",temp1));
}

void GetBomClosureRule(char* view, char* plantName)
{
    tc_strcpy(ClosureRule,"");
    tc_strcpy(ClosureRev,"");
    if(tc_strcmp(view,"ERC")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleERC");
        tc_strcpy(ClosureRev,"ERC release and above");
    }
	else if(tc_strcmp(view,"MBOM")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM");
        tc_strcpy(ClosureRev,"MBOM Release and Above");
    }
	else if(tc_strcmp(view,"MBOM1")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM");
        tc_strcpy(ClosureRev,"ERC release and above");
    }
    else if (tc_strcmp(view,"APL")==0)
    {
        if (tc_strcmp(plantName,"APLJ")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLJ");
            tc_strcpy(ClosureRev,"ERC release and above");
        }
        else if (tc_strcmp(plantName,"APLL")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLL");
            tc_strcpy(ClosureRev,"APLL Release and Above");
        }
        else if (tc_strcmp(plantName,"APLD")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLD");
            tc_strcpy(ClosureRev,"APLD Release and Above");
        }
        else if (tc_strcmp(plantName,"APLP")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPL");
            tc_strcpy(ClosureRev,"APL Release and Above");
        }
    }
	else
	{
		printf("\n D9Z01 is not live for input plant\n");fflush(stdout);
	}
    printf("\n ClosureRule = %s\n ",ClosureRule);fflush(stdout);
    printf("\n ClosureRev = %s\n ",ClosureRev);fflush(stdout);
}

//Expand Vehicle in APL View and check if D9Y01 is present or not
void checkD9Y01UnderVeh(tag_t itemRev,char* tmpPlant,int* flagD9Y01UnderVeh)
{
	printf("\n*****D9Y01 Check under Vehicle*******\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d,",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		char *childItemName = NULL;
		char *bl_item_id2 = NULL;
		ITKCALL(BOM_line_unpack (child[childIterator]));
		ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
		ITKCALL(BOM_line_ask_attribute_tag(child[childIterator], iChildItemTag, &t_ChildItemRev));
		//ITKCALL(AOM_ask_value_tag(child[childIterator], "bl_revision", &t_ChildItemRev ));
		//ITKCALL(AOM_ask_value_string(child[childIterator], "bl_item_item_id", &bl_item_id2 ));
		//printf("\n[%d] bl_item_id2=%s",childIterator,bl_item_id2);fflush(stdout);
		//t_ChildItemRev = child[childIterator];
		if(t_ChildItemRev!=NULLTAG)
		{
			//ITKCALL(AOM_UIF_ask_value(t_ChildItemRev,"bl_item_item_id",&childItemName))
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			if(tc_strstr(childItemName,"D9Y01")!=NULL)
			{
				*flagD9Y01UnderVeh = *flagD9Y01UnderVeh +1;
				printf("\nD9Y01 found under :[%s]\n" ,childItemName );fflush(stdout);
			}
		}
	}
	printf("\n *flagD9Y01UnderVeh : [%d]", *flagD9Y01UnderVeh);fflush(stdout);
}


void checkD9Z01UnderVeh(tag_t itemRev,char* tmpPlant,int* flagD9Z01UnderVeh)
{
	printf("\n *********Check D9Z01 under vehicle*******\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule ** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule ** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d,",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		char *childItemName = NULL;
		char *bl_item_id2 = NULL;
		ITKCALL(BOM_line_unpack (child[childIterator]));
		ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
		ITKCALL(BOM_line_ask_attribute_tag(child[childIterator], iChildItemTag, &t_ChildItemRev));
		//ITKCALL(AOM_ask_value_tag(child[childIterator], "bl_revision", &t_ChildItemRev ));
		//ITKCALL(AOM_ask_value_string(child[childIterator], "bl_item_item_id", &bl_item_id2 ));
		//printf("\n[%d] bl_item_id2=%s",childIterator,bl_item_id2);fflush(stdout);
		//t_ChildItemRev = child[childIterator];
		if(t_ChildItemRev!=NULLTAG)
		{
			//ITKCALL(AOM_UIF_ask_value(t_ChildItemRev,"bl_item_item_id",&childItemName))
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			if(tc_strstr(childItemName,"D9Z01")!=NULL)
			{
				*flagD9Z01UnderVeh = *flagD9Z01UnderVeh+1;
				printf("\nD9Z01 found :[%s]\n" ,childItemName );fflush(stdout);
				D9Z01UnderVeh = t_ChildItemRev;
			}
		}
	}
	printf("\n-------flagD9Z01UnderVeh : [%d]",*flagD9Z01UnderVeh);fflush(stdout);
}

void checkControlObjectLive(char* t5_Syscd , char* t5_SubSyscd , char* t5_DelInd , int* coFlag , tag_t* coD9Z01)
{
	printf("\n*******Inside checkControlObjectLive********\n");fflush(stdout);
	tag_t 	query_tag = NULLTAG;
	tag_t* QuerySOB =NULLTAG;
	int     noOfArg    = 3;
	char    *qry_attrs[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char	**qry_values= (char **) MEM_alloc(10 * sizeof(char *));
	int  QuerySOBCount=0;	
	if(QRY_find("Control Objects...", &query_tag));
	if (query_tag)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_values[0] = t5_Syscd;
		qry_values[1] = t5_SubSyscd;
		if(tc_strcmp(t5_DelInd,"True")==0)
			qry_values[2] = "1";
		else if(tc_strcmp(t5_DelInd,"False")==0)
			qry_values[2] = "0";
		else
			qry_values[2] = "";
		printf("\n qry_values :[%s]:[%s]:[%s]",qry_values[0],qry_values[1],qry_values[2]);fflush(stdout);
		if(QRY_execute(query_tag, noOfArg, qry_attrs, qry_values, &QuerySOBCount, &QuerySOB));
		printf("\n QuerySOBCount :[%d]",QuerySOBCount);fflush(stdout);
		if(QuerySOBCount>0)
		{
			*coFlag = 1;
			*coD9Z01 = QuerySOB[0];
		}
	}
}

void getControlObjectDetails(tag_t coItem,char** clubbedInformation)
{
	printf("\n*******Inside checkControlObjectLive********\n");fflush(stdout);
	char* info = NULL;
	info = (char *) MEM_alloc(200);
	tc_strcpy(*clubbedInformation,"");
	tc_strcpy(info,"");
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo1",&info));
	printf("\n ^^^^info1 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo2",&info));
	printf("\n ^^^^info2 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo3",&info));
	printf("\n ^^^^info3 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo4",&info));
	printf("\n ^^^^info4 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo5",&info));
	printf("\n ^^^^info5 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo6",&info));
	printf("\n ^^^^info6 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo7",&info));
	printf("\n ^^^^info7 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo8",&info));
	printf("\n ^^^^info8 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_Userinfo9",&info));
	printf("\n ^^^^info9 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);
	ITKCALL(AOM_ask_value_string(coItem,"t5_userinfo10",&info));
	printf("\n ^^^^info10 : [%s]",info);fflush(stdout);
	autoresizestrAdd(&*clubbedInformation,info);	
	
}

void getCabBomLineMbomView(tag_t itemRev,char* clubbedInformation,tag_t** cabBomLineForD9Z01 , int * cabBomLineCount)
{
	printf("\n*******Inside getCabBomLineMbomView with ERC Closure Rule********\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count getCabBomLineMbomView %d,",count);fflush(stdout);
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		ITKCALL(BOM_line_unpack (child[childIterator]));
		ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
		ITKCALL(BOM_line_ask_attribute_tag(child[childIterator], iChildItemTag, &t_ChildItemRev));
		if(t_ChildItemRev!=NULLTAG)
		{
			char *childItemName = NULL;
			tag_t tempTag = NULLTAG;
			char* subModAddress = NULL;
			char* childPartType = NULL;
			char* tempSubModAdd = NULL;
			subModAddress = (char*)MEM_alloc(1*sizeof(char*));
			tc_strcpy(subModAddress,"");
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&childPartType));
			printf("childPartType:[%s]",childPartType);fflush(stdout);
			if(tc_strcmp(childPartType,"M")==0)
			{
				ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_ModuleAddress",&tempSubModAdd));
				if(strlen(tempSubModAdd)==5)
					autoresizestrAdd(&subModAddress,tempSubModAdd);
				else
				{
					autoresizestrAdd(&subModAddress,subString(childItemName,4,5));
				}
				printf("\n subModAddress : [%s] \n",subModAddress);fflush(stdout);
				if(tc_strstr(clubbedInformation,subModAddress)!=NULL)
				{
					printf("\n Submodule address present in Control Object [%d]\n",*cabBomLineCount);fflush(stdout);
					autoresizeTagAdd(cabBomLineCount,&*cabBomLineForD9Z01,t_ChildItemRev);
				}
			}
		}
	}
}
void getCabBomLineAPLView(tag_t itemRev,tag_t** cabBomLineForD9Z01 , int* cabBomLineCount)
{
	printf("\n*******Inside D9Z01 Bom Line in APL Plant View********\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d,",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		ITKCALL(BOM_line_unpack (child[childIterator]));
		ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
		ITKCALL(BOM_line_ask_attribute_tag(child[childIterator], iChildItemTag, &t_ChildItemRev));
		if(t_ChildItemRev!=NULLTAG)
		{
			char *childItemName = NULL;
			tag_t tempTag = NULLTAG;
			char* childPartType = NULL;
			char* tempSubModAdd = NULL;
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.D9Z01 child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&childPartType));
			printf("childPartType:[%s]",childPartType);fflush(stdout);
			printf("\n Submodule address present in Control Object [%d]\n",*cabBomLineCount);fflush(stdout);
			autoresizeTagAdd(cabBomLineCount,&*cabBomLineForD9Z01,t_ChildItemRev);
		}
	}
}
//This will compare Bom1 with Bom2 and will return all parts of Bom1 which are not in Bom2 and its changeCount
void fromToBomCompare(tag_t* Bom1,tag_t* Bom2,int bomcount, tag_t** bomLineChanges , int * changeCount)
{
	printf("\n **********fromToBomCompare********");fflush(stdout);
	int iteratorBom1,iteratorBom2=0;
	char* partNumberBom1 = NULL;
	char* partNumberBom2 = NULL;
	tag_t Bom1Ptr = NULLTAG;
	tag_t Bom2Ptr = NULLTAG;
	int bomChkFlag =0;
	for(iteratorBom1=0;iteratorBom1<bomcount;iteratorBom1++)
	{
		bomChkFlag = 0;
		Bom1Ptr = Bom1[iteratorBom1];
		ITKCALL(AOM_ask_value_string(Bom1Ptr,"item_id",&partNumberBom1));
		printf("\n %d.Bom1 partNumberBom1:[%s]\n",iteratorBom1,partNumberBom1);fflush(stdout);
		for(iteratorBom2=0;iteratorBom2<bomcount;iteratorBom2++)
		{
			Bom2Ptr = Bom2[iteratorBom2];
			ITKCALL(AOM_ask_value_string(Bom2Ptr,"item_id",&partNumberBom2));
			printf("\n %d.Bom2 partNumberBom2:[%s]\n",iteratorBom2,partNumberBom2);fflush(stdout);
			if(tc_strcmp(partNumberBom1,partNumberBom2) ==0)
			{
				printf("\n Match Found\n");fflush(stdout);
				bomChkFlag =1;
				break;
			}
		}
		if(bomChkFlag ==0)
		{
			printf("\n partNumber:[%s] is not in Bom2\n",partNumberBom1);fflush(stdout);
			autoresizeTagAdd(changeCount,&*bomLineChanges,Bom1Ptr);
		}
	}
}
*/
/*This function will update the CVM of D9Z01 applicable submodules under Vehicle to 1-- for required APL Plants only
This will be made control object based.
System will first fetch CO and based on this which ever plant has D9Z01 live system will update CMV for all those plants only
*/
/*
void updateCVM(tag_t item_revision, tag_t* D9Z01ToBeBom , int cabBomLineCount,char* tmpPlant)
{
	printf("\n **********updateCVM Vehicle********");fflush(stdout);
	tag_t D9Z01LivePlants = NULLTAG;
	int plantCount = 0;
	char* clubbedInformation = NULL;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	int plantIterator=0;
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	int len = 0;
	int length = 0;
	char* plant[10];
	char*    token                   = NULL;
	
	checkControlObjectLive("D9Z01Plants","D9Z01Plants","False",&plantCount,&D9Z01LivePlants);
	getControlObjectDetails(D9Z01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
	//Expand Vehicle to fetch BOM Line for CVM updation
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("\n rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,item_revision,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	token=strtok(clubbedInformation,",");
	//for(plantIterator =0;plantIterator <= length;plantIterator++)
	while(token!=NULL)
	{
		printf("\n plant token- [%s]",token);fflush(stdout);
		//CVM = currentViewMask(plant[plantIterator]);
		//tc_strcat(CVM,currentViewMask(token));
		char*    CVM	= currentViewMask(token);
		char*    childPartNum	= NULL;
		char*    childPartCVM	= NULL;
		printf("\n CVM - [%s]",CVM);fflush(stdout);
		for(childIterator=0;childIterator<count;childIterator++)
		{
			int j=0;
			tag_t D9Z01BomTag = NULLTAG;
			char* partNumber = NULL;
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childPartNum));
			printf("\n CVM childPartNum ItemName:[%s]",childPartNum);fflush(stdout);
			ITKCALL(AOM_ask_value_string(child[childIterator],CVM,&childPartCVM));
			printf("\n CVM childPartCVM :[%s]",childPartCVM);fflush(stdout);
			for(j=0;j<cabBomLineCount;j++)
			{
				D9Z01BomTag = D9Z01ToBeBom[j];
				ITKCALL(AOM_ask_value_string(D9Z01BomTag,"item_id",&partNumber));
				printf("\n CVM child ItemName:[%s]",partNumber);fflush(stdout);
				if(tc_strcmp(childPartNum,partNumber)==0)
				{
					printf("\n Parts Matched, Updating CVM");fflush(stdout);
					ITKCALL( AOM_set_value_string(child[childIterator],CVM,"0--"));
					printf("\n\n Value set as 0-- for Vehicle");fflush(stdout);
				}
			}
		}
		 token=strtok(NULL,",");
	}
	ITKCALL(BOM_save_window(window)); 
	ITKCALL(BOM_close_window(window)); 
	
}

//This Function will update the CVM under D9Z01 to -12 for all applicable plants
void updateCVMD9Z01(tag_t itemRev)
{
	printf("\n **********updateCVMD9Z01********");fflush(stdout);
	tag_t D9Z01LivePlants = NULLTAG;
	int plantCount = 0;
	char* clubbedInformation = NULL;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	int plantIterator=0;
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	int len = 0;
	int length = 0;
	char* plant[10];
	char*    token                   = NULL;
	char* temp = NULL;
	ITKCALL(AOM_ask_value_string(itemRev, "item_id", &temp));
	printf("\n updateCVMD9Z01 D9Z01===> [%s]\n", temp);fflush(stdout);
	checkControlObjectLive("D9Z01Plants","D9Z01Plants","False",&plantCount,&D9Z01LivePlants);
	getControlObjectDetails(D9Z01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
	//Expand Vehicle to fetch BOM Line for CVM updation
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("\n rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	token=strtok(clubbedInformation,",");
	//for(plantIterator =0;plantIterator <= length;plantIterator++)
	while(token!=NULL)
	{
		printf("\n plant token- [%s]",token);fflush(stdout);
		//CVM = currentViewMask(plant[plantIterator]);
		//tc_strcat(CVM,currentViewMask(token));
		char*    CVM	= currentViewMask(token);
		char*    childPartNum	= NULL;
		char*    childPartCVM	= NULL;
		printf("\n CVM - [%s]",CVM);fflush(stdout);
		for(childIterator=0;childIterator<count;childIterator++)
		{
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childPartNum));
			printf("\n CVM D9Z01 childPartNum ItemName:[%s]",childPartNum);fflush(stdout);
			ITKCALL(AOM_ask_value_string(child[childIterator],CVM,&childPartCVM));
			printf("\n CVM D9Z01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITKCALL( AOM_set_value_string(child[childIterator],CVM,"-12"));
			printf("\n\n Value set as -12");fflush(stdout);
			
		}
		token=strtok(NULL,",");
	}
	ITKCALL(BOM_save_window(window));
	ITKCALL(BOM_close_window(window));
	
}
*/
//This Function will update the CVM under D9Z01 to -12 for all applicable plants to be removed
/* void updateCVMD9Z01Ind(tag_t itemRev, char* childName)
{
	printf("\n **********updateCVMD9Z01********");fflush(stdout);
	tag_t D9Z01LivePlants = NULLTAG;
	int plantCount = 0;
	char* clubbedInformation = NULL;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	int plantIterator=0;
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	char*    childPartNum	= NULL;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	int len = 0;
	int length = 0;
	char* plant[10];
	char*    token                   = NULL;
	char* temp = NULL;
	ITKCALL(AOM_ask_value_string(itemRev, "item_id", &temp));
	printf("\n updateCVMD9Z01 D9Z01===> [%s]\n", temp);fflush(stdout);
	checkControlObjectLive("D9Z01Plants","D9Z01Plants","False",&plantCount,&D9Z01LivePlants);
	getControlObjectDetails(D9Z01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
	//Expand Vehicle to fetch BOM Line for CVM updation
	ITKCALL(BOM_create_window (&window));
	ITKCALL(CFM_find(ClosureRev,&rule));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));
	ITKCALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("\n rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	token=strtok(clubbedInformation,",");
	//for(plantIterator =0;plantIterator <= length;plantIterator++)
	int cvmflag=0;
	for(childIterator=0;childIterator<count;childIterator++)
	{
		ITKCALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childPartNum));
		printf("\n CVM D9Z01 childPartNum ItemName:[%s]",childPartNum);fflush(stdout);
		if(tc_strcmp(childPartNum,childName)==0 && cvmflag==0)
		{
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskJ",&childPartCVM));
			printf("\n CVM D9Z01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskJ","-12"));
			cvmflag++;
		}
		if(tc_strcmp(childPartNum,childName)==0 && cvmflag==1)
		{
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskL",&childPartCVM));
			printf("\n CVM D9Z01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskL","-12"));
			cvmflag++;
		}
		if(tc_strcmp(childPartNum,childName)==0 && cvmflag==2)
		{
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskD",&childPartCVM));
			printf("\n CVM D9Z01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskD","-12"));
			cvmflag++;
		}
		if(tc_strcmp(childPartNum,childName)==0 && cvmflag==3)
		{
			ITKCALL(AOM_ask_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskP",&childPartCVM));
			printf("\n CVM D9Z01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskP","-12"));
			cvmflag++;
		}
		printf("\n\n Value set as -12");fflush(stdout);
		
	}
	ITKCALL(BOM_save_window(window));
	ITKCALL(BOM_close_window(window));
	
} */
/*
//This function will create BOM for Newly created D9Z01 or Delete and Update the BOM under Revised D9Z01
int createModifyBom(tag_t item , tag_t* childSet , int childCount , char* tmpPlant)
{
	tag_t itemRev  = NULLTAG;
	char *newPartNumber = NULL;
	tag_t aplViewTag = NULL;
	char *psmbomview = NULL;
	int viewcount = 0;
	tag_t *viewtag = NULLTAG;
	char* cabView = getView(tmpPlant);
	tag_t *bvrviewtag = NULLTAG;
	tag_t bvrold = NULLTAG;
	int bvrviewcount = 0;
	tag_t Bomviewtag = NULLTAG;
	tag_t *occ_tag = NULLTAG;
	int occ_count = 0;
	tag_t BV = NULLTAG;
	int childIterator = 0;
	tag_t *occs = NULLTAG;
	char* clubbedInformation = NULL;
	char*    token                   = NULL;
	tag_t D9Z01LivePlants = NULLTAG;
	int plantCount = 0;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	checkControlObjectLive("D9Z01Plants","D9Z01Plants","False",&plantCount,&D9Z01LivePlants);
	getControlObjectDetails(D9Z01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation createModifyBom********    :[%s]\n",clubbedInformation);fflush(stdout);
	printf("\n D9Z01 is fired for ===> [%s]\n", cabView);fflush(stdout);
	printf("\n*****createModifyBom***********\n");fflush(stdout);
	ITKCALL(ITEM_ask_latest_rev(item,&itemRev));
	ITKCALL(AOM_ask_value_string(itemRev, "item_id", &newPartNumber));
	printf("\n in BOM CREATION for newPartNumber D9Z01===> [%s]\n", newPartNumber);fflush(stdout);
	ITKCALL(PS_find_view_type(cabView,&aplViewTag))
	ITKCALL(PS_ask_view_type_name(aplViewTag,&psmbomview));
	printf("\n Ps_view_type_name %s ",psmbomview);fflush(stdout);
	ITKCALL(ITEM_list_bom_views(item,&viewcount, &viewtag)); 
	printf("\n Number of bom view [%d] \n",viewcount);fflush(stdout);
	if(viewcount !=0)
	{
		ITKCALL(ITEM_rev_list_bom_view_revs(itemRev,&bvrviewcount,&bvrviewtag)); 
		printf("\n Number of bom view [%d] \n",bvrviewcount);fflush(stdout);
		bvrold=bvrviewtag[0];
		if(bvrold == NULLTAG)
		{
			Bomviewtag=viewtag[0];
			printf("\nBOM view Revision not available");fflush(stdout);
			ITKCALL(AOM_lock(itemRev));
			ITKCALL(PS_create_bvr(Bomviewtag,"","",false,itemRev,&bvrold));
			ITKCALL(AOM_save(bvrold));
			ITKCALL(AOM_save(itemRev));
			ITKCALL(AOM_unlock(itemRev));
		}
		else 
		{
			int count =0;
			printf("\n Delete previous Occurances & Add new occurences");fflush(stdout);
			ITKCALL(PS_list_occurrences_of_bvr(bvrold,&occ_count,&occ_tag));
			printf("\n Number of occurences in BVR  %d \n\n",occ_count); fflush(stdout);
			ITKCALL(AOM_lock(bvrold));
			printf("\n Going to delete occurences \n\n"); fflush(stdout);
			for(count = 0; count < occ_count; count++)
			{
				
				ITKCALL(PS_delete_occurrence(bvrold, occ_tag[count]));
			}
			ITKCALL(AOM_save(bvrold));
			ITKCALL(AOM_unlock(bvrold));
		}
	}
	else
	{
		printf("\nCreate BOM view ");fflush(stdout);
		ITKCALL(AOM_lock(item));
		ITKCALL(PS_create_bom_view(aplViewTag,"","",item,&BV));
		ITKCALL(AOM_save(BV));
		ITKCALL(AOM_save(item));
		ITKCALL(AOM_unlock(item));
		if(BV!=NULLTAG) 
		{
			printf("\nInside BVR Creation");fflush(stdout);
			ITKCALL(AOM_lock(itemRev));
			ITKCALL(PS_create_bvr(BV,"","",false,itemRev,&bvrold));
			ITKCALL(AOM_save(bvrold));
			ITKCALL(AOM_save(itemRev));
			ITKCALL(AOM_unlock(itemRev));
		}
	}
	printf("\n BVR Created not Going for BOM Creation ");fflush(stdout);
	ITKCALL(AOM_lock(bvrold));
	
	for(childIterator = 0; childIterator<childCount;childIterator++)
	{
		char* childName = NULL;
		ITKCALL(AOM_ask_value_string(itemRev, "item_id", &childName));
		printf("\n in Adding childName [%s] under D9Z01===> [%s]\n", childName,newPartNumber);fflush(stdout);
		ITKCALL(PS_create_occurrences(bvrold, childSet[childIterator], NULLTAG,1, &occs));
		
		//updateCVMD9Z01Ind(itemRev,childName);
	}
	ITKCALL(AOM_save(bvrold));
	ITKCALL(AOM_unlock(bvrold)); 
	printf("\n Occurances Added Succesfully\n ");fflush(stdout);
	updateCVMD9Z01(itemRev);
	
}
//This function will create/Revise D9Z01 and return item_revision to calling function
tag_t createD9Z01Part(tag_t vehicle ,char* partNumber , char* Rev, char* projectCode,char* vehicleDrAr)
{
	printf("\n*****createD9Z01Part***********\n");fflush(stdout);
	tag_t item_type_tag = NULLTAG;
	tag_t itemRev_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t D9Z01Mstr = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t itemRev_create_input_tag = NULLTAG;
	const char* irCreateInputTagUid[] = {0};
	ITKCALL(TCTYPE_find_type("Design",  NULL, &item_type_tag));
	ITKCALL(TCTYPE_find_type("Design Revision",NULL, &itemRev_type_tag));
	printf("\n partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);
	ITKCALL( TCTYPE_construct_create_input( item_type_tag, &item_create_input_tag) );
	ITKCALL( TCTYPE_construct_create_input( itemRev_type_tag, &itemRev_create_input_tag) );
	//Set attributes of Design Master
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag, "object_name", partNumber));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag, "object_desc", "FITTED CABIN ASSY-MFG"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag, "item_revision_id", Rev));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag, "t5_ProjectCode", projectCode));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag, "t5_DesignGrp", "60"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PartType","M"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DocRemarks","NEW RELEASE"));
	//ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_MThickness","NA"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DsgnDept","Pune-Design"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DsgnOwn","PROPUN"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_ColourInd","Y"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_ModuleAddress","MD9Z01"));
	//ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PrtCatCode","VEHICLE"));
	ITKCALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PartStatus",vehicleDrAr));
	
	ITKCALL( AOM_set_value_string(item_create_input_tag, "item_id", partNumber));
	ITKCALL( AOM_set_value_string(item_create_input_tag, "object_name", partNumber));
	ITKCALL( AOM_set_value_string(item_create_input_tag, "object_desc", "FITTED CABIN ASSY-MFG"));
	ITKCALL( AOM_set_value_tag(item_create_input_tag, "revision",itemRev_create_input_tag));
	printf("\n Creating partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);
	TCTYPE_create_object(item_create_input_tag, &D9Z01Mstr);
	if(D9Z01Mstr!=NULLTAG)
	{
		printf("\n Created partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);

		AOM_save(D9Z01Mstr);
	}
	//ITKCALL ( ITEM_ask_latest_rev( D9Z01Mstr, &ItemRev1 ));
	return D9Z01Mstr;
	
	
}
//This function will create new D9Z01 part number
int CreateD9Z01ObjAndBom(tag_t vehicle ,tag_t* D9Z01ToBeBom , int cabBomLineCount,char* tmpPlant, char* vehProject, char* vehicleDrAr, tag_t* NewD9Z01)
{
	printf("\n*****CreateD9Z01ObjAndBom***********\n");fflush(stdout);
	char* D9Z01FinalPartNo = NULL;
	char* D9Z01CreatePartNo = NULL;
	tag_t partTag = NULLTAG;
	D9Z01FinalPartNo = (char*)MEM_alloc(1*sizeof(char*));
	D9Z01CreatePartNo = (char*)MEM_alloc(1*sizeof(char*));
	tc_strcpy(D9Z01FinalPartNo,"");
	tc_strcpy(D9Z01CreatePartNo,"");
	autoresizestrAdd(&D9Z01FinalPartNo,vehProject);
	autoresizestrAdd(&D9Z01CreatePartNo,vehProject);
	autoresizestrAdd(&D9Z01FinalPartNo,"D9Z0160*");
	autoresizestrAdd(&D9Z01CreatePartNo,"D9Z0160");//2829D9Z0160001
	printf("\n Query Existing D9Z01 so that new number can be generated :  To search ===> %s\n", D9Z01FinalPartNo);fflush(stdout);
	if(QRY_find("Item Revision...", &partTag));
	if(partTag != NULLTAG)
	{
		printf("\nFound Query partTag \n"); fflush(stdout);
		char* newPartNumber = NULL;
		int 		n_entries			=	2;
		int  num_to_sort = 1;
		int 		Qry_Found 			;
		tag_t 		*setOfD9Z01 	= 	NULLTAG;
		tag_t 		setOfD9Z01Ptr 	= 	NULLTAG;
		char *keys[1] = {"object_name"};
		//char *keys[1] = {"creation_date"};
		int  	 orders[1]  ={2};
		char 		*qry_entries[2] 	= 	{"Item ID","Type"};
		char 		*qry_values[]		=	{D9Z01FinalPartNo,"Design Revision"};
		char* num = NULL;
		ITKCALL(QRY_execute_with_sort(partTag, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &Qry_Found, &setOfD9Z01));
		printf("\n Total D9Z01FinalPartNo found : %d",Qry_Found);fflush(stdout);
		if(Qry_Found == 0)
		{
			printf("\n No D9Z01 exists with [%s] hence fisrt D9Z01 number \n",D9Z01FinalPartNo);fflush(stdout);
			autoresizestrAdd(&D9Z01CreatePartNo,"001");
			printf("\n D9Z01CreatePartNo [%s] hence firt D9Z01 number",D9Z01CreatePartNo);fflush(stdout);
			
		}
		else
		{
			char* cabSfx = NULL;
			char* cabFinal = (char*) MEM_alloc(15*sizeof(char*));
			cabSfx = (char*)MEM_alloc(1*sizeof(char*));
			tc_strcpy(cabSfx,"");
			printf("\n***D9Z01 exists with [%s] so finding latest partnumber in sequence",D9Z01FinalPartNo);fflush(stdout);
			ITKCALL(AOM_ask_value_string(setOfD9Z01[0], "item_id", &num));
			printf("\n num Parts D9Z01 : %s",num);fflush(stdout);
			autoresizestrAdd(&cabSfx,subString(num,11,3));
			printf("\n ****cabSfx : %s",cabSfx);fflush(stdout);
			sprintf(cabFinal,"%03d",(atoi(cabSfx)+1));
			printf("\n cabFinal after conversion===> %s\n", cabFinal);fflush(stdout);
			//nlsStrCat(r40PartNumFinal,"00");
			autoresizestrAdd(&D9Z01CreatePartNo,cabFinal);
			printf("\n D9Z01CreatePartNo after conversion===> %s\n", D9Z01CreatePartNo);fflush(stdout);
			
		}
		*NewD9Z01 = createD9Z01Part(vehicle,D9Z01CreatePartNo ,"NR;1",vehProject,vehicleDrAr);
		ITKCALL(AOM_ask_value_string(*NewD9Z01, "item_id", &newPartNumber));
		printf("\n newPartNumber Created===> %s\n\n ^^^^^^^^^Going To Create Bom for the same^^^^^^^^^\n", newPartNumber);fflush(stdout);
		createModifyBom(*NewD9Z01 , D9Z01ToBeBom , cabBomLineCount , tmpPlant );
		updateCVM(vehicle,D9Z01ToBeBom,cabBomLineCount,tmpPlant);
	}
}

int t5CheckForCommonD9Z01Obj(tag_t* D9Z01ToBeBom , int cabBomLineCount,char* tmpPlant, char* vehProject, tag_t* existingD9Z01)
{
	char* D9Z01FinalPartNo = NULL;
	tag_t partTag = NULLTAG;
	D9Z01FinalPartNo = (char*)MEM_alloc(1*sizeof(char*));
	tc_strcpy(D9Z01FinalPartNo,"");
	autoresizestrAdd(&D9Z01FinalPartNo,vehProject);
	autoresizestrAdd(&D9Z01FinalPartNo,"D9Z0160*");
	printf("\n t5CheckForCommonD9Z01Obj :  D9Z01FinalPartNo ===> %s\n", D9Z01FinalPartNo);fflush(stdout);
	if(QRY_find("Item Revision...", &partTag));
	if(partTag != NULLTAG)
	{
		printf("\nFound Query partTag \n"); fflush(stdout);
		int 		n_entries			=	2;
		int 		Qry_Found 			;
		tag_t 		*setOfD9Z01 	= 	NULLTAG;
		tag_t 		setOfD9Z01Ptr 	= 	NULLTAG;
		char 		*qry_entries[2] 	= 	{"Item ID","Type"};
		char 		*qry_values[]		=	{D9Z01FinalPartNo,"Design Revision"};
		ITKCALL(QRY_execute(partTag,n_entries,qry_entries,qry_values,&Qry_Found,&setOfD9Z01));
		printf("\n Total Parts found t5CheckForCommonD9Z01Obj : %d",Qry_Found);fflush(stdout);
		//D9Z01 found for similar project
		if(Qry_Found > 0)
		{
			int i=0;
			char* D9Z01Number = NULL;
			tag_t* cabBomLineFromD9Z01 = NULL;
			int fromD9Z01Count	=	NULL;
			tag_t* ToBeUpdatedInCab	=	NULL;
			int		 ToBeUpdatedCount	=	1;
			int		 CommonFoundFlag	=	0;
			GetBomClosureRule("APL",tmpPlant);
			//Expand each D9Z01 and check if its having same bom as per D9Z01 Applicable bom
			for(i=0;i<Qry_Found;i++)
			{
				setOfD9Z01Ptr = setOfD9Z01[i];
				AOM_ask_value_string(setOfD9Z01Ptr,"item_id",&D9Z01Number);
				printf("\n %d) D9Z01Number 			: %s\n",i,D9Z01Number);fflush(stdout);
				getCabBomLineAPLView(setOfD9Z01Ptr,&cabBomLineFromD9Z01,&fromD9Z01Count);
				if(fromD9Z01Count == cabBomLineCount)
					fromToBomCompare(D9Z01ToBeBom,cabBomLineFromD9Z01,cabBomLineCount,&ToBeUpdatedInCab,&ToBeUpdatedCount);
				if(ToBeUpdatedCount == 0)
				{
					printf("\n Common D9Z01 found : D9Z01Number 			: %s\n" ,D9Z01Number);fflush(stdout);
					*existingD9Z01 = setOfD9Z01Ptr;
					CommonFoundFlag = 1;
					break;
				}
			}
			if(CommonFoundFlag == 1)
				return 1;
			else
				return 0;
		}
		else
			return 0;
	}
}

void  GetProjectUserAccessDetails( char  *Projj , char  *UsrId ,int *Gmcnt ,tag_t	**GmFound)
{
	int		n_entries = 2;
	int		countt=0;

	char	*qry_entries[2] = {"Project ID","Id"};
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t	queryTag   = NULLTAG;

	 char *Object_Name  =  NULL;



	printf( "Projj:%s\n", Projj);fflush(stdout);
	printf( "UsrId:%s\n", UsrId);fflush(stdout);
	 

				if(QRY_find("ProjectUserAccessDet", &queryTag));
				printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = Projj;
				qry_values[1] = UsrId;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, Gmcnt, GmFound));
				printf("\n MT: Gmcnt : %d\n", *Gmcnt); fflush(stdout);

//                for(countt==0;countt<*Gmcnt;countt++)
//				{
//						Object_Name  =  NULL;
//						ITKCALL(AOM_UIF_ask_value(GmFound[countt],"object_string", &Object_Name));	
//						printf("\n %s",Object_Name);fflush(stdout);
//				}

}


void  GetAggregateFromERCDML( char * Task_no ,char  Aggregt[40])
{
    printf( "Task_no:%s\n", Task_no);fflush(stdout);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,Task_no);

	printf( "item_idCpy:%s\n", item_idCpy);fflush(stdout);

	if(strlen(item_idCpy)>0)
	{
		char	*ERCDMLNo				=	NULL;
		ERCDMLNo	=	subString(item_idCpy,0,10);
		printf( " \n ERCDMLNo :%s\n", ERCDMLNo);fflush(stdout);

			char  AllAggregate[500];
			char    *qry_entryCntrlformat[2]  = {"Type","Item ID"};	
			char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
			tag_t   qryTagCntrlobj     = NULLTAG;
			int     n_entryCntrlobj    = 2;
			int controlObjfound=0;
			tag_t *list_of_cntrl_tags=NULLTAG;

			if(QRY_find("Item Revision...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="ERC DML Revision";
				qry_valuesCntrlformat[1]=ERCDMLNo;

				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Item Revision... Query not Found \n");fflush(stdout);
			}	
			
			printf("\n ERC Setsize is : %d\n",controlObjfound);fflush(stdout);


			if(controlObjfound>0)
			{
					char **AggregateList;
					int AggrCount=0;
					int i=0;
			
					tc_strcpy(AllAggregate,"");

					AOM_ask_value_strings(list_of_cntrl_tags[0],"t5_ERCAggregate",&AggrCount,&AggregateList);
					//AOM_ask_value_strings(list_of_cntrl_tags[0],"t5_crdesigngroup",&AggrCount,&AggregateList);

					for(i=0;i<AggrCount;i++)
					{
						printf("\n AggregateList[i] is : %s\n",AggregateList[i]);fflush(stdout);
					
						tc_strcat(AllAggregate,AggregateList[i]);
						tc_strcat(AllAggregate,",");
					}
			}

			printf("\n tc_strlen(AllAggregate) is : %d\n",tc_strlen(AllAggregate));fflush(stdout);
			printf("\n AllAggregate is : %s\n",AllAggregate);fflush(stdout);

			if(strstr(AllAggregate,",")!=NULL)
			{
					if(strcmp(AllAggregate,"BIW,")==0)
					{
						tc_strcpy(Aggregt,"BIW");
				
					}

					else if( strstr(AllAggregate,"BIW")!=NULL )
						{
							if(strstr(AllAggregate,"Mechanism")!=NULL || strstr(AllAggregate,"Trim")!=NULL || strstr(AllAggregate,"Chassis")!=NULL || strstr(AllAggregate,"E&E")!=NULL || strstr(AllAggregate,"PT")!=NULL  )
								{
									tc_strcpy(Aggregt,"BIWTCF");
								}
						}
			}
	}

}

int GetAggregateBaseMapping(char* Proj_Code)
{

	int k=0;
	int Flag=0;

	char* info2=NULL;
	char    *qry_entryCntrlformat[4]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
	char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   qryTagCntrlobj     = NULLTAG;
	int     n_entryCntrlobj    = 4;
	int controlObjfound=0;
	tag_t *list_of_cntrl_tags=NULLTAG;

	printf("\n\n\t\t inside GetAggregateBaseMapping func..[%s] ",Proj_Code);fflush(stdout);

			if(QRY_find("Control Objects...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="Aggregate";
				qry_valuesCntrlformat[1]="APLMapping";
				qry_valuesCntrlformat[2]="0";
				qry_valuesCntrlformat[3]="Live";
				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n controlObjfound is : %d\n",controlObjfound);fflush(stdout);

			if(controlObjfound>0)
			{
				for(k=0;k<controlObjfound;k++)
				{
					 AOM_ask_value_string( list_of_cntrl_tags[k], "t5_Userinfo2", &info2);
					 printf("\n info2: %s\n",info2);fflush(stdout);

					 if(strcmp(info2,Proj_Code)==0)
					{
						Flag=1;
						break;
					}
				}
			}

		
		printf("\n\n\t\t Flag =:[%d]",Flag);fflush(stdout);
			return Flag;

}

int AssignAPLPlannerD9Z01(tag_t APLTaskRevT,char*		Proj_Code)
{
	char*			Task_no				= NULL;
	//char*			Dsgn_Grp			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	// Added by Dhanashri for Projectwise Mapping

				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignPlanner=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

	// Added by Dhanashri for Projectwise Mapping

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
char Aggregt[40];
	
	// Ketan Added
	char* Temp_Dsgn_No	= NULL;
	char* Temp_Task_no	= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//
	
	printf("\n Inside AssignAPLPlanner \n");

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Task_no  is :%s",Task_no);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for APL Planner Temp_Task_no :%s",Temp_Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	// Ketan Added for MBOM 

	//if(tc_strstr(Temp_Task_no,"MB_")!=NULL)
	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for APL Planner\n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}
	
	
	if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	

	
//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}else
//	if(tc_strcmp(PLT_Code,"APLV")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UV");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}


// Added By Dhanashri for projectwise mapping// 

					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"APL");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);


				tc_strcpy(Projj,Proj_Code);
				printf("\n Projj :[%s]\n",Projj);fflush(stdout);
				//Aggregate Base mapping
				int FlagAggregateBaseMapping=0;
				FlagAggregateBaseMapping=GetAggregateBaseMapping(Proj_Code);
				printf("\n FlagAggregateBaseMapping :[%d]\n",FlagAggregateBaseMapping);fflush(stdout);
				if(FlagAggregateBaseMapping==1)
				{
					GetAggregateFromERCDML(Task_no,Aggregt);
				}
			printf("\n Aggregt: %s \n",Aggregt);fflush(stdout);
			printf("\n length Aggregt: %d \n",strlen(Aggregt));fflush(stdout);
			//End Aggregate Base mapping

// End Of code Added By Dhanashri for projectwise mapping// 
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignPlanner=0; // by dss for projectwise mapping.

		//Aggregate Base mapping
		if( FlagAggregateBaseMapping==1 && strstr(Aggregt,"BIW")!=NULL )
		{
				char RoleToassign[50];
				tc_strcpy(RoleToassign,Aggregt);
				tc_strcat(RoleToassign,"_");
				printf("\n RoleToassign : %s\n",RoleToassign);fflush(stdout);

				
				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
						//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
						printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

						if(strstr(rolename,"APL") && strstr(rolename,RoleToassign) && strstr(rolename,"Planner") && strstr(rolename,"Default")==NULL ) 
						{
									printf("\nMatch Found\n");fflush(stdout);
									role_tag = role_tags[i];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (j=0;j<num_of_members ;j++  )
										{
											CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
											CALLAPI(SA_ask_user_identifier(user_tag,userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
										
											// Added by Dhanashri for projectwise mapping//
											ProjectAccessFound=0;
											Gmcnt1=0;
											GmFound1 = NULLTAG;
											GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
											printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
											
											countt=0;
											for(countt==0;countt<Gmcnt1;countt++)
											{
													Object_Name  =  NULL;
													CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
													printf("\n after func :  %s",Object_Name);fflush(stdout);
												
													if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,RoleToassign) && strstr(Object_Name,"Planner") && strstr(Object_Name,"Default")==NULL) 
													{
														printf("\n Condition Satisfy... ");fflush(stdout);
														ProjectAccessFound=1;
														break;
													}
											}
											printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
											// Added by Dhanashri for projectwise mapping//
											
											if(ProjectAccessFound==1)
											{
												TCTYPE_find_type("Analyst", "Analyst", &participant_type);
												EPM_create_participant(member_tags[j], participant_type, &participant_tag);
												GRM_find_relation_type("HasParticipant", &relation_type);
												GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
												GRM_save_relation(relation);
												printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
												FlaggAssignPlanner=1;
												//break;
											}
										}
									}

							
							if(FlaggAssignPlanner==1)
							{
								break;
							}
						}// Role matches  
					}	
		}
		//End of aggregate mapping
printf("\n hi FlaggAssignPlanner : [%d]\n",FlaggAssignPlanner);fflush(stdout);
if(FlaggAssignPlanner==0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Planner"))
				if(strstr(rolename,"APL") && strstr(rolename,Dsgn_No) && strstr(rolename,"Planner") && strstr(rolename,"Default")==NULL ) 
				{
							printf("\nMatch Found\n");fflush(stdout);
							role_tag = role_tags[i];
							CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
								
									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Planner") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//
									
									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("Analyst", "Analyst", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
										FlaggAssignPlanner=1;
										//break;
									}
								}
							}

					
					if(FlaggAssignPlanner==1)
					{
						break;
					}
				}// Role matches  
		}
	}
		printf("\n FlaggAssignPlanner: %d \n",FlaggAssignPlanner);fflush(stdout);

		if(FlaggAssignPlanner==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"APL");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[z],rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;
						for (b=0;b<num_of_members ;b++  )
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}        
	

	} // if(num_of_roles>0)

	return ITK_ok;
}

int AssignAPLGMReviewerD9Z01(tag_t APLTaskRevT,char*		Proj_Code)
{
	char*			Task_no				= NULL;
	//char*			Dsgn_Grp			= NULL;
//	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	char Aggregt[40];
	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	// Added by Dhanashri for Projectwise Mapping
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignReviewer=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

	// Added by Dhanashri for Projectwise Mapping

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;


	printf("\n Inside AssignAPLGMReviewer  \n");fflush(stdout);

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLGMReviewer:Task_no  is :%s",Task_no);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	

	if(QRY_find("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	

	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo8", &PltCodeFrmCntrl);
			printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
			tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
		}
	}
	else
	{
		tc_strcpy(PLT_CodeS,"PUNE");
	}
	printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);


	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"APL");
	tc_strcat(APL_Plnr_Grp,PLT_CodeS);

	tc_strcpy(Projj,Proj_Code);
	printf("\n Projj :[%s]\n",Projj);fflush(stdout);
	//Aggregate Base mapping
	

	// End Of code Added By Dhanashri for projectwise mapping// 
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignReviewer=0; // by dss for projectwise mapping.
		if(FlaggAssignReviewer==0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
					CALLAPI(SA_ask_role_name(role_tags[i],rolename));
					printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
					//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
					 printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);
					//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Reviewer"))
					if(strstr(rolename,"APL") && strstr(rolename,Dsgn_No) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL )
					{
						printf("\nMatch Found\n");fflush(stdout);

								role_tag = role_tags[i];
								CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
								printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
								if(num_of_members>0)
								{
									for (j=0;j<num_of_members ;j++  )
									{
										CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
										CALLAPI(SA_ask_user_identifier(user_tag,userid));
										printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);

										// Added by Dhanashri for projectwise mapping//
										ProjectAccessFound=0;
										Gmcnt1=0;
										GmFound1 = NULLTAG;
										GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
										printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
										
										countt=0;
										for(countt==0;countt<Gmcnt1;countt++)
										{
												Object_Name  =  NULL;
												CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
												printf("\n after func :  %s",Object_Name);fflush(stdout);
											
												if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
												{
													printf("\n Condition Satisfy... ");fflush(stdout);
													ProjectAccessFound=1;
													break;
												}
										}
										printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
										// Added by Dhanashri for projectwise mapping//

										if(ProjectAccessFound==1)
										{
											TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
											EPM_create_participant(member_tags[j], participant_type, &participant_tag);
											GRM_find_relation_type("HasParticipant", &relation_type);
											GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
											GRM_save_relation(relation);
											printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
											FlaggAssignReviewer=1;
										}

									}
								}
							
						if(FlaggAssignReviewer==1)
						{
							break;
						}
					}  // Roll matches
			}
		}

		printf("\n FlaggAssignReviewer: %d \n",FlaggAssignReviewer);fflush(stdout);

		if(FlaggAssignReviewer==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"APL");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[z],rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;	
						for (b=0;b<num_of_members ;b++)
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}

			}

		}  

	}
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer \n");

	///return 0;
}

int AssignAPLReviewerD9Z01(tag_t APLTaskRevT,char*		Proj_Code)
{
	char*			Task_no				= NULL;
	//char*			Dsgn_Grp			= NULL;
//	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char			rolename[SA_name_size_c+1];
	char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
char Aggregt[40];
	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	// Added by Dhanashri for Projectwise Mapping
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignReviewer=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

	// Added by Dhanashri for Projectwise Mapping

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;

	// Ketan Added
	char* Temp_Dsgn_No		= NULL;
	char* Temp_Task_no		= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//


	printf("\n Inside AssignAPLReviewer  \n");fflush(stdout);

	CALLAPI(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	//CALLAPI(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Task_no  is :%s",Task_no);	fflush(stdout);

	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for APL Reviewer Temp_Task_no:%s",Temp_Task_no);	fflush(stdout);

	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));


	// Ketan Added for MBOM 

	//if(tc_strstr(Temp_Task_no,"MB_")!=NULL)
	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for APL Reviewer  \n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}

			if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
					{
						AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo8", &PltCodeFrmCntrl);
						printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
						tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
					}
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				
//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}else
//	if(tc_strcmp(PLT_Code,"APLV")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UV");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}

// Added By Dhanashri for projectwise mapping// 

				APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
				tc_strcpy(APL_Plnr_Grp,"APL");
				tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			
				tc_strcpy(Projj,Proj_Code);
				printf("\n Projj :[%s]\n",Projj);fflush(stdout);
				//Aggregate Base mapping
				int FlagAggregateBaseMapping=0;
				FlagAggregateBaseMapping=GetAggregateBaseMapping(Proj_Code);
				printf("\n FlagAggregateBaseMapping :[%d]\n",FlagAggregateBaseMapping);fflush(stdout);
				if(FlagAggregateBaseMapping==1)
				{
					GetAggregateFromERCDML(Task_no,Aggregt);
				}
				printf("\n Aggregt: %s \n",Aggregt);fflush(stdout);
				printf("\n length Aggregt: %d \n",strlen(Aggregt));fflush(stdout);
				//End Aggregate Base mapping

// End Of code Added By Dhanashri for projectwise mapping// 
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	CALLAPI(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignReviewer=0; // by dss for projectwise mapping.

		//Aggregate Base mapping
		if( FlagAggregateBaseMapping==1 && strstr(Aggregt,"BIW")!=NULL )
		{
				char RoleToassign[50];
				tc_strcpy(RoleToassign,Aggregt);
				tc_strcat(RoleToassign,"_");
				printf("\n RoleToassign : %s\n",RoleToassign);fflush(stdout);

				for (i=0;i<num_of_roles ;i++ )
				{
						CALLAPI(SA_ask_role_name(role_tags[i],rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
						//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
						 printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);
						
						if(strstr(rolename,"APL") && strstr(rolename,RoleToassign) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL )
						{
							printf("\nMatch Found\n");fflush(stdout);

									role_tag = role_tags[i];
									CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (j=0;j<num_of_members ;j++  )
										{
											CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
											CALLAPI(SA_ask_user_identifier(user_tag,userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);

											// Added by Dhanashri for projectwise mapping//
											ProjectAccessFound=0;
											Gmcnt1=0;
											GmFound1 = NULLTAG;
											GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
											printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
											
											countt=0;
											for(countt==0;countt<Gmcnt1;countt++)
											{
													Object_Name  =  NULL;
													CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
													printf("\n after func :  %s",Object_Name);fflush(stdout);
												
													if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,RoleToassign) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
													{
														printf("\n Condition Satisfy... ");fflush(stdout);
														ProjectAccessFound=1;
														break;
													}
											}
											printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
											// Added by Dhanashri for projectwise mapping//

											if(ProjectAccessFound==1)
											{
												TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
												EPM_create_participant(member_tags[j], participant_type, &participant_tag);
												GRM_find_relation_type("HasParticipant", &relation_type);
												GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
												GRM_save_relation(relation);
												printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
												FlaggAssignReviewer=1;
											}

										}
									}
								
							if(FlaggAssignReviewer==1)
							{
								break;
							}
						}  // Roll matches
				}
		}
		//Aggregate Base mapping
printf("\n hi FlaggAssignReviewer : [%d]\n",FlaggAssignReviewer);fflush(stdout);

if(FlaggAssignReviewer==0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
                 printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);
				//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Reviewer"))
				if(strstr(rolename,"APL") && strstr(rolename,Dsgn_No) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL )
				{
					printf("\nMatch Found\n");fflush(stdout);

							role_tag = role_tags[i];
							CALLAPI(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
									CALLAPI(SA_ask_user_identifier(user_tag,userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);

									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											CALLAPI(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//

									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
										FlaggAssignReviewer=1;
									}

								}
							}
						
					if(FlaggAssignReviewer==1)
					{
						break;
					}
				}  // Roll matches
		}
	}

		printf("\n FlaggAssignReviewer: %d \n",FlaggAssignReviewer);fflush(stdout);

		if(FlaggAssignReviewer==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"APL");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[z],rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					CALLAPI(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;	
						for (b=0;b<num_of_members ;b++)
						{
							CALLAPI(SA_ask_groupmember_user(member_tags[b],&user_tag));
							CALLAPI(SA_ask_user_identifier(user_tag,userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}  



	}
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer \n");

	///return 0;
}



//This Function will attach D9Z01 to 60_APL task ans submit task in wf
int createtask_attchedtoDML(char* DML_ID,tag_t itemRev , char* tmpPlant,char* vehicleProject)
{
	printf("\n **********createtask_attchedtoDML********");fflush(stdout);
	char* temp = NULL;
	temp = (char*)MEM_alloc(1*sizeof(char*));
	autoresizestrAdd(&temp,DML_ID);
	autoresizestrAdd(&temp,"_");
	autoresizestrAdd(&temp,tmpPlant);
	printf("\n temp Found  : %d",temp);fflush(stdout);
	const char *attrs[1];
    const char *values[1];
	values[0] = temp;
	attrs[0] ="item_id";
	
	int 	 task_count		=0;
	int 	 part_count		=0;
	int      DML_count		=0; 
	int      Task_count		=0; 
	int 	 idml			=0;
	int 	 iTask			=0;
	
	//int    Task_rev_count		=0; 
	tag_t	 Tasktag				=NULLTAG;
	tag_t	 TaskRev				=NULLTAG;
	tag_t	 *taskItemTag			=NULLTAG;
	tag_t	 *parttag			=NULLTAG;
	tag_t  	 TasktoDMLrel			=NULLTAG;
	tag_t  	 PartRevTag			=NULLTAG;
	tag_t  	 TaskPartRel			=NULLTAG;
	tag_t	 *DMLTagt				=NULLTAG;
	tag_t	 *TaskTagt				=NULLTAG;
	tag_t	 TaskRevTagg			= NULLTAG;
	tag_t	 DMLRevTagg				= NULLTAG;
	tag_t	 DMLTypeTag				= NULLTAG;
	tag_t	 dmltaskRel				= NULLTAG;
	tag_t	 taskpartREL				= NULLTAG;
	tag_t	 taskpartRel				= NULLTAG;
	tag_t	 taskpartRelation				= NULLTAG;
	tag_t	 latestrev				= NULLTAG;
	tag_t	 isltstDML				= NULLTAG;
	
	char	*DMLNumberr				= NULL;
	char	*ftaskname					= NULL;
	ftaskname = (char*)MEM_alloc(1*sizeof(char*));
	
	//tag_t	*Task_rev_tag	=NULLTAG;
	
		ITKCALL(ITEM_find_items_by_key_attributes(1,attrs,values,&DML_count, &DMLTagt));
		printf("\n DMLTagt Found  : %d",DML_count);fflush(stdout);
		if(DML_count>0)
		{
			ITKCALL(ITEM_ask_latest_rev(DMLTagt[0],&isltstDML));
			if(isltstDML !=NULLTAG)
			{
				printf("\n\t Latest DML rev is  Found .....\n");fflush(stdout);
			}
			ITKCALL(AOM_ask_value_string(isltstDML, "item_id", &DMLNumberr));
			printf("\n Current DML id is : %s",DMLNumberr);fflush(stdout);
		}
 		tag_t	APLTTypeTag			= NULLTAG;
		tag_t	APLTCreInTag		= NULLTAG;
		tag_t	APLTRevTypeTag		= NULLTAG;
		tag_t	APLTRevCreInTag		= NULLTAG;
		tag_t	APLTaskTag			= NULLTAG;
		tag_t 	APLTaskRevTag	    = NULLTAG;
		int		n_strings			= 1;
		int		l_strings		  	= 500;
		int		index			  	= 0;
		char**	stringArrayAPLT	  	= NULL;
		char*	tempStringt1		= NULL;
		
		autoresizestrAdd(&ftaskname,DML_ID);
		if(tc_strcmp(tmpPlant,"APLJ")==0)
		{
			autoresizestrAdd(&ftaskname,"_67_");
		}
		else 
		{
			autoresizestrAdd(&ftaskname,"_60_");
		}
		autoresizestrAdd(&ftaskname,tmpPlant);
		printf("\t setting Object Name object_name ...%s\n", ftaskname);fflush(stdout);
		const char *values2[1];
		values2[0] = ftaskname;
		ITKCALL(ITEM_find_items_by_key_attributes(1,attrs,values2,&Task_count, &TaskTagt));
		printf("\n Task_count Found  : %d",Task_count);fflush(stdout);
		if(Task_count ==0)
		{
			stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
			for( index=0; index<n_strings; index++ )
			{
				stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
			}
			
			ITKCALL( TCTYPE_find_type("T5_APLTask", NULL, &APLTTypeTag) );//T5_APLTask
			ITKCALL( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

			ITKCALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &APLTRevTypeTag) );//T5_APLTaskRevision
			ITKCALL( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );
			tc_strcpy( stringArrayAPLT[0], ftaskname);
			ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );

			tc_strcpy( stringArrayAPLT[0], ftaskname);
			printf("\t setting Object Name object_name ...%s\n", ftaskname);fflush(stdout);
			ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );
			
			tc_strcpy( stringArrayAPLT[0], "D9Z01 Task");
			ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_desc", 1,(const char**)stringArrayAPLT) );
			
			ITKCALL( AOM_tag_to_string(APLTRevCreInTag, &tempStringt1) );
			tc_strcpy( stringArrayAPLT[0], tempStringt1);
			printf("\nTest..'%s'\n",stringArrayAPLT[0]);fflush(stdout);
			ITKCALL( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
			tc_strcpy( stringArrayAPLT[0], "A");
			ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
			printf("\n Value to set in apl_task_number :%s\n",ftaskname);fflush(stdout);
			tc_strcpy( stringArrayAPLT[0], vehicleProject);
			printf("\t setting project code t5_cprojectcode ...%s\n", stringArrayAPLT[0]);fflush(stdout);
			ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );
			
			if(tc_strcmp(tmpPlant,"APLJ")==0)
			{
				tc_strcpy( stringArrayAPLT[0], "67");
			}
			else 
			{
				tc_strcpy( stringArrayAPLT[0], "60");
			}
			ITKCALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
			ITKCALL( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
			ITKCALL( AOM_save(APLTaskTag));
			ITKCALL(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));
			printf("\nSave APL TASK ITEM AND REV\n");fflush(stdout);
			AOM_save(APLTaskTag);
			AOM_save(APLTaskRevTag);
			if (APLTaskTag!=NULLTAG)
			{
				printf("\nTASK ITEM IS CREATED\n");fflush(stdout);
			}
			else
			{
				printf("\nTASK ITEM IS NOT CREATED\n");fflush(stdout);
			}
			if (APLTaskRevTag!=NULLTAG)
			{
				printf("\nTASK ITEM REV IS CREATED\n");fflush(stdout);
			}
			else
			{
				printf("\nTASK ITEM REV IS NOT CREATED\n");fflush(stdout);
			}
			//Create task relation with Dml
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&TasktoDMLrel));
			if (TasktoDMLrel!=NULLTAG)
			{
				ITKCALL(GRM_create_relation(isltstDML,APLTaskRevTag,TasktoDMLrel,NULLTAG,&dmltaskRel));
				if(dmltaskRel==NULLTAG)
				{
					printf("\n dmltaskRel does not exist");fflush(stdout);
				}
				else
				{
					ITKCALL(GRM_save_relation(dmltaskRel));
					printf("\n\t TAsk to Dml relation created");fflush(stdout);
				}
			}
		}
		else
		{
			ITKCALL(ITEM_ask_latest_rev(TaskTagt[0],&APLTaskRevTag));
			if(APLTaskRevTag !=NULLTAG)
			{
				printf("\n\t Latest APLTaskRevTag rev is  Found .....\n");fflush(stdout);
			}
		}
		
		//attached part in task into solution 
		ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&TaskPartRel));
		ITKCALL(GRM_create_relation(APLTaskRevTag,itemRev,TaskPartRel,NULLTAG,&taskpartRelation));
		if(taskpartRelation==NULLTAG)
		{
			printf("\n part task rel does not exist");fflush(stdout);
		}
		else
		{
			ITKCALL(GRM_save_relation(taskpartRelation));
			printf("\n\t TAsk to part relation created");fflush(stdout);
		}
		
		if(Task_count ==0)
		{
			//create analyst and reviewer before submitting the task in WF
			//AssignAPLPlanner(APLTaskRevTag,vehicleProject);
			//AssignAPLReviewer(APLTaskRevTag,vehicleProject);
			
			printf("\n\n\n******************** INSIDE Workflow initiated on Created Task    *********************\n\n\n");fflush(stdout);
			tag_t process_temp;
			tag_t new_process;
			tag_t new_processDML;
			tag_t new_processPART;
			int attachment_type = 1;
			ITKCALL(EPM_find_template2("APL Task BreakDown",0,&process_temp));
			if (process_temp != NULLTAG)
			{
				printf("\n\n\t process found successfully.........");fflush(stdout);
				ITKCALL(EPM_create_process("23CU002002_67_APLJ/A;1","", process_temp, 1, &APLTaskRevTag, &attachment_type, &new_process));
				if (new_process != NULLTAG)
				{
					printf("\n\n\t process successfully initiated on task \n");fflush(stdout);
				} 	
			}
			else
			{
				printf("\n\n\t process NOT found ");fflush(stdout);
			}
		}
		
	return ITK_ok;
}
int ModCabBomRestFuncXYZ(void *return_data)
{
	int 			status;
	int				ifail 				=	ITK_ok;
	char 			*selectedVehicle	=	NULL;
	char 			*selectedVehRev		=	NULL;
	char 			*selectedVehSeq		=	NULL;
	char 			*selectedTask		= 	NULL;
	char 			*userName			= 	NULL;
	
	printf("\n I am in main program");fflush(stdout);
	USERARG_get_string_argument(&selectedVehicle);	
	USERARG_get_string_argument(&selectedVehRev);	
	USERARG_get_string_argument(&selectedVehSeq);	
	USERARG_get_string_argument(&selectedTask);
	USERARG_get_string_argument(&userName);
	
	printf("\n Input selectedVehicle :: %s ",selectedVehicle);fflush(stdout);
	printf("\n Input selectedVehRev :: %s ",selectedVehRev);fflush(stdout);
	printf("\n Input selectedVehSeq :: %s ",selectedVehSeq);fflush(stdout);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	printf("\n Input userName :: %s ",userName);fflush(stdout);
	
	int n_tags_found					=0;
	int task_tags_found					=0;
	int user_tags_found					=0;
    tag_t* tags_found 					= NULL;
    const char *attrs[1];
    const char *values[1];
    char *usrValues[1];
	tag_t vehItemRev 					= NULLTAG;
	tag_t* taskItemTag 					= NULL;
	tag_t usrItemTag 					= NULLTAG;
	tag_t itemRev 						= NULLTAG;
	char * vehicleProject	=	NULL;
	char * vehicleDrAr	=	NULL;
	char * vehicleProjectTemp	=	NULL;
	char* DMLNumberr = NULL;
	char* taskNumber = NULL;
	
    ClosureRule = (char *) MEM_alloc(100);
    ClosureRev = (char *) MEM_alloc(100);
	
	//Query Vehicle:
	attrs[0] ="item_id";
	values[0] = (char *)selectedVehicle;
	ITKCALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found = [%d]",n_tags_found);fflush(stdout);	
	
	if(n_tags_found>0)
	{
		printf("\n----------Vehicle Found----------\n");fflush(stdout);	
		char* itemRevSeq = NULL;
		itemRevSeq = (char *) MEM_alloc(1 * sizeof(char *));
		tc_strcpy(itemRevSeq,"");
		tag_t item = NULLTAG;
		
		strcpy(itemRevSeq,selectedVehRev);
		strcat(itemRevSeq,";");
		strcat(itemRevSeq,selectedVehSeq);
		printf("\n itemRevSeq= %s",itemRevSeq);fflush(stdout);
		item = tags_found[0];
        ITKCALL(ITEM_find_revision(item,itemRevSeq,&itemRev));
	}
	ITKCALL(AOM_ask_value_string(itemRev,"t5_ProjectCode",&vehicleProject));
	ITKCALL(AOM_ask_value_string(itemRev,"t5_PartStatus",&vehicleDrAr));
	printf("\n vehicleProject :[%s]\n",vehicleProject);fflush(stdout);
	printf("\n vehicleDrAr :[%s]\n",vehicleDrAr);fflush(stdout);
	//Query Task
	values[0] = (char *)selectedTask;
	ITKCALL(ITEM_find_items_by_key_attributes(1,attrs, values, &task_tags_found, &taskItemTag));
	if(task_tags_found>0)
	{
		printf("\n task_tags_found = [%d]",task_tags_found);fflush(stdout);	
		ITKCALL(AOM_ask_value_string(taskItemTag[0],"item_id",&taskNumber));
		printf("\n taskNumber :[%s]\n",taskNumber);fflush(stdout);
		DMLNumberr = strtok(taskNumber,"_");
		printf("\n DMLNumberr :[%s]\n",DMLNumberr);fflush(stdout);
	}
	//Query User
	attrs[0] = "user_id";
	usrValues[0] = (char *)userName;
	//ITKCALL(ITEM_find(values[0], &user_tags_found, &usrItemTag));
	ITKCALL(POM_get_user(usrValues, &usrItemTag));
	if(usrItemTag>0)
	{
		user_tags_found = 1;
		printf("\n user_tags_found = [%d]",user_tags_found);fflush(stdout);	
	}
	if(n_tags_found >0 && task_tags_found>0 && user_tags_found>0)
	{
		char* tmpPlant = NULL;
		tmpPlant = (char *) MEM_alloc(1 * sizeof(char *));
		int flagD9Y01UnderVeh = 0;
		int flagD9Z01UnderVeh = 0;
		int coD9Z01Flag = 0;
		int cabBomLineCount = 0;
		int fromD9Z01Count = 0;
		tag_t coD9Z01 = NULLTAG;
		char* clubbedInformation = NULL;
		tag_t* cabBomLineForD9Z01 = NULL;
		tag_t* cabBomLineFromD9Z01 = NULL;
		tag_t* ToBeUpdatedInCab	=	NULL;
		int		 ToBeUpdatedCount	=	0;
		int wrongD9Z01Flag = 0;
		int commonFound = 0;
		tag_t commonD9Z01 = NULLTAG;
		clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
		
		printf("\n********* All okay hence proceed further*********\n");fflush(stdout);
		get_Plant(selectedTask,&tmpPlant);
		printf("\n user is from [%s] Plant",tmpPlant);fflush(stdout);
		GetBomClosureRule("MBOM1",tmpPlant);
		checkControlObjectLive("R40Modl","R40Modl","False",&coD9Z01Flag,&coD9Z01);
		printf("\n coD9Z01Flag : [%d]\n",coD9Z01Flag);fflush(stdout);
		if(coD9Z01Flag==0)
		{
			printf("\nExit program with popup to user\n");fflush(stdout);
		}
		else
		{
			printf("\n coD9Z01Flag is Live hence proceed further\n");fflush(stdout);
			getControlObjectDetails(coD9Z01 , &clubbedInformation);
			printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
		}
		//Check 1: D9Y01:Should be present under Vehicle at Level1 in MBOM View - Later this chec should be based on Modular Accuracy check
		checkD9Y01UnderVeh(itemRev,tmpPlant,&flagD9Y01UnderVeh);
		printf("\n flagD9Y01UnderVeh : [%d]\n",flagD9Y01UnderVeh);fflush(stdout);
		//This function will get the to be D9Z01 Bom from MBOM View of the vehicle
		getCabBomLineMbomView(itemRev,clubbedInformation,&cabBomLineForD9Z01,&cabBomLineCount);
		printf("\n cabBomLineCount : [%d] \n",cabBomLineCount);fflush(stdout);		
		printTagLoop(cabBomLineForD9Z01,cabBomLineCount);
		//Check 2: D9Z01
		GetBomClosureRule("APL",tmpPlant);
		checkD9Z01UnderVeh(itemRev,tmpPlant,&flagD9Z01UnderVeh);
		printf("\n flagD9Z01UnderVeh : [%d]\n",flagD9Z01UnderVeh);fflush(stdout);		
		//flagD9Z01UnderVeh = 0; //to be removed in production just for test
		if(flagD9Z01UnderVeh ==1)
		{
			//Get D9Z01 BomLine and if the same bom is present then no action is required
			printf("\n D9Z01 is present, Get D9Z01 BomLine and if the same bom is present then no action is required\n");fflush(stdout);		
			GetBomClosureRule("APL",tmpPlant);
			getCabBomLineAPLView(D9Z01UnderVeh,&cabBomLineFromD9Z01,&fromD9Z01Count);
			printf("\n fromD9Z01Count : [%d] \n",fromD9Z01Count);fflush(stdout);		
			printTagLoop(cabBomLineFromD9Z01,fromD9Z01Count);
			if(fromD9Z01Count != cabBomLineCount)
			{
				printf("\n MBOM and APL Sets are different in qty\n");fflush(stdout);		
				fromToBomCompare(cabBomLineForD9Z01,cabBomLineFromD9Z01,cabBomLineCount,&ToBeUpdatedInCab,&ToBeUpdatedCount);
				wrongD9Z01Flag = 1;
			}
			else
			{
				//check for equality of the BOM of D9Z01 and MBOM View
				printf("\n bomCompare between MBOM and APL as sets are same in qty\n");fflush(stdout);		
				fromToBomCompare(cabBomLineForD9Z01,cabBomLineFromD9Z01,cabBomLineCount,&ToBeUpdatedInCab,&ToBeUpdatedCount);
				printf("\n ToBeUpdatedCount : [%d] \n",ToBeUpdatedCount);fflush(stdout);
				printTagLoop(ToBeUpdatedInCab,ToBeUpdatedCount);
				if( ToBeUpdatedCount >0)
					wrongD9Z01Flag=1;
			}
			//check for revise
			if(wrongD9Z01Flag == 1)
			{
				int  	n_parents=0;
				int * 	levels;
				tag_t * 	parents	 =NULLTAG;
				printf("\n Checking for revise case\n");fflush(stdout);
				ITKCALL(PS_where_used_all(D9Z01UnderVeh,1,&n_parents,&levels,&parents));
				printf("\n***** No of Parent objects are n_parents : %d\n",n_parents);fflush(stdout);
				//n_parents = 2; //to be removed in production just for test 
				if(n_parents > 1)
				{
					printf("\n Since existing D9Z01 is applicable to multiple Vehicles, Hence searching for Common D9Z01\n");fflush(stdout);
					commonFound = t5CheckForCommonD9Z01Obj(cabBomLineForD9Z01 ,cabBomLineCount,tmpPlant, vehicleProject, &commonD9Z01);
					//commonFound = 0; //to be removed in production just for test 
					if(commonFound == 1)
					{
						printf("\n Common D9Z01 Exists\n");fflush(stdout);
						//Attach D9Z01 to Vehicle in APL View
						//APL,Mbom, 0--
						//-12
						//-1-
						//--2
						
						//pnt - 0--
						tag_t*	parentBvr= NULLTAG;
						int	parentBvrCount= 0;
						char* view_name = NULL;
						tag_t	*occurrences	=	NULLTAG;
						ITKCALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
						printf("\n parentBvrCount : [%d] \n",parentBvrCount);fflush(stdout);
						if(parentBvrCount>0)
						{
							int noccs = 0;
							tag_t *noccsal = NULLTAG;
							char* existingD9Z01 = NULL;
							char* nocc_item_id = NULL;
							int noccsItr=0;
							tag_t	nChildItem		= NULLTAG;
							tag_t	nbvrchild		= NULLTAG;
							printf("\n Inside for loop ..");fflush(stdout);
							ITKCALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
							printf("\n view_name %s",view_name);fflush(stdout);
							ITKCALL(AOM_ask_value_string(D9Z01UnderVeh,"item_id",&existingD9Z01));
							printf("\n existingD9Z01 %s",existingD9Z01);fflush(stdout);
							printf("\n Delete old D9Z01\n");fflush(stdout);
							//Delete old D9Z01
							ITKCALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
							printf("\n PS_list_occurrences_of_bvr noccs : [%d] \n",noccs);fflush(stdout);
							//CALLAPI(AOM_lock( parentBvr[0]));
							for(noccsItr=0;noccsItr<noccs;noccsItr++)
							{
								ITKCALL(PS_ask_occurrence_child(parentBvr[0],noccsal[noccsItr], &nChildItem, &nbvrchild));
								ITKCALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
								printf("\n nChildItem number- [%s]",nocc_item_id);fflush(stdout);
								if(tc_strcmp(existingD9Z01,nocc_item_id)==0)
								{
									//ITKCALL(PS_delete_occurrence(parentBvr[0], noccsal[noccsItr]));
									printf("\n Deleting existing D9Z01 i.e [%s]",existingD9Z01);fflush(stdout);
								}
							}

							printf("\n D9Z01 Added \n");fflush(stdout);
							//Update CVM for APL plants to 1--
							
							updateCVM(itemRev,cabBomLineForD9Z01 , cabBomLineCount,tmpPlant);
							//createtask_attchedtoDML(DMLNumberr , commonD9Z01,tmpPlant,vehicleProject);
						}
					}//End of if(commonFound == 1)
					else
					{
						tag_t NewD9Z01 = NULLTAG;
						printf("\n No Common D9Z01 Exists so going to create New D9Z01\n");fflush(stdout);
						CreateD9Z01ObjAndBom(itemRev,cabBomLineForD9Z01 , cabBomLineCount,tmpPlant, vehicleProject , vehicleDrAr,&NewD9Z01);	
						createtask_attchedtoDML(DMLNumberr , NewD9Z01,tmpPlant,vehicleProject);
					}
				}
				else
				{
					printf("\n D9Z01 is applicable to single vehicle\n");fflush(stdout);
					commonFound = t5CheckForCommonD9Z01Obj(cabBomLineForD9Z01 ,cabBomLineCount,tmpPlant, vehicleProject, &commonD9Z01);
					//commonFound =2;
					if(commonFound == 1)
					{
						printf("\n Common *** D9Z01 Exists\n");fflush(stdout);
						//Attach D9Z01 to Vehicle in APL View
						//APL,Mbom, 0--
						//-12
						//-1-
						//--2
						
						//pnt - 0--
						tag_t*	parentBvr= NULLTAG;
						int	parentBvrCount= 0;
						char* view_name = NULL;
						tag_t	*occurrences	=	NULLTAG;
						ITKCALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
						printf("\n parentBvrCount ** : [%d] \n",parentBvrCount);fflush(stdout);
						if(parentBvrCount>0)
						{
							int noccs = 0;
							tag_t *noccsal = NULLTAG;
							char* existingD9Z01 = NULL;
							char* nocc_item_id = NULL;
							int noccsItr=0;
							tag_t	nChildItem		= NULLTAG;
							tag_t	nbvrchild		= NULLTAG;
							printf("\n Inside for loop ***");fflush(stdout);
							ITKCALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
							printf("\n view_name *** %s",view_name);fflush(stdout);
							ITKCALL(AOM_ask_value_string(D9Z01UnderVeh,"item_id",&existingD9Z01));
							printf("\n existingD9Z01 *** %s",existingD9Z01);fflush(stdout);
							printf("\n Delete old D9Z01 ***\n");fflush(stdout);
							ITKCALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
							printf("\n PS_list_occurrences_of_bvr noccs *** : [%d] \n",noccs);fflush(stdout);
							//CALLAPI(AOM_lock( parentBvr[0]));
							for(noccsItr=0;noccsItr<noccs;noccsItr++)
							{
								ITKCALL(PS_ask_occurrence_child(parentBvr[0],noccsal[noccsItr], &nChildItem, &nbvrchild));
								ITKCALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
								printf("\n nChildItem number ***- [%s]",nocc_item_id);fflush(stdout);
								if(tc_strcmp(existingD9Z01,nocc_item_id)==0)
								{
									//ITKCALL(PS_delete_occurrence(parentBvr[0], noccsal[noccsItr]));
									printf("\n Deleting existing D9Z01 *** i.e [%s]",existingD9Z01);fflush(stdout);
								}
							}
							
							// ITKCALL(PS_create_occurrences(parentBvr[0],commonD9Z01,NULLTAG,1,&occurrences));
							//ITKCALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
							// ITKCALL(AOM_save(parentBvr[0]));
							// CALLAPI(AOM_refresh(parentBvr[0],1));
							// CALLAPI(AOM_refresh(itemRev,0));
							// CALLAPI(AOM_unlock(parentBvr[0]));
							printf("\n D9Z01 Added ***\n");fflush(stdout);
							//Update CVM for APL plants to 1--
							// Here two cases
							// Case 1: Count Same but wrongD9Z01Flag
							// Case 2: Count Mismatch
							
							updateCVM(itemRev,cabBomLineForD9Z01 , cabBomLineCount,tmpPlant);
							//createtask_attchedtoDML(DMLNumberr , commonD9Z01,tmpPlant,vehicleProject);
						}
					}//End of if(commonFound == 1)
					else
					{
						tag_t NewD9Z01 = NULLTAG;
						char* existingD9Z01 = NULL;
						ITKCALL(AOM_ask_value_string(D9Z01UnderVeh,"item_id",&existingD9Z01));
						
						//ITKCALL(AOM_set_value_string(D9Z01UnderVeh,"t5_ModuleAddress","D9Z01"));
						//AOM_save(D9Z01UnderVeh);
						printf("\n No Common D9Z01 Exists so going to Revise [%s]\n",existingD9Z01);fflush(stdout);
						
						ITKCALL(ITEM_copy_rev(D9Z01UnderVeh,NULL,&NewD9Z01));
						ITKCALL(AOM_refresh(D9Z01UnderVeh,0));
						ITKCALL(AOM_refresh(NewD9Z01,0));
						createModifyBom(NewD9Z01 , cabBomLineForD9Z01 , cabBomLineCount , tmpPlant );
						createtask_attchedtoDML(DMLNumberr , NewD9Z01,tmpPlant,vehicleProject);
					}
				}
			}
		}
		else if (flagD9Z01UnderVeh == 0)
		{
			tag_t NewD9Z01 = NULLTAG;
			printf("\n No D9Z01 exists under vehicle [%s] \n",selectedVehicle);fflush(stdout);
			commonFound = t5CheckForCommonD9Z01Obj(cabBomLineForD9Z01 ,cabBomLineCount,tmpPlant, vehicleProject, &commonD9Z01);
			if(commonFound==0)
			{
				CreateD9Z01ObjAndBom(itemRev,cabBomLineForD9Z01 , cabBomLineCount,tmpPlant, vehicleProject , vehicleDrAr,&NewD9Z01);	
				createtask_attchedtoDML(DMLNumberr , NewD9Z01,tmpPlant,vehicleProject);
			}
			else
			{
				printf("\n communization process [%s] \n",selectedVehicle);fflush(stdout);
				tag_t*	parentBvr= NULLTAG;
				int	parentBvrCount= 0;
				char* view_name = NULL;
				tag_t	*occurrences	=	NULLTAG;
				ITKCALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
				printf("\n parentBvrCount : [%d] \n",parentBvrCount);fflush(stdout);
				if(parentBvrCount>0)
				{
					int noccs = 0;
					tag_t *noccsal = NULLTAG;
					char* existingD9Z01 = NULL;
					char* nocc_item_id = NULL;
					int noccsItr=0;
					tag_t	nChildItem		= NULLTAG;
					tag_t	nbvrchild		= NULLTAG;
					printf("\n Inside for loop ..");fflush(stdout);
					ITKCALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
					printf("\n view_name %s",view_name);fflush(stdout);
					ITKCALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
					printf("\n 	noccs - [%d] \n",noccs);fflush(stdout);
					CALLAPI(AOM_lock( parentBvr[0]));
					ITKCALL(PS_create_occurrences(parentBvr[0],commonD9Z01,NULLTAG,1,&occurrences));
					//ITKCALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
					ITKCALL(AOM_save(parentBvr[0]));
					CALLAPI(AOM_refresh(parentBvr[0],1));
					CALLAPI(AOM_refresh(itemRev,0));
					CALLAPI(AOM_unlock(parentBvr[0]));
					printf("\n D9Z01 Added \n");fflush(stdout);
					//Update CVM for APL plants to 1--
					// Here two cases
					// Case 1: Count Same but wrongD9Z01Flag
					// Case 2: Count Mismatch
					
					updateCVM(itemRev,cabBomLineForD9Z01 , cabBomLineCount,tmpPlant);
					//createtask_attchedtoDML(DMLNumberr , commonD9Z01,tmpPlant,vehicleProject);
				}
			}
		}
		else
		{
			printf("\n Something went wrong, please check once\n");fflush(stdout);		
		}
	}
    return ifail;
}
*/
int ModCabBomRestFunc(void *return_data)
{
	int 			status;
	int 		    i,m,t				=0;
	int				ifail 				=	ITK_ok;
	int             MBOMViewChildLinesCount = 0;
	char 			*selectedVehicle	=	NULL;
	char 			*selectedVehRev		=	NULL;
	char 			*selectedVehSeq		=	NULL;
	char 			*selectedTask		= 	NULL;
	char 			*userName			= 	NULL;
	char	         command[1000];
	char	        *VehChildPart_type				= NULL;	
	char *output = NULL;
	char ChildRelErr[1000] = "";
	tag_t       item                    = NULLTAG;
	EPM_decision_t   decision;
	tag_t           *ClosureA_tagMBOM			= NULLTAG;
	tag_t           *VehicleitemTag			= NULLTAG;
	tag_t            revTag			= NULLTAG;
	tag_t*          MBOMViewViewChildLines = NULL;
	tag_t           Fclosure_ruleMBOM		= NULLTAG;
	int Part_count =0;
	char *ClosureRuleMBOM = (char *) malloc(50*sizeof(char));
	char *RptString=NULL;
	
    char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int     control_number_found1    = 0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	
	printf("\n I am in main program");fflush(stdout);
	USERARG_get_string_argument(&selectedVehicle);	
	USERARG_get_string_argument(&selectedVehRev);	
	USERARG_get_string_argument(&selectedVehSeq);	
	USERARG_get_string_argument(&selectedTask);
	USERARG_get_string_argument(&userName);
	
	printf("\n Input selectedVehicle :: %s ",selectedVehicle);fflush(stdout);
	printf("\n Input selectedVehRev :: %s ",selectedVehRev);fflush(stdout);
	printf("\n Input selectedVehSeq :: %s ",selectedVehSeq);fflush(stdout);
	printf("\n Input selectedTask :: %s ",selectedTask);fflush(stdout);
	printf("\n Input userName :: %s ",userName);fflush(stdout);
	
	/* ---------------- Find Item & Revision ---------------- */
  // ITK_CALL(ITEM_find_item(selectedVehicle, &VehicleitemTag));
  // ITK_CALL(ITEM_find_rev(VehicleitemTag, selectedVehRev, &revTag));
  
     if (QRY_find2("Control Objects...", &qryTagCntrl1) == ITK_ok && qryTagCntrl1 != NULLTAG)
     {
        printf("\n Control Object Query Found"); fflush(stdout);

        qry_valuesCntrl1[0] = "D9Z01CONTROL";
        qry_valuesCntrl1[1] = "D9Z01CONTROL";
        qry_valuesCntrl1[2] = "0";
    
      QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1);
	  printf("\n control_number_found1 ===> %d", control_number_found1); fflush(stdout);
     }
     else
     {
        printf("\n Control Object Query not Found"); fflush(stdout);
     }
    /* ---------------- if control object found do mbom validation ---------------- */
	 if (control_number_found1 > 0)
     {
        printf("\n control object found running MBOM Validation"); fflush(stdout);
		
       const char *attrs[1];
	   const char *values[1];
			
	   attrs[0] ="item_id";  
	   values[0] = selectedVehicle;
		/*******GET ITEM*************************************************************/		
	   ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs,values,&Part_count, &VehicleitemTag)); 
	   if(Part_count>0)
	   {
                      			
	    RptString=(char *)MEM_alloc(500);
        tc_strcpy(RptString,"");
	    strcpy(RptString,selectedVehRev);
	    strcat(RptString,";"); 
	    strcat(RptString,selectedVehSeq);
	    printf("\n concatenated string is %s",RptString);  
		/*******GET ITEM ALL REVISION*************************************************************/	
        item = VehicleitemTag[0];
	    ITK_CALL(ITEM_find_revision(item,RptString,&revTag));
	/* ---------------- Vehicle Expansion in MBOM View ---------------- */
	
	   tag_t tWindowMBOM = NULLTAG;
       int CRule_foundMBOM     = 0;
	   ITKCALL(BOM_create_window(&tWindowMBOM));
	   //printf("New window is created");
	   tag_t tRuleMBOM= NULLTAG;
	   ITKCALL(CFM_find("MBOM release and above", &tRuleMBOM));
	   //printf("\nMBOM release and above is %d",tRuleMBOM);
	   tc_strcpy(ClosureRuleMBOM,"BOMViewClosureRuleMBOM");
	   PIE_find_closure_rules2( ClosureRuleMBOM,PIE_TEAMCENTER,&CRule_foundMBOM,&ClosureA_tagMBOM);
	   if (CRule_foundMBOM > 0)
	   {
		Fclosure_ruleMBOM = ClosureA_tagMBOM[0];
	    ITK_CALL(BOM_window_set_closure_rule(tWindowMBOM,Fclosure_ruleMBOM,0,NULL,NULL));
		ITK_CALL(BOM_set_window_config_rule( tWindowMBOM, tRuleMBOM ));
		tag_t tBOMTopLineMBOM = NULLTAG;
	/* ---------------- Set Top Line --------------------------------*/
	    //ITKCALL(BOM_set_window_top_line(tWindowMBOM, NULLTAG, revTag[m], NULLTAG, &tBOMTopLineMBOM));
		ITKCALL(BOM_set_window_top_line(tWindowMBOM, NULLTAG, revTag, NULLTAG, &tBOMTopLineMBOM));
	    ITKCALL(BOM_line_ask_child_lines(tBOMTopLineMBOM, &MBOMViewChildLinesCount, &MBOMViewViewChildLines));
		printf("\nNo of MBOMViewViewChildLines Found --------> %d\n",MBOMViewChildLinesCount);fflush(stdout);
		
    /* ---------------- Check Part Type --------------------------------*/
		for (int i = 0; i < MBOMViewChildLinesCount; i++)
         {
		  printf("\n New 111window is created");
          ITK_CALL(AOM_ask_value_string(MBOMViewViewChildLines[i],"bl_Design Revision_t5_PartType",&VehChildPart_type));
		   printf("\n Part_type  is :%s\n", VehChildPart_type);
		   if((tc_strcmp(VehChildPart_type,"T")==0))
			{
               printf("\n ERRORRRR:TPL found in Vehicle BOM, Part ID: %s\n", selectedVehicle);fflush(stdout);
			  snprintf(ChildRelErr, sizeof(ChildRelErr),
                         "BOM_ERROR111:Vehicle %s is having hybrid structure (modular + TPL), hence D9Z01 will not generate for this Vehicle.",
                         selectedVehicle);

                EMH_clear_errors();
                EMH_store_error_s2(
                    EMH_severity_error,
                    ITK_errStore1,
			        ChildRelErr,
					NULL
                ); 
	        //EMH_clear_errors();
			//EMH_store_error_s2(EMH_severity_error,ITK_errStore1,"BOM_ERROR111:Vehicle[selectedVehicle] is having hybrid structure (modular + TPL), hence D9Z01 will not generate for this Vehicle.",selectedVehicle);
    
               decision = EPM_nogo;
			   return ITK_errStore1;
             
                                               
            }			       
         }

	    }
	  }
	 }
	 
	 else
    {
        printf("\n control object not found skipping MBOM Validation"); fflush(stdout);
    }
	
	/* ---------------- END found VEHICLE BOM  ---------------- */
	//sprintf(command,"/home/manishk1.ttl/manish/tm_ModCabBomRestService %s %s %s %s %s",selectedVehicle,selectedVehRev,selectedVehSeq,selectedTask,userName);
	//sprintf(command,"/user/cvprod/shells/D9Z01.sh  %s %s %s %s %s",selectedVehicle,selectedVehRev,selectedVehSeq,selectedTask,userName);
	sprintf(command,"/user/cvprod/shells/APL/D9Z01.sh  %s %s %s %s %s",selectedVehicle,selectedVehRev,selectedVehSeq,selectedTask,userName);
	TC_write_syslog("Command = %s\n",command);
	system(command);
	output = (char *)MEM_alloc(100);
    tc_strcpy(output, "D9Z01 executed successfully");

    *((char **)return_data) = output;
	return ITK_ok;
}

extern int tm_ModCabBomRestServiceCalling(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
	int nargs = 5;//To be recieved from RAC
	int retValueType;
	int* inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	
	inputArgTypes[0] = USERARG_STRING_TYPE; //vehicle Number
	inputArgTypes[1] = USERARG_STRING_TYPE; //Rev
	inputArgTypes[2] = USERARG_STRING_TYPE; //Seq
	inputArgTypes[3] = USERARG_STRING_TYPE; //Selected Task
	inputArgTypes[4] = USERARG_STRING_TYPE; //UserName
		
	retValueType = USERARG_STRING_TYPE ; 
	//printf("\n tm_ModCabBomRestServiceCalling before....ModCabBomRestFunc");fflush(stdout);  
	ifail=USERSERVICE_register_method("ModCabBomRestFunc",(USER_function_t)ModCabBomRestFunc,nargs,inputArgTypes,retValueType);
	return ifail;
	
}

extern DLLAPI int tm_ModCabBomRestService_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registering userservice....tm_ModCabBomRestService");fflush(stdout);   
	ifail = CUSTOM_register_exit("tm_ModCabBomRestService", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ModCabBomRestServiceCalling);
	//printf("\n After registering userservice....tm_ModCabBomRestService");fflush(stdout);
	return(ITK_ok);
}
