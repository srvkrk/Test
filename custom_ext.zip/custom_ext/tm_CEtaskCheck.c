#include "TMLLibrary_server_exits.h"

int tm_CEtaskCheck(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int jkk					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int	taskflag            = 0;
	int	count               = 0;
	int	tskcount            = 0;
	int	tsk                 = 0;
	int error_code			= ITK_ok;
	int CECHKFlag			= 0;
	int Prtycount			= 0;

	char *dmlTaskNo         = NULL;
	char *DMLtype           = NULL;
	char *sDMLno            = NULL;
	char *DMLprirty         = NULL;
	char *ObjTyp            = NULL;
	char *info1					= NULL;
	char *info2					= NULL;
	char *info3					= NULL;
	char *info4					= NULL;
	char *RelTypeCat			= NULL;
	char *catDMlBU				= NULL;
	char *ObjClassName			= NULL;
	char *item_id				= NULL;
	char *DML_no				= NULL;
	char **DesignGroupList		= NULL;
	char *DML_Project_Code		= NULL;
	char *businessUnit			= NULL;
	char *releasetype			= NULL;
	char *fromtostatus			= NULL;
	char *sDMLDR				= NULL;
	char *tskid					= NULL;
	char *ProjVehClass			= NULL;
	char *ProjDesc				= NULL;
	char *Proj_PltFrm			= NULL;
	char *Proj_BU				= NULL;
	char *sProjecttype			= NULL;
	char *sXOinfo1				= NULL;
	char *sXOinfo2				= NULL;
	char *sXOinfo3				= NULL;
	char *sXOinfo4				= NULL;
	char *DML				    = NULL;
	char *Prty_typ				= NULL;
	char *sVehProj				= NULL;
	char *AnaAssignee			= NULL;
	char *Assignee			    = NULL;
	char *AssigneeGrp			= NULL;
	char *DMUAccesNm			= NULL;
	char *ActGmName1			= NULL;
	char *Task_class			= NULL;
	char *type_name8			= NULL;
	char *type_name			    = NULL;
	char *TskAnlyst			    = NULL;
	char *TskAnlystGrp			= NULL;
	char *DMUAssignee			= NULL;
	char *CRBassigned			= NULL;
	char *CRBassignedGrp	    = NULL;
	char *Tsk_Prty_typ	    = NULL;
	char *DMLno	    = NULL;

	tag_t  *DMLRevision     = NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  *contrlObjs	    = NULLTAG;
	tag_t  *tskobjs		    = NULLTAG;
	tag_t  *DmlCRB		    = NULLTAG;
	tag_t  DmlCRBTag		    = NULLTAG;
	tag_t  TagClassId	    = NULLTAG;
    tag_t  roottask			= NULLTAG;
	tag_t  objTypTag        = NULLTAG;
	tag_t  DMLRevTg         = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  DMLTag           = NULLTAG;
	tag_t  DMLRevTag        = NULLTAG;
	tag_t  query			= NULLTAG;
	tag_t  tskreltype	    = NULLTAG;
	tag_t  ObjTypTskCRB	    = NULLTAG;
	tag_t  dml_Prty_rel_type	    = NULLTAG;
	tag_t  DMLTaskTag = NULLTAG;
	logical is_latest;

	char   objTypeofTask[TCTYPE_name_size_c+1];
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_entriesProj = (char **) MEM_alloc(30 * sizeof(char *));
	char **DML_qry_entry = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	char **qry_valuesProj = (char **) MEM_alloc(100 * sizeof(char *));
	char **DML_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t  *Attachments	    = NULLTAG;
	printf("\n tm_CEtaskCheck Function started...");fflush(stdout);
	TC_write_syslog("\n tm_CEtaskCheck Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_CEtaskCheck:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_CEtaskCheck:INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if(DMLRevTag != NULLTAG)
			{
			  qry_entries[0] ="SYSCD";
			  qry_values[0]  ="CECHK";

			  ITK_CALL(QRY_find2("Control Objects...", &query));
			  ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
			  printf("\n Control objects : count==>%d \n",count);fflush(stdout);
			  if (count>0)
			  {

				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&info1));
				ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&info2));

				printf("\n L1:info1 is : [%s]  L2:info2 is : [%s] \n",info1,info2);fflush(stdout);

				if (tc_strstr(info1,"CECHKOFF")==NULL)
				{
					ITK_CALL(POM_class_of_instance(DMLRevTag,&TagClassId));	//class=ChangeRequestRevision
					ITK_CALL(POM_name_of_class(TagClassId,&ObjClassName));
					printf("\n ObjClassName: %s",ObjClassName);

					if(tc_strstr(ObjClassName,"ChangeRequestRevision")!=NULL)
					{
						printf("\n  class is ChangeRequestRevision......\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&item_id));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"current_id",&DML_no));
						//ITK_CALL(AOM_ask_value_strings(DMLRevTag,"t5_crdesigngroup",&DesignGroupList));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&releasetype));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DML_Project_Code));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&businessUnit));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&fromtostatus));
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&sDMLDR));
						//printf("\n from to status is : [%s]\n", info2);fflush(stdout);
						printf("\n item_id : %s, DML_no : %s, releasetype is :%s DML_Project_Code:%s businessUnit:%s fromtostatus:%s sDMLDR:%s \n",item_id,DML_no,releasetype,DML_Project_Code,businessUnit,fromtostatus,sDMLDR);fflush(stdout);

						ITK_CALL(GRM_find_relation_type("HasParticipant", &dml_Prty_rel_type));
						if (dml_Prty_rel_type!=NULLTAG)
						{
							printf("\n MT:inside Check HasParticipant.. \n");fflush(stdout);
							ITK_CALL(AOM_ask_value_string(Attachments[i],"item_id",&DMLno));
							printf("\n MT: DMLno::\n",DMLno);	fflush(stdout);

							ITK_CALL(GRM_list_secondary_objects_only(Attachments[i],dml_Prty_rel_type,&Prtycount,&DmlCRB));
							printf("\n MT: DmlCRB count: %d",Prtycount);fflush(stdout);
							if(Prtycount > 0)
							{						
								for (jkk=0;jkk<Prtycount ;jkk++ )
								{
									//printf("\n MT:jkk: %d.\n",jkk);fflush(stdout);
									DmlCRBTag = DmlCRB[jkk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypTskCRB));
									if(TCTYPE_ask_name2(ObjTypTskCRB,&Tsk_Prty_typ));
									if (tc_strcmp(Tsk_Prty_typ,"T5_CEReviewer")==0)
									{
										printf("\n P2. \n");fflush(stdout);
										CECHKFlag=1;
										printf("CE Reviewer is assigned is %d",CECHKFlag);fflush(stdout);
										break;

									}
								}
							}
						}
						if (CECHKFlag==1)
						{
							printf("\n : task found.....\n");fflush(stdout);
							return 0;
						}
						else
						{
							printf("\n  Other group task..... \n");fflush(stdout);
							return 1;
						}
					}
					else
					{
						  printf("\n Not a valid Type. \n");fflush(stdout);
						  return 0;
					}
				}
			    else
			    {
					  printf("\n CECHKOFF...... \n");fflush(stdout);
					  return 0;
			    }
			  }
			}
		}
	}
	printf("\n tm_CEtaskCheck Function end...");fflush(stdout);
	TC_write_syslog("\n tm_CEtaskCheck Function end...");
	//return error_code;
	return 0;
}