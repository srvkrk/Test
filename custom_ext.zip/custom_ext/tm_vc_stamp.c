/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   Workflow Rule Handler for SVR Work Flow check..
*  Code                 :   tm_vc_stamp.c
*  Created on			:   21/05/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 28/08/2019				Abhilash Shilamkar			VC_Handler
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_vc_stamp(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVC				= 0;
	int error_code			= ITK_ok;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t   DMLObject		= NULLTAG;

	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *DMLDRstauts		=NULL;
	char   *value			=NULL;
	char	command[512];
	char*	ObjTyp=NULL;
	char   *info1		= NULL;
	char   *info2		= NULL;
	char   *info3		= NULL;
	char   *info4		= NULL;

	//control logic:
	tag_t   qryTag		= NULLTAG;
	int     n_entry		= 1;
	int     rsltCount	= 0;
	char    *qry_entry[1]  = {"SYSCD"};
	tag_t   *CntrlObjectTag   = NULLTAG;
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n tm_vc_stamp Function started...");fflush(stdout);
	TC_write_syslog("\n tm_vc_stamp Function started...");

	//EPM_decision_t decision = EPM_go;
	
	printf("\n *********** ::start here:: **********");fflush(stdout);

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation));
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
					if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
					printf("\n\t count is : %d",count);
					
					if(count >0)
					{
						
						for(j=0;j<count;j++)
						{
						  if(AOM_ask_value_string(SecObject[j],"object_type",&objecttype));
						  if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
						  //if(AOM_ask_value_string(SecObject[j],"object_desc",&objectdesc));
						  if(AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus));
						  //if(AOM_ask_value_string(SecObject[j],"t5_PartStatus",&objectDRstatus));

						  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
						  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
						  //printf("SecObject objectdesc = [%s]\n",objectdesc);fflush(stdout);
						  printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
						  //printf("SecObject objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
							
							if(tc_strlen(objectId)>0)
							{
							  if(tc_strlen(objectId)==9) 
							  {
								
								if ((strcmp(objectrelstatus,"T5_LcsReview")==0) || (strcmp(objectrelstatus,"ERC Review")==0))
								{
									printf("\n INSIDE To Run SH %s", objectId);fflush(stdout);
									//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/expgmdml.sh %s ",objectId);
									//TC_write_syslog("Command = %s\n",command);
									//system(command);

									//Control object logic:
									if(QRY_find2("ControlObjects", &qryTag));
									if (qryTag)
									{
										printf("\n P13:Found Query ControlObjects \n");fflush(stdout);
									}
									else
									{
										printf("\n P14:Not Found Query ControlObjects \n");fflush(stdout);
									}

									qry_values2[0] = "VCCHCK";
									if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
									printf(" \n <<rsltCount:>>%d:", rsltCount); fflush(stdout);
									if(rsltCount > 0)
									{
										//if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
										if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
										printf("\n info1 is :[%s]\n", info1);fflush(stdout);
										printf("\n info2 is :[%s]\n", info2);fflush(stdout);
										printf("\n info3 is :[%s]\n", info3);fflush(stdout);
										printf("\n info4 is :[%s]\n", info4);fflush(stdout);
										if(strstr(info1,"VCOFF")!=NULL)
										{
											printf("\n INSIDE CntrlObjectTag " );fflush(stdout);
											if(strstr(info2,"VCUAPROD")!=NULL)
											{
												printf("\n UAPROD:VC no : %s ", objectId);fflush(stdout);
												sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/vcdml.sh %s ",objectId);
												TC_write_syslog("Command = %s\n",command);
												system(command);
											}
											else if(strstr(info2,"VCCVPROD")!=NULL)
											{
												printf("\n CVPROD:VC no : %s ", objectId);fflush(stdout);
												sprintf(command,"/user/cvprod/shells/DML_DCR/vcdml.sh %s ",objectId);
												TC_write_syslog("Command = %s\n",command);
												system(command);
											}
											else if(strstr(info3,"VCCMITEST")!=NULL)
											{
												printf("\n CMITEST:VC no : %s ", objectId);fflush(stdout);
												sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/vcdml.sh %s ",objectId);
												TC_write_syslog("Command = %s\n",command);
												system(command);
											}
											else if(strstr(info4,"VCUADEV")!=NULL)
											{
												printf("\n UADEV:VC no : %s ", objectId);fflush(stdout);
												sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/vcdml.sh %s ",objectId);
												TC_write_syslog("Command = %s\n",command);
												system(command);
											}
											else
											{
												printf("\n GMDchk:other client \n");fflush(stdout);
											}
										}
									}
								}
								else
								{printf("\n OUT111111111111111111 \n");fflush(stdout);
								}
							  }
							}
						}
					}
				}	
			}
		}
	}
	printf("\n tm_vc_stamp Function end...");fflush(stdout);
	TC_write_syslog("\n tm_vc_stamp Function end...");
	//return error_code;
	return 0;
}