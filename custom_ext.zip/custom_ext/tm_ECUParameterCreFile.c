/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_ECUTechcreate.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for WCQ Result 7 Report.
*				  > This ITK functions are called in Rich Client
* Module
* Since		    :   28-06-2023
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name									Description of Change
* 28/05/2025  	 Prathmesh Deshmukh						    Base Code
*

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h> 
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
//#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
//#include <bom/bom.h>
#include <tccore/aom_prop.h>
//int FDJcount=0;
//int GCIcount=0;

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int ITK_CALL(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

int                     ifail                           = ITK_ok;

//#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 5)
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text(stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
/* //Global Declairation
FILE*       Report_FP      = NULL;
char*       stamptime      = NULL; */
//Global Declaration

int Ifail_error(int Ifail)
{
	char* Error = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &Error);
		  printf("\n Error is : %s", Error);
		  exit(0);
		}

		return iFail;
}
void IMPLstrcat(char **src,char* dest)
{
	//printf("\n Inside Function IMPLstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

int Set_attr_valuesFile(char* part_no, char* rev_id, char* itemid_para, char* EPType, char* EPDesc, char* EPUnit, char* EPLen, char* ECUType, char* EPDidValue, char* EPReadable, char* EPApplicable, char* ECUVendor, char* ECUVersion, char* BitValue);
//int Set_attr_valuesFile(char* part_no, char* rev_id, char* itemid_para, char* rev_para, char* EPType, char* EPDesc, char* EPUnit, char* EPLen, char* EPValueList, char* ECUType, char* EPDidValue, char* EPReadable, char* EPApplicable, char* ECUVendor, char* ECUVersion, char* BitValue, char* ParamValue);
int read_value_from_file_para(char*,char*,char*);
//int create_relationFile(char*, char*, tag_t, char*, char*);
int create_relationFile(char*, char*, tag_t, char*);

extern int ECUParameterCreFile(void *retValue)
{ 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	 //char *output	 = NULL;

	int ifail =ITK_ok;
	int vcattr =0;
	int sec_result_count =0;
	tag_t *statustags = NULLTAG;
	tag_t itemrevtag2 = NULLTAG;
	tag_t Latestrev_Tag = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t designtag = NULLTAG;
	tag_t tRelationFind = NULLTAG;
	tag_t itemrevtag = NULLTAG;
	tag_t itemtag = NULLTAG;
	tag_t Relationtag = NULLTAG;
	

	 char		*sItemId 		= NULL;
	 char		*itemName 		= NULL;
	 char		*Releasestatuspt 		= NULL;
	 char		*releasedate 		= NULL;
	 char		*statusname 		= NULL;
	 char		*revid 		= NULL;
	 
     USERARG_get_string_argument(&sItemId);
	 USERARG_get_string_argument(&revid);

	
     printf("\n selected Item revision %s\n",sItemId);
     printf("\n selected Revision Sequenec %s\n",revid);	





	 tag_t relation_type = NULLTAG;
	 tag_t itemtag2 = NULLTAG;
	// tag_t itemrevtag2 = NULLTAG;
	 tag_t sec_tag_para = NULLTAG;
	 tag_t realRelationTag = NULLTAG;
	 tag_t *rellist = NULLTAG;
	 char		*BitValue 		= NULL;
	 char		*Swtype 		= NULL;
	 char		*Swtype2 		= NULL;
	 char		*type_name				= NULL;
	 char		*type_name2				= NULL;
	 tag_t objTypeTag = NULLTAG;
	 tag_t objTypeTag2 = NULLTAG;

	 int count=0;
	 int i=0;

	  ITK_CALL(ITEM_find_item(sItemId,&itemtag));
	   if (itemtag)
	   {
		ITK_CALL(ITEM_find_revision(itemtag,revid, &itemrevtag));

		ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_SwPartType",&Swtype));
		printf("\n --Swtype= %s  ",Swtype);fflush(stdout);

		ITK_CALL(TCTYPE_ask_object_type(itemrevtag,&objTypeTag));
		ITK_CALL(TCTYPE_ask_name2(objTypeTag, &type_name));
		printf("\n --object_type:%s ", type_name);

        if((tc_strcmp(type_name, "T5_EE_PartRevision") == 0) && (tc_strcmp(Swtype,"PRM")==0))
		 {

			char* class =NULL;
			char               *tempRev_ID	          =NULL;
			char	*Fname	=  NULL;
			char *FullPath=NULL;
			char	*Dataset_Type	=  NULL;
			char	*Dataset_name	=  NULL;
			char* NR_Filename=NULL;
			Fname=(char *)MEM_alloc(100);
			FullPath=(char *) MEM_alloc(1000);

			tag_t dataset_rel_type=NULLTAG;
			 int DsCnt=0;
			int NR_count=0;;
			 tag_t* datasetobj1=NULLTAG;
			tag_t* Named_ref=NULLTAG;
			 tag_t Datasetobj3=NULLTAG;
			 tag_t Named_ref_obj=NULLTAG;

			tc_strcpy(Fname,"");				
			tc_strcat(Fname,stripBlanks(sItemId));
			tc_strcat(Fname,"_");
			ITK_CALL(STRNG_replace_str(revid,";","_",&tempRev_ID));
			tc_strcat(Fname,tempRev_ID);
			tc_strcat(Fname,"_parameter.csv");


			FullPath = strcpy(FullPath,"/tmp/");
			tc_strcat(FullPath,Fname);

			printf("\n file name: %s \n",Fname);
			printf("\n FullPath: %s \n",FullPath);
					
			 class=(char *) MEM_alloc(100);
			 ITK_CALL(AOM_ask_value_string(itemrevtag,"object_name",&class));
			
			 ITK_CALL(GRM_find_relation_type("IMAN_reference", &dataset_rel_type));
			 ITK_CALL(GRM_list_secondary_objects_only(itemrevtag,dataset_rel_type,&DsCnt,&datasetobj1));
			 printf("\n DsCnt = %d \n",DsCnt);fflush(stdout);
			if(DsCnt>0)
			{
				for( i=0; i<DsCnt; i++)
					{
						
						Datasetobj3=datasetobj1[i];

						ITK_CALL(AOM_ask_value_string(Datasetobj3,"object_type",&Dataset_Type));
						printf("\n Dataset_Type = %s \n",Dataset_Type);fflush(stdout);

					   if(tc_strcmp(Dataset_Type,"Text")==0)
					   {
						   printf("\n Dataset_Type Is Text \n");fflush(stdout);

							  ITK_CALL(AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name));
							  printf("\n object_name= %s \n",Dataset_name);fflush(stdout);

								if(tc_strcmp(Dataset_name,Fname)==0)
								{
									printf("\nDataset found checking for Named ref file");fflush(stdout);
									ITK_CALL(AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref));
								  
									if(NR_count>0)
									{
									 //  for( i=0; i<NR_count; i++)
									//	{
										 Named_ref_obj=Named_ref[0];
										 ITK_CALL(AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename));
										 printf("\n NR_Filename= %s \n",NR_Filename);fflush(stdout);
										// if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
											if(tc_strcmp(NR_Filename,Fname)==0)
											{ 
												printf("\n Befor File Export");fflush(stdout);
												//////////////
												char   pathname[SS_MAXPATHLEN + 1];
												char* newNR_Filename =NULL;
												char* datetime = NULL;
												char buffer[80];			
												datetime =(char *) MEM_alloc(sizeof(char)* 50); 
												time_t t = time(NULL);
												struct tm* timeinfo;   
												time(&t);
												timeinfo = localtime(&t);
												strftime(buffer,80,"_%Y-%m-%d-%H-%M-%S",timeinfo);
												printf("\n current date & time : %s \n",buffer);fflush(stdout);
											
												int len = strlen(NR_Filename);
												printf("\n len : %d \n",len);fflush(stdout);
												int  len1=len-4;
												printf("\n len1 : %d \n",len1);fflush(stdout);

												newNR_Filename=subString(NR_Filename, 0, len1);

												printf("\n newNR_Filename: %s \n",newNR_Filename);fflush(stdout);

												tc_strcat(newNR_Filename,buffer);
												tc_strcat(newNR_Filename,".csv");
												sprintf(pathname,"/tmp/%s",newNR_Filename);  

												printf("\n pathname=%s\n",pathname);fflush(stdout);

											///////////////


											   ITK_CALL(AE_export_named_ref(Datasetobj3,"Text",pathname));
												printf("\n Afer File Export");fflush(stdout);
												ifail = read_value_from_file_para(pathname,sItemId,revid);

											   // AE_export_named_ref(Datasetobj3,"Text",FullPath);
												//ifail = read_value_from_file_para(FullPath,sItemId,revid);
									

											}
										
									//   }
									
									}
								}
					   }
					}

			}
            


	     }
      }
	  else
	  {
	  printf("\n part2 not found:%s ", sItemId);
	  }


	return ifail; 
}

int read_value_from_file_para(char* Filename,char* part_no,char* rev_id)
{
      //  char                    *part_no                                        = NULL;
       // char                    *rev_id                                         = NULL;
        char                    *itemid_para                            = NULL;
        char                    *rev_para                                       = NULL;
        char                    *EPType                                         = NULL;
        char                    *EPDesc                                         = NULL;
        char                    *EPUnit                                         = NULL;
        char                    *EPLen                                          = NULL;
        char                    *ECUType                                        = NULL;
        char                    *EPDidValue                                     = NULL;
        char                    *EPReadable                                     = NULL;
        char                    *EPApplicable                           = NULL;
        char                    *ECUVendor                                      = NULL;
        char                    *ECUVersion                                     = NULL;
        char                    *BitValue                                       = NULL;
        char                    *ParamValue                                     = NULL;
                char                    *EPValueList                            = NULL;
        char                    temp[10000];

        FILE            * fp                                    = NULL;
        int flag =0;
		
		printf("\nInput part_no:%s",part_no);

		printf("\nInput rev_id:%s",rev_id);

        fp = fopen(Filename, "r");
        if (fp != NULL)
        {
                while (fgets(temp, 10000, fp)!= NULL)
                {
					flag++;
                        tc_strcpy(temp,stripBlanks(temp));

                        if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
                        {
                         /*      part_no = strtok(temp, ",");
                                printf("\nInput part_no:%s",part_no);

                                rev_id = strtok(NULL, ",");
                                printf("\nInput rev_id:%s",rev_id);*/

								if (flag==1)
								{
									 printf("\n Excluding first line \n");
									continue;
								}

                                itemid_para = strtok(temp, ",");
                                printf("\nInput Parametr Item_id:[%s]",itemid_para);

                          //      rev_para = strtok(NULL, ",");
                           //     printf("\nInput rev_para:%s",rev_para);

                                EPType = strtok(NULL, ",");
                                printf("\nInput EPType:[%s]", EPType);

                                EPDesc = strtok(NULL, ",");
                                printf("\nInput EPDesc:[%s]", EPDesc);

                                EPUnit = strtok(NULL, ",");
                                printf("\nInput EPUnit:[%s]", EPUnit);

                                EPLen = strtok(NULL, ",");
                                printf("\nInput EPLen:[%s]", EPLen);

                            //    EPValueList = strtok(NULL, ",");
                           //     printf("\nInput EPValueList:%s", EPValueList);

                                ECUType = strtok(NULL, ",");
                                printf("\nInput ECUType:[%s]", ECUType);

                                EPDidValue = strtok(NULL, ",");
                                printf("\nInput EPDidValue:[%s]", EPDidValue);

                                EPReadable = strtok(NULL, ",");
                                printf("\nInput EPReadable:[%s]", EPReadable);

                                 EPApplicable = strtok(NULL, ",");
                                printf("\nInput EPApplicable:[%s]", EPApplicable);

                                ECUVendor = strtok(NULL, ",");
                                printf("\nInput ECUVendor:[%s]", ECUVendor);

                                ECUVersion = strtok(NULL, ",");
                                printf("\nInput ECUVersion:[%s]", ECUVersion);

                                BitValue = strtok(NULL, ",");
                                printf("\nInput BitValue:%s", BitValue);

                             //   ParamValue = strtok(NULL, ",");
                            //    printf("\nInput ParamValue:%s\n", ParamValue);


                           //    ifail = Set_attr_valuesFile(part_no, rev_id, itemid_para, rev_para, EPType, EPDesc, EPUnit, EPLen, EPValueList, ECUType, EPDidValue, EPReadable, EPApplicable, ECUVendor, ECUVersion, BitValue, ParamValue);
                               ifail = Set_attr_valuesFile(part_no, rev_id, itemid_para, EPType, EPDesc, EPUnit, EPLen, ECUType, EPDidValue, EPReadable, EPApplicable, ECUVendor, ECUVersion, BitValue);
                        }
                        printf("\n***************************************\n");
                         tc_strcpy(temp, "");
                }
        }
        else
        {
                printf("File Unable to Open...!!");
        }
        fclose(fp);
        return ifail;
}


/******************************************************************************************************
    Function:       Set_attr_valuesFile
    Description:    This function takes the attribute values and print the same.
*******************************************************************************************************/
//int Set_attr_valuesFile(char* part_no, char* rev_id, char* itemid_para, char* rev_para, char* EPType, char* EPDesc, char* EPUnit, char* EPLen, char* EPValueList, char* ECUType, char* EPDidValue, char* EPReadable, char* EPApplicable, char* ECUVendor, char* ECUVersion, char* BitValue, char* ParamValue)
int Set_attr_valuesFile(char* part_no, char* rev_id, char* itemid_para, char* EPType, char* EPDesc, char* EPUnit, char* EPLen, char* ECUType, char* EPDidValue, char* EPReadable, char* EPApplicable, char* ECUVendor, char* ECUVersion, char* BitValue)
{
        int                             i                                                               = 0;
        int                             n_items                                                 = 0;
        int                             objectfound                                             = 0;

        char                    *EPType_cp                                              = NULL;
        char                    *EPDesc_cp                                              = NULL;
        char                    *EPUnit_cp                                              = NULL;
        char                    *EPLen_cp                                               = NULL;
        char                    *ECUType_cp                                             = NULL;
        char                    *EPDidValue_cp                                  = NULL;
        char                    *EPReadable_cp                                  = NULL;
        char                    *EPApplicable_cp                                = NULL;
        char                    *ECUVendor_cp                                   = NULL;
        char                    *ECUVersion_cp                                  = NULL;
        char* errormsg=NULL;
        tag_t                   object                                                  = NULLTAG;
        tag_t                   new_object                                              = NULLTAG;
        tag_t                   relation_type                                   = NULLTAG;
        tag_t                   new_relation                                    = NULLTAG;
        tag_t                   item_type_tag                                   = NULLTAG;
        tag_t                   para_rev_tag                                    = NULLTAG;
        tag_t                   item_create_input_tag                   = NULLTAG;

        tag_t                   *item_tags                                              = NULL;
char*filename1=NULL;
                filename1=(char *) MEM_alloc(100);
                filename1=strcpy(filename1,"Found.txt");
                FILE* fp1 = NULL;
                //fp1 = fopen(filename1,"a+");
      char*filename2=NULL;
                filename2=(char *) MEM_alloc(100);
                filename2=strcpy(filename2,"not_Found.txt");
                FILE* fp2 = NULL;
                //fp2 = fopen(filename2,"a+");
           char *Token_01=NULL;
           char *Token_02=NULL;
       tag_t KWDescQry     = NULLTAG;
            tag_t *moduleTags   = NULL;
                int modCount=0;
                int Entry_count=10;
                char **Values = (char **) MEM_alloc(500 * sizeof(char *));

                char* itemid_para_tok=NULL;
        char* itemid_para_Fin=NULL;
                char* EPDesc_tok=NULL;
        char* EPDesc_Fin=NULL;
                char* ECUVendor_tok=NULL;
        char* ECUVendor_Fin=NULL;

                //item_id tokenmisation

                itemid_para_tok=(char *) MEM_alloc(500);
                itemid_para_Fin=(char *) MEM_alloc(500);
                itemid_para_tok=tc_strcpy(itemid_para_tok,"");
                itemid_para_tok=tc_strcpy(itemid_para_tok,itemid_para);
                if(tc_strstr(itemid_para, ":") !=NULL)
                {

                       Token_01=tc_strtok(itemid_para_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           itemid_para_Fin=tc_strcpy(itemid_para_Fin,"");
                                   itemid_para_Fin=tc_strcpy(itemid_para_Fin,Token_01);
                                   itemid_para_Fin=tc_strcat(itemid_para_Fin,"*");
                                   itemid_para_Fin=tc_strcat(itemid_para_Fin,Token_02);
                }
                                else
                                {
                                        itemid_para_Fin=tc_strcpy(itemid_para_Fin,"");
                                itemid_para_Fin=tc_strcpy(itemid_para_Fin,itemid_para);
                                }


                        printf("\naitemid_para_tok:[%s]",itemid_para_Fin);



                //Paramter descp tokenisation

                EPDesc_tok=(char *) MEM_alloc(500);
                EPDesc_Fin=(char *) MEM_alloc(500);
                EPDesc_tok=tc_strcpy(EPDesc_tok,"");
                EPDesc_tok=tc_strcpy(EPDesc_tok,EPDesc);
                if(tc_strstr(EPDesc, ":") !=NULL)
                {

                       Token_01=tc_strtok(EPDesc_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           EPDesc_Fin=tc_strcpy(EPDesc_Fin,"");
                                   EPDesc_Fin=tc_strcpy(EPDesc_Fin,Token_01);
                                   EPDesc_Fin=tc_strcat(EPDesc_Fin,"*");
                                   EPDesc_Fin=tc_strcat(EPDesc_Fin,Token_02);
                }
                                else
                                {
                                        EPDesc_Fin=tc_strcpy(EPDesc_Fin,"");
                                EPDesc_Fin=tc_strcpy(EPDesc_Fin,EPDesc);
                                }
                        printf("\naEPDesc_tok:[%s]",EPDesc_Fin);

                        //supplier tokenisation

                ECUVendor_tok=(char *) MEM_alloc(500);
                ECUVendor_Fin=(char *) MEM_alloc(500);
                ECUVendor_tok=tc_strcpy(ECUVendor_tok,"");
                ECUVendor_tok=tc_strcpy(ECUVendor_tok,ECUVendor);
                if(tc_strstr(ECUVendor, ":") !=NULL)
                {

                       Token_01=tc_strtok(ECUVendor_tok, ":");
                                           Token_02 =tc_strtok(NULL, ":");
                                           ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,"");
                                   ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,Token_01);
                                   ECUVendor_Fin=tc_strcat(ECUVendor_Fin,"*");
                                   ECUVendor_Fin=tc_strcat(ECUVendor_Fin,Token_02);
                }
                                else
                                {
                                        ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,"");
                                ECUVendor_Fin=tc_strcpy(ECUVendor_Fin,ECUVendor);
                                }


                        printf("\naECUVendor_tok:[%s]",ECUVendor_Fin);



//char *Entries[11] = {"Name","ECU Type","Paramter Desc","Supplier","Versions","Data Type","Unit","Length","DID Value","Applicable to","Read/Write"};
char *Entries[10] = {"Name","ECU Type","Supplier","Versions","Data Type","Unit","Length","DID Value","Applicable to","Read/Write"};

/*Values[0]= itemid_para_Fin;
Values[1]= ECUType;
Values[2]= EPDesc_Fin;
Values[3]= ECUVendor_Fin;
Values[4]= ECUVersion;
Values[5]= EPType;
Values[6]= EPUnit;
Values[7]= EPLen;
Values[8]= EPDidValue;
Values[9]= EPApplicable;
Values[10]=EPReadable;*/

Values[0]= itemid_para_Fin;
Values[1]= ECUType;
Values[2]= ECUVendor_Fin;
Values[3]= ECUVersion;
Values[4]= EPType;
Values[5]= EPUnit;
Values[6]= EPLen;
Values[7]= EPDidValue;
Values[8]= EPApplicable;
Values[9]=EPReadable;



           ifail=QRY_find2("EEPara", &KWDescQry);
           if (KWDescQry)
{


        QRY_execute(KWDescQry, Entry_count, Entries, Values, &modCount, &moduleTags);

         printf("\nMod count = %d\n",modCount);
        if(modCount>0)
        {
         printf("\nparameter Found successfully!!\n");

                //fprintf(fp1,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s\n",itemid_para, ECUType, ECUVendor, ECUVersion, EPApplicable, EPDesc, EPDidValue,EPLen,EPReadable,EPType, EPUnit);

            //    ITK_CALL(create_relationFile(part_no, rev_id, moduleTags[0], BitValue, ParamValue));
                ITK_CALL(create_relationFile(part_no, rev_id, moduleTags[0], BitValue));
        }
        else
        {

                    if((tc_strcmp(EPUnit, " ") == 0) || tc_strlen(EPUnit) == 0)
                        {
                                tc_strcpy(EPUnit, "NA");
                        }
                        if(tc_strcmp(EPLen, " ") == 0 || tc_strlen(EPLen) == 0)
                        {
                                tc_strcpy(EPLen, "NA");
                        }
                   /*     if((tc_strcmp(EPValueList, " ") == 0) || tc_strlen(EPValueList) == 0)
                        {
                                tc_strcpy(EPValueList, "NA");
                        }*/
               printf("\nRequired parameter not found, hence going to create new parameter...!!\n");
                ifail = TCTYPE_find_type("T5_EPara", "Document", &item_type_tag);
                ifail = TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);
                                ifail = AOM_UIF_set_value(item_create_input_tag, "item_id", itemid_para);
                ifail = AOM_UIF_set_value(item_create_input_tag, "object_name", itemid_para);
                                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPType", EPType);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPUnit", EPUnit);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPLen", EPLen);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUType", ECUType);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPDidValue", EPDidValue);
                ifail = AOM_UIF_set_value(item_create_input_tag,"t5_EPReadable",EPReadable);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_EPApplicable", EPApplicable);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUVendor", ECUVendor);
                ifail = AOM_UIF_set_value(item_create_input_tag, "t5_ECUVersion", ECUVersion);
                ifail = TCTYPE_create_object (item_create_input_tag, &object);
                                ifail=AOM_save_without_extensions(object);


                                if(ifail==ITK_ok)
                                {
                                         printf("\nitem created successfully!!\n");
                                                                                 ifail = AOM_refresh (object, 1);

                                            ifail = AOM_UIF_set_value (object, "t5_t5EPDesc",EPDesc);

                                            ifail = AOM_save_without_extensions (object);

                                            ifail = AOM_refresh (object, 0);

                                                                             //   ITK_CALL(create_relationFile(part_no, rev_id, object, BitValue, ParamValue));
                                                                                ITK_CALL(create_relationFile(part_no, rev_id, object, BitValue));

                                }
                                else
                         {
                         printf("\nitem not created successfully!!\n");
                                //fprintf(fp2,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s\n",itemid_para, ECUType, ECUVendor, ECUVersion, EPApplicable, EPDesc, EPDidValue,EPLen,EPReadable,EPType, EPUnit);

                                }
                        ifail=EMH_ask_error_text(ifail,&errormsg);
            printf("\n[%s]\n",errormsg);








        }
        MEM_free(moduleTags);

        //fclose(fp1);
        //fclose(fp2);
}

        return ifail;
}


//int create_relationFile(char* part_no, char* rev_id, tag_t object, char* BitValue, char* ParamValue)
int create_relationFile(char* part_no, char* rev_id, tag_t object, char* BitValue)
{
        int                             i                                                       = 0;
        int                             count                                           = 0;

        char                    *obj_string                                     = NULL;

        tag_t                   *sec_tag                                        = NULL;

        tag_t                   ee_part_rev_tag                         = NULLTAG;
        tag_t                   relation_type                           = NULLTAG;
        tag_t                   new_relation                            = NULLTAG;
        tag_t                   rel_exist                                       = NULLTAG;


                int     number_of_types2;

                tag_t *         type_tag3_R;

                tag_t   object_create_input_tag3_R                  = NULLTAG;



        printf("\nGoing to create relation between EE Part and ECU Parameter Master...!!\n");
        ITK_CALL(ITEM_find_rev (part_no, rev_id, &ee_part_rev_tag));
        printf("\npart:%s and rev:%s\n", part_no, rev_id);
        if(ee_part_rev_tag != NULLTAG)
        {
                printf("\nEE part revision found...!!\n");
                ITK_CALL(GRM_find_relation_type ("T5_EEPrm", &relation_type));

                if(relation_type != NULLTAG)
                {

                     /*   ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
                                                ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));*/

                        printf("\nRelation type found...!!\n");
					 //////////////////////////////////
						tag_t relation_type=NULLTAG;
						tag_t reltag=NULLTAG;
						tag_t rel2=NULLTAG;
						tag_t *rellist2=NULLTAG;
						int cnt =0;
						char* paraobjname=NULL;
						char* curruntname=NULL;
						int found=0;

					   GRM_find_relation_type ("T5_EEPrm", &relation_type);
					   GRM_list_secondary_objects_only(ee_part_rev_tag,relation_type, &cnt, &rellist2);
					   
					   AOM_ask_value_string(object, "object_name", &curruntname);
					   printf("\n Current Clause name: %s ",curruntname);fflush(stdout);

					   for (int r=0;r<cnt;r++)
					   {
						rel2  = rellist2[r];

						AOM_ask_value_string(rel2, "object_name", &paraobjname);

						printf("\n Clause object name: %s ",paraobjname);fflush(stdout);
						if (tc_strcmp(curruntname,paraobjname)==0)
						{
							found=1;
						}

					   }

					   if (found==1)
					   {
						 
						 printf("\n Clause already available: %s ",curruntname);fflush(stdout);

						   GRM_find_relation(ee_part_rev_tag,object,relation_type,&reltag);
						   if (reltag!=NULLTAG)
						   {
							   printf("\n IUpdating User entered value");fflush(stdout);
							   ITK_CALL(AOM_refresh(reltag,1));
							   ITK_CALL(AOM_UIF_set_value(reltag,"t5_BitValue",BitValue));
							    ITK_CALL(AOM_save_without_extensions(reltag));
							   ITK_CALL(AOM_refresh(reltag,0));
							   ITK_CALL(AOM_unlock(reltag));
						   }
						   
					   }
					   else
						{
						   printf("\n Clause not available so creating Relation: %s ",curruntname);fflush(stdout);
						ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
						ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));

						}

                     ///////////////////////////////////



                }
        }
        return ifail;
}


extern int tm_ECUParameterCreFile(int *decision, va_list args)
{	
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
    int retValueType;
	int nargs = 2;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) ); 
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_STRING_TYPE;

	retValueType = USERARG_STRING_TYPE ;
	printf("\n tm_ECUParameterCreFile before....tm_ECUParameterCreFile");fflush(stdout);  
	ifail=USERSERVICE_register_method("ECUParameterCreFile",(USER_function_t)ECUParameterCreFile,nargs,inputArgTypes,retValueType);
	return ifail;
}


extern DLLAPI int tm_ECUParameterCreFile_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registering userservice....tm_ECUParameterCreFile");fflush(stdout);
	ifail = CUSTOM_register_exit("tm_ECUParameterCreFile", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)tm_ECUParameterCreFile);
	printf("\n After registering userservice....tm_ECUParameterCreFile");fflush(stdout);
	return(ITK_ok);
}


