/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Setting VMTL reviewer on task.
*  Code                 :   tm_VMLTReviewerForTask.c
*  Created on			:   28/05/2021
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.		28/05/2021				Mohan Tayade		Setting VMTL reviewer on task.
*   2.	   19.4.22		-			Prasad				Uploaded Data from Bhaskar Folder to DV
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_VMLTReviewerForTask(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *sDMLBU		= NULL;
	char *DMlid		= NULL;
	char *Pathinfo5		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	char *VCDMLcommand		= NULL;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n tm_VMLTReviewerForTask Function started...");fflush(stdout);
	TC_write_syslog("\n tm_VMLTReviewerForTask Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"t5_ERCBusiUt",&sDMLBU)!=ITK_ok)PrintErrorStack();
				printf("\n CH:sDMLBU is :%s\n",sDMLBU);fflush(stdout);
				if(tc_strstr(sDMLBU,"CV") != NULL)
				{
					printf("\n VMTL Reviewer handler bypass for CVBU... \n");fflush(stdout);
				}
				else
				{
					//Control object logic:
					if(QRY_find2("ControlObjects", &DRqryTag));
					if (DRqryTag)
					{
						printf("\n POCHCK:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n POCHCK:Not Found Query ControlObjects \n");fflush(stdout);
					}

					DR_qry_values2[0] = "VMTLTB";
					if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
					printf(" \n POCHCK:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
					if(DR_rsltCount > 0)
					{
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
						printf("\n POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
						if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo5",&Pathinfo5)!=ITK_ok)   PrintErrorStack();
						printf("\n Pathinfo5 is :[%s]\n", Pathinfo5);fflush(stdout);
						if(strstr(POinfo3,"VMTLTBCHKOFF1")==NULL)
						{
							if(strstr(POinfo3,"VMTLTBCHKUAPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UAPROD:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/vmtlrevset.sh %s ",DMlid);
								sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/vmtlrevset.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"VMTLTBCHKCVPROD")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CVPROD:DML no : %s ", DMlid);fflush(stdout);
								//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/vmtlrevset.sh %s ",DMlid);
								sprintf(command,"/user/cvprod/shells/DML_DCR/vmtlrevset.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"VMTLTBCHKCMITEST")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n CMITEST:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/vmtlrevset.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else if(strstr(POinfo3,"VMTLTBCHKUADEV")==NULL)
							{
								if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
								printf("\n UADEV:DML no : %s ", DMlid);fflush(stdout);
								sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/vmtlrevset.sh %s ",DMlid);
								TC_write_syslog("Command = %s\n",command);
								system(command);
							}
							else
							{
								printf("\n POCHCK:other client \n");fflush(stdout);
							}
						}
						else if(strstr(POinfo3,"VC002")==NULL)
						{
							printf("\n VCDRST:PATHBase:command.. \n");fflush(stdout);
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n Path:DML no : %s ", DMlid);fflush(stdout);
							VCDMLcommand = (char	*)MEM_alloc(500);
							tc_strcpy(VCDMLcommand,"");
							tc_strcpy(VCDMLcommand,Pathinfo5);
							tc_strcat(VCDMLcommand," ");
							tc_strcat(VCDMLcommand,DMlid);
							//tc_strcat(VCDMLcommand," ");
							printf("\n REF::VCDMLcommand: %s \n",VCDMLcommand);fflush(stdout);
							TC_write_syslog("VCDMLcommand = %s\n",VCDMLcommand);
							system(VCDMLcommand);
							printf("\n VCDRST::PATHBase:. successfully.. \n");fflush(stdout);
						}
						else if(strstr(POinfo3,"VC003")==NULL)
						{
							printf("\n VCDRST:PATHBase:command.. \n");fflush(stdout);
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n Path::DML no : %s ", DMlid);fflush(stdout);
							VCDMLcommand = (char	*)MEM_alloc(500);
							tc_strcpy(VCDMLcommand,"");
							tc_strcpy(VCDMLcommand,Pathinfo5);
							tc_strcat(VCDMLcommand," ");
							tc_strcat(VCDMLcommand,Pathinfo5);
							tc_strcat(VCDMLcommand," ");
							printf("\n REF:VCDMLcommand: %s \n",VCDMLcommand);fflush(stdout);
							TC_write_syslog("VCDMLcommand = %s\n",VCDMLcommand);
							system(VCDMLcommand);
							printf("\n VCDRST:PATHBase:. successfully.. \n");fflush(stdout);
						}
						else
						{
							printf("\n VCDRST:nothing.... \n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_VMLTReviewerForTask Function end...");fflush(stdout);
	TC_write_syslog("\n tm_VMLTReviewerForTask Function end...");
	//return error_code;
	return 0;
}