
//@<COPYRIGHT>@
//==================================================
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Business Object T5_VerticalLOVImpl

*/

#ifndef TRL001__T5_VERTICALLOVIMPL_HXX
#define TRL001__T5_VERTICALLOVIMPL_HXX

#include <T5_tm_cmlib/T5_VerticalLOVGenImpl.hxx>

#include <T5_tm_cmlib/libt5_tm_cmlib_exports.h>

#define T5_VerticalLOVPomClassName "Fnd0ListOfValuesDynamic"

namespace TRL001
{
   class T5_VerticalLOVImpl; 
   class T5_VerticalLOVDelegate;
}
 
class  T5_TM_CMLIB_API TRL001::T5_VerticalLOVImpl
           : public TRL001::T5_VerticalLOVGenImpl 
{
public:


   /**
    * Returns List Of Values based on Dynamic LOV definition and user search criteria.
    * @param operationInputTag - Operation Input containing the modified values.
    * @param propertyName - Name of the selected property.
    * @param searchString - User entered search string.
    * @param sortByProp - Property to use for sorting.
    * @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    * @param nResults - Number of returned results.
    * @param results - Returned Values for LOV.
    * @return - Zero (0) if everything is alright otherwise the error code.
    */
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    // Constructor for a T5_VerticalLOV
    explicit T5_VerticalLOVImpl( T5_VerticalLOV& busObj );

    // Destructor
    ~T5_VerticalLOVImpl();


private:
    // Default Constructor for the class
    T5_VerticalLOVImpl();
    
    // Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_VerticalLOVImpl( const T5_VerticalLOVImpl& );

    // Copy constructor
    T5_VerticalLOVImpl& operator=( const T5_VerticalLOVImpl& );

    // Method to initialize this Class
    static int initializeClass();

    //static data
    friend class TRL001::T5_VerticalLOVDelegate;

};

#include <T5_tm_cmlib/libt5_tm_cmlib_undef.h>
#endif // TRL001__T5_VERTICALLOVIMPL_HXX
