#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#define NUM_ENTRIES 1
#define TE_MAXLINELEN 128
#define _CRT_SECURE_NO_DEPRECATE
#include <Fnd0Participant/participant.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
#include "functionCallForMPP.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)

#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL                                       \
    if (ifail != 0)                                      \
    {                                                    \
        printf("line %d (ifail %d)\n", __LINE__, ifail); \
        return 0;                                        \
    }
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore 91900002


int pBOP_Task_Assignment(EPM_action_message_t msg)
{
    tag_t rootTask = NULLTAG;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    tag_t target_obj = NULLTAG;
    int noAttachment =0;
    tag_t *attachments = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    char *type_name = NULL;
    char *item_id = NULL;
    //char idplantcode =NULL;
    //char aggrigate =NULL; 
    char group[15];  
    char* tsgroupName = NULL;
    char* psdgroupName = NULL;
    char*	pBOP_Planner_role	= NULL;
    char*	pBOPpsd_Planner_role	= NULL;
    char*	pBOP_reviewer_role	= NULL;
    char*	pBOPpsd_reviewer_role	= NULL;
    tag_t	group_tag = NULLTAG;
    const char * ts ="TS";
    const char * psd ="PSD";
    const char * dash ="-";
    const char * planner ="Planner";
    const char * reviewer ="Reviewer";
    tag_t   qryTagCntrl	= NULLTAG;
    tsgroupName = (char*)MEM_alloc(100);
    psdgroupName = (char*)MEM_alloc(100);
    char    AggregateDash [15];
    char	**participants = (char **) MEM_alloc(5 * sizeof(char *));
    participants[0]="T5_mppaplplanner";
    participants[1]="T5_mppaplreviewer";
    participants[2]="T5_mpppsdplanner";
    participants[3]="T5_mpppsdreviewer";

    char* GroupName = NULL;
    GroupName	= (char	*)MEM_alloc(100);

    pBOP_Planner_role	= (char	*)MEM_alloc(100);
    pBOPpsd_Planner_role = (char	*)MEM_alloc(100);
    pBOP_reviewer_role	= (char	*)MEM_alloc(100);
    pBOPpsd_reviewer_role = (char	*)MEM_alloc(100);

   

    printf("\t pBOP_Task_Assignment Handler called.........\n");

    EPM_ask_root_task(msg.task, &rootTask);
    AOM_ask_value_string(msg.task, "object_name", &CurrentTask);
    printf("\nCurrent Task is:%s\n", CurrentTask);
    AOM_ask_value_string(rootTask, "object_name", &parent_name);
    printf("\nParent Name:%s\n", parent_name);
    EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments);
    printf("Target Attachment:%d\n", noAttachment);
    QRY_find2("Control Objects...", &qryTagCntrl);
    if (qryTagCntrl)
    {
        int n_entryCntrl =3;
        char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
        char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        qry_valuesCntrl[0]="pBOPAssignment";
        qry_valuesCntrl[1]="pBOPAssignment";
        qry_valuesCntrl[2]="0";
        int  	control_number_found		= 0;
        tag_t 	*cntr_objects				= NULLTAG;


        printf("\n Control Object Query Found \n");fflush(stdout);
        QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
        if(control_number_found>0)
        {
            char *UserInfo1 = NULL;
            char *UserInfo2 = NULL;
            char *UserInfo3 = NULL;
            char *UserInfo4 = NULL;
            char *UserInfo5 = NULL;
            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&UserInfo1);
            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&UserInfo2);
            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo3",&UserInfo3);
            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo4",&UserInfo4);
            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo5",&UserInfo5);

            printf("\n UserInfo1 is:- %s\n", UserInfo1);
            printf("\n UserInfo2 is:- %s\n", UserInfo2);
            printf("\n UserInfo3 is:- %s\n", UserInfo3);
            printf("\n UserInfo4 is:- %s\n", UserInfo4);
            printf("\n UserInfo5 is:- %s\n", UserInfo5);

            if (noAttachment > 0)
            {
                target_obj  = attachments[0];
                char idplantcode[5];  
                char aggrigate[4]; 

                TCTYPE_ask_object_type(target_obj, &objTypeTag);
                TCTYPE_ask_name2(objTypeTag, &type_name);
                printf("\nType_name is:- %s\n", type_name);
                if((strcmp(type_name,"MEProductBOPRevision")==0) || (strcmp(type_name,"Mfg0MEProcLineRevision")==0) || (strcmp(type_name,"Mfg0MEProcStatnRevision")==0))
                {
                    
                    printf("\n Inside MEProductBOPRevision  \n");fflush(stdout);

                    AOM_ask_value_string(target_obj, "item_id", &item_id);
                    printf("\n Item Id of pBOP is:- %s  \n",item_id);fflush(stdout);

                    strcpy(idplantcode, "");
                    strncat(idplantcode, item_id, 4);
                    idplantcode[4] = '\0';   //1001

                    strcpy(aggrigate, "");
                    strncat(aggrigate, item_id + 4, 3);
                    aggrigate[3] = '\0';
                    printf("idplantcode is:-  %s\n", idplantcode); //CHA AXL
                    printf("Aggrigate is:-  %s\n", aggrigate); //CHA AXL

                    if(strcmp(type_name,"MEProductBOPRevision")==0)
                    {
                        printf("\n Target object is Product BOP Revision\n");fflush(stdout);
                        PlannerReviewer(idplantcode, aggrigate, UserInfo1, pBOP_Planner_role, pBOP_reviewer_role, pBOPpsd_Planner_role, pBOPpsd_reviewer_role,GroupName);
                        printf("\n GroupName : [%s] \n",GroupName);fflush(stdout);
                        printf("\n APLPlanner : [%s] \n",pBOP_Planner_role);fflush(stdout);
                        printf("\n APLReviewer : [%s] \n",pBOP_reviewer_role);fflush(stdout);
                        printf("\n PSDPlanner : [%s] \n",pBOPpsd_Planner_role);fflush(stdout);
                        printf("\n PSDReviewer : [%s] \n",pBOPpsd_reviewer_role);fflush(stdout);

                        int a=0;
                        for(a=0;a<4;a++)
                        {
                            printf("\n inside for loop ");
                            removeparticipant(target_obj,participants[a]);
                        }
                        printf("\n for loop completed");

                        AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOP_Planner_role,pBOP_reviewer_role);
                    
                        AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOPpsd_Planner_role,pBOPpsd_reviewer_role);

                    } 
                    else if((strcmp(type_name,"Mfg0MEProcLineRevision")==0) || (strcmp(type_name,"Mfg0MEProcStatnRevision")==0))
                    {
                        printf("\n Target object is Process Line Revision or process Station Revision...\n");fflush(stdout);
                        PlannerReviewer(idplantcode, aggrigate, UserInfo3, pBOP_Planner_role, pBOP_reviewer_role, pBOPpsd_Planner_role, pBOPpsd_reviewer_role,GroupName);
                        printf("\n GroupName : [%s] \n",GroupName);fflush(stdout);
                        printf("\n APLPlanner : [%s] \n",pBOP_Planner_role);fflush(stdout);
                        printf("\n APLReviewer : [%s] \n",pBOP_reviewer_role);fflush(stdout);
                        printf("\n PSDPlanner : [%s] \n",pBOPpsd_Planner_role);fflush(stdout);
                        printf("\n PSDReviewer : [%s] \n",pBOPpsd_reviewer_role);fflush(stdout);

                        int a=0;
                        for(a=0;a<4;a++)
                        {
                            printf("\n inside for loop ");
                            removeparticipant(target_obj,participants[a]);
                        }
                        printf("\n for loop completed");

                        AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOP_Planner_role,pBOP_reviewer_role);

                    }
                    else
                    {
                        printf("\n Not product BOP not procline revision\n");fflush(stdout);

                    }                  
                    
                    
                }
                else if((strcmp(type_name,"MEProcessRevision")==0))
                {
                    printf("\n Target object is Process  Revision...\n");fflush(stdout);
                    printf("\n Process Revision  \n");fflush(stdout);

                    AOM_ask_value_string(target_obj, "item_id", &item_id);
                    printf("\n Item Id of Process is:- %s  \n",item_id);fflush(stdout);

                   char *idplantcode =NULL;
                    char aggrigate [4] = {0};

                    char first[2] = {0};      // 1 char + null terminator
                    //char second[4] = {0};     // 3 chars + null terminator

                    size_t len = strlen(item_id);
                    if (len >= 4) {
                        first[0] = item_id[0];          // First character
                        first[1] = '\0';

                        memcpy(aggrigate, item_id + 1, 3); // Next 3 characters
                        aggrigate[3] = '\0';
                        printf("First string: %s\n", first);
                        printf("Second string: %s\n", aggrigate);

                        if(tc_strcmp(first,"P")==0)
                        {
                            idplantcode = "1001";
                        }
                        else if(tc_strcmp(first,"J")==0)
                        {
                            idplantcode = "2001";

                        }
                        else if (tc_strcmp(first,"U")==0)
                        {
                            idplantcode = "3100";

                        }
                        else if(tc_strcmp(first,"D")==0)
                        {
                            idplantcode = "3001";

                        }
                        else if(tc_strcmp(first,"L")==0)
                        {
                            idplantcode = "1500";

                        }
                        printf("Group name string: %s\n", idplantcode);
                        printf("aggrigate string: %s\n", aggrigate);
                    } 
                    else 
                    {
                        printf("Input string too short.\n");
                    }

                    PlannerReviewer(idplantcode, aggrigate, UserInfo1, pBOP_Planner_role, pBOP_reviewer_role, pBOPpsd_Planner_role, pBOPpsd_reviewer_role,GroupName);

                    printf("\nAfter Function call................");
                    printf("\n GroupName : [%s] \n",GroupName);fflush(stdout);
                    printf("\n APLPlanner : [%s] \n",pBOP_Planner_role);fflush(stdout);
                    printf("\n APLReviewer : [%s] \n",pBOP_reviewer_role);fflush(stdout);
                    printf("\n PSDPlanner : [%s] \n",pBOPpsd_Planner_role);fflush(stdout);
                    printf("\n PSDReviewer : [%s] \n",pBOPpsd_reviewer_role);fflush(stdout);
                    int iterator=0;
                    for(iterator=0;iterator<4;iterator++)
                    {
                        printf("\n inside for loop ");
                        removeparticipant(target_obj,participants[iterator]);
                    }
                    printf("\n for loop completed");
                    AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOP_Planner_role,pBOP_reviewer_role);
                
                    AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOPpsd_Planner_role,pBOPpsd_reviewer_role);
                }
                else if ((strcmp(type_name,"MEOPRevision")==0))
                {
                    printf("\n Inside Operation Revision.......  \n");fflush(stdout);
                    AOM_ask_value_string(target_obj, "item_id", &item_id);
                    printf("\n Item Id of Operation is:- %s  \n",item_id);fflush(stdout);

                    
                    char *idplantcode =NULL;
                    char aggrigate [4] = {0};
                    char first[2] = {0};   
                    size_t len = strlen(item_id);
                    if (len >= 4) {
                        first[0] = item_id[0];          
                        first[1] = '\0';

                        memcpy(aggrigate, item_id + 1, 3); 
                        aggrigate[3] = '\0';
                        printf("First string: %s\n", first);
                        printf("Second string: %s\n", aggrigate);

                        if(tc_strcmp(first,"P")==0)
                        {
                            idplantcode = "1001";
                        }
                        else if(tc_strcmp(first,"J")==0)
                        {
                            idplantcode = "2001";

                        }
                        else if (tc_strcmp(first,"U")==0)
                        {
                            idplantcode = "3100";

                        }
                        else if(tc_strcmp(first,"D")==0)
                        {
                            idplantcode = "3001";

                        }
                        else if(tc_strcmp(first,"L")==0)
                        {
                            idplantcode = "1500";

                        }
                        printf("Group name string: %s\n", idplantcode);
                        printf("aggrigate string: %s\n", aggrigate);
                    } 
                    else 
                    {
                        printf("Input string too short.\n");
                    }

                    PlannerReviewer(idplantcode, aggrigate, UserInfo1, pBOP_Planner_role, pBOP_reviewer_role, pBOPpsd_Planner_role, pBOPpsd_reviewer_role,GroupName);

                    printf("\nAfter Function call................");
                    printf("\n GroupName : [%s] \n",GroupName);fflush(stdout);
                    printf("\n APLPlanner : [%s] \n",pBOP_Planner_role);fflush(stdout);
                    printf("\n APLReviewer : [%s] \n",pBOP_reviewer_role);fflush(stdout);
                    printf("\n PSDPlanner : [%s] \n",pBOPpsd_Planner_role);fflush(stdout);
                    printf("\n PSDReviewer : [%s] \n",pBOPpsd_reviewer_role);fflush(stdout);
                    int iterator=0;
                    for(iterator=0;iterator<4;iterator++)
                    {
                        printf("\n inside for loop ");
                        removeparticipant(target_obj,participants[iterator]);
                    }
                    printf("\n for loop completed");
                    
                    AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOP_Planner_role,pBOP_reviewer_role);
                
                    AssignaplPlannerandreviewer(target_obj,aggrigate,GroupName,pBOPpsd_Planner_role,pBOPpsd_reviewer_role);
                }
                else
                {
                    printf("\n Selected Object is not related to pBOP Workflow pocess.............!");

                }     

            }

        }
    }

    return 0;
}
int plBOPStamping(EPM_action_message_t msg )
{
    tag_t rootTask = NULLTAG;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    int noAttachment = 0;
    logical retain = 0;
    tag_t *attachments = NULLTAG;
    printf("\n Inside plBOPStamping  ...");
	EPM_ask_root_task(msg.task,&rootTask);
	AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\nCurrentTask:%s\n",CurrentTask);
	AOM_ask_value_string(rootTask,"object_name",&parent_name);
	printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments);
	printf("Target Attachment:%d\n",noAttachment);fflush(stdout);
	if(noAttachment > 0)
	{
        for(int AttachIterator = 0;AttachIterator<noAttachment;AttachIterator++)
        {
            char *AttachementItemId = NULL;
            char *AttachementrevId = NULL;
            char *AttachementObjectType = NULL;
            AOM_ask_value_string(attachments[AttachIterator],"object_type",&AttachementObjectType);
            if(tc_strcmp(AttachementObjectType,"Mfg0MEProcStatnRevision")==0 || tc_strcmp(AttachementObjectType,"Mfg0MEProcLineRevision")==0)
            {                
                AOM_ask_value_string(attachments[AttachIterator],"item_id",&AttachementItemId);
                printf("AttachementItemId : %s\n",AttachementItemId);fflush(stdout);

                AOM_ask_value_string(attachments[AttachIterator],"item_revision_id",&AttachementrevId);
                printf("AttachementrevId : %s\n",AttachementrevId);fflush(stdout);

                char plantCode[5];

                strcpy(plantCode, "");
                strncat(plantCode, AttachementItemId, 4);
                plantCode[4] = '\0'; 
                //strncpy(plantCode, AttachementItemId, 4);
                tag_t qryTagCntrl = NULLTAG;
                printf("\nplantCode",plantCode);fflush(stdout);
                QRY_find2("Control Objects...", &qryTagCntrl);
                if (qryTagCntrl)
                {
                    int n_entryCntrl =3;
                    char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
                    char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
                    qry_valuesCntrl[0]="plBOPAssignment";
                    qry_valuesCntrl[1]="plBOPAssignment";
                    qry_valuesCntrl[2]="0";
                    int  	control_number_found		= 0;
                    tag_t 	*cntr_objects				= NULLTAG;

                    printf("\n Control Object Query Found \n");fflush(stdout);
                    QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
                    if(control_number_found>0)
                    {
                        char *UserInfo1 = NULL;
                        
                        AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&UserInfo1); 
                        printf("UserInfo1 : %s\n",UserInfo1);fflush(stdout);

                        char command[515];
                        sprintf(command,"%s \"%s\" %s %s",UserInfo1,CurrentTask,AttachementItemId,AttachementrevId);
                        printf("\n command:- %s",command);fflush(stdout);
                        system(command);
                    }
                }
                else 
                {
                    printf("\ncontrol object not found");fflush(stdout);

                }
            }
        }
    }
    return 0;
}



int preconditionformpp(METHOD_message_t *msg, va_list args)
{
    printf("\n inside precondition..........");


    tag_t processtag= NULLTAG;
    tag_t objTypeTag =NULLTAG;
    tag_t revtag =NULLTAG;
    char *type_name=NULL;
    char *objecttype = NULL;
    char *objecttype1 = NULL;
    char *aggrigate = NULL;
    char *plantcode = NULL;
    char *linenot = NULL;
    EPM_decision_t decision;
    tag_t qryTagCntrl1 = NULLTAG;
    int n_entryCntrl1 = 3;
    char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
    int control_number_found1 = 0;

    va_list largs;    
	va_copy( largs, args ); 
    tag_t TaskTagrev = va_arg(args, tag_t);
    tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;


    QRY_find2("Control Objects...", &qryTagCntrl1);
    if (qryTagCntrl1)
    {
        qry_valuesCntrl1[0] = "MPPmandatoryattributes";
        qry_valuesCntrl1[1] = "MPPmandatoryattributes";
        qry_valuesCntrl1[2] = "0";
        QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1);
        if(control_number_found1>0)
        {
            AOM_ask_value_string(TaskTagrev, "object_type", &objecttype);
            printf("\n object type for current:- %s", objecttype);

            TCTYPE_ask_object_type(TaskTagrev, &objTypeTag);
            TCTYPE_ask_name2(objTypeTag, &type_name);
            printf("\n  MPP Type name is :-  %s\n", type_name);
            if((tc_strcmp(type_name,"MEProcessRevision")==0)||(tc_strcmp(type_name,"Mfg0MEProcAreaRevision")==0))
            {
                AOM_ask_value_string(TaskTagrev, "t5_PR_aggregate", &aggrigate);
                printf("\n object type for current:- %s", aggrigate);

                AOM_ask_value_string(TaskTagrev, "t5_PR_plantcode", &plantcode);
                printf("\n object type for current:- %s", plantcode);

                AOM_ask_value_string(TaskTagrev, "t5_PR_lineNo", &linenot);
                printf("\n object type for current:- %s", linenot);

                if((tc_strcmp(aggrigate,"")==0)||(tc_strcmp(plantcode,"")==0)||(tc_strcmp(linenot,"")==0))
                {
                    EMH_clear_errors();
                    EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Fill Mandatory attributes 'line No', 'Aggregate' & 'Plant code'.");
                    decision =EPM_nogo;
                    return ITK_errStore;

                }
                else
                {
                    printf("\n Mandatory attributes are filled so allowed to create Item.....");

                }

            }
            else if((tc_strcmp(type_name,"Mfg0MEProcStatnRevision")==0))
            {
                char *StationType = NULL;

                AOM_ask_value_string(TaskTagrev, "t5_PR_aggregate", &aggrigate);
                printf("\n object type for current:- %s", aggrigate);

                AOM_ask_value_string(TaskTagrev, "t5_PR_plantcode", &plantcode);
                printf("\n object type for current:- %s", plantcode);

                AOM_ask_value_string(TaskTagrev, "t5_PR_lineNo", &linenot);
                printf("\n object type for current:- %s", linenot);

                AOM_ask_value_string(TaskTagrev, "t5_station_type", &StationType);
                printf("\n object type for current:- %s", StationType);

                if((tc_strcmp(aggrigate,"")==0)||(tc_strcmp(plantcode,"")==0)||(tc_strcmp(linenot,"")==0||(tc_strcmp(StationType,"")==0)))
                {
                    EMH_clear_errors();
                    EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Fill Mandatory attributes 'line No', 'Aggregate', 'Plant code' & 'station_type'.");
                    decision =EPM_nogo;
                    return ITK_errStore;

                }
                else
                {
                    printf("\n Mandatory attributes are filled so allowed to create Item.....");

                }

            }
            else if((tc_strcmp(type_name,"MEOPRevision")==0))
            {
                char *aggrigateOP = NULL;
                char *plantcodeop = NULL;
                char *linenop = NULL;
                AOM_ask_value_string(TaskTagrev, "t5_OP_aggregate", &aggrigateOP);
                printf("\n object type for current:- %s", aggrigateOP);

                AOM_ask_value_string(TaskTagrev, "t5_OP_plantcode", &plantcodeop);
                printf("\n object type for current:- %s", plantcode);

                AOM_ask_value_string(TaskTagrev, "t5_OP_lineNo", &linenop);
                printf("\n object type for current:- %s", linenop);

                if((tc_strcmp(aggrigateOP,"")==0)||(tc_strcmp(plantcodeop,"")==0)||(tc_strcmp(linenop,"")==0))
                {
                    EMH_clear_errors();
                    EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Fill Mandatory attributes 'line No', 'Aggregate' & 'Plant code'.");
                    decision =EPM_nogo;
                    return ITK_errStore;

                }
                else
                {
                    printf("\n Mandatory attributes are filled so allowed to create Item.....");

                }

            }

            else if((tc_strcmp(type_name,"Mfg0MEProcLineRevision")==0))
            {
                AOM_ask_value_string(TaskTagrev, "t5_PR_aggregate", &aggrigate);
                printf("\n object type for current:- %s", aggrigate);

                AOM_ask_value_string(TaskTagrev, "t5_PR_plantcode", &plantcode);
                printf("\n object type for current:- %s", plantcode);
                if((tc_strcmp(aggrigate,"")==0)||(tc_strcmp(plantcode,"")==0))
                {
                    EMH_clear_errors();
                    EMH_store_error_s1(EMH_severity_error, ITK_errStore1, "Fill Mandatory attributes 'Aggregate' & 'Plant code'.");
                    decision =EPM_nogo;
                    return ITK_errStore;

                }
                else
                {
                    printf("\n Mandatory attributes are filled so allowed to create Item.....");

                }
                
            }
            else
            {
                printf("\n Type name not compared so by pass.....");

            }

        }
    }

    return 0;
}
extern int tm_MPPLib_register_method(int *decision, va_list args)
{
    int ifail = 0;
    METHOD_id_t methodidProcess;
    METHOD_id_t methodidOperation;
    METHOD_id_t methodidStation;
    METHOD_id_t methodidline;

    // for work area

    METHOD_id_t methodidWork;

    //

    printf("\n Welcome to MPP Customization................");

    printf("\n Before Register Action handler pBOP_Task_Assignment...............");
    EPM_register_action_handler("pBOP_Task_Assignment", "", pBOP_Task_Assignment);
    printf("\n After register Action handler pBOP_Task_Assignment...............");
 
    if (ITK_ok == EPM_register_action_handler("plBOPStamping", "", plBOPStamping))
    {
        printf("\t\n Registered Action Handler plBOPStamping\n");
        fflush(stdout);
    }
    else
    {
        printf("\t FAILED to register Action Handler plBOPStamping\n");
        fflush(stdout);
    }
    

    //pre-condition for mandatory plant code and aggrigate.
    printf("\n befor regestred method");
    METHOD_find_method("MEProcessRevision", TC_save_msg, &methodidProcess);
    if (methodidProcess.id != NULL)
    {
        METHOD_add_action(methodidProcess, METHOD_pre_action_type, (METHOD_function_t)preconditionformpp, NULL);
    }
    else
    {
        printf("\n Method not found..................");
    }

    METHOD_find_method("MEOPRevision", TC_save_msg, &methodidOperation);
    if (methodidOperation.id != NULL)
    {
        METHOD_add_action(methodidOperation, METHOD_pre_action_type, (METHOD_function_t)preconditionformpp, NULL);
    }
    else
    {
        printf("\n Method not found..................");
    }
    METHOD_find_method("Mfg0MEProcStatnRevision", TC_save_msg, &methodidStation);
    if (methodidStation.id != NULL)
    {
        METHOD_add_action(methodidStation, METHOD_pre_action_type, (METHOD_function_t)preconditionformpp, NULL);
    }
    else
    {
        printf("\n Method not found..................");
    }
    METHOD_find_method("Mfg0MEProcLineRevision", TC_save_msg, &methodidline);
    if (methodidline.id != NULL)
    {
        METHOD_add_action(methodidline, METHOD_pre_action_type, (METHOD_function_t)preconditionformpp, NULL);
    }
    else
    {
        printf("\n Method not found..................");
    }

    // for work area

    METHOD_find_method("Mfg0MEProcAreaRevision", TC_save_msg, &methodidWork);
    if (methodidWork.id != NULL)
    {
        METHOD_add_action(methodidWork, METHOD_pre_action_type, (METHOD_function_t)preconditionformpp, NULL);
    }
    else
    {
        printf("\n Method not found..................");
    }

    //

    return ITK_ok;
  
}
DLLAPI int tm_MPPLib_register_callbacks()
{
    printf("\n Before registered function in MPP\n");fflush(stdout);
    CUSTOM_register_exit("tm_MPPLib", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_MPPLib_register_method);
    printf("\n registered function tm_MPPLib \n");fflush(stdout);
    
    return (ITK_ok);
}