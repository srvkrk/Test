/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_CKDReports.c
* Created By                   : 
* Created On                   : 19/04/2019
* Project                      : TML
* Description                  : On TMML custom action
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/

	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <stdarg.h>
	#include <tccore/custom.h>
	#include <ict/ict_userservice.h>
	//#include <tc/iman.h>
	//#include <tccore/imantype.h>
	//#include <sa/imanfile.h>
	#include <tc/preferences.h>
	#include <lov/lov_msg.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/tc_msg.h>
	#include <ae/dataset_msg.h>
	//#include <tc/tc.h>
	#include <tc/emh.h>
	#include <ecm/ecm.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <ae/ae.h>                  /* for dataset id and rev */
	#include <setjmp.h>
	#include <ae/ae_errors.h>           /* for dataset id and rev */
	#include <ae/ae_types.h>            /* for dataset id and rev */
	#include <unidefs.h>
	#include <user_exits/user_exit_msg.h>
	#include <pom/enq/enq.h>
	#include <ug_va_copy.h>
	//#include <itk/mem.h>
	#include <tie/tie_errors.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tc/tc_startup.h>
	#include <user_exits/user_exits.h>
	#include <tccore/method.h>
	#include <property/prop.h>
	#include <property/prop_msg.h>
	#include <property/prop_errors.h>
	#include <tccore/item.h>
	#include <lov/lov.h>
	#include <sa/sa.h>
	#include <sa/site.h>
	#include <res/res_itk.h>
	#include <res/reservation.h>
	#include <tccore/workspaceobject.h>
	#include <tc/wsouif_errors.h>
	#include <tccore/aom.h>
	#include <publication/dist_user_exits.h>
	#include <form/form.h>
	#include <epm/epm.h>
	#include <epm/epm_task_template_itk.h>
	#include <constants/constants.h>
	//#include <tc/emh_const.h>
	#include <sa/groupmember.h>
	#include <tc/tc_arguments.h>
	
	
#define ITK_err 919006
#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define MAX_LINE_LEN 1024
#define GRM_create_msg "GRM_create"   1
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

				
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}



	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	                   \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
	
		typedef struct delta_bom
	{
		int count;
		char **uidlist;
		int *status;
		
		
	}Delta_Bom;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int report_error(char *file, int line, char *call, int status,
	logical exit_on_error)
{
	if (status != ITK_ok)
	{
	/*int
		n_errors = 0,
		*severities = NULL,
		*statuses = NULL;
		*/
		int n_errors = 0;
		const int 
			*severities=NULL,
			*statuses=NULL;
	const char
		**messages;
		


	EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
	if (n_errors > 0)
	{
		ECHO("\n%s\n", messages[n_errors-1]);
		EMH_clear_errors();
	}
	else
	{
		char *error_message_string;
		//EMH_ask_error_text(NULLTAG, status, &error_message_string);
		ECHO("\n%s\n", error_message_string);
	}

	ECHO("error %d at line %d in %s\n", status, line, file);
	ECHO("%s\n", call);

	if (exit_on_error)
	{
		ECHO("Exiting program!\n");
		exit (status);
	}
	}

	return status;
}


static int bom_sorting (tag_t line_1, tag_t line_2, void * client_data)
{
	/* returns strcmp style -1/0/+1 according to whether line_1 and line_2 sort <, = or > */
	char *partno1, *partno2;
	int ifail = ITK_ok;
	int result;
	(void)client_data;
	ifail= AOM_ask_value_string (line_1, "bl_occ_t5_ShpVal", &partno1);
	//printf("\n partnumber 1 = %s\n",partno1);fflush(stdout);
	
	ifail= AOM_ask_value_string (line_2, "bl_occ_t5_ShpVal", &partno2);
	//printf("\n partnumber 2 = %s\n",partno2);fflush(stdout);
	
	if (partno1 == NULL || partno2 == NULL)
	  result = 0;  															  				    									   		
	else
		result = tc_strcmp (partno1, partno2);
	  //result = tc_strcmp (partno2, partno1); //for descending order of item_id
  
	MEM_free (partno1);
	MEM_free (partno2);
	return result;			   
}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;


	
	void getIndex(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=-1;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=k;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}

void getStrByIndex(char **view_list,int count,int idx,char **str)
{

		printf("\n **getStrByIndex");fflush(stdout);
		
		*str =view_list[idx];
	 
		


}
	
	void setAddStrInCKDReport(int *count,char ***strset,char* str)
	{

	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
	printf("\n setAddStr2");fflush(stdout);
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
	printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
	printf("\n setAddStr4");fflush(stdout);
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrInCKDReport character found===%s",(*strset)[*count-1]);fflush(stdout);



	}



	
	
	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
	{

	*count=*count+1;
	if(*count==1)
	{
	printf("\n ****setAddTAG1");fflush(stdout);
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG2");fflush(stdout);
	}
	else
	{
	printf("\n **setAddTAG3");fflush(stdout);
	(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	printf("\n ***setAddTAG4");fflush(stdout);
	printf("\n **serTAG6");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




	}
	
void setAddInt(int *count,int **objlist,int obj )
        {

        *count=*count+1;
        if(*count==1)
        {
        printf("\n ****setAddTAG1");fflush(stdout);
        (*objlist) = (int *)malloc((*count ) * sizeof(int ));
        printf("\n ***setAddTAG2");fflush(stdout);
        }
        else
        {
        printf("\n **setAddTAG3");fflush(stdout);
        (*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
        printf("\n ***setAddTAG4");fflush(stdout);
        printf("\n **serTAG6");fflush(stdout);
        }

        (*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));




        }

void setFindStr(char **view_list,int count,char *str,int *found)
{

		printf("\n **setFindStr");fflush(stdout);
		int k=0;
		*found=0;
			for(k=0;k<count;k++)
			{

			printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
				if(tc_strcmp(view_list[k],str)==0)
				{


				*found=1;
				break;

				}

			}
		printf("\n **setFindStr found= %d",*found);fflush(stdout);


}



static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

void FU_dumpItkErrors
(
 int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
 const char * prog_name,             /* <I> Name of the Module  */
 int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
 const char * fileName               /* <I> Name of the File */
 );
#define ITK(x)                                                             \
{                                                                          \
    if ( ifail == ITK_ok )                                                 \
    {                                                                      \
        if ( (ifail = (x)) != ITK_ok )                                     \
        {                                                                  \
            FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
        }                                                                  \
    }                                                                      \
}
/****************************************************************************/
/* Function Name    : FU_dumpItkErrors                                      */
/*                                                                          */
/* Called From      : ITK                                                   */
/*                                                                          */
/* Input Parms      : int stat                                              */
/*                    const char * prog_name                                */
/*                    int line_number                                       */
/*                    const char * file_name                                */
/*                                                                          */
/* Output Parms     : None                                                  */
/*                                                                          */
/* Functions called : None                                                  */
/*                                                                          */
/* File Description : Called by the ITK macro to log errors                 */
/*                                                                          */
/* Return Value     : Void                                                  */

/**********************************************************************/



/*Sneha -------------------CKD REPORT *****/

	int PlantDisplayValue(char* plantNameValue,char** displayName)
	{
	  int ifail = ITK_ok;
	 
		printf("INSIDE TRANSLATED PLANT VALUES");fflush(stdout);	 
	   if(tc_strcmp(plantNameValue,"PlantName8")==0)
		{
			tc_strdup("CVBU JSR",displayName);	
		}
		else if(tc_strcmp(plantNameValue,"PlantName1")==0)
		{
			tc_strdup("CAR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName9")==0)
		{
			tc_strdup("CVBU LKO",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName2")==0)
		{
			tc_strdup("CVBU PNR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName3")==0)
		{
			tc_strdup("CVBU PUNE",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName4")==0)
		{
			tc_strdup("PCBU",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName5")==0)
		{
			tc_strdup("PCBU and CVBU",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName10")==0)
		{
			tc_strdup("PCBU LKO",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName6")==0)
		{
			tc_strdup("SMALLCAR AHD",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName7")==0)
		{
			tc_strdup("SMALLCAR PNR",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName11")==0)
		{
			tc_strdup("DHARWAD",displayName);
		}
		else if(tc_strcmp(plantNameValue,"PlantName12")==0)
		{
			tc_strdup("TMLDL JSR",displayName);
		}
		
		
		return ifail;
	}
	


 int getQueryItemRevision_AllType( const char *val,char *type,tag_t** items,int *n_found)
{
           int ifail = ITK_ok;
		   
		   printf("\n Inside getQueryItemRevision_AllType......");fflush(stdout);

           printf("\n\n RowsVal object==%s",val);fflush(stdout);
           printf("\n RowsVal type==%s \n",type);fflush(stdout);
		  
           tag_t        query           = NULLTAG;
          
           char
                   *qry_entries3[] = {"Item ID","Type"},
                   *qry_values3[]  = {(char *)val,type};

        

                     
            QRY_find2("Item Revision...", &query);

               
      

            QRY_execute(query,2, qry_entries3, qry_values3, n_found, items);

            printf("\n\n getQueryItemRevision_AllType Rows555==%s \n",val);fflush(stdout);



                 return ifail;


} 



int AddValueinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* attrValue)
{
	int				ifail 						= ITK_ok;
	
	char *delimiterValue=NULL;
	
	
	delimiterValue=MEM_alloc(1000);
	
	tc_strcpy(delimiterValue,"");
	tc_strcat(delimiterValue,",");
	tc_strcat(delimiterValue,attrValue);
		
	// sprintf(delimiterValue,",%s",attrValue);
	setAddStrInCKDReport(buff_cnt,bufferedXmlStrOut,delimiterValue);
	
	if(delimiterValue!=NULL) MEM_free(delimiterValue); 

return ifail;
	
}



int newlineValueinBuffer(char*** bufferedXmlStrOut, int *buff_cnt,char* attrValue)
{
	int				ifail 						= ITK_ok;
	
	
	char *newlineValue=NULL;
	
	
	newlineValue=MEM_alloc(1000);
	
	tc_strcpy(newlineValue,"");
	tc_strcat(newlineValue,"\n");
	tc_strcat(newlineValue,attrValue);
	
	// sprintf(newlineValue,",%s\n",attrValue);
	setAddStrInCKDReport(buff_cnt,bufferedXmlStrOut,newlineValue);
	
	if(newlineValue!=NULL) MEM_free(newlineValue); 

return ifail;
	
}
	
	 int ReleaseStatusObject(tag_t item_tag_rev, char *ReleaseStat)
		{
		 int ifail = ITK_ok;
		int ii             = 0;
		int	status_count   = 0;
		int status;	
		tag_t* status_list = NULLTAG;
        char *relStatus=NULL;
		char *lifecyclestat=NULL;
		lifecyclestat = (char *) MEM_alloc( 100 * sizeof(char) );  
		  
		status=WSOM_ask_release_status_list(item_tag_rev,&status_count,&status_list);
		printf("\n number of statuses for object: %d \n",  status_count);
		
		if (status_count>0)
		{
				if(status==ITK_ok)
				 {
					
					for (ii = 0; ii < status_count; ii++)
					{
						ITK_CALL (AOM_ask_name(status_list[ii], &relStatus));
						printf("\t ReleaseStat: %s\n", relStatus);fflush(stdout);
					}
				 }
				 
		 if (tc_strcmp(	relStatus,"T5_LcsAplRlzd")==0)
			{
			tc_strcpy(lifecyclestat,"APL RELEASED");
			}
			
		else if (tc_strcmp(	relStatus,"T5_LcsStdRlzd")==0)
			{
			tc_strcpy(lifecyclestat,"STDSI RELEASED");
			}
		else if (tc_strcmp(	relStatus,"T5_LcsErcRlzd")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC RELEASED");
			}
		else if (tc_strcmp(	relStatus,"T5_LcsReview")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC REVIEW");
			}
			
			else if (tc_strcmp(	relStatus,"T5_LcsWorking")==0) 
			{
			tc_strcpy(lifecyclestat,"ERC WORKING");
			}
			else
			{
			tc_strcpy(lifecyclestat,relStatus);
			}
			printf("\t Lifecycle stat: %s\n", lifecyclestat);fflush(stdout);
			
		tc_strcpy(ReleaseStat,lifecyclestat);
		}
		
		MEM_free(lifecyclestat);
		
		return ifail;
		}	
			

int lovDisplayedName(char* lovType,char* lovValue,char** displayName)
{
		int				ifail 						= ITK_ok;

		int nlov=0;
		int nlovdesc=0;
		int numlov=0;
		tag_t* tagLov=NULLTAG;
		tag_t Lov=NULLTAG;
		LOV_usage_t   lov_usage;
		LOV_usage_t   lov_usage1;
		char **LovDisplay=NULL;
		char **getLovVal=NULL;
		char **desc_strings=NULL;
		
		 logical*      is_null;         
		 logical*      is_empty; 

		printf("\n  parameters are : %s   %s \n",lovType,lovValue); fflush(stdout);
		
		if (lovValue!=NULL && tc_strlen(lovValue)>0)
		{
			CALLAPI(LOV_find(lovType,&numlov,&tagLov ));
			printf("\n  No of TC LOV are : %d \n",numlov); fflush(stdout);
			
			if (numlov>0)
			{
		
				CALLAPI(LOV_ask_values_display_string(tagLov[0],&lov_usage,&nlov,&LovDisplay,&getLovVal )) ;
				CALLAPI(LOV_ask_value_descriptions(tagLov[0],&lov_usage1,&nlovdesc,&desc_strings,&is_null,&is_empty));
				
				printf("\n  No of TC LOV are : %d \n",nlov); fflush(stdout);
				printf("\n  No of TC LOV are : %d \n",nlovdesc); fflush(stdout);
				int x=0;
				for(x=0;x<nlov;x++)
				{
					printf("\n  In Loopp lovValue : [%s]:%s->%s-->%s \n",lovValue,getLovVal[x],LovDisplay[x],desc_strings[x]); fflush(stdout);
					if(tc_strcmp(lovValue,getLovVal[x])==0) 
					 {
						break;
					 }
				 
				}
				
				printf("\n  lovValue Matched: [%s]:%s->%s->%s \n",lovValue,getLovVal[x],LovDisplay[x],desc_strings[x]); fflush(stdout);
				
				tc_strdup(LovDisplay[x],displayName);
							
			}
		}

return ifail;
}

/*Pratik *************/
int GenerateCALLUPReport(char* ckdDmlNo, char* dmlrev, char*** bufferedStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	int a,n_tags_found,i, n_tags_found1;
	char* s;
	tag_t query, *tags_found, query1, *tags_found1;
	
	char *name[2]={"DML NO","Revision No"};
	char *val[2]={ckdDmlNo,dmlrev};
	
	char *name1[1]={"DML No"};
	char *val1[1]={ckdDmlNo};
	
	char shpdesc[100][100];
	char shpdesc1[100][100];
	

	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n\n======================================================================================");
	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n,,COMPLETE KNOCKDOWN SYSTEM");
	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n=======================================================================================\n");
	
	
	ifail=QRY_find2("CKDDML", &query);
	
	
	ifail=QRY_execute(query, 2, name, val, &n_tags_found, &tags_found);
	
	printf("\n n_tags_found =%d",n_tags_found);fflush(stdout);
	
	ifail=QRY_find2("LOTNUMBER", &query1);
	
	ifail=QRY_execute(query1, 1, name1, val1, &n_tags_found1, &tags_found1);
	
	printf("\n n_tags_found1 =%d",n_tags_found1);fflush(stdout);
	
	for(a=0;a<n_tags_found1;a++)
	{
		char* lotobj = NULL;
		char* lotqty = NULL;
		char* lotcntry = NULL;
		char *lotstr = NULL;
		char *boxstr = NULL;
		char *lotqtyStr = NULL;
		char *cntryStr = NULL;
		
		lotstr = MEM_alloc(50*sizeof(*lotstr));
		boxstr = MEM_alloc(50*sizeof(*boxstr));
		lotqtyStr = MEM_alloc(50*sizeof(*lotqtyStr));
		cntryStr = MEM_alloc(50*sizeof(*cntryStr));
		
		ifail= AOM_ask_value_string(tags_found1[a],"item_id",&lotobj);
		
		ifail= AOM_ask_value_string(tags_found1[a],"t5_RepQty",&lotqty);
		
		ifail= AOM_ask_value_string(tags_found1[a],"t5_PlcCode",&lotcntry);
		
		
		sprintf(lotstr,"\n,PACKING SLIP FOR LOT: %s", lotobj);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,lotstr);
		
		sprintf(boxstr,"\n,BOX Number: %s", lotobj);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,boxstr);
		
		sprintf(lotqtyStr,"\n,LOT QUANTITY: %s", lotqty);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,lotqtyStr);
		
		sprintf(cntryStr,"\n,Contry Code: %s", lotcntry);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,cntryStr);
		
	}
	
	
	for(i=0;i<n_tags_found;i++)
	{
		
		tag_t relatnType_tag, *brkDwnObj, querylot, *lot_found, query1, ckdDmlPar;
		int relCount, j, m, n_lots_found, desCount;
		char* ckdDml = NULL;
		char* name1 = NULL;
		char* spcfNo = NULL;
		char* specStr = NULL;
		char** desgnGrp = NULL;
		
		specStr = MEM_alloc(50*sizeof(*specStr));
		
				
		ifail= ITEM_ask_item_of_rev(tags_found[i],&ckdDmlPar);
		
		
		ifail= AOM_ask_value_string(ckdDmlPar,"t5_ErcEsNo",&spcfNo);
		
		printf("\n spcfNo: %s",spcfNo);
		
		ifail= AOM_ask_value_strings(tags_found[i],"t5_crdesigngroup",&desCount,&desgnGrp);
		
		printf("\n desgnGrp: %s",desgnGrp[0]);
		
																					 
		
		
		sprintf(specStr,"\n,SPECIFICATION NO.: %s", spcfNo);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,specStr);
					
		ifail= AOM_ask_value_string(tags_found[i],"item_id",&ckdDml);
		
		printf("\n ckdDml: %s",ckdDml);
						
		ifail= GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag);
		
		
		ifail= GRM_list_secondary_objects_only(tags_found[i],relatnType_tag,&relCount,&brkDwnObj);
		
		printf("\n brkDwnObj: %d",relCount);
		
		for(j=0;j<relCount;j++)
		{
			char *breakDownInto = NULL;
			tag_t solution_rel, *solObj;
			int relCount1, k;
			
			ifail= AOM_ask_value_string(brkDwnObj[j],"object_string",&breakDownInto);
			
		
			printf("\n breakDownInto =%s",breakDownInto);fflush(stdout);
			
			ifail= GRM_find_relation_type("CMHasSolutionItem",&solution_rel);
			
			ifail= GRM_list_secondary_objects_only(brkDwnObj[j],solution_rel,&relCount1,&solObj);
			
			printf("\n solObj: %d",relCount1);
			
			for(k=0;k<relCount1;k++)
			{
				char* soluName = NULL;
				char* partType = NULL;
				char* soluName1 = NULL;
				//char* desgnGrp = NULL;
				char* dsgnGrpStr = NULL;
				char* soluNameStr = NULL;
				
				dsgnGrpStr = MEM_alloc(50*sizeof(dsgnGrpStr));
				soluNameStr = MEM_alloc(50*sizeof(soluNameStr));
				
				tag_t window, solObjMain, bomline, *bomChild;
				int bomCount, l;
				
				
				ifail= AOM_ask_value_string(solObj[k],"t5_PartType",&partType);
				
				
				
				if(tc_strcmp(partType,"CKDVC")==0)
				{
					ifail= AOM_ask_value_string(solObj[k],"object_name",&soluName);
					
					
					
					
					
					//ifail= AOM_ask_value_string(solObj[k],"t5_DesignGrp",&desgnGrp[0]);
					
					printf("\n soluName =%s",soluName);fflush(stdout);
					printf("\n partType =%s",partType);fflush(stdout);
				
					sprintf(dsgnGrpStr,"\n\nGROUP DESCRIPTION: %s", desgnGrp[0]); 
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,dsgnGrpStr);
					
				
					sprintf(soluNameStr,"\nBase VC: %s\n", soluName);
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,soluNameStr);
					
					
					
					//setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n=====,=====,=====,=====");
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\nSr No. ,PartNo. ,Description ,Quantity");
					//setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n=====,=====,=====,=====");
		
					ifail= ITEM_ask_item_of_rev(solObj[k],&solObjMain);
					
					ifail= AOM_ask_value_string(solObjMain,"object_string",&soluName1);
					
					
					printf("\n soluName1 =%s",soluName1);fflush(stdout);
					
					ifail= BOM_create_window(&window);
					
					ifail= BOM_set_window_sort_compare_fn (window, (void *)bom_sorting, NULL);
					
					ifail= BOM_set_window_top_line(window,solObjMain,solObj[k],NULLTAG,&bomline);
					
					
					ifail= BOM_line_ask_all_child_lines(bomline,&bomCount,&bomChild);
				
					printf("\n bomCount =%d",bomCount);fflush(stdout);
					
					for(l=0;l<bomCount;l++)
					{
						int objname, objDesc, objQty;
						char* childName = NULL;
						char* childDesc = NULL;
						char* childQty = NULL;
						char* datastr = NULL;
						char* shopVal = NULL;
						
						datastr = MEM_alloc(50*sizeof(datastr));
						
						//ifail= BOM_line_look_up_attribute ("bl_item_item_id",&objname);
						
						//ifail= BOM_line_look_up_attribute ("bl_item_object_desc",&objDesc);
						
						//ifail= BOM_line_look_up_attribute ("bl_quantity",&objQty); 


						
						
						//ifail= BOM_line_ask_attribute_string(bomChild[l],objname,&childName);
						
						//ifail= BOM_line_ask_attribute_string(bomChild[l],objDesc,&childDesc);
						
						//ifail= BOM_line_ask_attribute_string(bomChild[l],objQty,&childQty);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_item_id",&childName);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_object_desc",&childDesc);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_quantity",&childQty);
						
						
						
						printf("\n\t\t%d., %s, %s, %s",l+1,childName,childDesc,childQty);fflush(stdout);
						
						
						sprintf(datastr,"\n%d ,%s ,%s ,%s", l+1,childName,childDesc,childQty);
						setAddStrInCKDReport(buff_cnt,bufferedStrOut,datastr);
						
						
						
						
					}
					if(bomChild)
						MEM_free(bomChild);
				
				}
				
				
				
				
			}
			if(solObj)
			MEM_free(solObj);
			
		}
		if(brkDwnObj)
			MEM_free(brkDwnObj);
	}
	if(tags_found)
		MEM_free(tags_found);
	
	printf("\n\n");
	return 0;
	
	
}

/************************** CallTag- Pratik **************************************/
int GenerateCALLTagReport(char* ckdDmlNo, char* dmlrev, char*** bufferedStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	int a,n_tags_found,i, n_tags_found1;
	char* s;
	char* lotcntry = NULL;
	tag_t query, *tags_found, query1, *tags_found1;
	
	char *name[2]={"DML NO","Revision No"};
	char *val[2]={ckdDmlNo,dmlrev};
	
	char *name1[1]={"DML No"};
	char *val1[1]={ckdDmlNo};
	
	char shpdesc[100][100];
	char shpdesc1[100][100];
	

	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n========,========,========,========,========,========,========,========");
	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n,,,CALL TAG Report");
	setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\n========,========,========,========,========,========,========,========\n");
	
	
	ifail=QRY_find2("CKDDML", &query);
	
	
	ifail=QRY_execute(query, 2, name, val, &n_tags_found, &tags_found);
	
	printf("\n n_tags_found =%d",n_tags_found);fflush(stdout);
	
	ifail=QRY_find2("LOTNUMBER", &query1);
	
	ifail=QRY_execute(query1, 1, name1, val1, &n_tags_found1, &tags_found1);
	
	printf("\n n_tags_found1 =%d",n_tags_found1);fflush(stdout);
	
	
	for(a=0;a<n_tags_found1;a++)
	{
		
				
		//char* cntryStr = NULL;
		
		
		//cntryStr = MEM_alloc(50*sizeof(*cntryStr));
				
		ifail= AOM_ask_value_string(tags_found1[0],"t5_PlcCode",&lotcntry);
		/*						
		sprintf(cntryStr,"\n,Contry Code: %s", lotcntry);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,cntryStr);*/
		break;
	}
	
	
	for(i=0;i<n_tags_found;i++)
	{
		
		tag_t relatnType_tag, *brkDwnObj, querylot, *lot_found, query1, ckdDmlPar;
		int relCount, j, m, n_lots_found, desCount;
		char* ckdDml = NULL;
		char* name1 = NULL;
		char* spcfNo = NULL;
		char* specStr = NULL;
		//char* destination = NULL;
		char** desgnGrp = NULL;
		
		specStr = MEM_alloc(50*sizeof(*specStr));
		//destination = MEM_alloc(50*sizeof(*destination));
		
				
		ifail= ITEM_ask_item_of_rev(tags_found[i],&ckdDmlPar);
		
		ifail= AOM_ask_value_string(ckdDmlPar,"t5_ErcEsNo",&spcfNo);
		
		printf("\n spcfNo: %s",spcfNo);
		
		/*
		tc_strcpy(destination,"");
		tc_strcpy(destination,spcfNo);
		tc_strcat(destination," ");
		tc_strcat(destination,lotcntry);
		
		printf("\n destination: %s",destination);*/
		
		ifail= AOM_ask_value_strings(tags_found[i],"t5_crdesigngroup",&desCount,&desgnGrp);
		
		printf("\n desgnGrp: %s",desgnGrp[0]);
			
		/*
		sprintf(specStr,"\n,SPECIFICATION NO.: %s", spcfNo);
		setAddStrInCKDReport(buff_cnt,bufferedStrOut,specStr);*/
					
		ifail= AOM_ask_value_string(tags_found[i],"item_id",&ckdDml);
		
		printf("\n ckdDml: %s",ckdDml);
						
		ifail= GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag);
		
		
		ifail= GRM_list_secondary_objects_only(tags_found[i],relatnType_tag,&relCount,&brkDwnObj);
		
		printf("\n brkDwnObj: %d",relCount);
		
		for(j=0;j<relCount;j++)
		{
			char *breakDownInto = NULL;
			tag_t solution_rel, *solObj;
			int relCount1, k;
			
			ifail= AOM_ask_value_string(brkDwnObj[j],"object_string",&breakDownInto);
			
		
			printf("\n breakDownInto =%s",breakDownInto);fflush(stdout);
			
			ifail= GRM_find_relation_type("CMHasSolutionItem",&solution_rel);
			
			ifail= GRM_list_secondary_objects_only(brkDwnObj[j],solution_rel,&relCount1,&solObj);
			
			printf("\n solObj: %d",relCount1);
			
			for(k=0;k<relCount1;k++)
			{
				char* soluName = NULL;
				char* partType = NULL;
				char* soluName1 = NULL;
				//char* desgnGrp = NULL;
				char* dsgnGrpStr = NULL;
				char* soluNameStr = NULL;
				
				dsgnGrpStr = MEM_alloc(50*sizeof(dsgnGrpStr));
				soluNameStr = MEM_alloc(50*sizeof(soluNameStr));
				
				tag_t window, solObjMain, bomline, *bomChild;
				int bomCount, l;
				
				
				ifail= AOM_ask_value_string(solObj[k],"t5_PartType",&partType);
				
				
				
				if(tc_strcmp(partType,"CKDVC")==0)
				{
					ifail= AOM_ask_value_string(solObj[k],"object_name",&soluName);
					
					
					
					
					
					//ifail= AOM_ask_value_string(solObj[k],"t5_DesignGrp",&desgnGrp[0]);
					
					printf("\n soluName =%s",soluName);fflush(stdout);
					printf("\n partType =%s",partType);fflush(stdout);
				
					sprintf(dsgnGrpStr,"\nGROUP DESCRIPTION: %s", desgnGrp[0]); 
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,dsgnGrpStr);
					
				
					sprintf(soluNameStr,"\nBase VC: %s\n", soluName);
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,soluNameStr);
					
															
					setAddStrInCKDReport(buff_cnt,bufferedStrOut,"\nSr No. ,PartNo. ,Description ,Quantity, DESTINATION, S/O SUPPLY, CASE, CHECKED");					
		
					ifail= ITEM_ask_item_of_rev(solObj[k],&solObjMain);
					
					ifail= AOM_ask_value_string(solObjMain,"object_string",&soluName1);
					
					
					printf("\n soluName1 =%s",soluName1);fflush(stdout);
					
					ifail= BOM_create_window(&window);
					
					ifail= BOM_set_window_sort_compare_fn (window, (void *)bom_sorting, NULL);
					
					ifail= BOM_set_window_top_line(window,solObjMain,solObj[k],NULLTAG,&bomline);
					
					
					ifail= BOM_line_ask_all_child_lines(bomline,&bomCount,&bomChild);
				
					printf("\n bomCount =%d",bomCount);fflush(stdout);
					
					for(l=0;l<bomCount;l++)
					{
						int objname, objDesc, objQty, shpVal, caseVal;
						char* childName = NULL;
						char* childDesc = NULL;
						char* childQty = NULL;
						char* datastr = NULL;
						char* shopVal = NULL;
						char* childshpVal = NULL;
						char* childcaseVal = NULL;
						
						datastr = MEM_alloc(50*sizeof(datastr));
						
						/* ifail= BOM_line_look_up_attribute ("bl_item_item_id",&objname);
						
						ifail= BOM_line_look_up_attribute ("bl_item_object_desc",&objDesc);
						
						ifail= BOM_line_look_up_attribute ("bl_quantity",&objQty);
						
						ifail= BOM_line_look_up_attribute ("bl_occ_t5_ShpVal",&shpVal);
						
						ifail= BOM_line_look_up_attribute ("bl_occ_t5_CaseCode",&caseVal);
						
						
						ifail= BOM_line_ask_attribute_string(bomChild[l],objname,&childName);
						
						ifail= BOM_line_ask_attribute_string(bomChild[l],objDesc,&childDesc);
						
						ifail= BOM_line_ask_attribute_string(bomChild[l],objQty,&childQty);
						
						ifail= BOM_line_ask_attribute_string(bomChild[l],shpVal,&childshpVal);
						
						ifail= BOM_line_ask_attribute_string(bomChild[l],caseVal,&childcaseVal);
							ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_item_id",&childName); */
							
							
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_item_id",&childName);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_object_desc",&childDesc);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_quantity",&childQty);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_ShpVal",&childshpVal);
						
						ifail= AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_CaseCode",&childcaseVal);
							
						
						
						
						printf("\n\t\t%d.,%s, %s, %s, %s %s, %s, %s",l+1,childName,childDesc,childQty,spcfNo,lotcntry,childshpVal,childcaseVal);fflush(stdout);
						
						
						sprintf(datastr,"\n%d ,%s, %s, %s, %s %s, %s, %s, OK",l+1,childName,childDesc,childQty,spcfNo,lotcntry,childshpVal,childcaseVal);
						setAddStrInCKDReport(buff_cnt,bufferedStrOut,datastr);
						
						
						
						
					}
					if(bomChild)
						MEM_free(bomChild);
				
				}
				
								
				
			}
			if(solObj)
			MEM_free(solObj);
			
		}
		if(brkDwnObj)
			MEM_free(brkDwnObj);
	}
	if(tags_found)
		MEM_free(tags_found);
	
	printf("\n\n");
	return 0;
	
	
}

/****************************************************************/

int CallUpReport( void *retValue )
{
	printf("\n\ninside CallUpReport");fflush(stdout);
	
  /* int ifail = ITK_ok;
	int   count = 0;
   char* dmlNo;
   char** strOut = NULL;
   tag_t dml_object = NULLTAG;
   
   USERSERVICE_array_t 	array_structure;

	
	USERARG_get_tag_argument(&dml_object);
	AOM_ask_value_string(dml_object,"item_id",&dmlNo);
	//printf("\nitem_id of selected object:%s\n",DMLNumber);fflush(stdout);
	printf("ckd dml no.: %s",dmlNo);fflush(stdout);

	
	printf ("\n Repprt Completed ..return ");fflush(stdout);
   return ifail;*/
   
   
   int ifail = ITK_ok;
	int   count = 0;
   char* dmlNo;
	char* dmlrev;			
   char* output = NULL;
   char** strOut = NULL;
   tag_t dml_object = NULLTAG;
   char 					**string_array 	= NULL;	
   int array_size = 0;
   
   output = (char *) MEM_alloc( 5000 * sizeof(char) );
   tc_strcpy(output,"");
   
   USERSERVICE_array_t 	array_structure;
	
	//USERARG_get_string_argument(&dmlNo);
	
	USERARG_get_tag_argument(&dml_object);
	AOM_ask_value_string(dml_object,"item_id",&dmlNo);
	AOM_ask_value_string(dml_object,"item_revision_id",&dmlrev);														 
	
	printf("\nckd dml no.: %s",dmlNo);fflush(stdout);
	printf("\nckd dml rev.: %s",dmlrev);fflush(stdout);												
	
	if (dmlNo != NULLTAG)
	{
		char* dmlDup = NULLTAG;
		
		dmlDup = strdup(dmlNo);
		
		printf("\n Inside to call function GenerateCALLUPReport");	fflush(stdout);  
		GenerateCALLUPReport(dmlDup, dmlrev, &strOut, &count);
		
		printf("\nGenerateCALLUPReport count: %d",count);fflush(stdout);
	}
		
		int m =0;
		
		
		array_size = count;
		string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
		
		for(m=0;m<count;m++)
		{
			printf("\n%s",strOut[m]);fflush(stdout);
			
			tc_strcat(output,strOut[m]);
			
			//string_array[m] = strOut[m];
		}		
		printf("\n%s",output);fflush(stdout);
		printf ("\n After strOut\n");fflush(stdout);

		//ifail = USERSERVICE_return_string_array((const char**)string_array, count, &array_structure);
		//printf ("\n array_structure: %s", array_structure);fflush(stdout);

		
		//if (array_structure.length != 0)
		//	*((USERSERVICE_array_t*) retValue) = array_structure;			
		//MEM_free(string_array);
	
	
	*((char **) retValue) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) retValue), output); 
	
	printf ("\n Callup Report Completed ..return ");fflush(stdout);
   return ifail;
}

/****************************CallTag Report - Pratik*****************************************************/
int CallTagReport( void *retValue )
{
	printf("\n\ninside CallTagReport");fflush(stdout);
	   
   int ifail = ITK_ok;
	int   count = 0;
   char* dmlNo;
	char* dmlrev;			
   char* output = NULL;
   char** strOut = NULL;
   tag_t dml_object = NULLTAG;
   char 					**string_array 	= NULL;	
   int array_size = 0;
   
   output = (char *) MEM_alloc( 5000 * sizeof(char) );
   tc_strcpy(output,"");
   
   USERSERVICE_array_t 	array_structure;
	
	//USERARG_get_string_argument(&dmlNo);
	
	USERARG_get_tag_argument(&dml_object);
	AOM_ask_value_string(dml_object,"item_id",&dmlNo);
	AOM_ask_value_string(dml_object,"item_revision_id",&dmlrev);														 
	
	printf("\nckd dml no.: %s",dmlNo);fflush(stdout);
	printf("\nckd dml rev.: %s",dmlrev);fflush(stdout);												
	
	if (dmlNo != NULLTAG)
	{
		char* dmlDup = NULLTAG;
		
		dmlDup = strdup(dmlNo);
		
		printf("\n Inside to call function GenerateCALLUPReport");	fflush(stdout);  
		GenerateCALLTagReport(dmlDup, dmlrev, &strOut, &count);
		
		printf("\nGenerateCALLTagReport count: %d",count);fflush(stdout);
	}
		
		int m =0;
		
		
		array_size = count;
		string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
		
		for(m=0;m<count;m++)
		{
			printf("\n%s",strOut[m]);fflush(stdout);
			
			tc_strcat(output,strOut[m]);
			
			//string_array[m] = strOut[m];
		}		
		printf("\n%s",output);fflush(stdout);
		printf ("\n After strOut\n");fflush(stdout);
			
	
	*((char **) retValue) = 
	   (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));

	strcpy( *((char **) retValue), output); 
	
	printf ("\n CallTag Report Completed ..return ");fflush(stdout);
   return ifail;
}



/****************************CallTag Report - Pratik*****************************************************/


/* *********************/


/*Sneha Begins**********************/	

int GenerateCKDVCDMLReport(tag_t CKDDMLRevobjects,char*** bufferedXmlStrOut, int *buff_cnt)
{
	
	int				ifail 						= ITK_ok;
	char* ckdDml = NULL;
	tag_t relatnType_tag,*TaskObj;
	int relCount,j;
	
	
	
	CALLAPI(AOM_ask_value_string(CKDDMLRevobjects,"item_id",&ckdDml));
	printf("\n ckdDml: %s",ckdDml);
	
	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
	CALLAPI(GRM_list_secondary_objects_only(CKDDMLRevobjects,relatnType_tag,&relCount,&TaskObj));
	
	printf("\n TaskObj: %d",relCount);
	
	
	for(j=0;j<relCount;j++)
	{
		char *TaskCKD = NULL;
		tag_t solution_rel, *solObj;
		int solution_rel_cnt, k;
		
		CALLAPI(AOM_ask_value_string(TaskObj[j],"object_string",&TaskCKD));
			
		printf("\n TaskCKD =%s",TaskCKD);fflush(stdout);
		
		CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&solution_rel));
		CALLAPI(GRM_list_secondary_objects_only(TaskObj[j],solution_rel,&solution_rel_cnt,&solObj));
		printf("\n solution_rel_cnt: %d",solution_rel_cnt);
	
	    for(k=0;k<solution_rel_cnt;k++)
		{
			char* objectname = NULL;
			char* partType = NULL;
			char* CKDVCname = NULL;
			
			tag_t window, solObjMain, bomline, *bomChild,CKDVCobjects;
			int bomCount, l;
			
		    printf("\n Next Iteration: %d",k);
			CALLAPI(AOM_ask_value_string(solObj[k],"object_string",&objectname));
			printf("\n objectname =%s",objectname);fflush(stdout);
			
					
			CALLAPI(AOM_ask_value_string(solObj[k],"t5_PartType",&partType));
			printf("\n partType =%s",partType);fflush(stdout);
			
		
          		
			CALLAPI(ITEM_ask_item_of_rev(solObj[k],&solObjMain));
		
			CALLAPI(AOM_ask_value_string(solObjMain,"object_string",&CKDVCname));
			printf("\n CKDVCname =%s",CKDVCname);fflush(stdout);
			
			
			
			if((tc_strcmp(partType,"CKDVC")==0) || (tc_strcmp(partType,"D")==0))
			{
							
			CALLAPI(BOM_create_window(&window));
			CALLAPI(BOM_set_window_top_line(window,solObjMain,solObj[k],NULLTAG,&bomline));
							
			CALLAPI(BOM_line_ask_all_child_lines(bomline,&bomCount,&bomChild));
			printf("\n bomCount =%d",bomCount);fflush(stdout);
			
			if (bomCount>0)
			{
				for(l=0;l<bomCount;l++)
				{
					int objname, objDesc, objQty,objActind,objLevel,objTplNo,objTempAssy,objDmlno,objLoc;
					char* childName = NULL;
					char* childDesc = NULL;
					char* childQty = NULL;
					char* childActionInd = NULL;
					int childLevel = 0;
					char* childCkdTplNo = NULL;
					char* childTempAssy = NULL;
					char* childERCNo = NULL;
					char* childLoc = NULL;
					char* childLevelprint = NULL;
					
					childLevelprint=MEM_alloc(10);
					
					printf("\n bomCount1111 =%d",l);fflush(stdout);
					/* CALLAPI(BOM_line_look_up_attribute ("bl_child_id",&objname));
					CALLAPI(BOM_line_look_up_attribute ("bl_rev_object_desc",&objDesc));
					CALLAPI(BOM_line_look_up_attribute ("bl_quantity",&objQty));
					CALLAPI(BOM_line_look_up_attribute ("bl_occ_t5_ActionInd",&objActind));
					CALLAPI(BOM_line_look_up_attribute ("bl_level_starting_0",&objLevel));
					CALLAPI(BOM_line_look_up_attribute ("bl_occ_t5_CKDTPLNo",&objTplNo));
					CALLAPI(BOM_line_look_up_attribute ("bl_occ_t5_TempAssy",&objTempAssy));
					CALLAPI(BOM_line_look_up_attribute ("bl_occ_t5_ERCVCNo",&objDmlno));
					CALLAPI(BOM_line_look_up_attribute ("bl_occ_t5_Location",&objLoc)); */
					
					
					printf("\n bomCount22222 =%d",l);fflush(stdout);
					printf("\n objname, objDesc, objQty,objActind,objLevel,objTplNo,objTempAssy,objDmlno,objLoc =%d %d %d %d %d %d %d %d %d",objname, objDesc, objQty,objActind,objLevel,objTplNo,objTempAssy,objDmlno,objLoc);fflush(stdout);
					/* CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childName));
					printf("\n childName =%s",childName);fflush(stdout);
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childDesc));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childQty));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childActionInd));
					CALLAPI(AOM_ask_value_int(bomChild[l],"",&childLevel));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childCkdTplNo));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childTempAssy));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childERCNo));
					CALLAPI(BOM_line_ask_attribute_string(bomChild[l],"",&childLoc));
					ifail= AOM_UIF_ask_value(bomChild[l],"bl_item_item_id",&childName); */
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_child_id",&childName));
					printf("\n childName =%s",childName);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_rev_object_desc",&childDesc));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_quantity",&childQty));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_ActionInd",&childActionInd));
					CALLAPI(AOM_ask_value_int(bomChild[l],"bl_level_starting_0",&childLevel));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_CKDTPLNo",&childCkdTplNo));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_TempAssy",&childTempAssy));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_ERCVCNo",&childERCNo));
					CALLAPI(AOM_UIF_ask_value(bomChild[l],"bl_occ_t5_Location",&childLoc));
									
					
					
				
				
					
					 printf("\n\t\t%d.,%d, %s, %s, %s , %s , %s ,%s,%s",l+1,childLevel,childName,childDesc,childActionInd,childQty,childCkdTplNo,childTempAssy,childERCNo,childLoc);fflush(stdout);
					
					
					 sprintf(childLevelprint,"\n%d",childLevel);
					 setAddStrInCKDReport(buff_cnt,bufferedXmlStrOut,childLevelprint);
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childActionInd));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childCkdTplNo));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childTempAssy));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childName));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childDesc));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childLoc));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"---"));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,"---"));
					 CALLAPI(AddValueinBuffer(bufferedXmlStrOut,buff_cnt,childQty));
					 
					

					
					
				}
				
				if(bomChild) MEM_free(bomChild);
			}	
			}
		} //if(solObj)	MEM_free(solObj);	
			
			
	}//if(brkDwnObj)	MEM_free(brkDwnObj);


	printf("\n %d IFAIL CKD VC DML REPORT ",ifail);fflush(stdout);
	return ifail;
}



extern int CKD_VC_DMLReportServiceFnc( void *return_data )
{
	int				ifail 						= ITK_ok;
	int n_objects = 0;
    tag_t objects = NULLTAG;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	
	
	ifail = USERARG_get_tag_argument(&objects); 
		
	
	printf("After returning Value\n");fflush(stdout);
	
	char** bufferedXmlStrOut;
	int buff_cnt=0;
	
	if (objects != NULLTAG)
	  {
	 CALLAPI(GenerateCKDVCDMLReport(objects,&bufferedXmlStrOut,&buff_cnt));
	  }
	
	
	
	

		int m =0;
		printf("\nBuff count=%d\n",buff_cnt);fflush(stdout);
		array_size = buff_cnt;
		string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
		for(m=0;m<buff_cnt;m++)
		{
			printf("\n%s",bufferedXmlStrOut[m]);fflush(stdout);
			string_array[m] = bufferedXmlStrOut[m];
		}
		
			printf("\nBefore returning Value\n");fflush(stdout);

			ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

			
		 if (array_struct.length != 0)
			*((USERSERVICE_array_t*) return_data) = array_struct;	
	
	
	return ifail;
}

static int bom_sort_function (tag_t line_1, tag_t line_2, void * client_data)
{
	/* returns strcmp style -1/0/+1 according to whether line_1 and line_2 sort <, = or > */
	char *partno1, *partno2;
	int ifail = ITK_ok;
	int result;
	(void)client_data;
	ITK_CALL(AOM_ask_value_string (line_1, "bl_rev_item_id", &partno1));
	//printf("\n partnumber 1 = %s\n",partno1);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string (line_2, "bl_rev_item_id", &partno2));
	//printf("\n partnumber 2 = %s\n",partno2);fflush(stdout);
	
	if (partno1 == NULL || partno2 == NULL)
	  result = 0;
	else
		result = tc_strcmp (partno1, partno2);
	  //result = tc_strcmp (partno2, partno1); //for descending order of item_id
  
	MEM_free (partno1);
	MEM_free (partno2);
	return result;
}
	
int CKD_DML_CKIMP_Report_Servicefunc(void *retValue)
{
	const char				*prog_name 		="CKD_DML_CKIMP_Report_Servicefunc";
	int ifail = ITK_ok;
	tag_t ckddmlTag = NULLTAG;
	char 			*ckddmlno				= NULL;
	
	USERARG_get_tag_argument(&ckddmlTag); 

	ITK_CALL(AOM_ask_value_string(ckddmlTag,"item_id",&ckddmlno));
	printf("\n ckddmlno : %s",ckddmlno);   fflush(stdout);
	
	tag_t *retModules=NULLTAG;
	int moduleTagList_cnt=0;
	
	/* printf("\n building query \n");fflush(stdout);
	const char *select_attrs[]={"item_id"};
	const char *str_list[20]={ckddmlno};
	printf("\nstr_list[0]=%s",str_list[0]);fflush(stdout);
	int n_rows;
	int n_cols;
	void ***report;
	int row;
	int column;
	
	ERROR_CHECK(POM_enquiry_create ("find_lot"));
	printf("\nPOM_enquiry_create\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_add_select_attrs ("find_lot","T5_LotNumRevision", 1, select_attrs));
	printf("\nPOM_enquiry_add_select_attrs\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_set_string_value ("find_lot","attrval",1,str_list,POM_enquiry_bind_value));
	printf("\nPOM_enquiry_set_string_value\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_set_attr_expr ("find_lot","expr1", "T5_LotNumRevision","item_id",POM_enquiry_equal, "attrval"));
	printf("\nPOM_enquiry_set_attr_expr\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_set_where_expr ("find_lot","expr1"));
	printf("\nPOM_enquiry_set_where_expr\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_add_order_attr( "find_lot", "T5_LotNumRevision", "creation_date", POM_enquiry_desc_order ));
	printf("\nPOM_enquiry_add_order_attr\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_execute("find_lot", &n_rows, &n_cols, &report));
	printf("\nPOM_enquiry_execute\n");fflush(stdout);
	ERROR_CHECK(POM_enquiry_delete("find_lot")); 
	printf("\nPOM_enquiry_delete\n");fflush(stdout);
	
	printf("\nckddmlno=%s row=%d col=%d report=%s",ckddmlno,n_rows,n_cols,report);fflush(stdout);
	for (row = 0; row < n_rows; row++)
	{
		for (column = 0; column < n_cols; column++)
		{
			printf("\n CKIMP Query return=%s\t", report[row][column]);fflush(stdout);
		}

	}
	printf("\n CKIMP Row =%d Column =%d\t", n_rows,n_cols);fflush(stdout);
	if(n_rows==0 )
	{
		printf("\nCKIMP no rows\n");fflush(stdout);
	}
	else
	{
		printf("\nCKIMP rows fetched");fflush(stdout);
	} 
				
	printf("\n ending query");fflush(stdout); */
	
	
	tag_t   qryTag     = NULLTAG;
	int n_entry    = 1;
	char    *qry_entry[]  = {"DML No"};
	char    *qry_values2[]     = {ckddmlno};// (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount      =  0;
	tag_t   *LotNumber      = NULLTAG;
	char	*itemidLotNo	= NULL;
	char	*itemidLotQty	= NULL;
	char    *ckd_view       = NULL;
	
	printf("\n start version 1.8\n");fflush(stdout);
	
	if(QRY_find2("LOTNUMBER", &qryTag));
	if (qryTag)
	{
		printf("\n Found Query LOTNUMBER \n");fflush(stdout);
	}
	else
	{
		printf("\n Not Found Query LOTNUMBER \n");fflush(stdout);
	}

	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &LotNumber));
	printf(" \n LOTNUMBER rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		CALLAPI(AOM_ask_value_string(LotNumber[0],"item_id",&itemidLotNo));
		printf("\n LOTNUMBER: itemidLotNo is  = [%s]\n", itemidLotNo);fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(LotNumber[0],"t5_LotQty",&itemidLotQty));
		printf("\n LOTNUMBER: itemidLotQty is  = [%s]\n", itemidLotQty);fflush(stdout);
	}
			
	tag_t  ckddmlworkbreaksRelType=NULLTAG;
	int count;
	tag_t * 	secondary_objects ;
	char *taskno;
	
	tag_t  ckdtasksolutionRelType=NULLTAG;
	int count1;
	tag_t * 	secondary_item_objects ;
	char *partno;
	char *parttype;
	char *itemRevId;
	char *itemdesc;
	int i;
	
	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&ckddmlworkbreaksRelType));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&ckdtasksolutionRelType));
	
	ERROR_CHECK(GRM_list_secondary_objects_only(ckddmlTag,ckddmlworkbreaksRelType,&count,&secondary_objects ));
	
	printf("\n GRM_list_secondary_objects_only for task with count = %d\n",count);fflush(stdout);
	
	if(count>0)
	{
		
		ERROR_CHECK(AOM_ask_value_string(secondary_objects[0],"item_id" , &taskno));
		printf("\n TaskName: taskno is  = [%s]\n", taskno);fflush(stdout);
		
		ERROR_CHECK(GRM_list_secondary_objects_only(secondary_objects[0],ckdtasksolutionRelType,&count1,&secondary_item_objects ));
		
		if(count1 > 0)
		{
			ERROR_CHECK(AOM_ask_value_string(secondary_item_objects[0],"item_id" , &partno));
			printf("\n Part Number: partno is  = [%s]\n", partno);fflush(stdout);
			
			ERROR_CHECK(AOM_ask_value_string(secondary_item_objects[0],"t5_PartType" , &parttype));
			printf("\n Part Number: parttype is  = [%s]\n", parttype);fflush(stdout);
			
			if(tc_strcmp(parttype,"CKDVC")==0)
			{
				printf("\n Part Number: partno is CKD Vehicle Combination \n", partno);fflush(stdout);
			}
			else
			{
				return 	ifail;
			}
			
			ERROR_CHECK(AOM_ask_value_string(secondary_item_objects[0],"item_revision_id" , &itemRevId));
			printf("\n Part Number: itemRevId is  = [%s]\n", itemRevId);fflush(stdout);
			
			ERROR_CHECK(AOM_ask_value_string(secondary_item_objects[0],"object_desc" , &itemdesc));
			printf("\n Part Number: 1 itemdesc is  = [%s]\n", itemdesc);fflush(stdout);
			
			stripBlanks(itemdesc);
			printf("\n Part Number: 2 itemdesc is  = [%s]\n", itemdesc);fflush(stdout);
			
			for(i = 0; i <= tc_strlen(itemdesc); i++)
			{
				if(itemdesc[i] == '\n')  
				{
					itemdesc[i] = ' ';
				}
				if(itemdesc[i] == ',')  
				{
					itemdesc[i] = ';';
				}
			}
			
			printf("\n Part Number: 3 itemdesc is  = [%s]\n", itemdesc);fflush(stdout);
			
			//Colour Module not implemented yet	
			
			int num_of_bv;
			char *type_name;
			tag_t rule,window,*bv,view_type,item;
			int i;
			tag_t top_line;
  
 
			ITK_CALL( ITEM_ask_item_of_rev(secondary_item_objects[0],&item));
			
			char *item_id1;
			ITK_CALL(AOM_ask_value_string(item, "item_id", &item_id1 ));
			printf("\n item_id=%s",item_id1);fflush(stdout);
			
			ITK_CALL( ITEM_list_bom_views(item, &num_of_bv, &bv));
			printf("\n Number of bv = %d\n",num_of_bv);fflush(stdout);
			
			ITK_CALL(PREF_ask_char_value("CKDVIEW",0,&ckd_view));
			printf("\n ckd_view=%s \n",ckd_view);fflush(stdout);
			
			for (i = 0; i < num_of_bv; i++)
			{				
				ITK_CALL(PS_ask_bom_view_type(bv[i], &view_type));
				ITK_CALL(PS_ask_view_type_name(view_type, &type_name));
				
				printf("\n type_name = %s\n",type_name);fflush(stdout);
				
				if (tc_strstr(type_name, ckd_view)!=NULL)
				{
					printf("\n DFMA found\n");fflush(stdout);
					break;
				}
			}

			if(CFM_find( "Latest Working", &rule ));
			printf("\n Rule found \n");fflush(stdout);
			
			ITK_CALL(BOM_create_window (&window)); 
			ITK_CALL(BOM_set_window_sort_compare_fn (window, (void *)bom_sort_function, NULL));;
			ITK_CALL(BOM_set_window_top_line(window, item, secondary_item_objects[0], bv[i], &top_line));
						
			int n_bomlines;
			tag_t *bomlines;
			tag_t t_Childobject = NULLTAG;
			int j,k,x;
			
			ITK_CALL(BOM_line_ask_child_lines(top_line, &n_bomlines, &bomlines));
			printf("\n Number of child line = %d",n_bomlines);fflush(stdout);
            
			
			for (j = 0; j < n_bomlines; j++)
			{
				t_Childobject=bomlines[j];
				BOM_line_unpack(t_Childobject);
			}

			BOM_line_ask_child_lines (top_line, &n_bomlines, &bomlines);
			printf("\n Number of child line after unpacking = %d",n_bomlines);fflush(stdout);
			
			for (k = 0; k < n_bomlines; k++)
			{
				if(t_Childobject) t_Childobject=NULLTAG;

				t_Childobject=bomlines[k];
			}
			
			
			
			for(x=0;x<n_bomlines;x++)
			{

				tag_t childline = bomlines[x];
				
				setAddTagP(&moduleTagList_cnt,&retModules,childline);
				
				char *item_id;
				ITK_CALL(AOM_ask_value_string(childline, "bl_rev_item_id", &item_id ));
				printf("\n [%d] item_id1=%s",x,item_id);fflush(stdout);
			}
			
			printf("\n IT IS CALLING THE CORRECT SERVICE FUNCTION 12345");fflush(stdout);
			
			printf("\n before USERSERVICE_return_tag_array call with values moduleTagList_cnt[%d]",moduleTagList_cnt);fflush(stdout);
			ITK_CALL(USERSERVICE_return_tag_array(retModules,moduleTagList_cnt,(USERSERVICE_array_t*)retValue));
			printf("\n after USERSERVICE_return_tag_array call");fflush(stdout);
		}		
	}

	printf("\n End calling func CKD_DML_CKIMP_Report_Service version 1.8");fflush(stdout);
	return 	ifail;

}	


void tm_fnd_ERCDML_PART(char	*PLT_CODE,tag_t t_currentRevision, tag_t* t_DMLRevision)
{
	int     status;
	int     ifail;
	int		count_tsk				=	0;
	int		count_DML				=	0;
	int		iPPPM					=	0;
	int		itsk					=	0;
	int		idml					=	0;
	int		iDMLFnd					=	0;

	char	*c_PartNumber			=	NULL;
	char	*Part_Rev				=	NULL;
	char	*object_type			=	NULL;
	char	*type_name				=	NULL;
	char	*type_dml_name			=	NULL;
	char	*task_name				=	NULL;
	char	*DML_name				=	NULL;

	tag_t	tsk_part_sol_rel_type	=	NULLTAG;
	tag_t	dml_task_rel_type		=	NULLTAG;
	tag_t	*TaskRevision			=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	TaskRevTag				=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	objTaskTypeTag			=	NULLTAG;
	tag_t	objDMLTypeTag			=	NULLTAG;
	char       roleName[SA_name_size_c+1];

	printf("\nInside tm_fnd_ERCDML_PART \n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_id",&c_PartNumber));
	printf("\n Part_Number: %s\n",c_PartNumber);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"object_type",&object_type));
	printf("\nobject_type : %s",object_type);fflush(stdout);

	ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type));

	if(tsk_part_sol_rel_type!=NULLTAG)
	{
		GRM_list_primary_objects_only(t_currentRevision,tsk_part_sol_rel_type,&count_tsk,&TaskRevision);
		printf("\n\n\t\t APL DML Cre:ERC DML  : %d",count_tsk);fflush(stdout);

		if(count_tsk>0)
		{
			for(itsk=0;itsk<count_tsk;itsk++)
			{
				iDMLFnd		=	0;
				TaskRevTag	=	NULLTAG;
				TaskRevTag	=	TaskRevision[itsk];

				if(TCTYPE_ask_object_type(TaskRevTag,&objTaskTypeTag));
				if(TCTYPE_ask_name2(objTaskTypeTag,&type_name));
				printf("\n     type_name_erc changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
				{
					//item_id
					ITKCALL(AOM_ask_value_string(TaskRevTag,"item_id",&task_name));
					printf("\n\n\t\t object_type is :%s",task_name);fflush(stdout);
					
					char *PlantNameP=NULL;
					PlantNameP=subString(task_name,15,18);
					
					printf( "\n PlantNameP: %s\n", PlantNameP); fflush(stdout);

					if(tc_strstr(task_name,"PP")!=NULL || tc_strstr(task_name,"PM")!=NULL)
					{
						printf("\nPP Task found for DML.");fflush(stdout);
						iPPPM	=	1;
						if(strstr(task_name,PlantNameP))
						{
							printf("\nMatch found...!!!");fflush(stdout);

							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type));
							if(dml_task_rel_type!=NULLTAG)
							{
								ITKCALL(GRM_list_primary_objects_only(TaskRevTag,dml_task_rel_type,&count_DML,&DMLRevision));
								printf("\n\n\t\t No OF DML FOUND  : %d",count_DML);fflush(stdout);
								if(count_DML>0)
								{
									for(idml=0;idml<count_DML;idml++)
									{
										DMLRevTag	=	NULLTAG;
										DMLRevTag	=	DMLRevision[idml];
										
										if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
										if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
										printf("\ntype_dml_name : %s",type_dml_name);fflush(stdout);

										if (tc_strcmp(type_dml_name,"ChangeRequestRevision")==0)
										{
											iDMLFnd	=	1;
											ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DML_name));
											printf("\nDML_name founc : %s",DML_name);fflush(stdout);
											*t_DMLRevision	=	DMLRevTag;
											break;
										}
									}
								}
								else
								{
									printf("\nNo DML found...!!!");fflush(stdout);
								}
							}
						}
					}
				}
				if(iDMLFnd==1)
				{
					printf("\nTask Loop break...!!!");fflush(stdout);
					break;
				}
			}
			if(iPPPM==0)
			{
				printf("\nPP DML NOT FOUND, NEED TO CHECK AMDML");fflush(stdout);

				for(itsk=0;itsk<count_tsk;itsk++)
				{
					iDMLFnd		=	0;
					TaskRevTag	=	NULLTAG;
					TaskRevTag	=	TaskRevision[itsk];

					if(TCTYPE_ask_object_type(TaskRevTag,&objTaskTypeTag));
					if(TCTYPE_ask_name2(objTaskTypeTag,&type_name));
					printf("\n     type_name_erc changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

					if(tc_strcmp(type_name,"T5_APLTaskRevision")==0)
					{
						//item_id
						ITKCALL(AOM_ask_value_string(TaskRevTag,"item_id",&task_name));
						printf("\n\n\t\t object_type is :%s",task_name);fflush(stdout);

						if(tc_strstr(task_name,"AM")!=NULL)
						{
							printf("\nPP Task found for DML.");fflush(stdout);
							iPPPM	=	1;
							if(strstr(task_name,PLT_CODE))
							{
								printf("\nMatch found...!!!");fflush(stdout);

								ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type));
								if(dml_task_rel_type!=NULLTAG)
								{
									ITKCALL(GRM_list_primary_objects_only(TaskRevTag,dml_task_rel_type,&count_DML,&DMLRevision));
									printf("\n\n\t\t No OF DML FOUND  : %d",count_DML);fflush(stdout);
									if(count_DML>0)
									{
										for(idml=0;idml<count_DML;idml++)
										{
											DMLRevTag	=	NULLTAG;
											DMLRevTag	=	DMLRevision[idml];
											
											if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
											if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
											printf("\ntype_dml_name : %s",type_dml_name);fflush(stdout);

											if (tc_strcmp(type_dml_name,"T5_APLDMLRevision")==0)
											{
												iDMLFnd	=	1;
												ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DML_name));
												printf("\nDML_name founc : %s",DML_name);fflush(stdout);
												*t_DMLRevision	=	DMLRevTag;
												break;
											}
										}
									}
									else
									{
										printf("\nNo DML found...!!!");fflush(stdout);
									}
								}
							}
						}
					}
					if(iDMLFnd==1)
					{
						printf("\nTask Loop break...!!!");fflush(stdout);
						break;
					}
				}
			}
		}
		else
		{
			printf("\nNo task found");fflush(stdout);
		}
	}

}

int CkdErcVCReport( void *retValue )
{
	FILE *fp;
	FILE                    *report                               =NULL;
	FILE * DmlRelFile		=NULL;
	char str[1024];
	char *partno;
	char 	*Filepartno	= NULL;
	tag_t queryTag		= NULLTAG;
	int count;
	int ifail = ITK_ok;
	tag_t*  	prtTasks1			=	NULLTAG;
	tag_t*  	prtTasks2			=	NULLTAG;
	int	cntTask1=0;
	int	cntTask2=0;
	tag_t	relation_type = NULLTAG;
	int	iTask1=0;
	char GetPlant[40];
	char *FileLoc			= NULL;
	
	tag_t			TskToDMLRel= NULLTAG;
	tag_t			DMLRevTagg		= NULLTAG;
	tag_t			DMLTypeTag		= NULLTAG;
	tag_t*			DMLTagg		= NULLTAG;
	char*		DMLNumberr				= NULL;
	tag_t		DMLRevTag			= NULLTAG;
	tag_t*		DMLRevision			= NULLTAG;
	int j,CountDML,dmlcount,k=0;
	int Counter=0;
	int	FlagGotDML=0;
	char			DMLTyp[TCTYPE_name_size_c+1];
	char*	 Tasknum = NULL;
	tag_t *TskObjSO=NULLTAG;
	tag_t		tsk_dml_rel_type	= NULLTAG;
	char *DmlName=NULL;
	char		*DMLtype				= NULL;
	char		*DMLDRStatus				= NULL;
	char		*DMLCreReason				= NULL;
	char		*t5CkVcNum				= NULL;
	tag_t	t_DMLRevision		=	NULLTAG;
	char   *PlantName	=	NULL;
	char   *DML_name	=	NULL;
	//char	 *ClosureDate		= NULL;
	date_t 	 ERCRelDate;
	char* APLRelDateStr = NULL;
	
	char       roleName[SA_name_size_c+1];
	
	logical		is_latest;
	tag_t class_id1=NULLTAG;
	char *class_name1= NULL;
	
	time_t now;

	struct tm* now_tm;

	time(&now);

	now_tm = localtime(&now);
	char ReportFiredDate[26] = {'\0'};
	//z = ITK_init_module("infodba","infodba","dba");	
	//error(z,"login success\n");
	
	printf("file opening sequence starting\n");fflush(stdout);
	//fp = fopen("CkdVc.csv","r");
	//report = fopen("outpout.txt", "w");
	int Prtsize=0;
   char					**prtList 		= NULL;
	
	USERARG_get_string_array_argument(&Prtsize,&prtList);
	//char **bufferedXmlStrOut = NULL;
	//int buff_cnt =0;
	//bufferedXmlStrOut = (char *) MEM_alloc( 5000 * sizeof(char) );
	
	int i=0;
	for(i=0; i< Prtsize; i++)
	{
		printf("\nPart Number===>%s\n", prtList[i]);fflush(stdout);
	}
	//setAddStrInCKDReport(buff_cnt,bufferedXmlStrOut,"\n\n======================================================================================");
	//setAddStrInCKDReport(buff_cnt,bufferedXmlStrOut," \n\t\tCKD ERC VC Release Report:");
	char *OutPutValue=NULL;
	OutPutValue = (char *) MEM_alloc( 50000 * sizeof(char) );
	char *SesUsr = NULL;
	tc_strcpy(OutPutValue,"");
	tc_strcat(OutPutValue,"\n\t\tCKD ERC VC Release Report:");
	tc_strcat(OutPutValue,"\n\t\tFired on -->:");
	strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
	tc_strcat(OutPutValue,ReportFiredDate);
	
	POM_get_user_id (&SesUsr);
	printf("\n DRCHK: Session user: %s\n",SesUsr); fflush(stdout);
	tc_strcat(OutPutValue,"\n\t\tFired by -->");
	tc_strcat(OutPutValue,SesUsr);
	tc_strcat(OutPutValue,"\n\t\t-------------------------------------- \n");
	
	tc_strcat(OutPutValue,"\nPart_No,Part_Type,Part_Rev,Part_Desc,CKD_DML_No,CKD_DML_Description,ERCBaseVC_No,ERCBaseVC_Desc,ERCBaseVc_DML_No,ERCBaseVc_DML_Desc,ERC_VC_ReleaseDate,ERC_BaseVc_DML_DRstatus\n");
	tc_strcat(OutPutValue,"\n\n");
		
	if(Prtsize>0)
	{
				for(i=0; i< Prtsize; i++)
				{
				Filepartno = prtList[i];
				
				
				printf("\nInput is :%s\n",Filepartno);
				
				tag_t *part_rev_tag = NULLTAG;
				int partcount=0;
				ITK_CALL (getQueryItemRevision_AllType(Filepartno,"Design Revision",&part_rev_tag,&partcount));
				printf("\n number of the Part queried is [%d]",partcount);fflush(stdout);
				if(partcount>0 && part_rev_tag!=NULLTAG )
				{

					char*	item_idval		= NULL;
					char*	item_projcode	= NULL;
					char*	item_desgnGrp	= NULL;
					char*	parttype	= NULL;
					char *curentname= NULL;
					char*	PartDescription	= NULL;
					char*	PartRev	= NULL;
					tag_t	latestRevPart_tag	=	NULLTAG;
					tag_t  	PartRevag =	NULLTAG;
					cntTask1=0;
					iTask1=0;
					prtTasks1=NULLTAG;

					tag_t Part_tag =NULLTAG;
					Part_tag = part_rev_tag[0];
								
					CALLAPI(ITEM_ask_item_of_rev(Part_tag, &PartRevag));
					printf("\n ITEM_Found......");fflush(stdout);
							
					CALLAPI(ITEM_ask_latest_rev(PartRevag,&latestRevPart_tag));
								
					if (latestRevPart_tag!=NULLTAG)
					{
						if( AOM_ask_value_string(latestRevPart_tag,"object_string",&curentname)==ITK_ok)
						printf("\n latest revision---------------> %s\n",curentname);fflush(stdout);
					}
						
					CALLAPI(AOM_ask_value_string(latestRevPart_tag,"item_id",&item_idval));
					printf("\n The Filepartno is valid: %s \n",item_idval);fflush(stdout);	
					
					tc_strcat(OutPutValue,item_idval);
					tc_strcat(OutPutValue,",");
					
					CALLAPI(AOM_ask_value_string(latestRevPart_tag,"t5_PartType",&parttype));
					printf("\n The Filepartno parttype: %s \n",parttype);fflush(stdout);	
					
					tc_strcat(OutPutValue,parttype);
					tc_strcat(OutPutValue,",");
					
					CALLAPI(AOM_ask_value_string(latestRevPart_tag,"current_revision_id",&PartRev));
					printf("\n The Filepartno Description is: %s \n",PartRev);fflush(stdout);
					
					tc_strcat(OutPutValue,PartRev);
					tc_strcat(OutPutValue,",");
					
					CALLAPI(AOM_ask_value_string(latestRevPart_tag,"object_desc",&PartDescription));
					printf("\n The Filepartno Description is: %s \n",PartDescription);fflush(stdout);
					
					tc_strcat(OutPutValue,PartDescription);
					tc_strcat(OutPutValue,",");
					
					if(tc_strcmp(parttype,"CKDVC")==0)
					{
						ITKCALL( GRM_list_primary_objects_only(latestRevPart_tag,relation_type,&cntTask1,&prtTasks1));
						printf("\n cntTask1 : %d",cntTask1);fflush(stdout);
															
						if (cntTask1 > 0)
						{
							for (j=0;j<cntTask1;j++ )
							{
								if( AOM_ask_value_string(prtTasks1[j],"item_id",&Tasknum)==ITK_ok)
								printf("\n Task Attched is %s\n",Tasknum); fflush(stdout);
									
								ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							
								if (tsk_dml_rel_type!=NULLTAG)
								{
											
									ITKCALL(GRM_list_primary_objects_only(prtTasks1[j],tsk_dml_rel_type,&dmlcount,&DMLRevision));
									printf("\n\n\t\t DML Revision from Task : %d",dmlcount);fflush(stdout);		//task to dml
											
									for (k=0;k<dmlcount ;k++ )
									{
										ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[k],&is_latest));
										printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);

										if(is_latest != true)
										{
											printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
										}
										else
										{
											DMLRevTag = DMLRevision[k];//DML
											tag_t ckdDmlMaster=NULLTAG;
											char		*ckddmlmstvc				= NULL;
											char* ckdDmlMstNum = NULL;
											char* ckdDmlDesc = NULL;
											
											tag_t  *tags_found,ckdDmlPar;
												
											ifail= ITEM_ask_item_of_rev(DMLRevTag,&ckdDmlMaster);
							
											ifail= AOM_ask_value_string(DMLRevTag,"item_id",&ckdDmlMstNum);
											printf("\n ckdDml for itemrev: %s\n",ckdDmlMstNum);fflush(stdout);
											
											tc_strcat(OutPutValue,ckdDmlMstNum);
											tc_strcat(OutPutValue,",");
											
											ifail= AOM_ask_value_string(DMLRevTag,"t5_reasondesc",&ckdDmlDesc);
											printf("\n ckdDml for Description: %s\n",ckdDmlDesc);fflush(stdout);
											
											tc_strcat(OutPutValue,ckdDmlDesc);
											tc_strcat(OutPutValue,",");
							
											ifail= AOM_ask_value_string(ckdDmlMaster,"t5_CkVcNum",&ckddmlmstvc);
											printf("\n Base VC string: %s\n",ckddmlmstvc);fflush(stdout);

											tc_strcat(OutPutValue,ckddmlmstvc);
											tc_strcat(OutPutValue,",");											
											
														
											tag_t *part_rev_tag1 = NULLTAG;
											int partcount1=0;
											ITK_CALL (getQueryItemRevision_AllType(ckddmlmstvc,"Design Revision",&part_rev_tag1,&partcount1));
											printf("\n number of the Part queried is [%d]",partcount1);fflush(stdout);
											if(partcount1>0 && part_rev_tag1!=NULLTAG )
											{

												char*	item_idval1		= NULL;
												char*	item_projcode1	= NULL;
												char*	item_desgnGrp1	= NULL;
												char*	parttype1	= NULL;
												char*	partdesc1	= NULL;
												char *curentname1= NULL;
												tag_t	item_rev_tag						= NULLTAG;
												
												tag_t	latestRevPart_tag1	=	NULLTAG;
												tag_t  	PartRevag1 =	NULLTAG;
												tag_t	t_previousRevision			=	NULLTAG;
												t_DMLRevision		=	NULLTAG;
												
												PlantName	=	NULL;
												PlantName	=	subString(roleName,3,4);
												printf( "\n PlantName:%s\n", PlantName);
												
												cntTask2=0;
												iTask1=0;
												prtTasks2=NULLTAG;
												

												tag_t Part_tag1 =NULLTAG;
												Part_tag1 = part_rev_tag1[0];
															
												CALLAPI(ITEM_ask_item_of_rev(Part_tag1, &PartRevag1));
												printf("\n ITEM_Found......");fflush(stdout);
														
												CALLAPI(ITEM_ask_latest_rev(PartRevag1,&latestRevPart_tag1));
															
												if (latestRevPart_tag1!=NULLTAG)
												{
													if( AOM_ask_value_string(latestRevPart_tag1,"object_string",&curentname1)==ITK_ok)
													printf("\n latest revision---------------> %s\n",curentname1);fflush(stdout);
												}
													
												CALLAPI(AOM_ask_value_string(latestRevPart_tag1,"item_id",&item_idval1));
												printf("\n The Filepartno is valid: %s \n",item_idval1);fflush(stdout);	
													
												CALLAPI(AOM_ask_value_string(latestRevPart_tag1,"t5_PartType",&parttype1));
												printf("\n The Filepartno parttype1: %s \n",parttype1);fflush(stdout);	
												
												CALLAPI(AOM_ask_value_string(latestRevPart_tag1,"object_desc",&partdesc1));
												printf("\n The Filepartno partDesc1: %s \n",partdesc1);fflush(stdout);
												
												tc_strcat(OutPutValue,partdesc1);
												tc_strcat(OutPutValue,",");	
						 
												
												ITKCALL( GRM_list_secondary_objects_only(latestRevPart_tag1,relation_type,&cntTask2,&prtTasks2));
												printf("\n cntTask2 : %d \n",cntTask2);fflush(stdout);
												
												tm_fnd_ERCDML_PART(PlantName,latestRevPart_tag1, &t_DMLRevision);
												
												if (t_DMLRevision!=NULLTAG)
												{
													printf("\nDML TAG FOUND...!!!");fflush(stdout);
													DML_name	=	NULL;
													char* DML_descrip = NULL;
													date_t 	 ERCRelDate;
													char* APLRelDateStr = NULL;
													char* DML_DRstatus = NULL;
													
													ITKCALL(AOM_ask_value_string(t_DMLRevision,"item_id",&DML_name));
													printf("\nDML_name t_DMLRevision : %s \n",DML_name);fflush(stdout);
													
													tc_strcat(OutPutValue,DML_name);
													tc_strcat(OutPutValue,",");	
													
													ITKCALL(AOM_ask_value_string(t_DMLRevision,"current_name",&DML_descrip));
													printf("\nDML_name Description is : %s \n",DML_descrip);fflush(stdout);
													
													tc_strcat(OutPutValue,DML_descrip);
													tc_strcat(OutPutValue,",");
													
													ITK_CALL(AOM_ask_value_date(t_DMLRevision,"date_released",&ERCRelDate));
													ITK_CALL(DATE_date_to_string(ERCRelDate,"%d/%m/%Y",&APLRelDateStr));
													printf("\nDML ERC Release date : %s \n",APLRelDateStr);fflush(stdout);
													
													tc_strcat(OutPutValue,APLRelDateStr);
													tc_strcat(OutPutValue,",");
													
													ITKCALL(AOM_ask_value_string(t_DMLRevision,"t5_cDRstatus",&DML_DRstatus));
													printf("\nDML_name Description is : %s \n",DML_DRstatus);fflush(stdout);

													tc_strcat(OutPutValue,DML_DRstatus);
													tc_strcat(OutPutValue,",");
												}
						
												
										    }
									    }
												
								    }
									
								}
									
							}
							
						}
						else
						{
						printf("\n NO no task found with Part");fflush(stdout);	
						}
						
					}
					else
					{
					printf("\n NO CKDVC Foundaa \n");fflush(stdout);	
					}
					tc_strcat(OutPutValue,"\n");
				}
				else
				{
					tc_strcat(OutPutValue,Filepartno);
					tc_strcat(OutPutValue,",Not found in UA,,,,,,,,,,,\n");
				}
	}
}
else
	{
		tc_strcat(OutPutValue,"File size is zero,,,,,,,,,,,,");
	}

	
	*((char **) retValue) = 	(char *) MEM_alloc( (strlen(OutPutValue ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), OutPutValue); 
	
	return ifail;
	
}

extern int CKD_VC_DMLReportRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	int nargs = 1;
	int retValueType;
	

	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE ;	
	
	retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
///	printf("\n CKD_VC_DMLReportServiceFnc before....CKD_VC_DMLReportServiceCall1111111111");fflush(stdout);  
	ifail=USERSERVICE_register_method("CKD_VC_DMLReportServiceFnc",(USER_function_t)CKD_VC_DMLReportServiceFnc,nargs,inputArgTypes,retValueType);
 
	
	return ifail;
	
}

extern int CkdReportServiceFn()
{
	printf("\ninside CkdReportServiceFn");fflush(stdout);
	int ifail = ITK_ok;
	
	int nargs = 1;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );

	inputArgTypes[0] = USERARG_TAG_TYPE;

	retValueType = USERARG_STRING_TYPE;
	//retValueType = USERARG_ARRAY_TYPE;
	
//	printf("\n CKD_report before....");fflush(stdout);  
	ifail=USERSERVICE_register_method("CallUpReport",(USER_function_t)CallUpReport,nargs,inputArgTypes,retValueType);
	ifail=USERSERVICE_register_method("CallTagReport",(USER_function_t)CallTagReport,nargs,inputArgTypes,retValueType);
	return ifail;
	
}
extern int CKD_DML_CKIMP_Report_ServiceFn1()
{
	//printf("\n hereeeeeeee");fflush(stdout);  
	
	int ifail = ITK_ok;
	int nargs = 1;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_TAG_TYPE; // Platform Revision Tag
	//inputArgTypes[1] = USERARG_TAG_TYPE; // Variant Rule Tag
	retValueType = USERARG_TAG_TYPE+USERARG_ARRAY_TYPE; // this will be output for modules 
	//printf("\n CKD_DML_CKIMP_Report_Service before USERSERVICE_register_method version 1.8");fflush(stdout);  
	ifail=USERSERVICE_register_method("CKD_DML_CKIMP_Report_Servicefunc",(USER_function_t)CKD_DML_CKIMP_Report_Servicefunc,nargs,inputArgTypes,retValueType);
//	printf("\n expandPlatform_Module AfterUSERSERVICE_register_method version 1.8");fflush(stdout);
	
	return ifail;
	
}

extern int CkdErcVCReportFn()
{
	printf("\n Inside Akhilesh...");fflush(stdout);
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	int n_args = 1;
	int ret_value_type;
	int input_arg_type[1]={0};
	//input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	input_arg_type[0]=USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	ret_value_type = USERARG_STRING_TYPE;
 	
	//printf("\n CkdErcVCReportFn: Before registering CkdErcVCReport userservice...");  fflush(stdout);
	ifail=USERSERVICE_register_method("CkdErcVCReport",(USER_function_t)CkdErcVCReport,n_args,input_arg_type,ret_value_type);
	//printf("\n CkdErcVCReportFn: After registering CkdErcVCReport userservice....");  fflush(stdout);
	return ifail;
}


extern int AllCKDReportServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	CALLAPI(CKD_VC_DMLReportRegisterServiceFnc());
	CALLAPI(CkdReportServiceFn());
	CALLAPI(CKD_DML_CKIMP_Report_ServiceFn1());
	CALLAPI(CkdErcVCReportFn());
	
	
	return ifail;
	
}


extern DLLAPI int tm_CKDReports_register_callbacks ()
{
	//printf("\n tm_CKDReports_register_callbacks....");  
	int ifail    = ITK_ok;
	//printf("\n Before registering userservice for CKD Reports....");   
	ifail=CUSTOM_register_exit ( "tm_CKDReports", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllCKDReportServiceFnc);
	//printf("\n After registering userservice for CKD Reports....");
	return ( ITK_ok );
}
