
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_MBPAReportMail.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   28-02-2025
* ENVIRONMENT	:   ITK
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change

* -----------------------------------------------------------------------------
*
*****************************************************************************/
//#include <tc/tc.h>
//#include <itk/mem.h>
//#include <base_utils/ResultCheck.hxx>
//#include <base_utils/IFail.hxx>
//#include <base_utils/DateTime.hxx>
//#include <epm/releasestatus.h>

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <pom/pom/pom_errors.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <mld/journal/journal.h>
#include <tccore/grmtype.h>
#include <tccore/releasestatus.h>
#include <ae/dataset.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)

//////

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPIMBPA(expr)ITK_CALL_MBPA(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL_MBPA(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

                                                \
	    
#define ITK_err (EMH_USER_error_base+3)


//using namespace std;

int tm_MBPAReportMailSend(void *return_data)
{
	int ifail = ITK_ok;
	int		status;

	char*   plantNameStr         	 = NULL;
	tag_t   dataset         	     = NULLTAG;

	char*	Filename		= NULL;
	char*	FileLoc			= NULL;

	//Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );

	USERARG_get_string_argument(&plantNameStr);
	USERARG_get_tag_argument(&dataset);
	USERARG_get_string_argument(&Filename);
	
	
	printf("\n plantnamestr => %s\n",plantNameStr);fflush(stdout);
	//printf("\n Username => %s\n",Username);fflush(stdout);
	//printf("\n RoleName => %s\n",RoleName);fflush(stdout);

	//CALLAPIMBPA(POM_get_user_id(&loginuser));
	//printf("\n loginuser => %s\n",loginuser); fflush(stdout);
	
	
	tc_strcpy(FileLoc,"/tmp/");
	tc_strcat(FileLoc,Filename);
	printf("\n FileLoc: %s \n", FileLoc);fflush(stdout);

	
	ifail = AE_export_named_ref(dataset, "PDF_Reference", FileLoc);

	/******creating the File for writting ********/
    char    *qry_entryCntrl2[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl2[3]= {"MBPAMAILEXE",plantNameStr,"0"};
	
    tag_t qryTagCntrl2				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags2	= NULLTAG;

	int n_entryCntrl2		  = 3;
	int control_number_found2 = 0;;

	CALLAPIMBPA(QRY_find2("Control Objects...", &qryTagCntrl2));
	if (qryTagCntrl2)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPIMBPA(QRY_execute(qryTagCntrl2, n_entryCntrl2, qry_entryCntrl2, qry_valuesCntrl2, &control_number_found2, &list_of_WSO_cntrl_tags2));

		printf("\n control_number_found1 is : %d\n",control_number_found2);fflush(stdout);
	}
	char* t5_Userinfo2 = NULL;
	if(control_number_found2>0)
	{
		printf("\n Control Object Based Execution New1.1 \n");fflush(stdout);

		tag_t MBPA_obj = list_of_WSO_cntrl_tags2[0];
		CALLAPIMBPA(AOM_ask_value_string(MBPA_obj,"t5_Userinfo1",&t5_Userinfo2));
	}	
	
	
	// Control Object for Calling EXE // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"MBPAMailIDList",plantNameStr,"0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	CALLAPIMBPA(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPIMBPA(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Control Object Based Execution New1.1 \n");fflush(stdout);

	    char* t5_Userinfo1 = NULL;
		char cmd[1000];

		tag_t Mail_obj = list_of_WSO_cntrl_tags1[0];
		CALLAPIMBPA(AOM_ask_value_string(Mail_obj,"t5_Userinfo1",&t5_Userinfo1));
		printf("\n t5_Userinfo1 => %s \n",t5_Userinfo1);fflush(stdout);
		printf("\n FileLoc => %s \n",FileLoc);fflush(stdout);
		sprintf(cmd,"%s %s %s %s",t5_Userinfo2,FileLoc,t5_Userinfo1,Filename);//
		
		
		//sprintf(cmd,"mail -s MBPA for %s -a %s -c ss925791.ttl@tatamotors.com,dkk04042.ttl@tatamotors.com <",filename,FileLoc,t5_Userinfo1,);//MBPA fot the File Name
		printf("\n MBPA Inputs => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\nAfter executing Command for MBPA Mail \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for MBPA Mail \n");fflush(stdout);
	}	
	return ifail;
}

//

extern int MBPAReportServiceinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 

	int nargs = 3;
	int retValueType;
	int inputArgTypes[3] = {0};
	
	printf("\n ############ After Rigister MBPAReportServiceinitmodule");fflush(stdout);	
	
	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	inputArgTypes[1] = USERARG_TAG_TYPE; 
	inputArgTypes[2] = USERARG_STRING_TYPE;
	
	retValueType = USERARG_STRING_TYPE ; 
	
	printf("\n MBPAReportServiceinitmodule before...");fflush(stdout);  
	ifail=USERSERVICE_register_method((char *)"tm_MBPAReportMailSend",(USER_function_t)tm_MBPAReportMailSend,nargs,inputArgTypes,retValueType);	

	

	return ifail;	
}

extern DLLAPI int tm_MBPAReportMail_register_callbacks()
{	
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....tm_MBPAReportMail");fflush(stdout);   
	
	ifail=CUSTOM_register_exit ( "tm_MBPAReportMail", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)MBPAReportServiceinitmodule);
	printf("\n After registoring userservice....tm_MBPAReportMail");fflush(stdout);
	return ( ITK_ok );
}
