/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Deepti Meshram
*  Module		 :   TCUA DataSet Uploader for APL Org Part
*  Code			 :   t5APLPartDataSetAttachement.c
*  Created on	 :   March 29th, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100



extern int ITK_user_main (int argc, char ** argv )
{

    int status;

        int                                             result                                                                          = 0;
        int                                             count                                                                           = 0;
        int                                             iCounter1                                                                       = 0;
        int                                             i                                                                                       = 0;
        char                                    *value                                                                          = NULL;
        char                                    *argstring1                                                                     = NULL;
        char                                    *argstring2                                                                     = NULL;
        char                                    *argstring3                                                                     = NULL;

        char                                    *user                                                                   = NULL;
        char                                    *pass                                                                   = NULL;
        char                                    *group                                                                  = NULL;
        char                                    *RefNo                                                                  = NULL;

        char                                    *itemId                                                                         = NULL;
        char                                    *BomType                                                                                = NULL;
        char                                    *revisionID                                                                     = NULL;
        char                                    *ItmSeqID                                                                       = NULL;
        char                                     JTFile[256];
        char                                    *JTFileDesc                                                                     = NULL;
        char                                    *JTFileSeq                                                                      = NULL;
        char                                    *CreatedDate                                                            = NULL;
        char                                    *ModifyDate                                                                     = NULL;
        char                                    *fullPath                                                                       = NULL;
        char                                    *VaultLocation                                                          = NULL;
        char                                    *HostName                                                                       = NULL;
        char                                    *Owner                                                                          = NULL;
        char                                    *ProjectCode                                                            = NULL;
        char                                    *vault                                                                          = NULL;
        char                                    *InDatabase                                                                     = NULL;
        char                                    *Randomized                                                                     = NULL;
        char                                    *Superseded                                                                     = NULL;
        char                                    *Frozen                                                                         = NULL;
        char                                    *LifeCycleState                                                         = NULL;
        char                                    *FileStatus                                                                     = NULL;
        char                                    *Externallymanaged                                                              = NULL;
        char                                    *FileRegisteredBy                                                       = NULL;
        char                                    *ShadowCopy                                                                     = NULL;
        char                                    *Categoryname                                                           = NULL;
        char                                    *Sitename                                                                       = NULL;
        char                                    *WorkingFileName                                                        = NULL;
        char                                    *WorkingpathFormat                                                              = NULL;
        char                                    *BulkdataLocation                                                       = NULL;

        char                                    *Bulkdata                                                                       = NULL;
        char                                    *DataBasename                                                           = NULL;
        char                                    *PartSequence                                                           = NULL;

        char                                    *Status                                                                         = NULL;
        char                                    *relation_input                                                         = NULL;
        char                                    *file_type                                                                      = NULL;

        char                                    *error_Text                                                                     = NULL;
        tag_t                                   JTDataset                                                                       = NULLTAG;
        tag_t                                   relation_JTDataset                                                              = NULLTAG;

        char                                    line[500]                                                                       = {'\0'};
        FILE                                    *input                                                                          = NULL;
        char                                    *object_type                                                            = NULL;
        char                                    *relation_form                                                          = NULL;
        tag_t                                   t_item                                                                          = NULLTAG;
        tag_t                                   revision                                                                        = NULLTAG;
        tag_t                                   *status_list                                                            = NULLTAG;
        tag_t                                   release_status                                                          = NULLTAG;
        tag_t                                   revstatus                                                                       = NULLTAG;
        int                                             x                                                                                       = 0;
        int                                             ref_count;
        tag_t                                   datasettype                                                                     = NULLTAG;
        tag_t                                   Newdataset                                                                      = NULLTAG;
        tag_t                                   tool                                                                            = NULLTAG;
        tag_t                                   filetag                                                                         = NULLTAG;
        char                                    **ref_list;
        char                                    pathbuff[1000];
    char                                        *creation_date                                                          = NULL;
        char                                    *text                                                                           = NULL;
        tag_t                                   datasetAvl                                                                      = NULLTAG;
        IMF_file_t                              fileDescriptor;
        AE_reference_type_t             tagRefType                                                                      = 1;
        int                                             iCountSecondary                                                                 = 0;
        tag_t                                   *secondaryObjects                                                       = NULL;

        date_t                              test                                                                                = NULLDATE;
        date_t                                  test1                                                                       = NULLDATE;
        char                                    *o                                                                                  = NULL;
        char                                    result1 [ 10000 ] ;
        char                                     result2 [ 10000 ] ;
        char                                    *f                                                                                      =NULL;

        char                                    *test11                                                                         =NULL;
        char                                    *test12                                                                         =NULL;
        char                                    *test13                                                                         =NULL;
        char                                    *JTid                                                                           =NULL;
        char                                    *JTid1                                                                          =NULL;
        char                                    *itemId12                                                                               =NULL;
        char                                    *itemId123                                                                              =NULL;
        char                                    *Creator                                                                        =NULL;
        char                                    *aDatasetId                                                                     =NULL;
        char                                    *aDatasetRev                                                                    =NULL;
        char * parent_name ;
        char * Owne_site ;
        char * dataset_name ;
        char * parent_revision_id ;
        int parent_sequence_id ;
        int ItmSeqID_int ;

        tag_t   aDataset =NULLTAG;


        int ii,itemcount,j=0;
        int sPartNumberTokint=0;
        int c,t=0;
        tag_t item=NULLTAG;
        tag_t *rev=NULLTAG;
        char *format=NULL;
        char *StrWeightArrayMain1=NULL;
        tag_t relation_type, relation;

        char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
		char **values = (char **) MEM_alloc(2 * sizeof(char *));

        char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

        char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
        char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

        tag_t  reln_type = NULLTAG;
        int    n_attchs =0;
        int    Flag_1 =0;
        GRM_relation_t *rellist;
        tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
        tag_t Fndrelation = NULLTAG;
        int nameRef_cnt;
        tag_t *namRefObject = NULL;
		int  * nFound;
		int   nlFound;
		int   ds;
		int   ass = 0;
		tag_t **  datasets;
        int ref_count_d=0;


        int n_tags_found = 0;
        tag_t query = NULLTAG;
        tag_t   master          =       NULLTAG;
        tag_t *cntr_objects = NULL;
        tag_t   *t_item1                =       NULLTAG;
        tag_t   latestrev       =       NULLTAG;
        int n_entries = 2;
        int n_found = 1;
        int dd = 0;
        int org_seq_id_int=0;
        char *inputfile=NULL;
        tag_t *tags_found = NULL;
        char* inputline=NULL;
        tag_t   queryTag        = NULLTAG;
        int resultCount=0;
        tag_t item_tag = NULLTAG;
        char
                *qry_entries4[2] = {"Revision","ID"},
        *qry_values4[2] = {"*","*"};
        char *itemRevSeq = NULL;

        char *drawingnumber;
        FILE* fp=NULL;
        char *drawingtype;
       // char *relationstr;
        char *user_data_1;
        char  type_name[TCTYPE_name_size_c+1];
		char object_name[TCTYPE_name_size_c+1] ;
        tag_t *namRefObject_d = NULL;

		char *DataSetNm2 = NULL;
        char *DataSetNm = NULL;
        char *qry_entries[2] = {"Item ID","Revision"};

        char
        *qry_entries3[1] = {"ID"},
        *qry_values3[1] = {"*"};



        inputfile = ITK_ask_cli_argument("-i=");

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
        printf("\n Auto login ");fflush(stdout);
        //ITK_CALL(ITK_auto_login( ));
		ITK_CALL(ITK_init_module("hrb293377","XYT1ESA","APLCAR"));
		ITK_CALL(ITK_set_journalling( TRUE ));
        printf("\n Auto login .......");fflush(stdout);


        fp=fopen(inputfile,"r");
        if(fp!=NULL)
        {
                inputline=(char *) MEM_alloc(500);
                while(fgets(inputline,500,fp)!=NULL)
                {
                        fputs(inputline,stdout);
                        BomType=strtok(inputline,"^");  //1
                        itemId=strtok(NULL,"^");  //2
                        revisionID=strtok(NULL,"^"); //3
                        ItmSeqID=strtok(NULL,"^"); //4
                        JTid1=strtok(NULL,"^"); //5
                        fullPath=strtok(NULL,"^"); //6
                        JTFileSeq=strtok(NULL,"^"); //7
                        RefNo=strtok(NULL,"^"); //8

                        printf("itemId is --->%s\n",itemId);fflush(stdout);
                        printf("revisionID is --->%s\n",revisionID);fflush(stdout);
                        printf("Seq is --->%s\n",ItmSeqID);fflush(stdout);
                        printf("Name is --->%s\n",JTid1);fflush(stdout);
                        printf("FullPath is --->%s\n",fullPath);fflush(stdout);
                        printf("CAD Sequence is --->%s\n",JTFileSeq);fflush(stdout);
                        printf("Ref Nooooooooooooooooooooooooooooooo --->%s\n",RefNo);fflush(stdout);
                        itemId123 = NULL;
                        itemId123=(char *) MEM_alloc(50);

                        if(QRY_find("Unique RevSeq", &queryTag));
						printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
						if (queryTag)
						{
								printf("2.Found Query \n");fflush(stdout);
						}
						else
						{
								printf("Not Found Query");fflush(stdout);
						}
                        itemRevSeq = NULL;
                        itemRevSeq=(char *) MEM_alloc(50);
                        strcpy(itemRevSeq,revisionID);
                        strcat(itemRevSeq,"*");
                        strcat(itemRevSeq,ItmSeqID);
                       
						qry_values[0] = itemId ;
                        qry_values[1] = itemRevSeq ;

                        printf("  2.parent->item_id :%s: \n ",itemId);fflush(stdout);
                        printf("  2.parent->item_revision_id [%s] \n ", itemRevSeq);fflush(stdout);

                        if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
                        printf(" \n resultCount :%d:", resultCount); fflush(stdout);

                        if(resultCount>0)
                        {
                               printf("Item already exists\n");fflush(stdout);
                               for (j=0;j<resultCount;j++ )
                               {
									 printf("Item already exists111\n");fflush(stdout);
                                     item_tag = rev[j];
                                     if(RefNo != NULL)
                                     {
										printf("Item already exists122\n");fflush(stdout);
										printf("Ref Nooooooooooooooooooooooooooooooo123 --->%s\n",RefNo);
										if(tc_strstr(RefNo,"Ref") !=NULL)
                                        {
											printf("Item already exists123\n");fflush(stdout);
                                            if(strstr(JTid1,".CATDrawing")!=NULL)
                                            {
															Flag_1=0;
															ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
															printf("\nTotal n attches =%d\n",n_attchs);
															itemId12 = strtok(JTid1,".");  //1
															printf("Name is --->%s\n",itemId12);

															for (i= 0; i < n_attchs; i++)
															{
															  printf("\n Inside loop ..............");fflush(stdout);
															  //primary=secondary_objects[i];
															  primary=rellist[i].secondary;
															  ////relationstr=rellist[i].the_relation;

															  ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
															  ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
															  printf("\n Type Name:%s ..............",type_name);fflush(stdout);
															  if(strcmp(type_name,"ImanFile")==0)
																 continue;

															  result = AE_find_datasettype("CMI2Drawing", &datasettype);
															  printf("\nType found---->%d",result);fflush(stdout);

															  ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
															  printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
															  if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"CMI2Drawing") ==0)
															  {
																	result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
																	printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
																	if(ref_count_d>0)
																	{
																	Flag_1 = 1;
																	printf("\n Relationship already exist !!!!.......");fflush(stdout);
																	break;
																	} else {
																	result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
																	printf("\nGot reference list--->%d",result);fflush(stdout);

																	result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
																	printf("\nFile Imported--->%d",result);fflush(stdout);

																	result = AOM_save(filetag);
																	printf("\nFile saved--->%d",result);fflush(stdout);

																	result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
																	printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

																	AE_set_dataset_tool(primary,tool);
																	printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

																	//sPartNumberTokint = atoi(JTFileSeq);
																	//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
																	//WSOM_set_revision(primary,sPartNumberTokint);

																	printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

																	result = AOM_save(primary);
																	if(result == 0)
																			Flag_1 = 1;
																	}
															  }
															}

															if (Flag_1 == 0)
															{
	//                                                                result = AE_find_datasettype("CMI2Drawing", &datasettype);
															  result = AE_find_datasettype("CMI2Drawing", &datasettype);
															  printf("\nType found---->%d",result);fflush(stdout);

															  result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
															  printf("\nDataset created--->%s",itemId12);fflush(stdout);

															  result = AE_set_dataset_format(Newdataset, "BINARY_REF");
															  printf("\nDataset format set--->%d",result);fflush(stdout);

															  result = AE_set_dataset_tool(Newdataset,tool);
															  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

															  result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
															  printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

															  if (nameRef_cnt == 0)
															  {
															  result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
															  printf("\nGot reference list--->%d",result);fflush(stdout);

															  result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
															  printf("\nFile Imported--->%d",result);fflush(stdout);

															  result = AOM_save(filetag);
															  printf("\nFile saved--->%d",result);fflush(stdout);

															  result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
															  printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

															  AE_set_dataset_tool(Newdataset,tool);
															  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

															  //sPartNumberTokint = atoi(JTFileSeq);
															  //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
															  //WSOM_set_revision(Newdataset,sPartNumberTokint);

															  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

															  result = AOM_save(Newdataset);
															  }
															  result = GRM_find_relation_type("IMAN_reference", &relation_type);
															  printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
															  result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
															  printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
															  if(Fndrelation)
															  {
																	printf("\n\t Relation Already Exist.\n" );fflush(stdout);
															  }
															  else
															  {
															  result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
															  printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
															  result = GRM_save_relation(relation);
															  printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
															  }
															}
                                                        }

                                                        // for acad drw

                                                        if(strstr(JTid1,".dwg")!=NULL)
                                                        {
                                                               printf("Item already exists133\n");fflush(stdout);
                                                                Flag_1=0;
                                                                ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                                printf("\nTotal n attches =%d\n",n_attchs);fflush(stdout);
                                                                itemId12 = strtok(JTid1,".");  //1
                                                                printf("Name is --->%s\n",itemId12);fflush(stdout);

                                                                for (i= 0; i < n_attchs; i++)
                                                                {
                                                                  printf("\n Inside loop ..............");fflush(stdout);
                                                                  //primary=secondary_objects[i];
                                                                  primary=rellist[i].secondary;
                                                                  ////relationstr=rellist[i].the_relation;

                                                                  ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                  ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                  printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                                                  if(strcmp(type_name,"ImanFile")==0)
                                                                     continue;

                                                                  result = AE_find_datasettype("T5_AutoCADDrw", &datasettype);
                                                                  printf("\nType found---->%d",result);fflush(stdout);

                                                                  ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                  printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                  if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"T5_AutoCADDrw") ==0)
                                                                  {
                                                                        result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                        printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                        if(ref_count_d>0)
                                                                        {
                                                                        Flag_1 = 1;
                                                                        printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                        break;
                                                                        } else {
                                                                        result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                        printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                        result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                        printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                        result = AOM_save(filetag);
                                                                        printf("\nFile saved--->%d",result);fflush(stdout);

                                                                        result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                        printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                        AE_set_dataset_tool(primary,tool);
                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        //sPartNumberTokint = atoi(JTFileSeq);
                                                                        //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                        //WSOM_set_revision(primary,sPartNumberTokint);

                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        result = AOM_save(primary);
                                                                        if(result == 0)
                                                                                Flag_1 = 1;
                                                                        }
                                                                  }
                                                                }

                                                               if (Flag_1 == 0)
                                                                {
//                                                                result = AE_find_datasettype("CMI2Drawing", &datasettype);
                                                                  result = AE_find_datasettype("T5_AutoCADDrw", &datasettype);
                                                                  printf("\nType found---->%d",result);fflush(stdout);

                                                                  result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                  printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                  result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                  printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                  result = AE_set_dataset_tool(Newdataset,tool);
                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                  printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                  if (nameRef_cnt == 0)
                                                                  {
                                                                  result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                  printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                  result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                  printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                  result = AOM_save(filetag);
                                                                  printf("\nFile saved--->%d",result);fflush(stdout);

                                                                  result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                  printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                  AE_set_dataset_tool(Newdataset,tool);
                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  //sPartNumberTokint = atoi(JTFileSeq);
                                                                  //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                  //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  result = AOM_save(Newdataset);
                                                                  }
                                                                  result = GRM_find_relation_type("IMAN_reference", &relation_type);
                                                                  printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                  result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                  printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                  if(Fndrelation)
                                                                  {
                                                                        printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                  }
                                                                  else
                                                                  {
                                                                  result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                  printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                  result = GRM_save_relation(relation);
                                                                  printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                  }
                                                                }
                                                        }

                                                        if(strstr(JTid1,".pdf")!=NULL)
                                                        {
                                                                printf("Item already exists133\n");fflush(stdout);
                                                                Flag_1=0;
                                                                ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                                printf("\nTotal n attches =%d\n",n_attchs);fflush(stdout);
                                                                itemId12 = strtok(JTid1,".");  //1
                                                                printf("Name is --->%s\n",itemId12);fflush(stdout);

                                                                for (i= 0; i < n_attchs; i++)
                                                                {
                                                                  printf("\n Inside loop ..............");fflush(stdout);
                                                                  //primary=secondary_objects[i];
                                                                  primary=rellist[i].secondary;
                                                                  ////relationstr=rellist[i].the_relation;

                                                                  ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                  ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                  printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                                                  if(strcmp(type_name,"ImanFile")==0)
                                                                     continue;

                                                                  result = AE_find_datasettype("PDF", &datasettype);
                                                                  printf("\nType found---->%d",result);fflush(stdout);

                                                                  ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                  printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                  if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"PDF") ==0)
                                                                  {
                                                                        result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                        printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                        if(ref_count_d>0)
                                                                        {
                                                                        Flag_1 = 1;
                                                                        printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                        break;
                                                                        } else {
                                                                        result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                        printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                        result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                        printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                        result = AOM_save(filetag);
                                                                        printf("\nFile saved--->%d",result);fflush(stdout);

                                                                        result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                        printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                        AE_set_dataset_tool(primary,tool);
                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        //sPartNumberTokint = atoi(JTFileSeq);
                                                                        //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                        //WSOM_set_revision(primary,sPartNumberTokint);

                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        result = AOM_save(primary);
                                                                        if(result == 0)
                                                                                Flag_1 = 1;
                                                                        }
                                                                  }
                                                                }

                                                                if (Flag_1 == 0)
                                                                {
//                                                                result = AE_find_datasettype("CMI2Drawing", &datasettype);
                                                                  result = AE_find_datasettype("PDF", &datasettype);
                                                                  printf("\nType found---->%d",result);fflush(stdout);

                                                                  result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                  printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                  result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                  printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                  result = AE_set_dataset_tool(Newdataset,tool);
                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                  printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                  if (nameRef_cnt == 0)
                                                                  {
                                                                  result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                  printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                  result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                  printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                  result = AOM_save(filetag);
                                                                  printf("\nFile saved--->%d",result);fflush(stdout);

                                                                  result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                  printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                  AE_set_dataset_tool(Newdataset,tool);
                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  //sPartNumberTokint = atoi(JTFileSeq);
                                                                  //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                  //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  result = AOM_save(Newdataset);
                                                                  }
                                                                  result = GRM_find_relation_type("IMAN_reference", &relation_type);
                                                                  printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                  result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                  printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                  if(Fndrelation)
                                                                  {
                                                                        printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                  }
                                                                  else
                                                                  {
                                                                  result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                  printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                  result = GRM_save_relation(relation);
                                                                  printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                  }
                                                                }
                                                        }
                                                        // for acad drw end
                                                }
                                        }else ///// NON REFERENCE
                                        {
                                                if(strstr(JTid1,".jt")!=NULL)
                                                {
                                                    Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);

                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("DirectModel", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"DirectModel") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                 Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {

                                                                result = AE_find_datasettype("DirectModel", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                        result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);


                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);
                                                                result = AOM_save(Newdataset);

                                                                }

                                                                result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }
                                                }

                                                if(strstr(JTid1,".CATPart")!=NULL && strstr(JTid1,".cgr")!=NULL)
                                                {
                                                        printf("\n Inside loop of CATPart & .cgr1........");fflush(stdout);
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);

                                                        itemId12 = strtok(JTid1,".");  //1
                                                        strcpy(itemId123,itemId12);  //1
                                                        //strcat(itemId123,".cgr");  //1
                                                        printf("Name is --->%s\n",itemId123);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
                                                                {
                                                                  result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                  printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                  if(ref_count_d>0)
                                                                  {
                                                                  Flag_1 = 1;
                                                                  printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                  break;
                                                                  } else {
                                                                  result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                  printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                  result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                  printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                  result = AOM_save(filetag);
                                                                  printf("\nFile saved--->%d",result);fflush(stdout);

                                                                  result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                  printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                  AE_set_dataset_tool(primary,tool);
                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  //sPartNumberTokint = atoi(JTFileSeq);
                                                                  //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                  //WSOM_set_revision(primary,sPartNumberTokint);

                                                                  printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                  result = AOM_save(primary);
                                                                  if(result == 0)
                                                                        Flag_1 = 1;
                                                                  }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId123,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId123);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }

                                                         }

                                                }

                                                if(strstr(JTid1,".CATProduct")!=NULL && strstr(JTid1,".cgr")!=NULL)
                                                {
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        strcpy(itemId123,itemId12);  //1
                                                        //strcat(itemId123,".cgr");  //1
                                                        printf("Name is --->%s\n",itemId123);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId123,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId123);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }
                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }

                                                }

                                if(strstr(JTid1,".CATPart")!=NULL)
                                                {
                                                        if(strcmp(BomType,"NBOM")==0)
                                                        {
                                                                printf("\n Inside loop of CATPart & .cgr2........");fflush(stdout);
                                                                Flag_1=0;
                                                                ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                                printf("\nTotal n attches =%d\n",n_attchs);
                                                                itemId12 = strtok(JTid1,".");  //1
                                                                printf("Name is --->%s\n",itemId12);

                                                                for (i= 0; i < n_attchs; i++)
                                                                {
                                                                  printf("\n Inside loop ..............");fflush(stdout);
                                                                  printf("\n IJTid1 [%s]..............",itemId12);fflush(stdout);
                                                                  //primary=secondary_objects[i];
                                                                  primary=rellist[i].secondary;
                                                                  ////relationstr=rellist[i].the_relation;

                                                                  ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                  ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                  printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                                                  if(strcmp(type_name,"ImanFile")==0)
                                                                     continue;

                                                                  result = AE_find_datasettype("CMI2AuxPart", &datasettype);
                                                                  printf("\nType found---->%d",result);fflush(stdout);

                                                                  ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                  printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                  if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
                                                                  {
                                                                        result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                        printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                        if(ref_count_d>0)
                                                                        {
                                                                        Flag_1 = 1;
                                                                        printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                        break;
                                                                        } else {
                                                                        result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                        printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                        result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                        printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                        result = AOM_save(filetag);
                                                                        printf("\nFile saved--->%d",result);fflush(stdout);

                                                                        result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                        printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                        AE_set_dataset_tool(primary,tool);
                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        //sPartNumberTokint = atoi(JTFileSeq);
                                                                        //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                        //WSOM_set_revision(primary,sPartNumberTokint);

                                                                        printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                        result = AOM_save(primary);
                                                                        if(result == 0)
                                                                                Flag_1 = 1;
                                                                        }
                                                                  }
                                                                }

                                                        printf("\n Flag_1----> %d",Flag_1);fflush(stdout);

                                                        if (Flag_1 == 0)
                                                        {
                                                            result = AE_find_datasettype("CMI2AuxPart", &datasettype);
                                                                printf("\nType found---->11%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }

                                                                }
                                                        else ////For NON Spec files
                                                        {

                                                        //   To Stamp the Part Type to Compeonent  for CMI2Part
                                                        ITK_CALL(AOM_UIF_ask_value(item_tag,"owning_site",&Owne_site));
                                                        printf("\n Owne_site:%s ..............",Owne_site);fflush(stdout);

                                                        if(strcmp(Owne_site,"TMETC-Production")!=0)
                                                        {
                                                                printf("\n Stamping the  Part Type to component  \n");
                                                                ITK_CALL(AOM_lock(item_tag));
                                                                ITK_CALL(AOM_set_value_string(item_tag,"t5_PartType","C"));
                                                                ITK_CALL(AOM_save(item_tag));
                                                                ITK_CALL(AOM_unlock(item_tag));
                                                        }

                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("CMI2Part", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"CMI2Part") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {

                                                                result = AE_find_datasettype("CMI2Part", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                               result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }

                                                                }
                                                         }

                                                }

                                                if(strstr(JTid1,".CATProduct")!=NULL)
                                                {
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("CMI2Product", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"CMI2Product") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("CMI2Product", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }
                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }

                                                }

                                                if(strstr(JTid1,".CATDrawing")!=NULL)
                                                {
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("CMI2Drawing", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"CMI2Drawing") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("CMI2Drawing", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                result = AOM_save(Newdataset);
                                                                printf("\n Dataset seve--->%d",result);fflush(stdout);fflush(stdout);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }
                                                }

                                                // for acad drw

                                                if(tc_strstr(JTid1,".dwg")!=NULL)
                                                {
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("T5_AutoCADDrw", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"T5_AutoCADDrw") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("T5_AutoCADDrw", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                result = AOM_save(Newdataset);
                                                                printf("\n Dataset seve--->%d",result);fflush(stdout);fflush(stdout);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }
                                                }

                                                if(tc_strstr(JTid1,".pdf")!=NULL)
                                                {
                                                        Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("PDF", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"PDF") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                               Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("PDF", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                result = AOM_save(Newdataset);
                                                                printf("\n Dataset seve--->%d",result);fflush(stdout);fflush(stdout);
                                                                }

                                                                result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                                }
                                                                }
                                                }


                                                // for acad drw end

                                                if(strstr(JTid1,".asm")!=NULL)
                                                {

                                                Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                               if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("ProAsm", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"ProAsm") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("ProAsm", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }
                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                        }
                                                                }
                                                }

                                                if(strstr(JTid1,".prt")!=NULL)
                                                {

														Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
																if(strcmp(type_name,"ImanFile")==0)
                                                                   continue;

                                                                result = AE_find_datasettype("ProPrt", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"ProPrt") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                  Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("ProPrt", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }
                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                        }
                                                                }
                                                }

                                                if(strstr(JTid1,".drw")!=NULL)
                                                {

														Flag_1=0;
                                                        ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
                                                        printf("\nTotal n attches =%d\n",n_attchs);
                                                        itemId12 = strtok(JTid1,".");  //1
                                                        printf("Name is --->%s\n",itemId12);

                                                        for (i= 0; i < n_attchs; i++)
                                                        {
                                                                printf("\n Inside loop ..............");fflush(stdout);
                                                                //primary=secondary_objects[i];
                                                                primary=rellist[i].secondary;
                                                                ////relationstr=rellist[i].the_relation;

                                                                ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
                                                                printf("\n Type Name:%s ..............",type_name);fflush(stdout);
																if(strcmp(type_name,"ImanFile")==0)
                                                                continue;

                                                                result = AE_find_datasettype("ProDrw", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
                                                                printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
                                                                if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"ProDrw") ==0)
                                                                {
                                                                result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
                                                                printf("\n\t ****asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
                                                                if(ref_count_d>0)
                                                                {
                                                                Flag_1 = 1;
                                                                printf("\n Relationship already exist !!!!.......");fflush(stdout);
                                                                break;
                                                                } else {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(primary,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(primary,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(primary);
                                                                if(result == 0)
                                                                 Flag_1 = 1;
                                                                }
                                                                }
                                                        }

                                                        if (Flag_1 == 0)
                                                        {
                                                                result = AE_find_datasettype("ProDrw", &datasettype);
                                                                printf("\nType found---->%d",result);fflush(stdout);

                                                                result = AE_create_dataset_with_id(datasettype,itemId12,JTFileDesc, NULL, NULL, &Newdataset);
                                                                printf("\nDataset created--->%s",itemId12);fflush(stdout);

                                                                result = AE_set_dataset_format(Newdataset, "BINARY_REF");
                                                                printf("\nDataset format set--->%d",result);fflush(stdout);

                                                                result = AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
                                                                printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

                                                                if (nameRef_cnt == 0)
                                                                {
                                                                result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\nGot reference list--->%d",result);fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\nFile Imported--->%d",result);fflush(stdout);

                                                                result = AOM_save(filetag);
                                                                printf("\nFile saved--->%d",result);fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                //sPartNumberTokint = atoi(JTFileSeq);
                                                                //printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
                                                                //WSOM_set_revision(Newdataset,sPartNumberTokint);

                                                                printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

                                                                result = AOM_save(Newdataset);
                                                                }
                                                                result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                                                printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
                                                                printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
                                                                if(Fndrelation)
                                                                {
                                                                  printf("\n\t Relation Already Exist.\n" );fflush(stdout);
                                                                }
                                                                else
                                                                {
                                                                result = GRM_create_relation(item_tag, Newdataset, relation_type, NULLTAG, &relation);
                                                                printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
                                                                result = GRM_save_relation(relation);
                                                                printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
                                                        }
                                                                }

                                                }

                                 }
                        }
                                //}
                        }
                }
        }
        ITK_CALL(POM_logout(false));
        return status;
}
