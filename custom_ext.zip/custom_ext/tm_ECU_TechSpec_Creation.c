#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ics/ics2.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcfile_cache.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <fclasses/tc_date.h>
#include <ae/datasettype.h>
#include <cfm/cfm.h>
#include <tc/preferences.h>
//#include "participant.h"
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <time.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error6 (EMH_USER_error_base+27)
/*--------------------------------------------------*/

#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}


#define WRONG_USAGE 100001
char* subString (char* mainStringf ,int fromCharf,int toCharf);
//
void dousage()
{
   printf("\nUSAGE: t5ListEmptyVisPdfDesRev -fromDate= -toDate= -sType= -outFile= \n");
   printf("\E.g: t5ListEmptyVisPdfDesRev -fromDate=01-May-2018 -toDate=02-May-2018 -sType=CMI2Part -outFile=out.txt \n");
   return;
}

void lower_string(char s[])
{
	int c = 0;

	while (s[c] != '\0')
	{
		if (s[c] >= 'A' && s[c] <= 'Z')
		{
			s[c] = s[c] + 32;
		}
		c++;
	}
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

void EcuTechSpeccreate(char* sItemId,char* revid,char*PLATFORM,char*MODELNAME,char*CUSTOMER,char*FUEL)
{


   char *itemName=NULL;
   tag_t tRelationFind =NULLTAG;
   tag_t itemrevtag =NULLTAG;
   tag_t itemTag = NULLTAG;
   tag_t designtag = NULLTAG;
   tag_t itemrevtag2 = NULLTAG;
   tag_t Latestrev_Tag = NULLTAG;
   //tag_t tRelationExist =NULLTAG;
   tag_t tRelationExist =NULLTAG;
	   
    
	itemName=(char *)MEM_alloc(50);
	printf("\n sItemId=%s ,revid=%s, PLATFORM=%s MODELNAME=%s CUSTOMER=%s FUEL=%s ",sItemId,revid,PLATFORM,MODELNAME,CUSTOMER,FUEL);


	ITEM_find_item(sItemId, &designtag);
	ITEM_find_revision(designtag,revid,&Latestrev_Tag);


	tc_strcpy(itemName,"");
	tc_strcpy(itemName,"ECUTP");
	tc_strcat(itemName,sItemId);


	ITEM_create_item("",itemName,"T5_ECU_TSComp","",&itemTag,&itemrevtag2);
	ITEM_save_item(itemTag);
	ITEM_save_item(itemrevtag2);

	ITEM_ask_latest_rev(itemTag,&itemrevtag);

	if(itemrevtag!=NULLTAG)
	{

	  printf("\n inside value itemrevtag\n");
	 //ITK_CALL(AOM_lock(itemrevtag));
	 ITK_CALL(AOM_refresh(itemrevtag,TRUE));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_Platform",PLATFORM));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_Model",MODELNAME));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_Country",CUSTOMER));
	 ITK_CALL(AOM_UIF_set_value(itemrevtag,"t5_FuelType",FUEL));
	 ITK_CALL(AOM_save_without_extensions(itemrevtag));
	 ITK_CALL(AOM_refresh(itemrevtag,0));
	
	}

	GRM_find_relation_type("T5_Has_ECU_Tech_Spec",&tRelationFind);
	GRM_find_relation(Latestrev_Tag,itemrevtag,tRelationFind,&tRelationExist);
	GRM_save_relation(tRelationExist);



}


int getClsValueFrmECUICSTag( tag_t  IcsClsTag,char **AttrVal3,char** AttrVal1,char** AttrVal2,char **AttrVal4)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;

	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;

	char** attributeNames	= NULL;
	char** attributeValues	= NULL;


	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;
	
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	char 	*attributeValueDup3 			= NULL;
	char 	*attributeValueDup2 			= NULL;
	char 	*attributeValueDup4 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup2 = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup3 = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup4 = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;


	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	int theAttributeCount =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	char *AttrCsvName = NULL;
	tc_strcpy(attributeValueDup,"");
	tc_strcpy(attributeValueDup2,"");
	tc_strcpy(attributeValueDup3,"");
	tc_strcpy(attributeValueDup4,"");
	

	ITK_CALL( ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount>0)
	{
			for(i=0;i<theAttributeCount;i++)
			{
				TotVCAttrCount=TotVCAttrCount+theAttributeCount;

				sprintf(attrId,"%d",theAttributeIds[i]);
				//printf("\n attrId:[%s]",attrId);fflush(stdout);

				tc_strcpy(attributeNameDup,"");
				tc_strcpy(attributeNameDup,theAttributeNames[i]);

				//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

				
					
				

				for(x=0;x<theAttributeValCounts[i];x++)
				{

					if (tc_strcmp(attributeNameDup,"PLATFORM")==0)
						{

							printf("\n inide platform \n");
							tc_strcat(attributeValueDup,theAttributeValues[i][x]);
							printf("\n PLATFORM attributeValueDup value:[%s] ",attributeValueDup);fflush(stdout);


						}
						if (tc_strcmp(attributeNameDup,"MODEL NAME TO BE PRINTED ON RC")==0)
						{
							tc_strcat(attributeValueDup2,theAttributeValues[i][x]);
							printf("\n MODEL NAME TO BE PRINTED ON RC value:[%s] ",attributeValueDup2);fflush(stdout);
						}
						if (tc_strcmp(attributeNameDup,"[VC]CUSTOMER(CUSTOMER)")==0)
						{
							tc_strcat(attributeValueDup3,theAttributeValues[i][x]);
							printf("\n [VC]CUSTOMER(CUSTOMER) value:[%s] ",attributeValueDup3);fflush(stdout);
						}
						if (tc_strcmp(attributeNameDup,"[VC]FUEL(FUEL)")==0)
						{
							tc_strcat(attributeValueDup4,theAttributeValues[i][x]);
							printf("\n [VC]FUEL(FUEL) value:[%s] ",attributeValueDup4);fflush(stdout);
						}
					//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
					//tc_strcat(attributeValueDup,theAttributeValues[i][x]);
					//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
				}
				printf("\n theAttribute Name :[%s]",attributeNameDup,i);fflush(stdout);
//				printf("\n attrId:[%s]",attrId);fflush(stdout);
//				printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
				
                *AttrVal3=attributeValueDup;
				*AttrVal1=attributeValueDup2;
				*AttrVal2=attributeValueDup3;
				*AttrVal4=attributeValueDup4;

	            		

			}
			
	}

   // printf("\n attributeValueDup=%s ",attributeValueDup); fflush(stdout);
}

int techpecfunction( EPM_action_message_t msg )
{
		tag_t *ClsObjTag =NULLTAG;
		int cnt = 0;
		int sp = 0;
		int m = 0;
		int p = 0;
		int i = 0;
		int tech_count = 0;
		int progpartcount = 0;
		int noAttachment = 0;
		int Breakdowncount = 0;
        char* username = NULL;
        char* AttrKeyValue = NULL;
        char* objType = NULL;
        char* CurrentTask = NULL;
        char* parent_name = NULL;
        char* DesRevid = NULL;
        char* dmlNo = NULL;
        char* Busunit = NULL;
        char* TaskId = NULL;
        char* Userinfodup = NULL;
        char* Userinfodup2 = NULL;
        char* DMLReltypeProg = NULL;
        char* PsPartNum = NULL;
		tag_t rootTask =NULLTAG;
		tag_t Techqry_tg =NULLTAG;
		tag_t DMLRevTag =NULLTAG;
		tag_t DMLTag =NULLTAG;
		tag_t objTypTag =NULLTAG;
		tag_t tech_object1 =NULLTAG;
		tag_t ClsObj =NULLTAG;
		tag_t classitemTAG =NULLTAG;
		tag_t* BreakdowncountTags =NULLTAG;
		tag_t* attachments =NULLTAG;
		tag_t* tech_object =NULLTAG;
		//tag_t* Techqry_tg =NULLTAG;
		tag_t* ProgPartTags =NULLTAG;
		tag_t PsPartTag =NULLTAG;
		tag_t DML_tag =NULLTAG;
		tag_t Latestrev_Tag =NULLTAG;
		char*	 AttrKeyValue1		= NULL;
	    char*	 AttrKeyValue2		= NULL;
	    char*	 AttrKeyValue4		= NULL;
	    ITK_CALL(POM_get_user_id (&username));
		printf("\n Ecu_techpec Session User is : %s \n",username); fflush(stdout);
		if(QRY_find2("Control Objects...", &Techqry_tg));
		

		char *Tech_entry1[2] = {"SYSCD","SUBSYSCD"};
		char **tech_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
		tech_RelVal[0] = "Tech_Check";
		tech_RelVal[1] = "ON";

		ITK_CALL(QRY_execute(Techqry_tg, 2, Tech_entry1, tech_RelVal, &tech_count, &tech_object));
		printf("\n Tech_Check control object count1 :%d \n",tech_count);fflush(stdout);


		if(tech_count>0)
	   {

		tech_object1=tech_object[i];
		ITK_CALL(AOM_ask_value_string(tech_object1,"t5_Userinfo1",&Userinfodup));  
		printf("\n tech_object1 t5_Userinfo1:[%s]\n",Userinfodup); fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tech_object1,"t5_Userinfo2",&Userinfodup2));  
		printf("\n tech_object1 t5_Userinfo2:[%s]\n",Userinfodup2); fflush(stdout);
		

		

		if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		{

			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n Inside the Ecu_techpec Approved Condition ...\n");fflush(stdout);

			ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			printf("\n Ecu_techpec- CurrentTask: %s \n",CurrentTask);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			printf("\n Ecu_techpec- parent Name: %s \n",parent_name);fflush(stdout);

			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			printf("\n Ecu_techpec- Target Attachment:%d \n",noAttachment);fflush(stdout);


			if(noAttachment>0)
			{

			printf("\n Inside ECU_TechSpec Target Attachment:%d \n",noAttachment);fflush(stdout);
			DMLTag = attachments[0];

			ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&dmlNo));
			printf("\n Ecu_TechSpec current- DML No: [%s] \n", dmlNo);fflush(stdout);


			if(ITEM_find_item(dmlNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{
			  printf("\n DML tag is not null for ECU_TechSpec_Attach DML No: [%s] \n", dmlNo);fflush(stdout);

			  if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();

			  ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&Busunit));
			  printf("\n  Tech Busunit : [%s]\n", Busunit); fflush(stdout);

			  ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));


			    if(objTypTag!=NULLTAG)
				{
				
				 printf("\n object type found sucessfully \n");fflush(stdout);

				}


				ITK_CALL(TCTYPE_ask_name2(objTypTag,&objType));
			    printf("\n  object_type is %s\n", objType);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLReltypeProg));
				printf("\n  t5_rlstype ecu_techpec is : [%s]\n", DMLReltypeProg); fflush(stdout);

				if((tc_strcmp(Busunit,"CVBU")==0 && tc_strcmp(Userinfodup,"CVBU")==0 ) || (tc_strcmp(Busunit,"PVBU")==0 && tc_strcmp(Userinfodup2,"PVBU")==0))
				{
					printf("\n Inside business unit condition\n");fflush(stdout);


				if(tc_strcmp(objType,"ChangeRequestRevision")==0)   //IMAN_reference
				{

					ITK_CALL(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&Breakdowncount,&BreakdowncountTags));
					printf("\n Task count %d \n",Breakdowncount);fflush(stdout);

					if (Breakdowncount>0)
					{
						for (m=0;m<Breakdowncount;m++)
						{
							ITK_CALL(AOM_ask_value_string(BreakdowncountTags[m],"item_id",&TaskId));
							printf("\n Tech DML Task [%s]",TaskId);fflush(stdout);

							if(tc_strcmp(DMLReltypeProg,"Veh")==0)
							{

									if (tc_strstr(TaskId,"_00")==NULL)
									{
										printf("\n Tech Skipping Skip for other DML Task [%s] \n",TaskId);fflush(stdout);
										continue;
									}
									
									
									printf("\n Inside dmltype Veh prog\n"); fflush(stdout);
									ITK_CALL(AOM_ask_value_tags(BreakdowncountTags[m],"CMHasSolutionItem",&progpartcount,&ProgPartTags));
									printf("\n CMHasSolutionItem count Task111 [%d] \n",progpartcount);fflush(stdout);

									if(progpartcount>0)
								    {

										for(sp=0;sp<progpartcount;sp++)
										{
											printf("\n Inside progpartcount\n"); fflush(stdout);

										  PsPartTag=ProgPartTags[sp];

										   ITK_CALL(AOM_ask_value_string(PsPartTag,"item_id",&PsPartNum));
										   ITK_CALL(ITEM_find_item(PsPartNum,&classitemTAG));
										   if (classitemTAG!=NULLTAG)
										   {

											   printf("\n tech item found \n");

										   }
										   else
										   {
										      printf("\n tech item found \n");
										   }
										   ITK_CALL(AOM_UIF_ask_value(PsPartTag,"item_revision_id",&DesRevid));
									       
						

											ITK_CALL(AOM_ask_value_tags(classitemTAG,"IMAN_classification",&cnt,&ClsObjTag));

											printf("\n Count of classification object %d \n",cnt);fflush(stdout);

											if(cnt == 0)
											{
													continue;
											}
											else 
											{
												ClsObj=*ClsObjTag;

												ITK_CALL(getClsValueFrmECUICSTag(ClsObj,&AttrKeyValue,&AttrKeyValue1,&AttrKeyValue2,&AttrKeyValue4));
				                                printf("\n AttrKeyValue11=%s ,AttrKeyValue1=%s, AttrKeyValue2=%s AttrKeyValue4=%s ",AttrKeyValue,AttrKeyValue1,AttrKeyValue2,AttrKeyValue4);
												EcuTechSpeccreate(PsPartNum,DesRevid,AttrKeyValue,AttrKeyValue1,AttrKeyValue2,AttrKeyValue4);
											}

										   

										}


									
									
									
									  }



							}
						
						
						
						
						}
					
					
					
					
					}





				}
			}
			
			
			
			
			}







		}
		}
	   }

	   printf("\n tech code end \n");fflush(stdout);



		return 0;


}

//int fetch_TechSpec_details(tag_t DMLTag)
//{
//	int  ifail   = ITK_ok;
//	char* dml_no = NULL;
//	char* DMLItemRev = NULL;
//	tag_t DMLrevDML = NULLTAG;
//
//		if (DMLTag == NULLTAG) 
//		{
//			printf("ERROR: DML tag is NULL.\n");
//			return ITK_general_error;
//		}
//
//	ITEM_ask_latest_rev(DMLTag,&DMLrevDML);
//	
//	ITK_CALL(AOM_ask_value_string(DMLrevDML, "item_id", &dml_no));
//    printf("INFO: Fetching TechSpec for DML [%s]\n", dml_no);
//    MEM_free(dml_no);
//
//	ITK_CALL(AOM_ask_value_string(DMLrevDML,"item_revision_id",&DMLItemRev));
//	printf("\n DMLItemRev: %s ", DMLItemRev);fflush(stdout);
//
//}


extern int register_tm_ECU_TechSpec_Creation(int *decision, va_list args)
{


    if( ITK_ok == EPM_register_action_handler("Ecu_techpec", "Ecu_techpec", techpecfunction))
   {
		printf("\n Registered Action Handler Ecu_techpec \n");fflush(stdout);
   }
   else
   {
		printf("\n FAILED to register Action Handler Ecu_techpec\n");fflush(stdout);
   }

}


extern DLLAPI int tm_ECU_TechSpec_Creation_register_callbacks()
{
     CUSTOM_register_exit("tm_ECU_TechSpec_Creation", "USER_init_module", (CUSTOM_EXIT_ftn_t)register_tm_ECU_TechSpec_Creation);

    printf("\n tm_ECU_TechSpec_Creation Creation of Dataset \n");

	 return ( ITK_ok );
}