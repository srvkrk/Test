#ifndef IMAN_HEADER_H
#define IMAN_HEADER_H
// !USER_EXIT_H

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>
#include <unistd.h>
#include <errno.h>

#include <tccore/aom.h>
#include <tccore/grmtype.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/method.h>
#include <tccore/aom_prop.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/typecannedmethod.h>
#include <tccore/item_msg.h>
#include <tccore/wso_msg.h>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <tccore/iman_msg.h>

#include <pie/pie.h>
#include <pie/pie_errors.h>

#include <ae/ae.h>
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <form/form.h>
#include <pom/pom/pom.h>
#include <epm/cr.h>
#include <ss/ss_const.h>
#include <user_exits/user_exits.h>
#include <bom/bom.h>
#include <fclasses/tc_date.h>
#include <user_exits/user_exits.h>
#include <ict/ict_userservice.h>
#include <user_exits/aiws_ext.h>
#include <ss/ss_errors.h>
#include <itk/bmf.h>
#include <user_exits/user_exit_msg.h>
#include <epm/epm.h>
#include <ict/ict_userservice.h>
#include <user_exits/aiws_ext.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <property/nr.h>
#include <lov/lov.h>
#include <res/reservation.h>
#include <form/form.h>
#include <sa/imanfile.h>
#include <lov/lov_msg.h>
#include <ug_va_copy.h>
#include <time.h>
#include <tc/lm.h>
#include <tc/log.h>
#include <tc/wsouif_errors.h>
#include <tc/iman_arguments.h>
#include <tc/emh.h>
#include <tc/preferences.h>
#include <tc/iman.h>
#include <tc/folder.h>
#include <time.h>
#include <tccore/grm_msg.h>
#define EXIT_FAILURE 1


#define ALL_CUSTOMIZATIONS 2 
#define ONLY_CURRENT _CUSTOMIZATION 1     
#define NO_CUSTOMIZATIONS 0

#define ITK_err 919002
#define EPM_DCR_NOTFOUND EMH_USER_error_base+21
#define EPM_TASK_NOTFOUND EMH_USER_error_base+22
#define ITEM_NOTMATCH  EMH_USER_error_base+23
#define ITEMS_NOTFOUND_DCR  EMH_USER_error_base+24
#define ITEMS_NOTFOUND_DML  EMH_USER_error_base+25
#define DML_REVISION_NOT_FOUND  EMH_USER_error_base+26
#define CONTROL_OBJ_NOT_FOUND  EMH_USER_error_base+27
#define DR_NOT_MATCH  EMH_USER_error_base+28
#define PO_BASIC_VALI  EMH_USER_error_base+29
#define SVR_WrkFlw_error EMH_USER_error_base+30
#define PLM_error EMH_USER_error_base+31
#define PLM_error1 EMH_USER_error_base+31
#define VC_WrkFlw_error EMH_USER_error_base+32
#define VC_error EMH_USER_error_base+33
#define VC_Not_error EMH_USER_error_base+34
#define ITK_errStore EMH_USER_error_base+34

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

int Create_occ_effectivity(tag_t,tag_t,tag_t);
int Create_occurance_effectivity(tag_t,tag_t,date_t, date_t,char *);
int Delete_occurance_effectivity(tag_t,tag_t,char *,char *);
int Create_MR_occurance_effectivity(tag_t,char*,char*);
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		for( index=0; index<n_ifails; index++)
		{
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(2000);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

#endif