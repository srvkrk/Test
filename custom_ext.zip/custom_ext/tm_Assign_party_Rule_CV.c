/***************************************************************************
	* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Rule Handler for PO check Manager validations to check NOPO parts avalability..
*  Code                 :   tm_Assign_party_Rule_CV.c
*  Created on			:   12/04/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1		20/05/2024					Mohan Tayade		Check all eligible reviewers are assigned.	
***************************************************************************/

#include "TMLLibrary_server_exits.h"


char * 	ESOattrValue =NULL;

EPM_decision_t tm_Assign_party_Rule_CV(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int CEReviewerFlag=  0;
	int no_attach	=  0;
	char*   ObjTypp=NULL;
	tag_t	objTypTagg		= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	char*	CurrentTask				=NULL;
	const char*   Axle_Peer_role = "Peer_AXLE_W_T_Reviewers_CV";
	const char*   CAB_Peer_role = "Peer_CAB_Reviewers_CV";
	const char*   Chassis_Peer_role = "Peer_Chassis_Design_CV";
	const char*   E_and_E_Peer_role = "Peer_E_and_E_Reviewers_CV";
	const char*   Engine_Peer_role = "Peer_Review_Engine_CV";
	const char*   Brakes_Peer_role = "Peer_Brake_Reviewers_CV";
	const char*   PTrain_Peer_role = "Peer_Power_TrainInt_Reviewers_CV";
	const char*   Steering_System_Peer_role = "Peer_Steering_System_Reviewers_CV";
	const char*   Suspenssion_Peer_role = "Peer_Suspension_Reviewers_CV";
	const char*   Gearbox_Peer_role = "Peer_Aux_GearBox_Reviewers_CV";
	tag_t	DmlTask_tag		= NULLTAG;
	int     CRBcunt		=  0;
	int     Tskcout		=  0;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	logical is_Tsklatst;
	logical is_Tskletst;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t	TskCRBTag	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* primaryobjs = NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	char *sDMLrlstype = NULL;
	char	*Task_name		= NULL;
	char *DMLtype = NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t	TechSpecObjTag   = NULLTAG;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass = NULL;
	char*	ProjDesc = NULL;
	char*	TechSpecNum = NULL;
	char*	VCBusUnit = NULL;
	char*	Proj_PltFrm = NULL;
	char*	VCBusUnitDup = NULL;
	tag_t	item_tag		= NULLTAG;
	int t =0;
	int b =0;
	int jtsk =0;
	int ii =0;
	int jkk =0;
	int TScount =0;
	int DsgGrpcount =0;
	tag_t   PRDqryTag     = NULLTAG;
	tag_t   DMLqryTag     = NULLTAG;
	int     DsgGrup = 0;
	char	*DsgGrp			= NULL;
	char	*Tsk_class		= NULL;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	objTag		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	char	*DMLNo		= NULL;
	char	*TskReviewr		= NULL;
	char	*DML_info1		= NULL;
	char	*DML_info2		= NULL;
	char	*DML_info3	= NULL;
	char	*DML_info4	= NULL;
	char	*DML_info6	= NULL;
	char	*DML_info7	= NULL;
	char	*DML_info8	= NULL;
	char	*DML_info9	= NULL;
	char	*sPlntToPlnt	= NULL;
	char*   type_name8=NULL;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t*  DRAna			= NULLTAG;
	tag_t*  CertiAna			= NULLTAG;
	tag_t*  CEAna			= NULLTAG;
	tag_t	DRAna_Patri_Type	= NULLTAG;
	tag_t	CertiAna_Patri_Type	= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	tag_t	DRAna_Party		= NULLTAG;
	tag_t	CertiAna_Party		= NULLTAG;
	tag_t   NPIparty	        = NULLTAG;
	tag_t   NPIpartytag	        = NULLTAG;
	tag_t   role_tag	        = NULLTAG;
	char*	DMLType = NULL;
	char*	DML_BU = NULL;
	char*	ProjectID = NULL;
	char*	DMLDrStat = NULL;
	char*	DMLVertical = NULL;
	char*	DMLDesignGrp = NULL;
	char **DesignGroupList;
	char*	DMLReason = NULL;
	char*	DML_CE_Group = NULL;
	char*	Proj_BU = NULL;
	char*   groupName			    = NULL;
	char*   item_id				    = NULL;
	char	*DR_Gateway_Role		= NULL;
	char	*CertiFication_Role		= NULL;
	char	*DRgroupNameCV		= NULL;
	char	*groupNameCV		= NULL;
	char	*Part_prj		= NULL;
	char	*DesgTyp		= NULL;
	char	*Part_no		= NULL;
	char	*PartTyp		= NULL;
	char	*PRD_info4		= NULL;
	char	*PRD_info3		= NULL;
	char	*PRD_info2		= NULL;
	char	*PRD_info1		= NULL;
	char	*sPrtColInd		= NULL;
	char	*rel_status		= NULL;
	char	*rev_idd		= NULL;
	char	*Partno		= NULL;
	char	*Prtrev_idd		= NULL;
	char	*DML_info10		= NULL;
	char	*DMLReviewr		= NULL;
	char	*relation_name		= NULL;
	tag_t	PartypObj		= NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t   *reviewertag	= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	int     No_Peer = 0;
	int CRBcount = 0;
	int     CertiFlag = 0;
	int     kk = 0;
	int     ik = 0;
	int     jk = 0;
	int     Taskcout = 0;
	int     prt = 0;
	int     PltFrmPartFlg = 0;
	int     No_CertiAna = 0;
	int     No_DRAna = 0;
	int     No_CEAna = 0;
	int		partcnt = 0;
	int		resultCount = 0;
	int		FirstTimeVehFlag = 0;
	int		FourthCodition = 0;
	int		SixthCondition = 0;
	int		PassFlag = 0;
	int		DRPassFlag = 0;
	int		fivethCondition = 0;
	int		DRGateWayVehFalg = 0;
	int		DRGateWayFalg = 0;
	int		Item_count = 0;
	int		DsgN = 0;
	int		FirstTimeFlag = 0;
	int     cnt_ccvcls      =  0;
	int     noOfreviewer    =  0;
	tag_t *ClsObjTag= NULLTAG;
	tag_t  	master =	NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t ObjTypDmlCRB = NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t *DmlCRB = NULLTAG;
	tag_t DmlCRBTag = NULLTAG;
	tag_t   ClsObj     = NULLTAG;
	logical is_Tskltst;
	tag_t   DRGrp_tag			= NULLTAG;
	tag_t   CertiGrp_tag			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   DMLTag		= NULLTAG;
	tag_t   DRAnalyst_tag		= NULLTAG;
	tag_t   relation_type_tag		= NULLTAG;
	tag_t   CertiAnalyst_tag		= NULLTAG;
	tag_t   group_tag		= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t   *TskRevn_tag    =  NULLTAG;
	char	*BomAna_Role		= NULL;
	char	*info3		= NULL;
	char	*info2		= NULL;
	char	*info1		= NULL;
	tag_t   *PartsTag    =  NULLTAG;
	char*   sPartObjyp=NULL;
	char*   type_name7=NULL;
	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	tag_t   *PRD_CntrlObjectTag      = NULLTAG;
	char*   Tsk_Typ=NULL;
	tag_t   qryTag     = NULLTAG;
	int     PRDFlag =  0; 
	int     FirstTimeTPLFlag =  0; 
	int     rsltCount      =  0; 
	int     iESOAppliFlag =  0; 
	int     iESOAppliValue =  0; 
	int     DMUtaskflag =  0; 
	int     CVPeerFlag      =  0;
	int     DML_rsltCount      =  0;
	int     PRD_rsltCount      =  0;
	int     DML_n_entry    = 1;
	int     PRD_n_entry    = 1;
	int     n_entry    = 1; 
	char*	 Prtobj_type = NULL;
	char*	 Prtobj_typee = NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	tag_t   *CntrlObjectTag      = NULLTAG;
	char    *DML_qry_entry[1]  = {"SYSCD"};
	char    *PRD_qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **DML_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **PRD_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	sDMLrlstype=(char *)MEM_alloc(20);
	DML_CE_Group = (char	*)MEM_alloc(100);
	char cCurrentAccessDate[20]={0};
	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group_CV");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_Assign_party_Rule_CV Function started...");fflush(stdout);
	TC_write_syslog("\n tm_Assign_party_Rule_CV Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n ADPR:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n ADPR:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n ADPR::No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			objTag=taskAttachments[i];
			if(TCTYPE_ask_object_type(objTag,&objTypTagg));
			if(TCTYPE_ask_name2(objTypTagg,&ObjTypp));
			printf("\n ADPR:: Workfow obj type: [%s]\n", ObjTypp);fflush(stdout);
			if(tc_strcmp(ObjTypp,"ChangeRequestRevision")==0)
			{
				//Control Table for Assign dynamic party
				printf("\n ADPR:P1:.Control Table for Assign dynamic party....\n"); fflush(stdout);
				if(QRY_find2("ControlObjects", &DMLqryTag));
				if (DMLqryTag)
				{
					printf("\n ADPR:P2:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n ADPR:P3:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DML_qry_values2[0] = "CVDMLASG";
				if(QRY_execute(DMLqryTag, DML_n_entry, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
				printf(" \n ADPR:P4:DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
				if(DML_rsltCount > 0)
				{
					//CV ONOFF
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo1",&DML_info1)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info1 is.:[%s]\n", DML_info1);fflush(stdout);
					//CV All eligible DML Types: ,TSKR,MR,TODR,EP,RBQU,Veh,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo2",&DML_info2)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info2 is.:[%s]\n", DML_info2);fflush(stdout);
					//CV DML All BU: ,CVBU,CV-PSE,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo3",&DML_info3)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info3 is.:[%s]\n", DML_info3);fflush(stdout);
					//Certification BU :,CVBU,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo4",&DML_info4)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info4 is.:[%s]\n", DML_info4);fflush(stdout);
					//CV DML types for DR-Gate Way Reviewer.:,TODR,MR,TSKR,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo6",&DML_info6)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info6 is.:[%s]\n", DML_info6);fflush(stdout);
					//CV Part types for DR-Gate Way Reviewer.:,M,A,C,G,T,V,VC,CCVC,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo7",&DML_info7)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info7 is.:[%s]\n", DML_info7);fflush(stdout);
					//DML reason for DR gate way reviewer and CE Reviewer:
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo8",&DML_info8)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info8 is.:[%s]\n", DML_info8);fflush(stdout);
					//CE Reviewer DML types: ,TSKR,MR,TODR,EP,RBQU,Veh,
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo9",&DML_info9)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info9 is.:[%s]\n", DML_info9);fflush(stdout);
					//DML Types for Engine Peer Reviewer.
					if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_userinfo10",&DML_info10)!=ITK_ok)   PrintErrorStack();
					printf("\n ADPR:DML_info10 is.:[%s]\n", DML_info10);fflush(stdout);

					printf("\n ADPR:P9:.Control Table for PRD DML code for ECU DML....\n"); fflush(stdout);
					if(QRY_find2("ControlObjects", &PRDqryTag));
					if (PRDqryTag)
					{
						printf("\n ADPR:P10:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n ADPR:P11:Not Found Query ControlObjects \n");fflush(stdout);
					}

					PRD_qry_values2[0] = "PRDCODE";
					if(QRY_execute(PRDqryTag, PRD_n_entry, PRD_qry_entry, PRD_qry_values2, &PRD_rsltCount, &PRD_CntrlObjectTag));
					printf(" \n ADPR:P12:PRD_rsltCount :%d:", PRD_rsltCount); fflush(stdout);
					if(PRD_rsltCount > 0)
					{
						//PRD project: for engine Peer reviewer.
						if (AOM_ask_value_string(PRD_CntrlObjectTag[0],"t5_Userinfo1",&PRD_info1)!=ITK_ok)   PrintErrorStack();
						printf("\n ADPR:PRD_info1 is.:[%s]\n", PRD_info1);fflush(stdout);
						//PRD project: for engine Peer reviewer.
						if (AOM_ask_value_string(PRD_CntrlObjectTag[0],"t5_Userinfo2",&PRD_info2)!=ITK_ok)   PrintErrorStack();
						printf("\n ADPR:PRD_info2 is.:[%s]\n", PRD_info2);fflush(stdout);
						//PRD project: for engine Peer reviewer.
						if (AOM_ask_value_string(PRD_CntrlObjectTag[0],"t5_Userinfo3",&PRD_info3)!=ITK_ok)   PrintErrorStack();
						printf("\n ADPR:PRD_info3 is.:[%s]\n", PRD_info3);fflush(stdout);
						//PRD project: for engine Peer reviewer.
						if (AOM_ask_value_string(PRD_CntrlObjectTag[0],"t5_Userinfo4",&PRD_info4)!=ITK_ok)   PrintErrorStack();
						printf("\n ADPR:PRD_info4 is.:[%s]\n", PRD_info4);fflush(stdout);
					}

					if(tc_strstr(DML_info1,"CVRule01")==NULL)
					{
						printf("\n ADPR:function for CVBU...");fflush(stdout);
						groupNameCV = (char	*)MEM_alloc(100);
						tc_strcpy(groupNameCV,"DML_Participants_Group_CV");
						
						DMLType=(char *)MEM_alloc(20);
						DML_BU=(char *)MEM_alloc(30);
						ProjectID=(char *)MEM_alloc(20);
						if(AOM_ask_value_string(objTag,"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(objTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
						printf("\n ADPR:P13:DML Number: [%s] DMLType: [%s] DML_BU:[%s] ProjectID :[%s]",DMLNo,DMLType,DML_BU,ProjectID);fflush(stdout);
							
						printf("\n ADPR:P14::%s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
						tc_strcpy(sDMLrlstype,"");
						tc_strcpy(sDMLrlstype,",");
						tc_strcat(sDMLrlstype,DMLType);
						tc_strcat(sDMLrlstype,",");
						printf("\n ADPR:P15:sDMLrlstype: %s",sDMLrlstype);fflush(stdout);
						if(tc_strstr(DML_info1,"CVRule02") == NULL)
						{
							if(tc_strcmp(DMLType,"")==0)
							{
								printf("\n ADPR:P16:%s:ERROR:DML type is NULL..................",DMLNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR001:DML type is NULL, Please get valid DML type updated from DML support team.\n",DMLNo);	
								decision = EPM_nogo;
								return decision;
							}
							if(tc_strcmp(ProjectID,"")==0)
							{
								printf("\n ADPR:P16:%s:ERROR:DML Project is NULL..................",DMLNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR002:DML project code is NULL, Please get it updated from DML support team.\n.",DMLNo);	
								decision = EPM_nogo;
								return decision;
							}
							if(tc_strcmp(DML_BU,"")==0)
							{
								printf("\n ADPR:P16:%s:ERROR:DML_BU is NULL..................",DMLNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR003:DML business unit is NULL, Please get it updated from DML support team.\n.",DMLNo);	
								decision = EPM_nogo;
								return decision;
							}
						}
						if(tc_strstr(DML_info1,"DMLASGA02") == NULL)
						{
							printf("\n ADPR:P17::%s:Check for DML BU:[%s].",DMLNo,DML_BU);fflush(stdout);
							if(ProjectID)
							{
								if(QRY_find2("Qury_Project", &queryTag));
								printf("\n ADPR:P17:After Prd_Project: QRY_find2");fflush(stdout);
								if (queryTag)
								{
									printf("\n ADPR:P18:Found Query");fflush(stdout);
								}
								else
								{
									printf("\n ADPR:P19:Not Found Query");fflush(stdout);
								}
								qry_values[0] = ProjectID;
								if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
								printf("\n ADPR:P20: resultCount : %d\n", resultCount); fflush(stdout);
								if(resultCount > 0)
								{
									printf("\n ADPR:P21:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
									Project_t = t5_Project[0];
									if (Project_t!=NULLTAG)
									{
										ProjectClass=(char *)MEM_alloc(20);
										ProjDesc=(char *)MEM_alloc(200);
										Proj_PltFrm=(char *)MEM_alloc(20);
										Proj_BU=(char *)MEM_alloc(20);
										if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
										printf("\n ADPR:P22: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
										if(tc_strstr(DML_info1,"DMLASGA03") == NULL)
										{
											if(tc_strcmp(Proj_PltFrm,"")==0)
											{
												printf("\n ADPR:P23:%s:ERROR:Project platform is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR004:Project platform is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
												decision = EPM_nogo;
												return decision;
											}
											if(tc_strcmp(Proj_BU,"")==0)
											{
												printf("\n ADPR:P23:%s:ERROR:Project proj BU is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR005:Project business unit is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
												decision = EPM_nogo;
												return decision;
											}
											if(tc_strcmp(ProjectClass,"")==0)
											{
												printf("\n ADPR:P23:%s:ERROR:Project Proj Class is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
												EMH_clear_errors();
												EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR006:Project class is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
												decision = EPM_nogo;
												return decision;
											}
										}
									}
								}
							}
							//For CVBU DML BU
							if(tc_strstr(DML_info3,DML_BU) != NULL)
							{
								printf("\n ADPR:CV:P24:%s:It is for CV DML Type.",DMLNo);fflush(stdout);
								if(tc_strstr(DML_info2,sDMLrlstype) != NULL)
								{
									//CE Reviewer not for CVBU.
									DMLVertical=(char *)MEM_alloc(50);
									printf("\n ADPR:CV:P25: Setting CE Reviewer...");fflush(stdout);
									if(AOM_ask_value_string(objTag,"t5_cDRstatus",&DMLDrStat)!=ITK_ok)PrintErrorStack();
									//if(AOM_ask_value_string(objTag,"t5_reason",&DMLReason)!=ITK_ok)PrintErrorStack();
									if(AOM_UIF_ask_value(objTag, "t5_reason", &DMLReason)!=ITK_ok)PrintErrorStack();
									//if(AOM_ask_value_string_at(objTag,"t5_crdesigngroup",DsgGrpcount,&DMLDesignGrp)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_strings( objTag,"t5_crdesigngroup",&DsgGrpcount,&DesignGroupList)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_ProductLine",&DMLVertical)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(objTag,"t5_PlntToPlnt",&sPlntToPlnt)!=ITK_ok)PrintErrorStack();
									printf("\n ADPR:CV:P26:DML DR STATUS: [%s] DMLType: [%s] DMLReason: [%s] DsgGrpcount: [%d] DMLVertical: [%s] sPlntToPlnt:[%s]", DMLDrStat,DMLType,DMLReason,DsgGrpcount,DMLVertical,sPlntToPlnt);fflush(stdout);
									if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
									if (dml_CRB_rel_type!=NULLTAG)
									{
										printf("\n ADPR:P28:DML to Has participant. \n");fflush(stdout);
										if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
										printf("\n ADPR:CV:P29: DmlCRB count: %d",CRBcount);fflush(stdout);	
									}

									if(tc_strstr(DML_info1,"DMLASGB01") == NULL)
									{
										printf("\n ADPR:CV:P27:%s: CE REVIEWER Reviewer START.. \n",DMLNo);fflush(stdout);
										if(tc_strstr(DML_info1,"DML23Aug22") == NULL)
										{
											PassFlag=0;
											printf("\n ADPR:P1:DML Reason:[%s] DML_BU:[%s]\n",DMLReason,DML_BU);fflush(stdout);
											//Get DCR Reason Code.
											if((tc_strcmp(DML_BU,"CVBU")==0)||(tc_strcmp(DML_BU,"CV-PSE")==0))
											{
												//DMLType: TODR/Veh/MR/TSKR
												if(tc_strstr(DML_info9,DMLType)!=NULL)
												{
													if((tc_strcmp(DMLType,"TODR")==0)&&(tc_strcmp(DML_BU,"CVBU")==0))
													{
														printf("\n ADPR:P2:P49:inside TODR ..");fflush(stdout);
														if ((tc_strcmp(sPlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(sPlntToPlnt,"DR3P to DR4")==0))
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 4);
															DMLDrStat=subString(sPlntToPlnt, 8, 3);
														}
														else if ((tc_strcmp(sPlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(sPlntToPlnt,"DR3 to DR3P")==0))
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 3);
															DMLDrStat=subString(sPlntToPlnt, 7, 4);
														}
														else
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 3);
															DMLDrStat=subString(sPlntToPlnt, 7, 3);
														}
														printf("\n ADPR:P3: DMLDrStat:[%s]\n",DMLDrStat);fflush(stdout);
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTsk_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
															printf("\n ADPR:P4: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
															for (kk=0;kk<Taskcout ;kk++ )
															{
																if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
																if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
																printf("\n ADPR:P5: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
																if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
																{
																	if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																	if(is_Tskltst != true)
																	{
																		printf("\n ADPR:P6:is_Tskltst is not true .....\n");fflush(stdout);
																	}
																	else
																	{
																		if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																		printf("\n ADPR:P7: partcnt.:%d\n",partcnt);fflush(stdout);
																		if (partcnt>0)
																		{
																			prt=0;
																			PltFrmPartFlg=0;
																			for (prt=0;prt<partcnt ;prt++ )
																			{							
																				AssyTag=PartsTag[prt];
																				if(AOM_UIF_ask_value(AssyTag, "object_type", &Prtobj_type)!=ITK_ok)   PrintErrorStack();
																				printf("\n ADPR: Object Type is : %s",Prtobj_type);	fflush(stdout);	
																				if(tc_strcmp(Prtobj_type,"Folder")!=0)
																				{
																					if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																					printf("\n ADPR:P8:.Part_no:%s ...",Part_no);	fflush(stdout);
																					if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																					printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																					if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																					printf(" DesgTyp: [%s] ", DesgTyp);fflush(stdout);
																					if(AOM_UIF_ask_value(AssyTag, "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																					printf(" Prtrev_idd: [%s]\n", Prtrev_idd);fflush(stdout);
																					if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																					{
																						DRGateWayVehFalg ++;
																						printf("\n ADPR:P9:For DR Gateway review:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																						FirstTimeVehFlag=0;
																						FirstTimeVehFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																						printf("\n ADPR:P11:FirstTimeVehFlag:%d\n",FirstTimeVehFlag); fflush(stdout);
																						if (FirstTimeVehFlag > 0)
																						{
																							printf("\n ADPR:P122:Not First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																							break;
																						}
																						else
																						{
																							printf("\n ADPR:P277: First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																							//get part number and then its tech spec details.
																							Item_count=0;
																							//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																							All_item_tag= t5GetItemRevisonADP(Part_no);
																							if(All_item_tag==NULLTAG)
																							{
																								printf("\n ADPR:ESO:P288:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																							}
																							else
																							{
																								if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																								printf("\n ADPR:P299:Total rev found: %d.", Item_count);fflush(stdout);
																								if(Item_count > 0)
																								{
																									ii=0;
																									for(ii=Item_count-1;ii>=0;ii--)
																									{
																										if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																										if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																										if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																										if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																										if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																										printf("\n ADPR:P300:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																										//check revison
																										printf("\n ADPR:P311:ESO:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																										if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																										{
																											if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																											{

																												ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																												printf("\n ADPR:after T5_VCSpec relation find"); fflush(stdout);
																												if(relation_type_tag != NULLTAG)
																												{
																													printf("\n ADPR:inside T5_VCSpec relation found"); fflush(stdout);
																													ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																													printf("\n ADPR:relation_name[%s]",relation_name); fflush(stdout);
																													ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																													printf("\n ADPR:TScount: %d\n", TScount);fflush(stdout);
																													if(TScount>0)
																													{
																														TechSpecObjTag=primaryobjs[0];
																														printf("\nADPR:DlgwgtCodeValuDup");fflush(stdout);
																														ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																														printf("\n ADPR:TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																														ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																														if(VCBusUnit)
																														{
																															tc_strdup(VCBusUnit,&VCBusUnitDup);
																														}
																														printf("\n ADPR:VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																													}
																												}
																												//char *VCClsAddress=NULL
																												//char *TobeUpdAttrId=NULL;
																												if (VCBusUnitDup!=NULL)
																												{
																													char TobeUpdAttrId[30];
																													int retcount;
																													int ClsAttrId=0 ;
																													printf("\n ADPR:TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																													ITK_CALL(getClsCodeAttrNoWrtTSBURewADP(VCBusUnitDup,&retcount));
																													printf("\n ADPR:after call getCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																													ClsAttrId=retcount;
																													printf("\n ADPR:ClsAttrId[%d] for ESO Code \n",ClsAttrId);fflush(stdout);
																													if(ClsAttrId>0)
																													{

																														sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																														printf("\n ADPR:inside sprintf AttrId[%s] for Appl for ESO Code \n",TobeUpdAttrId);fflush(stdout);
																														//key_lov_id=theKeyLOVId;	
																													}
																													printf("\n  ADPR:AttrId[%s]",TobeUpdAttrId); fflush(stdout);




																												if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																												/*iESOAppliValue= tm_GetESOVCAttriFrmClassiObjADP(master,"8103");
																												printf("\n CV_CE:P333:ESO: iESOAppliValue:[%d] \n",iESOAppliValue); fflush(stdout);
																												if (iESOAppliValue >0)
																												{
																													iESOAppliFlag ++;
																												}*/
																												if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																												printf("\n ADPR:P322:Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																												if (cnt_ccvcls >0)
																												{
																													ClsObj=*ClsObjTag;
																													iESOAppliValue= tm_GetESOVCAttriFrmClassiObjADP(ClsObj,TobeUpdAttrId);
																													printf("\n ADPR:P333: iESOAppliValue:[%d] \n",iESOAppliValue); fflush(stdout);
																													if (iESOAppliValue >0)
																													{
																														iESOAppliFlag ++;
																													}
																												}
																												break;
																											}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																					else
																					{
																						DRGateWayFalg ++;
																						printf("\n ADPR:P14:module for DR Gateway review:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																						FirstTimeTPLFlag=0;
																						FirstTimeTPLFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																						printf("\n ADPR:P15:FirstTimeTPLFlag:%d\n",FirstTimeTPLFlag); fflush(stdout);
																						if (FirstTimeTPLFlag ==0)
																						{
																							printf("\n ADPR:P16:First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																							break;
																						}
																						else
																						{
																							printf("\n ADPR:P17:No first time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													else if((tc_strcmp(DMLType,"EP")==0) && (tc_strcmp(DML_BU,"CV-PSE")==0))
													{
														/*For ECU:
														BU : CVBU/CV-PSE
														DML Type ECU:
														If PRD then send to CV_FCE
														Otherwise as per program_Chf_Grp*/
														printf("\n ADPR:This is ECU DML.");fflush(stdout);
														if(tc_strcmp(ProjectClass,"PRD")==0)
														{
															//CV-PSE
															printf(" PRD Project.");fflush(stdout);
															tc_strcpy(DML_CE_Group,"");
															tc_strcat(DML_CE_Group,"CV_FCE");
															printf(" DML_CE_Group: %s.",DML_CE_Group);fflush(stdout);
														}
														else
														{
															printf("\n ADPR:Not PRD Project.");fflush(stdout);
															if (tc_strcmp(Proj_PltFrm,"")==0)
															{
																printf(".....");fflush(stdout);
																tc_strcpy(DML_CE_Group,"CE_ECU");
																tc_strcat(DML_CE_Group,"_Chf_Grp");
																printf(" DML_CE_Group:: %s.",DML_CE_Group);fflush(stdout);
															}
															else
															{
																printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																tc_strcpy(DML_CE_Group,Proj_PltFrm);
																tc_strcat(DML_CE_Group,"_Chf_Grp");
															}
														}
														printf("\n ADPR:CV:DML_CE_Group:%s",DML_CE_Group);fflush(stdout);
														
														if (CRBcount >0)
														{
															CEReviewerFlag=0;
															printf("\n ADPR:CV:P30:CE: checking for CE Reviewer: %s", DMLNo);fflush(stdout);
															for (jk=0;jk<CRBcount ;jk++ )
															{	
																//type_name7=NULL;
																DmlCRBTag = DmlCRB[jk];
																if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																printf("\n ADPR:CV:P30:CE: Participants Name: %s", type_name7);fflush(stdout);
																//VI Reviewer will be work as Certification reviewer
																if (tc_strcmp(type_name7,"T5_CEReviewer")==0)
																{
																	CEReviewerFlag=1;
																	break;
																}
															}
															if (CEReviewerFlag ==0)
															{
																//ERROR
																printf("\n ADPR:ERROR:CE01:Project Proj Class is NULL:%s..................",DMLNo);fflush(stdout);
																EMH_clear_errors();
																EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR007:DML is eligible for CE reviewer, but no CE reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",DML_CE_Group);	
																decision = EPM_nogo;
																return decision;
															}
														}
													}
													if(tc_strcmp(DML_BU,"CVBU")==0)
													{
														FirstTimeTPLFlag=0;
														printf("\n ADPR:P18:For module release DML/Module with spare kit release DML/.....\n");fflush(stdout);
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTsk_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
															printf("\n ADPR:P19: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
															for (kk=0;kk<Taskcout ;kk++ )
															{

																if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
																if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
																printf("\n ADPR:P20: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
																if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
																{
																	if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																	if(is_Tskltst != true)
																	{
																		printf("\n ADPR:P21:is_Tskltst is not true .....\n");fflush(stdout);
																	}
																	else
																	{

                                                                        if(AOM_ask_value_string(TskRevn_tag[kk],"item_id",&item_id)!=ITK_ok)PrintErrorStack();
																		printf("\n ADPR:item_id : %s",item_id);fflush(stdout);
																		

																		if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																		printf("\n ADPR:P22: partcnt.:%d\n",partcnt);fflush(stdout);
																		if (partcnt>0)
																		{
																			prt=0;
																			PltFrmPartFlg=0;
																			for (prt=0;prt<partcnt ;prt++ )
																			{							
																				AssyTag=PartsTag[prt];
																				if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																				printf("\n ADPR:P23:.Part_no:%s ...",Part_no);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																				printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																				printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																				if(AOM_UIF_ask_value(AssyTag, "item_revision_id", &Prtrev_idd)!=ITK_ok)PrintErrorStack();
																				printf(" Prtrev_idd: [%s]\n", Prtrev_idd);fflush(stdout);
																				if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																				{
																					DRGateWayVehFalg ++;
																					printf("\n ADPR:P24:more modification needed for DR Gateway review:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																					FirstTimeVehFlag=0;
																					FirstTimeVehFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																					printf("\n ADPR:P25:FirstTimeVehFlag:%d\n",FirstTimeVehFlag); fflush(stdout);
																					if (FirstTimeVehFlag > 0)
																					{
																						printf("\n ADPR:P26: Not First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						break;
																					}
																					else
																					{
																						printf("\n ADPR:P27: First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						//get part number and then its tech spec details.
																						Item_count=0;
																						//if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																						All_item_tag= t5GetItemRevisonADP(Part_no);
																						if(All_item_tag==NULLTAG)
																						{
																							printf("\n ADPR:P28:ERROR:All_item_tag is NULL.\n");fflush(stdout);
																						}
																						else
																						{
																							if(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list)!=ITK_ok)PrintErrorStack();
																							printf("\n ADPR:P29:Total rev found: %d.", Item_count);fflush(stdout);
																							if(Item_count > 0)
																							{
																								ii=0;
																								for(ii=Item_count-1;ii>=0;ii--)
																								{
																									if(AOM_UIF_ask_value(rev_list[ii], "item_id", &Partno)!=ITK_ok)PrintErrorStack();
																									if(AOM_ask_value_string(rev_list[ii], "t5_PartType", &PartTyp)!=ITK_ok)PrintErrorStack();
																									if(AOM_ask_value_string(rev_list[ii], "t5_ColourInd", &sPrtColInd)!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(rev_list[ii], "item_revision_id", &rev_idd)!=ITK_ok)PrintErrorStack();
																									if(AOM_UIF_ask_value(rev_list[ii], "release_status_list", &rel_status)!=ITK_ok)PrintErrorStack();
																									if(TCTYPE_ask_object_type(rev_list[ii],&PartypObj));
																									if(TCTYPE_ask_name2(PartypObj,&sPartObjyp));
																									printf("\n ADPR:P30:Part %s rev:%s PartTyp:%s Rel Status:%s sPartObjyp:%s", Partno,rev_idd,PartTyp,rel_status,sPartObjyp);fflush(stdout);
																									//check revison
																									printf("\n ADPR:P31:sPrtColInd:%s Prtrev_idd: %s rev_idd:%s",sPrtColInd,Prtrev_idd,rev_idd);fflush(stdout);
																									if((tc_strcmp(sPrtColInd,"N")==0)|| (tc_strcmp(sPrtColInd,"Y")==0))
																									{
																										if(tc_strcmp(Prtrev_idd,rev_idd)==0)
																										{


                                                                                                            ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
																											printf("\n ADPR:after T5_VCSpec relation find"); fflush(stdout);
																											if(relation_type_tag != NULLTAG)
																											{
																												printf("\n inside T5_VCSpec relation found"); fflush(stdout);
																												ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
																												printf("\n relation_name[%s]",relation_name); fflush(stdout);
																												ITK_CALL(GRM_list_secondary_objects_only(rev_list[ii],relation_type_tag,&TScount,&primaryobjs));
																												printf("\n TScount: %d\n", TScount);fflush(stdout);
																												if(TScount>0)
																												{
																													TechSpecObjTag=primaryobjs[0];
																													printf("\nDlgwgtCodeValuDup");fflush(stdout);
																													ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
																													printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
																													ITK_CALL( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
																													if(VCBusUnit)
																													{
																														tc_strdup(VCBusUnit,&VCBusUnitDup);
																													}
																													printf("\n ADPR:VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
																												}
																											}
																											//char *VCClsAddress=NULL
																											//char *TobeUpdAttrId=NULL;
																											if (VCBusUnitDup!=NULL)
																											{
																												char TobeUpdAttrId[30];
																												int retcount;
																												int ClsAttrId=0 ;
																												printf("\n ADPR:TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
																												ITK_CALL(getClsCodeAttrNoWrtTSBURewADP(VCBusUnitDup,&retcount));
																												printf("\n after call getCodeAttrNoWrtTSBURew count: %d \n",retcount);fflush(stdout);
																												ClsAttrId=retcount;
																												printf("\n ClsAttrId[%d] for ESO Code \n",ClsAttrId);fflush(stdout);
																												if(ClsAttrId>0)
																												{

																													sprintf(TobeUpdAttrId, "%d", ClsAttrId);
																													printf("\n inside sprintf AttrId[%s] for Appl for ESO Code \n",TobeUpdAttrId);fflush(stdout);
																													//key_lov_id=theKeyLOVId;	
																												}
																												printf("\n  AttrId[%s]",TobeUpdAttrId); fflush(stdout);



																												if(ITEM_ask_item_of_rev(rev_list[ii], &master)!=ITK_ok)PrintErrorStack();
																												if(AOM_ask_value_tags(master,"IMAN_classification",&cnt_ccvcls,&ClsObjTag)!=ITK_ok)PrintErrorStack();
																												printf("\n ADPR:P32:Classification relation: %d.",cnt_ccvcls); fflush(stdout);
																												if (cnt_ccvcls >0)
																												{
																													ClsObj=*ClsObjTag;
																													iESOAppliValue= tm_GetESOVCAttriFrmClassiObjADP(ClsObj,TobeUpdAttrId);
																													printf("\n ADPR:P33: iESOAppliValue:[%d] \n",iESOAppliValue); fflush(stdout);
																													if (iESOAppliValue >0)
																													{
																														iESOAppliFlag ++;
																													}
																												}
																												break;
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																				else
																				{
																					DRGateWayFalg ++;
																					printf("\n ADPR:P34:more modification needed for DR gateway:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																					FirstTimeTPLFlag=0;
																					FirstTimeTPLFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																					printf("\n ADPR:P35:FirstTimeTPLFlag:%d\n",FirstTimeTPLFlag); fflush(stdout);
																					if (FirstTimeTPLFlag ==0)
																					{
																						printf("\n ADPR:CV:P12:First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						break;
																					}
																					else
																					{
																						printf("\n ADPR:CV:P13:No first time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}

													printf("\n ADPR:CV:P14:DRGateWayFalg:%d FirstTimeTPLFlag:%d   \n DRGateWayVehFalg:%d FirstTimeVehFlag:%d iESOAppliFlag:%d",DRGateWayFalg,FirstTimeTPLFlag,DRGateWayVehFalg,FirstTimeVehFlag,iESOAppliFlag);fflush(stdout);
													if(DRGateWayVehFalg >0)
													{
														printf("\n ADPR:CV:P14:Vehicle DML condition..");fflush(stdout);
														if (FirstTimeVehFlag ==0)
														{
															printf("\n ADPR:CV:first Veh release..");fflush(stdout);
															if (iESOAppliFlag >0)
															{
																/*Veh: First time+ ESO-YES: 
																DR4: amk664922 CV_Head_Reviewer
																DR3/DR3P: Buses_HeadVIG_Chf_Grp
																DR1/DR2: Buses_FamChf_Chf_Grp
																DR0: Buses_ProjMgr_Chf_Grp*/
																printf("\n ADPR:CV:P14: first time Vehicle release and ESO-NO..");fflush(stdout);
																PassFlag=1;
																if(tc_strlen(DMLVertical)>0)
																{
																	if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																			//SCV Cargo_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																			//Pick-Up_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																			//MHCV-T3_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else
																		{
																			printf("\n ADPR:CV:...Else.....");fflush(stdout);
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																	else if(tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			//SCV Cargo_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			//Pick-Up_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			//MHCV-T3_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else
																		{
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																	else if(tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			//SCV Cargo_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			//Pick-Up_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else
																		{
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		printf("\n ADPR:CV:VIG:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																	else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																	{
																		tc_strcpy(DML_CE_Group,"");
																		tc_strcat(DML_CE_Group,"CV_Head_Reviewer");
																		printf("\n ADPR:CV:VIG:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																}
																else
																{
																	tc_strcpy(DML_CE_Group,"CE");
																	tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																	PassFlag=1;
																	printf("\n ADPR:CV:VERTICAL_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
															else
															{
																/*Veh:First time+ ESO NOT:  (ESO == NO & first time release)
																DR4: Buses_HeadVIG_Chf_Grp
																DR2/DR3/DR3P: Buses_FamChf_Chf_Grp
																DR0/DR1: Buses_ProjMgr_Chf_Grp*/
																printf("\n ADPR:CV:P14: first time Vehicle release and ESO-NO..");fflush(stdout);
																PassFlag=1;
																if(tc_strlen(DMLVertical)>0)
																{
																	if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																			//SCV Cargo_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																			//Pick-Up_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																			//MHCV-T3_ProjMgr_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		else
																		{
																			printf("\n ADPR:CV:...Else.....");fflush(stdout);
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																		}
																		printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																	else if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			//SCV Cargo_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			//Pick-Up_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			//MHCV-T3_FamChf_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		else
																		{
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																		}
																		printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																	else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																	{
																		if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																		{
																			//SCV Cargo_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Cargo");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																		{
																			//Pick-Up_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"Pick_Up");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"MHCV_T3");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																		{
																			//MHCV-T3_HeadVIG_Chf_Grp
																			tc_strcpy(DML_CE_Group,"SCV_Passenger");
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		else
																		{
																			tc_strcpy(DML_CE_Group,DMLVertical);
																			tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																		}
																		printf("\n ADPR:CV:VIG:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																	}
																}
																else
																{
																	tc_strcpy(DML_CE_Group,"CE");
																	tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																	PassFlag=1;
																	printf("\n ADPR:CV:VERTICAL_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
														}
														else
														{
															/*Veh: NO FIrst time and ESO-NO:
															DR4: Buses_HeadVIG_Chf_Grp
															DR2/DR3/DR3P: Buses_FamChf_Chf_Grp
															DR0/DR1: Buses_ProjMgr_Chf_Grp*/
															printf("\n ADPR:CV:P14:NO first time Vehicle release..");fflush(stdout);
															PassFlag=1;
															if(tc_strlen(DMLVertical)>0)
															{
																if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																		//SCV Cargo_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																		//Pick-Up_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																		//MHCV-T3_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else
																	{
																		printf("\n ADPR:CV:...Else.....");fflush(stdout);
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	printf("\n ADPR:CV:VIG:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
															else
															{
																tc_strcpy(DML_CE_Group,"CE");
																tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																PassFlag=1;
																printf("\n ADPR:CV:VERTICAL_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
															}
														}
														if (PassFlag >0)
														{
															//Set DR-Gate Way reviewer based on project class:ProjectClass
															printf("\n ASSIGN:CV:P455:CVBU: after DML_CE_Group: %s",DML_CE_Group);   fflush(stdout);
															if (CRBcount >0)
															{
																CEReviewerFlag=0;
																printf("\n ADPR:CV:P30:CE02: checking for CE Reviewer: %s", DMLNo);fflush(stdout);
																for (jk=0;jk<CRBcount ;jk++ )
																{	
																	//type_name7=NULL;
																	DmlCRBTag = DmlCRB[jk];
																	if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																	if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																	printf("\n ADPR:CV:P30:CE02: Participants Name: %s", type_name7);fflush(stdout);
																	if (tc_strcmp(type_name7,"T5_CEReviewer")==0)
																	{
																		CEReviewerFlag=1;
																		break;
																	}
																}
																if (CEReviewerFlag ==0)
																{
																	//ERROR
																	printf("\n ADPR:ERROR:CE02:Project Proj Class is NULL:%s..................",DMLNo);fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR008:DML is eligible for CE reviewer, but no CE reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",DML_CE_Group);	
																	decision = EPM_nogo;
																	return decision;
																}
															}
														}
													}
													else if(DRGateWayFalg >0)
													{
														printf("\n ADPR:CV:P17:TPL DML condition  ====>  \n ");fflush(stdout);
														if (FirstTimeTPLFlag ==0)
														{
															FourthCodition=1;
														}
														else
														{
															if(tc_strstr(DML_info8,DMLReason)!=NULL)
															{
																SixthCondition = 1;
																printf("\n ADPR:CV:P15:This is Drafting Error condition SixthCondition = %d  \n ",SixthCondition);fflush(stdout);
															}
															else
															{
																fivethCondition = 1;
																printf("\n ADPR:CV:P16:As Per Reason of DML it follows the 5th condtion of part Modification fivethCondition = %d  \n ",fivethCondition);fflush(stdout);
															}
														}
														printf("\n ADPR:CV:P17:FourthCodition  ====>  %d \n ",FourthCodition);fflush(stdout);
														printf("\n ADPR:CV:P18:fivethCondition ====>  %d \n ",fivethCondition);fflush(stdout);
														printf("\n ADPR:CV:P19:SixthCondition  ====>  %d \n ",SixthCondition);fflush(stdout);
														/*TCE: DR Gate Way reviewer:
														DML type: GM/TPL/TK

														First time:
														DR0/DR1: Buses_44_Lead_CoC
														DR4 above: 44_Group_head
														DR2/DR3/DR3P: 44_Head_Coc

														Draffting Error:
														DR0/DR1/DR2/DR3/DR3P: Buses_44_Lead_CoC
														DR4/DR5 : 44_Head_CoC

														Other than First time:
														DR0 to DR2: Buses_44_Lead_CoC
														DR3 and above: 44_Head_CoC*/
														if (FourthCodition >0)
														{
															/*First time with TPL DML:
															DR4: Buses_HeadVIG_Chf_Grp
															DR2/DR3/DR3P: Buses_FamChf_Chf_Grp
															DR0/DR1: Buses_ProjMgr_Chf_Grp*/
															PassFlag=1;
															if(tc_strlen(DMLVertical)>0)
															{
																if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																		//SCV Cargo_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																		//Pick-Up_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																		//MHCV-T3_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else
																	{
																		printf("\n ADPR:CV:...Else.....");fflush(stdout);
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
																	}
																	printf("\n ADPR:CV:VIG:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
															else
															{
																tc_strcpy(DML_CE_Group,"CE");
																tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																PassFlag=1;
																printf("\n ADPR:CV:VERTICAL_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
															}
														}
														else if (fivethCondition >0)
														{
															/*Not First time with TPL DML: 
															DR0 to DR2: Buses_ProjMgr_Chf_Grp
															DR3 to DR4: Buses_FamChf_Chf_Grp*/
															PassFlag=1;
															if(tc_strlen(DMLVertical)>0)
															{
																if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																		//SCV Cargo_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																		//Pick-Up_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																		//MHCV-T3_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else
																	{
																		printf("\n ADPR:CV:...Else.....");fflush(stdout);
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0||tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
															else
															{
																tc_strcpy(DML_CE_Group,"CE");
																tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																PassFlag=1;
																printf("\n ADPR:CV:VERTI_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
															}
														}
														else if (SixthCondition >0)
														{
															/*First time with TPL DML: Drafting error-reason
															DR0 to DR3P: Buses_ProjMgr_Chf_Grp
															DR4: Buses_FamChf_Chf_Grp*/
															PassFlag=1;
															if(tc_strlen(DMLVertical)>0)
															{
																if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 ||tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		printf("\n ADPR:CV:...Else if 1.....");fflush(stdout);
																		//SCV Cargo_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		printf("\n ADPR:CV:...Else if 2.....");fflush(stdout);
																		//Pick-Up_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		printf("\n ADPR:CV:...Else if 3.....");fflush(stdout);
																		//MHCV-T3_ProjMgr_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		printf("\n ADPR:CV:...Else if 4.....");fflush(stdout);
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	else
																	{
																		printf("\n ADPR:CV:...Else.....");fflush(stdout);
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
																	}
																	printf("\n ADPR:CV:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
																else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
																{
																	if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																	{
																		//SCV Cargo_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Cargo");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																	{
																		//Pick-Up_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"Pick_Up");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																	{
																		//MHCV-T3_FamChf_Chf_Grp
																		tc_strcpy(DML_CE_Group,"MHCV_T3");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																	{
																		//MHCV-T3_HeadVIG_Chf_Grp
																		tc_strcpy(DML_CE_Group,"SCV_Passenger");
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	else
																	{
																		tc_strcpy(DML_CE_Group,DMLVertical);
																		tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
																	}
																	printf("\n ADPR:CV:Fam:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
																}
															}
															else
															{
																tc_strcpy(DML_CE_Group,"CE");
																tc_strcat(DML_CE_Group,"_Reviewer_Grp");
																PassFlag=1;
																printf("\n ADPR:CV:VERTI_NULL:DML_CE_Group: [%s] ",DML_CE_Group);fflush(stdout);
															}
														}
														if (PassFlag >0)
														{
															printf("\n ADPR:CV:P45:CVBU: after DML_CE_Group: %s",DML_CE_Group);   fflush(stdout);
															if (CRBcount >0)
															{
																CEReviewerFlag=0;
																printf("\n ADPR:CV:P30:CE03: checking for CE Reviewer: %s", DMLNo);fflush(stdout);
																for (jk=0;jk<CRBcount ;jk++ )
																{	
																	//type_name7=NULL;
																	DmlCRBTag = DmlCRB[jk];
																	if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																	if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																	printf("\n ADPR:CV:P30:CE03: Participants Name: %s", type_name7);fflush(stdout);
																	//VI Reviewer will be work as Certification reviewer
																	if (tc_strcmp(type_name7,"T5_CEReviewer")==0)
																	{
																		CEReviewerFlag=1;
																		break;
																	}
																}
																printf("\n ADPR:CV:P30:CE03: Participants Name:CEReviewerFlag: %d", CEReviewerFlag);fflush(stdout);
																if (CEReviewerFlag ==0)
																{
																	//ERROR
																	printf("\n ADPR:ERROR:CE03:Project Proj Class is NULL:%s..................",DMLNo);fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR009:DML is eligible for CE reviewer, but no CE reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",DML_CE_Group);	
																	decision = EPM_nogo;
																	return decision;
																}
															}
														}
													}
													else
													{
														printf("\n ADPR:CV:P14:ECU DMl or other case....");fflush(stdout);
													}
												}
											}
										}
										// START: CERTIFICATION REVIEWER : T5_CertificatnReviewer ---------------------------------------------------------
										printf("\n ADPR:P1:START:CE REVIEWER: T5_CertificatnReviewer....................................");fflush(stdout);
										if(tc_strstr(DML_info1,"DMLASGB03") == NULL)
										{
											printf("\n ADPR:P2:Going for certification reviewer only for vehicle DML and veh GMD......\n");fflush(stdout);
											//if((tc_strcmp(DML_BU,"PCBU")==0)||(tc_strcmp(DML_BU,"PVBU")==0)||(tc_strcmp(DML_BU,"CVBU")==0))
											if(tc_strcmp(DML_BU,"CVBU")==0)
											{
												//DMLType
												if((tc_strcmp(DMLType,"Veh")==0)&&((tc_strcmp(DMLDrStat,"DR3")==0)||(tc_strcmp(DMLDrStat,"DR3P")==0)||(tc_strcmp(DMLDrStat,"DR4")==0)||(tc_strcmp(DMLDrStat,"DR5")==0)||(tc_strcmp(DMLDrStat,"AR3")==0)||(tc_strcmp(DMLDrStat,"AR3P")==0)||(tc_strcmp(DMLDrStat,"AR4")==0)||(tc_strcmp(DMLDrStat,"AR5")==0)))
												{
													if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
													if (DmlTsk_tag!=NULLTAG)
													{		
														if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
														printf("\n ADPR:P3:Veh: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
														for (kk=0;kk<Taskcout ;kk++ )
														{
															if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
															if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
															printf("\n ADPR:P4:Veh: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
															if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
															{
																if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																if(is_Tskltst != true)
																{
																	printf("\n ADPR:P5:Veh:is_Tskltst is not true .....\n");fflush(stdout);
																}
																else
																{
																	if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																	printf("\n ADPR:P6:Veh: partcnt.:%d\n",partcnt);fflush(stdout);
																	if (partcnt>0)
																	{
																		prt=0;
																		PltFrmPartFlg=0;
																		for (prt=0;prt<partcnt ;prt++ )
																		{							
																			AssyTag=PartsTag[prt];
																			if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																			printf("\n ADPR:P7:Veh:.Part_no:%s ...",Part_no);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																			printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																			printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																			if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																			{
																				CertiFlag ++;
																				printf("\n ADPR:P8:Veh:more modification needed for certification review:%d",CertiFlag);fflush(stdout);
																			}
																		}
																	}
																}
															}
														}
													}
												}
												else if((tc_strcmp(DMLType,"TODR")==0)&&((tc_strcmp(sPlntToPlnt,"DR2 to DR3")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR3P")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR4 to DR5")==0)))
												{
													if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
													if (DmlTsk_tag!=NULLTAG)
													{		
														if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
														printf("\n ADPR:P9:GM:: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
														for (kk=0;kk<Taskcout ;kk++ )
														{
															if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
															if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
															printf("\n ADPR:P10:GM:: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
															if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
															{
																if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																if(is_Tskltst != true)
																{
																	printf("\n ADPR:P11:GM::is_Tskltst is not true .....\n");fflush(stdout);
																}
																else
																{
																	if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																	printf("\n ADPR:P12:GM:: partcnt.:%d\n",partcnt);fflush(stdout);
																	if (partcnt>0)
																	{
																		prt=0;
																		PltFrmPartFlg=0;
																		for (prt=0;prt<partcnt ;prt++ )
																		{							
																			AssyTag=PartsTag[prt];
																			if(AOM_UIF_ask_value(AssyTag, "object_type", &Prtobj_typee)!=ITK_ok)   PrintErrorStack();
																			printf("\n ADPR: Object Type is : %s",Prtobj_typee);	fflush(stdout);	
																			if(tc_strcmp(Prtobj_typee,"Folder")!=0)
																			{
																				if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																				printf("\n ADPR:P12:GM::.Part_no:%s ...",Part_no);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																				printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																				printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																				if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																				{
																					CertiFlag ++;
																					printf("\n ADPR:P13:GM:more modification needed for certification review:%d",CertiFlag);fflush(stdout);
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
												else
												{
													printf("\n ADPR:P14:This DML type is not applicable for certification review.");fflush(stdout);
												}
												if (CertiFlag >0)
												{
													//Set certification reviewer based on project class:ProjectClass
													CertiFication_Role = (char	*)MEM_alloc(100);
													tc_strcpy(CertiFication_Role,"");
													if(tc_strlen(ProjectClass)>0)
													{
														if (tc_strcmp(ProjectClass,"SEMI VEHICLE")==0)
														{
															//SEMI VEHICLE_Certification_Reviewer
															tc_strcpy(CertiFication_Role,"SEMI_VEHICLE");
														}
														else
														{
															tc_strcpy(CertiFication_Role,ProjectClass);
														}
													}
													else
													{
														tc_strcpy(CertiFication_Role,"CV");
													}

													//XXXXXX_Certification_Reviewer
													//tc_strcpy(CertiFication_Role,ProjectClass);
													tc_strcat(CertiFication_Role,"_");
													//tc_strcat(CertiFication_Role,"Certification_Reviewer");
													tc_strcat(CertiFication_Role,"Cert_Reviewer");
													printf("\n ADPR:P15::CVBU: after CertiFication_Role: %s",CertiFication_Role);   fflush(stdout);
													if (CRBcount >0)
													{
														CEReviewerFlag=0;
														printf("\n ADPR:CV:P30:CR01: checking for Certification Reviewer: %s", DMLNo);fflush(stdout);
														for (jk=0;jk<CRBcount ;jk++ )
														{	
															//type_name7=NULL;
															DmlCRBTag = DmlCRB[jk];
															if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
															if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
															printf("\n ADPR:CV:P30:CR01: Participants Name: %s", type_name7);fflush(stdout);
															//VI Reviewer will be work as Certification reviewer
															if (tc_strcmp(type_name7,"T5_CertificatnReviewer")==0)
															{
																CEReviewerFlag=1;
																break;
															}
														}
														printf("\n ADPR:CV:P30:CR01: Participants Name: %d", CEReviewerFlag);fflush(stdout);
														if (CEReviewerFlag ==0)
														{
															//ERROR
															printf("\n ADPR:ERROR:CE03:Project Proj Class is NULL:%s..................",DMLNo);fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR010:DML is eligible for Certification reviewer, but no reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",CertiFication_Role);	
															decision = EPM_nogo;
															return decision;
														}
													}
												}
											}
										}
										// START: DR GATEWAY REVIEWER ---------------------------------------------------------
										printf("\n ADPR:P1:START:DR_Gateway Reviewer....................................");fflush(stdout);
										if(tc_strstr(DML_info1,"DML17Aug22") == NULL)
										{
											DRgroupNameCV = (char	*)MEM_alloc(100);
											tc_strcpy(DRgroupNameCV,"DML_DR_Gateway_Group_CV");
											printf("\n ADPR:P2:DML Reason:[%s] DML_BU:[%s]\n",DMLReason,DML_BU);fflush(stdout);
											//Get DCR Reason Code.
											if(tc_strcmp(DML_BU,"CVBU")==0)
											{
												//DMLType: TODR/MR/MRSP
												if(tc_strstr(DML_info6,DMLType)!=NULL)
												{
													//DMLDrStat
													//sPlntToPlnt
													//if((tc_strcmp(DMLType,"TODR")==0)&&((tc_strcmp(sPlntToPlnt,"DR2 to DR3")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR3P")==0)||(tc_strcmp(sPlntToPlnt,"DR3 to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(sPlntToPlnt,"DR4 to DR5")==0)))
													if(tc_strcmp(DMLType,"TODR")==0)
													{
														printf("\n ADPR:P3:inside TODR ..");fflush(stdout);
														if ((tc_strcmp(sPlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(sPlntToPlnt,"DR3P to DR4")==0))
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 4);
															DMLDrStat=subString(sPlntToPlnt, 8, 3);
														}
														else if ((tc_strcmp(sPlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(sPlntToPlnt,"DR3 to DR3P")==0))
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 3);
															DMLDrStat=subString(sPlntToPlnt, 7, 4);
														}
														else
														{
															//FromPlnt=subString(sPlntToPlnt, 0, 3);
															DMLDrStat=subString(sPlntToPlnt, 7, 3);
														}
														printf("\n ADPR:P4: DMLDrStat:[%s]\n",DMLDrStat);fflush(stdout);
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTsk_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
															printf("\n ADPR:P5: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
															for (kk=0;kk<Taskcout ;kk++ )
															{
																if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
																if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
																printf("\n ADPR:P6: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
																if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
																{
																	if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																	if(is_Tskltst != true)
																	{
																		printf("\n ADPR:P7:is_Tskltst is not true .....\n");fflush(stdout);
																	}
																	else
																	{
																		if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																		printf("\n ADPR:P8: partcnt.:%d\n",partcnt);fflush(stdout);
																		if (partcnt>0)
																		{
																			prt=0;
																			PltFrmPartFlg=0;
																			for (prt=0;prt<partcnt ;prt++ )
																			{							
																				AssyTag=PartsTag[prt];
																				if(AOM_UIF_ask_value(AssyTag, "object_type", &Prtobj_typee)!=ITK_ok)   PrintErrorStack();
																				printf("\n ADPR: Object Type is : %s",Prtobj_typee);	fflush(stdout);	
																				if(tc_strcmp(Prtobj_typee,"Folder")!=0)
																				{
																					if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																					printf("\n ADPR:P9:.Part_no:%s ...",Part_no);	fflush(stdout);
																					if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																					printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																					if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																					printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																					if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																					{
																						DRGateWayFalg=0;
																						printf("\n ADPR:P10:DR-Gate way reviewer not needed.:%d",DRGateWayFalg);fflush(stdout);
																						break;
																					}
																					else
																					{
																						DRGateWayFalg ++;
																						printf("\n ADPR:P11:for DR Gateway review:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																						FirstTimeFlag=0;
																						FirstTimeFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																						printf("\n ADPR:P12:FirstTimeFlag:%d\n",FirstTimeFlag); fflush(stdout);
																						if (FirstTimeFlag ==0)
																						{
																							printf("\n ADPR:P13:First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																							break;
																						}
																						else
																						{
																							printf("\n ADPR:P14:No first time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													else
													{
														FirstTimeFlag=0;
														printf("\n ADPR:P15:For module release DML.....\n");fflush(stdout);
														//if((tc_strcmp(DMLType,"TPL")==0)&&((tc_strcmp(DMLDrStat,"DR3")==0)||(tc_strcmp(DMLDrStat,"DR3P")==0)||(tc_strcmp(DMLDrStat,"DR4")==0)||(tc_strcmp(DMLDrStat,"DR5")==0)||(tc_strcmp(DMLDrStat,"AR3")==0)||(tc_strcmp(DMLDrStat,"AR3P")==0)||(tc_strcmp(DMLDrStat,"AR4")==0)||(tc_strcmp(DMLDrStat,"AR5")==0)))
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTsk_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
															printf("\n ADPR:P17: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
															for (kk=0;kk<Taskcout ;kk++ )
															{
																if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
																if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
																printf("\n ADPR:P18: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
																if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
																{
																	if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																	if(is_Tskltst != true)
																	{
																		printf("\n ADPR:P19:is_Tskltst is not true .....\n");fflush(stdout);
																	}
																	else
																	{
																		if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																		printf("\n ADPR:P20: partcnt.:%d\n",partcnt);fflush(stdout);
																		if (partcnt>0)
																		{
																			prt=0;
																			PltFrmPartFlg=0;
																			for (prt=0;prt<partcnt ;prt++ )
																			{							
																				AssyTag=PartsTag[prt];
																				if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																				printf("\n ADPR:P21:.Part_no:%s ...",Part_no);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																				printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																				printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																				if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																				{
																					DRGateWayFalg =0;
																					printf("\n ADPR:P22:For DR- review:%d",DRGateWayFalg);fflush(stdout);
																					break;
																				}
																				else
																				{
																					DRGateWayFalg ++;
																					printf("\n ADPR:P23: for DR gateway:[%d] DMLDrStat:[%s] DML_info7:[%s]",DRGateWayFalg,DMLDrStat,DML_info7);fflush(stdout);
																					FirstTimeFlag=0;
																					FirstTimeFlag = IsFirstTImeRelRevADP(Part_no,DMLDrStat,DML_info7);
																					printf("\n ADPR:P24:FirstTimeFlag:%d\n",FirstTimeFlag); fflush(stdout);
																					if (FirstTimeFlag ==0)
																					{
																						printf("\n ADPR:P25:First time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																						break;
																					}
																					else
																					{
																						printf("\n ADPR:P26:No first time release part found for DR-status:%s.",DMLDrStat);fflush(stdout);
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													printf("\n ADPR:P27:DRGateWayFalg:%d FirstTimeFlag:%d",DRGateWayFalg,FirstTimeFlag);fflush(stdout);
													if(DRGateWayFalg >0)
													{
														printf("\n ADPR:P28:FirstTimeFlag:%d.",FirstTimeFlag);fflush(stdout);
														if (FirstTimeFlag ==0)
														{
															FourthCodition=1;
														}
														else
														{
															//Check DML reason codes here.
															//TCE:translate t540 to "SAMPLES TO BE APPROVED" ;
															//TCE:translate t536 to "DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT";
															if(tc_strstr(DML_info8,DMLReason)!=NULL)
															{
																SixthCondition = 1;
																printf("\n ADPR:P29:This is Drafting Error condition SixthCondition = %d  \n ",SixthCondition);fflush(stdout);
															}
															else
															{
																fivethCondition = 1;
																printf("\n ADPR:P30:As Per Reason of DML it follows the 5th condtion of part Modification fivethCondition = %d  \n ",fivethCondition);fflush(stdout);
															}
														}
														printf("\n ADPR:P31:FourthCodition  ====>  %d \n ",FourthCodition);fflush(stdout);
														printf("\n ADPR:P32:fivethCondition ====>  %d \n ",fivethCondition);fflush(stdout);
														printf("\n ADPR:P33:SixthCondition  ====>  %d \n ",SixthCondition);fflush(stdout);
														if (FourthCodition >0)
														{
															/*First time:
															DR0/DR1: Buses_44_Lead_CoC
															DR4 above: 44_Group_head
															DR2/DR3/DR3P: 44_Head_CoC*/
															//First time DR gate
															if (tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
															{
																//check for DML design group logic
																printf("\n ADPR:P34:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																
																printf("\n ADPR:P35:DsgGrpcount of design group:%d \n",DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		//DMLDESGGRP_Group_Head
																		printf("\n ADPR:P36:DesignGroupList2:%s\n",DesignGroupList[DsgN]);fflush(stdout);
																		tc_strcpy(DR_Gateway_Role,"");
																		tc_strcpy(DR_Gateway_Role,DesignGroupList[DsgN]);
																		tc_strcat(DR_Gateway_Role,"_Group_Head");
																		printf("\n ADPR:P37:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																		//44_Group_head
																		break;
																	}
																}
																DRPassFlag=1;
															}
															else if (tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0 ||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
															{
																//check for DML design group logic
																printf("\n CV_GATE:P38:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:P39:DsgGrpcount of design group:%d \n",DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		//DMLDESGGRP_Group_Head
																		printf("\n CV_GATE:P40:DesignGroupList2:%s\n",DesignGroupList[DsgN]);fflush(stdout);
																		tc_strcpy(DR_Gateway_Role,"");
																		tc_strcpy(DR_Gateway_Role,DesignGroupList[DsgN]);
																		tc_strcat(DR_Gateway_Role,"_Head_CoC");
																		printf("\n CV_GATE:P41:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																		//44_Head_CoC
																		break;
																	}
																}
																printf("\n CV_GATE:P42:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
															else if (tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 )
															{
																//check for DML design group logic
																printf("\n CV_GATE:P43:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:P44:DsgGrpcount of design group:%d \n",DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		//DMLDESGGRP_Group_Head
																		printf("\n CV_GATE:P45:DMLVertical:%s DesignGroupList2:%s\n",DMLVertical,DesignGroupList[DsgN]);fflush(stdout);
																		tc_strcpy(DR_Gateway_Role,"");
																		if(tc_strcmp(DMLVertical,"")==0)
																		{
																			tc_strcpy(DR_Gateway_Role,"DR_Gateway");
																			//tc_strcat(DR_Gateway_Role,"_");
																			//tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																		}
																		else
																		{
																			if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Cargo");
																			}
																			else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"Pick_Up");
																			}
																			else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"MHCV_T3");
																			}
																			else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Passenger");
																			}
																			else
																			{
																				tc_strcpy(DR_Gateway_Role,DMLVertical);
																			}
																			tc_strcat(DR_Gateway_Role,"_");
																			tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																		}
																		//Buses_44_Lead_CoC
																		break;
																	}
																}
																printf("\n CV_GATE:P46:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
														}
														else if (fivethCondition >0)
														{
															/*Other than First time:
															DR0 to DR2: Buses_44_Lead_CoC
															DR3 and above: 44_Head_CoC*/
															if (tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0 ||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0 || tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
															{
																//DR3 and above
																//check for DML design group logic
																printf("\n CV_GATE:P47:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:P48:DsgGrpcount of design group:%d \n",DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		tc_strcpy(DR_Gateway_Role,"");
																		tc_strcpy(DR_Gateway_Role,DesignGroupList[DsgN]);
																		tc_strcat(DR_Gateway_Role,"_Head_CoC");
																		//44_Head_CoC
																		break;
																	}
																}
																printf("\n CV_GATE:P49:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
															else if (tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
															{
																//DR0 to DR2
																//check for DML design group logic
																printf("\n CV_GATE:50:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:51:DMLVertical:%s DsgGrpcount of design group:%d \n",DMLVertical,DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		tc_strcpy(DR_Gateway_Role,"");
																		if(tc_strcmp(DMLVertical,"")==0)
																		{
																			tc_strcpy(DR_Gateway_Role,"DR_Gateway");
																			//tc_strcat(DR_Gateway_Role,"_");
																			//tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																		}
																		else
																		{
																			if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Cargo");
																			}
																			else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"Pick_Up");
																			}
																			else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"MHCV_T3");
																			}
																			else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Passenger");
																			}
																			else
																			{
																				tc_strcpy(DR_Gateway_Role,DMLVertical);
																			}
																			tc_strcat(DR_Gateway_Role,"_");
																			tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																			//Buses_44_Lead_CoC
																		}
																		break;
																	}
																}
																printf("\n CV_GATE:52:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
														}
														else if (SixthCondition >0)
														{
															/*Draffting Error:
															DR0/DR1/DR2/DR3/DR3P: Buses_44_Lead_CoC
															DR4/DR5 : 44_Head_CoC*/
															if (tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
															{
																//check for DML design group logic
																printf("\n CV_GATE:53:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:54: DsgGrpcount of design group:%d \n",DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		tc_strcpy(DR_Gateway_Role,"");
																		tc_strcpy(DR_Gateway_Role,DesignGroupList[DsgN]);
																		tc_strcat(DR_Gateway_Role,"_Head_CoC");
																		//44_Head_CoC
																		break;
																	}
																}
																printf("\n CV_GATE:56:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
															else if (tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 ||tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0 ||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
															{
																//check for DML design group logic
																printf("\n CV_GATE:57:Head of Group Is should be assign \n");fflush(stdout);
																DR_Gateway_Role = (char	*)MEM_alloc(100);
																printf("\n CV_GATE:58:Proj_PltFrm:%s DsgGrpcount of design group:%d \n",Proj_PltFrm,DsgGrpcount);fflush(stdout);
																if(DsgGrpcount > 0)
																{
																	for(DsgN=0;DsgN<DsgGrpcount;DsgN++)
																	{
																		tc_strcpy(DR_Gateway_Role,"");
																		if(tc_strcmp(DMLVertical,"")==0)
																		{
																			tc_strcpy(DR_Gateway_Role,"DR_Gateway");
																			//tc_strcat(DR_Gateway_Role,"_");
																			//tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																		}
																		else
																		{
																			if (tc_strcmp(DMLVertical,"SCV Cargo")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Cargo");
																			}
																			else if (tc_strcmp(DMLVertical,"Pick-Up")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"Pick_Up");
																			}
																			else if (tc_strcmp(DMLVertical,"MHCV-T3")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"MHCV_T3");
																			}
																			else if (tc_strcmp(DMLVertical,"SCV Passenger")==0)
																			{
																				tc_strcpy(DR_Gateway_Role,"SCV_Passenger");
																			}
																			else
																			{
																				tc_strcpy(DR_Gateway_Role,DMLVertical);
																			}
																			tc_strcat(DR_Gateway_Role,"_");
																			tc_strcat(DR_Gateway_Role,DesignGroupList[DsgN]);
																			tc_strcat(DR_Gateway_Role,"_Lead_CoC");
																			//Buses_44_Lead_CoC
																		}
																		break;
																	}
																}
																printf("\n CV_GATE:58:DR-Gate Way Reviewer Group TPL id2:(%s)\n",DR_Gateway_Role);fflush(stdout);
																DRPassFlag=1;
															}
														}
														if (DRPassFlag >0)
														{
															//Set DR-Gate Way reviewer based on project class:ProjectClass
															printf("\n CV_GATE:59:CVBU: after DR_Gateway_Role: %s",DR_Gateway_Role);   fflush(stdout);
															if(SA_find_group(DRgroupNameCV, &DRGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(DR_Gateway_Role,&DRAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(DRGrp_tag!=NULLTAG && DRAnalyst_tag!=NULLTAG)
															{
																if (CRBcount >0)
																{
																	CEReviewerFlag=0;
																	printf("\n ADPR:CV:P30:CR01: checking for T5_DRGatewayReviewer Reviewer: %s", DMLNo);fflush(stdout);
																	for (jk=0;jk<CRBcount ;jk++ )
																	{	
																		//type_name7=NULL;
																		DmlCRBTag = DmlCRB[jk];
																		if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																		if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																		printf("\n ADPR:CV:P30:CR02: Participants Name: %s", type_name7);fflush(stdout);
																		//VI Reviewer will be work as T5_DRGatewayReviewer reviewer
																		if (tc_strcmp(type_name7,"T5_DRGatewayReviewer")==0)
																		{
																			CEReviewerFlag=1;
																			break;
																		}
																	}
																	printf("\n ADPR:CV:P30:CR02: Participants Name: %d", CEReviewerFlag);fflush(stdout);
																	if (CEReviewerFlag ==0)
																	{
																		//ERROR
																		printf("\n ADPR:ERROR:CR02:T5_DRGatewayReviewer:%s..................",DMLNo);fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR011:DML is eligible for DR Gateway reviewer, but no reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",DR_Gateway_Role);	
																		decision = EPM_nogo;
																		return decision;
																	}
																}
															}
														}
													}
													else
													{
														printf("\n CV_GATE:62::Vehicle is attached, so not valid case..");fflush(stdout);
													}
												}
											}
										}
									}
									//START PEER REVIEWERS ----------------------------------------------------------------
									printf("\n CV_PEER:63:START:PEER REVIEWERS ....................................");fflush(stdout);
									if(tc_strstr(DML_info1,"DMLASGB02") == NULL)
									{
										printf("\n CV_PEER:64:TASK:REMOVING PEER REVIEWERS FOR TASK START......\n");fflush(stdout);
										if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
										if (DmlTask_tag!=NULLTAG)
										{		
											if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
											printf("\n CV_PEER:65:TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
											printf("\n CV_PEER:71:START:CVBU:ADDING PEER REVIEWERS FOR TASK START......\n");fflush(stdout);
											printf("\n DML type:sDMLrlstype:[%s] ProjectID: [%s]\n",sDMLrlstype,ProjectID); fflush(stdout);
											for (t=0;t<Tskcout ;t++ )
											{ 
												CVPeerFlag=0;
												if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
												//printf("\n MT:is_Tsklatst %d",is_Tsklatst);fflush(stdout);

												if(is_Tsklatst != true)
												{
													printf("\n ACV_GATE:72:is_Tsklatst is not true .....\n");fflush(stdout);
												}
												else
												{	
													TskRev_t = TskRev_tag[t];

													if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
													if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
													printf("\n CV_PEER:73: Task class..:%s",Tsk_class); fflush(stdout);
													if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
													{
														//Setting Peer Reviewers.
														if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
														printf("\n CV_PEER:74: Task Name :[%s]",Task_name);fflush(stdout);
														DsgGrp=subString(Task_name,11,2);
														DsgGrup=(int) atoi(DsgGrp);
														printf(" and design group: [%s] DsgGrup [%d]\n",DsgGrp,DsgGrup);fflush(stdout);
														if((tc_strcmp(DMLType,"PDR")!=0) && (tc_strcmp(DMLType,"TODR")!=0)&& (tc_strcmp(DMLType,"Veh")!=0))
														{
															printf("\n CV_PEER:75:SETTING CVBU Peer Reviewer.....: ");fflush(stdout);
															if(SA_find_group(groupNameCV, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
															if((tc_strcmp(DsgGrp,"CO")==0)||(tc_strcmp(DsgGrp,"SP")==0))
															{
																printf(" CO/SP task skipped.. \n"); fflush(stdout);
																CVPeerFlag=0;
															}
															else if((DsgGrup ==33) ||(DsgGrup ==35)||(DsgGrup ==40))
															{
																if(tc_strcmp(ProjectClass,"PRD")==0)
																{
																	printf("\nSkip �Peer_AXLE_W_T_Reviewers� group to PRD projects as per TCE in module release DML \n"); fflush(stdout);
																}
																else
																{
																	printf("Axle_Peer_role.. \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
															}
															else if ((DsgGrup >=60) && (DsgGrup <=99))
															{
																printf("CAB_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if (DsgGrup ==31)
															{
																printf("Chassis_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if (DsgGrup ==54)
															{
																printf("E_and_E_Peer_role..54 group \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if (DsgGrup ==16)
															{
																if(tc_strcmp(DMLType,"EP")==0)
																{
																	//check project code.
																	if((tc_strstr(PRD_info1,ProjectID)!=NULL)||(tc_strstr(PRD_info2,ProjectID)!=NULL)||(tc_strstr(PRD_info3,ProjectID)!=NULL)||(tc_strstr(PRD_info4,ProjectID)!=NULL))
																	{
																		printf("EP:P1:Engine_Peer_role.. \n"); fflush(stdout);
																		CVPeerFlag=1;
																	}
																	else
																	{
																		printf("EP:P2:E_and_E_Peer_role..Other Project \n"); fflush(stdout);
																		CVPeerFlag=1;
																	}
																}
																else if(tc_strstr(DML_info10,sDMLrlstype) != NULL)
																{
																	printf(" P3:Engine_Peer_role.. \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
																else
																{
																	printf("P4:E_and_E_Peer_role.. \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
															}
															else if ((DsgGrup ==42)||(DsgGrup ==43))
															{
																printf("Brakes_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if(DsgGrup ==50)
															{
																if(tc_strstr(DML_info10,sDMLrlstype) != NULL)
																{
																	printf("P5:Engine_Peer_role..50Group \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
																else
																{
																	printf("PTrain_Peer_role.. \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
															}
															else if(DsgGrup ==21)
															{
																if(tc_strstr(DML_info10,sDMLrlstype) != NULL)
																{
																	printf("P6:Engine_Peer_role..21Group \n"); fflush(stdout);
																	CVPeerFlag=1;
																}
																else
																{
																	printf("\n Peer review skipped.. \n"); fflush(stdout);
																}
															}
															else if ((DsgGrup ==47)||(DsgGrup ==49))
															{
																printf("PTrain_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if ((DsgGrup ==29)||(DsgGrup ==30)||(DsgGrup ==46))
															{
																printf("Steering_System_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if (DsgGrup ==32)
															{
																printf("Suspenssion_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else if (DsgGrup ==28)
															{
																printf("Gearbox_Peer_role.. \n"); fflush(stdout);
																CVPeerFlag=1;
															}
															else
															{
																printf("\n CV_PEER:76: ELSE Other design group.. \n"); fflush(stdout);
															}
															printf("\n CV_PEER:77: Find  grp member for Peer count.[%d] \n",CVPeerFlag); fflush(stdout);
															if(CVPeerFlag>0)
															{
																printf("\n CV_PEER:76: Task is eligible for Peer reviewer:%s\n",Task_name); fflush(stdout);
																getCurrentDateTime(cCurrentAccessDate);
																printf("\n Before Time : %s",cCurrentAccessDate);
																if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
																if (Tsk_CRB_rel_type!=NULLTAG)
																{
																	if(GRM_list_secondary_objects_only(TskRev_t,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
																	printf("\n CV_PEER:67:TASK: count: %d",CRBcunt);fflush(stdout);	
																	if (CRBcunt >0)
																	{
																		CEReviewerFlag=0;
																		printf("\n ADPR:CV:P30:CR01: checking for Peer Reviewer: %s", DMLNo);fflush(stdout);
																		for (jk=0;jk<CRBcunt ;jk++ )
																		{	
																			//type_name7=NULL;
																			DmlCRBTag = TskCRB[jk];
																			if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																			if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																			printf("\n ADPR:CV:P30:CR02: Peer Name: %s", type_name7);fflush(stdout);
																			//VI Reviewer will be work as T5_PeerReviewer reviewer
																			if (tc_strcmp(type_name7,"T5_PeerReviewer")==0)
																			{
																				CEReviewerFlag=1;
																				break;
																			}
																		}
																		printf("\n ADPR:CV:P30:Peer: Participants Name: %d", CEReviewerFlag);fflush(stdout);
																		if (CEReviewerFlag ==0)
																		{
																			//ERROR
																			printf("\n ADPR:ERROR:CR02:T5_PeerReviewer:%s..................",DMLNo);fflush(stdout);
																			EMH_clear_errors();
																			EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:ADPR012:Task is eligible for Peer reviewer, but no reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",ProjectID);	
																			decision = EPM_nogo;
																			return decision;
																		}
																	}
																}
															}
														}
														else
														{
															printf("\n CV_PEER:79: Other DML Type...... \n"); fflush(stdout);
														}
													}
												}
											}
										}
									}
									printf("\n ASSIGN:CV:END:CVBU:ADDING PEER REVIEWERS FOR TASK START......\n");fflush(stdout);
								}
							}
						}
					}
					else if(tc_strstr(DML_info1,"PVRule01")==NULL)
					{
						printf("\n ASSIGN:function for PVBU to check participants..");fflush(stdout);
						if(AOM_ask_value_string(objTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
						printf("\n PVADP:P1:DML/Task Number: [%s].", DMLNo);fflush(stdout);
						if(AOM_ask_value_string(objTag,"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						printf("\n PVADP:P2:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);
						if(AOM_ask_value_string(objTag,"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
						printf("\n PVADP:P3:DML_BU is :%s\n",DML_BU);fflush(stdout);
						if(tc_strstr(DML_info1,"PVRule02") == NULL)
						{
							if(tc_strcmp(DMLType,"")==0)
							{
								printf("\n PVADP:P4:%s:ERROR:DML type is NULL..................",DMLNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP001:DML type is NULL, Please get valid DML type updated from DML support team.\n",DMLNo);	
								decision = EPM_nogo;
								return decision;
							}
							if(tc_strcmp(DML_BU,"")==0)
							{
								printf("\n PVADP:P5:%s:ERROR:DMLBU is NULL..................",DMLNo);fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP002:DML business unit is NULL, Please get it updated from DML support team.\n.",DMLNo);	
								decision = EPM_nogo;
								return decision;
							}
						}
						if(tc_strstr(DML_BU,"CV") != NULL)
						{
							printf("\n PVADP:P6:Assign dynamic Party handler bypassed for CVBU..");fflush(stdout);
						}
						else
						{
							if(tc_strcmp(DMLType,"Veh")!=0)
							{
								if(AOM_ask_value_string(objTag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
								printf("\n PVADP:P7: ProjectID : %s",ProjectID);   fflush(stdout);
								if(tc_strstr(DML_info1,"PVRule03") == NULL)
								{
									if(tc_strcmp(ProjectID,"")==0)
									{
										printf("\n PVADP:P8:%s:ERROR:DML Project is NULL..................",DMLNo);fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP003:DML project code is NULL, Please get it updated from DML support team.\n.",DMLNo);	
										decision = EPM_nogo;
										return decision;
									}
								}
								if(ProjectID)
								{
									if(QRY_find2("Qury_Project", &queryTag));
									printf("\n PVADP:P9:After Prd_Project: QRY_find2");fflush(stdout);
									if (queryTag)
									{
										printf("\n PVADP:P10:Found Query");fflush(stdout);
									}
									else
									{
										printf("\n PVADP:P11:Not Found Query");fflush(stdout);
									}
									qry_values[0] = ProjectID;
									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
									printf("\n PVADP:P12: resultCount : %d\n", resultCount); fflush(stdout);
									if(resultCount > 0)
									{
										printf("\n PVADP:P13:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
										Project_t = t5_Project[0];
										if (Project_t!=NULLTAG)
										{
											if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
											if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
											printf("\n PVADP:P14: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
											if(tc_strstr(DML_info1,"PVRule04") == NULL)
											{
												if(tc_strcmp(Proj_PltFrm,"")==0)
												{
													printf("\n PVADP:P15:%s:ERROR:Project platform is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP004:Project platform is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
													decision = EPM_nogo;
													return decision;
												}
												if(tc_strcmp(Proj_BU,"")==0)
												{
													printf("\n PVADP:P15:%s:ERROR:Project proj BU is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP005:Project business unit is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
													decision = EPM_nogo;
													return decision;
												}
												if(tc_strcmp(ProjectClass,"")==0)
												{
													printf("\n PVADP:P15:%s:ERROR:Project Proj Class is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP006:Project class is NULL, Please get it updated from PLM admin team.\n.",ProjectID);	
													decision = EPM_nogo;
													return decision;
												}
											}
											//Query control table for PRDtoCVBU workflow project list.
											printf("\n PVADP:P16:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
											if(QRY_find2("ControlObjects", &qryTag));
											if (qryTag)
											{
												printf("\n PVADP:P17:Found Query ControlObjects \n");fflush(stdout);
											}
											else
											{
												printf("\n PVADP:P18:Not Found Query ControlObjects \n");fflush(stdout);
											}

											qry_values2[0] = "PRDCVBU";
											if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
											printf(" \n PVADP:P19:rsltCount :%d:", rsltCount); fflush(stdout);
											if(rsltCount > 0)
											{
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
												printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
												printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
												printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
											}
											if(tc_strstr(info3,"DMLASGPV")==NULL)
											{
												printf("\n PVADP:P20:%s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
												if(tc_strcmp(ProjectClass,"PRD")==0)
												{
													if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
													{
														PRDFlag=1;
														printf("\n PVADP:P20:.PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
													}
													else
													{
														PRDFlag=0;
														printf("\n PVADP:P20:.No project CVBU found: %d",PRDFlag); fflush(stdout);
													}
												}
												else
												{
													PRDFlag=1;
													printf("\n PVADP:P20:.No PRD project: %d",PRDFlag); fflush(stdout);
												}
												if (PRDFlag >0)
												{
													//############################### Checking PARTICIPALNTS START################################/
													if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
													if (dml_CRB_rel_type!=NULLTAG)
													{
														printf("\n PVADP:P20:CHk PARTICIPALNTS START.. \n");fflush(stdout);
														if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
														printf("\n PVADP:P20: DmlCRB count: %d",CRBcount);fflush(stdout);	
													}
													printf("\n PVADP:P20:START ASSIGNING REVIEWERS: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
													if((tc_strcmp(Proj_BU,"PCBU")==0)||(tc_strcmp(Proj_BU,"PVBU")==0))
													{
														if(tc_strcmp(DMLType,"SVR")==0)
														{
															//VI Reviewer for SVR only.
															printf("\n PVADP:P21:PCBU: Setting VI Analyst...");fflush(stdout);
															if (CRBcount >0)
															{
																CEReviewerFlag=0;
																printf("\n PVADP:P22: checking for VI Reviewer: %s", DMLNo);fflush(stdout);
																for (jk=0;jk<CRBcount ;jk++ )
																{	
																	//type_name7=NULL;
																	DmlCRBTag = DmlCRB[jk];
																	if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																	if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																	printf("\n PVADP:P23: Participants Name: %s", type_name7);fflush(stdout);
																	//VI Reviewer will be work as VI reviewer
																	if (tc_strcmp(type_name7,"T5_VIReviewer")==0)
																	{
																		CEReviewerFlag=1;
																		break;
																	}
																}
																if (CEReviewerFlag ==0)
																{
																	//ERROR
																	printf("\n PVADP:P24:T5_VIReviewer:%s..................",DMLNo);fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP007:DML is eligible for VI reviewer, but no VI reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",ProjectID);	
																	decision = EPM_nogo;
																	return decision;
																}
															}
														}
														else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
														{
															if(tc_strcmp(Proj_PltFrm,"")!=0)
															{
																if(tc_strcmp(Proj_PltFrm,"TBD")==0)
																{
																	printf("\n PVADP:P25:BOM Analyst Set to NULL since platform is TBD...");fflush(stdout);
																}
																else
																{
																	BomAna_Role = (char	*)MEM_alloc(100);
																	tc_strcpy(BomAna_Role,"");
																	tc_strcpy(BomAna_Role,Proj_PltFrm);
																	tc_strcat(BomAna_Role,"_");
																	tc_strcat(BomAna_Role,"BOM_Analyst");
																	printf("\n PVADP:P25: after BomAna_Role: %s",BomAna_Role);   fflush(stdout);
																	if (CRBcount >0)
																	{
																		CEReviewerFlag=0;
																		printf("\n PVADP:P27: checking for BOM Reviewer: %s", DMLNo);fflush(stdout);
																		for (jk=0;jk<CRBcount ;jk++ )
																		{	
																			//type_name7=NULL;
																			DmlCRBTag = DmlCRB[jk];
																			if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																			if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																			printf("\n PVADP:P27:: Participants Name: %s", type_name7);fflush(stdout);
																			//VI Reviewer will be work as T5_BOMAnalyst
																			if (tc_strcmp(type_name7,"T5_BOMAnalyst")==0)
																			{
																				CEReviewerFlag=1;
																				break;
																			}
																		}
																		if (CEReviewerFlag ==0)
																		{
																			//ERROR
																			printf("\n APVADP:P27:T5_BOMAnalyst:%s..................",DMLNo);fflush(stdout);
																			EMH_clear_errors();
																			EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP008:DML is eligible for BOM reviewer, but no BOM reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",ProjectID);	
																			decision = EPM_nogo;
																			return decision;
																		}
																	}																	
																}
															}
															else
															{
																printf("\n PVADP:P28:Proj Platform is NULL...");fflush(stdout);
															}
														}
														else
														{
															printf("\n PVADP:P29: NO Assignment for XO/TOO/PDR dmls...... \n"); fflush(stdout);
														}
														printf("\n PVADP:P29:TASK:Checking REVIEWERS FOR TASK START......\n");fflush(stdout);
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTask_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
															printf("\n PVADP:P30:TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
															for (t=0;t<Tskcout ;t++ )
															{ 
																DMUtaskflag=0;
																if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
																if(is_Tsklatst != true)
																{
																	printf("\n PVADP:P31:is_Tsklatst is not true .....\n");fflush(stdout);
																}
																else
																{	
																	TskRev_t = TskRev_tag[t];
																	if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
																	if (Tsk_CRB_rel_type!=NULLTAG)
																	{
																		if(GRM_list_secondary_objects_only(TskRev_t,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
																		printf("\n CV_PEER:67:TASK: count: %d",CRBcunt);fflush(stdout);	
																	}
																	if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
																	if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
																	printf("\n PVADP:P32: Task class..:%s",Tsk_class); fflush(stdout);
																	if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
																	{
																		//Setting DMU Reviewers.
																		if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
																		printf("\n PVADP:P33:Task Name :[%s]",Task_name);fflush(stdout);
																		DsgGrp=subString(Task_name,11,2);
																		DsgGrup=(int) atoi(DsgGrp);
																		printf(" and design group: [%s]\n",DsgGrp);fflush(stdout);
																		if(tc_strcmp(DMLType,"SVR")==0)
																		{
																			if (CRBcunt >0)
																			{
																				int BIWReviewerFlag=0;
																				int PTReviewerFlag=0;
																				int CHReviewerFlag=0;
																				int TRMReviewerFlag=0;
																				int EEReviewerFlag=0;
																				printf("\n PVADP:P34: checking for T5_BIWReviewer: %s", DMLNo);fflush(stdout);
																				for (jk=0;jk<CRBcunt ;jk++ )
																				{	
																					//type_name7=NULL;
																					DmlCRBTag = TskCRB[jk];
																					if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																					if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																					printf("\n PVADP:P35: Participants Name: %s", type_name7);fflush(stdout);
																					
																					if (tc_strcmp(type_name7,"T5_BIWReviewer")==0)
																					{
																						BIWReviewerFlag=1;
																					}
																					if (tc_strcmp(type_name7,"T5_PTReviewer")==0)
																					{
																						PTReviewerFlag=1;
																					}
																					if (tc_strcmp(type_name7,"T5_CHReviewer")==0)
																					{
																						CHReviewerFlag=1;
																					}
																					if (tc_strcmp(type_name7,"T5_TRIMReviewer")==0)
																					{
																						TRMReviewerFlag=1;
																					}
																					if (tc_strcmp(type_name7,"T5_EEReviewer")==0)
																					{
																						EEReviewerFlag=1;
																					}
																				}
																				if (EEReviewerFlag ==0)
																				{
																					//ERROR
																					printf("\n PVADP:P36:T5_EEReviewer:%s..................",DMLNo);fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP009:DML is eligible for EE reviewer, but no EE COC reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",Task_name);	
																					decision = EPM_nogo;
																					return decision;
																				}
																				if (BIWReviewerFlag ==0)
																				{
																					//ERROR
																					printf("\n PVADP:P37:T5_BIWReviewer:%s..................",DMLNo);fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP010:DML is eligible for BIW reviewer, but no BIW COC reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",Task_name);	
																					decision = EPM_nogo;
																					return decision;
																				}
																				if (PTReviewerFlag ==0)
																				{
																					//ERROR
																					printf("\n PVADP:P38:T5_PTReviewer:%s..................",DMLNo);fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP011:DML is eligible for PT reviewer, but no PT COC reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",Task_name);	
																					decision = EPM_nogo;
																					return decision;
																				}
																				if (CHReviewerFlag ==0)
																				{
																					//ERROR
																					printf("\n PVADP:P39:T5_CHReviewer:%s..................",DMLNo);fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP012:DML is eligible for Chassis reviewer, but no Chassis COC reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",Task_name);	
																					decision = EPM_nogo;
																					return decision;
																				}
																				if (TRMReviewerFlag ==0)
																				{
																					//ERROR
																					printf("\n PVADP:P40:T5_TRIMReviewer:%s..................",DMLNo);fflush(stdout);
																					EMH_clear_errors();
																					EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP013:DML is eligible for TRIM reviewer, but no TRIM COC reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",Task_name);	
																					decision = EPM_nogo;
																					return decision;
																				}
																			}
																		}
																		else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
																		{
																			//COC DMU Reviewer
																			printf("\n PVADP:P41:DsgGrup:%d ",DsgGrup);fflush(stdout);
																			//if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
																			if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
																			{
																				DMUtaskflag=1;
																			}
																			else if ((DsgGrup >=60) && (DsgGrup <=66))
																			{
																				DMUtaskflag=1;
																			}
																			else if ((DsgGrup >=70) && (DsgGrup <=80))
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==88)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==81)
																			{
																				DMUtaskflag=1;
																			}
																			else if ((DsgGrup >=67) && (DsgGrup <=69))
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==55)
																			{
																				DMUtaskflag=1;
																			}
																			else if ((DsgGrup >=91) && (DsgGrup <=96))
																			{
																				DMUtaskflag=1;
																			}
																			else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==49)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==31)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==47)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==83)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==24)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==97)
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==46)
																			{
																				DMUtaskflag=1;
																			}
																			else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
																			{
																				DMUtaskflag=1;
																			}
																			else if(DsgGrup ==58)
																			{
																				DMUtaskflag=1;
																			}
																			else
																			{
																				printf("\n PVADP:P41: ELSE Other design group.. \n"); fflush(stdout);
																			}
																			
																			printf("\n PVADP:P42: Find  grp member for DMU count..%d \n",DMUtaskflag); fflush(stdout);
																			if(DMUtaskflag>0)
																			{
																				//T5_DMUReviewer
																				if (CRBcunt >0)
																				{
																					CEReviewerFlag=0;
																					printf("\n PVADP:P43: checking for BOM Reviewer: %s", DMLNo);fflush(stdout);
																					for (jk=0;jk<CRBcunt ;jk++ )
																					{	
																						//type_name7=NULL;
																						DmlCRBTag = TskCRB[jk];
																						if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
																						if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
																						printf("\n PVADP:P44: Participants Name: %s", type_name7);fflush(stdout);
																						//VI Reviewer will be work as T5_BOMAnalyst
																						if (tc_strcmp(type_name7,"T5_DMUReviewer")==0)
																						{
																							CEReviewerFlag=1;
																							break;
																						}
																					}
																					if (CEReviewerFlag ==0)
																					{
																						//ERROR
																						printf("\n PVADP:P44:T5_DMUReviewer:%s..................",DMLNo);fflush(stdout);
																						EMH_clear_errors();
																						EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:PVADP014:DML task is eligible for DMU reviewer, but no DMU reviewer is assigned.\nPlease get it assigned from DML support tem.\n.",ProjectID);	
																						decision = EPM_nogo;
																						return decision;
																					}
																				}
																			}
																		}
																		else
																		{
																			printf("\n PVADP:P45: Other DML Type...... \n"); fflush(stdout);
																		}

																		if(tc_strstr(DML_info1,"MF_1")==NULL)
	                                                                    {
																			Printf("3135 :Inside Memory releasing");
                                                                            if(DMLType){MEM_free(DMLType);}
																			if(DML_BU){MEM_free(DML_BU);}
	                                                                    }                                                                  
																	}
																}
															}
														}
													}
													else if(tc_strcmp(Proj_BU,"CVBU")==0)
													{
														printf("\n PVADP:P46: Other Program will set for CVBU...... \n"); fflush(stdout);
													}
													else
													{
														printf("\n PVADP:P47: PRD Dml..... \n"); fflush(stdout);
													}
												}
											}
										}
										else
										{
											printf("\n PVADP:P48:NO PROJECT AVAILABLE..\n");fflush(stdout);
										}
									}
									else
									{
										PRDFlag=0;
										printf("\n PVADP:P49: No project found: %d",PRDFlag); fflush(stdout);
									}
								}
							}
						}
					}
					else
					{
						printf("\n ASSIGN:function tm_Assign_Dynamic_party_Rule_CVFun is OFF.");fflush(stdout);
					}
				}
			}
		}
	}
	
	/*if(DML_info1){MEM_free(DML_info1);}
	if(DML_info2){MEM_free(DML_info2);}
	if(DML_info3){MEM_free(DML_info3);}
	if(DML_info4){MEM_free(DML_info4);}
	if(DML_info6){MEM_free(DML_info6);}
	if(DML_info7){MEM_free(DML_info7);}
	if(DML_info8){MEM_free(DML_info8);}
	if(DML_info9){MEM_free(DML_info9);}
	if(DML_info10){MEM_free(DML_info10);}
	if(PRD_info1){MEM_free(PRD_info1);}
	if(PRD_info2){MEM_free(PRD_info2);}
	if(PRD_info3){MEM_free(PRD_info3);}
	if(PRD_info4){MEM_free(PRD_info4);}
	if(DMLType){MEM_free(DMLType);}
	if(DML_BU){MEM_free(DML_BU);}
	if(ProjectID){MEM_free(ProjectID);}
	if(DMLNo){MEM_free(DMLNo);}
	if(ProjectClass){MEM_free(ProjectClass);}
	if(ProjDesc){MEM_free(ProjDesc);}
	if(Proj_PltFrm){MEM_free(Proj_PltFrm);}
	if(Proj_BU){MEM_free(Proj_BU);}
	if(DMLDrStat){MEM_free(DMLDrStat);}
	if(DMLReason){MEM_free(DMLReason);}
	if(DesignGroupList){MEM_free(DesignGroupList);}
	if(DMLVertical){MEM_free(DMLVertical);}
	if(sPlntToPlnt){MEM_free(sPlntToPlnt);}
	if(Prtobj_type){MEM_free(Prtobj_type);}
	if(Part_no){MEM_free(Part_no);}
	if(Part_prj){MEM_free(Part_prj);}
	if(DesgTyp){MEM_free(DesgTyp);}
	if(Prtrev_idd){MEM_free(Prtrev_idd);}
	if(Partno){MEM_free(Partno);}
	if(PartTyp){MEM_free(PartTyp);}
	if(sPrtColInd){MEM_free(sPrtColInd);}
	if(rev_idd){MEM_free(rev_idd);}
	if(rel_status){MEM_free(rel_status);}
	if(TechSpecNum){MEM_free(TechSpecNum);}
	if(PartsTag){MEM_free(PartsTag);}*/
	printf("\n tm_Assign_party_Rule_CV Function end...");fflush(stdout);
	TC_write_syslog("\n tm_Assign_party_Rule_CV Function end...");
	return decision;
}

int IsFirstTImeRelRevADP(char* prtno,char* DMLDrStat,char* DML_info7)
{
	int cr =0;
	int crr =0;
	int DROKFlag =0;
	int PRTSTVALU =0;
	int Child_Rev_count =0;
	int Chld_Rel_Stus_Cunt =0;
	tag_t	Child_All_Rev		= NULLTAG;
	tag_t*	Child_rev_list		= NULLTAG;
	tag_t*	Child_status_lst	= NULLTAG;
	char*	 PrtDRs = NULL;
	char*	 Chld_Rel_Stus = NULL;
	char*	 Child_Prt_DR = NULL;
	char*	 Child_Parttyp = NULL;
	char*	 Child_rev_idd = NULL;
	char*	 PRTDRStr = NULL;

	printf("\n IsFirstTImeRelRevADP Function started...");fflush(stdout);
	TC_write_syslog("\n IsFirstTImeRelRevADP Function started...");
	//GETTING RELEASED REVISION
	printf("\n DR:prtno..:%s:%s: DRGateway part type:%s.", prtno,DMLDrStat,DML_info7);fflush(stdout);
	Child_All_Rev= t5GetItemRevisonADP(prtno);
	if(Child_All_Rev==NULLTAG)
	{
		printf("\n DR4:Child_All_Rev is NULL.\n");fflush(stdout);
	}
	else
	{
		if(ITEM_list_all_revs (Child_All_Rev, &Child_Rev_count, &Child_rev_list)!=ITK_ok)PrintErrorStack();
		printf("\n DR:Total Child rev found: %d", Child_Rev_count);fflush(stdout);
		if(Child_Rev_count > 0)
		{
			cr=0;
			DROKFlag=0;
			for(cr=Child_Rev_count-1;cr>=0;cr--)
			{
				Chld_Rel_Stus_Cunt=0;
				DROKFlag=0;
				Child_rev_idd=NULL;
				if(AOM_ask_value_string (Child_rev_list[cr], "t5_PartType", &Child_Parttyp)!=ITK_ok)PrintErrorStack();
				if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
				if(AOM_UIF_ask_value (Child_rev_list[cr], "t5_PartStatus", &PrtDRs)!=ITK_ok)PrintErrorStack();
				printf("\n DR:Latest released rev is:%s: Part Type: %s: DMLDR: %s  PrtDRs:%s", Child_rev_idd,Child_Parttyp,DMLDrStat,PrtDRs);fflush(stdout);
				if(tc_strstr(DML_info7,Child_Parttyp)!=NULL)
				{
					if(WSOM_ask_release_status_list (Child_rev_list[cr], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
					printf("\n DR:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
					if(Chld_Rel_Stus_Cunt > 0)
					{
						crr=0;
						for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
						{
							DROKFlag=0;
							if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
							printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
							if((tc_strstr(Chld_Rel_Stus,"Released")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Rlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
							{
								DROKFlag=0;
								if (tc_strcmp(DMLDrStat,PrtDRs)==0)
								{
									printf("\n DR:Latest released rev is Released:%s:%s.",DMLDrStat,Child_rev_idd);fflush(stdout);
									DROKFlag=1;
									break;
								}
								else
								{
									printf("\n DR:Latest released rev is NOT Released:%s:%s.",DMLDrStat,Child_rev_idd);fflush(stdout);
									DROKFlag=0;
									//return 0;
								}
							}
						}
						if (DROKFlag >0)
						{
							break;
						}
					}
				}
			}
			printf("\n DR:DROKFlag: %d",DROKFlag);fflush(stdout);
			if (DROKFlag >0)
			{
				printf("\n Released rev found:%s ",DMLDrStat);fflush(stdout);
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	printf("\n IsFirstTImeRelRevADP Function end...");fflush(stdout);
	TC_write_syslog("\n IsFirstTImeRelRevADP Function end...");

	return 0;	
}



int tm_GetESOVCAttriFrmClassiObjADP( tag_t  ClsObj , char *clsKeyAtrrId)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char*   Ptype_name=NULL;
	char*   Stype_name=NULL;
	char*   relation_name=NULL;
	char   *username  = NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	double iUnladenWeight=0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	int partRevCnt=0;
    tag_t* partRevTagObjs = NULLTAG;
    tag_t partRevTag = NULLTAG;

	printf("\n tm_GetESOVCAttriFrmClassiObjADP Function started...");fflush(stdout);
	TC_write_syslog("\n tm_GetESOVCAttriFrmClassiObjADP Function started...");
	if(ClsObj!=NULLTAG)
	{
		char * 	theClassId =NULL;
		int  	theAttributeCount;
		int * 	theAttributeIds;
		int * 	theAttributeValCounts;
		char ** 	theAttributeValues;
		tag_t 	theICOTag=NULLTAG;
		printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
		char keyPrefix[10];
		tc_strcpy(keyPrefix,"-");
		tc_strcat(keyPrefix,clsKeyAtrrId);
		printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
		const char * 	key_lov_id=keyPrefix; 
		char * 	key_lov_name;
		int  	options;
		int i;
		int keyfound=0;
		int  	n_lov_entries;
		char ** 	lov_keys;
		char ** 	lov_values;
		logical * 	deprecated_staus;
		char * 	owning_site;
		char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
		int  	n_shared_sites;
		char ** 	shared_sites ;
		theICOTag=ClsObj;
		if(ICS_ask_attribute_value(ClsObj,clsKeyAtrrId,&AttrKeyValue)!=ITK_ok)PrintErrorStack();
		
		printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
		if(AttrKeyValue)
		{
		
			if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites)!=ITK_ok)PrintErrorStack();
			printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
			for(i=0;i<n_lov_entries;i++)								
			{
				if(tc_strcmp(AttrKeyValue,lov_keys[i])==0)
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(lov_values[i])
					{
						ESOattrValue    =(char *) MEM_alloc(20);
						tc_strcpy(ESOattrValue,"");
						tc_strcpy(ESOattrValue,lov_values[i]);
						printf("\n ESOattrValue  =%s",ESOattrValue); fflush(stdout);
						if((tc_strcmp(AttrKeyValue,"YES")==0)||(tc_strcmp(AttrKeyValue,"yes")==0))
						{
							return 1;
						}
						else
						{
							return 0;
						}
					}
				}
			}
		}
		else
		{
			return 0;
		}
	}
	printf("\n tm_GetESOVCAttriFrmClassiObjADP Function end...");fflush(stdout);
	TC_write_syslog("\n tm_GetESOVCAttriFrmClassiObjADP Function end...");
	return 0;
}

int getClsCodeAttrNoWrtTSBURewADP( char *TechSpecBusunit,int   *retCodeattrno)
{
    int ifail = ITK_ok;

    //tag_t        query           = NULLTAG;    
    tag_t    *RetICOAttrNoContrlObjs=NULLTAG;
    char *CntrlObjName=NULL;
    char *Attrid=NULL;
    int EsoAttridInt=0;
    int retCntrlObjcount=0;

	printf("\n getClsCodeAttrNoWrtTSBURewADP Function started...");fflush(stdout);
	TC_write_syslog("\n getClsCodeAttrNoWrtTSBURewADP Function started...");
    if(TechSpecBusunit)
    {
        retCntrlObjcount=0;
        //ITKCALL(getNPIAttrObj(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
        ITKCALL(getICOUpdCOADP(TechSpecBusunit,"ICOESOAttrNo",&retCntrlObjcount,&RetICOAttrNoContrlObjs));
        printf("\n after call getCodeAttrNoWrtTSBURew count: %d \n",retCntrlObjcount);fflush(stdout);
        if(retCntrlObjcount>0)
        {
            ITKCALL( AOM_ask_value_string(RetICOAttrNoContrlObjs[0], "object_name", &CntrlObjName));
            printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
            AOM_ask_value_string(RetICOAttrNoContrlObjs[0], "t5_Userinfo1", &Attrid);
            printf("\n after getAttrid: info1[%s] \n",Attrid);fflush(stdout);
        }
    }
    printf("\n getAttrObj: info1[%s] \n",Attrid);fflush(stdout);
    if(Attrid!=NULL)
    {
         EsoAttridInt=atoi(Attrid);
    }
    if(EsoAttridInt>0)
    {
         *retCodeattrno =EsoAttridInt;
    }
    else
    {
        EsoAttridInt=8103;
        printf("\n EsoAttridInt=%d\n",EsoAttridInt);fflush(stdout);
         *retCodeattrno =EsoAttridInt;

    }
    printf("\n\n End Qry for getCodeAttrNoWrtTSBURew control object size ==%d with retCodeattrno=%d\n",retCntrlObjcount,*retCodeattrno);fflush(stdout);

	printf("\n getClsCodeAttrNoWrtTSBURewADP Function end...");fflush(stdout);
	TC_write_syslog("\n getClsCodeAttrNoWrtTSBURewADP Function end...");

    return 0;
    //return ifail;
}	


int getICOUpdCOADP( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n getICOUpdCOADP Function started...");fflush(stdout);
	TC_write_syslog("\n getICOUpdCOADP Function started...");
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);
	
	printf("\n b4 Qry getICOUpdCORew");fflush(stdout);

	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getICOUpdCORew");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getICOUpdCORew control object size ==%d \n",*n_found);fflush(stdout);
	
	printf("\n getICOUpdCOADP Function end...");fflush(stdout);
	TC_write_syslog("\n getICOUpdCOADP Function end...");
	return 0;
	//return ifail;
}


int t5GetItemRevisonADP(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	printf("\n t5GetItemRevisonADP Function started...");fflush(stdout);
	TC_write_syslog("\n t5GetItemRevisonADP Function started...");

	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n Y13: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n Y14: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/
	printf("\n t5GetItemRevisonADP Function end...");fflush(stdout);
	TC_write_syslog("\n t5GetItemRevisonADP Function end...");

	return OutPutTag;
}