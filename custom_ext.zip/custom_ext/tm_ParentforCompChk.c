
#include "TMLLibrary_server_exits.h"

#define Rollup_err 919002

EPM_decision_t tm_ParentforCompChk(EPM_rule_message_t msg)
{
	
	int i      =  0;
	int     Compfound      =  0;
	int no_attach	=  0;
	int     n_parents =  0;
	int error_code	= ITK_ok;
	int *levels = 0;
	int	Tskcnt	= 0;
	int	Xpartcount	= 0;
	int     Xp      =  0;
	int j =0;
	int countt =0;
	int     ParentPrtAttachFlg      =  0;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;

	tag_t *taskAttachments=NULLTAG;
	tag_t *parents = NULLTAG;
	tag_t tPrntTag = NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t	roottask        =  NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *XPartTags= NULLTAG;
	tag_t DMLRevTg         = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t   DRqryTag		= NULLTAG;
	tag_t   DMLtsk_tag		= NULLTAG;
	tag_t   *DRCntrlObjectTag   = NULLTAG;

	char	*DMLtype		=  NULL;
	char	*partProjectCode		=  NULL;
	char	*Spartid		        =  NULL;
	char*   ObjTyp=  NULL;
	char	*sPrntNo		    =  NULL;
	char   *partprentcheck1 =NULL;
	char   *partprentcheck2 =NULL;
	char	*parttype		=  NULL;
	char	*sDMLtaskno		=  NULL;
	char	*sDMLrlstype		=  NULL;
	char	*sPartTyp		=  NULL;
	char	*sDMLno		=  NULL;
	char	*partid		    =  NULL;
	char	*ErorStrg		=  NULL;
	char	*sErroPart		=  NULL;
	char	*taskid		        =  NULL;
	char*	CurrentTask				=NULL;


	logical is_latest;
	
	
	
	char    *DR_qry_entry[1]  = {"SYSCD"};
	
	
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	sPartTyp =(char *) MEM_alloc(20 * sizeof(char *));
	sDMLrlstype =(char *) MEM_alloc(20 * sizeof(char *));
	
	ErorStrg =(char *) MEM_alloc(200 * sizeof(char *));
	sErroPart=(char *)MEM_alloc(20);


	printf("\n tm_ParentforCompChk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ParentforCompChk Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n Wt:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n Wt: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			//Query Control table.
			if(QRY_find2("ControlObjects", &DRqryTag));
			if (DRqryTag)
			{
				printf("\n Wt::Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Wt::Not Found Query ControlObjects \n");fflush(stdout);
			}

			DR_qry_values2[0] = "PARENTCHK";
			if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
			printf(" \n Wt::DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
			if(DR_rsltCount > 0)
			{
				//ON/OFF
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&partprentcheck1)!=ITK_ok)   PrintErrorStack();
				//Release_Type
				if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&partprentcheck2)!=ITK_ok)   PrintErrorStack();
				printf("\n Wt:A:partprentcheck1: %s \n",partprentcheck1);fflush(stdout);
				printf("\n Wt:A:partprentcheck2: %s \n",partprentcheck2);fflush(stdout);

				//ON/OFF of Loagic
				if(tc_strstr(partprentcheck1,"OFF") == NULL)
				{
					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
					{
						printf("\n inside loop of partprentcheck1 .\n");fflush(stdout);
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLtaskno)!=ITK_ok)PrintErrorStack();
						printf("\n Wt:sDMLtaskno:%s.",sDMLtaskno);fflush(stdout);
						if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
						if (tsk_dml_rel_type!=NULLTAG)
						{
							if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
							printf("\n Wt:DML Revision from Task for MR : %d",countt);fflush(stdout);
							for (j=0;j<countt ;j++ )
							{
								if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
								printf("\n Wt: is_latest MR is : %d\n",is_latest);fflush(stdout);

								if(is_latest != true)
								{
									printf("\n Wt:is_latest is not true .....\n");fflush(stdout);
								}
								else
								{
									DMLRevTg = DMLRevision[j];
									if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
									printf("\n Wt:sDMLno taken for processing...:%s.",sDMLno);fflush(stdout);

									if(DMLRevTg==NULLTAG)
									{
										printf("\n Wt::item_tag is NULL.\n");fflush(stdout);
										return decision;
									}
									else
									{
										printf("\n Wt::item_tag found.\n");fflush(stdout);
										
										if(DMLRevTg!=NULLTAG)
										{
											if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
											printf("\n DMLtype = %s \n",DMLtype);fflush(stdout);
											tc_strcpy(sDMLrlstype,"");
											tc_strcpy(sDMLrlstype,",");
											tc_strcat(sDMLrlstype,DMLtype);
											tc_strcat(sDMLrlstype,",");
											printf("\n sDMLrlstype:: %s",sDMLrlstype);fflush(stdout);
											if(tc_strstr(partprentcheck2,sDMLrlstype) != NULL) //condition is true only if DMLtype exists in partprentcheck2.
											{
												if(AOM_ask_value_tags(DMLRevTg,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
												printf("\n Wt::Now Tskcnt:%d\n",Tskcnt);fflush(stdout);

												if (Tskcnt>0)
												{
													Compfound=0;
													tc_strcpy(sErroPart,"");
													//FOR-1 Tasks
													for (j=0;j<Tskcnt ;j++)
													{
														DMLtsk_tag=Dml_tasks[j];

														if(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid)!=ITK_ok)PrintErrorStack();
														printf("\n taskid = %s \n",taskid);fflush(stdout);

														if(AOM_ask_value_tags(DMLtsk_tag,"CMHasSolutionItem",&Xpartcount,&XPartTags)!=ITK_ok)PrintErrorStack(); //
														printf("\n 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);

														printf("\n inside for loop");fflush(stdout);
														if(Xpartcount >0)
														{
															//FOR-2: parts
															for(Xp=0;Xp<Xpartcount;Xp++)
															{
																if(AOM_ask_value_string(XPartTags[Xp],"item_id",&partid)!=ITK_ok)PrintErrorStack();
																printf("\n partid = %s \n",partid);fflush(stdout);
																//Project code should not be 1111
																if(AOM_UIF_ask_value(XPartTags[Xp],"t5_ProjectCode",&partProjectCode)!=ITK_ok)PrintErrorStack();
																printf("\n partProjectCode = %s \n",partProjectCode);fflush(stdout);
																if(tc_strcmp(partProjectCode,"1111") != 0)
																{
																	printf("\n 1111 project code skip \n");fflush(stdout);
																	if(AOM_UIF_ask_value(XPartTags[Xp],"t5_PartType",&parttype)!=ITK_ok)PrintErrorStack();
																	printf("\n parttype = %s \n",parttype);fflush(stdout);
																	if((tc_strcmp(parttype,"C") == 0) || (tc_strcmp(parttype,"Component") == 0) )
																	{
																		Compfound ++;
																		ParentPrtAttachFlg=0;
																		
																		ITKCALL(PS_where_used_all(XPartTags[Xp],1,&n_parents,&levels,&parents));
																		printf("\n\n Total Parent Part : [%d]",n_parents); fflush(stdout);
																		//FOR-3: Parent part
																		for (int Xp1=0;Xp1<n_parents;Xp1++ )
																		{
																			tPrntTag=parents[Xp1];
																			if(AOM_ask_value_string(tPrntTag,"item_id",&sPrntNo)!=ITK_ok)PrintErrorStack();
																			//if(AOM_ask_value_string(tPrntTag,"release_status_list",&Release_Status)!=ITK_ok)PrintErrorStack();

																			printf("\n Checkinh Parent Part no.(%d):(%s)",Xp1,sPrntNo);fflush(stdout);
																			//Task loop
																			for (int jr=0;jr<Tskcnt ;jr++)
																			{
																				DMLtsk_tag=Dml_tasks[jr];

																				if(AOM_ask_value_string(DMLtsk_tag,"item_id",&taskid)!=ITK_ok)PrintErrorStack();
																				printf("\n Inside part type C taskid = %s \n",taskid);fflush(stdout);

																				if(AOM_ask_value_tags(DMLtsk_tag,"CMHasSolutionItem",&Xpartcount,&XPartTags)!=ITK_ok)PrintErrorStack(); //Change References
																				printf("\n Inside part type C 1.No of Parts found = %d\n",Xpartcount);fflush(stdout);
																				////Checkinging parent part in parts attached to task
																				for(int XPP=0;XPP<Xpartcount;XPP++)
																				{
																					if(AOM_ask_value_string(XPartTags[XPP],"item_id",&Spartid)!=ITK_ok)PrintErrorStack();
																					printf("\n checking Parent prt :%s with task part=(%d) %s \n",sPrntNo,XPP,Spartid);fflush(stdout);
																					if(tc_strcmp(Spartid,sPrntNo)==0)
																					{
																						ParentPrtAttachFlg=1;
																						printf("\n Parent part..:%s attached to task flag:%d",partid,ParentPrtAttachFlg);	fflush(stdout);
																						break;
																					}
																				}
																				if (ParentPrtAttachFlg >0)
																				{
																					break;
																				}
																			}
																			if (ParentPrtAttachFlg >0)
																			{
																				break;
																			}
																		}
																		if (ParentPrtAttachFlg ==0)
																		{
																			printf("\n Before: sErroPart: %s",sErroPart);fflush(stdout);
																			//note parent part on error snap
																			if (tc_strlen(sErroPart) < 500)
																			{
																				if ((tc_strlen(sErroPart) >65) && (tc_strlen(sErroPart) <70))
																				{
																					tc_strcat(sErroPart,"\n");
																				}
																				tc_strcat(sErroPart,partid);
																				tc_strcat(sErroPart,", ");
																				printf("\n After sErroPart: %s",sErroPart);fflush(stdout);
																			}
																		}
																	}
																}
															}
														}
													}
													//
													printf("\n Compfound:%d sErroPart:%s ",Compfound,sErroPart);fflush(stdout);
													if ((tc_strlen(sErroPart) >0) && (Compfound>0))
													{
														printf("\nERROR: Atleast one parent part should be attached to same DML for below mentioned child part. \n Please attach parent part and then sign off task.");fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err, "ERROR: Atleast one parent part should be attached to same DML for below mentioned child part. \n Please attach parent part and then sign off task.\n",sErroPart);
														decision = EPM_nogo;
														
													}
													else
													{
														printf("\n Success Code ");fflush(stdout);

													}
												}
											}
											printf("\n partprentcheck  in partprentcheck2 Release type not Found\n");fflush(stdout);
										}
									}
								}
							
							}
						}
					}
				}
				else
				{
					printf("\n Control obj partprentcheck is bypass\n ");	fflush(stdout);
				}
			}
		}
	}
	printf("\n tm_ParentforCompChk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ParentforCompChk Function end...");
	return decision;
}

