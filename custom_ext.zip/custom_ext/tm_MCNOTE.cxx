
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_MCNOTE.cxx
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   05-02-2018
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 05/02/2018   	 Sandeep Goyal			    Base Code
* 17/07/2023   	 Sandeep Goyal			    Nccessary Changes on UsageRT calculation to reflect the value in UI
* 26/07/2023   	 Sandeep Goyal			    Nccessary Changes on UsageRT calculation to reflect the value in UI

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <tccore/releasestatus.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include <epm/cr.h>
#include <qry/qry.h>
#include <epm/epm.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <cfm/cfm.h>
#include <fclasses/tc_date.h>
#include <epm/epm_task_template_itk.h>
#include <sub_mgr/tcactionhandler.h>
#include <user_exits/user_exits.h>
//#include <tccore/iman_msg.h>
#include <tccore/item_msg.h>
#include <extensionframework/callback.h>
#define ITK_err 910001
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}


logical StatusFound = false;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
/* CHARACTER ARRAY */
void setAddStrFamily(int *count,char ***strset,char* str)
{
	*count = *count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
		printf("\n setAddStr2");fflush(stdout);
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
		printf("\n setAddStr3");fflush(stdout);
	}
	else
	{
		printf("\n setAddStr4");fflush(stdout);
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
		printf("\n setAddStr5");fflush(stdout);
	}
	(*strset)[*count-1] = (char *)malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\n setAddStrFamily character found===%s",(*strset)[*count-1]);fflush(stdout);
}

extern DLLAPI int getSupSpcIsInMatCdeSecondary(tag_t matcodeObj,tag_t* supspcObjs)
{
	int 	ifail 				= ITK_ok;
	tag_t 	relType 			= NULLTAG;
	tag_t* 	primary_objects 	= NULL;
	int 	count				= 0;
	printf("\n Start func getSupSpcIsInMatCdeSecondary\n");fflush(stdout);
	CALLAPI(GRM_find_relation_type("T5_MatSpc", &relType));
	if( relType != NULLTAG )
	{
		CALLAPI(GRM_list_primary_objects_only(matcodeObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{
			*supspcObjs = primary_objects[0];
		}
	}
	return ifail;
	printf("\n End func getSupSpcIsInMatCdeSecondary\n");fflush(stdout);
}

extern DLLAPI int getSupSpcIsInMatCde(METHOD_message_t * message, va_list args )
{
	int ifail = ITK_ok;
	tag_t *supspcTag=NULLTAG;
	tag_t matcdeTag= message->object_tag;
	va_list largs;
	va_copy( largs, args);
	va_arg( largs, tag_t );
	supspcTag = va_arg( largs, tag_t*);
	va_end( largs );
	
	printf("\n Start func getSupSpcIsInMatCde\n");fflush(stdout);
	printf("\n Calling func getSupSpcIsInMatCdeSecondary\n");fflush(stdout);
	CALLAPI(getSupSpcIsInMatCdeSecondary(matcdeTag,supspcTag));
	
	return ifail;
}

extern DLLAPI int UsageCalcFunc(tag_t t5RptRel,double* Retusgcalc)
{

	
	int ifail = ITK_ok;
	char *Familytype;
	double LeftPartWeight= 0.0;
	//double usgcalc= 0.0;
	char *PartType;
	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;

	printf("\n Start func UsageCalcFunc\n");fflush(stdout);

	//  *value=12.1234;
	printf("\n In runtime attribute11111111 MC NOTE");fflush(stdout);

	tag_t  Raw_Master = NULLTAG, *secondaries = NULLTAG,relation = NULLTAG,Raw_Master_Rev = NULLTAG;
	tag_t  LeftPartDesRev = NULLTAG;
	int n_secondary =0;			

	//METHOD_PROP_MESSAGE_OBJECT(message, t5RptRel);


	if(t5RptRel==NULLTAG)
	{
	printf("\n In runtime t5RptRel is NULL MC NOTE");fflush(stdout);
	}
	ITKCALL(AOM_ask_value_tag(t5RptRel,"secondary_object", &Raw_Master));
	ITKCALL(GRM_find_relation_type("T5_RPtRel", &relation));
	ITKCALL(GRM_list_secondary_objects_only(t5RptRel,relation, &n_secondary,&secondaries));
	printf("\n In runtime 33333333 MC NOTE");fflush(stdout);

	//getting Left Design Part Rev from relation
	ITKCALL(AOM_ask_value_tag(t5RptRel,"primary_object", &LeftPartDesRev));			
	printf("\n After getting Left Design Part Rev from relation \n");fflush(stdout);

	AOM_ask_value_double(LeftPartDesRev,"t5_Weight",&LeftPartWeight);
	printf("\n In runtime Family Type of Raw Part is %lf ",LeftPartWeight);fflush(stdout);

	AOM_ask_value_string(Raw_Master,"t5_Family",&Familytype);
	printf("\n In runtime Family Type of Raw Part is %s ",Familytype);fflush(stdout);
	ITKCALL(ITEM_ask_latest_rev(Raw_Master,&Raw_Master_Rev));

	if(Raw_Master!=NULLTAG)
	{
	tag_t                   classificationObject;
	int theAttributeCount =0;
	int *theAttributeIds ;
	int *theAttributeValCounts=0;
	char                    **theAttributeNames; 
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	double  BlankLength = 0.0;
	double  CompPerBlnk = 0.0;
	double  BlankPerSheet = 0.0;
	double  TotalSheetWeight = 0.0;
	double  SheetLength = 0.0;
	double  RawWidth = 0.0;
	double  BlankWidth = 0.0;
	double  Offcut1Length = 0.0;
	double  Offcut2Length = 0.0;
	double  Offcut1Width = 0.0;
	double  Offcut2Width = 0.0;
	double  FirstPiece = 0.0;
	double  Pitch = 0.0;
	double  usgcalc = 0.0f;
	char *DiaInd;
	int x=0,i =0;
	//Raw_Master = secondaries[0];
	char *type;
	printf("\n In runtime 2222222 MC NOTE");fflush(stdout);
	AOM_ask_value_string(Raw_Master,"object_type",&type);
	printf("\n In runtime NOT NULL =%sMC NOTE",type);fflush(stdout);

	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_BlankLength",&BlankLength));	
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_ComponentsPerBlank",&CompPerBlnk));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_BlankPerSheet",&BlankPerSheet));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_TotalSheetWeight",&TotalSheetWeight));
	ITKCALL(AOM_ask_value_string(t5RptRel,"t5_DiaInd",&DiaInd));


	//ITKCALL(AOM_ask_value_double(t5RptRel,"t5_SheetLength",&SheetLength));

	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_BlankWidth",&BlankWidth));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_Offcut1Length",&Offcut1Length));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_Offcut2Length",&Offcut2Length));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_Offcut1Width",&Offcut1Width));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_Offcut2Width",&Offcut2Width));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_FirstPiece",&FirstPiece));
	ITKCALL(AOM_ask_value_double(t5RptRel,"t5_Pitch",&Pitch));
	printf("\n inside getsheetweight runtime func with req get values BlankLength[%lf] CompPerBlnk[%lf] BlankPerSheet[%lf] TotalSheetWeight[%lf] DiaInd[%s] SheetLength[%lf] \n RawWidth[%lf] BlankWidth[%lf] Offcut1Length[%lf] Offcut2Length[%lf] Offcut1Width[%lf] Offcut2Width[%lf] FirstPiece[%lf] Pitch[%lf]",BlankLength,CompPerBlnk,BlankPerSheet,TotalSheetWeight,DiaInd,SheetLength,RawWidth,BlankWidth,Offcut1Length,Offcut2Length,Offcut1Width,Offcut2Width,FirstPiece,Pitch);fflush(stdout);

	ITKCALL(ICS_ask_classification_object(Raw_Master,&classificationObject));
	if(classificationObject==NULLTAG)
	{
		printf("\n In runtime NULL MC NOTE");fflush(stdout);	
	}
	else
	{
		printf("\n In runtime NOT NULL MC NOTE");fflush(stdout);	
	}
	//ITKCALL( ICS_ico_ask_attributes(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeValCounts, &theAttributeValues)); 

	ITKCALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits)); 
	char * Weight = NULL;
	Weight = (char * )MEM_alloc(10);
	char * Width = NULL;
	Width = (char * )MEM_alloc(10);
	char * Length = NULL;
	Length = (char * )MEM_alloc(10);
	printf("\n THE VAL==%d",theAttributeCount);fflush(stdout);
		for(i=0;i<theAttributeCount;i++)
		{
			printf("\n aattributeNames id:[%d]",theAttributeIds[i]);fflush(stdout);
			printf("\n theAttributeNames id:[%s]",theAttributeNames[i]);fflush(stdout);
			if(tc_strcmp(theAttributeNames[i],"Weight")==0)
			{
				if(theAttributeValCounts[i]>0)
				{
					tc_strcpy(Weight,theAttributeValues[i][0]);
					printf("\n Value of Weight is :[%s]",Weight);fflush(stdout);
					printf("\n Familytype 11111 is :[%s]",Familytype);fflush(stdout);
					if((tc_strcmp(Familytype,"COILS") == 0) || (tc_strcmp(Familytype,"STRIPS") == 0))
					{	
						printf("\n Familytype 22222 is :[%s]",Familytype);fflush(stdout);
						usgcalc = (double)(atof(Weight)*BlankLength)/(1000*CompPerBlnk);
						printf("\n Value of Weight in 1st if loop is :[%s]",Weight);fflush(stdout);
						printf("\n Value of usgcalc in 1st if loop is :[%lf]",usgcalc);fflush(stdout);
					}
					else if(((tc_strcmp(Familytype,"COILS") != 0) || (tc_strcmp(Familytype,"STRIPS") != 0)) && tc_strcmp (DiaInd,"Y")==0)
					{
						usgcalc = (atof(Weight)*BlankLength)/(1000*CompPerBlnk);fflush(stdout);
					}
					else if(((tc_strcmp(Familytype,"COILS") != 0) || (tc_strcmp(Familytype,"STRIPS") != 0)) && tc_strcmp (DiaInd,"N")==0)
					{
						usgcalc = (atof(Weight))/(BlankPerSheet*CompPerBlnk);fflush(stdout);
					}
					else if(tc_strcmp(Familytype,"TWB") == 0)
					{
						usgcalc = (TotalSheetWeight*BlankLength)/(1000*CompPerBlnk);fflush(stdout);
					}
					else
					{
						printf("\n Family and dia indicator is not matching with expected values");fflush(stdout);
					}
					//char * usagecalcstr = NULL;
					//usagecalcstr = (char * )MEM_alloc(100);
					printf("\n Value of usgcalc in 1st iftrtrt loop is :[%lf]",usgcalc);fflush(stdout);
					//usgcalc=123.45f;
					//sprintf(usagecalcstr,"%.2f", usgcalc);
					*Retusgcalc=usgcalc;
					printf("\n Value of usagecalcstr1111  is :[%lf]",*Retusgcalc);fflush(stdout);
					//strcpy(*value,usagecalcstr); 
					break;
				}
			}
		} 
	}
	return ifail;
	printf("\n End func UsageCalcFunc\n");fflush(stdout);
}	


void  getPlantLocName( char *Plt_Code ,char RetPlantName[40])
{
	char *syscd			= NULL;
	   char *subsyscd			= NULL;
	    char *delind			= NULL;
	 //char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 //char *qry_entryCntrl1[] = {"SYSCD","SUBSYSCD","Delete Indicator"};
									//char *qry_valuesCntrl1[] = {"CHASSIS",busUnit};
	 //char *qry_entries3[] = {"SYSCD","SUBSYSCD","Delete Indicator"};
									//char *qry_values3[] = {"CHASSIS",busUnit};
	 
	
	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 
	 char *UserLoc			= NULL;
	 
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 
	 
	  
		 char *syscdval			= NULL;
		  char *delindval			= NULL;
		  
	 int max_char_size = 80;
	 syscd = (char *)MEM_alloc(max_char_size * sizeof(char));
 subsyscd = (char *)MEM_alloc(max_char_size * sizeof(char));
  delind = (char *)MEM_alloc(max_char_size * sizeof(char));
  syscdval = (char *)MEM_alloc(max_char_size * sizeof(char));
  delindval = (char *)MEM_alloc(max_char_size * sizeof(char));
	PlantOneChar=subString(Plt_Code,3,1);
	printf("\n inside getPlantLocName func PlantOneChar:%s",PlantOneChar);fflush(stdout);	

	
	tc_strcpy(syscd,"SYSCD");
	tc_strcpy(subsyscd,"SUBSYSCD");
	tc_strcpy(delind,"Delete Indicator");

	 char *qry_entryCntrl1[] = {syscd,subsyscd,delind};
	
	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				tc_strcpy(syscdval,"APLPltInf");
				tc_strcpy(delindval,"0");
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]=syscdval;
				qry_valuesCntrl1[1]=Plt_Code;
				qry_valuesCntrl1[2]=delindval;
				//char *qry_valuesCntrl2[] = {"APLPltInf",Plt_Code,"0"};
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n  inside getPlantLocName func Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n inside getPlantLocName func control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				


				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &UserLoc);
				printf("\ninside getPlantLocName func UserLoc: %s\n",UserLoc);fflush(stdout);

				

				//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &Info10ctrl);
				//printf("\n Info10ctrl: %s\n",Info10ctrl);fflush(stdout);				

				
				if(tc_strlen(UserLoc)>0) 
				{
					printf("\ninside getPlantLocName func retruning UserLoc: %s\n",UserLoc);fflush(stdout);
					tc_strcpy(RetPlantName,UserLoc);
				}
				
					
			} 
			else
			{
				printf("\ninside getPlantLocName func :No Control Object<APLPltInf> found so retruning Default UserLoc: CAR\n");fflush(stdout);
				tc_strcpy(RetPlantName,"CAR");
			}
		//return 0;	
}



//Start iman_save to create relation between Assembly & Raw Part
extern DLLAPI int  setPlantInRawPartRelCre(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	
	va_list largs;
	va_copy( largs, args);               
	tag_t T5_RPtRelTag = va_arg(largs, tag_t);
	
	tag_t	primary_object				=	NULLTAG;
	tag_t	secondary_object			=	NULLTAG;
	//tag_t	T5_RPtRelTag				=	va_arg(args, tag_t);
	tag_t	objTypeTag					=	NULLTAG;
	tag_t	RelobjTypeTag				=	NULLTAG;
	tag_t	priObjTypeTag				=	NULLTAG;
	tag_t	secObjTypeTag				=	NULLTAG;

	// char   type_name[TCTYPE_name_size_c+1];
	// char   type_name1[TCTYPE_name_size_c+1];
	// char   type_name2[TCTYPE_name_size_c+1];
	char 	*type_name  	= NULL;
	char 	*type_name1 	= NULL;
	char 	*type_name2 	= NULL;
	char 	*user_id		= NULL;	
	char	*leftPart		= NULL;
	char	*leftPartDup	= NULL;
	char	*rightPart		= NULL;
	char	*rightPartDup	= NULL;
	char 	plantloc[40];
	tag_t	CurrentRoleTag	= NULLTAG;
	char	*roleName				=	NULL;
	va_end( largs );
	
	
	printf("\n Inside setPlantInRawPartRelCre logic");fflush(stdout);

	if (POM_get_user_id(&user_id)!=ITK_ok);

	printf("\n Inside setPlantInRawPartRelCre curent login user is ==> [ %s ] \n",user_id);fflush(stdout);
	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName));

	printf("\n grp user role : %s",roleName);fflush(stdout);
	char *PlantName	=	NULL;
	PlantName	=	subString(roleName,3,4);
	printf( "\nPlantName:%s\n", PlantName);fflush(stdout);
	
	if(tc_strcmp(user_id,"loader")!=0 && tc_strcmp(user_id,"infodba")!=0)
	{
		if(T5_RPtRelTag!=NULLTAG)
		{
			printf("\n Inside T5_RPtRelTag getting\n");fflush(stdout);
			if (TCTYPE_ask_object_type(T5_RPtRelTag,&objTypeTag)!=ITK_ok);
			printf("\n after T5_RPtRelTag getting\n");fflush(stdout);
			if(objTypeTag!=NULLTAG)
			{
				printf("\n Inside T5_RPtRelTag getting\n");fflush(stdout);
				if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
				printf("\n RRB::type_name :%s\n",type_name);fflush(stdout);

				if (GRM_ask_primary (T5_RPtRelTag,&primary_object)!=ITK_ok);
				if(primary_object!=NULLTAG)
				{
					printf("\n Inside Primary Object");fflush(stdout);
				}

				if (GRM_ask_secondary (T5_RPtRelTag,&secondary_object)!=ITK_ok);
				if(secondary_object!=NULLTAG)
				{
					printf("\n Inside Secondary Object");fflush(stdout);
				}
				if (TCTYPE_ask_object_type(secondary_object,&secObjTypeTag)!=ITK_ok);
				AOM_ask_value_string( secondary_object, "item_id", &rightPart);
				printf("\n Right part ID :%s\n", rightPart);fflush(stdout);
				
				if(rightPart)
				{
					printf("\n Right part ID :%s\n", rightPart);fflush(stdout);
					tc_strdup(rightPart,&rightPartDup);
					printf("\n RrightPartDup :%s\n",rightPartDup);fflush(stdout);
				}
				if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
				printf("\n RRB::sec_type_name :%s\n", type_name2);fflush(stdout);
				
				if (TCTYPE_ask_object_type(primary_object,&priObjTypeTag)!=ITK_ok);
				if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
				printf("\n RRB::Primary_type_name :%s\n", type_name1);fflush(stdout);
				if(primary_object!=NULLTAG)
				{
					AOM_ask_value_string( primary_object, "item_id", &leftPart);
					printf("\n primary obj/left Item_ID :%s\n",leftPart);fflush(stdout);
					if(leftPart)
					{
						tc_strdup(leftPart,&leftPartDup);
						printf("\nAfter DUP of leftPart ");
					}
				}
				printf("\n\n\t\t leftPart :%s",leftPartDup);	fflush(stdout);
				printf("\n\t setPlantInRawPartRelCre Pri obj type name is :%s leftPart=%s  rightPart=%s\n", type_name1,leftPart,rightPartDup);fflush(stdout);
				//CALLAPI(getPlantLocName(PlantName,plantloc));
				printf( "\nPlantName:%s before calling func getPlantLocName\n", PlantName);fflush(stdout);
				getPlantLocName(PlantName,plantloc);
				printf("\n\n\t\t After Return plantloc[%s] from func getPlantLocName",plantloc);fflush(stdout);
				CALLAPI(AOM_lock(T5_RPtRelTag));
				printf("\nAfter Locking rel obj T5_RPtRelTag");fflush(stdout);				
				CALLAPI( AOM_set_value_string(T5_RPtRelTag,"t5_MCNRawPrtPlnt",plantloc));   
				printf("\n in t5_MCNRawPrtPlnt AOM_set_value_string for T5_RPtRelTag with plantloc[%s]\n",plantloc);fflush(stdout);
					
				CALLAPI(AOM_save_without_extensions(T5_RPtRelTag));		//Deprecated API Modification by Amar
				printf("\n in T5_RPtRelTag save..\n");fflush(stdout);

				CALLAPI(AOM_unlock(T5_RPtRelTag));
				printf("\n in T5_RPtRelTag unlock..\n");fflush(stdout);
				
				CALLAPI(AOM_refresh(T5_RPtRelTag,TRUE));
				printf("\n in T5_RPtRelTag refresh..\n");fflush(stdout);
			}
		}
		else
		{
			printf("\n in T5_RPtRelTag is coming as NULLTAG so skiiping logic of plant update..\n");fflush(stdout);
		}
	}

	return 0;
	
}
	
int RawPrtUsagePostValidation( METHOD_message_t *msg, va_list args )
{

   printf("\n Start Update *****RawPrtUsagePostValidation\n");fflush(stdout);

   int ifail = ITK_ok;
   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t T5_RPtRel_tag = va_arg(largs, tag_t);
   tag_t item_rev_tag = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	char *item_id=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *Familytype=NULL;
	char *PartType=NULL;
	char *RawPartNum=NULL;
	char *LeftPartNum=NULL;
	int count;
	int count1;
	double  UsageRT = 0.0;
	double  LeftPartWeight = 0.0;
	double  totalLmt = 0.0;
	tag_t projtag;
	tag_t *Ownprojtag;
	tag_t userSession=NULLTAG;
	tag_t  Raw_Master = NULLTAG;
	tag_t  LeftPartRevTag =NULLTAG;
	tag_t  Raw_Master_Rev = NULLTAG;
	char *Type = va_arg(largs, char *);
	va_end( largs );
	
	printf("\n Start *****RawPrtUsagePostValidation Func");fflush(stdout);
   
	if(T5_RPtRel_tag==NULLTAG)
	{
		printf("\n In runtime T5_RPtRel_tag is NULL during Raw Part & Design rev relation");fflush(stdout);
	}
			ITKCALL(AOM_ask_value_tag(T5_RPtRel_tag,"secondary_object", &Raw_Master));
			ITKCALL(AOM_ask_value_tag(T5_RPtRel_tag,"primary_object", &LeftPartRevTag));
			
	if(Raw_Master==NULLTAG)
	{
		printf("\n In runtime Raw_Master is NULL during Raw Part & Design rev relation");fflush(stdout);
		return ifail;
	}
	if(LeftPartRevTag==NULLTAG)
	{
		printf("\n In runtime LeftPartRevTag is NULL during Raw Part & Design rev relation");fflush(stdout);
		return ifail;
	}
	printf("\n inside post Calling func UsageCalcFunc\n");fflush(stdout);
	CALLAPI(UsageCalcFunc(T5_RPtRel_tag,&UsageRT));			
	printf("\n inside post return usageRT from func UsageCalcFunc =%lf\n",UsageRT);fflush(stdout);
			
	CALLAPI( AOM_ask_value_string(Raw_Master, "item_id",&RawPartNum));	
	CALLAPI( AOM_ask_value_string(LeftPartRevTag, "item_id",&LeftPartNum));
	//CALLAPI( AOM_ask_value_double(T5_RPtRel_tag, "t5_UsageRT",&UsageRT));
	CALLAPI( AOM_ask_value_double(LeftPartRevTag, "t5_Weight",&LeftPartWeight));
	printf("\n UsageRT[%lf] between Design Part[%s] and Raw Part[%s] and LeftPartWeight[%lf]",UsageRT,LeftPartNum,RawPartNum,LeftPartWeight);fflush(stdout);
	
	AOM_ask_value_string(Raw_Master,"t5_Family",&Familytype);
	printf("\n In runtime Family Type of Raw Part is %s ",Familytype);fflush(stdout);
	ITKCALL(ITEM_ask_latest_rev(Raw_Master,&Raw_Master_Rev));
	AOM_ask_value_string(Raw_Master_Rev,"t5_PartType",&PartType);
	printf("\n Raw PartType is %s ",PartType);fflush(stdout);
	if(tc_strcmp(PartType,"R")==0 || tc_strcmp(PartType,"C")==0)
	{
		printf("\n allow the Raw PartType is %s for raw part relation",PartType);fflush(stdout);
	}
	else
	{
		printf("\n*** Part Type of the coil part No is not Component pls check and get it corrected from concern. ***\n");
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type of the coil part No is not Component pls check and get it corrected from concern.");
		printf("\nAfter COIL,STRIP <Raw Part/Coil part Type> validation occured \n");fflush(stdout);
		return ITK_err;
	}
	totalLmt = (UsageRT*(1.8));
	printf("\n totalLmt = [%lf] \n",totalLmt); fflush(stdout);
	if(LeftPartWeight<=totalLmt)
	{
		printf("\n allow to proceed ahead with value LeftPartWgtDup[%lf] totalLmt = [%lf] \n",LeftPartWeight,totalLmt); fflush(stdout);
	}
	else
	{
		printf("\n*** Weight of Raw material for a part should not exceed more than 1.8 times than that of finished part. ***\n");
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Weight of Raw material for a part should not exceed more than 1.8 times than that of finished part.");
		printf("\nAfter  <UsageRT> validation occured \n");fflush(stdout);
		return ITK_err;
	}
	printf("\n End *****RawPrtUsagePostValidation Func");fflush(stdout);
	return 0;
}
	

	
int McNoteValidationFunc( METHOD_message_t *msg, va_list args )
{

   printf("\n Start Update *****McNoteValidationFunc_pre\n");fflush(stdout);

   int ifail = ITK_ok;
   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t T5_RPtRel_tag = va_arg(largs, tag_t);
   tag_t item_rev_tag = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	

	char *item_id=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *Familytype=NULL;
	char *PartType=NULL;
	int count;
	int count1;
	tag_t projtag;
	tag_t *Ownprojtag;
	tag_t userSession=NULLTAG;
	tag_t  Raw_Master = NULLTAG;
	tag_t  Raw_Master_Rev = NULLTAG;
	char *Type = va_arg(largs, char *);
	va_end( largs );
  printf("\n Start *****McNoteValidationFunc_pre Func");fflush(stdout);
   
	if(T5_RPtRel_tag==NULLTAG)
	{
		printf("\n In runtime T5_RPtRel_tag is NULL during Raw Part & Design rev relation");fflush(stdout);
	}
			ITKCALL(AOM_ask_value_tag(T5_RPtRel_tag,"secondary_object", &Raw_Master));
			
	//CALLAPI( AOM_ask_value_string(T5_RPtRel_tag, "object_name",&item_id));
	//CALLAPI( AOM_ask_value_string(T5_RPtRel_tag, "t5_ProjectCode",&ProjName));
	//CALLAPI( AOM_ask_value_tags(T5_RPtRel_tag, "owning_project",&count1,&Ownprojtag));
	AOM_ask_value_string(Raw_Master,"t5_Family",&Familytype);
	printf("\n In runtime Family Type of Raw Part is %s ",Familytype);fflush(stdout);
	ITKCALL(ITEM_ask_latest_rev(Raw_Master,&Raw_Master_Rev));
	AOM_ask_value_string(Raw_Master_Rev,"t5_PartType",&PartType);
	printf("\n Raw PartType is %s ",PartType);fflush(stdout);
	if(tc_strcmp(PartType,"R")==0 || tc_strcmp(PartType,"C")==0)
	{
		printf("\n allow the Raw PartType is %s for raw part relation",PartType);fflush(stdout);
	}
	else
	{
		printf("\n*** Part Type of the coil part No is not Component pls check and get it corrected from concern. ***\n");
		EMH_store_error_s1(EMH_severity_error,ITK_err,"Part Type of the coil part No is not Component pls check and get it corrected from concern.");
		printf("\nAfter COIL,STRIP <Raw Part/Coil part Type> validation occured \n");fflush(stdout);
		return ITK_err;
	}
   
		if(Raw_Master!=NULLTAG)
		{
			 tag_t                   classificationObject;
			int theAttributeCount =0;
			int *theAttributeIds ;
			int *theAttributeValCounts=0;
			char                    **theAttributeNames; 
			char***       theAttributeValues;
			char***       theAttributeOptimizedUnits;
			double  BlankLength = 0.0;
			double  CompPerBlnk = 0.0;
			double  BlankPerSheet = 0.0;
			double  TotalSheetWeight = 0.0;
			double  SheetLength = 0.0;
			double  RawWidth = 0.0;
			double  BlankWidth = 0.0;
			double  Offcut1Length = 0.0;
			double  Offcut2Length = 0.0;
			double  Offcut1Width = 0.0;
			double  Offcut2Width = 0.0;
			double  FirstPiece = 0.0;
			double  Pitch = 0.0;
			double  usgcalc = 0.0f;
			char *DiaInd;
			int x=0,i =0;
			//Raw_Master = secondaries[0];
			char *type;
			printf("\n In runtime 2222222 MC NOTE");fflush(stdout);
			AOM_ask_value_string(Raw_Master,"object_type",&type);
			printf("\n In runtime NOT NULL =%sMC NOTE",type);fflush(stdout);
			
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_BlankLength",&BlankLength));	
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_ComponentsPerBlank",&CompPerBlnk));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_BlankPerSheet",&BlankPerSheet));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_TotalSheetWeight",&TotalSheetWeight));
			ITKCALL(AOM_ask_value_string(T5_RPtRel_tag,"t5_DiaInd",&DiaInd));
			
			
			//ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_SheetLength",&SheetLength));
			
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_BlankWidth",&BlankWidth));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_Offcut1Length",&Offcut1Length));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_Offcut2Length",&Offcut2Length));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_Offcut1Width",&Offcut1Width));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_Offcut2Width",&Offcut2Width));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_FirstPiece",&FirstPiece));
			ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_Pitch",&Pitch));
			printf("\n inside getsheetweight runtime func with req get values BlankLength[%lf] CompPerBlnk[%lf] BlankPerSheet[%lf] TotalSheetWeight[%lf] DiaInd[%s] SheetLength[%lf] \n RawWidth[%lf] BlankWidth[%lf] Offcut1Length[%lf] Offcut2Length[%lf] Offcut1Width[%lf] Offcut2Width[%lf] FirstPiece[%lf] Pitch[%lf]",BlankLength,CompPerBlnk,BlankPerSheet,TotalSheetWeight,DiaInd,SheetLength,RawWidth,BlankWidth,Offcut1Length,Offcut2Length,Offcut1Width,Offcut2Width,FirstPiece,Pitch);fflush(stdout);
		
		if(BlankLength>0.0 && BlankPerSheet>0.0 && BlankWidth>0.0)
		{
			if(CompPerBlnk<=0.0)
			{
				printf("\n*** ComponentsPerBlank should not be NULL if all required value for Usage Calc is not NULL. ***\n");
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Components/Blank should not be NULL if all required value for Usage Calc is not NULL..");
				printf("\nAfter  <Blank Width> validation occured \n");fflush(stdout);
				return ITK_err;
			}
		}
		
		ITKCALL(ICS_ask_classification_object(Raw_Master,&classificationObject));
			if(classificationObject==NULLTAG)
			{
				printf("\nCls Object not found during RAW Part relation creation");fflush(stdout);	
			}
			else
			{

				printf("\n Cls Object found for RAW Part relation creation :In runtime NOT NULL MC NOTE");fflush(stdout);	
			
//ITKCALL( ICS_ico_ask_attributes(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeValCounts, &theAttributeValues)); 

			ITKCALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits)); 
			char * Weight = NULL;
			Weight = (char * )MEM_alloc(10);
			char * Width = NULL;
			Width = (char * )MEM_alloc(10);
			char * Length = NULL;
			Length = (char * )MEM_alloc(10);
			printf("\n THE VAL==%d",theAttributeCount);fflush(stdout);
			for(i=0;i<theAttributeCount;i++)
			{
				printf("\n aattributeNames id:[%d]",theAttributeIds[i]);fflush(stdout);
				printf("\n theAttributeNames id:[%s]",theAttributeNames[i]);fflush(stdout);
				
				
				
				if(tc_strcmp(theAttributeNames[i],"Weight")==0)
				{
				   if(theAttributeValCounts[i]>0)
				   {
					tc_strcpy(Weight,theAttributeValues[i][0]);
					printf("\n Value of Weight is :[%s]",Weight);fflush(stdout);
					printf("\n Familytype 11111 is :[%s]",Familytype);fflush(stdout);
				   }

				}
				else if(tc_strcmp(theAttributeNames[i],"Width")==0)
					{
						if(theAttributeValCounts[i]>0)
						{
							tc_strcpy(Width,theAttributeValues[i][0]);
							printf("\n Value of cls Width is :[%s]",Width);fflush(stdout);
							
							//atof(Width);
							
							if(BlankWidth>(atof(Width)))
							{
								printf("\n*** <Blank Width> cannot be greater than <Raw Width>. ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"<Blank Width> cannot be greater than <Raw Width>.");
								printf("\nAfter  <Blank Width> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							if(Offcut1Width>(atof(Width)) || Offcut2Width>(atof(Width)))
							{
								printf("\n*** <Offcut Width> cannot be greater than <Raw Sheet Width> ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"<Offcut Width> cannot be greater than <Raw Sheet Width>.");
								printf("\nAfter  <OffcutWidth Length> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							//printf("\n Familytype 11111 is :[%s]",Familytype);fflush(stdout);
							//ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_SheetWidth",&RawWidth));
						}
					}
					else if(tc_strcmp(theAttributeNames[i],"Length")==0)
					{
						printf("\n b4 Value of cls Length is :[%s]",Length);fflush(stdout);
						if(theAttributeValCounts[i]>0)
						{
							tc_strcpy(Length,theAttributeValues[i][0]);
							printf("\n Value of cls Length is :[%s]",Length);fflush(stdout);
							
							if(BlankLength>(atof(Length)))
							{
								printf("\n*** For <Form> not in (COIL,STRIP) <Blank Length> cannot be greater than <Raw Length>. ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For <Form> not in (COIL,STRIP) <Blank Length> cannot be greater than <Raw Length>.");
								printf("\nAfter COIL,STRIP <Blank Length> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							
							if(Offcut1Length>(atof(Length)) || Offcut2Length>(atof(Length)))
							{
								printf("\n*** <Offcut Lengths> cannot be greater than <Raw Length> ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"<Offcut Lengths> cannot be greater than <Raw Length>.");
								printf("\nAfter COIL,STRIP <OffcutLength Length> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							
							if(FirstPiece>(atof(Length)) || Pitch>(atof(Length)))
							{
								printf("\n*** <First Piece> or <Pitch> cannot be greater than <Raw Length> ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"<First Piece> or <Pitch> cannot be greater than <Raw Length>.");
								printf("\nAfter COIL,STRIP <First Piece or Pitch> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							
							if((Pitch * BlankPerSheet) > (atof(Length)))
							{
								printf("\n*** <Pitch> X <Blanks Per Sheet> cannot be greater than <Raw Length> ***\n");
								EMH_store_error_s1(EMH_severity_error,ITK_err,"<Pitch> X <Blanks Per Sheet> cannot be greater than <Raw Length>.");
								printf("\nAfter COIL,STRIP <Pitch> X <Blanks Per Sheet> validation occured \n");fflush(stdout);
								return ITK_err;
							}
							//printf("\n Familytype 11111 is :[%s]",Familytype);fflush(stdout);
							//ITKCALL(AOM_ask_value_double(T5_RPtRel_tag,"t5_SheetWidth",&RawWidth));
						}
					}
					else
					{
						printf("\n No condition to fetch cls value");fflush(stdout);
					}
				
				/*for(x=0;x<theAttributeValCounts[i];x++)
				{
					printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);
				}*/
			}
			}			
		}
   
   printf("\n End *****McNoteValidationFunc_pre Func");fflush(stdout);
   return 0;

}
// Func to getting Assembly from Raw Part Object 
extern DLLAPI int getAsmfrmRawPart(tag_t RawPrtObj,tag_t* AsmFrmRawPrtTag)
{

	 printf("\n Start func getAsmfrmRawPart\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;


	CALLAPI(GRM_find_relation_type("T5_RPtRel", &relType));

	printf("\n RawPrtObj=%u relType=%u\n",RawPrtObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		CALLAPI(GRM_list_primary_objects_only(RawPrtObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{

		*AsmFrmRawPrtTag = primary_objects[0];
		}

	}
	return ifail;	

	printf("\n End func getAsmfrmRawPart\n");fflush(stdout);

}


extern DLLAPI int getAsmRelationFrmRawPrt(METHOD_message_t * message, va_list args )
{

printf("\n Start func getAsmRelationFrmRawPrt\n");fflush(stdout);
int ifail = ITK_ok;
tag_t *AsmTag=NULLTAG;


	tag_t RawPrtTag= message->object_tag;

	va_list largs;

	va_copy( largs, args);
	va_arg( largs, tag_t );
	AsmTag = va_arg( largs, tag_t*);
	va_end( largs );

	

		printf("\n Calling func getAsmfrmRawPart\n");fflush(stdout);
		CALLAPI(getAsmfrmRawPart(RawPrtTag,AsmTag));

		printf("\n After func call getAsmfrmRawPart AsmTag=%u\n",AsmTag);fflush(stdout);
		
			
		
		return ifail;	

	
		
}	
int remove_from_all_folders(tag_t object)
{
  int ifail = ITK_ok;
    int
        cnt = 0,
        ii,
        n_levels,
        n_instances,
        *instance_levels,
        *instance_where_found,
        n_classes,
        *class_levels,
        *class_where_found;
    tag_t
        folder_type,
        home_folder_type,
        newstuff_type,
        *ref_instances,
        *ref_classes,
        type = NULLTAG;
        
           printf(" IN Folder Delete!\n");
        
    CALLAPI(TCTYPE_find_type("Fnd0HomeFolder", NULL, &home_folder_type));
    if (home_folder_type == NULLTAG)
    {
        printf(" HOME Folder type not found!\n");
        return FALSE;
    } 
    else
    {
    printf(" HOME Folder type  found!\n");
    }   

    CALLAPI(TCTYPE_find_type("Folder", NULL, &folder_type));
    if (folder_type == NULLTAG)
    {
        printf("Folder type not found!\n");
        return FALSE;
    }
     else
    {
    printf(" Folder type  found!\n");
    } 

    CALLAPI(TCTYPE_find_type("Newstuff Folder", NULL, &newstuff_type));
    if (newstuff_type == NULLTAG)
    {
        printf("Newstuff Folder type not found!\n");
        return FALSE;
    }
     else
    {
    printf(" Newstuff Folder type  found!\n");
    } 

    CALLAPI(POM_referencers_of_instance(object, 1, POM_in_ds_and_db,
        &n_instances, &ref_instances, &instance_levels,
        &instance_where_found, &n_classes, &ref_classes, &class_levels,
        &class_where_found));

    if (n_instances > 0)
    {
        for (ii = 0; ii < n_instances; ii++)
        {
            CALLAPI(TCTYPE_ask_object_type(ref_instances[ii], &type));
            if ((type == folder_type) || (type == newstuff_type) || (type == home_folder_type))
            {
                CALLAPI(AOM_refresh(ref_instances[ii], TRUE));
                CALLAPI(FL_remove(ref_instances[ii], object));
                CALLAPI(AOM_save_without_extensions(ref_instances[ii]));   //Deprecated API Modification by Amar
                CALLAPI(AOM_refresh(ref_instances[ii], FALSE));
                cnt++;
            }
        }
        MEM_free(ref_instances);
        MEM_free(instance_levels);
        MEM_free(instance_where_found);
    }

    if (n_classes > 0)
    {
        MEM_free(ref_classes);
        MEM_free(class_levels);
        MEM_free(class_where_found);
    }

    return ifail;
}







int CreateRawPartpost( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	
/*	
	@param const char* item_id
    @param const char* item_name
    @param const char* type_name
    @param const char* rev_id
    @param tag_t*      new_item
    @param tag_t*      new_rev
    @param tag_t       item_master_form
    @param tag_t       item_rev_master_form
*/	
	char* item_id  = va_arg(args, char*);
    const char* item_name = va_arg(args, char*);
    const char* type_name = va_arg(args, char*);
    const char* rev_id = va_arg(args, char*);
    tag_t*      new_item = va_arg(args, tag_t*);
    tag_t*      new_rev = va_arg(args, tag_t*);
    tag_t       item_master_form = va_arg(args, tag_t);
    tag_t       item_rev_master_form = va_arg(args, tag_t);
	

		char *item_idval=NULL;
		const char *valuetype={item_id};
		const char *attr="t5_PART_NO";
   
   	int  rows = 0, columns = 0;
		void ***report;

		CALLAPI(POM_enquiry_create("T5_StdTmp_enq"));

		const char *sel_attrs[1] = {"puid"};

		CALLAPI(POM_enquiry_add_select_attrs("T5_StdTmp_enq", "T5_StdTmp", 1, sel_attrs));
		CALLAPI(POM_enquiry_set_string_value("T5_StdTmp_enq", "value", 1, &valuetype,POM_enquiry_bind_value));
		CALLAPI(POM_enquiry_set_attr_expr ("T5_StdTmp_enq", "expression", "T5_StdTmp", attr, POM_enquiry_equal, "value"));
		CALLAPI(POM_enquiry_set_where_expr ( "T5_StdTmp_enq", "expression" ));

		
		CALLAPI(POM_enquiry_add_order_attr ( "T5_StdTmp_enq","T5_StdTmp","t5_PART_NO",POM_enquiry_desc_order));

		CALLAPI(POM_enquiry_execute("T5_StdTmp_enq", &rows, &columns, &report));
		
		tag_t objtag=NULLTAG;

	


		if (rows != 0)
		{
			objtag  = *(tag_t*)(report[0][0]);

			printf("\n \n number of obj row : %d cols : %d \n",rows,columns);fflush(stdout);
			
			CALLAPI(AOM_ask_value_string(objtag,"t5_PART_NO",&item_idval));
      CALLAPI(remove_from_all_folders(objtag));
			CALLAPI(AOM_lock_for_delete(objtag));
            CALLAPI(AOM_delete(objtag));
		}
		

		CALLAPI(POM_enquiry_delete("T5_StdTmp_enq"));

	
	return ifail;
}
	
	
/*********************************/

/****************************************************************************
Function:       dynamic_rawfamily_LOV
Description:    This function used while creating Raw Part to populate Raw Part Family
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_rawfamily_LOV( char*** RF_LovValue )
{

/* va_list for LOV_ask_values_msg */

 
	char   *user_name_string = NULL;
	char   *subsyscd = NULL;

	char  ***values = NULL;

	int  
	ifail = ITK_ok;

	int Lov_cnt=0;
	
	tag_t	TagQryContObjSite = NULLTAG, *ICS_RawPartCntrlObj = NULL;
	int		n_Input = 1,ICS_RawPartCount = 0,CheckBypasFlag=0;
	char	*qry_Input[1] = {(char*)"SYSCD"};
	char	*qry_BypVal[1] = {(char*)"ICS_RawPart"};

	printf("\n dynamic_rawfamily_LOV");fflush(stdout);

	//CALLAPI(SA_init_module());
	//CALLAPI(ICS_init_module());
	CALLAPI(ICS_init_hooks());
	printf("\n ICS_init_hooks");fflush(stdout);
	//printf("\n ICS_init_module");fflush(stdout);
	tag_t  ParentRawPrtfamilyTag = NULLTAG;
	//ICS_RawPart
	if(QRY_find2("ControlObjQry", &TagQryContObjSite));
		if(TagQryContObjSite)
		{
			 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ICS_RawPartCount, &ICS_RawPartCntrlObj));
			 
			 printf("\nObjects for Query ICS_RawPart == %d", ICS_RawPartCount);fflush(stdout);
			 
			 
			 
		}
		else
		{
			printf("\nContrlObj not found for SYSCD=ICS_RawPart");fflush(stdout);
		
			
		}
		if(ICS_RawPartCount >0)
		{
			ITKCALL(AOM_ask_value_string(ICS_RawPartCntrlObj[0],"t5_SubSyscd",&subsyscd));	//Design Grou
		}
		printf("\nsubsyscd=%s",subsyscd);fflush(stdout);
	//ITKCALL(ICS_find_class("ICM01020101",&ParentRawPrtfamilyTag));
	if(subsyscd)
	{
		ITKCALL(ICS_find_class(subsyscd,&ParentRawPrtfamilyTag));
	}		
	
	if (ParentRawPrtfamilyTag!=NULLTAG)
	{
		tag_t *rawfamily_childsobj_tag = NULLTAG;
		int rawfamilychildcnt = 0;
		ITKCALL(ICS_ask_children(ParentRawPrtfamilyTag,&rawfamilychildcnt,&rawfamily_childsobj_tag));
		printf("\n No Of Raw Part Family Childs is %d",rawfamilychildcnt);fflush(stdout);
		if (rawfamilychildcnt>0 && rawfamily_childsobj_tag!=NULLTAG)
		{
			int i =0;
			
			for(i=0;i<rawfamilychildcnt;i++)
			{
				tag_t rawfamily_child_tag = NULLTAG;
				rawfamily_child_tag = rawfamily_childsobj_tag[i];
				if(rawfamily_child_tag != NULLTAG)
				{
					char*	familychild_idval		= NULL;
					char*	familychild_nameval		= NULL;
					
					//familychild_idval 	=  (char *)MEM_alloc(50);
					//familychild_nameval 	=  (char *)MEM_alloc(50);
					ITKCALL(ICS_ask_id_name(rawfamily_child_tag,&familychild_idval,&familychild_nameval));
					printf("\n RAw Part Family Child Group Counter is :: %d Child ID is :: %s chils Name is :: %s",i,familychild_idval,familychild_nameval);fflush(stdout);
					
					tag_t *child_childsobj_tag = NULLTAG;
					int familychildtochildcnt = 0;
					ITKCALL(ICS_ask_children(rawfamily_child_tag,&familychildtochildcnt,&child_childsobj_tag));
					printf("\n No Of Raw Part Family Childs is %d",familychildtochildcnt);fflush(stdout);
					if(familychildtochildcnt>0 && child_childsobj_tag!=NULLTAG)
					{
						int ii =0;
						for(ii=0;ii<familychildtochildcnt;ii++)
						{
							if(child_childsobj_tag[ii] != NULLTAG)
							{
								char*	familychildchild_idval		= NULL;
								char*	familychildchild_nameval		= NULL;
								
								ITKCALL(ICS_ask_id_name(child_childsobj_tag[ii],&familychildchild_idval,&familychildchild_nameval));
								printf("\n RAw Part Family Child to Child Group Counter is :: %d Child ID is :: %s chils Name is :: %s",ii,familychildchild_idval,familychildchild_nameval);fflush(stdout);
								setAddStrFamily(&Lov_cnt,RF_LovValue,familychildchild_nameval);
								MEM_free(familychildchild_idval);
								MEM_free(familychildchild_nameval);
							}
						}
					}
					else
					{
						setAddStrFamily(&Lov_cnt,RF_LovValue,familychild_nameval);
					}
					MEM_free(familychild_idval);
					MEM_free(familychild_nameval);
					MEM_free(child_childsobj_tag);
				}
				
			}
		}
		else
		{
			printf("\n Raw Part Family child Tags are not Found so exiting without values ");fflush(stdout);
		}
		MEM_free(rawfamily_childsobj_tag);
	}
	else
	{
		printf("\n Parent Raw Part Family Tag is not Found so exiting without values ");fflush(stdout);
	}

    return Lov_cnt;
}


/****************************************************************************
Function:       dynamic_raw_LengthsMethodFamily
Description:    This function used while creating Raw Part to populate Raw Part Family
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_raw_LengthsMethodFamily( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **RF_LovValue=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n dynamic_raw_LengthsMethodFamily");fflush(stdout);
  
  *length=dynamic_rawfamily_LOV(&RF_LovValue);
  printf("\n dynamic_raw_LengthsMethodFamily===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_raw_ValuesMethodFamily
Description:    This function used while creating Raw Part to populate Raw Part Family
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_raw_ValuesMethodFamily( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

	logical active = TRUE;
	tag_t lov_tag = va_arg (args, tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** RF_LovValue;
	int Lov_cnt=0;
   
  
	 printf("\n dynamic_raw_ValuesMethodFamily");fflush(stdout);
	  
	 *n_values=dynamic_rawfamily_LOV(&RF_LovValue);
	 printf("\n dynamic_raw_ValuesMethodFamily==>[%d]",*n_values);fflush(stdout);

	 *values = (char **) MEM_alloc (*n_values * sizeof (char*));
	 memset (*values, 0,  *n_values * sizeof(char*));

	 for (ii = 0; ii < *n_values; ii++)
	{ 
						
		(*values)[ii] = (char *) MEM_alloc (strlen(RF_LovValue[ii]) + 1);
		tc_strcpy ((*values)[ii], RF_LovValue[ii]);	   
	  } 
	  
    return ifail; 
}


extern "C" int getsheetweight (METHOD_message_t * message, va_list args )
        {
			int ifail = ITK_ok;
			tag_t rel_object=NULLTAG;
			char *Familytype;
			double LeftPartWeight= 0.0;
			char *PartType;
			printf("\n In runtime getsheetweight MC NOTE");fflush(stdout);
			va_list largs;

			va_copy( largs, args);

			tag_t prop_tag = va_arg( largs, tag_t);
			char **value=va_arg( largs, char **);
			va_end( largs );
			*value = (char *)MEM_alloc(15);
			//strcpy(*value, "12.1234"); 

			//object  = m->object_tag;
			double  RetUsgcalcFrmFunc = 0.0f;
			
			//  *value=12.1234;
			printf("\n In runtime attribute11111111 MC NOTE");fflush(stdout);

			tag_t  Raw_Master = NULLTAG, *secondaries = NULLTAG,relation = NULLTAG,Raw_Master_Rev = NULLTAG;
			tag_t  LeftPartDesRev = NULLTAG;
			int n_secondary =0;			
			
			METHOD_PROP_MESSAGE_OBJECT(message, rel_object);
			

			if(rel_object==NULLTAG)
			{
				printf("\n In runtime rel_object is NULL MC NOTE");fflush(stdout);
			}
			
			printf("\n Calling func UsageCalcFunc\n");fflush(stdout);
			CALLAPI(UsageCalcFunc(rel_object,&RetUsgcalcFrmFunc));
			
			char * usagecalcstr = NULL;
			usagecalcstr = (char * )MEM_alloc(100);
			printf("\n Value of usgcalc in 1st iftrtrt loop is :[%lf]",RetUsgcalcFrmFunc);fflush(stdout);
			//usgcalc=123.45f;
			//sprintf(usagecalcstr,"%s", RetUsgcalcFrmFunc);
			sprintf(usagecalcstr,"%.3f", RetUsgcalcFrmFunc);
			printf("\n Value of usagecalcstr1111  is :[%s]",usagecalcstr);fflush(stdout);
			strcpy(*value,usagecalcstr);
			printf("\n return usageRT from func UsageCalcFunc =%lf value[%s]\n",RetUsgcalcFrmFunc,*value);fflush(stdout);
		
			return ifail;
        }
/*******************************/

//Added user service to stamp date in mcnote & Raw part on 05/02/2020

/****************************************************************************
Function:       TML_token_to_date
Description:    This function used to change format of Date string .
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	//printf("\n Debugging ==> 000899999 \n");fflush(stdout);

	if(tc_strlen(str)>0)
	{
		//printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;

		printf("\n year[%d] month[%d] day[%d] hour[%d] minute[%d] second[%d]\n",year,month,day,hour,minute,second);fflush(stdout);
		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		//printf("\n Debugging ==> 0008 \n");fflush(stdout);

	}
	return date;
}

static void Service_check_status(int count, tag_t *status_list, char *status_name,tag_t * revstatus)
{
	int   NStatus					 = 0;
	int   ifail						 = 0;
	//char  name[WSO_name_size_c+1]    = {'\0'};
	char           *name=NULL;
	//logical  StatusFound = false;
*revstatus=NULLTAG;
	printf("\n Inside MM_check_status::count==>[%d] \n",count);fflush(stdout);
	if(count>0)
	{
		for(NStatus=0;NStatus<count;NStatus++)
		{
			ifail=RELSTAT_ask_release_status_type(status_list[NStatus],&name);
			printf("\n Inside MM_check_status==>[%s] \n",name);fflush(stdout);

			if(tc_strcmp(name,status_name)==0)
			{
				StatusFound = true;
				*revstatus=status_list[NStatus];
				break;
			}
		}
	}
	else
	{
		printf("\n Inside Service_check_status else ::revstatus==>[%u] \n",revstatus);fflush(stdout);
		*revstatus=NULLTAG;
		printf("\n After NULLTAG Service_check_status else ::revstatus==>[%u] \n",revstatus);fflush(stdout);
	}
	
}

static void ServiceReleaseRevision(tag_t rev,tag_t *released_rev,char *status_name,char *ReleasedDate_str)
{
   int   hits                                                                           = 0,
	count                                                                                = 0,
	ifail                                                                                   = 0;	
   //char *status_name                                                    = NULL;

    tag_t list                                                                                         = NULLTAG,
				  set_effec                                                                         = NULLTAG,
				  revstatus                                                                         = NULLTAG,
				  release_status                                  = NULLTAG;

   tag_t  *status_list                                                          = NULL;
   //date_t ReleasedDate =NULLDATE;
   date_t ReleasedDate;
 //ResultStatus stat;
   char         *stamp             = NULL;
   char         *itemId             = NULL;

   char  name[WSO_name_size_c+1]    = {'\0'};
	
   
   StatusFound = false;

   printf("\n Inside MM_ReleaseRevision \n");fflush(stdout);

  // ifail=CR_find_status_type(status_name,&list );
  ifail=EPM_find_status_type(status_name,&list );
   //printf("\n find status list hits:%d\n",list);

   ifail=RELSTAT_create_release_status( status_name,&release_status);
   ifail=WSOM_ask_release_status_list(rev ,&count,&status_list);
   
   printf("\n Inside MM_ReleaseRevision::count-->[%d] %s\n",count,status_name);fflush(stdout);
   //Check this status is alreasy present in ItemRevision
   Service_check_status(count,status_list,status_name,&revstatus);
    printf("\n Inside MM_ReleaseRevision::count-->[%d] %u\n",count,revstatus);fflush(stdout);
   //if Status is not present ,it will add status under ItemRevision
   if ( revstatus==NULLTAG )
   {

	  tag_t     releaseStatusListId = NULLTAG;
	  tag_t     releaseDateId     = NULLTAG;
	  printf("\n b4 RELSTAT_add_release_status ");fflush(stdout);
	   RELSTAT_add_release_status( release_status, 1, &rev, true );
	   printf("\n After RELSTAT_add_release_status ReleasedDate_str[%s] ",ReleasedDate_str);fflush(stdout);
	  //ITKCALL(ITK_string_to_date("30-Dec-2019 00:00",&ReleasedDate));
	  //ReleasedDate = TML_token_to_date("2006/02/21-00:00:00");
	  ReleasedDate = TML_token_to_date(ReleasedDate_str);
	   printf("\n After ITK_string_to_date ReleasedDate=%d",ReleasedDate.day);fflush(stdout);
	  ifail = AOM_set_value_date(release_status, "date_released", ReleasedDate);

	 // printf("\n ReleasedDate_str=%s ReleasedDate=%s",ReleasedDate_str,ReleasedDate);fflush(stdout);
	printf("\n find status list hits fail=%d ",ifail);fflush(stdout);
	  /* Load the workspace object for modification */
	  ifail = AOM_refresh(rev, POM_modify_lock);

	  AOM_ask_value_string(rev,"item_id",&itemId);
	  printf("\n 1 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	 // ifail = POM_attr_id_of_attr("date_released", "WorkspaceObject", &releaseDateId);
	  ifail = POM_attr_id_of_attr("date_released", "ItemRevision", &releaseDateId);
		printf("\n 2find status list hits fail=%d ",ifail);fflush(stdout);
	  printf("\n 3 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	  
	  printf("\n 5 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
		printf("\n 4find status list hits fail=%d ",ifail);fflush(stdout);
	 /* Unlock the newly created release status instance */
	 //ifail = POM_refresh_instances_any_class(1, &rev, POM_no_lock);
	 ifail = POM_refresh_instances_any_class(1, &rev, POM_modify_lock);
	printf("\n 6find status list hits fail=%d ",ifail);fflush(stdout);
	ifail = POM_set_attr_date(1, &rev, releaseDateId, ReleasedDate);
	 printf("\n 7 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	 /* Save the workspace object */
	 //ifail = POM_save_instances(1, &rev, false);
	 ifail = POM_save_instances(1, &rev, true);
	printf("\n 7find status list hits fail=%d ",ifail);fflush(stdout);
	 printf("\n 8 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
	 
   }
   if(revstatus==NULLTAG)
   printf("\n  NULL  ServicesetRevEff  MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);

   printf("\n  14 ServicesetRevEff  MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
   *released_rev=revstatus;
   //*released_rev=release_status;
   printf("\n 15 MM_ReleaseRevision::itemId is [%s]",itemId);fflush(stdout);
}


int RelaeseRevision(void *return_data)
{
	int ifail = ITK_ok;
	int n_ints = 0;
	int ii;
	tag_t obj=NULLTAG;
	tag_t relrev=NULLTAG;
        tag_t released_rev=NULLTAG;
	char *status_name=NULL;
	char *ReleasedDate_str=NULL;
	char *ReleasedDate_str_to=NULL;
	int *args = NULL;
	printf("\n Action..... \n");fflush(stdout);
	USERARG_get_tag_argument(&obj);
	USERARG_get_string_argument(&status_name);
	USERARG_get_string_argument(&ReleasedDate_str);
	
	 printf("\n After get status_name[%s] ReleasedDate_str[%s]..... \n",status_name,ReleasedDate_str);fflush(stdout);
        
   	ServiceReleaseRevision(obj,&released_rev,status_name,ReleasedDate_str);
    printf("\n After ServiceReleaseRevision..... \n");fflush(stdout);

	
  
	return ifail;
}

extern int call_releaserevision_methods(int *decision, va_list args)
{
	  int n_input_args = 3;
	  int input_args[3]= {0, 0, 0} ;
	  int return_data = USERARG_VOID_TYPE;
	  //int return_data = USERARG_TAG_TYPE;

	  int   status = ITK_ok;
	  int ifail = ITK_ok;
 
 /* input arguments passed from client to server */
  
  input_args[0] = USERARG_TAG_TYPE; 
  input_args[1] = USERARG_STRING_TYPE; 
  input_args[2] = USERARG_STRING_TYPE; 
  //input_args[3] = USERARG_STRING_TYPE;

	char *funcname=(char *)"RelaeseRevision";


  //printf("\n In Before call_releaserevision_methods\n");fflush(stdout);
  ifail=USERSERVICE_register_method(funcname,(USER_function_t)RelaeseRevision,n_input_args,input_args,return_data);
  //printf("\n In After call_releaserevision_methods\n");fflush(stdout);
 
  return ifail;
}



//End User Service process

extern int MCNOTEinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	METHOD_id_t  method1;
	METHOD_id_t  method2;
	METHOD_id_t  method3;
	METHOD_id_t methodrawfamily,methodsheetweight;
	//printf("\n ############ After Rigister MCNOTEinitmodule");fflush(stdout);
		//CALLAPI(ICS_init_module());
		CALLAPI(ICS_init_hooks());
	//printf("\n ICS_init_hooks");fflush(stdout);
	/*L/R INDICATOR DYNAMIC LIST OF VALUES POPULATE FOR CKD DUMMY PART CREATION*/
	CALLAPI(METHOD_register_method( "T5_RawPartFamilyLov",LOV_ask_values_msg,&dynamic_raw_ValuesMethodFamily, 0,&methodrawfamily));
    CALLAPI(METHOD_register_method( "T5_RawPartFamilyLov",LOV_ask_num_of_values_msg,&dynamic_raw_LengthsMethodFamily,0,&methodrawfamily));
	CALLAPI(METHOD_register_prop_method("T5_RPtRel", "t5_UsageRT",  PROP_UIF_ask_value_msg, getsheetweight, 0,  &methodsheetweight ));
	if(methodsheetweight.id==NULLTAG)
	printf("\n METHOD REGISTER ERROR");
	else
	//printf("\n METHOD REGISTER SUCCESS");
	//printf("\n IN ******************************dynamic_pos_Method registering REGISTER");fflush(stdout);	
	
	
	//closed by Amar
	////Start Method registering 
	//CALLAPI(METHOD_find_method("T5_RawPart", "ITEM_create", &method1));
	////printf("\n  *****METHOD_find_method\n");fflush(stdout);    
	//
	////printf("\n TMML.c: MyType:method - ");fflush(stdout);			   
	//if (method1.id != NULLTAG)
	//{
	//	//printf("\n  *****b4 METHOD_add_Post_action\n");fflush(stdout);    
	//	CALLAPI( METHOD_add_action(method1, METHOD_post_action_type,(METHOD_function_t)CreateRawPartpost, NULL));
	//	//printf("\n  *****After CreateRawPartpost METHOD_add_action\n");fflush(stdout); 		  
	//}
	
	
	//Start Method registering for T5_RPtRel
	CALLAPI(METHOD_find_method("T5_RPtRel", "IMAN_save", &method2));
	//printf("\n  *****METHOD_find_method T5_RPtRel for T5_RPtRel of IMAN_save \n");fflush(stdout);    

	//printf("\n MyType:method - T5_RPtRel");fflush(stdout);			   
	if (method2.id != NULLTAG)
	{
		
		//printf("\n  *****b4 METHOD_add_pre_action McNoteValidationFunc\n");fflush(stdout);    
		CALLAPI( METHOD_add_action(method2, METHOD_pre_action_type,(METHOD_function_t) McNoteValidationFunc, NULL));
		//printf("\n  *****After McNoteValidationFuncPre METHOD_add_action\n");fflush(stdout);
		
		//printf("\n  *****b4 METHOD_add_post_action RawPrtUsagePostValidation\n");fflush(stdout);    
		CALLAPI( METHOD_add_action(method2, METHOD_post_action_type,(METHOD_function_t) RawPrtUsagePostValidation, NULL));
		//printf("\n  *****After RawPrtUsagePostValidation METHOD_add_action\n");fflush(stdout);
		
	}
	
	//CALLAPI( METHOD_find_method("T5_RPtRel", IMAN_save_msg, &method3));
	CALLAPI( METHOD_find_method("T5_RPtRel", TC_save_msg, &method3));
	if (method3.id != NULLTAG)
	{
		//printf("\n  *****b4 METHOD_add_Post_action for IMAN_save_msg for plantname set for raw part relation creation\n");fflush(stdout);    
		CALLAPI( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) setPlantInRawPartRelCre, NULL));
		//if( METHOD_add_pre_condition(method5,(METHOD_function_t)Has_ChassisType_validation,NULL)!=ITK_ok)
		//printf("\n  *****After METHOD_add_Post_action for IMAN_save_msg for plantname set for raw part relation creation\n");fflush(stdout); 		  
		
		
	}
	else
	{
		printf("method3 not found for setPlantInRawPartRelCre for IMAN_save_msg\n");fflush(stdout);
	}
	//printf("\n  b4 METHOD_register_prop_method register\n");fflush(stdout); 		
	CALLAPI(METHOD_register_prop_method("T5_SupSpc", "t5_SupSpcIsInMatCde",  PROP_ask_value_tag_msg, getSupSpcIsInMatCde, 0,  &method2 ));
	//printf("\n  After METHOD_register_prop_method register\n");fflush(stdout); 	
	
	
	//printf("\n  b4 METHOD_register_prop_method register for t5_RawPrtinAsmRelCls\n");fflush(stdout); 		
	CALLAPI(METHOD_register_prop_method("T5_RawPart", "t5_RawPrtinAsmRelCls",  PROP_ask_value_tag_msg, getAsmRelationFrmRawPrt, 0,  &method2 ));
	//printf("\n  After METHOD_register_prop_method register for t5_RawPrtinAsmRelCls\n");fflush(stdout); 	
	
   /* End  */
	
	return ifail;
}

//


extern "C" DLLAPI int tm_MCNOTE_register_callbacks ()
{
	
	int ifail    = ITK_ok;
	//printf("\n Before registring userservice....tm_MCNOTE");fflush(stdout);  
	ifail=CUSTOM_register_exit ( "tm_MCNOTE", "USER_init_module", (CUSTOM_EXIT_ftn_t)MCNOTEinitmodule);
	//printf("\n After registoring userservice....tm_MCNOTE");fflush(stdout);
	//printf("\n Before registring userservice....call_releaserevision_methods");fflush(stdout);
	ifail=CUSTOM_register_exit ( "tm_MCNOTE", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  call_releaserevision_methods);
	//printf("\n After registring userservice....call_releaserevision_methods");fflush(stdout);
	return ( ITK_ok );
}
