/****************************************************************************************************
*  File            :   Revise
*  Created By      :   TcUA Team
*  Created On      :   06-Jun-2018
*  Purpose         :   Revise of ERC Review/ERC Working Design Object should be blocked			
*					   This is called at Revise action of Design Revision creation.
******************************************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <time.h>

#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <bom/bom_tokens.h>
#include <pom/pom/pom.h>
#include <tccore/aom.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <ps/ps_errors.h>
#include <ps/vrule.h>
#include <tccore/grm.h>
#include <tc/emh_errors.h>
#include <tc/tc_errors.h>
#include <ss/ss_errors.h>
#include <fclasses/tc_string.h>
#include <property/prop.h>
#include <error.h>

#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>

#define ITK_errStore 91900002
#define ITK_err 91900003
#define ITK_err1 91900004
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

static int	 LHRhFlag		= -1;

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}


extern  DLLAPI int Revise_properties(METHOD_message_t *m, va_list args)
{
	char   *ReleaseStatus=NULL;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t  source_rev_Type_Tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	int	   ifail	=0;
	int	   ii=0;
	char   *text	=NULL;
	int	   status_count=0;
	char   *Item_string=NULL;
	int status;	
	tag_t	source_rev				 = va_arg(args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	tag_t	master	=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	tag_t	sequence_id_c	=	NULLTAG;
	tag_t	sequence_id_c1	=	NULLTAG;
	char	*Desc_obj	 = NULL;
	char	*Desc_obj1	 = NULL;
	char	*ITemRevSeq	 = NULL;
	char	*ITemRevSeq1 = NULL;

	//LH/RH Attribute
	char * ItemLhRhInd;
	char *SesUsr = NULL;
	int result,n_attch = 0;
	tag_t  	ItemMstr1 =	NULLTAG;
	tag_t  	*ItemMstr2 =	NULLTAG;
	tag_t   relSor_type =	NULLTAG;
	tag_t   relation_type =	NULLTAG;
	tag_t	ItemMstrRev	=	NULLTAG;
	tag_t   objTypeTag1 =   NULLTAG;
	char type_name1[TCTYPE_name_size_c+1];
	tag_t RevNewSeqTag = NULLTAG;
	
	printf("\n Inside Revise_properties Function.... \n");fflush(stdout);	
	if(TCTYPE_ask_object_type(source_rev,&source_rev_Type_Tag)!=ITK_ok) PrintErrorStack(); 
	if(TCTYPE_ask_name(source_rev_Type_Tag,type_name)!=ITK_ok) PrintErrorStack();	
	printf("\n Item Type Found:%s\n", type_name);fflush(stdout);	
	
	if(strcmp(type_name,"Design Revision")==0)
	{
		status=WSOM_ask_release_status_list(source_rev,&status_count,&status_list);
	    if(status==ITK_ok)
		{
			printf("\n number of statuses: %d \n",  status_count);
			for (ii = 0; ii < status_count; ii++)
			{
				AOM_ask_name(status_list[ii], &ReleaseStatus);
				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
			}
							
			AOM_ask_value_string(source_rev,"object_string",&Item_string);
			printf("\t Revision %s with %s\n", Item_string,ReleaseStatus);fflush(stdout);

			if((strcmp(ReleaseStatus,"T5ErcPublished")==0) )
			{
				printf("\n BaseLine Revision %s Failed. \n",Item_string);fflush(stdout);
				status=EMH_store_error_s1(EMH_severity_error,ITK_err, "BaseLine Object Cannot Be Revised, Please Revise The Actual Object");
				return ITK_err;
			}	

			if(ITEM_ask_item_of_rev(source_rev,&master) );
			if(ITEM_ask_latest_rev(master,&latestrev));

			if (AOM_ask_value_string(latestrev,"current_revision_id",&Desc_obj)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_int(latestrev,"sequence_id",&sequence_id_c)) PrintErrorStack();
			ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
			sprintf(ITemRevSeq,"%d",sequence_id_c);

			if (AOM_ask_value_string(source_rev,"current_revision_id",&Desc_obj1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_int(source_rev,"sequence_id",&sequence_id_c1))PrintErrorStack();
			ITemRevSeq1 = (char *) MEM_alloc( 5 * sizeof(char) );
			sprintf(ITemRevSeq1,"%d",sequence_id_c1);

			if ((strcmp(Desc_obj,Desc_obj1) !=0) || (sequence_id_c != sequence_id_c1))
			{
				printf("\n Part is not latest ERC Released,Revision of %s Failed. \n",Item_string);fflush(stdout);
				status=EMH_store_error_s2(EMH_severity_error,ITK_err1, "Only Latest ERC Released Revision is allowed to Revise,Revision Failed for part",Item_string);
				return ITK_err1;
			}
			
			/******************************************************************************************
											LH/RH Revise start
			******************************************************************************************/	
			POM_get_user_id(&SesUsr);
			printf("\n Session user : %s\n",SesUsr); fflush(stdout);

			if((tc_strcmp(SesUsr,"infodba") !=0) && (tc_strcmp(SesUsr,"loader") !=0))
			{
				if((strcmp(ReleaseStatus,"T5_LcsErcRlzd")!=0) )
				{
					printf("\n Only ERC Released Revision is allowed to Revise,Revision of %s Failed. \n",Item_string);fflush(stdout);
					status=EMH_store_error_s2(EMH_severity_error,ITK_errStore, "Only ERC Released Revision is allowed to Revise,Revision Failed for part",Item_string);
					return ITK_errStore;
				}else
				{
					printf("\t Revision of %s with %s is successfully Created. \n", Item_string,ReleaseStatus);fflush(stdout);				
					ITKCALL(AOM_ask_value_string(source_rev,"t5_LeftRh_Comp",&ItemLhRhInd));
					printf("\n LH/RH Indicator of Left Part is :: %s",ItemLhRhInd);fflush(stdout);

					if((ItemLhRhInd==NULL) || (tc_strcmp(ItemLhRhInd,"NA")==0))
					{	
						printf("\n inside NULL/NA of LH/RH Indicator values");fflush(stdout);
					}else
					{
						if(tc_strcmp(ItemLhRhInd,"LH CATIA")==0 || tc_strcmp(ItemLhRhInd,"LH PROE")==0)
						{
							printf("\n inside LH CATIA OR PROE--------->\n");fflush(stdout);
							ITKCALL(ITEM_ask_item_of_rev(source_rev, &ItemMstr1)); 
							printf("\n ITEM_Found......");fflush(stdout);

							result = GRM_find_relation_type("T5_LRReln", &relation_type);
							printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

							if (relation_type!=NULLTAG)
							{
								ITKCALL(GRM_list_secondary_objects_only(ItemMstr1,relation_type,&n_attch,&ItemMstr2));
								printf("\n ItemMstr2 from Design master1 :: %d\n",n_attch);fflush(stdout);
								if(n_attch>0)
								{
									ITKCALL(ITEM_ask_latest_rev(ItemMstr2[0],&ItemMstrRev));
									if (ItemMstrRev!=NULLTAG)
									{	  
									  printf("\n ItemMstr2 latest revision found------->\n");fflush(stdout); 
									  if(TCTYPE_ask_object_type(ItemMstrRev,&objTypeTag1)!=ITK_ok)PrintErrorStack();
									  if(TCTYPE_ask_name(objTypeTag1,type_name1)!=ITK_ok)PrintErrorStack();								 
									  printf("\n type_name1 ==> %s\n", type_name1);fflush(stdout);

									  if((tc_strcmp(type_name1,"Design Revision")==0) || (tc_strcmp(type_name1,"ItemRevision")==0))
									  {
										printf("\n LH Part Revision is also of type [Design Revision/ItemRevision]");fflush(stdout);
										printf("\n LHRhFlag : %d",LHRhFlag);
										LHRhFlag = 1;
										printf("\n LHRhFlag : %d",LHRhFlag);
										if(LHRhFlag==1)
										{
											if(ITK_ok != (ifail = ITEM_copy_rev(ItemMstrRev,NULL,&RevNewSeqTag)))
											{
												printf("\n RH Part ifail for Revise.............");fflush(stdout);
												return ifail;
											}else
											{
												printf("\n RH Part success for Revise.............");fflush(stdout);
												ITKCALL(AOM_refresh(ItemMstrRev,0));		
											}
										}
									  }
									}							
								}else
								{
									status=EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please Confirm LH/RH Relationship.\n");
									return ITK_errStore;
								}
							}
						}else if(tc_strcmp(ItemLhRhInd,"RH CATIA")==0 || tc_strcmp(ItemLhRhInd,"RH PROE")==0)
						{
							printf("\n inside RH CATIA OR PROE--------->\n");fflush(stdout);
							ITKCALL(ITEM_ask_item_of_rev(source_rev, &ItemMstr1)); 
							printf("\n ITEM_Found......");fflush(stdout);

							result = GRM_find_relation_type("T5_LRReln", &relSor_type);
							printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
							if (relSor_type!=NULLTAG)
							{
								ITKCALL(GRM_list_secondary_objects_only(ItemMstr1,relSor_type,&n_attch,&ItemMstr2));
								printf("\n ItemMstr2 from Design ItemMstr1 :: %d\n",n_attch);fflush(stdout);

								if(n_attch>0)
								{
									printf("\n for RH CATIA LHRhFlag values is => %d\n",LHRhFlag);
									if(LHRhFlag<1)
									{
										status=EMH_store_error_s1(EMH_severity_error,ITK_errStore, "In-Valid to Revise RH Part, Pls select LH Part and Revise\n");
										return ITK_errStore;
									}
								}else
								{
									status=EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please Confirm LH/RH Relationship.\n");
									return ITK_errStore;
								}
							}
						}else
						printf("\n ItemLhRhInd other than LH/RH CATIA/PROE..........\n");fflush(stdout);
					}
				 }
		  }else
		  {
			printf("\n Bypass for infodba/loader..........\n");fflush(stdout);	
		  }
		 }else
		 {
			 status=EMH_ask_error_text(ifail,&text); 
		 }		
	}

	MEM_free(status_list);
	MEM_free(ReleaseStatus);
	MEM_free(Item_string);
	
	printf("\nKnow LHRhFlag going to change values to -1\n");fflush(stdout);
	LHRhFlag= -1;

	return ITK_ok;
}


extern int libRevise_register_pre_condition(int *decision, va_list args)
{
	METHOD_id_t  method;
	int	ifail = 0;
    *decision = ALL_CUSTOMIZATIONS;
	
	printf("\n Inside libRevise_register_pre_condition  \n");;fflush(stdout);
    CALLAPI(METHOD_find_method("Design Revision", "ITEM_copy_rev", &method));
    if (method.id != NULLTAG)
    {
        CALLAPI(METHOD_add_pre_condition(method, (METHOD_function_t) Revise_properties, NULL));

		TC_write_syslog("\n\nAfter Register Revise\n");

		printf("\n Registered as libRevise_register_pre_condition for Creation \n");fflush(stdout);
    }else
     printf("\n Method not found! \n");fflush(stdout);

    return ifail;	
}

extern DLLAPI int libRevise_register_callbacks()
{
	printf("\n Inside libRevise_register_callbacks  \n");;fflush(stdout);

	CUSTOM_register_exit("libRevise", "USER_init_module", (CUSTOM_EXIT_ftn_t)libRevise_register_pre_condition);

    TC_write_syslog("\nRegister libRevise_register_callbacks \n");

	printf("\n libRevise_register_callbacks called.   \n");;fflush(stdout);

	return ITK_ok;
}
