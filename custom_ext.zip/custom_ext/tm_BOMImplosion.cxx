#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pom/pom/pom.h>
// #include <tc/tc.h>clclk
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
// #include <tc/iman.h>
// #include <tccore/imantype.h>
// #include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
// #include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h> /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h> /* for dataset id and rev */
#include <ae/ae_types.h>  /* for dataset id and rev */
#include <unidefs.h>
#include <tccore/tctype.h>

#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
// #include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
// #include <tc/emh_const.h>
#include <sa/groupmember.h>
// #include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
// #include <tc/tc.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>

#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>

#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <sstream>
#include <streambuf>
#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <iterator>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <map>
//#include <base_utils/IFail.hxx>
// #include <base_utils/TcResultStatus.hxx>
// #include <base_utils/ScopedPtr.hxx>
// #include <base_utils/ScopedSmPtr.hxx>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
// #include <tc/iman.h>
// #include <tccore/imantype.h>
// #include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
// #include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h> /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h> /* for dataset id and rev */
#include <ae/ae_types.h>  /* for dataset id and rev */
#include <unidefs.h>
#include <tccore/tctype.h>

#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
// #include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
// #include <tc/emh_const.h>
#include <sa/groupmember.h>
// #include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <iostream>
#include <tccore/tctype.h>
// #include <tc/tc.h>
#include <tccore/aom.h>
#include <ps/ps.h>
#include <epm/epm.h>
#include <string>
#include <vector>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <ae/dataset.h>

#include <pom/pom/pom.h>
#include <form/form.h>
#include <tccore/project.h>

// #include <metaframework/BusinessObjectRef.hxx>
// #include <base_utils/IFail.hxx>
// #include <base_utils/TcResultStatus.hxx>
// #include <base_utils/ScopedSmPtr.hxx>
// #include <mld/logging/TcMainLogger.hxx>

using namespace std;
//using namespace Teamcenter;
// using Teamcenter::Main::logger;
#include <tccore/aom_prop.h>

#define CALLAPI(expr)      \
    ITKCALL(ifail = expr); \
    if (ifail != ITK_ok)   \
    {                      \
        return ifail;      \
    }

#define ITK_CALL(x)                                                              \
    {                                                                            \
        int stat;                                                                \
        char *err_string;                                                        \
        if ((stat = (x)) != ITK_ok)                                              \
        {                                                                        \
            EMH_get_error_string(NULLTAG, stat, &err_string);                    \
            printf("ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
            printf("FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
            if (err_string)                                                      \
                MEM_free(err_string);                                            \
            exit(EXIT_FAILURE);                                                  \
        }                                                                        \
    }

typedef struct PartQtyList
{

    tag_t partobj;
    float actualqty;
    float consolidateqty;
    char *currentViewMaskMBOM;
    char *currentViewMask;
    date_t createDate;
    char *partType;
    char *plantCS;
    char *relStatusList;

} PartQtyList_t;

char *removeChar_BOMImplosion(char *in)
{
    // printf("\n Test Inside Function removeChar \n");fflush(stdout);
    int i, j;
    char *tmp;
    tmp = (char *)malloc(strlen(in) + 2);
    i = 0;
    j = 0;
    while (in[j])
    {
        // if (in[j] != '\x01' && in[j] != '\x02')
        if (in[j] != '\n' && in[j] != '\r' && in[j] != '#' && in[j] != '$' && in[j] != ',')
        {
            tmp[i] = in[j];
            i++;
        }
        j++;
    }
    tmp[i] = '\0';

    return tmp;
}

bool sortVector(PartQtyList p1, PartQtyList p2)
{

    int ans;
    POM_compare_dates(p1.createDate, p2.createDate, &ans);

    return ans == 1;
}

// void setAddTAG(int *count, tag_t **objlist, tag_t obj)
// {

// 	*count = *count + 1;
// 	if (*count == 1)
// 	{
// 		// printf("\n ****setAddTAG1");fflush(stdout);
// 		(*objlist) = (tag_t *)malloc((*count) * sizeof(tag_t));
// 	}
// 	else
// 	{
// 		// printf("\n ****setAddTAG2");fflush(stdout);
// 		(*objlist) = (tag_t *)realloc((*objlist), (*count) * sizeof(tag_t));
// 	}

// 	(*objlist)[*count - 1] = obj; // malloc((strlen(view_id)+1) * sizeof(char));
// }

void get_PSOccurrences_of_item(tag_t itemRev, tag_t item_rev_tag, tag_t rule, std::set<std::string> &parentPart, int *n_occs, tag_t **occs)
{
    int n_instances = 0;
    int *instance_levels = 0;
    int *instance_where_found = 0;
    int n_classes = 0;
    int *class_levels = 0;
    int *class_where_found;
    tag_t *ref_instances = NULL;
    tag_t *ref_classes = NULL;
    char *pitem_id;
    int n_parents = 0;
    tag_t *levels = NULL;
    tag_t *parents = NULL;
    char *parent_part;

    AOM_ask_value_string(item_rev_tag, "item_id", &pitem_id);
    ITKCALL(PS_where_used_configured(itemRev, rule, 1, &n_parents, &levels, &parents));
    printf("Shiv: n_parents= %d \n", n_parents); //
    printf("Shiv: item_id= %s \n", pitem_id);    // give child part
    // printf("Shiv: itemRev= %s \n ", itemRev);
    if (n_parents > 0)
    {
        // printf("n_parents : %d \n", n_parents);
        cout << "n_parents: " << n_parents << endl;
        printf("inside PS_where_used_configured \n");
        for (int i = 0; i < n_parents; i++)
        {
            tag_t type_tag1 = NULLTAG;
            (TCTYPE_ask_object_type(parents[i], &type_tag1));

            char *type_name1 = NULL;
            (TCTYPE_ask_name2(type_tag1, &type_name1));

            AOM_ask_value_string(parents[i], "object_string", &parent_part);
            // std::string objStr = removeChar_BOMImplosion(objStrChk);

            // printf("Object Testing : %s \n ", objStrChk);
            // printf("Object Testing2 : %s \n ", removeChar_BOMImplosion(objStrChk));
            // printf("Object Testing3 : %s \n ", objStr.c_str());
            cout << "parent_part: " << "i " << i << " " << parent_part << endl; // give parent part
            parentPart.insert(parent_part);
        }
    }

    (POM_referencers_of_instance(item_rev_tag, 1, POM_in_db_only,
                                 &n_instances, &ref_instances, &instance_levels,
                                 &instance_where_found, &n_classes, &ref_classes, &class_levels,
                                 &class_where_found));

    printf("\n *************start get_PSOccurrences_of_item pitem_id=%s n_instances==%d", pitem_id, n_instances);

    if (n_instances > 0)
    {
        int count = 0;

        for (int ii = 0; ii < n_instances; ii++)
        {
            tag_t type_tag = NULLTAG;
            (TCTYPE_ask_object_type(ref_instances[ii], &type_tag));

            char *type_name = NULL;
            (TCTYPE_ask_name2(type_tag, &type_name));

            printf("pitem_id=%s type_name=%s \n", pitem_id, type_name);

            if (type_name != NULL && !strcmp("PSOccurrence", type_name))
            {
                count++;
                if (count == 1)
                {
                    (*occs) = (tag_t *)MEM_alloc(sizeof(tag_t));
                }
                else
                {
                    (*occs) = (tag_t *)MEM_realloc((*occs), count * sizeof(tag_t));
                }
                (*occs)[count - 1] = ref_instances[ii];
                *n_occs = count;
            }
        }

        if (instance_levels)
            MEM_free(instance_levels);
        if (instance_where_found)
            MEM_free(instance_where_found);
        if (class_levels)
            MEM_free(class_levels);
        if (ref_classes)
            MEM_free(ref_classes);
        if (class_where_found)
            MEM_free(class_where_found);
        if (ref_instances)
            MEM_free(ref_instances);
    }
}

int getParents(float pconqty, char *origPart, tag_t itemRev, tag_t revRule, char *revName, char *remUndPrt, char *skipZero, int levelCnt, int maxLimit, map<std::string, std::string> &topLevelParts, map<std::string, float> &vcModMAP, std::set<std::string> &modQtySet, map<std::string, std::string> &vcVehicle, std::set<std::string> &vehicleSet, tag_t rule, std::set<std::string> &parentPart, FILE *fp)
{
    if (levelCnt > maxLimit)
        return;
    int ifail = ITK_ok;
    int occCnt = 0;
    tag_t *occurences = NULLTAG;

    tag_t itemMaster = NULLTAG;
    char *masterItemID;
    ITEM_ask_item_of_rev(itemRev, &itemMaster);
    AOM_ask_value_string(itemMaster, "item_id", &masterItemID);

    printf("Item Master in Progress -> ", masterItemID);

    // Control Object Initialization
    char *qryCOEntries[4] = {"SYSCD", "SUBSYSCD", "Information-1", "Delete Indicator"};
    char *qryCOValues[4] = {"BOMImplosion", "RevisionRule", revName, "0"};

    char *qryIREntries[2] = {"Item ID", "Release Status"};
    char *qryIRSort[1] = {"creation_date"};
    int qryIRSortOrder[1] = {2};

    tag_t qryCOTag = NULLTAG;
    tag_t qryIRTag = NULLTAG;

    int cocnt;
    tag_t *cores = NULLTAG;

    int ircnt = 0;
    tag_t *irres = NULLTAG;

    char *reqMakeBuy;
    char *itemId;

    CALLAPI(QRY_find2("Control Objects...", &qryCOTag));
    CALLAPI(QRY_find2("Item Revision...", &qryIRTag));
    // Control Object Initialization - END

    char *cvmask;
    CALLAPI(QRY_execute(qryCOTag, 4, qryCOEntries, qryCOValues, &cocnt, &cores));

    CALLAPI(AOM_ask_value_string(cores[0], "t5_Userinfo3", &cvmask));
    printf("\n cvmask - %s \n", cvmask);

    CALLAPI(AOM_ask_value_string(cores[0], "t5_Userinfo6", &reqMakeBuy));
    printf("\n Plant CS - %s \n", reqMakeBuy);

    get_PSOccurrences_of_item(itemRev, itemMaster, rule, parentPart, &occCnt, &occurences); // replace api
    printf("Exit loop get_PSOccurrences_of_item \n");

    std::map<std::string, std::vector<PartQtyList>> partlistmap;

    std::map<std::string, std::string> parentItemMap;
    std::set<std::string> maskSet;

    char *currentid;
    char *Objectdesc;
    char *itemrevision;
    printf("how many time \n");
    // AOM_ask_value_string(itemRev, "object_string", &objStrChk);
    AOM_ask_value_string(itemRev, "current_id", &currentid);
    AOM_ask_value_string(itemRev, "item_revision_id", &itemrevision);
    AOM_ask_value_string(itemRev, "object_desc", &Objectdesc);

    std::string objStrChk = std::string(currentid) + "/" + std::string(itemrevision) + "/" + std::string(Objectdesc);
    char *objStrChk_c = (char *)MEM_alloc(objStrChk.size() + 1);
    strcpy(objStrChk_c, objStrChk.c_str());
    std::string objStr = removeChar_BOMImplosion(objStrChk_c);

    printf("Object Testing : %s \n ", objStrChk_c); // our base part for which we are finding parent
    printf("Object Testing2 : %s \n ", removeChar_BOMImplosion(objStrChk_c));
    printf("Object Testing3 : %s \n ", objStr.c_str());
    if (occCnt == 0 && tc_strcmp(objStrChk_c, origPart) != 0)
    {
        double qtyval;
        float consolidateqty;
        char qtyvalStr[64];
        char consolidateqtyStr[64];
        printf("\nInside Top line set Add - %s\n", objStrChk_c);
        // string objStr = std::string(objStrChk);

        std::map<std::string, std::string>::iterator itrCheck = topLevelParts.find(objStrChk_c);

        if (itrCheck == topLevelParts.end())
        {
            char *relStatusListTop = (char *)MEM_alloc(100 * sizeof(char *));
            char *allTopProp = (char *)MEM_alloc(500 * sizeof(char *));
            char *relStatusListsTop, *partTypeTop;

            AOM_UIF_ask_value(itemRev, "t5_PartType", &partTypeTop);
            AOM_UIF_ask_value(itemRev, "release_status_list", &relStatusListsTop);
            STRNG_replace_str(relStatusListsTop, ",", ";", &relStatusListTop);
            qtyval = pconqty;
            consolidateqty = pconqty;
            sprintf(qtyvalStr, "%.2f", qtyval); // format double to string with 2 decimal places
          //  sprintf(consolidateqtyStr, "%.2f", consolidateqty);//06022026
              sprintf(consolidateqtyStr, "%d", (int)consolidateqty);
            printf("qtyvalStr %.2f", qtyvalStr);
            printf("\n consolidateqty==%.2f \n", consolidateqty);

            printf("\n relStatusList==%s \n", relStatusListTop);
            printf("\n partTypeTop==%s \n", partTypeTop);
            

            tc_strcpy(allTopProp, partTypeTop);
            tc_strcat(allTopProp, ",");
            tc_strcat(allTopProp, relStatusListTop);
            tc_strcat(allTopProp, ","); //change on 031225
             tc_strcat(allTopProp, consolidateqtyStr);//06-02-26
            //  tc_strcat(allTopProp, ",");
            //  tc_strcat(allTopProp, qtyvalStr);

            // topLevelParts.insert(std::pair<std::string, std::string>(removeChar_BOMImplosion(objStrChk), allTopProp));
            topLevelParts.insert(std::pair<std::string, std::string>(objStr.c_str(), allTopProp));
        }
    }
    printf("\n OCCS==%s %d", masterItemID, occCnt);
    if (occCnt > 0)
    {
        for (int i = 0; i < occCnt; i++)
        {
            tag_t parent_bvr = NULLTAG;
            int itemRevCnt = 0;
            tag_t *itemRevList;
            double qtyval;
            char *parentBVR;
            char *itemRevListStr;
            char *currentViewMask;
            char *currentViewMaskMBOM;
            date_t creationDate;
            char *reqCureViewMask;

            // char *suppressed;

            tag_t parentItem;
            char *parentItemID;

            char *partType;
            char *relStatusList = (char *)MEM_alloc(100 * sizeof(char *));
            char *relStatusLists;
            char *plantCS;

            AOM_ask_value_tag(occurences[i], "parent_bvr", &parent_bvr);
            if (parent_bvr == NULLTAG)
                continue;

            PS_list_owning_revs_of_bvr(parent_bvr, &itemRevCnt, &itemRevList);
            if (itemRevList == NULLTAG)
                continue;

            // int tempNum;
            // char **tempTag;
            // AOM_ask_prop_names(itemRevList[0],&tempNum,&tempTag);
            // for(int d=0;d<tempNum;d++)
            // {
            // 	printf("\n tempTag -%s \n",tempTag[d]);
            // }
            // exit(0);

            printf("\n itemRevCnt - %d\n", itemRevCnt);

            tag_t configured_revs1 = NULLTAG;
            tag_t itemMaster1 = NULLTAG;
            char *how_configured1 = NULL;
            char *configuredRev1;

            ITEM_ask_item_of_rev(itemRevList[0], &itemMaster1);

            CFM_item_ask_configured(revRule, itemMaster1, &configured_revs1, &how_configured1);

            if (configured_revs1 == NULL)
                continue;

            AOM_ask_value_string(configured_revs1, "object_string", &configuredRev1);

            printf("\n ConfigRev111=%s \n", configuredRev1);

            AOM_ask_value_string(itemRevList[0], "object_string", &itemRevListStr);
            printf("\n itemRevListStr==%s \n", itemRevListStr);

            // if (tc_strcmp(configuredRev1, itemRevListStr) != 0)
            // {
            //     printf("\n Compare  configuredRev1==%s,itemRevListStr==%s \n", configuredRev1, itemRevListStr);
            //     continue;
            // }
            if (parentPart.find(itemRevListStr) == parentPart.end())
            {
                printf("In set parentPart condition /n");
                continue;
            }

            AOM_ask_value_string(parent_bvr, "object_string", &parentBVR);
            printf("\nparentBVR==%s \n", parentBVR);

            //			AOM_ask_value_string(itemRevList[0], "object_string", &itemRevListStr);
            //			printf("\n itemRevListStr==%s \n", itemRevListStr);

            AOM_ask_value_double(occurences[i], "qty_value", &qtyval);
            printf("qtyval= %lf \n", qtyval);

            AOM_ask_value_string(itemRevList[0], "item_id", &itemId);
            printf("\n itemId==%s \n", itemId);

            AOM_UIF_ask_value(itemRevList[0], "t5_PartType", &partType);
            printf("\n partType==%s \n", partType);
            printf("\n itemId==%s \n", itemId);

            AOM_UIF_ask_value(itemRevList[0], "release_status_list", &relStatusLists);
            STRNG_replace_str(relStatusLists, ",", ";", &relStatusList);
            printf("\n relStatusList==%s \n", relStatusList);

            AOM_ask_value_string(occurences[i], "t5_CurrentViewMaskM", &currentViewMaskMBOM);
            printf("\n currentViewMaskMBOM==%s \n", currentViewMaskMBOM);

            // AOM_UIF_ask_value(itemRevList[0], "bl_is_occ_suppressed", &suppressed);
            // printf("\n suppressed==%s \n", suppressed);

            if (tc_strcmp(skipZero, "+") == 0)
            {
                if (qtyval == 0)
                    continue;
            }

            if (tc_strcmp(remUndPrt, "+") == 0)
            {
                if (tc_strstr(itemId, "_") != NULL)
                    continue;
            }
            cout << "before CV mask" << std::endl;
            if (cvmask == NULL)
            {
                std::cout << "cvmask is NULL\n";
            }
            else
            {
                std::cout << "cvmask = [" << cvmask << "]\n";
            }
            if (tc_strcmp("", cvmask) != 0)
            {
                std::cout << "cvmask is NULL\n";
            }
            else
            {
                std::cout << "cvmask = [" << cvmask << "]\n";
            }

            if (cvmask != NULL && tc_strcmp("", cvmask) != 0)
            {
                maskSet.clear();
                cout << "before cvmask condition!! " << cvmask << std::endl;
                AOM_ask_value_string(occurences[i], cvmask, &currentViewMask);
                // AOM_ask_value_string(occurences[i], "t5_CurrentViewMaskM", &currentViewMask);
                cout << "currentViewMask After AOM" << currentViewMask << std::endl;
                std::string curMask(currentViewMask);
                CALLAPI(AOM_ask_value_string(cores[0], "t5_Userinfo4", &reqCureViewMask));

                if (reqCureViewMask != nullptr && *reqCureViewMask != '\0')
                {
                    cout << "Under reqCureViewMask condition!!" << std::endl;

                    std::string maskStr(reqCureViewMask);
                    std::stringstream ss(maskStr);
                    std::string token;

                    while (std::getline(ss, token, ','))
                    {
                        if (!token.empty())
                        {
                            maskSet.insert(token);
                        }
                    }
                }
                for (const auto &val : maskSet)
                {
                    std::cout << "Value of mask set map: " << "[" << val << "]" << std::endl;
                }
                std::cout << "value of curMask: " << curMask << std::endl;

                if (maskSet.find(curMask) != maskSet.end())
                {
                    {
                        cout << "Under maskSet condition!!" << std::endl;

                        printf("\n Skipping part because of Current View mask\n");
                        continue;
                    }
                }
            }
            else
            {
                currentViewMask = (char *)MEM_alloc(10 * sizeof(char *));
                tc_strcpy(currentViewMask, "");
            }

            if (reqMakeBuy != NULL && tc_strcmp("", reqMakeBuy) != 0)
            {
                AOM_ask_value_string(itemRevList[0], reqMakeBuy, &plantCS);
            }
            else
            {
                plantCS = (char *)MEM_alloc(10 * sizeof(char *));
                tc_strcpy(plantCS, "");
            }

            printf("currentViewMask=%s \n", currentViewMask);
            printf("plantCS=%s \n", plantCS);

            AOM_ask_value_date(itemRevList[0], "creation_date", &creationDate);
            // printf("currentViewMask=%s \n", currentViewMask);

            if (itemRevCnt > 0)
            {
                PartQtyList pql;
                pql.partobj = itemRevList[0];
                if (levelCnt > 1) // pobjpart.partobj!=NULLTAG)
                {
                    pql.consolidateqty = pconqty * qtyval;
                    printf("\n ************iNOTTTT*************************nullptr:\n");
                    printf("\n consolidateqty = %.2f\n", pql.consolidateqty);
                }
                else
                {
                    pql.consolidateqty = qtyval;
                    printf("\n *************************************nullptr:");
                    printf("\n consolidateqty = %.2f\n", pql.consolidateqty);
                }
                pql.actualqty = qtyval; // talking about parent occurence
                pql.currentViewMaskMBOM = currentViewMaskMBOM;
                pql.currentViewMask = currentViewMask;
                pql.createDate = creationDate;
                pql.partType = partType;
                pql.plantCS = plantCS;
                pql.relStatusList = relStatusList;

                // ITEM_ask_item_of_rev(itemRevList[0], &parentItem);
                char *revID;
                AOM_ask_value_string(itemRevList[0], "item_id", &parentItemID);
                AOM_ask_value_string(itemRevList[0], "current_revision_id", &revID);
                std::string parentStr = std::string(parentItemID);

                std::map<std::string, std::vector<PartQtyList>>::iterator search = partlistmap.find(parentStr);

                if (search != partlistmap.end())
                {
                    printf("\n Inside parentItemID - %s / %s found\n", parentItemID, revID);
                    // partlistmap.erase(parentStr);
                    std::vector<PartQtyList> partset = search->second;
                    // partset.clear();
                    // search->second.push_back(pql);// commented 10-05-2025 It-1
                    char *objdispstr = NULL;
                    PartQtyList tmpprtqty = partset[0];
                    AOM_ask_value_string(tmpprtqty.partobj, "object_string", &objdispstr);
                    cout << "\n 11==> " << objdispstr << ":" << tmpprtqty.consolidateqty << " ::Before ::" << pql.consolidateqty << endl; // added 10-05-2025 It-1
                    tmpprtqty.consolidateqty = tmpprtqty.consolidateqty + pql.consolidateqty;                                             // added 10-05-2025 It-1
                    tmpprtqty.actualqty = tmpprtqty.actualqty + pql.actualqty;                                                            // added 10-05-2025 It-1
                    printf("\n qqttyy=%lf", tmpprtqty.consolidateqty);
                    cout << "\n 123==>" << objdispstr << ":" << tmpprtqty.consolidateqty << " ::After ::" << pql.consolidateqty << endl; // added 10-05-2025 It-1
                                                                                                                                         // partset.clear();

                    search->second[0].consolidateqty = tmpprtqty.consolidateqty;
                    search->second[0].actualqty = tmpprtqty.actualqty;
                }
                else
                {
                    printf("\n Inside not parentItemID - %s / %s found\n", parentItemID, revID);
                    // printf("\n parentStr - %s\n", parentStr);
                    std::vector<PartQtyList> partset;
                    partset.push_back(pql);
                    partlistmap.insert(std::pair<std::string, std::vector<PartQtyList>>(parentStr, partset));
                }
            }

            // tag_t *partobjset = NULLTAG;
        }

        std::map<std::string, std::vector<PartQtyList>>::iterator itr = partlistmap.begin();

        while (itr != partlistmap.end())
        {
            cout << "itr:- " << itr->first << "\n";
            std::vector<PartQtyList> partTagSet = itr->second;

            sort(partTagSet.begin(), partTagSet.end(), sortVector);

            int cnt = 0;

            cout << "partTagSet.size():- " << partTagSet.size() << endl;

            int chkMatch = 0;
            int partTagSize = partTagSet.size();
            // for (int iv = 0; iv < partTagSet.size(); iv++)

            for (int iv = partTagSize - 1; iv >= 0; iv--)
            {
                printf("\n iv - %d\n", iv);
                chkMatch = 0;
                char *parentObjStr;
                char *parentItemObj;

                AOM_ask_value_string(partTagSet[iv].partobj, "object_string", &parentObjStr);

                char *itemRevStr;

                char *child_part_name;
                char *child_part_rs;
                char *child_part_desc;
                char *child_partType;
                char *child_object_name;
                char *childpartType;

                AOM_ask_value_string(itemRev, "object_string", &itemRevStr);

                printf("\n parentObjStr - %s\n", parentObjStr); // parent part
                printf("\n itemRevStr - %s\n", itemRevStr);     // intially base child part
                AOM_UIF_ask_value(itemRevStr, "t5_PartType", &childpartType);

                AOM_ask_value_string(itemRev, "item_id", &child_part_name);
                AOM_ask_value_string(itemRev, "object_string", &child_object_name);
                std::string input1(child_part_name);
                std::string c_module = input1.substr(4, 4);
                char module[16]; // enough space
                bool allDigits = true;
                for (char ch : c_module)
                {
                    if (!std::isdigit(static_cast<unsigned char>(ch)))
                    {
                        allDigits = false;
                        break;
                    }
                }
                if (allDigits)
                {
                    std::strncpy(module, input1.c_str(), sizeof(module));
                }
                else
                {
                    std::strncpy(module, c_module.c_str(), sizeof(module));
                }

                module[sizeof(module) - 1] = '\0';
                std::cout << "module: " << module << std::endl;

                AOM_ask_value_string(itemRev, "item_revision_id", &child_part_rs);
                AOM_ask_value_string(itemRev, "object_desc", &child_part_desc);
                AOM_ask_value_string(itemRev, "t5_PartType", &child_partType);

                printf("\n child_part_name - %s\n", child_part_name);
                printf("\n child_part_rs - %s\n", child_part_rs);
                printf("\n child_part_desc - %s\n", child_part_desc);
                printf("\n child_partType - %s\n", child_partType);

                tag_t pItem = NULLTAG;

                ITEM_ask_item_of_rev(partTagSet[iv].partobj, &pItem);
                // AOM_ask_value_string(pItem, "item_id", &parentItemObj);

                tag_t configured_revs = NULLTAG;
                char *how_configured = NULL;
                char *configuredRev;
                char *compCode;

                char *parent_part_name;
                char *parent_object_name;
                char *parent_part_rs;
                char *parent_part_desc;
                char *parent_partType;

                CFM_item_ask_configured(revRule, pItem, &configured_revs, &how_configured);
                AOM_ask_value_string(configured_revs, "object_string", &configuredRev);
                AOM_UIF_ask_value(configured_revs, "t5_PrtCatCode", &compCode);

                if (configured_revs == NULL)
                    continue;

                printf("\n configuredRev - %s\n", configuredRev);

                AOM_ask_value_string(configured_revs, "item_id", &parent_part_name);
                AOM_ask_value_string(configured_revs, "object_string", &parent_object_name);
                std::string input2(removeChar_BOMImplosion(parent_object_name));
                // printf("Shiv check5 %s \n" shiv );
                printf("parent_part_name: %s \n", parent_part_name);
                printf("parent_object_name: %s \n", parent_object_name);
                std::string c_vechicle = input2;
                // char *vechicle = new char[c_vechicle.length() + 1];
                // std::strcpy(vechicle, c_vechicle.c_str());
                // tc_strcat(vechicle, "_");
                // tc_strcat(vechicle, module);

                std::string vechicle = std::string(parent_object_name) + "_" + module;

                AOM_ask_value_string(configured_revs, "item_revision_id", &parent_part_rs);
                AOM_ask_value_string(configured_revs, "object_desc", &parent_part_desc);
                AOM_ask_value_string(configured_revs, "t5_PartType", &parent_partType);

                printf("\n parent_part_name - %s\n", parent_part_name);
                printf("\n parent_part_rs - %s\n", parent_part_rs);
                printf("\n parent_part_desc - %s\n", parent_part_desc);
                printf("\n parent_partType - %s\n", parent_partType);

                std::string cStr = std::string(child_partType);
                std::string pStr = std::string(parent_partType);

                if (pStr == "V")
                {
                    printf("under V T");
                    printf("parent_object_name: %s", parent_object_name);
                    printf("child_object_name: %s", child_object_name);

                    vehicleSet.insert(parent_object_name);
                }

                //if (((pStr == "VC" || pStr == "VCCR" || pStr == "Vehicle Combination CR") && cStr == "V") )//06-02-26
                if (((pStr == "VC"|| pStr == "Vehicle Combination CR" || pStr == "VCCR") && cStr == "V") || (pStr == "VCCR" && cStr == "M" ))
                {
                    printf("Change implemented \n");
                    printf("under vcVehicle map \n");

                    // modQtySet.insert(module);

                    vcVehicle.insert(std::pair<std::string, std::string>(parent_object_name, child_object_name));
                    for (const auto &pair : vcVehicle)
                    {
                        std::cout << "VC=> Vehicle ::" << pair.first << " => " << pair.second << '\n';
                    }
                }

              // if (((pStr == "V" || pStr == "VCCR" || pStr == "Vehicle Combination CR") && cStr == "M")|| (( pStr == "VCCR" || pStr == "Vehicle Combination CR") && cStr == "A") || ((pStr == "Technical Part List" || pStr == "T") && (cStr == "C" || cStr == "Component"))|| ((pStr == "Technical Part List" || pStr == "T") && cStr == "A") || ((pStr == "Technical Part List" || pStr == "T") && cStr == "M")|| ((pStr == "V") && (cStr == "Technical Part List" || cStr == "T")))//06-02-26
               if (((pStr == "V"|| pStr == "VCCR"   || pStr == "Vehicle Combination CR") && cStr == "M")|| ((pStr == "Vehicle Combination CR" || pStr == "VCCR") && cStr == "A") ||((pStr == "V") && (cStr == "Technical Part List" || cStr == "T")))

                {
                    printf("Shivanshu test 1 \n");
                    vcModMAP.insert(std::pair<std::string, float>(vechicle, partTagSet[iv].consolidateqty));
                    std::cout << "Shivanshu test point 2 :\n";
                    for (const auto &pair : vcModMAP)
                    {
                        std::cout << "Shivanshu test point 33 :\n";
                        std::cout << pair.first << " => " << pair.second << '\n';
                    }
                    std::cout << "Shivanshu test point 3 :\n";
                    modQtySet.insert(module);
                    for (const auto &s : modQtySet)
                    {
                        std::cout << s << std::endl;
                    }
                }

                int configRevFlag = 0;
                if (strcmp(parentObjStr, configuredRev) == 0)
                {
                    printf("\n Match Found \n");
                    printf(" parentObjStr %s \n", parentObjStr);
                    printf(" configuredRev %s \n", configuredRev);
                    printf("\n Match Found end \n");
                    configRevFlag++;
                }

                if (configRevFlag > 0)
                {
                    printf("\nInside PSOccurencesRevList > 0\n");
                    fprintf(fp, "%d,%s,%s,%s,%s,%s,%s,%s,%s,%lf,%lf,%s,%s,%s,%s,%s,%s\n", levelCnt, removeChar_BOMImplosion(itemRevStr), child_part_name, child_part_rs, removeChar_BOMImplosion(child_part_desc), removeChar_BOMImplosion(configuredRev), parent_part_name, parent_part_rs, removeChar_BOMImplosion(parent_part_desc), partTagSet[iv].consolidateqty, partTagSet[iv].actualqty, partTagSet[iv].currentViewMaskMBOM, partTagSet[iv].currentViewMask, partTagSet[iv].partType, compCode, partTagSet[iv].plantCS, partTagSet[iv].relStatusList);
                    printf("\n CPart=%s,Parent1=%s, Consolidated QTY=%lf, CurrentViewMask=%s \n", removeChar_BOMImplosion(itemRevStr), removeChar_BOMImplosion(configuredRev), partTagSet[iv].consolidateqty, partTagSet[iv].currentViewMask);
                    getParents(partTagSet[iv].consolidateqty, origPart, partTagSet[iv].partobj, revRule, revName, remUndPrt, skipZero, levelCnt + 1, maxLimit, topLevelParts, vcModMAP, modQtySet, vcVehicle, vehicleSet, rule, parentPart, fp);
                    // std::string parentStr = std::string(parentItemID);
                    // parentItemMap.insert

                    break;
                }

                else
                {
                    printf("\nInside PSOccurencesRevList == 0 (else)\n");

                    char *relStatus = NULL;
                    char *itemToCheck = NULL;

                    if (cocnt > 0)
                    {
                        CALLAPI(AOM_ask_value_string(cores[0], "t5_Userinfo2", &relStatus));

                        AOM_ask_value_string(configured_revs, "item_id", &itemToCheck);
                        printf("\n itemToCheck - %s\n", itemToCheck);
                        char *qryIRValues[2] = {itemToCheck, relStatus};

                        CALLAPI(QRY_execute_with_sort(qryIRTag, 2, qryIREntries, qryIRValues, 1, qryIRSort, qryIRSortOrder, &ircnt, &irres));

                        printf("\nircnt = %d\n", ircnt);
                        if (ircnt > 0)
                        {

                            for (int IR = 0; IR < ircnt; IR++)
                            {
                                char *itemIDOcc;
                                AOM_ask_value_string(irres[IR], "object_string", &itemIDOcc);
                                AOM_UIF_ask_value(irres[IR], "t5_PrtCatCode", &compCode);
                                printf("\n itemIDOcc = %s\n", itemIDOcc);

                                if (strcmp(parentObjStr, itemIDOcc) == 0)
                                {
                                    printf("\nInside Item Revision ... > 0\n");
                                    fprintf(fp, "%d,%s,%s,%s,%s,%s,%s,%s,%s,%lf,%s,%s,%s,%s,%s\n", levelCnt, removeChar_BOMImplosion(itemRevStr), child_part_name, child_part_rs, child_part_desc, removeChar_BOMImplosion(parentObjStr), parent_part_name, parent_part_rs, parent_part_desc, partTagSet[iv].consolidateqty, partTagSet[iv].currentViewMaskMBOM, partTagSet[iv].currentViewMask, partTagSet[iv].partType, compCode, partTagSet[iv].plantCS, partTagSet[iv].relStatusList);
                                    printf("CPart=%s,Parent2=%s, Consolidated Qty=%lf, CurrentViewMask=%s \n", removeChar_BOMImplosion(itemRevStr), removeChar_BOMImplosion(parentObjStr), partTagSet[iv].consolidateqty, partTagSet[iv].currentViewMask);
                                    getParents(partTagSet[iv].consolidateqty, origPart, partTagSet[iv].partobj, revRule, revName, remUndPrt, skipZero, levelCnt + 1, maxLimit, topLevelParts, vcModMAP, modQtySet, vcVehicle, vehicleSet, rule, parentPart, fp);
                                    chkMatch++;
                                    break;
                                }
                            }

                            if (chkMatch > 0)
                            {
                                printf("\n chkMatch = %d\n", chkMatch);
                                break;
                            }
                        }
                        else
                        {
                            printf("\nRevision Rule Status is not Configured\n");
                        }
                    }
                }

                // fprintf(fp, "%s,%s,%lf,%s\n", itemRevStr, parentObjStr, partTagSet[iv].consolidateqty,partTagSet[iv].currentViewMask);
                // printf("\n CPart=%s,Parent=%s,QTY=%lf CURRENTVIEWMASK=%s\n", itemRevStr, parentObjStr, partTagSet[iv].consolidateqty,partTagSet[iv].currentViewMask);
            }

            itr++;
        }
    }

    else
    {

        printf("\n else occs==%d", occCnt);
    }

    return ifail;
}

int ITK_user_main(int argc, char *argv[])
{
    // ./tm_BOMImplosion -id="5550D9Y0160015FD" -rev="NR;1" -rule="APLP Release and Above"
    // ./tm_BOMImplosion -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -id="5709H1A0201001^J^3" -rule="ERC1 Release and Above" -remUndPrt="+" -skipZero="+" -mail="po924057.ttl@tatamotors.com"
    int ifail = ITK_ok;
    tag_t rule = NULLTAG;
    tag_t item = NULLTAG;
    tag_t ititem = NULLTAG;
    tag_t itemRev = NULLTAG;
    tag_t ititemRev = NULLTAG;
    char *origPart1 = NULL;
    char *origPart = NULL;
    //std::string Plant;
    std::string AMDEN_Plant;
    char fourthCharRev;

    char *id = ITK_ask_cli_argument("-id=");
    char *revRule = ITK_ask_cli_argument("-rule="); // first character (erc plant = ) (APLP plant= Pune) (APLU plant = UTK, MBOM)
    // char *showSupp = ITK_ask_cli_argument("-showSupp=");
    char *remUndPrt = ITK_ask_cli_argument("-remUndPrt=");
    char *skipZero = ITK_ask_cli_argument("-skipZero=");
    char *mail = ITK_ask_cli_argument("-mail=");
    char *Plant = ITK_ask_cli_argument("-pl=");
    char *TplmoduleBreakdown = ITK_ask_cli_argument("-brk=");
    cout << "revRule: " << revRule << std::endl;
 
    printf("Plant : %s\n", Plant);
    printf("remUndPrt : %s\n", remUndPrt);

    if (revRule != nullptr && *revRule != '\0')
    {
        std::string revRuleCopy(revRule);
        //  char *tok_revrule = strtok(revRule, " ");
        char *tok_revrule = std::strtok(revRuleCopy.data(), " ");
        if (tok_revrule != nullptr)
        {

            cout << "Rev Rule first word: 12 " << std::endl;

            if (strlen(tok_revrule) >= 4)
            {
                cout << "Rev Rule first word: " << tok_revrule << std::endl;
                fourthCharRev = tok_revrule[3];

                std::cout << "Fourth character of Rev Rule: " << fourthCharRev << std::endl;

                switch (fourthCharRev)
                {
                case 'P':
                    Plant		= "Pune";
                    AMDEN_Plant	= "AMDEN_PUNE";
                    break;
				case 'J':
                   Plant		= "JSR";
                   AMDEN_Plant	= "AMDEN_JSR";
                   break;
                case 'U':
                    Plant		= "UTK";
                    AMDEN_Plant	= "AMDEN_PNR";
                    break;
                case 'D':
                    Plant		= "Dharwad";
                     AMDEN_Plant	= "AMDEN_DWD";
                    break;
                case 'L':
                    Plant = "Lucknow";
                     AMDEN_Plant	= "AMDEN_LKN";
                    break;
                case 'M':
                    Plant = "MBOM";
					break;
                default:
                    Plant		= "ERC";
					AMDEN_Plant	= "";
					break;
                }
            }
            else
            {
                Plant = "ERC";
            }
        }
    }
    cout << "Plant: " << Plant << std::endl;

    ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);

    CALLAPI(ITK_auto_login());
    ITK_set_bypass(true);
    CALLAPI(ITK_set_journalling(TRUE));

    CFM_find(revRule, &rule);
    ifail = ITEM_find_item(id, &item);
    tag_t configured_rev = NULLTAG;

    int pltCnt;
    tag_t *pltRes;
    char *plantName;
    tag_t qryPltTag;
    char *qryPltEntries[4] = {"SYSCD", "SUBSYSCD", "Information-1", "Delete Indicator"};
    char *qryPltValues[4] = {"BOMImplosion", "RevisionRule", revRule, "0"};
    CALLAPI(QRY_find2("Control Objects...", &qryPltTag));
    CALLAPI(QRY_execute(qryPltTag, 4, qryPltEntries, qryPltValues, &pltCnt, &pltRes));

    if (pltCnt > 0)
    {
        AOM_ask_value_string(pltRes[0], "t5_Userinfo5", &plantName);
    }
	///////////// Ketan ///////////////
	
	int pltCnt1;
    tag_t *pltRes1;
    tag_t qryPltTag1;
	
	std::string Amden_PartList="";
	
    char *qryPltEntries1[2] = {"Name", "Type", };
    char *qryPltValues1[2] = {AMDEN_Plant.c_str(), "Amden Table"};

    CALLAPI(QRY_find2("General...", &qryPltTag1));
    CALLAPI(QRY_execute(qryPltTag1, 2, qryPltEntries1, qryPltValues1, &pltCnt1, &pltRes1));
	printf("\n pltCnt1 => %d \n", pltCnt1);fflush(stdout);

    if (pltCnt1 > 0)
    {
		tag_t	Amdentable			= NULLTAG;
		tag_t*	AmdenTableRowset    = NULLTAG;
		
		int         TblRowCnt               = 0;

		Amdentable = pltRes1[0];
		CALLAPI(AOM_ask_table_rows(Amdentable,"t5_AmdTablerow",&TblRowCnt,&AmdenTableRowset));
		
		if(TblRowCnt>0)
		{
			for (int i1 = 0; i1 < TblRowCnt; i1++)
			{
				 char*	AmdInputPart      =       NULL;
				 CALLAPI(AOM_ask_value_string(AmdenTableRowset[i1], "t5_AmdPartNumber", &AmdInputPart));
				 Amden_PartList += std::string(AmdInputPart);
			}
		} 
    }

	///////////// Ended ///////////////

    tag_t qryLimTag;
    CALLAPI(QRY_find2("Control Objects...", &qryLimTag));
    int maxLimit = 0;
    int limcnt;
    tag_t *limRes;
    char *qryLimEntries[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qryLimValues[3] = {"BOMImplosion", "ImplosionLimit", "0"};
    CALLAPI(QRY_execute(qryLimTag, 3, qryLimEntries, qryLimValues, &limcnt, &limRes));

    if (limcnt > 0)
    {
        AOM_ask_value_int(limRes[0], "t5_Userinfo2", &maxLimit);
    }

    printf("\nmaxlimit = %d\n");

    if (maxLimit == 0)
        maxLimit = 10;

    set<string> partList;
    map<std::string, std::string> topLevelParts;
    map<std::string, std::string> vcVehicle;
    map<std::string, float> vcModMAP;
    std::set<std::string> parentPart;
    // map<std::string, std::string> modQtyMAP;
    std::set<std::string> modQtySet;
    std::set<std::string> vehicleSet;

    char *idList = tc_strtok(id, ",");

    while (idList != NULL)
    {
        partList.insert(idList);
        idList = tc_strtok(NULL, ",");
    }

    char ReportFiredDate[200] = "";
    time_t now;
    struct tm when;
    time(&now);
    when = *localtime(&now);
    strftime(ReportFiredDate, 100, "%d_%b_%Y_%H_%M_%S", &when);

    set<string>::iterator itr;
    for (itr = partList.begin(); itr != partList.end(); itr++)
    {
        char *partNumber = itr->c_str();
        printf("\nID in progress = %s\n", partNumber);
        fflush(stdout);

        char *partnumber_tok = tc_strtok(partNumber, "^");
        char *rev_tok = tc_strtok(NULL, "^");
        char *seq_tok = tc_strtok(NULL, "^");

        char *itemRevSeq = (char *)MEM_alloc(5 * sizeof(char));
        tc_strcpy(itemRevSeq, rev_tok);
        tc_strcat(itemRevSeq, ";");
        tc_strcat(itemRevSeq, seq_tok);

        CALLAPI(ITEM_find_item(partNumber, &item));

        if (rev_tok != NULL)
        {
            ITEM_find_revision(item, itemRevSeq, &itemRev);
        }
        else
        {
            CALLAPI(ITEM_ask_latest_rev(item, &itemRev));
        }

        char *FileName = NULL;
        FileName = (char *)MEM_alloc(100 * sizeof(char *));
        // sprintf(FileName, "/tmp/BOMImplosion_Report_%s_%s.csv",partnumber_tok, ReportFiredDate);
        sprintf(FileName, "/tmp/BOMImplosion_Report_%s_%s.csv", partnumber_tok, ReportFiredDate);
        printf("\n FileName is===>[%s]", FileName);
        fflush(stdout);

        char *FileNameTop = NULL;
        FileNameTop = (char *)MEM_alloc(100 * sizeof(char *));
        sprintf(FileNameTop, "/tmp/BOMImplosion_Report_TopLine_%s_%s.csv", partnumber_tok, ReportFiredDate);
        printf("\n FileNameTop is===>[%s]", FileNameTop);
        fflush(stdout);

        CALLAPI(AOM_ask_value_string(itemRev, "object_string", &origPart1));
        STRNG_replace_str(origPart1, ",", ";", &origPart);

        FILE *fp = NULL;
        FILE *fpTop = NULL;

        fp = fopen(FileName, "w");
        fpTop = fopen(FileNameTop, "w");
        PartQtyList prpart;
        int count = 0;

        fprintf(fp, "Part Number,%s\n", partNumber);
        fprintf(fp, "Revision Rule,%s\n", revRule);
        fprintf(fp, "Skip Zero Quantity,%s\n", skipZero);
        fprintf(fp, "Remove Underscore Parts,%s\n", remUndPrt);
        fprintf(fp, "Report Fire Date,%s\n\n", ReportFiredDate);

        fprintf(fpTop, "Part Number,%s\n", partNumber);
        fprintf(fpTop, "Revision Rule,%s\n", revRule);
        fprintf(fpTop, "Skip Zero Quantity,%s\n", skipZero);
        fprintf(fpTop, "Remove Underscore Parts,%s\n", remUndPrt);
        fprintf(fpTop, "Report Fire Date,%s\n\n", ReportFiredDate);

        fprintf(fp, "Level,Child Part,Child Part Number,Child Part RevSeq,Child Part Desc, Parent Part, Parent Part Number, Parent Part RevSeq, Parent Part Desc, Consolidate qty ,Actual Qty, Current View Mask (MBOM),Current View Mask %s,Part Type,Comp Code,%s Make Buy Indicator,Release Status\n", plantName, plantName);
        // fprintf(fpTop, "Part Number,Top Level Part, Top Level Part Rev, Top Level Part Desc,  Part Type,Release Status, Actual Qty, Consolidate qty,");
        //fprintf(fpTop, "Part Number,VC Number,VC Revision,VC Description,Part Type,Release Status,Plant Applicability,");//06-02-26
        fprintf(fpTop, "Part Number,VC Number,VC Revision,VC Description,Part Type,Release Status,");

        int levelCnt = 0;
        getParents(1, origPart, itemRev, rule, revRule, remUndPrt, skipZero, levelCnt + 1, maxLimit, topLevelParts, vcModMAP, modQtySet, vcVehicle, vehicleSet, rule, parentPart, fp);

        // for (const auto &kv3 : modQtySet) // change 021225
        // {
        //     fprintf(fpTop, "%s,", kv3.c_str());
        // }
        fprintf(fpTop, "%s,%s", "Total Cons Qty", "Plant Applicability");
        fprintf(fpTop, "\n");

        std::map<std::string, std::string>::iterator itr = topLevelParts.begin();

        while (itr != topLevelParts.end())
        {
            printf("Inside File write for Top Level \n");
            char *itrname = itr->first.c_str();
            char *itrname1 = itr->first.c_str();
            std::string itrname2 = itr->first;
            printf("itrname2:  %s \n", itrname2.c_str());

            size_t firstSlash = itr->first.find('/');
            size_t secondSlash = std::string::npos;

            if (firstSlash != std::string::npos)
            {
                secondSlash = itrname2.find('/', firstSlash + 1);
            }

            std::string topLevelPart, topLevelPartRev, topLevelPartDesc;

            if (firstSlash != std::string::npos)
            {
                topLevelPart = itrname2.substr(0, firstSlash);

                if (secondSlash != std::string::npos)
                {
                    // Case: two slashes present
                    topLevelPartRev = itrname2.substr(firstSlash + 1, secondSlash - firstSlash - 1);
                    topLevelPartDesc = itrname2.substr(secondSlash + 1);
                }
                else
                {
                    // Case: only one slash present
                    topLevelPartRev = itrname2.substr(firstSlash + 1);
                    topLevelPartDesc = ""; // no third part
                }
            }
            else
            {
                // No slash present
                topLevelPart = itrname2;
                topLevelPartRev = "";
                topLevelPartDesc = "";
            }

            std::cout << "topLevelPart: " << topLevelPart << std::endl;
            std::cout << "topLevelPartRev: " << topLevelPartRev << std::endl;
            std::cout << "topLevelPartDesc: " << topLevelPartDesc << std::endl;
            // if(topLevelPart == "51620768000R"){
            //     continue;
            // }

            tag_t ititem = NULLTAG;
            tag_t ititemRev = NULLTAG;
            int n_items = 0;
            tag_t *item_tags = NULL;
            char *ititemPartTypechar = NULL;

            // const char *attr_names[2]  = {"item_id", "object_type"};
            // const char *attr_values[2] = {topLevelPart.c_str(), "Item"};

            const char *attr_names[1] = {"item_id"};
            const char *attr_values[1] = {topLevelPart.c_str()};

            printf("testing point 1\n");
            // CALLAPI(ITEM_find_item(topLevelPart.c_str(), &ititem));
            CALLAPI(ITEM_find_items_by_key_attributes(1, attr_names, attr_values, &n_items, &item_tags));
            printf("Attribute value %s \n", topLevelPart.c_str());
            if (n_items == 0)
            {
                printf("No item found for ID: %s\n", topLevelPart.c_str());
            }
            else if (n_items > 1)
            {
                printf("Testing n_items ");
                printf("Multiple items found for ID: %s, picking the first.\n", topLevelPart.c_str());
            }

            if (n_items > 0)
            {
                ititem = item_tags[0];
                MEM_free(item_tags);
                printf("testing point 2");
                ITKCALL(ITEM_find_revision(ititem, topLevelPartRev.c_str(), &ititemRev));

                ITKCALL(AOM_ask_value_string(ititemRev, "t5_PartType", &ititemPartTypechar));

                std::string ititemPartType(ititemPartTypechar);
                printf("\n ititemPartTypechar2: %s \n", ititemPartType.c_str());
                printf("\n ititemPartTypechar3: %s \n", ititemPartTypechar);
            }

            // fprintf(fpTop, "%s,%s,%s,", origPart, itr->first.c_str(), itr->second.c_str());
            cout << "1ssssss" << endl;
           // if (std::string(ititemPartTypechar) == "VC" || std::string(ititemPartTypechar) == "Vehicle Combination CR" || std::string(ititemPartTypechar) == "VCCR" || std::string(ititemPartTypechar) == "Technical Part List" || std::string(ititemPartTypechar) == "T" || std::string(ititemPartTypechar) == "V" || std::string(ititemPartTypechar) == "A") //06-02-26
           if (std::string(ititemPartTypechar) == "VC" || std::string(ititemPartTypechar) == "Vehicle Combination CR"|| std::string(ititemPartTypechar) == "VCCR" )

            {
                printf("Under ititemPartTypechar condition ");
                cout << "2ssssss" << endl;

				char plantapplicability[20]; // Ketan

				cout << "Amden_PartList: " << Amden_PartList<< endl;

				if(tc_strstr(Amden_PartList.c_str(),topLevelPart.c_str()) != NULL)
				{
					 tc_strcpy(plantapplicability,AMDEN_Plant.c_str());
				}
				else
				{
					tc_strcpy(plantapplicability,"NO");
				}
				
				cout << "plantapplicability: " << "topLevelPart: "<< topLevelPart << plantapplicability<< endl;
				
                fprintf(fpTop, "%s,%s,%s,%s,%s,%s,", origPart, topLevelPart.c_str(), topLevelPartRev.c_str(), topLevelPartDesc.c_str(), itr->second.c_str(),plantapplicability);
                printf(" checking iteration %s => %s => %s  \n", origPart, itr->first.c_str(), itr->second.c_str()); // print child and then parent
                int compareLength = 8;
                int compareLength2 = 4;
                std::string input3(itr->first);
                std::string topVC = input3;
                auto tt = vcVehicle.find(itr->first);
                if (tt != vcVehicle.end())
                {
                    printf("Under vcVehicle \n");
                    double totalSum = 0.0;

                    std::set<std::string> newVehModSet;

                    if (modQtySet.empty())
                    {
                        printf("modQtySet is EMPTY. Setting totalSum = 1\n");
                        totalSum = 1.0;
                    }

                    else
                    {
                        for (const auto &item : modQtySet)
                        {
                            std::string combined = tt->second + "_" + item;
                            newVehModSet.insert(tt->second + "_" + item);
                        }

                        printf("After insertion, newVehModSet contents:\n");
                        for (const auto &val : newVehModSet)
                        {
                            printf("%s\n", val.c_str());
                        }

                        for (const auto &item : newVehModSet)
                        {
                            std::cout << "new item: " << item << std::endl;
                        }
                        std::cout << "vcModMAP size = " << vcModMAP.size() << std::endl;

                        for (const auto &item : newVehModSet)
                        {
                            std::cout << "vcModMAP size = " << vcModMAP.size() << std::endl;
                            auto it = vcModMAP.find(item);
                            if (it != vcModMAP.end())
                            {
                                printf("UNDER vcModMAP.end");
                                printf("it->second: %f,", it->second);

                                //fprintf(fpTop, "%f,", it->second); // change 021225
                                totalSum += it->second;
                            }
                            else
                            {
                                // printf("Match not found %s \n", kv2);
                                //fprintf(fpTop, ","); // change 021225
                                printf("UNDER ELSE OF vcModMAP.end \n");
                            }
                        }
                    }
                   // fprintf(fpTop, "%f,", totalSum);//06-02-26
                   // fprintf(fpTop, "%d,", (int)totalSum);//06-02-26
                    printf("totalSum: %f", totalSum);
                    printf("next line \n");
                }

                auto tv = vehicleSet.find(itr->first);
                if (tv != vehicleSet.end())
                {

                    printf("Under vehicleSet ");
                    std::cout << "Found vehicle: " << *tv << "\n";
                    double totalSum = 0.0;

                    std::set<std::string> newVehModSet;

                    if (newVehModSet.empty())
                    {
                        printf("modQtySet is EMPTY. Setting totalSum = 1\n");
                        totalSum = 1.0;
                    }
                    else
                    {
                        for (const auto &item : modQtySet)
                        {
                            newVehModSet.insert(*tv + "_" + item);
                        }

                        for (const auto &item : newVehModSet)
                        {
                            std::cout << "new item: " << item << std::endl;
                        }

                        for (const auto &item : newVehModSet)
                        {

                            for (const auto &pair2 : vcModMAP)
                            {
                                std::cout << "Shivanshu test point under vcmodmap :\n";
                                std::cout << pair2.first << " => " << pair2.second << '\n';
                            }
                            // int sum= 0;
                            auto it = vcModMAP.find(item);
                            if (it != vcModMAP.end())
                            {
                                // printf("Matched Under Module %s \n", kv2.c_str());
                              //  fprintf(fpTop, "%f,", it->second); // change 021225
                                printf("UNDER vcModMAP %f \n", it->second);
                                totalSum += it->second;
                                // sum= sum+ it->second;
                            }
                            else
                            {
                                // printf("Match not found %s \n", kv2);
                               // fprintf(fpTop, ","); // change 021225
                                printf("UNDER else of vcModMAP \n ");
                            }
                        }
                    }
                    //fprintf(fpTop, "%f,", totalSum);//06-02-26
                   // fprintf(fpTop, "%d,", (int)totalSum);//06-02-26
                    printf("next line \n");
                }
                fprintf(fpTop, "\n");
            }
            itr++;
        }
        printf("Count: %d ", count);

        fclose(fp);
        fclose(fpTop);

        // Control Object for EXE
        char *qry_entries[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
        char *qry_values[3] = {"BOMImplosion", "REPORTPATH", "0"};

        tag_t qryTag = NULLTAG;
        int query_count;
        tag_t *query_result = NULLTAG;

        CALLAPI(QRY_find2("Control Objects...", &qryTag));

        if (qryTag)
        {
            printf("\n Control Object Query Found \n");
            fflush(stdout);

            CALLAPI(QRY_execute(qryTag, 3, qry_entries, qry_values, &query_count, &query_result));

            printf("\n query_count is : %d\n", query_count);
            fflush(stdout);

            if (query_count > 0)
            {
                char *t5_Userinfo2 = NULL;
                char cmd[500];
                tag_t obj = query_result[0];
                CALLAPI(AOM_ask_value_string(obj, "t5_Userinfo2", &t5_Userinfo2));
                sprintf(cmd, "%s/communication_BOMImplosion.sh %s %s %s", t5_Userinfo2, FileNameTop, FileName, mail);
                printf("\nExcuting Command = %s\n", cmd);

           //   /user/testcmi/Palash/tm_BOMImplosion/EXE_BOMImplosion.sh "28296000M10017^NR^1" "APLP Release and Above" "+" "+" "pravinj1.ttl@tatamotors.com"
                fflush(stdout);
                system(cmd);
                printf("\nAfter executing Command\n");
                fflush(stdout);
            }
        }
    }
}

int tm_BOMImplosionFtn_Call(void *return_data)
{
    // Variable Decleration
    int ifail = ITK_ok;
    // tag_t rev = NULLTAG;
    char *rev = NULL;
    char *inp_revRule = NULL;
    char *inp_RemoveUnderscorePart = NULL;
    char *inp_skipZero = NULL;
    char *inp_mail = NULL;
    char *inp_Plant = NULL;
    char *inp_brk = NULL;

    USERARG_get_string_argument(&rev);                      // rev
    USERARG_get_string_argument(&inp_revRule);              // revision rule
    USERARG_get_string_argument(&inp_RemoveUnderscorePart); // remove underscore part
    USERARG_get_string_argument(&inp_skipZero);             // skip zero
    USERARG_get_string_argument(&inp_mail);                 // mail lov
    USERARG_get_string_argument(&inp_Plant); 
    USERARG_get_string_argument(&inp_brk); 


    printf("rev                  : %s\n", rev ? rev : "(null)");
printf("inp_revRule          : %s\n", inp_revRule ? inp_revRule : "(null)");
printf("inp_RemoveUnderscore : %s\n", inp_RemoveUnderscorePart ? inp_RemoveUnderscorePart : "(null)");
printf("inp_skipZero         : %s\n", inp_skipZero ? inp_skipZero : "(null)");
printf("inp_mail             : %s\n", inp_mail ? inp_mail : "(null)");
printf("inp_Plant            : %s\n", inp_Plant ? inp_Plant : "(null)");
printf("inp_brk              : %s\n", inp_brk ? inp_brk : "(null)");

    // Control Object for EXE
    char *qry_entries[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qry_values[3] = {"BOMImplosion", "REPORTPATH", "0"};

    tag_t qryTag = NULLTAG;
    int query_count;
    tag_t *query_result = NULLTAG;

    CALLAPI(QRY_find2("Control Objects...", &qryTag));

    if (qryTag)
    {
        printf("\n Control Object Query Found \n");
        fflush(stdout);

        CALLAPI(QRY_execute(qryTag, 3, qry_entries, qry_values, &query_count, &query_result));

        printf("\n query_count is : %d\n", query_count);
        fflush(stdout);

        if (query_count > 0)
        {
            char *t5_Userinfo1 = NULL;
            char cmd[500];
            tag_t obj = query_result[0];
            CALLAPI(AOM_ask_value_string(obj, "t5_Userinfo1", &t5_Userinfo1));
            sprintf(cmd, "%s/EXE_BOMImplosion.sh %s %s %s %s %s %s %s &", t5_Userinfo1, rev, inp_revRule, inp_RemoveUnderscorePart, inp_skipZero, inp_mail, inp_Plant, inp_brk);
            printf("Excuting Command = %s", cmd);
            fflush(stdout);
            system(cmd);
            printf("After executing Command");
            fflush(stdout);
        }
    }

    return ifail;
}

extern int AllUserServiceFnBOMImplosionFtn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    int nargs = 7;
    int retValueType;
    int inputArgTypes[7] = {0};

    // int *inputArgtypes = (int *) MEM_alloc ( nargs * sizeof (int) );
    //  Refer ict_userservice.h for more arg types
    inputArgTypes[0] = USERARG_STRING_TYPE; // listVCString
    inputArgTypes[1] = USERARG_STRING_TYPE; // Revision Rule
    inputArgTypes[2] = USERARG_STRING_TYPE; // removeUnderscoreValue
    inputArgTypes[3] = USERARG_STRING_TYPE; // skipZeroValue
    inputArgTypes[4] = USERARG_STRING_TYPE; // mailLOV
    inputArgTypes[5] = USERARG_STRING_TYPE; // plant
    inputArgTypes[6] = USERARG_STRING_TYPE; //TplmoduleBreakdown

    retValueType = USERARG_STRING_TYPE;
    printf("\n AllUserServiceFnBOMImplosionFtn before....tm_BOMImplosionFtnFtn");
    fflush(stdout);
    ifail = USERSERVICE_register_method("tm_BOMImplosionFtn_Call", (USER_function_t)tm_BOMImplosionFtn_Call, nargs, inputArgTypes, retValueType);

    return ifail;
}

extern "C" DLLAPI int tm_BOMImplosion_register_callbacks()
{

    int ifail = ITK_ok;
    printf("\n Before registoring userservice....tm_BOMImplosion");
    fflush(stdout);
    ifail = CUSTOM_register_exit("tm_BOMImplosion", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)AllUserServiceFnBOMImplosionFtn);
    printf("\n After registoring userservice....tm_BOMImplosion");
    fflush(stdout);
    return (ITK_ok);
}

