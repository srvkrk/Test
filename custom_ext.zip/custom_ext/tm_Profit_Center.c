/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_Profit_Center.c
**
**
**	Date				   Author			        Modification
**	18-09-2025			Sourav Karak	    Profit Center Logic Implementation
* 
* SrNo		Modified By		   Date			     Modification
*	1		Sourav Karak 	18-Sep-2025		Profit Center Logic Implementation

***********************************************************************************************************************************************************/

#include "malloc.h"
#include "stdio.h"
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/signoff.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#include <user_exits/epm_toolkit_utils.h>
#define PS_where_used_all_levels   -1 
#define T5_WorkFlowHandlerErr (EMH_USER_error_base + 701)

int status =0;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int PC_PreApprovalMail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag	=  NULLTAG;
	tag_t	ObjTypTag	    = NULLTAG;
	int      no_attach      =  0;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag1     = NULLTAG; 
	char    *qry_entry1[1]  = {"SYSCD"};
	int     n_entry1    = 1; 
	int     rsltCount1 =  0; 
	tag_t   *CntrlObjectTag1  = NULLTAG;	
	int error_code = ITK_ok;
	char* user_id1 =NULL;
	char    *qry_values1[1] = {"ProfitCenterPreApprovalMail"};
    POM_get_user_id (&user_id1);
	
	printf("\n PC: PC_PreApprovalMail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id1);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}
	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag1));
	if (qryTag1)
	{
		printf("\n PC: ProfitCenterPreApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag1, n_entry1, qry_entry1, qry_values1, &rsltCount1, &CntrlObjectTag1));
		printf("\n PC: ProfitCenterPreApprovalMail: Result Count: [%d]", rsltCount1);fflush(stdout);
		if(rsltCount1 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPreApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag1[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nBelow VC created in SAP with the profit center indicated: ");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,PCobjAppStatus);
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"\nPLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPreApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PC_PreApprovalMail_Func end.......");fflush(stdout);

	return error_code;
}

int PC_PostApprovalMail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag			=  NULLTAG;
	int     no_attach      =  0;
	tag_t	ObjTypTag	    = NULLTAG;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char    *PCobjAppDate = NULL;
	char	*PCobjPlant	=  NULL;
	char    *PCobjAppName = NULL;
	char    *PCobjAppComnt = NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag2     = NULLTAG; 
	char    *qry_entry2[1]  = {"SYSCD"};
	int     n_entry2    = 1; 
	int     rsltCount2 =  0; 
	tag_t   *CntrlObjectTag2  = NULLTAG;	
	char    *qry_values2[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id2 =NULL;
	
    POM_get_user_id (&user_id2);
	printf("\n PC: PC_PostApprovalMail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id2);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag2));
	if (qryTag2)
	{
		printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag2, n_entry2, qry_entry2, qry_values2, &rsltCount2, &CntrlObjectTag2));
		printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount2);fflush(stdout);
		if(rsltCount2 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr3",&PCobjAppDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_PCApproverName",&PCobjAppName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_PCApproveComment",&PCobjAppComnt)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Object Approved Date: [%s]", PCobjAppDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
				printf("\n PC: Approver Name: [%s]", PCobjAppName);fflush(stdout);
				printf("\n PC: Approver Comment: [%s]", PCobjAppComnt);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"APPROVED:Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nThanks for confirming we are processing below VC with mapped profit center ");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\nObject Approved Date: ");
				tc_strcat(envDesc,PCobjAppDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,"APPROVED");
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"\nPLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PC_PostApprovalMail_Func end.......");fflush(stdout);
	
	return error_code;
}

int PC_FinanceHeadRejectEmail_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag		=  NULLTAG;
	tag_t	ObjTypTag	    = NULLTAG;
	int      no_attach      =  0;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	tag_t   qryTag3     = NULLTAG; 
	char    *qry_entry3[1]  = {"SYSCD"};
	int     n_entry3    = 1; 
	int     rsltCount3 =  0; 
	tag_t   *CntrlObjectTag3  = NULLTAG;	
	char    *qry_values3[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id3 =NULL;
	
    POM_get_user_id (&user_id3);
	printf("\n PC: PC_FinanceHeadRejectEmail_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id3);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag3));
	if (qryTag3)
	{
		printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag3, n_entry3, qry_entry3, qry_values3, &rsltCount3, &CntrlObjectTag3));
		printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount3);fflush(stdout);
		if(rsltCount3 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				char* info5 = NULL;
				char* info6 = NULL;
				char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag3[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				tc_strcpy(eMailTo,info5);
				tc_strcat(eMailTo,info6);
				tc_strcat(eMailTo,info7);
				tc_strcpy(eMailCC,info8);
				tc_strcat(eMailCC,info9);
				tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"REJECT:Profit Center for new VC: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear Sir / Madam, ");
				tc_strcat(envDesc,"\n\nThanks we will review rejection comments and re-process below VC with correct profit center");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\n\nApproval Status: ");
				tc_strcat(envDesc,"REJECTED");
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"\nPLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
	printf("\n PC: PC_FinanceHeadRejectEmail_Func end.......");fflush(stdout);
	
	return error_code;
}

int PCRemove_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	PCobjTag			=  NULLTAG;
	int     no_attach      =  0;
	tag_t	ObjTypTag	    = NULLTAG;
    char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char    *PCobjAppDate   =  NULL;
	char	*PCobjPlant	=  NULL;
	char   *ObjTypName = NULL;
	char* info1 = NULL;
	char* info2 = NULL;
	char* info3 = NULL;
	char* info4 = NULL;
	tag_t   qryTag2     = NULLTAG; 
	char    *qry_entry2[1]  = {"SYSCD"};
	int     n_entry2    = 1; 
	int     rsltCount2 =  0; 
	tag_t   *CntrlObjectTag2  = NULLTAG;	
	char    *qry_values2[1] = {"ProfitCenterPostApprovalMail"};
	int error_code = ITK_ok;
	char* user_id2 =NULL;
	
	tag_t   qryTag7     = NULLTAG; 
	char    *qry_entry7[1]  = {"SYSCD"};
	int     n_entry7    = 1; 
	int     rsltCount7 =  0; 
	tag_t   *CntrlObjectTag7  = NULLTAG;	
	char    *qry_values7[1] = {"PCRemoveShell"};
	char *shellinfo1 = NULL;
	char *ShellPath  = NULL;
	
    POM_get_user_id (&user_id2);
	printf("\n PC: PCRemove_Func start.......");fflush(stdout);
	printf("\n PC: current user is: [%s]", user_id2);fflush(stdout);
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n PC: No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		PCobjTag = attachment[0];
	}

	if(TCTYPE_ask_object_type(attachment[0],&ObjTypTag));
	if(TCTYPE_ask_name2(ObjTypTag,&ObjTypName));
	printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTypName);fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag2));
	if (qryTag2)
	{
		printf("\n PC: PCRemove_Func: Found Query ControlObjects \n");fflush(stdout);
		if(QRY_execute(qryTag2, n_entry2, qry_entry2, qry_values2, &rsltCount2, &CntrlObjectTag2));
		printf("\n PC: PCRemove_Func: Result Count: [%d]", rsltCount2);fflush(stdout);
		if(rsltCount2 > 0)
		{
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
			if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
			printf("\n PC: PCRemove_Func: Information-1: [%s]\n", info1);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-2: [%s]\n", info2);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-3: [%s]\n", info3);fflush(stdout);
			printf("\n PC: PCRemove_Func: Information-4: [%s]\n", info4);fflush(stdout);
			if((tc_strcmp(ObjTypName,info1)==0) && (tc_strcmp(info2,"Mail")==0))
			{
				if(AOM_ask_value_string(attachment[0],"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr3",&PCobjAppDate)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(attachment[0],"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
				printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
				printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
				printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
				printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
				printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
				printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
				printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
				printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
				printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
				printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
				printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
				printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
				printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
				printf("\n PC: Object Approval Date: [%s]", PCobjAppDate);fflush(stdout);
				printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
				
				char *changeno = (char *) malloc(100*sizeof(char));
				char GenDate[100] = "";
				time_t 	now;
				struct 	tm when;
				time(&now);
				when = *localtime(&now);
				strftime(GenDate,100,"%d%m%y",&when);
				printf("\n PC: PCRemove_Func: Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
				tc_strcpy(changeno,"CORRCT");
				tc_strcat(changeno,GenDate);
				printf("\n PC: PCRemove_Func: Change Number: [%s]\n", changeno);fflush(stdout);
				
				printf("\n PC: PCRemove_Func: PC Remove Shell Call Start..\n");fflush(stdout);
				if(QRY_find2("ControlObjects", &qryTag7));
				if (qryTag7)
				{
					printf("\n PC: PCRemove_Func: Found Query ControlObjects \n");fflush(stdout);
					if(QRY_execute(qryTag7, n_entry7, qry_entry7, qry_values7, &rsltCount7, &CntrlObjectTag7));
					printf("\n PC: PCRemove_Func: Result Count: [%d]", rsltCount7);fflush(stdout);
					if(rsltCount7 > 0)
					{
						if(AOM_ask_value_string(CntrlObjectTag7[0],"t5_Userinfo1",&shellinfo1)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(CntrlObjectTag7[0],"t5_Userinfo2",&ShellPath)!=ITK_ok)   PrintErrorStack();
						printf("\n PC: PCRemove_Func: PC Remove Shell Information-1: [%s]\n", shellinfo1);fflush(stdout);
						printf("\n PC: PCRemove_Func: PC Remove Shell Information-2: [%s]\n", ShellPath);fflush(stdout);
						if(tc_strcmp(shellinfo1,"ON")==0)
			            {
							char *command = NULL;
							command = (char *)MEM_alloc(500);
							sprintf(command,"%s %s %s %s",ShellPath,PCObjvcNo,PCobjPlant,changeno);
							printf("\n Command to be run  == <%s>", command);fflush(stdout);
							system(command);
						}
						else
						{
							printf("\n PC: PCRemove_Func: Control Object is OFF !!\n");fflush(stdout);
						}
					}
				}
				printf(" PC: PCRemove_Func: PC Remove Shell Call End..\n");fflush(stdout);
	
				char  *envSub	  = NULL;
				char  *envDesc	  = NULL;
				char  *buff 	= NULL;
				char*	eMailCC			= NULL;
				char*	eMailTo			= NULL;
				eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
				eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
				envSub = (char *) MEM_alloc( 250 * sizeof(char) );
				envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
				buff=(char *) MEM_alloc(2000 * sizeof(char *));
				//char* info5 = NULL;
				//char* info6 = NULL;
				//char* info7 = NULL;
				char* info8 = NULL;
				char* info9 = NULL;
				char* info10 = NULL;
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
				//if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
				if(AOM_ask_value_string(CntrlObjectTag2[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
				tc_strcpy(eMailCC,"");
				tc_strcpy(eMailTo,"");
				tc_strcpy(envSub,"");
				tc_strcpy(envDesc,"");
				tc_strcpy(buff,"");
				//tc_strcpy(eMailTo,info5);
				//tc_strcat(eMailTo,info6);
				//tc_strcat(eMailTo,info7);
				tc_strcpy(eMailTo,info8);
				tc_strcat(eMailTo,info9);
				tc_strcat(eMailTo,info10);
				tc_strcpy(eMailCC,info4);
				//tc_strcpy(eMailCC,info8);
				//tc_strcat(eMailCC,info9);
				//tc_strcat(eMailCC,info10);
				
				tc_strcpy(envSub,"UPDATE:PC tag removed from SAP: ");
				tc_strcat(envSub,PCobjName);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjProfit);
				tc_strcat(envSub," | ");
				tc_strcat(envSub,PCobjPlant);

				tc_strcpy(envDesc,"Dear All, ");
				tc_strcat(envDesc,"\n\nPC tag removed for below vc from SAP");
				tc_strcat(envDesc,"\nVC Number: ");
				tc_strcat(envDesc,PCObjvcNo);
				tc_strcat(envDesc,"\nDescription: ");
				tc_strcat(envDesc,PCobjDesc);
				tc_strcat(envDesc,"\nProduct Line: ");
				tc_strcat(envDesc,PCObjProd);
				tc_strcat(envDesc,"\nPlatform: ");
				tc_strcat(envDesc,PCobjPlat);
				tc_strcat(envDesc,"\nSegment: ");
				tc_strcat(envDesc,PCobjSeg);
				tc_strcat(envDesc,"\nProfit Center: ");
				tc_strcat(envDesc,PCobjProfit);
				tc_strcat(envDesc,"\nPlant Code: ");
				tc_strcat(envDesc,PCobjPlant);
				tc_strcat(envDesc,"\nSystem Release Date: ");
				tc_strcat(envDesc,PCobjRelDate);
				tc_strcat(envDesc,"\nObject Created Date: ");
				tc_strcat(envDesc,PCobjCrDate);
				tc_strcat(envDesc,"\nPC Tag Remove Date: ");
				tc_strcat(envDesc,PCobjAppDate);
				tc_strcat(envDesc,"\n\nRegards, ");
				tc_strcat(envDesc,"\nPLM Team\n\n");

				printf("\n\nMAIL_initialize\n\n");
				sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
				printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
				system(buff);
			}
		}
		else
		{
			printf("\n PC: PCRemove_Func: Control Object Not Found \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n PC: PCRemove_Func: ControlObjects Query Tag Not Found \n");fflush(stdout);
	}
    printf("\n PC: PCRemove_Func end.......");fflush(stdout);
	
	return error_code;
}

EPM_decision_t PCFinanceHeadDecisionCmnt( EPM_rule_message_t msg)
{
	
	tag_t user_tag = NULLTAG;
	char* username = NULL;
	EPM_signoff_decision_t desc = EPM_no_decision;
	char* comments = NULL;
	date_t decision_date = NULLDATE;
	tag_t tzroottask=NULLTAG;
	int izntaskattachment = 0;
	tag_t *tzattachment = NULLTAG;
	tag_t objTag =  NULLTAG;
	char* newtype = NULL;
	char* newname = NULL;
	char* decisiondate = NULL;
	char* DECISION = NULL;
	EPM_decision_t	decision = EPM_go;
	tag_t objTypTag	= NULLTAG;
	char  *ObjTyp = NULL;
	tag_t   qryTag  = NULLTAG;
	int n_entry = 1;
	char  *qry_entry[1]  = {"SYSCD"};
	char  *qry_values2[1]  =  {"ProfitCenterPostApprovalMail"};
	int  rsltCount = 0;
	tag_t *CntrlObjectTag = NULLTAG;
	char *info1	= NULL;
	char *info2	= NULL;
	char	*PCobjName	=  NULL;
	char	*PCobjDesc	=  NULL;
	char	*PCobjBu	=  NULL;
	char	*PCobjDML	=  NULL;
	char	*PCObjvcNo	=  NULL;
	char	*PCObjProd	=  NULL;
	char	*PCobjPlat	=  NULL;
	char	*PCobjSeg	=  NULL;
	char	*PCobjVar	=  NULL;
	char	*PCobjProfit	=  NULL;
	//char	*PCobjAppStatus	=  NULL;
	char	*PCobjRelDate	=  NULL;
	char	*PCobjCrDate	=  NULL;
	char	*PCobjPlant	=  NULL;
	tag_t updateappstat = NULLTAG;
	tag_t updateappname = NULLTAG;
	tag_t updateappcomnt = NULLTAG;
	tag_t updateappdate = NULLTAG;
	int ifail = ITK_ok;
	int error_code = ITK_ok;
	char command[512];
	
	char GenDate[100] = "";
	time_t  now;
	struct  tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d-%b-%Y %H:%M",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf(" =========== Approver Decision New Start ==============");fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\n PC: username: [%s]\n",username);fflush(stdout);	
	EPM_ask_decision(msg.task,user_tag,&desc,&comments,&decision_date);
	printf("\n PC: comments: [%s]\n",comments);fflush(stdout);
	EPM_ask_root_task(msg.task, &tzroottask);
	EPM_ask_attachments(tzroottask, EPM_target_attachment,&izntaskattachment, &tzattachment);
	printf("\n PC: Attachements: [%d]", izntaskattachment);fflush(stdout);
	if(izntaskattachment>0)
	{
		objTag = tzattachment[0];
		AOM_ask_value_string(tzattachment[0],"object_type",&newtype);
		printf("\n PC: Object_Type: [%s]", newtype);fflush(stdout);
		AOM_ask_value_string(tzattachment[0],"object_name",&newname);
		printf("\n PC: Object_Name: [%s]", newname);fflush(stdout);
		ITK_date_to_string(decision_date,&decisiondate);
		if(desc==EPM_approve_decision)
		{
			DECISION = (char*)MEM_alloc(20*sizeof(char));
			tc_strcpy(DECISION,"APPROVED");
		}
		if(desc==EPM_reject_decision)
		{
			DECISION = (char*)MEM_alloc(20*sizeof(char));
			tc_strcpy(DECISION,"REJECT");
		}
		printf("\n PC: DECISION: [%s]", DECISION);fflush(stdout);
	}
	printf("\n PC: DECISION: [%s]", DECISION);fflush(stdout);
	printf("\n PC: comments: [%s]", comments);fflush(stdout);
	if(desc==EPM_approve_decision || desc==EPM_reject_decision)
	{
		if(comments == NULL)
		{
			char* buff = NULL;
			ifail=T5_WorkFlowHandlerErr;
			buff = (char*)MEM_alloc(200*sizeof(char));
			sprintf(buff, "Sign off Comment is mandatory. Please enter comments before sign off");
			EMH_store_error_s1(EMH_severity_error,ifail,buff);
			decision = EPM_nogo;
			if(buff)MEM_free(buff);
			return decision; 						
		}
		else
		{
			if(tc_strcmp(comments,"")==0)
			{
				char* buff = NULL;
				ifail=T5_WorkFlowHandlerErr;
				buff = (char*)MEM_alloc(200*sizeof(char));
				sprintf(buff, "Sign off Comment is blank. Please enter comments before sign off");
				EMH_store_error_s1(EMH_severity_error,ifail,buff);
				decision = EPM_nogo;
				if(buff)MEM_free(buff);
				return decision; 						
			}
			else
			{
				if(TCTYPE_ask_object_type(objTag,&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n PC: Workfow Object Type Name: [%s]\n", ObjTyp);fflush(stdout);
				if(QRY_find2("ControlObjects", &qryTag));
				if(qryTag)
				{
					printf("\n PC: ProfitCenterPostApprovalMail: Found Query ControlObjects \n");fflush(stdout);
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
					printf("\n PC: ProfitCenterPostApprovalMail: Result Count: [%d]", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{
						if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
						if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n PC: ProfitCenterPostApprovalMail: Information-2: [%s]\n", info2);fflush(stdout);
						if((tc_strcmp(ObjTyp,info1)==0) && (tc_strcmp(info2,"Mail")==0))
						{
							if(AOM_ask_value_string(objTag,"object_name",&PCobjName)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"object_desc",&PCobjDesc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_BusinessUnit",&PCobjBu)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ERCDMLNo",&PCobjDML)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_VcNumber",&PCObjvcNo)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ProductLine",&PCObjProd)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_Platform",&PCobjPlat)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_Segment",&PCobjSeg)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_Variant",&PCobjVar)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ProfitCenter",&PCobjProfit)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(objTag,"t5_ApprovalStatus",&PCobjAppStatus)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ExtraAttr1",&PCobjRelDate)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ExtraAttr2",&PCobjCrDate)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(objTag,"t5_ExtraAttr5",&PCobjPlant)!=ITK_ok)PrintErrorStack();
							printf("\n PC: Name: [%s]", PCobjName);fflush(stdout);
							printf("\n PC: Description: [%s]", PCobjDesc);fflush(stdout);
							printf("\n PC: Business Unit: [%s]", PCobjBu);fflush(stdout);
							printf("\n PC: DML No: [%s]", PCobjDML);fflush(stdout);
							printf("\n PC: VC No: [%s]", PCObjvcNo);fflush(stdout);
							printf("\n PC: Product Line: [%s]", PCObjProd);fflush(stdout);
							printf("\n PC: Platform: [%s]", PCobjPlat);fflush(stdout);
							printf("\n PC: Segment: [%s]", PCobjSeg);fflush(stdout);
							printf("\n PC: Variant: [%s]", PCobjVar);fflush(stdout);
							printf("\n PC: Profit Center: [%s]", PCobjProfit);fflush(stdout);
							//printf("\n PC: Approval Status: [%s]", PCobjAppStatus);fflush(stdout);
							printf("\n PC: System Release Date: [%s]", PCobjRelDate);fflush(stdout);
							printf("\n PC: Object Creation Date: [%s]", PCobjCrDate);fflush(stdout);
							printf("\n PC: Plant Code: [%s]", PCobjPlant);fflush(stdout);
							if(desc==EPM_approve_decision || tc_strcmp(DECISION,"APPROVED")==0 || desc==EPM_reject_decision || tc_strcmp(DECISION,"REJECT")==0)
							{
								printf("\n PC: PCFinanceHeadDecisionCmnt: desc: [%d]", desc);fflush(stdout);
								printf("\n PC: After PCFinanceHeadDecisionCmnt: FinanceHeadDecision: [%s]", DECISION);fflush(stdout);
								if(desc==EPM_reject_decision || tc_strcmp(DECISION,"REJECT")==0)
								{
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_ApprovalStatus", "T5_ProfitCenterMapping", &updateappstat);
									POM_set_attr_string(1, &objTag, updateappstat, "REJECT");
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [REJECT] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Name set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_PCApproverName", "T5_ProfitCenterMapping", &updateappname);
									POM_set_attr_string(1, &objTag, updateappname, username);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Name set for [REJECT] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Comments set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_PCApproveComment", "T5_ProfitCenterMapping", &updateappcomnt);
									POM_set_attr_string(1, &objTag, updateappcomnt, comments);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Comments set for [REJECT] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Time set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_ExtraAttr3", "T5_ProfitCenterMapping", &updateappdate);
									POM_set_attr_string(1, &objTag, updateappdate, GenDate);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Time set for [REJECT] Decision End..");fflush(stdout);
								}
								if(desc==EPM_approve_decision || tc_strcmp(DECISION,"APPROVED")==0)
								{
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [APPROVED] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_ApprovalStatus", "T5_ProfitCenterMapping", &updateappstat);
									POM_set_attr_string(1, &objTag, updateappstat, "APPROVED");
									POM_save_instances(1, &objTag, false);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approval Status set For [APPROVED] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Name set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_PCApproverName", "T5_ProfitCenterMapping", &updateappname);
									POM_set_attr_string(1, &objTag, updateappname, username);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Name set for [REJECT] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Comments set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_PCApproveComment", "T5_ProfitCenterMapping", &updateappcomnt);
									POM_set_attr_string(1, &objTag, updateappcomnt, comments);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Comments set for [REJECT] Decision End..");fflush(stdout);
									
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Time set for [REJECT] Decision Start..");fflush(stdout);
									AOM_refresh(objTag, TRUE);
									POM_attr_id_of_attr("t5_ExtraAttr3", "T5_ProfitCenterMapping", &updateappdate);
									POM_set_attr_string(1, &objTag, updateappdate, GenDate);
									POM_save_instances(1, &objTag, false);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Completed: POM_save_instances");fflush(stdout);
									AOM_refresh(objTag, FALSE);
									printf("\n PC: PCFinanceHeadDecisionCmnt: Approver Time set for [REJECT] Decision End..");fflush(stdout);
								}
							}	
		
							char  *envSub	  = NULL;
							char  *envDesc	  = NULL;
							char  *buff 	= NULL;
							char*	eMailCC			= NULL;
							char*	eMailTo			= NULL;
							eMailCC=(char *) MEM_alloc(500 * sizeof(char *));
							eMailTo=(char *) MEM_alloc(500 * sizeof(char *));
							envSub = (char *) MEM_alloc( 250 * sizeof(char) );
							envDesc = (char *) MEM_alloc( 1000 * sizeof(char) );
							buff=(char *) MEM_alloc(2000 * sizeof(char *));
							char* info5 = NULL;
							char* info6 = NULL;
							char* info7 = NULL;
							char* info8 = NULL;
							char* info9 = NULL;
							char* info10 = NULL;
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
							if(AOM_ask_value_string(CntrlObjectTag[0],"t5_userinfo10",&info10)!=ITK_ok)   PrintErrorStack();
							tc_strcpy(eMailCC,"");
							tc_strcpy(eMailTo,"");
							tc_strcpy(envSub,"");
							tc_strcpy(envDesc,"");
							tc_strcpy(buff,"");
							tc_strcpy(eMailTo,info8);
							tc_strcat(eMailTo,info9);
							tc_strcat(eMailTo,info10);
							tc_strcpy(eMailCC,info5);
							tc_strcat(eMailCC,info6);
							tc_strcat(eMailCC,info7);
							
							//tc_strcpy(envSub,DECISION);
							tc_strcpy(envSub,"Finance Comments");
							tc_strcat(envSub,":Profit Center for new VC: ");
							tc_strcat(envSub,PCobjName);
							tc_strcat(envSub," | ");
							tc_strcat(envSub,PCobjProfit);
							tc_strcat(envSub," | ");
							tc_strcat(envSub,PCobjPlant);

							tc_strcpy(envDesc,"Dear All, ");
							tc_strcat(envDesc,"\n\nPlease find Finance Head Teams Approval Status and comments for below VC: ");
							tc_strcat(envDesc,"\nVC Number: ");
							tc_strcat(envDesc,PCObjvcNo);
							tc_strcat(envDesc,"\nDescription: ");
							tc_strcat(envDesc,PCobjDesc);
							tc_strcat(envDesc,"\nProduct Line: ");
							tc_strcat(envDesc,PCObjProd);
							tc_strcat(envDesc,"\nPlatform: ");
							tc_strcat(envDesc,PCobjPlat);
							tc_strcat(envDesc,"\nSegment: ");
							tc_strcat(envDesc,PCobjSeg);
							tc_strcat(envDesc,"\nProfit Center: ");
							tc_strcat(envDesc,PCobjProfit);
							tc_strcat(envDesc,"\nPlant Code: ");
							tc_strcat(envDesc,PCobjPlant);
							tc_strcat(envDesc,"\nSystem Release Date: ");
							tc_strcat(envDesc,PCobjRelDate);
							tc_strcat(envDesc,"\nObject Created Date: ");
							tc_strcat(envDesc,PCobjCrDate);
							tc_strcat(envDesc,"\n\nFinance Team Approver Name: ");
							tc_strcat(envDesc,username);
							tc_strcat(envDesc,"\nFinance Team Approval Status: ");
							tc_strcat(envDesc,DECISION);
							tc_strcat(envDesc,"\nFinance Team Comments: ");
							tc_strcat(envDesc,comments);
							tc_strcat(envDesc,"\n\nRegards, ");
							tc_strcat(envDesc,"\nPLM Team\n\n");

							printf("\n\nMAIL_initialize\n\n");
							sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);
							printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);
							system(buff);
						}
					}
					else
					{
						printf("\n PC: ProfitCenterPostApprovalMail: Control Object Not Found \n");fflush(stdout);
					}
				}
				else
				{
					printf("\n PC: ControlObjects Query Tag Not Found \n");fflush(stdout);
				}
			}
		}
	}
	printf(" =========== Approver Decision New End ==============");fflush(stdout);
	
	return decision;
}

extern int Profit_Center_register_method(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;

	status = EPM_register_action_handler ("PCPreApprovalMail","PCPreApprovalMail",(EPM_action_handler_t)PC_PreApprovalMail_Func);
	status = EPM_register_action_handler ("PCPostApprovalMail","PCPostApprovalMail",(EPM_action_handler_t)PC_PostApprovalMail_Func);
	status = EPM_register_action_handler ("PCFinanceHeadRejectEmail","PCFinanceHeadRejectEmail",(EPM_action_handler_t)PC_FinanceHeadRejectEmail_Func);
	status = EPM_register_action_handler ("PCRemove","PCRemove",(EPM_action_handler_t)PCRemove_Func);
    status = EPM_register_rule_handler ("PCFinanceHeadDecision","PCFinanceHeadDecision",(EPM_rule_handler_t)PCFinanceHeadDecisionCmnt);
	
	return status;
}

extern DLLAPI int tm_Profit_Center_register_callbacks ()
{
	int ifail = ITK_ok;
	printf("\n [Profit_Center]Before register tm_Profit_Center...");fflush(stdout);
    ifail=CUSTOM_register_exit("tm_Profit_Center","USER_init_module",(CUSTOM_EXIT_ftn_t)Profit_Center_register_method);
	printf("\n [Profit_Center]After register tm_Profit_Center...");fflush(stdout);
    return ( ITK_ok );
}