/****************************************************************************************************
*  File	           :   std_common_function.c ( File name )
*  Project         :   PLM TCUA Project-STDS1.		     
*  Modification History :
*  Date			Modified By			TZ			Modification Notes
*  20/06/18		Priti Pagar			1.35		STDSI Sign off validations-1. Previous revision not released check
																		   2. Child part not released
																		   3. AMDML validations bypass
																		   4. Two revision can not be released on same day
																		   5. Next revision of part exists with DR>DR3
																		   6. PP/PM DML for part released error
*******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define EMH_severity_information 1
#define EMH_severity_warning      2
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

//Start Code to Explode BOM -3
void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}
void  getPlantDetailsAttr_Std( char * RoleName ,char  getPlantCS[40],char  getPlantOptCS[40],char  getPlantIA[40],char  getPlantStore[40],char  getUserAgency[40],char  getRevisionRule[40],char  getClosureRule[40],char  getBVR[40],char getAPLDMLPlant[40])
{
     char   *PlantName=NULL;
	  printf( "RoleName:%s\n", RoleName);
      PlantName=subString(RoleName,3,4);
      printf( "PlantName:%s\n", PlantName);
	  if(strcmp(RoleName,"STDD")==0)
	  {
		tc_strcpy(getPlantCS,"t5_DwdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_DwdOptionalCS");
		tc_strcpy(getPlantIA,"t5_DwdIntialAgency");
		tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
		tc_strcpy(getUserAgency,"DWD");
		tc_strcpy(getRevisionRule,"STDD Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDD");
		tc_strcpy(getBVR,"STDD View");
		tc_strcpy(getAPLDMLPlant,"APLD");
	  }else  if(strcmp(PlantName,"STDP")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
		tc_strcpy(getRevisionRule,"STDP Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDP");
		tc_strcpy(getBVR,"STDP View");
		tc_strcpy(getAPLDMLPlant,"APLP");
	  }else  if(strcmp(PlantName,"STDC")==0)
	  {
		tc_strcpy(getPlantCS,"t5_CarMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_CarOptionalCS");
		tc_strcpy(getPlantIA,"t5_CarIntialAgency");
		tc_strcpy(getPlantStore,"t5_CarStoreLocation");
		tc_strcpy(getUserAgency,"CAR");
		tc_strcpy(getRevisionRule,"STDC Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDC");
		tc_strcpy(getBVR,"STDC View");
		tc_strcpy(getAPLDMLPlant,"APLC");
	  }else  if(strcmp(PlantName,"STDJ")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JsrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JsrOptionalCS");
		tc_strcpy(getPlantIA,"t5_JsrIntialAgency");
		tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
		tc_strcpy(getUserAgency,"JSR");
		tc_strcpy(getRevisionRule,"STDJ Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDJ");
		tc_strcpy(getBVR,"STDJ View");
		tc_strcpy(getAPLDMLPlant,"APLJ");
	  }else  if(strcmp(PlantName,"STDL")==0)
	  {
		tc_strcpy(getPlantCS,"t5_LkoMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_LkoOptionalCS");
		tc_strcpy(getPlantIA,"t5_LkoIntialAgency");
		tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
		tc_strcpy(getUserAgency,"LKO");
		tc_strcpy(getRevisionRule,"STDL Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDL");
		tc_strcpy(getBVR,"STDL View");
		tc_strcpy(getAPLDMLPlant,"APLL");
	  }else  if(strcmp(PlantName,"STDA")==0)
	  {
		tc_strcpy(getPlantCS,"t5_AhdMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"t5_AhdOptionalCS");
		tc_strcpy(getPlantIA,"t5_AhdIntialAgency");
		tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
		tc_strcpy(getUserAgency,"AHD");
		tc_strcpy(getRevisionRule,"STDA Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDA");
		tc_strcpy(getBVR,"STDA View");
		tc_strcpy(getAPLDMLPlant,"APLA");
	  }else  if(strcmp(PlantName,"STDU")==0)
	  {
		tc_strcpy(getPlantCS,"t5_PnrMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PnrOptionalCS");
		tc_strcpy(getPlantIA,"t5_PnrIntialAgency");
		tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
		tc_strcpy(getUserAgency,"PNR");
		tc_strcpy(getRevisionRule,"STDU Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDPU");
		tc_strcpy(getBVR,"STDU View");
		tc_strcpy(getAPLDMLPlant,"APLU");
	  }else  if(strcmp(PlantName,"STDS")==0)
	  {
		tc_strcpy(getPlantCS,"t5_JdlMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_JdlOptionalCS");
		tc_strcpy(getPlantIA,"t5_JdlIntialAgency");
		tc_strcpy(getPlantStore,"t5_JdlStoreLocation");
		tc_strcpy(getUserAgency,"JDL");
		tc_strcpy(getRevisionRule,"STDS Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDS");
		tc_strcpy(getBVR,"STDS View");
		tc_strcpy(getAPLDMLPlant,"APLS");
	  }else
	 {
		tc_strcpy(getPlantCS,"t5_PunMakeBuyIndicator");
		tc_strcpy(getPlantOptCS,"bl_occ_t5_PunOptionalCS");
		tc_strcpy(getPlantIA,"t5_PunIntialAgency");
		tc_strcpy(getPlantStore,"t5_PunStoreLocation");
		tc_strcpy(getUserAgency,"PUN");
		tc_strcpy(getRevisionRule,"STDP Released and Above");
		tc_strcpy(getClosureRule,"BOMViewClosureRuleSTDP");
		tc_strcpy(getBVR,"STDP View");
		tc_strcpy(getAPLDMLPlant,"APLP");

	  }
}
