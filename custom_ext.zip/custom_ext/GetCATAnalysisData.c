/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   A
*  Module		 :   CR client-code request for JT and PDF tessellation in TCUA environment
*  Code			 :   DesRevFromDateToDate.c
*  Created on	 :   Jan 20th, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <time.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

typedef struct  
{
    char* DsgGrp; 
	char* KeywrdDsc;
	char* PrtFmilyS;
} InputFile;


//static int PrintErrorStack( void )
extern int ITK_user_main(int argc, char ** argv )
{

    int status;
	
    char	buf[1000];
	int		BUFFER_SIZE	= 5000;

	int						result											= 0;
	int						count											= 0;
	int						iCounter1										= 0;
	int						i												= 0;
	char					*value											= NULL;
	char					*argstring1										= NULL;
	char					*argstring2										= NULL;
	char					*argstring3										= NULL;

	char					*user										= NULL;
	char					*pass										= NULL;
	char					*group										= NULL;
	char					*RefNo										= NULL;

	char					*itemId											= NULL;
	char					*revId											= NULL;
	char					*SeqID											= NULL;
	char					*revisionID										= NULL;
	char					*ItmSeqID										= NULL;
	char					 JTFile[256];
	char					*JTFileDesc										= NULL;
	char					*JTFileSeq										= NULL;
	char					*CreatedDate									= NULL;
	char					*ModifyDate										= NULL;
	char					*fullPath										= NULL;
	char					*VaultLocation									= NULL;
	char					*HostName										= NULL;
	char					*Owner											= NULL;
	char					*ProjectCode									= NULL;
	char					*vault											= NULL;
	char					*InDatabase										= NULL;
	char					*Randomized										= NULL;
	char					*Superseded										= NULL;
	char					*Frozen											= NULL;
	char					*LifeCycleState									= NULL;
	char					*FileStatus										= NULL;
	char					*Externallymanaged								= NULL;
	char					*FileRegisteredBy								= NULL;
	char					*ShadowCopy										= NULL;
	char					*Categoryname									= NULL;
	char					*Sitename										= NULL;
	char					*WorkingFileName								= NULL;
	char					*WorkingpathFormat								= NULL;
	char					*BulkdataLocation								= NULL;

	char					*Bulkdata										= NULL;
	char					*DataBasename									= NULL;
	char					*PartSequence									= NULL;

	char					*Status											= NULL;
	char					*relation_input									= NULL;
	char					*file_type										= NULL;

	char					*error_Text										= NULL;
	tag_t					JTDataset										= NULLTAG;
	tag_t					relation_JTDataset								= NULLTAG;

//	char  					line[500]										= {'\0'};
	FILE					*input											= NULL;
	char					*relation_form									= NULL;
	tag_t					t_item											= NULLTAG;
	tag_t					revision										= NULLTAG;
	tag_t					*status_list									= NULLTAG;
	tag_t					release_status									= NULLTAG;
	tag_t					revstatus										= NULLTAG;
	int						x												= 0;
	int						ref_count = 0;
	tag_t					datasettype										= NULLTAG;
	tag_t					Newdataset										= NULLTAG;
	tag_t					tool											= NULLTAG;
	tag_t					filetag											= NULLTAG;
	char					**ref_list;
	char					pathbuff[1000];
    char					*creation_date									= NULL;
	char					*text											= NULL;
	tag_t					datasetAvl										= NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType										= 1;
	int						iCountSecondary									= 0;
	tag_t					*secondaryObjects								= NULL;
        char *buf1=NULL;
	date_t				    test											= NULLDATE;
	date_t					test1										    = NULLDATE;
	char					*o											    = NULL;
	char					result1 [ 10000 ] ;
	char					 result2 [ 10000 ] ;
	char					*f												=NULL;

	char					*test11											=NULL;
	char					*test12											=NULL;
	char					*test13											=NULL;
	char					*JTid											=NULL;
	char					*JTid1											=NULL;
	char					*itemId12											=NULL;
	char					*Creator										=NULL;
	char					*aDatasetId										=NULL;
	char					*aDatasetRev										=NULL;
	char * parent_name ;
	char * dataset_name ;
	char * parent_revision_id ;
	int parent_sequence_id ;
	int ItmSeqID_int ;

	tag_t 	aDataset =NULLTAG;


	int ii,itemcount,j=0;
	int sPartNumberTokint=0;
	int c=0;
	tag_t item=NULLTAG;
	tag_t *rev=NULLTAG;
	tag_t revTag=NULLTAG;
	char *format=NULL;
	char *StrWeightArrayMain1=NULL;
	tag_t relation_type, relation;
	int				ifail=0;

	char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
    char **values = (char **) MEM_alloc(2 * sizeof(char *));

	//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	tag_t  reln_type = NULLTAG;
	int    n_attchs =0;
	int    flag =0;
	GRM_relation_t *rellist;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t Fndrelation = NULLTAG;
	int nameRef_cnt;
	tag_t *namRefObject = NULL;
    int  * nFound;
    int   nlFound;
    int   ds;
    int   ass = 0;
    tag_t **  datasets;
    tag_t **  childkeytag;
	int ref_count_d=0;
	int countkey=0;


	int n_tags_found = 0;
	tag_t query = NULLTAG;
	tag_t	LatestRev		=	NULLTAG;
	tag_t *cntr_objects = NULL;
	tag_t	*t_item1		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	int n_entries = 2;
	int n_found = 1;
	int dd = 0;
	int org_seq_id_int=0;
	char *inputfile=NULL;
	char *type=NULL;
	tag_t *tags_found = NULL;
	//char* inputline=NULL;
	tag_t	queryTag	= NULLTAG;
	int resultCount=0;
	tag_t item_tag = NULLTAG;
	char
		*qry_entries4[2] = {"creation_date_after","creation_date_before"},
        *qry_values4[2]	= {"*"};
	char *itemRevSeq = NULL;

	char *drawingnumber;
	FILE* fp=NULL;
	char *drawingtype;
	char *relationstr;
	char *user_data_1;
	//char *type_name;
	char  type_new[TCTYPE_name_size_c+1];
    char object_name[TCTYPE_name_size_c+1] ;
	tag_t *namRefObject_d = NULL;

	char *DataSetNm2 = NULL;
	char *DataSetNm = NULL;
	const char *qry_entries[1] = {"item_id"};
	const char *qry_values123[1];
	char *rev_id123 = NULL;
	char *checkout = NULL;
	char *last_mod_date = NULL;
	char *currentRevID = NULL;
	char *IsDataset = NULL;
	char *currentRevID2 = NULL;
	char *currentRevID3 = NULL;
	char *LatestRevID = NULL;
	char *object_type = NULL;
	char *object_type1 = NULL;
	char *sRef_list		= NULL;
	char *sRelStatus		= NULL;
	char *owning_user1 = NULL;
	char *checked_out_user1 = NULL;
	char *newSeqID = NULL;
	char *newRevID = NULL;
	char *Dataset = NULL;
	char *NmdRef = NULL;
	char *revIDCheck = NULL;
	char *revIDCheck1 = NULL;
	char *revIDCheck2 = NULL;

	int n_count_item=0;
	int newSeqID1=0;
	int n_rev_cnt=0;
	tag_t all_rev;
	tag_t *secObj;
	tag_t *namedRef_tag =NULLTAG;
	tag_t Relatn_type;
	tag_t Relatn_type1;
	int revloop=0;
	int secObjCount=0;
	int revIDInt1=0;
	int refnum=0;
	int reference_count=0;
	FILE *fptr;
	FILE *fptr1;
	FILE *fptr2;
	FILE *fptr3;
	FILE *fptr4;
	char* line;
	
	tag_t newRev= NULLTAG;
	char *DataSetNmOrg = NULL;
	char *fullpath = NULL;
	int RevSeq=1;
	int revCount=0;
	int Latest_count=0;
	int Latest_count123=0;
	int Lastest_corct_count123=0;
	tag_t *rev_list=NULLTAG;
	tag_t *objTypeTagDi=NULLTAG;
	char	*BOMtype	=NULL;

	tag_t secObjTypeTag = NULLTAG;

	char type_name2[TCTYPE_name_size_c+1];
	char *reference_nameDS=NULL;

	char *User_id=NULL;
	char *fromDate=NULL;
	char *ToDate=NULL;
	char *CClass=NULL;
	char *TClass=NULL;
	char *OwnSite=NULL;
	char *sItemId=NULL;
	logical is_chkout;

	char	*sday	= NULL;
	char	*sMonth	= NULL;
	char	*sTemp	= NULL;
	char	*sDate	= NULL;
	char	*sTmSec	= NULL;
	char	*sYear	= NULL;	
	char	*getInt = NULL;
	char	*IPFileNm = NULL;
	char	*sConTime = NULL;
	char	*DsgnGrp = NULL;
	char	*KeywordDsc = NULL;
	char	*PrtFmilySS = NULL;
	char	*tok = NULL;
	char*	 PrtDSgnGrpS = NULL;
	char*	 PrtDsgnGrp1S = NULL;
	InputFile temp;	
	int n_entriesK = 3;	
	int k = 0;	
	int nChildren =0;

	char *qry_entriesK[3] = {"creation_date_after","creation_date_before","Name"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	
	int resultCountK =0;
	tag_t *NewPartsSet=NULLTAG;	

	tag_t KeywordObj=NULLTAG;	
	tag_t queryTagK = NULLTAG;
	tag_t *children=NULLTAG;
	char *itemname = NULL;
	char *keydesuaname = NULL;
	char *itemnameParent = NULL;
	int nAttributes = 0;
	int nk = 0;
	int ct = 0;
	int ctq = 0;
	int flaggg = 0;
	int keyflag = 0;

	IPFileNm=(char *) MEM_alloc(200);
	sConTime=(char *) MEM_alloc(200);
	
	IsDataset=(char *) MEM_alloc(1000);
	reference_nameDS=(char *) MEM_alloc(10);

	char **attributeNames = (char **) MEM_alloc(1 * sizeof(char *));
	char **attributeValues = (char **) MEM_alloc(1 * sizeof(char *));
	
	time_t t = time(NULL);
	char* inputline=NULL;
	struct tm *tm = localtime(&t);
    char sTime[64];
	char *NewlyId = NULL;
	char *NewlyIdUsCse = NULL;
	char *NewlyIdKeyword = NULL;
	char ** 	id = NULL;
	char ** 	propername = NULL;
	char ** 	Desid = NULL;
	char ** 	iddfq = NULL;
	char *name = NULL;
	char **DATEname = NULL;
	char **moddatename = NULL;
	char *classname = NULL;
	char *Desname = NULL;
	char *abst = NULL;
	char *Fromdate = NULL;
	char *Fromdate1 = NULL;
	char *Todate = NULL;
	char *Todate1 = NULL;
	tag_t keyChild=NULLTAG;
    tag_t	ObjTypProj	= NULLTAG;
	tag_t *parent=NULLTAG;
	tag_t *desparent=NULLTAG;
	tag_t *classt=NULLTAG;
	tag_t	NewClass_t		= NULLTAG;
	char *revSeq = NULL;
	char *revSeqDup = NULL;
	char	*outfileNm = NULL;
	char *desgrp=NULL;
	char	*Part_Desg	= NULL;
	outfileNm=(char *) MEM_alloc(200);
	Fromdate1 = (char *)malloc(500 * sizeof(char));
	Todate1 = (char *)malloc(500 * sizeof(char));

	char			type_name[TCTYPE_name_size_c+1];
    strftime(sTime, sizeof(sTime), "%c", tm);

    if( ITK_init_module("infodba","infodba","dba")!=ITK_ok) ;
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login \n");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));

	printf("\n Auto login .......");fflush(stdout);
	
	printf("\nRead File Data....\n"); fflush(stdout);
	// inputfile = ITK_ask_cli_argument("-i=");
	 Fromdate = ITK_ask_cli_argument("-fd=");
	 printf("\n Fromdate ###---> %s\n",Fromdate);fflush(stdout);
	 Todate = ITK_ask_cli_argument("-td=");
	 printf("\n Todate ###---> %s\n ",Todate);fflush(stdout);

	strcpy(Fromdate1,Fromdate);
	strcat(Fromdate1,"");
	strcat(Fromdate1," 00:00");
	printf("\n Fromdate1 ---> %s",Fromdate1);fflush(stdout);
	

	strcpy(Todate1,Todate);
	strcat(Todate1,"");
	strcat(Todate1," 00:00");
	printf("\n Todate1 ---> %s",Todate1);fflush(stdout);

	//printf("\nInput inputfile: %s \n",inputfile);fflush(stdout);

	strcpy(outfileNm,"");
	strcat(outfileNm,"partlist.txt");	
	printf("\n output file [%s]",outfileNm);fflush(stdout);

	fptr1=fopen(outfileNm,"w");

	//fptr=fopen(inputfile,"w");
	if(fptr1!=NULL)
	{
		inputline=(char *) MEM_alloc(5000);
		
			qry_values[0] = Fromdate1; 
			qry_values[1] = Todate1;
			qry_values[2] = "T5_LcsReview";

			if(QRY_find("CatiaCheckin", &queryTagK));
			if (queryTagK)
			{
				printf("\nQuery Found ..\n");fflush(stdout);
			}
			else
			{
				printf("\nQuery Not Found \n");fflush(stdout);
			}

			if(QRY_execute(queryTagK, n_entriesK, qry_entriesK, qry_values, &resultCountK, &NewPartsSet));
			printf("\n Query CatiaCheckin :%d:\n", resultCountK); fflush(stdout);
			if(resultCountK > 0)
			{
				for(k=0; k<resultCountK; k++)
				{
					printf("\nPrint K value ---->>%d\n",k);fflush(stdout);

					KeywordObj = NewPartsSet[k];
					if( AOM_ask_value_string(KeywordObj,"item_id",&itemname)!=ITK_ok);
					if(AOM_ask_value_string(KeywordObj,"item_revision_id",&revSeqDup)!=ITK_ok);
					if(revSeqDup) tc_strdup(revSeqDup, &revSeq);
												
					printf("\nItem name----->> %s,RevSeq == %s\n",itemname,revSeq);fflush(stdout);

					Part_Desg=subString(itemname, 8, 2);
					desgrp=subString(itemname, 4, 2);
					printf("\n 5th and 6th digits are[%s]\n", desgrp);fflush(stdout);
					
					printf("\n 9th and 10th digits are[%s]\n", Part_Desg);fflush(stdout);

					if((tc_strcmp(desgrp,"60")==0) ||  (tc_strcmp(desgrp,"61")==0) ||(tc_strcmp(desgrp,"62")==0) || (tc_strcmp(desgrp,"63")==0)|| (tc_strcmp(desgrp,"64")==0) 
					|| (tc_strcmp(desgrp,"65")==0) ||  (tc_strcmp(desgrp,"70")==0) ||(tc_strcmp(desgrp,"71")==0)|| (tc_strcmp(desgrp,"72")==0)|| (tc_strcmp(desgrp,"73")==0)
					|| (tc_strcmp(desgrp,"74")==0) ||  (tc_strcmp(desgrp,"77")==0)|| (tc_strcmp(desgrp,"79")==0) || (tc_strcmp(desgrp,"80")==0)|| (tc_strcmp(desgrp,"88")==0)
					|| (tc_strcmp(desgrp,"89")==0) )
					{
							printf("\n Printing required design group value :%s\n",desgrp);fflush(stdout);
							
							if((tc_strcmp(Part_Desg,"33")==0) ||  (tc_strcmp(Part_Desg,"82")==0) || (tc_strcmp(Part_Desg,"86")==0))         
							{
								printf("\n Inside required 9th and 10th digit value :%s\n",Part_Desg);fflush(stdout);

								if(GRM_list_secondary_objects_only(KeywordObj,reln_type,&n_attchs,&secondary_objects)!=ITK_ok);
								printf("\nChecking No of DI :%d\n",n_attchs);fflush(stdout);
						
								if(n_attchs>0)
							   {
									for (i = 0; i < n_attchs; i++)
									{
										primary=secondary_objects[i];
										if(TCTYPE_ask_object_type(primary,&objTypeTagDi));
										if(TCTYPE_ask_name(objTypeTagDi,type_name2));
										printf("\nType of DI %s\n",type_name2);fflush(stdout);

										if(tc_strcmp(type_name2,"CMI2Part")==0 )
										{
										   printf("\n Inside the CMI2Part \n");fflush(stdout);
										   fprintf(fptr1,"%s,%s\n",itemname,revSeq);fflush(stdout);
										}
									}
								
							   }

							}
					
					    }

				}	
					
		}
	//}
if(fptr1) fclose(fptr1); fptr1=NULL;
}
	return status;

}

