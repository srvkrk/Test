/*******************
*  File            :   tm_DML_ImplosionRpt.c
*  Created By      :   Vijay Khandare
*  Created On      :   10-06-2023
*  Purpose         :   DML Implosion Report...
*  TZ			   :   
*******************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdbool.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define MAX_SIZE 30000
#define STRING_LENGTH 30

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;		

void IMPLstrcat(char **src,char* dest)
{
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* replace(char *str, const char *find, const char *replace) 
{
    // Allocate memory for the new string
    char *result;
    int i, count = 0;
    int find_len = strlen(find);
    int replace_len = strlen(replace);

    // Count the number of times the 'find' substring occurs in the original string
    for (i = 0; str[i] != '\0'; i++) 
	{
        if (strstr(&str[i], find) == &str[i])
		{
            count++;
           // Jump index to the next occurrence of the 'find' substring
            i += find_len - 1;
        }
    }
    // Allocate memory for the new string
    result = (char *)MEM_alloc(i + count * (replace_len - find_len) + 1);  
    i = 0;
    while (*str)
	{
        // Compare the substring with the result
        if (strstr(str, find) == str) 
		{
            strcpy(&result[i], replace);
            i += replace_len;
            str += find_len;
        } 
		else 
	    {
            result[i++] = *str++;
        }
    }
    result[i] = '\0';
    //printf("Replaced string: %s\n", result);
    return result;
}

void setFixedSize(char **str, size_t size) 
{
    // Dynamically allocate memory for the string
    *str = (char *)MEM_realloc(*str, size + 1); // +1 for null terminator
    
    // If realloc fails, handle the error
    if (*str == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    
    // If the length of the string is less than the desired size, add spaces
    size_t len = strlen(*str);
    if (len < size) {
        memset(*str + len, ' ', size - len);
        (*str)[size] = '\0'; // Null-terminate the string
    }
    // If the length of the string is greater than the desired size, remove extra characters
    else if (len > size) {
        (*str)[size] = '\0'; // Null-terminate the string at the desired size
    }
}

bool isStringAlreadyCopied(char *targetStrings[STRING_LENGTH], int targetCount, char *str) 
{
	int  i = 0;
    for(i = 0; i < targetCount; i++) 
    {
        if(strcmp(targetStrings[i], str) == 0) 
    	{
            return true;
        }
    }
    return false;
}

char     commonStringsUnq[MAX_SIZE][STRING_LENGTH];
bool isStringAlreadyCopiedUnq(char targetStrings[][STRING_LENGTH], int targetCount, char *str)
{
        int  i = 0;
    for(i = 0; i < targetCount; i++)
    {
        if(strcmp(targetStrings[i], str) == 0)
        {
            return true;
        }
    }
    return false;
}

int tm_PartImplFn(tag_t PartItem,char* TaskName,char* PlantName,char* FileFormat,int AllPlantflag,int row_cnt,tag_t* AmdentableRowset,char** OutputCKD,char** OutputCargo,
char** OutputDefence,char** OutputEPA,char** OutputTipper,char** OutputWT,char** UniqueVC,char** AllVcOutput,int* CKDSum,
int* CargoSum,int* Defencesum,int* EPAsum,int* Tippersum,int* WTsum)
{
	
    tag_t	     GnrQryTag	               = NULLTAG;
    tag_t	     CntrlQryTag               = NULLTAG;
    
	tag_t	     RevRuleObjTag             = NULLTAG;
	char*	     CntRisionRule             = NULL;
	char         *PartNo                   = NULL;
	char         *PartRevSeq               = NULL;
	char         *PartRevSeqV              = NULL;
	char         *PartDrStaus              = NULL;
	char         *PartDesc                 = NULL;
	char         *PartDescV                = NULL;
	char         *PartType                 = NULL;
	char         *MakeBy                   = NULL;
	int          ALLUnqVcSum               = 0;
	int          ALLUnqVcSumUnq            = 0;
	
	int          n_ParentFound             = 0;
	int          *n_Parent                 = 0;
	tag_t        *ParentSet                = NULLTAG;
	
	//int CKDSum=0,CargoSum=0,Defencesum=0,EPAsum=0,Tippersum=0, WTsum=0;
	
	// Query Control Object and revision rule...................

	if(QRY_find2("General...", &CntrlQryTag));//API changed for 12.2 to 14.3 upgrade...
	if(CntrlQryTag != NULLTAG)
	{
		printf("query found\n");fflush(stdout);
	    int         Cntrlcnt              = 0;
	    tag_t       *CntrlObSet           = NULLTAG;


		char 		*CntrEntry[2] 	= 	{"Name","Type"};
	    char 		**Cntrvalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
	
	    Cntrvalues[0]				=	"RevisionRuleForDmlImpl";
	    Cntrvalues[1]				=	"Control Object";

		if(QRY_execute(CntrlQryTag,2,CntrEntry,Cntrvalues,&Cntrlcnt,&CntrlObSet));

		if(Cntrlcnt > 0)
	    {
	    	printf("\nControl Object found ......  :%d\n",Cntrlcnt);fflush(stdout);
            tag_t	     CntrlObjTag               = NULLTAG;
			CntrlObjTag = CntrlObSet[0];

			ITK_CALL(AOM_UIF_ask_value(CntrlObjTag,"t5_Userinfo1",&CntRisionRule));
	        printf("Control Object Revision Rule is = %s\n",CntRisionRule);fflush(stdout);
	    }
		else
		{
			printf("Control Object not found\n");fflush(stdout);
		}
	} 
	else
	{
        printf("Control object Query not found\n");fflush(stdout);
	}

	if(QRY_find2("General...", &GnrQryTag));//API changed for 12.2 to 14.3 upgrade...
	if(GnrQryTag != NULLTAG)
	{
		printf("query found\n");fflush(stdout);
		int         RevRuleCnt              = 0;
		tag_t       *RevRuleSet            = NULLTAG;

		char 		*RevruleEntry[2] 	= 	{"Name","Type"};
	    char 		**Revrulevalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
	
	    Revrulevalues[0]				=	CntRisionRule;
	    Revrulevalues[1]				=	"Revision Rule";

		if(QRY_execute(GnrQryTag,2,RevruleEntry,Revrulevalues,&RevRuleCnt,&RevRuleSet));

		if(RevRuleCnt > 0)
	    {
	        char*	     GetRevRule             = NULL;

			RevRuleObjTag = RevRuleSet[0];
			ITK_CALL(AOM_UIF_ask_value(RevRuleObjTag,"object_name",&GetRevRule));
	        printf("Revision Rule from Rev rule object is = %s\n",GetRevRule);fflush(stdout);
		}
		else
		{
			printf("Revision Rule not found\n");fflush(stdout);

		}
	} 
	else
	{
        printf("Revision Rule Query not found\n");fflush(stdout);
	}
	//....................................................................................................
	
	
	if(tc_strcmp(PlantName,"DWD")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(PartItem,"t5_DwdMakeBuyIndicator",&MakeBy));
		printf("DWD make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"JSR")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(PartItem,"t5_JsrMakeBuyIndicator",&MakeBy));
        printf("JSR make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"LKO")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(PartItem,"t5_LkoMakeBuyIndicator",&MakeBy));
        printf("LKO make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PNR")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(PartItem,"t5_PnrMakeBuyIndicator",&MakeBy));
        printf("PNR make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PUNE")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(PartItem,"t5_PunMakeBuyIndicator",&MakeBy));
    	printf("Pune make by is  = %s\n",MakeBy);fflush(stdout);
	}
	
	//Parts details.............................................................
	
	ITK_CALL(AOM_ask_value_string(PartItem,"item_id",&PartNo));
	printf("Part no is = %s\n",PartNo);fflush(stdout);
	
	ITK_CALL(AOM_UIF_ask_value(PartItem,"item_revision_id",&PartRevSeq));
	printf("Part revision/sequence no is = %s\n",PartRevSeq);fflush(stdout);
	
	PartRevSeqV=replace(PartRevSeq, ",", ";");
	
	ITK_CALL(AOM_ask_value_string(PartItem,"t5_PartStatus",&PartDrStaus));
	printf("Part DR status is = %s\n",PartDrStaus);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(PartItem,"current_desc",&PartDesc));
	printf("Part PartDesc is = %s\n",PartDesc);fflush(stdout);
    
	PartDescV = replace(PartDesc, ",", " ");
	
	ITK_CALL(AOM_ask_value_string(PartItem,"t5_PartType",&PartType));
	printf("Part PartType is = %s\n",PartType);fflush(stdout);
	
	//...........................................................................


    if(AllPlantflag == 1)
    { 
	    //ALL VCS ............................................................................................................................................
        IMPLstrcat(AllVcOutput,"    Impl of Part : ");
        IMPLstrcat(AllVcOutput,PartNo);
        IMPLstrcat(AllVcOutput,"\n");
        IMPLstrcat(AllVcOutput,"    Revision     : ");
        IMPLstrcat(AllVcOutput,PartRevSeqV);
        IMPLstrcat(AllVcOutput,"\n");
        IMPLstrcat(AllVcOutput,"    Description  : ");
        IMPLstrcat(AllVcOutput,PartDescV);
        IMPLstrcat(AllVcOutput,"\n");
        IMPLstrcat(AllVcOutput,"    DR Status    : ");
        IMPLstrcat(AllVcOutput,PartDrStaus);
        IMPLstrcat(AllVcOutput,"\n");
        IMPLstrcat(AllVcOutput,"    Part Type    : ");
        IMPLstrcat(AllVcOutput,PartType);
        IMPLstrcat(AllVcOutput,"\n");
        IMPLstrcat(AllVcOutput,"    ===========================================\n");
		
		if(tc_strcmp(FileFormat,".csv") == 0)
        {
            IMPLstrcat(AllVcOutput,"    ===============       ,       ==================================,           ==========   ,           =================   ,\n");
            IMPLstrcat(AllVcOutput,"        VC LIST           ,                  DESCRIPTION            ,            DR STATUS   ,            RELEASE STATUS   ,\n");
            IMPLstrcat(AllVcOutput,"    ===============       ,       ==================================,           ==========   ,           =================   ,\n");
            //......................................................................................................................................................................
		}
		else if(tc_strcmp(FileFormat,".txt") == 0)
        {
			IMPLstrcat(AllVcOutput,"    =============         ==================================       ==========        =================    \n");
            IMPLstrcat(AllVcOutput,"        VC LIST                     DESCRIPTION                    DR STATUS         RELEASE STATUS    \n");
            IMPLstrcat(AllVcOutput,"    =============         ==================================       ==========        =================    \n");
            //......................................................................................................................................................................
		}
		else
		{
			
		}
	}
	else
	{     
		if(tc_strcmp(FileFormat,".txt") == 0)
		{
		    //CKD.............................................................................................................................................
            IMPLstrcat(OutputCKD,"    Impl of Part : ");
            IMPLstrcat(OutputCKD,PartNo);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    Revision     : ");
            IMPLstrcat(OutputCKD,PartRevSeqV);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    Description  : ");
            IMPLstrcat(OutputCKD,PartDescV);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    DR Status    : ");
            IMPLstrcat(OutputCKD,PartDrStaus);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    Part Type    : ");
            IMPLstrcat(OutputCKD,PartType);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    Make By      : ");
            IMPLstrcat(OutputCKD,MakeBy);
            IMPLstrcat(OutputCKD,"\n");
            IMPLstrcat(OutputCKD,"    ===========================================\n");


		    IMPLstrcat(OutputCKD,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputCKD,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputCKD,"    ===============               ==================================            ==========    \n");
 
		    
            //Cargo.............................................................................................................................................
            IMPLstrcat(OutputCargo,"    Impl of Part : ");
            IMPLstrcat(OutputCargo,PartNo);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    Revision     : ");
            IMPLstrcat(OutputCargo,PartRevSeqV);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    Description  : ");
            IMPLstrcat(OutputCargo,PartDescV);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    DR Status    : ");
            IMPLstrcat(OutputCargo,PartDrStaus);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    Part Type    : ");
            IMPLstrcat(OutputCargo,PartType);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    Make By      : ");
            IMPLstrcat(OutputCargo,MakeBy);
            IMPLstrcat(OutputCargo,"\n");
            IMPLstrcat(OutputCargo,"    ===========================================\n");

		    IMPLstrcat(OutputCargo,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputCargo,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputCargo,"    ===============               ==================================            ==========    \n");

            //Defence.............................................................................................................................................
            IMPLstrcat(OutputDefence,"    Impl of Part : ");
            IMPLstrcat(OutputDefence,PartNo);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    Revision     : ");
            IMPLstrcat(OutputDefence,PartRevSeqV);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    Description  : ");
            IMPLstrcat(OutputDefence,PartDescV);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    DR Status    : ");
            IMPLstrcat(OutputDefence,PartDrStaus);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    Part Type    : ");
            IMPLstrcat(OutputDefence,PartType);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    Make By      : ");
            IMPLstrcat(OutputDefence,MakeBy);
            IMPLstrcat(OutputDefence,"\n");
            IMPLstrcat(OutputDefence,"    ===========================================\n");

		    IMPLstrcat(OutputDefence,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputDefence,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputDefence,"    ===============               ==================================            ==========    \n");

            //EPA.............................................................................................................................................
            IMPLstrcat(OutputEPA,"    Impl of Part : ");
            IMPLstrcat(OutputEPA,PartNo);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    Revision     : ");
            IMPLstrcat(OutputEPA,PartRevSeqV);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    Description  : ");
            IMPLstrcat(OutputEPA,PartDescV);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    DR Status    : ");
            IMPLstrcat(OutputEPA,PartDrStaus);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    Part Type    : ");
            IMPLstrcat(OutputEPA,PartType);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    Make By      : ");
            IMPLstrcat(OutputEPA,MakeBy);
            IMPLstrcat(OutputEPA,"\n");
            IMPLstrcat(OutputEPA,"    ===========================================\n");

		    IMPLstrcat(OutputEPA,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputEPA,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputEPA,"    ===============               ==================================            ==========    \n");

            //Tipper.............................................................................................................................................
            IMPLstrcat(OutputTipper,"    Impl of Part : ");
            IMPLstrcat(OutputTipper,PartNo);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    Revision     : ");
            IMPLstrcat(OutputTipper,PartRevSeqV);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    Description  : ");
            IMPLstrcat(OutputTipper,PartDescV);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    DR Status    : ");
            IMPLstrcat(OutputTipper,PartDrStaus);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    Part Type    : ");
            IMPLstrcat(OutputTipper,PartType);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    Make By      : ");
            IMPLstrcat(OutputTipper,MakeBy);
            IMPLstrcat(OutputTipper,"\n");
            IMPLstrcat(OutputTipper,"    ===========================================\n");

		    IMPLstrcat(OutputTipper,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputTipper,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputTipper,"    ===============               ==================================            ==========    \n");

            //WT.............................................................................................................................................
            IMPLstrcat(OutputWT,"    Impl of Part : ");
            IMPLstrcat(OutputWT,PartNo);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    Revision     : ");
            IMPLstrcat(OutputWT,PartRevSeqV);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    Description  : ");
            IMPLstrcat(OutputWT,PartDescV);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    DR Status    : ");
            IMPLstrcat(OutputWT,PartDrStaus);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    Part Type    : ");
            IMPLstrcat(OutputWT,PartType);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    Make By      : ");
            IMPLstrcat(OutputWT,MakeBy);
            IMPLstrcat(OutputWT,"\n");
            IMPLstrcat(OutputWT,"    ===========================================\n");

		    IMPLstrcat(OutputWT,"    ===============               ==================================            ==========    \n");
            IMPLstrcat(OutputWT,"        VC LIST                              DESCRIPTION                         DR STATUS    \n");
            IMPLstrcat(OutputWT,"    ===============               ==================================            ==========    \n");
	    }
	}
	
	int          RevCount                  = 0;
	tag_t        ItemMaster                = NULLTAG;
	tag_t        PartLtstRev               = NULLTAG;
	tag_t        *PartLtstRevSet           = NULLTAG;
	char         *PartRlzStat              = NULL;
	
	//ITK_CALL(PS_where_used_all(PartItem,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	//ITK_CALL(PS_where_used_all(PartItem,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	ITK_CALL(PS_where_used_configured(PartItem,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	if(n_ParentFound > 0)
    {
		
	}
	else
	{
		ITEM_ask_item_of_rev(PartItem, &ItemMaster);
	    //AOM_ask_value_string(ItemMaster, "item_id", &ItemMaster);
		
		ITK_CALL(ITEM_ask_latest_rev(ItemMaster,&PartLtstRev));
		
		ITK_CALL(AOM_UIF_ask_value(PartLtstRev,"release_status_list",&PartRlzStat));
		printf("Part PartRlzStat is ... = %s\n",PartRlzStat);fflush(stdout);
		if(tc_strstr(PartRlzStat,"ERC Released")!= NULL)
		{
		    ITK_CALL(PS_where_used_configured(PartLtstRev,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
		}
		else
		{
			ITK_CALL(ITEM_list_all_revs(ItemMaster,&RevCount,&PartLtstRevSet));
			
			if(RevCount > 0)
			{
				printf("No of rev is ... = %d\n",RevCount);fflush(stdout);
				int RevItr = 0;
				for(RevItr = 0; RevItr < RevCount; RevItr++)
				{
					tag_t     PrtRevObj         = NULLTAG;
					char      *PrtRlzVal        = NULL;
					char      *PrtRevSeq        = NULL;
					PrtRevObj = PartLtstRevSet[RevItr];
					
					ITK_CALL(AOM_UIF_ask_value(PrtRevObj,"release_status_list",&PrtRlzVal));
					//printf("Part PrtRlzVal is ... = %s\n",PrtRlzVal);fflush(stdout);	
					
					if(tc_strstr(PrtRlzVal,"ERC Released")!= NULL)
		            {
						ITK_CALL(AOM_UIF_ask_value(PrtRevObj,"item_revision_id",&PrtRevSeq));
	                    printf("PrtRevSeq value is ... = %s\n",PrtRevSeq);fflush(stdout);
						
		                ITK_CALL(PS_where_used_configured(PrtRevObj,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
		            }
					
				}
			}
			
		}
	}
	
	printf("Number of Parent found part is  = %d\n",n_ParentFound);fflush(stdout);
	
    if(n_ParentFound > 0)
    {
		
		char **commonStrings = (char **)MEM_alloc(n_ParentFound * sizeof(char *));
	    
	    if (commonStrings == NULL) 
	    {
            printf("Memory allocation failed\n");
            return 1;
	    }
        int itr = 0;
	    for (itr = 0; itr < n_ParentFound; itr++) 
	    {
            commonStrings[itr] = (char *)malloc(STRING_LENGTH * sizeof(char));
            if(commonStrings[itr] == NULL) 
	    	{
            printf("Memory allocation failed\n");
            return 1;
	    	}
	    }
	    
    	//Compare Amden vc .........................
    	tag_t       AmdentableRow             = NULLTAG;
    	char        *AmdenVC                  = NULL;
    	char        *AmdenAgency              = NULL;
    	int index;
        for( index = 0; index < n_ParentFound; index++ )
        {
            if ( index == n_ParentFound - 1 || n_Parent[index] >= n_Parent[index+1] )
            {
    
    	        tag_t     ParentItem        = NULLTAG;
    	        char      *ParentNo         = NULL;
    	        char      *ParentType       = NULL;
    	        char      *ParentDR         = NULL;
    	        char      *ParentDesc       = NULL;
    	        char      *ParentDescV      = NULL;
				char      *ParentRlzS       = NULL;
				char      *ParentRlzSV      = NULL;
				char      *ParentRlzSV1     = NULL;
				char      *ParentPrtType    = NULL;
				char      *RevisionId       = NULL; 	

    	        ParentItem = ParentSet[index];

    	        ITK_CALL(AOM_ask_value_string(ParentItem,"item_id",&ParentNo));
                //printf("Parent  is = %s\n",ParentNo);fflush(stdout);
    	        ITK_CALL(AOM_ask_value_string(ParentItem,"object_type",&ParentType));
                //printf("Parent type is = %s\n",ParentType);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PartType",&ParentPrtType));
				//printf("Parent Part type is..... = %s\n",ParentPrtType);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(ParentItem,"item_revision_id",&RevisionId));
				//printf("Parent Revision Id  is..... = %s\n",RevisionId);fflush(stdout);

    	        ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PartStatus",&ParentDR));
                // printf("Parent DR status is = %s\n",ParentDR);fflush(stdout);
    	        ITK_CALL(AOM_ask_value_string(ParentItem,"object_desc",&ParentDesc));
    	        ParentDescV=replace(ParentDesc, ",", " ");

                setFixedSize(&ParentDescV, 30);
				
				ITK_CALL(AOM_UIF_ask_value(ParentItem,"release_status_list",&ParentRlzS));
				ParentRlzSV=replace(ParentRlzS, ",", " ");
				ParentRlzSV1=replace(ParentRlzSV, "ERC Review", " ");
    	        //printf("Parent Desc is = %s\n",ParentDescV);fflush(stdout);
				char* ParentMakeBuy = NULL;
				if(tc_strcmp(PlantName,"DWD")==0)
				{
					ITK_CALL(AOM_ask_value_string(ParentItem,"t5_DwdMakeBuyIndicator",&ParentMakeBuy));
				    //printf("DWD make by is  = %s\n",ParentMakeBuy);fflush(stdout);
				}
				else if(tc_strcmp(PlantName,"JSR")==0)
				{
					ITK_CALL(AOM_ask_value_string(ParentItem,"t5_JsrMakeBuyIndicator",&ParentMakeBuy));
					//printf("JSR make by is  = %s\n",ParentMakeBuy);fflush(stdout);
				}
				else if(tc_strcmp(PlantName,"LKO")==0)
				{
					ITK_CALL(AOM_ask_value_string(ParentItem,"t5_LkoMakeBuyIndicator",&ParentMakeBuy));
				    //printf("LKO make by is  = %s\n",ParentMakeBuy);fflush(stdout);
				}
				else if(tc_strcmp(PlantName,"PNR")==0)
				{
					ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PnrMakeBuyIndicator",&ParentMakeBuy));
				    //printf("PNR make by is  = %s\n",ParentMakeBuy);fflush(stdout);
				}
				else if(tc_strcmp(PlantName,"PUNE")==0)
				{
					ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PunMakeBuyIndicator",&ParentMakeBuy));
				    //printf("Pune make by is  = %s\n",ParentMakeBuy);fflush(stdout);
				}


				//if((tc_strcmp(ParentPrtType,"VC") == 0 || tc_strcmp(ParentPrtType,"VCCR") == 0) && tc_strstr(ParentRlzS,"ERC Released")!= NULL)
				if( tc_strstr(ParentRlzS,"ERC Released")!= NULL && (tc_strcmp(ParentMakeBuy,"E99")==0 || tc_strcmp(ParentMakeBuy,"E98")== 0))
                {
					if(!isStringAlreadyCopied(commonStrings, ALLUnqVcSum, ParentNo)) 
                    {
					    strcpy(commonStrings[ALLUnqVcSum++],ParentNo);
					
					    if(AllPlantflag == 1)
                        {
							if(tc_strcmp(FileFormat,".csv") == 0)
                            {
					    	
					    	    //ALL VCS..........................................
					    	    IMPLstrcat(AllVcOutput,"    ");
    	                        IMPLstrcat(AllVcOutput,ParentNo);
    	                        IMPLstrcat(AllVcOutput,",");
    	                        IMPLstrcat(AllVcOutput,"                 ");
    	                        IMPLstrcat(AllVcOutput,ParentDescV);
    	                        IMPLstrcat(AllVcOutput,",");
    	                        IMPLstrcat(AllVcOutput,"             ");
    	                        IMPLstrcat(AllVcOutput,ParentDR);
    	                        IMPLstrcat(AllVcOutput,",");
					    	    IMPLstrcat(AllVcOutput,ParentRlzSV1);
    	                        IMPLstrcat(AllVcOutput,",");
    	                        IMPLstrcat(AllVcOutput,"\n");
					    	    //....................................................
							}
							else if(tc_strcmp(FileFormat,".txt") == 0)
                            {
								//ALL VCS..........................................
					    	    IMPLstrcat(AllVcOutput,"    ");
    	                        IMPLstrcat(AllVcOutput,ParentNo);
    	                        IMPLstrcat(AllVcOutput,"            ");
    	                        IMPLstrcat(AllVcOutput,ParentDescV);
    	                        IMPLstrcat(AllVcOutput,"            ");
    	                        IMPLstrcat(AllVcOutput,ParentDR);
								IMPLstrcat(AllVcOutput,"             ");
					    	    IMPLstrcat(AllVcOutput,ParentRlzSV1);
    	                        IMPLstrcat(AllVcOutput,"\n");
					    	    //....................................................
							}
							else
							{
								
							}
					    	
					    }
					    else
					    {
					        int Amdenitr = 0;
    		                for(Amdenitr = 0 ; Amdenitr < row_cnt ; Amdenitr++)
    	                    {
								char* VCInProd=NULL;
    	                        AmdentableRow = AmdentableRowset[Amdenitr];
                                ITK_CALL(AOM_ask_value_string(AmdentableRow,"t5_AmdPartNumber",&AmdenVC));
    	                        //printf("\n Amden VC for Compare ... = %s\n",AmdenVC);fflush(stdout);    
    	                        ITK_CALL(AOM_ask_value_string(AmdentableRow,"t5_AmdAgency",&AmdenAgency));
								ITK_CALL(AOM_ask_value_string(AmdentableRow,"t5_AmdInProduction",&VCInProd));
    	                        //printf("\n Amden agency .... = %s\n",AmdenAgency);fflush(stdout);
								if(tc_strcmp(VCInProd,"N") == 0)
								{
									continue;
								}
    		              
    	                    	if(tc_strcmp(FileFormat,".csv") == 0)
                                {
								    if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"CKD") == 0))
    	                    	    {

                                        //CKD
										IMPLstrcat(OutputCKD,TaskName);
										IMPLstrcat(OutputCKD,",");
    	                    	    	IMPLstrcat(OutputCKD,PartNo);
									    IMPLstrcat(OutputCKD," ");
                                        IMPLstrcat(OutputCKD,PartRevSeqV);
                                        IMPLstrcat(OutputCKD,",");
                                        IMPLstrcat(OutputCKD,PartDescV);
                                        IMPLstrcat(OutputCKD,",");
                                        IMPLstrcat(OutputCKD,PartDrStaus);
                                        IMPLstrcat(OutputCKD,",");
                                        IMPLstrcat(OutputCKD,PartType);
                                        IMPLstrcat(OutputCKD,",");
    	                	    	    IMPLstrcat(OutputCKD,ParentNo);
    	                	    	    IMPLstrcat(OutputCKD,",");
    	                	    	    IMPLstrcat(OutputCKD,ParentDescV);
    	                	    	    IMPLstrcat(OutputCKD,",");
    	                	    	    IMPLstrcat(OutputCKD,ParentDR);
    	                	    	    IMPLstrcat(OutputCKD,"\n");
									    
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *CKDSum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*CKDSum],ParentNo);
									    	
									    	*CKDSum = *CKDSum+1;
    	                	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,"CKD");
    	                	    	        IMPLstrcat(UniqueVC,"\n");
									    }
    		                	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Cargo") == 0))
    	                    	    {
    	                    	    	//*CargoSum = *CargoSum+1;
    	                    	    
    	                    	    	//Cargo
										IMPLstrcat(OutputCargo,TaskName);
										IMPLstrcat(OutputCargo,",");
                                        IMPLstrcat(OutputCargo,PartNo);
                                        IMPLstrcat(OutputCargo," ");
                                        IMPLstrcat(OutputCargo,PartRevSeqV);
                                        IMPLstrcat(OutputCargo,",");
                                        IMPLstrcat(OutputCargo,PartDescV);
                                        IMPLstrcat(OutputCargo,",");
                                        IMPLstrcat(OutputCargo,PartDrStaus);
                                        IMPLstrcat(OutputCargo,",");
                                        IMPLstrcat(OutputCargo,PartType);
                                        IMPLstrcat(OutputCargo,",");
    	                	    	    IMPLstrcat(OutputCargo,ParentNo);
    	                	    	    IMPLstrcat(OutputCargo,",");
    	                	    	    IMPLstrcat(OutputCargo,ParentDescV);
    	                	    	    IMPLstrcat(OutputCargo,",");
    	                	    	    IMPLstrcat(OutputCargo,ParentDR);
    	                	    	    IMPLstrcat(OutputCargo,"\n");
									    
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *CargoSum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*CargoSum],ParentNo);
									    	*CargoSum = *CargoSum+1;
									    
    		            	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,"Cargo");
    	                	    	        IMPLstrcat(UniqueVC,"\n");
									    }
    	                    	      
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Defence") == 0))
    	                    	    {
    	                    	        //*Defencesum = *Defencesum+1;
								    
    	                    	        //Defence
										IMPLstrcat(OutputDefence,TaskName);
										IMPLstrcat(OutputDefence,",");
    	                	            IMPLstrcat(OutputDefence,PartNo);
                                        IMPLstrcat(OutputDefence," ");
                                        IMPLstrcat(OutputDefence,PartRevSeqV);
                                        IMPLstrcat(OutputDefence,",");
                                        IMPLstrcat(OutputDefence,PartDescV);
                                        IMPLstrcat(OutputDefence,",");
                                        IMPLstrcat(OutputDefence,PartDrStaus);
                                        IMPLstrcat(OutputDefence,",");
                                        IMPLstrcat(OutputDefence,PartType);
                                        IMPLstrcat(OutputDefence,",");
    	                	    	    IMPLstrcat(OutputDefence,ParentNo);
    	                	    	    IMPLstrcat(OutputDefence,",");
    	                	    	    IMPLstrcat(OutputDefence,ParentDescV);
    	                	    	    IMPLstrcat(OutputDefence,",");
    	                	    	    IMPLstrcat(OutputDefence,ParentDR);
    	                	    	    IMPLstrcat(OutputDefence,"\n");
    	                	            
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *Defencesum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*Defencesum],ParentNo);
									    	*Defencesum = *Defencesum+1;
									    
    		            	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,"Defence");
    	                	    	        IMPLstrcat(UniqueVC,"\n");
									    }
					    		    	
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && ((tc_strcmp(AmdenAgency,"EPA") == 0) || 
									(tc_strcmp(AmdenAgency,"VEHICLE") == 0) || (tc_strcmp(AmdenAgency,"Vehicle") == 0) || 
								    (tc_strcmp(AmdenAgency,"Maxicab") == 0) || (tc_strcmp(AmdenAgency,"ACE GOLD RDE") == 0) ||
									(tc_strcmp(AmdenAgency,"EPA RDE") == 0)))
    	                    	    {
    	                    	        //*EPAsum = *EPAsum+1;
    	                    	        //EPA
										IMPLstrcat(OutputEPA,TaskName);
										IMPLstrcat(OutputEPA,",");
    	                	            IMPLstrcat(OutputEPA,PartNo);
                                        IMPLstrcat(OutputEPA," ");
                                        IMPLstrcat(OutputEPA,PartRevSeqV);
                                        IMPLstrcat(OutputEPA,",");
                                        IMPLstrcat(OutputEPA,PartDescV);
                                        IMPLstrcat(OutputEPA,",");
                                        IMPLstrcat(OutputEPA,PartDrStaus);
                                        IMPLstrcat(OutputEPA,",");
                                        IMPLstrcat(OutputEPA,PartType);
                                        IMPLstrcat(OutputEPA,",");
    	                	    	    IMPLstrcat(OutputEPA,ParentNo);
    	                	    	    IMPLstrcat(OutputEPA,",");
    	                	    	    IMPLstrcat(OutputEPA,ParentDescV);
    	                	    	    IMPLstrcat(OutputEPA,",");
    	                	    	    IMPLstrcat(OutputEPA,ParentDR);
    	                	    	    IMPLstrcat(OutputEPA,"\n");
    	                	            
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *EPAsum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*EPAsum],ParentNo);
									    	*EPAsum = *EPAsum+1;
									    
    		            	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,"EPA");
    	                	    	        IMPLstrcat(UniqueVC,"\n");
									    }
					    		    	
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Tipper") == 0))
    	                    	    {
    	                    	        //*Tippersum = *Tippersum+1;
    	                    	        
    	                    	        //Tipper
										IMPLstrcat(OutputTipper,TaskName);
										IMPLstrcat(OutputTipper,",");
    	                	            IMPLstrcat(OutputTipper,PartNo);
                                        IMPLstrcat(OutputTipper," ");
                                        IMPLstrcat(OutputTipper,PartRevSeqV);
                                        IMPLstrcat(OutputTipper,",");
                                        IMPLstrcat(OutputTipper,PartDescV);
                                        IMPLstrcat(OutputTipper,",");
                                        IMPLstrcat(OutputTipper,PartDrStaus);
                                        IMPLstrcat(OutputTipper,",");
                                        IMPLstrcat(OutputTipper,PartType);
                                        IMPLstrcat(OutputTipper,",");
    	                	    	    IMPLstrcat(OutputTipper,ParentNo);
    	                	    	    IMPLstrcat(OutputTipper,",");
    	                	    	    IMPLstrcat(OutputTipper,ParentDescV);
    	                	    	    IMPLstrcat(OutputTipper,",");
    	                	    	    IMPLstrcat(OutputTipper,ParentDR);
    	                	    	    IMPLstrcat(OutputTipper,"\n");
    	                	            
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *Tippersum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*Tippersum],ParentNo);
									    	*Tippersum = *Tippersum+1;
									    
    		            	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,"Tipper");
    	                	    	        IMPLstrcat(UniqueVC,"\n");
									    }
    	                    	    
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"WT") == 0))
    	                    	    {
    	                    	        //*WTsum = *WTsum+1;
    	                    	        //WT
										IMPLstrcat(OutputWT,TaskName);
										IMPLstrcat(OutputWT,",");
    	                	            IMPLstrcat(OutputWT,PartNo);
                                        IMPLstrcat(OutputWT," ");
                                        IMPLstrcat(OutputWT,PartRevSeqV);
                                        IMPLstrcat(OutputWT,",");
                                        IMPLstrcat(OutputWT,PartDescV);
                                        IMPLstrcat(OutputWT,",");
                                        IMPLstrcat(OutputWT,PartDrStaus);
                                        IMPLstrcat(OutputWT,",");
                                        IMPLstrcat(OutputWT,PartType);
                                        IMPLstrcat(OutputWT,",");
    	                	    	    IMPLstrcat(OutputWT,ParentNo);
    	                	    	    IMPLstrcat(OutputWT,",");
    	                	    	    IMPLstrcat(OutputWT,ParentDescV);
    	                	    	    IMPLstrcat(OutputWT,",");
    	                	    	    IMPLstrcat(OutputWT,ParentDR);
    	                	    	    IMPLstrcat(OutputWT,"\n");
    	                	            
									    if(!isStringAlreadyCopiedUnq(commonStringsUnq, *WTsum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*WTsum],ParentNo);
									    	*WTsum = *WTsum+1;
									    
    		            	    	        IMPLstrcat(UniqueVC,ParentNo);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,RevisionId);
									    	IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDescV);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(UniqueVC,ParentDR);
    	                	    	        IMPLstrcat(UniqueVC,",");
    	                	    	        IMPLstrcat(OutputWT,"WT");
    	                	    	        IMPLstrcat(OutputWT,"\n");
									    }
    	                    	    
    	                    	    }
					        	    else
					        	    {
								    
					        	    }
								}
								else if(tc_strcmp(FileFormat,".txt") == 0)
                                {
									if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"CKD") == 0))
    	                    	    {
								    
    	                    	    	//*CKDSum = *CKDSum+1;
                                        //CKD..................................................
    	                    	    	IMPLstrcat(OutputCKD,"    ");
    	                    	    	IMPLstrcat(OutputCKD,ParentNo);
    	                    	    	IMPLstrcat(OutputCKD,"                 ");
    	                    	    	IMPLstrcat(OutputCKD,ParentDescV);
    	                    	    	IMPLstrcat(OutputCKD,"                    ");
    	                    	    	IMPLstrcat(OutputCKD,ParentDR);
    	                    	    	IMPLstrcat(OutputCKD,"\n");
								    
								    
    		                	    	if(!isStringAlreadyCopiedUnq(commonStringsUnq, *CKDSum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*CKDSum],ParentNo);
											*CKDSum = *CKDSum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"CKD");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
								    
    	                    	    	//.........................................................
    		                	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Cargo") == 0))
    	                    	    {
    	                    	    	//*CargoSum = *CargoSum+1;
    	                    	    
    	                    	    	//Cargo..................................................
    	                    	    	IMPLstrcat(OutputCargo,"    ");
    	                    	    	IMPLstrcat(OutputCargo,ParentNo);
    	                    	    	IMPLstrcat(OutputCargo,"                 ");
    	                    	    	IMPLstrcat(OutputCargo,ParentDescV);
    	                    	    	IMPLstrcat(OutputCargo,"                    ");
    	                    	    	IMPLstrcat(OutputCargo,ParentDR);
    	                    	    	IMPLstrcat(OutputCargo,"\n");
								    
										if(!isStringAlreadyCopiedUnq(commonStringsUnq, *CargoSum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*CargoSum],ParentNo);
											*CargoSum = *CargoSum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"Cargo");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
    	                    	      
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Defence") == 0))
    	                    	    {
    	                    	        //*Defencesum = *Defencesum+1;
								    
    	                    	        //Defence..................................................
    	                    	        IMPLstrcat(OutputDefence,"    ");
    	                    	        IMPLstrcat(OutputDefence,ParentNo);
    	                    	        IMPLstrcat(OutputDefence,"                 ");
    	                    	        IMPLstrcat(OutputDefence,ParentDescV);
    	                    	        IMPLstrcat(OutputDefence,"                    ");
    	                    	        IMPLstrcat(OutputDefence,ParentDR);
    	                    	        IMPLstrcat(OutputDefence,"\n");
    	                    	        
										if(!isStringAlreadyCopiedUnq(commonStringsUnq, *Defencesum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*Defencesum],ParentNo);
											*Defencesum = *Defencesum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"Defence");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
					    		    	
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && ((tc_strcmp(AmdenAgency,"EPA") == 0) || 
									(tc_strcmp(AmdenAgency,"VEHICLE") == 0) || (tc_strcmp(AmdenAgency,"Vehicle") == 0) || 
								    (tc_strcmp(AmdenAgency,"Maxicab") == 0) || (tc_strcmp(AmdenAgency,"ACE GOLD RDE") == 0) ||
									(tc_strcmp(AmdenAgency,"EPA RDE") == 0)))
									{
    	                    	        //*EPAsum = *EPAsum+1;
    	                    	        //EPA..................................................
    	                    	        IMPLstrcat(OutputEPA,"    ");
    	                    	        IMPLstrcat(OutputEPA,ParentNo);
    	                    	        IMPLstrcat(OutputEPA,"                 ");
    	                    	        IMPLstrcat(OutputEPA,ParentDescV);
    	                    	        IMPLstrcat(OutputEPA,"                    ");
    	                    	        IMPLstrcat(OutputEPA,ParentDR);
    	                    	        IMPLstrcat(OutputEPA,"\n");
    	                    	        
										if(!isStringAlreadyCopiedUnq(commonStringsUnq, *EPAsum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*EPAsum],ParentNo);
											*EPAsum = *EPAsum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"EPA");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
					    		    	
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Tipper") == 0))
    	                    	    {
    	                    	        //*Tippersum = *Tippersum+1;
    	                    	        
    	                    	        //Tipper..................................................
    	                    	        IMPLstrcat(OutputTipper,"    ");
    	                    	        IMPLstrcat(OutputTipper,ParentNo);
    	                    	        IMPLstrcat(OutputTipper,"                 ");
    	                    	        IMPLstrcat(OutputTipper,ParentDescV);
    	                    	        IMPLstrcat(OutputTipper,"                    ");
    	                    	        IMPLstrcat(OutputTipper,ParentDR);
    	                    	        IMPLstrcat(OutputTipper,"\n");
    	                    	        
										if(!isStringAlreadyCopiedUnq(commonStringsUnq, *Tippersum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*Tippersum],ParentNo);
											*Tippersum = *Tippersum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"Tipper");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
    	                    	    
    	                    	    }
    	                    	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"WT") == 0))
    	                    	    {
    	                    	        //*WTsum = *WTsum+1;
    	                    	        //WT..................................................
    	                    	        IMPLstrcat(OutputWT,"    ");
    	                    	        IMPLstrcat(OutputWT,ParentNo);
    	                    	        IMPLstrcat(OutputWT,"                 ");
    	                    	        IMPLstrcat(OutputWT,ParentDescV);
    	                    	        IMPLstrcat(OutputWT,"                    ");
    	                    	        IMPLstrcat(OutputWT,ParentDR);
    	                    	        IMPLstrcat(OutputWT,"\n");
    	                    	        
										if(!isStringAlreadyCopiedUnq(commonStringsUnq, *WTsum, ParentNo)) 
                                        {
					                        strcpy(commonStringsUnq[*WTsum],ParentNo);
											*WTsum = *WTsum+1;

    		                	    	    IMPLstrcat(UniqueVC,"    ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentNo);
	    	    				    	    IMPLstrcat(UniqueVC,"      ");
										    IMPLstrcat(UniqueVC,RevisionId);
	    	    				    	    IMPLstrcat(UniqueVC,"       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	    IMPLstrcat(UniqueVC,"                       ");
	    	    				    	    IMPLstrcat(UniqueVC,ParentDR);
	    	    				    	    IMPLstrcat(UniqueVC,"                    ");
	    	    				    	    IMPLstrcat(UniqueVC,"WT");
	    	    				    	    IMPLstrcat(UniqueVC,"\n");
										}
    	                    	    
    	                    	    }
					        	    else
					        	    {
								    
					        	    }
								}
								else
								{
									
								}
    			            }
					    }
					}
				}
				else
				{

				}
    		}					
        }
        //........................................................................................	
		MEM_free(commonStrings);
    }
	else
    {
    	printf("\n No Parents found under Part......\n");fflush(stdout);
    }	
	
	printf("CKD sum [%d] Cargo sum [%d] Defence sum [%d] EPA sum [%d] Tipper sum [%d] WT sum [%d]\n",*CKDSum,*CargoSum,*Defencesum,*EPAsum,*Tippersum,*WTsum);fflush(stdout);

	if(AllPlantflag != 1)
    {
        IMPLstrcat(OutputCKD,"    \n");
        IMPLstrcat(OutputCargo,"    \n");
        IMPLstrcat(OutputDefence,"    \n");
        IMPLstrcat(OutputEPA,"    \n");
        IMPLstrcat(OutputTipper,"    \n");
        IMPLstrcat(OutputWT,"    \n");
	}
	return ITK_ok;
}

int tm_DML_ImplosionRpt(char *InputERCDML,char *PlantName,char **output,char *Revision,char * FileFormat)
{
	printf("Inside the function of tm_DML_ImplosionRptFn\n");fflush(stdout);
	tag_t	QryTag	               = NULLTAG;
	tag_t	*ERCDMLSet	           = NULLTAG;

	//char    **qry_entries	       = NULL;
    //char    **qry_values	       = NULL;

	char     *OutputCKD			 = NULL;
    char     *OutputCargo	     = NULL;
    char     *OutputDefence	     = NULL;
    char     *OutputEPA			 = NULL;
    char     *OutputTipper		 = NULL;
    char     *OutputWT			 = NULL;
    char     *UniqueVC			 = NULL;
	//TZ Changes......
	char     *AllVcOutput		 = NULL;
	int      AllPlantflag        = 0;
	int      SummaryFlag         = 0;
	
	int CKDSumS=0,CargoSumS=0,DefencesumS=0,EPAsumS=0,TippersumS=0, WTsumS=0;
	
	int CKDSumF=0,CargoSumF=0,DefencesumF=0,EPAsumF=0,TippersumF=0, WTsumF=0;
	
	//..................................................................
    
    OutputCKD = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputCargo = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputDefence = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputEPA = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputTipper = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputWT = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    UniqueVC = (char *) MEM_alloc( 10000000 * sizeof(char*) );
	//TZ Changes....................................................
	AllVcOutput = (char *) MEM_alloc( 10000000 * sizeof(char*) );

	tc_strcpy(OutputCKD,"");
	tc_strcpy(OutputCargo,"");
	tc_strcpy(OutputDefence,"");
	tc_strcpy(OutputEPA,"");
	tc_strcpy(OutputTipper,"");
	tc_strcpy(OutputWT,"");
	tc_strcpy(UniqueVC,"");
	//TZ Changes....................................................
	tc_strcpy(AllVcOutput,"");

	int 	ERCDMLCount		       = 0;
	
	printf("Input DML no is  :%s\n",InputERCDML);fflush(stdout);
	printf("Input Plant name is :%s\n",PlantName);fflush(stdout);
	printf("\nInput ERC DML is %s\n",InputERCDML);fflush(stdout);
	printf("\nInput revision  is... %s\n",Revision);fflush(stdout);
	printf("\nInput FileFormat  is... %s\n",FileFormat);fflush(stdout);
	
	//All plants ..................................................
	if(tc_strcmp(PlantName,"All Plant(Independent of AMDEN)")==0)
	{
		AllPlantflag = 1;
	}
	//........................................................
	
	//Amden Query ........................................................
	
	char     *AmdenTname			 = NULL;
	AmdenTname = (char *) MEM_alloc( 5 * sizeof(char*) );

	if(tc_strcmp(PlantName,"JSR")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_JSR");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"LKO")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_LKN");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"DWD")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_DWD");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PNR")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_PNR");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PUNE")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_PUNE");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else
	{
		printf("\n Inside else ...");fflush(stdout);
	}
	//......................................................................
	
	int         AmdenCnt              = 0;
	int         row_cnt               = 0;
	tag_t       *Amdentableset        = NULLTAG;
	tag_t       Amdentable            = NULLTAG;
	tag_t       *AmdentableRowset     = NULLTAG;
	tag_t       AMDENQryTag           = NULLTAG;

    //TZ Changes....................................................
	if(AllPlantflag != 1)
	{
	    if(QRY_find2("General...", &AMDENQryTag));//API changed for 12.2 to 14.3 upgrade...
	    if(AMDENQryTag != NULLTAG)
	    {
	    	printf("Amden query found\n");fflush(stdout);
	    	char 		*AMDqry_entries[2] 	= 	{"Name","Type"};
	        char 		**AMDqry_values 		= 	(char **) MEM_alloc(10 * sizeof(char *));
	        
	        AMDqry_values[0]					=	AmdenTname;
	        AMDqry_values[1]					=	"Amden Table";
    
	        if(QRY_execute(AMDENQryTag,2,AMDqry_entries,AMDqry_values,&AmdenCnt,&Amdentableset));
    
	    	if(AmdenCnt > 0)
	        {
	        	printf("\nTotal MADEN found ......  :%d\n",AmdenCnt);fflush(stdout);
	    		Amdentable = Amdentableset[0];
	    	    ITK_CALL(AOM_ask_table_rows(Amdentable,"t5_AmdTablerow",&row_cnt,&AmdentableRowset));
	    	    printf("\nTotal row found under AMden table is ... :%d\n",row_cnt);fflush(stdout);
	    	    if(row_cnt > 0)
	    	    {
	    	    	printf(" \nAmden table row found ..... !\n");fflush(stdout);
	    	    }
	        }
	        else 
	        {
                printf(" \n\n AMDEN Not found !\n");fflush(stdout);
	    		
	        }
	    } 
	    else
	    {
	    	printf("Amden Query not found\n");fflush(stdout);
	    }
	}
	
	
    //...............................................................................

	// DML find ..................................................................................	

	if(QRY_find2("Item Revision...", &QryTag));//API changed for 12.2 to 14.3 upgrade...
	if(QryTag != NULLTAG)
	{
		printf("query found\n");fflush(stdout);
	

	    int 		n_entries			=	2;
	    tag_t 		ERCDMLObjtag 		= 	NULLTAG;
	    tag_t 		*erc_DML_Result 	= 	NULLTAG;
	    char 		*qry_entries[3] 	= 	{"Item ID","Type","Revision"};
	    char 		**qry_values 		= 	(char **) MEM_alloc(10 * sizeof(char *));
	    
	    qry_values[0]					=	InputERCDML;
	    qry_values[1]					=	"ERC DML Revision";
	    qry_values[2]					=	Revision;
    
	    
	    printf("\n Into the Query \n");fflush(stdout);
	    if(QRY_execute(QryTag,n_entries,qry_entries,qry_values,&ERCDMLCount,&ERCDMLSet));
	    
	    printf("\nNumber of ERC DML is :%d\n",ERCDMLCount);fflush(stdout);
	    if(ERCDMLCount > 0)
	    {
	    	printf("***********************Query Ececuted Succesfully\n");fflush(stdout);
	    	int serial = 0;
	    	serial++;
	    	char*	    DMLName          	= NULL;
	        char*	    DML_Rev         	= NULL;
	    	char*	    DMLType        	    = NULL;
	    	char*	    DMLDesc          	= NULL;
	    	char*	    DMLDescV          	= NULL;
	    	char*	    DML_Seq          	= NULL;
	    	char*	    DMLRlzDate          = NULL;
	    	char*       DMLRlzType          = NULL;
	    	tag_t       DMLItem             = NULLTAG;
	    	tag_t       DMLRevision         = NULLTAG;
	    	tag_t       TaskRelation        = NULLTAG;
	    	tag_t       DCRRelation         = NULLTAG;
	    	tag_t       *TaskSet            = NULLTAG;
	    	tag_t       *DCRSet             = NULLTAG;
	    	int         NoOfTask            = 0;
	    	int         NoOfDCR             = 0;
	    	char        *DCRStatus			= NULL;
			char        *DMLRlzStatus       = NULL;
	        DCRStatus = (char *) MEM_alloc( 5 * sizeof(char*) );
    
	    	char        *CKDSumV            = (char *) MEM_alloc(5 * sizeof(char *));
	    	char        *CargoSumV          = (char *) MEM_alloc(5 * sizeof(char *));
	    	char        *DefencesumV        = (char *) MEM_alloc(5 * sizeof(char *));
	    	char        *EPAsumV            = (char *) MEM_alloc(5 * sizeof(char *));
	    	char        *WTsumV             = (char *) MEM_alloc(5 * sizeof(char *));
	    	char        *TippersumV         = (char *) MEM_alloc(5 * sizeof(char *));
	    	
	    	DMLItem = ERCDMLSet[0];
	    	
	        ITK_CALL(AOM_ask_value_string(DMLItem,"item_id",&DMLName));
	        printf("DML name is = %s\n",DMLName);fflush(stdout);
    
	    	ITK_CALL(AOM_ask_value_string(DMLItem,"current_desc",&DMLDesc));
	        //printf("DML Desc is = %s\n",DMLDesc);fflush(stdout);
    
	    	ITK_CALL(AOM_ask_value_string(DMLItem,"t5_rlstype",&DMLRlzType));
	        printf("DML Type is = %s\n",DMLRlzType);fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(DMLItem,"release_status_list",&DMLRlzStatus));
			//printf("DML Release status is = %s\n",DMLRlzStatus);fflush(stdout);	
    
    
	    	//tc_strcpy(DMLDescV,replace(DMLDesc, ",", " "));
	    	DMLDescV = replace(DMLDesc, ",", " ");
    
	    	//printf("after replace DML Desc is = %s\n",DMLDescV);fflush(stdout);
    
	    	//ITK_CALL(AOM_ask_value_string(DMLItem,"item_revision_id",&DML_Rev));
	    	ITK_CALL(AOM_UIF_ask_value(DMLItem,"item_revision_id",&DML_Rev));
	        printf("DML Revision is = %s\n",DML_Rev);fflush(stdout);
    
	    	ITK_CALL(AOM_UIF_ask_value(DMLItem,"sequence_id",&DML_Seq));
	        //printf("DML Sequence is = %s\n",DML_Seq);fflush(stdout);
    
	    	//ITK_CALL(AOM_ask_value_string(DMLItem,"date_released",&DMLRlzDate));//AOM_UIF_ask_value
	    	ITK_CALL(AOM_UIF_ask_value(DMLItem,"date_released",&DMLRlzDate));
	        //printf("DML Date Released is = %s\n",DMLRlzDate);fflush(stdout);
    
	    	//DCR find ...............................................................
    
	    	GRM_find_relation_type("CMImplements",&DCRRelation);
	        GRM_list_secondary_objects_only(DMLItem,DCRRelation,&NoOfDCR,&DCRSet);
    
	    	if(NoOfDCR > 0) 
	    	{
	    		tc_strcpy(DCRStatus,"Y");
	    	}
	    	else
	    	{
	    		tc_strcpy(DCRStatus,"N");
	    	}
	    	//..........................................................................
    
    
	    	
    
	    	// DML IMPLOSION Summary............................
	    	//Write all data in one string  ............................................................................
    
	        if(AllPlantflag == 1)
			{
				IMPLstrcat(output,"\n");
	            IMPLstrcat(output,"                          DML IMPLOSION REPORT FOR ALL PLANTS (INDEPENDENT OF AMDEN)                     \n");
	            IMPLstrcat(output,"                          ==========================================================                     \n");
	            IMPLstrcat(output,"    ===============================================================\n");
	    	    IMPLstrcat(output,"    DML Number       : ");
	    	    IMPLstrcat(output,DMLName);
	    	    IMPLstrcat(output,"       Revision : ");
	    	    IMPLstrcat(output,DML_Rev);
	    	    IMPLstrcat(output,"      Sequence : ");
	    	    IMPLstrcat(output,DML_Seq);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    DML Desription.  : ");
	    	    IMPLstrcat(output,DMLDesc);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    Released Date    : ");
	    	    IMPLstrcat(output,DMLRlzDate);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    DCR Attached     : ");
	    	    IMPLstrcat(output,DCRStatus);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    ===============================================================\n\n");
			}
			else
			{
				SummaryFlag = 1;
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                          DML IMPLOSION REPORT                     \n");
	    	    IMPLstrcat(output,"                          ====================                     \n");
	    	    IMPLstrcat(output,"    ===============================================================\n");
	    	    IMPLstrcat(output,"    DML Number       : ");
	    	    IMPLstrcat(output,DMLName);
	    	    IMPLstrcat(output,"       Revision : ");
	    	    IMPLstrcat(output,DML_Rev);
	    	    IMPLstrcat(output,"      Sequence : ");
	    	    IMPLstrcat(output,DML_Seq);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    DML Desription.  : ");
	    	    IMPLstrcat(output,DMLDesc);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    Released Date    : ");
	    	    IMPLstrcat(output,DMLRlzDate);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    DCR Attached     : ");
	    	    IMPLstrcat(output,DCRStatus);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    ===============================================================\n\n");
	    	    //Return to rac ............................................................................

                if(tc_strcmp(FileFormat,".csv") == 0)
	            {
                    //Unique VC list..............................................................................
	                tc_strcat(UniqueVC,",====== Unique VC List Affected by DML =======\n");
	                tc_strcat(UniqueVC,"===============,=====,==================================,==========,=============\n");
	                tc_strcat(UniqueVC,"VC LIST,REV,VC DESC,DR Stat,AGENCY\n");
	                tc_strcat(UniqueVC,"===============,=====,==================================,==========,=============\n");
	                //.............................................................................................
				}
				else if(tc_strcmp(FileFormat,".txt") == 0)
	            {
					//Unique VC list..............................................................................
	                tc_strcat(UniqueVC,"    ====== Unique VC List Affected by DML =======\n");
	                tc_strcat(UniqueVC,"    ===============   =====      ==================================                  ==========            =============\n");
	                tc_strcat(UniqueVC,"        VC LIST        REV                DESCRIPTION                                  DR Stat              AGENCY   \n");
	                tc_strcat(UniqueVC,"    ===============   =====      ==================================                  ==========            =============\n");
	                //.............................................................................................
				}
				else
				{
					
				}
        
                //CKD........................................................................
	    	    tc_strcat(OutputCKD,"\n");
	    	    tc_strcat(OutputCKD,"    CKD START\n");
	    	    tc_strcat(OutputCKD,"                   CKD                         \n");
	    	    tc_strcat(OutputCKD,"                   ---                         \n");
	    	    tc_strcat(OutputCKD,"    ===========================================\n");
	    	    tc_strcat(OutputCKD,"    DML NO.       : ");
	    	    tc_strcat(OutputCKD,DMLName);
	    	    tc_strcat(OutputCKD,"\n");
	    	    tc_strcat(OutputCKD,"    Released Date : ");
	    	    tc_strcat(OutputCKD,DMLRlzDate);
	    	    tc_strcat(OutputCKD,"\n");
	    	    tc_strcat(OutputCKD,"    ===========================================\n\n");
	    	    //.............................................................................
        
	    	    //Cargo........................................................................
	    	    tc_strcat(OutputCargo,"\n");
	    	    tc_strcat(OutputCargo,"    CARGO START\n");
	    	    tc_strcat(OutputCargo,"                   Cargo                         \n");
	    	    tc_strcat(OutputCargo,"                   ---                         \n");
	    	    tc_strcat(OutputCargo,"    ===========================================\n");
	    	    tc_strcat(OutputCargo,"    DML NO.       : ");
	    	    tc_strcat(OutputCargo,DMLName);
	    	    tc_strcat(OutputCargo,"\n");
	    	    tc_strcat(OutputCargo,"    Released Date : ");
	    	    tc_strcat(OutputCargo,DMLRlzDate);
	    	    tc_strcat(OutputCargo,"\n");
	    	    tc_strcat(OutputCargo,"    ===========================================\n\n");
	    	    //.............................................................................
        
	    	    //Defence........................................................................
	    	    tc_strcat(OutputDefence,"\n");
	    	    tc_strcat(OutputDefence,"    DEFENCE START\n");
	    	    tc_strcat(OutputDefence,"                   Defence                         \n");
	    	    tc_strcat(OutputDefence,"                   -------                         \n");
	    	    tc_strcat(OutputDefence,"    ===========================================\n");
	    	    tc_strcat(OutputDefence,"    DML NO.       : ");
	    	    tc_strcat(OutputDefence,DMLName);
	    	    tc_strcat(OutputDefence,"\n");
	    	    tc_strcat(OutputDefence,"    Released Date : ");
	    	    tc_strcat(OutputDefence,DMLRlzDate);
	    	    tc_strcat(OutputDefence,"\n");
	    	    tc_strcat(OutputDefence,"    ===========================================\n\n");
	    	    //.............................................................................
        
	    	    //EPA........................................................................
	    	    tc_strcat(OutputEPA,"\n");
	    	    tc_strcat(OutputEPA,"    EPA START\n");
	    	    tc_strcat(OutputEPA,"                   EPA                         \n");
	    	    tc_strcat(OutputEPA,"                   ---                         \n");
	    	    tc_strcat(OutputEPA,"    ===========================================\n");
	    	    tc_strcat(OutputEPA,"    DML NO.       : ");
	    	    tc_strcat(OutputEPA,DMLName);
	    	    tc_strcat(OutputEPA,"\n");
	    	    tc_strcat(OutputEPA,"    Released Date : ");
	    	    tc_strcat(OutputEPA,DMLRlzDate);
	    	    tc_strcat(OutputEPA,"\n");
	    	    tc_strcat(OutputEPA,"    ===========================================\n\n");
	    	    //.............................................................................
        
	    	    //Tipper........................................................................
	    	    tc_strcat(OutputTipper,"\n");
	    	    tc_strcat(OutputTipper,"    TIPPER START\n");
	    	    tc_strcat(OutputTipper,"                   Tipper                         \n");
	    	    tc_strcat(OutputTipper,"                   ------                        \n");
	    	    tc_strcat(OutputTipper,"    ===========================================\n");
	    	    tc_strcat(OutputTipper,"    DML NO.       : ");
	    	    tc_strcat(OutputTipper,DMLName);
	    	    tc_strcat(OutputTipper,"\n");
	    	    tc_strcat(OutputTipper,"    Released Date : ");
	    	    tc_strcat(OutputTipper,DMLRlzDate);
	    	    tc_strcat(OutputTipper,"\n");
	    	    tc_strcat(OutputTipper,"    ===========================================\n\n");
	    	    //.............................................................................
        
	    	    //WT IMPLOSION REPORT............................................................................................
        
	            //WT........................................................................
	    	    tc_strcat(OutputWT,"\n");
	    	    tc_strcat(OutputWT,"    WT START\n");
	    	    tc_strcat(OutputWT,"                   WT                         \n");
	    	    tc_strcat(OutputWT,"                   --                       \n");
	    	    tc_strcat(OutputWT,"    ===========================================\n");
	    	    tc_strcat(OutputWT,"    DML NO.       : ");
	    	    tc_strcat(OutputWT,DMLName);
	    	    tc_strcat(OutputWT,"\n");
	    	    tc_strcat(OutputWT,"    Released Date : ");
	    	    tc_strcat(OutputWT,DMLRlzDate);
	    	    tc_strcat(OutputWT,"\n");
	    	    tc_strcat(OutputWT,"    ===========================================\n\n");
	    	    //.............................................................................
        
			}


	    	if(tc_strcmp(DMLRlzStatus,"ERC Released") == 0)
			{
				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&TaskRelation));
	    	    ITK_CALL(GRM_list_secondary_objects_only(DMLItem,TaskRelation,&NoOfTask,&TaskSet));
    
			    printf("Number of task found under DML is = %d\n",NoOfTask);fflush(stdout);
	    	    if(NoOfTask > 0)
	    	    {
	    	    	int    TaskItr   = 0;
	    	    	int Serial = 0;
	    	    	for(TaskItr = 0; TaskItr < NoOfTask;TaskItr++)
	    	    	{  
	    	    		Serial++;
	    	    		tag_t      TaskItem        = NULLTAG;
	    	    		tag_t      PartRelation    = NULLTAG;
	    	    		tag_t      *PartSet        = NULLTAG;
	    	    		char       *TaskName       = NULL;
			    		char       *TaskType       = NULL;
	    	    		int        NoOfParts       = NULL; 
	    	    		TaskItem = TaskSet[TaskItr];
        
	    	    		ITK_CALL(AOM_ask_value_string(TaskItem,"item_id",&TaskName));
	                    printf("Task name is = %s\n",TaskName);fflush(stdout);
    
			    		ITK_CALL(AOM_ask_value_string(TaskItem,"object_type",&TaskType));
	                    //printf("Task type is = %s\n",TaskType);fflush(stdout);	
    
			    		if((strstr(TaskName,"MBOM") || strstr(TaskName,"APL")))
			    		{
			    			printf("Skiping because task is MBOM or APL\n");fflush(stdout);
			    		}
			    		else if(tc_strcmp(TaskType,"T5_ChangeTaskRevision") == 0)
			    		{	   
        
                            if(AllPlantflag == 1)
			                {  
								//All vc ......................................................................
							    tc_strcat(AllVcOutput,"    Task Number : ");
	    	    		        tc_strcat(AllVcOutput,TaskName);
	    	    		        tc_strcat(AllVcOutput,"\n");
	    	    		        tc_strcat(AllVcOutput,"    ===========================================\n");
	    	    		        //............................................................................................................................
							}
							else
							{     
								//CKD
								if(tc_strcmp(FileFormat,".csv") == 0)
								{
									
		                            tc_strcat(OutputCKD," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputCKD," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputCKD," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
		                            
		                            //Cargo
		                            tc_strcat(OutputCargo," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputCargo," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputCargo," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
		                            
		                            //Defence
		                            tc_strcat(OutputDefence," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputDefence," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputDefence," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    
		                            //EPA
		                            tc_strcat(OutputEPA," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputEPA," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputEPA," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
		                            
		                            //Tipper
		                            tc_strcat(OutputTipper," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputTipper," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputTipper," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
		                            
		                            //WT
		                            tc_strcat(OutputWT," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
                                    tc_strcat(OutputWT," Task No,Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
                                    tc_strcat(OutputWT," ===============,===============,===========================,============,===========,=============,===========================,==============\n");
								}
								else if(tc_strcmp(FileFormat,".txt") == 0)
								{
									//CKD.............................................................................
	    	    		            tc_strcat(OutputCKD,"    Task Number : ");
	    	    		            tc_strcat(OutputCKD,TaskName);
	    	    		            tc_strcat(OutputCKD,"\n");
	    	    		            tc_strcat(OutputCKD,"    ===========================================\n");
								    
	    	    		            //.................................................................................
								    
	    	    		            //Cargo.............................................................................
	    	    		            tc_strcat(OutputCargo,"    Task Number : ");
	    	    		            tc_strcat(OutputCargo,TaskName);
	    	    		            tc_strcat(OutputCargo,"\n");
	    	    		            tc_strcat(OutputCargo,"    ===========================================\n");
								    
	    	    		            //.................................................................................
								    
	    	    		            //Defence.............................................................................
	    	    		            tc_strcat(OutputDefence,"    Task Number : ");
	    	    		            tc_strcat(OutputDefence,TaskName);
	    	    		            tc_strcat(OutputDefence,"\n");
	    	    		            tc_strcat(OutputDefence,"    ===========================================\n");
								    
	    	    		            //.................................................................................
								    
	    	    		            //EPA.............................................................................
	    	    		            tc_strcat(OutputEPA,"    Task Number : ");
	    	    		            tc_strcat(OutputEPA,TaskName);
	    	    		            tc_strcat(OutputEPA,"\n");
	    	    		            tc_strcat(OutputEPA,"    ===========================================\n");
								    
	    	    		            //.................................................................................
								    
	    	    		            //Tipper.............................................................................
	    	    		            tc_strcat(OutputTipper,"    Task Number : ");
	    	    		            tc_strcat(OutputTipper,TaskName);
	    	    		            tc_strcat(OutputTipper,"\n");
	    	    		            tc_strcat(OutputTipper,"    ===========================================\n");
								    
	    	    		            //.................................................................................
								    
	    	    		            //WT.............................................................................
	    	    		            tc_strcat(OutputWT,"    Task Number : ");
	    	    		            tc_strcat(OutputWT,TaskName);
	    	    		            tc_strcat(OutputWT,"\n");
	    	    		            tc_strcat(OutputWT,"    ===========================================\n");
								    
							        //.................................................................................	
								}
								else
								{
									printf("check the file format...\n");fflush(stdout);
								}
							}
    
            
	    	    		    //............................................................................................................................
    
			    			//DML Release Type ...........................................................................
	    	                if(tc_strcmp(DMLRlzType,"TODR") == 0)
	    	                {
	    	    		    	ITK_CALL(GRM_find_relation_type("CMReferences",&PartRelation));
	    	                    ITK_CALL(GRM_list_secondary_objects_only(TaskItem,PartRelation,&NoOfParts,&PartSet));      
	    	                }
	    	    		    else 
	    	    		    {
	    	    		    	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&PartRelation));
	    	                    ITK_CALL(GRM_list_secondary_objects_only(TaskItem,PartRelation,&NoOfParts,&PartSet));
	    	    		    }
	    	    		    // ........................................................................................
            
	    	    		    printf("Number of parts found under task is = %d\n",NoOfParts);fflush(stdout);
        
        
	    	    		    if(NoOfParts > 0)
	    	    		    {
	    	    		    	int    PartItr   = 0;
	    	    		    	int    PrtSerial = 0;
	    	    	            for(PartItr = 0; PartItr < NoOfParts;PartItr++)
	    	    	            { 
	    	    		    		PrtSerial++;
	    	    		    		tag_t     PartItem           = NULLTAG;
	    	    		    		char      *Prt_object_type   = NULL; 
	    	    		    		char      *PartRevSeq        = NULL; 
	    	    		    		char      *Releasestate1     = NULL;
	    	    		    		char      *PartDesc          = NULL;
	    	    		    		char      *PartDescV         = NULL;
	    	    		    		char      *PartType          = NULL;
	    	    		    		char      **RlzStsList       = NULL;
	    	    		    		int        NoofLC            = 0;

	    	    		    	
	    	    		    		PartItem = PartSet[PartItr];
									
									ITK_CALL(AOM_ask_value_string(PartItem,"object_type",&Prt_object_type));
	                                printf("Prt_object_type is... = %s\n",Prt_object_type);fflush(stdout);
            
	    	    		    		//printf("after replace Part PartDesc is = %s\n",PartDescV);fflush(stdout);

	    	    		    		ITK_CALL(AOM_ask_value_string(PartItem,"t5_PartType",&PartType));
	                                printf("Part PartType is = %s\n",PartType);fflush(stdout);
            
	    	    		    		//ITK_CALL(AOM_UIF_ask_value(PartItem,"release_status_list",&Releasestate1));
									
									if(strcmp(Prt_object_type,"Folder")==0)		
									{
										char*    fldItrrName        = NULL;
										
										ITK_CALL(AOM_ask_value_string(PartItem,"object_name",&fldItrrName));
										
										printf("\n fldItrrName is :: %s \n", fldItrrName);fflush(stdout);
					
										if(tc_strcmp(fldItrrName,"Parts For Gate Maturation")==0)
										{
											printf("\n Inside folder found \n");fflush(stdout);
											int       fldItrerSize           = 0;
											int       fldItrerObjCount       = 0;
											tag_t*    FolderObj_tag       = NULL;
			
											ITK_CALL(FL_ask_size(PartItem,&fldItrerSize));
											
											printf("\n fldItrerSize is:   %d \n",fldItrerSize);fflush(stdout);
											
											
											ITK_CALL(FL_ask_references(PartItem,FL_fsc_by_date_modified ,&fldItrerObjCount,&FolderObj_tag));
											
											printf("\n for No of parts under folder, fldItrerObjCount is..:   %d \n",fldItrerObjCount);fflush(stdout);
											
											if(fldItrerObjCount>0)
											{
												int fldItr   = 0;
												for (fldItr = 0; fldItr < fldItrerObjCount; fldItr++)
												{ 
											
										            tag_t     FLPartItem           = NULLTAG;
													char      *PartID              = NULL; 
	    	    		    		                char      *PartRevSeqV         = NULL; 
	    	    		    		                char      *PartRevSeqV1        = NULL; 
	    	    		    		                char      *DrStatus            = NULL; 
	    	    		    		                char      *PartDescK           = NULL; 
	    	    		    		                char      *PartDescK1          = NULL; 
	    	    		    		                char      *PartTypeV           = NULL; 
													
													FLPartItem = FolderObj_tag[fldItr];
													
													ITK_CALL(AOM_ask_value_string(FLPartItem,"item_id",&PartID));
													ITK_CALL(AOM_ask_value_string(FLPartItem,"item_revision_id",&PartRevSeqV));
													ITK_CALL(AOM_ask_value_string(FLPartItem,"t5_PartStatus",&DrStatus));
													ITK_CALL(AOM_ask_value_string(FLPartItem,"current_desc",&PartDescK));
													ITK_CALL(AOM_ask_value_string(FLPartItem,"t5_PartType",&PartTypeV));
													
													PartRevSeqV1=replace(PartRevSeqV, ",", ";");
													PartDescK1 = replace(PartDescK, ",", " ");
													    
													printf("\n------->PartID PartRevSeq DrStatus Part Desc :%s %s %s %s\n",PartID,PartRevSeqV1,DrStatus,PartDescK1);fflush(stdout);
	               
													
													if((tc_strcmp(PartTypeV,"D") == 0) || (tc_strcmp(PartTypeV,"DC") == 0) || (tc_strcmp(PartTypeV,"CM") == 0 ))
                                                    {
	    	    		    		                	printf(" folder Skiping because Part type is D or DC or CM\n");fflush(stdout);
	    	    		    		                }
													else
													{

													    //Part Impl.......................................................................
										                tm_PartImplFn(FLPartItem,TaskName,PlantName,FileFormat,AllPlantflag,row_cnt,AmdentableRowset,&OutputCKD,&OutputCargo,
										                &OutputDefence,&OutputEPA,&OutputTipper,&OutputWT,&UniqueVC,&AllVcOutput,&CKDSumS,
										                &CargoSumS,&DefencesumS,&EPAsumS,&TippersumS,&WTsumS);
														
														printf("CKD sumF.. [%d] Cargo sumF.. [%d] Defence sumF [%d] EPA sumF [%d] Tipper sumF [%d] WT sumF [%d]\n",CKDSumS,CargoSumS,DefencesumS,EPAsumS,TippersumS,WTsumS);fflush(stdout);	

										                //................................................................................
													}
												}
											}
										}
									}
	    	    		    	    if((tc_strcmp(PartType,"D") == 0) || (tc_strcmp(PartType,"DC") == 0) || (tc_strcmp(PartType,"CM") == 0 ) || (tc_strcmp(Prt_object_type,"Folder") == 0 ))
                                    {
	    	    		    			printf("Skiping because Part type is D or DC or CM or Folder\n");fflush(stdout);
	    	    		    		}
	    	    		    		else
									{
										//Part Impl.......................................................................
										tm_PartImplFn(PartItem,TaskName,PlantName,FileFormat,AllPlantflag,row_cnt,AmdentableRowset,&OutputCKD,&OutputCargo,
										&OutputDefence,&OutputEPA,&OutputTipper,&OutputWT,&UniqueVC,&AllVcOutput,&CKDSumS,
										&CargoSumS,&DefencesumS,&EPAsumS,&TippersumS,&WTsumS);
										
										printf("CKD sumF.. [%d] Cargo sumF.. [%d] Defence sumF [%d] EPA sumF [%d] Tipper sumF [%d] WT sumF [%d]\n",CKDSumS,CargoSumS,DefencesumS,EPAsumS,TippersumS,WTsumS);fflush(stdout);	
									
										//................................................................................
									}
	    	    		    		
	    	    		        }          
	    	    		    }
							else
				            {
				            	printf("\n No part found under task......\n");fflush(stdout);
				            }
			    		}
	    	    	}
	    	    }
				else
				{
					printf("\n No task found under DML.......\n");fflush(stdout);
				}
			}
			else
			{
				printf("\nDML not ERC Released......\n");fflush(stdout);
			}

			if(AllPlantflag != 1)
		    {
    
	    	    tc_strcat(OutputCKD,"    CKD END \n");
	    	    tc_strcat(OutputCargo,"    CARGO END \n");
	    	    tc_strcat(OutputDefence,"    DEFENCE END \n");
	    	    tc_strcat(OutputEPA,"    EPA END \n");
	    	    tc_strcat(OutputTipper,"    TIPPER END \n");
	    	    tc_strcat(OutputWT,"    WT END \n");
        
	    	    //.........................................................
				
				//printf("CKD sumF [%d] Cargo sumF [%d] Defence sumF [%d] EPA sumF [%d] Tipper sumF [%d] WT sumF [%d]\n",CKDSumF,CargoSumF,DefencesumF,EPAsumF,TippersumF,WTsumF);fflush(stdout);	

        
	    	    sprintf(CKDSumV,"%d",CKDSumS);
	    	    sprintf(CargoSumV,"%d",CargoSumS);
	    	    sprintf(DefencesumV,"%d",DefencesumS);
	    	    sprintf(EPAsumV,"%d",EPAsumS);
	    	    sprintf(TippersumV,"%d",TippersumS);
	    	    sprintf(WTsumV,"%d",WTsumS);
				
				
                
	    	    //Write all data in one string  ............................................................................
                
	    	    IMPLstrcat(output,"    ===============================================================\n");
	    	    IMPLstrcat(output,"                               Change Occurances          \n");
	    	    IMPLstrcat(output,"                               =================          \n");
	    	    IMPLstrcat(output,"                               CKD      :     ");
	    	    IMPLstrcat(output,CKDSumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                               Cargo    :     ");
	    	    IMPLstrcat(output,CargoSumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                               Defence  :     ");
	    	    IMPLstrcat(output,DefencesumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                               EPA      :     ");
	    	    IMPLstrcat(output,EPAsumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                               Tipper   :     ");
	    	    IMPLstrcat(output,TippersumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"                               WT       :     ");
	    	    IMPLstrcat(output,WTsumV);
	    	    IMPLstrcat(output,"\n");
	    	    IMPLstrcat(output,"    ===============================================================\n");
        
	    	    tc_strcat(UniqueVC,"    ========================== END OF THE REPORT ========================\n");
			}
	    }
		else
		{
			printf("Erc Dml Revision not found.....\n");fflush(stdout);
		}

		if(AllPlantflag == 1)
		{
			tc_strcat(AllVcOutput,"    ========================== END OF THE REPORT ========================\n");
			IMPLstrcat(output,AllVcOutput);

			MEM_free(AllVcOutput);

		}
		else
		{
		    IMPLstrcat(output,OutputCKD);
	        IMPLstrcat(output,OutputCargo);
	        IMPLstrcat(output,OutputDefence);
	        IMPLstrcat(output,OutputEPA);
	        IMPLstrcat(output,OutputTipper);
	        IMPLstrcat(output,OutputWT);
	        IMPLstrcat(output,UniqueVC);

			MEM_free(OutputCKD);
	        MEM_free(OutputCargo);
	        MEM_free(OutputDefence);
	        MEM_free(OutputEPA);
	        MEM_free(OutputTipper);
	        MEM_free(OutputWT);
	        MEM_free(UniqueVC);

		}
	    
	    printf("End of the function tm_DML_ImplosionRpt.... \n");fflush(stdout);
		return ITK_ok;
	}
	else
	{
		printf("Query not found .......\n");fflush(stdout);
	}
}

int DML_ImplosionReport(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
    char     *InputERCDML        = NULL;
	char     *PlantName          = NULL; 
	char     *output			 = NULL;
	char     *Revision			 = NULL;
	char     *FileFormat	     = NULL;
			
	output = (char *) MEM_alloc( 90000000 * sizeof(char*) );

	printf("\n inside the function DML_ImplosionRpt .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&InputERCDML);
	USERARG_get_string_argument(&PlantName);
	USERARG_get_string_argument(&Revision);
	USERARG_get_string_argument(&FileFormat);

	printf("\n Input DML number :: %s ",InputERCDML);fflush(stdout);
	printf("\n Input Plant Name  :: %s ",PlantName);fflush(stdout);
	printf("\n Input Revision is  :: %s ",Revision);fflush(stdout);
	printf("\n Input file format is  :: %s ",FileFormat);fflush(stdout);

	//..........................................................
		
	
	tc_strcpy(output,"");

	tm_DML_ImplosionRpt(InputERCDML,PlantName,&output,Revision,FileFormat);

	printf("\n before return data....!\n");fflush(stdout);

	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(output);

	printf("\n After free...!\n");fflush(stdout);
    return ifail;
}

extern int AllUserServiceFnDMLImplFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 4;
    int retValueType;
    int inputArgTypes[4] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //DML Number 
    inputArgTypes[1] = USERARG_STRING_TYPE; //Plant Name 
	inputArgTypes[2] = USERARG_STRING_TYPE; //Revision 
	inputArgTypes[3] = USERARG_STRING_TYPE; //fileformat 
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("DML_ImplosionReport",(USER_function_t)DML_ImplosionReport,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_DML_ImplosionRpt_register_callbacks ()
{

    int ifail    = ITK_ok;
    printf("\n Before registering userservice....tm_DML_ImplosionRpt");fflush(stdout);
    ifail = CUSTOM_register_exit("tm_DML_ImplosionRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnDMLImplFn);
    printf("\n After registering userservice....tm_DML_ImplosionRpt");fflush(stdout);
    return ifail;
}
