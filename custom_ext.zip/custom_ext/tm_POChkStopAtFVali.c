/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Rule Handler basic PO Check validations.
*  Code                 :   tm_POChkStopAtFVali.c
*  Created on			:   12/04/2019
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
*	1.	12/04/2019					Mohan Tayade		PO check basic validations
*	2.	08/05/2019					Mohan Tayade		Handle DR3P/AR3P
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_POChkStopAtFVali(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int iii    =  0;
	int j      =  0;
	int i      =  0;
	int spPartCnt	=  0;
	int task_count	=  0;
	int Col1_count	=  0;
	int part_count	=  0;
	int Item_count	=  0;
	int count	=  0;
	int no_attach	=  0;
	int FirstCheckOK	=  0;
	int error_code	= ITK_ok;
	char *task_id		= NULL;
	char *sPOCHKInfo3		= NULL;
	char *sDMLno		= NULL;
	char *DMLtype		= NULL;
	char *DMLProj		= NULL;
	char *PlntToPlnt		= NULL;
	char *sDml_DR		= NULL;
	char *usernam		= NULL;
	char *staskId		= NULL;
	char *sDml_TP		= NULL;
	char	*class_name1	= NULL;
	char*   ObjTyp=NULL;
	tag_t	spCMRefrel		= NULLTAG;
	tag_t	DMLRevTg		= NULLTAG;
	tag_t	objTypTag		= NULLTAG;
	tag_t *spPartTags=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t class_id1 =NULLTAG;
	tag_t tsk_dml_rel_type =NULLTAG;
	tag_t dml_task_rel	= NULLTAG;
	tag_t *task_tag = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	logical is_latest;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_POChkStopAtFVali Function started...");fflush(stdout);
	TC_write_syslog("\n tm_POChkStopAtFVali Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n PO:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n PO:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "POCHCK";
				//DR_qry_values2[0] = "CREVali";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n PO:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//PO bypass
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&sPOCHKInfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n PO:Basic Vali:sPOCHKInfo3:%s\n",sPOCHKInfo3);fflush(stdout);
					if(strstr(sPOCHKInfo3,"POBASICVALI")==NULL)
					{
						if(POM_get_user_id (&usernam)!=ITK_ok)PrintErrorStack();
						printf("\n PO:Session login User1 for MR : %s\n",usernam); fflush(stdout);

						if(tc_strcmp(usernam,"infodba") !=0 && tc_strcmp(usernam,"loader") !=0)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								if(GRM_list_primary_objects_only(taskAttachments[i],tsk_dml_rel_type,&count,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n PO:DML Revision from Task for MR : %d",count);fflush(stdout);
								for (j=0;j<count ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n PO: is_latest MR is : %d\n",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n PO:is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];
										if(POM_class_of_instance(DMLRevTg,&class_id1)!=ITK_ok)PrintErrorStack();
										if(POM_name_of_class(class_id1,&class_name1)!=ITK_ok)PrintErrorStack();
										printf("\n PO: class_name is:%s",class_name1);
										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_PlntToPlnt",&PlntToPlnt)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_cDRstatus",&sDml_DR)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(DMLRevTg,"t5_TargetPlant",&sDml_TP)!=ITK_ok)PrintErrorStack();
										printf("\n PO: sDMLno:%s DMLtype:%s DMLProj:%s PlntToPlnt:%s sDml_TP:%s sDml_DR:%s",sDMLno,DMLtype,DMLProj,PlntToPlnt,sDml_TP,sDml_DR);fflush(stdout);

										//DML DR-status should not be NULL.
										if((sDml_DR==NULL)|| (tc_strcmp(sDml_DR,"")==0))
										{
											printf("\n PO:ERROR: DR-status should not be NULL for DML.\n");fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML not having valid DR-status, please updated it and then sign off task.\n",sDMLno);	
											decision = EPM_nogo;
											return decision;
										}
										else
										{
											if((tc_strcmp(DMLtype,"MR")==0)||(tc_strcmp(DMLtype,"DFMR")==0)||(tc_strcmp(DMLtype,"TPL")==0)||(tc_strcmp(DMLtype,"Veh")==0))
											{
												if((strstr(sDml_DR,"AR")!=NULL)||(strstr(sDml_DR,"DR")!=NULL))
												{
													printf("\n PO:MR:.valid DR-status available.\n");fflush(stdout);
													if(((tc_strcmp(DMLtype,"MR")==0)||(tc_strcmp(DMLtype,"DFMR")==0)||(tc_strcmp(DMLtype,"TPL")==0)||(tc_strcmp(DMLtype,"Veh")==0))&& ((tc_strcmp(sDml_DR,"AR3P")==0)||(tc_strcmp(sDml_DR,"DR3P")==0)||(tc_strcmp(sDml_DR,"DR4")==0)|| (tc_strcmp(sDml_DR,"DR5")==0)||(tc_strcmp(sDml_DR,"AR4")==0)|| (tc_strcmp(sDml_DR,"AR5")==0)))
													{
														printf("\n PO:MR:.PO FirstCheckOK for DML:%s \n",sDMLno);fflush(stdout);
														if((sDml_TP==NULL)|| (tc_strcmp(sDml_TP,"")==0))
														{
															printf("\n PO:ERROR: Target plant should not be NULL for DML.\n");fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML not having valid target plant. Please update valid target plant and then sign off DML.\n",sDMLno);	
															decision = EPM_nogo;
															return decision;
														}
													}
													else
													{
														printf("\n PO:GM: Not eligible DML:%s \n",sDMLno);fflush(stdout);
													}
													
												}
												else
												{
													printf("\n PO:ERROR:MR: Valid DR-status should be for DML.\n");fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML not having valid DR-status, please updated it and then sign off task.\n",sDMLno);	
													decision = EPM_nogo;
													return decision;
												}
											}
											else if(tc_strcmp(DMLtype,"TODR")==0)
											{
												if(strstr(sPOCHKInfo3,"GMDNAVALI")!=NULL)
												{
													//DML DR-status
													if(tc_strcmp(sDml_DR,"NA")!=0)
													{
														printf("\n PO:ERROR:Gate Maturation DML should have NA as DR-status.\n");fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"Gate Maturation DML should have NA as DR-status.\n",sDMLno);	
														decision = EPM_nogo;
														return decision;
													}
												}
												//FROMTO Gate change is mandatroy.
												if((PlntToPlnt==NULL)|| (tc_strcmp(PlntToPlnt,"")==0))
												{
													printf("\n PO:ERROR: Target plant should not be NULL for DML.\n");fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML not having valid FROM-TO DR-Gate value updated. Please update valid value and then sign off DML.\n",sDMLno);	
													decision = EPM_nogo;
													return decision;
												}
												printf("\n PO:GM:NA-status available.\n");fflush(stdout);
												if((tc_strcmp(DMLtype,"TODR")==0) && ((tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)|| (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)|| (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0)||(tc_strcmp(PlntToPlnt,"AR3 to AR4")==0)||(tc_strcmp(PlntToPlnt,"AR4 to AR5")==0)||(tc_strcmp(PlntToPlnt,"DR3 to DR4")==0)||(tc_strcmp(PlntToPlnt,"DR4 to DR5")==0)))
												{
													printf("\n PO:GM: PO FirstCheckOK for DML:%s \n",sDMLno);fflush(stdout);
													if((sDml_TP==NULL)|| (tc_strcmp(sDml_TP,"")==0))
													{
														printf("\n PO:ERROR: Target plant should not be NULL for DML.\n");fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"DML not having valid target plant. Please update valid target plant and then sign off DML.\n",sDMLno);	
														decision = EPM_nogo;
														return decision;
													}
												}
												//Check For Empty task.
												if(strstr(sPOCHKInfo3,"EMP001")==NULL)
												{
													printf("\n PO:Checking GMD empty task.\n");fflush(stdout);
													if(AOM_ask_value_string(taskAttachments[i],"item_id",&staskId)!=ITK_ok)PrintErrorStack();
													if(GRM_find_relation_type("CMReferences", &spCMRefrel)!=ITK_ok)PrintErrorStack();
													if(GRM_list_secondary_objects_only(taskAttachments[i],spCMRefrel,&spPartCnt,&spPartTags)!=ITK_ok)PrintErrorStack();
													printf("\n T5TaskToPartCreateVal-->spPartCnt [%s] [%d].\n",staskId,spPartCnt); fflush(stdout);
													if (spPartCnt == 0)
													{
														printf("\n PO:ERROR: GMD having empty task.\n");fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR: Change reference folder of task is empty.Empty Task sign off is not allowed.\n Please attach Component/Assy/Module/VC to valid DML task�s change references folder or abort DML and delete task.\n",staskId);	
														decision = EPM_nogo;
														return decision;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_POChkStopAtFVali Function end...");fflush(stdout);
	TC_write_syslog("\n tm_POChkStopAtFVali Function end...");
	return decision;
}
