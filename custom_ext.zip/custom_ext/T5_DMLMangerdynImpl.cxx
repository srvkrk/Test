//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_DMLMangerdynImpl
//

#include <T5_AssignDynParty/T5_DMLMangerdynImpl.hxx>


#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define ITK_error2 (EMH_USER_error_base+80)
using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_DMLMangerdynImpl::T5_DMLMangerdynImpl(T5_DMLMangerdyn& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_DMLMangerdynImpl::T5_DMLMangerdynImpl( T5_DMLMangerdyn& busObj )
   : T5_DMLMangerdynGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_DMLMangerdynImpl::~T5_DMLMangerdynImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_DMLMangerdynImpl::~T5_DMLMangerdynImpl()
{
}

//----------------------------------------------------------------------------------
// T5_DMLMangerdynImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_DMLMangerdynImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_DMLMangerdynGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///

int getDmlManagerValue (const char *DesignGrp,int* count, tag_t** items)
{
        int ifail = ITK_ok;
        int n_entries = 3;
        int resultCount = 0;
        char *qry_entries[] = {(char *)"Name",(char *)"Role",(char *)"Status"};

        tag_t queryTag = NULLTAG;
        tag_t *partObjs = NULLTAG;

        char *GroupName = NULL;
        char *RoleName = NULL;
        char *Status = NULL;
        GroupName = (char *)MEM_alloc(50*sizeof(char));
        RoleName = (char *)MEM_alloc(50*sizeof(char));
        Status = (char *)MEM_alloc(50*sizeof(char));

        tc_strcpy(GroupName,"");
        tc_strcat(GroupName,"ERC_Designers_Group");

        RoleName = tc_strcpy(RoleName,"");
        RoleName = tc_strcat(RoleName,DesignGrp);
        RoleName = tc_strcat(RoleName,"_Managers");
		
		tc_strcpy(Status,"");
        tc_strcat(Status,"0");
		
        printf("\nValues before query are as below  --> Rolename [%s] Group name[%s]  Status [%s] >>\n",RoleName,GroupName,Status);fflush(stdout);

        char  *qry_values[] = {(char *)GroupName,(char *)RoleName,(char *)Status};

        printf("\nGet_Part_Details Quering GroupName [%s] RoleName [%s]",GroupName,RoleName);

        ifail =(QRY_find2("DML_DYN_PARTY", &queryTag));

        if (queryTag)
        {
                ifail =(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
                printf("\nParticipants count in TCUA : [%d]",resultCount);

                *count = resultCount;


                        printf("\n\n getDMLManagerlist = %d\n",*count);fflush(stdout);
                        (*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
                        int i=0;
                        for(i=0;i<*count;i++)
                                        {
                                                        (*items)[i] = partObjs[i];
                                        }


        }


        return ifail;


}

int  T5_DMLMangerdynImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;
    std::vector<std::string> Design_group;
    std::vector<int> isNull_1;
   // char *ErrorMessage = NULL;
    int error_flag = 0;
//ErrorMessage = (char *)MEM_alloc(300);

printf("\n--->>>>> T5_DMLMangerdynImpl::In NOT NULL 11111111");fflush(stdout);

    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation
try
                        {
                    //  list_displayable_properties_with_value(operationInputTag);
                                Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
                                (Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
								
                                if( refOprtnInput!=NULL )
                                {
									    refOprtnInput->getStringArray("t5_crdesigngroup",Design_group,isNull_1);
										// printf("\nDes_grp for DML manager : [%s]",Design_group[0].c_str());

                                       // tc_strcpy(ErrorMessage,"Please select below Required Field before Click DML Manager!\n");

                                              if(isNull_1.size()==0)
                                                {
                                                     printf("\nDes_grp is not selected");
                                                        error_flag++;
                                                        //tc_strcat(ErrorMessage,"Design group");

                                                }

              printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
                                             if(error_flag>0)
                                                {

                                                        EMH_clear_errors();
                                                        EMH_store_error_s1(EMH_severity_error,ITK_error2,"Please select design group before here!\n");
                                                        (*results)=NULLTAG;
                                                        *nResults=0;
                                                        return(ITK_error2);
                                                }
                                           if(error_flag==0)
                                                {
                                                        printf("\n Before Call T5_DmlManagerLov::getDmlManagerValue");fflush(stdout);
                                                        printf("\nSelected design group -->[%s] >>\n",Design_group[0].c_str());fflush(stdout);

                                                                                                        (*results)=NULLTAG;
                                                                                                        *nResults=0;
                                                                                                        (*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
                                                                                                        getDmlManagerValue(Design_group[0].c_str(),nResults, results);
                                                                                                        printf("\n After Call T5_DmlManagerLov::getDmlManagerValue");fflush(stdout);
                                                }
                                }
                                else
                                                        {
                                                                printf("\n--->>>>> In  NULL refinputtag");fflush(stdout);
                                                        }

                        }
                        catch( const IFail& ex )
                        {
                           ifail = ex.ifail();
                        }

    return ifail;
}
