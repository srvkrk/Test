/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Ajinkya
*  Module               :   ..
*  Code                 :   tm_DML_WF_Submit_Chk.c
*  Created on			:  
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
***************************************************************************/

#include "TMLLibrary_server_exits.h"

EPM_decision_t tm_DML_WF_Submit_Chk(EPM_rule_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *sDMLReltyp		= NULL;
	char *sDMLSUBInfo1		= NULL;
	char *sDMLSUBInfo2		= NULL;
	char *DMLRlztp		= NULL;
	char *sDMLno		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char*	CurrentTask				=NULL;
	int status_count = 0;
	int RelStusFnd = 0;
	int k1 = 0;
	char *latest_rev_Rel_Stus1 = NULL;
	tag_t *relStatus_list = NULLTAG;

	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	EPM_decision_t decision = EPM_go;
	
	printf("\n tm_DML_WF_Submit_Chk Function started...");fflush(stdout);
	TC_write_syslog("\n tm_DML_WF_Submit_Chk Function started...");
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	printf("\n Root task found..");fflush(stdout);
	if(AOM_ask_value_string(msg.task,"object_name",&CurrentTask)!=ITK_ok)PrintErrorStack();
	printf("\n CurrentTask.:%s\n",CurrentTask);fflush(stdout);

	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n DMLSUB:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n DMLSUB: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				if(AOM_ask_value_string(taskAttachments[i],"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
				printf("\n sDMLno:%s.",sDMLno);fflush(stdout);
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n DMLSUB:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n DMLSUB:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "DMLSUB";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n DMLSUB:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					//PO bypass
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo1",&sDMLSUBInfo1)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo2",&sDMLSUBInfo2)!=ITK_ok)   PrintErrorStack();
					printf("\n DMLSUB:  sDMLSUBInfo1:%s & sDMLSUBInfo2 [%s]\n",sDMLSUBInfo1,sDMLSUBInfo2);fflush(stdout);
					if(strstr(sDMLSUBInfo1,"DML001")==NULL)
					{
						if(AOM_ask_value_string(taskAttachments[i],"t5_rlstype",&sDMLReltyp)!=ITK_ok)PrintErrorStack();
						printf("\n DMLSUB:sDMLReltyp:%s.",sDMLReltyp);fflush(stdout);
						DMLRlztp = MEM_alloc(100);
						tc_strcpy(DMLRlztp,"");
						tc_strcpy(DMLRlztp,",");
						tc_strcat(DMLRlztp,sDMLReltyp);
						tc_strcat(DMLRlztp,",");
						printf("\n DMLSUB::DMLRlztp.:%s \n",DMLRlztp);fflush(stdout);
						if(tc_strstr(sDMLSUBInfo1,DMLRlztp) != NULL)
						{
							printf("\n DMLSUB::DML submition not alowed.\n");fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:This release type of DML if not allowed to submit to 'Change request life cycle  workflow.\n If it it vehicle release type DML, then submit to 'VC/CCV Release Workflow'.\n If still any query, please raise ticket in TMS under DML workflow category.",sDMLno);	
							decision = EPM_nogo;
							return decision;
						}
						else
						{
							printf("\n DMLSUB:Allow to submit this DML type.. \n");fflush(stdout);
						}
					}
					
					if(strstr(sDMLSUBInfo2,"Rlz001")==NULL)
					{
						WSOM_ask_release_status_list(taskAttachments[i], &status_count, &relStatus_list);
						printf("\n\t WSOM_ask_release_status_list count is :: %d\n",status_count);fflush(stdout);

						if (status_count > 0)
						{
							for (k1=0;k1 < status_count; k1++)
							{
								AOM_ask_value_string(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus1);
								printf("\n\t %d. Release status is : %s>>>>>>>>>\n",k1,latest_rev_Rel_Stus1);fflush(stdout);
								if ((tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(latest_rev_Rel_Stus1,"ERC Released")==0))
								{
									printf("\n\t Release status found for the DML : %s\n",sDMLno);fflush(stdout);
									RelStusFnd = 1;
									printf("\n\t RelStusFnd Set to 1");fflush(stdout);
									break;
								}
							}
							if (RelStusFnd > 0)
							{
								printf("\n DMLSUB::DML submition not alowed, DML is in Released Stage.\n");fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s2(EMH_severity_error,PO_BASIC_VALI,"ERROR:This DML submition not alowed, DML is in Released Stage ::",sDMLno);	
								decision = EPM_nogo;
								return decision;
							}
						}
					}			
				}
			}
		}
	}
	
	/*if(CurrentTask){MEM_free(CurrentTask);}
	if(sDMLno){MEM_free(sDMLno);}
	if(sDMLSUBInfo1){MEM_free(sDMLSUBInfo1);}
	if(sDMLSUBInfo2){MEM_free(sDMLSUBInfo2);}
	if(sDMLReltyp){MEM_free(sDMLReltyp);}
	if(latest_rev_Rel_Stus1){MEM_free(latest_rev_Rel_Stus1);}*/
	printf("\n tm_DML_WF_Submit_Chk Function end...");fflush(stdout);
	TC_write_syslog("\n tm_DML_WF_Submit_Chk Function end...");
	return decision;
}
