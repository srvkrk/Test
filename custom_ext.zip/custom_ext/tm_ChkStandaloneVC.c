/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   To check standalone VC.
*  Code                 :   tm_ChkStandaloneVC.c
*  Created on			:   21/04/2023
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 21/04/2023				Mohan Tayade			 To check standalone VC.
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_ChkStandaloneVC(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int error_code			= ITK_ok;
	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	int	taskflag =0;
	char *dmlTaskNo= NULL;
	char *DMLtype= NULL;
	char * sDMLno= NULL;
	char * DMLprirty= NULL;
	char * sFormDesc= NULL;
	char * sDMLRoute= NULL;
	char * sVehForm= NULL;
	char * VCInfo1= NULL;
	tag_t  objTypTag = NULLTAG;
	tag_t  DMLRevTg = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  *DMLRevision = NULLTAG;
	char*	ObjTyp =NULL;
	tag_t  DMLTaskTag = NULLTAG;
	logical is_latest;
	//control logic:
	tag_t   VCqryTag		= NULLTAG;
	int     VC_n_entry		= 1;
	int     VC_rsltCount	= 0;
	char    *VC_qry_entry[1]  = {"SYSCD"};
	tag_t   *VCCntrlObjectTag   = NULLTAG;
	char    **VC_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	//Query Form
	//char **FR_qry_entry = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t   FRqryTag		= NULLTAG;
	int     FR_n_entry		= 2;
	char    *FR_qry_entry[2]  = {"Name","Type"};
	char    **FR_qry_values2     =  (char **) MEM_alloc(100 * sizeof(char *));
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	sVehForm = (char	*)MEM_alloc(100);

	//EPM_decision_t decision = EPM_go;
	
	printf("\n tm_ChkStandaloneVC Function started...");fflush(stdout);
	TC_write_syslog("\n tm_ChkStandaloneVC Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n STD:P2:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n STD:P3:INSIDE Attachments.");fflush(stdout);
			DMLTaskTag=taskAttachments[i];
			if (DMLTaskTag != NULLTAG)
			{
				printf("\n STD:P5:getting typ.");fflush(stdout);
				if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n STD:P6: Workfow obj type: [%s] ", ObjTyp);fflush(stdout);

				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
					printf("\n STD:P4--DML Task No: [%s] ", dmlTaskNo);fflush(stdout);
					taskflag=0;
					if(tc_strstr(dmlTaskNo,"_00")!=NULL)
					{
						taskflag=1;
					}
					printf("\n STD:P5--taskflag= %d ",taskflag);fflush(stdout);
					//Control object logic:
					if(QRY_find2("ControlObjects", &VCqryTag));
					if (VCqryTag)
					{
						printf("\n STD:P7:Found Query ControlObjects.");fflush(stdout);
					}
					else
					{
						printf("\n STD:P7:Not Found Query ControlObjects \n");fflush(stdout);
					}

					VC_qry_values2[0] = "STDALONE";
					if(QRY_execute(VCqryTag, VC_n_entry, VC_qry_entry, VC_qry_values2, &VC_rsltCount, &VCCntrlObjectTag));
					printf(" \n STD:P8:VC_rsltCount:%d:", VC_rsltCount); fflush(stdout);
					if(VC_rsltCount > 0)
					{
						if (AOM_ask_value_string(VCCntrlObjectTag[0],"t5_Userinfo1",&VCInfo1)!=ITK_ok)   PrintErrorStack();
						printf("\n STD:P9:VCInfo1 is :[%s]", VCInfo1);fflush(stdout);
						if(strstr(VCInfo1,"STD001")==NULL)
						{
							if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
							if (tsk_dml_rel_type!=NULLTAG)
							{
								if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
								printf("\n STD:P10--DML Revision from Task for : [%d]",countt);fflush(stdout);
								for (j=0;j<countt ;j++ )
								{
									if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
									printf("\n STD:P11:is_latest  is : [%d]",is_latest);fflush(stdout);

									if(is_latest != true)
									{
										printf("\n STD:P12:is_latest is not true .....\n");fflush(stdout);
									}
									else
									{
										DMLRevTg = DMLRevision[j];
										if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
										printf("\n STD:P13: for sDMLno : [%s] ",sDMLno);fflush(stdout);
										if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
										printf(" Release Type: [%s]", DMLtype); fflush(stdout);
										if(AOM_ask_value_string(DMLRevTg,"t5_cpriority",&DMLprirty)!=ITK_ok)PrintErrorStack();
										printf(" DMLprirty: [%s]\n", DMLprirty); fflush(stdout);
										//Form check here
										if(strstr(VCInfo1,"STD002")==NULL)
										{
											//Vehicle without SVR 
											//Vehicle with SVR and Platform
											tc_strcpy(sVehForm,"");
											tc_strcpy(sVehForm,sDMLno);
											tc_strcat(sVehForm,"*");
											printf("\n STD:P14: DML Form check start here.....:[%s]\n",sVehForm);fflush(stdout);
											/*const char *VCattrs2[2];
											const char *VCvalues2[2];
											VCattrs2[0] ="object_name";
											VCattrs2[1] ="object_type";
											VCvalues2[0] = (char *)sDMLno;
											VCvalues2[1] = "Veh Dml Form";
											if(ITEM_find_items_by_key_attributes(2,VCattrs2, VCvalues2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
											printf("\n STD:14:Veh DML form count :[%d].", n_tags_found2);fflush(stdout);*/
											if(QRY_find2("tm_Veh_DML_Form_Query", &FRqryTag));
											if (FRqryTag)
											{
												printf("\n STD:P14:Found Query ControlObjects.");fflush(stdout);
											}
											else
											{
												printf("\n STD:P14:Not Found Query ControlObjects \n");fflush(stdout);
											}
											
											FR_qry_values2[0] = sVehForm;
											FR_qry_values2[1] = "Veh Dml Form";
											if(QRY_execute(FRqryTag, FR_n_entry, FR_qry_entry, FR_qry_values2, &n_tags_found2, &tags_found2));
											printf(" \n STD:P14:n_tags_found2:%d:", n_tags_found2); fflush(stdout);
											if (n_tags_found2>0)
											{
												OutPutTag= tags_found2[0];
												if(AOM_ask_value_string(OutPutTag,"t5_VehicleDMLRoute",&sDMLRoute)!=ITK_ok)PrintErrorStack();
												printf("\n STD:P15: sDMLRoute : [%s] ",sDMLRoute);fflush(stdout);
												if(AOM_ask_value_string(OutPutTag,"object_desc",&sFormDesc)!=ITK_ok)PrintErrorStack();
												printf(" sFormDesc: [%s]", sFormDesc); fflush(stdout);
												if ((tc_strcmp(DMLtype,"TODR")==0)||(tc_strcmp(DMLtype,"Veh")==0))	//for Gate Maturation and Vehicle release
												{
													//Priority High means: SVR VC case.
													if(tc_strcmp(sDMLRoute,"Vehicle with SVR and Platform")==0)
													{
														if (taskflag==1)
														{
															printf("\n STD:P16: SVR VC and 00 task.:retur-1:SVR Way:Run_BOM\n");fflush(stdout);
															return 1;
														}
														else
														{
															printf("\n STD:P17:SVR VC and Other task.:retur-10001 : for SVR Way:PSE\n");fflush(stdout);
															return 10001;
														}
													}
													else
													{
														printf("\n STD:P18:stand-alone VC case:retur- 0: Standalone way. \n");fflush(stdout);
														return 0;
													}
												}
												else
												{
													printf("\n STD:P19:Not for DML type. \n");fflush(stdout);
													return 0;
												}
											}
										}
										else if(strstr(VCInfo1,"STD003")==NULL)
										{
											if ((tc_strcmp(DMLtype,"TODR")==0)||(tc_strcmp(DMLtype,"Veh")==0))	//for Gate Maturation and Vehicle release
											{
												//Priority High means: SVR VC case.
												if(tc_strcmp(DMLprirty,"High")==0)
												{
													if (taskflag==1)
													{
														printf("\n STD:P20: SVR VC and 00 task.....\n");fflush(stdout);
														return 1;
													}
													else
													{
														printf("\n STD:P21:SVR VC and Other task..... \n");fflush(stdout);
														return 10001;
													}
												}
												else
												{
													printf("\n STD:P22:stand-alone VC case \n");fflush(stdout);
													return 0;
												}
											}
											else
											{
												printf("\n STD:P23:Not for DML type. \n");fflush(stdout);
												return 0;
											}
										}
										else
										{
											//ALl will be for SVR way..
											if ((tc_strcmp(DMLtype,"TODR")==0)||(tc_strcmp(DMLtype,"Veh")==0))	//for Gate Maturation and Vehicle release
											{
												//Priority High means: SVR VC case.
												if(tc_strcmp(DMLprirty,"High")==0)
												{
													if (taskflag==1)
													{
														printf("\n STD:P20: SVR VC and 00 task.....\n");fflush(stdout);
														return 1;
													}
													else
													{
														printf("\n STD:P21:SVR VC and Other task..... \n");fflush(stdout);
														return 10001;
													}
												}
												else
												{
													//printf("\n STD:P22:stand-alone VC case \n");fflush(stdout);;;;
													if (taskflag==1)
													{
														printf("\n STD:P20: SVR VC and 00 task.....\n");fflush(stdout);
														return 1;
													}
													else
													{
														printf("\n STD:P21:SVR VC and Other task..... \n");fflush(stdout);
														return 10001;
													}
												}
											}
											else
											{
												printf("\n STD:P23:Not for DML type. \n");fflush(stdout);
												return 0;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_ChkStandaloneVC Function end...");fflush(stdout);
	TC_write_syslog("\n tm_ChkStandaloneVC Function end...");
	//return error_code;
	return 0;
}