//#define _CRT_SECURE_NO_DEPRECATE
//import_uiconfig -u=infodba -p=infodba -g=dba -file=T5_Package_qryResult_Package.txt -action=override

#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define NO_OF_PARTS 200
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/custom.h>
#include <tccore/grm_msg.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <cfm/cfm.h>
//#include <sys/time.h>
#include <time.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

int tm_fctn_CabinKitAppbUpd_action_handler ( EPM_action_message_t msg ) ;
int tm_fctn_CabinKitCre_action_handler ( EPM_action_message_t msg ) ;
extern EPM_decision_t DLLAPI tm_fctn_CabinKitAppbUpd_rule_handler ( EPM_rule_message_t msg ) ;
extern EPM_decision_t DLLAPI tm_fctn_CabinKitCre_rule_handler ( EPM_rule_message_t msg ) ;
extern int tm_CabinKitAppbUpd_register_method ( int *decision, va_list args ) ;


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ExpandMultilvlforP(tag_t ,char *,tag_t , tag_t , tag_t ,tag_t );
int ExpandMultilvlforGroupid(tag_t ,char *, tag_t ,tag_t ,tag_t , tag_t);

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf(" %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog(" %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
int tm_check_control_object_UCKA ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ; 
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	return n_found ;
}
int tm_check_control_object_CKC ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ; 
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	return n_found ;
}
int GetPartListfromFile_task(tag_t task_tag,char **ret_File_dml_PartList,int *nPartCount,char *ftn_dml_no)
{
	tag_t dml_task_rel_type = NULLTAG;
	tag_t *dml_Tags = NULLTAG;
	int dml_count = 0 ;
	int t3_counter = 0;
	char *object_type = NULL;
	char *DMLtype = NULL;
	char *BusinessUnit = NULL;
	char *erc_dml_no = NULL;
	tag_t dml_dataset_rel_type = NULLTAG;
	int dml_ref_datasetCount = 0;
	tag_t *dml_data_setTags = NULLTAG;
	char **FileD_Part_List = NULL;
	int i_dml_PartCntr = 0;
	int dml_dataset_Count = 0;
	i_dml_PartCntr = 0;
	tag_t dml_text_data_file_tag = NULLTAG;
	AE_reference_type_t ref_type;
	IMF_file_t file_dml_descriptor = NULL;
	int iPart_d_Cntr = 0;
	//char text_line[SS_MAXLLEN+1];
	char *text_line=NULL;
						
	printf("\nIn call GetPartListfromFile_task");
	TC_write_syslog("\nIn call GetPartListfromFile_task");

	ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_task_rel_type ) ) ;
	ITK_CALL ( GRM_list_primary_objects_only ( task_tag, dml_task_rel_type, &dml_count, &dml_Tags ) ) ;//task to text dataset expand
	if ( dml_count > 0 )
	{
		for( t3_counter = 0 ; t3_counter < dml_count; t3_counter++ )
		{
			printf("\n\nfor Loop t3_counter: [%d]",t3_counter);
			TC_write_syslog("\n\nfor Loop t3_counter: [%d]",t3_counter);
			ITK_CALL ( AOM_ask_value_string(dml_Tags[t3_counter],"item_id",&erc_dml_no) );

			tc_strcpy ( ftn_dml_no, erc_dml_no ) ;
			printf("\nCabinKit erc_dml_no 3 : [%s] ftn_dml_no : [%s]",erc_dml_no,ftn_dml_no);fflush(stdout);
			TC_write_syslog("\nCabinKit erc_dml_no 3 : [%s] ftn_dml_no : [%s]",erc_dml_no,ftn_dml_no);fflush(stdout);

			ITK_CALL ( AOM_ask_value_string(dml_Tags[t3_counter],"object_type",&object_type) );
			printf("\nCabinKitobject_type 3 : [%s]",object_type);fflush(stdout);
			TC_write_syslog("\nCabinKitobject_type 3 : [%s]",object_type);fflush(stdout);
			if ( tc_strcmp(object_type,"ChangeRequestRevision" ) == 0 )//TargetObject ChangeRequestRevision
			{
				ITK_CALL(AOM_ask_value_string(dml_Tags[t3_counter],"t5_rlstype",&DMLtype));
				printf("\nCabinKitDMLtype 3 : [%s]",DMLtype);fflush(stdout);
				TC_write_syslog("\nCabinKitDMLtype 3 : [%s]",DMLtype);fflush(stdout);
				if ( tc_strcmp ( DMLtype, "UCKA" ) == 0 )
				{
					ITK_CALL ( AOM_ask_value_string(dml_Tags[t3_counter], "t5_ERCBusiUt",&BusinessUnit) );
					printf("\nCabinKitBusinessUnit 3 : [%s]",BusinessUnit);fflush(stdout);
					TC_write_syslog("\nCabinKitBusinessUnit 3 : [%s]",BusinessUnit);fflush(stdout);
					if ( tc_strcmp ( BusinessUnit, "CVBU" ) == 0 )
					{
						ITK_CALL ( GRM_find_relation_type ( "IMAN_reference", &dml_dataset_rel_type ) ) ;
						ITK_CALL ( GRM_list_secondary_objects_only ( dml_Tags[t3_counter], dml_dataset_rel_type, &dml_ref_datasetCount, &dml_data_setTags ) ) ;//task to text dataset expand

						if ( dml_ref_datasetCount > 0 )	//if ref dataset is attached allocate memory for parts
						{
							FileD_Part_List = ( char** ) MEM_alloc ( NO_OF_PARTS * sizeof *FileD_Part_List ) ;
						}
						for ( iPart_d_Cntr = 0 ; iPart_d_Cntr < NO_OF_PARTS ; iPart_d_Cntr++ )//allocate memory for each part string in file
						{
							FileD_Part_List[iPart_d_Cntr] = ( char *) MEM_alloc ( 50 * sizeof(char) ) ;
							memset ( FileD_Part_List[iPart_d_Cntr], 0, 50 * sizeof (char) );
						}
						
						for (dml_dataset_Count = 0; dml_dataset_Count < dml_ref_datasetCount ; dml_dataset_Count++)
						{
							printf("\n\ndml dataset Count : [%d]",dml_dataset_Count);
							ITK_CALL(AOM_refresh(dml_data_setTags[dml_dataset_Count], TRUE));
							//ITK_CALL(AE_ask_dataset_named_ref(dml_data_setTags[dml_dataset_Count], "Text",  &ref_type, &dml_text_data_file_tag));
							ITK_CALL(AE_ask_dataset_named_ref2(dml_data_setTags[dml_dataset_Count], "Text",  &ref_type, &dml_text_data_file_tag));//replace depricate Apis Shubham
							if (dml_text_data_file_tag == NULLTAG) continue;
							ITK_CALL(AOM_refresh(dml_text_data_file_tag, TRUE));
						
							ITK_CALL(IMF_ask_file_descriptor(dml_text_data_file_tag, &file_dml_descriptor));
							ITK_CALL(IMF_open_file(file_dml_descriptor, SS_RDONLY));
							char *local_part_no = NULL;
							char *local_part_appb = NULL;
							local_part_appb = MEM_alloc ( 50 * sizeof ( char ) ) ;

							i_dml_PartCntr = 0;
							while (IMF_read_file_line2(file_dml_descriptor, &text_line) == ITK_ok)
							{
								tc_strcpy(FileD_Part_List[i_dml_PartCntr],text_line);
								printf("\nReading from dml file : [%s]", FileD_Part_List[i_dml_PartCntr]);
								TC_write_syslog("\nReading from dml file : [%s]", FileD_Part_List[i_dml_PartCntr]);
								if ( tc_strstr ( FileD_Part_List[i_dml_PartCntr], "," ) != NULL )	
								{
									tc_strcpy( local_part_appb, FileD_Part_List[i_dml_PartCntr] ) ;
									local_part_no = tc_strtok ( local_part_appb, "," ) ;
									tc_strcpy( ret_File_dml_PartList[i_dml_PartCntr], local_part_no ) ;

									printf("\nPart fun GetPartListfromFile_task : [%s]", ret_File_dml_PartList[i_dml_PartCntr]);
									TC_write_syslog("\nPart fun GetPartListfromFile_task : [%s]", ret_File_dml_PartList[i_dml_PartCntr]);
								
								}
								i_dml_PartCntr = i_dml_PartCntr + 1;
						
							}
							*nPartCount = i_dml_PartCntr;
							printf("\nNo of part found in file count : [%d]", *nPartCount);
							TC_write_syslog("\nNo of part found in file count : [%d]", *nPartCount);
								
							ITK_CALL(IMF_close_file(file_dml_descriptor));
							ITK_CALL(AOM_unload(dml_text_data_file_tag));
							ITK_CALL(AOM_unload(dml_data_setTags[dml_dataset_Count]));
						}

					}
				}
			}
		}
	}



	return 0;
}
extern EPM_decision_t DLLAPI tm_fctn_CabinKitAppbUpd_rule_handler( EPM_rule_message_t msg )
{
	EPM_decision_t decision = EPM_go;

	char* object_type = NULL;
	int t = 0;
	tag_t rootTask = NULLTAG;
	tag_t *attachments = NULLTAG;
	char* parent_name = NULL;
	int noAttachment = 0;
	char* CurrentTask = NULL;
	char **File_dml_PartList = NULL;
	int nPartCount = 0;
	char *CabinKitAppbVal = NULL;
	int refPartCount_1 = 0;
	int refdatasetCount = 0;
	int part_Counter = 0;
	int part_t_Count = 0;
	int part_u_Count = 0;
	int datasetCount = 0;
	tag_t task_part_rel_type = NULLTAG;
	tag_t task_dataset_rel_type = NULLTAG;
	tag_t *datasetTags = NULLTAG;
	tag_t *Part_dml_Tags = NULLTAG;
	AE_reference_type_t ref_type;
	tag_t text_file_tag = NULLTAG;
	char *DMLtype = NULL;
	char *BusinessUnit = NULL;
	int iPart_d_Cntr = 0 ;
	char *erc_dml_no = NULL;
	char *erc_task_no = NULL;
	int ii = 0 ;
	char *name = NULL ;
	char *value = NULL ;
	char **props = NULL ;
	int n_props = 0 ;
	char TxtFnameOfDataset[200] = { 0 } ;
	int t1 = 0;
	char *DupPartList = NULL;
	int DupPartFound = 0;
	char *d_Part_id = NULL;
	char **ref_rel_dml_PartList = NULL;
	int ref_part_found_flag = 0;
	char *cNot_Found_in_taskref_part = NULL;
	int i_No_Match_flag = 0 ;
	int iPart_d1_Cntr = 0;
	int iCounter = 0;
	int jCounter = 0;
	char *ftn_dml_no = NULL;
	int file_part_found_flag = 0;
	int n_UCKA_obj = 0;				
					
						
	CabinKitAppbVal = MEM_alloc ( 10 * sizeof ( char ) ) ;	
		
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nCabinKit Rule Handler started"); fflush(stdout);
	TC_write_syslog("\nCabinKit Rule Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCabinKit Rule CurrentTask : [%s]",CurrentTask);
	TC_write_syslog("\nCabinKit Rule CurrentTask : [%s]",CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nCabinKit Rule Parent Name : [%s]",parent_name);fflush(stdout);
	TC_write_syslog("\nCabinKit Rule Parent Name : [%s]",parent_name);fflush(stdout);

	if(strstr(parent_name,"Cabin Kit task Workflow")!=NULL)//workflowname subprocess name to add part to task
	{
			//error_919002, "You have not attached the part to SolutionItems. This will not be considered for release1"
			if(strstr(CurrentTask,"Add Cabin Kit")!=NULL)//do task
			{
				n_UCKA_obj = tm_check_control_object_UCKA ( "UCKA_CO", "ON" );
				if (n_UCKA_obj > 0 )
				{
					printf("\ncondition Rule CurrentTask_2 : [%s]",CurrentTask);
					TC_write_syslog("\ncondition Rule CurrentTask_2 : [%s]",CurrentTask);
					ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
					printf("\nCabinKitTarget Rule Attachment 2 : [%d]",noAttachment);fflush(stdout);
					TC_write_syslog("\nCabinKitTarget Rule Attachment 2 : [%d]",noAttachment);fflush(stdout);

					if( noAttachment > 0)
					{
						for( t1 = 0 ; t1 < noAttachment; t1++ )
						{
							printf("\n\nfor 2 Rule Loop t: [%d]",t1);
							TC_write_syslog("\n\nfor 2 Rule Loop t: [%d]",t1);
							ITK_CALL ( AOM_ask_value_string(attachments[t1],"item_id",&erc_task_no) );
							printf("\nCabinKiterc 2 Rule erc_task_no : [%s]",erc_task_no);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Rule erc_task_no is : [%s]",erc_task_no);fflush(stdout);

							//task to part expand
							ITK_CALL ( GRM_find_relation_type ( "CMReferences", &task_part_rel_type ) ) ;
							ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t1], task_part_rel_type, &refPartCount_1, &Part_dml_Tags ) ) ;//task to dml traversal
							
							if ( refPartCount_1 <= 0 )
							{
								printf("\nCabinKiterc Rule cNot_Found_in_taskref_part : [%d] , Attach Parts in Change References relation in task as per TXT attachment to DML",refPartCount_1);fflush(stdout);
								TC_write_syslog("\nCabinKit Rule cNot_Found_in_taskref_part is : [%d] , Attach Parts in Change References relation in task as per TXT attachment to DML",refPartCount_1);fflush(stdout);

								EMH_store_error_s1(EMH_severity_warning,ITK_err, "Attach Parts in Change References relation in task as per TXT attachment to DML");
								decision = EPM_nogo;
								return decision;
							}

							ref_rel_dml_PartList = ( char** ) MEM_alloc ( NO_OF_PARTS * sizeof *ref_rel_dml_PartList ) ;
							for ( iPart_d1_Cntr = 0 ; iPart_d1_Cntr < NO_OF_PARTS ; iPart_d1_Cntr++ )//allocate memory for each part string in file
							{
								ref_rel_dml_PartList[iPart_d1_Cntr] = ( char *) MEM_alloc ( 50 * sizeof(char) ) ;
								memset ( ref_rel_dml_PartList[iPart_d1_Cntr], 0, 50 * sizeof (char) );
							}

							for ( part_Counter = 0; part_Counter < refPartCount_1 ; part_Counter++)
							{
								printf("\n\npart_Counter Rule : [%d]",part_Counter);
								TC_write_syslog("\n\npart_Counter Rule : [%d]",part_Counter);
					
								ITK_CALL(AOM_ask_value_string(Part_dml_Tags[part_Counter],"item_id",&d_Part_id));
								tc_strcpy ( ref_rel_dml_PartList[part_Counter], d_Part_id ) ;
								printf("\nvRule for d_Part_id : [%s] \n",d_Part_id);fflush(stdout);
								TC_write_syslog("\nRule for d_Part_id : [%s] \n",d_Part_id);fflush(stdout);
							}

							printf("\nRule total part atached refPartCount_1 : [%d]",refPartCount_1);
							TC_write_syslog("\nRule total part atached refPartCount_1 : [%d]",refPartCount_1);

							//-----------------------get Part list from file and check duplicate part in file------------------

							
							File_dml_PartList = ( char** ) MEM_alloc ( NO_OF_PARTS * sizeof *File_dml_PartList ) ;
							for ( iPart_d_Cntr = 0 ; iPart_d_Cntr < NO_OF_PARTS ; iPart_d_Cntr++ )//allocate memory for each part string in file
							{
								File_dml_PartList[iPart_d_Cntr] = ( char *) MEM_alloc ( 50 * sizeof(char) ) ;
								memset ( File_dml_PartList[iPart_d_Cntr], 0, 50 * sizeof (char) );
							}

							printf("\nbefore call Rule GetPartListfromFile_task");
							TC_write_syslog("\nbefore call Rule GetPartListfromFile_task");

							ftn_dml_no = MEM_alloc ( 50 );

							GetPartListfromFile_task(attachments[t1],File_dml_PartList,&nPartCount,ftn_dml_no);

							tc_strcpy ( erc_dml_no, ftn_dml_no ) ;
							
							DupPartList = MEM_alloc ( 5000 * sizeof ( char ) );
							DupPartFound = 0;
							tc_strcpy( DupPartList, "Remove Duplicate Part from TXT file : " );

							

							for ( part_t_Count = 0; part_t_Count < nPartCount ; part_t_Count++ )
							{
								printf("\nAdd Cabin Kit Rule Part [%d] : [%s]",part_t_Count,File_dml_PartList[part_t_Count]);
								TC_write_syslog("\nAdd Cabin Kit Rule Part [%d] : [%s]",part_t_Count,File_dml_PartList[part_t_Count]);
									
								for ( part_u_Count = part_t_Count + 1 ; part_u_Count < nPartCount ; part_u_Count++ )
								{
									if (tc_strcmp ( File_dml_PartList[part_t_Count], File_dml_PartList[part_u_Count]) == 0 )
									{
										if (tc_strstr(DupPartList,File_dml_PartList[part_t_Count])== NULL)
										{
											tc_strcat ( DupPartList, File_dml_PartList[part_t_Count] ) ;
											tc_strcat ( DupPartList, ":" ) ;
											DupPartFound = DupPartFound + 1 ;
										}
										else
										{
											printf("\nPresent in duplicate part list hence skipping");
											TC_write_syslog("\nPresent in duplicate part list hence skipping");
										}
									}
								}
							}
							printf("\nNo of Duplicate Part found in file : %d",DupPartFound);
							TC_write_syslog("\nNo of Duplicate Part found in file : %d",DupPartFound);
							if ( DupPartFound > 0)
							{
								//EMH_store_error_s3(EMH_severity_error,ITK_err, "Cabin Kit assignment -> Add Cabin Kit, Sign Off is not Allowed, reason : ",ErrorMessage,DupPartList);
								EMH_store_error_s1(EMH_severity_warning,ITK_err, DupPartList);
								decision = EPM_nogo;
								return decision;
								//EMH_store_error_s1(EMH_severity_error,ITK_err,DupPartList);
								//return ITK_err;
							}

							//-----------------------check part attached to task and part present in file are matching-------------------
							//refPartCount_1 variable for part attached to dml task set anme is "ref_rel_dml_PartList"
							//nPartCount variable for part list from text dataset namereference	set name is "File_dml_PartList"
							

							//checking file part list in reference relation
							cNot_Found_in_taskref_part = MEM_alloc ( 5000 ) ;
							tc_strcpy ( cNot_Found_in_taskref_part, "");
							for ( iCounter = 0; iCounter < nPartCount ; iCounter++ )
							{
								ref_part_found_flag = 0;
								for ( jCounter = 0; jCounter < refPartCount_1 ; jCounter++ )
								{
									if ( tc_strcmp ( File_dml_PartList[iCounter] , ref_rel_dml_PartList[jCounter] ) == 0 )
									{
										ref_part_found_flag = 0;
										break;
									}
									else
									{
										ref_part_found_flag = 1;
									}
								}
								if ( ref_part_found_flag == 1)
								{
									tc_strcat ( cNot_Found_in_taskref_part, ":Not Present in reference Relation:" );
									tc_strcat ( cNot_Found_in_taskref_part, File_dml_PartList[iCounter] );
									tc_strcat ( cNot_Found_in_taskref_part, "," );
									i_No_Match_flag = i_No_Match_flag + 1;
								}
							}
							//checking reference relation part in file part list
							file_part_found_flag = 0;
							for ( jCounter = 0; jCounter < refPartCount_1 ; jCounter++ )
							{
								file_part_found_flag = 0;
								for ( iCounter = 0; iCounter < nPartCount ; iCounter++ )
								{
									if ( tc_strcmp (  ref_rel_dml_PartList[jCounter], File_dml_PartList[iCounter] ) == 0 )
									{
										file_part_found_flag = 0;
										break;
									}
									else
									{
										file_part_found_flag = 1;
									}
								}
								if ( file_part_found_flag == 1)
								{
									tc_strcat ( cNot_Found_in_taskref_part, ":Not Present in File:" );
									tc_strcat ( cNot_Found_in_taskref_part, ref_rel_dml_PartList[jCounter] );
									tc_strcat ( cNot_Found_in_taskref_part, "," );
									i_No_Match_flag = i_No_Match_flag + 1;
								}
							}

							if ( i_No_Match_flag > 0 )
							{
								//Error for attached part and part from file
								printf("\ncNot_Found_in_taskref_part : [%s]",cNot_Found_in_taskref_part);
								TC_write_syslog("\ncNot_Found_in_taskref_part : [%s]",cNot_Found_in_taskref_part);
					
								//EMH_store_error_s1(EMH_severity_error,ITK_err,cNot_Found_in_taskref_part);
								//return ITK_err;
								EMH_store_error_s1(EMH_severity_warning,ITK_err, cNot_Found_in_taskref_part);
																
								decision = EPM_nogo;
								return decision;
								
							}
						}
					}
				}
			}//if(strstr(CurrentTask,"Add Cabin Kit")!=NULL)
	}
	else if(strstr(parent_name,"Cabin kit applicability update")!=NULL)//workflowname main Parent process
	{
		if(strstr(CurrentTask,"Attach Text File To UCKA DML")!=NULL)//do task
		{
			n_UCKA_obj = tm_check_control_object_UCKA ( "UCKA_CO", "ON" );
			if ( n_UCKA_obj > 0 )
			{
				
				printf("\ncondition Rule CurrentTask_1 : [%s]",CurrentTask);
				TC_write_syslog("\ncondition Rule CurrentTask_1 : [%s]",CurrentTask);
				ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
				printf("\nCabinKit Rule Target Attachment : [%d]",noAttachment);fflush(stdout);
				TC_write_syslog("\nCabinKit Rule Target Attachment : [%d]",noAttachment);fflush(stdout);

				if( noAttachment > 0)
				{
					for( t = 0 ; t < noAttachment; t++ )
					{
						printf("\n\nfor Rule Loop t: [%d]",t);
						TC_write_syslog("\n\nfor Rule Loop t: [%d]",t);
						ITK_CALL ( AOM_ask_value_string(attachments[t],"item_id",&erc_dml_no) );
						printf("\nCabinKit Rule erc_dml_no 1 : [%s]",erc_dml_no);fflush(stdout);
						TC_write_syslog("\nCabinKit Rule erc_dml_no 1 : [%s]",erc_dml_no);fflush(stdout);

						tc_strcpy ( TxtFnameOfDataset, erc_dml_no ) ;
						tc_strcat ( TxtFnameOfDataset, "_cabinkit.txt" ) ;

						ITK_CALL ( AOM_ask_value_string(attachments[t],"object_type",&object_type) );
						printf("\nCabinKit Rule object_type 1 : [%s]",object_type);fflush(stdout);
						TC_write_syslog("\nCabinKit Rule object_type 1 : [%s]",object_type);fflush(stdout);
						if ( tc_strcmp(object_type,"ChangeRequestRevision" ) == 0 )//TargetObject ChangeRequestRevision
						{
							ITK_CALL(AOM_ask_value_string(attachments[t],"t5_rlstype",&DMLtype));
							printf("\nCabinKit Rule DMLtype 1 : [%s]",DMLtype);fflush(stdout);
							TC_write_syslog("\nCabinKit Rule DMLtype 1 : [%s]",DMLtype);fflush(stdout);
							if ( tc_strcmp ( DMLtype, "UCKA" ) == 0 )
							{
								ITK_CALL ( AOM_ask_value_string(attachments[t], "t5_ERCBusiUt",&BusinessUnit) );
								printf("\nCabinKit Rule BusinessUnit 1 : [%s]",BusinessUnit);fflush(stdout);
								TC_write_syslog("\nCabinKit Rule BusinessUnit 1 : [%s]",BusinessUnit);fflush(stdout);
								//attachments[t]
								if ( tc_strcmp ( BusinessUnit, "CVBU" ) == 0 )
								{

									//--------------------------------------read dataset start-----------------------------------------------------------
										//task to text dataset expand
										ITK_CALL ( GRM_find_relation_type ( "IMAN_reference", &task_dataset_rel_type ) ) ;
										ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t], task_dataset_rel_type, &refdatasetCount, &datasetTags ) ) ;//task to text dataset expand
										if ( refdatasetCount <= 0 )
										{
											//throw error no dataset attached to dml in IMAN_reference relation
											printf("\nNo dataset attached to dml in IMAN_reference relation Rule");
											TC_write_syslog("\nNo dataset attached to dml in IMAN_reference relation Rule");
											EMH_store_error_s1(EMH_severity_error,ITK_err,"No dataset attached to dml in IMAN_reference relation");
											//return ITK_err;
											decision = EPM_nogo;
											return decision;
										}
										for (datasetCount = 0; datasetCount < refdatasetCount ; datasetCount++)
										{
												printf("\n\ndatasetCount Rule 1 : [%d]",datasetCount);
												TC_write_syslog("\n\ndatasetCount Rule 1 : [%d]",datasetCount);
									
												ITK_CALL(AOM_refresh(datasetTags[datasetCount], TRUE));
												//ITK_CALL(AE_ask_dataset_named_ref(datasetTags[datasetCount], "Text",  &ref_type, &text_file_tag));
												ITK_CALL(AE_ask_dataset_named_ref2(datasetTags[datasetCount], "Text",  &ref_type, &text_file_tag));//replace depricate Apis Shubham

												if ( text_file_tag == NULLTAG )
												{
													printf("\nNo named reference attached to DML Rule");
													TC_write_syslog("\nNo named reference attached to DML Rule");
													EMH_store_error_s1(EMH_severity_error,ITK_err,"No named reference attached to DML");
													//return ITK_err;
													decision = EPM_nogo;
													return decision;
												}
												
												//check file name and size
												
												ITK_CALL(AOM_ask_prop_names(text_file_tag, &n_props, &props)); 
												//get all property names on dataset using below for loop
	//											for (ii = 0; ii < n_props; ii++)
	//											{
	//												printf("\nprops[ii]: [%s]",props[ii]);
	//											}
												for (ii = 0; ii < n_props; ii++)
												{
													if ((strcmp(props[ii], "file_size") == 0) || 
														(strcmp(props[ii], "byte_size") == 0) || 
														//(strcmp(props[ii], "file_name") == 0) || 
														(strcmp(props[ii], "original_file_name") == 0) || 
														(strcmp(props[ii], "file_ext") == 0) || 
														//(strcmp(props[ii], "relative_directory_path") == 0) || 
														//(strcmp(props[ii], "sd_path_name") == 0) || 
														(strcmp(props[ii], "object_type") == 0))
													{
														ITK_CALL(AOM_UIF_ask_name(text_file_tag, props[ii], &name));
														ITK_CALL(AOM_UIF_ask_value(text_file_tag, props[ii], &value));
														printf("\nRule Display Name: [%s] Property name: [%s] value: [%s]",name, props[ii], value);
														TC_write_syslog("\nRule Display Name: [%s] Property name: [%s] value: [%s]",name, props[ii], value);
														//example output
														//Property name: original_file_name   value: 00PP000007_cabinkit.txt
														//Property name: file_size   value: 34 bytes
														//Property name: object_type   value: ImanFile
														//Property name: byte_size   value: 34
														if ( strcmp(props[ii], "original_file_name") == 0)
														{
															if ( tc_strcmp ( value, TxtFnameOfDataset ) != 0 )
															{
																printf("\nRule Dataset Filename is not as per convention Keep name as : [%s]",TxtFnameOfDataset);
																TC_write_syslog("\nRule Dataset Filename is not as per convention Keep name as : [%s]",TxtFnameOfDataset);
																EMH_store_error_s1(EMH_severity_error,ITK_err,"DatasetFilename is not as per convention DmlNo_cabinkit.txt");
																//return ITK_err;
																decision = EPM_nogo;
																return decision;
															}
														}
														else if ( strcmp(props[ii], "byte_size") == 0)
														{
															if ( atol(value) <= 0 )
															{
																printf("\nRule File size is zero provide cabinkit part details in file");
																TC_write_syslog("\nRule File size is zero provide cabinkit part details in file");
																EMH_store_error_s1(EMH_severity_error,ITK_err,"File size is zero provide cabinkit part details in file");
																//return ITK_err;
																decision = EPM_nogo;
																return decision;
															}
														}

														if ( name ) MEM_free ( name ) ;
														if ( value ) MEM_free ( value ) ;
													}        
												}
												for (ii = 0; ii < n_props; ii++) 
													if(props[ii]) MEM_free(props[ii]);
												if(props) MEM_free(props);
										}
								}
							}
						}
					}
				}
			}
		}//if(strstr(CurrentTask,"Attach Text File To UCKA DML")!=NULL)

	}


	printf("\n------------------------CABIN KIT rule handler DONE : erc_dml_no : [%s] erc_task_no : [%s]-------------------------\n",erc_dml_no,erc_task_no);
	TC_write_syslog("\n------------------------CABIN KIT rule handler DONE : erc_dml_no : [%s] erc_task_no : [%s]-------------------------\n",erc_dml_no,erc_task_no);
	
	decision = EPM_go;
	return decision;
}

//Start Shrivardhan
extern EPM_decision_t DLLAPI tm_fctn_CabinKitCre_rule_handler( EPM_rule_message_t msg )//Cabin kit creation Validation
{
	EPM_decision_t decision = EPM_go;

	char* object_type = NULL;
	int t1 = 0;
	int t2 = 0;
	tag_t rootTask = NULLTAG;
	tag_t *attachments = NULLTAG;
	char* parent_name = NULL;
	int noAttachment = 0;
	char* CurrentTask = NULL;
	int n_CKC_obj = 0;		
	char *erc_task_no = NULL;
	tag_t *Part_dml_Tags = NULLTAG;
	tag_t *dml_Tags = NULLTAG;
    int refPartCount_1 = 0;
    int dmlCount = 0;
	tag_t task_part_rel_type = NULLTAG;
	tag_t task_dml_rel_type = NULLTAG;
	char *partStatus = NULL;
	char *parttype = NULL;
	char *DMLrlstype = NULL;
	char *DMLERCBusiUt = NULL;
	char *release_status = NULL;
	int flag = 0;
	
	//CabinKitAppbVal = MEM_alloc ( 10 * sizeof ( char ) ) ;	
		
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nCabinKit Rule Handler started"); fflush(stdout);
	TC_write_syslog("\nCabinKitCre Rule Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCabinKitCre Rule CurrentTask : [%s]",CurrentTask);
	TC_write_syslog("\nCabinKitCre Rule CurrentTask : [%s]",CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nCabinKitCre Rule Parent Name : [%s]",parent_name);fflush(stdout);
	TC_write_syslog("\nCabinKitCre Rule Parent Name : [%s]",parent_name);fflush(stdout);

	if(strstr(parent_name,"Cabin Kit Creation Task workflow")!=NULL)//workflowname subprocess name to add part to task
	{
			//error_919002, "You have not attached the part to SolutionItems. This will not be considered for release1"
			if(strstr(CurrentTask,"Add solution items")!=NULL)//do task
			{
				n_CKC_obj = tm_check_control_object_CKC ( "CKC_CO", "ON" );
				if (n_CKC_obj > 0 )
				{
					printf("\ncondition Rule CurrentTask_2 : [%s]",CurrentTask);
					TC_write_syslog("\ncondition Rule CurrentTask_2 : [%s]",CurrentTask);
					ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
					printf("\nCabinKitTarget Rule Attachment 2 : [%d]",noAttachment);fflush(stdout);
					TC_write_syslog("\nCabinKitTarget Rule Attachment 2 : [%d]",noAttachment);fflush(stdout);

					if( noAttachment > 0)
					{
						for( t1 = 0 ; t1 < noAttachment; t1++ )
						{
							printf("\n\nfor 2 Rule Loop t: [%d]",t1);
							TC_write_syslog("\n\nfor 2 Rule Loop t: [%d]",t1);
							ITK_CALL ( AOM_ask_value_string(attachments[t1],"item_id",&erc_task_no) );
							printf("\nCabinKiterc 2 Rule erc_task_no : [%s]",erc_task_no);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Rule erc_task_no is : [%s]",erc_task_no);fflush(stdout);

							ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &task_dml_rel_type ) ) ;
							ITK_CALL ( GRM_list_primary_objects_only ( attachments[t1], task_dml_rel_type, &dmlCount, &dml_Tags ) ) ;//task to dml traversal
			

							if (dmlCount > 0)
							{

								ITK_CALL ( AOM_ask_value_string ( dml_Tags[0], "t5_rlstype", &DMLrlstype  ) ) ;
                                printf("\nCabinKiterc DML Release type  : [%s]",DMLrlstype);fflush(stdout);
							    TC_write_syslog("\nCabinKiterc DML Release type  : [%s]",DMLrlstype);fflush(stdout);

								ITK_CALL ( AOM_ask_value_string ( dml_Tags[0], "t5_ERCBusiUt", &DMLERCBusiUt ) ) ;
                                printf("\nCabinKiterc DMLERCBusiUt  : [%s]",DMLERCBusiUt);fflush(stdout);
							    TC_write_syslog("\nCabinKiterc DMLERCBusiUt  : [%s]",DMLERCBusiUt);fflush(stdout);

								if (tc_strcmp (DMLERCBusiUt,"CVBU")!=0)
								{
									printf("\nBusiness unit is not CVBU");fflush(stdout);
									TC_write_syslog("\nBusiness unit is not CVBU");fflush(stdout);
									
									EMH_store_error_s1(EMH_severity_warning,ITK_err, "Business unit is not CVBU");
									decision = EPM_nogo;
									return decision;
								}


							}


							//task to part expand
							ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &task_part_rel_type ) ) ;
							//ITK_CALL ( GRM_find_relation_type ( "CMReferences", &task_part_rel_type ) ) ; // 10-10-2025 updated Nikhil
							ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t1], task_part_rel_type, &refPartCount_1, &Part_dml_Tags ) ) ;//task to dml traversal

							printf ( "\nCabinKitCre Part Count : [%d]", refPartCount_1 ) ; fflush ( stdout) ;
	                        TC_write_syslog ( "\nCabinKitCre Part Count : [%d]", refPartCount_1 ) ;
							
							if ( refPartCount_1 <= 0 )
							{
								printf("\nCabinKiterc Rule cNot_Found_in_taskref_part : [%d] , Attach Parts in Solution Item relation in task",refPartCount_1);fflush(stdout);
								TC_write_syslog("\nCabinKit Rule cNot_Found_in_taskref_part is : [%d] , Attach Parts in Solution Item relation in task",refPartCount_1);fflush(stdout);

								//EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please attach Part to solution items");
								EMH_store_error_s1(EMH_severity_warning,ITK_err, "Please attach Part to CMHasSolutionItem");
								decision = EPM_nogo;
								return decision;
							}
							else
							{
								for (t2=0; t2<refPartCount_1 ; t2++ )
								{
                                    
                                    ITK_CALL ( AOM_ask_value_string ( Part_dml_Tags[t2], "t5_PartType", &parttype  ) ) ;
	                                printf ( "\nCabinKitCre Part type : [%s]", parttype ) ; fflush ( stdout) ;
	                                TC_write_syslog ( "\nCabinKitCre Part type : [%s]", parttype ) ;

									ITK_CALL ( AOM_UIF_ask_value ( Part_dml_Tags[t2], "release_status_list", &release_status  ) ) ;
	                                printf ( "\nCabinKitCre Part Release Status : [%s]", release_status ) ; fflush ( stdout) ;
	                                TC_write_syslog ( "\nCabinKitCre Part Release Status : [%s]", release_status ) ;

									ITK_CALL ( AOM_ask_value_string ( Part_dml_Tags[t2], "t5_PartStatus", &partStatus  ) ) ;
	                                printf ( "\nCabinKitCre Part DR status : [%s]", partStatus ) ; fflush ( stdout) ;
	                                TC_write_syslog ( "\nCabinKitCre Part DR status : [%s]", partStatus ) ;

									if ((tc_strcmp(DMLrlstype,"CKC")==0) &&
										((tc_strcmp(parttype,"VC")==0) ||
										(tc_strcmp(parttype,"CCVC")==0) || (tc_strcmp(parttype,"CRVC")==0)) &&
										((tc_strcmp(partStatus,"DR3")==0) || (tc_strcmp(partStatus,"DR3P")==0) ||
										(tc_strcmp(partStatus,"DR4")==0 ) || (tc_strcmp(partStatus,"DR5")==0 ) ||
										(tc_strcmp(partStatus,"AR3")==0 ) || (tc_strcmp(partStatus,"AR3P")==0 ) ||
										(tc_strcmp(partStatus,"AR4")==0 ) || (tc_strcmp(partStatus,"AR5")==0 )) &&
										(tc_strstr(release_status,"ERC Released")!=NULL) )
									{
										printf("\nCabinKit Rule Part type : [%s] , Part DR Status : [%s] , Part Release Status :[%s]",parttype,partStatus,release_status);fflush(stdout);
								        TC_write_syslog("\nCabinKit Rule Part type : [%s] , Part DR Status : [%s] , Part Release Status :[%s]",parttype,partStatus,release_status);fflush(stdout);
								 
									}

									else
									{

										printf("\nAttach Parts Should have part type :VC/CCVC/CRVC, DR Status :DR3,AR3 or Above And Release status :ERC Released");fflush(stdout);
										TC_write_syslog("\nAttach Parts Should have part type :VC/CCVC/CRVC, DR Status :DR3,AR3 or Above And Release status :ERC Released");fflush(stdout);
										flag = 1;
									}
								}
								if (flag == 1)
								{
									printf("\nAttach Parts Should have part type :VC/CCVC/CRVC, DR Status :DR3,AR3 or Above And Release status :ERC Released");fflush(stdout);
									TC_write_syslog("\nAttach Parts Should have part type :VC/CCVC/CRVC, DR Status :DR3,AR3 or Above And Release status :ERC Released");fflush(stdout);
									
								    EMH_store_error_s1(EMH_severity_warning,ITK_err, "Attach Parts Should have part type :VC/CCVC/CRVC, DR Status :DR3,AR3 or Above And Release status :ERC Released");
								    decision = EPM_nogo;
								    return decision;

								}
							}
						}
					
					}
				}
			}
	}

	printf("\n------------------------CABIN KIT CREATION rule handler DONE -------------------------\n");
	TC_write_syslog("\n------------------------CABIN KIT CREATION rule handler DONE -------------------------\n");
	
	decision = EPM_go;
	return decision;

}
//END Shrivardhan
int tm_fctn_CabinKitAppbUpd_action_handler( EPM_action_message_t msg )
{
	char* object_type = NULL;
	int t = 0;
	tag_t rootTask = NULLTAG;
	tag_t *attachments = NULLTAG;
	char* parent_name = NULL;
	int noAttachment = 0;
	char* CurrentTask = NULL;
	char **FilePartList = NULL;
	char *CabinKitAppbVal = NULL;
	int Breakdowncount = 0;
	int refPartCount = 0;
	int refdatasetCount = 0;
	int taskCount = 0;
	int partCount = 0;
	int datasetCount = 0;
	tag_t dml_tsk_rel_type = NULLTAG;
	tag_t task_part_rel_type = NULLTAG;
	tag_t task_dataset_rel_type = NULLTAG;
	tag_t *dmlTaskTags = NULLTAG;
	tag_t *datasetTags = NULLTAG;
	tag_t *PartTags = NULLTAG;
	char *Task_id = NULL;
	char *Part_id = NULL;
	AE_reference_type_t ref_type;
	tag_t text_file_tag = NULLTAG;
	IMF_file_t file_descriptor = NULL;
	//char text_line[SS_MAXLLEN+1];
	char *text_line=NULL;
	char *DMLtype = NULL;
	char *BusinessUnit = NULL;
	int iPartCntr = 0 ;
	int icPartCntr = 0 ;
	int iBPartCntr = 0;
	char *erc_dml_no = NULL;
	int n_UCKA_obj = 0;

	CabinKitAppbVal = MEM_alloc ( 10 * sizeof ( char ) ) ;	
		
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nCabinKit Action Handler started"); fflush(stdout);
	TC_write_syslog("\nCabinKit Action Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCabinKit CurrentTask : [%s]",CurrentTask);
	TC_write_syslog("\nCabinKit CurrentTask : [%s]",CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nCabinKitParent Name : [%s]",parent_name);fflush(stdout);
	TC_write_syslog("\nCabinKitParent Name : [%s]",parent_name);fflush(stdout);

	if(strstr(parent_name,"Cabin kit applicability update")!=NULL)//workflowname main Parent process
	{
		if(strstr(CurrentTask,"Acknowledge UCKA DML and Update Cabin kit Applicability")!=NULL)//do task
		{
			n_UCKA_obj = tm_check_control_object_UCKA ( "UCKA_CO", "ON" );
			if ( n_UCKA_obj > 0 )
			{
				
				printf("\ncondition CurrentTask_2 : [%s]",CurrentTask);
				TC_write_syslog("\ncondition CurrentTask_2 : [%s]",CurrentTask);
				
				ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
				printf("\nCabinKitTarget Attachment : [%d]",noAttachment);fflush(stdout);
				TC_write_syslog("\nCabinKitTarget Attachment : [%d]",noAttachment);fflush(stdout);

				if(noAttachment > 0)
				{
					for( t = 0 ; t < noAttachment; t++ )
					{
						printf("\nfor 2nd loop t: [%d]",t);
						TC_write_syslog("\nfor 2nd loop t: [%d]",t);
						ITK_CALL ( AOM_ask_value_string(attachments[t],"item_id",&erc_dml_no) );
						printf("\nCabinKiterc_dml_no is : [%s]",erc_dml_no);fflush(stdout);
						TC_write_syslog("\nCabinKiterc_dml_no is : [%s]",erc_dml_no);fflush(stdout);

						ITK_CALL ( AOM_ask_value_string(attachments[t],"object_type",&object_type) );
						printf("\nCabinKitobject_type is : [%s]",object_type);fflush(stdout);
						TC_write_syslog("\nCabinKitobject_type is : [%s]",object_type);fflush(stdout);
						if ( tc_strcmp(object_type,"ChangeRequestRevision" ) == 0 )//TargetObject ChangeRequestRevision
						{
							ITK_CALL(AOM_ask_value_string(attachments[t],"t5_rlstype",&DMLtype));
							printf("\nCabinKitDMLtype is : [%s]",DMLtype);fflush(stdout);
							TC_write_syslog("\nCabinKitDMLtype is : [%s]",DMLtype);fflush(stdout);
							if ( tc_strcmp ( DMLtype, "UCKA" ) == 0 )
							{
								ITK_CALL ( AOM_ask_value_string(attachments[t], "t5_ERCBusiUt",&BusinessUnit) );
								printf("\nCabinKitBusinessUnit is : [%s]",BusinessUnit);fflush(stdout);
								TC_write_syslog("\nCabinKitBusinessUnit is : [%s]",BusinessUnit);fflush(stdout);
								//attachments[t]
								if ( tc_strcmp ( BusinessUnit, "CVBU" ) == 0 )
								{
										//--------------------------------------read dataset start-----------------------------------------------------------
										//dml to text dataset expand
										ITK_CALL ( GRM_find_relation_type ( "IMAN_reference", &task_dataset_rel_type ) ) ;
										ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t], task_dataset_rel_type, &refdatasetCount, &datasetTags ) ) ;//dml to text dataset expand
										
										if ( refdatasetCount > 0 )	//if ref dataset is attached allocate memory for parts
										{
											FilePartList = ( char** ) MEM_alloc ( NO_OF_PARTS * sizeof *FilePartList ) ;
										}
										for ( iPartCntr = 0 ; iPartCntr < NO_OF_PARTS ; iPartCntr++ )//allocate memory for each part string in file
										{
											FilePartList[iPartCntr] = ( char *) MEM_alloc ( 50 * sizeof(char) ) ;
											memset ( FilePartList[iPartCntr], 0, 50 * sizeof (char) );
										}
										
										icPartCntr = 0;
										for (datasetCount = 0; datasetCount < refdatasetCount ; datasetCount++)
										{
											printf("\n\ndatasetCount : [%d]",datasetCount);
											ITK_CALL(AOM_refresh(datasetTags[datasetCount], TRUE));
											//ITK_CALL(AE_ask_dataset_named_ref(datasetTags[datasetCount], "Text",  &ref_type, &text_file_tag));
											ITK_CALL(AE_ask_dataset_named_ref2(datasetTags[datasetCount], "Text",  &ref_type, &text_file_tag));//replace depricate Apis Shubham
											if (text_file_tag == NULLTAG) continue;
											ITK_CALL(AOM_refresh(text_file_tag, TRUE));

											ITK_CALL(IMF_ask_file_descriptor(text_file_tag, &file_descriptor));
											ITK_CALL(IMF_open_file(file_descriptor, SS_RDONLY));

											while (IMF_read_file_line2(file_descriptor, &text_line) == ITK_ok)
											{
												//text_line[tc_strlen(text_line)] = '\0';
												tc_strcpy(FilePartList[icPartCntr],text_line);
												//FilePartList[icPartCntr][tc_strlen(FilePartList[icPartCntr])] = '\0';
												printf("\nReading from file : [%s]", FilePartList[icPartCntr]);
												TC_write_syslog("\nReading from file : [%s]", FilePartList[icPartCntr]);
												icPartCntr = icPartCntr + 1;

											}
											ITK_CALL(IMF_close_file(file_descriptor));
											ITK_CALL(AOM_unload(text_file_tag));
											ITK_CALL(AOM_unload(datasetTags[datasetCount]));
										}
									//--------------------------------------read dataset end-----------------------------------------------------------
									
									ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ) ;
									ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t], dml_tsk_rel_type, &Breakdowncount, &dmlTaskTags ) ) ;//task to dml traversal

									for (taskCount = 0; taskCount < Breakdowncount ; taskCount++ )
									{
										printf("\n\ntaskCount : [%d]",taskCount);
										ITK_CALL(AOM_ask_value_string(dmlTaskTags[taskCount],"item_id",&Task_id));
										printf("\nfor Task_id : [%s]",Task_id);fflush(stdout);
										TC_write_syslog("\nfor Task_id : [%s]",Task_id);fflush(stdout);
										
										//-------------------------------------------------------------------------------------------------
										//task to part expand
										ITK_CALL ( GRM_find_relation_type ( "CMReferences", &task_part_rel_type ) ) ;
										ITK_CALL ( GRM_list_secondary_objects_only ( dmlTaskTags[taskCount], task_part_rel_type, &refPartCount, &PartTags ) ) ;//task to dml traversal

										printf("\ntotal part atached refPartCount : [%d]",refPartCount);
										TC_write_syslog("\ntotal part atached refPartCount : [%d]",refPartCount);

										for (partCount = 0; partCount < refPartCount ; partCount++)
										{
											printf("\n\npartCount : [%d]",partCount);
											TC_write_syslog("\n\npartCount : [%d]",partCount);
								
											ITK_CALL(AOM_ask_value_string(PartTags[partCount],"item_id",&Part_id));
											printf("\nPart_id : [%s] \n",Part_id);fflush(stdout);
											TC_write_syslog("\nPart_id : [%s] \n",Part_id);fflush(stdout);

											printf("\nabc icPartCntr : [%d] \n",icPartCntr);fflush(stdout);
											TC_write_syslog("\nabc icPartCntr : [%d] \n",icPartCntr);fflush(stdout);

											for ( iBPartCntr = 0 ; iBPartCntr < ( icPartCntr + 1 )  ; iBPartCntr++ )//icPartCntr is having total part count from file read
											{
											
												char *CurrentPartID = NULL;
												char *CurrentPartAppb = NULL;
												char *localPartCpy = NULL;

												printf("\nabc FilePartList[iBPartCntr] : [%s] \n",FilePartList[iBPartCntr]);fflush(stdout);
												TC_write_syslog("\nabc FilePartList[iBPartCntr] : [%s] \n",FilePartList[iBPartCntr]);fflush(stdout);
												if ( tc_strstr ( FilePartList[iBPartCntr], "," ) != NULL )	//Partnumber,Applicability Y/N/P  check comma
												{
													localPartCpy = MEM_alloc (tc_strlen(FilePartList[iBPartCntr]) * sizeof (char) ) ;
													tc_strcpy ( localPartCpy, FilePartList[iBPartCntr] );
													CurrentPartID = tc_strtok(localPartCpy,",");
													CurrentPartAppb = tc_strtok(NULL, ",");
													printf("\nlength of CurrentPartAppb : [%zd]",tc_strlen(CurrentPartAppb));fflush(stdout);
													TC_write_syslog("\nlength of CurrentPartAppb : [%zd]",tc_strlen(CurrentPartAppb));fflush(stdout);
													CurrentPartAppb[1]='\0';	//indicator is one char hence 2 nd char is set as \0
													printf("\nabc after tokenizing CurrentPartID : [%s] localPartCpy: : [%s] CurrentPartAppb : [%s] tc_strlen(CurrentPartAppb) : [%zd]\n",CurrentPartID,localPartCpy,CurrentPartAppb,tc_strlen(CurrentPartAppb));fflush(stdout);
													TC_write_syslog("\nabc after tokenizing CurrentPartID : [%s] localPartCpy: : [%s] CurrentPartAppb : [%s] tc_strlen(CurrentPartAppb) : [%zd]\n",CurrentPartID,localPartCpy,CurrentPartAppb,tc_strlen(CurrentPartAppb));fflush(stdout);

													if (CurrentPartID != NULL)
													{
														printf("\nComparing CurrentPartID : [%s],Part_id : [%s]",CurrentPartID,Part_id);
														TC_write_syslog("\nComparing CurrentPartID : [%s],Part_id : [%s]",CurrentPartID,Part_id);
														if ( tc_strcmp ( CurrentPartID,Part_id ) == 0 )
														{
															//tc_strcpy(CabinKitAppbVal,"Y");
															printf("\nUpdating CabinKitAppbVal : [%s]",CabinKitAppbVal);
															TC_write_syslog("\nUpdating CabinKitAppbVal : [%s]",CabinKitAppbVal);
															tc_strcpy(CabinKitAppbVal,CurrentPartAppb);
															//printf("\nCabinKitset value of cabin Kit applicability object");fflush(stdout);
															//TC_write_syslog("\nCabinKitset value of cabin Kit applicability object");fflush(stdout);
															ITK_CALL(AOM_lock(PartTags[partCount]));
															ITK_CALL(AOM_set_value_string(PartTags[partCount],"t5_cabkitapp",CabinKitAppbVal));
															//ITK_CALL(AOM_save(PartTags[partCount]));
															ITK_CALL ( AOM_refresh ( PartTags[partCount],TRUE ) );//lock
															ITK_CALL(AOM_save_without_extensions(PartTags[partCount]));
															ITK_CALL ( AOM_refresh ( PartTags[partCount],FALSE ) ) ;//unlock
															//ITK_CALL(AOM_unlock(PartTags[partCount]));
															printf("\nCabinKitafter save of cabin Kit applicability object");fflush(stdout);
															TC_write_syslog("\nCabinKitafter save of cabin Kit applicability object");fflush(stdout);
															break;
														}
														else
														{
															printf("Part not matched skipping");
															TC_write_syslog("Part not matched skipping");
														}
													}
												}
											}
										}
										if ( refdatasetCount > 0 )	//if ref dataset is attached allocate memory for parts
										{
											for ( iPartCntr = 0 ; iPartCntr < NO_OF_PARTS ; iPartCntr++ )//delete memory for each part string in file
											{
												if ( FilePartList[iPartCntr] ) 
												{
													MEM_free( FilePartList[iPartCntr] ) ;
												}
											}
											if ( FilePartList ) 
											{
												MEM_free( FilePartList ) ;
											}
										}
									}
								}//end CVBU
							}//end UCKA
							
						}
						else
						{
							printf("\nCABIN KIT action handler Skipping type object : [%s]",object_type);
						}
					}
				}
			}
		}//if(strstr(CurrentTask,"Acknoledgement UCKA DML and Update Cabin kit Applicability")!=NULL)
	}
	printf("\n------------------------CABIN KIT action handler DONE : [%s]-------------------------\n",erc_dml_no);
	TC_write_syslog("\n------------------------CABIN KIT action handler DONE : [%s]-------------------------\n",erc_dml_no);
	
	return ITK_ok;
}

int ExpandMultilvl(tag_t top_bomline,char *Partprjcode,tag_t top_bom_line_ck, tag_t bom_view, tag_t bvr,tag_t window)
{
	printf("\nInside ExpandMultilvl************");
	TC_write_syslog("\nInside ExpandMultilvl************");

	int i = 0;
	int CntChild = 0;
	tag_t *ChildLine = NULLTAG;
	tag_t ChildPartTag = NULLTAG;
	tag_t itemRevTag = NULLTAG;
	tag_t new_line = NULLTAG;
	
	char *ChildRevSeq = NULL;
	char *ObjName = NULL;
	char *cabkitapp = NULL;
	char *ObjPartType = NULL;

	ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));
	printf("\nChild Count:[%d]",CntChild);
	TC_write_syslog("\nChild Count:[%d]",CntChild);

    for (i = 0 ; i < CntChild ; i++ )
    {
		ChildPartTag = ChildLine[i];
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &ChildRevSeq));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType));

		if (tc_strcmp(cabkitapp,"Y")==0)
		{
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			
			
			char *partId = NULL;
			char *revId = NULL;
			
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &partId));
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &revId));
			
			if (partId && revId)
			{
				printf("\nLooking for part...: %s, revision: %s", partId, revId);
				TC_write_syslog("\nLooking for part...: %s, revision: %s", partId, revId);
				
				
				tag_t itemTag = NULLTAG;
				ITEM_find_item(partId, &itemTag);
				
				if (itemTag != NULLTAG)
				{
					
					tag_t *revList = NULL;
					int revCount = 0;
					ITK_CALL(ITEM_list_all_revs(itemTag, &revCount, &revList));
					
					//for specific revision
					for (int j = 0; j < revCount; j++)
					{
						char *thisRevId = NULL;
						ITK_CALL(AOM_ask_value_string(revList[j], "item_revision_id", &thisRevId));
						
						if (thisRevId && tc_strcmp(thisRevId, revId) == 0)
						{
							itemRevTag = revList[j];  //  exact revision
							printf("\n exact revision: %s", revId);
							TC_write_syslog("\n exact revision: %s", revId);
							
							if (thisRevId) MEM_free(thisRevId);
							break;
						}
						
						if (thisRevId) MEM_free(thisRevId);
					}
					
					
					if (revList) MEM_free(revList);
				}
				
				
				if (partId) MEM_free(partId);
				if (revId) MEM_free(revId);
				
				if (itemRevTag != NULLTAG)
				{
					// Ad BOM
					int ret = BOM_line_add(top_bom_line_ck, NULLTAG, itemRevTag, NULLTAG, &new_line);
					if (ret == ITK_ok)
					{
						ITK_CALL(BOM_save_window(window));
						printf("\nPart %s rev: %s is added in BOM...", ObjName, ChildRevSeq);
						TC_write_syslog("\nPart %s rev: %s is added in BOM...", ObjName, ChildRevSeq);
					}
					else
					{
						printf("\n BOM_line_add failed for %s", ObjName);
						TC_write_syslog("\n BOM_line_add failed for %s", ObjName);
						report_error(__FILE__, __LINE__, "BOM_line_add", ret);
					}
					
					
					itemRevTag = NULLTAG;
				}
				else
				{
					printf("\n Could not find revision %s for part: %s", ChildRevSeq, ObjName);
					TC_write_syslog("\n Could not find revision %s for part: %s", ChildRevSeq, ObjName);
				}
			}
			else
			{
				
				if (partId) MEM_free(partId);
				if (revId) MEM_free(revId);
			}
		}
		
	
		if (ObjName) MEM_free(ObjName);
		if (ChildRevSeq) MEM_free(ChildRevSeq);
		if (cabkitapp) MEM_free(cabkitapp);
		if (ObjPartType) MEM_free(ObjPartType);
    }
	
	if (ChildLine) MEM_free(ChildLine);
	
	return ITK_ok;
}


int ExpandMultilvlforP(tag_t top_bomline,char *Partprjcode,tag_t top_bom_line_ck, tag_t bom_view, tag_t bvr,tag_t window)
{
	printf("\nInside ExpandMultilvlforP************");
	TC_write_syslog("\nInside ExpandMultilvlforP************");

	int i = 0;
	int CntChild = 0;
	tag_t *ChildLine = NULLTAG;
	tag_t ChildPartTag = NULLTAG;
	tag_t VPartTag_1 = NULLTAG;
	tag_t new_line = NULLTAG;

	char *ChildRevSeq = NULL;
	char *ObjName = NULL;
	char *cabkitapp = NULL;
	char *ObjPartType = NULL;
	char *ObjPartType1 = NULL;

	ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));

    for (i = 0 ; i < CntChild ; i++ )
    {
		ChildPartTag = ChildLine[i];
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &ChildRevSeq));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
		ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType));
		ITK_CALL(AOM_ask_value_string(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType1));

		if (tc_strcmp(cabkitapp,"Y")==0)
		{
			printf("\ntObjPartType UIF:[%s]",ObjPartType);
			printf("\ntObjPartType value string:[%s]",ObjPartType1);
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType1:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType1);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType1:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType1);
			
			
			char *partId = NULL;
			char *revId = NULL;
			
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &partId));
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &revId));
			
			if (partId && revId)
			{
				printf("\nLooking for part: %s, revision: %s", partId, revId);
				TC_write_syslog("\nLooking for part: %s, revision: %s", partId, revId);
				
				tag_t itemTag1 = NULLTAG;
				ITEM_find_item(partId, &itemTag1);
				
				if (itemTag1 != NULLTAG)
				{
					tag_t *revList = NULL;
					int revCount = 0;
					ITK_CALL(ITEM_list_all_revs(itemTag1, &revCount, &revList));
					
					// specific revision
					for (int j = 0; j < revCount; j++)
					{
						char *thisRevId = NULL;
						ITK_CALL(AOM_ask_value_string(revList[j], "item_revision_id", &thisRevId));
						
						if (thisRevId && tc_strcmp(thisRevId, revId) == 0)
						{
							VPartTag_1 = revList[j];  //  exact revision
							printf("\n exact revision: %s", revId);
							TC_write_syslog("\n exact revision: %s", revId);
							
							if (thisRevId) MEM_free(thisRevId);
							break;
						}
						
						if (thisRevId) MEM_free(thisRevId);
					}
					
					if (revList) MEM_free(revList);
				}
				
				if (partId) MEM_free(partId);
				if (revId) MEM_free(revId);
				
				if (VPartTag_1 != NULLTAG)
				{
					int ret = BOM_line_add(top_bom_line_ck, NULLTAG, VPartTag_1, NULLTAG, &new_line);
					if (ret == ITK_ok)
					{
						ITK_CALL(BOM_save_window(window));
						printf("\nPart %s rev: %s is added in BOM", ObjName, ChildRevSeq);
						TC_write_syslog("\nPart %s rev: %s is added in BOM", ObjName, ChildRevSeq);
					}
					else
					{
						printf("\n BOM_line_add failed for %s", ObjName);
						TC_write_syslog("\n BOM_line_add failed for %s", ObjName);
						report_error(__FILE__, __LINE__, "BOM_line_add", ret);
					}
					
					// reset VPartTag_1 for next loop
					VPartTag_1 = NULLTAG;
				}
				else
				{
					printf("\n Could not find revision %s for part: %s", ChildRevSeq, ObjName);
					TC_write_syslog("\n Could not find revision %s for part: %s", ChildRevSeq, ObjName);
				}
			}
			else
			{
				// Clean up
				if (partId) MEM_free(partId);
				if (revId) MEM_free(revId);
			}
		}
		else if (tc_strcmp(cabkitapp,"N")==0 && (tc_strcmp(ObjPartType1,"G")!=0 ))
		{
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			printf("\nExpanding all level:[%s]",ObjName);
			TC_write_syslog("\nExpanding all level:[%s]",ObjName);
			ExpandMultilvlforP(ChildPartTag,Partprjcode,top_bom_line_ck, bom_view, bvr,window);
		}
		else if (tc_strcmp(cabkitapp,"N")==0 && (tc_strcmp(ObjPartType1,"G")==0 ))
		{
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			
			printf("\nGroup id found....");
			TC_write_syslog("\nGroup id found....");
			ExpandMultilvlforGroupid(ChildPartTag,Partprjcode,top_bom_line_ck, bom_view, bvr,window);
		}
		else
		{
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);
		}
		
		if (ObjName) MEM_free(ObjName);
		if (ChildRevSeq) MEM_free(ChildRevSeq);
		if (cabkitapp) MEM_free(cabkitapp);
		if (ObjPartType) MEM_free(ObjPartType);
		if (ObjPartType1) MEM_free(ObjPartType1);
    }
	
	if (ChildLine) MEM_free(ChildLine);
	
	return ITK_ok;
}

/*int ExpandMultilvl(tag_t top_bomline,char *Partprjcode,tag_t top_bom_line_ck, tag_t bom_view, tag_t bvr,tag_t window)

{

	printf("\nInside ExpandMultilvl************");
	TC_write_syslog("\nInside ExpandMultilvl************");



	int i =0;
	int ii =0;
	int CntChild =0;
	int CntChild1 =0;
	int n_closure_tags 		= 0;

	tag_t	top_bomline1    = NULLTAG;
	tag_t	ChildLineTag   = NULLTAG;
	tag_t	*ChildLine     = NULLTAG;
	tag_t	*Revision     = NULLTAG;
	tag_t	rule           = NULLTAG;
	tag_t	ToplineTag		   = NULLTAG;
	tag_t	ChildPartTag		      = NULLTAG;
	tag_t	iChildItemTag_1		      = NULLTAG;
	tag_t	VPartTag_1		      = NULLTAG;
	//char	*VPartTag_1		      = NULL;
	tag_t	new_line		      = NULLTAG;
	
	char *Part_Number      = NULL;
	char *ChildPart_Number = NULL;
	char *ChildRevSeq      = NULL;
	char *ObjName      = NULL;
	char *cabkitapp      = NULL;
	char *ObjPartType      = NULL;
	tag_t itemTag = NULLTAG;
	tag_t* top_line;

			ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));

			printf("\nChild Count:[%d]",CntChild);
			TC_write_syslog("\nChild Count:[%d]",CntChild);

            for (i = 0 ; i < CntChild ; i++ )
            {
				ChildPartTag = ChildLine[i];
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &ChildRevSeq));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType));

				if (tc_strcmp(cabkitapp,"Y")==0)
				{

					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					//fprintf(fp,"\n22280002000R - %s,%s",ObjName,cabkitapp);fflush(stdout);
					//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_1);
					//BOM_line_ask_attribute_tag( ChildPartTag, iChildItemTag_1, &VPartTag_1);
					
					ITK_CALL(AOM_ask_value_tag(ChildPartTag,"bl_item_item_id",&VPartTag_1));
					//ITK_CALL(AOM_UIF_ask_value(ChildPartTag,"bl_rev_item_revision_id",&VPartTag_1));

					//ITK_CALL(BOM_line_ask_item(ChildPartTag, &itemTag));
					//ITK_CALL(ITEM_ask_rev_of_item(itemTag, &VPartTag_1));

					//ITK_CALL(AOM_ask_value_string(ChildPartTag,"bl_item_item_id",&VPartTag_1));

					//ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,VPartTag_1,NULLTAG,&new_line));
					ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,VPartTag_1,NULLTAG,&new_line));
					ITK_CALL(BOM_save_window(window));

					printf("\nnObjName : [%s] is added in BOM",ObjName);
					TC_write_syslog("\nnObjName : [%s] is added in BOM",ObjName);

				}

				else if (tc_strcmp(cabkitapp,"P")==0)
				{
					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					ExpandMultilvlforP(ChildPartTag,Partprjcode,top_bom_line_ck, bom_view, bvr,window);

				}
				else
				{
					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);

				}
				
            }

}*/


/*int ExpandMultilvlforP(tag_t top_bomline,char *Partprjcode,tag_t top_bom_line_ck, tag_t bom_view, tag_t bvr,tag_t window)

{

	printf("\nInside ExpandMultilvlforP************");
	TC_write_syslog("\nInside ExpandMultilvlforP************");


	int i =0;
	int ii =0;
	int CntChild =0;
	int CntChild1 =0;
	int n_closure_tags 		= 0;

	tag_t	top_bomline1    = NULLTAG;
	tag_t	ChildLineTag   = NULLTAG;
	tag_t	*ChildLine     = NULLTAG;
	tag_t	*Revision     = NULLTAG;
	tag_t	rule           = NULLTAG;
	tag_t	ToplineTag		   = NULLTAG;
	tag_t	ChildPartTag		      = NULLTAG;
	tag_t	iChildItemTag_1		      = NULLTAG;
	tag_t	VPartTag_1		      = NULLTAG;
	//char	*VPartTag_1		      = NULL;
	tag_t	new_line		      = NULLTAG;

	char *Part_Number      = NULL;
	char *ChildPart_Number = NULL;
	char *ChildRevSeq      = NULL;
	char *ObjName      = NULL;
	char *cabkitapp      = NULL;
	char *ObjPartType      = NULL;
	char *ObjPartType1      = NULL;
	tag_t itemTag1 = NULLTAG;



			ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));

			//printf("\nChild Count:[%d]",CntChild);

            for (i = 0 ; i < CntChild ; i++ )
            {
				ChildPartTag = ChildLine[i];
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &ChildRevSeq));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
				ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType));
				ITK_CALL(AOM_ask_value_string(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType1));

				if (tc_strcmp(cabkitapp,"Y")==0)
				{
                    printf("\ntObjPartType UIF:[%s]",ObjPartType);fflush(stdout);
                    printf("\ntObjPartType value strin:[%s]",ObjPartType1);fflush(stdout);
					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);

					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType1:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType1);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType1:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType1);fflush(stdout);
					//fprintf(fp,"\n22280002000R - %s,%s",ObjName,cabkitapp);fflush(stdout);
					//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_1);
					//BOM_line_ask_attribute_tag( ChildPartTag, iChildItemTag_1, &VPartTag_1);
					ITK_CALL(AOM_ask_value_tag(ChildPartTag,"bl_item_item_id",&VPartTag_1));//24/12/25
					
					//ITK_CALL(BOM_line_ask_item_rev(ChildPartTag, &VPartTag_1));
					//ITK_CALL(BOM_line_ask_item(ChildPartTag, &itemTag1)); 
					//ITK_CALL(ITEM_ask_rev_of_item(itemTag1, &VPartTag_1));
					
					//ITK_CALL(AOM_ask_value_string(ChildPartTag,"bl_item_item_id",&VPartTag_1));
					//ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,VPartTag_1,NULLTAG,&new_line));
					ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,VPartTag_1,NULLTAG,&new_line));
					ITK_CALL(BOM_save_window(window));

					printf("\nnObjName : [%s] is added in BOM",ObjName);
					TC_write_syslog("\nnObjName : [%s] is added in BOM",ObjName);

				}

				else if (tc_strcmp(cabkitapp,"N")==0 && (tc_strcmp(ObjPartType1,"G")!=0 ))
				{

					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					printf("\nExpanding all level:[%s]",ObjName);fflush(stdout);
					TC_write_syslog("\nExpanding all level:[%s]",ObjName);fflush(stdout);
					ExpandMultilvlforP(ChildPartTag,Partprjcode,top_bom_line_ck, bom_view, bvr,window);
					//ExpandMultilvlforGroupid(ChildPartTag,top_bom_line_ck, bom_view, bvr,window);
				}
				else if (tc_strcmp(cabkitapp,"N")==0 && (tc_strcmp(ObjPartType1,"G")==0 ))
				{


					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					//ExpandMultilvlforGroupid(ChildPartTag,top_bom_line_ck, fp);

					printf("\nGroup id found....");
					TC_write_syslog("\nGroup id found....");
					ExpandMultilvlforGroupid(ChildPartTag,Partprjcode,top_bom_line_ck, bom_view, bvr,window);
					//group id tag

				}
				else
				{
					printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
					TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);

				}
				
            }

}*/

int ExpandMultilvlforGroupid(tag_t top_bomline,char *Partprjcode, tag_t top_bom_line_ck,tag_t bom_view,tag_t bvr, tag_t window)

{

	printf("\nInside ExpandMultilvlforGroupid************");
	TC_write_syslog("\nInside ExpandMultilvlforGroupid************");



	int i =0;
	int j =0;
	int ij =0;
	int ik =0;
	int s =0;
	int a =0;
	int sflag = 0;
	int flag = 0;
	int phflag = 0;
	int flag1 = 0;
	int CntChild =0;
	int CntChild_1 =0;
	int n_GroupID =0;
	int n_PartNum =0;
	int CntChild1 =0;
	int n_closure_tags 		= 0;

	char *Part_Number      = NULL;
	char *ChildPart_Number = NULL;
	char *ChildRevSeq      = NULL;
	char *ObjName      = NULL;
	char *GroupID      = NULL;
	char *cabkitapp      = NULL;
	char *PartNum      = NULL;
	char str[20];
	char *phAssychildNum      = NULL;
	char *ObjPartType      = NULL;
	char *ObjName_groupID      = NULL;
	char *GroupID_prjCode      = NULL;

	tag_t	top_bomline1    = NULLTAG;
	tag_t	top_bom_line_GCK    = NULLTAG;
	tag_t	top_bom_line_PHCK    = NULLTAG;
	tag_t	ChildLineTag   = NULLTAG;
	tag_t	*ChildLine     = NULLTAG;
	tag_t	*ChildLine_1     = NULLTAG;
	tag_t	*Revision     = NULLTAG;
	tag_t	rule           = NULLTAG;
	tag_t	ToplineTag		   = NULLTAG;
	tag_t	ChildPartTag		      = NULLTAG;
	tag_t	ChildPartTag_1		      = NULLTAG;
	tag_t	iChildItemTag_1		      = NULLTAG;
	tag_t	iChildItemTag_2		      = NULLTAG;
	tag_t	VPartTag_1		      = NULLTAG;
	tag_t	VPartTag_2		      = NULLTAG;
	tag_t	new_line		      = NULLTAG;
	tag_t	*GroupID_tag		      = NULLTAG;
	tag_t	*PartNum_tag		      = NULLTAG;
	tag_t tRevTypeTag = NULLTAG ;
	tag_t tRevCreateInputTag  = NULLTAG ;
	tag_t tItemTypeTag = NULLTAG ;
	tag_t tItemCreateInputTag = NULLTAG ;
	tag_t GCKtItemTag = NULLTAG ;
	tag_t PHCKtItemTag = NULLTAG ;
	tag_t latestGCKrev = NULLTAG ;
	tag_t latestPHCKrev = NULLTAG ;
	tag_t GroupID_no_tag = NULLTAG ;
	tag_t G_new_line = NULLTAG;
	tag_t G_bom_view = NULLTAG;
	tag_t G_bvr = NULLTAG;
	tag_t PH_new_line = NULLTAG;
	tag_t PH_bom_view = NULLTAG;
	tag_t PH_bvr = NULLTAG;



	PartNum 	    	= (char *) MEM_alloc(100);

	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;


	ITK_CALL(AOM_UIF_ask_value(top_bomline, "bl_item_item_id", &ObjName_groupID));

	printf("\nObjName_groupID : [%s]",ObjName_groupID);fflush(stdout);
	TC_write_syslog("\nObjName_groupID : [%s]",ObjName_groupID);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(top_bomline, "bl_Design Revision_t5_ProjectCode", &GroupID_prjCode));

	printf("\nGroupID_prjCode : [%s]",GroupID_prjCode);fflush(stdout);
	TC_write_syslog("\nGroupID_prjCode : [%s]",GroupID_prjCode);fflush(stdout);

	STRNG_replace_str(ObjName_groupID,"G","GCK",&GroupID);

	ITEM_find  (GroupID,&n_GroupID,&GroupID_tag); 

	if (n_GroupID > 0)
	{

		printf("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);
		TC_write_syslog("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);

		ITK_CALL (ITEM_find_item (GroupID,&GroupID_no_tag));

		ITK_CALL (ITEM_ask_latest_rev (GroupID_no_tag,&latestGCKrev));

		printf("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);
		TC_write_syslog("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);

		ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,latestGCKrev,NULLTAG,&new_line));
		ITK_CALL(BOM_save_window(window));

	}
	else
	{
	
		ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));
		printf("\nChild Count:[%d]",CntChild);
		TC_write_syslog("\nChild Count:[%d]",CntChild);
	
	
	    for (i = 0 ; i < CntChild ; i++ )
	    {
			ChildPartTag = ChildLine[i];
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_rev_item_revision_id", &ChildRevSeq));
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
			ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_Design_t5_RevPartType", &ObjPartType));
	
	
			printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
			TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
			if (tc_strcmp(cabkitapp,"Y")==0)
			{
	
				printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
				TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
				//fprintf(fp,"\n22280002000R - %s,%s",ObjName,cabkitapp);fflush(stdout);
				//cabin kit tag
				//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_1);
				//BOM_line_ask_attribute_tag( ChildPartTag, iChildItemTag_1, &VPartTag_1);
				ITK_CALL(AOM_ask_value_tag(ChildPartTag,"bl_item_item_id",&VPartTag_1));
	
				ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,VPartTag_1,NULLTAG,&new_line));
				ITK_CALL(BOM_save_window(window));
	
			}
	
			else if (tc_strcmp(cabkitapp,"N")==0)
			{
	
				flag1  = 0;
		
				//expand assembly
				printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
				TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
				////fprintf(fp,"\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\t:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
	
				ITK_CALL(BOM_line_ask_child_lines(ChildPartTag, &CntChild_1, &ChildLine_1));
				printf("\n***CntChild_1:[%d]",CntChild_1);fflush(stdout);
				TC_write_syslog("\n***CntChild_1:[%d]",CntChild_1);fflush(stdout);
	
				if (CntChild_1 > 0 )
				{
	
		
						for (j = 0; j < CntChild_1 ; j++ )
						{
						
								ChildPartTag_1 = ChildLine_1[j];
								ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_item_item_id", &ObjName));
								ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_rev_item_revision_id", &ChildRevSeq));
								ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
								ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design_t5_RevPartType", &ObjPartType));
				
								if (tc_strcmp(cabkitapp,"Y")==0)
								{
	
									printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
									TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
									////fprintf(fp,"\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
	
									printf("\nflag1:[%d]",flag1);fflush(stdout);
									TC_write_syslog("\nflag1:[%d]",flag1);fflush(stdout);
									////fprintf(fp,"\nflag1:[%d]",flag1);fflush(stdout);
									flag1++;
									//setAddStr(&a,&phAssychild,ObjName);
									
									printf("\nafter increasing flag1:[%d]",flag1);fflush(stdout);
									TC_write_syslog("\nafter increasing flag1:[%d]",flag1);fflush(stdout);
									printf("\nafter****a:[%d]",a);fflush(stdout);
									TC_write_syslog("\nafter****a:[%d]",a);fflush(stdout);
									////fprintf(fp,"\nafter increasing flag1:[%d]",flag1);fflush(stdout);
	
	
				
								}
	
								
						}
	
	
	
						if (flag1 == 1)
						{
	
							if (CntChild_1 > 0 )
							{
									for (ij = 0; ij < CntChild_1 ; ij++ )
									{
	
										ChildPartTag_1 = ChildLine_1[ij];
										ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_item_item_id", &ObjName));
										ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_rev_item_revision_id", &ChildRevSeq));
										ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
										ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design_t5_RevPartType", &ObjPartType));
	
										if (tc_strcmp(cabkitapp,"Y")==0)
										{
	
											printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
											TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
	
											//printf("\nflag1:[%d]",flag1);fflush(stdout);
											//printf("\nafter increasing flag1:[%d]",flag1);fflush(stdout);
											//printf("\nafter****a:[%d]",a);fflush(stdout);
	
											STRNG_replace_str(ObjName_groupID,"G","GCK",&GroupID);
								
											printf("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
											TC_write_syslog("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
											////fprintf(fp,"\nCreating Group ID 1(GCK)");fflush(stdout);

											ITEM_find  (GroupID,&n_GroupID,&GroupID_tag); 
	
											if (n_GroupID > 0)
											{
													//ITK_CALL ( ITEM_ask_latest_rev ( GroupID_tag, &latestGCKrev ) ) ;
	
													printf("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);
													TC_write_syslog("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);
											}
											else
											{
	
												printf("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
												TC_write_syslog("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
												ITK_CALL ( TCTYPE_find_type ( "Design Revision", NULL, &tRevTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
												printf ( "\nDesign Revision test" ) ; fflush ( stdout) ;
												TC_write_syslog ( "\nDesign Revision test" ) ;
	
												ITK_CALL ( TCTYPE_find_type ( "Design", NULL, &tItemTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
												printf("\nfind the item type Design\n"); fflush ( stdout) ;
												TC_write_syslog("\nfind the item type Design\n");
	
	
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", GroupID ) ) ;		//item
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", GroupID ) ) ;
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_desc", "GROUP CABIN KIT" ) ) ;
	
												ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;
	
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_ProjectCode", Partprjcode ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DesignGrp", "00" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartType", "G" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartStatus", "NA" ) );
												//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_cabkitapp", "Y" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "item_revision_id", "NR;1" ) );
												//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_Weight", "1.00" ) );
												
												ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &GCKtItemTag ) ) ;
	
	
												//ITK_CALL ( AOM_save ( GCKtItemTag ) ) ;
												//ITK_CALL ( AOM_refresh ( GCKtItemTag,TRUE ) ) ;
												ITK_CALL ( AOM_refresh ( GCKtItemTag,TRUE ) );//lock
												ITK_CALL(AOM_save_without_extensions(GCKtItemTag));
												ITK_CALL ( AOM_refresh ( GCKtItemTag,FALSE ) ) ;//unlock
												ITK_CALL ( ITEM_ask_latest_rev ( GCKtItemTag, &latestGCKrev ) ) ;

												ITK_CALL ( AOM_set_value_string ( latestGCKrev, "t5_cabkitapp", "Y" ) );
	
												logical  retain_released_date_GCK  = TRUE;
												tag_t status_rel_GCK		   = NULLTAG;
			
												//ITK_CALL (CR_create_release_status("T5_LcsErcRlzd",&status_rel_GCK));
												//ITK_CALL(EPM_add_release_status(status_rel_GCK,1,&latestGCKrev ,retain_released_date_GCK));
												//printf("\nERC Review stamping on CK....");fflush(stdout);
												//TC_write_syslog("\nERC Review stamping on CK....");fflush(stdout);
	
												ITK_CALL ( RES_checkout2 ( latestGCKrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;
	
												printf("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);
												TC_write_syslog("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);
												////fprintf(fp,"\n22280002000R - %s",GroupID);fflush(stdout);
												
												ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,latestGCKrev,NULLTAG,&new_line));
												ITK_CALL(BOM_save_window(window));
												//ITK_CALL(BOM_close_window(window));
												
	
												ITK_CALL(PS_create_bom_view(NULLTAG,NULL,NULL,GCKtItemTag,&G_bom_view));
												//ITK_CALL(AOM_save(G_bom_view));
												ITK_CALL ( AOM_refresh (G_bom_view,TRUE ) );//lock
												ITK_CALL(AOM_save_without_extensions(G_bom_view));
												ITK_CALL ( AOM_refresh (G_bom_view,FALSE ) ) ;//unlock
	
												ITK_CALL(PS_create_bvr(G_bom_view,NULL,NULL,FALSE,latestGCKrev,&G_bvr));
												//ITK_CALL(AOM_save(G_bvr));
												ITK_CALL ( AOM_refresh (G_bvr,TRUE ) );//lock
												ITK_CALL(AOM_save_without_extensions(G_bvr));
												ITK_CALL ( AOM_refresh (G_bvr,FALSE ) ) ;//unlock
	
												ITK_CALL(BOM_create_window(&window));
												ITK_CALL(BOM_set_window_top_line(window,NULLTAG,latestGCKrev,G_bom_view,&top_bom_line_GCK));
												ITK_CALL(BOM_save_window(window));
	
												//ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,latestGCKrev,NULLTAG,&new_line));
												//ITK_CALL(BOM_save_window(window));
	
											}
	
												//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_2);
												//BOM_line_ask_attribute_tag( ChildPartTag_1, iChildItemTag_2, &VPartTag_2);
												ITK_CALL(AOM_ask_value_tag(ChildPartTag_1,"bl_item_item_id",&VPartTag_2));
												ITK_CALL(BOM_line_add(top_bom_line_GCK,NULLTAG,VPartTag_2,NULLTAG,&G_new_line));
												ITK_CALL(BOM_save_window(window));
		
	
	
	
										}
	
	
									}
							}

							
						}
	
						else if (flag1 > 1)
						{
	
	
							printf("\nCreating phantom assy\n"); fflush ( stdout) ;
							TC_write_syslog("\nCreating phantom assy\n"); fflush ( stdout) ;
	
							phflag = 1;
	
							int pk = 1;
							int ip = 0;
	
							//for(ip = 0 ; ip < 5 ; ip++)
							for(ip = 0 ; ip < 999 ; ip++)
							{
	
								sprintf(str,"%03d",pk);
								tc_strcpy(PartNum,Partprjcode);
								tc_strcat(PartNum,"00");
								tc_strcat(PartNum,"GCK");
								tc_strcat(PartNum,str);
	
								printf("\nphantom assy [%s]\n",PartNum); fflush ( stdout) ;
								TC_write_syslog("\nphantom assy [%s]\n",PartNum); fflush ( stdout) ;
								ITEM_find  (PartNum,&n_PartNum,&PartNum_tag); 
	
								if (n_PartNum > 0)
								{
	
									printf("\nphantom assy [%s] already exist \n",PartNum); fflush ( stdout) ;
									TC_write_syslog("\nphantom assy [%s] already exist \n",PartNum); fflush ( stdout) ;
	
								}
								else
								{
										printf("\nCreating phantom assy [%s]\n",PartNum); fflush ( stdout) ;
										TC_write_syslog("\nCreating phantom assy [%s]\n",PartNum); fflush ( stdout) ;
	
										ITK_CALL ( TCTYPE_find_type ( "T5_SparKitRevision", NULL, &tRevTypeTag ) ) ;
										ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
										printf ( "\nT5_SparKitRevision test" ) ; fflush ( stdout) ;
										TC_write_syslog ( "\nT5_SparKitRevision test" ) ;
	
										ITK_CALL ( TCTYPE_find_type ( "T5_SparKit", NULL, &tItemTypeTag ) ) ;
										ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
										printf("\nfind the item type T5_SparKit\n"); fflush ( stdout) ;
										TC_write_syslog("\nfind the item type T5_SparKit\n");
	
	
										ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", PartNum ) ) ;		//item
										ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", PartNum ) ) ;
										ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_desc", "CABIN KIT PHANTOM ASSAY" ) ) ;
	
										ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;
	
										ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_ProjectCode", Partprjcode ) );
										ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DesignGrp", "00" ) );
										ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartType", "A" ) );
										ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartStatus", "NA" ) );
										//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_cabkitapp", "Y" ) );
										ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "item_revision_id", "NR;1" ) );
										//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_Weight", "1.00" ) );
	
										ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &PHCKtItemTag ) ) ;
	
	
										//ITK_CALL ( AOM_save ( PHCKtItemTag ) ) ;
										//ITK_CALL ( AOM_refresh ( PHCKtItemTag,TRUE ) ) ;
										ITK_CALL ( AOM_refresh (PHCKtItemTag,TRUE ) );//lock
										ITK_CALL(AOM_save_without_extensions(PHCKtItemTag));
										ITK_CALL ( AOM_refresh (PHCKtItemTag,FALSE ) ) ;//unlock
										ITK_CALL ( ITEM_ask_latest_rev ( PHCKtItemTag, &latestPHCKrev ) ) ;

										ITK_CALL ( AOM_set_value_string ( latestPHCKrev, "t5_cabkitapp", "Y" ) );
	
										ITK_CALL ( RES_checkout2 ( latestPHCKrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;
	
										printf("Creating bom for Phantom assy : [%s]",PartNum);
										TC_write_syslog("Creating bom for Phantom assy : [%s]",PartNum);
										
	
										sflag =1;
	
										break;
								}
	
	
									printf("\n*****for loop ...........");
									TC_write_syslog("\n*****for loop ...........");
									printf("\n*****pk : [%d]",pk);		
									TC_write_syslog("\n*****pk : [%d]",pk);		
									pk++;
							
									printf("\n*****pk : [%d]",pk);
									TC_write_syslog("\n*****pk : [%d]",pk);
	
							}
	
							if (CntChild_1 > 0 )
							{
	
									for (ik = 0; ik < CntChild_1 ; ik++ )
									{
	
	
											ChildPartTag_1 = ChildLine_1[ik];
											ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_item_item_id", &ObjName));
											ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_rev_item_revision_id", &ChildRevSeq));
											ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design Revision_t5_cabkitapp", &cabkitapp));
											ITK_CALL(AOM_UIF_ask_value(ChildPartTag_1, "bl_Design_t5_RevPartType", &ObjPartType));
	
											if (tc_strcmp(cabkitapp,"Y")==0)
											{
	
												printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
												TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
	
												//printf("\nflag1:[%d]",flag1);fflush(stdout);
												//printf("\nafter increasing flag1:[%d]",flag1);fflush(stdout);
												//printf("\nafter****a:[%d]",a);fflush(stdout);
	
												STRNG_replace_str(ObjName_groupID,"G","GCK",&GroupID);
								
												printf("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
												TC_write_syslog("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
												////fprintf(fp,"\nCreating Group ID 1(GCK)");fflush(stdout);
	
	
												ITEM_find  (GroupID,&n_GroupID,&GroupID_tag); 
	
												if (n_GroupID > 0)
												{
														//ITK_CALL ( ITEM_ask_latest_rev ( GroupID_tag, &latestGCKrev ) ) ;
	
														printf("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);
														TC_write_syslog("\nGroup ID : [%s] Already exist",GroupID);fflush(stdout);
												}
												else
												{
	
													printf("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
													TC_write_syslog("\nCreating Group ID : [%s]",GroupID);fflush(stdout);
													ITK_CALL ( TCTYPE_find_type ( "Design Revision", NULL, &tRevTypeTag ) ) ;
													ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
													printf ( "\nDesign Revision test" ) ; fflush ( stdout) ;
													TC_write_syslog ( "\nDesign Revision test" ) ;
	
													ITK_CALL ( TCTYPE_find_type ( "Design", NULL, &tItemTypeTag ) ) ;
													ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
													printf("\nfind the item type Design\n"); fflush ( stdout) ;
													TC_write_syslog("\nfind the item type Design\n");
	
	
													ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", GroupID ) ) ;		//item
													ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", GroupID ) ) ;
													ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_desc", "GROUP CABIN KIT" ) ) ;
	
													ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;
	
													ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_ProjectCode", Partprjcode ) );
													ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DesignGrp", "00" ) );
													ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartType", "G" ) );
													ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartStatus", "NA" ) );
													//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_cabkitapp", "Y" ) );
													ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "item_revision_id", "NR;1" ) );
													//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_Weight", "1.00" ) );
													
													ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &GCKtItemTag ) ) ;
	
	
													//ITK_CALL ( AOM_save ( GCKtItemTag ) ) ;
													//ITK_CALL ( AOM_refresh ( GCKtItemTag,TRUE ) ) ;
													ITK_CALL ( AOM_refresh (GCKtItemTag,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(GCKtItemTag));
													ITK_CALL ( AOM_refresh (GCKtItemTag,FALSE ) ) ;//unlock
													ITK_CALL ( ITEM_ask_latest_rev ( GCKtItemTag, &latestGCKrev ) ) ;

													ITK_CALL ( AOM_set_value_string ( latestGCKrev, "t5_cabkitapp", "Y" ) );
	
	
													logical  retain_released_date_GCK  = TRUE;
													tag_t status_rel_GCK		   = NULLTAG;
			
													//ITK_CALL (CR_create_release_status("T5_LcsErcRlzd",&status_rel_GCK));
													//ITK_CALL(EPM_add_release_status(status_rel_GCK,1,&latestGCKrev ,retain_released_date_GCK));
													//printf("\nERC Review stamping on CK....");fflush(stdout);
													//TC_write_syslog("\nERC Review stamping on CK....");fflush(stdout);
	
													ITK_CALL ( RES_checkout2 ( latestGCKrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;
													
	
													printf("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);
													TC_write_syslog("\nAttaching Group ID : [%s] to Cabin kit",GroupID);fflush(stdout);
													////fprintf(fp,"\n22280002000R - %s",GroupID);fflush(stdout);
													ITK_CALL(BOM_line_add(top_bom_line_ck,NULLTAG,latestGCKrev,NULLTAG,&new_line));
													ITK_CALL(BOM_save_window(window));
													//ITK_CALL(BOM_close_window(window));
												
	
												}
	
	
													printf("\nAttaching part : [%s] to phantom assy : [%s]",ObjName,PartNum); fflush ( stdout) ;
													TC_write_syslog("\nAttaching part : [%s] to phantom assy : [%s]",ObjName,PartNum); fflush ( stdout) ;
													
													//ITK_CALL(BOM_line_add(top_bom_line_GCK,NULLTAG,latestPHCKrev,NULLTAG,&G_new_line));
													//ITK_CALL(BOM_save_window(window));
													
													ITK_CALL(PS_create_bom_view(NULLTAG,NULL,NULL,PHCKtItemTag,&PH_bom_view));
													//ITK_CALL(AOM_save(PH_bom_view));
													ITK_CALL ( AOM_refresh (PH_bom_view,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(PH_bom_view));
													ITK_CALL ( AOM_refresh (PH_bom_view,FALSE ) ) ;//unlock
	
													ITK_CALL(PS_create_bvr(PH_bom_view,NULL,NULL,FALSE,latestPHCKrev,&PH_bvr));
													//ITK_CALL(AOM_save(PH_bvr));
													ITK_CALL ( AOM_refresh (PH_bvr,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(PH_bvr));
													ITK_CALL ( AOM_refresh (PH_bvr,FALSE ) ) ;//unlock
	
													ITK_CALL(BOM_create_window(&window));
													ITK_CALL(BOM_set_window_top_line(window,NULLTAG,latestPHCKrev,PH_bom_view,&top_bom_line_PHCK));
													ITK_CALL(BOM_save_window(window));
	
													//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_2);
													//BOM_line_ask_attribute_tag( ChildPartTag_1, iChildItemTag_2, &VPartTag_2);
													ITK_CALL(AOM_ask_value_tag(ChildPartTag_1,"bl_item_item_id",&VPartTag_2));
	
													ITK_CALL(BOM_line_add(top_bom_line_PHCK,NULLTAG,VPartTag_2,NULLTAG,&PH_new_line));
													ITK_CALL(BOM_save_window(window));
	
											}
	
	
									}

									printf("\nCheck-in : [%s]",PartNum); fflush ( stdout) ;
									TC_write_syslog("\nCheck-in : [%s]",PartNum); fflush ( stdout) ;

									ITK_CALL ( RES_checkin  ( latestPHCKrev ) ) ;


									printf("\nCheck-in : [%s] Successfully",PartNum); fflush ( stdout) ;
									TC_write_syslog("\nCheck-in : [%s] Successfully",PartNum); fflush ( stdout) ;

								
							}
	
	
						}
				}
	
	
	
				if (phflag == 1)
				{
	
						ITK_CALL(PS_create_bom_view(NULLTAG,NULL,NULL,GCKtItemTag,&G_bom_view));
						//ITK_CALL(AOM_save(G_bom_view));
						ITK_CALL ( AOM_refresh (G_bom_view,TRUE ) );//lock
						ITK_CALL(AOM_save_without_extensions(G_bom_view));
						ITK_CALL ( AOM_refresh (G_bom_view,FALSE ) ) ;//unlock
	
						ITK_CALL(PS_create_bvr(G_bom_view,NULL,NULL,FALSE,latestGCKrev,&G_bvr));
						//ITK_CALL(AOM_save(G_bvr));
						ITK_CALL ( AOM_refresh (G_bvr,TRUE ) );//lock
						ITK_CALL(AOM_save_without_extensions(G_bvr));
						ITK_CALL ( AOM_refresh (G_bvr,FALSE ) ) ;//unlock
	
						ITK_CALL(BOM_create_window(&window));
						ITK_CALL(BOM_set_window_top_line(window,NULLTAG,latestGCKrev,G_bom_view,&top_bom_line_GCK));
						ITK_CALL(BOM_save_window(window));
						ITK_CALL(BOM_line_add(top_bom_line_GCK,NULLTAG,latestPHCKrev,NULLTAG,&G_new_line));
						ITK_CALL(BOM_save_window(window));
	
				}
	
	
			}
			else
			{
	
				printf("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
				TC_write_syslog("\nObjName:[%s]\tChildRevSeq:[%s]\tcabkitapp:[%s]\tObjPartType:[%s]",ObjName,ChildRevSeq,cabkitapp,ObjPartType);fflush(stdout);
	
			}
						
		}


		printf("\nCheck-in : [%s]",GroupID); fflush ( stdout) ;
		TC_write_syslog("\nCheck-in : [%s]",GroupID); fflush ( stdout) ;

		ITK_CALL ( RES_checkin  ( latestGCKrev ) ) ;


		printf("\nCheck-in : [%s] Successfully",GroupID); fflush ( stdout) ;
		TC_write_syslog("\nCheck-in : [%s] Successfully",GroupID); fflush ( stdout) ;

	}


	if ( PartNum ) MEM_free ( PartNum ) ;


}


int CK_Bom_create (tag_t latestCkrev, tag_t tItemTag, tag_t VC_prt_Tags)
{
	
	printf("\n------------------------ INSIDE BOM CREATE FUNCTION -------------------------\n");
	TC_write_syslog("\n------------------------ INSIDE BOM CREATE FUNCTION -------------------------\n");

	int CntChild = 0;
	int i = 0;
	int j = 0;
	int partCntChild = 0;
	int VCntChild = 0;
	int iChildItemTag_1 = 0;
	int iChildItemTag_2 = 0;

	char *part_type			= NULL;
	char *PartNum			= NULL;
	char *PartRev			= NULL;
	char *Rev			= NULL;
	char *Seq			= NULL;
	char *part_DRstatus 	= NULL;
	char *PartRelStat 		= NULL;
	char *VChild_no 		= NULL;
	char *VChild_cabkitapp 		= NULL;
	char *partObjName 		= NULL;
	char *partcabkitapp 		= NULL;
	char *VObjName 		= NULL;
	char *Cabin_kit_no 		= NULL;
	char *Partprjcode 		= NULL;
	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	tag_t window = NULLTAG;
	//tag_t window = NULLTAG;
	tag_t partChildLine_Tag = NULLTAG;
	tag_t VChildLine_Tag = NULLTAG;
	tag_t top_bomline = NULLTAG;
	tag_t top_bom_line_ck = NULLTAG;
	tag_t new_line = NULLTAG;
	tag_t ck_bom_view = NULLTAG;
	tag_t bom_view = NULLTAG;
	tag_t bvr = NULLTAG;
	tag_t CK_parent = NULLTAG;
	tag_t *ChildLine = NULLTAG;
	tag_t *VChildLine = NULLTAG;
	tag_t *partChildLine = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t VPartTag_1 = NULLTAG;
	tag_t VPartTag_2 = NULLTAG;

	//*************************//
	//tag_t window = NULLTAG;
	tag_t top_bom_line = NULLTAG;
	//tag_t new_line = NULLTAG;
	//tag_t bom_view = NULLTAG;
	//tag_t bvr = NULLTAG;

	
	ITK_CALL(AOM_ask_value_string(latestCkrev,"item_id",&Cabin_kit_no));
	printf("\nCabin_kit_no : [%s]",Cabin_kit_no);
	TC_write_syslog("\nCabin_kit_no : [%s]",Cabin_kit_no);


	ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"item_id",&PartNum));
	printf("\nPartNum : [%s]",PartNum);
	TC_write_syslog("\nPartNum : [%s]",PartNum);

	ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"item_revision_id",&PartRev));
	printf("\nPartRev : [%s]",PartRev);
	TC_write_syslog("\nPartRev : [%s]",PartRev);

	ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_PartType",&part_type));
	printf("\npart_type : [%s]",part_type);
	TC_write_syslog("\npart_type : [%s]",part_type);

	ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_PartStatus",&part_DRstatus));
	printf("\npart_DRstatus : [%s]",part_DRstatus);
	TC_write_syslog("\npart_DRstatus : [%s]",part_DRstatus);

	ITK_CALL(AOM_UIF_ask_value(VC_prt_Tags,"release_status_list",&PartRelStat));
	printf("\nPartRelStat : [%s]",PartRelStat);
	TC_write_syslog("\nPartRelStat : [%s]",PartRelStat);

	ITK_CALL(AOM_UIF_ask_value(VC_prt_Tags,"t5_ProjectCode",&Partprjcode));
	printf("\nPartprjcode : [%s]",Partprjcode);
	TC_write_syslog("\nPartprjcode : [%s]",Partprjcode);


	int n_found = 0 ;
	int n_entries = 2 ; 
	char *cabkit_exe_path = NULL;
	char *command		= NULL;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { "CABKIT_EXE", "ON" } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;
	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
	printf ( "\nCABKIT_EXE found : [%d] ",n_found ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nCABKIT_EXE found : [%d] ",n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{

		Rev = tc_strtok(PartRev,";");
		Seq = tc_strtok(NULL,"");

	    ITK_CALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&cabkit_exe_path));

		printf("\n Cabin kit bom creation exe path is  = [%s] [%s] [%s] [%s] [%s]\n", cabkit_exe_path,PartNum,Rev,Seq,Cabin_kit_no);fflush(stdout);

		command = malloc(1500);
		sprintf(command,"%s %s %s %s %s",cabkit_exe_path,PartNum,Rev,Seq,Cabin_kit_no);
		printf("\nCommand = %s\n",command);
		system(command);

	}

	else
	{
	
		//ITK_CALL ( AOM_refresh ( latestCkrev,TRUE ) ) ;
		ITK_CALL(BOM_create_window(&window));
		ITK_CALL(CFM_find("ERC release and above", &rule));
		ITK_CALL(BOM_set_window_config_rule(window, rule));
		ITK_CALL(BOM_set_window_pack_all (window, false));
		ITK_CALL(BOM_set_window_top_line(window, NULLTAG, VC_prt_Tags, NULLTAG, &top_bomline));
		ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));
		printf("\nCntChild : %d",CntChild);

		if ( CntChild > 0 )
		{


			printf("\n....Vehicle tag");

			VChildLine_Tag	= ChildLine[0];

			ITK_CALL(AOM_ask_value_string(VChildLine_Tag, "bl_item_item_id", &VObjName));
			printf("\nVehicle VObjName : [%s]",VObjName);
			TC_write_syslog("\nVehicle VObjName : [%s]",VObjName);

			ITK_CALL(BOM_line_ask_child_lines(VChildLine_Tag, &VCntChild, &VChildLine));
			printf("\nVehicle VCntChild : [%d]",VCntChild);
			TC_write_syslog("\nVehicle VCntChild : [%d]",VCntChild);


			ITK_CALL ( RES_checkout2 ( latestCkrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;

			printf("\nCabin Kit Successfully Checked out\n");fflush(stdout);
			TC_write_syslog("\nCabin Kit Successfully Checked out\n");fflush(stdout);

			
			printf("\nCreating BOM view for Cabin Kit\n");fflush(stdout);
			TC_write_syslog("\nCreating BOM view for Cabin Kit\n");fflush(stdout);


			ITK_CALL(PS_create_bom_view(NULLTAG,NULL,NULL,tItemTag,&bom_view));
			//ITK_CALL(AOM_save(bom_view));
			ITK_CALL ( AOM_refresh (bom_view,TRUE ) );//lock
			ITK_CALL(AOM_save_without_extensions(bom_view));
			ITK_CALL ( AOM_refresh (bom_view,FALSE ) ) ;//unlock

			ITK_CALL(PS_create_bvr(bom_view,NULL,NULL,FALSE,latestCkrev,&bvr));
			//ITK_CALL(AOM_save(bvr));
			ITK_CALL ( AOM_refresh (bvr,TRUE ) );//lock
			ITK_CALL(AOM_save_without_extensions(bvr));
			ITK_CALL ( AOM_refresh (bvr,FALSE ) ) ;//unlock


			ITK_CALL(BOM_create_window(&window));
			ITK_CALL(BOM_set_window_top_line(window,NULLTAG,latestCkrev,bom_view,&top_bom_line_ck));
			ITK_CALL(BOM_save_window(window));

			//ExpandMultilvlforP(top_bomline,top_bom_line_ck,bom_view,bvr,window);
			ExpandMultilvl(ChildLine[0],Partprjcode,top_bom_line_ck,bom_view,bvr,window);
		
		}

		ITK_CALL(BOM_save_window(window));
		ITK_CALL(BOM_close_window(window));
	}

	printf("\n------------------------ CABIN KIT BOM CREATION COMPLETED -------------------------\n");
	return 0;

}

int ExpandMultilvlforReport(tag_t top_bomline,FILE *repfp, int a)

{

	printf("\nInside ExpandMultilvl************");
	TC_write_syslog("\nInside ExpandMultilvl************");


	int i =0;
	int CntChild =0;
	int j = 0;

	char *ObjName      = NULL;

	tag_t	*ChildLine     = NULLTAG;
	tag_t	ChildPartTag		      = NULLTAG;


			ITK_CALL(BOM_line_ask_child_lines(top_bomline, &CntChild, &ChildLine));

			printf("\nChild Count:[%d]",CntChild);

			if (CntChild > 0)
			{

				j = a+1;
			

					for (i = 0 ; i < CntChild ; i++ )
					{
						ChildPartTag = ChildLine[i];
						ITK_CALL(AOM_UIF_ask_value(ChildPartTag, "bl_item_item_id", &ObjName));
						printf("\nObjName :[%s]:\n",ObjName);fflush(stdout);
						fprintf(repfp,"\n[%d],[%s]",j,ObjName);fflush(stdout);
						ExpandMultilvlforReport(ChildPartTag,repfp,j);
						
					}
			}

}

//Start Shrivardhan
/*int tm_fctn_CabinKitCre_action_handler(EPM_action_message_t msg)//Cabin kit creation and BOM attach
{
	EPM_decision_t decision = EPM_go;
	int t1 = 0;
	int n_cabinkitID = 0;
	int t2 = 0;
	int n_CKC_obj = 0;
	int noAttachment = 0;
	int refPartCount_1 = 0;
	int prtCount = 0;
	int DMLCount = 0;
	int flag = 0;
	int prjflag = 0;
	int a=0;


	FILE *repfp;
	char *reportFile = NULL;
	char* object_type = NULL;
	char* parent_name = NULL;
	char* partname = NULL;
	char* CurrentTask = NULL;
	char *erc_task_no = NULL;
	char *partStatus = NULL;
	char *parttype = NULL;
	char *DMLrlstype = NULL;
	char *release_status = NULL;
	char *cabinkitID = NULL;
	char *cabinkit_desc = NULL;
	char *part_ProjectCode = NULL;
	char *part_cabkitapp = NULL;
	char *ctrlobjprjcode = NULL;


	tag_t	top_bomline = NULLTAG;
	tag_t   window      = NULLTAG;
	tag_t   ERCDML_Tag      = NULLTAG;
	char *ERCDML		= NULL;


	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	tag_t *Part_dml_Tags = NULLTAG;
	tag_t *prt_Tags = NULLTAG;
	tag_t *DML_Tags = NULLTAG;
	tag_t task_part_rel_type = NULLTAG;
	tag_t task_DML_rel_type = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t tRevTypeTag = NULLTAG ;
	tag_t tRevCreateInputTag  = NULLTAG ;
	tag_t tItemTypeTag = NULLTAG ;
	tag_t tItemCreateInputTag = NULLTAG ;
	tag_t tItemTag = NULLTAG ;
	tag_t latestCkrev = NULLTAG ;
	tag_t tRelationFind	= NULLTAG ;
	tag_t tRelationFind1	= NULLTAG ;
	tag_t PartCKRelTag = NULLTAG ;
	tag_t PartCKRelTag1 = NULLTAG ;
	tag_t VC_prt_Tags = NULLTAG ;
	tag_t *cabinkitID_tag = NULLTAG ;
	tag_t cabinkitID_no_tag = NULLTAG ;

	// for solution attach CK
	tag_t solution_relation_type = NULLTAG;

	logical  retain_released_date_CK  = TRUE;
	tag_t status_rel_CK		   = NULLTAG;

	cabinkitID = MEM_alloc ( 20 * sizeof ( char ) ) ;	
	cabinkit_desc = MEM_alloc ( 50 * sizeof ( char ) ) ;	
	ctrlobjprjcode = MEM_alloc ( 50 * sizeof ( char ) ) ;	
	reportFile = MEM_alloc ( 100 * sizeof ( char ) ) ;	
		
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nCabinKit Action Handler started"); fflush(stdout);
	TC_write_syslog("\nCabinKitCre Action Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCabinKitCre Action CurrentTask : [%s]",CurrentTask);
	TC_write_syslog("\nCabinKitCre Action CurrentTask : [%s]",CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nCabinKitCre Action Parent Name : [%s]",parent_name);fflush(stdout);
	TC_write_syslog("\nCabinKitCre Action Parent Name : [%s]",parent_name);fflush(stdout);

	if(strstr(parent_name,"Cabin Kit Creation Task workflow")!=NULL)//workflowname subprocess name to add part to task
	{
			//error_919002, "You have not attached the part to SolutionItems. This will not be considered for release1"
			if(strstr(CurrentTask,"Add solution items")!=NULL)//do task
			{
				n_CKC_obj = tm_check_control_object_CKC ( "CKC_CO", "ON" );
				if (n_CKC_obj > 0 )
				{
					printf("\ncondition Action CurrentTask_2 : [%s]",CurrentTask);
					TC_write_syslog("\ncondition Action CurrentTask_2 : [%s]",CurrentTask);
					ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
					printf("\nCabinKitTarget Action Attachment 2 : [%d]",noAttachment);fflush(stdout);
					TC_write_syslog("\nCabinKitTarget Action Attachment 2 : [%d]",noAttachment);fflush(stdout);

					if( noAttachment > 0)
					{
						for( t1 = 0 ; t1 < noAttachment; t1++ )
						{
							printf("\n\nfor 2 Action Loop t: [%d]",t1);
							TC_write_syslog("\n\nfor 2 Action Loop t: [%d]",t1);
							ITK_CALL ( AOM_ask_value_string(attachments[t1],"item_id",&erc_task_no) );
							printf("\nCabinKiterc 2 Action erc_task_no : [%s]",erc_task_no);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Action erc_task_no is : [%s]",erc_task_no);fflush(stdout);

							//ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &task_part_rel_type ) );
							// 09-oct-25 Nikhil updated
							ITK_CALL ( GRM_find_relation_type ( "CMReferences", &task_part_rel_type ) ); // 09-oct-25 Nikhil updated
							//end
							ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t1], task_part_rel_type, &prtCount, &prt_Tags ) ) ;//task to dml traversal

							printf("\nCabinKiterc 2 Action erc_task prtCount : [%d]",prtCount);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Action erc_task prtCount is : [%d]",prtCount);fflush(stdout);

							if (prtCount>0)
							{
								for (t2 = 0;t2 < prtCount ;t2++ )
								{

									VC_prt_Tags = prt_Tags[t2];


									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"item_id",&partname));
	                                printf("\nCabinKitCre Action partname : [%s]",partname);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action partname : [%s]",partname);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_ProjectCode",&part_ProjectCode));
	                                printf("\nCabinKitCre Action part_ProjectCode : [%s]",part_ProjectCode);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action part_ProjectCode : [%s]",part_ProjectCode);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_cabkitapp",&part_cabkitapp));
	                                printf("\nCabinKitCre Action part_cabkitapp : [%s]",part_cabkitapp);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action part_cabkitapp : [%s]",part_cabkitapp);fflush(stdout);

									int n_found = 0 ;
                                    int n_entries = 2 ; 
                                    char *cabkit_info1 = NULL;


                                    char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
                                    char *qry_values[2] =  { "CABKIT", "CABKIT" } ;
                                    tag_t query = NULLTAG ;
                                    tag_t *cntr_objects = NULL ;

                                    ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
                                    ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
                                    printf ( "\nCABKIT found : [%d] ",n_found ) ; fflush ( stdout) ;
                                    TC_write_syslog ( "\nCABKIT found : [%d] ",n_found ) ; fflush ( stdout) ;

									if ( n_found > 0 )
                                    {

                                        ITK_CALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&cabkit_info1));
                                        printf("\nCabinKitCre Action cabkit_info1 : [%s]",cabkit_info1);fflush(stdout);
                                        TC_write_syslog("\nCabinKitCre Action cabkit_info1 : [%s]",cabkit_info1);fflush(stdout);

                                        tc_strcpy (ctrlobjprjcode,",");
                                        tc_strcat (ctrlobjprjcode,part_ProjectCode);
                                        tc_strcat (ctrlobjprjcode,",");

										
                                        if (tc_strstr(cabkit_info1,ctrlobjprjcode)!=NULL)
                                        {

                                            printf("\nCabin Kit is applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
                                            TC_write_syslog("\nCabin Kit is applicable for project code : [%s]",part_ProjectCode);fflush(stdout);


											if (partname != NULL)
											{
												tc_strcpy(cabinkitID,"");
												tc_strcat(cabinkitID,partname);
												tc_strcat(cabinkitID,"CK");

												tc_strcpy(cabinkit_desc,"CABIN KIT FOR ");
												tc_strcat(cabinkit_desc,partname);
											

											}

											ITEM_find  (cabinkitID,&n_cabinkitID,&cabinkitID_tag); 

											if ( n_cabinkitID > 0 )
											{

												printf("\nCabin Kit : [%s] Already exist",cabinkitID);fflush(stdout);
												TC_write_syslog("\nCabin Kit : [%s] Already exist",cabinkitID);fflush(stdout);
											

												ITK_CALL (ITEM_find_item (cabinkitID,&cabinkitID_no_tag));

												ITK_CALL (ITEM_ask_latest_rev (cabinkitID_no_tag,&latestCkrev));

											    ITK_CALL ( GRM_find_relation_type ( "T5_HasSpareKit", &tRelationFind ) ) ;
											    printf("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    TC_write_syslog("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( VC_prt_Tags, latestCkrev, tRelationFind, NULLTAG, &PartCKRelTag ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag ) ) ;
											    //ITK_CALL ( AOM_refresh ( VC_prt_Tags,TRUE ) );
											    ITK_CALL ( AOM_refresh ( VC_prt_Tags,FALSE ) );
											    //ITK_CALL ( AOM_save ( prt_Tags[t2] ) );
											    printf("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname );
											    
												// Testing start

												ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &solution_relation_type ) ) ;
											    printf("\nfound relation CMHasSolutionItem for Solution Items folder\n");fflush(stdout);
											    TC_write_syslog("\nfound relation CMHasSolutionItem for Solution Items folder\n");fflush(stdout);

												// END
											    
											    //ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &tRelationFind1 ) ) ;
											    //printf("\nfound relation CMHasSolutionItem \n");fflush(stdout);
											    //TC_write_syslog("\nfound relation CMHasSolutionItem \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( attachments[t1], latestCkrev, solution_relation_type, NULLTAG, &PartCKRelTag1 ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag1 ) ) ;
											    //ITK_CALL ( AOM_refresh ( attachments[t1],TRUE ) );
											    ITK_CALL ( AOM_refresh ( attachments[t1],FALSE ) );
											    //ITK_CALL ( AOM_save ( attachments[t1] ) );
											    printf("\nCK [%s] and ERC Task [%s] relation created successfully\n",cabinkitID, erc_task_no ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] and ERC Task [%s] relation created successfully\n",cabinkitID, erc_task_no );
													
												a =1;

												ERCDML = tc_strtok(erc_task_no,"_");


												tc_strcpy(reportFile,"/tmp/Cabinkit_Bom_Report_system_");
												tc_strcat(reportFile,ERCDML);
												tc_strcat(reportFile,".txt");

												printf("\nReport : [%s]",reportFile);

												repfp = fopen(reportFile,"a");



												fprintf(repfp,"[%d],[%s]",a,cabinkitID);

												ITK_CALL(BOM_create_window(&window));
												ITK_CALL(BOM_set_window_pack_all (window, false));
												ITK_CALL(BOM_set_window_top_line(window, NULLTAG, latestCkrev, NULLTAG, &top_bomline));

												
												ExpandMultilvlforReport(top_bomline,repfp,a);

												fclose(repfp);

												ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &task_DML_rel_type ) );
												ITK_CALL ( GRM_list_primary_objects_only ( attachments[t1], task_DML_rel_type, &DMLCount, &DML_Tags ) ) ;//task to dml traversal

												if ( DMLCount > 0 )
												{
					
													ERCDML_Tag = DML_Tags[0];
													printf("\ninside attachment");
													tag_t	ImanRefRel		= NULLTAG;
													tag_t	dsTypeTxt		= NULLTAG;
													tag_t	newtxtDS		= NULLTAG;
													tag_t	Dml_ImanRefRel	= NULLTAG;
													tag_t	txtDS_Rev		= NULLTAG;

													char *ds_Name = (char *) MEM_alloc(50 * sizeof (char *));

													int						ds_ref_count = 0;
													char					**ref_list;
													tag_t					repFiletag	= NULLTAG;
													IMF_file_t				fileDescriptor;
													AE_reference_type_t		tagRefType = 1;

													printf("\n\n\nDataset Creation Starts...\n");fflush(stdout);

													ITK_CALL(GRM_find_relation_type("IMAN_reference", &ImanRefRel));

													ITK_CALL(AE_find_datasettype2("Text",&dsTypeTxt));

													if(dsTypeTxt == NULLTAG)
													{
													printf("\nCould not find Text Dataset\n");fflush(stdout);
													}

													tc_strcpy(ds_Name,"");
													tc_strcpy(ds_Name,"Cabinkit_Bom_Report_system_");
													tc_strcat(ds_Name,ERCDML);


													ITK_CALL(AE_create_dataset_with_id(dsTypeTxt,ds_Name,ds_Name,"","",&newtxtDS));
													ITK_CALL(AE_save_myself(newtxtDS));
													printf("\nText Dataset created successfully\n");

													ITK_CALL(AE_ask_dataset_latest_rev(newtxtDS,&txtDS_Rev));
													ITK_CALL(AOM_refresh(txtDS_Rev,TRUE));

													ITK_CALL(AE_ask_datasettype_refs(dsTypeTxt, &ds_ref_count, &ref_list));
													ITK_CALL(IMF_import_file(reportFile,NULL, SS_TEXT, &repFiletag, &fileDescriptor));
													//AOM_save(repFiletag);
													ITK_CALL ( AOM_refresh (repFiletag,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(repFiletag));
													ITK_CALL ( AOM_refresh (repFiletag,FALSE ) ) ;//unlock
													printf("\nFile Imported successfully");fflush(stdout);

													ITK_CALL(AE_add_dataset_named_ref2(txtDS_Rev,ref_list[0],tagRefType,repFiletag));
													//AOM_save(txtDS_Rev);
													ITK_CALL ( AOM_refresh (txtDS_Rev,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(txtDS_Rev));
													ITK_CALL ( AOM_refresh (txtDS_Rev,FALSE ) ) ;//unlock
													printf("\nReport file added in dataset named reference successfully\n");

													ITK_CALL(GRM_create_relation(ERCDML_Tag,newtxtDS,ImanRefRel,NULLTAG,&Dml_ImanRefRel));
													ITK_CALL(GRM_save_relation(Dml_ImanRefRel));
													ITK_CALL(AOM_refresh(ERCDML_Tag,TRUE));
													printf("Excel Dataset attached in DML Iman reference relation successfully\n");
													if(ds_Name) MEM_free(ds_Name);
												}

											}
												
											else
											{

												//T5_SparKitRevision
												ITK_CALL ( TCTYPE_find_type ( "T5_SparKitRevision", NULL, &tRevTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
												printf ( "\nT5_SparKitRevision test" ) ; fflush ( stdout) ;
												TC_write_syslog ( "\nT5_SparKitRevision test" ) ;

												ITK_CALL ( TCTYPE_find_type ( "T5_SparKit", NULL, &tItemTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
												printf("\nfind the item type T5_SparKit\n"); fflush ( stdout) ;
												TC_write_syslog("\nfind the item type T5_SparKit\n");


											//if ((tRevTypeTag != NULLTAG) && (tItemTypeTag != NULLTAG) )
											//{
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", cabinkitID ) ) ;		//item
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", cabinkitID ) ) ;
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_desc", cabinkit_desc ) ) ;

												ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;


												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_ProjectCode", part_ProjectCode ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DesignGrp", "00" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartType", "A" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartStatus", "NA" ) );
												//ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_cabkitapp", part_cabkitapp ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "item_revision_id", "NR;1" ) );

												ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;

												//ITK_CALL ( AOM_save_with_extensions ( tItemTag ) ) ;
												//ITK_CALL ( AOM_save ( tItemTag ) ) ;
												//ITK_CALL ( AOM_refresh ( tItemTag,TRUE ) ) ;
												ITK_CALL ( AOM_refresh (tItemTag,TRUE ) );//lock
												ITK_CALL(AOM_save_without_extensions(tItemTag));
												ITK_CALL ( AOM_refresh (tItemTag,FALSE ) ) ;//unlock
											   // ITK_CALL ( AOM_unlock ( tItemTag ) ) ;
											    ITK_CALL ( ITEM_ask_latest_rev ( tItemTag, &latestCkrev ) ) ;

												ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_cabkitapp", part_cabkitapp ) );

												CK_Bom_create (latestCkrev, tItemTag, VC_prt_Tags); 
	
											    ITK_CALL ( RES_checkin  ( latestCkrev ) ) ;

											    ITK_CALL ( GRM_find_relation_type ( "T5_HasSpareKit", &tRelationFind ) ) ;
											    printf("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    TC_write_syslog("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( VC_prt_Tags, latestCkrev, tRelationFind, NULLTAG, &PartCKRelTag ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag ) ) ;
											    //ITK_CALL ( AOM_refresh ( VC_prt_Tags,TRUE ) );
											    ITK_CALL ( AOM_refresh ( VC_prt_Tags,FALSE ) );
											    //ITK_CALL ( AOM_save ( prt_Tags[t2] ) );
											    printf("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname );
											    
												// Testing to CK attach to solution folder
												
												ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &solution_relation_type ) ) ;
											    printf("\nfound relation CMHasSolutionItem for Solution Items folder\n");fflush(stdout);
											    TC_write_syslog("\nfound relation CMHasSolutionItem for Solution Items folder\n");fflush(stdout);
												
												// END
											    
											    //ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &tRelationFind1 ) ) ;
											    //printf("\nfound relation CMHasSolutionItem \n");fflush(stdout);
											    //TC_write_syslog("\nfound relation CMHasSolutionItem \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( attachments[t1], latestCkrev, solution_relation_type, NULLTAG, &PartCKRelTag1 ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag1 ) ) ;
											    //ITK_CALL ( AOM_refresh ( attachments[t1],TRUE ) );
											    ITK_CALL ( AOM_refresh ( attachments[t1],FALSE ) );
											    //ITK_CALL ( AOM_save ( attachments[t1] ) );
											    printf("\nCK [%s] and ERC Task [%s] relation created successfully\n",cabinkitID, erc_task_no ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] and ERC Task [%s] relation created successfully\n",cabinkitID, erc_task_no );
												      
												      
											    //ITK_CALL ( AOM_refresh ( latestCkrev,TRUE ) );
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "object_desc", cabinkit_desc ) ) ;
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_ProjectCode", part_ProjectCode ) ) ;
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_DesignGrp", "00" ) ) ;
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_PartType", "A" ) ) ;
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_PartStatus", "NA" ) ) ;
											    //ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_cabkitapp", part_cabkitapp ) ) ;
											    //ITK_CALL ( AOM_refresh ( latestCkrev,FALSE ) );
												printf ( "\nCreating BOM report of Cabin Kit : [%s]",cabinkitID) ; fflush ( stdout) ;
												TC_write_syslog ( "\nCreating BOM report of Cabin Kit : [%s]",cabinkitID) ; fflush ( stdout) ;


												a =1;
												ERCDML = tc_strtok(erc_task_no,"_");


												tc_strcpy(reportFile,"/tmp/Cabinkit_Bom_Report_system_");
												tc_strcat(reportFile,ERCDML);
												tc_strcat(reportFile,".txt");

												printf("\nReport : [%s]",reportFile);

												repfp = fopen(reportFile,"a");



												fprintf(repfp,"[%d],[%s]",a,cabinkitID);

												ITK_CALL(BOM_create_window(&window));
												ITK_CALL(BOM_set_window_pack_all (window, false));
												ITK_CALL(BOM_set_window_top_line(window, NULLTAG, latestCkrev, NULLTAG, &top_bomline));

												
												ExpandMultilvlforReport(top_bomline,repfp,a);

												fclose(repfp);

												ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &task_DML_rel_type ) );
												ITK_CALL ( GRM_list_primary_objects_only ( attachments[t1], task_DML_rel_type, &DMLCount, &DML_Tags ) ) ;//task to dml traversal

												if ( DMLCount > 0 )
												{
					
													ERCDML_Tag = DML_Tags[0];
													printf("\ninside attachment");
													tag_t	ImanRefRel		= NULLTAG;
													tag_t	dsTypeTxt		= NULLTAG;
													tag_t	newtxtDS		= NULLTAG;
													tag_t	Dml_ImanRefRel	= NULLTAG;
													tag_t	txtDS_Rev		= NULLTAG;

													char *ds_Name = (char *) MEM_alloc(50 * sizeof (char *));

													int						ds_ref_count = 0;
													char					**ref_list;
													tag_t					repFiletag	= NULLTAG;
													IMF_file_t				fileDescriptor;
													AE_reference_type_t		tagRefType = 1;

													printf("\n\n\nDataset Creation Starts...\n");fflush(stdout);

													ITK_CALL(GRM_find_relation_type("IMAN_reference", &ImanRefRel));

													ITK_CALL(AE_find_datasettype2("Text",&dsTypeTxt));

													if(dsTypeTxt == NULLTAG)
													{
													printf("\nCould not find Text Dataset\n");fflush(stdout);
													}

													tc_strcpy(ds_Name,"");
													tc_strcpy(ds_Name,"Cabinkit_Bom_Report_system_");
													tc_strcat(ds_Name,ERCDML);


													ITK_CALL(AE_create_dataset_with_id(dsTypeTxt,ds_Name,ds_Name,"","",&newtxtDS));
													ITK_CALL(AE_save_myself(newtxtDS));
													printf("\nText Dataset created successfully\n");

													ITK_CALL(AE_ask_dataset_latest_rev(newtxtDS,&txtDS_Rev));
													ITK_CALL(AOM_refresh(txtDS_Rev,TRUE));

													ITK_CALL(AE_ask_datasettype_refs(dsTypeTxt, &ds_ref_count, &ref_list));
													ITK_CALL(IMF_import_file(reportFile,NULL, SS_TEXT, &repFiletag, &fileDescriptor));
													//AOM_save(repFiletag);
													ITK_CALL ( AOM_refresh (repFiletag,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(repFiletag));
													ITK_CALL ( AOM_refresh (repFiletag,FALSE ) ) ;//unlock
													printf("\nFile Imported successfully");fflush(stdout);

													ITK_CALL(AE_add_dataset_named_ref2(txtDS_Rev,ref_list[0],tagRefType,repFiletag));
													//AOM_save(txtDS_Rev);
													ITK_CALL ( AOM_refresh (txtDS_Rev,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(txtDS_Rev));
													ITK_CALL ( AOM_refresh (txtDS_Rev,FALSE ) ) ;//unlock
													printf("\nReport file added in dataset named reference successfully\n");

													ITK_CALL(GRM_create_relation(ERCDML_Tag,newtxtDS,ImanRefRel,NULLTAG,&Dml_ImanRefRel));
													ITK_CALL(GRM_save_relation(Dml_ImanRefRel));
													ITK_CALL(AOM_refresh(ERCDML_Tag,TRUE));
													printf("Excel Dataset attached in DML Iman reference relation successfully\n");
													if(ds_Name) MEM_free(ds_Name);
												}

								

											//} //  
											}
										}

										else
										{

											printf("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
											TC_write_syslog("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
											prjflag =1;


										}
									}
									
								}

							}



						}

	
					}

				}

			}

	}

	if (prjflag > 0)
	{
		
		printf("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
		TC_write_syslog("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);

		EMH_store_error_s2(EMH_severity_warning,ITK_err, "Cabin Kit is not applicable for project code :",part_ProjectCode);
		decision = EPM_nogo;
		return decision;
	}
	else
	{

		if ( cabinkitID ) MEM_free ( cabinkitID ) ;
		if ( cabinkit_desc ) MEM_free ( cabinkit_desc  ) ;
		if ( ctrlobjprjcode) MEM_free ( ctrlobjprjcode ) ;
		if ( reportFile) MEM_free ( reportFile ) ;
		
		printf("\n------------------------CABIN KIT CREATION action handler DONE-------------------------\n");
		TC_write_syslog("\n------------------------CABIN KIT CREATION action handler DONE-------------------------\n");
		return ITK_ok;
	}
}*/

int tm_fctn_CabinKitCre_action_handler(EPM_action_message_t msg)//Cabin kit creation and BOM attach
{
	EPM_decision_t decision = EPM_go;
	int t1 = 0;
	int n_cabinkitID = 0;
	int t2 = 0;
	int n_CKC_obj = 0;
	int noAttachment = 0;
	int refPartCount_1 = 0;
	int prtCount = 0;
	int DMLCount = 0;
	int flag = 0;
	int prjflag = 0;
	int a=0;


	FILE *repfp;
	char *reportFile = NULL;
	char* object_type = NULL;
	char* parent_name = NULL;
	char* partname = NULL;
	char* CurrentTask = NULL;
	char *erc_task_no = NULL;
	char *partStatus = NULL;
	char *parttype = NULL;
	char *DMLrlstype = NULL;
	char *release_status = NULL;
	char *cabinkitID = NULL;
	char *cabinkit_desc = NULL;
	char *part_ProjectCode = NULL;
	char *part_cabkitapp = NULL;
	char *ctrlobjprjcode = NULL;


	tag_t	top_bomline = NULLTAG;
	tag_t   window      = NULLTAG;
	tag_t   ERCDML_Tag      = NULLTAG;
	char *ERCDML		= NULL;


	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	tag_t *Part_dml_Tags = NULLTAG;
	tag_t *prt_Tags = NULLTAG;
	tag_t *DML_Tags = NULLTAG;
	tag_t task_part_rel_type = NULLTAG;
	tag_t task_DML_rel_type = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t tRevTypeTag = NULLTAG ;
	tag_t tRevCreateInputTag  = NULLTAG ;
	tag_t tItemTypeTag = NULLTAG ;
	tag_t tItemCreateInputTag = NULLTAG ;
	tag_t tItemTag = NULLTAG ;
	tag_t latestCkrev = NULLTAG ;
	tag_t tRelationFind	= NULLTAG ;
	tag_t tRelationFind1	= NULLTAG ;
	tag_t PartCKRelTag = NULLTAG ;
	tag_t PartCKRelTag1 = NULLTAG ;
	tag_t VC_prt_Tags = NULLTAG ;
	tag_t *cabinkitID_tag = NULLTAG ;
	tag_t cabinkitID_no_tag = NULLTAG ;

	// for solution attach CK
	tag_t solution_relation_type = NULLTAG;

	logical  retain_released_date_CK  = TRUE;
	tag_t status_rel_CK		   = NULLTAG;

	cabinkitID = MEM_alloc ( 20 * sizeof ( char ) ) ;	
	cabinkit_desc = MEM_alloc ( 50 * sizeof ( char ) ) ;	
	ctrlobjprjcode = MEM_alloc ( 50 * sizeof ( char ) ) ;	
	reportFile = MEM_alloc ( 100 * sizeof ( char ) ) ;	
		
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nCabinKit Action Handler started"); fflush(stdout);
	TC_write_syslog("\nCabinKitCre Action Handler started"); fflush(stdout);
	ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	printf("\nCabinKitCre Action CurrentTask : [%s]",CurrentTask);
	TC_write_syslog("\nCabinKitCre Action CurrentTask : [%s]",CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	printf("\nCabinKitCre Action Parent Name : [%s]",parent_name);fflush(stdout);
	TC_write_syslog("\nCabinKitCre Action Parent Name : [%s]",parent_name);fflush(stdout);

	// Find CMHasSolutionItem relation type 
	ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &solution_relation_type ) ) ;
	if (solution_relation_type == NULLTAG)
	{
		printf("\n Could not find CMHasSolutionItem relation type\n"); fflush(stdout);
		TC_write_syslog("\n Could not find CMHasSolutionItem relation type\n");
		EMH_store_error_s1(EMH_severity_error, ITK_err, "Could not find CMHasSolutionItem relation type");
		return ITK_err;
	}
	printf("\nFound CMHasSolutionItem relation type for Solution Items folder\n"); fflush(stdout);
	TC_write_syslog("\nFound CMHasSolutionItem relation type for Solution Items folder\n");

	if(strstr(parent_name,"Cabin Kit Creation Task workflow")!=NULL)//workflowname subprocess name to add part to task
	{
			//error_919002, "You have not attached the part to SolutionItems. This will not be considered for release1"
			if(strstr(CurrentTask,"Add solution items")!=NULL)//do task
			{
				n_CKC_obj = tm_check_control_object_CKC ( "CKC_CO", "ON" );
				if (n_CKC_obj > 0 )
				{
					printf("\ncondition Action CurrentTask_2 : [%s]",CurrentTask);
					TC_write_syslog("\ncondition Action CurrentTask_2 : [%s]",CurrentTask);
					ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
					printf("\nCabinKitTarget Action Attachment 2 : [%d]",noAttachment);fflush(stdout);
					TC_write_syslog("\nCabinKitTarget Action Attachment 2 : [%d]",noAttachment);fflush(stdout);

					if( noAttachment > 0)
					{
						for( t1 = 0 ; t1 < noAttachment; t1++ )
						{
							printf("\n\nfor 2 Action Loop t: [%d]",t1);
							TC_write_syslog("\n\nfor 2 Action Loop t: [%d]",t1);
							ITK_CALL ( AOM_ask_value_string(attachments[t1],"item_id",&erc_task_no) );
							printf("\nCabinKiterc 2 Action erc_task_no : [%s]",erc_task_no);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Action erc_task_no is : [%s]",erc_task_no);fflush(stdout);

							//  CMReferences for checking parts in task 
						//	ITK_CALL ( GRM_find_relation_type ( "CMReferences", &task_part_rel_type ) );
							ITK_CALL ( GRM_find_relation_type ( "CMHasSolutionItem", &task_part_rel_type ) );
							ITK_CALL ( GRM_list_secondary_objects_only ( attachments[t1], task_part_rel_type, &prtCount, &prt_Tags ) ) ;//task to dml traversal

							printf("\nCabinKiterc 2 Action erc_task prtCount : [%d]",prtCount);fflush(stdout);
							TC_write_syslog("\nCabinKit 2 Action erc_task prtCount is : [%d]",prtCount);fflush(stdout);

							if (prtCount>0)
							{
								for (t2 = 0;t2 < prtCount ;t2++ )
								{

									VC_prt_Tags = prt_Tags[t2];


									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"item_id",&partname));
	                                printf("\nCabinKitCre Action partname : [%s]",partname);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action partname : [%s]",partname);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_ProjectCode",&part_ProjectCode));
	                                printf("\nCabinKitCre Action part_ProjectCode : [%s]",part_ProjectCode);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action part_ProjectCode : [%s]",part_ProjectCode);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(VC_prt_Tags,"t5_cabkitapp",&part_cabkitapp));
	                                printf("\nCabinKitCre Action part_cabkitapp : [%s]",part_cabkitapp);fflush(stdout);
	                                TC_write_syslog("\nCabinKitCre Action part_cabkitapp : [%s]",part_cabkitapp);fflush(stdout);

									int n_found,i = 0 ;
                                    int n_entries = 2 ; 
                               //     char *cabkit_info1 = NULL;
									char *cabkit_info1 = NULL;
									char *cabkit_info2 = NULL;
									char *cabkit_info3 = NULL;
									char *cabkit_info4 = NULL;
									char *cabkit_info5 = NULL;
									char *cabkit_info6 = NULL;
									char *cabkit_info7 = NULL;
									char *cabkit_info8 = NULL;
									char *cabkit_info9 = NULL;
									char *cabkit_info10 = NULL;



                                    char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
                                    char *qry_values[2] =  { "CABKIT", "CABKIT" } ;
                                    tag_t query = NULLTAG ;
                                    tag_t *cntr_objects = NULL ;

                                    ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
                                    ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
                                    printf ( "\nCABKIT found : [%d] ",n_found ) ; fflush ( stdout) ;
                                    TC_write_syslog ( "\nCABKIT found : [%d] ",n_found ) ; fflush ( stdout) ;

									if ( n_found > 0 )
                                    {
										for ( i =0; i < n_found; i++)
											{
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo1",&cabkit_info1));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo2",&cabkit_info2));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo3",&cabkit_info3));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo4",&cabkit_info4));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo5",&cabkit_info5));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo6",&cabkit_info6));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo7",&cabkit_info7));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo8",&cabkit_info8));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo9",&cabkit_info9));
												ITK_CALL(AOM_ask_value_string(cntr_objects[i],"t5_Userinfo10",&cabkit_info10));
												printf("\nControl object cabkit : [%s,%s,%s,%s,%s,%s,%s,%s,%s,%s]",cabkit_info1,cabkit_info2,cabkit_info3,cabkit_info4,cabkit_info5,cabkit_info6,cabkit_info7,cabkit_info8,cabkit_info9,cabkit_info10);fflush(stdout);

												if (tc_strstr(cabkit_info1,part_ProjectCode) !=NULL || tc_strstr(cabkit_info2,part_ProjectCode) !=NULL || tc_strstr(cabkit_info3,part_ProjectCode) !=NULL ||tc_strstr(cabkit_info4,part_ProjectCode) !=NULL ||tc_strstr(cabkit_info5,part_ProjectCode) !=NULL || tc_strstr(cabkit_info6,part_ProjectCode) !=NULL || tc_strstr(cabkit_info7,part_ProjectCode) !=NULL || tc_strstr(cabkit_info8,part_ProjectCode) !=NULL || tc_strstr(cabkit_info9,part_ProjectCode) !=NULL  ||tc_strstr(cabkit_info10,part_ProjectCode) !=NULL )
												{


										//		ITK_CALL(AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&cabkit_info1));
										//		printf("\nCabinKitCre Action cabkit_info1 : [%s]",cabkit_info1);fflush(stdout);
												TC_write_syslog("\nCabinKitCre Action cabkit_info1 : [%s]",cabkit_info1);fflush(stdout);

												tc_strcpy (ctrlobjprjcode,",");
												tc_strcat (ctrlobjprjcode,part_ProjectCode);
												tc_strcat (ctrlobjprjcode,",");

												
										//		if (tc_strstr(cabkit_info1,ctrlobjprjcode)!=NULL)
										//		{

													printf("\nCabin Kit is applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
													TC_write_syslog("\nCabin Kit is applicable for project code : [%s]",part_ProjectCode);fflush(stdout);


													if (partname != NULL)
													{
														tc_strcpy(cabinkitID,"");
														tc_strcat(cabinkitID,partname);
														tc_strcat(cabinkitID,"CK");

														tc_strcpy(cabinkit_desc,"CABIN KIT FOR ");
														tc_strcat(cabinkit_desc,partname);
													

													}

											ITEM_find  (cabinkitID,&n_cabinkitID,&cabinkitID_tag); 

											if ( n_cabinkitID > 0 )
											{

												printf("\nCabin Kit : [%s] Already exist",cabinkitID);fflush(stdout);
												TC_write_syslog("\nCabin Kit : [%s] Already exist",cabinkitID);fflush(stdout);
											

												ITK_CALL (ITEM_find_item (cabinkitID,&cabinkitID_no_tag));

												ITK_CALL (ITEM_ask_latest_rev (cabinkitID_no_tag,&latestCkrev));

											    ITK_CALL ( GRM_find_relation_type ( "T5_HasSpareKit", &tRelationFind ) ) ;
											    printf("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    TC_write_syslog("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( VC_prt_Tags, latestCkrev, tRelationFind, NULLTAG, &PartCKRelTag ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag ) ) ;
											    ITK_CALL ( AOM_refresh ( VC_prt_Tags,FALSE ) );
											    printf("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname );
											    
												// Create relation with Solution  folder  CMHasSolutionItem
											    printf("\nCreating relation with Solution Items folder using CMHasSolutionItem\n");fflush(stdout);
											    TC_write_syslog("\nCreating relation with Solution Items folder using CMHasSolutionItem\n");
											    
											    ITK_CALL ( GRM_create_relation ( attachments[t1], latestCkrev, solution_relation_type, NULLTAG, &PartCKRelTag1 ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag1 ) ) ;
											    ITK_CALL ( AOM_refresh ( attachments[t1],FALSE ) ) ;
											    printf("\nCK [%s] attached to Solution Items of ERC Task [%s] successfully\n",cabinkitID, erc_task_no ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] attached to Solution Items of ERC Task [%s] successfully\n",cabinkitID, erc_task_no );
													
												a =1;

												ERCDML = tc_strtok(erc_task_no,"_");


												tc_strcpy(reportFile,"/tmp/Cabinkit_Bom_Report_system_");
												tc_strcat(reportFile,ERCDML);
												tc_strcat(reportFile,".txt");

												printf("\nReport : [%s]",reportFile);

												repfp = fopen(reportFile,"a");



												fprintf(repfp,"[%d],[%s]",a,cabinkitID);

												ITK_CALL(BOM_create_window(&window));
												ITK_CALL(BOM_set_window_pack_all (window, false));
												ITK_CALL(BOM_set_window_top_line(window, NULLTAG, latestCkrev, NULLTAG, &top_bomline));

												
												ExpandMultilvlforReport(top_bomline,repfp,a);

												fclose(repfp);

												ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &task_DML_rel_type ) );
												ITK_CALL ( GRM_list_primary_objects_only ( attachments[t1], task_DML_rel_type, &DMLCount, &DML_Tags ) ) ;//task to dml traversal

												if ( DMLCount > 0 )
												{
					
													ERCDML_Tag = DML_Tags[0];
													printf("\ninside attachment");
													tag_t	ImanRefRel		= NULLTAG;
													tag_t	dsTypeTxt		= NULLTAG;
													tag_t	newtxtDS		= NULLTAG;
													tag_t	Dml_ImanRefRel	= NULLTAG;
													tag_t	txtDS_Rev		= NULLTAG;

													char *ds_Name = (char *) MEM_alloc(50 * sizeof (char *));

													int						ds_ref_count = 0;
													char					**ref_list;
													tag_t					repFiletag	= NULLTAG;
													IMF_file_t				fileDescriptor;
													AE_reference_type_t		tagRefType = 1;

													printf("\n\n\nDataset Creation Starts...\n");fflush(stdout);

													ITK_CALL(GRM_find_relation_type("IMAN_reference", &ImanRefRel));

													ITK_CALL(AE_find_datasettype2("Text",&dsTypeTxt));

													if(dsTypeTxt == NULLTAG)
													{
													printf("\nCould not find Text Dataset\n");fflush(stdout);
													}

													tc_strcpy(ds_Name,"");
													tc_strcpy(ds_Name,"Cabinkit_Bom_Report_system_");
													tc_strcat(ds_Name,ERCDML);


													ITK_CALL(AE_create_dataset_with_id(dsTypeTxt,ds_Name,ds_Name,"","",&newtxtDS));
													ITK_CALL(AE_save_myself(newtxtDS));
													printf("\nText Dataset created successfully\n");

													ITK_CALL(AE_ask_dataset_latest_rev(newtxtDS,&txtDS_Rev));
													ITK_CALL(AOM_refresh(txtDS_Rev,TRUE));

													ITK_CALL(AE_ask_datasettype_refs(dsTypeTxt, &ds_ref_count, &ref_list));
													ITK_CALL(IMF_import_file(reportFile,NULL, SS_TEXT, &repFiletag, &fileDescriptor));
													ITK_CALL ( AOM_refresh (repFiletag,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(repFiletag));
													ITK_CALL ( AOM_refresh (repFiletag,FALSE ) ) ;//unlock
													printf("\nFile Imported successfully");fflush(stdout);

													ITK_CALL(AE_add_dataset_named_ref2(txtDS_Rev,ref_list[0],tagRefType,repFiletag));
													ITK_CALL ( AOM_refresh (txtDS_Rev,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(txtDS_Rev));
													ITK_CALL ( AOM_refresh (txtDS_Rev,FALSE ) ) ;//unlock
													printf("\nReport file added in dataset named reference successfully\n");

													ITK_CALL(GRM_create_relation(ERCDML_Tag,newtxtDS,ImanRefRel,NULLTAG,&Dml_ImanRefRel));
													ITK_CALL(GRM_save_relation(Dml_ImanRefRel));
													ITK_CALL(AOM_refresh(ERCDML_Tag,TRUE));
													printf("Excel Dataset attached in DML Iman reference relation successfully\n");
													if(ds_Name) MEM_free(ds_Name);
												}

											}
												
											else
											{

												//T5_SparKitRevision
												ITK_CALL ( TCTYPE_find_type ( "T5_SparKitRevision", NULL, &tRevTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
												printf ( "\nT5_SparKitRevision test" ) ; fflush ( stdout) ;
												TC_write_syslog ( "\nT5_SparKitRevision test" ) ;

												ITK_CALL ( TCTYPE_find_type ( "T5_SparKit", NULL, &tItemTypeTag ) ) ;
												ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
												printf("\nfind the item type T5_SparKit\n"); fflush ( stdout) ;
												TC_write_syslog("\nfind the item type T5_SparKit\n");

												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", cabinkitID ) ) ;		//item
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", cabinkitID ) ) ;
												ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_desc", cabinkit_desc ) ) ;

												ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;


												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_ProjectCode", part_ProjectCode ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DesignGrp", "00" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartType", "A" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PartStatus", "NA" ) );
												ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "item_revision_id", "NR;1" ) );

												ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;

												ITK_CALL ( AOM_refresh (tItemTag,TRUE ) );//lock
												ITK_CALL(AOM_save_without_extensions(tItemTag));
												ITK_CALL ( AOM_refresh (tItemTag,FALSE ) ) ;//unlock
											    ITK_CALL ( ITEM_ask_latest_rev ( tItemTag, &latestCkrev ) ) ;

												ITK_CALL ( AOM_set_value_string ( latestCkrev, "t5_cabkitapp", part_cabkitapp ) );

												CK_Bom_create (latestCkrev, tItemTag, VC_prt_Tags); 
	
											    ITK_CALL ( RES_checkin  ( latestCkrev ) ) ;

											    ITK_CALL ( GRM_find_relation_type ( "T5_HasSpareKit", &tRelationFind ) ) ;
											    printf("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    TC_write_syslog("\nfound relation T5_HasSpareKit \n");fflush(stdout);
											    
											    ITK_CALL ( GRM_create_relation ( VC_prt_Tags, latestCkrev, tRelationFind, NULLTAG, &PartCKRelTag ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag ) ) ;
											    ITK_CALL ( AOM_refresh ( VC_prt_Tags,FALSE ) );
											    printf("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] revision [%s] and part relation created successfully\n",cabinkitID, partname );
											    
												// Create relation with Solution  folder  CMHasSolutionItem
											    printf("\nCreating relation with Solution Items folder using CMHasSolutionItem\n");fflush(stdout);
											    TC_write_syslog("\nCreating relation with Solution Items folder using CMHasSolutionItem\n");
											    
											    ITK_CALL ( GRM_create_relation ( attachments[t1], latestCkrev, solution_relation_type, NULLTAG, &PartCKRelTag1 ) ) ;
											    ITK_CALL ( GRM_save_relation ( PartCKRelTag1 ) ) ;
											    ITK_CALL ( AOM_refresh ( attachments[t1],FALSE ) ) ;
											    printf("\nCK [%s] attached to Solution Items of ERC Task [%s] successfully\n",cabinkitID, erc_task_no ); fflush ( stdout) ;
											    TC_write_syslog("\nCK [%s] attached to Solution Items of ERC Task [%s] successfully\n",cabinkitID, erc_task_no );
												      
												printf ( "\nCreating BOM report of Cabin Kit : [%s]",cabinkitID) ; fflush ( stdout) ;
												TC_write_syslog ( "\nCreating BOM report of Cabin Kit : [%s]",cabinkitID) ; fflush ( stdout) ;


												a =1;
												ERCDML = tc_strtok(erc_task_no,"_");


												tc_strcpy(reportFile,"/tmp/Cabinkit_Bom_Report_system_");
												tc_strcat(reportFile,ERCDML);
												tc_strcat(reportFile,".txt");

												printf("\nReport : [%s]",reportFile);

												repfp = fopen(reportFile,"a");



												fprintf(repfp,"[%d],[%s]",a,cabinkitID);

												ITK_CALL(BOM_create_window(&window));
												ITK_CALL(BOM_set_window_pack_all (window, false));
												ITK_CALL(BOM_set_window_top_line(window, NULLTAG, latestCkrev, NULLTAG, &top_bomline));

												
												ExpandMultilvlforReport(top_bomline,repfp,a);

												fclose(repfp);

												ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &task_DML_rel_type ) );
												ITK_CALL ( GRM_list_primary_objects_only ( attachments[t1], task_DML_rel_type, &DMLCount, &DML_Tags ) ) ;//task to dml traversal

												if ( DMLCount > 0 )
												{
					
													ERCDML_Tag = DML_Tags[0];
													printf("\ninside attachment");
													tag_t	ImanRefRel		= NULLTAG;
													tag_t	dsTypeTxt		= NULLTAG;
													tag_t	newtxtDS		= NULLTAG;
													tag_t	Dml_ImanRefRel	= NULLTAG;
													tag_t	txtDS_Rev		= NULLTAG;

													char *ds_Name = (char *) MEM_alloc(50 * sizeof (char *));

													int						ds_ref_count = 0;
													char					**ref_list;
													tag_t					repFiletag	= NULLTAG;
													IMF_file_t				fileDescriptor;
													AE_reference_type_t		tagRefType = 1;

													printf("\n\n\nDataset Creation Starts...\n");fflush(stdout);

													ITK_CALL(GRM_find_relation_type("IMAN_reference", &ImanRefRel));

													ITK_CALL(AE_find_datasettype2("Text",&dsTypeTxt));

													if(dsTypeTxt == NULLTAG)
													{
													printf("\nCould not find Text Dataset\n");fflush(stdout);
													}

													tc_strcpy(ds_Name,"");
													tc_strcpy(ds_Name,"Cabinkit_Bom_Report_system_");
													tc_strcat(ds_Name,ERCDML);


													ITK_CALL(AE_create_dataset_with_id(dsTypeTxt,ds_Name,ds_Name,"","",&newtxtDS));
													ITK_CALL(AE_save_myself(newtxtDS));
													printf("\nText Dataset created successfully\n");

													ITK_CALL(AE_ask_dataset_latest_rev(newtxtDS,&txtDS_Rev));
													ITK_CALL(AOM_refresh(txtDS_Rev,TRUE));

													ITK_CALL(AE_ask_datasettype_refs(dsTypeTxt, &ds_ref_count, &ref_list));
													ITK_CALL(IMF_import_file(reportFile,NULL, SS_TEXT, &repFiletag, &fileDescriptor));
													ITK_CALL ( AOM_refresh (repFiletag,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(repFiletag));
													ITK_CALL ( AOM_refresh (repFiletag,FALSE ) ) ;//unlock
													printf("\nFile Imported successfully");fflush(stdout);

													ITK_CALL(AE_add_dataset_named_ref2(txtDS_Rev,ref_list[0],tagRefType,repFiletag));
													ITK_CALL ( AOM_refresh (txtDS_Rev,TRUE ) );//lock
													ITK_CALL(AOM_save_without_extensions(txtDS_Rev));
													ITK_CALL ( AOM_refresh (txtDS_Rev,FALSE ) ) ;//unlock
													printf("\nReport file added in dataset named reference successfully\n");

													ITK_CALL(GRM_create_relation(ERCDML_Tag,newtxtDS,ImanRefRel,NULLTAG,&Dml_ImanRefRel));
													ITK_CALL(GRM_save_relation(Dml_ImanRefRel));
													ITK_CALL(AOM_refresh(ERCDML_Tag,TRUE));
													printf("Excel Dataset attached in DML Iman reference relation successfully\n");
													if(ds_Name) MEM_free(ds_Name);
												}

											}
									//	}
									}
								}
									}
										else
										{

											printf("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
											TC_write_syslog("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
											prjflag =1;


										}
									}
									
								}

							}



						}

	
					}

				}

			}



	if (prjflag > 0)
	{
		
		printf("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);
		TC_write_syslog("\nCabin Kit is not applicable for project code : [%s]",part_ProjectCode);fflush(stdout);

		EMH_store_error_s2(EMH_severity_warning,ITK_err, "Cabin Kit is not applicable for project code :",part_ProjectCode);
		decision = EPM_nogo;
		return decision;
	}
	else
	{

		if ( cabinkitID ) MEM_free ( cabinkitID ) ;
		if ( cabinkit_desc ) MEM_free ( cabinkit_desc  ) ;
		if ( ctrlobjprjcode) MEM_free ( ctrlobjprjcode ) ;
		if ( reportFile) MEM_free ( reportFile ) ;
		
		printf("\n------------------------CABIN KIT CREATION action handler DONE-------------------------\n");
		TC_write_syslog("\n------------------------CABIN KIT CREATION action handler DONE-------------------------\n");
		return ITK_ok;
	}
}



extern int tm_CabinKitAppbUpd_register_method(int *decision, va_list args)
{
	*decision = ALL_CUSTOMIZATIONS;
	
	if( ITK_ok == EPM_register_rule_handler ( "tm_RuleH_CabinKitAppbUpd", "", (EPM_rule_handler_t) tm_fctn_CabinKitAppbUpd_rule_handler ) )
	{
		printf("\nRegistered EPM_register_rule_handler tm_fctn_CabinKitAppbUpd_rule_handler");fflush(stdout);
		TC_write_syslog("\nRegistered EPM_register_rule_handler tm_fctn_CabinKitAppbUpd_rule_handler");fflush(stdout);
	}
	else
	{
		printf("\nFAILED to register EPM_register_rule_handler tm_fctn_CabinKitAppbUpd_rule_handler\n");fflush(stdout);
		TC_write_syslog("\nFAILED to register EPM_register_rule_handler tm_fctn_CabinKitAppbUpd_rule_handler\n");fflush(stdout);
	}

	if ( ITK_ok == EPM_register_action_handler ( "tm_ActnH_CabinKitAppbUpd", "", tm_fctn_CabinKitAppbUpd_action_handler ) )
	{
		printf("\nRegistered EPM_register_action_handler tm_fctn_CabinKitAppbUpd_action_handler");fflush(stdout);
		TC_write_syslog("\nRegistered EPM_register_action_handler tm_fctn_CabinKitAppbUpd_action_handler");fflush(stdout);
	}
	else
	{
		printf("\nFAILED to register EPM_register_action_handler tm_fctn_CabinKitAppbUpd_action_handler\n");fflush(stdout);
		TC_write_syslog("\nFAILED to register EPM_register_action_handler tm_fctn_CabinKitAppbUpd_action_handler\n");fflush(stdout);
	}

	if ( ITK_ok == EPM_register_action_handler ( "tm_ActnH_CabimKitCre", "", tm_fctn_CabinKitCre_action_handler ) )// Cabin kit create for release VC Action handler
	{
		printf("\nRegistered EPM_register_action_handler tm_fctn_CabinKitCre_action_handler");fflush(stdout);
		TC_write_syslog("\nRegistered EPM_register_action_handler tm_fctn_CabinKitCre_action_handler");fflush(stdout);
	}
	else
	{
		printf("\nFAILED to register EPM_register_action_handler tm_fctn_CabinKitCre_action_handler\n");fflush(stdout);
		TC_write_syslog("\nFAILED to register EPM_register_action_handler tm_fctn_CabinKitCre_action_handler\n");fflush(stdout);
	}
	if( ITK_ok == EPM_register_rule_handler ( "tm_RuleH_CabinKitCre", "", (EPM_rule_handler_t) tm_fctn_CabinKitCre_rule_handler ) )// Cabin kit create for release VC Rule handler
	{
		printf("\nRegistered EPM_register_rule_handler tm_fctn_CabinKitCre_rule_handler");fflush(stdout);
		TC_write_syslog("\nRegistered EPM_register_rule_handler tm_fctn_CabinKitCre_rule_handler");fflush(stdout);
	}
	else
	{
		printf("\nFAILED to register EPM_register_rule_handler tm_fctn_CabinKitCre_rule_handler\n");fflush(stdout);
		TC_write_syslog("\nFAILED to register EPM_register_rule_handler tm_fctn_CabinKitCre_rule_handler\n");fflush(stdout);
	}
	
 return ITK_ok;
}

extern DLLAPI int tm_CabinKitAppbUpd_register_callbacks()
{

	CUSTOM_register_exit("tm_CabinKitAppbUpd", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_CabinKitAppbUpd_register_method);
	printf("\nregistered CUSTOM_register_exit tm_CabinKitAppbUpd\n");	fflush(stdout);
	TC_write_syslog("\nregistered CUSTOM_register_exit tm_CabinKitAppbUpd\n");	fflush(stdout);
	return ( ITK_ok );
}