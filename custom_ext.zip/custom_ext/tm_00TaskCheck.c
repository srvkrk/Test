/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Module               :   To check standalone VC.
*  Code                 :   tm_00TaskCheck.c
*  Created on			:   21/04/2023
* Modification History :
* S.No    Date          CR No		Modified By         Modification Notes
* 1.	 21/04/2023				Mohan Tayade			 To check standalone VC.
***************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_00TaskCheck(EPM_action_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int countt				= 0;
	int no_attach			= 0;
	int error_code			= ITK_ok;
	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	int	taskflag =0;
	char *dmlTaskNo= NULL;
	char *DMLtype= NULL;
	char * sDMLno= NULL;
	char * DMLprirty= NULL;
	tag_t  objTypTag = NULLTAG;
	tag_t  DMLRevTg = NULLTAG;
	tag_t  tsk_dml_rel_type = NULLTAG;
	tag_t  *DMLRevision = NULLTAG;
	char*	ObjTyp= NULL;
	tag_t  DMLTaskTag = NULLTAG;
	logical is_latest;

	//EPM_decision_t decision = EPM_go;
	
	printf("\n tm_00TaskCheck Function started...");fflush(stdout);
	TC_write_syslog("\n tm_00TaskCheck Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n tm_00TaskCheck:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n tm_00TaskCheck:INSIDE Attachments.");fflush(stdout);
			DMLTaskTag=taskAttachments[i];
			if (DMLTaskTag != NULLTAG)
			{
				if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n tm_00TaskCheck: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
				{
					if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
					printf("\n tm_00TaskCheck--DML Task No: [%s] \n", dmlTaskNo);fflush(stdout);
					taskflag=0;
					if(tc_strstr(dmlTaskNo,"_00")!=NULL)
					{
						taskflag=1;
					}
					printf("\n tm_00TaskCheck--taskflag= %d ",taskflag);fflush(stdout);
					if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
					if (tsk_dml_rel_type!=NULLTAG)
					{
						if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&countt,&DMLRevision)!=ITK_ok)PrintErrorStack();
						printf("\n tm_00TaskCheck--DML Revision from Task for : %d",countt);fflush(stdout);

						
						for (j=0;j<countt ;j++ )
						{
							if(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest)!=ITK_ok)PrintErrorStack();
							printf("\n tm_00TaskCheck--is_latest  is : %d\n",is_latest);fflush(stdout);

							if(is_latest != true)
							{
								printf("\n tm_00TaskCheck--is_latest is not true .....\n");fflush(stdout);
							}
							else
							{
								DMLRevTg = DMLRevision[j];
								if(AOM_ask_value_string(DMLRevTg,"item_id",&sDMLno)!=ITK_ok)PrintErrorStack();
								printf("\n tm_00TaskCheck--for sDMLno : [%s] ",sDMLno);fflush(stdout);
								if(AOM_ask_value_string(DMLRevTg,"t5_rlstype",&DMLtype)!=ITK_ok)PrintErrorStack();
								printf(" Release Type: [%s]", DMLtype); fflush(stdout);
								if(AOM_ask_value_string(DMLRevTg,"t5_cpriority",&DMLprirty)!=ITK_ok)PrintErrorStack();
								printf(" DMLprirty: [%s]\n", DMLprirty); fflush(stdout);
								if ((tc_strcmp(DMLtype,"TODR")==0)||(tc_strcmp(DMLtype,"Veh")==0))	//for Gate Maturation and Vehicle release
								{
									//Priority High means: SVR VC case.
									if (taskflag==1)
									{
										printf("\n tm_00TaskCheck: 00 task found.....\n");fflush(stdout);
										return 0;
									}
									else
									{
										printf("\n tm_00TaskCheck Other group task..... \n");fflush(stdout);
										return 10002;
									}
								}
								else
								{
									printf("\n tm_00TaskCheck:Not for DML type. \n");fflush(stdout);
									return 0;
								}
							}
						}
					}
				}
			}
		}
	}
	printf("\n tm_00TaskCheck Function end...");fflush(stdout);
	TC_write_syslog("\n tm_00TaskCheck Function end...");
	//return error_code;
	return 0;
}