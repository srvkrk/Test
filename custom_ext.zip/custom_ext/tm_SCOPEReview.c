#include "TMLLibrary_server_exits.h"

#define ITK_err 919002
#define SCOPE_VAL EMH_USER_error_base+30

extern EPM_decision_t DLLAPI tm_SCOPEReview(EPM_rule_message_t msg)
{
    int seccount      =0;
    int i             =0;
    int DMLScopeDoc   =0;
    int Taskcout      =0;
    int partcnt       =0;
    int no_attach     =0;
    int ChkScopeFlag  =0;
    int count  =0;
    int kk  =0;
    int prt  =0;
    int ChkDMLScop  =0;
    int p  =0;
    tag_t DMLTag     = NULLTAG;
    tag_t dmltag     = NULLTAG;
    tag_t DMLRevTag  = NULLTAG;
    tag_t rel_type   = NULLTAG;
    tag_t DmlTsk_tag = NULLTAG;
    tag_t TskTypeTag = NULLTAG;
    tag_t objTypTag = NULLTAG;
    tag_t AssyTag   = NULLTAG;
	tag_t roottask			 = NULLTAG;
	tag_t query			 = NULLTAG;
    tag_t *secobjects  = NULLTAG;
    tag_t *TskRevn_tag = NULLTAG;
    tag_t *PartsTag    = NULLTAG;
	tag_t *contrlObjs  = NULLTAG;
	tag_t * Attachments= NULLTAG;
    char *drstatus   = NULL;
    char *item_id    = NULL;
    char *Chklistvar = NULL;
    char *scopedoc   = NULL;
    char *docname    = NULL;
    char *doctype    = NULL;
	char *DMLNo      = NULL;
	char *Tsk_Typ    = NULL;
	char *Part_no    = NULL;
	char *Part_prj   = NULL;
	char *DesgTyp    = NULL;
	char *sScopeInfo1    = NULL;
	char *sScopeInfo4    = NULL;
	char *sScopeInfo2    = NULL;
	char *sScopeInfo5    = NULL;
	char *sScopeInfo3    = NULL;
	char *objTypeofTask    = NULL;
	char *sDMLUnt    = NULL;
	char *DMLtype    = NULL;
	char *sDMLrlstype    = NULL;
	logical     is_latest;
	logical     is_Tskltst;

	EPM_decision_t decision = EPM_go;

    char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values  = (char **) MEM_alloc(100 * sizeof(char *));
	sDMLrlstype=(char *)MEM_alloc(20);

	printf("\n tm_SCOPEReview Function started...");fflush(stdout);
	TC_write_syslog("\n tm_SCOPEReview Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n :INSIDE Attachments.");fflush(stdout);
			DMLRevTag=Attachments[i];

			if (DMLRevTag != NULLTAG)
			{
				qry_entries[0] ="SYSCD";
				qry_values[0]  ="SCOPECHK";

				ITK_CALL(QRY_find2("Control Objects...", &query));
				ITK_CALL(QRY_execute(query,1,qry_entries,qry_values,&count,&contrlObjs));
				printf("\n Control objects : count==>%d \n",count);fflush(stdout);
				if (count>0)
				{
					//ON/OFF
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo1",&sScopeInfo1));
					//DML type for: DML SCOPE
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo2",&sScopeInfo2));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo3",&sScopeInfo3));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo4",&sScopeInfo4));
					ITK_CALL(AOM_ask_value_string(contrlObjs[0],"t5_Userinfo5",&sScopeInfo5));
					printf("\n L1:sScopeInfo1 is : [%s]  L2:sScopeInfo2 is : [%s]  L3:sScopeInfo3 is : [%s] L4:sScopeInfo4 is : [%s]\n",sScopeInfo1,sScopeInfo2,sScopeInfo3,sScopeInfo4);fflush(stdout);
					printf("\n DML BU skipped: %s \n",sScopeInfo5);fflush(stdout);

					if(tc_strstr(sScopeInfo1,"SCOPEOFF1") == NULL)
					{
						ChkDMLScop=0;
						ITK_CALL(TCTYPE_ask_object_type(DMLRevTag,&objTypTag));
						printf("\n objtype found \n");fflush(stdout);
					  
						ITK_CALL(TCTYPE_ask_name2(objTypTag,&objTypeofTask));
						printf("\n  object_type is %s\n", objTypeofTask);fflush(stdout);
						if(tc_strcmp(objTypeofTask,"ChangeRequestRevision")==0)
						{
							if(tc_strstr(sScopeInfo1,"SCOPEOFF2") == NULL)
							{
								ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"item_id",&item_id));
								printf("\n item_id is: %s \n",item_id);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype));
								printf("\n  t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

								ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"t5_cDRstatus",&drstatus));
								printf("\n drstatus is: %s \n",drstatus);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&sDMLUnt));
								printf("\n sDMLUnt is: %s \n",sDMLUnt);fflush(stdout);
								if(tc_strstr(sScopeInfo5,sDMLUnt) == NULL)
								{
									printf(" AA.");fflush(stdout);
									if(tc_strstr(sScopeInfo5,drstatus) == NULL)
									{
										printf(" BB.");fflush(stdout);
										ChkDMLScop=1;
									}
									else
									{
										printf(" CC.");fflush(stdout);
										ChkDMLScop=0;
									}
								}
								else
								{
									printf(" DD.");fflush(stdout);
									ChkDMLScop=0;
								}
								printf("\n DML scope: ChkDMLScop: %d",ChkDMLScop);fflush(stdout);
								if(ChkDMLScop >0)
								{
									tc_strcpy(sDMLrlstype,"");
									tc_strcpy(sDMLrlstype,",");
									tc_strcat(sDMLrlstype,DMLtype);
									tc_strcat(sDMLrlstype,",");
									printf("\n sDMLrlstype: %s",sDMLrlstype);fflush(stdout);

									/*Chklistvar = MEM_alloc(50);
									tc_strcat(Chklistvar,item_id);
									tc_strcat(Chklistvar,"_");
									tc_strcat(Chklistvar,drstatus);
									tc_strcat(Chklistvar,"_Gateway_Checklist");*/
									scopedoc = MEM_alloc(50);
									tc_strcat(scopedoc,"DSAS_");
									tc_strcat(scopedoc,item_id);
									printf("\n scopedoc is: %s \n",scopedoc);fflush(stdout);

									if(tc_strstr(sScopeInfo2,sDMLrlstype)!=NULL)
									{
										ChkScopeFlag=0;
										if (tc_strcmp(DMLtype,"TODR")==0)
										{
											if (tc_strcmp(drstatus,"DR3P")==0)
											{
												ChkScopeFlag=1;
											}
											else
											{
												//GO to task to part type
												if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
												if (DmlTsk_tag!=NULLTAG)
												{		
													if(GRM_list_secondary_objects_only(DMLRevTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
													printf("\n CV_CERT:P9:GM:: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
													for (kk=0;kk<Taskcout ;kk++ )
													{
														if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
														if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
														printf("\n CV_CERT:P10:GM:: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
														if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
														{
															if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
															if(is_Tskltst != true)
															{
																printf("\n CV_CERT:P11:GM::is_Tskltst is not true .....\n");fflush(stdout);
															}
															else
															{
																if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																printf("\n CV_CERT:P12:GM:: partcnt.:%d\n",partcnt);fflush(stdout);
																if (partcnt>0)
																{
																	prt=0;
																
																	for (prt=0;prt<partcnt ;prt++ )
																	{							
																		AssyTag=PartsTag[prt];
																		if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																		printf("\n CV_CERT:P12:GM::.Part_no:%s ...",Part_no);	fflush(stdout);
																		if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																		printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																		if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																		printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																		if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																		{
																			ChkScopeFlag=1;
																			printf("\n CV_CERT:P13:GM:ChkScopeFlag:%d",ChkScopeFlag);fflush(stdout);
																		}
																	}
																}
															}
														}
													}
												}
											}
											printf("\n CV_CERT:P13:GM:Final ChkScopeFlag:%d",ChkScopeFlag);fflush(stdout);
										}
										else
										{
											ChkScopeFlag=0;
											printf("\n CV_CERT:P13:MR:Final ChkScopeFlag:%d",ChkScopeFlag);fflush(stdout);
										}
									}
									else
									{
										printf("\n DML type is not apllicable t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);
										decision = EPM_go;
										return decision;
									}
									if (ChkScopeFlag ==0)
									{
										ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
								  
										ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&seccount,&secobjects));
										printf("\n seccount:%d\n",seccount);fflush(stdout);
										if (seccount>0)
										{
											DMLScopeDoc = 0;
											for(i=0;i<seccount;i++)
											{
												ITK_CALL(AOM_UIF_ask_value(secobjects[i],"object_type",&doctype)); 
												if (tc_strstr(doctype,"PDF")!=NULL)
												{
													ITK_CALL(AOM_UIF_ask_value(secobjects[i],"current_name",&docname)); 
													//if ((tc_strstr(docname,Chklistvar)!=NULL)) //&& 
													if(tc_strstr(docname,scopedoc)!=NULL)
													{
														printf("\n Scope Doc attached found \n");fflush(stdout);
														printf("\n checlist attached found \n");fflush(stdout);
														DMLScopeDoc = 1;							
														break;
													}
												}
											}
										}
										if (DMLScopeDoc == 0)
										{
										  if(tc_strstr(sScopeInfo1,"SCP001") == NULL)
										  {
											printf("\n Condition 3 found"); fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,  "\n The validity of the DML scope document needs to be reconfirmed after every rejection of the DML in its workflow. \n Please check and initiate the DML scope document workflow afresh, if required.");
											decision = EPM_nogo;
											return decision;
											printf("\nCE Review: DML scope doc is NOT attached.  \n"); fflush(stdout); 
										  }
										}
										else
										{
										printf("\n CE Review: DML scope doc is attached. \n"); fflush(stdout);
										decision = EPM_go;
										return decision;
										}
									}
									else
									{
										decision = EPM_go;
										return decision;
									}
								}
							}
						}
						else if(tc_strcmp(objTypeofTask,"T5_ChangeTaskRevision")==0)
						{
							if(tc_strstr(sScopeInfo1,"SCOPEOFF3") == NULL)
							{
								if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
								if (DmlTsk_tag!=NULLTAG)
								{		
									if(GRM_list_primary_objects_only(DMLRevTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
									printf("\n CV_CERT:P9:GM:: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
									for (p=0; p<Taskcout; p++)
									{
										ChkDMLScop=0;
										dmltag = TskRevn_tag[p];

										ITK_CALL(AOM_UIF_ask_value(dmltag,"item_id",&item_id));
										printf("\n item_id is: %s \n",item_id);fflush(stdout);

										ITK_CALL(AOM_ask_value_string(dmltag,"t5_rlstype",&DMLtype));
										printf("\n  t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);

										ITK_CALL(AOM_UIF_ask_value(dmltag,"t5_cDRstatus",&drstatus));
										printf("\n drstatus is: %s \n",drstatus);fflush(stdout);
										
										ITK_CALL(AOM_ask_value_string(dmltag,"t5_ERCBusiUt",&sDMLUnt));
										printf("\n sDMLUnt is: %s \n",sDMLUnt);fflush(stdout);
										if(tc_strstr(sScopeInfo5,sDMLUnt) == NULL)
										{
											printf(" QQ.."); fflush(stdout);
											if(tc_strstr(sScopeInfo5,drstatus) == NULL)
											{
												printf(" RR.."); fflush(stdout);
												ChkDMLScop=1;
											}
											else
											{
												printf(" EE.."); fflush(stdout);
												ChkDMLScop=0;
											}
										}
										else
										{
											printf(" TT..\n"); fflush(stdout);
											ChkDMLScop=0;
										}
										printf("\n DML scope:: ChkDMLScop: %d",ChkDMLScop);fflush(stdout);
										if(ChkDMLScop >0)
										{
											tc_strcpy(sDMLrlstype,"");
											tc_strcpy(sDMLrlstype,",");
											tc_strcat(sDMLrlstype,DMLtype);
											tc_strcat(sDMLrlstype,",");
											printf("\n sDMLrlstype: %s",sDMLrlstype);fflush(stdout);

											/*Chklistvar = MEM_alloc(50);
											tc_strcat(Chklistvar,item_id);
											tc_strcat(Chklistvar,"_");
											tc_strcat(Chklistvar,drstatus);
											tc_strcat(Chklistvar,"_Gateway_Checklist");*/
											scopedoc = MEM_alloc(50);
											tc_strcat(scopedoc,"DSAS_");
											tc_strcat(scopedoc,item_id);
											printf("\n scopedoc is: %s \n",scopedoc);fflush(stdout);

											if(tc_strstr(sScopeInfo2,sDMLrlstype)!=NULL)
											{
												ChkScopeFlag=0;
												if (tc_strcmp(DMLtype,"TODR")==0)
												{
													if (tc_strcmp(drstatus,"DR3P")==0)
													{
														ChkScopeFlag=1;
													}
													else
													{
														//GO to task to part type
														if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
														if (DmlTsk_tag!=NULLTAG)
														{		
															if(GRM_list_secondary_objects_only(dmltag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
															printf("\n CV_CERT:P9:GM:: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
															for (kk=0;kk<Taskcout ;kk++ )
															{
																if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
																if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
																printf("\n CV_CERT:P10:GM:: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
																if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
																{
																	if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																	if(is_Tskltst != true)
																	{
																		printf("\n CV_CERT:P11:GM::is_Tskltst is not true .....\n");fflush(stdout);
																	}
																	else
																	{
																		if(AOM_ask_value_tags(TskRevn_tag[kk],"CMReferences",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																		printf("\n CV_CERT:P12:GM:: partcnt.:%d\n",partcnt);fflush(stdout);
																		if (partcnt>0)
																		{
																			prt=0;
																			
																			for (prt=0;prt<partcnt ;prt++ )
																			{							
																				AssyTag=PartsTag[prt];
																				if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																				printf("\n CV_CERT:P12:GM::.Part_no:%s ...",Part_no);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																				printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																				if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																				printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																				if((tc_strcmp(DesgTyp,"V")==0)||(tc_strcmp(DesgTyp,"VC")==0)||(tc_strcmp(DesgTyp,"CCVC")==0))
																				{
																					ChkScopeFlag=1;
																					printf("\n CV_CERT:P13:ChkScopeFlag review:%d",ChkScopeFlag);fflush(stdout);
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
												else
												{
													ChkScopeFlag=0;
													printf("\n DML type is appicable : [%d]\n", ChkScopeFlag); fflush(stdout);
												}
											}
											else
											{
												printf("\n DML type is not apllicable t5_rlstype is : [%s]\n", DMLtype); fflush(stdout);
												decision = EPM_go;
												return decision;
											}

											if (ChkScopeFlag ==0)
											{
												DMLScopeDoc = 0;
												ITK_CALL(GRM_find_relation_type("IMAN_reference",&rel_type));
												ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,rel_type,&seccount,&secobjects));
												if (seccount>0)
												{
												  for(i=0;i<seccount;i++)
												  {
													  ITK_CALL(AOM_UIF_ask_value(secobjects[i],"object_type",&doctype)); 
													  if (tc_strstr(doctype,"PDF")!=NULL)
													  {
														ITK_CALL(AOM_UIF_ask_value(secobjects[i],"current_name",&docname)); 
														//if ((tc_strstr(docname,Chklistvar)!=NULL)) //&& 
														if((tc_strstr(docname,scopedoc)!=NULL) && (tc_strstr(docname,Chklistvar)!=NULL))
														{
															DMLScopeDoc = 1;	
															printf("\n Scope Doc attached found :%d \n",DMLScopeDoc);fflush(stdout);				
															break;
														}
													  }
												   }
												}
												if (DMLScopeDoc == 1)
												{
													decision = EPM_go;
													printf("\n DML Scope attached... \n");fflush(stdout);
													return decision;
												}
												else
												{
												  printf("\n Condition 3 found"); fflush(stdout);
												  if(tc_strstr(sScopeInfo1,"SCP002") == NULL)
												  {
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_warning,SCOPE_VAL,"\nPlease ensure that the DML scope document workflow is initiated so that it gets attached to the DML before the CE sign-off. \n In absence of the DML scope document, the DML can�t cross the CE sign-off node.");
													decision = EPM_go;
													printf("\n A--End of for loop for check.............................. \n");fflush(stdout);
													return decision;

													printf("\n SOFT CHK: DML scope doc is NOT attached.  \n"); fflush(stdout);
												  }
												}
											}
											else
											{
												printf("\n DML scope bypass for Vehicle..  \n"); fflush(stdout);
												decision = EPM_go;
												return decision;
											}
										}
										else
										{
											decision = EPM_go;
											return decision;
										}
									}
								}
							}
						}
					}
					else
					{
						 decision = EPM_go;
						 return decision;
					}
				}
			}
		}
	}
	/*if(sScopeInfo1){MEM_free(sScopeInfo1);}
	if(sScopeInfo2){MEM_free(sScopeInfo2);}
	if(sScopeInfo3){MEM_free(sScopeInfo3);}
	if(sScopeInfo4){MEM_free(sScopeInfo4);}
	if(sScopeInfo5){MEM_free(sScopeInfo5);}
	if(DMLtype){MEM_free(DMLtype);}
	if(drstatus){MEM_free(drstatus);}
	if(sDMLUnt){MEM_free(sDMLUnt);}
	if(Part_no){MEM_free(Part_no);}
	if(Part_prj){MEM_free(Part_prj);}
	if(DesgTyp){MEM_free(DesgTyp);}
	if(item_id){MEM_free(item_id);}*/
	printf("\n tm_SCOPEReview Function end...");fflush(stdout);
	TC_write_syslog("\n tm_SCOPEReview Function end...");
	return decision;
}