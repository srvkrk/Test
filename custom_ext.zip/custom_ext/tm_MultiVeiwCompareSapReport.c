
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:	tm_MultiVeiwCompareSapReport.c
*
* Description	: > 
*				  > 
* Module  		        
* Since		    :   31-08-2023
* ENVIRONMENT	:   ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 31/08/2023   	 Amar Kate				    Base Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <lov/lov_msg.h> 
#include <pom/enq/enq.h>
#include <tccore/tctype.h>
#include <qry/qry.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <pom/pom/pom_errors.h>
#include <mld/journal/journal.h>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/grmtype.h>
#include <epm/releasestatus.h>
#include <tccore/releasestatus.h>
#define ITK_errStore1 (EMH_USER_error_base + 5)

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI1(expr)ITK_CALL_CKD(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL_CKD(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define ITK_err (EMH_USER_error_base+3)


//using namespace std;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int tm_MultiVeiwCompareSapReport_Call(void *return_data)
{
	int ifail = ITK_ok;
	int		status;
	
	char* VCList			=NULL;
	char* MailList			=NULL;
	char* sapServer			=NULL;
	char* selPlant			=NULL;
	char* sapPlant			=NULL;     
	char* ercRevRule		=NULL;   
	char* ercClousreRule	=NULL;
	char* aplRevRule		=NULL;    
	char* aplClousreRule	=NULL;
	char* stdRevRule		=NULL;    
	char* stdClousreRule	=NULL;
	char* compath			=NULL;

	printf("\n Amar Inside tm_MultiVeiwCompareSapReport_Release_Call .....\n");
	
	USERARG_get_string_argument(&VCList);
	USERARG_get_string_argument(&MailList);              
	USERARG_get_string_argument(&sapServer);              
	USERARG_get_string_argument(&selPlant);              
	USERARG_get_string_argument(&sapPlant);              
	USERARG_get_string_argument(&ercRevRule);              
	USERARG_get_string_argument(&ercClousreRule);              
	USERARG_get_string_argument(&aplRevRule);
	USERARG_get_string_argument(&aplClousreRule);
	USERARG_get_string_argument(&stdRevRule);
	USERARG_get_string_argument(&stdClousreRule);
	USERARG_get_string_argument(&compath);
           
	 
	printf("\n VCList => %s\n",VCList);fflush(stdout);
	printf("\n MailList => %s\n",MailList);fflush(stdout);
	printf("\n sapServer => %s\n",sapServer);fflush(stdout);
	printf("\n selPlant => %s\n",selPlant);fflush(stdout);
	printf("\n sapPlant => %s\n",sapPlant);fflush(stdout);
	printf("\n ercRevRule => %s\n",ercRevRule);fflush(stdout);
	printf("\n ercClousreRule => %s\n",ercClousreRule);fflush(stdout);
	printf("\n aplRevRule => %s\n",aplRevRule);fflush(stdout);
	printf("\n aplClousreRule => %s\n",aplClousreRule);fflush(stdout);
	printf("\n stdRevRule => %s\n",stdRevRule);fflush(stdout);
	printf("\n stdClousreRule => %s\n",stdClousreRule);fflush(stdout);
	printf("\n compath => %s\n",compath);fflush(stdout);

 
	// Control Object for EXE
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"VCCMP","CONFIG","0"};
	
    tag_t qryTagCntrl1=NULLTAG;
    int control_number_found1;
    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;

	int n_entryCntrl1=3;

	CALLAPI1(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    CALLAPI1(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
		
		if(control_number_found1>0)
	   {
			char* t5_Userinfo4 = NULL;
			char cmd[100];
			tag_t obj = list_of_WSO_cntrl_tags1[0];
			CALLAPI1(AOM_ask_value_string(obj,"t5_Userinfo4",&t5_Userinfo4));	
			//sprintf(cmd,"%s -if=%s -im=%s -iv=%s -ip=%s -is=%s -ier=\"%s\" -iec=%s -iar=\"%s\" -iac=%s -isr=\"%s\" -isc=%s -icp=%s &",t5_Userinfo4,VCList,MailList,sapServer,selPlant,sapPlant,ercRevRule,ercClousreRule,aplRevRule,aplClousreRule,stdRevRule,stdClousreRule,compath);
			sprintf(cmd,"%s %s %s %s %s %s \"%s\" %s \"%s\" %s \"%s\" %s %s &",t5_Userinfo4,VCList,MailList,sapServer,selPlant,sapPlant,ercRevRule,ercClousreRule,aplRevRule,aplClousreRule,stdRevRule,stdClousreRule,compath);
			printf("Excuting Command = %s",cmd);fflush(stdout);
			system(cmd);
			printf("After executing Command");fflush(stdout);
	   }
	}
		
	return ifail;

}

extern int tm_MultiVeiwCompareSapReportinitmodule(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	// Amar Added for tm_MultiVeiwCompareSapReport

	int nargs1 = 12;
	int retValueType1;
	int inputArgTypes1[12] = {0};
	
	inputArgTypes1[0] = USERARG_STRING_TYPE;
	inputArgTypes1[1] = USERARG_STRING_TYPE; 
	inputArgTypes1[2] = USERARG_STRING_TYPE; 
	inputArgTypes1[3] = USERARG_STRING_TYPE; 
	inputArgTypes1[4] = USERARG_STRING_TYPE; 
	inputArgTypes1[5] = USERARG_STRING_TYPE; 
	inputArgTypes1[6] = USERARG_STRING_TYPE; 
	inputArgTypes1[7] = USERARG_STRING_TYPE; 
	inputArgTypes1[8] = USERARG_STRING_TYPE; 
	inputArgTypes1[9] = USERARG_STRING_TYPE; 
	inputArgTypes1[10] = USERARG_STRING_TYPE; 
	inputArgTypes1[11] = USERARG_STRING_TYPE; 

	retValueType1 = USERARG_STRING_TYPE ; 
	
	//printf("\n tm_MultiVeiwCompareSapReportinitmodule before....tm_MultiVeiwCompareSapReport_Call");fflush(stdout);
	ifail=USERSERVICE_register_method((char *)"tm_MultiVeiwCompareSapReport_Call",(USER_function_t)tm_MultiVeiwCompareSapReport_Call,nargs1,inputArgTypes1,retValueType1);

	// Ended

	return ifail;	
}

extern DLLAPI int tm_MultiVeiwCompareSapReport_register_callbacks()
{	
	int ifail    = ITK_ok;
	//printf("\n Amar Before registoring userservice....tm_MultiVeiwCompareSapReport");fflush(stdout);   
	ifail=CUSTOM_register_exit ( "tm_MultiVeiwCompareSapReport", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_MultiVeiwCompareSapReportinitmodule);
	//printf("\n Amar After registoring userservice....tm_MultiVeiwCompareSapReport");fflush(stdout);
	return ( ITK_ok );
}
