#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pie/pie.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <bom/bom.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#define MAX_LINE_LEN 1024
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}
#define ITK_errStore 91900002
#include "tm_apl_std_common_function.c"
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*Depricated API BOM_line_ask_attribute_string replaced with  AOM_ask_displayable_values
*Depricated API BOM_line_look_up_attribute replaced with   TCTYPE_ask_property_by_name
*Depricated API BOM_line_set_attribute_string replaced with    AOM_UIF_set_value
*/

{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
;

int  GetCorrectDR( char* FromPlnt ,char*  Part_revStat_Id)
{
	int Flag_dr =0;
	if((tc_strcmp(FromPlnt,"DR0")==0)|| (tc_strcmp(FromPlnt,"AR0")==0))
	{
		 printf("\n 1111AA \n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR1")==0) ||(tc_strcmp(Part_revStat_Id,"DR2")==0)||(tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR1")==0) ||(tc_strcmp(Part_revStat_Id,"AR2")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
			
			printf("\n 1111 \n");fflush(stdout);
			Flag_dr++;
			
		}

	}
	else if((tc_strcmp(FromPlnt,"DR1")==0)|| (tc_strcmp(FromPlnt,"AR1")==0))
	{
		printf("\n 1111AABB \n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR2")==0)||(tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0) ||(tc_strcmp(Part_revStat_Id,"AR2")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
		   
			printf("\n 2222222 \n");fflush(stdout);
			 Flag_dr++;
			

		}

	}
	else if((tc_strcmp(FromPlnt,"DR2")==0)|| (tc_strcmp(FromPlnt,"AR2")==0))
	{
		printf("\n 1111AABBCC \n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR3")==0)||(tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR3")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
			
			printf("\n 33333330 \n");fflush(stdout);
			Flag_dr++;
			

		}

	}
	else if((tc_strcmp(FromPlnt,"DR3")==0)|| (tc_strcmp(FromPlnt,"AR3")==0))
	{
		printf("\n 1111AABBCCDD\n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR3P")==0)||(tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR3P")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
			
			printf("\n 4444 \n");fflush(stdout);
			Flag_dr++;
			

		}

	}
	else if((tc_strcmp(FromPlnt,"DR3P")==0)|| (tc_strcmp(FromPlnt,"AR3P")==0))
	{
		printf("\n 1111AABBCCDDEE\n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR4")==0)||(tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR4")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
			
			printf("\n 66666 \n");fflush(stdout);
			Flag_dr++;
			
		}

	}

	else if((tc_strcmp(FromPlnt,"DR4")==0)|| (tc_strcmp(FromPlnt,"AR4")==0))
	{
		printf("\n 1111AABBCCDDEEFF\n");fflush(stdout);
		if((tc_strcmp(Part_revStat_Id,"DR5")==0)||(tc_strcmp(Part_revStat_Id,"AR5")==0))
		{
			printf("\n 777 \n");fflush(stdout);
			Flag_dr++;
			
		}

	}
	else
	{
		printf("\n 1111AABBCCDDEEFFGG\n");fflush(stdout);
		printf("\n 88888888888888 \n");fflush(stdout);
		

	}
	if(Flag_dr ==1)
	{
		return 1;
	}
	else{
		return 0;
	}
}

void  GetPlant_CR( char *PlantName ,char  getPlantCR[40])
{
	
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	int cntrlcnt=0;
	int  control_number_found1=0;

	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	tag_t   qryTagCntrl1    = NULLTAG;
	int     n_entryCntrl1   = 3;
    char	*PlantCLosRule	= NULL;
	char	* APlPltNm		= NULL;
	int max_char_size = 80;
	APlPltNm = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("Inside getPlantDetailsAttr plant name : %s",PlantName);fflush(stdout);
		
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLLcsInf";
		qry_valuesCntrl1[1]=PlantName;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{
		for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
		{
			
            AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo5", &PlantCLosRule);
			printf("\n PlantCLosRule: %s\n",PlantCLosRule);fflush(stdout);
            
			tc_strcpy(getPlantCR,PlantCLosRule);
			
        }
	}
	else
	{
		
      tc_strcpy(getPlantCR,"BOMViewClosureRuleMBOM");
		
	}
}


void  get_CtrlVal_APLStateInf1( char * Plt_Code ,char  APlRevwLC[40],char  AplWrkngLC[40],char  AplRlzdLC[40],char  StdWrkngLC[40],char  StdRlzdLC[40], char PlantLCFlag[40], char StdPlant[40], char StdRevRule[40], char StdCLosRule[40],char StdView[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *APlRevw 			= NULL;
	 char *AplWrkng			= NULL;
	 char *AplRlzd			= NULL;
	 char *StdWrkng			= NULL;
	 char *StdRlzd			= NULL;
	 char *Plant			= NULL;
	 char *stdCode			= NULL;
	 char *RevRule		= NULL;
	 char *stdClsRule		= NULL;
	 char *stdBvr			= NULL;
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("\n Plt_Code:%s",Plt_Code);fflush(stdout);
	PlantOneChar=subString(Plt_Code,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(viewtocpy,"");
	tc_strcat(viewtocpy,"STD");
	tc_strcat(viewtocpy,PlantOneChar);
	tc_strcat(viewtocpy," View");
	printf("\n View to copy:%s",viewtocpy);fflush(stdout);
	 

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=Plt_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &APlRevw);
				printf("\n APlRevw: %s\n",APlRevw);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &AplWrkng);
				printf("\n AplWrkng: %s\n",AplWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &AplRlzd);
				printf("\n AplRlzd: %s\n",AplRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &StdWrkng);
				printf("\n StdWrkng: %s\n",StdWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &StdRlzd);
				printf("\n StdRlzd: %s\n",StdRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &Plant);
				printf("\n Plant: %s\n",Plant);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &stdCode);
				printf("\n stdCode: %s\n",stdCode);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &stdClsRule);
				printf("\n stdClsRule: %s\n",stdClsRule);fflush(stdout);

							
				if(tc_strlen(APlRevw)>0) 
				{ 
					tc_strcpy(APlRevwLC,APlRevw);
				}
				if(tc_strlen(AplWrkng)>0) 
				{ 
					tc_strcpy(AplWrkngLC,AplWrkng);
				}
				if(tc_strlen(AplRlzd)>0) 				
				{
					tc_strcpy(AplRlzdLC,AplRlzd);
				}
				if(tc_strlen(StdWrkng)>0) 
				{
					tc_strcpy(StdWrkngLC,StdWrkng);
				}
				if(tc_strlen(StdRlzd)>0) 
				{
					tc_strcpy(StdRlzdLC,StdRlzd);
				}
				if(tc_strlen(Plant)>0) 
				{
					tc_strcpy(PlantLCFlag,Plant);
				}
				if(tc_strlen(stdCode)>0) 
				{
					tc_strcpy(StdPlant,stdCode);
				}
				if(tc_strlen(RevRule)>0) 
				{
					tc_strcpy(StdRevRule,RevRule);
				}
				if(tc_strlen(stdClsRule)>0) 
				{
					tc_strcpy(StdCLosRule,stdClsRule);
				}
				if(tc_strlen(viewtocpy)>0) 
				{
					tc_strcpy(StdView,viewtocpy);
				}
			}
			else
			{
				tc_strcpy(APlRevwLC,"T5_LcsAplReview");
				tc_strcpy(AplWrkngLC,"T5_LcsAPLWrkg");
				tc_strcpy(AplRlzdLC,"T5_LcsAplRlzd");
				tc_strcpy(StdWrkngLC,"T5_LcsSTDWrkg");
				tc_strcpy(StdRlzdLC,"T5_LcsStdRlzd");		
				tc_strcpy(PlantLCFlag,"CAR");
				tc_strcpy(StdPlant,"STDC");
				tc_strcpy(StdRevRule,"APLC Release and above");
				tc_strcpy(StdCLosRule,"BOMViewClosureRuleSTDC");
				tc_strcpy(StdView,viewtocpy);
			}
}


void getDMLUserGroup(char	*sPlantName, char	*sUserGroup)
{

	printf("\nInside getDMLUserGroup");fflush(stdout);
	printf("\nDML Plant name : %s",sPlantName);fflush(stdout);
	sUserGroup	=	(char	*)MEM_alloc(tc_strlen(sPlantName)+10);
	if (tc_strcmp(sPlantName,"APLC")==0)
	{
		tc_strcpy(sUserGroup,"APLCAR");
	}
	else if(tc_strcmp(sPlantName,"APLP")==0)
	{
		tc_strcpy(sUserGroup,"APLPUNE");
	}
	else if (tc_strcmp(sPlantName,"APLJ")==0)
	{
		tc_strcpy(sUserGroup,"APLJSR");
	}
	else if (tc_strcmp(sPlantName,"APLL")==0)
	{
		tc_strcpy(sUserGroup,"APLLKO");
	}
	else if (tc_strcmp(sPlantName,"APLV")==0)
	{
		tc_strcpy(sUserGroup,"APLUV");
	}
	else if (tc_strcmp(sPlantName,"APLA")==0)
	{
		tc_strcpy(sUserGroup,"APLAHD");
	}
	else if (tc_strcmp(sPlantName,"APLD")==0)
	{
		tc_strcpy(sUserGroup,"APLDWD");
	}
	else if (tc_strcmp(sPlantName,"APLU")==0)
	{
		tc_strcpy(sUserGroup,"APLUTK");
	}
	else
	{
		tc_strcpy(sUserGroup,"APLCAR");
	}

	printf("\nUser Group : %s",sUserGroup);fflush(stdout);
}


void  get_CtrlVal_APLLcsInf3( char * Tsk_Own_Grp ,char  RevRuleInfo1[40],char  BVRInfo2[40],char  CurMskInfo3[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevRule 			= NULL;
	 char *viewfrmCtrl		= NULL;
	 char *CurVwMask		= NULL;

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLLcsInf";
				qry_valuesCntrl1[1]=Tsk_Own_Grp;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &viewfrmCtrl);
				printf("\n viewfrmCtrl: %s\n",viewfrmCtrl);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &CurVwMask);
				printf("\n CurVwMask: %s\n",CurVwMask);fflush(stdout);

				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(BVRInfo2,viewfrmCtrl);
				tc_strcpy(CurMskInfo3,CurVwMask);
					
			}
			else
			{
				tc_strcpy(RevRuleInfo1,"ERC release and above");
				tc_strcpy(BVRInfo2,"View");
				tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskC");
			}
}

int CreateRelFun(tag_t objTag, char* Toplnt, char*  PrtDRst,tag_t rev_tag)
{
	int		ifail 		= ITK_ok;
	int		CreatAllow = 0;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	Ref_Rel	= NULLTAG;
	tag_t relation= NULLTAG;
	tag_t relation1= NULLTAG;
	tag_t pfolder_tag= NULLTAG;
	tag_t item_type_tag	= NULLTAG;
	tag_t item_type_tag1 = NULLTAG;
	tag_t FL_create_input_tag= NULLTAG;
	tag_t FL_co_input_tag= NULLTAG;
	tag_t projTag= NULLTAG;
	tag_t GrpTag= NULLTAG;
	tag_t item_tag1	= NULLTAG;
	tag_t *itemRev_tag1=NULLTAG;

	char			* DsgGrp						= NULL;

	char			* projectCode						= NULL;
	char			* GrpMembName						= NULL;
	char			* DRnewRev						= NULL;
	char			* DRnew						= NULL;
	char			* clrell_status						= NULL;
	char			* dmlNo						= NULL;
	char			* dNo						= NULL;
	char			* TaskNo						= NULL;
	char			* PartN						= NULL;
	char			* Ipart						= NULL;
	char			* Fld_Des						= NULL;
	int i,number_found,number_found1,fldEmpty=0,check=0;
	int	AccesFound=0,FlCreated=0,count,count1;
	WSO_search_criteria_t  	criteria;
	tag_t *list_of_WSO_tags=NULLTAG;

	int	jkl=0;
	int	addToCarryOver=0;
	int	jk=0;
	int	Itm_found=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	tag_t	*Itm_tagS = NULLTAG;
	tag_t	part_tg		= NULLTAG;
	char   UserAccess[1000];
	char   UserAccess2[1000];

	if (objTag==NULLTAG || tc_strcmp(Toplnt,"")==0 ||tc_strlen(Toplnt)==0|| Toplnt==NULL || rev_tag==NULLTAG)
	{
		printf("\n Input arguments are NULL or Blank for CreateRelFun");fflush(stdout);
		return 0;
	}

	printf("\n Inside CreateRelFun: Toplnt:%s PrtDRst:%s", Toplnt,PrtDRst);fflush(stdout);

	printf("\n RelFun: Toplnt:%s PrtDRst:%s", Toplnt,PrtDRst);fflush(stdout);
	if((tc_strcmp(PrtDRst,"")==0) || (tc_strcmp(PrtDRst,"NA")==0))
	{
		CreatAllow=1;
		printf("NAcase:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR5")==0)|| (tc_strcmp(Toplnt,"AR5")==0)) && ((tc_strcmp(PrtDRst,"DR4")==0)|| (tc_strcmp(PrtDRst,"AR4")==0)))
	{
		CreatAllow=1;
		printf("R5:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtDRst,"DR3")==0)|| (tc_strcmp(PrtDRst,"AR3")==0)))
	{
		CreatAllow=1;
		printf("R4:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtDRst,"DR3P")==0)|| (tc_strcmp(PrtDRst,"AR3P")==0)))
	{
		CreatAllow=1;
		printf("R4P:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(PrtDRst,"DR2")==0)|| (tc_strcmp(PrtDRst,"AR2")==0)))
	{
		CreatAllow=1;
		printf("R3:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(PrtDRst,"DR3")==0)|| (tc_strcmp(PrtDRst,"AR3")==0)))
	{
		CreatAllow=1;
		printf("R3P:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)))
	{
		CreatAllow=1;
		printf("R2:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else if(((tc_strcmp(Toplnt,"DR1")==0)|| (tc_strcmp(Toplnt,"AR1")==0)) && ((tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=1;
		printf("R1:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	if (CreatAllow >0)
	{
		printf("R1:Flag herere ");fflush(stdout);
		//create relation with task.
		
		ITKCALL( GRM_find_relation_type("CMReferences", &tsk_CMRef_type));
		if (tsk_CMRef_type!=NULLTAG)
		{
			printf("\n relation lock");fflush(stdout);
			
			if ((rev_tag!=NULLTAG) || (objTag!=NULLTAG) )
			{
					//folder description
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
					
					if (tsk_dml_rel_type!=NULLTAG)
					{
						
						ITKCALL(GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision));
						ITKCALL(AOM_UIF_ask_value(DMLRevision[0],"item_id",&dmlNo));
						ITKCALL( AOM_UIF_ask_value(rev_tag,"item_id",&dNo))
						printf("\n DML number and Part Number %s : %s",dmlNo,dNo);fflush(stdout);
					}
					else
					{
						printf("relation is not found for task and dml");fflush(stdout);
					}
					char *Fld_Des=NULL;
					Fld_Des=(char *) MEM_alloc(50);
					
					char *Fld_Des_tsk=NULL;
					Fld_Des_tsk=(char *) MEM_alloc(50);
					
					ITKCALL(AOM_UIF_ask_value(objTag,"item_id",&TaskNo));fflush(stdout);
					tc_strcpy(Fld_Des_tsk,"");
					tc_strcat(Fld_Des_tsk,"Task-");
					tc_strcat(Fld_Des_tsk,TaskNo);
					printf("\n folderTASK description %s",Fld_Des_tsk);fflush(stdout);

					
					//tc_strcpy(Fld_Des,"");
					//tc_strcat(Fld_Des,"DML-");
					//tc_strcat(Fld_Des,dmlNo);

					//printf("\n folder description %s",Fld_Des);
					//folder description

				
						//adding parts in 'Parts For Gate Maturation' folder
						
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.name,"Parts For Gate Maturation");
						strcpy(criteria.desc,Fld_Des_tsk);
						ITKCALL(WSOM_search(criteria, &number_found, &list_of_WSO_tags));
						printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

						if (number_found>0)
						{
							i=i++;
							ITKCALL(AOM_UIF_ask_value(rev_tag,"item_id",&PartN));
							printf("\n PartN folder insert %s",PartN);fflush(stdout);
							ITKCALL(AOM_lock(list_of_WSO_tags[0]));
							ITKCALL(FL_insert(list_of_WSO_tags[0],rev_tag,i));
							//API Change
							//ITKCALL(AOM_save(list_of_WSO_tags[0]));
							ITKCALL(AOM_save_without_extensions(list_of_WSO_tags[0]));
							ITKCALL(AOM_unlock(list_of_WSO_tags[0]));
							ITKCALL(AOM_refresh(list_of_WSO_tags[0],TRUE));
						}
						else
						{
							printf("\n folder description111111 %s",Fld_Des_tsk);

							//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

							ITKCALL(TCTYPE_find_type("Folder", "", &item_type_tag))
							ITKCALL(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag))
							ITKCALL(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation"));
							ITKCALL(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk));
							ITKCALL(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag));

							if (pfolder_tag!=NULLTAG)
							{
								printf("\n inside folder Parts For Gate Maturation to save");fflush(stdout);
								 ITKCALL(GRM_find_relation_type("CMReferences", &Ref_Rel));
								 //API change
								 //ITKCALL(AOM_save(pfolder_tag));
								 ITKCALL(AOM_save_without_extensions(pfolder_tag));
								 ITKCALL(AOM_refresh(pfolder_tag,TRUE));
								 ITKCALL(AOM_lock(objTag));
								if (Ref_Rel!=NULLTAG)
								{
									ITKCALL(GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1));
									printf("\n folder save");fflush(stdout);
									if (relation1!=NULLTAG)
									{
										printf("\n Relation save");fflush(stdout);
										ITKCALL(AOM_refresh(relation1,TRUE));
										ITKCALL( GRM_save_relation(relation1));
										ITKCALL (AOM_unlock(objTag));
										printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
										printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
									}
								}
							}
							
								//printf("\n folder tag not found");
								i=i++;
								printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
								ITKCALL(AOM_UIF_ask_value(rev_tag,"item_id",&PartN));
								printf("\n PartN folder PFG  %s",PartN);fflush(stdout);
								ITKCALL(AOM_lock(pfolder_tag));
								ITKCALL(FL_insert(pfolder_tag,rev_tag,i));
								//API change
								//ITKCALL(AOM_save(pfolder_tag));
								ITKCALL(AOM_save_without_extensions(pfolder_tag));
								ITKCALL(AOM_unlock(pfolder_tag));
								ITKCALL(AOM_refresh(pfolder_tag,TRUE));
						}
					
			}
				

		}
		else
		{
			printf("\n tag not found");fflush(stdout);

		}
			
	}
	

	return 0;
}

int tm_GateMaturaion(tag_t tTaskTag, char	*cPlantName)
{
	int		ifail 				=	ITK_ok;
	int		dmlcount			=	0;
	int		DR_rsltCount		=	0;
	int		CMRefcount			=	0;
	int		Mstr				=	0;
	int		num_found			=	0;
	int		idml				=	0;
	int		iChildItemTag		=	0;		
	int		itsk				=	0;
	int		iadml				=	0;
	int		GMDMLFound			=	0;
	int     DR_n_entry			=	1;

	char	*ObjTyp				=	NULL;
	char	*class_name1		=	NULL;
	char	*DMLtype			=	NULL;
	char	*DMLECNtype			=	NULL;
	char	*DMLProj			=	NULL;
	char	*PlntToPlnt			=	NULL;
	char	*PlntToPlnt1		=	NULL;
	char	*FromPlnt			=	NULL;
	char	*ToPlnt				=	NULL;
	char	*TskNm				=	NULL;
	char	*LiveProjInfo		=	NULL;
	char	*PartMstr_no		=	NULL;
	char	*sUserGroup			=	NULL;
	char	*AMDMLtype			=	NULL;
	char	*ItemRevOwnGrp		=	NULL;
	char	*ItemRevDRStatus	=	NULL;

	char	*ItemType			=	NULL;
	char	*ItemName			=	NULL;
	char	*ItemRev			=	NULL;
	
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	logical is_latest;

	tag_t	tsk_dml_rel_type	=	NULLTAG;		
	tag_t	Part_tag			=	NULLTAG;		
	tag_t	*DMLRevision		=	NULLTAG;
	tag_t	class_id1			=	NULLTAG;	
	tag_t   DRqryTag			=	NULLTAG;
	tag_t	*DRCntrlObjectTag	=	NULLTAG;
	tag_t	tsk_CMRef_type		=	NULLTAG;
	tag_t	tsk_Rel_type		=	NULLTAG;
	tag_t	Part_lrev_tag		=	NULLTAG;
	tag_t	*TaskCMRef			=	NULLTAG;
	tag_t	AssyMstrtag			=	NULLTAG;
	tag_t	tag_query			=	NULLTAG;
	tag_t	DMLRevTag			=	NULLTAG;
	tag_t	*itemclass1			=	NULLTAG;
	tag_t	objChild_BVR		=	NULLTAG;
	tag_t	t_ChildItemRev_BS	=	NULLTAG;
	tag_t	t_apldml			=	NULLTAG;
	tag_t	relation			=	NULLTAG;
	tag_t	AssyRev			=	NULLTAG;



	char *Part_rev_Id			=	NULL;
	char *Part_revItm_Id			=	NULL;
	char *Part_revStat_Id				=	NULL;
	int   Flag_dr =0;

	char AplRvwLC[40];
	char AplWrkngLC[40];
	char AplRlzd[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char RevRuleInfo1[40];
	char BVRInfo2[40];
	char Info3[40];
	char closureRuleName[40];

	printf("\nInside tm_GateMaturaion");fflush(stdout);
	printf("\nAPL GM DML Plant NAME : %s",cPlantName);fflush(stdout);
	get_CtrlVal_APLStateInf1(cPlantName,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);
	
	if(AOM_ask_value_string(tTaskTag,"object_type",&ObjTyp)!=ITK_ok)PrintErrorStack();
	printf("\nObject typee : %s",ObjTyp);fflush(stdout);
	if(tc_strcmp(ObjTyp,"T5_APLTaskRevision")==0 || tc_strcmp(ObjTyp,"T5_MBOMTASKRevision")==0)
	{
		printf("\n 11111 ");fflush(stdout);
		GetPlant_CR(cPlantName ,closureRuleName);
		
		printf("\nAPL GM DML Revsion closureRuleName : %s",closureRuleName);fflush(stdout);

		ITKCALL(AOM_UIF_ask_value(tTaskTag,"owning_group",&sUserGroup));
		printf("\n  taskowning_groupVal:%s ..............",sUserGroup);fflush(stdout);
		//get_CtrlVal_APLLcsInf3(sUserGroup,RevRuleInfo1,BVRInfo2,Info3);
		get_CtrlVal_APLLcsInf(sUserGroup, RevRuleInfo1, BVRInfo2, Info3); //sanket
		

		printf("\nAPL GM DML Revsion Rule : %s",RevRuleInfo1);fflush(stdout);
		printf("\nAPL GM DML Revsion BVRInfo2 : %s",BVRInfo2);fflush(stdout);
		printf("\nAPL GM DML Revsion Info3 : %s",Info3);fflush(stdout);
		

		if (GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
		if (tsk_dml_rel_type!=NULLTAG)
		{
			if (GRM_list_primary_objects_only(tTaskTag,tsk_dml_rel_type,&dmlcount,&DMLRevision)!=ITK_ok)PrintErrorStack();
			printf("\n APL GM: DML Revision from Task: %d.",dmlcount);fflush(stdout);
			if (dmlcount>0)
			{
				for (idml=0;idml<dmlcount ;idml++ )
				{
//					if (ITEM_rev_sequence_is_latest(DMLRevision[idml],&is_latest)!=ITK_ok)PrintErrorStack();
//					if(is_latest != true)
//					{
//						printf("\nAPL GM: is_latest is not true.");fflush(stdout);
//					}
//					else
//					{	
						DMLtype		=	NULL;
						DMLECNtype	=	NULL;
						DMLProj		=	NULL;
						PlntToPlnt	=	NULL;
						PlntToPlnt1	=	NULL;
						DMLRevTag = DMLRevision[idml];
						ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
						ITKCALL(POM_name_of_class(class_id1,&class_name1));
						printf("\n GM: class_name found1 MR :%s.",class_name1);fflush(stdout);
						if(tc_strcmp(ObjTyp,"T5_APLTaskRevision")==0)
						{	
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_EcnType",&DMLtype));
						}

						if(tc_strcmp(ObjTyp,"T5_MBOMTASKRevision")==0)
						{	
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_MBOMRlzType",&DMLtype));
						}

						ITKCALL( AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLECNtype));
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLProj));
						ITKCALL(AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&PlntToPlnt));
						ITKCALL(AOM_UIF_ask_value(DMLRevTag,"t5_PlntToPlnt",&PlntToPlnt1));
						printf("\n GM: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s].[%s]",DMLtype,DMLProj,PlntToPlnt,PlntToPlnt1);fflush(stdout);

						if(tc_strcmp(DMLtype,"TODRAPL")==0 || tc_strcmp(DMLtype,"GM_MMDML")==0)
						{
							if(PlntToPlnt!=NULL)
							{
								char	*TaskDsgGrp	=	NULL;
								FromPlnt=subString(PlntToPlnt, 0, 3);
								if (tc_strstr(PlntToPlnt,"3P")!=NULL)
								{
									ToPlnt=subString(PlntToPlnt, 7, 4);
								}
								else
								{
									ToPlnt=subString(PlntToPlnt, 7, 3);
								}
								ITKCALL( AOM_UIF_ask_value(tTaskTag,"item_id",&TskNm));//Task Number
								TaskDsgGrp=subString(TskNm,11,2);
								printf("\n GM: Task: [%s] TaskDsgGrp:[%s] FromDR:[%s] ToDR:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,ToPlnt);fflush(stdout);

									ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &tsk_CMRef_type));
									if (tsk_CMRef_type!=NULLTAG)
									{
										ITKCALL(GRM_list_secondary_objects_only(tTaskTag,tsk_CMRef_type,&CMRefcount,&TaskCMRef));
										printf("\n APL GM DML: Task CMRefcount: %d",CMRefcount);fflush(stdout);
										if(CMRefcount > 0)
										{
											
											for(Mstr=0;Mstr<CMRefcount;Mstr++)
											{
												tag_t objTypeTag2=NULLTAG;
												//char   type_name2[TCTYPE_name_size_c+1];
												char   *type_name2 = NULL;
												printf("\n GM:Design Mstr:%d",Mstr);fflush(stdout);
												AssyMstrtag=TaskCMRef[Mstr];
												ITKCALL(AOM_ask_value_string(AssyMstrtag,"item_id",&PartMstr_no));
												ITKCALL(TCTYPE_ask_object_type(AssyMstrtag,&objTypeTag2));
												//API change
												ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
												printf("\n GM:Part Mstr_no:%s",type_name2);fflush(stdout);
												printf("\n GM:Part no:%s",PartMstr_no);fflush(stdout);

												//Find the latest APLC Released part
												//ITKCALL(QRY_find2("Driver VC Query",&tag_query));
												//printf("Searching...\n");fflush(stdout);
												//int		n_entries		=	2;
												//char	*entries[2]		=	{"Item ID","Release Status"};
												//char	**values		=	(char **) MEM_alloc(10 * sizeof(char *));
												//char	*DriverVCLCS	=	NULL;
												//char	*DriverVC		=	NULL;

												//DriverVC	=	(char *)MEM_alloc(tc_strlen(PartMstr_no)+50);
												//tc_strcpy(DriverVC,PartMstr_no);

												//DriverVCLCS	=	(char *)MEM_alloc(tc_strlen(AplRlzd)+50);
												//tc_strcpy(DriverVCLCS,AplRlzd);
												//printf("\nDrive VC LCS : %s",DriverVCLCS);fflush(stdout);
												//printf("nArgument passed in is: %s...\n",DriverVC);fflush(stdout);
												
												//num_found	=	0;
												//itemclass1	=	NULLTAG;

												//values[0]=DriverVC;
												//values[1]=DriverVCLCS;

												//if(QRY_execute(tag_query,n_entries, entries, values,&num_found,&itemclass1))	PrintErrorStack();
												//printf("\nNo of Part Found : %d",num_found);fflush(stdout);

												
												//if(num_found>0)
											//{
													printf("\nEXP APL GM DML Revsion Rule : %s",RevRuleInfo1);fflush(stdout);
													printf("\nEXP APL GM DML Revsion BVRInfo2 : %s",BVRInfo2);fflush(stdout);
													printf("\nEXP APL GM DML Revsion Info3 : %s",Info3);fflush(stdout);

													AssyRev		=	NULLTAG;
													//AssyRev				=	itemclass1[0];
													
													//Explode the BOM
													int	childBS = 0;
													int	Prt = 0;
													int	StructCntBdyShProdPlan	= 0;
													struct			BomChldStrut	ChldStrutBdySh[5000];
													//Priyanka Change//
													//ITKCALL( ITEM_find_item( PartMstr_no, &AssyMstrtag ));
													//ITKCALL(ITEM_ask_latest_rev(AssyMstrtag,&AssyRev)) ;
													//ITKCALL(Get_Part_BOM_Lvl(AssyRev,99,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
													ITKCALL(Get_Part_BOM_Lvl(AssyMstrtag,99,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
													printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);
													if(StructCntBdyShProdPlan>0)
													{
														for(childBS = 1;childBS <= StructCntBdyShProdPlan; childBS++)
													{
															ItemType			=	NULL;
															ItemName			=	NULL;
															ItemRev				=	NULL;
															ItemRevOwnGrp		=	NULL;
															GMDMLFound			=	0;
	
															objChild_BVR		=	NULLTAG;
															t_ChildItemRev_BS	=	NULLTAG;
															iChildItemTag		=	0;
															int ii =0;
															
															int Item_count =0;
															tag_t	*rev_list				= NULL;
	
	
															objChild_BVR=ChldStrutBdySh[childBS].child_objs_bvr;
															t_ChildItemRev_BS=ChldStrutBdySh[childBS].child_objs;
	
															ITKCALL(AOM_ask_value_string(objChild_BVR,"bl_item_owning_group",&ItemRevOwnGrp));
															printf("\n child ItemRevOwnGrp:%s ..............",ItemRevOwnGrp);fflush(stdout);

															ITKCALL(AOM_ask_value_string(t_ChildItemRev_BS,"item_id",&ItemName));
															printf("\n child ItemName123:%s ..............",ItemName);fflush(stdout);

	
															

														if (((tc_strstr(ItemRevOwnGrp,"APL")!=NULL && tc_strstr(BVRInfo2,"APL")!=NULL)) || ((tc_strstr(ItemRevOwnGrp,"MBOM")!=NULL && tc_strstr(BVRInfo2,"MBOM")!=NULL)))
														{
															Part_tag			=	NULLTAG;
															ITKCALL(AOM_ask_value_string(t_ChildItemRev_BS,"item_id",&ItemName));
															printf("\n child ItemName:%s ..............",ItemName);fflush(stdout);

															ITKCALL( ITEM_find_item( ItemName, &Part_tag ));

															ITKCALL(ITEM_list_all_revs (Part_tag, &Item_count, &rev_list));
															printf("\n Total rev found: %d.", Item_count);fflush(stdout);
															if(Item_count > 0)
															{
																Flag_dr =0;
																
																for(ii=Item_count-1;ii>=0;ii--)
																{
																	Part_rev_Id			=	NULL;
																	Part_revItm_Id			=	NULL;
																	Part_revStat_Id				=	NULL;
																	
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"item_id",&Part_revItm_Id));
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&Part_revStat_Id));
																	 printf("\n child ItemRevDRStatus:%s,%s %s ..............",Part_rev_Id,Part_revItm_Id,Part_revStat_Id);fflush(stdout);
																	 Flag_dr =  GetCorrectDR(FromPlnt ,Part_revStat_Id);
																	 printf("\nFlag_dr 9999  %d\n",Flag_dr); fflush(stdout);
																	 if(Flag_dr == 0)
																	{
																		 printf("\nFlag_dr IF"); fflush(stdout);
																		 continue;
																	}else{
																		printf("\nFlag_dr ELSE"); fflush(stdout);
																		break;
																	}

																}

																if(Flag_dr == 0)
																{

																	printf("\n[%s] having part type [%s] and owing group [%s]",ItemName,ItemType,ItemRevOwnGrp);fflush(stdout);
																	printf("\n Going to create Relation ");fflush(stdout);
																	//ITKCALL(ITEM_ask_latest_rev(Part_tag,&Part_lrev_tag)) ;
																	//printf("\n Latest part for attachment ");fflush(stdout);
																	tsk_Rel_type= NULLTAG;

																	
																	//ITKCALL(GRM_find_relation_type("CMReferences", &tsk_Rel_type));
																	  ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &tsk_Rel_type));
																	if (tsk_Rel_type!=NULLTAG)
																	{
																			printf("\n tsk_Rel_type is not NULLTAG");fflush(stdout);
																			ITKCALL(AOM_ask_value_string(tTaskTag,"item_revision_id",&Part_rev_Id));
																			ITKCALL(AOM_ask_value_string(tTaskTag,"item_id",&Part_revItm_Id));
																			printf("\n 111..Part_rev_Id  is :%s\n",Part_rev_Id);fflush(stdout);
																			printf("\n 111..Part_revItm_Id is :%s\n",Part_revItm_Id);fflush(stdout);
																			//ITKCALL(GRM_create_relation(tTaskTag,Part_lrev_tag,tsk_Rel_type,NULLTAG, &relation));
																			//venkat create folder for parts for gate maturation
																			int CreateRelFunflag =0 ;
																			CreateRelFunflag=CreateRelFun( tTaskTag,ToPlnt,Part_revStat_Id,t_ChildItemRev_BS);
																			if (CreateRelFunflag = 0)
																			{
																				printf("\n Relation created successfully");fflush(stdout);

																			}
																	}
																						
																

															 }

														}
													}


													}
												}
											}
										}

									}
									else
									{
										printf("\n APL GM DML Solutions relation not found...");fflush(stdout);
									}
									//venkat CMReferences
									ITKCALL(GRM_find_relation_type("CMReferences", &tsk_CMRef_type));
									if (tsk_CMRef_type!=NULLTAG)
									{
										ITKCALL(GRM_list_secondary_objects_only(tTaskTag,tsk_CMRef_type,&CMRefcount,&TaskCMRef));
										printf("\n APL GM DML: Task CMRefcount: %d",CMRefcount);fflush(stdout);
										if(CMRefcount > 0)
										{
											
											for(Mstr=0;Mstr<CMRefcount;Mstr++)
											{
												tag_t objTypeTag2=NULLTAG;
												//char   type_name2[TCTYPE_name_size_c+1];
												//API change
												char   *type_name2 = NULL;
												printf("\n GM:Design Mstr:%d",Mstr);fflush(stdout);
												AssyMstrtag=TaskCMRef[Mstr];
												ITKCALL(AOM_ask_value_string(AssyMstrtag,"item_id",&PartMstr_no));
												ITKCALL(TCTYPE_ask_object_type(AssyMstrtag,&objTypeTag2));
												ITKCALL(TCTYPE_ask_name2(objTypeTag2,&type_name2));
												printf("\n GM:Part Mstr_no:%s",type_name2);fflush(stdout);
												printf("\n GM:Part no:%s",PartMstr_no);fflush(stdout);

												
													printf("\nEXP APL GM DML Revsion Rule : %s",RevRuleInfo1);fflush(stdout);
													printf("\nEXP APL GM DML Revsion BVRInfo2 : %s",BVRInfo2);fflush(stdout);
													printf("\nEXP APL GM DML Revsion Info3 : %s",Info3);fflush(stdout);

													AssyRev		=	NULLTAG;
													
													int	childBS = 0;
													int	Prt = 0;
													int	StructCntBdyShProdPlan	= 0;
													struct			BomChldStrut	ChldStrutBdySh[5000];
													
													ITKCALL(Get_Part_BOM_Lvl(AssyMstrtag,99,closureRuleName,RevRuleInfo1,BVRInfo2,ChldStrutBdySh,&StructCntBdyShProdPlan));
													printf("\n\t\t StructCntBdyShProdPlan:%d",StructCntBdyShProdPlan);fflush(stdout);
													if(StructCntBdyShProdPlan>0)
													{
														for(childBS = 1;childBS <= StructCntBdyShProdPlan; childBS++)
													{
															ItemType			=	NULL;
															ItemName			=	NULL;
															ItemRev				=	NULL;
															ItemRevOwnGrp		=	NULL;
															GMDMLFound			=	0;
	
															objChild_BVR		=	NULLTAG;
															t_ChildItemRev_BS	=	NULLTAG;
															iChildItemTag		=	0;
															int ii =0;
															
															int Item_count =0;
															tag_t	*rev_list				= NULL;
	
	
															objChild_BVR=ChldStrutBdySh[childBS].child_objs_bvr;
															t_ChildItemRev_BS=ChldStrutBdySh[childBS].child_objs;
	
															ITKCALL(AOM_ask_value_string(objChild_BVR,"bl_item_owning_group",&ItemRevOwnGrp));
															printf("\n child ItemRevOwnGrp:%s ..............",ItemRevOwnGrp);fflush(stdout);

															ITKCALL(AOM_ask_value_string(t_ChildItemRev_BS,"item_id",&ItemName));
															printf("\n child ItemName:%s ..............",ItemName);fflush(stdout);

	
															

														if (((tc_strstr(ItemRevOwnGrp,"APL")!=NULL && tc_strstr(BVRInfo2,"APL")!=NULL)) || ((tc_strstr(ItemRevOwnGrp,"MBOM")!=NULL && tc_strstr(BVRInfo2,"MBOM")!=NULL)))//MBOM
														{
															Part_tag			=	NULLTAG;
															ITKCALL(AOM_ask_value_string(t_ChildItemRev_BS,"item_id",&ItemName));
															printf("\n child ItemName:%s ..............",ItemName);fflush(stdout);

															ITKCALL( ITEM_find_item( ItemName, &Part_tag ));

															ITKCALL(ITEM_list_all_revs (Part_tag, &Item_count, &rev_list));
															printf("\n Total rev found: %d.", Item_count);fflush(stdout);
															if(Item_count > 0)
															{
																Flag_dr =0;
																
																for(ii=Item_count-1;ii>=0;ii--)
																{
																	Part_rev_Id			=	NULL;
																	Part_revItm_Id			=	NULL;
																	Part_revStat_Id				=	NULL;
																	
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"item_id",&Part_revItm_Id));
																	 ITKCALL(AOM_ask_value_string(rev_list[ii],"t5_PartStatus",&Part_revStat_Id));
																	 printf("\n child ItemRevDRStatus:%s,%s %s ..............",Part_rev_Id,Part_revItm_Id,Part_revStat_Id);fflush(stdout);
																	 Flag_dr =  GetCorrectDR(FromPlnt ,Part_revStat_Id);
																	 printf("\nFlag_dr 9999  %d\n",Flag_dr); fflush(stdout);
																	 if(Flag_dr == 0)
																	{
																		 printf("\nFlag_dr IF"); fflush(stdout);
																		 continue;
																	}else{
																		printf("\nFlag_dr ELSE"); fflush(stdout);
																		break;
																	}

																}

																if(Flag_dr == 0)
																{

																	printf("\n[%s] having part type [%s] and owing group [%s]",ItemName,ItemType,ItemRevOwnGrp);fflush(stdout);
																	printf("\n Going to create Relation ");fflush(stdout);
																	

																	ITKCALL(GRM_find_relation_type("CMReferences", &tsk_Rel_type));
																	//ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &tsk_Rel_type));
																	if (tsk_Rel_type!=NULLTAG)
																	{
																			printf("\n tsk_Rel_type is not NULLTAG");fflush(stdout);
																			ITKCALL(AOM_ask_value_string(tTaskTag,"item_revision_id",&Part_rev_Id));
																			ITKCALL(AOM_ask_value_string(tTaskTag,"item_id",&Part_revItm_Id));
																			printf("\n 111..Part_rev_Id  is :%s\n",Part_rev_Id);fflush(stdout);
																			printf("\n 111..Part_revItm_Id is :%s\n",Part_revItm_Id);fflush(stdout);
																			//ITKCALL(GRM_create_relation(tTaskTag,Part_lrev_tag,tsk_Rel_type,NULLTAG, &relation));
																			//venkat create folder for parts for gate maturation
																			int CreateRelFunflag =0 ;
																			CreateRelFunflag=CreateRelFun( tTaskTag,ToPlnt,Part_revStat_Id,t_ChildItemRev_BS);
																			if (CreateRelFunflag = 0)
																			{
																				printf("\n Relation created successfully");fflush(stdout);

																			}
																	}

																	
																						
																	
																 }

														}
													}


													}
												}
											}
										}

									}
									else
									{
										printf("\n APL GM DML cmreference relation not found...");fflush(stdout);
									}




									///////
								
							}
							else
							{
								printf("\n GM: t5_PlntToPlnt is null.");fflush(stdout);
							}
						}
						else
						{
							printf("\n GM: Other than GM DML.");fflush(stdout);
					}
//												printf("\n updation ");fflush(stdout);
//												ITKCALL(AOM_lock(DMLRevTag));
//												
//												if(tc_strcmp(ObjTyp,"T5_APLTaskRevision")==0)
//												{
//												ITKCALL(AOM_UIF_set_value(DMLRevTag,"t5_OptFlg","1"));
//												}
//												if(tc_strcmp(ObjTyp,"T5_MBOMTASKRevision")==0)
//												{
//												ITKCALL(AOM_UIF_set_value(DMLRevTag,"t5_mbomOptFlg","1"));
//												}
//												printf("\n GM:Part no33333:%s",ToPlnt);fflush(stdout);
//												ITKCALL( AOM_save(DMLRevTag) );
//												printf("\n GM:Part no33333090:%s",ToPlnt);fflush(stdout);
//												ITKCALL( AOM_unlock(DMLRevTag) );
//												printf("\n Value set:%s",ToPlnt);fflush(stdout);
					//
				}
			}
			else
			{
				printf("\nNo DML tag found....");fflush(stdout);
			}
		}
		else
		{
			printf("\nT5_DMLTaskRelation relation is not found...");fflush(stdout);
		}
	}
	else
	{
		printf("\nObject type is not APL Task Revision...");fflush(stdout);
	}

	return ifail;
}




/*******************************4.*******************************************/
//extern int APLGMDMLserviceCalling(char  *AplRevw,char *TotalRowSelc,char *itemId,char *Rev,void *retValue)
extern int APLGMDMLserviceCalling(void *retValue)
 {
	 	
	tag_t  CntrlTag		= NULLTAG;
	tag_t  query1 = NULLTAG;
  	tag_t *CntrlObjs	= NULLTAG;
	tag_t	TbNopart_tg	= NULLTAG;
	tag_t	TbNopart_tag	= NULLTAG;
	tag_t  *occs					=	NULLTAG;
	tag_t	*bvrs					=	NULLTAG;
	tag_t	*bvrs1					=	NULLTAG;
	tag_t *occs_clr = NULLTAG;
	tag_t *bvrTag = NULLTAG;
		tag_t			bvr_tag= NULLTAG;

	char	    *AplRevw				=NULL;
	char		*VEHID					= NULL;
	char		*VehRev					= NULL;
	char		*VehItem_Rev		=	NULL;
	char		*VehItem_Seq		=	NULL;
	char		*responseString1	= NULL;
	//char		*sCustomExpression	= NULL;
	char		*item_id 				= NULL;
	char		*item_idTB 				= NULL;
	char		*item_idTaB 				= NULL;
	char		*item_revision_id= NULL;
	char		*object_desc 			= NULL;
	char		*RowCntWindow1 = NULL;
	char		*TotalRowSelc 		= NULL;
	char		*wind2AElements 		= NULL;
	char		*Rolename 		= NULL;
	char **	GStringList =NULL;
	char **	GStringList2 =NULL;
	char *value_flag_colour=NULL;
		char *  item_Mask= NULL;
		char *  partNumber= NULL;
		tag_t 			*tagTopBLchildLine 			= NULLTAG;
		tag_t 			*tagTopBLchildLine2			= NULLTAG;
			tag_t	window 				= NULLTAG;
			tag_t	window2				= NULLTAG;
			tag_t	top_line			= NULLTAG;

	int				ifail 	= ITK_ok;
	int		cntt							=0;
	int		n_entries1				=2;
	int		ic				=0;
	int		n_found1				=0;
	int		aModCnt					=0;
	int		bvr_count				=	0;
	int		bvr_count1				=	0;
	int		childCountTopBomLine				=	0;
	int		childCountTopBomLine2				=	0;
	int	TbNo=0;
	int StringCount=0;
	int	TbNo1=0;
	int	iCount=0;
	int StringCount1=0;
		int n_occs_clr=0;
	int  sCustomExpression=0;


	char RevisionRule[40];
	char ClosureRule[40];
	char CurrentViewMask[40];
	char ERCClosureRule[40];
	char BVR[40];
	tag_t   ClrPrtrule	=NULLTAG;

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

	int		StructCntPaintProdPlan	= 0;
	struct	BomChldStrut	ChldStrutPart[1000];
	int		childBS			=0;	
	char * DML_Taskid=NULL;
	char * cdmlnumber=NULL;
	char * DmlEcnTypDup=NULL;
	char * getPlant=NULL;


	 
	int		n_entries	=	1;
	int		iii	=	0;
	int		t	=	0;
	int		n_found=	0;
	int		 n_items =0;	
	int		 taskcount =0;	
	int		 Partcount =0;	
	int		 PartChildcount =0;	
	
	int		 Pcont =0;	
	int		 totalDmlCnt =0;	
	int		 idml =0;	
	

	tag_t	task_dml_rel_type	=	NULLTAG;
	tag_t	task_tag	=	NULLTAG;
	tag_t   tsk_rev_tag	=	NULLTAG;
	tag_t	*dmlRevTagList		= NULLTAG;
	tag_t	 dmlrevtag			= NULLTAG;
	tag_t	 ERCPartTag			= NULLTAG;
	tag_t	 PartTagSol			= NULLTAG;
	tag_t	 PartInSol			= NULLTAG;
	tag_t *DmlTasksTags		= NULLTAG;
	tag_t *PartTagsSol	= NULLTAG;
	tag_t *PartTagsSol1	= NULLTAG;

	responseString1=(char *)MEM_alloc(200);

	USERARG_get_string_argument(&AplRevw);	

	printf("\n \nCreateVCRstBOMServiceCalling Registration Successful ****"); fflush(stdout);
	printf("\n *Input From RAC Code AplRevw ::%s",AplRevw); fflush(stdout);


	ifail = ITEM_find_item( AplRevw, &task_tag );
	printf("\n \n00000000000000000000000000000000****"); fflush(stdout);
   if (task_tag != NULLTAG)
	{
		ITKCALL(ITEM_ask_latest_rev(task_tag,&tsk_rev_tag)) ;

		if (tsk_rev_tag  != NULLTAG)
		{
				ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &task_dml_rel_type));
				ITKCALL(GRM_list_primary_objects_only(tsk_rev_tag,task_dml_rel_type,&totalDmlCnt,&dmlRevTagList));
				printf("\nNo of dml found : %d",totalDmlCnt);fflush(stdout);
				if (totalDmlCnt>0)
				{
					for (idml=0;idml<totalDmlCnt ;idml++ )
					{
						dmlrevtag	=	dmlRevTagList[idml];

							char *item_idCpy =NULL;
							char *revStr =NULL;
							char *tmpStr =NULL;
							char *revStr1 =NULL;
							
							item_idCpy	=	(char *)MEM_alloc(50);

							ITKCALL(AOM_ask_value_string(dmlrevtag,"item_id",&cdmlnumber));
							printf("\ncheckAMDMLForGMDML cdmlnumber:%s",cdmlnumber);fflush(stdout);

							tc_strcpy(item_idCpy,cdmlnumber);
							reverse(item_idCpy);
							revStr	=	(char *)MEM_alloc(50);
							tc_strcpy(revStr,item_idCpy);
							printf("\n revStr Find %s.......",revStr);fflush(stdout);
							tmpStr	=	strtok(revStr,"_");
							printf("\n tmpStr Find %s.......",tmpStr);fflush(stdout);
							getPlant	=	(char *)MEM_alloc(50);
							reverse(tmpStr);
							printf("\n revStr1 Find %s.......11",tmpStr);fflush(stdout);
							tc_strcpy(getPlant,tmpStr);
							printf("\n revStr1 Find %s.......00",getPlant);fflush(stdout);
							printf("\n Plant name : %s",getPlant);fflush(stdout);

							if (tc_strstr(cdmlnumber,"APL")!=NULL)
							{

								ITKCALL(AOM_ask_value_string(dmlrevtag,"t5_EcnType",&DmlEcnTypDup));
								printf("\ncheckAMDMLForGMDML DmlEcnTypDup:%s",DmlEcnTypDup);fflush(stdout);
							}
							else if(tc_strstr(cdmlnumber,"MBOM")!=NULL)
							{
								ITKCALL(AOM_ask_value_string(dmlrevtag,"t5_MBOMRlzType",&DmlEcnTypDup));
								printf("\ncheckAMDMLForGMDML0 DmlEcnTypDup:%s",DmlEcnTypDup);fflush(stdout);

							}
						if (tc_strcmp(DmlEcnTypDup,"TODRAPL")==0 || tc_strcmp(DmlEcnTypDup,"GM_MMDML")==0)//MBOM
						{
							//TOO DML FOUND
							printf("\nAPL GM DML found...");fflush(stdout);
							tm_GateMaturaion(tsk_rev_tag,getPlant);
						
						}
					}
				}

		}
	}


		tag_t * docn_best = (tag_t *) MEM_alloc (1 * sizeof (tag_t));
		int n_docn_best = 1;
		USERSERVICE_array_t arrayStruct;
		docn_best=NULLTAG;

		ifail = USERSERVICE_return_tag_array(docn_best, n_docn_best, &arrayStruct);
		printf("\nAfter returning Value=%d",arrayStruct.length);fflush(stdout);

		if (arrayStruct.length != 0)
		*((USERSERVICE_array_t*) retValue) = arrayStruct;	

		printf("\nAfter returning Value*******");fflush(stdout);
	
	


	return ifail;
 }
/*******************************3.*******************************************/
extern int tm_APLGMDMLserviceCalling()
{
	int ifail = ITK_ok;
	int nargs = 1;
	int retValueType;
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );

	/* Refer ict_userservice.h for more arg types*/	
	inputArgTypes[0] = USERARG_STRING_TYPE;
	
	printf("\n tm_APLGMDMLserviceCalling1100000000000 ");  fflush(stdout);
	retValueType = USERARG_TAG_TYPE+ USERARG_ARRAY_TYPE;
	ifail=USERSERVICE_register_method("APLGMDMLserviceCalling",(USER_function_t)APLGMDMLserviceCalling,nargs,inputArgTypes,retValueType);
 	
	return ifail;
	
}
/*******************************2.*******************************************/

extern int tm_CreateAPLGMDMLservice(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	printf("\n trm_CreateAPLGMDMLservice00 ");   fflush(stdout);

	tm_APLGMDMLserviceCalling();
	
	return ifail;
	
}

/*******************************1.*******************************************/
extern DLLAPI int tm_CreateAPLGMDML_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n Before registoring userservice....33000000");   fflush(stdout);
	ifail=CUSTOM_register_exit ( "tm_CreateAPLGMDML", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_CreateAPLGMDMLservice);
	printf("\n After registoring userservice....0000");
	return ( ITK_ok );
}