/*********************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Action Handler		:	CM_ImpactAnalysisReport.c
*
*  Author				:   Bhaskar Dimble
*  Module				:   Workflow Action Handler to generate impact analysis report
*  Code					:   CM_ImpactAnalysisReport.c
*  Created on			:   Feb 1st, 2019
*  Modification History	:
*
* S.No		Date         CR No		Modified By		Modification Notes
*  01		19.04.22		-		Prasad Sagare	Uploaded Data from Bhaskar Folder to DV
*  02		12.10.22		-		Rupali Rane		Hard coding of project replaced with control object validation
*  03		23.06.23		-		Rupali Rane		CCVC Revise ITK called from 2c4--2c7 system call
*********************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

char NoModuleStr[1900];

int AssignProject(tag_t  itemRev,char* projectcode)
{
	tag_t projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;
	int stat = ITK_ok;
	int ifail = 0;

	// ITK_CALL(AOM_lock(itemRev));
	printf("\n AssignProject--Projectcode [%s]\n",projectcode); fflush(stdout);
	CALLAPI(PROJ_find(projectcode,&projobj));
	printf("\t Assigned to Project\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		printf("\n AssignProject--Before Assigned to Project\n");fflush(stdout);
		CALLAPI(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n AssignProject--After Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n AssignProject--Project not found\n");fflush(stdout);
	}
	//   ITK_CALL(AOM_save_without_extensions(itemRev));
	//  ITK_CALL(AOM_unlock(itemRev));

	//return ITK_ok;
	return 0;
}

void getCurrentDateTimee(char cCurrentAccessDate[20])
{
	int ch = 0;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];

	printf("\n getCurrentDateTime calling..........\n");

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%b_%Y_%H:%M",timeptr);

	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n getCurrentDateTimee--cCurrentAccessDate: %s\n",cCurrentAccessDate);

	printf(" getCurrentDateTimee--Date:  %d\n",(timeptr->tm_mday)); fflush(stdout);
	printf(" getCurrentDateTimee--Month: %d\n",(timeptr->tm_mon)+1); fflush(stdout);
	printf(" getCurrentDateTimee--Year:  %d\n",(timeptr->tm_year+1900)); fflush(stdout);
}

int CM_ImpactAnalysisReport(EPM_action_message_t msg)
{
	int i=0,j=0,k=0,kl=0,status=ITK_ok;
	int Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int ItmCnt = 0;
	int attachmentCount=0;
	int n_bom_views=0;

	char *obj_type =NULL;
	char* FileDown =NULL;
	char* filename =NULL;

	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t ItemObj = NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t e_block=NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t rule = NULLTAG;
	tag_t Childobject1=NULLTAG;
	tag_t Childobject33=NULLTAG;
	tag_t *bom_variant_rule=NULLTAG;
	tag_t dml_Ref_Rel = NULLTAG;
	tag_t dml_Ref_Rel_t = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t close_tag = NULLTAG;

	tag_t *taskAttachments=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *bom_views=NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *closurerule = NULLTAG;

	FILE *fd = NULL;

	int n_lines3=0;
	int rulefound= 0;
	int n_lines1=0;
	int PltFrmPartFlg = 0;
	int p34=0;
	int p3=0;
	int BOmvarcnt1=0;

	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *childsvrname=NULL;

	char **rulename = NULL;
	char **rulevalue = NULL;

	char* type_name=NULL;

	char docFile[100];
	char command[512];
	char MulModule[1900] = { 0 };
	char NoModule[1900];
	char RevMisMatch[900];

	logical modB=FALSE;

	FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	TempVal = (char *) MEM_alloc (sizeof (char) * 128);
	filename = (char *) MEM_alloc (sizeof (char) * 128);
	printf("\n CM_ImpactAnalysisReport Function started...");fflush(stdout);
	TC_write_syslog("\n CM_ImpactAnalysisReport Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_ImpactAnalysisReport--Object Type = %s\n",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			if(DcrProblmItemsRelType != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				for(i=0;i<Dcrcnt;i++)
				{
					printf("\n CM_ImpactAnalysisReport--to find impacted items\n");fflush(stdout);

					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&objectname));
					printf("\n CM_ImpactAnalysisReport--Object Type in loop = %s\n",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"VariantRule")==0)
					{
						tc_strcpy(TempVal,objectname);
						primary1=rev1;

						tc_strcpy(FileDown,"/tmp/");
						tc_strcat(FileDown,TempVal);
						tc_strcat(FileDown,"_BomCompare.csv");

						fd=fopen(FileDown,"w");
						if(fd==NULL)
						{
							printf("\nCM_ImpactAnalysisReport--Error in opening the file ");fflush(stdout);
						}
						fprintf(fd,"\nCM_ImpactAnalysisReport--,Super SVR Name ==> %s\n",TempVal);

						tc_strcpy(docFile,"");
						tc_strcat(docFile,"/tmp/");
						tc_strcat(docFile,TempVal);
						tc_strcat(docFile,"_ImpactAnalysis.csv");

						TC_write_syslog("\n CM_ImpactAnalysisReport--Doc File = %s \n",docFile);
					}
				}

				for(j=0;j<Dcrcnt;j++)
				{
					printf("\n CM_ImpactAnalysisReport--to find impacted items\n");fflush(stdout);
					rev = DcrList[j];
					if(AOM_ask_value_string(rev,"object_type",&objecttype));
					if(AOM_ask_value_string(rev,"object_name",&objectname));

					//if(AOM_ask_value_string(rev,"object_type",&objecttype));
					if (strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						printf( "\n CM_ImpactAnalysisReport--INside platform\n"); fflush(stdout);

						if ( rev !=NULLTAG )
						{
						if ( PS_find_view_type( "view", &view_type ));
						printf("\n CM_ImpactAnalysisReport--PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
						if ( ITEM_ask_item_of_rev( rev, &item ));
						if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

						bom_view = bom_views[0];
						}
						else
						printf("\n CM_ImpactAnalysisReport--View not found check.......\n"); fflush(stdout);
						}

						if ( bom_view != NULLTAG )
						{
							printf(" CM_ImpactAnalysisReport--before BOM_create_window..\n");        fflush(stdout);
							if ( BOM_create_window( &bom_window ));
							//if(CFM_find( "ERC release and above", &rule ))
							if(CFM_find( "ERC release and above", &rule ));
							if(BOM_set_window_config_rule( bom_window, rule ));


							if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

							printf ("CM_ImpactAnalysisReport--rule count %d \n",rulefound);fflush(stdout);
							if (rulefound > 0)
							{
								close_tag = closurerule[0];
								printf ("CM_ImpactAnalysisReport--closure rule found \n");fflush(stdout);
								// MEM_free(tags_found);
							}
							if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

							if(BOM_set_window_pack_all(bom_window, TRUE));
							if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
							printf( " CM_ImpactAnalysisReport--After BOM_set_window_top_line..\n");fflush(stdout);

							//if ( BOM_window_ask_variant_rule( bom_window,&bom_variant_rule ));
							if ( BOM_window_ask_variant_rules( bom_window,&BOmvarcnt1,&bom_variant_rule ));
							printf( " CM_ImpactAnalysisReport--BOM_window_ask_variant_rules..\n");fflush(stdout);
                            if(BOmvarcnt1>0)
                            {
							if(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name));
							}

							if ( ITEM_ask_rev_variants ( rev, &e_block ));
							printf(" CM_ImpactAnalysisReport--ITEM_ask_rev_variants..\n");fflush(stdout);

							if ( top_line!=NULLTAG )
							{
								fprintf( stderr, "\n print Master second .\n");

								if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
								printf("\n CM_ImpactAnalysisReport--before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);
								if(bom_window != NULLTAG)
								{
									printf("\n CM_ImpactAnalysisReport--before inside bom_window-----\n"); fflush(stdout);
									if(BOM_window_hide_unconfigured(bom_window))   ;
									if(BOM_window_show_variants(bom_window))   ;


									if(DmlTaskRelationType_t != NULLTAG)

									ITK_CALL(GRM_list_secondary_objects_only(primary1,DmlTaskRelationType_t,&ItmCnt,&taskList));

									tc_strcpy(MulModule,"");
									tc_strcpy(NoModule,"");
									tc_strcpy(RevMisMatch,"");

									for(k=0;k<ItmCnt;k++)
									{
										printf("\n CM_ImpactAnalysisReport--to find impacted items-1--\n");fflush(stdout);
										ItemObj = taskList[k];
										if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));

										fprintf(fd,"\t");

										fprintf(fd,childsvrname);
										fprintf(fd,",");
										fprintf(fd,"\t");

										printf("\n CM_ImpactAnalysisReport--After inside bom_window-----\n"); fflush(stdout);
										// if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										if(BOM_window_apply_variant_configuration(bom_window,1,&primary1))   ;
										printf("\n CM_ImpactAnalysisReport--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										if(BOM_window_hide_variants(bom_window))   ;
										if(BOM_window_ask_is_modified(bom_window,&modB))   ;

										if(modB)
										{
											fprintf( stderr, "\n modified bom window:..\n");fflush(stdout);
										}
										else
										{
											fprintf( stderr, "\n not modfiifed ..\n");fflush(stdout);
										}

										if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										printf("\n CM_ImpactAnalysisReport--2nd time LLlast Before setting option n_lines1: %d  mulmodule: [%s]\n", n_lines1,MulModule); fflush(stdout);

										//EMH_clear_errors();

										if (n_lines1 >0)
										{
											//MulModule = (char *)MEM_alloc (1024 * sizeof(char));

											for (p3=0;p3<n_lines1 ;p3++ )
											{
												if(Childobject1) Childobject1=NULLTAG;

												Childobject1=lines[p3];

												if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
												if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

												printf("\n CM_ImpactAnalysisReport--n_lines3: %d ",n_lines3);fflush(stdout);

												if (n_lines3 >0)
												{
													for (p34=0;p34<n_lines3 ;p34++ )
													{
														if(Childobject33) Childobject33=NULLTAG;
														Childobject33=lines3[p34];
														if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
														if(AOM_ask_value_string(Childobject33, "bl_rev_item_revision_id", &child_item_revision_id ));

														fprintf(fd,"\t");
														fprintf(fd,child_item_id15);
														fprintf(fd,"/");
														fprintf(fd,child_item_revision_id);
														fprintf(fd,",");
														//fprintf(fd,"\t");
													}
												}
											}

											fprintf(fd,"\n");
										}
									}

									if (fd)
									{
										fclose(fd);
									}

									// for getting child SVR information
									FILE *ff [ ItmCnt ] ;

									PltFrmPartFlg=0;

									for(kl=0;kl<ItmCnt;kl++)
									{
										printf("\n CM_ImpactAnalysisReport--to find impacted items-2--\n");fflush(stdout);

										ItemObj = taskList[kl];
										if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));

										tc_strcpy(filename,"/tmp/");
										tc_strcat(filename,childsvrname);
										tc_strcat(filename,"_Module.csv");

										ff [kl]=fopen(filename,"w");
										if(ff [kl]==NULL)
										{
											printf("\nCM_ImpactAnalysisReport--Error in opening the file \n");fflush(stdout);
										}

										fprintf(ff [kl],"\n,Child SVR Name ==>%s\n",childsvrname);

										printf("\n CM_ImpactAnalysisReport--B--After inside bom_window-----\n"); fflush(stdout);
										// if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										printf("\n CM_ImpactAnalysisReport--B--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										if(BOM_window_hide_variants(bom_window))   ;
										if(BOM_window_ask_is_modified(bom_window,&modB))   ;
										if(modB)
										{
											fprintf( stderr, "\n CM_ImpactAnalysisReport--B--modified bom window:..\n");fflush(stdout);
										}
										else
										{
											fprintf( stderr, "\n CM_ImpactAnalysisReport--B--not modfiifed ..\n");fflush(stdout);
										}

										if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										printf("\n CM_ImpactAnalysisReport--B--2nd time LLlast Before setting option n_lines1: %d  mulmodule: [%s] \n", n_lines1,MulModule); fflush(stdout);

										//EMH_clear_errors();

										if (n_lines1 >0)
										{
											for (p3=0;p3<n_lines1 ;p3++ )
											{
												if(Childobject1) Childobject1=NULLTAG;

												Childobject1=lines[p3];

												if(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));

												if(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

												printf("\n CM_ImpactAnalysisReport--n_lines3 :%d ",n_lines3);fflush(stdout);

												if (n_lines3 >0)
												{
													for (p34=0;p34<n_lines3 ;p34++ )
													{
														if(Childobject33) Childobject33=NULLTAG;
														Childobject33=lines3[p34];
														if(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));

														fprintf(ff[kl],"\n");
														fprintf(ff[kl],child_item_id15);
													}
												}
											}
											fprintf(ff [kl],"\n");
										}
										fclose ( ff [kl]) ;
										PltFrmPartFlg++;
										//sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/ClusterSVRImpact.sh %s %s %d %d",FileDown,filename,ItmCnt,PltFrmPartFlg);
										sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/ClusterSVRImpact.sh %s %s %d %d",FileDown,filename,ItmCnt,PltFrmPartFlg);
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									// child SVR info finish
								}
								else
								{
									fprintf( stderr, "\n no bom window found here \n");
								}

								//break;
							}
						}
					}
				}
			}
		}
		printf("\n CM_ImpactAnalysisReport--JJJJJJJJ2 ");fflush(stdout);

		if(access(docFile,F_OK)!=-1)
		{
			printf("\n CM_ImpactAnalysisReport--KKKKKK ");fflush(stdout);
			if(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel)!=ITK_ok);
			printf("\n CM_ImpactAnalysisReport--LLLLLLLL ");fflush(stdout);
			TC_write_syslog("Doc file created successfully ");
			//if(AE_find_datasettype2("MSWord",&msWordType)!=ITK_ok);
			//if(AE_find_datasettype2("Text",&msWordType)!=ITK_ok);
			//if(AE_find_datasettype2("MS Excel",&msWordType)!=ITK_ok);
			if(AE_find_datasettype2("MSExcel",&msWordType)!=ITK_ok);
			printf("\n CM_ImpactAnalysisReport--MMMMMMMMMM ");fflush(stdout);

			if(msWordType == NULLTAG)
			{
				printf("\n CM_ImpactAnalysisReport--NNNNNNNNNN ");fflush(stdout);
				TC_write_syslog("Could not find Dataset Type Text. Please check data model ");
				//continue;
			}

			if(AE_create_dataset_with_id(msWordType,TempVal,"Impact Analysis for SuperSVR","","",&wordDataset)!=ITK_ok);
			if(AE_save_myself(wordDataset));
			if(GRM_create_relation(taskAttachments[Itemscnt],wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t)!=ITK_ok);
			if(AOM_load(dml_Ref_Rel_t)!=ITK_ok);
			if(GRM_save_relation(dml_Ref_Rel_t)!=ITK_ok);
			if(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
			if(AOM_refresh(wordLatestDat_t,TRUE)!=ITK_ok);

			//if(AE_import_named_ref(wordLatestDat_t,"word",FileDown,NULL,SS_BINARY)!=ITK_ok);
			if(AE_import_named_ref(wordLatestDat_t,"excel",docFile,NULL,SS_BINARY)!=ITK_ok);
			//if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok);
			
			printf("\n CM_ImpactAnalysisReport--HHHHH ");fflush(stdout);
			if(AE_save_myself(wordLatestDat_t)!=ITK_ok);
			printf("\n CM_ImpactAnalysisReport--IIIII ");fflush(stdout);
			
			remove(docFile);
			printf("\n CM_ImpactAnalysisReport--JJJJJ ");fflush(stdout);
			//if(docFile) MEM_free(docFile);
		}
	}

	printf("\n CM_ImpactAnalysisReport Function end...");fflush(stdout);
	TC_write_syslog("\n CM_ImpactAnalysisReport Function end...");

	//return ITK_ok;
	return 0;
}

int CM_CreateCCVfromSVR(EPM_action_message_t msg)
{
	int i=0,j=0,k=0,status=ITK_ok;
	int Dcrcnt = 0;
	int ifail=0;
	int jy=0;
	int Itemscnt=0;
	int ItmCnt = 0, taskcnt = 0;
	int attachmentCount=0;

	char *obj_type=NULL;
	char *DMLDRstatus=NULL;
	char *VCname=NULL;
	char *VCrevee=NULL;

	tag_t rev1=NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t ItemObj = NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t VcSpecRel_t=NULLTAG;
	tag_t DMLRevTag=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t item=NULLTAG;
	tag_t DMLTaskTag=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t *DMLRevision= NULLTAG;
	tag_t VCrev= NULLTAG;

	int index = 0;
	int l_strings=80;
	int tempStrLength = 80;

	char *RevId = NULL;
	char *itemId12 = NULL;
	char *itemId123 = NULL;
	char *itemId1234 = NULL;
	char *itemId12345 = NULL;
	tag_t Rel_task = NULLTAG;
	tag_t Rel_taska = NULLTAG;
	tag_t Rel_taskab = NULLTAG;
	tag_t Rel_taskab11 = NULLTAG;
	tag_t Rel_taskab112 = NULLTAG;
	tag_t rev_type_tag = NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t tRelationExista = NULLTAG;
	tag_t tRelationExistab = NULLTAG;
	tag_t tRelationExistab11 = NULLTAG;
	tag_t SVRDerRel_t = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;

	char *child_item_id1=NULL;
	char *child_item_revision_id=NULL;

	tag_t *attachments12 =NULLTAG;
	tag_t *status_list = NULLTAG;

	tag_t status3=NULLTAG;
	tag_t parent_revision = NULLTAG;
	tag_t objTypeTag1=NULLTAG;
	tag_t NewRevTag	= NULLTAG;

	//char *VehName =NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *ObjectName1=NULL;
	char *childsvrname=NULL;
	char *childsvrdesc=NULL;

	//logical retain=false;
	logical retain_released_date =TRUE;
	char** stringArray = NULL;

	int n_strings = 1;
	int cnt12 = 0;

	char* tempString = NULL;
	char *rel_status = NULL;
	char *rel_status1 = NULL;
	char *PartTypeStr = NULL;
	char* type_name= NULL;

	int status_count =0;
	char RelStat[200] = { 0 };
	char *ReleaseStatus=NULL;
	int ii =0;
	logical is_latest;
	int jm=0;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	printf("\n CM_CreateCCVfromSVR Function started...");fflush(stdout);
	TC_write_syslog("\n CM_CreateCCVfromSVR Function started...");

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("T5_VCSpec",&VcSpecRel_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_DerivedFromSVR",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("T5_SVRDerivesCCV",&SVRDerRel_t));

	// for getting DR status of DML from DML task
	if(attachmentCount > 0)
	{
		if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
		//DMLTaskTag = taskAttachments[0];
		for(jm=0;jm<attachmentCount;jm++)
		{
			DMLTaskTag=taskAttachments[jm];
			if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n : Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&taskcnt,&DMLRevision));
					printf("\n\t CM_CreateCCVfromSVR--DML Revision from Task for MR : %d",taskcnt);fflush(stdout);
					for (jy=0;jy<taskcnt ;jy++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
						printf("\n\t CM_CreateCCVfromSVR--is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n\t CM_CreateCCVfromSVR--is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTag = DMLRevision[jy];

							if(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
						}
					}
				}
				break;
			}
		}
	}
	// for getting DR status of DML from DML task end

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_CreateCCVfromSVR--Object Type = %s",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			if(DcrProblmItemsRelType != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&objectname));
					printf("\n CM_CreateCCVfromSVR--Object Type in loop = %s ",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"VariantRule")==0)
					{
						primary1=rev1;

						if(DmlTaskRelationType_t != NULLTAG)

						ITK_CALL(GRM_list_secondary_objects_only(primary1,DmlTaskRelationType_t,&ItmCnt,&taskList));

						for(k=0;k<ItmCnt;k++)
						{
							ItemObj = taskList[k];
							
							if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));
							if(AOM_ask_value_string(ItemObj,"object_desc",&childsvrdesc));
							
							ITK_CALL(AOM_UIF_ask_value (ItemObj,"release_status_list", &rel_status1));
							printf("\n CM_CreateCCVfromSVR--release_status_list rel_status11111111 :[%s] \n",rel_status1);   fflush(stdout);
							
							if(strstr(rel_status1,"ERC Released")!=NULL)
							{
								printf("\nCM_CreateCCVfromSVR--childsvr is released  hence ignoring ****** ");fflush(stdout);
							}
							else
							{
								printf("\n CM_CreateCCVfromSVR--VC-ItemId(childsvrname) := %s ", childsvrname); fflush(stdout);

								itemId12 = tc_strtok(childsvrname,"_");
								RevId=tc_strtok(NULL,"_");

								itemId123=subString(itemId12,0,8);
								itemId1234=subString(itemId12,0,4);
								itemId12345=subString(itemId12,11,1);

								//VehName=(char *) MEM_alloc(20);
								//tc_strcpy(VehName,"");
								//tc_strcpy(VehName,itemId123);
								//tc_strcat(VehName,itemId12345);

								printf("\n CM_CreateCCVfromSVR--itemId12==> %s ",itemId12); fflush(stdout);
								printf("\n CM_CreateCCVfromSVR--itemId1234==> %s ",itemId1234); fflush(stdout);

								ITK_CALL(ITEM_find_item(itemId12, &parent_master1));
								//ass
								if (parent_master1!=NULLTAG)
								{
									ITK_CALL(ITEM_ask_latest_rev(parent_master1, &parent_revision));
									if (parent_revision!=NULLTAG)
									{
										printf("\n CM_CreateCCVfromSVR--parent_revision latest revision found\n");fflush(stdout);
									
										ITK_CALL(AOM_UIF_ask_value (parent_revision,"release_status_list", &rel_status));
										printf("\n CM_CreateCCVfromSVR--1-------");fflush(stdout);
										ITK_CALL(AOM_ask_value_string(parent_revision,"t5_PartType",&PartTypeStr));
										printf("\n CM_CreateCCVfromSVR--release_status_list :[%s] PartTypeStr : [%s]\n",rel_status,PartTypeStr);   fflush(stdout);

										if (WSOM_ask_release_status_list(parent_revision,&status_count,&status_list)) PrintErrorStack();
										
										tc_strcpy(RelStat,"");
										
										printf("\n CM_CreateCCVfromSVR--status_count: %d ",status_count);fflush(stdout);
										for (ii = 0; ii < status_count; ii++)
										{
											if(AOM_ask_name(status_list[ii], &ReleaseStatus));
											printf(" ReleaseStatus: [%s]", ReleaseStatus);fflush(stdout);
											tc_strcat(RelStat,"[");
											tc_strcat(RelStat,ReleaseStatus);
											tc_strcat(RelStat,"]");
											tc_strcat(RelStat,",");
										}

										if(tc_strstr(RelStat,"T5_LcsErcRlzd")!=NULL)
										{
											if(tc_strcmp(PartTypeStr,"CCVC")==0)
											{
												printf("\n CM_CreateCCVfromSVR--<<<<<<<<<<<<<<<<child SVR is ERC Released>>>>>>>");fflush(stdout);

												if (TCTYPE_ask_object_type(parent_revision,&objTypeTag1)!=ITK_ok)PrintErrorStack();
												if (TCTYPE_ask_name2(objTypeTag1,&type_name)!=ITK_ok)PrintErrorStack();
												printf("\n CM_CreateCCVfromSVR--<<<<<<<<<<type_name>>>>>>>>>> %s\n", type_name);fflush(stdout);
												// for VC spec delete

												if(GRM_list_secondary_objects_only(parent_revision,VcSpecRel_t,&cnt12,&attachments12));
												if (cnt12==1)
												{
													if (AOM_ask_value_string(attachments12[0],"object_name",&ObjectName1)!=ITK_ok)   PrintErrorStack();
													printf("\n\n CM_CreateCCVfromSVR--TechSpec Name  :%s ",ObjectName1);fflush(stdout);

													if (GRM_find_relation(parent_revision,attachments12[0],VcSpecRel_t,&tRelationExistab11));

													if(tRelationExistab11 != NULLTAG)
													{
														printf("\n CM_CreateCCVfromSVR--Now deleting Relation Between VC and TechSpec \n");fflush(stdout);
														// if(GRM_create_relation(ItemObj,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
														// if(GRM_save_relation  (Rel_taskab));
														ITK_CALL(GRM_delete_relation(tRelationExistab11));
														printf("\n CM_CreateCCVfromSVR--Relation deleted Successfully\n");fflush(stdout);
													}
												}
												// for VC spec delete ends

												if(tc_strcmp(type_name,"Design Revision")==0 )
												{
													ITK_CALL(ITEM_copy_rev(parent_revision,NULL,&NewRevTag));
													ITK_CALL(AOM_refresh(parent_revision,0));
													ITK_CALL(AOM_refresh(NewRevTag,0));
													ITK_CALL(AssignProject(NewRevTag,itemId1234));

													//printf("\n CM_CreateCCVfromSVR--Now creating Relation Between VC and TechSpec \n");fflush(stdout);
													//if(GRM_create_relation(NewRevTag,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab11));
													//if(GRM_save_relation  (Rel_taskab11));

													//if(GRM_create_relation(parent_revision,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab112));
													//if(GRM_save_relation  (Rel_taskab112));
													//ITK_CALL(GRM_delete_relation(tRelationExistab11));
													//printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);

													if(DmlItemsRelation_t != NULLTAG)
													{
														GRM_find_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,&tRelationExist);
														if (tRelationExist==NULLTAG)
														{
															 //###  Creating Relation between DML and Task  ###
															 printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
															 if(GRM_create_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,NULLTAG,&Rel_task));
															 if(GRM_save_relation  (Rel_task));
															 printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
															 // for adding newly created CCV in solution  item end
														}
													}

													if(implemRelationType_t != NULLTAG)
													{
														if (GRM_find_relation(NewRevTag,ItemObj,implemRelationType_t,&tRelationExista));
														if (tRelationExista==NULLTAG)
														{
															printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between CCV and SVR \n");fflush(stdout);
															if(GRM_create_relation(NewRevTag,ItemObj,implemRelationType_t,NULLTAG,&Rel_taska));
															if(GRM_save_relation  (Rel_taska));
															printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
														}
													}

													if (AOM_refresh(NewRevTag,0));
													ITK_CALL(AOM_unlock(NewRevTag));
													if (AOM_unlock(parent_master1));
												}

												if(SVRDerRel_t != NULLTAG)
												{
													if (GRM_find_relation(ItemObj,NewRevTag,SVRDerRel_t,&tRelationExistab));
													if (tRelationExistab==NULLTAG)
													{
														printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between SVR and CCV \n");fflush(stdout);
														if(GRM_create_relation(ItemObj,NewRevTag,SVRDerRel_t,NULLTAG,&Rel_taskab));
														if(GRM_save_relation  (Rel_taskab));
														printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
													}
												}
											}
											else
											{
												EMH_store_error_s1(EMH_severity_error,PLM_error1,"Please Get Vehicle released with unit BOM ");
												printf("\n CM_CreateCCVfromSVR--<<<<< release_status_list :[%s] >>>>>\n",rel_status);fflush(stdout);
												return(PLM_error1);
											}
										}
										else
										{
											//if(strstr(rel_status,"ERC Released")==NULL)
											//{
											printf("\n CM_CreateCCVfromSVR--release_status_list :[%s] ",rel_status);fflush(stdout);
											if (tc_strcmp(PartTypeStr,"CCVC")==0)
											{
												printf("\n CM_CreateCCVfromSVR--PartTypeStr>>> : [%s] ",PartTypeStr);   fflush(stdout);
												EMH_store_error_s1(EMH_severity_error,PLM_error,"Please Get CCVC Released First ");
												printf("\n CM_CreateCCVfromSVR--<<<<< release_status_list :[%s] >>>>>\n",rel_status);fflush(stdout);
												return(PLM_error);
											}
											//}
										}
									}
								}
								//ass
								else
								{
									if(parent_master1 == NULLTAG)
									{
										
										stringArray = (char**)malloc( n_strings * sizeof *stringArray );
						              for( index=0; index<n_strings; index++ )
						              {
						              	stringArray[index] = (char*)malloc( l_strings + 1 );
						              }
										tempString = malloc( tempStrLength + 1 );

										ITK_CALL( TCTYPE_find_type( "Design", NULL, &item_type_tag) );
										ITK_CALL( TCTYPE_find_type( "Design Revision", NULL, &rev_type_tag) );

										ITK_CALL( TCTYPE_construct_create_input( item_type_tag, &item_create_input_tag) );
										ITK_CALL( TCTYPE_construct_create_input( rev_type_tag, &rev_create_input_tag) );

										ITK_CALL( AOM_tag_to_string(rev_create_input_tag, &tempString) );
										strncpy( stringArray[0], tempString, l_strings );
										ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "revision", 1, stringArray) );


										strncpy( stringArray[0], itemId12, l_strings );
										ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "item_id", 1, stringArray) );

										strncpy( stringArray[0],itemId12,l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "object_name", 1, stringArray) );

										strncpy( stringArray[0],"NR;1",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "item_revision_id", 1, stringArray) );

										strncpy( stringArray[0],itemId1234,l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ProjectCode", 1, stringArray) );

										strncpy( stringArray[0],"CCVC",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartType", 1, stringArray) );

										strncpy( stringArray[0],childsvrdesc,l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "object_desc", 1, stringArray) );

										strncpy( stringArray[0],"00",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DesignGrp", 1, stringArray) );

										/*	strncpy( stringArray[0],"NA",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DocRemarks", 1, stringArray) );

										strncpy( stringArray[0],"PROPUN",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnOwn", 1, stringArray) ); */

										strncpy( stringArray[0],"Y",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ColourInd", 1, stringArray) );

										strncpy( stringArray[0],"VC",l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PrtCatCode", 1, stringArray) );

										strncpy( stringArray[0],DMLDRstatus,l_strings);
										ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartStatus", 1, stringArray) );

										//strncpy( stringArray[0],"Pune-Design",l_strings);
										//ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnDept", 1, stringArray) );
										//
										//strncpy( stringArray[0],"NA",l_strings);
										//ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_MThickness", 1, stringArray) );

										TCTYPE_create_object(item_create_input_tag, &parent_master1);
										ITK_CALL(AOM_save_without_extensions(parent_master1));
										ITK_CALL(AOM_refresh(parent_master1,0));
										ITK_CALL(ITEM_ask_latest_rev(parent_master1, &VCrev));
										//ITEM_find_revision(parent_master1,"NR;1", &VCrev);

										if (VCrev)
										{
											ITK_CALL(AOM_lock(parent_master1));
											ITK_CALL(AOM_lock(VCrev));

											ITK_CALL(AOM_save_without_extensions(VCrev));
											ITK_CALL (RELSTAT_create_release_status("T5_LcsReview",&status3));
											printf("\n CM_CreateCCVfromSVR--release status find 3.");fflush(stdout);
											//ITK_CALL(EPM_add_release_status(status3,1,&VCrev,retain));
											ITK_CALL (RELSTAT_add_release_status(status3,1,&VCrev,retain_released_date));

											ITK_CALL(AssignProject(VCrev,itemId1234));
											ITK_CALL(AssignProject(parent_master1,itemId1234));

											if(implemRelationType_t != NULLTAG)
											{
												if(GRM_find_relation(VCrev,ItemObj,implemRelationType_t,&tRelationExista));
												if (tRelationExista==NULLTAG)
												{
													printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between CCV and SVR \n");fflush(stdout);
													if(GRM_create_relation(VCrev,ItemObj,implemRelationType_t,NULLTAG,&Rel_taska));
													if(GRM_save_relation(Rel_taska));
													printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
												}
											}

											ITK_CALL(AOM_refresh(VCrev,0));
											ITK_CALL(AOM_unlock(VCrev));
											ITK_CALL(AOM_unlock(parent_master1));
										}

										if(SVRDerRel_t != NULLTAG)
										{
											if(GRM_find_relation(ItemObj,VCrev,SVRDerRel_t,&tRelationExistab));
											if (tRelationExistab==NULLTAG)
											{
												printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between SVR and CCV \n");fflush(stdout);
												if(GRM_create_relation(ItemObj,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
												if(GRM_save_relation  (Rel_taskab));
												printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
											}
										}

										if(AOM_ask_value_string(VCrev,"item_id",&VCname));
										if(AOM_ask_value_string(VCrev,"item_revision_id",&VCrevee));

										printf("\n CM_CreateCCVfromSVR--VC name and revision is .%s %s",VCname,VCrevee); fflush(stdout);

										// for adding newly created CCV in solution  item
										if(DmlItemsRelation_t != NULLTAG)
										{
											if(GRM_find_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,&tRelationExist));
											if (tRelationExist==NULLTAG)
											{
												//###  Creating Relation between DML and Task  ###
												printf("\n CM_CreateCCVfromSVR--Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
												if(GRM_create_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,NULLTAG,&Rel_task));
												if(GRM_save_relation  (Rel_task));
												printf("\n CM_CreateCCVfromSVR--Relation Created Successfully\n");fflush(stdout);
												// for adding newly created CCV in solution  item end
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	printf("\n CM_CreateCCVfromSVR Function end...");fflush(stdout);
	TC_write_syslog("\n CM_CreateCCVfromSVR Function end...");

	//return ITK_ok;
	return 0;
}
int CM_CreateSnapShotfromSVR(EPM_action_message_t msg)
{
	int i=0,j=0,k=0,kl=0,status=ITK_ok;
	int Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int ItmCnt = 0;
	int attachmentCount=0;
	int n_bom_views=0;

	char *obj_type=NULL;

	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t ItemObj = NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t VCrev= NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t snapshot=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t top_line1=NULLTAG;
	tag_t rule =NULLTAG;
	tag_t* bom_variant_rule=NULLTAG;
	tag_t dml_Ref_Rel = NULLTAG;
	tag_t dml_Ref_Rel_t = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t close_tag = NULLTAG;

	tag_t *taskAttachments=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *bom_views=NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *closurerule = NULLTAG;

	FILE *fd = NULL;

	int n_lines3=0;
	int rulefound= 0;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char* itemId12 = NULL;
	int n_lines1 = 0;
	int BOmvarcnt2 = 0;

	char* username=NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *childsvrname=NULL;
	char docFile[100];

	char* type_name=NULL;

	TempVal = (char *) MEM_alloc (sizeof (char) * 128);
	printf("\n CM_CreateSnapShotfromSVR Function started...");fflush(stdout);
	TC_write_syslog("\n CM_CreateSnapShotfromSVR Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_PartHasSnapShot",&implemRelationType_t));

	POM_get_user(&username,&user_tag);
	printf("\n CM_CreateSnapShotfromSVR--Starting for username : [%s] ",username);fflush(stdout);

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_CreateSnapShotfromSVR--Object Type = %s ",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			if(DcrProblmItemsRelType != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&objectname));
					
					printf("\n CM_CreateSnapShotfromSVR--A.ObjectType= %s",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"VariantRule")==0)
					{
						printf( "---INside VariantRule "); fflush(stdout);
						//tc_strcpy(TempVal,objectname);
						primary1=rev1;
					}
				}


				for(j=0;j<Dcrcnt;j++)
				{
					rev = DcrList[j];

					if(AOM_ask_value_string(rev,"object_type",&objecttype));
					if(AOM_ask_value_string(rev,"object_name",&objectname));

					printf("\n CM_CreateSnapShotfromSVR--B.ObjectType= %s",objecttype);fflush(stdout);

					if (strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						printf( "---INside platform "); fflush(stdout);

						if ( rev !=NULLTAG )
						{
							if ( PS_find_view_type( "view", &view_type ));
							printf("\n CM_CreateSnapShotfromSVR--PS_find_view_type is found......\n" ); fflush(stdout);

							if ( view_type != NULLTAG )
							{
								if ( ITEM_ask_item_of_rev( rev, &item ));
								if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

								bom_view = bom_views[0];
							}
							else
							{
								printf("\n CM_CreateSnapShotfromSVR--View not found check.......\n"); fflush(stdout);
							}
						}

						if ( bom_view != NULLTAG )
						{
							if ( BOM_create_window( &bom_window ));
							//if(CFM_find( "ERC release and above", &rule ))
							if(CFM_find( "ERC release and above", &rule ));
							if(BOM_set_window_config_rule( bom_window, rule ));

							if(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

							printf ("\n CM_CreateSnapShotfromSVR--rule count %d ",rulefound);fflush(stdout);
							if (rulefound > 0)
							{
								close_tag = closurerule[0];
								printf ("\n CM_CreateSnapShotfromSVR--closure rule found ");fflush(stdout);
								// MEM_free(tags_found);
							}
							if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

							if(BOM_set_window_pack_all(bom_window, TRUE));
							if ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
							printf("\n CM_CreateSnapShotfromSVR--After BOM_set_window_top_line..");fflush(stdout);

							//if ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
							if ( BOM_window_ask_variant_rules( bom_window,&BOmvarcnt2,&bom_variant_rule));
							printf("\n CM_CreateSnapShotfromSVR--BOM_window_ask_variant_rules..");fflush(stdout);
                          if(BOmvarcnt2>0)
                          {
							if(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name));
						  }

							if ( top_line!=NULLTAG )
							{
								if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
								printf("\n CM_CreateSnapShotfromSVR--before n_lines1: %d \n", n_lines1);fflush(stdout);
								
								if(bom_window != NULLTAG)
								{
									printf("\n CM_CreateSnapShotfromSVR--before inside bom_window-----\n"); fflush(stdout);
									if(BOM_window_hide_unconfigured(bom_window))   ;
									if(BOM_window_show_variants(bom_window))   ;


									if(DmlTaskRelationType_t != NULLTAG)

									ITK_CALL(GRM_list_secondary_objects_only(primary1,DmlTaskRelationType_t,&ItmCnt,&taskList));

									printf("\n CM_CreateSnapShotfromSVR--ItmCnt: [%d] ",ItmCnt); fflush(stdout);

									for(k=0;k<ItmCnt;k++)
									{
										ItemObj = taskList[k];

										if(AOM_ask_value_string(ItemObj,"object_name",&childsvrname));

										itemId12 = tc_strtok(childsvrname,"_");
										ITK_CALL(ITEM_find_item(itemId12, &parent_master1));
										ITEM_ask_latest_rev(parent_master1, &VCrev);

										tc_strcpy(TempVal,childsvrname);
										tc_strcat(TempVal,"_");
										tc_strcat(TempVal,username);
										tc_strcat(TempVal,"_Snapshot");


										printf("\n CM_CreateSnapShotfromSVR--After inside bom_window-----"); fflush(stdout);
										// if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										if(BOM_window_apply_variant_configuration(bom_window,1,&ItemObj))   ;
										printf("\n CM_CreateSnapShotfromSVR--After BOM_window_apply_variant_configuration-----"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										if(BOM_window_hide_variants(bom_window))   ;
										if(BOM_create_snapshot(bom_window,TempVal,"Snapshot for SVR",&snapshot));
										if(snapshot)
										{
											if(AOM_save_without_extensions( snapshot) )
											if(AOM_refresh(snapshot,1));
											if(AOM_unlock(snapshot));
										}

										if (VCrev)
										{
											if(implemRelationType_t != NULLTAG)
											{
												if(GRM_create_relation(VCrev,snapshot,implemRelationType_t,NULLTAG,&Rel_task));
												if(GRM_save_relation  (Rel_task));
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	//printf("\n CM_CreateSnapShotfromSVR is completed ...\n");fflush(stdout);
	printf("\n CM_CreateSnapShotfromSVR Function end...");fflush(stdout);
	TC_write_syslog("\n CM_CreateSnapShotfromSVR Function end...");

	//return ITK_ok;
	return 0;
}

// create CCV from SVR
int CM_CreateCCVfromSingleSVR(EPM_action_message_t msg)
{
	int i=0,j=0,k=0;
	//int status=ITK_ok;
	int Dcrcnt = 0;
	int ifail=0;
	int jy=0;
	int Itemscnt=0;
	int ItmCnt = 0,taskcnt = 0;
	int rulefound= 0 , status=0 ;
	int attachmentCount=0;
	int n_strings = 1;
	int cnt12 = 0;
	int status_count =0;
	int ii =0;
	int index=0;
	int l_strings=80;
	int tempStrLength = 80;
	int VCReviseQryC=0 , NewRevstatus_count = 0 , ss2=0;

	char *obj_type=NULL;

	char *DMLDRstatus=NULL;
	char *VCname=NULL;
	char *VCrevee=NULL;
	char *RevId = NULL;
	char *itemId12 = NULL;
	char *itemId123 = NULL;
	char *itemId1234 = NULL;
	char *itemId12345 = NULL;
	char *child_item_id1=NULL;
	char *child_item_revision_id=NULL;
	char *VehName =NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *platformName=NULL;
	char *objectname=NULL;
	char *ObjectName1=NULL;
	char *childsvrname=NULL;
	char *SVRNameStr=NULL;
	char *childsvrdesc=NULL;
	char *tempString = NULL;
	char *rel_status = NULL;
	char *rel_status1 = NULL;
	char *PartTypeStr = NULL;
	char *ReleaseStatus=NULL;
	char *DMLNo=NULL;
	char *VCReviseinfo1 =NULL;
	char *latest_rev_Rel_Stus = NULL;
	char *NewRevRelStatus = NULL;

	char **stringArray = NULL;
	char **rulename = NULL;
	char **rulevalue = NULL;

	char* type_name= NULL;
	char RelStat[200] = { 0 };
	char command[512];

	tag_t bom_window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t svrRev=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t VcSpecRel_t=NULLTAG;
	tag_t DMLRevTag=NULLTAG;
	tag_t item=NULLTAG;
	tag_t DMLTaskTag=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t VCrev= NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t Rel_taska = NULLTAG;
	tag_t Rel_taskab = NULLTAG;
	tag_t Rel_taskab11 = NULLTAG;
	tag_t Rel_taskab112 = NULLTAG;
	tag_t rev_type_tag = NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t tRelationExist  = NULLTAG;
	tag_t tRelationExista  = NULLTAG;
	tag_t tRelationExistab  = NULLTAG;
	tag_t tRelationExistab11  = NULLTAG;
	tag_t SVRDerRel_t  = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t tRelationExistab11ss = NULLTAG;
	tag_t status3=NULLTAG;
	tag_t objTypeTag=NULLTAG;
 	tag_t close_tag = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t parent_revision = NULLTAG;
	tag_t objTypeTag1=NULLTAG;
	tag_t NewRevTag = NULLTAG;
	tag_t PlatformRevTag = NULLTAG;
	tag_t CtrObjVCReviseQryTag = NULLTAG;

	tag_t *taskAttachments=NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t *DMLRevision= NULLTAG;
	tag_t *attachments12 =NULLTAG;
	tag_t* status_list = NULLTAG;
	tag_t *VCReviseCtrObj = NULLTAG;
	tag_t *NewRevstatus_list = NULLTAG;
	int jm=0;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	//logical retain=false;
	logical retain_released_date =TRUE;
	logical is_latest;

	char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	printf("\n CM_CreateCCVfromSingleSVR Function started...");fflush(stdout);
	TC_write_syslog("\n CM_CreateCCVfromSingleSVR Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	printf("\n\n\t ----Start of function CM_CreateCCVfromSingleSVR---attachmentCount: %d ----------",attachmentCount);fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_VCSpec",&VcSpecRel_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_DerivedFromSVR",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("T5_SVRDerivesCCV",&SVRDerRel_t));

	// for getting DR status of DML from DML task
	if(attachmentCount > 0)
	{
		printf("\n  Root Task Count is [%d]\n",attachmentCount);fflush(stdout);
		for(jm=0;jm<attachmentCount;jm++)
		{
			DMLTaskTag=taskAttachments[jm];
			if(TCTYPE_ask_object_type(DMLTaskTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n  Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&taskcnt,&DMLRevision));
					printf("\n CM_CreateCCVfromSingleSVR---DML Revision from Task for MR : %d",taskcnt);fflush(stdout);

					for (jy=0;jy<taskcnt ;jy++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
						printf("\n CM_CreateCCVfromSingleSVR---is_latest MR is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n CM_CreateCCVfromSingleSVR---is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTag = DMLRevision[jy];

							if(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
							ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo));
							printf("\n CM_CreateCCVfromSingleSVR---DMLNo------>:%s: ",DMLNo);fflush(stdout);
						}
					}
				}
			}
			break;
		}
	}

	//for getting DR status of DML from DML task end
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

		printf("\n CM_CreateCCVfromSingleSVR---Object Type = %s ",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			if(DcrProblmItemsRelType != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				printf("\n CM_CreateCCVfromSingleSVR---Dcrcnt= %d ",Dcrcnt);fflush(stdout);

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&platformName));

					printf("\n CM_CreateCCVfromSingleSVR--Object Type in loop = [%s] ",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						printf("\t Platform: [%s] --> Platform Found",platformName);fflush(stdout);

						PlatformRevTag=rev1;
						break;
					}
				}

				if (PlatformRevTag == NULLTAG)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,PLM_error1,"Error1::Platform is not attached under DML Task Relation. Please raise ticket in TMS for support.");
					printf("\n CM_CreateCCVfromSingleSVR--Platform is not attached under DML Task Relation ?? \n\n");fflush(stdout);
					return PLM_error1;
				}

				for(i=0;i<Dcrcnt;i++)
				{
					printf("\n CM_CreateCCVfromSingleSVR---to find impacted items ");fflush(stdout);

					svrRev = DcrList[i];

					if(AOM_ask_value_string(svrRev,"object_type",&objecttype));
					if(AOM_ask_value_string(svrRev,"object_name",&objectname));
					printf(" CM_CreateCCVfromSingleSVR---Object Type in loop = %s [%s] ",objecttype,objectname);fflush(stdout);

					if (tc_strcmp(objecttype,"VariantRule")==0)
					{
						primary1=svrRev;

						if(AOM_ask_value_string(primary1,"object_name",&childsvrname));
						if(AOM_ask_value_string(primary1,"object_name",&SVRNameStr));
						if(AOM_ask_value_string(primary1,"object_desc",&childsvrdesc));
						
						ITK_CALL(AOM_UIF_ask_value (primary1,"release_status_list", &rel_status1));

						printf("\n CM_CreateCCVfromSingleSVR---release_status_list rel_status11111111 :[%s] ",rel_status1);   fflush(stdout);

						if(strstr(rel_status1,"ERC Released")!=NULL)
						{
							printf("\n CM_CreateCCVfromSingleSVR---SVR is released hence ignoring ?? ");fflush(stdout);
						}
						else
						{
							printf("\n CM_CreateCCVfromSingleSVR---VC-ItemId := %s ", childsvrname); fflush(stdout);

							itemId12 = tc_strtok(childsvrname,"_");
							RevId=tc_strtok(NULL,"_");

							itemId123=subString(itemId12,0,8);
							itemId1234=subString(itemId12,0,4);
							itemId12345=subString(itemId12,11,1);

							VehName=(char *) MEM_alloc(20);
							tc_strcpy(VehName,"");
							tc_strcpy(VehName,itemId123);
							tc_strcat(VehName,itemId12345);

							printf("\n CM_CreateCCVfromSingleSVR---itemId12 ==> [%s] ",itemId12); fflush(stdout);
							printf(" itemId1234-project==> [%s] \n",itemId1234); fflush(stdout);

							// Start-Module Address Validation UA1.68
							if (PlatformRevTag != NULLTAG)
							{
								if(BOM_create_window( &bom_window ));
								if(CFM_find( "ERC release and above", &rule ));
								if(BOM_set_window_config_rule( bom_window, rule ));
								if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

								printf ("\n CM_CreateCCVfromSingleSVR--rule-count: %d ",rulefound);fflush(stdout);
								if (rulefound > 0)
								{
									close_tag = closurerule[0];
									printf ("\n CM_CreateCCVfromSingleSVR--closure rule found ");fflush(stdout);
								}

								if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

								if(BOM_set_window_pack_all(bom_window, TRUE));
								if(BOM_set_window_top_line( bom_window, NULLTAG, PlatformRevTag, NULLTAG, &top_line ));
								printf("\n CM_CreateCCVfromSingleSVR--After BOM_set_window_top_line..");fflush(stdout);

								if(BOM_window_apply_variant_configuration(bom_window,1,&svrRev));
								if(BOM_window_hide_unconfigured(bom_window));
								if(BOM_window_show_variants(bom_window));

								if(top_line!=NULLTAG)
								{
									status = tm_validateModuleAddress(DMLRevTag , top_line, 0 ); //AltrozFlag=0 for hornbill/Punch
									printf("\n CM_CreateCCVfromSingleSVR--tm_validateModuleAddress--status: [%d] ",status); fflush(stdout);
									if (status != 0)
									{
										printf("\n CM_CreateCCVfromSingleSVR--2.....show error....");fflush(stdout);

										tc_strcat(NoModuleStr,"-->");
										tc_strcat(NoModuleStr,SVRNameStr);

										printf("\n CM_CreateCCVfromSingleSVR--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModuleStr);fflush(stdout);
										printf("\n -------A.CM_CreateCCVfromSingleSVR function ended with above data error---------------------\n\n");fflush(stdout);

										EMH_clear_errors();
										EMH_store_error_s3(EMH_severity_information,PLM_error,"No module is present under **",NoModuleStr," please verify the SVR.");
										return PLM_error;
									}
								}
							}
							// End-Module Address Validation UA1.68

							ITK_CALL(ITEM_find_item(itemId12, &parent_master1));

							if (parent_master1!=NULLTAG)
							{
								ITK_CALL(ITEM_ask_latest_rev(parent_master1, &parent_revision));
								if (parent_revision!=NULLTAG)
								{
									printf("\n CM_CreateCCVfromSingleSVR---parent_revision latest revision found [%s] ",itemId12);fflush(stdout);
									// ITK_CALL(AOM_UIF_ask_value (parent_revision,"release_status_list", &rel_status));
									ITK_CALL(AOM_ask_value_string(parent_revision,"t5_PartType",&PartTypeStr));

									printf("\n CM_CreateCCVfromSingleSVR---release_status_list :[%s] PartTypeStr : [%s] ",rel_status,PartTypeStr);   fflush(stdout);

									if (WSOM_ask_release_status_list(parent_revision,&status_count,&status_list)) PrintErrorStack();
									tc_strcpy(RelStat,"");
									printf("\n CM_CreateCCVfromSingleSVR---number of statuses: %d \n",  status_count);fflush(stdout);

									for (ii = 0; ii < status_count; ii++)
									{
										if(AOM_ask_name(status_list[ii], &ReleaseStatus));
										printf("\t ReleaseStatus: %s ", ReleaseStatus);fflush(stdout);
										
										tc_strcat(RelStat,"[");
										tc_strcat(RelStat,ReleaseStatus);
										tc_strcat(RelStat,"]");
										tc_strcat(RelStat,",");
									}

									if(tc_strstr(RelStat,"T5_LcsErcRlzd")!=NULL)
									{
										if(tc_strcmp(PartTypeStr,"CCVC")==0) //Part type check
										{
											printf("\n CM_CreateCCVfromSingleSVR---<<<<<<<<<<<<<<<<child SVR is ERC Released>>>>>>>");fflush(stdout);

											if (TCTYPE_ask_object_type(parent_revision,&objTypeTag1)!=ITK_ok)PrintErrorStack();
											if (TCTYPE_ask_name2(objTypeTag1,&type_name)!=ITK_ok)PrintErrorStack();
											printf("\n CM_CreateCCVfromSingleSVR---<<<<<<<<<<type_name>>>>>>>>>> %s ", type_name);fflush(stdout);

											//if(GRM_list_secondary_objects_only(parent_revision,VcSpecRel_t,&cnt12,&attachments12));
											//if (cnt12==1)
											//{
											//	if (AOM_ask_value_string(attachments12[0],"object_name",&ObjectName1)!=ITK_ok)   PrintErrorStack();
											//	printf("\n\n CM_CreateCCVfromSingleSVR---TechSpec Name: [%s] ",ObjectName1);fflush(stdout);
											//
											//	if(GRM_find_relation(parent_revision,attachments12[0],VcSpecRel_t,&tRelationExistab11));
											//	if(tRelationExistab11 != NULLTAG)
											//	{
											//		printf("\n CM_CreateCCVfromSingleSVR---Relation found Between VC and TechSpec ......");fflush(stdout);
											//
											//		//printf("\n Now deleting Relation Between VC and TechSpec \n");fflush(stdout);
											//		//ITK_CALL(GRM_delete_relation(tRelationExistab11));
											//		//printf("\nRelation deleted Successfully\n");fflush(stdout);
											//	}
											//}
											//// for VC spec delete ends

											if(tc_strcmp(type_name,"Design Revision")==0 )
											{
												printf("\n CM_CreateCCVfromSingleSVR---In type_name=Design Revision if condition--Non-NR Revision....");fflush(stdout);

												CALLAPI(QRY_find2("Control Objects...", &CtrObjVCReviseQryTag));
												if (CtrObjVCReviseQryTag != NULLTAG)
												{
													VCReviseEntryValue[0] = "DmlVCRevise";	//SYSCD
													VCReviseEntryValue[1] = "ON";			//SUBSYSCD

													CALLAPI(QRY_execute(CtrObjVCReviseQryTag, 2, VCReviseQryEntry, VCReviseEntryValue, &VCReviseQryC, &VCReviseCtrObj));
												}
												printf("\n CM_CreateCCVfromSingleSVR--Control Object AltrozVCRevise count:--> [%d] ",VCReviseQryC); fflush(stdout);

												if(VCReviseQryC>0)	
												{
													CALLAPI(AOM_ask_value_string(VCReviseCtrObj[0],"t5_Userinfo1",&VCReviseinfo1));

													tc_strcpy(command,"");
													tc_strcpy(command,VCReviseinfo1);
													tc_strcat(command," ");
													tc_strcat(command,DMLNo);
													tc_strcat(command," ");
													tc_strcat(command,itemId12);

													printf("\n CM_CreateCCVfromSingleSVR--:command: %s",command);fflush(stdout);

													TC_write_syslog("CM_CreateCCVfromSingleSVR--Command = %s\n",command);
													system(command);

													CALLAPI(ITEM_ask_latest_rev(parent_master1, &NewRevTag ));
													if (NewRevTag!=NULLTAG)
													{
														printf("\n CM_CreateCCVfromSingleSVR--:NewRevTag Found.. ");fflush(stdout);

														CALLAPI(AOM_UIF_ask_value(NewRevTag, "release_status_list", &latest_rev_Rel_Stus));
														printf("\n CM_CreateCCVfromSingleSVR--:latest_rev_Rel_Stus: [%s] ",latest_rev_Rel_Stus);fflush(stdout);

														CALLAPI(WSOM_ask_release_status_list(NewRevTag,&NewRevstatus_count,&NewRevstatus_list));

														printf("\n CM_CreateCCVfromSingleSVR--:NewRevstatus_count: [%d] ",NewRevstatus_count);fflush(stdout);
														if (NewRevstatus_count > 0)  // No Status, so the Item is not yet Released
														{
															for(ss2=0; ss2<NewRevstatus_count ; ss2++)
															{
																CALLAPI(AOM_ask_value_string(NewRevstatus_list[ss2],"object_name",&NewRevRelStatus));
																printf("\n CM_CreateCCVfromSingleSVR--NewRevRelStatus: %s ",NewRevRelStatus);fflush(stdout);

																if((tc_strstr(NewRevRelStatus,"ERC Released")!=NULL) || (tc_strstr(NewRevRelStatus,"T5_LcsErcRlzd")!=NULL) )
																{
																	EMH_clear_errors();
																	EMH_store_error_s1(EMH_severity_error,PLM_error,"Unable to Revise Vehicle for SVR attached under DML. Please raise ticket in TMS.");
																	printf("\n CM_CreateCCVfromSingleSVR--Unable to Revise Vehicle for SVR attached under DML ?? \n\n");fflush(stdout);
																	return PLM_error;
																}
															}
														}
													}
												}
												else
												{
													ITK_CALL(ITEM_copy_rev(parent_revision,NULL,&NewRevTag));
												}

												ITK_CALL(AOM_refresh(parent_master1,0));
												ITK_CALL(AOM_refresh(NewRevTag,0));
												ITK_CALL(AssignProject(NewRevTag,itemId1234));

												ITK_CALL(AOM_lock( NewRevTag ));
												ITK_CALL(AOM_set_value_string(NewRevTag,"t5_PartStatus",DMLDRstatus));
												ITK_CALL(AOM_set_value_string(NewRevTag, "object_desc", childsvrdesc));

												if(AOM_save_without_extensions(NewRevTag));
												if(AOM_refresh(NewRevTag,0));
												if(AOM_unlock(NewRevTag));

												printf("\n CM_CreateCCVfromSingleSVR-------------object-----------------");fflush(stdout);

												//printf("\n Now creating Relation Between VC and TechSpec \n");fflush(stdout);
												//if(GRM_create_relation(NewRevTag,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab11));
												//if(GRM_save_relation  (Rel_taskab11));
												//
												//if(GRM_create_relation(parent_revision,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab112));
												//if(GRM_save_relation  (Rel_taskab112));
												//printf("\nRelation Created Successfully\n");fflush(stdout);

												if(DmlItemsRelation_t != NULLTAG)
												{
													GRM_find_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,&tRelationExist);
													if (tRelationExist==NULLTAG)
													{
														//###  Creating Relation between DML and Task  ###
														printf("\n CM_CreateCCVfromSingleSVR---Now Creating Relation Between DML Task and VC Object ");fflush(stdout);
														if(GRM_create_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,NULLTAG,&Rel_task));
														if(GRM_save_relation  (Rel_task));
														printf("\n CM_CreateCCVfromSingleSVR---Relation Created Successfully ");fflush(stdout);

														// for adding newly created CCV in solution  item end
													}
												}

												// to delete existing svr relation
												int snapcnt=0;
												int iy=0;
												tag_t *extsnap = NULLTAG;

												if(GRM_list_secondary_objects_only(NewRevTag,implemRelationType_t,&snapcnt,&extsnap));
												for(iy=0; iy<snapcnt; iy++)
												{
													if(GRM_find_relation(NewRevTag,extsnap[iy],implemRelationType_t,&tRelationExistab11ss));

													if(tRelationExistab11ss != NULLTAG)
													{
														printf("\n CM_CreateCCVfromSingleSVR---Now deleting Relation Between CCVVC and SVR ");fflush(stdout);
														if(GRM_delete_relation(tRelationExistab11ss));
														printf("\n CM_CreateCCVfromSingleSVR---Relation deleted Successfully ");fflush(stdout);
													}
												}
												// end to delete existing svr relation

												if(implemRelationType_t != NULLTAG)
												{
														if(GRM_find_relation(NewRevTag,primary1,implemRelationType_t,&tRelationExista));
														if (tRelationExista==NULLTAG)
														{
															printf("\n CM_CreateCCVfromSingleSVR---1.Now Creating Relation Between CCV and SVR ");fflush(stdout);
															if(GRM_create_relation(NewRevTag,primary1,implemRelationType_t,NULLTAG,&Rel_taska));
															if(GRM_save_relation  (Rel_taska));
															printf("\n CM_CreateCCVfromSingleSVR---1.Relation Created Successfully ");fflush(stdout);
														}
												}

												ITK_CALL(AOM_refresh(NewRevTag,0));
												ITK_CALL(AOM_unlock(NewRevTag));
												ITK_CALL(AOM_unlock(parent_master1));

												printf("\n CM_CreateCCVfromSingleSVR---1.Before Relation Create....");fflush(stdout);
												if(SVRDerRel_t != NULLTAG)
												{
													if(GRM_find_relation(primary1,NewRevTag,SVRDerRel_t,&tRelationExistab));
													if (tRelationExistab==NULLTAG)
													{
														printf("\n CM_CreateCCVfromSingleSVR---2.Now Creating Relation Between SVR and CCV ");fflush(stdout);
														if(GRM_create_relation(primary1,NewRevTag,SVRDerRel_t,NULLTAG,&Rel_taskab));
														if(GRM_save_relation  (Rel_taskab));
														printf("\n CM_CreateCCVfromSingleSVR---2.Relation Created Successfully ");fflush(stdout);
													}
												}
											}
										}
										else
										{
											EMH_store_error_s1(EMH_severity_error,PLM_error1,"Please Get Vehicle released with unit BOM ");
											printf("\n CM_CreateCCVfromSingleSVR---2.<<<<< release_status_list :[%s] ",rel_status);fflush(stdout);
											return(PLM_error1);
										}
									}
									else
									{
										//if(strstr(rel_status,"ERC Released")==NULL)
										//{
										printf("\n CM_CreateCCVfromSingleSVR---3.release_status_list :[%s] ",rel_status);fflush(stdout);
										if (tc_strcmp(PartTypeStr,"CCVC")==0)
										{
											printf("\n  CM_CreateCCVfromSingleSVR---3.PartTypeStr>>> : [%s] ",PartTypeStr);   fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,PLM_error,"Please Get CCVC Released First ");
											printf("\n CM_CreateCCVfromSingleSVR---3.<<<<< release_status_list :[%s] ",rel_status);fflush(stdout);
											return(PLM_error);
										}
										//}
									}
								}
							}
							else
							{
								if(parent_master1 == NULLTAG)
								{
									stringArray = malloc( n_strings * sizeof *stringArray );
									for( index=0; index<n_strings; index++ )
									{
									stringArray[index] = malloc( l_strings + 1 );
									}
									tempString = malloc( tempStrLength + 1 );

									ITK_CALL( TCTYPE_find_type( "Design", NULL, &item_type_tag) );
									ITK_CALL( TCTYPE_find_type( "Design Revision", NULL, &rev_type_tag) );
									ITK_CALL( TCTYPE_construct_create_input( item_type_tag, &item_create_input_tag) );
									ITK_CALL( TCTYPE_construct_create_input( rev_type_tag, &rev_create_input_tag) );

									ITK_CALL( AOM_tag_to_string(rev_create_input_tag, &tempString) );
									strncpy( stringArray[0], tempString, l_strings );
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "revision", 1, stringArray) );

									strncpy( stringArray[0], itemId12, l_strings );
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "item_id", 1, stringArray) );

									strncpy( stringArray[0],itemId12,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "object_name", 1, stringArray) );

									//strncpy( stringArray[0],RevId,l_strings);
									//ITK_CALL( TCTYPE_set_create_display_value( itemRevCreInTag, "item_revision_id", 1, stringArray) );

									strncpy( stringArray[0],"NR;1",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "item_revision_id", 1, stringArray) );

									strncpy( stringArray[0],itemId1234,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ProjectCode", 1, stringArray) );

									strncpy( stringArray[0],"CCVC",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartType", 1, stringArray) );

									strncpy( stringArray[0],childsvrdesc,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "object_desc", 1, stringArray) );

									strncpy( stringArray[0],"00",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DesignGrp", 1, stringArray) );

									/*	strncpy( stringArray[0],"NA",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DocRemarks", 1, stringArray) );

									strncpy( stringArray[0],"PROPUN",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnOwn", 1, stringArray) ); */

									strncpy( stringArray[0],"Y",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ColourInd", 1, stringArray) );

									strncpy( stringArray[0],"VC",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PrtCatCode", 1, stringArray) );

									strncpy( stringArray[0],DMLDRstatus,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartStatus", 1, stringArray) );

									/*	strncpy( stringArray[0],"Pune-Design",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnDept", 1, stringArray) );

									strncpy( stringArray[0],"NA",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_MThickness", 1, stringArray) ); */

									TCTYPE_create_object(item_create_input_tag, &parent_master1);
									ITK_CALL(AOM_save_without_extensions(parent_master1));
									AOM_refresh(parent_master1,0);
									ITEM_ask_latest_rev(parent_master1, &VCrev);
									//ITEM_find_revision(parent_master1,"NR;1", &VCrev);

									if (VCrev!=NULLTAG)
									{
										ITK_CALL(AOM_lock(parent_master1));
										ITK_CALL(AOM_lock(VCrev));

										ITK_CALL(AOM_save_without_extensions(VCrev));
										printf("\n CM_CreateCCVfromSingleSVR---5.rev tag found. ");fflush(stdout);
										ITK_CALL (RELSTAT_create_release_status("T5_LcsReview",&status3));
										printf("\n CM_CreateCCVfromSingleSVR---5.release status find 3. ");fflush(stdout);
										//ITK_CALL(EPM_add_release_status(status3,1,&VCrev,retain));
                                         ITK_CALL(RELSTAT_add_release_status(status3,1,&VCrev,retain_released_date));
										ITK_CALL(AssignProject(VCrev,itemId1234));
										ITK_CALL(AssignProject(parent_master1,itemId1234));

										if(implemRelationType_t != NULLTAG)
										{
											GRM_find_relation(VCrev,primary1,implemRelationType_t,&tRelationExista);
											if (tRelationExista==NULLTAG)
											{
												printf("\n CM_CreateCCVfromSingleSVR---5.Now Creating Relation Between CCV and SVR ");fflush(stdout);
												if(GRM_create_relation(VCrev,primary1,implemRelationType_t,NULLTAG,&Rel_taska));
												if(GRM_save_relation  (Rel_taska));
												printf("\n CM_CreateCCVfromSingleSVR---5.Relation Created Successfully ");fflush(stdout);
											}
										}

										if(AOM_refresh(VCrev,0));
										ITK_CALL(AOM_unlock(VCrev));
										if(AOM_unlock(parent_master1));
									}

									if(SVRDerRel_t != NULLTAG)
									{
										GRM_find_relation(primary1,VCrev,SVRDerRel_t,&tRelationExistab);
										if (tRelationExistab==NULLTAG)
										{
											printf("\n CM_CreateCCVfromSingleSVR---6.Now Creating Relation Between SVR and CCV ");fflush(stdout);
											if(GRM_create_relation(primary1,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
											if(GRM_save_relation  (Rel_taskab));
											printf("\n CM_CreateCCVfromSingleSVR---6.Relation Created Successfully ");fflush(stdout);
										}
									}

									if(AOM_ask_value_string(VCrev,"item_id",&VCname));
									if(AOM_ask_value_string(VCrev,"item_revision_id",&VCrevee));

									printf("\n CM_CreateCCVfromSingleSVR---VC name and revision is .%s %s",VCname,VCrevee); fflush(stdout);

									// for adding newly created CCV in solution  item
									if(DmlItemsRelation_t != NULLTAG)
									{
										GRM_find_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,&tRelationExist);
										if (tRelationExist==NULLTAG)
										{
											//###  Creating Relation between DML and Task  ###

											printf("\n CM_CreateCCVfromSingleSVR---7.Now Creating Relation Between DML Task and VC Object ");fflush(stdout);
											if(GRM_create_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,NULLTAG,&Rel_task));
											if(GRM_save_relation  (Rel_task));
											printf("\n CM_CreateCCVfromSingleSVR---7.Relation Created Successfully ");fflush(stdout);

											// for adding newly created CCV in solution  item end
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	//printf("\n -----Completed CM_CreateCCVfromSingleSVR function -------------------------\n");fflush(stdout);
	printf("\n CM_CreateCCVfromSingleSVR Function end...");fflush(stdout);
	TC_write_syslog("\n CM_CreateCCVfromSingleSVR Function end...");

	//return ITK_ok;
	return 0;
}
// create CCV from SVR end

// create snapshot from single SVR
int tm_validateModuleAddress( tag_t DMLRevTag , tag_t top_line, int AltrozFlag)
{
	int ifail=0;
	int n_lines1=0 , p3=0, n_lines3=0;
	int ArchNodeQryC = 0 , ModuleAvailFlag=0, errorflag1=0 ;

	char *DMLNo=NULL;
	char *DMLDRstatus=NULL;
	char *DMLDRstatusStr=NULL;
	char *sModuleAdrr=NULL;
	char *Arch_item_id=NULL;
	char *Arch_item_idStr=NULL;
	char *strinfo1 =NULL;
	char *strinfo2 =NULL;
	char *strinfo3 =NULL;
	char *strinfo4 =NULL;
	char *strinfo6 =NULL;

	char *ArchQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **ArchrNodeyEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	tag_t *ArchNodeLines = NULL;
	tag_t *moduleslines = NULL;
	tag_t *ArchNodeCtrObj = NULLTAG;

	tag_t Childobject1 = NULLTAG;
	tag_t CtrObjArchQryTag = NULLTAG;
	tag_t ArchTag = NULLTAG;
	tag_t ArchTagRev = NULLTAG;


	DMLDRstatusStr=(char *) MEM_alloc(10);
	Arch_item_idStr=(char *) MEM_alloc(10);


	printf("\n tm_validateModuleAddress Function started...");fflush(stdout);
	TC_write_syslog("\n tm_validateModuleAddress Function started...");

	if (DMLRevTag != NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo));
		CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
		printf("\t DMLNo------>:%s: DMLDRstatus: %s ",DMLNo,DMLDRstatus);fflush(stdout);

		tc_strcpy(DMLDRstatusStr,",");
		tc_strcat(DMLDRstatusStr,DMLDRstatus);
		tc_strcat(DMLDRstatusStr,",");

		printf(" DMLDRstatusStr: [%s] ",DMLDRstatusStr);fflush(stdout);

		if (top_line != NULLTAG)
		{
			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &ArchNodeLines));
			printf("\n tm_validateModuleAddress--ArchNodeLines::n_lines1: [%d] ",n_lines1);fflush(stdout);

			if (n_lines1 >0)
			{
				tc_strcpy(NoModuleStr,"");

				CALLAPI(QRY_find2("Control Objects...", &CtrObjArchQryTag));
				if (CtrObjArchQryTag != NULLTAG)
				{
					if (AltrozFlag>0)
					{
						printf("\n tm_validateModuleAddress--In AltrozArchNode condition...."); fflush(stdout);
						ArchrNodeyEntryValue[0] = "AltrozArchNode"; //SYSCD
						ArchrNodeyEntryValue[1] = "AltrozArchNode"; //SUBSYSCD
					}
					else
					{
						printf("\n tm_validateModuleAddress--In HornbillArchNode condition...."); fflush(stdout);
						ArchrNodeyEntryValue[0] = "HornbillArchNode"; //SYSCD
						ArchrNodeyEntryValue[1] = "HornbillArchNode"; //SUBSYSCD
					}

					CALLAPI(QRY_execute(CtrObjArchQryTag, 2, ArchQryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
				}
				printf("\t Control-count: [%d] ",ArchNodeQryC); fflush(stdout);

				if(ArchNodeQryC>0)
				{
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6));

					printf("\n tm_validateModuleAddress--DR-Info6=> [%s] ",strinfo6); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info1=> [%s] ",strinfo1); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info2=> [%s] ",strinfo2); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info3=> [%s] ",strinfo3); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info4=> [%s] \n",strinfo4); fflush(stdout);
				}

				for (p3=0;p3<n_lines1 ;p3++ )
				{
					if(Childobject1) Childobject1=NULLTAG;

					Childobject1=ArchNodeLines[p3];

					CALLAPI(AOM_ask_value_string(Childobject1,"bl_item_item_id",&Arch_item_id));

					CALLAPI(BOM_line_ask_child_lines(Childobject1, &n_lines3, &moduleslines));

					printf("\n tm_validate--p3:[%d] Arch:[%s]-->childCnt: [%d] ",p3,Arch_item_id,n_lines3);fflush(stdout);

					if (n_lines3 == 0)
					{
						ModuleAvailFlag=0;

						printf(" DMLDR:[%s] info6:[%s] [%s] ArchLen:[%d] ",DMLDRstatusStr,strinfo6,Arch_item_id,tc_strlen(Arch_item_id));fflush(stdout);

						if (Arch_item_id!=NULL)
						{
							CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
							CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
							CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));

							tc_strcpy(Arch_item_idStr,subString(Arch_item_id , tc_strlen(Arch_item_id)-6 , tc_strlen(Arch_item_id)-1 ) ); //6=length of module address

							printf(" Arch_item_idStr:[%s] sModuleAdrr:[%s] ",Arch_item_idStr,sModuleAdrr);fflush(stdout);

							if(((strinfo1 != NULL)&&(tc_strstr(strinfo1,Arch_item_idStr) != NULL)) ||
							   ((strinfo2 != NULL)&&(tc_strstr(strinfo2,Arch_item_idStr) != NULL)) ||
							   ((strinfo3 != NULL)&&(tc_strstr(strinfo3,Arch_item_idStr) != NULL)) ||
							   ((strinfo4 != NULL)&&(tc_strstr(strinfo4,Arch_item_idStr) != NULL)) )
							{
								printf("\t --Found in control-Object ");fflush(stdout);
								ModuleAvailFlag=ModuleAvailFlag+1;
							}
						}

						printf("  ModuleAvailFlag: [%d] ",ModuleAvailFlag);fflush(stdout);

						if ((tc_strstr(strinfo6,DMLDRstatusStr)!=NULL)&&(ModuleAvailFlag>0)&&(DMLDRstatusStr != NULL)&&(strinfo6 != NULL))
						{
							tc_strcat(NoModuleStr,"[");
							tc_strcat(NoModuleStr,Arch_item_id);
							tc_strcat(NoModuleStr,"]");
							tc_strcat(NoModuleStr,",");

							errorflag1=errorflag1+1;

							printf("\n tm_validateModuleAddress--D......show error....for no module under architecture [%s] %d  [%s] \n",Arch_item_id,n_lines3,DMLDRstatusStr);fflush(stdout);
						}
					}
				}

				if (errorflag1 > 0)
				{
					printf("\n tm_validateModuleAddress--2.....show error..no module under architecture..");fflush(stdout);
					return PLM_error;
				}
			}
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Error2:Structure is not present under Platform. Please raise ticket in TMS TCUA-DML.");
			printf("\n tm_validateModuleAddress--Error2:Structure is not present under Platform in TCUA ?? \n\n");fflush(stdout);
			return PLM_error;
		}
	}
	else
	{
		printf("\n tm_validateModuleAddress--DMLRevTag is not found ??? \n");fflush(stdout);
	}

	//printf("\n ------------Completed function tm_validateModuleAddress------------\n");fflush(stdout);
	printf("\n tm_validateModuleAddress Function end...");fflush(stdout);
	TC_write_syslog("\n tm_validateModuleAddress Function end...");

	return 0;
}
int CM_CreateSnapShotfromSingleSVR( EPM_action_message_t msg )
{
	int status = ITK_ok;
	int ifail=0;
	int i=0,j=0;
	int Dcrcnt = 0;
	int iy=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int n_bom_views=0;
	int BOmvarcnt3=0;

	char *obj_type=NULL;
	char *FileDown =NULL;

	tag_t *taskAttachments=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *bom_views=NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *extsnap = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *DMLRevision = NULLTAG;

	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t derivedFromSVRRelType_ta=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t VCrev= NULLTAG;
	tag_t tRelationExistab11 = NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t snapshot=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t rule =NULLTAG;
	tag_t *bom_variant_rule=NULLTAG;
	tag_t dml_Ref_Rel = NULLTAG;
	tag_t dml_Ref_Rel_t = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t SVRDerRel_t=NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t Rel_taska = NULLTAG;
	tag_t Rel_taskab = NULLTAG;
	tag_t tRelationExista = NULLTAG;
	tag_t tRelationExistab = NULLTAG;
	tag_t tsk_dml_rel_type=NULLTAG;
	tag_t DMLTaskTag=NULLTAG;
	tag_t DMLRevTag=NULLTAG;

	FILE *fd = NULL;

	int n_lines3=0;
	int rulefound= 0;
	int snapcnt=0;
	int n_lines1 = 0;
	int count=0 , jy=0 ;

	char **rulename = NULL;
	char **rulevalue = NULL;

	char *itemId12 = NULL;
	char *itemId1234 = NULL;
	char *itemId123 = NULL;
	char *itemId12345 = NULL;
	char *VehName =NULL;
	char *child_item_id1=NULL;
	char *child_item_revision_id=NULL;
	char *username=NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *childsvrname=NULL;

	char cCurrentAccessDate[20]={0};
	char docFile[100];

	char* type_name=NULL;

	logical is_latest;

	TempVal = (char *) MEM_alloc (sizeof (char) * 128);
	
	printf("\n CM_CreateSnapShotfromSingleSVR Function started...");fflush(stdout);
	TC_write_syslog("\n CM_CreateSnapShotfromSingleSVR Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_PartHasSnapShot",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("T5_DerivedFromSVR",&derivedFromSVRRelType_ta));
	ITK_CALL(GRM_find_relation_type("T5_SVRDerivesCCV",&SVRDerRel_t));

	//POM_get_user(&username,&user_tag);
	POM_get_user_id(&username);

	printf("\n\n CM_CreateSnapShotfromSingleSVR--Starting for username: [%s]....",username);fflush(stdout);

	getCurrentDateTimee(cCurrentAccessDate);
	printf("\t cCurrentAccessDate:[%s]",cCurrentAccessDate);fflush(stdout);

	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

		printf(" CM_CreateSnapShotfromSingleSVR--Object Type = %s \n",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			DMLTaskTag = taskAttachments[Itemscnt];

			CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));

			if (tsk_dml_rel_type!=NULLTAG)
			{
				CALLAPI(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&count,&DMLRevision));
				printf("\n CM_CreateSnapShotfromSingleSVR--DML Revision from Task for MR : %d",count);fflush(stdout);

				for( jy=0; jy<count; jy++ )
				{
					CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
					printf("\n CM_CreateSnapShotfromSingleSVR--is_latest MR is : %d\n",is_latest);fflush(stdout);

					if(is_latest != true)
					{
						printf("\n\t CM_CreateSnapShotfromSingleSVR--is_latest is not true .....\n");fflush(stdout);
					}
					else
					{
						DMLRevTag = DMLRevision[jy];

						break;
					}
				}
			}

			char *qry_entriesR[] = { "SYSCD","SUBSYSCD"}, *qry_valuesR[] = {"Project","AltrozWay"};
			int noOfCoObjectsR = 0;
			tag_t queryR = NULLTAG;
			tag_t *CoobjectsR = NULLTAG;
			char *usrInfo1R = NULL;
			char *projStr = NULL;

			usrInfo1R = (char *) MEM_alloc(250);
			projStr=(char *) MEM_alloc(10);

			tc_strcpy(usrInfo1R,"");
			tc_strcpy(projStr,"");

			ITK_CALL(QRY_find2("Control Objects...", &queryR));
			if (queryR !=NULLTAG)
			{
				printf("\n CM_CreateSnapShotfromSingleSVR--queryR found");fflush(stdout);
				ITK_CALL(QRY_execute(queryR,2, qry_entriesR, qry_valuesR, &noOfCoObjectsR, &CoobjectsR));
				printf("\n\n CM_CreateSnapShotfromSingleSVR--Total Number Of CoobjectsR Found ==[%d] \n",noOfCoObjectsR);fflush(stdout);

				if(noOfCoObjectsR>0)
				{
					ITK_CALL(AOM_ask_value_string(CoobjectsR[0],"t5_Userinfo1",&usrInfo1R));
					printf("\n CM_CreateSnapShotfromSingleSVR--usrInfo1R :[%s]\n",usrInfo1R);fflush(stdout);
				}
			}

			if(DcrProblmItemsRelType != NULLTAG)
			{
				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items  Dcrcnt: [%d] \n",Dcrcnt);fflush(stdout);

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&objectname));

					printf(" CM_CreateSnapShotfromSingleSVR--Object Type in loop = %s\n",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						primary1=rev1;
						break;
					}
				}

				for(j=0;j<Dcrcnt;j++)
				{
					printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items\n");fflush(stdout);

					rev = DcrList[j];

					if(AOM_ask_value_string(rev,"object_type",&objecttype));
					if(AOM_ask_value_string(rev,"object_name",&objectname));

					if (strcmp(objecttype,"VariantRule")==0)
					{
						printf( "\n CM_CreateSnapShotfromSingleSVR--INside VariantRule [%s]...",objectname); fflush(stdout);
						if ( primary1 !=NULLTAG )
						{
							if ( PS_find_view_type( "view", &view_type ));
							printf("\n CM_CreateSnapShotfromSingleSVR--PS_find_view_type is found......\n" ); fflush(stdout);

							if ( view_type != NULLTAG )
							{
								if ( ITEM_ask_item_of_rev( primary1, &item ));
								if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

								bom_view = bom_views[0];
							}
							else
							{
								printf("\n CM_CreateSnapShotfromSingleSVR--View not found check.......\n"); fflush(stdout);
							}
						}

						if ( bom_view != NULLTAG )
						{
							printf(" CM_CreateSnapShotfromSingleSVR--before BOM_create_window..\n");        fflush(stdout);
							if ( BOM_create_window( &bom_window ));
							if(CFM_find( "ERC release and above", &rule));
							if(BOM_set_window_config_rule( bom_window, rule ));

							//if(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
							if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

							printf (" CM_CreateSnapShotfromSingleSVR--rule count %d \n",rulefound);fflush(stdout);
							if (rulefound > 0)
							{
								close_tag = closurerule[0];
								printf (" CM_CreateSnapShotfromSingleSVR--closure rule found \n");fflush(stdout);
							}
							if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

							if(BOM_set_window_pack_all(bom_window, TRUE));
							if (BOM_set_window_top_line( bom_window, NULLTAG, primary1, NULLTAG, &top_line ));
							printf( " CM_CreateSnapShotfromSingleSVR--After BOM_set_window_top_line..\n");fflush(stdout);

							//if (BOM_window_ask_variant_rules( bom_window, &bom_variant_rule ));
							if (BOM_window_ask_variant_rules(bom_window,&BOmvarcnt3,&bom_variant_rule ));
							printf( " CM_CreateSnapShotfromSingleSVR--BOM_window_ask_variant_rules..\n");fflush(stdout);
                         if(BOmvarcnt3>0)
                         {
							if(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name));
						 }

							if ( top_line!=NULLTAG )
							{
								int AltrozFlag = 0;

								printf("\n CM_CreateSnapShotfromSingleSVR--print Master second .\n"); fflush(stdout);

								if(bom_window != NULLTAG)
								{
									printf("\n CM_CreateSnapShotfromSingleSVR--Found-->");fflush(stdout);

									//printf("\n CM_CreateSnapShotfromSingleSVR--before inside bom_window-----\n"); fflush(stdout);
									if(BOM_window_hide_unconfigured(bom_window));
									if(BOM_window_show_variants(bom_window));

									if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
									printf("\n CM_CreateSnapShotfromSingleSVR--before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);

									if(AOM_ask_value_string(rev,"object_name",&childsvrname));

									itemId1234=subString(childsvrname,0,4);
									itemId123=subString(childsvrname,0,8);
									itemId12345=subString(childsvrname,11,1);

									VehName=(char *) MEM_alloc(20);
									tc_strcpy(VehName,"");
									tc_strcpy(VehName,itemId123);
									tc_strcat(VehName,itemId12345);

									tc_strcpy(projStr,"");
									tc_strcpy(projStr,",");
									tc_strcat(projStr,itemId1234);
									tc_strcat(projStr,",");

									printf("\t itemId1234: [%s]  VehName: [%s]  projStr: [%s] usrInfo1R: [%s]",itemId1234,VehName,projStr,usrInfo1R);fflush(stdout);

									//if (tc_strcmp(itemId1234,"5442")==0)
									if ((tc_strstr(usrInfo1R,projStr)!=NULL)&&(usrInfo1R!=NULL)) //allowing Altroz-way for project made live in control-object
									{
										printf("\t itemId12==> [%s] ",itemId12);fflush(stdout);

										ITK_CALL(ITEM_find_item(VehName, &parent_master1));
										ITK_CALL(ITEM_ask_latest_rev(parent_master1, &VCrev));

										AltrozFlag=AltrozFlag+1;
									}
									else
									{
										itemId12 = tc_strtok(childsvrname,"_");

										printf("\t itemId12: [%s] ",itemId12);fflush(stdout);

										ITK_CALL(ITEM_find_item(itemId12, &parent_master1));
										ITK_CALL(ITEM_ask_latest_rev(parent_master1, &VCrev));
									}
									printf("\t AltrozFlag==> [%d] \n",AltrozFlag);fflush(stdout);

									status = tm_validateModuleAddress(DMLRevTag , top_line, AltrozFlag );
									printf("\n CM_CreateSnapShotfromSingleSVR--tm_validateModuleAddress--status: [%d] \n",status); fflush(stdout);
									if (status != 0)
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--2.....show error....");fflush(stdout);

										tc_strcat(NoModuleStr,"-->");
										tc_strcat(NoModuleStr,objectname);

										printf("\n CM_CreateSnapShotfromSingleSVR--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModuleStr);fflush(stdout);
										printf("\n -------A.CM_CreateSnapShotfromSingleSVR function ended with above data error---------------------\n\n");fflush(stdout);

										EMH_clear_errors();
										//EMH_store_error_s3(EMH_severity_information,PLM_error,"No module is present under **",NoModuleStr," please verify the SVR.");
										//return PLM_error;
									}

									tc_strcpy(TempVal,objectname); //Copying SVR Name first
									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,username);
									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,cCurrentAccessDate);
									tc_strcat(TempVal,"_Snapshot");

									printf("\n CM_CreateSnapShotfromSingleSVR--After inside bom_window----->  TempVal: [%s] \n",TempVal); fflush(stdout);

									if(BOM_window_apply_variant_configuration(bom_window,1,&rev));
									printf("\n CM_CreateSnapShotfromSingleSVR--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

									//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									if(BOM_window_hide_variants(bom_window))   ;
									if(BOM_create_snapshot(bom_window,TempVal,"Snapshot for SVR",&snapshot));
									if(snapshot!=NULLTAG)
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--SnapShot is created for [%s] \n",TempVal); fflush(stdout);
										if(AOM_save_without_extensions( snapshot));
										if(AOM_refresh(snapshot,1));
										if(AOM_unlock(snapshot));
									}
									else
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--snapshot Tag not found ?? \n\n");fflush(stdout);
									}

									if (VCrev != NULLTAG)
									{
										// to delete existing snapshot relation
										ITK_CALL(GRM_list_secondary_objects_only(VCrev,implemRelationType_t,&snapcnt,&extsnap));

										printf("\n CM_CreateSnapShotfromSingleSVR--snapcnt-----> [%d] \n",snapcnt); fflush(stdout);
										for(iy=0;iy<snapcnt;iy++)
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items\n");fflush(stdout);

											ITK_CALL(GRM_find_relation(VCrev,extsnap[iy],implemRelationType_t,&tRelationExistab11));

											if(tRelationExistab11 != NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--Now deleting Relation Between VC and old Snap-shot \n");fflush(stdout);
												ITK_CALL(GRM_delete_relation(tRelationExistab11));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation deleted Successfully\n");fflush(stdout);
											}
										}
										// end to delete existing snapshot relation

										if(implemRelationType_t != NULLTAG)
										{
											if(GRM_create_relation(VCrev,snapshot,implemRelationType_t,NULLTAG,&Rel_task));
											if(GRM_save_relation  (Rel_task));
										}


										if(derivedFromSVRRelType_ta != NULLTAG)
										{
											int iz = 0 , DerSvrcnt = 0;
											tag_t *DerSvrSet = NULLTAG;
											tag_t tRelationExistab11ss = NULLTAG;

											if(GRM_list_secondary_objects_only(VCrev,derivedFromSVRRelType_ta,&DerSvrcnt,&DerSvrSet));
											for(iz=0; iz<DerSvrcnt; iz++)
											{
												if(GRM_find_relation(VCrev,DerSvrSet[iz],derivedFromSVRRelType_ta,&tRelationExistab11ss));
												if(tRelationExistab11ss != NULLTAG)
												{
													printf("\n iz:[%d] CM_CreateCCVfromSingleSVR---Now deleting older Relation Between CCVVC/VC/Veh and SVR. \n",iz);fflush(stdout);
													if(GRM_delete_relation(tRelationExistab11ss));
													printf("\n iz:[%d] CM_CreateCCVfromSingleSVR---older SVR Relation deleted Successfully from CCVVC/VC/Veh. \n",iz);fflush(stdout);
												}
											}
											// end to delete existing svr relation

											ITK_CALL(GRM_find_relation(VCrev,rev,derivedFromSVRRelType_ta,&tRelationExista));
											if (tRelationExista==NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--3.Now Creating Relation Between CCV and SVR \n");fflush(stdout);
												if(GRM_create_relation(VCrev,rev,derivedFromSVRRelType_ta,NULLTAG,&Rel_taska));
												if(GRM_save_relation  (Rel_taska));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation Created Successfully\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--T5_DerivedFromSVR relation Tag not found ?? \n\n");fflush(stdout);
										}

										ITK_CALL(AOM_refresh(VCrev,0));
										ITK_CALL(AOM_unlock(VCrev));

										if(SVRDerRel_t != NULLTAG)
										{
											ITK_CALL(GRM_find_relation(rev,VCrev,SVRDerRel_t,&tRelationExistab));
											if (tRelationExistab==NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--Now Creating Relation Between SVR and CCV \n");fflush(stdout);
												if(GRM_create_relation(rev,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
												if(GRM_save_relation  (Rel_taskab));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation Created Successfully\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--T5_SVRDerivesCCV relation Tag not found ?? \n\n");fflush(stdout);
										}
									} //End of condn if (VCrev != NULLTAG)
									else
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--VCrev Tag not found ?? \n\n");fflush(stdout);
									}
								} // End of condn if(bom_window != NULLTAG)
							}
						}
					} //End of if (strcmp(objecttype,"VariantRule")==0)
				}
			}
		} //End of if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
	}

	//printf("\n -----Completed CM_CreateSnapShotfromSingleSVR function -------------------------\n");fflush(stdout);
	printf("\n CM_CreateSnapShotfromSingleSVR Function end...");fflush(stdout);
	TC_write_syslog("\n CM_CreateSnapShotfromSingleSVR Function end...");

	//return ITK_ok;
	return 0;
}
// create snapshot from single SVR end.

//Start--UA 1.64
int tm_CreateCCVCAndSnapSfrmSVRforCV(EPM_action_message_t msg)
{
	int ifail = 0;
	int attachmentCount=0 , taskcnt=0 ,ta = 0 , jy=0;
	int DMLSTVALUT = 0;
	int CVDML_n_entry = 1;
	int CVDML_rsltCount = 0;

	char *obj_type = NULL;
	char *DMLDRstatus = NULL;
	char *DMLDRStrT=NULL;
	char *DMLNo=NULL;
	char *CVDML_info1 = NULL;
	char *CVDML_info2 = NULL;
	char *CVDML_info3 = NULL;
	char *sCVProdPath =  NULL;

	char command[512];

	char *CVDML_qry_entry[1]  = {"SYSCD"};

	char **CVDML_qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t rootTask_t=NULLTAG;
	tag_t tsk_dml_rel_type=NULLTAG;
	tag_t DMLRevTag=NULLTAG;
	tag_t CVDMLQryTag = NULLTAG;

	tag_t *taskAttachments=NULLTAG;
	tag_t *DMLRevision= NULLTAG;
	tag_t *CVDML_CntrlObjectTag = NULLTAG;

	logical is_latest;
	printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV Function started...");fflush(stdout);
	TC_write_syslog("\n tm_CreateCCVCAndSnapSfrmSVRforCV Function started...");
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	printf("\n\n\t\t ----Start of function tm_CreateCCVCAndSnapSfrmSVRforCV--attachmentCount: %d ----------",attachmentCount);fflush(stdout);

	if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));

	if(attachmentCount > 0)
	{
		for(ta=0;ta<attachmentCount;ta++)
		{
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[ta],&obj_type));

			printf(" tm_CreateCCVCAndSnapSfrmSVRforCV--Object Type = %s ",obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{
				if (tsk_dml_rel_type!=NULLTAG)
				{
					if(GRM_list_primary_objects_only( taskAttachments[ta], tsk_dml_rel_type,&taskcnt,&DMLRevision));
					printf("\n\t tm_CreateCCVCAndSnapSfrmSVRforCV--DML Revision from Task: %d  ",taskcnt);fflush(stdout);

					for (jy=0;jy<taskcnt ;jy++ )
					{
						if(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));

						printf("\n\n\t\t is_latest DML Rev is : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\n\n\t\t is_latest DML Rev is not true .....\n");fflush(stdout);
						}
						else
						{
							DMLRevTag = DMLRevision[jy];

							if(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));

							if(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();

							DMLDRStrT=NULL;
							DMLSTVALUT=0;

							DMLDRStrT=subString(DMLDRstatus, 2, 1);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--DMLDRStrT: %s and ",DMLDRStrT);fflush(stdout);

							DMLSTVALUT=atoi(DMLDRStrT);
							printf("  DMLSTVALUT: %d \n",DMLSTVALUT);fflush(stdout);
						}
					}
				}

				if(QRY_find2("ControlObjects", &CVDMLQryTag));
				if (CVDMLQryTag != NULLTAG)
				{
					printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--Found Query ControlObjects \n");fflush(stdout);

					CVDML_qry_values2[0] = "CVDMLBOM";

					if(QRY_execute(CVDMLQryTag, CVDML_n_entry, CVDML_qry_entry, CVDML_qry_values2, &CVDML_rsltCount, &CVDML_CntrlObjectTag));

					if(CVDML_rsltCount > 0)
					{
						//ONOFF
						if (AOM_ask_value_string(CVDML_CntrlObjectTag[0],"t5_Userinfo1",&CVDML_info1)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--CVDMLQryTag:CVDML_info1 is.:[%s]\n", CVDML_info1);fflush(stdout);

						//CV DML Shell path
						if (AOM_ask_value_string(CVDML_CntrlObjectTag[0],"t5_Userinfo2",&CVDML_info2)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--CVDMLQryTag:CVDML_info2 is.:[%s]\n", CVDML_info2);fflush(stdout);

						//ProgPath
						if (AOM_ask_value_string(CVDML_CntrlObjectTag[0],"t5_Userinfo3",&CVDML_info3)!=ITK_ok)   PrintErrorStack();
						printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--CVDMLQryTag:CVDML_info3 is.:[%s]\n", CVDML_info3);fflush(stdout);
					}
				}
				else
				{
					printf("\n CVDMLQryTag:Not Found Query ControlObjects \n");fflush(stdout);
				}

				printf(" \n CVDMLQryTag:CVDML_rsltCount :%d:", CVDML_rsltCount); fflush(stdout);

				if(CVDML_rsltCount > 0)
				{
					if(tc_strstr(CVDML_info1,"CVDMLON") == NULL)
					{
						printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--%s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
						//need to update CV prod path.
						printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--UAPROD:DML no : %s and Path: ", DMLNo,CVDML_info2);fflush(stdout);
						if(tc_strstr(CVDML_info3,"ProgPath1") != NULL)
						{
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--A:path start.. \n");fflush(stdout);
							tc_strcpy(command,"");
							tc_strcpy(command,CVDML_info2);
							tc_strcat(command," ");
							tc_strcat(command,DMLNo);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--:command: %s",command);fflush(stdout);
							//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
							TC_write_syslog("Command = %s\n",command);
							system(command);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--A:path start successfully.. \n");fflush(stdout);
						}
						else if(tc_strstr(CVDML_info3,"ProgPath2") != NULL)
						{
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--B:path start start.. \n");fflush(stdout);
							sCVProdPath = (char *)MEM_alloc(500);
							tc_strcpy(sCVProdPath,"");
							tc_strcpy(sCVProdPath,CVDML_info2);
							tc_strcat(sCVProdPath," ");
							tc_strcat(sCVProdPath,DMLNo);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--B:command: %s",sCVProdPath);fflush(stdout);
							//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
							TC_write_syslog("sCVProdPath = %s\n",sCVProdPath);
							system(sCVProdPath);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--B:path start successfully.. \n");fflush(stdout);
						}
						else if(tc_strstr(CVDML_info3,"ProgPath3") != NULL)
						{
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--C:path start start.. \n");fflush(stdout);
							sCVProdPath = (char *)MEM_alloc(500);
							tc_strcpy(sCVProdPath,"");
							tc_strcpy(sCVProdPath,CVDML_info2);
							tc_strcat(sCVProdPath," ");
							tc_strcat(sCVProdPath,DMLNo);
							tc_strcat(sCVProdPath," ");
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--C:command: %s",sCVProdPath);fflush(stdout);
							//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
							TC_write_syslog("sCVProdPath = %s\n",sCVProdPath);
							system(sCVProdPath);
							printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV--C:path start successfully.. \n");fflush(stdout);
						}
					}
				} //End of if(CVDML_rsltCount > 0)
			}
		} //for loop
	} //if(attachmentCount > 0)

	//printf("\n -----Completed tm_CreateCCVCAndSnapSfrmSVRforCV function -------------------------\n");fflush(stdout);
	printf("\n tm_CreateCCVCAndSnapSfrmSVRforCV Function end...");fflush(stdout);
	TC_write_syslog("\n tm_CreateCCVCAndSnapSfrmSVRforCV Function end...");

	//return ifail;
	return 0;
}
//End--UA 1.64

//Start--UA 1.65
int isVCCreateLiveForAtrozWay(tag_t *contrlTag, logical *result , tag_t dmlRevTag )
{
	int ifail = ITK_ok;
	int  count = 0;
	int  taskcnt = 0 , ti=0 , refcnt=0, ri=0;

	*result = FALSE;

	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	tag_t *contrlObjs = NULLTAG;
	tag_t *Dml_tasks = NULLTAG;
	tag_t *VariantList = NULLTAG;

	tag_t DMLToTaskReln = NULLTAG;
	tag_t CMReferencesRelType = NULLTAG;
	tag_t query = NULLTAG;

	char *Vobjecttype = NULL;
	char *SVRName = NULL;
	char *object_type = NULL;
	char *VCNo = NULL;

	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";

	qry_values[0] = "Hornbill_Way_VC";
	qry_values[1] = "Hornbill_Way";
	qry_values[2] = "FALSE";

	printf("\n isVCCreateLiveForAtrozWay Function started...");fflush(stdout);
	TC_write_syslog("\n isVCCreateLiveForAtrozWay Function started...");
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\n Veh-Release--Control objects Hornbill_Way_VC-count==> [%d] ", count);fflush(stdout);

	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		tag_t VariantTag = NULLTAG;

		cntrlObj = contrlObjs[0];
		//char* usrInfo3 = NULL;

		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskReln));
		ITK_CALL(GRM_find_relation_type("CMReferences",&CMReferencesRelType));

		ITK_CALL(GRM_list_secondary_objects_only(dmlRevTag,DMLToTaskReln, &taskcnt, &Dml_tasks));

		printf("\n Veh-Release--taskcnt :%d ",taskcnt);fflush(stdout);

		if (taskcnt>0)
		{
			for (ti=0;ti<taskcnt ;ti++ )
			{
				ITK_CALL(AOM_ask_value_string(Dml_tasks[ti],"object_type",&object_type));
				printf("\n Veh-Release--object_type is :%s\n",object_type);fflush(stdout);

				if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
				{
					if(CMReferencesRelType != NULLTAG)
					{
						ITK_CALL(GRM_list_secondary_objects_only(Dml_tasks[ti],CMReferencesRelType,&refcnt,&VariantList));

						printf("\n Veh-Release--to find impacted items  CMReference-RelCount: [%d] \n",refcnt);fflush(stdout);

						if(cntrlObj!=NULLTAG)
						{
							char* Info1Str = NULL;
							char* Info2Str = NULL;
							char* Info3Str = NULL;
							char* Info4Str = NULL;
							char* Info5Str = NULL;
							char* Info6Str = NULL;
							char* Info7Str = NULL;
							char* Info8Str = NULL;
							char* Info9Str = NULL;
							char* Info10Str = NULL;

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&Info1Str));
							printf("\n Veh-Release--Info1Str: [%s]", Info1Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&Info2Str));
							printf("\n Veh-Release--Info2Str: [%s]", Info2Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&Info3Str));
							printf("\n Veh-Release--Info3Str: [%s]", Info3Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&Info4Str));
							printf("\n Veh-Release--Info4Str: [%s]", Info4Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&Info5Str));
							printf("\n Veh-Release--Info5Str: [%s]", Info5Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&Info6Str));
							printf("\n Veh-Release--Info6Str: [%s]", Info6Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&Info7Str));
							printf("\n Veh-Release--Info7Str: [%s]", Info7Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&Info8Str));
							printf("\n Veh-Release--Info8Str: [%s]", Info8Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&Info9Str));
							printf("\n Veh-Release--Info9Str: [%s]", Info9Str);fflush(stdout);

							if(AOM_ask_value_string(cntrlObj,"t5_Userinfo10",&Info10Str));
							printf("\n Veh-Release--Info10Str: [%s]", Info10Str);fflush(stdout);


							for(ri=0;ri<refcnt;ri++)
							{
								VariantTag = VariantList[ri];

								if(AOM_ask_value_string(VariantTag,"object_type",&Vobjecttype));
								printf("\n\n Veh-Release--Vobjecttype: [%s] ", Vobjecttype);fflush(stdout);

								if (strcmp(Vobjecttype,"VariantRule")==0)
								{
									if(AOM_ask_value_string(VariantTag,"object_name",&SVRName));
									printf(" --SVRName: [%s] ", SVRName);fflush(stdout);

									VCNo = tc_strtok(SVRName,"_");
									printf(" --VCNo: [%s] ", VCNo);fflush(stdout);

									if(cntrlObj!=NULLTAG)
									{
										if ((tc_strstr(Info1Str,VCNo)!=NULL)||(tc_strstr(Info2Str,VCNo)!=NULL)
											||(tc_strstr(Info3Str,VCNo)!=NULL)||(tc_strstr(Info4Str,VCNo)!=NULL)
											||(tc_strstr(Info5Str,VCNo)!=NULL)||(tc_strstr(Info6Str,VCNo)!=NULL)
											||(tc_strstr(Info7Str,VCNo)!=NULL)||(tc_strstr(Info8Str,VCNo)!=NULL)
											||(tc_strstr(Info9Str,VCNo)!=NULL)||(tc_strstr(Info10Str,VCNo)!=NULL)
										   )
										{
											*result = TRUE;
											*contrlTag = cntrlObj;
											printf("\nVeh-Release--isVCCreateLiveForAtrozWay---VC Creation is Live in Hornbill-way....\n");fflush(stdout);
										}
										else
										{
											printf("\nVeh-Release--isVCCreateLiveForAtrozWay---VC Creation is Live in Atroz-way....\n");fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	//printf("\nVeh-Release--isVCCreateLiveForAtrozWay process completed....\n");fflush(stdout);
	printf("\n isVCCreateLiveForAtrozWay Function end...");fflush(stdout);
	TC_write_syslog("\n isVCCreateLiveForAtrozWay Function end...");

	//return ifail;
	return 0;
}

int tm_IsAtrozWayCreateVC(EPM_action_message_t  msg)
{
	const char *prog_name ="tm_IsAtrozWayCreateVC";

	int ifail = ITK_ok;
	int targetobjects_count = 0;
	int moduleCnt = 0 , n_entries = 0 ;
	int TaskPrimObjCnt = 0 , zk2=0 ;

	logical HornbilLiveFlag = FALSE;
	logical AltrozliveFlag = FALSE;

	char *dmlString = NULL;
	char* dmlReleaseType = NULL;
	char* dmlProject = NULL;
	char *usrInfo2R=NULL;
	char *class_nameR2=NULL;

	tag_t cntrlObj = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t DMLTaskTag=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t queryProject = NULLTAG;
	tag_t Taskclass_id = NULLTAG;
	tag_t TaskRelType = NULLTAG;

	tag_t* targetobjects = NULLTAG;
	tag_t *TaskPrimObjstag = NULLTAG;

	logical is_latest;
	printf("\n tm_IsAtrozWayCreateVC Function started...");fflush(stdout);
	TC_write_syslog("\n tm_IsAtrozWayCreateVC Function started...");
	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment, &targetobjects_count, &targetobjects));

	if(targetobjects_count > 0)
	{
		printf("\ntm_IsAtrozWayCreateVC--Veh-Release--Root task found..");fflush(stdout);
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		char* type_name=NULL;

		for(i=0;i<targetobjects_count;i++)
		{
			CALLAPI(TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag));
			CALLAPI(TCTYPE_ask_name2( objectTypeTag,&type_name));
			printf("\ntm_IsAtrozWayCreateVC--Veh-Release--type_name ==> %s  ", type_name);fflush(stdout);

			if (tc_strcmp(type_name,"T5_ChangeTaskRevision")==0)
			{
				DMLTaskTag = targetobjects[i];

				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &TaskRelType));
				if(GRM_list_primary_objects_only(DMLTaskTag, TaskRelType ,&TaskPrimObjCnt,&TaskPrimObjstag));
				printf("  TaskPrimObjCnt: %d ",TaskPrimObjCnt);fflush(stdout);

				for(zk2=0; zk2<TaskPrimObjCnt; zk2++)
				{
					ITKCALL(ITEM_rev_sequence_is_latest(TaskPrimObjstag[zk2],&is_latest));
					printf("\n\n\t\t tm_IsAtrozWayCreateVC--is_latest : %d\n",is_latest);fflush(stdout);

					if(is_latest != true)
					{
						printf("\n\n tm_IsAtrozWayCreateVC--Not latest DML Revision.....\n");fflush(stdout);
					}
					else
					{
						DMLTag = TaskPrimObjstag[zk2];
					}
				}

				if (DMLTag != NULLTAG)
				{
					CALLAPI(AOM_ask_value_string(DMLTag,"object_string",&dmlString));
					CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&dmlReleaseType));
					CALLAPI(AOM_ask_value_string(DMLTag,"t5_cprojectcode",&dmlProject));
				}
				printf("\n tm_IsAtrozWayCreateVC--Veh-Release--DML: [%s] ReleaseType:%s===>%s\n",dmlString,dmlReleaseType);fflush(stdout);

				if(tc_strcmp(dmlReleaseType,"Veh")==0)
				{
					printf("\t --VC-DML"); fflush(stdout);
					CALLAPI(isVCCreateLiveForAtrozWay(&cntrlObj,&HornbilLiveFlag, DMLTag));

					printf("\n\n A.tm_IsAtrozWayCreateVC--Veh-Release--A.HornbilLiveFlag: [%d] ===> From VC-Control-Object....",HornbilLiveFlag);fflush(stdout);

					if(HornbilLiveFlag)
					{
						//HornbilLiveFlag=FALSE;
						printf("\t HornbilLive Root....");fflush(stdout);
						return 0; //for hornbill-Root is false condition
					}
					else
					{
						printf("\n tm_IsAtrozWayCreateVC--Veh-Release--SVR-VC NOT Live for Hornbil-way to create-VC so Validating for Altroz-way....");fflush(stdout);

						char *qry_entriesR[] = { "SYSCD","SUBSYSCD"}, *qry_valuesR[] = {"Project","AltrozWay"};
						int noOfCoObjectsR = 0;
						tag_t queryR = NULLTAG;
						tag_t *CoobjectsR = NULLTAG;
						char *usrInfo1R = NULL;
						char *projStr = NULL;

						usrInfo1R = (char *) MEM_alloc(250);

						tc_strcpy(usrInfo1R,"");

						ITK_CALL(QRY_find2("Control Objects...", &queryR));
						if (queryR !=NULLTAG)
						{
							printf("\n tm_IsAtrozWayCreateVC--Veh-Release--queryR found");fflush(stdout);
							ITK_CALL(QRY_execute(queryR,2, qry_entriesR, qry_valuesR, &noOfCoObjectsR, &CoobjectsR));
							printf("\n\n tm_IsAtrozWayCreateVC--Veh-Release--Total Number Of CoobjectsR Found ==[%d] \n",noOfCoObjectsR);fflush(stdout);

							if(noOfCoObjectsR>0)
							{
								ITK_CALL(AOM_ask_value_string(CoobjectsR[0],"t5_Userinfo1",&usrInfo1R));
								printf("\n tm_IsAtrozWayCreateVC--Veh-Release--dmlProject: [%s] usrInfo1R :[%s]\n",dmlProject,usrInfo1R);fflush(stdout);
								ITK_CALL(AOM_ask_value_string(CoobjectsR[0],"t5_Userinfo2",&usrInfo2R));
								printf("\n tm_IsAtrozWayCreateVC:usrInfo2R :[%s]\n",usrInfo2R);fflush(stdout);

								if ((tc_strstr(usrInfo1R,dmlProject)!=NULL)&&(usrInfo1R!=NULL)) //allowing if project made live in control-object
								{
									printf("\t ---Project-Live-Found-- ");fflush(stdout);
									if (tc_strstr(usrInfo2R,"ALT001")==NULL)
									{
										printf("\t send 1 zero.. ");fflush(stdout);
										return 0;
									}
									else
									{
										printf("\t send 2 zero.. ");fflush(stdout);
										AltrozliveFlag = TRUE;
										return AltrozliveFlag;
									}
								}
							}
							printf("\t --1--AltrozliveFlag: [%d] \n",AltrozliveFlag);fflush(stdout);

							if (!AltrozliveFlag)
							{
								EMH_store_error_s1(EMH_severity_error,PLM_error,"ERC-DML Projectcode is not live. Please raise ticket in TMS TCUA-DML category.");
								printf("\n tm_IsAtrozWayCreateVC--Veh-Release--ERC-DML Projectcode [%s] is not live. Please raise ticket in TMS TCUA-DML category.\n",dmlProject);fflush(stdout);
								return(PLM_error);
							}
						}
					}
				}

				printf("\n B.tm_IsAtrozWayCreateVC--Veh-Release--B.HornbilLiveFlag: [%d]  AltrozliveFlag: [%d]",HornbilLiveFlag,AltrozliveFlag);fflush(stdout);

				break;
			}
		}
	}

	printf("\n tm_IsAtrozWayCreateVC Function end...");fflush(stdout);
	TC_write_syslog("\n tm_IsAtrozWayCreateVC Function end...");

	return AltrozliveFlag;
}
//End--UA 1.65
