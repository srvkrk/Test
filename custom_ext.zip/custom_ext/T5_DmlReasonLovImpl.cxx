//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object T5_DmlReasonLovImpl
//

#include <T5_tm_dmlreasonlov/T5_DmlReasonLov.hxx>
#include <T5_tm_dmlreasonlov/T5_DmlReasonLovImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <pom/pom/pom_errors.h>
#include <pom/pom/pom.h>
#include <mld/journal/journal.h>
#include <base_utils/ResultCheck.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Mem.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <ug_va_copy.h>
#include <sa/user.h>
#include <pom/enq/enq.h>
#include <tccore/aom_prop.h>
#include <qry/qry.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <property/propdesc.h>
#include <lov/lov.h>
#include <tccore/tctype.h>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <extensionframework/OperationDispatcherRegistry.hxx>
#include <tccore/grm.h>
#include <tccore/grmtype.h>

#define PLM_error1 (EMH_USER_error_base+26)

using namespace TRL001;

//----------------------------------------------------------------------------------
// T5_DmlReasonLovImpl::T5_DmlReasonLovImpl(T5_DmlReasonLov& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
T5_DmlReasonLovImpl::T5_DmlReasonLovImpl( T5_DmlReasonLov& busObj )
   : T5_DmlReasonLovGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// T5_DmlReasonLovImpl::~T5_DmlReasonLovImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
T5_DmlReasonLovImpl::~T5_DmlReasonLovImpl()
{
}

//----------------------------------------------------------------------------------
// T5_DmlReasonLovImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int T5_DmlReasonLovImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = T5_DmlReasonLovGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

int getDMLReasonValue(const char *BussUnit, const char *releasetype, const char *DmlVClassfctn, const char *DmlDRStatus, int* count, tag_t** items)
{
        int ifail = ITK_ok;
        tag_t imanren_reltag=NULLTAG;
        *count = 0;
        tag_t* itemsRev =NULLTAG;

        int* count1=0;
        tag_t* items1=NULLTAG;
        int    	num_to_sort =	1;
        char 	*keys[1] 	= 	{(char *)"t5_Userinfo3"};
        int  	orders[1]  	=	{1};

        char *item_id = NULL;
        tag_t  query    = NULLTAG;
        tag_t  *t_item1 = NULLTAG;
        int             n_found = 0;
        char *DRqry = NULL;
        DRqry=(char *)MEM_alloc(100);




        printf("\n\n getDMLReasonValue::BussUnit==%s \n",BussUnit);fflush(stdout);
        printf("\n\n getDMLReasonValue::releasetype==%s \n",releasetype);fflush(stdout);
        printf("\n\n getDMLReasonValue::DmlVClassfctn==%s \n",DmlVClassfctn);fflush(stdout);
        printf("\n\n getDMLReasonValue::DmlDRStatus==%s \n",DmlDRStatus);fflush(stdout);
        tc_strcpy(DRqry,"");
		tc_strcat(DRqry,"*");
		tc_strcat(DRqry,DmlDRStatus);
		tc_strcat(DRqry,"*");
		printf("\n getDMLReasonValue::DR to Qry == [%s]\n",DRqry); fflush(stdout);



        ///"SUBSYSCD"
        //char
        //*qry_entries3[2]         = {(char *)"SYSCD",(char *)"SUBSYSCD"},
        //*qry_values3[2]      = {"DMLReason",(char *)BussUnit};

        char	*dmlreasonqry_entries[] = {(char *)"SYSCD", (char *)"SUBSYSCD"};
        char	*dmlreasonqry_values[] = {(char *)"DMLReason",(char *)BussUnit};

        char	*dmlreasonqry_DRqryentries[] = {(char *)"SYSCD", (char *)"SUBSYSCD",(char *)"Information-1",(char *)"Information-2"};
        char	*dmlreasonqry_DRqryvalues[] = {(char *)"DMLReason",(char *)BussUnit,(char *)DmlVClassfctn,(char *)DRqry};

        char	*dmlreasonqry_entries_othercvbu[] = {(char *)"SYSCD"};
        char	*dmlreasonqry_values_othercvbu[] = {(char *)"DMLReason"};


        if (tc_strcmp(BussUnit,"PVBU") == 0 ||
        			tc_strcmp(BussUnit,"PV-PSE") == 0 ||
        			tc_strcmp(BussUnit,"PV-Transmission") == 0 ||
        			tc_strcmp(BussUnit,"PV-AdvTech") == 0 ||
        			tc_strcmp(BussUnit,"PV-AdvEng") == 0 ||
        			tc_strcmp(BussUnit,"CV-PSE") == 0 ||
        			tc_strcmp(BussUnit,"CV-Transmission") == 0 ||
        			tc_strcmp(BussUnit,"CV-AdvTech") == 0 ||
        			tc_strcmp(BussUnit,"CV-AdvEng") == 0)
        {
        	printf("\n\n getDMLReasonValue::Rows333==%s \n",BussUnit);fflush(stdout);
			QRY_find2("Control Objects...", &query);
			printf("\n\n getDMLReasonValue::Rows444==%s \n",BussUnit);fflush(stdout);

			//dmlreasonqry_values[1] = BussUnit;

			//QRY_execute(query, 2, dmlreasonqry_entries, dmlreasonqry_values, &n_found, &t_item1);
			QRY_execute_with_sort(query, 2, dmlreasonqry_entries, dmlreasonqry_values, num_to_sort, keys, orders, &n_found, &t_item1);
			printf("\n\n getDMLReasonValue::Rows555==%s %d\n",BussUnit,n_found);fflush(stdout);
			*count = n_found;


			printf("\n\n getDMLReasonValue::Rows1000 VAL= %d\n",*count);fflush(stdout);
			(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
			int i=0;
			for(i=0;i<*count;i++)
					{
							(*items)[i] = t_item1[i];
					}
        }
        else if (tc_strcmp(BussUnit,"CVBU")==0)
        {
        	if(tc_strcmp(releasetype,"TODR")==0
        			|| tc_strcmp(releasetype,"EP")==0
        			|| tc_strcmp(releasetype,"DL")==0
					|| tc_strcmp(releasetype,"KSP")==0
					|| tc_strcmp(releasetype,"SP")==0
					|| tc_strcmp(releasetype,"VOD")==0
					|| tc_strcmp(releasetype,"CP")==0
					|| tc_strcmp(releasetype,"CM")==0
					|| tc_strcmp(releasetype,"TS")==0
					|| tc_strcmp(releasetype,"WT")==0
					|| tc_strcmp(releasetype,"WO")==0
					|| tc_strcmp(releasetype,"VCMDU")==0
					|| tc_strcmp(releasetype,"COL")==0
					|| tc_strcmp(releasetype,"SPIUP")==0
					|| tc_strcmp(releasetype,"COL")==0)
        	{
        		printf("\n getDMLReasonValue::CVBU::Rows333==%s \n",BussUnit);fflush(stdout);
				QRY_find2("Control Objects...", &query);
				printf("\n\n getDMLReasonValue::CVBU::Rows444==%s \n",BussUnit);fflush(stdout);
				//dmlreasonqry_values[1] = BussUnit;

				//QRY_execute(query, 2, dmlreasonqry_entries, dmlreasonqry_values, &n_found, &t_item1);
				QRY_execute_with_sort(query, 2, dmlreasonqry_entries, dmlreasonqry_values, num_to_sort, keys, orders, &n_found, &t_item1);
				printf("\n\n getDMLReasonValue::CVBU::Rows555==%s %d\n",BussUnit,n_found);fflush(stdout);
				*count = n_found;


				printf("\n\n getDMLReasonValue::CVBU::Rows1000 VAL= %d\n",*count);fflush(stdout);
				(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
				int i=0;
				for(i=0;i<*count;i++)
						{
								(*items)[i] = t_item1[i];
						}
        	}
        	else
        	        {
        	        	//tc_strcpy(DRqry,"");
        	        	//tc_strcat(DRqry,"*");
        	        	//tc_strcat(DRqry,DmlDRStatus);
        	        	//tc_strcat(DRqry,"*");
        	        	printf("\n getDMLReasonValue::DR to Qry == [%s]\n",BussUnit); fflush(stdout);
        	        	printf("\n getDMLReasonValue::DR to Qry == [%s]\n",DmlVClassfctn); fflush(stdout);
        	        	printf("\n getDMLReasonValue::DR to Qry == [%s]\n",DRqry); fflush(stdout);

        				QRY_find2("Control Objects...", &query);

        				//QRY_execute(query, 4, dmlreasonqry_DRqryentries, dmlreasonqry_DRqryvalues, &n_found, &t_item1);
        				QRY_execute_with_sort(query, 4, dmlreasonqry_DRqryentries, dmlreasonqry_DRqryvalues, num_to_sort, keys, orders, &n_found, &t_item1);
        				printf("\n\n getDMLReasonValue::CVBU::DR:Rows555==%s %d\n",BussUnit,n_found);fflush(stdout);
        				*count = n_found;


        				printf("\n\n getDMLReasonValue::CVBU::DR:Rows1000 VAL= %d\n",*count);fflush(stdout);
        				(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
        				int i=0;
        				for(i=0;i<*count;i++)
        						{
        								(*items)[i] = t_item1[i];
        						}
        	        }
        }
        else
        {
        	printf("\n\n getDMLReasonValue::Rows333==%s \n",BussUnit);fflush(stdout);
        	QRY_find2("Control Objects...", &query);
        	printf("\n\n getDMLReasonValue::Rows444==%s \n",BussUnit);fflush(stdout);
			//QRY_execute(query, 1, dmlreasonqry_entries_othercvbu, dmlreasonqry_values_othercvbu, &n_found, &t_item1);
			QRY_execute_with_sort(query, 1, dmlreasonqry_entries_othercvbu, dmlreasonqry_values_othercvbu, num_to_sort, keys, orders, &n_found, &t_item1);
        	printf("\n\n getDMLReasonValue::Rows555==%s %d\n",BussUnit,n_found);fflush(stdout);
        	*count = n_found;


        	printf("\n\n getDMLReasonValue::Rows1000 VAL= %d\n",*count);fflush(stdout);
        	(*items) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*count));
        	int i=0;
        	for(i=0;i<*count;i++)
        	{
        		(*items)[i] = t_item1[i];
        	}
        }






                return ifail;
}
char *removeSpaces(char *str)
{
    int i = 0, j = 0;
    while (str[i])
    {
        if (str[i] != ' ')
           str[j++] = str[i];
        i++;
    }
    str[j] = '\0';
    return str;
}



///
/// Returns List Of Values based on Dynamic LOV definition and user search criteria.
/// @param operationInputTag - Operation Input containing the modified values.
/// @param propertyName - Name of the selected property.
/// @param searchString - User entered search string.
/// @param sortByProp - Property to use for sorting.
/// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
/// @param nResults - Number of returned results.
/// @param results - Returned Values for LOV.
/// @return - Zero (0) if everything is alright otherwise the error code.
///
int  T5_DmlReasonLovImpl::fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const
{
    int ifail = ITK_ok;

        bool isNull=false;
        bool isNull1=false;
        bool isNull2=false;
        bool isNull3=false;
        bool isNull4=false;
        bool isNull5=false;
        char *BussUnit = NULL;
        char *DRStatus1 = NULL;
        char *DRStatus = NULL;
        char *drstatus = NULL;
        char *ErrorMessage = NULL;
        	std::string obj_val;
        	std::string obj_val1;
        	std::string obj_val2;
        	std::string obj_val3;
        	std::string obj_val4;
        	std::string obj_val5;

        	//sortOrder=0;
        	int error_flag = 0;
        	*nResults=0;
        	(*results)=NULLTAG;
        	//(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
        	printf("\n--->>>>> T5_DmlReasonLovImpl::In NOT NULL 11111111");fflush(stdout);
        	BussUnit=(char *)MEM_alloc(100);
        	drstatus =(char *)MEM_alloc(100);
        	ErrorMessage = (char *)MEM_alloc(300);

        	if( JOURNAL_is_journaling() )
        		        {
        		            //JOURNAL_routine_start( "T5_DMLReasonCodeLOVImpl::fnd0askLOVValuesBase" );
        		            JOURNAL_routine_start( "T5_DmlReasonLovImpl::fnd0askLOVValuesBase" );
        		           // JOURNAL_address_in( impl );
        		            JOURNAL_routine_call();
        		        }

    // Call the parent Implementation
    ifail = super_fnd0askLOVValuesBase(  operationInputTag, propertyName, searchString, sortByProp, sortOrder, nResults, results );

    // Your Implementation

    printf("\n  T5_DmlReasonLov Starting Testing !!!>>\n");fflush(stdout);
        						try
            	                {
            	            //  list_displayable_properties_with_value(operationInputTag);
            	                        Teamcenter::OperationInput* refOprtnInput = dynamic_cast< Teamcenter::OperationInput* >
            	                        (Teamcenter::BusinessObjectRegistry::instance().getObject( operationInputTag ));
            	                        if( refOprtnInput!=NULL )
            	                        {
            	                                refOprtnInput->getString("t5_ERCBusiUt", obj_val, isNull ); ///get properties from the object
            	                                refOprtnInput->getString("t5_rlstype", obj_val1, isNull1 ); ///get properties from the object
            	                                refOprtnInput->getString("t5_DmlVClassfctn", obj_val2, isNull2 ); ///get properties from the object
            	                                refOprtnInput->getString("t5_cDRstatus", obj_val3, isNull3 ); ///get properties from the object
            	                                refOprtnInput->getString("t5_cprojectcode", obj_val4, isNull4 ); ///get properties from the object

            	                                tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Reason!\n"); ///ashwani

            	                                if(isNull4==true)
            	                                {

            	                                	error_flag++;
            	                                	tc_strcat(ErrorMessage,"Project Code");
            	                                	//EMH_clear_errors();
            	                                	//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Project Code First!!");
            	                                	//(*results)=NULLTAG;
            	                                	//*nResults=0;
            	                                	//return ITK_err;
            	                                }
            	                                if(isNull1==true)
            	                                {
            	                                	error_flag++;
            	                                	tc_strcat(ErrorMessage,",Release Type");
            	                                	//EMH_clear_errors();
    												//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Release Type First.!!");
    												//(*results)=NULLTAG;
    												//*nResults=0;
    												//return ITK_err;
            	                                }
            	                                if(isNull1==false)
            	                                {
            	                                	if(tc_strcmp(obj_val1.c_str(),"TODR")==0)
            	                                	{
            	                                		refOprtnInput->getString("t5_PlntToPlnt", obj_val5, isNull5 ); ///get properties from the object
            	                                		printf("\n--->>>>> T5_DmlReasonLov::PlntToPlnt ======>[%s] >>\n",obj_val5.c_str());fflush(stdout);
            	                                		tc_strcpy(drstatus,obj_val5.c_str());
            	                                		removeSpaces(drstatus);
            	                                		printf("\n--->>>>> T5_DmlReasonLov::drstatus ======>[%s] >>\n",drstatus);fflush(stdout);
            	                                		DRStatus1=tc_strtok(drstatus,"o");
            	                                		DRStatus = tc_strtok(NULL,"o");
            	                                		printf("\n--->>>>> T5_DmlReasonLov::DRStatus1 ======>[%s] >>\n",DRStatus1);fflush(stdout);
            	                                		printf("\n--->>>>> T5_DmlReasonLov::DR/AR ======>[%s] >>\n",DRStatus);fflush(stdout);
            	                                		if(isNull5==true)
            	                                		{
            	                                			error_flag++;
            	                                			tc_strcat(ErrorMessage,",Part Status/Site change [From-To]");
            	                                			//EMH_clear_errors();
            	                                			//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Part Status/Site change [From-To] First.!!");
            	                                			//(*results)=NULLTAG;
            	                                			//*nResults=0;
            	                                			//return ITK_err;
            	                                		}
            	                                	}

            	                                }
            	                                if(isNull3==true)
            	                                {
            	                                	error_flag++;
            	                                	tc_strcat(ErrorMessage,",DR Status");
            	                                	//EMH_clear_errors();
    												//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select DR/AR First.!!");
    												//(*results)=NULLTAG;
    												//*nResults=0;
    												//return ITK_err;
            	                                }

            	                                if(isNull==false)
            	                                {
            	                                	printf("\n--->>>>> T5_DmlReasonLov::In NOT NULL 11111111 %s >>\n",obj_val.c_str());fflush(stdout);
            	                                	if(tc_strcmp(obj_val.c_str(),"PV-Advanced Technology")==0)
            	                                	{
            	                                		tc_strcpy(BussUnit,"PV-AdvTech");
            	                                	}
            	                                	else if(tc_strcmp(obj_val.c_str(),"CV-Advanced Technology")==0)
    												{
    													tc_strcpy(BussUnit,"CV-AdvTech");
    												}
            	                                	else if(tc_strcmp(obj_val.c_str(),"PV-Advanced Engineering")==0)
    												{
    													tc_strcpy(BussUnit,"PV-AdvEng");
    												}
            	                                	else if(tc_strcmp(obj_val.c_str(),"CV-Advanced Engineering")==0)
    												{
    													tc_strcpy(BussUnit,"CV-AdvEng");
    												}
            	                                	else
            	                                	{
            	                                		tc_strcpy(BussUnit,obj_val.c_str());
            	                                	}
            	                                	printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",BussUnit);fflush(stdout);
            	                                	printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val1.c_str());fflush(stdout);
            	                                	printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val2.c_str());fflush(stdout);
            	                                	printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val3.c_str());fflush(stdout);
            	                                	printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val4.c_str());fflush(stdout);

            	                                	if(tc_strcmp(BussUnit,"CVBU")==0)
            	                                	{
            	                                		if(isNull2==true)
            	                                		{
            	                                			printf("\n--->>>>> DmlVClassfctn [%s] >>\n",obj_val2.c_str());fflush(stdout);
            	                                			error_flag++;
            	                                			tc_strcat(ErrorMessage,",Vehicle Classification");
            	                                			//EMH_clear_errors();
            	                                			//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please select DML Vehicle Classification!!");
            	                                			//(*results)=NULLTAG;
            	                                			//*nResults=0;
            	                                			//return ITK_err;

            	                                		}
            	                                	}
            	                                	//printf("\n Before Call T5_DmlReasonLov::getDMLReasonValue");fflush(stdout);
            	                                	//(*results)=NULLTAG;
            	                                	//*nResults=0;
            	                                	//(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
            	                                	//getDMLReasonValue(BussUnit,obj_val1.c_str(),obj_val2.c_str(),obj_val3.c_str(),nResults, results);
            	                                	//printf("\n After Call T5_DmlReasonLov::getDMLReasonValue");fflush(stdout);
            	                                }

            	                                else
            	                                {
            	                                        printf("\n--->>>>> T5_DmlReasonLov::In  NULL 11111111");fflush(stdout);
            	                                        error_flag++;
            	                                        tc_strcat(ErrorMessage,",Business Unit");
            	                                        //EMH_clear_errors();
            	                                        //EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Select Business Unit First!!");
            	                                        //(*results)=NULLTAG;
            	                                        //*nResults=0;
            	                                        //return ITK_err;
            	                                        //*nResults=0;
            	                                }
            	                                printf("\n error_flag [%d] >>\n",error_flag);fflush(stdout);
            	                                if(error_flag>0)
            	                                {
            	                                	//tc_strcpy(ErrorMessage,"Please select Below Required Fields before Click Reason!\n");
            	                                	//tc_strcat(ErrorMessage,"Project Code,Release Type,Business Unit,Vehicle Classification,DR Status,Part Status/Site change [From-To]");
            	                                	EMH_clear_errors();
            	                                	EMH_store_error_s2(EMH_severity_error,PLM_error1,"Message-",ErrorMessage);
            	                                	(*results)=NULLTAG;
            	                                	*nResults=0;
            	                                	return(PLM_error1);
            	                                }
            	                                if(error_flag==0)
            	                                {
            	                                	printf("\n Before Call T5_DmlReasonLov::getDMLReasonValue");fflush(stdout);
            	                                	printf("\nGiven Business Unit -->[%s] >>\n",BussUnit);fflush(stdout);
													printf("\nGiven Release Type  -->[%s] >>\n",obj_val1.c_str());fflush(stdout);
													printf("\nGiven VehClassification  -->[%s] >>\n",obj_val2.c_str());fflush(stdout);
													printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val3.c_str());fflush(stdout);
													printf("\n--->>>>> In NOT NULL 11111111 %s >>\n",obj_val4.c_str());fflush(stdout);
													(*results)=NULLTAG;
													*nResults=0;
													(*results) = (tag_t *) MEM_alloc(sizeof(tag_t)*(*nResults));
													getDMLReasonValue(BussUnit,obj_val1.c_str(),obj_val2.c_str(),obj_val3.c_str(),nResults, results);
													printf("\n After Call T5_DmlReasonLov::getDMLReasonValue");fflush(stdout);
            	                                }
            	                        }
            	                        else
    									{
            	                        	printf("\n--->>>>> T5_DmlReasonLov::In  NULL refinputtag");fflush(stdout);
    									}

            	                   }
    								catch( const IFail& ex )
    								{
    								   ifail = ex.ifail();
    								}

    return ifail;
}
