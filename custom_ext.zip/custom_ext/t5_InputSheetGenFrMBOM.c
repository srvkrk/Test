/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename             :       t5_UplMbom.c
*
* Description   : > This register custom user service. Implemented Custom ITK functions for generating UPLMBOM Object and Reports.
*                                 > This ITK functions are called in Rich Client
* Module
* Since             :   28-11-2022
* ENVIRONMENT   :   C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                                                                   Description of Change
* 18/01/2024     Sandeep Goyal/Abineswar Bisoi                      Base Code
*
* -----------------------------------------------------------------------------
*
*****************************************************************************/

#
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pie/pie.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>




#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

/*Global Declaration of Attribute required for Input Sheet Generation of MBOM*/
char        *BomGenMakeBuyInd     =   NULL;
char        *PartDesc             =   NULL;
char        *GenMakeBuyInd        =   NULL;
char        *GenPlantLCState      =   NULL;
char        *GenPlantLCStateStd   =   NULL;
char        *GetPlantStore        =   NULL;
char 	    *InputPart			  =	NULL;
char 	    *InputPartSeq	      =	NULL;
char 	    *InputPartRev	      =	NULL;
char 	    *ClosureRule	      =	NULL;
char 	    *ClosureRev	          =	NULL;
char 	    *PlantName	          =	NULL;
char 	    *InputView            =	NULL;
char        *timestamp            = NULL;
char 	    *RptTimestamp         = NULL;
int         GrpPartFlag           =   0;
int         GrpPartLevel          =   0;
int         PartIndex             =   0;



void IMPLstrcat(char **src,char* dest)
{
	char * desc = dest ? dest : "NA";
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
 
	tc_strcat(*src , desc);
}

void SetBomGenMakeBuyInd(char* view, char* plantName)
{
	printf("\n SetBomGenMakeBuyInd Started");fflush(stdout);
    tc_strcpy(BomGenMakeBuyInd,"");
    tc_strcpy(GenMakeBuyInd,"");
    if (tc_strcmp(plantName,"JSR")==0)
	{
        BomGenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_JsrMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(GenMakeBuyInd,"t5_JsrMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsApljRlzd");
        
		GenPlantLCStateStd	=(char *) MEM_alloc(100);
		tc_strcpy(GenPlantLCStateStd,"T5_LcsStdjRlzd");
        
		GetPlantStore=(char *) MEM_alloc(100);
		tc_strcpy(GetPlantStore,"t5_JsrStoreLocation");
	}
	else if (tc_strcmp(plantName,"PUNECVBU")==0)
	{
        BomGenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_PunMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(GenMakeBuyInd,"t5_PunMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsAplpRlzd");
        
        GenPlantLCStateStd	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCStateStd,"T5_LcsStdpRlzd");
        
        GetPlantStore=(char *) MEM_alloc(100);
        tc_strcpy(GetPlantStore,"t5_PunStoreLocation");
	}
	else if (tc_strcmp(plantName,"LKO")==0)
	{
        BomGenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_LkoMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(GenMakeBuyInd,"t5_LkoMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsApllRlzd");
        
        GenPlantLCStateStd	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCStateStd,"T5_LcsStdlRlzd");
        
        GetPlantStore=(char *) MEM_alloc(100);
        tc_strcpy(GetPlantStore,"t5_LkoStoreLocation");
	}
    else if (tc_strcmp(plantName,"DWD")==0)
	{
		BomGenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_DwdMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(GenMakeBuyInd,"t5_DwdMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsApldRlzd");
        
        GenPlantLCStateStd	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCStateStd,"T5_LcsStddRlzd");
        
        GetPlantStore=(char *) MEM_alloc(100);
        tc_strcpy(GetPlantStore,"t5_DwdStoreLocation");
	}
    else if (tc_strcmp(plantName,"PNR")==0)
	{
        BomGenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_PnrMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(GenMakeBuyInd,"t5_PnrMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsApluRlzd");
        
        GenPlantLCStateStd	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCStateStd,"T5_LcsStduRlzd");
        
        GetPlantStore=(char *) MEM_alloc(100);
        tc_strcpy(GetPlantStore,"t5_PnrStoreLocation");
	}
    else if (tc_strcmp(plantName,"AHD")==0)
	{
        BomGenMakeBuyInd	=(char *) MEM_alloc(100);
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_AhdMakeBuyIndicator");
        
        GenMakeBuyInd	=(char *) MEM_alloc(100);
        tc_strcpy(GenMakeBuyInd,"t5_AhdMakeBuyIndicator");
        
        GenPlantLCState	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCState,"T5_LcsAplaRlzd");
        
        GenPlantLCStateStd	=(char *) MEM_alloc(100);
        tc_strcpy(GenPlantLCStateStd,"T5_LcsStdaRlzd");
        
        GetPlantStore=(char *) MEM_alloc(100);
        tc_strcpy(GetPlantStore,"t5_AhdStoreLocation");
	}
    else if (tc_strcmp(plantName,"PUNECARPLT")==0)
	{
		tc_strcpy(BomGenMakeBuyInd,"bl_Design Revision_t5_CarMakeBuyIndicator");
        tc_strcpy(GenMakeBuyInd,"t5_CarMakeBuyIndicator");
	}
	else
	{
		printf("\n Input Plant is not yet live for MBOM/EBOM Report ");fflush(stdout);
	}
    printf("\n BomGenMakeBuyInd = %s\n ",BomGenMakeBuyInd);fflush(stdout);
	printf("\n SetBomGenMakeBuyInd Ended");fflush(stdout);
}

void GetClousureRuleNdRev(char* view, char* plantName,char* ClosureRule,char* ClosureRev)
{
    tc_strcpy(ClosureRule,"");
    tc_strcpy(ClosureRev,"");
    if(tc_strcmp(view,"ERC")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleERC1");
        tc_strcpy(ClosureRev,"ERC1 Release and Above");
    }
	else if(tc_strcmp(view,"MBOM")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM");
        tc_strcpy(ClosureRev,"MBOM Release and Above");
    }
    else if (tc_strcmp(view,"APL")==0)
    {
        if (tc_strcmp(plantName,"JSR")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLJ");
            tc_strcpy(ClosureRev,"APLJ Release and Above");
        }
        else if (tc_strcmp(plantName,"LKO")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLL");
            tc_strcpy(ClosureRev,"APLL Release and Above");
        }
        else if (tc_strcmp(plantName,"PNR")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLU");
            tc_strcpy(ClosureRev,"APLU Release and Above");
        }
        else if (tc_strcmp(plantName,"DWD")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLD");
            tc_strcpy(ClosureRev,"APLD Release and Above");
        }
        else if (tc_strcmp(plantName,"PUNECVBU")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLP");
            tc_strcpy(ClosureRev,"APLP Release and Above");
        }
        else if (tc_strcmp(plantName,"AHD")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLA");
            tc_strcpy(ClosureRev,"APLA Release and Above");
        }
        
    }
	
	else if (tc_strcmp(view,"STD")==0)
    {
        if (tc_strcmp(plantName,"JSR")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDJ");
            tc_strcpy(ClosureRev,"STDJ Released and Above");
        }
        else if (tc_strcmp(plantName,"LKO")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDL");
            tc_strcpy(ClosureRev,"STDL Released and Above");
        }
        else if (tc_strcmp(plantName,"PNR")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDU");
            tc_strcpy(ClosureRev,"STDU Released and Above");
        }
        else if (tc_strcmp(plantName,"DWD")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDD");
            tc_strcpy(ClosureRev,"APLD Released and Above");
        }
        else if (tc_strcmp(plantName,"PUNECVBU")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleSTDP");
            tc_strcpy(ClosureRev,"STDP Released and Above");
        }
        
    }
	
    printf("\n ClosureRule = %s\n ",ClosureRule);fflush(stdout);
    printf("\n ClosureRev = %s\n ",ClosureRev);fflush(stdout);
}



void GetClousureRuleNdRevFromCtrlObject(char* view, char* plantName,char* ClosureRule,char* ClosureRev)
{
	char    *qry_entry[1]            =    {"SYSCD",};
	char    *qry_values[1]           =    {"InputSheetGenExp"};
	
	tag_t   QryCtrlTag               =    NULLTAG;
	int     CountObject              =    0;
    tag_t   *Objects_Tag             =    NULLTAG;
	char*   CtrlObjInfo1             =    NULL;
	char*   CtrlObjInfo2             =    NULL;

	printf("\n GetClousureRuleNdRevFromCtrlObject Started");fflush(stdout);
	
    if(QRY_find("Control Objects...", &QryCtrlTag));
    if (QryCtrlTag)
    {
        printf("\n Query Control Objects... Found \n");fflush(stdout);
    }
    else
    {
        printf("\n Query Tag Control Objects... Not Found \n");fflush(stdout);
    }
	if(QRY_execute(QryCtrlTag, 1, qry_entry, qry_values, &CountObject, &Objects_Tag));
    printf("No of Object Found = %d",CountObject);fflush(stdout);
	
	if (CountObject > 0)
	{
		AOM_ask_value_string( Objects_Tag[0], "t5_Userinfo1", &CtrlObjInfo1);
		AOM_ask_value_string( Objects_Tag[0], "t5_Userinfo2", &CtrlObjInfo2);
		
		tc_strcpy(ClosureRule,CtrlObjInfo1);
        tc_strcpy(ClosureRev,CtrlObjInfo2);
	}
	printf("\n GetClousureRuleNdRevFromCtrlObject Ended");fflush(stdout);
}

void GetPartDesc(char* partName, char* partRev, char* partSeq,char* PartDesc)
{
	printf("\n GetPartDesc Started");fflush(stdout);
    int ifail = ITK_ok;
    int n_tags_found=0;
    tag_t* tags_found = NULL;
    const char *attrs[1];
    const char *values[1];
    
    
    attrs[0] ="item_id";
	values[0] = (char *)partName;
    
    tc_strcpy(PartDesc,"");
    ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found= %d",n_tags_found);fflush(stdout);
    
    if (n_tags_found >0)
    {
        char* itemRevSeq = NULL;
        itemRevSeq = (char *) MEM_alloc(32);
        tag_t item = NULLTAG;
        tag_t itemRev = NULLTAG;
        
        strcpy(itemRevSeq,partRev);
        strcat(itemRevSeq,";");
        strcat(itemRevSeq,partSeq);
        item = tags_found[0];
        ITK_CALL(ITEM_find_revision(item,itemRevSeq,&itemRev));
        printf("\n itemRevSeq= %s",itemRevSeq);fflush(stdout);
        char* tempPartDesc = NULL;
        
        if ( itemRev != NULLTAG)
        {   
            ITK_CALL(AOM_ask_value_string(itemRev,"current_desc",&tempPartDesc));
            //printf("\n ParDesc= %s",tempPartDesc);fflush(stdout);
            tc_strcpy(PartDesc,tempPartDesc);
        }
    }
	printf("\n GetPartDesc Ended");fflush(stdout);
}

void setofTagList(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n Malloc Started");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
		//printf("\n Malloc End");fflush(stdout);
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	
	(*objlist)[*count-1] = obj; 
}

int getChild(tag_t* child,int count,tag_t** SetOfParts)
{
    int ifail = ITK_ok;
    char *level=NULL;
    tag_t *subChild=NULLTAG;
    int level2 = 99;
   
   
    
    //printf("\n Number Of Children %d",count);
    int i = 0;
    for( i = 0;i<count;i++)
    {
        char* partName = NULL;
        int counter = 0;
        ITK_CALL(AOM_UIF_ask_value(child[i],"bl_level_starting_0",&level));
        int level1 = atoi(level);
        //printf("\n Level of Expension  = %d\n",level1);
        
        ITK_CALL(AOM_ask_value_string(child[i],"bl_item_item_id",&partName));
        //printf("\n Child Part Name = %s\n",partName);
		
		char* PartRevisionSeq = NULL;
		ITK_CALL(AOM_ask_value_string(child[i],"bl_rev_item_revision_id",&PartRevisionSeq));
        //printf("\n Child Part Name PartRevisionSeq = %s\n",PartRevisionSeq);
        
        //******** STOP EXPLOSION IF PART HAVING PART TYPE AS DUMMY **************//
        char* PartType = NULL;
        PartType = (char *) MEM_alloc(32);
        ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartType",&PartType));
        //printf("\n Child Part Part Type Is : %s\n",PartType);fflush(stdout);
        if(tc_strcmp(PartType,"")!=0)
        {
             if((tc_strcmp(PartType,"Dummy")==0) ||
			    (tc_strcmp(PartType,"Dummy Component")==0) ||
				(tc_strcmp(PartType,"CAD Module")==0) || 
				(tc_strcmp(PartType,"IFD Module")==0) ||
				(tc_strcmp(PartType,"Dummy Assembly")==0))
             {
				continue;
             }
        }
		else
		{
			continue;
		}
        //******** STOP EXPLOSION IF PART HAVING PART TYPE AS DUMMY **************//
        
		
		char* PartQty = NULL;
        PartQty = (char *) MEM_alloc(32);
        ITK_CALL(AOM_UIF_ask_value(child[i],"bl_quantity",&PartQty));
        //printf("\n Child Part PartQty : %s\n",PartQty);fflush(stdout);
		if(tc_strcmp(PartQty,"0")==0) 
		{
			continue;
		}
		
		
		//printf("\n Memory Alocation Started");fflush(stdout);
		tag_t BomPtr = NULLTAG;
		BomPtr = child[i];
		//printf("PartIndex = %d",PartIndex);fflush(stdout);
		setofTagList(&PartIndex,&*SetOfParts,BomPtr);
		
        
        //******** STOP EXPLOSION IF PART HAVING CS AS F/F18/F30 **************//
        char* suppCs = NULL;
        suppCs = (char *) MEM_alloc(64);
        tc_strcpy(suppCs,"");
        ITK_CALL(AOM_UIF_ask_value(child[i],BomGenMakeBuyInd,&suppCs))
        //printf("\n BomGenMakeBuyInd = %s\n",suppCs);
        
        if(tc_strcmp(suppCs,"")!=0)
        {
            if(strstr(suppCs,"External procurement")!=0)
	        {
				//printf("\n  Enter into the Continue Loop\n");
	            continue;
	        }
			else
			{
				//printf("\n  Not Enter into the Continue Loop\n");
			}
        }
        //******** STOP EXPLOSION IF PART HAVING CS AS F/F18/F30 **************//
        
        
        
        if(level1 <level2 )
        {
            ITK_CALL(BOM_line_ask_all_child_lines(child[i],&counter,&subChild));
            //printf("\n Number Of Sub Childs %d \n",counter);
            if (counter > 0)
            {
                getChild(subChild,counter,SetOfParts);
            }
        }
        
    }
    
}

int t5GetSLExplosionUpCs1(tag_t itemRev,tag_t** SetOfParts)
{
	printf("\n t5GetSLExplosionUpCs1 Started");fflush(stdout);
    int ifail = ITK_ok;
    tag_t window=NULLTAG;
    int rulefound = 0;
    tag_t rule=NULLTAG;
    tag_t *tClosurerule = NULLTAG;
    tag_t close_tag = NULLTAG;
    tag_t dItem=NULLTAG;
    tag_t top_line=NULLTAG;
    int   count = 0;
    tag_t *child=NULLTAG;
    
    char* suppCs = NULL;
    suppCs = (char *) MEM_alloc(64);
    tc_strcpy(suppCs,"");
    ITK_CALL(AOM_ask_value_string(itemRev,GenMakeBuyInd,&suppCs))
    //printf("\n GenMakeBuyInd = %s\n",suppCs);
    
    if(tc_strcmp(suppCs,"")!=0)
    {
        if(tc_strstr(suppCs,"F")!=NULL && tc_strcmp(suppCs,"F30") !=0)
	    {
	        printf("\n  Supplier CS :%s \n",suppCs);
	        return (ifail);
	    }
    }
    
    
    
    ITK_CALL(BOM_create_window(&window));
    ITK_CALL(CFM_find(ClosureRev,&rule));
	ITK_CALL(BOM_set_window_config_rule( window, rule ));
    ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
    //printf ("rule count %d \n",rulefound);fflush(stdout);
    if (rulefound > 0)
    {
        close_tag = tClosurerule[0];
        printf ("closure rule found \n");fflush(stdout);
    }
    else
    {
        printf ("closure rule not found \n");fflush(stdout);
        exit;
    }
    
    ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
    ITK_CALL(BOM_set_window_top_line(window,dItem,itemRev,NULLTAG,&top_line));
    ITK_CALL(BOM_line_ask_all_child_lines(top_line,&count,&child));
    
    
    
    getChild(child,count,SetOfParts);
	
	printf("\n t5GetSLExplosionUpCs1 Ended");fflush(stdout);
    return ifail;
}

int t5GetSLExplosionUpCs(char* inputPart,char* inputPartRev,char* inputPartSeq,tag_t** SetOfParts)
{
	printf("\n t5GetSLExplosionUpCs Started");fflush(stdout);
    int ifail = ITK_ok;
    int n_tags_found=0;
    tag_t* tags_found = NULL;
    const char *attrs[1];
    const char *values[1];
    
    
    attrs[0] ="item_id";
	values[0] = (char *)inputPart;
    ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found= %d",n_tags_found);fflush(stdout);
    
    if (n_tags_found >0)
    {
        char* itemRevSeq = NULL;
        itemRevSeq = (char *) MEM_alloc(32);
        tag_t item = NULLTAG;
        tag_t itemRev = NULLTAG;
        
        strcpy(itemRevSeq,inputPartRev);
        strcat(itemRevSeq,";");
        strcat(itemRevSeq,inputPartSeq);
        item = tags_found[0];
        ITK_CALL(ITEM_find_revision(item,itemRevSeq,&itemRev));
        printf("\n itemRevSeq= %s",itemRevSeq);fflush(stdout);
        
        if ( itemRev != NULLTAG)
        {
            t5GetSLExplosionUpCs1(itemRev,SetOfParts);
        }
        else
        {
            printf("Item Revision Not Found for %s",itemRevSeq);fflush(stdout);
        }
        
    }
    else
    {
        printf("\n Part is not Exist \n");fflush(stdout);
    }
	printf("\n t5GetSLExplosionUpCs Ended");fflush(stdout);
    return ifail;
}


void  t5GetUPLReportHdrPrint(char** output,char* inputPart,char* inputPartRev,char* inputPartSeq,char* PartDesc)
{
	printf("\n t5GetUPLReportHdrPrint Function Execution Started");fflush(stdout);
    time_t t;
    t = time(NULL);
    struct tm tm = *localtime(&t);
	
	char* StrYear = NULL;
	char* StrMnth = NULL;
	char* StrDay  = NULL;
	
	StrYear = (char *) MEM_alloc(20);
	StrMnth = (char *) MEM_alloc(20);
	StrDay = (char *) MEM_alloc(20);
	
	int YearIn = tm.tm_year+1900;
	int MonthIn = tm.tm_mon+1;
	int DayIn = tm.tm_mday;
	
	sprintf(StrYear,"%d",YearIn);
	sprintf(StrMnth,"%d",MonthIn);
	sprintf(StrDay,"%d",DayIn);
	
	IMPLstrcat(output,"\n,,Input Sheet generation for MBOM,,");
	IMPLstrcat(output,StrYear);
	IMPLstrcat(output,"-");
	IMPLstrcat(output,StrMnth);
	IMPLstrcat(output,"-");
	IMPLstrcat(output,StrDay);
	IMPLstrcat(output,"\n,,,,,,,,,,,,,,,,,,,");
	IMPLstrcat(output,"\n,,=======================================,,");
	IMPLstrcat(output,"\n======,=================,==========================================================");
	IMPLstrcat(output,"\n SR NO.,MODEL NO,D E S C R I P T I O N");
	IMPLstrcat(output,"\n 1,");
	IMPLstrcat(output,inputPart);
	IMPLstrcat(output,"-");
	IMPLstrcat(output,inputPartRev);
	IMPLstrcat(output,"-");
	IMPLstrcat(output,inputPartSeq);
	IMPLstrcat(output,",");
	IMPLstrcat(output,PartDesc);
	IMPLstrcat(output,"\n======,=================,==========================================================");
	IMPLstrcat(output,"\n==============,==============,=====================================================================,====,===================,====,====,========,======,======,======,");
	IMPLstrcat(output,"\n BOM Level,Material,Part Description,Rev,Part Type,Qty,CS,DR Stat,Parent Grp Part,Pending Task,Planner Details,");
	IMPLstrcat(output,"\n==============,==============,=====================================================================,====,===================,====,====,========,======,======,======,");
	
	printf("\n t5GetUPLReportHdrPrint Function Execution Completed");fflush(stdout);
}


void GetTaskNdPlannerName(char* ExcepPrtName,char* ExcepRevDup,char* ExcepSeqDup,char* PendingTaskName, char* PendingPlannerName)
{
	//printf("\n Enter Into GetTaskNdPlannerName Function");fflush(stdout);
	char* SampleAPLTaskName = NULL;
	SampleAPLTaskName=MEM_alloc(10);
	
	char* Assignee = NULL;
	char* AssigneeDup = NULL;
	char* TaskName = NULL;
	char* TaskNameDup = NULL;
	
	AssigneeDup=MEM_alloc(1000);
	TaskNameDup=MEM_alloc(50);
	
	strcpy(PendingPlannerName,"");	
	strcpy(PendingTaskName,"");	
	if(tc_strcmp(PlantName,"JSR") == 0)
	{
		strcpy(SampleAPLTaskName,"APLJ");
	}
	else if(tc_strcmp(PlantName,"PUNECVBU") == 0)
	{
		strcpy(SampleAPLTaskName,"APLP");
	}
	else if(tc_strcmp(PlantName,"LKO") == 0)
	{
		strcpy(SampleAPLTaskName,"APLL");
	}
	else if(tc_strcmp(PlantName,"DWD") == 0)
	{
		strcpy(SampleAPLTaskName,"APLD");
	}
	else if(tc_strcmp(PlantName,"PNR") == 0)
	{
		strcpy(SampleAPLTaskName,"APLU");
	}
	int n_tags_found=0;
    tag_t* tags_found = NULL;
    const char *attrs[1];
    const char *values[1];
    
    
    attrs[0] ="item_id";
	values[0] = (char *)ExcepPrtName;
	    
	ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
	//printf("\n n_tags_found= %d",n_tags_found);fflush(stdout);
    
	if (n_tags_found >0)
	{
		char* itemRevSeq = NULL;
		itemRevSeq = (char *) MEM_alloc(32);
		tag_t item = NULLTAG;
		tag_t ItemRev = NULLTAG;
        
		strcpy(itemRevSeq,ExcepRevDup);
		strcat(itemRevSeq,";");
		strcat(itemRevSeq,ExcepSeqDup);
		
			
		item = tags_found[0];
		ITK_CALL(ITEM_find_revision(item,itemRevSeq,&ItemRev));
		//printf("\n ExcepPrtName= %s",ExcepPrtName);fflush(stdout);
		//printf("\n itemRevSeq= %s",itemRevSeq);fflush(stdout);
        
		if ( ItemRev != NULLTAG)
		{
			tag_t *RefRnce;
		    int NoRefs;
		    int *Levels;
		    char **Relatins=NULL;
		    ITKCALL(WSOM_where_referenced(ItemRev, 1,&NoRefs,&Levels,&RefRnce,&Relatins));
		    //printf("\n\t WSOM_where_referenced levels:%d NoRefs: %d ",*Levels,NoRefs); fflush(stdout);
		        
		    int RefCounter = 0;
		    for(RefCounter = 0; RefCounter < NoRefs; RefCounter++)
		    {
				int GetDMLStatus = 0;
		        tag_t ObjTypeRefTag = NULLTAG;
		        char  TypeNameRef[TCTYPE_name_size_c+1];
		        ITKCALL(TCTYPE_ask_object_type(RefRnce[RefCounter],&ObjTypeRefTag));
		        ITKCALL(TCTYPE_ask_name(ObjTypeRefTag,TypeNameRef));
		        //printf("\n TypeNameRef= %s\n", TypeNameRef);fflush(stdout);
		        if (strcmp(TypeNameRef,"T5_MBOMTASKRevision")==0)
		        {
		        	if( AOM_ask_value_string(RefRnce[RefCounter],"item_id",&TaskName)!=ITK_ok);
		        	//printf("\n Task Name= %s\n", TaskName);fflush(stdout);
		        		
					
					tag_t*  status_list = NULLTAG;
					int status_count = 0;
                    char *StatusName=NULL;						
					ITK_CALL( WSOM_ask_release_status_list(RefRnce[RefCounter],&status_count,&status_list));
                    ITK_CALL(AOM_ask_value_string(status_list[0],"object_string",&StatusName));
					//printf("\n Task Status Name is : %s\n",StatusName);fflush(stdout);
						
					if (strcmp(StatusName,"MBOM Working")==0 || strcmp(StatusName,"MBOM Review")==0)
					{
						strcpy(TaskNameDup,TaskName);
						char* TaskState = NULL;
						char* CurrTaskName = NULL;
						tag_t TaskJob =NULLTAG;
						tag_t TaskJobType =NULLTAG;
						EPM_get_current_job(RefRnce[RefCounter],&TaskJob,&TaskJobType);
							
						if(TaskJob!=NULLTAG)
						{
							char* TaskJobName = NULL;
							char* RootTaskName = NULL;
							tag_t RootTsk = NULLTAG;
							int   NumOfSubTask = 0;
							int   SubTaskCnt = 0;
							tag_t *SubTaskstag =NULLTAG;
								
							AOM_UIF_ask_value(TaskJob,"object_name",&TaskJobName);
							//printf("\n TaskJobName = %s",TaskJobName);
							EPM_ask_root_task(TaskJob,&RootTsk);
							AOM_UIF_ask_value(RootTsk,"object_name",&RootTaskName);
							//printf("\n RootTaskName=%s ",RootTaskName);
								
							EPM_ask_sub_tasks(RootTsk,&NumOfSubTask,&SubTaskstag);
							//printf("\n NumOfSubTask is ",NumOfSubTask);fflush(stdout);
								
							for (SubTaskCnt = 0; SubTaskCnt < NumOfSubTask; SubTaskCnt++)
							{
								AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"task_state",&TaskState);
								AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"current_name",&CurrTaskName);
								//printf("\n Task Status is : %s CurrTaskName :%s",TaskState,CurrTaskName);
									
								if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Claim ERC Flown Task")!=NULL)
								{
							    	
							    	AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"awp0Acknowledgers",&Assignee);
							    	STRNG_replace_str(Assignee,","," ",&AssigneeDup);
							    	//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
									GetDMLStatus = 1;
							    	break;
								}
								if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Acknowledge ERC Flown Task")!=NULL)
								{
							    
									AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"fnd0Assignee",&Assignee);
									STRNG_replace_str(Assignee,","," ",&AssigneeDup);
									//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
									GetDMLStatus = 1;
									break;
								}
								if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Claim MBOM Task")!=NULL)
								{
							    
									AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"awp0Acknowledgers",&Assignee);
									STRNG_replace_str(Assignee,","," ",&AssigneeDup);
									//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
									GetDMLStatus = 1;
									break;
								}
								if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Work On MBOM-DML")!=NULL)
								{
									AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"fnd0Assignee",&Assignee);
									STRNG_replace_str(Assignee,","," ",&AssigneeDup);
									//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
									GetDMLStatus = 1;
									break;
								}
								if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Manager Review")!=NULL)
								{
									AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"awp0Reviewers",&Assignee);
									STRNG_replace_str(Assignee,","," ",&AssigneeDup);
									//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
									GetDMLStatus = 1;
									break;
								}
									
							}
							    
						}
					}
		        }
				else if (strcmp(TypeNameRef,"T5_APLTaskRevision")==0)
				{
		        	if( AOM_ask_value_string(RefRnce[RefCounter],"item_id",&TaskName)!=ITK_ok);
		        	//printf("\n Task Name= %s\n", TaskName);fflush(stdout);
					
					
					
					
					tag_t *DMLRefRnce;
					int NoRefsDML;
					int *LevelsDML;
					char **DMLRelatins=NULL;
					int DMLRefCounter = 0;
					int FlgDMLNeedToConside = 0;
					ITKCALL(WSOM_where_referenced(RefRnce[RefCounter], 1,&NoRefsDML,&LevelsDML,&DMLRefRnce,&DMLRelatins));
					tag_t DMLObjTypeRefTag = NULLTAG;
					char  DMLTypeNameRef[TCTYPE_name_size_c+1];
					for ( DMLRefCounter = 0;DMLRefCounter<NoRefsDML;DMLRefCounter++)
					{
						ITKCALL(TCTYPE_ask_object_type(DMLRefRnce[DMLRefCounter],&DMLObjTypeRefTag));
						ITKCALL(TCTYPE_ask_name(DMLObjTypeRefTag,DMLTypeNameRef));
						if (strcmp(DMLTypeNameRef,"T5_APLDMLRevision")==0)
						{
							char* DMLRlzType = NULL;
							char* DMLNum = NULL;
							if( AOM_ask_value_string(DMLRefRnce[DMLRefCounter],"t5_rlstype",&DMLRlzType)!=ITK_ok);
							if( AOM_ask_value_string(DMLRefRnce[DMLRefCounter],"item_id",&DMLNum)!=ITK_ok);
							
							
							if (strstr(DMLNum,SampleAPLTaskName)== NULL)
							{
								continue;
							}
							//printf("\n Task Name= %s", TaskName);fflush(stdout);
							//printf("\n DMLRlzType  %s", DMLRlzType);fflush(stdout);
							//printf("\n DMLNum= %s", DMLNum);fflush(stdout);
							if((strcmp(DMLRlzType,"TODR")==0) ||(strcmp(DMLRlzType,"X0")==0) )
							{
								FlgDMLNeedToConside = 99;
								continue;
							}
							else
							{
								FlgDMLNeedToConside = 1;
								break;
							}
						}
						else
						{
							continue;
						}
					}
					
					//printf("\n FlgDMLNeedToConside= %d", FlgDMLNeedToConside);fflush(stdout);
					if (FlgDMLNeedToConside == 99)
					{
						continue;
					}
					
					strcpy(TaskNameDup,TaskName);
					if (strstr(TaskNameDup,SampleAPLTaskName)== NULL)
					{
						strcpy(TaskNameDup,"");
						continue;
					}
					
					char* TaskState = NULL;
					char* CurrTaskName = NULL;
					tag_t TaskJob =NULLTAG;
					tag_t TaskJobType =NULLTAG;
					EPM_get_current_job(RefRnce[RefCounter],&TaskJob,&TaskJobType);
					
					if(TaskJob!=NULLTAG)
					{
						char* TaskJobName = NULL;
						char* RootTaskName = NULL;
						tag_t RootTsk = NULLTAG;
						int   NumOfSubTask = 0;
						int   SubTaskCnt = 0;
						tag_t *SubTaskstag =NULLTAG;
						
						AOM_UIF_ask_value(TaskJob,"object_name",&TaskJobName);
						//printf("\n TaskJobName = %s",TaskJobName);
						EPM_ask_root_task(TaskJob,&RootTsk);
						AOM_UIF_ask_value(RootTsk,"object_name",&RootTaskName);
						//printf("\n RootTaskName=%s ",RootTaskName);
						
						EPM_ask_sub_tasks(RootTsk,&NumOfSubTask,&SubTaskstag);
						//printf("\n NumOfSubTask is ",NumOfSubTask);fflush(stdout);
						
						for (SubTaskCnt = 0; SubTaskCnt < NumOfSubTask; SubTaskCnt++)
						{
							AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"task_state",&TaskState);
							AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"current_name",&CurrTaskName);
							//printf("\n Task Status is : %s CurrTaskName :%s",TaskState,CurrTaskName);
							
							
							
							if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Acknowledge Task")!=NULL)
							{
						   	
						   	    AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"awp0Acknowledgers",&Assignee);
						   	    STRNG_replace_str(Assignee,","," ",&AssigneeDup);
						   	    //printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
								GetDMLStatus = 1;
						   	    break;
							}
							if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Work On DML")!=NULL)
							{
						   	
								AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"fnd0Assignee",&Assignee);
								STRNG_replace_str(Assignee,","," ",&AssigneeDup);
								//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
								GetDMLStatus = 1;
								break;
							}
							if (tc_strstr(TaskState,"Started")!=NULL && tc_strstr(CurrTaskName,"Review The Changes Done By APL Planner")!=NULL)
							{
						   	
								AOM_UIF_ask_value(SubTaskstag[SubTaskCnt],"awp0Reviewers",&Assignee);
								STRNG_replace_str(Assignee,","," ",&AssigneeDup);
								//printf("\n Task Name= %s\n", TaskNameDup);fflush(stdout);
								//printf("\n AssigneeDup =%s",AssigneeDup);fflush(stdout);
								GetDMLStatus = 1;
								break;
							}
						}
					}
				}
				if (GetDMLStatus == 1)
				{
					GetDMLStatus = 0;
					break;
				}
					
			}
		}
		else
		{
			//printf("Item Revision Not Found for %s",itemRevSeq);fflush(stdout);
		}
        
	}
	else
	{
		//printf("\n Part is not Exist \n");fflush(stdout);
	}
	
	//printf("\n AssigneeDup = %s",AssigneeDup);fflush(stdout);
	//printf("\n TaskNameDup = %s",TaskNameDup);fflush(stdout);
	strcpy(PendingPlannerName,AssigneeDup);	
	strcpy(PendingTaskName,TaskNameDup);	
	//printf("\n PendingPlannerName = %s",PendingPlannerName);fflush(stdout);
	//printf("\n PendingTaskName = %s",PendingTaskName);fflush(stdout);
	//printf("\n Exit from GetTaskNdPlannerName Function");fflush(stdout);
}




void GetParentGrpPart(char* partName,int index,int partLevel,char* ParentGrpPart,tag_t* SetOfParts)
{
    int counter = 0;
    tag_t tpartObj = NULL;
    int skipFlag = 0;
   
    char* templevel = NULL;
    char* PartType  = NULL;
    char* ParentPart = NULL;
    char* GrandparentPart = NULL;
    char* ParentPartType = NULL;
    char* GrandparentPartType = NULL;
    
    templevel = (char *) MEM_alloc(100);
    PartType = (char *) MEM_alloc(100);
    ParentPart = (char *) MEM_alloc(100);
    GrandparentPart = (char *) MEM_alloc(100);
    ParentPartType = (char *) MEM_alloc(100);
    GrandparentPartType = (char *) MEM_alloc(100);
    
    tc_strcat(ParentGrpPart,"");
    ITK_CALL(AOM_ask_value_string(SetOfParts[index],"bl_Design Revision_t5_PartType",&PartType));
    //printf("\n PartType = %s",PartType);fflush(stdout);
    
    ITK_CALL(AOM_UIF_ask_value(SetOfParts[index],"bl_level_starting_0",&templevel));
    int level = atoi(templevel);
    //printf("\n templevel = %s",templevel);fflush(stdout);
    
    if ((tc_strcmp(PartType,"G") == 0) && GrpPartFlag == 0 )
    {
        GrpPartFlag = 1;
        GrpPartLevel = level;
        skipFlag = 1;
    }
    else if( GrpPartFlag == 1 && skipFlag == 1)
    {
        skipFlag = 0;
    }
    else if ( (GrpPartLevel == level || GrpPartLevel > level)&& skipFlag == 0)
    {
        GrpPartFlag = 0;
    }
    
    if (GrpPartFlag == 1 && skipFlag == 0)
    {
        for (counter = index-1;counter >= 0; counter--)
        {
            tpartObj = SetOfParts[counter];
            
            ITK_CALL(AOM_UIF_ask_value(tpartObj,"bl_level_starting_0",&templevel));
            level = atoi(templevel);
            //printf("\n templevel = %s",templevel);fflush(stdout);
            if ( level == partLevel)
            {
                continue;
            }
            else if(level == partLevel -1) //Parent
            {
                ITK_CALL(AOM_ask_value_string(tpartObj,"bl_item_item_id",&ParentPart));
                //printf("\n ParentPart = %s",ParentPart);fflush(stdout);
                
                ITK_CALL(AOM_ask_value_string(tpartObj,"bl_Design Revision_t5_PartType",&ParentPartType));
                //printf("\n ParentPartType = %s",ParentPartType);fflush(stdout);
                
                if (tc_strcmp(ParentPartType,"G") == 0)
                {
                    tc_strcat(ParentGrpPart,ParentPart);
                }
                else
                {
                    tc_strcat(ParentGrpPart,"KIT Part");
                }
                break;
            }
        }
    }
    
}

void t5SLstAllPrtExpFunc(tag_t* SetOfParts,char** output)
{
	printf("\n t5SLstAllPrtExpFunc Started");fflush(stdout);
    int IndexCnt = 0;
    for (IndexCnt = 0;IndexCnt <PartIndex; IndexCnt++)
    {
		tag_t tpartObjTemp = NULL;
		char* prtName = NULL;
		tpartObjTemp = SetOfParts[IndexCnt];
		char* TmpStrBld       = NULL;
		int PartLevel = 0;
		TmpStrBld = (char *) MEM_alloc(3000 * sizeof(char *));
		prtName = (char *) MEM_alloc(100 * sizeof(char *));
		
		if (tpartObjTemp != NULLTAG)
		{
			char* templevel = NULL;
            ITK_CALL(AOM_UIF_ask_value(tpartObjTemp,"bl_level_starting_0",&templevel));
			//printf("\n Part Execution templevel = %s",templevel);fflush(stdout);
			
            PartLevel = atoi(templevel);
			//printf("\n Part Execution prtName = %s",prtName);fflush(stdout);
			
            char* tempPrtNme = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,"bl_item_item_id",&tempPrtNme));
			tc_strcpy(prtName,tempPrtNme);
			
			//printf("\n Part Execution prtName = %s",prtName);fflush(stdout);
            
            char* tempPartDesc = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,"bl_item_object_desc",&tempPartDesc));
			
			
			char 	*tempPartDesc1               =	NULL;
		    tempPartDesc1 = (char *) MEM_alloc(100 * sizeof(char *));
			
			char 	*tempPartDesc2               =	NULL;
		    tempPartDesc2 = (char *) MEM_alloc(100 * sizeof(char *));
			
			STRNG_replace_str(tempPartDesc,",","_",&tempPartDesc1);
			STRNG_replace_str(tempPartDesc1,"\n"," ",&tempPartDesc2);
			//printf("\n Part Execution tempPartDesc2 = %s",tempPartDesc2);fflush(stdout);
           
            char* tempRev = NULL;
            char* tempRevDup = NULL;
            char* tempSeqDup = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,"bl_rev_item_revision_id",&tempRev));
            tempRevDup = strtok(tempRev,";");
            tempSeqDup = strtok(NULL,";");
			//printf("\n Part Execution tempRevDup = %s",tempRevDup);fflush(stdout);
            
			char* PartType = NULL;
            ITK_CALL(AOM_UIF_ask_value(tpartObjTemp,"bl_Design Revision_t5_PartType",&PartType));
            
            char* QtyReqAttr1 = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,"bl_quantity",&QtyReqAttr1));
			//printf("\n Part Execution QtyReqAttr1 = %s",QtyReqAttr1);fflush(stdout);
			
            
            char* tempCS = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,BomGenMakeBuyInd,&tempCS));
			//printf("\n Part Execution tempCS = %s",tempCS);fflush(stdout);
			
            
            char* tempDR = NULL;
            ITK_CALL(AOM_ask_value_string(tpartObjTemp,"bl_Design Revision_t5_PartStatus",&tempDR));
			//printf("\n Part Execution tempDR = %s",tempDR);fflush(stdout);
			
			char* ParentGrpPart = NULL;
            ParentGrpPart = (char *) MEM_alloc(100);
            
            GetParentGrpPart(prtName,IndexCnt,PartLevel,ParentGrpPart,SetOfParts);
            //printf("\n ParentGrpPart = %s",ParentGrpPart);fflush(stdout);
			
			
			char* PendingTaskName = NULL;
			char* PendingPlannerName = NULL;
			PendingTaskName = (char *) MEM_alloc(300);
			PendingPlannerName = (char *) MEM_alloc(1000);
			if (tempCS == NULL ||(tc_strcmp(tempCS,"")==0)|| (tc_strcmp(tempCS,"NA")==0))
			{
		        GetTaskNdPlannerName(prtName,tempRevDup,tempSeqDup,PendingTaskName,PendingPlannerName);
			}
            
			
			tc_strcpy(TmpStrBld,"");
            tc_strcat(TmpStrBld,templevel);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,prtName);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,tempPartDesc2);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,tempRevDup);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,PartType);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,QtyReqAttr1);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,tempCS);
			tc_strcat(TmpStrBld,",");
            tc_strcat(TmpStrBld,tempDR);
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,ParentGrpPart);
            tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,PendingTaskName);
            tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,PendingPlannerName);
            tc_strcat(TmpStrBld,",");
			IMPLstrcat(output,"\n");
			//printf("\n %s",TmpStrBld);fflush(stdout);
			IMPLstrcat(output,TmpStrBld);
			
		}
	}
	IMPLstrcat(output,"\n End of the file : Report completed");
	printf("\n t5SLstAllPrtExpFunc Ended");fflush(stdout);
}

void GenerateInputSheeetForMBOM(char **output)
{
	printf("\n GenerateInputSheeetForMBOM Started");fflush(stdout);
	char*       MbomFileName            = NULL;
	tag_t*      SetOfParts              = NULLTAG;
	
	timestamp = (char *) MEM_alloc(100 * sizeof(char *));
	MbomFileName = (char *) MEM_alloc(100 * sizeof(char *));
	BomGenMakeBuyInd = (char *) MEM_alloc(100);
    GenMakeBuyInd = (char *) MEM_alloc(100);
    PartDesc = (char *) MEM_alloc(100);
    ClosureRule = (char *) MEM_alloc(100);
    ClosureRev = (char *) MEM_alloc(100);
	
	SetBomGenMakeBuyInd(InputView, PlantName);
    GetPartDesc(InputPart,InputPartRev,InputPartSeq,PartDesc);
	GetClousureRuleNdRevFromCtrlObject(InputView,PlantName,ClosureRule,ClosureRev);
	t5GetSLExplosionUpCs(InputPart,InputPartRev,InputPartSeq,&SetOfParts);
	t5GetUPLReportHdrPrint(output,InputPart,InputPartRev,InputPartSeq,PartDesc);
	t5SLstAllPrtExpFunc(SetOfParts,output);
	printf("\n GenerateInputSheeetForMBOM Ended");fflush(stdout);
	
}

int InputSheetFrMBOMFuncsvr(void *return_data)
{
    int                     status;
    int                     ifail                                   =       ITK_ok;
	char                   *output			                        =       NULL;
    
	
 
    printf("\n Input Sheet Generation for MBOM ");fflush(stdout);
	
	output = (char *) MEM_alloc( 90000000 * sizeof(char*) );
	
    USERARG_get_string_argument(&InputPart);
    USERARG_get_string_argument(&InputPartRev);
    USERARG_get_string_argument(&InputPartSeq);
    USERARG_get_string_argument(&PlantName);
    USERARG_get_string_argument(&InputView);
    
    printf("\n I am in main program");fflush(stdout);
    printf("\n InputPart :: %s ",InputPart);fflush(stdout);
    printf("\n InputPartRev :: %s ",InputPartRev);fflush(stdout);
    printf("\n InputPartSeq :: %s ",InputPartSeq);fflush(stdout);
    printf("\n PlantName :: %s ",PlantName);fflush(stdout);
    printf("\n InputView :: %s ",InputView);fflush(stdout);
    
	tc_strcpy(output,"");
	
	GenerateInputSheeetForMBOM(&output);
	
	printf("\n before return data....!\n");fflush(stdout);

	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(output);

	printf("\n After free...!\n");fflush(stdout);
	
	
    return ifail;
}



extern int MBOMUserServiceFnInputSheetMbomFn()
{
    int ifail = ITK_ok;
    int nargs = 5;
    int retValueType;
    int inputArgTypes[5] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; 
    inputArgTypes[1] = USERARG_STRING_TYPE; 
    inputArgTypes[2] = USERARG_STRING_TYPE; 
    inputArgTypes[3] = USERARG_STRING_TYPE; 
    inputArgTypes[4] = USERARG_STRING_TYPE; 
    

    retValueType = USERARG_STRING_TYPE ;
    printf("\n MBOMUserServiceFnInputSheetMbomFn before....InputSheetFrMBOMFuncsvr");fflush(stdout);
    ifail=USERSERVICE_register_method("InputSheetFrMBOMFuncsvr",(USER_function_t)InputSheetFrMBOMFuncsvr,nargs,inputArgTypes,retValueType);
    return ifail;

}

extern int AllUserServiceFnInputSheetMbomRptFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;

    ITK_CALL(MBOMUserServiceFnInputSheetMbomFn());

    return ifail;
}

extern DLLAPI int t5_InputSheetGenFrMBOM_register_callbacks ()
{

    int ifail    = ITK_ok;
    printf("\n Before registering userservice....t5_InputSheetGenFrMBOM");fflush(stdout);
    ifail = CUSTOM_register_exit("t5_InputSheetGenFrMBOM", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnInputSheetMbomRptFn);
    printf("\n After registering userservice....t5_InputSheetGenFrMBOM");fflush(stdout);
    return(ITK_ok);
}

