//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_BulkSorImpl
//

#ifndef TRL001__T5_BULKSORIMPL_HXX
#define TRL001__T5_BULKSORIMPL_HXX

#include <T5_tm_bulkPPPMPrjCodelib/T5_BulkSorGenImpl.hxx>

#include <T5_tm_bulkPPPMPrjCodelib/libt5_tm_bulkpppmprjcodelib_exports.h>


namespace TRL001
{
    class T5_BulkSorImpl; 
    class T5_BulkSorDelegate;
}

class  T5_TM_BULKPPPMPRJCODELIB_API TRL001::T5_BulkSorImpl
    : public TRL001::T5_BulkSorGenImpl
{
public:


    ///
    /// desc for createPost
    /// @param creInput - Description for the Create Input
    /// @return - return desc for createPost
    ///
    int  createPostBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a T5_BulkSor
    explicit T5_BulkSorImpl( T5_BulkSor& busObj );

    ///
    /// Destructor
    virtual ~T5_BulkSorImpl();

private:
    ///
    /// Default Constructor for the class
    T5_BulkSorImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_BulkSorImpl( const T5_BulkSorImpl& );

    ///
    /// Copy constructor
    T5_BulkSorImpl& operator=( const T5_BulkSorImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_BulkSorDelegate;

};

#include <T5_tm_bulkPPPMPrjCodelib/libt5_tm_bulkpppmprjcodelib_undef.h>
#endif // TRL001__T5_BULKSORIMPL_HXX
