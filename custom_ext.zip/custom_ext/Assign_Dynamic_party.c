#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#define PS_where_used_all_levels   -1 
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/****************************************************************************
*   Function name			: Assign_Dynamic_party_Func
*   Description				: To set dynamic participant for dml and task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Mohan Tayade	1.30: Set dynamic participants for dml and task
*
****************************************************************************/
int Assign_Dynamic_party_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char	*groupName		= NULL;
	char	*DsgGrp			= NULL;
	char	*Task_name		= NULL;
	
	//BOM Analyst
	int     DsgGrup = 0;
	int     i = 0;
	int     No_BomAna = 0;
	tag_t   BomAna_Rev			= NULLTAG;
	tag_t   BAGrp_tag			= NULLTAG;
	tag_t   BomAnalyst_tag		= NULLTAG;
	tag_t	BomAna_Patri_Type	= NULLTAG;
	tag_t*  BomAna				= NULLTAG;
	tag_t	BomAna_Party		= NULLTAG;
	const char*   BomAnalyst_role = "BomAnalyst";
	//VI Reviewer
	int     iii = 0;
	int     No_VIAna = 0;
	tag_t   VIAna_Rev			= NULLTAG;
	tag_t   VIGrp_tag			= NULLTAG;
	tag_t   VIAnalyst_tag		= NULLTAG;
	tag_t	VIAna_Patri_Type	= NULLTAG;
	tag_t*  VIAna				= NULLTAG;
	tag_t	VIAna_Party		= NULLTAG;
	const char*   VIAnalyst_role = "VI_Reviewer";

	//CE Reviewer
	int     ik = 0;
	int     No_CEAna = 0;
	tag_t   CEAna_Rev			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t*  CEAna				= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	const char*   CEAnalyst_role = "CE_Reviewer";

	//Peer_reviewer
	int     ii = 0;
	int     No_Peer = 0;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	const char*   Brake_Peer_role = "CoC_Brakes_Controls_Peer_PVBU";
	const char*   BIW_Peer_role = "CoC_CAB_BIW_Peer_PVBU";
	const char*   Door_Peer_role = "CoC_CAB_Door_Peer_PVBU";
	const char*   ExtTrims_Peer_role = "CoC_CAB_Ext_Trims_Peer_PVBU";
	const char*   Fit_Peer_role = "CoC_CAB_Int_Fittings_Peer_PVBU";
	const char*   IntTrims_Peer_role = "CoC_CAB_Int_Trims_Peer_PVBU";
	const char*   Mascots_Peer_role = "CoC_CAB_Mascots_Peer_PVBU";
	const char*   Seat_Peer_role = "CoC_CAB_Seats_Peer_PVBU";
	const char*   EE_Peer_role = "CoC_E&E_Peer_PVBU";
	const char*   Exhaust_Peer_role = "CoC_Exhaust_Peer_PVBU";
	const char*   Frame_Peer_role = "CoC_Frames_Peer_PVBU";
	const char*   Fuel_Peer_role = "CoC_Fuel_System_Peer_PVBU";
	const char*   HVAC_Peer_role = "CoC_HVAC_Peer_PVBU";
	const char*   Mounts_Peer_role = "CoC_Mounts_Peer_PVBU";
	const char*   Restrn_Peer_role = "CoC_Restraints_Peer_PVBU";
	const char*   Steering_Peer_role = "CoC_Steering_Peer_PVBU";
	const char*   Suspension_Peer_role = "CoC_Suspension_Peer_PVBU";
	const char*   Tools_Peer_role = "CoC_Tools_Acessories_Peer_PVBU";

	//DMU_reviewer
	int     im = 0;
	int     No_DMU = 0;
	tag_t   DMUGrp_tag		= NULLTAG;
	tag_t   DMU_Rev			= NULLTAG;
	tag_t   DMU_tag		= NULLTAG;
	tag_t	DMU_Patri_Type	= NULLTAG;
	tag_t*  DMU_t			= NULLTAG;
	tag_t	DMU_Party		= NULLTAG;
	const char*   Brake_DMU_role = "CoC_Brakes_Controls_DMU_PVBU";
	const char*   BIW_DMU_role = "CoC_CAB_BIW_DMU_PVBU";
	const char*   Door_DMU_role = "CoC_CAB_Door_DMU_PVBU";
	const char*   ExtTrims_DMU_role = "CoC_CAB_Ext_Trims_DMU_PVBU";
	const char*   Fit_DMU_role = "CoC_CAB_Int_Fittings_DMU_PVBU";
	const char*   IntTrims_DMU_role = "CoC_CAB_Int_Trims_DMU_PVBU";
	const char*   Mascots_DMU_role = "CoC_CAB_Mascots_DMU_PVBU";
	const char*   Seat_DMU_role = "CoC_CAB_Seats_DMU_PVBU";
	const char*   EE_DMU_role = "CoC_E&E_DMU_PVBU";
	const char*   Exhaust_DMU_role = "CoC_Exhaust_DMU_PVBU";
	const char*   Frame_DMU_role = "CoC_Frames_DMU_PVBU";
	const char*   Fuel_DMU_role = "CoC_Fuel_System_DMU_PVBU";
	const char*   HVAC_DMU_role = "CoC_HVAC_DMU_PVBU";
	const char*   Mounts_DMU_role = "CoC_Mounts_DMU_PVBU";
	const char*   Restrn_DMU_role = "CoC_Restraints_DMU_PVBU";
	const char*   Steering_DMU_role = "CoC_Steering_DMU_PVBU";
	const char*   Suspension_DMU_role = "CoC_Suspension_DMU_PVBU";
	const char*   Tools_DMU_role = "CoC_Tools_Acessories_DMU_PVBU";


	//SVR COC Reviewer (Task)
	//BIW_COC_Reviewer
	int     b = 0;
	int     No_SVRcoc = 0;
	tag_t   SVRcocGrp_tag	= NULLTAG;
	tag_t   SVRcoc_tag		= NULLTAG;
	tag_t	SVRcoc_Patri_Type	= NULLTAG;
	tag_t*  SVRcoc_t			= NULLTAG;
	tag_t	SVRcoc_Party		= NULLTAG;
	//Trim_SVRCoC_role
	int     tr = 0;
	int     No_SVRt = 0;
	tag_t   SVRtGrp_tag	= NULLTAG;
	tag_t   SVRt_tag		= NULLTAG;
	tag_t	SVRt_Patri_Type	= NULLTAG;
	tag_t*  SVRt_t			= NULLTAG;
	tag_t	SVRt_Party		= NULLTAG;
	//CH_SVRCoC_role
	int     c = 0;
	int     No_SVRc = 0;
	tag_t   SVRcGrp_tag	= NULLTAG;
	tag_t   SVRc_tag		= NULLTAG;
	tag_t	SVRc_Patri_Type	= NULLTAG;
	tag_t*  SVRc_t			= NULLTAG;
	tag_t	SVRc_Party		= NULLTAG;
	//EE_SVRCoC_role
	int     e = 0;
	int     No_SVRe = 0;
	tag_t   SVReGrp_tag	= NULLTAG;
	tag_t   SVRe_tag		= NULLTAG;
	tag_t	SVRe_Patri_Type	= NULLTAG;
	tag_t*  SVRe_t			= NULLTAG;
	tag_t	SVRe_Party		= NULLTAG;
	//PT_SVRCoC_role
	int     p = 0;
	int     No_SVRp = 0;
	tag_t   SVRpGrp_tag	= NULLTAG;
	tag_t   SVRp_tag		= NULLTAG;
	tag_t	SVRp_Patri_Type	= NULLTAG;
	tag_t*  SVRp_t			= NULLTAG;
	tag_t	SVRp_Party			= NULLTAG;

	// Participants remove.
	int jk = 0;
	int jkk = 0;
	int kk = 0;
	int jtsk = 0;
	int CRBcount = 0;
	int CRBcunt = 0;
	char	*TskReviewr		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	TskCRBTag		= NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	char   type_name8[TCTYPE_name_size_c+1];
	char   Tsk_Typ[TCTYPE_name_size_c+1];
	logical is_Tskletst;
	logical is_Tskltst;

	//Task variables
	int     PltFrmPartFlg	=  0;
	int     prt		=  0;
	int     t		=  0;
	int     PRDFlag	=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     Tskcout		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*BomAna_Role		= NULL;
	char	*BIW_SVRCoC_role	= NULL;
	char	*Trim_SVRCoC_role	= NULL;
	char	*CH_SVRCoC_role		= NULL;
	char	*EE_SVRCoC_role		= NULL;
	char	*PT_SVRCoC_role		= NULL;
	char	*Tsk_class		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	logical is_Tsklatst;
	int error_code = ITK_ok;
	//Qry Project
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	int     n_entry    = 1;  
	int     rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n MT: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML/Task Number: [%s].", DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name(objTypTag,ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n MT:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);

		if(tc_strcmp(DMLType,"Veh")!=0)
		{
			if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
			printf("\n MT: ProjectID : %s",ProjectID);   fflush(stdout);

			//if(ITEM_find_item(ProjectID,&Project_t)!=ITK_ok)PrintErrorStack();
			if(ProjectID)
			{
				if(QRY_find("Qury_Project", &queryTag));
				printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = ProjectID;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
				printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

				if(resultCount > 0)
				{
					printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
					Project_t = t5_Project[0];
					if (Project_t!=NULLTAG)
					{
						if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
						printf("\n MT: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);

						if(tc_strcmp(ProjectClass,"PRD")==0)
						{
							//Query control table for PRDtoCVBU workflow project list.
							printf("\n MT:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
							if(QRY_find("ControlObjects", &qryTag));
							if (qryTag)
							{
								printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
							}
							else
							{
								printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
							}

							qry_values2[0] = "PRDCVBU";
							if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
							printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
							if(rsltCount > 0)
							{
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
								printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
								printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
								if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
								{
									PRDFlag=1;
									printf("\n MT:.PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
								}
								else
								{
									PRDFlag=0;
									printf("\n MT:.No project CVBU found: %d",PRDFlag); fflush(stdout);
								}
							}
							else
							{
								PRDFlag=0;
								printf("\n MT:.No project PRDCVBU found: %d",PRDFlag); fflush(stdout);
							}
						}
						else
						{
							PRDFlag=1;
							printf("\n MT:.No PRD project: %d",PRDFlag); fflush(stdout);
						}
						if (PRDFlag >0)
						{
							//############################### REMOVE PARTICIPALNTS START################################/
							if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
							if (dml_CRB_rel_type!=NULLTAG)
							{
								printf("\n MT:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
								if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
								printf("\n MT: DmlCRB count: %d",CRBcount);fflush(stdout);	
								for (jk=0;jk<CRBcount ;jk++ )
								{	
									//printf("\n MT:jk: %d.\n",jk);fflush(stdout);
									DmlCRBTag = DmlCRB[jk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
									if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
									printf("\n MT:DML: Participants Name: %s", type_name7);fflush(stdout);
									if(tc_strcmp(DMLType,"SVR")!=0)
									{
										if ((tc_strcmp(type_name7,"T5_BOMAnalyst")==0)||(tc_strcmp(type_name7,"T5_PPReviewer")==0))
										{
											if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
											printf("\n MT: Removing BOM/PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
											AOM_lock(objTag);
											if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
											AOM_save(objTag);
											AOM_unlock(objTag);
										}
									}
									else
									{
										if (tc_strcmp(type_name7,"T5_VIReviewer")==0)
										{
											if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
											printf("\n MT:Removing VI Reviewer: [%s] ",DMLReviewr);fflush(stdout);
											AOM_lock(objTag);
											if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
											AOM_save(objTag);
											AOM_unlock(objTag);
										}
									}
								}
							}
							printf("\n MT:START ASSIGNING REVIEWERS: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
							if((tc_strcmp(Proj_BU,"PCBU")==0)||(tc_strcmp(Proj_BU,"PVBU")==0))
							{
								if(tc_strcmp(DMLType,"SVR")==0)
								{
									//VI Reviewer for SVR only.
									printf("\n MT:PCBU: Setting VI Analyst...");fflush(stdout);
									if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
									printf("\n MT:PCBU:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
									if(No_VIAna>0)
									{
										for(iii=0;iii<No_VIAna;iii++)
										{	
											printf("\n MT:PCBU: VI Reviewer no: [%d]",iii);fflush(stdout);
											if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
											AOM_lock(objTag);			
											if(ITEM_rev_add_participant(objTag,VIAna_Party)!=ITK_ok)PrintErrorStack();
											AOM_save(objTag);
											AOM_unlock(objTag);
										}
									}
									AOM_refresh ( objTag,TRUE);
									MEM_free(VIAna);
								}
								else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
								{
									if(tc_strcmp(Proj_PltFrm,"")!=0)
									{
										if(tc_strcmp(Proj_PltFrm,"TBD")==0)
										{
											printf("\n MT:PCBU:BOM ANalyst Set to NULL since platform is TBD...");fflush(stdout);
										}
										else
										{
											BomAna_Role = (char	*)MEM_alloc(100);
											tc_strcpy(BomAna_Role,"");
											tc_strcpy(BomAna_Role,Proj_PltFrm);
											tc_strcat(BomAna_Role,"_");
											tc_strcat(BomAna_Role,"BOM_Analyst");
											printf("\n MT:PCBU: after BomAna_Role: %s",BomAna_Role);   fflush(stdout);
											if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(BomAna_Role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
											printf("\n MT:PCBU:No_BomAna :[%d]",No_BomAna);  fflush(stdout);
											if(No_BomAna>0)
											{
												for(i=0;i<No_BomAna;i++)
												{	
													printf("\n MT:PCBU:BOM Analyst no: [%d]",i);fflush(stdout);
													if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(BomAna[i],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(objTag);			
													if(ITEM_rev_add_participant(objTag,BomAna_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save(objTag);
													AOM_unlock(objTag);
												}
											}
											AOM_refresh (objTag,TRUE);
											MEM_free(BomAna);
										}
									}
									else
									{
										printf("\n MT:Proj Platform is NULL...");fflush(stdout);
									}
								}
								else
								{
									printf("\n MT: NO Assignment for XO/TOO/PDR dmls...... \n"); fflush(stdout);
								}
								//################# REVIEWERS FOR TASK START #####################/
								printf("\n MT:PVBU:TASK:REMOVING REVIEWERS FOR TASK START......\n");fflush(stdout);
								if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
								if (DmlTask_tag!=NULLTAG)
								{		
									if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
									printf("\n MT:TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
									for (jkk=0;jkk<Tskcout ;jkk++ )
									{
										if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
										//printf("\n MT:.is_Tskletst. %d",is_Tskletst);fflush(stdout);
										if(is_Tskletst != true)
										{
											printf("\n MT:TASK:is_Tskletst is not true .....\n");fflush(stdout);
										}
										else
										{	
											TskRev_tg = TskRev_tag[jkk];
											if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
											if (Tsk_CRB_rel_type!=NULLTAG)
											{
												if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
												printf("\n MT:TASK: count: %d",CRBcunt);fflush(stdout);	
												for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
												{	
													TskCRBTag = TskCRB[jtsk];
													if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
													if(TCTYPE_ask_name(ObjTypTskCRB,type_name8));
													printf("\n MT:TASK: Participant Name: %s\n", type_name8);fflush(stdout);
													if(tc_strcmp(DMLType,"SVR")==0)
													{
														if ((tc_strcmp(type_name8,"T5_BIWReviewer")==0)||(tc_strcmp(type_name8,"T5_PTReviewer")==0)||(tc_strcmp(type_name8,"T5_EEReviewer")==0)||
															(tc_strcmp(type_name8,"T5_CHReviewer")==0)||(tc_strcmp(type_name8,"T5_TRIMReviewer")==0))
														{
															printf("\n MT:TASK:: Removing "); fflush(stdout);
															if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
															printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
															AOM_lock(TskRev_tg);
															if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag) !=ITK_ok)PrintErrorStack();
															AOM_save(TskRev_tg);
															AOM_unlock(TskRev_tg);
														}
													}
													else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
													{
														if ((tc_strcmp(type_name8,"T5_DMUReviewer")==0)|| (tc_strcmp(type_name8,"T5_PeerReviewer")==0))
														{
															printf("\n MT:TASK: Removing "); fflush(stdout);
															if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
															printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
															AOM_lock(TskRev_tg);
															if(ITEM_rev_remove_participant (TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
															AOM_save(TskRev_tg);
															AOM_unlock(TskRev_tg);
														}
													}
													else
													{
														printf("\n MT: Other dml type... \n"); fflush(stdout);
													}
												}
											}
										}
									}

									printf("\n MT:PVBU:ADDING REVIEWERS FOR TASK START......\n");fflush(stdout);
									for (t=0;t<Tskcout ;t++ )
									{ 
										No_DMU=0;
										No_Peer=0;
										if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
										//printf("\n MT:is_Tsklatst %d",is_Tsklatst);fflush(stdout);

										if(is_Tsklatst != true)
										{
											printf("\n MT:is_Tsklatst is not true .....\n");fflush(stdout);
										}
										else
										{	
											TskRev_t = TskRev_tag[t];
											if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
											if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
											printf("\n MT: Task class..:%s",Tsk_class); fflush(stdout);
											if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
											{
												//Setting DMU Reviewers.
												if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
												printf("\n MT: Task Name :[%s]",Task_name);fflush(stdout);
												DsgGrp=subString(Task_name,11,2);
												DsgGrup=(int) atoi(DsgGrp);
												printf(" and design group: [%s]\n",DsgGrp);fflush(stdout);
												if(tc_strcmp(DMLType,"SVR")==0)
												{
													//SVR COC REVIEWER...
													No_SVRcoc=0;
													No_SVRc=0;
													No_SVRe=0;
													No_SVRp=0;
													No_SVRt=0;
													//BIW Reviewer.
													BIW_SVRCoC_role = (char	*)MEM_alloc(100);
													tc_strcpy(BIW_SVRCoC_role,"");
													tc_strcpy(BIW_SVRCoC_role,ProjectID);
													tc_strcat(BIW_SVRCoC_role,"_");
													tc_strcat(BIW_SVRCoC_role,"BIW_COC_Reviewer");
													printf("\n MT: Setting BIW_SVRCoC_role:%s \n",BIW_SVRCoC_role); fflush(stdout);
													if(SA_find_group(groupName, &SVRcocGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(BIW_SVRCoC_role,&SVRcoc_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(SVRcoc_tag,SVRcocGrp_tag,&No_SVRcoc,&SVRcoc_t)!=ITK_ok)PrintErrorStack();
													if(No_SVRcoc>0)
													{
														for(b=0;b<No_SVRcoc;b++)
														{	
															printf("\n MT: BIW_SVRCoC_role: %d",b);fflush(stdout);
															if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh ( TskRev_t,TRUE);
														MEM_free(SVRcoc_t);
													}
													//TRIM Reviewer
													Trim_SVRCoC_role = (char	*)MEM_alloc(100);
													tc_strcpy(Trim_SVRCoC_role,"");
													tc_strcpy(Trim_SVRCoC_role,ProjectID);
													tc_strcat(Trim_SVRCoC_role,"_");
													tc_strcat(Trim_SVRCoC_role,"Trim_COC_Reviewer");
													printf("\n MT: Setting Trim_SVRCoC_role:%s \n",Trim_SVRCoC_role); fflush(stdout);
													if(SA_find_group(groupName, &SVRtGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(Trim_SVRCoC_role,&SVRt_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(SVRt_tag,SVRtGrp_tag,&No_SVRt,&SVRt_t)!=ITK_ok)PrintErrorStack();
													if(No_SVRt>0)
													{
														for(tr=0;tr<No_SVRt;tr++)
														{	
															printf("\n MT: peer reviewer no: %d",tr);fflush(stdout);
															if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,SVRt_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh (TskRev_t,TRUE);
														MEM_free(SVRt_t);
													}
													//CHASSIS SVR ROLE
													CH_SVRCoC_role = (char	*)MEM_alloc(100);
													tc_strcpy(CH_SVRCoC_role,"");
													tc_strcpy(CH_SVRCoC_role,ProjectID);
													tc_strcat(CH_SVRCoC_role,"_");
													tc_strcat(CH_SVRCoC_role,"Chassis_COC_Reviewer");
													printf("\n MT: Setting CH_SVRCoC_role:%s \n",CH_SVRCoC_role); fflush(stdout);
													if(SA_find_group(groupName, &SVRcGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(CH_SVRCoC_role,&SVRc_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(SVRc_tag,SVRcGrp_tag,&No_SVRc,&SVRc_t)!=ITK_ok)PrintErrorStack();
													if(No_SVRc>0)
													{
														for(c=0;c<No_SVRc;c++)
														{	
															printf("\n MT: peer reviewer no: %d",c);fflush(stdout);
															if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,SVRc_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh (TskRev_t,TRUE);
														MEM_free(SVRc_t);
													}
													//EE COC reviewer
													EE_SVRCoC_role = (char	*)MEM_alloc(100);
													tc_strcpy(EE_SVRCoC_role,"");
													tc_strcpy(EE_SVRCoC_role,ProjectID);
													tc_strcat(EE_SVRCoC_role,"_");
													tc_strcat(EE_SVRCoC_role,"EE_COC_Reviewer");
													printf("\n MT: Setting EE_SVRCoC_role:%s \n",EE_SVRCoC_role); fflush(stdout);
													if(SA_find_group(groupName, &SVReGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(EE_SVRCoC_role,&SVRe_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(SVRe_tag,SVReGrp_tag,&No_SVRe,&SVRe_t)!=ITK_ok)PrintErrorStack();
													if(No_SVRe>0)
													{
														for(e=0;e<No_SVRe;e++)
														{	
															printf("\n MT: peer reviewer no: %d",e);fflush(stdout);
															if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,SVRe_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh (TskRev_t,TRUE);
														MEM_free(SVRe_t);
													}
													//Powertrain reviewer
													PT_SVRCoC_role = (char	*)MEM_alloc(100);
													tc_strcpy(PT_SVRCoC_role,"");
													tc_strcpy(PT_SVRCoC_role,ProjectID);
													tc_strcat(PT_SVRCoC_role,"_");
													tc_strcat(PT_SVRCoC_role,"Powertrain_COC_Reviewer");
													printf("\n MT: Setting PT_SVRCoC_role:%s \n",PT_SVRCoC_role); fflush(stdout);
													if(SA_find_group(groupName, &SVRpGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(PT_SVRCoC_role,&SVRp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(SVRp_tag,SVRpGrp_tag,&No_SVRp,&SVRp_t)!=ITK_ok)PrintErrorStack();
													if(No_SVRp>0)
													{
														for(p=0;p<No_SVRp;p++)
														{	
															printf("\n MT: PT_SVRCoC reviewer no: %d",p);fflush(stdout);
															if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,SVRp_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh (TskRev_t,TRUE);
														MEM_free(SVRp_t);
													}
												}
												else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
												{
													//COC DMU Reviewer
													printf("\n MT:SETTING COC DMU Reviewer.....: ");fflush(stdout);
													if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
													if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
													{
														printf("Brake_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Brake_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=60) && (DsgGrup <=66))
													{
														printf("BIW_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(BIW_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=70) && (DsgGrup <=80))
													{
														printf("Door_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Door_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==88)
													{
														printf("ExtTrims_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(ExtTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==81)
													{
														printf("Fit_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Fit_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=67) && (DsgGrup <=69))
													{
														printf("IntTrims_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(IntTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==55)
													{
														printf("Mascots_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Mascots_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=91) && (DsgGrup <=96))
													{
														printf("Seat_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Seat_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
													{
														printf("EE_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(EE_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==49)
													{
														printf("Exhaust_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Exhaust_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==31)
													{
														printf("Frame_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Frame_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==47)
													{
														printf("Fuel_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Fuel_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==83)
													{
														printf("HVAC_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(HVAC_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==24)
													{
														printf("Mounts_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Mounts_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==97)
													{
														printf("Restrn_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Restrn_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==46)
													{
														printf("Steering_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Steering_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
													{
														printf("Suspension_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Suspension_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==58)
													{
														printf("Tools_DMU_role.. \n"); fflush(stdout);
														if(SA_find_role2(Tools_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
													}
													else
													{
														printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
													}
													
													printf("\n MT: Find  grp member for DMU count..%d \n",No_DMU); fflush(stdout);
													if(No_DMU>0)
													{
														im=0;
														for(im=0;im<No_DMU;im++)
														{	
															printf("\n MT: DMU Reviewer no: %d",im);fflush(stdout);
															if(EPM_get_participanttype ("T5_DMUReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(DMU_t[im],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,DMU_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh ( TskRev_t,TRUE);
														MEM_free(DMU_t);
													}
													
													//COC PEER REVIEWER...
													printf("\n MT:SETTING COC Peer Reviewer.....: ");fflush(stdout);
													if(SA_find_group(groupName, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
													if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
													{
														printf("Brake_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Brake_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=60) && (DsgGrup <=66))
													{
														printf("BIW_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(BIW_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=70) && (DsgGrup <=80))
													{
														printf("Door_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Door_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==88)
													{
														printf("ExtTrims_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(ExtTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==81)
													{
														printf("Fit_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Fit_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=67) && (DsgGrup <=69))
													{
														printf("IntTrims_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(IntTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==55)
													{
														printf("Mascots_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Mascots_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if ((DsgGrup >=91) && (DsgGrup <=96))
													{
														printf("Seat_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Seat_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
													{
														printf("EE_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(EE_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==49)
													{
														printf("Exhaust_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Exhaust_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==31)
													{
														printf("Frame_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Frame_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==47)
													{
														printf("Fuel_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Fuel_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==83)
													{
														printf("HVAC_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(HVAC_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==24)
													{
														printf("Mounts_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Mounts_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==97)
													{
														printf("Restrn_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Restrn_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if(DsgGrup ==46)
													{
														printf("Steering_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Steering_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
													{
														printf("Suspension_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Suspension_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else  if(DsgGrup ==58)
													{
														printf("Tools_Peer_role.. \n"); fflush(stdout);
														if(SA_find_role2(Tools_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
													}
													else
													{
														printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
													}
													printf("\n MT: Find  grp member for Peer count..%d \n",No_Peer); fflush(stdout);
													if(No_Peer>0)
													{
														ii=0;
														for(ii=0;ii<No_Peer;ii++)
														{	
															printf("\n MT: peer reviewer no: %d",ii);fflush(stdout);
															if(EPM_get_participanttype ("T5_PeerReviewer",&Peer_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(Peer_t[ii],Peer_Patri_Type,&Peer_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(TskRev_t);			
															if(ITEM_rev_add_participant(TskRev_t,Peer_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save(TskRev_t);
															AOM_unlock(TskRev_t);
														}
														AOM_refresh ( TskRev_t,TRUE);
														MEM_free(Peer_t);
													}
												}
												else
												{
													printf("\n MT: Other DML Type...... \n"); fflush(stdout);
												}
											}
										}
									}
								}
							}
							else if(tc_strcmp(Proj_BU,"CVBU")==0)
							{
								if(tc_strcmp(DMLType,"SVR")==0)
								{
									//VI Reviewer for SVR only.
									printf("\n MT: Setting VI Analyst...");fflush(stdout);
									if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
									printf("\n MT:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
									if(No_VIAna>0)
									{
										for(iii=0;iii<No_VIAna;iii++)
										{	
											printf("\n MT: VI Reviewer no: [%d]",iii);fflush(stdout);
											if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
											AOM_lock(objTag);			
											if(ITEM_rev_add_participant(objTag,VIAna_Party)!=ITK_ok)PrintErrorStack();
											AOM_save(objTag);
											AOM_unlock(objTag);
										}
									}
									AOM_refresh ( objTag,TRUE);
									MEM_free(VIAna);
								}
								else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
								{
									if(tc_strcmp(Proj_BU,"CVBU")==0)
									{
										//BOM Analyst
										printf("\n MT: Setting BOM Analyst...");fflush(stdout);
										if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(BomAnalyst_role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
										printf("\n MT:No_BomAna  ---> [%d]",No_BomAna);  fflush(stdout);
										if(No_BomAna>0)
										{
											for(i=0;i<No_BomAna;i++)
											{	
												printf("\n MT:BOM Analyst no: [%d]",i);fflush(stdout);
												if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
												if(EPM_create_participant(BomAna[i],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
												AOM_lock(objTag);			
												if(ITEM_rev_add_participant(objTag,BomAna_Party)!=ITK_ok)PrintErrorStack();	
												AOM_save(objTag);
												AOM_unlock(objTag);
											}
										}
										AOM_refresh (objTag,TRUE);
										MEM_free(BomAna);

										//CE Reviewer not for PCBU.
										printf("\n MT: Setting CE Reviewer...");fflush(stdout);
										if(SA_find_group(groupName, &CEGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(CEAnalyst_role,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
										printf("\n MT:No_CEAna  :[%d]",No_CEAna);  fflush(stdout);

										if(No_CEAna>0)
										{
											for(ik=0;ik<No_CEAna;ik++)
											{	
												printf("\n MT:CE Reviewer no: %d",ik);fflush(stdout);
												if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
												if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
												AOM_lock(objTag);			
												if(ITEM_rev_add_participant(objTag,CEAna_Party)!=ITK_ok)PrintErrorStack();	
												AOM_save(objTag);
												AOM_unlock(objTag);
											}
										}
										AOM_refresh ( objTag,TRUE);
										MEM_free(CEAna);
									}
									else
									{
										printf("\n MT:CVBU:Other DMl...");fflush(stdout);
									}
								}
								else
								{
									printf("\n MT: NO Assignment for XO/TOO/PDR dmls...... \n"); fflush(stdout);
								}
							}
							else
							{
								printf("\n MT: PRD Dml..... \n"); fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n NO PROJECT AVAILABLE..\n");fflush(stdout);
					}
				}
				else
				{
					PRDFlag=0;
					printf("\n MT: No project found: %d",PRDFlag); fflush(stdout);
				}
			}
		}
	}
	return error_code;
}

/****************************************************************************
*   Function name			: Assign_Platform_Review_Func
*   Description				: To set PP Reviewer as per platform of project and decide for DML to send for PP reviewer.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		04/07/2018			Mohan Tayade	1.37: Assign PP reviewer
*
****************************************************************************/

int Assign_Platform_Review_Func(EPM_action_message_t msg)
{
	tag_t	root_task        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	char	*ObjTyp			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	//char   ObjTyp[TCTYPE_name_size_c+1];
	char	*groupName		= NULL;

	//Platform Reviewer (DML)
	int     pp = 0;
	int     No_PPAna = 0;
	tag_t   PPAna_Rev			= NULLTAG;
	tag_t   PPGrp_tag			= NULLTAG;
	tag_t   PPAnalyst_tag		= NULLTAG;
	tag_t	PPAna_Patri_Type	= NULLTAG;
	tag_t*  PPAna				= NULLTAG;
	tag_t	PPAna_Party		= NULLTAG;
	const char*   Def_PPAna_role = "Def_PPAnalyst";
	const char*   UV_PPAna_role = "UV_PPAnalyst";
	const char*   X0_PPAna_role = "X0_PPAnalyst";
	const char*   X1_PPAna_role = "X1_PPAnalyst";
	const char*   X2_PPAna_role = "X2_PPAnalyst";
	const char*   X3_PPAna_role = "X3_PPAnalyst";
	const char*   X4_PPAna_role = "X4_PPAnalyst";

	// Participants remove.
	int jk = 0;
	int kk = 0;
	int CRBcount = 0;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	TskTypeTag1	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	char   type_name7[TCTYPE_name_size_c+1];
	char   Tsk_Typ[TCTYPE_name_size_c+1];
	char   Tsk_Type[TCTYPE_name_size_c+1];
	logical is_Tskltst;
	logical is_Tsklatst;

	//Task variables
	int     PltFrmPartFlg	=  0;
	int     prt		=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     pcnts		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*Modltyp		= NULL;
	char	*BomAna_Role		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *Parts_t    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	Assy_t		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	int ifail = ITK_ok;

	//Qry project
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	user_tag  = NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char*	username	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   window     = NULLTAG; 
	tag_t   rule     = NULLTAG; 
	tag_t   top_line     = NULLTAG;
	tag_t *parents = NULLTAG;
	int     jd    = 1;  
	int     n_entry    = 1;  
	int     PRDFlag      =  0; 
	int     atch      =  0; 
	int     rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	int n_parents,n1_parents = 0;
	int *levels = 0;
	char*	prttyp				=NULL;
	char*	DesgTyp				=NULL;
	char*	Modltype				=NULL;
	char*	modlno				=NULL;
	char*	MObjTyp				=NULL;
	char*	CurrentTask				=NULL;
	char*	task_result				=NULL;
	char*	parent_name				=NULL;
	tag_t job = NULLTAG;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char	current_release_level[WSO_name_size_c + 1];


	printf("\n MT:PP: Dynamic Platform reviewer assignment start.......\n");fflush(stdout);
	// To get the Task Number from workflow..
	ifail = POM_get_user(&username,&user_tag);
	printf("\n MT:Starting for username:[%s]",username);fflush(stdout);

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n MT:Root task found");fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n MT:CurrentTask:%s.",CurrentTask);fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"task_result",&task_result);
	printf("\n MT:task_result:%s.",task_result);fflush(stdout);

	ifail = AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n MT:Parent Name:%s.",parent_name);fflush(stdout);

	ifail = EPM_ask_job( msg.task, &job );
	ifail = EPM_ask_review_task_name( msg.task, current_release_level );
	printf("\n MT:current_release_level :: %s\n",current_release_level); fflush(stdout);
	//if(tc_strcmp(parent_name,"Change Request Life Cycle")==0)
	//{
		//if(tc_strstr(CurrentTask,"Condition")!=NULL)
		//{
			if(EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
			printf("\n MT:PP:No of Attachements: [%d]", no_attach);fflush(stdout);
			if(no_attach> 0)
			{
				for(atch=0;atch<no_attach;atch++)
				{
					objTag = attachment[atch];
					if(AOM_ask_value_string(attachment[atch],"object_type",&ObjTyp)!=ITK_ok)PrintErrorStack();
					printf("\n ObjTyp is :%s\n",ObjTyp);fflush(stdout);

					if(AOM_ask_value_string(attachment[atch],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
					printf("\n DMLNo is :%s\n",DMLNo);fflush(stdout);

					if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						groupName = (char	*)MEM_alloc(100);
						tc_strcpy(groupName,"DML_Participants_Group");
						printf("\n MT:PP: groupName : %s",groupName);   fflush(stdout);

						if(AOM_ask_value_string(attachment[atch],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						printf("\n MT:PP:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);

						if(tc_strcmp(DMLType,"Veh")!=0)
						{
							if(AOM_ask_value_string(attachment[atch],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
							printf("\n MT:PP: ProjectID : %s",ProjectID);   fflush(stdout);
							if(ProjectID)
							{
								if(QRY_find("Qury_Project", &queryTag));
								printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
								if (queryTag)
								{
									printf("\n MT:Found Query");fflush(stdout);
								}
								else
								{
									printf("\n MT:Not Found Query");fflush(stdout);
								}
								qry_values[0] = ProjectID;

								if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
								printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

								if(resultCount > 0)
								{
									printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
									Project_t = t5_Project[0];
									if (Project_t!=NULLTAG)
									{
										if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
										printf("\n MT: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);

										if(tc_strcmp(ProjectClass,"PRD")==0)
										{
											//Query control table for PRDtoCVBU workflow project list.
											printf("\n MT:Checking PRD  to CVBU WF project...\n"); fflush(stdout);
											if(QRY_find("ControlObjects", &qryTag));
											if (qryTag)
											{
												printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
											}
											else
											{
												printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
											}

											qry_values2[0] = "PRDCVBU";
											if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
											printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
											if(rsltCount > 0)
											{
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
												printf("\n info1 is :[%s]\n", info1);fflush(stdout);
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
												printf("\n info2 is :[%s]\n", info2);fflush(stdout);
												if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
												printf("\n info3 is :[%s]\n", info3);fflush(stdout);
												if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
												{
													PRDFlag=1;
													printf("\n MT: PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
												}
												else
												{
													PRDFlag=0;
													printf("\n MT: No project CVBU found: %d",PRDFlag); fflush(stdout);
												}
											}
											else
											{
												PRDFlag=0;
												printf("\n MT: No project PRDCVBU found: %d",PRDFlag); fflush(stdout);
											}
										}
										else
										{
											PRDFlag=1;
											printf("\n MT: No PRD project: %d",PRDFlag); fflush(stdout);
										}
										if (PRDFlag >0)
										{
											printf("\n MT:PASS: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
											if (((tc_strcmp(Proj_BU,"PCBU")==0)||(tc_strcmp(Proj_BU,"PVBU")==0))&&((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0)&&(tc_strcmp(DMLType,"SVR")!=0)))
											{
												//REMOVE PARTICIPALNTS START
												if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
												if (dml_CRB_rel_type!=NULLTAG)
												{
													printf("\n MT:PP: REMOVE PARTICIPALNTS START......... \n"); fflush(stdout);
													if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
													printf("\n MT:PP: DmlCRB count: %d",CRBcount);fflush(stdout);	
													for (jk=0;jk<CRBcount ;jk++ )
													{	
														DmlCRBTag = DmlCRB[jk];
														if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
														if(TCTYPE_ask_name(ObjTypDmlCRB,type_name7));
														printf("\n MT:PP:DML: type_name7 :: %s", type_name7);fflush(stdout);
														if(tc_strcmp(DMLType,"SVR")!=0)
														{
															if (tc_strcmp(type_name7,"T5_PPReviewer")==0)
															{
																if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
																printf("\n MT:PP: Removing PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
																AOM_lock(objTag);
																if(ITEM_rev_remove_participant (objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
																AOM_save(objTag);
																AOM_unlock(objTag);
															}
														}
													}
												}
												printf("\n MT:PP:START ASSIGNING PLATFORM REVIEWER: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]\n", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
												if(tc_strcmp(Proj_PltFrm,"")!=0)
												{
													//Check if part of 5447 project available in task.WORKINGgggg
													if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
													if (DmlTsk_tag!=NULLTAG)
													{		
														if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
														printf("\n MT:PP: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
														for (kk=0;kk<Taskcout ;kk++ )
														{
															if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
															if(TCTYPE_ask_name(TskTypeTag,Tsk_Typ));
															printf("\n MT:PP: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
															if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
															{
																if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																if(is_Tskltst != true)
																{
																	printf("\n MT:PP:is_Tskltst is not true .....\n");fflush(stdout);
																}
																else
																{
																	if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																	printf("\n MT:PP: partcnt.:%d\n",partcnt);fflush(stdout);
																	if (partcnt>0)
																	{
																		prt=0;
																		PltFrmPartFlg=0;
																		for (prt=0;prt<partcnt ;prt++ )
																		{							
																			AssyTag=PartsTag[prt];
																			if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																			printf("\n MT:PP:.Part_no:%s ...",Part_no);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																			printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																			printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																			
																			//If 14 digit part and part type is Module then get Module type...
																			if(tc_strcmp(Part_prj,"5447")==0)
																			{
																				PltFrmPartFlg++;
																				printf("\n PltFrmPartFlg...BREAKING1: [%d]\n", PltFrmPartFlg);fflush(stdout);
																				break;
																			}
																			else if ((tc_strcmp(DesgTyp,"M")==0)&&(strlen(Part_no) ==14))
																			{
																				//get the Module type t5_ModuleType	....																					
																				if(AOM_ask_value_string(AssyTag,"t5_ModuleType",&Modltyp)!=ITK_ok)PrintErrorStack();
																				printf("\n MT:PP:Modltyp:%s ...",Modltyp);	fflush(stdout);
																				if (tc_strcmp(Modltyp,"PLATFORM")==0)
																				{
																					PltFrmPartFlg++;
																					printf("\n PltFrmPartFlg...BREAKING2: [%d]\n", PltFrmPartFlg);fflush(stdout);
																					break;
																				}
																			}
																		}
																		if (PltFrmPartFlg >0)
																		{
																			break;
																		}
																	}
																}
															}
														}
														printf("\n After first for loop.... \n"); fflush(stdout);
														if(tc_strstr(info3,"PLATFORM")==NULL)
														{
															if (PltFrmPartFlg ==0)
															{
																kk=0;
																for (kk=0;kk<Taskcout ;kk++ )
																{
																	if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag1));
																	if(TCTYPE_ask_name(TskTypeTag1,Tsk_Type));
																	printf("\n MT:PP: Tsk_Type := %s", Tsk_Type);fflush(stdout); 
																	if(tc_strcmp(Tsk_Type,"T5_ChangeTaskRevision")==0)
																	{
																		if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
																		if(is_Tsklatst != true)
																		{
																			printf("\n MT:PP:is_Tsklatst is not true .....\n");fflush(stdout);
																		}
																		else
																		{
																			partcnt=0;
																			if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&Parts_t)!=ITK_ok)PrintErrorStack();
																			printf("\n MT:PP:Now partcnt:%d\n",partcnt);fflush(stdout);
																			if (partcnt>0)
																			{
																				prt=0;
																				PltFrmPartFlg=0;
																				for (prt=0;prt<partcnt ;prt++ )
																				{	
																					Part_no = NULL;
																					Part_prj = NULL;
																					DesgTyp = NULL;
																					Part_no = NULL;
																					Assy_t=Parts_t[prt];
																					if(AOM_ask_value_string(Assy_t,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																					printf("\n MT:PP:Part_no:%s ...",Part_no);	fflush(stdout);
																					if (AOM_ask_value_string(Assy_t,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																					printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																					if (AOM_ask_value_string(Assy_t,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																					printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);

																					if (((tc_strcmp(DesgTyp,"A")==0)||(tc_strcmp(DesgTyp,"C")==0)||(tc_strcmp(DesgTyp,"G")==0))&&(strlen(Part_no) ==12))
																					{
																						//Implossion: If 12 digit part.
																						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
																						if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_top_line (window, null_tag,Assy_t , null_tag, &top_line)!=ITK_ok)PrintErrorStack();

																						PS_where_used_all( Assy_t, PS_where_used_all_levels, &n_parents, &levels, &parents );
																						printf("\n CP where_used count of parents: %d",n_parents); fflush(stdout);
																						if(n_parents>0)
																						{
																							jd=0;
																							for (jd=0;jd<n_parents;jd++ )
																							{
																								prttyp	= NULL;
																								Modltype	= NULL;
																								MObjTyp	= NULL;
																								modlno	= NULL;
																								if(AOM_ask_value_string(parents[jd],"item_id",&modlno)!=ITK_ok)PrintErrorStack(); 
																								printf("\n\t part no:[%s]",modlno);	fflush(stdout);
																								if(AOM_ask_value_string(parents[jd],"object_type",&MObjTyp)!=ITK_ok)PrintErrorStack();
																								printf("\t Objtype :[%s]",MObjTyp);fflush(stdout);
																								if(tc_strcmp(MObjTyp,"Design Revision")==0 || tc_strcmp(MObjTyp,"ItemRevision")==0)
																								{
																									if (AOM_ask_value_string(parents[jd],"t5_PartType",&prttyp)!=ITK_ok)   PrintErrorStack();
																									printf("\t Parttype:[%s]",prttyp);	fflush(stdout);
																									if (tc_strcmp(prttyp,"M")==0)
																									{
																										//get the Module type t5_ModuleType	....																					
																										if(AOM_ask_value_string(parents[jd],"t5_ModuleType",&Modltype)!=ITK_ok)PrintErrorStack();
																										printf("\t Modltype:[%s]",Modltype);	fflush(stdout);
																										if (tc_strcmp(Modltype,"PLATFORM")==0)
																										{
																											PltFrmPartFlg++;
																											printf("\t CONFIRMED.....:[%s] ...",Modltype);	fflush(stdout);
																											break;
																										}
																									}
																								}
																							}
																							if (PltFrmPartFlg >0)
																							{
																								break;
																							}
																						}
																					}
																				}
																				if (PltFrmPartFlg >0)
																				{
																					break;
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													printf("\n Setting PP reviewer.... \n"); fflush(stdout);
													if (PltFrmPartFlg >0)
													{
														if(SA_find_group(groupName, &PPGrp_tag)!=ITK_ok)PrintErrorStack();
														if(tc_strcmp(Proj_PltFrm,"Defence")==0)
														{
															printf("Def_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(Def_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"UV")==0)
														{
															printf("UV_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(UV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X0")==0)
														{
															printf("X0_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X0_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X1")==0)
														{
															printf("X1_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X1_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X2")==0)
														{
															printf("X2_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X2_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X3")==0)
														{
															printf("X3_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X3_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X4")==0)
														{
															printf("X4_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X4_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else
														{
															printf("OTHER PLATFORM... \n"); fflush(stdout);
															if(SA_find_role2(Def_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
													
														printf("\n MT:No_PPAna :[%d]",No_PPAna);  fflush(stdout);
														if(No_PPAna>0)
														{
															for(pp=0;pp<No_PPAna;pp++)
															{	
																printf("\n MT:PP Analyst no: [%d]",pp);fflush(stdout);
																if(EPM_get_participanttype ("T5_PPReviewer",&PPAna_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_create_participant(PPAna[pp],PPAna_Patri_Type,&PPAna_Party)!=ITK_ok)PrintErrorStack();
																AOM_lock(objTag);			
																if(ITEM_rev_add_participant(objTag,PPAna_Party)!=ITK_ok)PrintErrorStack();	
																AOM_save(objTag);
																AOM_unlock(objTag);
															}
														}
														AOM_refresh ( objTag,TRUE);
														MEM_free(PPAna);
														//break;
													}
												}
											}
										}
										else
										{
											printf("\n PRD project or NO project available..\n");fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
			}
		//}
	//}
	printf("\n MT:PP:Now PltFrmPartFlg:%d ",PltFrmPartFlg);fflush(stdout);
	if (PltFrmPartFlg >0)
	{
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
		printf("\n EPM_RESULT_True inside PP Reviewer: %d",ifail); fflush(stdout);	
	}
	else
	{
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
		printf("\n EPM_RESULT_False: %d",ifail); fflush(stdout);
	}

	return ifail;
}

int Assign_Dynamic_party_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{
		retcode = EPM_register_action_handler (
								"Assign_Dynamic_party",
								"Assign_Dynamic_party",
								(EPM_action_handler_t)Assign_Dynamic_party_Func
								);
		//Platform Reviewer
		retcode = EPM_register_action_handler (
								"Assign_Platform_Review",
								"Assign_Platform_Review",
								(EPM_action_handler_t)Assign_Platform_Review_Func
								);

		printf("\n at the end.....\n");fflush(stdout);
	}
	return retcode;
}

extern int Assign_Dynamic_party_action(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	

	printf("\n before .... ");fflush(stdout);
	status = Assign_Dynamic_party_register_action_handlers();
	printf("\n after ..... ");fflush(stdout);
	return status;
}

extern DLLAPI int Assign_Dynamic_party_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n\n before calling ..\n");
    ifail=CUSTOM_register_exit("Assign_Dynamic_party","USER_init_module",(CUSTOM_EXIT_ftn_t)Assign_Dynamic_party_action);
	printf("\n\n after calling ...\n");
	
    return ( ITK_ok );
}
