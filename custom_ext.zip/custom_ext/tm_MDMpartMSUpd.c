/*************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Mohan Tayade
*  Module               :   Workflow Action Handler to update latest released revisin of parts attached to MDM.
*  Code                 :   tm_MDMpartMSUpd.c
*  Created on			:   26/04/2022
*  Reference File		:	tm_GMDPartsDRUpd.c
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes

*******************************************************************************************************************************/

#include "TMLLibrary_server_exits.h"

int tm_MDMpartMSUpd(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	int i      =  0;
	int no_attach	=  0;
	int error_code	= ITK_ok;
	char *DMlid		= NULL;
	char *POinfo3		= NULL;
	char*   ObjTyp= NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	char command[512];
	//control logic:
	tag_t   DRqryTag		= NULLTAG;
	int     DR_n_entry		= 1;
	int     DR_rsltCount	= 0;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	tag_t   *DRCntrlObjectTag   = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	
	printf("\n tm_MDMpartMSUpd Function started...");fflush(stdout);
	TC_write_syslog("\n tm_MDMpartMSUpd Function started...");

	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n RPT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				//Control object logic:
				if(QRY_find2("ControlObjects", &DRqryTag));
				if (DRqryTag)
				{
					printf("\n MDMCHK:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n MDMCHK:Not Found Query ControlObjects \n");fflush(stdout);
				}

				DR_qry_values2[0] = "MDMCHK";
				if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &DRCntrlObjectTag));
				printf(" \n MDMCHK:DR_rsltCount:%d:", DR_rsltCount); fflush(stdout);
				if(DR_rsltCount > 0)
				{
					if (AOM_ask_value_string(DRCntrlObjectTag[0],"t5_Userinfo3",&POinfo3)!=ITK_ok)   PrintErrorStack();
					printf("\n POinfo3 is :[%s]\n", POinfo3);fflush(stdout);
					if(strstr(POinfo3,"MDMUPDVALOFF")==NULL)
					{
						if(strstr(POinfo3,"MDMUPDVALIUAPROD")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n UAPROD:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/MDMprtUpd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"MDMUPDVALICVPROD")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n CVPROD:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/user/cvprod/shells/DML_DCR/MDMprtUpd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"MDMUPDVALICMITEST")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n CMITEST:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/home/cmitest/TC_ROOT_10/bin/tml_tools/MDMprtUpd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else if(strstr(POinfo3,"MDMUPDVALIUADEV")==NULL)
						{
							if(AOM_UIF_ask_value(taskAttachments[i], "item_id", &DMlid)!=ITK_ok)   PrintErrorStack();
							printf("\n UADEV:DML no : %s ", DMlid);fflush(stdout);
							sprintf(command,"/home/uadev/TC_ROOT/bin/tml_tools/MDMprtUpd.sh %s ",DMlid);
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
						else
						{
							printf("\n POCHCK:other client \n");fflush(stdout);
						}
					}
				}
			}
		}
	}
	printf("\n tm_MDMpartMSUpd Function end...");fflush(stdout);
	TC_write_syslog("\n tm_MDMpartMSUpd Function end...");
	//return error_code;
	return 0;
}