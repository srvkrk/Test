
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_CEDCoatedPart.c
*
* Description		: > This contains custom user service and handler. Implemented Custom ITK functions for CED Part Creation logic
> This ITK functions are called in Rich Client 
* Module  		        
* Since		    :    
* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 23/09/2019   	Rajan Singh			    Reference SOR availability in References folder under part whose part category is BTS*

* -----------------------------------------------------------------------------
*
*****************************************************************************/				
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/aom_prop.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
//#include <tccore/iman_msg.h>
#include <tc/envelope.h>

#define T5_WorkFlowHandlerRefSorErr (EMH_USER_error_base + 710)
#define MAX_LINE_LEN 1024
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_err 910001


#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


		
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

int getRefSorTCObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	printf("\nREFSOR:object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("nREFSORgetLatestPart: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}

/* Function to add string into a set of string */
void tmRefSorSetAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}


EPM_decision_t tm_CheckRefSORAttachedToPartFn( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	const char * prog_name ="tm_CheckRefSORAttachedToPartFn";
	
	
	int n_found = 0 ;
	int n_entries = 1 ;
	char *qry_entries[1] = { "SUBSYSCD" } ;
	char *qry_values[1] =  { "RefSorCheck" } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;
	int refCheckfalg = 0;
	//char* deleteInd = NULL;
	//logical deleteInd = TRUE;
	char *ERCInf1   = NULL;
	char *ERCInf2   = NULL;
	char *ERCInf3   = NULL;
	char *ERCInf4   = NULL;
	char *ERCInf5   = NULL;
	char *ERCInf6   = NULL;
	char *ERCInf7   = NULL;
	char *ERCInf8   = NULL;
	char *ERCInf9   = NULL;
	char *ERCInf10   = NULL;

		
	printf("\n\nREFSOR: control_object_Check for Reference SOR: ");fflush(stdout);
	CALLAPI(QRY_find2("Control Objects...", &query));
	CALLAPI(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));

	// Print the number of found objects
	printf("REFSOR: n_found : [%d]", n_found);
	fflush(stdout);
	TC_write_syslog("REFSOR: n_found : [%d]", n_found);
	fflush(stdout);

	if (n_found > 0) 
	{
		//CALLAPI(AOM_ask_value_logical(cntr_objects[0], "t5_DelInd", &deleteInd));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo1",&ERCInf1));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo2",&ERCInf2));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo3",&ERCInf3));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo4",&ERCInf4));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo5",&ERCInf5));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo6",&ERCInf6));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo7",&ERCInf7));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo8",&ERCInf8));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo9",&ERCInf9));
		CALLAPI ( AOM_ask_value_string ( cntr_objects[0], "t5_userinfo10",&ERCInf10));
		printf("REFSOR: Information 1 for RefSorCheck  is [%s] \n",ERCInf1 );fflush(stdout);
		
		if(tc_strstr(ERCInf1,"ON")!=NULL)
		{  
			refCheckfalg=1;
			printf("REFSOR: Information 1 is >>> ON >>> Continue execution\n");fflush(stdout);
		}
	}
	
	if(refCheckfalg>0)
	{
		CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		//printf("\nRoot task found");fflush(stdout);
		
		CALLAPI(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
		//printf("\nCurrent Task:%s\n",currentTaskName);fflush(stdout);

		CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
		//printf("\nParent Name:%s\n",parentTaskName);fflush(stdout);	
		
		CALLAPI(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
		//printf("\ntargetobjects_count:%d\n",targetobjects_count);fflush(stdout);	
		
		
		
		printf("\nREFSOR:To be implemented\n");fflush(stdout);
		
		tag_t dmlTask = NULLTAG;
		int i = 0;
		for(i=0;i<targetobjects_count;i++)
		{
			char* objectType = NULL;
			//dmlTask = targetobjects[i];
			
			//ifail = AOM_ask_value_string(dmlTask,"object_type",&objectType);
			ifail = AOM_ask_value_string(targetobjects[i],"object_type",&objectType);
			printf("REFSOR:targetobjects[i] objectType===>[%s]\n",objectType);fflush(stdout);
			
			if(tc_strcmp(objectType,"T5_ChangeTaskRevision")==0)
			{
				ifail = AOM_ask_value_string(dmlTask,"object_type",&objectType);
				dmlTask = targetobjects[i];
				break;
			}
				
			
		}
		
			if(dmlTask != NULLTAG)
			{
				int partCnt = 0;
				tag_t* partTagObjects = NULL;
				CALLAPI(AOM_ask_value_tags(dmlTask,"CMHasSolutionItem",&partCnt,&partTagObjects));
				
				printf("REFSOR:part count===>[%d]\n",partCnt);fflush(stdout);
				
				int j = 0;
				
				char** errorPartList = NULL;
				int errorPartCnt = 0;
				
				for(j=0;j<partCnt;j++)
				{
					tag_t partObj = NULLTAG;
					logical applicable = FALSE;
					char* partNo = NULL;
					char* partCategory = NULL;
					char* BulkMaterial11 = NULL;
					char* PO_Revision = NULL;
					partObj = partTagObjects[j];
					char *revId = NULL, *revIdDup = NULL;
					char *Revtok = NULL, *Seqtok = NULL;
					int n_POentries = 2;
					tag_t PO_query_tag = NULLTAG;
					int n_PO_ObjFound = 0;
					tag_t *tPO_ObjResults = NULLTAG;
					char *ercDup = NULL;
					
					ifail = AOM_ask_value_string(partObj,"item_id",&partNo);
					ifail = AOM_ask_value_string(partObj,"current_revision_id",&revId);
					printf("REFSOR: Part Number:[%s] - Revision:[%s]",partNo,revId);fflush(stdout);
					tc_strdup(revId, &revIdDup);					
					if (revIdDup)
					{
						Revtok = strtok(revIdDup, ";");
						Seqtok = strtok(NULL, ";");

						if (Revtok && Seqtok)
						{
							printf("REFSOR: Revtok = [%s], Seqtok = [%s]\n", Revtok, Seqtok);
						}	
					}
					ifail = AOM_ask_value_string(partObj,"t5_SpareCriteria",&partCategory);
					if (partCategory == NULL || tc_strlen(partCategory) == 0) 
					{
						partCategory = "";
						printf("REFSOR: Part Category is NULL or Blank\n");fflush(stdout);
					}
					if (tc_strstr(partCategory, "BTS") != NULL) //RSS
					{
						if (ERCInf3 && Revtok)
						{
							
							tc_strdup(ERCInf3, &ercDup);

							char *ercToken = strtok(ercDup, " ");
							logical revtokMatched = FALSE;

							while (ercToken != NULL)
							{
								if (tc_strcmp(ercToken, Revtok) == 0)
								{
									revtokMatched = TRUE;
									break;
								}
								ercToken = strtok(NULL, " ");
							}
							//MEM_free(ercDup);
							
							if (revtokMatched) //Revision Matched with Control Object
							{
								QRY_find2("Part PO Details",&PO_query_tag);
								if (PO_query_tag != NULLTAG )
								{
									char *cEntries[2] = {"PO Revision", "Name"};
									char *cValues[2] = {Revtok, partNo};
									printf("REFSOR: Part PO Details Query Found Successfully...\n"); fflush(stdout);
									CALLAPI(QRY_execute(PO_query_tag, n_POentries, cEntries, cValues, &n_PO_ObjFound, &tPO_ObjResults));
									printf("REFSOR: PO Revision Count: [%d]\n",n_PO_ObjFound);fflush(stdout);
									if (n_PO_ObjFound > 0)
									{
										ifail = AOM_ask_value_string(tPO_ObjResults[0], "t5_BulkMaterial11", &BulkMaterial11);
										ifail = AOM_ask_value_string(tPO_ObjResults[0], "t5_PO_Revision", &PO_Revision);
										if (tc_strcmp(Revtok, PO_Revision)==0)
										{
											printf("REFSOR: Part_Category:[%s] & ** [%s]PO FOUND** >> PLM_Part_Rev:[%s] and SAP_Part_Rev:[%s] are same \n",partCategory,partNo,Revtok,PO_Revision);fflush(stdout);
											applicable = FALSE;
										}
										else
										{
											printf("REFSOR: Part_Category:[%s] - !! [%s]PO NOT FOUND* !! PLM_Part_Rev:[%s] and SAP_Part_Rev:[%s] are NOT same \n",partCategory,partNo,Revtok,PO_Revision);fflush(stdout);
											printf("REFSOR: Applicable to check reference SOR\n");fflush(stdout);
											applicable = TRUE;
										}
										
									}
									else
									{
										applicable = TRUE;
									}
								}
							} //revision didn't matched means No validation for this revision
							else
							{
								printf("REFSOR: Revtok [%s] did not match any tokens in ERCInf3: [%s]\n", Revtok, ERCInf3); fflush(stdout);
							}
						}							
					}
					else
					{
						printf("REFSOR: Part Category is not BTS \n");fflush(stdout);
					}
					if(applicable)
					{
						int refSorCnt = 0;
						tag_t* refSORTags = NULL;
						
						int flgCnt = 0;
						CALLAPI(AOM_ask_value_tags(partObj,"IMAN_reference",&refSorCnt,&refSORTags));
						
						if(refSorCnt > 0)
						{
							int k =0;
							for(k=0;k<refSorCnt;k++)
							{
								char* refSorType = NULL;
								ifail = AOM_ask_value_string(refSORTags[k],"object_type",&refSorType);
								
								if(tc_strcmp(refSorType,"T5_AutoSorRevision")==0 || tc_strcmp(refSorType,"T5_RfiSorRevision")==0)//check the applicable object type e.g RFI sor etc
								{
									printf("\n REFSOR: Type is of T5_AutoSorRevision or T5_RfiSorRevision \n");fflush(stdout);
									flgCnt++;
								}
							}
							
							if(flgCnt>0)
							{
								printf("REFSOR:Ref sor found\n");fflush(stdout);
								//decision = EPM_go;
							}
							else
							{
								printf("REFSOR: Ref sor not found. Adding to the error set:[%s]\n",partNo);fflush(stdout);
								tmRefSorSetAddStr(&errorPartCnt,&errorPartList,partNo);
											
								
							}					
						}
						else
						{
							printf("REFSOR: Ref sor not found. Adding to the error set:[%s]\n",partNo);fflush(stdout);
							tmRefSorSetAddStr(&errorPartCnt,&errorPartList,partNo);
						}								
					}
					else
					{
						printf("REFSOR: The Part:[%s] not applicable for ref sor check\n",partNo);fflush(stdout);
					 
					}
					/* 	if (revIdDup) { MEM_free(revIdDup); printf("Freed revIdDup\n"); }
					if (BulkMaterial11) { MEM_free(BulkMaterial11); printf("Freed BulkMaterial11\n"); }
					if (PO_Revision) { MEM_free(PO_Revision); printf("Freed PO_Revision\n"); }
					if (ercDup) { MEM_free(ercDup); printf("Freed ercDup\n"); } */
					
				}
				
				printf("REFSOR: errorPartCnt:[%d]\n",errorPartCnt);fflush(stdout);
				if(errorPartCnt > 0)
				{
					char* partNoBuff = NULL;
					int p =0;
					partNoBuff = (char*)MEM_alloc(errorPartCnt*50*sizeof(char));
					
					tc_strcpy(partNoBuff,"");
					for(p=0;p<errorPartCnt;p++)
					{
						tc_strcat(partNoBuff,errorPartList[p]);
						
						if(p<errorPartCnt -1)
						tc_strcat(partNoBuff,", ");
					}
					
					
					char* buff = NULL;
					ifail=T5_WorkFlowHandlerRefSorErr;
					buff = (char*)MEM_alloc(sizeof(partNoBuff) + 300);
					sprintf(buff, "No Reference SOR object found in Reference Relation for the Parts[%s]. Kindly attach only OFFER/RFI SOR in References folder under the part", partNoBuff);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					
					if(partNoBuff)MEM_free(partNoBuff);
					if(buff)MEM_free(buff);
					return EPM_nogo;
				}
				else
				{
					return EPM_go;
				}
					
			}
			else
			{
				printf("\nREFSOR: ERC DML Task not found\n");fflush(stdout);
			}
			return EPM_go;
	}
	
	printf("\n REFSOR: <<<<<<<< Reference SOR check is OFF >>>>>>>>\n");fflush(stdout);
	
	return EPM_go; // To soft Check
	//return EPM_nogo; // to Allow Hard Check
}


extern int tm_refSorVald_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS;
 							
   	ifail = EPM_register_rule_handler (
							"tm_CheckRefSORAttachedToPart",
							"tm_CheckRefSORAttachedToPart",
							(EPM_rule_handler_t)tm_CheckRefSORAttachedToPartFn
							);
    return ifail;
}

extern DLLAPI int tm_refSorVald_register_callbacks ()
{	
    int ifail    = ITK_ok;
	printf("\nREFSOR:tm_refSorVald_register_method:Before registoring....");  
    ifail=CUSTOM_register_exit ( "tm_refSorVald", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_refSorVald_register_method);
	printf("\nREFSOR:tm_refSorVald_register_method: After registoring....");
	
	
  return ( ITK_ok );
}

