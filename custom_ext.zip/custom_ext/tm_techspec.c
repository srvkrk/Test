#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_date.h>
#include <tccore/project.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <fclasses/tc_time.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <ps/ps_errors.h>
#include <tccore/aom_prop.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_basic.h>
#include<ics/ics.h>
#include<ics/ics2.h>
#include<ics/ics_defines.h>
#include<ics/ics_errors.h>
#include <bom/bom_errors.h>
#include <bom/bom_msg.h>
#include <bom/bomlines.h>
#include <common/tc_deprecation_macros.h>
	#define	ADD	1
	#define	DEL	-1
	#define	NA	0
	
	#define ITK_err 919006
	int childPartNotExist=0;
	static void ECHO(char *format, ...)
	{
	    char msg[1000];
	    va_list args;
	    va_start(args, format);
	    vsprintf(msg, format, args);
	    va_end(args);
	    printf(msg);
	    TC_write_syslog(msg);
	}
int getICOUpdCO( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs);
int TechSpec4CRVC(char **Info1);
int CreUpdClsValForModule(tag_t ModuleMstrTag,char *ModNum,char *ToBeClsClassName,char *CntrlObjName);
	#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
	#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)
	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
	static int report_error(char *file, int line, char *call, int status,
	    logical exit_on_error)
	{
	    if (status != ITK_ok)
	    {
		/*int
		    n_errors = 0,
		    *severities = NULL,
		    *statuses = NULL;
			*/
			int n_errors = 0;
			const int 
				*severities=NULL,
				*statuses=NULL;
		const char
		    **messages;
			


		EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
		if (n_errors > 0)
		{
		    ECHO("\n%s\n", messages[n_errors-1]);
		    EMH_clear_errors();
		}
		else
		{
		    char *error_message_string;
		    //EMH_get_error_string (NULLTAG, status, &error_message_string);
			EMH_ask_error_text(status,&error_message_string);
		    ECHO("\n%s\n", error_message_string);
		}

		ECHO("error %d at line %d in %s\n", status, line, file);
		ECHO("%s\n", call);

		if (exit_on_error)
		{
		    ECHO("Exiting program!\n");
		    exit (status);
		}
	    }

	    return status;
	}

	#define ITK_CALL(x) {           \
	    int stat;                     \
	    char *err_string;             \
	    if( (stat = (x)) != ITK_ok)   \
	    {                             \
	    EMH_ask_error_text(stat,&err_string);                 \
	    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	    if(err_string) MEM_free(err_string);                                \
	    exit (EXIT_FAILURE);                                                   \
	    }                                                                    \
	}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/* Function to add string into a set of string */
void setAddStrR(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStrR %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((tc_strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStrR===%s",(*strset)[*count-1]);fflush(stdout);

}
int getcntrlobjR( char *val,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SUBSYSCD"},
	*qry_values3[]       = {val};

	printf("\n in getDefaultUsr func");fflush(stdout);
	printf("\n\n Input SUBSYSCD==%s \n",val);fflush(stdout);
	
	printf("\n b4 Qry getDefaultUsr");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getDefaultUsr");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getDefaultUsr control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}

void tm_GetGroupFromNonErcDML(char	*cDMLNumber, char	**cRolename)
{

	printf("\nInside tm_GetRoleFromDML DML Number: %s",cDMLNumber);fflush(stdout);
	
	*cRolename	=	NULL;
	*cRolename	=	(char *) MEM_alloc(20 * sizeof(char *));
	if (tc_strstr(cDMLNumber,"APLC")!=NULL)
	{
		tc_strcpy(*cRolename,"APLCAR");
	}
	else if (tc_strstr(cDMLNumber,"APLP")!=NULL)
	{
		tc_strcpy(*cRolename,"APLPUNE");
	}
	else if (tc_strstr(cDMLNumber,"APLJ")!=NULL)
	{
		tc_strcpy(*cRolename,"APLJSR");
	}
	else if (tc_strstr(cDMLNumber,"APLD")!=NULL)
	{
		tc_strcpy(*cRolename,"APLDWD");
	}
	else if (tc_strstr(cDMLNumber,"APLJ")!=NULL)
	{
		tc_strcpy(*cRolename,"APLJSR");
	}
	else if (tc_strstr(cDMLNumber,"APLA")!=NULL)
	{
		tc_strcpy(*cRolename,"APLAHD");
	}
	else if (tc_strstr(cDMLNumber,"APLS")!=NULL)
	{
		tc_strcpy(*cRolename,"APLSND");
	}
	else if (tc_strstr(cDMLNumber,"APLL")!=NULL)
	{
		tc_strcpy(*cRolename,"APLLKO");
	}
	else if (tc_strstr(cDMLNumber,"APLU")!=NULL)
	{
		tc_strcpy(*cRolename,"APLPNR");
	}
	else if (tc_strstr(cDMLNumber,"APLV")!=NULL)
	{
		tc_strcpy(*cRolename,"APLUV");
	}
	else
	{
		tc_strcpy(*cRolename,"APLCAR");
	}

	printf("\nInside tm_GetRoleFromDML ROLE: %s",*cRolename);fflush(stdout);
}

void  get_CtrlVal_NonErccsInf( char * Tsk_Own_Grp ,char  RevRuleInfo1[40],char  BVRInfo2[40],char  CurMskInfo3[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevRule 			= NULL;
	 char *viewfrmCtrl		= NULL;
	 char *CurVwMask		= NULL;
	 //char *Info4Ctrl		= NULL;
	 //char *Info5Ctrl		= NULL;
	// char *Info6Ctrl		= NULL;
	// char *Info7Ctrl		= NULL;
	// char *Info8Ctrl		= NULL;
	// char *Info9Ctrl		= NULL;

	 if( QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLLcsInf";
				qry_valuesCntrl1[1]=Tsk_Own_Grp;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &viewfrmCtrl);
				printf("\n viewfrmCtrl: %s\n",viewfrmCtrl);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &CurVwMask);
				printf("\n CurVwMask: %s\n",CurVwMask);fflush(stdout);

				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(BVRInfo2,viewfrmCtrl);
				tc_strcpy(CurMskInfo3,CurVwMask);
					
			}
			else
			{
				//tc_strcpy(RevRuleInfo1,"ERC release and above");
				tc_strcpy(RevRuleInfo1,"ERC release and above APLC");//Deepti TZ1.55
				tc_strcpy(BVRInfo2,"View");
				tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskC");
			}
}

int getICOAttrList( char *val,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SUBSYSCD"},
	*qry_values3[]       = {val};

	printf("\n in getICOAttrList func");fflush(stdout);
	printf("\n\n Input SUBSYSCD==%s \n",val);fflush(stdout);
	
	printf("\n b4 Qry getICOAttrList");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getICOAttrList");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getICOAttrList control object size ==%s \n",n_found);fflush(stdout);

	return ifail;
}

int MdmAHBypassChk()
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 3;
	int ifail=0;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	
			printf("\n start func MdmAHBypassChk Calling qry to decide whether this AH will required or not ....\n");
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]="MdmAHBypass";
				qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="0";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
			printf("\n MdmAHBypassChk is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
			ifail= control_number_found;
			 return ifail;
			}
		
printf("\n end the function MdmAHBypassChk with ifail [%d]\n",ifail);fflush(stdout);		
return ifail;
}
int AHBypassChk(char *syscd)
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 3;
	int ifail=0;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	
			printf("\n start func AHBypassChk Calling qry to decide whether this AH will required or not with input syscd=%s....\n",syscd);
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]=syscd;
				qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="0";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
			printf("\n AHBypassChk is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
			ifail= control_number_found;
			 return ifail;
			}
		
printf("\n end the function AHBypassChk with ifail [%d]\n",ifail);fflush(stdout);		
return ifail;
}
int TechSpecDocRHChk(char *taskid)
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 4;
	int ifail=0;
	char    *qry_entryCntrl[4]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	
			printf("\n start func TechSpecDocRHChk Calling qry to decide whether this AH will required or not with task input[%s] ....\n",taskid);
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]="TechSpecDocRHChk";
				qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="0";
				qry_valuesCntrl[3]=taskid;
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object for TechSpecDocRHChk Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
			printf("\n TechSpecDocRHChk is byapssed with ifail[%d]\n",ifail);fflush(stdout);
			ifail= control_number_found;
			 return ifail;
			}
		
printf("\n end the function TechSpecDocRHChk with ifail [%d]\n",ifail);fflush(stdout);		
return ifail;
}

int getCntrlObj( char *val,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SUBSYSCD"},
	*qry_values3[]       = {val};

	printf("\n in getCntrlObj func");fflush(stdout);
	printf("\n\n Input SUBSYSCD==%s \n",val);fflush(stdout);
	
	printf("\n b4 Qry getCntrlObj");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getCntrlObj");fflush(stdout);
	QRY_execute(query, 1, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getCntrlObj control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}


/*C TS_subString function: It returns a pointer to the TS_subString */
 
char *TS_subString(char *string, int position, int length)
{
   char *pointer;
   int c;
 
   pointer = malloc(length+1);
   
   if (pointer == NULL)
   {
      printf("Unable to allocate memory.\n");
      exit(1);
   }
 
   for (c = 0 ; c < length ; c++)
   {
      *(pointer+c) = *(string+position-1);      
      string++;  
   }
 
   *(pointer+c) = '\0';
 
   return pointer;
}
	
int printObject(tag_t objtag)
{

               int                prop_count=0;
               char**             prop_names=NULL;
               int        num_values=0;
               char**     values =NULL;
               tag_t                   class_tag=NULLTAG;
               char                     *class_name=NULL;
               int j=0,k=0;

               logical propConstReqBool=false;

               int ifail=ITK_ok;

               printf("\n printObject()->");fflush(stdout);

     if(objtag==NULLTAG)
     {
                printf("\nNULLTAG");fflush(stdout);
                return ifail;
     }
               /* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
               ITK_CALL(POM_name_of_class(class_tag, &class_name) );

*/
     char *type_name=NULL;
     tag_t type_tag = NULLTAG;
     ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

     ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));



               ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
               printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
               // printf("\n printObject2 %d",prop_count);fflush(stdout);

               for (k=0;k<prop_count;k++)
               {
               //ITK_CALL(AOM_UIF_ask_values(objtag,prop_names[k],&num_values,&values));
			   ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values));

               tag_t prop_tag = NULLTAG;
               ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
               printf("\n %s:{,[",prop_names[k]);fflush(stdout);

               propConstReqBool=false;
               char *prop_dispay_name=NULL;
               PROP_value_type_t valtype;
               char *valtypeName=NULL;
               ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));

                                                                           printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
                                                                           printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);
                                                                           ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
                                                                           printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);
                                                                           printf("\n]\n");fflush(stdout);

               for(j=0;j<num_values;j++)
               {
               printf("\n\t%s,",values[j]);fflush(stdout);
               }

               printf("\n },");fflush(stdout);

               }
               printf("\n]");fflush(stdout);
return ifail;
}

void setFindStrR(char **view_list,int count,char *str,int *found)
{


	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}


int TS_getCmvrattridItkFunc(char *VehClsBU,char **RetCmvrAttrId)
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 3;
	int ifail=0;
	char    *qry_entryCntrl[3]  = {"SUBSYSCD","Delete Indicator","Name"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	
			printf("\n start func TS_getCmvrattridItkFunc Calling qry to decide whether this AH will required or not ....\n");
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found for TS_getCmvrattridItkFunc \n");fflush(stdout);
				qry_valuesCntrl[0]=VehClsBU;
				qry_valuesCntrl[1]="0";
				//qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="ClsCmvrattrID";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query for TS_getCmvrattridItkFunc not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
			printf("\n TS_getCmvrattridItkFunc is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
			char *syscd=NULL;
			
			AOM_ask_value_string( cntrlObjSet[0], "t5_Syscd", &syscd);
							printf("\n syscd: %s \n",syscd);fflush(stdout);
							
			
			*RetCmvrAttrId=syscd;
			printf("\n RetCmvrAttrId: %s \n",*RetCmvrAttrId);fflush(stdout);
			//ifail= control_number_found;
			// return ifail;
			}
		
printf("\n end the function TS_getCmvrattridItkFunc with ifail [%d] RetCmvrAttrId[%s] \n",ifail,*RetCmvrAttrId);fflush(stdout);		
return ifail;
}

int getLatestReleasedPart2(tag_t partMaster, tag_t *partlist)
{
                int ifail = ITK_ok;
                int partRevCnt=0;
                tag_t* partRevTagObjs = NULLTAG;
                tag_t partRevTag = NULLTAG;
                printf("\nStart of function ==> getLatestPartNew");fflush(stdout);
                if(partMaster == NULLTAG)
                {
                                printf("\nDesign Master===> NULLTAG.Exit--> please check with admin");fflush(stdout);
                                return ifail;
                }
                
                ITKCALL(ITEM_list_all_revs (partMaster, &partRevCnt, &partRevTagObjs));
                printf("\nPart Revision counts :%d\n",partRevCnt);fflush(stdout);
                
                if(partRevCnt>0)
                {
                                int i=0;

                                for(i=partRevCnt-1;i>=0;i--)
                                {
                                                partRevTag = partRevTagObjs[i];
                                                char* itemId = NULL;
                                                char* partRev = NULL;
                                                char* checkedOut = NULL;
                                                char* rel_status = NULL;
                                                ITKCALL(AOM_ask_value_string(partRevTag,"item_id",&itemId));
                                                ITKCALL(AOM_ask_value_string(partRevTag,"item_revision_id",&partRev));
                                                ITKCALL(AOM_UIF_ask_value(partRevTag, "release_status_list", &rel_status));
                                                
                                                //checked_out
                                                ITKCALL(AOM_UIF_ask_value(partRevTag,"checked_out",&checkedOut));
                                                printf("\ngetLatestPartNew - Part object[%d]==>  %s,%s. Checkedout==>%s, Release status==>%s\n",i,itemId,partRev,checkedOut,rel_status);fflush(stdout);
                                                
                                                //Skip the checked out part
                                                if(tc_strcmp(checkedOut, "Y") == 0 )
                                                {
                                                                continue;
                                                }
                                                
                                                if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
                                                {
													//setAddTagObj(cnt,partlist,partRevTag);
													*partlist=partRevTag;
                                                                break;
                                                }
                                                
                                                                                
                                }

                }
				else
				{
					 printf("\n No revision found - partRevCnt[%d]==>",partRevCnt); fflush(stdout);
					 *partlist=NULLTAG;
						
				}
                
				 printf("\n End getLatestReleasedPart func- partRevCnt[%d]==>",partRevCnt); fflush(stdout);
				 
                
                return ifail;
}


void setFindStrRFrom(char **view_list,int count,char *str,int start,int *found)
{


	int k=0;
	*found=0;
	for(k=start;k<count;k++)
	{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
		if(tc_strcmp(view_list[k],str)==0)
		{


			*found=1;
			break;

		}

	}



}

int tm_TSAssignProject(tag_t  itemRev,char* projectcode)
{
	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;
	
	TC_write_syslog("\n Start:tm_TSAssignProject.");
	printf("\n projectcode [%s]",projectcode);fflush(stdout);
	if(PROJ_find(projectcode,&projobj)!=ITK_ok)PrintErrorStack();
	printf("\n Assigned to Project111");fflush(stdout);

	if(projobj !=NULLTAG)
	{
	//	POM_get_user(&username,&user_tag);
	//	if(PROJ_add_members(projobj,1,&user_tag)!=ITK_ok)PrintErrorStack();
		if(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev)!=ITK_ok)PrintErrorStack();
		printf("\n Assigned to Project");fflush(stdout);
	}
	else
	{
		printf("\n Project not found");fflush(stdout);
	}
	//if(AOM_save_without_extensions(itemRev)!=ITK_ok)PrintErrorStack();
	//if(AOM_unlock(itemRev)!=ITK_ok)PrintErrorStack();

	printf ("\n--------------tm_TSAssignProject=Completed--------------------\n");	fflush(stdout);
	TC_write_syslog("\n End:tm_TSAssignProject.");
	//return status;
	return 0;
}
		
	

//Funtion to Create TechSpec for CCV
	int TechSpecCreFun(char *projcode ,char *OwnerDesDept,char *OwnerDesUnit,char *VcClass,char *Desc,char *ProjClass,tag_t *RetTSItem)
	   {
				int ifail = ITK_ok;
	           /* tag_t    itemrev = NULLTAG;
				char *srcview=NULL;
				char *desview=NULL;
				char *status=NULL;*/
				tag_t createInputTag = NULLTAG;
				tag_t createRevInputTag = NULLTAG;
				tag_t type = NULLTAG;
				tag_t revtype = NULLTAG;
			    tag_t item = NULLTAG;
				char *tspartnum=NULL;
				char *tempnum =NULL;
				const char *select_attrs[]={"item_id"};
				int n_rows;
				int n_cols;
				int row;
				int column;
				void ***report;
				char vals[30];
				//char *Item;
				//const char *str_list[15];
				 char FinalItemId[15];
	            
				
				printf("\nInside TechSpecCreFun*******");
				char *basepart=(char *) MEM_alloc(10 * sizeof(char *));
				tspartnum=MEM_alloc(30);
				//tempnum=MEM_alloc(30);
				printf("\n Input Parameters projcode=%s OwnerDesDept=%s OwnerDesUnit=%s VcClass=%s Desc=%s ProjClass=%s",projcode,OwnerDesDept,OwnerDesUnit,VcClass,Desc,ProjClass);
				tc_strcpy(FinalItemId,"2590");
				tc_strcat(FinalItemId,projcode);
				tc_strcpy(basepart,"2590");
				tc_strcat(basepart,projcode);
				tc_strcat(FinalItemId,"*");
				printf("\n FinalItemId=%s",FinalItemId);
				
				
				const char *str_list[15]={FinalItemId};
				printf("\nstr_list[0]=%s",str_list[0]);
				//Create Start
				
				      printf("\nB4 query Build FinalItemId=%s",FinalItemId);
					ERROR_CHECK(POM_enquiry_create ("find_TechSpec_by_type"));
					ERROR_CHECK(POM_enquiry_add_select_attrs ("find_TechSpec_by_type","T5_TSComp", 1, select_attrs));
					ERROR_CHECK(POM_enquiry_set_string_value ("find_TechSpec_by_type","attrval",1,str_list,POM_enquiry_bind_value));
					ERROR_CHECK(POM_enquiry_set_attr_expr ("find_TechSpec_by_type","expr1", "T5_TSComp","item_id",POM_enquiry_like, "attrval"));
					ERROR_CHECK(POM_enquiry_set_where_expr ("find_TechSpec_by_type","expr1"));
					ERROR_CHECK(POM_enquiry_add_order_attr( "find_TechSpec_by_type", "T5_TSComp", "item_id", POM_enquiry_desc_order ));
					ERROR_CHECK(POM_enquiry_execute("find_TechSpec_by_type", &n_rows, &n_cols, &report));
					ERROR_CHECK(POM_enquiry_delete("find_TechSpec_by_type")); 
					
							printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",FinalItemId,n_rows,n_cols,report);
						for (row = 0; row < n_rows; row++)
						{
						for (column = 0; column < n_cols; column++)
						printf("\n Query return=%s\t", report[row][column]);
					
						}
						printf("\n Row =%d Column =%d\t", n_rows,n_cols);
						if(n_rows==0 )
						{
						printf("\nInside start Base part=%s",basepart);
						strcat(basepart,"0001");
						}
						else
						{
							printf("\nInside Base part increment condition=%s ",basepart);
							char *tmpStr=report[0][0];
							printf("\ntmpStr=%s",tmpStr);
							//char *str=TS_subString(tmpStr,9,tc_strlen(tmpStr));
							int last4dig=atoi(TS_subString(tmpStr,9,tc_strlen(tmpStr)));
							last4dig=last4dig+1;
							printf("\n str=%d",last4dig);
							sprintf(vals,"%.4d",last4dig);
							printf("\nInside vals=%s",vals);
					     	strcat(basepart,vals);
						} 
				
					printf("\nto be create part=%s",basepart);
				//create End
				
				
				ERROR_CHECK(TCTYPE_find_type ("T5_TSComp", NULL, &type ));
				ERROR_CHECK(TCTYPE_find_type ("T5_TSCompRevision", NULL, &revtype ));
				ERROR_CHECK(TCTYPE_construct_create_input ( type , &createInputTag));
				ERROR_CHECK(TCTYPE_construct_create_input ( revtype , &createRevInputTag));
				printf("\n TechSpecCreFun1*******");
			  // ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5projectname", projcode));
				
				ERROR_CHECK( AOM_set_value_string(createRevInputTag, "object_desc", Desc));				
				 ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_DsgnDeptCpy", OwnerDesDept));
				ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_DsgnOwnCpy", OwnerDesUnit));
				ERROR_CHECK( AOM_set_value_string(createRevInputTag, "item_revision_id", "A"));
				ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_VCSubClass", VcClass));
				ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_VCClassName", ProjClass)); 
				
				printf("\n TechSpecCreFun2*******");
				
				ERROR_CHECK( AOM_set_value_string(createInputTag, "item_id", basepart));
				ERROR_CHECK( AOM_set_value_string(createInputTag, "object_name", Desc));
				 ERROR_CHECK(AOM_set_value_tag(createInputTag, "revision",createRevInputTag));
			    ERROR_CHECK(TCTYPE_create_object(createInputTag, &item));
				printf("\n TechSpecCreFun5*******");
				
				printf("\n Tech Spec [%s] Created Successfully*******",basepart);
			
			if(item!=NULLTAG)
			{
				ERROR_CHECK( AOM_save_with_extensions(item));
				/*
				if(userid!=NULL)
				{
				   CALLAPI(SA_find_user(userid,&user_tag)); 
				}
					if(user_tag!=NULLTAG)
				    {
						//CALLAPI(AOM_lock(item));
						CALLAPI(POM_set_owning_user(item,user_tag));
                        save_object(item);
						AOM_refresh(item,0) // 0 for if AOM_Lock is not called & do not require to reload
					}
					
				*/
				*RetTSItem=item;
			}
			
			return 	ifail;
	   
	   
	   }
// Func to getting Vehicle from Tech Spec Object 
extern DLLAPI int getVehfrmTechSpec(tag_t TechSpecObj,tag_t* VehFrmTS)
{

	 printf("\n Start func getVehfrmTechSpec\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;


	ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relType));

	printf("\n TechSpecObj=%u relType=%u\n",TechSpecObj,relType);fflush(stdout);
	
	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(TechSpecObj,relType,&count,&primary_objects));
		printf("\n count=%d \n",count);fflush(stdout);
		if(count > 0)
		{

		*VehFrmTS = primary_objects[0];
		}

	}
	return ifail;	

	printf("\n End func getVehfrmTechSpec\n");fflush(stdout);

}


	extern DLLAPI int getVehRelationFrmTS(METHOD_message_t * message, va_list args )
	{

	printf("\n Start func getVehRelationFrmTS\n");fflush(stdout);
    int ifail = ITK_ok;
	tag_t *VehTag=NULLTAG;
	

        tag_t TSTag= message->object_tag;

        va_list largs;

        va_copy( largs, args);
        va_arg( largs, tag_t );
        VehTag = va_arg( largs, tag_t*);
        va_end( largs );

		

			printf("\n Calling func getVehfrmTechSpec\n");fflush(stdout);
			ITK_CALL(getVehfrmTechSpec(TSTag,VehTag));

			printf("\n After func call getVehfrmTechSpec VehTag=%u\n",VehTag);fflush(stdout);
			
				
			
			return ifail;	

		
			
	}
int T5TechSpecCre_pre( METHOD_message_t *msg, va_list args )
{

   printf("\n Start Update *****T5TechSpecCre_pre\n");fflush(stdout);

   int ifail = ITK_ok;
   /* va_list for BOMLine_add_msg */
   va_list largs;
   va_copy( largs, args );               
   tag_t item_tag = va_arg(largs, tag_t);
   tag_t item_rev_tag = va_arg(largs, tag_t);
   logical  isNew = va_arg(args, int);
	

	char *item_id=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	int count;
	int count1;
	tag_t projtag;
	tag_t *Ownprojtag;
	tag_t userSession=NULLTAG;
	char *Type = va_arg(largs, char *);
	va_end( largs );
   printf("\n Start Update *****T5TechSpecCre_pre111\n");fflush(stdout);
	ITK_CALL( AOM_ask_value_string(item_tag, "object_name",&item_id));
	ITK_CALL( AOM_ask_value_string(item_tag, "t5_ProjectCode",&ProjName));
	ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
	printf("\n count=%d Ownprojtag =%u\n",count1,Ownprojtag);fflush(stdout);
	printf("\n ProjName=%s \n",ProjName);fflush(stdout);
	
   if(ProjName)
   {
	printf("\n Inside the func AssignProj ");fflush(stdout);
	//ITK_CALL(AssignProj(ProjName));   
	ITK_CALL(PROJ_find(ProjName, &projtag));
	printf("\n After PROJ_find=%u",projtag);fflush(stdout);
	SA_set_current_project(projtag);
   }
   
   
   printf("\n Start Update *****T5TechSpecCre_pre item_id=%s projcode=%s \n",item_id,projcode);fflush(stdout);
   return 0;

}

/*
int T5TechSpecCre_post( METHOD_message_t *msg, va_list args )
{

	printf("\n Start Update *****T5TechSpecCre_post\n");fflush(stdout);

	int ifail = ITK_ok;
	// va_list for BOMLine_add_msg 
	va_list largs;
	va_copy( largs, args );               
	tag_t item_tag = va_arg(largs, tag_t);
	tag_t item_rev_tag = va_arg(largs, tag_t);
	logical  isNew = va_arg(args, int);			    
	tag_t Attachrelation_type=NULLTAG;
	tag_t Attach_type_rel=NULLTAG;
	tag_t *attachments1;
	tag_t		filetag = NULLTAG;
	tag_t		datasettype = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t  	itemrev= NULLTAG;
	tag_t project	 = NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType	= 1;
	char *item_ids=NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *busUnit=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	int count;
	int cnt1;
	int count1;
	int j;
	tag_t projtag = NULLTAG;
	tag_t *Ownprojtag = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		dataset = NULLTAG;
	logical active = TRUE;
	// char *item_type=NULL;
	// char *design_grp=NULL;
	// char *part_type=NULL;
	// char full_group[20];

	// logical hasBypass=false;
	// logical part_found=false;

	tag_t userSession=NULLTAG;
	char *Type = va_arg(largs, char *);
			   //tag_t *newBomline_tag = va_arg(largs, tag_t *);
			   va_end( largs );
			   printf("\n Start Update *****T5TechSpecCre_post111\n");fflush(stdout);
			   ITK_CALL( AOM_ask_value_string(item_tag, "item_id",&item_ids));
				ITK_CALL( AOM_ask_value_string(item_tag, "object_name",&Desc));
				ITK_CALL( AOM_ask_value_string(item_tag, "t5_ProjectCode",&ProjName));
				ITEM_ask_latest_rev(item_tag,&itemrev);
				ITK_CALL( AOM_ask_value_string(itemrev, "item_revision_id",&Itemrevid));
				ITK_CALL( AOM_ask_value_string(itemrev, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tag(item_tag, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
				printf("\n item_id=%s Desc=%s Itemrevid=%s isNew=%d ProjName=%s busUnit=%s\n",item_ids,Desc,Itemrevid,isNew,ProjName,busUnit);fflush(stdout);
				
				if(isNew==0)
				{
					printf("\n TechSpec has already created\n");fflush(stdout);
					return ifail;
					
				}
				
				// START Assigning project to TechSpec //
				
				//Assign project process 
				printf("\n Inside Assign project process with ProjName=%s",ProjName);fflush(stdout);
				//ifail = AOM_lock(item_tag);
				ifail = PROJ_find(ProjName, &projtag);
				printf("\n After PROJ_find");fflush(stdout);
				ifail = PROJ_is_project_active(projtag, &active);	
				printf("\n After PROJ_is_project_active");fflush(stdout);							
				tag_t projtag1[]={projtag};		
				tag_t itemtag1[]={item_tag};									
				printf("\n Before PROJ_assign_objects");fflush(stdout);	
				ifail = PROJ_assign_objects(1, projtag1, 1, itemtag1);
				printf("\n After PROJ_assign_objects");fflush(stdout);	
				ifail = WSOM_assign_to_owning_project(item_tag,projtag);//set owning_project	
				printf("\n After WSOM_assign_to_owning_project");fflush(stdout);								
				//ifail = AOM_save(&item_tag);
				//ifail = AOM_unlock(item_tag);
				printf("\n End Assign project process");fflush(stdout);	
				
				
			   
			   printf("\n End*****T5TechSpecCre_Post item_id=%s projcode=%s \n",item_ids,projcode);fflush(stdout);
			   return 0;

}
*/

int T5TechSpecCre_savepost( METHOD_message_t *msg, va_list args )
{

	//printf("\n 1111Start techspec Update *****T5TechSpecCre_post for savepost\n");fflush(stdout);
	printf("\n 1111Start techspec Update *****T5TechSpecCre_savepost for Savepost\n");fflush(stdout);

	int ifail = ITK_ok;
	// va_list for item save 
		va_list largs;
		va_copy( largs, args );               
		tag_t item_tag = va_arg(largs, tag_t);
		tag_t item_rev_tag = va_arg(largs, tag_t);
		logical  isNew = va_arg(args, int);	
	//End item save signature
	
	//signature for item create
	
	// char* item_id  = va_arg(args, char*);
    // const char* item_name = va_arg(args, char*);
    // const char* type_name = va_arg(args, char*);
    // const char* rev_id = va_arg(args, char*);
    // tag_t*      item_tag = va_arg(args, tag_t*);
    // tag_t*      item_rev_tag = va_arg(args, tag_t*);
    // tag_t       item_master_form = va_arg(args, tag_t);
    // tag_t       item_rev_master_form = va_arg(args, tag_t);
	
	//end signature for item create
	tag_t Attachrelation_type=NULLTAG;
	tag_t Attach_type_rel=NULLTAG;
	tag_t *attachments1;
	tag_t		filetag = NULLTAG;
	tag_t		datasettype = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t  	itemrev= NULLTAG;
	tag_t project	 = NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType	= 1;
	char *item_ids=NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *busUnit=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	char *TSRevid=NULL;
	int count;
	int cnt1;
	int count1;
	int j;
	tag_t projtag = NULLTAG;
	tag_t *Ownprojtag = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		dataset = NULLTAG;
	logical active = TRUE;
	// char *item_type=NULL;
	// char *design_grp=NULL;
	// char *part_type=NULL;
	// char full_group[20];

	// logical hasBypass=false;
	// logical part_found=false;

	tag_t userSession=NULLTAG;
	//char *Type = va_arg(largs, char *);
			   //tag_t *newBomline_tag = va_arg(largs, tag_t *);
			  // va_end( args );
			   itemrev=item_rev_tag;
			   printf("\n Start techspec Update *****T5TechSpecCre_savepost action\n");fflush(stdout);
			   ITK_CALL( AOM_ask_value_string(item_tag,"item_id",&item_ids));
				ITK_CALL( AOM_ask_value_string(item_tag,"object_name",&Desc));
				ITK_CALL( AOM_ask_value_string(item_tag,"t5_ProjectCode",&ProjName));
				//ITEM_ask_latest_rev(item_tag,&itemrev);
				ITK_CALL( AOM_ask_value_string(itemrev, "item_revision_id",&Itemrevid));
				ITK_CALL( AOM_ask_value_string(itemrev, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tag(item_rev_tag, "item_revision_id",&TSRevid));
				//ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
				printf("\n techspec item_id=%s Desc=%s Itemrevid=%s  ProjName=%s busUnit=%s\n",item_ids,Desc,Itemrevid,ProjName,busUnit);fflush(stdout);
				//printf("\n tsltechspec TSRevid=%s \n",TSRevid);fflush(stdout);
				// if(isNew==0)
				// {
					// printf("\n TechSpec has already created\n");fflush(stdout);
					// return ifail;
					
				// }
				
				printf("\n b4 GRM_find_relation_type in T5TechSpecCre_savepost  \n");fflush(stdout);
				//START : TechSpec DOCUMENTS Finding/create in attach relation
				ITK_CALL(GRM_find_relation_type("TC_Attaches",&Attachrelation_type));
				printf("\n after GRM_find_relation Attachrelation_type\n");fflush(stdout);   
				if(Attachrelation_type != NULLTAG)
				{
					printf("\n inside Attachrelation_type\n");fflush(stdout);   
					GRM_list_secondary_objects_only(itemrev,Attachrelation_type,&cnt1,&attachments1);
					printf("\n TechSpec Docs Datasets:%d\n",cnt1);fflush(stdout);
					if(cnt1>0)
					{
						printf("\n Inside TechSpec Docs found n");fflush(stdout);
						// for(j=0;j<cnt1;j++)
						// {
							//CE_current_user_session_tag(&userSession);
						   // AOM_ask_value_tag(userSession ,"user", &user);
						   // AOM_ask_value_tag(item_tag ,"owning_group", &group);
							//AOM_set_ownership(attachments[j], user,group);

							//move_dataset_to_WIPVolume(attachments[j]);

						//}
					}
					else
					{
						//Create TechSpec Datasets process 
						char* username;
					tag_t user_tag=NULLTAG;
					ITK_CALL(POM_get_user_id (&username));
					//POM_get_user(&username,&user_tag);
					printf("\n\n  username : %s\n",username); fflush(stdout);
					
						int count=0;
						tag_t    *TSbypassCntrlObjSet=NULLTAG;
						char *bypassuser=NULL;
						CALLAPI(getCntrlObj( "ByPassUser",&count ,&TSbypassCntrlObjSet));
						printf("\n after ByPassUser count[%d]",count);fflush(stdout);
						if(count>0)
						{
							ITK_CALL(AOM_ask_value_string(TSbypassCntrlObjSet[0],"t5_Syscd",&bypassuser));
						}
						printf("\n  bypassuser[%s]",bypassuser);fflush(stdout);
					
					if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,bypassuser)!=0))
					{
						printf("\n Start Create TechSpec Datasets process");fflush(stdout);
						char *FileLoc;
						char *Filename;
						char *modeltmplate;
						FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
						Filename = (char *) MEM_alloc( 100 * sizeof(char) );
						modeltmplate = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(Filename,item_ids);
						tc_strcat(Filename,".docx");
						printf("\n Filename====>[%s]", Filename);fflush(stdout);
						
						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Filename);
						printf("\n FileLoc====>[%s]", FileLoc);fflush(stdout);
						
						tc_strcpy(modeltmplate,busUnit);
						//tc_strcat(modeltmplate,".docx");
						printf("\n modeltmplate====>[%s]", modeltmplate);fflush(stdout);
						AE_find_dataset2(modeltmplate,&dataset);
						
						printf("\n After dataset get ====>[%u]", dataset);fflush(stdout);
						if(dataset)
						{	
							ITK_CALL( AOM_ask_value_string(dataset, "object_name",&dsetName));
							printf("\n After dataset name ====>[%s]", dsetName);fflush(stdout);
							 ifail = AE_export_named_ref(dataset, "word", FileLoc);
							  //ifail = AE_export_named_ref(dataset, "word", "/tmp/HCV1.docx");
							  printf("\n After AE_export_named_ref FileLoc====>[%s]", FileLoc);fflush(stdout);
							
								
								//AE_find_datasettype("MSWord", &datasettype);
								AE_find_datasettype2("MSWord", &datasettype);
								//AE_find_tool("MSWord", &tool);
								AE_find_tool2("MSWord", &tool);
								AE_create_dataset_with_id(datasettype,Filename,Desc, item_ids, "A", &Newdataset);
								AE_set_dataset_tool(Newdataset,tool);
								//AE_set_dataset_format(Newdataset, "BINARY_REF");
								AE_set_dataset_format2(Newdataset, "BINARY_REF");
								printf("\n MSWord====>");fflush(stdout);
								//AOM_save(Newdataset);							
								AOM_save_without_extensions(Newdataset);							
								
								//ResultStatus rstat;
		
								//ifail = AOM_refresh(Newdataset, true);
								ifail = AOM_refresh(Newdataset,0);
								AOM_lock(Newdataset);
								
								//char os_path[] = "C:\\Users\\infodba\\Desktop\\junk.txt";   

								// import the dataset from the volume to newly created dataset
								char  auto_assign[] = ""; 
								
								ifail = AE_import_named_ref(Newdataset, "word", FileLoc, auto_assign, SS_BINARY);
								
								//ifail = AOM_save(Newdataset);
								ifail = AOM_save_without_extensions(Newdataset);
								//ifail = AOM_refresh(Newdataset, FALSE);
								ifail = AOM_refresh(Newdataset,0);
								ifail = AOM_unlock(Newdataset);						
								
								//End
								
								printf("\n Inside T5TechSpecCre_savepost Attachrelation_type relation create");fflush(stdout);
								GRM_find_relation_type("IMAN_specification",&Attach_type_rel);
								if(Attachrelation_type)
								{
									printf("\n Inside IMAN_specification Create rel");fflush(stdout);
									ifail = GRM_create_relation(itemrev, Newdataset, Attach_type_rel,NULLTAG, &relationTag);
									ifail = GRM_save_relation(relationTag);
									printf("\n After IMAN_specification Create rel");fflush(stdout);
									
								}
						}
					}
					else
					{
						printf("\n extra dataset creation not required for migration by Loader/infodba for Techspec ====>[%s]", item_ids);fflush(stdout);
					}
					}
				}
				/*********** START Assigning project to TechSpec ******** */
				
				
				 				//Assign project process 
				printf("\n Inside Assign project process with ProjName=%s",ProjName);fflush(stdout);
				//ifail = AOM_lock(item_tag);
				ifail = PROJ_find(ProjName, &projtag);
				printf("\n After PROJ_find");fflush(stdout);
				ifail = PROJ_is_project_active(projtag, &active);	
				printf("\n After PROJ_is_project_active");fflush(stdout);							
				tag_t projtag1[]={projtag};		
				tag_t itemtag1[]={item_tag};									
				printf("\n Before PROJ_assign_objects");fflush(stdout);	
				ifail = PROJ_assign_objects(1, projtag1, 1, itemtag1);
				printf("\n After PROJ_assign_objects");fflush(stdout);	
				ifail = WSOM_assign_to_owning_project(item_tag,projtag);//set owning_project	
				printf("\n After WSOM_assign_to_owning_project");fflush(stdout);								
				//ifail = AOM_save(&item_tag);
				//ifail = AOM_unlock(item_tag);
				printf("\n End Assign project process");fflush(stdout);	
				
				//start status assign process
				if(itemrev)
				{
					char *Release_status = NULL;
					tag_t rel_status		   = NULLTAG;
					logical retain_released_date= TRUE;
					//ITK_CALL (CR_create_release_status("T5_LcsWorking",&rel_status));
					//ITK_CALL(EPM_add_release_status(rel_status,1,&itemrev ,retain_released_date));
					
					ITK_CALL(RELSTAT_create_release_status("T5_LcsWorking",&rel_status)); //similar new API for Teamcenter14
						if(rel_status)
						ITK_CALL(RELSTAT_add_release_status(rel_status,1,&itemrev,retain_released_date));  
					ITK_CALL(AOM_UIF_ask_value(itemrev,"release_status_list",&Release_status));
					printf ( "\nRelease_status_TechSpec : [%s]", Release_status ) ; fflush ( stdout) ;

				}			
				//End status assign process				
				
				
				
			   
			   printf("\n End*****T5TechSpecCre_SavePost for savepost with item_id=%s projcode=%s \n",item_ids,ProjName);fflush(stdout);
			   return 0;

}

int T5TechSpecCre_post( METHOD_message_t *msg, va_list args )
{

	printf("\n 1111Start techspec Update *****T5TechSpecCre_post for CreateItempost\n");fflush(stdout);
	

	int ifail = ITK_ok;
	// va_list for item save 
		// va_list largs;
		// va_copy( largs, args );               
		// tag_t item_tag = va_arg(largs, tag_t);
		// tag_t item_rev_tag = va_arg(largs, tag_t);
		// logical  isNew = va_arg(args, int);	
	//End item save signature
	

	tag_t Attachrelation_type=NULLTAG;
	tag_t Attach_type_rel=NULLTAG;
	tag_t *attachments1;
	tag_t		filetag = NULLTAG;
	tag_t		datasettype = NULLTAG;
	tag_t		Newdataset = NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t  	itemrev= NULLTAG;
	tag_t project	 = NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType	= 1;
	char *item_ids=NULL;
	char *dsetName = NULL;
	char *Itemrevid=NULL;
	char *busUnit=NULL;
	char *Desc=NULL;
	char **projcode=NULL;
	char *projcode1=NULL;
	char *ProjName=NULL;
	char *ProjID=NULL;
	char *TSRevid=NULL;
	int count;
	int cnt1;
	int count1;
	int j;
	tag_t projtag = NULLTAG;
	tag_t *Ownprojtag = NULLTAG;
	tag_t		tool = NULLTAG;
	tag_t		dataset = NULLTAG;
	logical active = TRUE;
	// char *item_type=NULL;
	// char *design_grp=NULL;
	// char *part_type=NULL;
	// char full_group[20];

	// logical hasBypass=false;
	// logical part_found=false;

	tag_t userSession=NULLTAG;
	
		//signature for item create
	
	va_list largs;
	va_copy( largs, args );    
	const char* item_id  = va_arg(largs, char*);
    const char* item_name = va_arg(largs, char*);
    const char* type_name = va_arg(largs, char*);
    const char* rev_id = va_arg(largs, char*);
    tag_t*      item_tag = va_arg(largs, tag_t*);
    tag_t*      item_rev_tag = va_arg(largs, tag_t*);
    tag_t       item_master_form = va_arg(largs, tag_t);
    tag_t       item_rev_master_form = va_arg(largs, tag_t);
	va_end( largs );
	//end signature for item create
	
	printf("\n 1111Start techspec Update *****T5TechSpecCre_post for Createpost\n");fflush(stdout);
	//char *Type = va_arg(largs, char *);
			   //tag_t *newBomline_tag = va_arg(largs, tag_t *);
			   //va_end( args );
			   itemrev=*item_rev_tag;
			   printf("\n Start techspec Update *****T5TechSpecCre_post action\n");fflush(stdout);
			   ITK_CALL( AOM_ask_value_string(*item_tag,"item_id",&item_ids));
				ITK_CALL( AOM_ask_value_string(*item_tag,"object_name",&Desc));
				ITK_CALL( AOM_ask_value_string(*item_tag,"t5_ProjectCode",&ProjName));
				//ITEM_ask_latest_rev(item_tag,&itemrev);
				ITK_CALL( AOM_ask_value_string(itemrev, "item_revision_id",&Itemrevid));
				ITK_CALL( AOM_ask_value_string(itemrev, "t5_VCClassName",&busUnit));
				//ITK_CALL( AOM_ask_value_tag(item_rev_tag, "item_revision_id",&TSRevid));
				//ITK_CALL( AOM_ask_value_tags(item_tag, "owning_project",&count1,&Ownprojtag));
				printf("\n techspec item_id=%s Desc=%s Itemrevid=%s  ProjName=%s busUnit=%s\n",item_ids,Desc,Itemrevid,ProjName,busUnit);fflush(stdout);
				//printf("\n tsltechspec TSRevid=%s \n",TSRevid);fflush(stdout);
				// if(isNew==0)
				// {
					// printf("\n TechSpec has already created\n");fflush(stdout);
					// return ifail;
					
				// }
				
				printf("\n b4 GRM_find_relation_type in T5TechSpecCre_post  \n");fflush(stdout);
				//START : TechSpec DOCUMENTS Finding/create in attach relation
				ITK_CALL(GRM_find_relation_type("TC_Attaches",&Attachrelation_type));
				printf("\n after GRM_find_relation Attachrelation_type\n");fflush(stdout);   
				if(Attachrelation_type != NULLTAG)
				{
					printf("\n inside Attachrelation_type\n");fflush(stdout);   
					GRM_list_secondary_objects_only(itemrev,Attachrelation_type,&cnt1,&attachments1);
					printf("\n TechSpec Docs Datasets:%d\n",cnt1);fflush(stdout);
					if(cnt1>0)
					{
						printf("\n Inside TechSpec Docs found n");fflush(stdout);
						// for(j=0;j<cnt1;j++)
						// {
							//CE_current_user_session_tag(&userSession);
						   // AOM_ask_value_tag(userSession ,"user", &user);
						   // AOM_ask_value_tag(item_tag ,"owning_group", &group);
							//AOM_set_ownership(attachments[j], user,group);

							//move_dataset_to_WIPVolume(attachments[j]);

						//}
					}
					else
					{
						//Create TechSpec Datasets process 
						char* username;
					tag_t user_tag=NULLTAG;

					//POM_get_user(&username,&user_tag);
					ITK_CALL(POM_get_user_id (&username));
					printf("\n\n  username : %s\n",username); fflush(stdout);
					
						int count=0;
						tag_t    *TSbypassCntrlObjSet=NULLTAG;
						char *bypassuser=NULL;
						ITK_CALL(getCntrlObj( "ByPassUser",&count,&TSbypassCntrlObjSet));
						printf("\n after ByPassUser count[%d]",count);fflush(stdout);
						if(count>0)
						{
							ITK_CALL(AOM_ask_value_string(TSbypassCntrlObjSet[0],"t5_Syscd",&bypassuser));
						}
						printf("\n  bypassuser[%s]",bypassuser);fflush(stdout);

					
					if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,bypassuser)!=0))
					{
						printf("\n Start Create TechSpec Datasets process");fflush(stdout);
						char *FileLoc;
						char *Filename;
						char *modeltmplate;
						FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
						Filename = (char *) MEM_alloc( 100 * sizeof(char) );
						modeltmplate = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(Filename,item_ids);
						tc_strcat(Filename,".docx");
						printf("\n Filename====>[%s]", Filename);fflush(stdout);
						
						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Filename);
						printf("\n FileLoc====>[%s]", FileLoc);fflush(stdout);
						
						tc_strcpy(modeltmplate,busUnit);
						//tc_strcat(modeltmplate,".docx");
						printf("\n modeltmplate====>[%s]", modeltmplate);fflush(stdout);
						AE_find_dataset2(modeltmplate,&dataset);
						
						printf("\n After dataset get ====>[%u]", dataset);fflush(stdout);
						if(dataset)
						{	
							ITK_CALL( AOM_ask_value_string(dataset, "object_name",&dsetName));
							printf("\n After dataset name ====>[%s]", dsetName);fflush(stdout);
							 ifail = AE_export_named_ref(dataset, "word", FileLoc);
							  //ifail = AE_export_named_ref(dataset, "word", "/tmp/HCV1.docx");
							  printf("\n After AE_export_named_ref FileLoc====>[%s]", FileLoc);fflush(stdout);
							
								
								//AE_find_datasettype("MSWord", &datasettype);
								AE_find_datasettype2("MSWord", &datasettype);
								//AE_find_tool("MSWord", &tool);
								AE_find_tool2("MSWord", &tool);
								//AE_create_dataset_with_id(datasettype,Filename,Desc, item_ids, "A", &Newdataset);
								AE_create_dataset_with_id(datasettype,item_ids,Desc, item_ids, "A", &Newdataset);
								AE_set_dataset_tool(Newdataset,tool);
								//AE_set_dataset_format(Newdataset, "BINARY_REF");
								AE_set_dataset_format2(Newdataset, "BINARY_REF");
								printf("\n MSWord====>");fflush(stdout);
								//AOM_save(Newdataset);							
								AOM_save_without_extensions(Newdataset);							
								
								//ResultStatus rstat;
		
								//ifail = AOM_refresh(Newdataset, true);
								ifail = AOM_refresh(Newdataset,0);
								AOM_lock(Newdataset);
								
								//char os_path[] = "C:\\Users\\infodba\\Desktop\\junk.txt";   

								// import the dataset from the volume to newly created dataset
								char  auto_assign[] = ""; 
								
								ifail = AE_import_named_ref(Newdataset, "word", FileLoc, auto_assign, SS_BINARY);
								
								//ifail = AOM_save(Newdataset);
								ifail = AOM_save_without_extensions(Newdataset);
								//ifail = AOM_refresh(Newdataset, FALSE);
								ifail = AOM_refresh(Newdataset,0);
								ifail = AOM_unlock(Newdataset);						
								
								//End
								
								printf("\n Inside Attachrelation_type relation create");fflush(stdout);
								GRM_find_relation_type("IMAN_specification",&Attach_type_rel);
								if(Attachrelation_type)
								{
									printf("\n Inside IMAN_specification Create rel");fflush(stdout);
									ifail = GRM_create_relation(itemrev, Newdataset, Attach_type_rel,NULLTAG, &relationTag);
									ifail = GRM_save_relation(relationTag);
									printf("\n After IMAN_specification Create rel");fflush(stdout);
									
								}
						}
					}
					else
					{
						printf("\n extra dataset creation not required for migration by Loader/infodba for Techspec ====>[%s]", item_ids);fflush(stdout);
					}
					}
				}
				/// START Assigning project to TechSpec 
				
				
				 				//Assign project process 
				printf("\n Inside Assign project process with ProjName=%s",ProjName);fflush(stdout);
				//ifail = AOM_lock(item_tag);
				ifail = PROJ_find(ProjName, &projtag);
				printf("\n After PROJ_find");fflush(stdout);
				ifail = PROJ_is_project_active(projtag, &active);	
				printf("\n After PROJ_is_project_active");fflush(stdout);							
				tag_t projtag1[]={projtag};		
				tag_t itemtag1[]={*item_tag};									
				printf("\n Before PROJ_assign_objects");fflush(stdout);	
				ifail = PROJ_assign_objects(1, projtag1, 1, itemtag1);
				printf("\n After PROJ_assign_objects");fflush(stdout);	
				ifail = WSOM_assign_to_owning_project(*item_tag,projtag);//set owning_project	
				printf("\n After WSOM_assign_to_owning_project");fflush(stdout);								
				//ifail = AOM_save(&item_tag);
				//ifail = AOM_unlock(item_tag);
				printf("\n End Assign project process");fflush(stdout);	
				
				//start status assign process
				if(itemrev)
				{
					char *Release_status = NULL;
					tag_t rel_status		   = NULLTAG;
					logical retain_released_date= TRUE;
					//ITK_CALL (CR_create_release_status("T5_LcsWorking",&rel_status));
					//ITK_CALL(EPM_add_release_status(rel_status,1,&itemrev ,retain_released_date));
					
					ITK_CALL(RELSTAT_create_release_status("T5_LcsWorking",&rel_status)); //similar new API for Teamcenter14
						if(rel_status)
						ITK_CALL(RELSTAT_add_release_status(rel_status,1,&itemrev,retain_released_date));  
					ITK_CALL(AOM_UIF_ask_value(itemrev,"release_status_list",&Release_status));
					printf ( "\nRelease_status_TechSpec : [%s]", Release_status ) ; fflush ( stdout) ;

				}			
				//End status assign process				
				
				
				
			   
			 //  printf("\n End*****T5TechSpecCre_Post for Createpost with item_id=%s projcode=%s \n",item_ids,ProjName);fflush(stdout);
			 printf("\n End*****T5TechSpecCre_Post");fflush(stdout);
			   return 0;

}
/*
//Revise Pre Action for Tech Spec Revision
	extern DLLAPI int Revise_Pre_Action_TechSpecRev(METHOD_message_t *m,va_list args)
	{
		
		int		       ifail=0;
		printf("\n Start Revise_Pre_Action_TechSpecRev !!\n");fflush(stdout);
		tag_t		   relation_type	= NULLTAG;
		tag_t		   primary_object	= NULLTAG;
		char *TechSpecNum=NULL;
		tag_t	 	   TechSpecObjTag		= va_arg (args, tag_t);
		//#define ITK_err 910001
		AOM_ask_value_string(TechSpecObjTag,"object_string",&TechSpecNum);
		printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
		char* checkedOut = NULL;
		char* rel_status = NULL;
		tag_t *relStatus_list = NULLTAG;
		int RlzStatusCnt=0;
		int RlzRevFlag=0;
		int ss=0;
		const char *reason = "" ;
		const char *change_id = "" ;
		const char *dir_name = "" ;
		logical  retain  = TRUE;
		CALLAPI(AOM_UIF_ask_value(TechSpecObjTag, "release_status_list", &rel_status))
		CALLAPI(AOM_UIF_ask_value(TechSpecObjTag,"checked_out",&checkedOut));
		printf("  rel_status: %s",rel_status);fflush(stdout);                       
		//checked_out
		
		printf("\nTechSpecNum object[%s] Checkedout==>%s, Release status==>%s\n",TechSpecNum,checkedOut,rel_status);fflush(stdout);
		
		//Skip the checked out part
		
		if(tc_strcmp(checkedOut, "Y") == 0 )
			{
							//continue;
							printf(" not allow to checkout/revise techspec if check indicator is : %s",checkedOut);fflush(stdout);
				ifail=ITK_err;
			}
		
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				printf("  allow to revise techspec for : %s",rel_status);fflush(stdout);
			}
			else if((tc_strstr(rel_status,"Review")!=NULL)||(tc_strstr(rel_status,"Working")!=NULL)||(tc_strstr(rel_status,"ERC Review")!=NULL))
			{
				printf(" not allow to checkout/revise techspec only instead of revise: %s",rel_status);fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Attached Tech Spec Header is ERC Review/Working therefore Revise Tech Spec not allowed ");
									//return ITK_err;
				
				ifail=ITK_err;
				//check-out the techspec 
				// CALLAPI ( RES_checkout ( TechSpecObjTag, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to do check-out if part having ERC Review status
				// tag_t status_rel = NULLTAG;
				// char*			ReleaseStatus	=NULL;
				// if(RELSTAT_create_release_status("T5_LcsReview",&status_rel)) PrintErrorStack();
				// if(RELSTAT_add_release_status(status_rel,1,&TechSpecObjTag,retain)) PrintErrorStack();
				
			}
			else
			{
				printf("  not allow to revise/check-out techspec : %s",rel_status);fflush(stdout);
				ifail=ITK_err;
				//return ITK_err;
			}
			
			 printf("\n\nEnd Revise_Pre_Action_TechSpecRev with Ifail:%d\n",ifail);
			return ifail;
	}


*/

//Start Action Handler

/*
	Action Handler		:		AH_Get_MDMVCList
	Description			:		This handler checks the VC/CCV for respective module & attach to Task's Reference item for MDM release
*/

int AH_Get_MDMVCList(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	char *obj_type=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  	objTypeTag=NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	int x =0;
	int p =0;
	int count=0;
	int retcount=0;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *parttype;
	tag_t * 	secondary_objects ;
	tag_t * 	VCLists ;
		char *ccvRevId =NULL;
		char *CCVDesc =NULL;
		char *CCVDescDup =NULL;
		int tscount;
	tag_t			relation1			= NULLTAG;
		
	//Newly attrs
	int       st_count=0;
	tag_t*    status_list;
	tag_t	*RetVehlist			=	NULLTAG;
	int		n_found			=	0;
	tag_t  	itemrev= NULLTAG;
	tag_t  	itemrev1= NULLTAG;
	tag_t	*prnts					=	NULLTAG;
	tag_t	*prnts1					=	NULLTAG;
	tag_t	RetObjType				=	NULLTAG;
	tag_t	RetObjType1				=	NULLTAG;
	int		*lvls					=	0;
	int		*lvls1					=	0;
	int		n_prnts					=	0;
	int		n_prnts1					=	0;
	int jk =0;
	int iv =0;
	int k=0;
	int PrimaryVCcnt=0;
	int  n_refs= 0;
	int  *levels = 0;
	int  indx =0;
	char	*latest_rev_Rel_Stus	= NULL;
	char *partNo=NULL;
	char *parttype1=NULL;
	char *Itemrevid=NULL;
	char *Itemid=NULL;
	char *PrntItemid=NULL;
	char *PrntItemid1=NULL;
	char	*RetTypeName			=	NULL;
	char *PrntPartType =NULL;
		char	*RetTypeName1			=	NULL;
	char *PrntPartType1 =NULL;
	char *Prntparttype1 =NULL;
	char   *CCVNo =NULL;
	tag_t *referencers=NULLTAG;
	tag_t 	itemmstr    =NULLTAG;
	char  **relations=NULL;
	char  **AlrdyAddedVcList=NULL;
	char  **AlrdyAddedVcList1=NULL;
	char  **TaskVcList=NULL;
	tag_t	CCVtoSnapShot_Rel_Type	= NULLTAG;
	tag_t	*CCVTags 	= NULLTAG;
	tag_t	CCVTag 	= NULLTAG;
	tag_t	CCVTag1 	= NULLTAG;
	tag_t	SnpObjTypeTag 	= NULLTAG;
	//char   SnpObjTypeNm[TCTYPE_name_size_c+1];
	char *rfrnce_name = NULL;
	//char   SnpObjTypeNm[TCTYPE_name_size_c+1];
	char   *SnpObjTypeNm=NULL;
	char **bufferedXmlStrOut = NULL;
		int setAddStrRcnt =0;
		int setFndstrCnt =0;
		int setAddStrRcnt1 =0;
		int setAddStrRcnt2 =0;
		int setFndstrCnt1 =0;
		int setFndstrCnt2 =0;
	//End newly attr def
	
	
	
	
	
 

printf("inside AH_Get_MDMVCList Action Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_Get_MDMVCList attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n AH_Get_MDMVCList Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=taskAttachments[Itemscnt];
		char *id;
		char *Solid;
		char *TaskAnlyst =NULL;
		char *TaskAnlystDup =NULL;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);

		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
		printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);
		
		if(TaskAnlyst)
				{
					 tc_strdup(TaskAnlyst,&TaskAnlystDup);	
					
				}
		printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
		//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
		printf( "reference item attachment count:%d\n", count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				printf( "loop i=%d\n", i);fflush(stdout);
				char *VCClass;
				ITKCALL(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
				printf("\n Solution Item= %s",Solid);fflush(stdout);
				
				setAddStrR(&setAddStrRcnt2,&TaskVcList,Solid);
				ITKCALL(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				ITKCALL(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				ITKCALL(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				ITKCALL(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
				if(CCVDesc)
				{
					tc_strdup(CCVDesc,&CCVDescDup);
				}
				printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
				//return;
				
				if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
				{
				if(tc_strstr(parttype,"M")!=NULL)	//Module
				{
					//if(tc_strstr(ccvRevId,"NR")!=NULL)
					//{
					char *projcode;
					char *DRStatus;
					tag_t  CurrentRoleTag = NULLTAG;
					char       roleName[SA_name_size_c+1];
					printf("\n before going to update VC Attributes value"); fflush(stdout);
					
					//ITKCALL(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
								
						retcount=0;
						ITKCALL(getICOUpdCO("ICOUPDLIST",Solid,&retcount,&RetContrlObjs));
						printf("\n to Upd VCAttr ICOUPDLIST count: %d for [%s]\n",retcount,Solid);fflush(stdout);
						if(retcount>0)
						{
							//ITKCALL(ITEM_ask_latest_rev(secondary_objects[i],&itemrev));
							if(secondary_objects[i])
							{
										ITKCALL( AOM_ask_value_string(secondary_objects[i], "item_id",&Itemid));
										ITKCALL( AOM_ask_value_string(secondary_objects[i], "item_revision_id",&Itemrevid));
										
										printf("\n\n Itemid ==%s Itemrevid[%s]\n",Itemid,Itemrevid);fflush(stdout);
										
									//expand CCV to snapshot.
								//if(GRM_find_relation_type("IMAN_reference", &CCVtoSnapShot_Rel_Type)!=ITK_ok)PrintErrorStack();
								//ITKCALL(WSOM_where_referenced(secondary_objects[i], 1 ,&n_refs,&levels,&referencers,&relations));
								ITKCALL(WSOM_where_referenced2(secondary_objects[i], 1 ,&n_refs,&levels,&referencers,&relations));
								printf("\n\n n_refs ==%d levels[%d]\n",n_refs,levels);fflush(stdout);
								for (cnt=0;cnt<n_refs ;cnt++ )
								 {
									 ITKCALL(WSOM_ask_name2(referencers[cnt],&rfrnce_name));
									 printf("\n\n rfrnce_name ==%s \n",rfrnce_name);fflush(stdout);
									 if(tc_strstr(rfrnce_name,"Snapshot")!=NULL)
									 {
										if(TCTYPE_ask_object_type(referencers[cnt],&SnpObjTypeTag)!=ITK_ok)PrintErrorStack();
										//if(TCTYPE_ask_name(SnpObjTypeTag,SnpObjTypeNm)!=ITK_ok)PrintErrorStack();
										if(TCTYPE_ask_name2(SnpObjTypeTag,&SnpObjTypeNm)!=ITK_ok)PrintErrorStack();
										printf("\n CCV:SnpObjTypeNm:: [%s] \n",SnpObjTypeNm); fflush(stdout);

										if(strcmp(SnpObjTypeNm,"Snapshot")==0)
										{
											if(GRM_find_relation_type("T5_PartHasSnapShot", &CCVtoSnapShot_Rel_Type)!=ITK_ok)PrintErrorStack();
										if (CCVtoSnapShot_Rel_Type!=NULLTAG)
										{ 
											PrimaryVCcnt=0;
											if(GRM_list_primary_objects_only(referencers[cnt],CCVtoSnapShot_Rel_Type,&PrimaryVCcnt,&CCVTags)!=ITK_ok)PrintErrorStack();
											printf("\n CCV:PrimaryVCcnt: %d",PrimaryVCcnt);fflush(stdout);
											if(PrimaryVCcnt > 0)
											{
												for (iv=0;iv<PrimaryVCcnt;iv++ )
												{
													CCVTag = CCVTags[iv];
													//VCLists[i]=CCVTag;
													if(TCTYPE_ask_object_type(CCVTag,&SnpObjTypeTag)!=ITK_ok)PrintErrorStack();
													//if(TCTYPE_ask_name(SnpObjTypeTag,SnpObjTypeNm)!=ITK_ok)PrintErrorStack();
													if(TCTYPE_ask_name2(SnpObjTypeTag,&SnpObjTypeNm)!=ITK_ok)PrintErrorStack();
													printf("\n CCV:SnpObjTypeNm:: [%s] \n",SnpObjTypeNm); fflush(stdout);
													
													//if(strcmp(SnpObjTypeNm,"Snapshot")==0)
													//{
														if(AOM_ask_value_string(CCVTag,"object_name",&CCVNo)!=ITK_ok)   PrintErrorStack();
															printf("\n CCVNo:%s ......\n",CCVNo);fflush(stdout);
															
													//}
													//to create relation between vehicle & Task for reference_item
													//ITKCALL(ITEM_ask_latest_rev(CCVTag,&itemrev));
													if(tc_strcmp(SnpObjTypeNm,"Design")==0)
													{
														if(CCVTag)
														{
															ITKCALL(getLatestReleasedPart2(CCVTag,&itemrev));
														}
													}
													if(tc_strcmp(SnpObjTypeNm,"Design Revision")==0)
													{
														//itemrev=CCVTag;
														ITKCALL(ITEM_ask_item_of_rev(CCVTag,&itemmstr));
														if(itemmstr)
														{
															ITKCALL(getLatestReleasedPart2(itemmstr,&itemrev));
														}
													}
												if(itemrev!=NULLTAG)
												{
													ITKCALL( AOM_ask_value_string(itemrev, "item_id",&partNo));
														printf("\n\t partNo := %s\n", partNo);fflush(stdout);
													ITKCALL( AOM_ask_value_string(itemrev, "t5_PartType",&parttype1));
														printf("\n\t parttype1 := %s\n", parttype1);fflush(stdout);
														//ITKCALL(WSOM_ask_release_status_list(itemRev,&st_count,&status_list));
														//to create relation between vehicle & Task for reference_item
														setFndstrCnt=0;
														//return ifail;
													if(partNo)
													{														
														printf("\n\t b4 setFndstrCnt := %d setAddStrRcnt=%d\n", setFndstrCnt,setAddStrRcnt);fflush(stdout);
														setFindStrR(AlrdyAddedVcList,setAddStrRcnt,partNo,&setFndstrCnt);
														printf("\n\t After setFndstrCnt := %d\n", setFndstrCnt);fflush(stdout);
														
														setFndstrCnt2=0;
														printf("\n\t b4 setFndstrCnt2 := %d setAddStrRcnt2=%d\n", setFndstrCnt2,setAddStrRcnt2);fflush(stdout);
														setFindStrR(TaskVcList,setAddStrRcnt2,partNo,&setFndstrCnt2);
														printf("\n\t After setFndstrCnt2 := %d\n", setFndstrCnt2);fflush(stdout);
														if(setFndstrCnt==0 && setFndstrCnt2==0)
														{
														//if(tc_strcmp(parttype1,"V")==0)
														if(tc_strcmp(parttype1,"CCVC")==0||tc_strcmp(parttype1,"V")==0)
														{
															
															//ITKCALL(AOM_ask_value_string(status_list[0],"object_name",&latest_rev_Rel_Stus));
															//printf("\n latest_rev_Rel_Stus: %s",latest_rev_Rel_Stus);fflush(stdout);
															//if(tc_strstr(latest_rev_Rel_Stus,"Release")!=NULL)
															//if(VcRev)
															//{
																printf("\n\t Itemscnt := %d\n", Itemscnt);fflush(stdout);
																//ifail = GRM_create_relation(taskAttachments[Itemscnt], itemrev, DmlItemsRelation_t, NULLTAG, &relation1);
																//taskAttachments[Itemscnt]
																ITKCALL(GRM_create_relation(taskAttachments[Itemscnt], itemrev, DcrProblmItemsRelType, NULLTAG, &relation1));
																ITKCALL(GRM_save_relation(relation1));
																printf("\n After Task[%s] to part[%s] relation\n",id,partNo);fflush(stdout);
															//}
																setAddStrR(&setAddStrRcnt,&AlrdyAddedVcList,partNo);
														printf("\n\t After setAddStrRcnt := %d\n", setAddStrRcnt);fflush(stdout);																
																//AlrdyAddedVcList[indx++]=partNo;
																	/* if(setFindStrR1(&iWrite,&SSDetails,PartNumber)==-1)
																	//if(setFindStrR1(&iWrite,&SSDetails,PartNo)==0)
																	 {
																		setAddStrR(&iWrite,&SSDetails,PartNumber);
																		printf("\n AAAAAAAAAAAAAAAAAAAAAAAAAAAAA tm_ECURefSnapshot module [%s] added directly \n",PartNumber);fflush(stdout);
																	 }
																	else
																	 {
																		printf("\n module [%s] already exists in set \n",PartNumber);fflush(stdout);
																		
																	 } */
														}
														}
													}
													//ifail = GRM_create_relation(taskAttachments[Itemscnt], CCVTag, DcrProblmItemsRelType, NULLTAG, &relation1);
													//ifail = GRM_save_relation(relation1);
												}
												else
												{
														printf("\n No Vehicle/CCVC found or not Released Vehicle/CCVC for part[%s], so ignore to attach with task\n",CCVNo);fflush(stdout);
												}
													//printf("\n After Task[%s] to part[%s] relation\n",id,CCVNo);fflush(stdout);
												}
											}
										}
										}

									 }
									 
																							
									 
								 }
								//CCVTag=NULLTAG;
								itemrev=NULLTAG;
							
								
										
								ITKCALL(PS_where_used_all(secondary_objects[i],1,&n_prnts,&lvls,&prnts));
								printf("\n n_prnts:%d ......\n",n_prnts);fflush(stdout);
								if(n_prnts > 0)
								{
									for (jk=0;jk<n_prnts;jk++ )
									{
										if(TCTYPE_ask_object_type(prnts[jk],&RetObjType));
										if(TCTYPE_ask_name2(RetObjType,&RetTypeName));

										printf("\n\t RetTypeName := %s\n", RetTypeName);fflush(stdout);
																				
										if(tc_strcmp(RetTypeName,"T5_ArchModuleRevision")!=0 && tc_strcmp(RetTypeName,"T5_ClrPartRevision")!=0 )
										//if(tc_strstr(RetTypeName,"T5_ClrPartRevision")==NULL)
										{
											//ITKCALL(ITEM_ask_item_of_rev(prnts[jk],&CCVTag1));
											printf("\n\t jk := %d\n", jk);fflush(stdout);
											if(TCTYPE_ask_object_type(prnts[jk],&RetObjType1));
											if(TCTYPE_ask_name2(RetObjType1,&RetTypeName1));
											printf("\n\t b4 getLatestReleasedPart2 := %s\n", RetTypeName1);fflush(stdout);
											itemrev=NULLTAG;
											
											if(tc_strcmp(RetTypeName1,"Design Revision")==0)
											{
												//itemrev=NULLTAG;
												
												ITKCALL(ITEM_ask_item_of_rev(prnts[jk],&CCVTag1));
												if(CCVTag1)
												{
													ITKCALL(getLatestReleasedPart2(CCVTag1,&itemrev));
												}
											}
											if(tc_strcmp(RetTypeName1,"Design")==0)
											{
											//ITKCALL(ITEM_ask_item_of_rev(prnts[jk],&CCVTag1));
											ITKCALL(getLatestReleasedPart2(prnts[jk],&itemrev));
											}
											printf("\n\t After getLatestReleasedPart2 := %s\n", RetTypeName1);fflush(stdout);
											if(itemrev)
											{
											ITKCALL( AOM_ask_value_string(itemrev, "item_id",&PrntItemid));
											printf("\n\t PrntItemid := %s\n", PrntItemid);fflush(stdout);
											ITKCALL( AOM_ask_value_string(itemrev, "t5_PartType",&PrntPartType));
											printf("\n\t PrntPartType := %s\n", PrntPartType);fflush(stdout);
											if(tc_strcmp(PrntPartType,"M")==0)
											{
												ITKCALL(PS_where_used_all(prnts[jk],1,&n_prnts1,&lvls1,&prnts1));
												if(n_prnts1 > 0)
												{
													for (k=0;k<n_prnts1;k++ )
													{
														if(TCTYPE_ask_object_type(prnts1[k],&RetObjType1));
														if(TCTYPE_ask_name2(RetObjType1,&RetTypeName1));

														printf("\n\t if module parent found RetTypeName1 := %s\n", RetTypeName1);fflush(stdout);
														if(tc_strcmp(RetTypeName1,"T5_ArchModuleRevision")!=0)
														{
														ITKCALL( AOM_ask_value_string(prnts1[k], "item_id",&PrntItemid1));
														printf("\n\t PrntItemid1 := %s\n", PrntItemid1);fflush(stdout);
														ITKCALL( AOM_ask_value_string(prnts1[k], "t5_PartType",&Prntparttype1));
														printf("\n\t Prntparttype1 := %s\n", Prntparttype1);fflush(stdout);
														//to create relation between vehicle & Task for reference_item
														setFndstrCnt1=0;
														printf("\n\t b4 setFndstrCnt := %d setAddStrRcnt1=%d\n", setFndstrCnt1,setAddStrRcnt1);fflush(stdout);
														setFindStrR(AlrdyAddedVcList1,setAddStrRcnt1,PrntItemid1,&setFndstrCnt1);
														printf("\n\t After setFndstrCnt1 := %d\n", setFndstrCnt1);fflush(stdout);
														setFndstrCnt2=0;
														printf("\n\t b4 setFndstrCnt2 := %d setAddStrRcnt2=%d\n", setFndstrCnt2,setAddStrRcnt2);fflush(stdout);
														setFindStrR(TaskVcList,setAddStrRcnt2,PrntItemid1,&setFndstrCnt2);
														printf("\n\t After setFndstrCnt2 := %d setFndstrCnt1=%d\n", setFndstrCnt2,setFndstrCnt1);fflush(stdout);
														if(setFndstrCnt1==0 && setFndstrCnt2==0)
														{
														//if(tc_strcmp(Prntparttype1,"V")==0)
															itemmstr=NULLTAG;
															//itemrev=NULLTAG;
															if(tc_strcmp(Prntparttype1,"CCVC")==0||tc_strcmp(Prntparttype1,"V")==0)
															{
																if(tc_strcmp(RetTypeName1,"Design Revision")==0)
																	{
																		itemrev=NULLTAG;
																		
																		ITKCALL(ITEM_ask_item_of_rev(prnts1[k],&itemmstr));
																		if(itemmstr)
																		{
																			ITKCALL(getLatestReleasedPart2(itemmstr,&itemrev));
																		}
																	}
																
																if(itemrev)
																{
																		printf("\n b4 Task[%s] to part[%s] relation b4 setAddStrRcnt1 val[%d]\n",id,PrntItemid1,setAddStrRcnt1);fflush(stdout);
																		ITKCALL( GRM_create_relation(taskAttachments[Itemscnt], itemrev, DcrProblmItemsRelType, NULLTAG, &relation1));
																		ITKCALL( GRM_save_relation(relation1));
																		printf("\n After Task[%s] to part[%s] relation b4 setAddStrRcnt1 val[%d]\n",id,PrntItemid1,setAddStrRcnt1);fflush(stdout);
																		setAddStrR(&setAddStrRcnt1,&AlrdyAddedVcList1,PrntItemid1);
																		printf("\n\t After setAddStrRcnt1 := %d\n", setAddStrRcnt1);fflush(stdout);
																}
																else 																	
																{
																		printf("\n No Vehicle/CCVC found or not Released Vehicle/CCVC for part[%s], so ignore to attach with task\n",PrntItemid1);fflush(stdout);
																}
															}
														}
														
													}
													}
												}
											}
										
											//to create relation between vehicle & Task for reference_item
											
											printf("\n\t b4 for direct vehicle parent setFndstrCnt := %d PrntItemid=%s setAddStrRcnt1=%d\n", setFndstrCnt1,PrntItemid,setAddStrRcnt1);fflush(stdout);
														if(PrntItemid)
														{
															setFndstrCnt1=0;
															//printf("\n\t b4 for direct vehicle parent AlrdyAddedVcList1 := %s \n", AlrdyAddedVcList1[setAddStrRcnt1]);fflush(stdout);
															setFindStrR(AlrdyAddedVcList1,setAddStrRcnt1,PrntItemid,&setFndstrCnt1);
															printf("\n\t After setFndstrCnt1 := %d setAddStrRcnt1=%d\n", setFndstrCnt1,setAddStrRcnt1);fflush(stdout);
															setFndstrCnt2=0;
															printf("\n\t b4 setFndstrCnt2 := %d\n", setFndstrCnt2);fflush(stdout);
															setFindStrR(TaskVcList,setAddStrRcnt2,PrntItemid,&setFndstrCnt2);
															printf("\n\t After setFndstrCnt2 := %d setAddStrRcnt2=%d setFndstrCnt1=%d\n", setFndstrCnt2,setAddStrRcnt2,setFndstrCnt1);fflush(stdout);
															if(setFndstrCnt1==0 && setFndstrCnt2==0)
															{
																if(tc_strcmp(PrntPartType,"CCVC")==0||tc_strcmp(PrntPartType,"V")==0)
																{
																	/* itemmstr=NULLTAG;
																	
																	if(tc_strcmp(RetTypeName,"Design Revision")==0)
																	{
																		itemrev=NULLTAG;
																		ITKCALL(ITEM_ask_item_of_rev(prnts[jk],&itemmstr));
																		if(itemmstr)
																		{
																			ITKCALL(getLatestReleasedPart2(itemmstr,&itemrev));
																		}
																	} */
																	if(itemrev!=NULLTAG)
																	{
																		printf("\n B4 Task[%s] to part[%s] relation direct vehicle parent\n",id,PrntItemid);fflush(stdout);
																			ITKCALL(GRM_create_relation(taskAttachments[Itemscnt], itemrev, DcrProblmItemsRelType, NULLTAG, &relation1));
																			printf("\n 222B4 Task[%s] to part[%s] relation direct vehicle parent\n",id,PrntItemid);fflush(stdout);
																			ITKCALL(GRM_save_relation(relation1));
																			printf("\n After Task[%s] to part[%s] relation direct vehicle parent\n",id,PrntItemid);fflush(stdout);
																			setAddStrR(&setAddStrRcnt1,&AlrdyAddedVcList1,PrntItemid);
																			printf("\n\t After direct vehicle parent setAddStrRcnt1 := %d\n", setAddStrRcnt1);fflush(stdout);
																	}
																	else 																	
																	{
																			printf("\n No Vehicle/CCVC found or not Released Vehicle/CCVC for part[%s], so ignore to attach with task\n",PrntItemid);fflush(stdout);
																	}
																}
																
															}
															else
															{
																printf("\nVC[%s] is already attached to Task[%s]",PrntItemid,id); fflush(stdout);
																continue;
															}
														}
														
											}
										}
										else
										{
											continue;
										}
										
										
									}
								}
						}
					}
				//ifail = GRM_create_relation(attachments[0], dataset1, rel_type, NULLTAG, &relation1);
				//ifail = GRM_save_relation(relation1);
					
			}
			else
			{
				printf("\n Part Type is not Module applicable to attach with Task"); fflush(stdout);
				continue;
			}
			
			}
			else
			{
				printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable to attach with Task"); fflush(stdout);
				continue;
			}
			
  
		}
		
		
		}
		
	}
}
}
printf("\n End Parent Vehicle/CCV attachment process w.r.t MDM DML with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//Start Action Handler

/*
	Action Handler		:		CM_Check_CCVForTechSpec
	Description			:		This handler checks the CCV & create the TechSpec for that if applicable
*/
int CM_Check_CCVForTechSpec(EPM_rule_message_t msg)
{
	int i=0,j=0,k=0;
	//int status=ITK_ok;
	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int n_option_data=0,p1=0;
	int n_ves_2_save=0;
	int n_lines2=0;
	int n_lines3=0;
	int n_lines4=0;
	int rulefound= 0;
	int p2=0;	int ss=0;
	int p4=0;
	int n_lines,n_lines1,Item_ID = 0;
	int IntAtr5=0;
	int rule_count=0;
	int count=0;
	int resultCount = 0;
	int n_entries = 1;
	int tscount = 0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char *dmlProjID=NULL;
	char *DMLDRstatus=NULL;
	char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;
	char *ItemId = NULL;
	char *RevId = NULL;
	char *VCItemId = NULL;
	char *SVRType = NULL;
	char *v2_text=NULL;
	char *desc = NULL;
	char *varrul = NULL;
	char *CurrentRelStatus = NULL;
	char *Item_ID_str=NULL;
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_id156=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *ChildSVRname=NULL;
	char *child_bl_formula=NULL;
	char *child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *ProjDesc = NULL;
	char *Proj_PltFrm = NULL;
	char *Proj_BU = NULL;
	char *Proj_DesgOwnUnit = NULL;
	char *Proj_ProtoUnit = NULL;
	char *Proj_VCSubClass = NULL;
	char *val = NULL;
	char *parttype = NULL;
	char *ProjectID = NULL;
	char *group_name = NULL;
	char *ProjectClass = NULL;
	char *user_name_string = NULL;
	char *SesLoc = NULL;
	char *ccvRevId = NULL;
	char *CCVDesc = NULL;
	char *CCVDescDup = NULL;
	char *tsitem = NULL;

	char relation_name[TCTYPE_name_size_c+1];

	char **qryEntries=NULL;
	char **qryValues=NULL;
	char **rulename = NULL;
	char **rulevalue = NULL;

	char *qry_entries[1] = {"Name"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *Proj_DesgOwnDept = (char *) MEM_alloc(10 * sizeof(char *));

	tag_t *taskAttachments=NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULLTAG;
	tag_t *saved_variant_rules=NULLTAG;
	tag_t *options=NULLTAG;
	tag_t *option1_rev=NULLTAG;
	tag_t *option2_rev=NULLTAG;
	tag_t *option_revs=NULLTAG;
	tag_t *ves_2_save=NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *lines2 = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *lines4 = NULLTAG;
	tag_t *Newlines = NULLTAG;
	tag_t *status_list = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *techspec_objects = NULLTAG;
	tag_t *t5_Project = NULLTAG;

	tag_t rootTask_t=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t bom_view_type=NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t window2=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t top_line1=NULLTAG;
	tag_t rule =NULLTAG;
	tag_t Childobject=NULLTAG;
	tag_t Childobject1=NULLTAG;
	tag_t Childobject3=NULLTAG;
	tag_t Childobject4=NULLTAG;
	tag_t Childobject33=NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t bom_variant_rule=NULLTAG;
	tag_t option1=NULLTAG;
	tag_t option2=NULLTAG;
	tag_t topline = NULLTAG;
	tag_t toggle_ve=NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t Project_t = NULLTAG;
	tag_t GroupMem = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t user = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t user_tag = NULLTAG;

	void **option_data=NULL;

	logical list_changed=FALSE;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;

	char* shellpath = NULL;
	printf("\n inside CM_Check_CCVForTechSpec Action Handler -----------\n");fflush(stdout);

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));

	printf("\n CM_Check_CCVForTechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
	if(attachmentCount>0)
	{
		for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
		{
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

			printf("\n CM_Check_CCVForTechSpec Object Type = %s ",obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{
				printf("\t inside query \n");fflush(stdout);

				char *id = NULL;
				char *Solid = NULL;
				char *TaskAnlyst =NULL;
				char *TaskAnlystDup =NULL;
				char * 	type_name=NULL;
				tag_t	priObjTypeTag			=	NULLTAG;
				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));

				printf("\n CM_Check_CCVForTechSpec--Task_id= %s",id);fflush(stdout);

				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
				printf("\n CM_Check_CCVForTechSpec--Analyst for Task= %s",TaskAnlyst);fflush(stdout);

				if(TaskAnlyst)
				{
					tc_strdup(TaskAnlyst,&TaskAnlystDup);
				}
				printf("\n CM_Check_CCVForTechSpec--TaskAnlystDup: %s  ", TaskAnlystDup);fflush(stdout);

				//ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
				ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
				//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );

				printf("\n CM_Check_CCVForTechSpec--count: %d  ",count);fflush(stdout);
				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						char *VCClass = NULL;
						if (TCTYPE_ask_object_type(secondary_objects[i],&priObjTypeTag)!=ITK_ok);
						if (TCTYPE_ask_name2(priObjTypeTag,&type_name)!=ITK_ok);
						printf( "type_name:%s\n", type_name);fflush(stdout);
						if(tc_strcmp(type_name,"Design Revision")==0)
						{
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_string", &Solid));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType", &parttype));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type", &VCClass));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id", &ccvRevId));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc", &CCVDesc));

							char *partnum=NULL;

										CALLAPI(AOM_ask_value_string(secondary_objects[i],"item_id",&partnum));
										printf("\n task attached partnum = [%s] \n",partnum);fflush(stdout);
							if(CCVDesc)
							{
								tc_strdup(CCVDesc,&CCVDescDup);
							}
							printf("\n CM_Check_CCVForTechSpec--Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
							//return;
							if(tc_strcmp(parttype,"VCCR")==0)	
							{
								int TechSpec4CRVCLiveFlg=TechSpec4CRVC(&shellpath);
								printf("\n CM_Check_CCVForTechSpec--TechSpec4CRVCLiveFlg=%d",TechSpec4CRVCLiveFlg); fflush(stdout);
								if(TechSpec4CRVCLiveFlg>0)
								{
									//calling EXE process
									printf("\nshellpath for CpyCRVCTechSpec tm_CpyVCattrtoNewVC ==>%s\n",shellpath);fflush(stdout);
									if(tc_strlen(shellpath)>0)
									{
										printf("\ninside tm_CpyVCattrtoNewVC Execute through client code......\n");fflush(stdout);

										

										//if(tc_strstr(InpVehPrtType,"VCCR")!=NULL)
										//{
										char *basepart=NULL;
										char *lastDigit=NULL;
										char *partnumDup=NULL;
										char *CRVCParNum=NULL;

										char* sysCmnd = NULL;
										char *BaseVCNo=(char *) MEM_alloc(10);
										if(partnum)
										{
											tc_strdup(partnum,&partnumDup);	
											tc_strdup(partnum,&CRVCParNum);	

										}
										printf("\n partnumDup=%s\n",partnumDup);fflush(stdout);
										if(partnumDup)
										{
											basepart=TS_subString(partnumDup,1,8);
											printf("\n basepart=%s partnum=%s\n",basepart,partnum);fflush(stdout);
											lastDigit=TS_subString(partnumDup,(tc_strlen(partnumDup)),tc_strlen(partnumDup));
											printf("\n lastDigit=%s partnum=%s\n",lastDigit,partnumDup);fflush(stdout);
											if(tc_strlen(basepart)>0 && tc_strlen(lastDigit)>0)
											{
												tc_strcpy(BaseVCNo,basepart);
												tc_strcat(BaseVCNo,lastDigit);						
											}			

											printf("\n BaseVCNo=%s CRVCParNum=%s \n",BaseVCNo,CRVCParNum);fflush(stdout);			

											sysCmnd=(char *) MEM_alloc(300);
											tc_strcpy(sysCmnd,shellpath);
											tc_strcat(sysCmnd," ");
											tc_strcat(sysCmnd,BaseVCNo);
											tc_strcat(sysCmnd," ");
											tc_strcat(sysCmnd,CRVCParNum);
											printf("\n before-- Calling shell file for CRVC tm_CpyVCattrtoNewVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
											system(sysCmnd);

											printf("\n after --- Calling shell file for CRVC tm_CpyVCattrtoNewVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);

											MEM_free(sysCmnd);
										}
									}
									else
									{
										printf("\n No TechSpec required for CM_Check_CCVForTechSpec--TechSpec4CRVCLiveFlg=%d",TechSpec4CRVCLiveFlg); fflush(stdout);
									}
								}
							}
							else
							{
								if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
								{
									if(tc_strstr(parttype,"V")!=NULL)	//allowing CCV/V
									{
										if(tc_strstr(ccvRevId,"NR")!=NULL)
										{
											char *projcode;
											char *DRStatus;
											tag_t  CurrentRoleTag = NULLTAG;
											//char roleName[SA_name_size_c+1];
											char *roleName=NULL;
											printf("\n CM_Check_CCVForTechSpec--going to create Tech Spec"); fflush(stdout);

											ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
											ERROR_CHECK(GRM_list_secondary_objects_only(secondary_objects[i],relation_type_tag,&tscount,&techspec_objects ));

											if(tscount==0)
											{
												//Query to custom project class
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_ProjectCode",&ProjectID));
												printf("\n CM_Check_CCVForTechSpec--ProjectID : %s",ProjectID);   fflush(stdout);
												if(ProjectID)
												{
													//if(QRY_find("Qury_Project", &queryTag));
													if(QRY_find2("Qury_Project", &queryTag));
													printf("\n CM_Check_CCVForTechSpec--After Prd_Project: QRY_find");fflush(stdout);
													if (queryTag)
													{
														printf("\n CM_Check_CCVForTechSpec--Found Query");fflush(stdout);
													}
													else
													{
														printf("\n CM_Check_CCVForTechSpec--Not Found Query");fflush(stdout);
													}
													qry_values[0] = ProjectID;
													if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
													printf("\n CM_Check_CCVForTechSpec--resultCount : %d\n", resultCount); fflush(stdout);

													if(resultCount > 0)
													{
														printf("\n CM_Check_CCVForTechSpec--t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
														Project_t = t5_Project[0];
														if (Project_t!=NULLTAG)
														{
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_DsgnOwn",&Proj_DesgOwnUnit));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProtoUnit",&Proj_ProtoUnit));
															ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProjSubVehClass",&Proj_VCSubClass));

															printf("\n CM_Check_CCVForTechSpec--ProjectClass:[%s] \n ProjDesc : %s \n Proj_PltFrm :[%s] \n Proj_BU:[%s] \n Proj_DesgOwnUnit[%s] \n Proj_ProtoUnit[%s]\n Proj_VCSubClass=[%s] \n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU,Proj_DesgOwnUnit,Proj_ProtoUnit,Proj_VCSubClass);   fflush(stdout);
															if(tc_strstr(Proj_DesgOwnUnit,"PUN")!=NULL)
															{
																Proj_DesgOwnDept="Pune-Design";
															}
															else if(tc_strstr(Proj_DesgOwnUnit,"JSR")!=NULL)
															{
																Proj_DesgOwnDept="JSR-Design";
															}
															else if(tc_strstr(Proj_DesgOwnUnit,"LKO")!=NULL)
															{
																Proj_DesgOwnDept="JSR-Design";
															}
															else if(tc_strstr(Proj_DesgOwnUnit,"AHD")!=NULL)
															{
																Proj_DesgOwnDept="AHD-Design";
															}
															else
															{
																printf("\n Proj_DesgOwnUnit is not matching with condition value");fflush(stdout);
															}

															printf("\n CM_Check_CCVForTechSpec--Proj_DesgOwnDept =%s",Proj_DesgOwnDept);fflush(stdout);
														}
													}
													//End Query custom project
													char        *creatorStr           = NULL;
													ERROR_CHECK(POM_get_user(&user_name_string, &user));
													ERROR_CHECK(SA_ask_current_location_code(&SesLoc));
													SA_ask_current_groupmember(&GroupMem);
													printf("\n CM_Check_CCVForTechSpec--GroupMem: %u SesLoc=%s\n",GroupMem,SesLoc);fflush(stdout);
													if(GroupMem !=NULLTAG)
													{
														//printObject(GroupMem);
														ERROR_CHECK(AOM_ask_value_string(GroupMem,"object_name",&group_name));
														printf("\n CM_Check_CCVForTechSpec--group_name session is pare  : %s\n",group_name);fflush(stdout);
													}
													ERROR_CHECK(SA_ask_current_role(&CurrentRoleTag));
													//ERROR_CHECK(SA_ask_role_name(CurrentRoleTag,roleName));
													ERROR_CHECK(SA_ask_role_name2(CurrentRoleTag,&roleName));
													printf("\n\n CM_Check_CCVForTechSpec--roleName : %s\n",roleName); fflush(stdout);

													ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_ProjectCode" , &projcode));
													ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartStatus" , &DRStatus));
													//ERROR_CHECK(AOM_ask_value_string(user,"t5_ProjectCode" , &projcode));
													printf("\n CM_Check_CCVForTechSpec--projcode=%s DRStatus=%s ",projcode,DRStatus); fflush(stdout);
													if(tc_strlen(projcode)<=0)
													{
														 ERROR_CHECK( AOM_ask_value_string(secondary_objects[i],"project_ids",&projcode));
														 
														 //if(QRY_find("Qury_Project", &queryTag));
														if(QRY_find2("Qury_Project", &queryTag));
														printf("\n CM_Check_CCVForTechSpec--After Prd_Project: QRY_find");fflush(stdout);
														if (queryTag)
														{
															printf("\n CM_Check_CCVForTechSpec--Found Query");fflush(stdout);
														}
														else
														{
															printf("\n CM_Check_CCVForTechSpec--Not Found Query");fflush(stdout);
														}
														qry_values[0] = projcode;
														if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
														printf("\n CM_Check_CCVForTechSpec--resultCount : %d\n", resultCount); fflush(stdout);

														if(resultCount > 0)
														{
															printf("\n CM_Check_CCVForTechSpec--t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
															Project_t = t5_Project[0];
															if (Project_t!=NULLTAG)
															{
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_DsgnOwn",&Proj_DesgOwnUnit));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProtoUnit",&Proj_ProtoUnit));
																ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProjSubVehClass",&Proj_VCSubClass));

																printf("\n CM_Check_CCVForTechSpec--ProjectClass:[%s] \n ProjDesc : %s \n Proj_PltFrm :[%s] \n Proj_BU:[%s] \n Proj_DesgOwnUnit[%s] \n Proj_ProtoUnit[%s]\n Proj_VCSubClass=[%s] \n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU,Proj_DesgOwnUnit,Proj_ProtoUnit,Proj_VCSubClass);   fflush(stdout);
																if(tc_strstr(Proj_DesgOwnUnit,"PUN")!=NULL)
																{
																	Proj_DesgOwnDept="Pune-Design";
																}
																else if(tc_strstr(Proj_DesgOwnUnit,"JSR")!=NULL)
																{
																	Proj_DesgOwnDept="JSR-Design";
																}
																else if(tc_strstr(Proj_DesgOwnUnit,"LKO")!=NULL)
																{
																	Proj_DesgOwnDept="JSR-Design";
																}
																else if(tc_strstr(Proj_DesgOwnUnit,"AHD")!=NULL)
																{
																	Proj_DesgOwnDept="AHD-Design";
																}
																else
																{
																	printf("\n Proj_DesgOwnUnit is not matching with condition value");fflush(stdout);
																}

																printf("\n CM_Check_CCVForTechSpec--Proj_DesgOwnDept =%s",Proj_DesgOwnDept);fflush(stdout);
															}
															 
														}
													}
													printf("\n CM_Check_CCVForTechSpec--projcode=%s ",projcode); fflush(stdout);
													printf("\n CM_Check_CCVForTechSpec--before func call  TechSpecCreFun: ProjectClass:[%s] \n CCVDescDup : %s \n Proj_PltFrm :[%s] \n Proj_BU:[%s] \n Proj_DesgOwnUnit[%s] \n Proj_ProtoUnit[%s]\n Proj_VCSubClass=[%s] \n Proj_DesgOwnDept=[%s] \n",ProjectClass,CCVDescDup,Proj_PltFrm,Proj_BU,Proj_DesgOwnUnit,Proj_ProtoUnit,Proj_VCSubClass,Proj_DesgOwnDept);   fflush(stdout);
													printf("\n\n CM_Check_CCVForTechSpec--before func call  TechSpecCreFun: "); fflush(stdout);
													tag_t retTStag= NULLTAG;
													ERROR_CHECK(TechSpecCreFun(projcode,Proj_DesgOwnDept,Proj_DesgOwnUnit,Proj_VCSubClass,CCVDescDup,ProjectClass,&retTStag));
													printf("\n\n CM_Check_CCVForTechSpec--After func call  TechSpecCreFun: "); fflush(stdout);
													if(retTStag!=NULLTAG)
													{
														//printObject(retTStag);
														printf("\n\n CM_Check_CCVForTechSpec--inside create relation between CCV & Tech Spec: "); fflush(stdout);
														tag_t *techspecRevTag=NULLTAG;
														int num;
														ERROR_CHECK(AOM_ask_value_tags(retTStag, "revision_list",&num,&techspecRevTag));
														ERROR_CHECK(AOM_UIF_ask_value(retTStag,"owning_user",&creatorStr));
														printf("\n creatorStr: %s ", creatorStr);fflush(stdout);
														//if(techspecRevTag!=NULLTAG)
														if(techspecRevTag!=0)
														{
															printf(" CM_Check_CCVForTechSpec--TaskAnlystDup: %s \n", TaskAnlystDup);fflush(stdout);
															if(TaskAnlystDup)
															{
																//CALLAPI(SA_find_user(TaskAnlystDup,&user_tag));
																//if(tc_strstr(creatorStr,TaskAnlystDup)==NULL)
																//{
																	CALLAPI(SA_find_user2(TaskAnlystDup,&user_tag));
																	if(user_tag!=NULLTAG)
																	{
																		AOM_ask_value_tag(taskAttachments[Itemscnt] ,"owning_group", &GroupMem);

																		CALLAPI(AOM_set_ownership(retTStag,user_tag,GroupMem));
																		CALLAPI(AOM_set_ownership(*techspecRevTag,user_tag,GroupMem));
																	}
																//}
															}
															//ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
															ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
															tag_t relation_tag  = NULLTAG;
															ERROR_CHECK(GRM_create_relation(secondary_objects[i],techspecRevTag[0],relation_type_tag, NULLTAG, &relation_tag));
															ERROR_CHECK(GRM_save_relation(relation_tag));
															printf("\n\n CM_Check_CCVForTechSpec--After create relation between CCV & Tech Spec: "); fflush(stdout);
															// if(relation_tag)
															// {
																// printObject(relation_tag);
															// }
														}
													}
													//printf("\n\n  CM_Check_CCVForTechSpec--After printObject "); fflush(stdout);

													////if(tc_strcmp(DRStatus,"DR4")==0 || tc_strcmp(DRStatus,"DR5")==0 || tc_strcmp(DRStatus,"AR4")==0 || tc_strcmp(DRStatus,"AR5")==0)
													////{
													////	//ERROR_CHECK(TechSpecCreFun(char *projcode ,char *OwnerDesDept,char *OwnerDesUnit,char *VcClass,char *Desc,char *FilePath));
													////	printf("\n eligible to create Tech Spec"); fflush(stdout);
													////}
													////else
													////{
													////	printf("\n not eligible to create Tech Spec"); fflush(stdout);
													////}
												}
											}
											else
											{
												ERROR_CHECK(AOM_ask_value_string(techspec_objects[0],"item_id" , &tsitem));
												printf("\n CM_Check_CCVForTechSpec--Tech Spec object[%s] is already available for this CCV [%s]",tsitem,Solid); fflush(stdout);
											}
										}
										else
										{
											printf("\n CM_Check_CCVForTechSpec--NON-NR revision is not eligible to create Tech Spec for Cluster SVR release process, it will auto-revise with VC.. \n"); fflush(stdout);
										}
									}
								}
								else
								{
									printf("\n CM_Check_CCVForTechSpec--Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case \n"); fflush(stdout);
								}
							}

						}
						else
						{
							printf("\n Object Type is not Design Revision so skipping this."); fflush(stdout);
							continue;
						}

					}

				}
			}
		}
	}	

	printf("\n End of CM_Check_CCVForTechSpec ........\n");fflush(stdout);

	return ifail;
}
//End Action Handler
//AH setClsValueToICSTag for set actual value to ICS class
int setClsValueToICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char *AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char   *Ptype_name=NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	char *keyLovOfAttrVal =NULL;
	ITKCALL(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//ITKCALL(TCTYPE_ask_name(objTypeTag,Ptype_name));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	printf("\n setClsValueToICSTag IcsClsTag  Ptype_name :: %s clsKeyAtrrId[%s] AttrVal[%s]\n", Ptype_name,clsKeyAtrrId,AttrVal); fflush(stdout);
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULLTAG;
	tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
		int intid2 =0;
		int  	theAttributeCount;
		int * 	theAttributeIds;
		int * 	theAttributeValCounts;
		char *** 	theAttributeValues;
		char atrid[10];
		tag_t 	theICOTag=NULLTAG;
		tag_t			*RetContrlObjs				=NULLTAG;
		int   n_found=0;
		char *ICOAttrListVal=NULL;
		char * 	unctName=NULL;
		char *	shortName=NULL;
		char * 	unctUnit=NULL;
		int  	unctFormat=0;
		printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
		tc_strcpy(atrid,clsKeyAtrrId);			
		intid2=atoi(atrid);
		printf("\n  input intid2[%d]",intid2); fflush(stdout);

		printf("\n  111"); fflush(stdout);
		ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
		printf("\n  222 ifail[%d]",ifail); fflush(stdout);
		if(ifail != ITK_ok)
		{
			printf("\n  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
			return ifail;	
		}
		printf("\n  2intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);

		char theKeyLOVId[10];	


		const char * 	key_lov_id;		
		if(unctFormat)
		{

			sprintf(theKeyLOVId, "%d", unctFormat);
			key_lov_id=theKeyLOVId;	
		}
		printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);	
		char * 	key_lov_name;
		int  	options;
		int i;
		int keyfound=0;
		int  	n_lov_entries;
		char ** 	lov_keys;
		char ** 	lov_values;
		logical * 	deprecated_staus;
		char * 	owning_site;
		keyLovOfAttrVal=(char*) MEM_alloc( 10 * sizeof(AttrVal) );
		int  	n_shared_sites;
		char ** 	shared_sites ;
		theICOTag=IcsClsTag;
		ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId,&AttrKeyValue));

		printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);


		int attrid=atoi(clsKeyAtrrId);
		int n_attrs = 1;
		int att_ids[1] = {attrid};
		int n_attr_val[1] = {1};

		char ***attr_vals;
		attr_vals = (char***) MEM_alloc( n_attrs * sizeof(char**) );

		if(AttrKeyValue)
		{			


			printf("\n AttrVal=%s ",AttrVal); fflush(stdout);
			if(AttrVal)
			{
				strcpy(keyLovOfAttrVal, AttrVal);
			}

			printf("\n keyLovofAttrVal=%s ",keyLovOfAttrVal); fflush(stdout);
			attr_vals[0] = (char**) MEM_alloc( n_attr_val[0] * sizeof(char*) );
			attr_vals[1] = (char**) MEM_alloc( n_attr_val[1] * sizeof(char*) ); 
			attr_vals[0][0] = (char *) MEM_alloc(tc_strlen(AttrVal) + 1);
			//strcpy(attr_vals[0][0], AttrVal);


			printf("\n inside set key for attr_vals[0][0]=%s ",attr_vals[0][0]); fflush(stdout);

			char *getAttrVal;

			//ITKCALL(getClsValueFrmICSTag( theICOTag , key_lov_id,&getAttrVal));;


			if(tc_strstr(key_lov_id,"-")!=NULL)
			{
			ITKCALL(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			printf("\n AttrKeyValue=%s key_lov_name=%s n_lov_entries=%d options=%d",AttrKeyValue,key_lov_name,n_lov_entries,options); fflush(stdout);
				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n AttrKeyValue=[%s] lov_keys=%s lov_values=%s",AttrKeyValue,lov_keys[i],lov_values[i]); fflush(stdout);

					//if(tc_strcmp(keyLovOfAttrVal,lov_keys[i])==0)
					if(tc_strcmp(keyLovOfAttrVal,lov_values[i])==0)
					{
						printf("\n inside set lov_keys=%s lov_values=%s keyLovOfAttrVal=%s",lov_keys[i],lov_values[i],keyLovOfAttrVal); fflush(stdout);


						strcpy(attr_vals[0][0], lov_keys[i]);
						
						break;
					}



				}
			}
			else
			{
				printf("\n for Not LOV condition keyLovOfAttrVal==%s ",keyLovOfAttrVal); fflush(stdout);
				strcpy(attr_vals[0][0], keyLovOfAttrVal);
				printf("\n non LOV updated for attr[%s] with AttrVal==%s ",clsKeyAtrrId,keyLovOfAttrVal); fflush(stdout);
			}



			ITKCALL(ICS_ico_set_attributes(theICOTag,n_attrs,att_ids,n_attr_val,(const char***)attr_vals));
			printf("\n after update  classifiction VALUE by MDM process for attrid[%d]",attrid); fflush(stdout);
		}
		else
		{
			printf("\n input AttrKeyValue [%s] is NULL,so process aborted"); fflush(stdout);

		}





	}						
	printf("\n End setClsValueToICSTag function "); fflush(stdout);


	return ITK_ok;

}


//AH setClsKeyValueToICSTag for set keyvalue to ICS class 
int setClsKeyValueToICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char *AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char   *Ptype_name=NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	char *keyLovOfAttrVal =NULL;
	ITKCALL(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//ITKCALL(TCTYPE_ask_name(objTypeTag,Ptype_name));
	ITKCALL(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	printf("\n setClsKeyValueToICSTag IcsClsTag  Ptype_name :: %s clsKeyAtrrId[%s] AttrVal[%s]\n", Ptype_name,clsKeyAtrrId,AttrVal); fflush(stdout);
	int partRevCnt=0;
	tag_t* partRevTagObjs = NULLTAG;
	tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
		int intid2 =0;
		int  	theAttributeCount;
		int * 	theAttributeIds;
		int * 	theAttributeValCounts;
		char *** 	theAttributeValues;
		char atrid[10];
		tag_t 	theICOTag=NULLTAG;
		tag_t			*RetContrlObjs				=NULLTAG;
		int   n_found=0;
		char *ICOAttrListVal=NULL;
		char * 	unctName=NULL;
		char *	shortName=NULL;
		char * 	unctUnit=NULL;
		int  	unctFormat=0;
		printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
		tc_strcpy(atrid,clsKeyAtrrId);			
		intid2=atoi(atrid);
		printf("\n  input intid2[%d]",intid2); fflush(stdout);

		printf("\n  111"); fflush(stdout);
		ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
		printf("\n  222 ifail[%d]",ifail); fflush(stdout);
		if(ifail != ITK_ok)
		{
			printf("\n  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
			return ifail;	
		}
		printf("\n  2intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);

		char theKeyLOVId[10];	


		const char * 	key_lov_id;		
		if(unctFormat)
		{

			sprintf(theKeyLOVId, "%d", unctFormat);
			key_lov_id=theKeyLOVId;	
		}
		printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);	
		char * 	key_lov_name;
		int  	options;
		int i;
		int keyfound=0;
		int  	n_lov_entries;
		char ** 	lov_keys;
		char ** 	lov_values;
		logical * 	deprecated_staus;
		char * 	owning_site;
		keyLovOfAttrVal=(char*) MEM_alloc( 10 * sizeof(AttrVal) );
		int  	n_shared_sites;
		char ** 	shared_sites ;
		theICOTag=IcsClsTag;
		ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId,&AttrKeyValue));

		printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);


		int attrid=atoi(clsKeyAtrrId);
		int n_attrs = 1;
		int att_ids[1] = {attrid};
		int n_attr_val[1] = {1};

		char ***attr_vals;
		attr_vals = (char***) MEM_alloc( n_attrs * sizeof(char**) );

		if(AttrKeyValue)
		{			


			printf("\n AttrVal=%s ",AttrVal); fflush(stdout);
			if(AttrVal)
			{
				strcpy(keyLovOfAttrVal, AttrVal);
			}

			printf("\n keyLovofAttrVal=%s ",keyLovOfAttrVal); fflush(stdout);
			attr_vals[0] = (char**) MEM_alloc( n_attr_val[0] * sizeof(char*) );
			attr_vals[1] = (char**) MEM_alloc( n_attr_val[1] * sizeof(char*) ); 
			attr_vals[0][0] = (char *) MEM_alloc(tc_strlen(AttrVal) + 1);
			//strcpy(attr_vals[0][0], AttrVal);


			printf("\n inside set key for attr_vals[0][0]=%s ",attr_vals[0][0]); fflush(stdout);

			char *getAttrVal;

			//ITKCALL(getClsValueFrmICSTag( theICOTag , key_lov_id,&getAttrVal));;


			if(tc_strstr(key_lov_id,"-")!=NULL)
			{
			ITKCALL(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			printf("\n AttrKeyValue=%s key_lov_name=%s n_lov_entries=%d options=%d",AttrKeyValue,key_lov_name,n_lov_entries,options); fflush(stdout);
				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n AttrKeyValue=[%s] lov_keys=%s lov_values=%s",AttrKeyValue,lov_keys[i],lov_values[i]); fflush(stdout);

					if(tc_strcmp(keyLovOfAttrVal,lov_keys[i])==0) 
					//if(tc_strcmp(keyLovOfAttrVal,lov_values[i])==0)
					{
						printf("\n inside set lov_keys=%s lov_values=%s keyLovOfAttrVal=%s",lov_keys[i],lov_values[i],keyLovOfAttrVal); fflush(stdout);


						strcpy(attr_vals[0][0], lov_keys[i]);
						
						break;
					}



				}
			}
			else
			{
				printf("\n for Not LOV condition keyLovOfAttrVal==%s ",keyLovOfAttrVal); fflush(stdout);
				strcpy(attr_vals[0][0], keyLovOfAttrVal);
				printf("\n non LOV updated for attr[%s] with AttrVal==%s ",clsKeyAtrrId,keyLovOfAttrVal); fflush(stdout);
			}



			ITKCALL(ICS_ico_set_attributes(theICOTag,n_attrs,att_ids,n_attr_val,(const char***)attr_vals));
			printf("\n after update  classifiction VALUE by MDM process for attrid[%d]",attrid); fflush(stdout);
		}
		else
		{
			printf("\n input AttrKeyValue [%s] is NULL,so process aborted"); fflush(stdout);

		}





	}						
	printf("\n End setClsKeyValueToICSTag function "); fflush(stdout);


	return ITK_ok;

}


int getICOUpdCO( char *syscd,char *subsys,int   *n_found ,tag_t    **RetContrlObjs)
{
	int ifail = ITK_ok;
	
	tag_t        query           = NULLTAG;	

	char  *qry_entries3[] = {"SYSCD","SUBSYSCD"},
	*qry_values3[]       = {syscd,subsys};

	printf("\n in getICOUpdCO func");fflush(stdout);
	printf("\n\n Input syscd=%s SUBSYSCD==%s \n",syscd,subsys);fflush(stdout);
	
	printf("\n b4 Qry getICOUpdCO");fflush(stdout);

	//QRY_find("Control Objects...", &query);
	QRY_find2("Control Objects...", &query);
	printf("\n in after qry find getICOUpdCO");fflush(stdout);
	QRY_execute(query, 2, qry_entries3, qry_values3, n_found, RetContrlObjs);	
	printf("\n\n End Qry for getICOUpdCO control object size ==%d \n",*n_found);fflush(stdout);

	return ifail;
}

//Start Action Handler

/*
	Action Handler		:		AH_deleteMDMControlObj
	Description			:		This handler is used to delete the control object for MDM process post MDM process complete
*/

int AH_deleteMDMControlObj(EPM_rule_message_t msg)
{
	int i=0,status=ITK_ok;
	//int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	//int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	//int DcrItemscnt=0;
	int attachmentCount=0;
	//int    n_bom_views=0;
	//int    bom_view_index=0;
	//int    noAttachment=0;
	int cnt=0;
	char *obj_type=NULL;
	//char *dmlNumber=NULL;
	//char *revId=NULL;
	//char **qryEntries=NULL;
	//char **qryValues=NULL;
	//char *dmlProjID=NULL;
	//char *DMLDRstatus=NULL;
	//char *dmlRelType=NULL;
	
	//char *ItemNumber=NULL;
	//char *ItemNumberwithDml=NULL;

    //tag_t  rev=NULLTAG;
    //tag_t  rev1=NULLTAG;
	//tag_t  view_type= NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	//tag_t  primary1=NULLTAG;
	//tag_t  ItemObj = NULLTAG;
	//tag_t  DcrItemObj=NULLTAG;
	//tag_t  ctrlObjQry=NULLTAG;
	//tag_t  implemRelationType_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	

	
	tag_t  	objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		
	tag_t*   ClsObjTag= NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	int x =0;
	logical	delInd	= false;
	
	
	//char *VCAttrNo=NULL;
	
	//tag_t rev;
	tag_t	Project_t		= NULLTAG;
	//int k;
	//int i;
	int rule_count;
	int count=0;
	int retcount=0;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *parttype;
	char 	*ProjectID		= NULL;
	char *group_name	= NULL;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
	tag_t * 	secondary_objects ;
	tag_t			GroupMem								= NULLTAG;
	tag_t queryTag = NULLTAG;
	char
        *user_name_string;
		char *SesLoc;
		char *ccvRevId =NULL;
		char *CCVDesc =NULL;
		char *CCVDescDup =NULL;
		char *CntrlObjToBeName =NULL;
		int tscount;
    tag_t
        user;
		char* tsitem;
	tag_t relation_type_tag = NULLTAG;
	
	int status_count = 0;
	int structcount=0;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char NoSubSet[1900] = { 0 };
	char RevMisMatch[19000] = { 0 };
	//char *VcAttrStr=(char *) MEM_alloc(10 * sizeof(char *));
	char *VcAttrStr=MEM_alloc(2000);
	CntrlObjToBeName=(char *) MEM_alloc(10 * sizeof(char *));
	//char *VCattrList[5000];
	int p34=0;
	int p3=0;
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	//char RevMisMatch[19000];
  

printf("inside AH_deleteMDMControlObj Action Handler\n");fflush(stdout);

int MdmAHBypassChkFlg=0;
	printf("\n b4 call MdmAHBypassChk = %d func for AH_deleteMDMControlObj\n",MdmAHBypassChkFlg);fflush(stdout);
	MdmAHBypassChkFlg=AHBypassChk("MdmAHBypass");

	printf("\n after AH_deleteMDMControlObj MdmAHBypassChk = %d\n",MdmAHBypassChkFlg);fflush(stdout);
	if(MdmAHBypassChkFlg>0)
	{
		return ifail;
	}
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_deleteMDMControlObj attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n AH_deleteMDMControlObj Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=tags_found[0];
		char *id;
		char *Solid;
		char *TaskAnlyst =NULL;
		char *TaskAnlystDup =NULL;
		char *CntrlObjName=NULL;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);

		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
		printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);
		
		if(TaskAnlyst)
				{
					 tc_strdup(TaskAnlyst,&TaskAnlystDup);	
					
				}
		printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
		//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				char *VCClass;
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
				printf("\n Solution Item= %s",Solid);fflush(stdout);
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
				if(CCVDesc)
				{
					tc_strdup(CCVDesc,&CCVDescDup);
				}
				printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
				//return;
				
				if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
				{
				if(tc_strstr(parttype,"V")!=NULL || tc_strstr(parttype,"M")!=NULL)	//allowing CCV/V/Module
				{
					//if(tc_strstr(ccvRevId,"NR")!=NULL)
					//{
					char *projcode;
					char *DRStatus;
					tag_t  CurrentRoleTag = NULLTAG;
					char       roleName[SA_name_size_c+1];
					printf("\n going to delete control object ICOUPDLIST"); fflush(stdout);
					
					CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
								CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
								printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt,Solid); fflush(stdout);
					
					if(cnt>0)
					{
						retcount=0;
						int k=0;
						CALLAPI(getICOUpdCO("ICOUPDLIST",Solid,&retcount,&RetContrlObjs));
						printf("\n ICOUPDLIST count: %d for [%s] to delcontrol\n",retcount,Solid);fflush(stdout);
						if(retcount>0)
						{
							for(k=0;k<retcount;k++)
							{
								AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
								printf("\n delInd: %d\n",delInd);fflush(stdout);
								CALLAPI( AOM_ask_value_string(RetContrlObjs[k], "object_name", &CntrlObjName));
								printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
								if(delInd==false)
								{
									
											
									printf("\n b4Update delInd as true: %d\n",delInd);fflush(stdout);
									CALLAPI(AOM_lock(RetContrlObjs[k]));
									CALLAPI(AOM_set_value_logical(RetContrlObjs[k], "t5_DelInd",true));
									//id
									if(CntrlObjName)
									{
										tc_strcpy(CntrlObjToBeName,CntrlObjName);
										tc_strcat(CntrlObjToBeName,"_");
										tc_strcat(CntrlObjToBeName,id);
										printf("\n b4Update CntrlObjToBeName : %s\n",CntrlObjToBeName);fflush(stdout);
										CALLAPI( AOM_set_value_string(RetContrlObjs[k], "object_name", CntrlObjToBeName));
									}
									
									//CALLAPI(AOM_save(RetContrlObjs[k]));
									CALLAPI(AOM_save_without_extensions(RetContrlObjs[k]));
									CALLAPI(AOM_unlock(RetContrlObjs[k]));
									printf("\n After Update delInd as true: %d\n",delInd);fflush(stdout);
								}
							}
						}
						else
						{
							printf("\nNO ICOUPDLIST control object found for VC: %s\n",Solid);fflush(stdout);
						}
					}
				
						
				}
				else
				{
					printf("\n Part Type is not Vehicle/CCV/Module so skip to process the update clsval by MDM process"); fflush(stdout);
				}
			}
			else
			{
				printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case"); fflush(stdout);
			}
			}
			printf("\nEnd VC Attributes updation w.r.t MDM ");fflush(stdout);
  
		}
		
		
		}
		
	}
}
printf("\nEnd Delete Control object for MDM Attributes updation process w.r.t MDM DML ");fflush(stdout);	
	return ifail;
}


//End Action Handler

//Start Action Handler

/*
	Action Handler		:		AH_MdmUpdate_ForTechSpec
	Description			:		This handler checks the update the VC attributes for MDM process 
*/

int AH_MdmUpdate_ForTechSpec(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
	//int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	//int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	//int DcrItemscnt=0;
	int attachmentCount=0;
	//int    n_bom_views=0;
	//int    bom_view_index=0;
	//int    noAttachment=0;
	int cnt=0;
	char *obj_type=NULL;
	//char *dmlNumber=NULL;
	//char *revId=NULL;
	//char **qryEntries=NULL;
	//char **qryValues=NULL;
	//char *dmlProjID=NULL;
	//char *DMLDRstatus=NULL;
	//char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *usrInfo3=NULL;
	char *usrInfo4=NULL;
	char *usrInfo5=NULL;
	char *usrInfo6=NULL;
	char *usrInfo7=NULL;
	char *usrInfo8=NULL;
	char *usrInfo9=NULL;
	char *usrInfo10=NULL;
	//char *ItemNumber=NULL;
	//char *ItemNumberwithDml=NULL;

    //tag_t  rev=NULLTAG;
    //tag_t  rev1=NULLTAG;
	//tag_t  view_type= NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	//tag_t  primary1=NULLTAG;
	//tag_t  ItemObj = NULLTAG;
	//tag_t  DcrItemObj=NULLTAG;
	//tag_t  ctrlObjQry=NULLTAG;
	//tag_t  implemRelationType_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	

	
	tag_t  	objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		char   *TempVal			=NULL;
		tag_t close_tag;
	char *objectname=NULL;
	tag_t*   ClsObjTag= NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	int x =0;
	int p =0;
	logical	delInd	= false;
	char *info1=NULL;
	char *info2=NULL;
	char *info3=NULL;
	char *info4=NULL;
	char *info5=NULL;
	char *info6=NULL;
	char *info7=NULL;
	char *info8=NULL;
	char *info9=NULL;
	char *info10=NULL;
	
	//char *VCAttrNo=NULL;
	char *VCattrList[50000];
	char *TobeUpdAttrId=NULL;
	char *TobeUpdAttrVal=NULL;
	//char *VCAttrNo=NULL;
	//char *VCAttrNo=(char *) MEM_alloc(10 * sizeof(char *));
	char *VCAttrNo=MEM_alloc(200);
	char *getAttridval=NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char	*Proj_BU		= NULL;
	char 	*Proj_DesgOwnUnit	= NULL;
	char	*Proj_ProtoUnit		= NULL;
	char	*Proj_VCSubClass		= NULL;
	//tag_t rev;
	tag_t	Project_t		= NULLTAG;
	//int k;
	//int i;
	int rule_count;
	int count=0;
	int retcount=0;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *parttype;
	char 	*ProjectID		= NULL;
	char *group_name	= NULL;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
	tag_t * 	secondary_objects ;
	tag_t			GroupMem								= NULLTAG;
	tag_t queryTag = NULLTAG;
	char
        *user_name_string;
		char *SesLoc;
		char *ccvRevId =NULL;
		char *CCVDesc =NULL;
		char *CCVDescDup =NULL;
		int tscount;
    tag_t
        user;
		char* tsitem;
	tag_t relation_type_tag = NULLTAG;
	
	int status_count = 0;
	int structcount=0;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char NoSubSet[1900] = { 0 };
	char RevMisMatch[19000] = { 0 };
	//char *VcAttrStr=(char *) MEM_alloc(10 * sizeof(char *));
	char *VcAttrStr=MEM_alloc(2000);
	//char *VCattrList[5000];
	int k=0;
	int p3=0;
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	//char RevMisMatch[19000];
  
  
  

printf("inside AH_MdmUpdate_ForTechSpec Action Handler\n");fflush(stdout);

int MdmAHBypassChkFlg=0;
printf("\n b4 call MdmAHBypassChk = %d func for AH_MdmUpdate_ForTechSpec\n",MdmAHBypassChkFlg);fflush(stdout);
MdmAHBypassChkFlg=AHBypassChk("MdmAHBypass");

printf("\n after AH_MdmUpdate_ForTechSpec MdmAHBypassChk = %d\n",MdmAHBypassChkFlg);fflush(stdout);
if(MdmAHBypassChkFlg>0)
{
	return ifail;
}
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_MdmUpdate_ForTechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
	//Update Tech Spec Attribute call by client code Process
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;
	char *TaskNo=NULL;
	
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="AHMDMTSAttrUpd";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object AH_MdmUpdate_ForTechSpec CC  Found \n");fflush(stdout);
				
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_CopyAplRestrPrtToErcBom Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL)
						{	
						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &TaskNo));
						printf("\n TaskNo:%d\n",TaskNo);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
						
						printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
							if(tc_strlen(shellpath)>0)
							{
								printf("\ninside tm_AplBomCpyToErc Execute through client code......\n");fflush(stdout);
								
								
								sysCmnd=(char *) MEM_alloc(400);
								tc_strcpy(sysCmnd,shellpath);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,TaskNo);
								printf("\n before-- Calling shell file tm_MdmVcAttrUpdCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								system(sysCmnd);
								
								printf("\n after --- Calling shell file tm_MdmVcAttrUpdCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								
								MEM_free(sysCmnd);
							}
						}
					}
				}
			}	
			//End Update Tech Spec Attribute call by client code Process
			else
			{	
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_MdmUpdate_ForTechSpec Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
						{

										printf("\n inside query \n");fflush(stdout);
						
						
						//platform_rev=tags_found[0];
						char *id;
						char *Solid;
						char *TaskAnlyst =NULL;
						char *TaskAnlystDup =NULL;
						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
						//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
						printf("\n Task_id= %s",id);fflush(stdout);

						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
						printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);
						
						if(TaskAnlyst)
								{
									 tc_strdup(TaskAnlyst,&TaskAnlystDup);	
									
								}
						printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
						//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
						ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
						//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
						printf( "reference item attachment count:%d\n", count);fflush(stdout);
						if(count>0)
						{
							for(i=0;i<count;i++)
							{
								printf( "loop i=%d\n", i);fflush(stdout);
								char *VCClass;
								ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
								printf("\n Solution Item= %s",Solid);fflush(stdout);
								ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
								ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
								ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
								ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
								if(CCVDesc)
								{
									tc_strdup(CCVDesc,&CCVDescDup);
								}
								printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
								//return;
								
								if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
								{
								if(tc_strstr(parttype,"V")!=NULL || tc_strstr(parttype,"M")!=NULL)	//allowing CCV/V/Module
								{
									//if(tc_strstr(ccvRevId,"NR")!=NULL)
									//{
									char *projcode;
									char *DRStatus;
									tag_t  CurrentRoleTag = NULLTAG;
									char       roleName[SA_name_size_c+1];
									printf("\n before going to update VC Attributes value"); fflush(stdout);
									
									CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
												CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
												printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt,Solid); fflush(stdout);
									
									if(cnt>0)
									{
										retcount=0;
										CALLAPI(getICOUpdCO("ICOUPDLIST",Solid,&retcount,&RetContrlObjs));
										printf("\n to Upd VCAttr ICOUPDLIST count: %d for [%s]\n",retcount,Solid);fflush(stdout);
										for(k=0;k<retcount;k++)
										{
										if(retcount>0)
										{
											//VcAttrStr=NULL;
											AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
											printf("\n delInd: %d\n",delInd);fflush(stdout);
											if(delInd==false)
											{
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo1", &info1);
											printf("\n ICOUPDLIST: info1 %s\n",info1);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo2", &info2);
											printf("\n ICOUPDLIST: info2 %s\n",info2);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo3", &info3);
											printf("\n ICOUPDLIST: info3 %s\n",info3);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo4", &info4);
											printf("\n ICOUPDLIST: info4 %s\n",info4);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo5", &info5);
											printf("\n ICOUPDLIST: info5 %s\n",info5);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo6", &info6);
											printf("\n ICOUPDLIST: info6 %s\n",info6);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo7", &info7);
											printf("\n ICOUPDLIST: info7 %s\n",info7);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo8", &info8);
											printf("\n ICOUPDLIST:info8 %s\n",info8);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo9", &info9);
											printf("\n ICOUPDLIST: info9 %s\n",info9);fflush(stdout);
											AOM_ask_value_string( RetContrlObjs[k], "t5_userinfo10", &info10);
											printf("\n ICOUPDLIST: info10 %s\n",info10);fflush(stdout);
											
											if(info1)
											{
												tc_strcpy(VcAttrStr,info1);				
											
											}
											if(info2)
											{
											tc_strcat(VcAttrStr,info2);
											
											}
											if(info3)
											{
											tc_strcat(VcAttrStr,info3);
											
											}
											if(info4)
											{
											tc_strcat(VcAttrStr,info4);
											
											}
											if(info5)
											{
											tc_strcat(VcAttrStr,info5);
											
											}
											if(info6)
											{
											tc_strcat(VcAttrStr,info6);
											
											}
											if(info7)
											{
											tc_strcat(VcAttrStr,info7);
											
											}
											if(info8)
											{
											tc_strcat(VcAttrStr,info8);
											
											}
											if(info9)
											{
											tc_strcat(VcAttrStr,info9);
											
											}
											if(info10)
											{
											tc_strcat(VcAttrStr,info10);							
											}
											
											printf("\n ICOUPDLIST: Final VcAttrStr [%s]\n",VcAttrStr);fflush(stdout);
											if(VcAttrStr)
											{
												VCAttrNo=strtok(VcAttrStr,",");
												printf("inside strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
												p=0;
												 while (VCAttrNo != NULL)
												{
													printf("inside next strtok VCAttrNo=%s\n",VCAttrNo); fflush(stdout);
													VCattrList[p++] = VCAttrNo;
													VCAttrNo = strtok (NULL, ",");
													printf("\n2inside next strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
												}
												
											}
											}
											
											if(delInd==false)
											{
												for (x = 0; x < p; ++x) 
												{
													 printf("\nP size=%d X=%d VCattrList[x]=%s\n", p,x,VCattrList[x]);
													 getAttridval=NULL;
													 TobeUpdAttrId=NULL;
													 TobeUpdAttrVal=NULL;
													 getAttridval=strtok(VCattrList[x],",");
													 TobeUpdAttrId=strtok(getAttridval,":");
													 TobeUpdAttrVal=strtok(NULL,":");
													  printf("TobeUpdAttrId[%s] TobeUpdAttrVal[%s]\n", TobeUpdAttrId,TobeUpdAttrVal);
													  tag_t 	theICOTag=NULLTAG;
													  
													  if((ClsObjTag) && (TobeUpdAttrId) && (TobeUpdAttrVal))
													  {
														  theICOTag=*ClsObjTag;
														  printf("\nBefore call func  setClsValueToICSTag");fflush(stdout);
														 CALLAPI(setClsKeyValueToICSTag(theICOTag,TobeUpdAttrId,TobeUpdAttrVal)); 
														printf("\n After call func  setClsValueToICSTag");fflush(stdout);
													  }
													
												}
											}
											else
											{
												printf("\n MDM process configuration control object is not found or DelInd is true, so skip to process the update clsval by MDM process"); fflush(stdout);
											}
										}
									}
									}
									else
									{
										//CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
										char *ModAddrs=NULL;
										int cnt1=0;
										CALLAPI(getICOUpdCO("ICOUPDLIST",Solid,&retcount,&RetContrlObjs));
										printf("\n to Upd VCAttr ICOUPDLIST count: %d for [%s]\n",retcount,Solid);fflush(stdout);
										for(k=0;k<retcount;k++)
										{
											if(retcount>0)
											{
												//VcAttrStr=NULL;
												AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
												printf("\n delInd: %d\n",delInd);fflush(stdout);
												if(delInd==false)
												{
												AOM_ask_value_string( RetContrlObjs[k], "object_name", &ModAddrs);
												printf("\n ICOUPDLIST: ModAddrs %s\n",ModAddrs);fflush(stdout);
												break;
												}
											}
										}
										printf("\n b4 call func CreUpdClsValForModule in ICOUPDLIST AH with val ModAddrs[%s] for CCV/Module[%s] with delInd[%d] !!",ModAddrs,Solid,delInd); fflush(stdout);	
										if(ModAddrs!=NULL && tc_strlen(ModAddrs)>0 && delInd==false)
										{
										CALLAPI(CreUpdClsValForModule(ccvMstrTag,Solid,ModAddrs,"ICOUPDLIST"));
										}
										
										CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt1,&ClsObjTag));
										printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt1,Solid); fflush(stdout);				
									}
								
										
								}
								else
								{
									printf("\n Part Type is not Vehicle/CCV/Module so skip to process the update clsval by MDM process"); fflush(stdout);
								}
							}
							else
							{
								printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case"); fflush(stdout);
							}
							}
							printf("\nEnd VC Attributes updation w.r.t MDM ");fflush(stdout);
				  
						}
						
						
						}
						
					}
				}
			}
printf("\n End MDM Attributes updation process w.r.t MDM DML with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//End Action Handler


//Start Action Handler

/*
	Action Handler		:		AH_MdmWrdFileUpd4TechSpec
	Description			:		This handler replace the word file for TechSpec by MDM process 
*/

int AH_MdmWrdFileUpd4TechSpec(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
		int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	char *obj_type=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	logical	delInd	= false;



printf("inside AH_MdmWrdFileUpd4TechSpec Action Handler\n");fflush(stdout);

int MdmAHBypassChkFlg=0;
printf("\n b4 call MdmWrdAHBypass = %d func for AH_MdmWrdFileUpd4TechSpec\n",MdmAHBypassChkFlg);fflush(stdout);
MdmAHBypassChkFlg=AHBypassChk("MdmWrdAHBypass");

printf("\n after AH_MdmWrdFileUpd4TechSpec MdmWrdAHBypass = %d\n",MdmAHBypassChkFlg);fflush(stdout);
if(MdmAHBypassChkFlg>0)
{
	return ifail;
}
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_MdmWrdFileUpd4TechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
	//Update Tech Spec Attribute call by client code Process
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;
	char *TaskNo=NULL;
	
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="AHMDMTSWrdUpd";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object AH_MdmWrdFileUpd4TechSpec CC  Found \n");fflush(stdout);
				
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_CopyAplRestrPrtToErcBom Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL)
						{	
						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &TaskNo));
						printf("\n TaskNo:%d\n",TaskNo);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
						
						printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
							if(tc_strlen(shellpath)>0)
							{
								printf("\ninside MdmWrdFileUpdCC Execute through client code......\n");fflush(stdout);
								
								
								sysCmnd=(char *) MEM_alloc(400);
								tc_strcpy(sysCmnd,shellpath);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,TaskNo);
								printf("\n before-- Calling shell file tm_MdmWrdFileUpdCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								system(sysCmnd);
								
								printf("\n after --- Calling shell file tm_MdmWrdFileUpdCC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								
								MEM_free(sysCmnd);
							}
						}
					}
				}
			}	
			//End Update Tech Spec Attribute call by client code Process
			
printf("\n End MDM Word Doc updation process w.r.t MDM DML with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//End Action Handler


//TZ1.63 for CR-FY23-0092
/*static int doClassify(tag_t item,char *ClsName)
{
    int
        ii,
        nAttributes;
    tag_t
        class,
        view,
        rev,
        classificationObject;
    char **attributeNames;
     char   **attributeValues;
	 char *PartToBeClassify;
    printf("doClassify func with input ClsName = %s\n", ClsName);             
    ITK_CALL(ICS_find_class(ClsName, &class));
	
	AOM_ask_value_string( item, "object_string", &PartToBeClassify);
	printf("\n doClassify: PartToBeClassify %s\n",PartToBeClassify);fflush(stdout);
	
    //ITK_CALL(ICS_find_view(class, "defaultView", &view));
   view=NULLTAG;
   // ITK_CALL(ITEM_create_item("MY_ITEM", "item_name", "Item", "A", &item, &rev));
    //ITK_CALL(ITEM_save_item(item));
			//ITK_CALL(AOM_lock(item));		
			
    ITK_CALL(ICS_create_classification_object(item, "VCExceptionModule",class, &classificationObject));
	
	//ITK_CALL(ICS_classify_wsobject(item,class));
     //CALLAPI(AOM_set_value_logical(partRev,attrname,attrVal));
		//ITK_CALL(AOM_set_value_string(partRev,attrname,attrVal));
		// ITK_CALL(AOM_save(item));
		// ITK_CALL(AOM_refresh(item,0));
		// ITK_CALL(AOM_unlock(item));           
    ITK_CALL(ICS_ask_attributes_of_classification_obj(classificationObject,&nAttributes, &attributeNames, &attributeValues));
        
    printf("ICS_ask_attributes_of_classification_obj nAttributes = %d\n", nAttributes);
    for(ii = 0; ii < nAttributes; ii++)
    {
        printf("\t%s - %s\n", attributeNames[ii], attributeValues[ii]);
        MEM_free(attributeNames[ii]);
        MEM_free(attributeValues[ii]); 
    }
	//return 0;
    MEM_free(attributeNames);
    MEM_free(attributeValues);     
	return 0;
}
*/


int DataMining4VCattrBypassChk()
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 3;
	int ifail=0;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;
	
			printf("\n start func DataMining4VCattrBypassChk Calling qry to decide whether this AH will required or not ....\n");
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]="VCAttrMiningAHBypass";
				qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="0";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
			printf("\n DataMining4VCattrBypassChk is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
			ifail= control_number_found;
			 //return ifail;
			}
		
printf("\n end the function DataMining4VCattrBypassChk with ifail [%d]\n",ifail);fflush(stdout);		
return ifail;
}


//Start Action Handler

/*
	Action Handler		:		AH_PltfrmDataMining4VCattr
	Description			:		This handler will do the data mining for latest VC attributes for the platform
*/

int AH_PltfrmDataMining4VCattr(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
		int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	char *obj_type=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	logical	delInd	= false;



printf("inside AH_PltfrmDataMining4VCattr Action Handler\n");fflush(stdout);

int DataMining4VCattrBypassChkFlg=0;
printf("\n b4 call DataMining4VCattrBypassChk = %d func for AH_PltfrmDataMining4VCattr\n",DataMining4VCattrBypassChkFlg);fflush(stdout);
DataMining4VCattrBypassChkFlg=DataMining4VCattrBypassChk();

printf("\n after AH_PltfrmDataMining4VCattr DataMining4VCattrBypassChk = %d\n",DataMining4VCattrBypassChkFlg);fflush(stdout);
if(DataMining4VCattrBypassChkFlg>0)
{
	return ifail;
}
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_PltfrmDataMining4VCattr attachmentCount = %d\n",attachmentCount);fflush(stdout);
	//Update Tech Spec Attribute call by client code Process
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;
	char *TaskNo=NULL;
	
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="AHVCATTRMINING";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for  AHVCATTRMINING.... \n");fflush(stdout);
				
			}	
			
			printf("\n control object for AHVCATTRMINING is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object AH_PltfrmDataMining4VCattr CC  Found \n");fflush(stdout);
				
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n tm_CpyVCAttrToNewVC4Mining Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strstr(obj_type,"T5_ChangeTaskRevision")!=NULL)
						{
							tag_t* ERCDmlObjTags=NULLTAG;
							tag_t Task2DMLrelation_type=NULLTAG;
							char *ERCDMLCls=NULL;
							char *ErcDmlNo=NULL;
							int dmlcnt=0;
							GRM_find_relation_type("T5_DMLTaskRelation",&Task2DMLrelation_type);
		
							ITK_CALL(GRM_list_primary_objects_only(taskAttachments[Itemscnt],Task2DMLrelation_type,&dmlcnt,&ERCDmlObjTags ));
							if(dmlcnt>0)
							{
								//ITK_CALL(AOM_ask_value_string( ERCDmlObjTags[0], "t5_rlstype", &DMLrlstype));
								ITK_CALL(AOM_ask_value_string( ERCDmlObjTags[0], "item_id", &ErcDmlNo));
								ITK_CALL(AOM_ask_value_string(ERCDmlObjTags[0],"object_type" , &ERCDMLCls));
								taskAttachments[Itemscnt]=ERCDmlObjTags[0];
								printf("\n inside tm_CpyVCAttrToNewVC4Mining task to DML get ErcDmlNo:%s ERCDMLCls=%s\n",ErcDmlNo,ERCDMLCls);fflush(stdout);
							}
							
						}
						if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL || tc_strstr(obj_type,"T5_ChangeTaskRevision")!=NULL)
						{	
						ITK_CALL(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &TaskNo));
						printf("\n TaskNo:%s\n",TaskNo);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
						
						printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
							if(tc_strlen(shellpath)>0)
							{
								printf("\ninside tm_CpyVCAttrToNewVC4Mining Execute through client code......\n");fflush(stdout);
								
								
								sysCmnd=(char *) MEM_alloc(400);
								tc_strcpy(sysCmnd,shellpath);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,TaskNo);
								printf("\n before-- Calling shell file tm_CpyVCAttrToNewVC4Mining.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								system(sysCmnd);
								
								printf("\n after --- Calling shell file tm_CpyVCAttrToNewVC4Mining.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								
								MEM_free(sysCmnd);
							}
						}
					}
				}
			}	
			//End Update Tech Spec Attribute call by client code Process
			
printf("\n End tm_CpyVCAttrToNewVC4Mining process w.r.t VC/CCV Release DML with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//End Action Handler



	//Start Action Handler

	/*
		Action Handler		:		AH_NRVC_Chk_4_TechSpec
		Description			:		This handler checks the NR VC applicability 
	 */

	int AH_NRVC_Chk_4_TechSpec(EPM_rule_message_t msg)
	{
		int i=0;
		int status=ITK_ok;
		int ifail=0;
		int Itemscnt=0;
		int attachmentCount=0;
		int cnt=0;
		char *obj_type=NULL;
		tag_t  rootTask_t=NULLTAG;
		tag_t  DcrProblmItemsRelType=NULLTAG;
		tag_t  DmlTaskRelationType_t=NULLTAG;
		tag_t  DmlItemsRelation_t=NULLTAG;
		tag_t  *taskAttachments=NULLTAG;
		tag_t  	objTypeTag=NULLTAG;
		int k =0;
		int p =0;
		tag_t object=NULLTAG;
		int n_tags_found;
		tag_t *tags_found=NULLTAG;
		tag_t Task2DMLrelation_type=NULLTAG;
		tag_t *ERCTaskObjTags=NULLTAG;
		char *taskobj_type=NULL;
		char *id=NULL;
		int count=0;
		int retcount=0;
		
		int		n_entries = 1;
		char *val;
		char *parttype;
		char 	*ProjectID		= NULL;
		char *group_name	= NULL;
		char	*qry_entries[1] = {"Name"};
		char*	ProjectClass			= NULL;
		char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
		tag_t * 	secondary_objects ;
		tag_t			GroupMem								= NULLTAG;
		tag_t queryTag = NULLTAG;
		char *ccvRevId =NULL;
		char *CCVDesc =NULL;
		char *CCVDescDup =NULL;
		int NrFlg=0;
		printf("inside AH_NRVC_Chk_4_TechSpec Action Handler\n");fflush(stdout);

		int NRVCChkTSMiningChkFlg=0;
		printf("\n b4 call NRVCChkTSMiningChkFlg = %d func for AH_NRVC_Chk_4_TechSpec\n",NRVCChkTSMiningChkFlg);fflush(stdout);
		NRVCChkTSMiningChkFlg=AHBypassChk("NRVCChkTSMining");

		printf("\n after AH_NRVC_Chk_4_TechSpec NRVCChkTSMiningChkFlg = %d\n",NRVCChkTSMiningChkFlg);fflush(stdout);
		if(NRVCChkTSMiningChkFlg>0)
		{
			ifail = 1001;
			printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
			return ifail; //Go to error path
		}
		ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
		ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
		//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
		ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
		ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
		printf("\n AH_NRVC_Chk_4_TechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
		//Update Tech Spec Attribute call by client code Process

		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *TaskNo=NULL;
		char* dmlreltype = NULL;
		char *dmlreltypedup=NULL;

		//End Update Tech Spec Attribute call by client code Process

		if(attachmentCount>0)
		{
			for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
			{

				ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
				printf("\n AH_NRVC_Chk_4_TechSpec Object Type = %s\n",obj_type);fflush(stdout);

				if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
				{

					printf("\n inside AH_NRVC_Chk_4_TechSpec \n");fflush(stdout);

					ITK_CALL(AOM_ask_value_string(taskAttachments[Itemscnt],"t5_rlstype" , &dmlreltype));
					if(dmlreltype)
					{
						tc_strdup(dmlreltype,&dmlreltypedup);	

					}
					if(tc_strstr(dmlreltypedup,"Veh")==NULL)
					{
						ifail = 1001;
						printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith as release type is not vehicle release ifail=%d",ifail);fflush(stdout);
						return ifail; //Go to error path
					}
					//Steps to get ERC DML & check release type
					GRM_find_relation_type("T5_DMLTaskRelation",&Task2DMLrelation_type);
					ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],Task2DMLrelation_type,&count,&ERCTaskObjTags ));

					for(k=0;k<count;k++)
					{
						ITK_CALL(WSOM_ask_object_type2(ERCTaskObjTags[k],&taskobj_type));
						if(tc_strcasecmp(taskobj_type,"T5_ChangeTaskRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(ERCTaskObjTags[k],"item_id" , &id));
							//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
							printf("\n 1 in AH_NRVC_Chk_4_TechSpec for Task_id= %s",id);fflush(stdout);
							if(tc_strstr(id,"_00")!=NULL)
							{
							object=ERCTaskObjTags[k];
							break;
							}
						}
					}
				}

				printf("\n tm_CpyVCAttrToNewVC4Mining4Task taskobj_type = %s\n",taskobj_type);fflush(stdout);
				if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0 )
				{

					printf("\n inside query \n");fflush(stdout);
					//platform_rev=taskAttachments[Itemscnt];
					//char *id;
					//char *Solid;
					ITK_CALL(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
					//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
					printf("\n 2 AH_NRVC_Chk_4_TechSpec for Task_id= %s",id);fflush(stdout);
					if(tc_strstr(id,"_00")!=NULL)
					{
						object=taskAttachments[Itemscnt];
						//break;
					}

					//printf("\n after call tm_CpyVCAttrToNewVC4Mining for Task_id= %s",id);fflush(stdout);

				}


				//if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
				if(tc_strcasecmp(taskobj_type,"T5_ChangeTaskRevision")==0 || tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
				{

					printf("\n inside query \n");fflush(stdout);


					//platform_rev=tags_found[0];
					//char *id;
					 NrFlg=0;
					char *Solid;
					char *TaskAnlyst =NULL;
					char *TaskAnlystDup =NULL;
					ERROR_CHECK(AOM_ask_value_string(object,"item_id" , &id));
					//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
					printf("\n Task_id= %s",id);fflush(stdout);
					ERROR_CHECK(AOM_ask_value_string(object,"item_revision_id" , &ccvRevId));
					ERROR_CHECK(AOM_ask_value_string(object,"analyst_user_id",&TaskAnlyst));
					printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);

					if(TaskAnlyst)
					{
						tc_strdup(TaskAnlyst,&TaskAnlystDup);	

					}
					printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
					//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
					ERROR_CHECK(GRM_list_secondary_objects_only(object,DmlItemsRelation_t,&count,&secondary_objects ));
					//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
					printf( "reference item attachment count:%d\n", count);fflush(stdout);
					if(count>0)
					{
						for(i=0;i<count;i++)
						{
							printf( "loop i=%d\n", i);fflush(stdout);
							char *VCClass;
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
							printf("\n Solution Item= %s",Solid);fflush(stdout);
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
							if(CCVDesc)
							{
								tc_strdup(CCVDesc,&CCVDescDup);
							}
							printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
							//return;
							
							if(tc_strcmp(VCClass,"Design Revision")==0)
							{
								if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
								{
									if(tc_strstr(parttype,"V")!=NULL )	//allowing CCV/V/Module
									{
										if(tc_strstr(ccvRevId,"NR")!=NULL)
										{
											printf("\nAH_NRVC_Chk_4_TechSpec: Valid to go to data mining process with ifail=%d",ifail);fflush(stdout);
											//break;
											NrFlg=1;
											return ifail;

										}
										else
										{
											ifail = 1001;
											printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
											return ifail; //Go to error path
										}

									}
									else
									{
										printf("\n Part Type is not Vehicle/CCV/Module so skip to process the update clsval by MDM process"); fflush(stdout);
									}
								}
								else
								{
									printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case"); fflush(stdout);
								}
							}
						}
						printf("\nEnd VC Attributes updation w.r.t MDM ");fflush(stdout);

					}
					else
					{
						ifail = 1001;
						printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
						return ifail; //Go to error path
					}


				}
				else
				{
					ifail = 1001;
					printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
					return ifail; //Go to error path
				}

			}
		}
		else
		{
			ifail = 1001;
			printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
			return ifail; //Go to error path
		}
		printf("\n End AH_NRVC_Chk_4_TechSpec ifail[%d] NrFlg=%d",ifail,NrFlg);fflush(stdout);

		if(NrFlg<1)
		{
			ifail = 1001;
			printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining process as NrFlg is [%d] with ifail=%d",NrFlg,ifail);fflush(stdout);
			//return ifail; //Go to error path
		}
		if(ifail!=0)
		{
			printf("\nAH_NRVC_Chk_4_TechSpec: Not Valid to go to data mining processwith ifail=%d",ifail);fflush(stdout);
			//return ifail; //Go to error path
		}
		else
		{
			printf("\nAH_NRVC_Chk_4_TechSpec: Valid to go to data mining process with ifail=%d",ifail);fflush(stdout);
			//return ifail;
		}
		
		return ifail;
	}


	//End Action Handler

static int doClassify(tag_t item,char *ClsName)
{
    int
        ii,
        nAttributes;
    tag_t
        class,
        view,
        rev,
        classificationObject;
    char **attributeNames;
     char   **attributeValues;
	 char *PartToBeClassify;
	 char *ClsClass=NULL;
	 int ifail=0;
	 int cnt =0;
	 int ij=0;
tag_t*   ClsObjTag= NULLTAG;
    printf("doClassify func with input ClsName = %s\n", ClsName);             
   // ITK_CALL(ICS_find_class(ClsName, &class));
	ifail=ICS_find_class(ClsName, &class);
	if(ifail)
	{
		 printf("doClassify failed for part[%s]  \n", ClsName);    
		return 0;
	}
	AOM_ask_value_string( item, "object_string", &PartToBeClassify);
	printf("\n doClassify: PartToBeClassify %s\n",PartToBeClassify);fflush(stdout);
	
	
	ITK_CALL(AOM_ask_value_tags(item,"IMAN_classification",&cnt,&ClsObjTag));
	printf("\n  classified object count[%d] for CCV/Module[%s] !!",cnt,PartToBeClassify); fflush(stdout);
	if(cnt>0)
	{
		printf("\n11 ");fflush(stdout);
		//ClsClassMatchCnt=0;
		printf("\n111");fflush(stdout);
		for(ij=0;ij<cnt;ij++)
		{
			//printObject(ClsObjTag[i]);
			printf("\n b4 get ClsClass= %s",ClsClass);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(ClsObjTag[ij],"cid",&ClsClass));
			printf("\n ClsClass= %s",ClsClass);fflush(stdout);
			if(tc_strcmp(ClsName,ClsClass)==0)
			{
				printf("\n Part[%s] has already classified on ClsClass= %s",ClsClass,PartToBeClassify);fflush(stdout);
				return 0;
			}
		}
	}
	
	
    //ITK_CALL(ICS_find_view(class, "defaultView", &view));
   view=NULLTAG;
   // ITK_CALL(ITEM_create_item("MY_ITEM", "item_name", "Item", "A", &item, &rev));
    //ITK_CALL(ITEM_save_item(item));
			//ITK_CALL(AOM_lock(item));		
    //ITK_CALL(ICS_create_classification_object(item, "VCExceptionModule",class, &classificationObject));

int 	theAttributeCount=0;
int * 	theAttributeIds=0;
int * 	theAttributeValCounts=0;
const char *** 	theAttributeValues;

 ITK_CALL(ICS_ico_create2(NULL,item,ClsName,theAttributeCount,theAttributeIds,theAttributeValCounts,theAttributeValues,&classificationObject));
	
	//ITK_CALL(ICS_classify_wsobject(item,class));
     //CALLAPI(AOM_set_value_logical(partRev,attrname,attrVal));
		//ITK_CALL(AOM_set_value_string(partRev,attrname,attrVal));
		// ITK_CALL(AOM_save(item));
		// ITK_CALL(AOM_refresh(item,0));
		// ITK_CALL(AOM_unlock(item));        
tag_t  	theClass;
int  	nAttributes1;
tag_t * 	attributeList;
int p=0;
int * 	theAttrIDs;
int * 	theAttrFormats;
char ** 	theAttrAnnotations;
char ** 	theAttrNames;
char ** 	theAttrShortNames;
char **	theAttrUnits;
char **	theUserData1;
//char ** 	configField;
char ** 	theUserData2;
int * 	theFlags ;



int *	uncts;

int * 	nonMetricFormats;
char ** 	attributeIds;
char ** 	attributeNames1;
char ** 	shortNames;
char ** 	units;
char ** 	configBefore;
char ** 	configField1;
char ** 	configAfter;
int * 	flags;
char **	metricMin;
char ** 	metricMax;
char ** 	nonMetricMin;
char ** 	nonMetricMax;
char **	metricDefaultValue;
char **	nonMetricDefaultValue;
		ITK_CALL(ICS_ask_class_of_classification_obj(	classificationObject,&theClass));

		// ITK_CALL(ICS_describe_view	(	theClass,&nAttributes1,&theAttrIDs,&theAttrFormats,&theAttrAnnotations,&theAttrNames,&theAttrShortNames,&theAttrUnits,&theUserData1,&configField,&theUserData2,&theFlags));		
		
		 ITK_CALL(ICS_view_describe_view(theClass,&nAttributes1,&uncts,&theAttrFormats,&nonMetricFormats,&attributeIds,&attributeNames1,&shortNames,&units,&configBefore,&configField1,&configAfter,&flags,&metricMin,&metricMax,&nonMetricMin,&nonMetricMax,&metricDefaultValue,&nonMetricDefaultValue ));		
		//ITK_CALL(ICS_ask_attributes	(theClass,&nAttributes1,&attributeList));
		printf("ICS_ask_attributes nAttributes1 = %d\n", nAttributes1);
		
		for(p = 0; p < nAttributes1; p++)
		{
			//printf("\t%d\n", theAttrIDs[p]);
			printf("\t%s\n", attributeIds[p]);
			//MEM_free(attributeList[p]);
			//MEM_free(attributeValues[ii]); 
		}
		

    ITK_CALL(ICS_ask_attributes_of_classification_obj(classificationObject,&nAttributes, &attributeNames, &attributeValues));
        
    printf("ICS_ask_attributes_of_classification_obj nAttributes = %d\n", nAttributes);
    for(ii = 0; ii < nAttributes; ii++)
    {
        printf("\t%s - %s\n", attributeNames[ii], attributeValues[ii]);
        MEM_free(attributeNames[ii]);
        MEM_free(attributeValues[ii]); 
    }
	//return 0;
    MEM_free(attributeNames);
    MEM_free(attributeValues);     
	return 0;
}

static int UpdClsVal(char *ModNum,tag_t   ModClsTag,char *UpdClsCntrlObjName)
{
int retcount=0;
int k=0;
logical	delInd	= false;
logical	delInd1	= false;
tag_t *RetContrlObjs=NULLTAG;
char *info1=NULL;
	char *info2=NULL;
	char *info3=NULL;
	char *info4=NULL;
	char *info5=NULL;
	char *info6=NULL;
	char *info7=NULL;
	char *info8=NULL;
	char *info9=NULL;
	char *info10=NULL;
	//char *VcAttrStr=(char *) MEM_alloc(10 * sizeof(char *));
	char *VcAttrStr=MEM_alloc(2000);
	//char *VCAttrNo=NULL;
	char *VCattrList[50000];
	char *TobeUpdAttrId=NULL;
	char *TobeUpdAttrVal=NULL;
	//char *VCAttrNo=(char *) MEM_alloc(10 * sizeof(char *));
	char *VCAttrNo=MEM_alloc(200);
	char *getAttridval=NULL;
	int p=0;
	int x=0;
printf("\n inside the func UpdClsVal with input ModNum [%s] UpdClsCntrlObjName[%s]\n",ModNum,UpdClsCntrlObjName);fflush(stdout);
						ITK_CALL(getICOUpdCO(UpdClsCntrlObjName,ModNum,&retcount,&RetContrlObjs));
						printf("\n to Upd VCAttr ICOMODUPD count: %d for [%s]\n",retcount,ModNum);fflush(stdout);
//						int k=0;
						if(retcount>0)
						{	
						
						for(k=0;k<retcount;k++)
						{
							//VcAttrStr=NULL;
							delInd=false;
							AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
							printf("\n delInd: %d k=%d\n",delInd,k);fflush(stdout);
							if(delInd==false)
							{
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo1", &info1);
							printf("\n ICOMODUPD: info1 %s\n",info1);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo2", &info2);
							printf("\n ICOMODUPD: info2 %s\n",info2);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo3", &info3);
							printf("\n ICOMODUPD: info3 %s\n",info3);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo4", &info4);
							printf("\n ICOMODUPD: info4 %s\n",info4);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo5", &info5);
							printf("\n ICOMODUPD: info5 %s\n",info5);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo6", &info6);
							printf("\n ICOMODUPD: info6 %s\n",info6);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo7", &info7);
							printf("\n ICOMODUPD: info7 %s\n",info7);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo8", &info8);
							printf("\n ICOMODUPD:info8 %s\n",info8);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_Userinfo9", &info9);
							printf("\n ICOMODUPD: info9 %s\n",info9);fflush(stdout);
							AOM_ask_value_string( RetContrlObjs[k], "t5_userinfo10", &info10);
							printf("\n ICOMODUPD: info10 %s\n",info10);fflush(stdout);
							
							if(info1)
							{
								tc_strcpy(VcAttrStr,info1);				
							
							}
							if(info2)
							{
							tc_strcat(VcAttrStr,info2);
							
							}
							if(info3)
							{
							tc_strcat(VcAttrStr,info3);
							
							}
							if(info4)
							{
							tc_strcat(VcAttrStr,info4);
							
							}
							if(info5)
							{
							tc_strcat(VcAttrStr,info5);
							
							}
							if(info6)
							{
							tc_strcat(VcAttrStr,info6);
							
							}
							if(info7)
							{
							tc_strcat(VcAttrStr,info7);
							
							}
							if(info8)
							{
							tc_strcat(VcAttrStr,info8);
							
							}
							if(info9)
							{
							tc_strcat(VcAttrStr,info9);
							
							}
							if(info10)
							{
							tc_strcat(VcAttrStr,info10);							
							}
							
							printf("\n %s Final VcAttrStr [%s]\n",UpdClsCntrlObjName,VcAttrStr);fflush(stdout);
							if(VcAttrStr)
							{
								VCAttrNo=strtok(VcAttrStr,",");
								printf("inside strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
								p=0;
								 while (VCAttrNo != NULL)
								{
									printf("inside next strtok VCAttrNo=%s\n",VCAttrNo); fflush(stdout);
									VCattrList[p++] = VCAttrNo;
									VCAttrNo = strtok (NULL, ",");
									printf("\n2inside next strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
								}
								
							}
							}
							
							if(delInd==false)
							{
								for (x = 0; x < p; ++x) 
								{
									 printf("\nP size=%d X=%d VCattrList[x]=%s\n", p,x,VCattrList[x]);
									 getAttridval=NULL;
									 TobeUpdAttrId=NULL;
									 TobeUpdAttrVal=NULL;
									 getAttridval=strtok(VCattrList[x],",");
									 TobeUpdAttrId=strtok(getAttridval,":");
									 TobeUpdAttrVal=strtok(NULL,":");
									  printf("TobeUpdAttrId[%s] TobeUpdAttrVal[%s]\n", TobeUpdAttrId,TobeUpdAttrVal);
									  tag_t 	theICOTag=NULLTAG;
									  
									  if((ModClsTag) && (TobeUpdAttrId) && (TobeUpdAttrVal))
									  {
										  theICOTag=ModClsTag;
										  printf("\nBefore call func  setClsValueToICSTag");fflush(stdout);
										 ITK_CALL(setClsKeyValueToICSTag(theICOTag,TobeUpdAttrId,TobeUpdAttrVal)); 
										printf("\n After call func  setClsValueToICSTag");fflush(stdout);
									  }
									
								}
							}
							else
							{
								printf("\n MDM process configuration control object is not found or DelInd is true, so skip to process the update clsval by MDM process"); fflush(stdout);
							}
							printf("\n delInd before update : %d k=%d\n",delInd,k);fflush(stdout);
							ITK_CALL(AOM_lock(RetContrlObjs[k]));
							AOM_set_value_logical(RetContrlObjs[k] , "t5_DelInd", true);
							//ITK_CALL(AOM_save(RetContrlObjs[k]));
							ITK_CALL(AOM_save_without_extensions(RetContrlObjs[k]));
							printf("\n5555\n");fflush(stdout);
							ITK_CALL(AOM_unlock(RetContrlObjs[k]));
							AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd1);
							printf("\n delInd after update : %d k=%d\n",delInd1,k);fflush(stdout);
							
						}
					}
					
					return 0;
}
int CreUpdClsValForModule(tag_t ModuleMstrTag,char *ModNum,char *ToBeClsClassName,char *CntrlObjName)
{	
int cnt =0;
tag_t*   ClsObjTag= NULLTAG;
int ij=0;
char *ClsClass;
int cnt1 =0;
tag_t*   ClsObjTag1= NULLTAG;
int k=0;
char *ClsClass1;
int ClsClassMatchCnt;
	printf("\n  inside CreUpdClsValForModule func with input ToBeClsClassName[%s] for Module[%s] CntrlObjName[%s]!!",ToBeClsClassName,ModNum,CntrlObjName); fflush(stdout);

	ITK_CALL(AOM_ask_value_tags(ModuleMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
	printf("\n  classified object count[%d] for CCV/Module[%s] !!",cnt,ModNum); fflush(stdout);
	if(cnt>0)
	{
		ClsClassMatchCnt=0;
		for(ij<0;ij<cnt;ij++)
		{
			//printObject(ClsObjTag[i]);
			ITK_CALL(AOM_ask_value_string(ClsObjTag[ij],"cid" , &ClsClass));
			printf("\n ClsClass= %s",ClsClass);fflush(stdout);
			if(tc_strcmp(ClsClass,ToBeClsClassName)==0)
			{
				printf("\n b4x UpdClsVal for CCV/Module[%s] with CntrlObjName[%s]!!",ModNum,CntrlObjName); fflush(stdout);
				ITK_CALL(UpdClsVal(ModNum,ClsObjTag[ij],CntrlObjName));
				printf("\n Afterx UpdClsVal for CCV/Module[%s] !!",ModNum); fflush(stdout);
				ClsClassMatchCnt=1;
			}
			
		}
		
		printf("\n ClsClassMatchCnt[%d] !!",ClsClassMatchCnt); fflush(stdout);
		if(ClsClassMatchCnt<=0)
		{
			printf("\n b4 doClassify of CCV/Module[%s] for ToBeClsClassName[%s]!!",ModNum,ToBeClsClassName); fflush(stdout);
			ITK_CALL(doClassify(ModuleMstrTag,ToBeClsClassName));
			printf("\n after doClassify of CCV/Module[%s] for ToBeClsClassName[%s]!!",ModNum,ToBeClsClassName); fflush(stdout);
			//int k=0;
			ITK_CALL(AOM_ask_value_tags(ModuleMstrTag,"IMAN_classification",&cnt1,&ClsObjTag1));
			printf("\n else classified object count[%d] for CCV/Module[%s] !!",cnt1,ModNum); fflush(stdout);
			if(cnt1>0)
			{
				for(k<0;k<cnt1;k++)
				{
					//printObject(ClsObjTag[i]);
					ITK_CALL(AOM_ask_value_string(ClsObjTag1[k],"cid" , &ClsClass1));
					printf("\n ClsClass1= %s",ClsClass1);fflush(stdout);
					if(tc_strcmp(ClsClass1,ToBeClsClassName)==0)
					{
						printf("\n b4x UpdClsVal for CCV/Module[%s] CntrlObjName[%s]!!",ModNum,CntrlObjName); fflush(stdout);
						ITK_CALL(UpdClsVal(ModNum,ClsObjTag1[k],CntrlObjName));
						printf("\n Afterx UpdClsVal for CCV/Module[%s] !!",ModNum); fflush(stdout);
						ClsClassMatchCnt=1;
					}
					
				}
			}
			//printf("\n b4 UpdClsVal func call after classify CCV/Module[%s] !!",Solid); fflush(stdout);
			//ITK_CALL(UpdClsVal(Solid,ClsObjTag1));
			printf("\n After Classify & UpdClsVal func call after classify  CCV/Module[%s] for Classfication Class[%s] !!",ModNum,ToBeClsClassName); fflush(stdout);
			
		}
	}
	else
	{
			printf("\n not classification found b4 doClassify of CCV/Module[%s] for ToBeClsClassName[%s]!!",ModNum,ToBeClsClassName); fflush(stdout);
			ITK_CALL(doClassify(ModuleMstrTag,ToBeClsClassName));
			printf("\n after doClassify of CCV/Module[%s] for ToBeClsClassName[%s]!!",ModNum,ToBeClsClassName); fflush(stdout);
			//int k=0;
			ITK_CALL(AOM_ask_value_tags(ModuleMstrTag,"IMAN_classification",&cnt1,&ClsObjTag1));
			printf("\n else classified object count[%d] for CCV/Module[%s] !!",cnt1,ModNum); fflush(stdout);
			if(cnt1>0)
			{
				for(k<0;k<cnt1;k++)
				{
					//printObject(ClsObjTag[i]);
					ITK_CALL(AOM_ask_value_string(ClsObjTag1[k],"cid" , &ClsClass1));
					printf("\n ClsClass1= %s",ClsClass1);fflush(stdout);
					if(tc_strcmp(ClsClass1,ToBeClsClassName)==0)
					{
						printf("\n b4x UpdClsVal for CCV/Module[%s] CntrlObjName[%s]!!",ModNum,CntrlObjName); fflush(stdout);
						ITK_CALL(UpdClsVal(ModNum,ClsObjTag1[k],CntrlObjName));
						printf("\n Afterx UpdClsVal for CCV/Module[%s] !!",ModNum); fflush(stdout);
						//ClsClassMatchCnt=1;
					}
					
				}
			}
			//printf("\n b4 UpdClsVal func call after classify CCV/Module[%s] !!",Solid); fflush(stdout);
			//ITK_CALL(UpdClsVal(Solid,ClsObjTag1));
			printf("\n After Classify & UpdClsVal func call after classify  CCV/Module[%s] for Classfication Class[%s] !!",ModNum,ToBeClsClassName); fflush(stdout);
	}
	printf("\n end CreUpdClsValForModule func with ClsClassMatchCnt[%d] for Module[%s] !!",ClsClassMatchCnt,ModNum); fflush(stdout);
	//return ClsClassMatchCnt;
}

int AH_ModuleClsValUpd(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	int k=0;
	int x =0;
	int count=0;
	int retcount=0;
	char *ModAddress=NULL;
	char *obj_type=NULL;
	char *parttype;
	char *ccvRevId =NULL;
	char *CCVDesc =NULL;
	char *CCVDescDup =NULL;		
	char   type_name[TCTYPE_name_size_c+1];
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  	objTypeTag=NULLTAG;		
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	tag_t * 	secondary_objects ;		
	logical	delInd	= false;
	
	printf("inside AH_ModuleClsValUpd Action Handler\n");fflush(stdout);
	
	int MdmAHBypassChkFlg=0;
	printf("\n b4 call AHBypassChk = %d func for AH_ModuleClsValUpd\n",MdmAHBypassChkFlg);fflush(stdout);
	MdmAHBypassChkFlg=AHBypassChk("ModAHBypass");

	printf("\n after AH_ModuleClsValUpd AHBypassChk = %d\n",MdmAHBypassChkFlg);fflush(stdout);
	if(MdmAHBypassChkFlg>0)
	{
		return ifail;
	}
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("IMAN_reference",&DcrProblmItemsRelType));
	//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DcrProblmItemsRelType));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_ModuleClsValUpd attachmentCount = %d\n",attachmentCount);fflush(stdout);
	
	//Update Tech Spec Attribute call by client code Process
	
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;
	char *TaskNo=NULL;
	char *TaskAnlyst =NULL;
	char *TaskAnlystDup =NULL;
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="AHMODTSAttrUpd";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object AH_ModuleClsValUpd CC  Found \n");fflush(stdout);
				
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_ModuleClsValUpd Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strstr(obj_type,"T5_ChangeTaskRevision")!=NULL)
						{
							tag_t* ERCDmlObjTags=NULLTAG;
							tag_t Task2DMLrelation_type=NULLTAG;
							char *ERCDMLCls=NULL;
							char *ErcDmlNo=NULL;
							int dmlcnt=0;
							GRM_find_relation_type("T5_DMLTaskRelation",&Task2DMLrelation_type);
		
							ITK_CALL(GRM_list_primary_objects_only(taskAttachments[Itemscnt],Task2DMLrelation_type,&dmlcnt,&ERCDmlObjTags ));
							if(dmlcnt>0)
							{
								//ITK_CALL(AOM_ask_value_string( ERCDmlObjTags[0], "t5_rlstype", &DMLrlstype));
								ITK_CALL(AOM_ask_value_string( ERCDmlObjTags[0], "item_id", &ErcDmlNo));
								ITK_CALL(AOM_ask_value_string(ERCDmlObjTags[0],"object_type" , &ERCDMLCls));
								taskAttachments[Itemscnt]=ERCDmlObjTags[0];
								printf("\n inside AH_ModuleClsValUpd task to DML get ErcDmlNo:%s ERCDMLCls=%s\n",ErcDmlNo,ERCDMLCls);fflush(stdout);
								
							}
							
						}
						//if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL)
						//{	
						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &TaskNo));
						printf("\n TaskNo:%s\n",TaskNo);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
						
						printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
							if(tc_strlen(shellpath)>0)
							{
								printf("\ninside AH_ModuleClsValUpd Execute through client code......\n");fflush(stdout);
								
								
								sysCmnd=(char *) MEM_alloc(400);
								tc_strcpy(sysCmnd,shellpath);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,TaskNo);
								printf("\n before-- Calling shell file tm_ModuleClsValUp.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								system(sysCmnd);
								
								printf("\n after --- Calling shell file tm_ModuleClsValUp.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								
								MEM_free(sysCmnd);
							}
						//}
					}
				}
			}	
			//End Update Tech Spec Attribute call by client code Process
			else
			{
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_ModuleClsValUpd Object Type = %s\n",obj_type);fflush(stdout);
						
						
							if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL)
							{
								tag_t relatnType_tag                            = NULLTAG;
									int  noOfTask           = 0;
									tag_t *task_obj_tag                        		= NULLTAG;
									int ii=0;
								ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
									
								if (relatnType_tag!=NULLTAG)
								{
									if ( (ifail = GRM_list_secondary_objects_only( taskAttachments[Itemscnt], relatnType_tag, &noOfTask, &task_obj_tag )) != ITK_ok )
									{
										return ifail;
									}
									
									
									
									if(noOfTask>0)
									{			
									for (ii=0;ii<noOfTask ;ii++ )
									{	
										//NoDMLTask=1;

										// Retrieve the Task-Revision Tag.
										tag_t task_rev_tag                              = NULLTAG;

										task_rev_tag=task_obj_tag[ii];
										if (task_rev_tag  != NULLTAG)
										{

											int Tskcnt=0;
											int TskcntInPart=0;

											tag_t *TaskRevision=NULLTAG;
											tag_t relatnType_tag=NULLTAG;
											char  *TaskType   = NULL;
											char *TaskNum=NULL;


											ITK_CALL (AOM_ask_value_string(task_rev_tag,"item_id",&TaskNum));
											printf("\n DMLTaskRel : Task-Rev item_id : %s \n",TaskNum); fflush(stdout);
											ERROR_CHECK(AOM_ask_value_string(task_rev_tag,"analyst_user_id",&TaskAnlyst));
											printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);
											if(TaskAnlyst)
											{
												tc_strdup(TaskAnlyst,&TaskAnlystDup);	

											}
											if(tc_strstr(TaskNum,"_00")!=NULL)
											{
												taskAttachments[Itemscnt]=task_rev_tag;
												
											}
										}
									}
									}
								}
								
							}
						
						
						
						//if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
						//{

							printf("\n inside query \n");fflush(stdout);


							//platform_rev=tags_found[0];
							char *id;
							char *Solid;
							
							tag_t	priObjTypeTag			=	NULLTAG;
							//char   type_name[TCTYPE_name_size_c+1];
							char   *type_name=NULL;
							ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
							//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
							printf("\n Task_id= %s",id);fflush(stdout);

							

							
							printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
							//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
							ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
							//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
							printf( "reference item attachment count:%d\n", count);fflush(stdout);
							if(count>0)
							{
								for(i=0;i<count;i++)
								{
									printf( "loop i=%d\n", i);fflush(stdout);
									char *VCClass;
									if (TCTYPE_ask_object_type(secondary_objects[i],&priObjTypeTag)!=ITK_ok);
									//if (TCTYPE_ask_name(priObjTypeTag,type_name)!=ITK_ok);
									if (TCTYPE_ask_name2(priObjTypeTag,&type_name)!=ITK_ok);
									printf( "type_name:%d\n", type_name);fflush(stdout);
									if(tc_strcmp(type_name,"Design Revision")==0)
									{
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
										printf("\n Solution Item= %s",Solid);fflush(stdout);
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
										
										if(CCVDesc)
										{
											tc_strdup(CCVDesc,&CCVDescDup);
										}
										printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
										//return;

					
											if(tc_strstr(parttype,"M")!=NULL)	//allowing CCV/V/Module
											{
												//if(tc_strstr(ccvRevId,"NR")!=NULL)
												//{
												char *projcode;
												char *DRStatus;
												tag_t  CurrentRoleTag = NULLTAG;
												char       roleName[SA_name_size_c+1];
												printf("\n before going to update Module Attributes value"); fflush(stdout);

												printf("\n b4 call func getICOUpdCO with input ModNum [%s] for ICOMODUPD\n",Solid);fflush(stdout);
												CALLAPI(getICOUpdCO("ICOMODUPD",Solid,&retcount,&RetContrlObjs));
												printf("\n after call func getICOUpdCO for ICOMODUPD count: %d for [%s]\n",retcount,Solid);fflush(stdout);
												
												if(retcount>0)
												{	

													for(k=0;k<retcount;k++)
													{
														//VcAttrStr=NULL;
														delInd=false;
														AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
														printf("\n delInd: %d k=%d\n",delInd,k);fflush(stdout);
														if(delInd==false || delInd<=0)
														{
															AOM_ask_value_string( RetContrlObjs[k], "object_name", &ModAddress);
															printf("\n ICOMODUPD: Name %s\n",ModAddress);fflush(stdout);												
															break;

														}
													}
												}
												printf("\n b4 CreUpdClsValForModule ICOMODUPD: Name %s delInd=%d\n",ModAddress,delInd);fflush(stdout);
												if(ModAddress!=NULL && tc_strlen(ModAddress)>0 && delInd==false)
												{
													//int ClsClassMatchCnt=0;
													CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
													printf("\n b4 call func CreUpdClsValForModule with val ModAddress[%s] for CCV/Module[%s] !!",ModAddress,Solid); fflush(stdout);	
													ITK_CALL(CreUpdClsValForModule(ccvMstrTag,Solid,ModAddress,"ICOMODUPD"));
													//ITK_CALL(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
													printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt,Solid); fflush(stdout);								
													
												}
													

											}
											else
											{
												printf("\n Part Type is not Module so skip to process the update clsval by Module process"); fflush(stdout);
												continue;
											}
										
									}
									else
									{
										printf("\n Object Type is not Design Revision so skipping this."); fflush(stdout);
										continue;
									}
								}
								printf("\nEnd Module Attributes updation w.r.t Module ");fflush(stdout);

							}


						//}

					}
				}
			}
	printf("\n End Module Attributes updation process w.r.t Module DML with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//End Action Handler

//Start Action Handler

/*
	Action Handler		:		AH_DelModuleContrlObj
	Description			:		This handler is used to delete the control object for ICOMODUPD process post ICOMODUPD process complete
*/

int AH_DelModuleContrlObj(EPM_rule_message_t msg)
{
	int i=0,status=ITK_ok;

	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	char *obj_type=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t*   ClsObjTag= NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	int x =0;
	logical	delInd	= false;
	int count=0;
	int retcount=0;
	char *parttype;
	tag_t * 	secondary_objects ;
	char *ccvRevId =NULL;
	char *CCVDesc =NULL;
	char *CCVDescDup =NULL;
	char *CntrlObjToBeName =NULL;	
	char   type_name[TCTYPE_name_size_c+1];
	CntrlObjToBeName=(char *) MEM_alloc(10 * sizeof(char *));
	
	printf("inside AH_DelModuleContrlObj Action Handler\n");fflush(stdout);
	
	
	int MdmAHBypassChkFlg=0;
	printf("\n b4 call MdmAHBypassChk = %d func for AH_ModuleClsValUpd\n",MdmAHBypassChkFlg);fflush(stdout);
	MdmAHBypassChkFlg=AHBypassChk("MdmAHBypass");

	printf("\n after AH_ModuleClsValUpd MdmAHBypassChk = %d\n",MdmAHBypassChkFlg);fflush(stdout);
	if(MdmAHBypassChkFlg>0)
	{
		return ifail;
	}
	
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DcrProblmItemsRelType));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_DelModuleContrlObj attachmentCount = %d\n",attachmentCount);fflush(stdout);
	if(attachmentCount>0)
	{
		for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
		{
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
			printf("\n AH_DelModuleContrlObj Object Type = %s\n",obj_type);fflush(stdout);
			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{

				printf("\n inside query \n");fflush(stdout);


				//platform_rev=tags_found[0];
				char *id;
				char *Solid;
				char *TaskAnlyst =NULL;
				char *TaskAnlystDup =NULL;
				char *CntrlObjName=NULL;
				tag_t	priObjTypeTag			=	NULLTAG;
				//char   type_name[TCTYPE_name_size_c+1];
				char   *type_name=NULL;
				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
				//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
				printf("\n Task_id= %s",id);fflush(stdout);

				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
				printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);

				if(TaskAnlyst)
				{
					tc_strdup(TaskAnlyst,&TaskAnlystDup);	

				}
				printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
				//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
				ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
				//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						char *VCClass;
						if (TCTYPE_ask_object_type(secondary_objects[i],&priObjTypeTag)!=ITK_ok);
						//if (TCTYPE_ask_name(priObjTypeTag,type_name)!=ITK_ok);
						if (TCTYPE_ask_name2(priObjTypeTag,&type_name)!=ITK_ok);
						printf( "type_name:%d\n", type_name);fflush(stdout);
						if(tc_strcmp(type_name,"Design Revision")==0)
						{
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
							printf("\n Solution Item= %s",Solid);fflush(stdout);
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
							if(CCVDesc)
							{
								tc_strdup(CCVDesc,&CCVDescDup);
							}
							printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
							//return;

							if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
							{
								if(tc_strstr(parttype,"V")!=NULL || tc_strstr(parttype,"M")!=NULL)	//allowing CCV/V/Module
								{
									//if(tc_strstr(ccvRevId,"NR")!=NULL)
									//{
									char *projcode;
									char *DRStatus;
									tag_t  CurrentRoleTag = NULLTAG;
									char       roleName[SA_name_size_c+1];
									printf("\n going to delete control object ICOMODUPD"); fflush(stdout);

									CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
									CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
									printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt,Solid); fflush(stdout);

									if(cnt>0)
									{
										retcount=0;
										int k=0;
										CALLAPI(getICOUpdCO("ICOMODUPD",Solid,&retcount,&RetContrlObjs));
										printf("\n ICOMODUPD count: %d for [%s] to delcontrol\n",retcount,Solid);fflush(stdout);
										if(retcount>0)
										{
											for(k=0;k<retcount;k++)
											{
												AOM_ask_value_logical( RetContrlObjs[k], "t5_DelInd", &delInd);
												printf("\n delInd: %d\n",delInd);fflush(stdout);
												CALLAPI( AOM_ask_value_string(RetContrlObjs[k], "object_name", &CntrlObjName));
												printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
												if(delInd==false)
												{


													printf("\n b4Update delInd as true: %d\n",delInd);fflush(stdout);
													CALLAPI(AOM_lock(RetContrlObjs[k]));
													CALLAPI(AOM_set_value_logical(RetContrlObjs[k], "t5_DelInd",true));
													//id
													if(CntrlObjName)
													{
														tc_strcpy(CntrlObjToBeName,CntrlObjName);
														tc_strcat(CntrlObjToBeName,"_");
														tc_strcat(CntrlObjToBeName,id);
														printf("\n b4Update CntrlObjToBeName : %s\n",CntrlObjToBeName);fflush(stdout);
														CALLAPI( AOM_set_value_string(RetContrlObjs[k], "object_name", CntrlObjToBeName));
													}

													//CALLAPI(AOM_save(RetContrlObjs[k]));
													CALLAPI(AOM_save_without_extensions(RetContrlObjs[k]));
													CALLAPI(AOM_unlock(RetContrlObjs[k]));
													printf("\n After Update delInd as true: %d\n",delInd);fflush(stdout);
												}
											}
										}
										else
										{
											printf("\nNO ICOMODUPD control object found for VC: %s\n",Solid);fflush(stdout);
										}
									}


								}
								else
								{
									printf("\n Part Type is not Vehicle/CCV/Module so skip to process the update clsval by ICOMODUPD process"); fflush(stdout);
								}
							}
							else
							{
								printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case"); fflush(stdout);
							}
						}
						else
						{
							printf("\n Object Type is not Design Revision so skipping this."); fflush(stdout);
							continue;
						}
					}
					printf("\nEnd VC Attributes updation w.r.t ICOMODUPD ");fflush(stdout);

				}


			}

		}
	}
	printf("\nEnd Delete Control object for ICOMODUPD Attributes updation process w.r.t ICOMODUPD DML ");fflush(stdout);	
	return ifail;
}


//End Action Handler

//Start for TZ 1.69


int getNPICodeAttrNoWrtTSBU( char *TechSpecBusunit,int   *retNpiCodeattrno )
{
	int ifail = ITK_ok;
	
	//tag_t        query           = NULLTAG;	
	tag_t    *RetICONpiAttrNoContrlObjs=NULLTAG;
	char *CntrlObjName=NULL;
	char *NpiAttrid=NULL;
	int NpiAttridInt=0;
	int retCntrlObjcount=0;
	if(TechSpecBusunit)
	{
		
		retCntrlObjcount=0;
		//ITKCALL(getNPIAttrObj(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
		ITKCALL(getICOUpdCO(TechSpecBusunit,"ICONpiAttrNo",&retCntrlObjcount,&RetICONpiAttrNoContrlObjs));
		printf("\n after call getNPICodeAttrNoWrtTSBU count: %d \n",retCntrlObjcount);fflush(stdout);
		if(retCntrlObjcount>0)
		{
			ITKCALL( AOM_ask_value_string(RetICONpiAttrNoContrlObjs[0], "object_name", &CntrlObjName));
			printf("\n CntrlObjName: %s\n",CntrlObjName);fflush(stdout);
			AOM_ask_value_string( RetICONpiAttrNoContrlObjs[0], "t5_Userinfo1", &NpiAttrid);
			printf("\n after getNpiAttrid: info1[%s] \n",NpiAttrid);fflush(stdout);
		}
	}
	printf("\n 22getNPIAttrObj: info1[%s] \n",NpiAttrid);fflush(stdout);
	if(NpiAttrid!=NULL)
	{
		 NpiAttridInt=atoi(NpiAttrid);
	}
	if(NpiAttridInt>0)
	{
		 *retNpiCodeattrno =NpiAttridInt;
	}
	else
	{
		NpiAttridInt=8172;
		printf("\n NpiAttridInt=%d\n",NpiAttridInt);fflush(stdout);
		 *retNpiCodeattrno =NpiAttridInt;

	}
	printf("\n\n End Qry for getNPICodeAttrNoWrtTSBU control object size ==%d with retNpiCodeattrno=%d\n",retCntrlObjcount,*retNpiCodeattrno);fflush(stdout);

	return ifail;
}


//Start Action Handler

/*
	Action Handler		:		AH_UpdNpiCodeToClsVc
	Description			:		This handler is used to update NPI code for VC's Technical Specification Attributes 
	
*/

int AH_UpdNpiCodeToClsVc(EPM_rule_message_t msg)
{
	int i=0,status=ITK_ok;

	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	char *obj_type=NULL;
	char *ObjType=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  TasktodmlRel=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t*   ClsObjTag= NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	int x =0;
	logical	delInd	= false;
	int count=0;
	int retcount=0;
	char *parttype;
	tag_t * 	secondary_objects ;
	tag_t relation_tag  = NULLTAG;
	tag_t *primaryobjs = NULLTAG;
	tag_t TechSpecObjTag = NULLTAG;
	tag_t *TaskPrimaryObj = NULLTAG;
	char *TechSpecNum=NULL;
	char *ClsClass=NULL;
	
	char *ccvRevId =NULL;
	char *CCVDesc =NULL;
	char *CCVDescDup =NULL;
	int DMLRevcount = 0;
	char *VCBusUnit =NULL;
	char *VCBusUnitDup =NULL;
	char *DlgNpiCodeValu =NULL;
	char *DlgNpiCodeValuDup =NULL;
	char *CntrlObjToBeName =NULL;	
	char   type_name[TCTYPE_name_size_c+1];
	int k=0;
	int TScount=0;
	CntrlObjToBeName=(char *) MEM_alloc(10 * sizeof(char *));
	
	printf("inside AH_UpdNpiCodeToClsVc Action Handler\n");fflush(stdout);
	
	
	int MdmAHBypassChkFlg=0;
	printf("\n b4 call MdmAHBypassChk = %d func for AH_UpdNpiCodeToClsVc\n",MdmAHBypassChkFlg);fflush(stdout);
	MdmAHBypassChkFlg=AHBypassChk("UpdNpiAHBypass");

	printf("\n after AH_UpdNpiCodeToClsVc MdmAHBypassChk = %d\n",MdmAHBypassChkFlg);fflush(stdout);
	if(MdmAHBypassChkFlg>0)
	{
		return ifail;
	}
	
	
	
	int tscount=0;
	tag_t    *NpiValAttrCntrlObjSet=NULLTAG;
	tag_t    NpiValAttrCntrlObj=NULLTAG;
	char *Npiattrname=NULL;
	char *NpiattrnameDup=NULL;
	//t5_PartType
	//CMReferences
	//ITEM_copy_rev = for revise
	//printf("\n inside CheckTechSpecNoMultiRel_post_action function");fflush(stdout);
	//CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
	printf("\n inside AH_UpdNpiCodeToClsVc for NPI Attrbute name ");fflush(stdout);
	CALLAPI(getCntrlObj( "NPIValAttrName",&tscount ,&NpiValAttrCntrlObjSet));
	
	printf("\n inside AH_UpdNpiCodeToClsVc tscount[%d]",tscount);fflush(stdout);
	if(tscount>0)
	{
		NpiValAttrCntrlObj = NpiValAttrCntrlObjSet[0];
		if (NpiValAttrCntrlObj!=NULLTAG)
		{
			ITK_CALL(AOM_ask_value_string(NpiValAttrCntrlObj,"t5_Userinfo1",&Npiattrname));
			if(Npiattrname)
			{
				tc_strdup(Npiattrname,&NpiattrnameDup);	
			}
		}
	}
	printf("\n inside AH_UpdNpiCodeToClsVc NpiattrnameDup[%s]",NpiattrnameDup);fflush(stdout);
	/*
	char *inpClsName                  = ITK_ask_cli_argument("-cls=");
	char *inpveh                  = ITK_ask_cli_argument("-veh=");	
	char *inpattrno                = ITK_ask_cli_argument("-attrno=");
	char *inpattrval                = ITK_ask_cli_argument("-attrval=");
	*/
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	//ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_UpdNpiCodeToClsVc attachmentCount = %d\n",attachmentCount);fflush(stdout);
	if(attachmentCount>0)
	{
		for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
		{
			ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
			printf("\n AH_UpdNpiCodeToClsVc Object Type = %s\n",obj_type);fflush(stdout);
			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{

				printf("\n inside query \n");fflush(stdout);


				//platform_rev=tags_found[0];
				char *id;
				char *Solid;
				char *SolidDup;
				char *TaskAnlyst =NULL;
				char *TaskAnlystDup =NULL;
				char *ReleaseType =NULL;
				char *CntrlObjName=NULL;
				tag_t	priObjTypeTag			=	NULLTAG;
				//char   type_name[TCTYPE_name_size_c+1];
				char * 	type_name=NULL;
				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
				//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
				printf("\n Task_id= %s",id);fflush(stdout);

				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
				printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);

				if(TaskAnlyst)
				{
					tc_strdup(TaskAnlyst,&TaskAnlystDup);	

				}
				printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
				//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
				ERROR_CHECK(GRM_find_relation_type("T5_DMLTaskRelation",&TasktodmlRel));

				ERROR_CHECK(GRM_list_primary_objects_only(taskAttachments[Itemscnt],TasktodmlRel,&DMLRevcount,&TaskPrimaryObj));

				printf("\n DML Revision count is %d",DMLRevcount);fflush(stdout);

				ITK_CALL(WSOM_ask_object_type2(TaskPrimaryObj[0],&ObjType));
			    printf("\n AH_UpdNpiCodeToClsVc Object Type = %s\n",ObjType);fflush(stdout);
			if(tc_strcasecmp(ObjType,"ChangeRequestRevision")==0)
			{
	
				ERROR_CHECK(AOM_ask_value_string(TaskPrimaryObj[0],"t5_rlstype",&ReleaseType));
				printf("\n Release Type of DML = %s",ReleaseType);fflush(stdout);

				if(tc_strstr(ReleaseType,"TODR")!=NULL)
				{
					ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
					
				}
				else
				{
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DcrProblmItemsRelType));
					
				}
				

				ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&count,&secondary_objects ));
				//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						char *VCClass;
						if (TCTYPE_ask_object_type(secondary_objects[i],&priObjTypeTag)!=ITK_ok);
						if (TCTYPE_ask_name2(priObjTypeTag,&type_name)!=ITK_ok);
						printf( "type_name:%s\n", type_name);fflush(stdout);
						if(tc_strcmp(type_name,"Design Revision")==0)
						{
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
							printf("\n Solution Item= %s",Solid);fflush(stdout);
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
							ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
							if(Solid)
							{
								tc_strdup(Solid,&SolidDup);
							}
							if(VCBusUnit)
							{
								tc_strdup(VCBusUnit,&VCBusUnitDup);
							}
							printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",SolidDup,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
							//return;

							if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
							{
								if(tc_strstr(parttype,"V")!=NULL )	//allowing CCV/V only
								{
									//if(tc_strstr(ccvRevId,"NR")!=NULL)
									//{
									char *projcode;
									char *DRStatus;
									char *relation_name;
									tag_t  CurrentRoleTag = NULLTAG;
									char       roleName[SA_name_size_c+1];
									printf("\n inside vehicle/CCV found in AH_UpdNpiCodeToClsVc"); fflush(stdout);

									if(NpiattrnameDup)
									{
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],NpiattrnameDup, &DlgNpiCodeValu));
									}
									else
									{
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"gov_classification" , &DlgNpiCodeValu));
									}
									//ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"gov_classification" , &DlgNpiCodeValu));
									if(DlgNpiCodeValu)
									{
										tc_strdup(DlgNpiCodeValu,&DlgNpiCodeValuDup);
									}
									printf("\n DlgNpiCodeValuDup[%s] in AH_UpdNpiCodeToClsVc",DlgNpiCodeValuDup); fflush(stdout);
									if(tc_strlen(DlgNpiCodeValuDup)<=0)
									{
										
										printf("\n null value found for DlgNpiCodeValuDup[%s] so skipping this process for AH_UpdNpiCodeToClsVc",DlgNpiCodeValuDup); fflush(stdout);
										return ifail;
									}
									printf("\n outside check DlgNpiCodeValuDup[%s] in AH_UpdNpiCodeToClsVc",DlgNpiCodeValuDup); fflush(stdout);
									ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
									printf("\n after T5_VCSpec relation find"); fflush(stdout);
									if(relation_type_tag != NULLTAG)
									{
										printf("\n inside T5_VCSpec relation found"); fflush(stdout);
										ERROR_CHECK(TCTYPE_ask_name2( relation_type_tag, &relation_name));
										printf("\n relation_name[%s]",relation_name); fflush(stdout);
										ERROR_CHECK(GRM_list_secondary_objects_only(secondary_objects[i],relation_type_tag,&TScount,&primaryobjs));
										printf("\n TScount: %d\n", TScount);fflush(stdout);
										if(TScount>0)
										{
											TechSpecObjTag=primaryobjs[0];
											printf("\nDlgNpiCodeValuDup");fflush(stdout);
											ERROR_CHECK(AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum));
											printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
											ERROR_CHECK( AOM_ask_value_string(TechSpecObjTag, "t5_VCClassName", &VCBusUnit));
											if(VCBusUnit)
											{
												tc_strdup(VCBusUnit,&VCBusUnitDup);
											}
											printf("\n VCBusUnitDup: %s\n", VCBusUnitDup);fflush(stdout);
										}
									}
									
									//CALLAPI(GRM_create_relation(secondary_objects[i],techspecRevTag[0],relation_type_tag, NULLTAG, &relation_tag));
									//CALLAPI(GRM_save_relation(relation_tag));
									printf("\n\n DlgNpiCodeValuDup--After NPI  code update: "); fflush(stdout);
									
									//char *VCClsAddress=NULL
									//char *TobeUpdAttrId=NULL;
									char TobeUpdAttrId[30];
									int retcount;
									int ClsAttrId=0 ;
									printf("\n TechSpecBusunitDup: %s \n",VCBusUnitDup);fflush(stdout);
									ITK_CALL(getNPICodeAttrNoWrtTSBU(VCBusUnitDup,&retcount));
									printf("\n after call getNPICodeAttrNoWrtTSBU count: %d \n",retcount);fflush(stdout);
									ClsAttrId=retcount;
									printf("\n ClsAttrId[%d] for NPI Code \n",ClsAttrId);fflush(stdout);
									if(ClsAttrId>0)
									{

										sprintf(TobeUpdAttrId, "%d", ClsAttrId);
										printf("\n inside sprintf TobeUpdAttrId[%s] for NPI Code \n",TobeUpdAttrId);fflush(stdout);
										//key_lov_id=theKeyLOVId;	
									}
									printf("\n  TobeUpdAttrId[%s]",TobeUpdAttrId); fflush(stdout);
									//char VCClsAddress[100];
									char *VCClsAddress=(char *) MEM_alloc(20 * sizeof(char *));
									char *VCClsAddressDup=NULL;
									tc_strcpy(VCClsAddress,VCBusUnitDup);
									tc_strcat(VCClsAddress,"VCATTR01");
									if(VCClsAddress)
										{
											tc_strdup(VCClsAddress,&VCClsAddressDup);
										}
									printf("\n classification Address [%s] for CCV[%s] !!",VCClsAddressDup,SolidDup); fflush(stdout);
									ITK_CALL(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));
									ITK_CALL(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
									printf("\n classified object count[%d] for CCV/Module[%s] !!",cnt,SolidDup); fflush(stdout);
									 tag_t 	theICOTag=NULLTAG;
									if(cnt>0)
									{
										for(k=0;k<cnt;k++)
										{
										theICOTag=ClsObjTag[k];
										printf("\n b4 get ClsClass= %s",ClsClass);fflush(stdout);
										ITK_CALL(AOM_ask_value_string(theICOTag,"cid",&ClsClass));
										printf("\n ClsClass= %s",ClsClass);fflush(stdout);
											if(tc_strcmp(ClsClass,VCClsAddressDup)==0)
											{
												if(tc_strlen(DlgNpiCodeValuDup)>0 && DlgNpiCodeValuDup !=NULL)
												{
												//Logic for control object check 1st
												
												tag_t *list_of_WSO_cntrl_tags=NULLTAG;
												tag_t   qryTagCntrl    = NULLTAG;
												int     n_entryCntrl    = 3;
												char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
												char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
												//int cntrlcnt=0;
												int  control_number_found=0;
												char* shellpath = NULL;
												char* sysCmnd = NULL;
				
												//if(QRY_find("Control Objects...", &qryTagCntrl));
												if(QRY_find2("Control Objects...", &qryTagCntrl));
												if (qryTagCntrl)
												{
													printf("\n Control Object Query Found \n");fflush(stdout);
													qry_valuesCntrl[0]="ICONpiAttrNoUpdExe";
													qry_valuesCntrl[1]="Live";
													//qry_valuesCntrl1[1]="ICONpiAttrNo";
													qry_valuesCntrl[2]="0";
													
													if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
												}
												else
												{
													printf("\n Control Object Query not Found .... \n");fflush(stdout);
													
												}	
												
												printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
												
												if(control_number_found>0)
												{
													printf("\n Control Object ICONpiAttrNo Found \n");fflush(stdout);											
													
															
															ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags[0],"t5_Userinfo1",&shellpath));
															
															printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
																if(tc_strlen(shellpath)>0)
																{
																	printf("\ninside ICONpiAttrNo Execute through client code with values VC[%s] TobeUpdAttrId[%s]for DlgNpiCodeValuDup[%s]\n",SolidDup,TobeUpdAttrId,DlgNpiCodeValuDup);fflush(stdout);
																	
																	
																	sysCmnd=(char *) MEM_alloc(400);
																	tc_strcpy(sysCmnd,shellpath);
																	tc_strcat(sysCmnd," ");
																	tc_strcat(sysCmnd,SolidDup);
																//	tc_strcat(sysCmnd," ");
																	//tc_strcat(sysCmnd,TobeUpdAttrId);
																	// tc_strcat(sysCmnd," ");
																	// tc_strcat(sysCmnd,DlgNpiCodeValuDup);
																	printf("\n before-- Calling shell file tm_UpdNPICodeToClsnNew.sh using client system command: %s\n",sysCmnd);fflush(stdout);
																	system(sysCmnd);
																	
																	printf("\n after --- Calling shell file tm_UpdNPICodeToClsnNew.sh using client system command: %s\n",sysCmnd);fflush(stdout);
																	
																	MEM_free(sysCmnd);
																}
												}
												else
												{												
												printf("\nNo control found therefore going to update by AH directly Before NPI Code Update call func  setClsValueToICSTag");fflush(stdout);
												ITK_CALL(setClsValueToICSTag(theICOTag,TobeUpdAttrId,DlgNpiCodeValuDup)); 
												printf("\n After NPI Code Update call func  setClsValueToICSTag");fflush(stdout);
												}
												}
												
											}
										}
									}


								}
								else
								{
									printf("\n Part Type is not Vehicle/CCV so ski,p to process the update clsval by AH_UpdNpiCodeToClsVc process"); fflush(stdout);
								}
							}
							else
							{
								printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case"); fflush(stdout);
							}
						}
						else
						{
							printf("\n Object Type is not Design Revision so skipping this."); fflush(stdout);
							continue;
						}
					}
					printf("\nEnd VC Attributes updation w.r.t AH_UpdNpiCodeToClsVc ");fflush(stdout);

				}


			}
		}

		}
	}
	printf("\nEnd AH_UpdNpiCodeToClsVc Attributes updation process w.r.t AH_UpdNpiCodeToClsVc DML ");fflush(stdout);	
	return ifail;
}


//End Action Handler


//End for TZ 1.69

//End for CR-FY23-0092


int GetRestructCurrVewMaskVal( tag_t BomlineTag,int   *RetCurVwMaskValFlg ,char **RetCVMAttrName,char    **RetCVMValue)
{
char *CurVwMaskJ=NULL;
char *JsrCVMValue=NULL;
char *JsrCVMAttrName=NULL;
char *CurVwMaskC=NULL;
char *CarCVMValue=NULL;
char *CarCVMAttrName=NULL;
char *CurVwMaskP=NULL;
char *PunCVMValue=NULL;
char *PunCVMAttrName=NULL;
char *CurVwMaskD=NULL;
char *DwdCVMValue=NULL;
char *DwdCVMAttrName=NULL;
char *CurVwMaskS=NULL;
char *SndCVMValue=NULL;
char *SndCVMAttrName=NULL;
char *CurVwMaskL=NULL;
char *lkoCVMValue=NULL;
char *lkoCVMAttrName=NULL;
char *CurVwMaskU=NULL;
char *UtkCVMValue=NULL;
char *UtkCVMAttrName=NULL;
char *CurVwMaskV=NULL;
char *APLVCVMValue=NULL;
char *APLVCVMAttrName=NULL;
//char *RetCVMValue=NULL;
//char *RetCVMAttrName=NULL;
//int RetCurVwMaskValFlg=NULL;
int ifail = 0;
int JsrCVMAttr_flag=0;
int JsrCVMValFlg=0;
int CarCVMAttr_flag=0;
int CarCVMValFlg=0;
int PunCVMAttr_flag=0;
int PunCVMValFlg=0;
int DwdCVMAttr_flag=0;
int DwdCVMValFlg=0;
int SndCVMAttr_flag=0;
int SndCVMValFlg=0;
int lkoCVMAttr_flag=0;
int LkoCVMValFlg=0;
int UtkCVMAttr_flag=0;
int UtkCVMValFlg=0;
int APLVCVMAttr_flag=0;
int APLVCVMValFlg=0;
int num_values=0;
char **CVMValuelist=NULL;
int j=0;
printf("\n inside function GetRestructCurrVewMaskVal with BOMLINE input Tag[%u] ",BomlineTag);fflush(stdout);

*RetCVMAttrName	=	NULL;
*RetCVMValue    =   NULL;
	*RetCVMAttrName	=	(char *) MEM_alloc(20 * sizeof(char *));
	*RetCVMValue=       (char *) MEM_alloc(20 * sizeof(char *));
	if(BomlineTag!=NULLTAG)
	{
		
		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskC", &CarCVMAttr_flag));
		//printf("\n CarCVMAttr_flag:%d ..............",CarCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, CarCVMAttr_flag, &CarCVMValue));
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskC",&num_values, &CVMValuelist));
		printf("\n num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tCarCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&CarCVMValue);
						break;
					}
               }
			printf("\n CarCVMValue:%s ..............",CarCVMValue);fflush(stdout);   
		if(tc_strlen(CarCVMValue)>0 && CarCVMValue!=NULL)
		{
			CurVwMaskC="bl_occ_t5_CurrentViewMaskC";
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskC";
			tc_strcpy(*RetCVMAttrName,CurVwMaskC);
			tc_strcpy(*RetCVMValue,CarCVMValue);
			*RetCurVwMaskValFlg=CarCVMValFlg++;
			printf("\n CarCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",CarCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
			
		}
		
		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskJ", &JsrCVMAttr_flag));
		//printf("\n JsrCVMAttr_flag:%d ..............",JsrCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, JsrCVMAttr_flag, &JsrCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskJ",&num_values, &CVMValuelist));
		printf("\n JsrCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tJsrCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&JsrCVMValue);
						break;
					}
               }
			//printf("\n CarCVMValue:%s ..............",CarCVMValue);fflush(stdout);   
		
		printf("\n JsrCVMValue:%s ..............",JsrCVMValue);fflush(stdout);
		if(tc_strlen(JsrCVMValue)>0 && JsrCVMValue!=NULL)
		{
			CurVwMaskJ="bl_occ_t5_CurrentViewMaskJ";
			tc_strcpy(*RetCVMAttrName,CurVwMaskJ);
			tc_strcpy(*RetCVMValue,JsrCVMValue);
			*RetCurVwMaskValFlg=JsrCVMValFlg++;
			printf("\n JsrCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",JsrCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}


		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskP", &PunCVMAttr_flag));
		//printf("\n PunCVMAttr_flag:%d ..............",PunCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, PunCVMAttr_flag, &PunCVMValue));
		
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskP",&num_values, &CVMValuelist));
		printf("\n PunCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tPuneCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&PunCVMValue);
						break;
					}
               }
		
		printf("\n PunCVMValue:%s ..............",PunCVMValue);fflush(stdout);
		if(tc_strlen(PunCVMValue)>0 && PunCVMValue!=NULL)
		{
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskP";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskP");
			tc_strcpy(*RetCVMValue,PunCVMValue);
			*RetCurVwMaskValFlg=PunCVMValFlg++;
			printf("\n PunCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",PunCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}

		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskD", &DwdCVMAttr_flag));
		//printf("\n DwdCVMAttr_flag:%d ..............",DwdCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, DwdCVMAttr_flag, &DwdCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskD",&num_values, &CVMValuelist));
		printf("\n DwdCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tDhwCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&DwdCVMValue);
						break;
					}
               }
		printf("\n DwdCVMValue:%s ..............",DwdCVMValue);fflush(stdout);
		if(tc_strlen(DwdCVMValue)>0 && DwdCVMValue!=NULL)
		{
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskD";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskD");
			tc_strcpy(*RetCVMValue,DwdCVMValue);
			*RetCurVwMaskValFlg=DwdCVMValFlg++;
			printf("\n DwdCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",DwdCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}

		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskS", &SndCVMAttr_flag));
		//printf("\n SndCVMAttr_flag:%d ..............",SndCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, SndCVMAttr_flag, &SndCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskS",&num_values, &CVMValuelist));
		printf("\n SndCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tDhwCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&SndCVMValue);
						break;
					}
               }
		printf("\n SndCVMValue:%s ..............",SndCVMValue);fflush(stdout);
		if(tc_strlen(SndCVMValue)>0 && SndCVMValue!=NULL)
		{
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskS";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskS");
			//*RetCVMValue=SndCVMValue;
			tc_strcpy(*RetCVMValue,SndCVMValue);
			*RetCurVwMaskValFlg=SndCVMValFlg++;
			printf("\n SndCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",SndCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}

		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskL", &lkoCVMAttr_flag));
		//printf("\n lkoCVMAttr_flag:%d ..............",lkoCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, lkoCVMAttr_flag, &lkoCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskL",&num_values, &CVMValuelist));
		printf("\n lkoCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tDhwCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&lkoCVMValue);
						break;
					}
               }
		printf("\n lkoCVMValue:%s ..............",lkoCVMValue);fflush(stdout);
		if(tc_strlen(lkoCVMValue)>0 && lkoCVMValue!=NULL)
		{
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskL";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskL");
			//*RetCVMValue=lkoCVMValue;
			tc_strcpy(*RetCVMValue,lkoCVMValue);
			*RetCurVwMaskValFlg=LkoCVMValFlg++;
			printf("\n LkoCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",LkoCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}

		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskU", &UtkCVMAttr_flag));
		//printf("\n UtkCVMAttr_flag:%d ..............",UtkCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, UtkCVMAttr_flag, &UtkCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskU",&num_values, &CVMValuelist));
		printf("\n UtkCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tDhwCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&UtkCVMValue);
						break;
					}
               }
		
		printf("\n UtkCVMValue:%s ..............",UtkCVMValue);fflush(stdout);
		if(tc_strlen(UtkCVMValue)>0 && UtkCVMValue!=NULL)
		{		
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskU";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskU");
			//*RetCVMValue=UtkCVMValue;
			tc_strcpy(*RetCVMValue,UtkCVMValue);
			*RetCurVwMaskValFlg=UtkCVMValFlg++;
			printf("\n UtkCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",UtkCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
		}

		//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskV", &APLVCVMAttr_flag));
		//printf("\n APLVCVMAttr_flag:%d ..............",APLVCVMAttr_flag);fflush(stdout);
		//ITKCALL(BOM_line_ask_attribute_string(BomlineTag, APLVCVMAttr_flag, &APLVCVMValue));
		CVMValuelist=NULL;
		num_values=0;
		ITKCALL(AOM_ask_displayable_values(BomlineTag, "bl_occ_t5_CurrentViewMaskV",&num_values, &CVMValuelist));
		printf("\n APLVCVMValue num_values:%d ..............",num_values);fflush(stdout);
		
		for(j=0;j<num_values;j++)
               {
               printf("\n\tDhwCVMValuelist=%s,",CVMValuelist[j]);fflush(stdout);
					if(CVMValuelist[j])
					{
						tc_strdup(CVMValuelist[j],&APLVCVMValue);
						break;
					}
               }
		printf("\n APLVCVMValue:%s ..............",APLVCVMValue);fflush(stdout);
		if(tc_strlen(APLVCVMValue)>0 && APLVCVMValue!=NULL)
		{
			printf("\n APLVCVMValue:%s ..............",APLVCVMValue);fflush(stdout);
			//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskV";
			tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskV");
			//*RetCVMValue=APLVCVMValue;
			tc_strcpy(*RetCVMValue,APLVCVMValue);
			*RetCurVwMaskValFlg=APLVCVMValFlg++;
			printf("\n APLVCVMValFlg:%d RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",APLVCVMValFlg,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
			
		}

	}
	else
	{
		printf("\n input BOMLINE tag is NULL [%u] ",BomlineTag);fflush(stdout);
		//*RetCVMAttrName="bl_occ_t5_CurrentViewMaskC";
		tc_strcpy(*RetCVMAttrName,"bl_occ_t5_CurrentViewMaskC");
		//*RetCVMValue=NULL;
		tc_strcpy(*RetCVMValue,"NoVal");
		*RetCurVwMaskValFlg=0;
		printf("\n no plant flag found with RetCVMValue[%s], RetCurVwMaskValFlg:%d RetCVMAttrName[%s] RetCVMValue[%s]..............",RetCVMValue,*RetCurVwMaskValFlg,*RetCVMAttrName,*RetCVMValue);fflush(stdout);
	}
	printf("\n final RetCurVwMaskValFlg:%d ..............",RetCurVwMaskValFlg);fflush(stdout);
	return ifail;
}

extern int APLBomCarryForwardDuringERCRevise(tag_t DesignRevTag)
{
	//EPM_decision_t decision;
	int status;
	tag_t ItemTypeTag = NULLTAG;
	int iNumAttch = 0;
	int count = 0;
	int k = 0,Item_ID=0,childCnt=0;
	int count_child = 0;
	int   attribute_act_tak;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char *Item_id = NULL;
	char *Item_rev = NULL;
	char *Item_LCS = NULL;
	char *Item_Lcs_str = NULL;
	tag_t * pTagAttch;
	int i = 0;
	int j = 0;
	int n = 0;
	int stampingdone=0;
	int iGChld = 0;
	char*	itemid;
	char*	childPartNo;
	char*	revid;
	char *viewtype_name=NULL;
	//char  type_name[TCTYPE_name_size_c+1];
char  *type_name=NULL;
	//char  type_itemRev[TCTYPE_name_size_c+1];
	char  *type_itemRev=NULL;
	char  ChildRevtype_name[TCTYPE_name_size_c+1];
	tag_t	window								= NULLTAG;
	tag_t	window1								= NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t	top_line							= NULLTAG;
	tag_t	Childtop_line							= NULLTAG;
	tag_t	view_type							= NULLTAG;
	tag_t	item_rev_tag							= NULLTAG;
	tag_t	itemTypeTag_cdss							= NULLTAG;
	tag_t	*itemclassp	= NULLTAG;
	tag_t	itemcldclass							= NULLTAG;
	tag_t	value_child_details							= NULLTAG;
	//char  req_id[ITEM_id_size_c+1];
	tag_t  *children;
	tag_t  *totalchildren;
	tag_t  	value_act_Tak;
	tag_t  	item_rev_cld_tag;
	tag_t*			PartTags			= NULLTAG;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				ii				= 0;
	char*			value					=NULL;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	char*			Part_no				= NULL;
	int       st_count=0;
	int       iLCS=0;
	int       cntLcs=0;
	int				BypassNACSFlag=0;
	int				BypassAMDMLFlag=0;
	int RetCVMFlg=0;
	char    *RetCVMVal=NULL;
	char    *RetCVMAttr= NULL;
	//int childPartNotExist=0;
	char PlantCS[40];
	char PlantOptCS[40];
	char PlantIA[40];
	char PlantStore[40];
	char UserAgency[40];
	char STDDmlPlnt[40];
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char       *roleName=NULL  ;
	char *CurVewMaskAttrCpy=NULL;
	char *CurVewMaskValCpy=NULL;
 int  cnt = 0;
int  cntFlag = 0;
char	**SetGMErr = NULL;
int icount1=0;

	char RevisionRule[40];
	char ClosureRule[40];
	char BVR[40];
	char APLDmlPlnt[40];
	char *task_po_check=NULL;

	CurVewMaskAttrCpy =(char *) MEM_alloc(20 * sizeof(char *));
	CurVewMaskValCpy =(char *) MEM_alloc(20 * sizeof(char *));
SetGMErr = (char**)MEM_alloc( 1 * sizeof *SetGMErr );

	printf("\n Calling APLBomCarryForwardDuringERCRevise %d.....\n",iNumAttch);

    tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	int cntrlcnt=0;
	int  control_number_found1=0;
	int  FlagGotFrmToplt=0;
int ifail = 0;
    char *FrmPltToPlt 	   = NULL;
char *curvewMask=NULL;
childPartNotExist=0;
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStructCpyInErcBom";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object APLStructCpyInErcBom Found \n");fflush(stdout);
				
		
				
			}
			else
			{
				printf("\n Control Object APLStructCpyInErcBom Not Found \n");fflush(stdout);
				return ifail; //this will stop the process.
			}
			
			

	ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	//ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	ITKCALL(SA_ask_role_name2(CurrentRoleTag,&roleName))
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


	tag_t objTypeTag = NULLTAG;
		tag_t objChildRevTag = NULLTAG;

		const char *qry_entries[1];
		const char *qry_values[1];
 int FlagGotPart=0;
		int n_tags_found=0;
		int			attribute_flag					=0;
		 tag_t	*itemclass							= NULLTAG;

		  tag_t item = NULLTAG;

		  int LPCpart1 = 0;
		 tag_t  *LatestPchildPart1=NULLTAG;
		 tag_t	DsgnRevTag1			=	NULLTAG;
		 //tag_t	rule		=	NULLTAG;
		 tag_t	PartRevTag1		=	NULLTAG;
		 tag_t	top_line1			=	NULLTAG;
		  
		  char *ChildOfLatestPart=NULL;
		char *ChildRevOfLatestPart=NULL;
		char *LatParentPrtsChldCurVewmask=NULL;
		char *ParentPartNo=NULL;
		char *ParentPartRev=NULL;
		tag_t   ChildItemRevToBeCpy=NULLTAG;  
		
		char*		PrevRevChilditemid	=	NULL;
		char*		PrevRev_Chldrevid	=	NULL;
		
		int Flag = 0;
//					int ii=0;
					int zz=1;
		ITKCALL(AOM_ask_value_string(DesignRevTag, "item_id",&itemid));
		printf("\n itemid %s.....\n",itemid);
		qry_entries[0] ="item_id";
		qry_values[0] = itemid;

		
		ITKCALL( TCTYPE_ask_object_type (DesignRevTag, &objTypeTag));
		//ITKCALL( TCTYPE_ask_name( objTypeTag, type_name) );
		ITKCALL( TCTYPE_ask_name2( objTypeTag, &type_name) );
		printf("\t  type_name ...%s\n", type_name);


ITKCALL (TCTYPE_ask_object_type(DesignRevTag,&itemTypeTag_cdss));
			//ITKCALL (TCTYPE_ask_name(itemTypeTag_cdss,type_itemRev));
			ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
			printf("\t  type_itemRev ...%s\n", type_itemRev);

	char *cur_rev=NULL;
				  
				  AOM_UIF_ask_value(DesignRevTag,"item_revision_id",&cur_rev);
				  printf("\n\n\t  Part String is cur_rev--->%s",cur_rev);

				  // finding child parts
				  	char	*cGroupname				=	NULL;
			      tm_GetGroupFromNonErcDML(itemid, &cGroupname);
			      printf("\ngroup Name :%s",cGroupname);fflush(stdout);

				 char	RevRuleInfo1[40];
				 char	BVRInfo2[40];
				 char	currviewmask[40];
				 get_CtrlVal_NonErccsInf(cGroupname,RevRuleInfo1,BVRInfo2,currviewmask);
				   printf("\n\n\t  RevRuleInfo1[%s] BVRInfo2[%s] currviewmask--->%s",RevRuleInfo1,BVRInfo2,currviewmask);
					//tag_t  	item=NULLTAG;
				// if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
				 ITKCALL(ITEM_ask_item_of_rev(DesignRevTag,&item));
				//int attribute_flag1=0;
				//int attribute_flag3=0;
				//ITKCALL(BOM_line_look_up_attribute(currviewmask, &attribute_flag1));

				 int LPCpart = 0;
				 tag_t  *LatestPchildPart=NULLTAG;
			  	 tag_t	DsgnRevTag			=	NULLTAG;
				 char *ToBeCurrVewMask=NULL;
				 //tag_t	rule		=	NULLTAG;
				 tag_t	PartRevTag		=	NULLTAG;
			 	 //tag_t	top_line			=	NULLTAG;
				FlagGotPart=0;
				 ITKCALL(BOM_create_window (&window));//PrintErrorStack();
				 ITKCALL(CFM_find( RevRuleInfo1, &rule ));//PrintErrorStack();
				 ITKCALL(BOM_set_window_config_rule( window, rule ));//PrintErrorStack();
				 //if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
				// if(BOM_set_window_top_line (window, NULLTAG, item, NULLTAG, &top_line)!=ITK_ok);//PrintErrorStack();
				 ITKCALL(BOM_set_window_top_line (window, item, DesignRevTag, NULLTAG, &top_line));//PrintErrorStack();
				printf("\n inside bom_window-----555\n"); fflush(stdout);
				 ITKCALL(BOM_line_ask_child_lines (top_line, &LPCpart, &LatestPchildPart));
				 printf("\n\n\t\t No of child objects are n 555 : %d\n",LPCpart);fflush(stdout);

				if(LPCpart>0)
				{
				  //finding successors revisions
					//ITKCALL(ITEM_ask_item_of_rev(item, &PartRevTag));

					int count1=0;
					//char  	rev_id1[ITEM_id_size_c+1];
					//char  	rev_id1[ITEM_id_size_c+1];
					char  	*rev_id1=NULL;
					tag_t *  rev_list;
				  	ITEM_list_all_revs  (item, &count1,  &rev_list );
					printf("\n\n\t\t WSOM count1:- %d\n\n",count1);
					
					Flag = 0;
					for (ii = 0; ii < count1; ii++)
					{
						ITEM_ask_rev_id2( rev_list[ii], &rev_id1);
						printf("\n\n\t  Part String is rev_id1--->%s Parent Revision[%s]",rev_id1,cur_rev);
						if(tc_strstr(rev_id1,cur_rev)==NULL) //skip the latest revision expansion
						{
							if(Flag !=1)
							{
							 //successor revisions//
							 //explode successor revisions and check for view mask.
			 				 DsgnRevTag                  =    NULLTAG; //successor itemrev tag
        			         DsgnRevTag	=	rev_list[ii];
							//childPartNotExist=0;
							
									 
									  ITKCALL(AOM_ask_value_string(rev_list[ii],"item_id",&ParentPartNo))
									 printf("\n processing ParentPartNo:%s ..............",ParentPartNo);fflush(stdout);
									  ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&ParentPartRev))
									 printf("\n processing ParentPartRev:%s ..............",ParentPartRev);fflush(stdout);
									 
									 ITKCALL(BOM_create_window (&window1));//PrintErrorStack();
									 ITKCALL(CFM_find( RevRuleInfo1, &rule ));//PrintErrorStack();
									 ITKCALL(BOM_set_window_config_rule( window1, rule ));//PrintErrorStack();
									 //if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
									// if(BOM_set_window_top_line (window, NULLTAG, item, NULLTAG, &top_line)!=ITK_ok);//PrintErrorStack();
									 ITKCALL(BOM_set_window_top_line (window1, item, rev_list[ii], NULLTAG, &top_line1));//PrintErrorStack();
									printf("\n inside bom_window-----666\n"); fflush(stdout);
									 ITKCALL(BOM_line_ask_child_lines (top_line1, &LPCpart1, &LatestPchildPart1));
									 printf("\n\n\t\t No of child objects are n 666 : %d\n",LPCpart1);fflush(stdout);
									
									 int zzz=0;
									 
							if(LPCpart1<=0)
							{
								childPartNotExist++;
								continue;
							}								
				for(zzz=0;zzz<LPCpart1;zzz++)
				{
							 int iChildItemTag1=0;
							 tag_t   t_ChildItemRev1;
							 

							 BOM_line_unpack (LatestPchildPart1[zzz]);
							 //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag1);
							 //BOM_line_ask_attribute_tag(LatestPchildPart1[zzz], iChildItemTag1, &t_ChildItemRev1);
							ITKCALL(AOM_ask_value_tag(LatestPchildPart1[zzz], "bl_revision", &t_ChildItemRev1));
					if(t_ChildItemRev1!=NULLTAG)
					{
											tag_t Bomline_tag1 = NULLTAG;

											Bomline_tag1=NULLTAG;
											
											 Bomline_tag1 = LatestPchildPart1[zzz];
								
								
											
						if(Bomline_tag1!=NULLTAG)
						{
										RetCVMAttr=NULL;
										RetCVMVal=NULL;
										//before func GetRestructCurrVewMaskVal call
											printf("\n before func GetRestructCurrVewMaskVal call with RetCVMFlg[%d] and RetCVMVal[%s]",RetCVMFlg,RetCVMVal);fflush(stdout);
											ITKCALL(GetRestructCurrVewMaskVal( Bomline_tag1,&RetCVMFlg,&RetCVMAttr ,&RetCVMVal));
											
											printf("\n After func GetRestructCurrVewMaskVal call with RetCVMFlg[%d] and RetCVMVal[%s] RetCVMAttr[%s]",RetCVMFlg,RetCVMVal,RetCVMAttr);fflush(stdout);
								//return ifail; //this need to be remove after test
										
										
										char*		value_flag	=	NULL;

									//	ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskC", &attribute_flag));
										//ITKCALL(BOM_line_look_up_attribute(currviewmask, &attribute_flag));
									//	printf("\n 2attribute_flag:%d ..............",attribute_flag);fflush(stdout);

										

										ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_id",&PrevRevChilditemid))
										printf("\n 2Arc Node child PrevRevChilditemid:%s ..............",PrevRevChilditemid);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev1,"item_revision_id",&PrevRev_Chldrevid))
										printf("\n 2PrevRev_Chldrevid:%s ..............",PrevRev_Chldrevid);fflush(stdout);
									
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag1, attribute_flag, &value_flag));
										

									curvewMask=RetCVMVal;	
									
									if(tc_strlen(RetCVMVal)>0)
									{
										tc_strcpy(CurVewMaskValCpy,RetCVMVal);
										
									}
									
									if(tc_strlen(RetCVMAttr)>0)
									{
										tc_strcpy(CurVewMaskAttrCpy,RetCVMAttr);
										
									}
										
										printf("\n  2value_flag:%s ..............currentViewMaskSize[%d] curvewMask=%s CurVewMaskAttrCpy[%s] CurVewMaskValCpy[%s]",RetCVMVal,tc_strlen(RetCVMVal),curvewMask,CurVewMaskAttrCpy,CurVewMaskValCpy);fflush(stdout);
								//Latest Part's BOM
								
								 //int zz=1;
						   for(zz=0;zz<=LPCpart;zz++)
							{
							 int iChildItemTag=0;
								 tag_t   t_ChildItemRev;
								printf("\n  zz:%d LPCpart=%d",zz,LPCpart); fflush(stdout);
								 BOM_line_unpack (LatestPchildPart[zz]);
								 //BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
								 //BOM_line_ask_attribute_tag(LatestPchildPart[zz], iChildItemTag, &t_ChildItemRev);
								 ITKCALL(AOM_ask_value_tag(LatestPchildPart[zz], "bl_revision", &t_ChildItemRev));
								printf("\n latest part's child size:%d ..............",iChildItemTag);fflush(stdout);	
								if(t_ChildItemRev!=NULLTAG)
								{
									tag_t Bomline_tag = NULLTAG;

									Bomline_tag=LatestPchildPart[zz];
									
									RetCVMFlg=0;	
									RetCVMAttr=NULL;
									LatParentPrtsChldCurVewmask=  NULL;
									ChildOfLatestPart=NULL;
									
									//before func GetRestructCurrVewMaskVal call
											printf("\n before func GetRestructCurrVewMaskVal call with RetCVMFlg[%d] and RetCVMVal[%s]",RetCVMFlg,RetCVMVal);fflush(stdout);
											ITKCALL(GetRestructCurrVewMaskVal( Bomline_tag,&RetCVMFlg,&RetCVMAttr ,&LatParentPrtsChldCurVewmask));
											
											printf("\n After func GetRestructCurrVewMaskVal call with RetCVMFlg[%d] and RetCVMVal[%s] RetCVMAttr[%s]",RetCVMFlg,RetCVMVal,RetCVMAttr);fflush(stdout);
									
									if(tc_strlen(LatParentPrtsChldCurVewmask)>0)
									{
										tc_strcpy(CurVewMaskValCpy,LatParentPrtsChldCurVewmask);
										
									}
									
									if(tc_strlen(RetCVMAttr)>0)
									{
										tc_strcpy(CurVewMaskAttrCpy,RetCVMAttr);
										
									}
									
									 printf("\n inside latest part's child iteration ChildOfLatestPart:%s CurVewMaskAttrCpy[%s] CurVewMaskValCpy[%s]..............",ChildOfLatestPart,CurVewMaskAttrCpy,CurVewMaskValCpy);fflush(stdout);
									
									 ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&ChildOfLatestPart))
									 printf("\n ChildOfLatestPart:%s ..............",ChildOfLatestPart);fflush(stdout);
									  ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&ChildRevOfLatestPart))
									 printf("\n ChildRevOfLatestPart:%s ..............",ChildRevOfLatestPart);fflush(stdout);
									// ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskC", &attribute_flag));
									// ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &LatParentPrtsChldCurVewmask));
									 printf("\n  LatParentPrtsChldCurVewmask:%s ..............",LatParentPrtsChldCurVewmask);fflush(stdout);
									 
									 if ((tc_strlen(LatParentPrtsChldCurVewmask)>0) && ((tc_strstr(LatParentPrtsChldCurVewmask,"1")!=NULL) || (tc_strstr(LatParentPrtsChldCurVewmask,"2")!=NULL)) )
										{
											printf("\n latest revision's child part does have APL/STDSI View Mask so No BOM Propagation required"); fflush(stdout);
											FlagGotPart++;
											//continue;
										}



									
									if(tc_strstr(PrevRevChilditemid,ChildOfLatestPart)!=NULL)
									{	
											printf("\n same child part exist with PrevRevChilditemid[%s] and ChildOfLatestPart[%s]",PrevRevChilditemid,ChildOfLatestPart); fflush(stdout);
										if (tc_strlen(value_flag)<=0)
										{
											printf("\n No BOM Propagation required"); fflush(stdout);
											FlagGotPart++;
											continue;
										}
										
										if((tc_strstr(value_flag,"0")!=NULL) || (tc_strstr(value_flag,"12")!=NULL))
										{
											//ChildOfLatestPart
											if((tc_strstr(LatParentPrtsChldCurVewmask,"0")!=NULL) || (tc_strstr(LatParentPrtsChldCurVewmask,"12")!=NULL))
											{
												
												printf("\n same child part exist in previous rev part:%s with same current view mask [%s]..............",PrevRevChilditemid,LatParentPrtsChldCurVewmask);fflush(stdout);
												FlagGotPart++;
												continue;
											}
											else
											{
											//UPDATEVIEWMASK:
											printf("\n same child part exist in previous rev part:%s with diffrent current view mask [%s]..............",PrevRevChilditemid,LatParentPrtsChldCurVewmask);fflush(stdout);
											ChildItemRevToBeCpy=t_ChildItemRev1;
											FlagGotPart++;
											
											}
										}
										
									}
									else
									{
										printf("\n child part not exist with PrevRevChilditemid[%s] and ChildOfLatestPart[%s]",PrevRevChilditemid,ChildOfLatestPart); fflush(stdout);
										printf("\n LPCpart[%d] and zz[%d] childPartNotExist=%d zzz=%d",LPCpart,zz,childPartNotExist,zzz); fflush(stdout);
										childPartNotExist++;
										if((LPCpart-1)==zz && (FlagGotPart<LPCpart1))
										{
											printf("\n inside condition LPCpart[%d] == zz[%d] childPartNotExist=%d",LPCpart,zz,childPartNotExist); fflush(stdout);
											ChildItemRevToBeCpy=NULLTAG;
											childPartNotExist=0;
											FlagGotPart=0;
											ChildItemRevToBeCpy=t_ChildItemRev1;
										}
																				
										continue;
									}
									
									printf("\n FlagGotPart[%d] and zz[%d] childPartNotExist=%d",FlagGotPart,zz,childPartNotExist); fflush(stdout);
										  
										
								}


											
							}
							
							
						}
						
						//Need to add here
							
							 printf("\n  FlagGotPart:%d  childPartNotExist:%d LPCpart1=%d zzz=%d",FlagGotPart,childPartNotExist,LPCpart1,zzz);fflush(stdout);
										  if(FlagGotPart==0 && childPartNotExist==0 && LPCpart1!=zzz)
											{
											   	//to check whether APLC bvr exists or not 15197
												//if not create ps_create_bvr : to create bvr 
												//then add apl part: PS_create_occurrences

											   int aplcViewFound=0;
											   int     bvr_count_bsRev					=	0;
											   tag_t	*bvrs_BSRev						=	NULLTAG;
											   	tag_t	bvr_BSRev1						=	NULLTAG;
												char *ParentPart=NULL;
												char *ParentPartRev =NULL;
											   //ITKCALL(ITEM_rev_list_bom_view_revs( AssyTag, &bvr_count_bsRev, &bvrs_BSRev));
											   //ITKCALL(ITEM_rev_list_bom_view_revs( DsgnRevTag, &bvr_count_bsRev, &bvrs_BSRev));
											   //ITKCALL(AOM_ask_value_string(DsgnRevTag,"item_id",&ParentPart));
											   ITKCALL(ITEM_rev_list_bom_view_revs( DesignRevTag, &bvr_count_bsRev, &bvrs_BSRev));
											   ITKCALL(AOM_ask_value_string(DesignRevTag,"item_id",&ParentPart));
											   
													printf("\n ParentPart %s",ParentPart);fflush(stdout);
													 ITKCALL(AOM_ask_value_string(DesignRevTag,"item_revision_id",&ParentPartRev));
													printf("\n ParentPartRev %s",ParentPartRev);fflush(stdout);
											   printf("\n bvr_count_bsRev %d ",bvr_count_bsRev);fflush(stdout);
											   aplcViewFound=0;
											   int assbvr=0;
												for(assbvr=0;assbvr<bvr_count_bsRev;assbvr++)
												{	
													char	*view_name						=	NULL;
													tag_t	itemTypeTag_cdss				=	NULLTAG;
													char	*type_itemRev					=	NULL;
													tag_t	bvr_BSRev1						=	NULLTAG;

													ITKCALL(AOM_ask_value_string(bvrs_BSRev[assbvr],"object_name",&view_name));
													printf("\n view_name %s",view_name);fflush(stdout);
													ITKCALL (TCTYPE_ask_object_type(bvrs_BSRev[assbvr],&itemTypeTag_cdss));
													ITKCALL (TCTYPE_ask_name2(itemTypeTag_cdss,&type_itemRev));
													printf("\n22222Grp 98 type_itemRev : %s",type_itemRev);fflush(stdout);
													if(tc_strstr(view_name,BVRInfo2)!=NULL)
													{
														printf("\nInside view found");fflush(stdout);
														aplcViewFound++;
														bvr_BSRev1	=	bvrs_BSRev[assbvr];
														break;
													}
												}
												if (aplcViewFound==0 && bvr_count_bsRev ==1)
												{
													printf("\n2222Inside view not found");fflush(stdout);
													aplcViewFound++;
													bvr_BSRev1	=	bvrs_BSRev[0];
												}
												tag_t	childItemTag		=	NULLTAG;
												char *childitemid =NULL;
												char *childitemrev=NULL;
												if(ChildItemRevToBeCpy)
												{
													ITKCALL(ITEM_ask_item_of_rev(ChildItemRevToBeCpy, &childItemTag));
													printf("\n childItemTag:%u ..............",childItemTag);fflush(stdout);

													ITKCALL(AOM_ask_value_string(ChildItemRevToBeCpy,"item_id",&childitemid));
													printf("\n childitemid %s",childitemid);fflush(stdout);
													ITKCALL(AOM_ask_value_string(ChildItemRevToBeCpy,"item_revision_id",&childitemrev));
													printf("\n childitemrev %s",childitemrev);fflush(stdout);
												}
												printf("\naplcViewFound=%d",aplcViewFound);fflush(stdout);
												
													if(aplcViewFound==0)
													{
														tag_t	*bvrs_BS						=	NULLTAG;
														int bvr_count_bs=0;
														tag_t	bom_view_bs						=	NULLTAG;
														tag_t	*occurrences				=	NULLTAG;
														tag_t	Item_ds		=	NULLTAG;

														 ITKCALL(ITEM_ask_item_of_rev(DsgnRevTag, &Item_ds));

														printf("\naplcViewFound is 0");fflush(stdout);
														ITKCALL(ITEM_list_bom_views( Item_ds, &bvr_count_bs, &bvrs_BS));
														printf("\n bvr_count_bs %d ",bvr_count_bs);fflush(stdout);

														if (bvr_count_bs<=0)
														{
															char	*getPlantViewName				=	NULL;
															tag_t	view_type_tag				=	NULLTAG;


															getPlantViewName=NULL;
															//tm_GetViewFromDML(Item_ds, &getPlantViewName);
															//printf("\nGrp98 getPlantViewName : %s",getPlantViewName);fflush(stdout);
															ITKCALL(PS_find_view_type("view",&view_type_tag ));

															AOM_lock(Item_ds);
															ITKCALL(PS_create_bom_view (view_type_tag,"","",Item_ds,&bom_view_bs));
															//ITKCALL(AOM_save(bom_view_bs));
															ITKCALL(AOM_save_without_extensions(bom_view_bs));
															//ITKCALL(AOM_save(Item_ds));
															ITKCALL(AOM_save_without_extensions(Item_ds));
															ITKCALL(AOM_unlock(Item_ds));
														}
														else
														{
															bom_view_bs	=	bvrs_BS[0];
														}
														
														AOM_lock(DsgnRevTag);
														ITKCALL(PS_create_bvr (bom_view_bs,"","",false,DsgnRevTag,&bvr_BSRev1));
														//ITKCALL(AOM_save(bvr_BSRev1));
														ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
														//ITKCALL(AOM_save(DsgnRevTag));
														ITKCALL(AOM_save_without_extensions(DsgnRevTag));
														ITKCALL(AOM_unlock(DsgnRevTag));
													
														//consumableQtyD=1;
														//ITKCALL(BOM_line_set_attribute_string(bvr_BSRev1, attribute_flag1, value_flag));
														ITKCALL(PS_create_occurrences(bvr_BSRev1,childItemTag,NULLTAG,1,&occurrences));
														//ITKCALL(PS_set_occurrence_qty(bvr_BSRev1, occurrences[0], consumableQtyD ));
														//ITKCALL(AOM_save(bvr_BSRev1));
														ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
														ITKCALL(AOM_unlock(bvr_BSRev1));
														//goto UPDATEVIEWMASK;

													}
													else
													{
														//consumableQtyD	=	1;
														tag_t	*occurrences					=	NULLTAG;
														//AOM_lock(DsgnRevTag);
														//printf("\n hi dss attribute_flag1:%d ..............",attribute_flag1);fflush(stdout);
														printf("\n curvewMask:%s ..............",curvewMask);fflush(stdout);
														
														
														
														
														
														if (bvr_BSRev1!=NULLTAG)
														{
														printf("\n inside PS_create_occurrences condition with ToBeCurrVewMask[%s]",curvewMask);fflush(stdout);
														//ITKCALL(BOM_line_set_attribute_string(bvr_BSRev1, attribute_flag1, value_flag));
														//ITKCALL(BOM_line_set_attribute_string(bvr_BSRev1, "bl_occ_t5_CurrentViewMaskC", value_flag));
															if(tc_strlen(curvewMask)>0)
															{	
																ITKCALL(PS_create_occurrences(bvr_BSRev1,childItemTag,NULLTAG,1,&occurrences));
																//ToBeCurrVewMask
																//ITKCALL(BOM_line_set_attribute_string(Bomline_tag2, attribute_flag3, curvewMask));//Changes the value from "1" to "-1"
																//ITKCALL(PS_set_occurrence_qty(bvr_BSRev1, occurrences[0], consumableQtyD ));
																//ITKCALL(AOM_save(bvr_BSRev1));
																ITKCALL(AOM_save_without_extensions(bvr_BSRev1));
																//goto UPDATEVIEWMASK;
																FlagGotPart++;
															}
														}
														else
														{
														printf("\n bvr_BSRev1 tag null ..");fflush(stdout);
														}

													}

												
														//Setbomline for parent part
														int iChildItemTag3=0;
														tag_t   t_ChildItemRev3;
														int x=0;
														
														 int LPCpart2 = 0;
														 tag_t  *LatestPchildPart2=NULLTAG;
														 tag_t	window2			=	NULLTAG;
														 tag_t	rule2		=	NULLTAG;
														 tag_t	top_line2			=	NULLTAG;

									
														 if(BOM_create_window (&window2)!=ITK_ok);//PrintErrorStack();
														 if(CFM_find( RevRuleInfo1, &rule2 )!=ITK_ok);//PrintErrorStack();
														 if(BOM_set_window_config_rule( window2, rule2 )!=ITK_ok);//PrintErrorStack();
														 //if(BOM_set_window_pack_all (window2, false)!=ITK_ok)PrintErrorStack();
														 if(BOM_set_window_top_line (window2, NULLTAG, DesignRevTag, NULLTAG, &top_line2)!=ITK_ok);//PrintErrorStack();
														 printf("\n inside bom_window-----555\n"); fflush(stdout);
														 if(BOM_line_ask_child_lines (top_line2, &LPCpart2, &LatestPchildPart2));
														 printf("\n\n\t\t No of child objects are n LPCpart2 : %d\n",LPCpart2);fflush(stdout);
														for(x=0;x<LPCpart2;x++)
														{
															BOM_line_unpack (LatestPchildPart2[x]);
															//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag3);
															//BOM_line_ask_attribute_tag(LatestPchildPart2[x], iChildItemTag3, &t_ChildItemRev3);
															
															ITKCALL(AOM_ask_value_tag(LatestPchildPart2[x], "bl_revision", &t_ChildItemRev3));
															//ITKCALL(BOM_line_ask_child_lines (top_line2, &n, &children));
															printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);
															//tag_t Bomline_tag2 = NULLTAG;
															
															//Bomline_tag2 = LatestPchildPart2[x];
															
															char *cItemName=NULL;
															if(t_ChildItemRev3!=NULLTAG)
															{
																ITKCALL(AOM_ask_value_string(t_ChildItemRev3,"item_id",&cItemName));
																printf("\n\n\t\t Part Compare : %s: tobecopiedChild=%s\n",cItemName,childitemid);fflush(stdout);
																if(tc_strcmp(cItemName,childitemid)==0)
																{
																	printf("\nGoing to stamp current view mask for RetCVMAttr[%s] CurVewMaskValCpy[%s]...!!!",CurVewMaskAttrCpy,CurVewMaskValCpy);fflush(stdout);
																	if(tc_strlen(CurVewMaskValCpy)>0)
																	{
																	ITKCALL(AOM_lock(t_ChildItemRev3));
																	//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskC", &attribute_flag3));										
																	//ITKCALL(BOM_line_look_up_attribute(CurVewMaskAttrCpy, &attribute_flag3));
																	//ITKCALL(BOM_line_set_attribute_string(LatestPchildPart2[x], attribute_flag3, CurVewMaskValCpy));//Changes the value from "1" to "-1"
																	//ITKCALL(AOM_save(t_ChildItemRev3));
																	
																	ITKCALL(AOM_UIF_set_value(LatestPchildPart2[x], "bl_occ_t5_CurrentViewMaskC", CurVewMaskValCpy));//Changes the value from "1" to "-1"
																	ITKCALL(AOM_save_without_extensions(t_ChildItemRev3));
																	ITKCALL(AOM_unlock(t_ChildItemRev3 ));
																	printf("\n Updated CAR Viewmask with [%s]",CurVewMaskValCpy);fflush(stdout);
																	//break;																
																	}
																}
															}
														}
														//end bomline set 														

										  }
										  else
										  {
											printf("\nChild part [%s] already exist in BOM with current view mask [%s]!!!",PrevRevChilditemid,curvewMask);fflush(stdout);  
											//continue;
										  }
									
					}
					
					
									

					
				} // end of all revision's child part for loop under product pln

											
			}
				
					}	

						  if (strcmp(rev_id1,cur_rev)==0)
						  {
	  						printf("\n \t  Both revisions match");
							Flag = 1;
						  }
						 
					  }

				}
			    else
			    {
					printf("\n No child found under latest Design Revision......\n");fflush(stdout);
			    }


// BYPASSVALIDATIONS:
//	decision = EPM_go;
	return ifail;
}



//End function APLBomCarryForwardDuringERCRevise 

//Start Action Handler

/*
	Action Handler		:		AH_CopyAplRestrPrtToErcBom
	Description			:		This handler checks the APL restrcuture Part in ERC revised Part, if cahnges there then copy APL restructured in latest revision if not found
*/

int AH_CopyAplRestrPrtToErcBom(EPM_rule_message_t msg)
{
	int i=0;
	int status=ITK_ok;
	//int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int cnt=0;
	int k=0;
	char *obj_type=NULL;
char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *usrInfo3=NULL;
	char *usrInfo4=NULL;
	char *usrInfo5=NULL;
	char *usrInfo6=NULL;
	char *usrInfo7=NULL;
	char *usrInfo8=NULL;
	char *usrInfo9=NULL;
	char *usrInfo10=NULL;
	tag_t  rootTask_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  	objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		char   *TempVal			=NULL;
		tag_t close_tag;
	char *objectname=NULL;
	tag_t*   ClsObjTag= NULLTAG;
	tag_t *RetContrlObjs=NULLTAG;
	tag_t 		ccvMstrTag=NULLTAG;
	int x =0;
	int p =0;
	logical	delInd	= false;
	char *info1=NULL;
	char *info2=NULL;
	char *info3=NULL;
	char *info4=NULL;
	char *info5=NULL;
	char *info6=NULL;
	char *info7=NULL;
	char *info8=NULL;
	char *info9=NULL;
	char *info10=NULL;
	
	tag_t *Dml_tasks= NULLTAG;
	int cnt1 =0;
	char *object_type=NULL;
	//char *VCAttrNo=NULL;
	char *VCattrList[50000];
	char *TobeUpdAttrId=NULL;
	char *TobeUpdAttrVal=NULL;
	char *VCAttrNo=NULL;
	char *getAttridval=NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char	*Proj_BU		= NULL;
	char 	*Proj_DesgOwnUnit	= NULL;
	char	*Proj_ProtoUnit		= NULL;
	char	*Proj_VCSubClass		= NULL;
	//tag_t rev;
	tag_t	Project_t		= NULLTAG;
	//int k;
	//int i;
	int rule_count;
	int count=0;
	int retcount=0;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *parttype;
	char 	*ProjectID		= NULL;
	char *group_name	= NULL;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
	tag_t * 	secondary_objects ;
	tag_t			GroupMem								= NULLTAG;
	tag_t queryTag = NULLTAG;
	char
        *user_name_string;
		char *SesLoc;
		char *ccvRevId =NULL;
		char *CCVDesc =NULL;
		char *CCVDescDup =NULL;
		int tscount;
    tag_t
        user;
		char* tsitem;
		char *DMLNo=NULL;
	tag_t relation_type_tag = NULLTAG;
	//tag_t	objTypeTag				=	NULLTAG;
	int status_count = 0;
	int structcount=0;
	//char   type_name2[TCTYPE_name_size_c+1];
	//char   type_name[TCTYPE_name_size_c+1];
	char   *type_name=NULL;
	//char   type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char NoSubSet[1900] = { 0 };
	char RevMisMatch[19000] = { 0 };
	//char *VcAttrStr=(char *) MEM_alloc(10 * sizeof(char *));
	char *VcAttrStr=MEM_alloc(2000);
	//char *VCattrList[5000];
	int p34=0;
	int p3=0;
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	//char RevMisMatch[19000];
	
	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	int cntrlcnt=0;
	int  control_number_found1=0;
	char* shellpath = NULL;
	char* sysCmnd = NULL;
	


printf("inside AH_CopyAplRestrPrtToErcBom Action Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n AH_CopyAplRestrPrtToErcBom attachmentCount = %d\n",attachmentCount);fflush(stdout);
	
	//Logic for control object check 1st
	
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStructCpyInErcBom";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object APLStructCpyInErcBom Found \n");fflush(stdout);
				
				if(attachmentCount>0)
				{
					for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
					{
						ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
						printf("\n AH_CopyAplRestrPrtToErcBom Object Type = %s\n",obj_type);fflush(stdout);
						if(tc_strstr(obj_type,"ChangeRequestRevision")!=NULL)
						{	
						ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &DMLNo));
						printf("\n DMLNo:%s\n",DMLNo);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
						
						printf("\nshellpath==>%s\n",shellpath);fflush(stdout);
							if(tc_strlen(shellpath)>0)
							{
								printf("\ninside tm_AplBomCpyToErc Execute through client code......\n");fflush(stdout);
								
								
								sysCmnd=(char *) MEM_alloc(400);
								tc_strcpy(sysCmnd,shellpath);
								tc_strcat(sysCmnd," ");
								tc_strcat(sysCmnd,DMLNo);
								printf("\n before-- Calling shell file tm_AplBomCpyInErcRevise.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								system(sysCmnd);
								
								printf("\n after --- Calling shell file tm_AplBomCpyInErcRevise.sh using client system command: %s\n",sysCmnd);fflush(stdout);
								
								MEM_free(sysCmnd);
							}
							else
							{
								printf("\ninside the normal action handler AH_CopyAplRestrPrtToErcBom call without client code......\n");fflush(stdout);
							 ITK_CALL(AOM_ask_value_tags(taskAttachments[Itemscnt],"T5_DMLTaskRelation",&cnt1,&Dml_tasks));
							printf("\n Now cnt1:%d\n",cnt1);fflush(stdout);
							if (cnt1>0)
								{
									for (k=0;k<cnt1 ;k++ )
									{
										   AOM_ask_value_string(Dml_tasks[k],"object_type",&object_type);
										   printf("\n object_type is :%s\n",object_type);fflush(stdout);
											
										if(tc_strcasecmp(object_type,"T5_ChangeTaskRevision")==0)
										{

										 printf("\n inside T5_ChangeTaskRevision logic \n");fflush(stdout);
										
										
										//platform_rev=tags_found[0];
										char *id;
										char *Solid;
										char *TaskAnlyst =NULL;
										char *TaskAnlystDup =NULL;
										ERROR_CHECK(AOM_ask_value_string(Dml_tasks[k],"item_id" , &id));
										//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
										printf("\n Task_id= %s",id);fflush(stdout);

										ERROR_CHECK(AOM_ask_value_string(Dml_tasks[k],"analyst_user_id",&TaskAnlyst));
										printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);
										
										if(TaskAnlyst)
												{
													 tc_strdup(TaskAnlyst,&TaskAnlystDup);	
													
												}
										printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
										//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
										ERROR_CHECK(GRM_list_secondary_objects_only(Dml_tasks[k],DmlItemsRelation_t,&count,&secondary_objects ));
										//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
										printf( "reference item attachment count:%d\n", count);fflush(stdout);
										if(count>0)
										{
											for(i=0;i<count;i++)
											{
												printf( "loop i=%d\n", i);fflush(stdout);
												char *VCClass;
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_id" , &Solid));
												printf("\n Solution Item= %s",Solid);fflush(stdout);
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
												ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));
												
												
												if(CCVDesc)
												{
													tc_strdup(CCVDesc,&CCVDescDup);
												}
												
												if(TCTYPE_ask_object_type(secondary_objects[i],&objTypeTag));
											if(TCTYPE_ask_name2(objTypeTag,&type_name));
											printf("\n Task Type : %s",type_name);fflush(stdout);
												printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
												//return;
												if(tc_strstr(ccvRevId,"NR")==NULL) //skip NR Revision parts
												{
													if(strcmp(type_name,"Design Revision")==0)
													{
														printf("\n Design Revision Found .......\n");fflush(stdout);
														printf("\n b4 call func APLBomCarryForwardDuringERCRevise\n");fflush(stdout);
														APLBomCarryForwardDuringERCRevise(secondary_objects[i]);
														printf("\n After call func APLBomCarryForwardDuringERCRevise\n");fflush(stdout);
													}
												}
											}
										}
										else
										{
											printf("\n No Design Revision attached to Solution Item for Task[%s]\n",id);fflush(stdout);
											return ifail;
										}
										
										}
										
									}
								}
							}
						}
					}
				}
				
			}
			else
			{
				printf("\n Control Object APLStructCpyInErcBom Not Found , so process will stop here\n");fflush(stdout);
				return ifail; //this will stop the process.
			}
	
	//End Control object logic
	

printf("\n End APLBomCarryForwardDuringERCRevise AH  with ifail[%d] ",ifail);fflush(stdout);	
	return ifail;
}


//End Action Handler







int TechSpec_register_action_handlers() //this is used to register action handler
{
	TC_write_syslog("before Action Handler CM_Check_CCVForTechSpec registered..\n");
	ERROR_CHECK(EPM_register_action_handler("CM_Check_CCVForTechSpec","Action Handler to create Tech Spec in SVR WF",( EPM_action_handler_t) CM_Check_CCVForTechSpec));
	
	TC_write_syslog("Registered Action Handler CM_Check_CCVForTechSpec..\n");
	
	
	TC_write_syslog("before Action Handler AH_MdmUpdate_ForTechSpec registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_MdmUpdate_ForTechSpec","Action Handler to Update MDM VC ATTR by MDM WF",( EPM_action_handler_t) AH_MdmUpdate_ForTechSpec));
	
	TC_write_syslog("Registered Action Handler AH_MdmUpdate_ForTechSpec..\n");
	
	
	//AH_MdmWrdFileUpd4TechSpec
	
	TC_write_syslog("before Action Handler AH_MdmWrdFileUpd4TechSpec registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_MdmWrdFileUpd4TechSpec","Action Handler to Update MDM VC ATTR by MDM WF",( EPM_action_handler_t) AH_MdmWrdFileUpd4TechSpec));
	TC_write_syslog("Registered Action Handler AH_MdmWrdFileUpd4TechSpec..\n");
	
	TC_write_syslog("before Action Handler AH_Get_MDMVCList registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_Get_MDMVCList","Action Handler to attach affected V/CCV to Task for MDM's Module VC ATTR Update by MDM WF",( EPM_action_handler_t) AH_Get_MDMVCList));
	
	TC_write_syslog("Registered Action Handler AH_Get_MDMVCList..\n");
	
	
	TC_write_syslog("before Action Handler AH_deleteMDMControlObj registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_deleteMDMControlObj","Action Handler to delete the control object for MDM VC ATTR by MDM WF",( EPM_action_handler_t) AH_deleteMDMControlObj));
	
	TC_write_syslog("Registered Action Handler AH_deleteMDMControlObj..\n");
	
	
	TC_write_syslog("before Action Handler AH_ModuleClsValUpd registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_ModuleClsValUpd","Action Handler to update the classification value for control object ICOMODUPD by WF",( EPM_action_handler_t) AH_ModuleClsValUpd));
	
	TC_write_syslog("Registered Action Handler AH_ModuleClsValUpd..\n");
	
	
	TC_write_syslog("before Action Handler AH_DelModuleContrlObj registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_DelModuleContrlObj","Action Handler to delete the control object ICOMODUPD by MDM WF",( EPM_action_handler_t) AH_DelModuleContrlObj));
	
	TC_write_syslog("Registered Action Handler AH_DelModuleContrlObj..\n");
	
	//AH_CopyAplRestrPrtToErcBom
	
	TC_write_syslog("before Action Handler AH_CopyAplRestrPrtToErcBom registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_CopyAplRestrPrtToErcBom","Action Handler to copy APL BOM to ERC BOM if restructured happens in APL for revised Design Revision",( EPM_action_handler_t) AH_CopyAplRestrPrtToErcBom));
	
	TC_write_syslog("Registered Action Handler AH_CopyAplRestrPrtToErcBom..\n");
	
	TC_write_syslog("before Action Handler AH_UpdNpiCodeToClsVc registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_UpdNpiCodeToClsVc","Action Handler to update the classification value for NPI CODE via CCVC release ",( EPM_action_handler_t) AH_UpdNpiCodeToClsVc));
	
	TC_write_syslog("Registered Action Handler AH_UpdNpiCodeToClsVc..\n");
	
	TC_write_syslog("before Action Handler AH_PltfrmDataMining4VCattr registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_PltfrmDataMining4VCattr","Action Handler to update the classification value for NR VC after minning via CCVC release ",( EPM_action_handler_t) AH_PltfrmDataMining4VCattr));
	
	TC_write_syslog("Registered Action Handler AH_PltfrmDataMining4VCattr..\n");
	
	TC_write_syslog("before Action Handler AH_NRVC_Chk_4_TechSpec registered..\n");
	ERROR_CHECK(EPM_register_action_handler("AH_NRVC_Chk_4_TechSpec","Action Handler to check NR VC/CCVC check ",( EPM_action_handler_t) AH_NRVC_Chk_4_TechSpec));
	
	TC_write_syslog("Registered Action Handler AH_NRVC_Chk_4_TechSpec..\n");
	
	return ITK_ok;
}

 int tm_MissMandatoryVCAttrCountFunc(tag_t VC_tag)
{
	tag_t IcsClsTag=NULLTAG;
    //char *VC_No=NULL;
    char **AttrVal=NULL;
	tag_t objTypeTag=NULLTAG;
	int Total_count = 0;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;

	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;

	char** attributeNames	= NULL;
	char** attributeValues	= NULL;


	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;
	
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	//int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;
	int NullCount =0;
	int counter2 = 0;
    char	Timestamp1[100]	= "";
	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	int theAttributeCount =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	char *AttrCsvName = NULL;
	char *FileUp = NULL;
	const char * 	theViewId;
	//int theAttributeId=6001;
	//char * 	thePropertyValue =NULL;
	FileUp = (char *) MEM_alloc (sizeof (char) * 128);
	AttrCsvName = (char *) MEM_alloc (sizeof (char) * 128);
	char *ClsClass=NULL;
	
	int  	theCount=0;
	int * 	theIds;
	char ** 	theNames;
	char ** 	theShortNames;
	char ** 	theAnnotations;
	int * 	theArraySize;
	int * 	theFormat;
	char ** 	theUnit;
	char ** 	theMinValues;
	char ** 	theMaxValues;
	char ** 	theDefaultValues;
	char ** 	theDescriptions;
	int * 	theOptions ;
	char * 	thePropertyValue =NULL;
	int k=0;
	char *MandatoryAttrList=MEM_alloc(1000);
	
	CALLAPI(ICS_ask_classification_object(VC_tag,&IcsClsTag));
	if (IcsClsTag)
	{
		printf("\n b4 get ClsClass= %s",ClsClass);fflush(stdout);
		CALLAPI(AOM_ask_value_string(IcsClsTag,"cid",&ClsClass));
		printf("\n ClsClass= %s",ClsClass);fflush(stdout);
	//	printf("\n Before theAttributeCount");fflush(stdout);
	
	//ITK_CALL(ICS_view_ask_attr_property("HCVVCATTR01",theViewId,theAttributeId,"MANDATORY",&thePropertyValue));
	
		CALLAPI( ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
		
		//CALLAPI( ICS_ico_ask_all_attributes(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeValCounts,&theAttributeValues));
		//CALLAPI( ICS_ico_ask_attributes(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeValCounts,&theAttributeValues));
		printf("\n theAttributeCount:[%d] theAttributeValCounts[%d]",theAttributeCount,*theAttributeValCounts);fflush(stdout);
		
		
		CALLAPI(ICS_class_describe_attributes(ClsClass,&theCount,&theIds,&theAttributeNames,&theShortNames,&theAnnotations,&theArraySize,&theFormat,&theUnit,&theMinValues,&theMaxValues,&theDefaultValues,&theDescriptions,&theOptions ));
		printf("\n theCount=%d\n\n",theCount);
		tc_strcpy(MandatoryAttrList,"");
		char mandAttrId[10];
		int mandattrsize=0;
		for(k=0;k<theCount;k++)
		{
			printf("\n theIds[%d] theDescriptions[%d]=%s with theOptions value [%d] theArraySize[%d] theDefaultValues[%s]\n\n",theIds[k],k,theDescriptions[k],theOptions[k],theArraySize[k],theDefaultValues[k]);
			//theOptions value =4 means mandatory attribute ,theOptions value=0 means non-mandatory attribute,theOptions value=1 means multiple array based string attribute
			if(theOptions[k]==4)
			{
				 
				if(theIds[k]>0)
				{

					sprintf(mandAttrId, "%d", theIds[k]);
					printf("\n inside sprintf mandAttrId[%s] mandatory attr check \n",mandAttrId);fflush(stdout);
					//key_lov_id=theKeyLOVId;	
				}
									printf("\n  mandAttrId[%s]",mandAttrId); fflush(stdout);
				tc_strcat(MandatoryAttrList,",");
				tc_strcat(MandatoryAttrList,mandAttrId);
				mandattrsize++;
			}
		}
		printf("\n  mandattrsize=%d MandatoryAttrList[%s]",mandattrsize,MandatoryAttrList); fflush(stdout);
	}
	
	if(theAttributeCount>0)
	{
		NullCount=0;
		counter2=0;
			for(i=0;i<theAttributeCount;i++)
			{
				//TotVCAttrCount=TotVCAttrCount+theAttributeCount;

				sprintf(attrId,"%d",theAttributeIds[i]);
				//printf("\n attrId:[%s]",attrId);fflush(stdout);
				printf("\n  attrId[%s]",attrId); fflush(stdout);
				if(tc_strstr(MandatoryAttrList,attrId)!=NULL)
				{
					printf("\n  inside mandatory attrId[%s]",attrId); fflush(stdout);
					tc_strcpy(attributeNameDup,"");
					tc_strcpy(attributeNameDup,theAttributeNames[i]);

					//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

					
						
					tc_strcpy(attributeValueDup,"");

					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						printf("\n  inside mandatory attributeValueDup[%s]",attributeValueDup); fflush(stdout);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
						// if (tc_strlen(attributeValueDup)== 0) 
						// {
							// printf("\n attrId=%s attributeNameDup=%s attributeValueDup:[%s]",attrId,attributeNameDup,attributeValueDup);fflush(stdout);
							// NullCount++;
							// counter2++;
						// }
					}
				//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					if (tc_strlen(attributeValueDup)== 0) 
					{
						printf("\n attrId=%s attributeNameDup=%s attributeValueDup:[%s]",attrId,attributeNameDup,attributeValueDup);fflush(stdout);
						NullCount++;
						counter2++;
					}		
				
				}
			}

printf("\nTotal count %d counter2=%d\n",Total_count,counter2);
Total_count=counter2;
			 
			   printf("\nTotal Missing Attributes %d\n",Total_count);
			   if(Total_count<=0)
			   {
				    printf("\nNo Mandatory Missing Attributes found %d\n",Total_count);
			   }
			   

	}

printf("\nEnd tm_MissMandatoryVCAttrCountFunc with missing mandatory attrs Total_count[%d] \n",Total_count);

    return Total_count;
}

 
int tm_MissMandatoryVCAttrCountFunc_V2(tag_t VC_tag)
{
    /* ===================== VARIABLE DECLARATIONS ===================== */
    tag_t IcsClsTag                     = NULLTAG;
    tag_t hybridClassTag                = NULLTAG;
    tag_t *hybridAttrTags               = NULLTAG;
    tag_t *ClsObjTag                    = NULLTAG;
    tag_t *ModuleClsObjTag              = NULLTAG;
    tag_t ModuleClsObj                  = NULLTAG;
    tag_t latestrev                     = NULLTAG;
    tag_t window                        = NULLTAG;
    tag_t rule                          = NULLTAG;
    tag_t top_line                      = NULLTAG;
    tag_t VC_Tecspec_object             = NULLTAG;
    tag_t VCspecRel                     = NULLTAG;
    tag_t item_tag                      = NULLTAG;
    tag_t actualClassTag                = NULLTAG;

    tag_t *LatChildSet                  = NULLTAG;
    tag_t *VC_Tecspec_objects           = NULLTAG;

    int ifail                           = ITK_ok;
    int i                               = 0;
    int x                               = 0;
    int aa                              = 0;
    int c                               = 0;
    int n_count                         = 0;
    int Mcnt                            = 0;
    int nHybridAttrs                    = 0;
    int theAttributeCount               = 0;
    int theAttributeCount1              = 0;
    int Total_count                     = 0;
    int counter_vc                      = 0;
    int counter_module                  = 0;
    int VCTecspecCount                  = 0;
    int n_count_bom                     = 0;
    int remainingAttrCount              = 0;
    int totalNeverFound                 = 0;

    int *theAttributeIds                = NULL;
    int *theAttributeValCounts          = NULL;
    int *theAttributeIds1               = NULL;
    int *theAttributeValCounts1         = NULL;
    int *remainingAttrFoundFlag         = NULL;
	char **remainingAttrEmptyModules    = NULL;
    /* For ICS_view_describe_view */
    int    *vw_uncts                    = NULL;
    int    *vw_formats                  = NULL;
    int    *vw_nonMetricFormats         = NULL;
    char   **vw_attributeIds            = NULL;
    char   **vw_attributeNames          = NULL;
    char   **vw_shortNames              = NULL;
    char   **vw_units                   = NULL;
    char   **vw_configBefore            = NULL;
    char   **vw_configField             = NULL;
    char   **vw_configAfter             = NULL;
    int    *vw_flags                    = NULL;
    char   **vw_metricMin               = NULL;
    char   **vw_metricMax               = NULL;
    char   **vw_nonMetricMin            = NULL;
    char   **vw_nonMetricMax            = NULL;
    char   **vw_metricDefaultValue      = NULL;
    char   **vw_nonMetricDefaultValue   = NULL;

    char **theAttributeNames            = NULL;
    char ***theAttributeValues          = NULL;
    char ***theAttributeOptimizedUnits  = NULL;
    char **theAttributeNames1           = NULL;
    char ***theAttributeValues1         = NULL;
    char ***theAttributeOptimizedUnits1 = NULL;

    char *classId                       = NULL;
    char *className                     = NULL;
    char *classIdFromTag                = NULL;
    char *hybridClassName               = NULL;
    char *attrId                        = NULL;
    char *attrId1                       = NULL;
    char *hybridAttrId                  = NULL;
    char *hybridAttrName                = NULL;
    char *attributeNameDup              = NULL;
    char *attributeValueDup             = NULL;
    char *attributeNameDup1             = NULL;
    char *attributeValueDup1            = NULL;
    char *value_itemid                  = NULL;
    char *moduleAddressS                = NULL;
    char *BussUnit                      = NULL;
    char *tobeModaddress                = NULL;
    char *buPrefix                      = NULL;

    char **hybridAttrNames              = NULL;
    char **hybridAttrIds                = NULL;
    char **remainingAttrNames           = NULL;
    char **remainingAttrIds             = NULL;
    char **vcAttrNames                  = NULL;
    char **vcAttrValues                 = NULL;
    char **vcAttrIds                    = NULL;

    logical icsIcsClsExist              = false;

    /* Allocate working buffers */
    attrId                = (char *) MEM_alloc(50   * sizeof(char));
    attrId1               = (char *) MEM_alloc(50   * sizeof(char));
    hybridClassName       = (char *) MEM_alloc(200  * sizeof(char));
    buPrefix              = (char *) MEM_alloc(200  * sizeof(char));
    attributeNameDup      = (char *) MEM_alloc(5000 * sizeof(char));
    attributeValueDup     = (char *) MEM_alloc(5000 * sizeof(char));
    attributeNameDup1     = (char *) MEM_alloc(5000 * sizeof(char));
    attributeValueDup1    = (char *) MEM_alloc(5000 * sizeof(char));
    tobeModaddress        = (char *) MEM_alloc(200  * sizeof(char));

    printf("\n\n========================================================\n");
    printf("=             START OF VCAttr()                        =\n");
    printf("========================================================\n");
    fflush(stdout);

    /* ===================== STEP 1: GET VC CLASSIFICATION & EXTRACT BU ===================== */
    printf("\n[STEP 1] Getting classification object for VC tag...\n");
    fflush(stdout);

    ITK_CALL(ICS_ask_classification_object(VC_tag, &IcsClsTag));

    if(IcsClsTag == NULLTAG)
    {
        printf("\n[ERROR] IcsClsTag is NULLTAG — VC is not classified. Exiting VCAttr.\n");
        fflush(stdout);
        return -1;
    }

    printf("[STEP 1] IcsClsTag (ICO) obtained successfully.\n");
    fflush(stdout);

    /* Get class ID string directly from ICO */
    ITK_CALL(ICS_ico_ask_class(IcsClsTag, &classId));

    if(classId == NULL)
    {
        printf("\n[ERROR] classId is NULL after ICS_ico_ask_class. Exiting VCAttr.\n");
        fflush(stdout);
        return -1;
    }

    printf("[STEP 1] VC Classification Class ID   : [%s]\n", classId);
    fflush(stdout);

    /* Get class tag using classId */
    ITK_CALL(ICS_find_class(classId, &actualClassTag));

    if(actualClassTag == NULLTAG)
    {
        printf("\n[ERROR] actualClassTag is NULLTAG — could not find class [%s]. Exiting VCAttr.\n", classId);
        fflush(stdout);
        return -1;
    }

    printf("[STEP 1] actualClassTag found successfully for class [%s].\n", classId);
    fflush(stdout);

    /* Get class name using actual class tag */
    ITK_CALL(ICS_ask_id_name(actualClassTag, &classIdFromTag, &className));

    printf("[STEP 1] VC Classification Class ID   : [%s]\n", classIdFromTag);
    printf("[STEP 1] VC Classification Class Name : [%s]\n", className);
    fflush(stdout);

    /*
     * Extract BU prefix by stripping "VCATTR01" from the class ID
     * e.g. "HCVVCATTR01" → strip "VCATTR01" → BU = "HCV"
     */
    char *vcAttrMarker = tc_strstr(classId, "VCATTR01");
    if(vcAttrMarker == NULL)
    {
        printf("\n[ERROR] Could not find 'VCATTR01' marker in class ID [%s]. Cannot extract BU prefix.\n", classId);
        fflush(stdout);
        return -1;
    }

    int buLen = (int)(vcAttrMarker - classId);
    buPrefix  = (char *) MEM_alloc((buLen + 1) * sizeof(char));
    tc_strncpy(buPrefix, classId, buLen);
    buPrefix[buLen] = '\0';

    printf("[STEP 1] Extracted BU Prefix          : [%s]\n", buPrefix);
    fflush(stdout);

    /* Build hybrid class name: BU + "HBRDVCATTR01" */
    tc_strcpy(hybridClassName, buPrefix);
    tc_strcat(hybridClassName, "HBRDVCATTR01");

    printf("[STEP 1] Built Hybrid Class Name       : [%s]\n", hybridClassName);
    fflush(stdout);

    /* ===================== STEP 2: GET HYBRID CLASS ATTRIBUTES ===================== */
    printf("\n[STEP 2] Finding Hybrid class tag for [%s]...\n", hybridClassName);
    fflush(stdout);

    /* Verify attr count first */
    char *attrCount = NULL;
    ICS_class_ask_property(hybridClassName, "ATTR_COUNT", &attrCount);
    printf("[STEP 2] ATTR_COUNT for hybrid class [%s] = [%s]\n", 
           hybridClassName, attrCount ? attrCount : "NULL");
    fflush(stdout);
    if(attrCount) MEM_free(attrCount);

    ITK_CALL(ICS_find_class(hybridClassName, &hybridClassTag));

    if(hybridClassTag == NULLTAG)
    {
        printf("\n[ERROR] Hybrid class [%s] not found in ICS. Exiting VCAttr.\n", hybridClassName);
        fflush(stdout);
        return -1;
    }

    printf("[STEP 2] Hybrid class tag found successfully. Tag = [%u]\n", hybridClassTag);
    fflush(stdout);

    ITK_CALL(ICS_view_describe_view(
        hybridClassTag,
        &nHybridAttrs,
        &vw_uncts,
        &vw_formats,
        &vw_nonMetricFormats,
        &vw_attributeIds,
        &vw_attributeNames,
        &vw_shortNames,
        &vw_units,
        &vw_configBefore,
        &vw_configField,
        &vw_configAfter,
        &vw_flags,
        &vw_metricMin,
        &vw_metricMax,
        &vw_nonMetricMin,
        &vw_nonMetricMax,
        &vw_metricDefaultValue,
        &vw_nonMetricDefaultValue));

    printf("[STEP 2] Total attributes in Hybrid class [%s] : [%d]\n", hybridClassName, nHybridAttrs);
    fflush(stdout);

    if(nHybridAttrs <= 0)
    {
        printf("\n[ERROR] No attributes found in Hybrid class [%s]. Exiting VCAttr.\n", hybridClassName);
        fflush(stdout);
        return -1;
    }

    /* Collect hybrid attribute names and IDs into arrays */
    hybridAttrNames = (char **) MEM_alloc(nHybridAttrs * sizeof(char *));
    hybridAttrIds   = (char **) MEM_alloc(nHybridAttrs * sizeof(char *));

    printf("\n[STEP 2] Listing all Hybrid class attributes:\n");
    printf("%-5s | %-20s | %s\n", "Idx", "Attr ID", "Attr Name");
    printf("------|----------------------|---------------------------\n");
    fflush(stdout);

for(i = 0; i < nHybridAttrs; i++)
{
    /* Handle attribute name */
    if(vw_attributeNames[i] == NULL)
    {
        hybridAttrNames[i] = (char *) MEM_alloc(1 * sizeof(char));
        tc_strcpy(hybridAttrNames[i], "");
    }
    else
    {
        hybridAttrNames[i] = (char *) MEM_alloc((tc_strlen(vw_attributeNames[i]) + 1) * sizeof(char));
        tc_strcpy(hybridAttrNames[i], vw_attributeNames[i]);
    }

    /* Use vw_uncts as attribute ID since vw_attributeIds is empty */
    hybridAttrIds[i] = (char *) MEM_alloc(20 * sizeof(char));
    sprintf(hybridAttrIds[i], "%d", vw_uncts[i]);

    printf("%-5d | %-20s | %s\n", i, hybridAttrIds[i], hybridAttrNames[i]);
    fflush(stdout);
}

    printf("\n[STEP 2] Hybrid attribute names and IDs collected successfully.\n");
    fflush(stdout);

    /* ===================== STEP 3: GET MODULAR VC CLASSIFICATION ATTRIBUTES ===================== */
    printf("\n[STEP 3] Getting Modular VC classification attributes...\n");
    fflush(stdout);

    ITK_CALL(ICS_ico_ask_attributes_optimized(
        IcsClsTag,
        &theAttributeCount,
        &theAttributeIds,
        &theAttributeNames,
        &theAttributeValCounts,
        &theAttributeValues,
        &theAttributeOptimizedUnits));

    printf("[STEP 3] Total attributes on Modular VC : [%d]\n", theAttributeCount);
    printf("\n[STEP 3] Listing all VC-level attributes:\n");
    printf("%-5s | %-10s | %-30s | %s\n", "Idx", "Attr ID", "Attr Name", "Value");
    printf("------|------------|--------------------------------|---------------------------\n");
    fflush(stdout);

    /* Collect VC level attribute names, IDs and values */
    vcAttrNames  = (char **) MEM_alloc(theAttributeCount * sizeof(char *));
    vcAttrValues = (char **) MEM_alloc(theAttributeCount * sizeof(char *));
    vcAttrIds    = (char **) MEM_alloc(theAttributeCount * sizeof(char *));

    for(i = 0; i < theAttributeCount; i++)
    {
        tc_strcpy(attributeNameDup,  "");
        tc_strcpy(attributeValueDup, "");

        sprintf(attrId, "%d", theAttributeIds[i]);
        tc_strcpy(attributeNameDup, theAttributeNames[i]);

        for(x = 0; x < theAttributeValCounts[i]; x++)
        {
            tc_strcat(attributeValueDup, theAttributeValues[i][x]);
        }

        printf("%-5d | %-10s | %-30s | '%s'\n", i, attrId, attributeNameDup, attributeValueDup);
        fflush(stdout);

        /* Store for comparison */
        vcAttrIds[i]    = (char *) MEM_alloc((tc_strlen(attrId)           + 1) * sizeof(char));
        vcAttrNames[i]  = (char *) MEM_alloc((tc_strlen(attributeNameDup) + 1) * sizeof(char));
        vcAttrValues[i] = (char *) MEM_alloc((tc_strlen(attributeValueDup)+ 1) * sizeof(char));
        tc_strcpy(vcAttrIds[i],    attrId);
        tc_strcpy(vcAttrNames[i],  attributeNameDup);
        tc_strcpy(vcAttrValues[i], attributeValueDup);
    }
	
////////////////////////////////
/* After VC attr collection loop in Step 3 */
printf("\n[STEP 3] Mapping Hybrid attr IDs from VC attr IDs by name match...\n");
fflush(stdout);

/* After VC attr collection loop in Step 3 */
printf("\n[STEP 3] Mapping Hybrid attr IDs from VC attr IDs by name match...\n");
fflush(stdout);

for(i = 0; i < nHybridAttrs; i++)
{
    for(int v = 0; v < theAttributeCount; v++)
    {
        if(tc_strcmp(hybridAttrNames[i], vcAttrNames[v]) == 0)
        {
            /* Name matched - verify if VC attr ID matches vw_uncts */
            printf("[STEP 3] Name match found: Hybrid attr [%s] | HybridID(unct)=[%s] | VC AttrID=[%s]\n",
                   hybridAttrNames[i],
                   hybridAttrIds[i],
                   vcAttrIds[v]);
            fflush(stdout);
            break;
        }
    }
}
////////////////////////////////	
	

    /* ===================== STEP 4: COMPARE VC LEVEL ATTRS AGAINST HYBRID CLASS ===================== */
    printf("\n[STEP 4] Comparing VC-level attributes against Hybrid class [%s]...\n", hybridClassName);
    printf("%-20s | %-30s | %-15s | %s\n", "Hybrid Attr ID", "Hybrid Attr Name", "Found in VC?", "Value");
    printf("--------------------|--------------------------------|-----------------|---------------------------\n");
    fflush(stdout);

    /* Array to store unmatched hybrid attrs to carry forward to Step 5 */
    remainingAttrNames = (char **) MEM_alloc(nHybridAttrs * sizeof(char *));
    remainingAttrIds   = (char **) MEM_alloc(nHybridAttrs * sizeof(char *));

    for(i = 0; i < nHybridAttrs; i++)
    {
        int foundFlag     = 0;
        int emptyFlag     = 0;
        char *foundValue  = "";

        for(int v = 0; v < theAttributeCount; v++)
        {
            if(tc_strcmp(hybridAttrNames[i], vcAttrNames[v]) == 0)
            {
                foundFlag  = 1;
                foundValue = vcAttrValues[v];

                if(tc_strlen(vcAttrValues[v]) == 0)
                {
                    emptyFlag = 1;
                }
                break;
            }
        }

        if(!foundFlag)
        {
            printf("%-20s | %-30s | %-15s | %s\n",
                   hybridAttrIds[i], hybridAttrNames[i], "NOT FOUND", "N/A");
            fflush(stdout);

            /* Add to remaining list for Step 5 */
            remainingAttrNames[remainingAttrCount] = (char *) MEM_alloc((tc_strlen(hybridAttrNames[i]) + 1) * sizeof(char));
            remainingAttrIds[remainingAttrCount]   = (char *) MEM_alloc((tc_strlen(hybridAttrIds[i])   + 1) * sizeof(char));
            tc_strcpy(remainingAttrNames[remainingAttrCount], hybridAttrNames[i]);
            tc_strcpy(remainingAttrIds[remainingAttrCount],   hybridAttrIds[i]);
            remainingAttrCount++;
        }
        else if(emptyFlag)
        {
            printf("%-20s | %-30s | %-15s | %s\n",
                   hybridAttrIds[i], hybridAttrNames[i], "FOUND-EMPTY", "''");
            fflush(stdout);

            /* Add to remaining list for Step 5 */
            remainingAttrNames[remainingAttrCount] = (char *) MEM_alloc((tc_strlen(hybridAttrNames[i]) + 1) * sizeof(char));
            remainingAttrIds[remainingAttrCount]   = (char *) MEM_alloc((tc_strlen(hybridAttrIds[i])   + 1) * sizeof(char));
            tc_strcpy(remainingAttrNames[remainingAttrCount], hybridAttrNames[i]);
            tc_strcpy(remainingAttrIds[remainingAttrCount],   hybridAttrIds[i]);
            remainingAttrCount++;
        }
        else
        {
            printf("%-20s | %-30s | %-15s | '%s'\n",
                   hybridAttrIds[i], hybridAttrNames[i], "FOUND-OK", foundValue);
            fflush(stdout);
        }
    }

    printf("\n[STEP 4] VC-level summary:\n");
    printf("  Total Hybrid attrs          : [%d]\n", nHybridAttrs);
    printf("  Matched at VC level         : [%d]\n", nHybridAttrs - remainingAttrCount);
    printf("  Carried forward to Step 5   : [%d]\n", remainingAttrCount);
    fflush(stdout);

    if(remainingAttrCount > 0)
    {
        printf("\n[STEP 4] Remaining attributes carried to Step 5:\n");
        printf("%-20s | %s\n", "Attr ID", "Attr Name");
        printf("--------------------|------------------------------\n");
        for(i = 0; i < remainingAttrCount; i++)
        {
            printf("%-20s | %s\n", remainingAttrIds[i], remainingAttrNames[i]);
            fflush(stdout);
        }
    }
    else
    {
        printf("\n[STEP 4] All Hybrid attributes matched at VC level. No need to check modules.\n");
        fflush(stdout);
        Total_count = 0;

        /* Cleanup and return */
        for(i = 0; i < nHybridAttrs; i++)
        {
            if(hybridAttrNames[i]) MEM_free(hybridAttrNames[i]);
            if(hybridAttrIds[i])   MEM_free(hybridAttrIds[i]);
        }
        if(hybridAttrNames)    MEM_free(hybridAttrNames);
        if(hybridAttrIds)      MEM_free(hybridAttrIds);
        if(remainingAttrNames) MEM_free(remainingAttrNames);
        if(remainingAttrIds)   MEM_free(remainingAttrIds);
        for(i = 0; i < theAttributeCount; i++)
        {
            if(vcAttrNames[i])  MEM_free(vcAttrNames[i]);
            if(vcAttrValues[i]) MEM_free(vcAttrValues[i]);
            if(vcAttrIds[i])    MEM_free(vcAttrIds[i]);
        }
        if(vcAttrNames)  MEM_free(vcAttrNames);
        if(vcAttrValues) MEM_free(vcAttrValues);
        if(vcAttrIds)    MEM_free(vcAttrIds);

        return Total_count;
    }

    /* ===================== STEP 5: BOM EXPANSION & MODULE LEVEL COMPARISON ===================== */
    printf("\n[STEP 5] Starting BOM expansion for module-level attribute check...\n");
    fflush(stdout);
	
    /* Initialize found tracker for remaining attrs */
    remainingAttrFoundFlag = (int *) MEM_alloc(remainingAttrCount * sizeof(int));
	remainingAttrEmptyModules = (char **) MEM_alloc(remainingAttrCount * sizeof(char *));
    for(i = 0; i < remainingAttrCount; i++)
    {
        remainingAttrFoundFlag[i] = 0;  /* 0 = not found in any module yet */
		remainingAttrEmptyModules[i] = NULL;  /* NULL = not found empty in any module yet */

    }

    ITK_CALL(getLatestReleasedPart2(VC_tag, &latestrev));

    if(latestrev == NULLTAG)
    {
        printf("\n[ERROR] No latest released revision found for VC. Skipping BOM expansion.\n");
        fflush(stdout);
        Total_count = remainingAttrCount;
        return Total_count;
    }

    /* Get TechSpec to read BussUnit */
    ITK_CALL(GRM_find_relation_type("T5_VCSpec", &VCspecRel));
    ITK_CALL(GRM_list_secondary_objects_only(latestrev, VCspecRel, &VCTecspecCount, &VC_Tecspec_objects));

    printf("[STEP 5] T5_VCSpec related objects count : [%d]\n", VCTecspecCount);
    fflush(stdout);

    if(VCTecspecCount <= 0)
    {
        printf("\n[ERROR] No TechSpec found via T5_VCSpec relation. Skipping BOM expansion.\n");
        fflush(stdout);
        Total_count = remainingAttrCount;
        return Total_count;
    }

    VC_Tecspec_object = VC_Tecspec_objects[0];
    ITKCALL(AOM_ask_value_string(VC_Tecspec_object, "t5_VCClassName", &BussUnit));

    printf("[STEP 5] BussUnit (t5_VCClassName)       : [%s]\n", BussUnit);
    fflush(stdout);

    /* Open BOM window */
    ITKCALL(BOM_create_window(&window));
    ITKCALL(CFM_find("ERC release and above", &rule));
    ITKCALL(BOM_set_window_config_rule(window, rule));
    ITKCALL(BOM_set_window_pack_all(window, true));
    ITKCALL(BOM_set_window_top_line(window, VC_tag, latestrev, NULLTAG, &top_line));
    ITKCALL(BOM_line_ask_child_lines(top_line, &n_count_bom, &LatChildSet));

    printf("[STEP 5] Total child BOM lines found     : [%d]\n", n_count_bom);
    fflush(stdout);

    if(n_count_bom <= 0)
    {
        printf("\n[STEP 5] No child BOM lines found. Skipping module-level check.\n");
        fflush(stdout);
        Total_count = remainingAttrCount;
        ITKCALL(BOM_close_window(window));
        goto FINAL_REPORT;
    }

    /* Loop through each child BOM line */
    for(aa = 0; aa < n_count_bom; aa++)
    {
        printf("\n--------------------------------------------------------\n");
        printf("[STEP 5] Processing BOM child [%d of %d]\n", aa + 1, n_count_bom);
        printf("--------------------------------------------------------\n");
        fflush(stdout);

        value_itemid      = NULL;
        moduleAddressS    = NULL;
        tobeModaddress[0] = '\0';

        ITKCALL(BOM_line_unpack(LatChildSet[aa]));
        ITKCALL(AOM_ask_value_string(LatChildSet[aa], "bl_item_item_id",                     &value_itemid));
        ITKCALL(AOM_ask_value_string(LatChildSet[aa], "bl_Design Revision_t5_ModuleAddress",  &moduleAddressS));

        printf("[STEP 5] Child Item ID   : [%s]\n", value_itemid);
        printf("[STEP 5] Module Address  : [%s]\n", moduleAddressS);
        fflush(stdout);

        if(tc_strlen(moduleAddressS) > 0)
        {
            tc_strcpy(tobeModaddress, BussUnit);
            tc_strcat(tobeModaddress, moduleAddressS);
        }
        else
        {
            printf("[STEP 5] Module address is empty for item [%s]. Skipping.\n", value_itemid);
            fflush(stdout);
            continue;
        }

        printf("[STEP 5] Full Class Path : [%s]\n", tobeModaddress);
        fflush(stdout);

        icsIcsClsExist = ICS_class_exists(tobeModaddress);
        printf("[STEP 5] Class exists    : [%s]\n", icsIcsClsExist ? "YES" : "NO");
        fflush(stdout);

        if(icsIcsClsExist == false)
        {
            printf("[STEP 5] Class [%s] does not exist in ICS. Skipping module [%s].\n",
                   tobeModaddress, value_itemid);
            fflush(stdout);
            continue;
        }

        /* Get item tag */
        item_tag = NULLTAG;
        ITKCALL(ITEM_find_item(value_itemid, &item_tag));

        if(item_tag == NULLTAG)
        {
            printf("[ERROR] Could not find item tag for item ID [%s]. Skipping.\n", value_itemid);
            fflush(stdout);
            continue;
        }

        /* Get classification objects for this module */
        Mcnt            = 0;
        ModuleClsObjTag = NULLTAG;

        ITK_CALL(AOM_ask_value_tags(item_tag, "IMAN_classification", &Mcnt, &ModuleClsObjTag));

        printf("[STEP 5] Classification object count for module [%s] : [%d]\n", value_itemid, Mcnt);
        fflush(stdout);

        if(Mcnt == 0)
        {
            printf("[STEP 5] Module [%s] has no classification object.\n", value_itemid);
            fflush(stdout);
            continue;
        }

        /* Loop through each classification object of the module */
        for(c = 0; c < Mcnt; c++)
        {
            printf("\n[STEP 5] Processing classification object [%d of %d] for module [%s]\n",
                   c + 1, Mcnt, value_itemid);
            fflush(stdout);

            if(tc_strstr(tobeModaddress, BussUnit) == NULL)
            {
                printf("[STEP 5] tobeModaddress [%s] does not contain BussUnit [%s]. Skipping.\n",
                       tobeModaddress, BussUnit);
                fflush(stdout);
                continue;
            }

            ModuleClsObj = ModuleClsObjTag[c];

            theAttributeCount1          = 0;
            theAttributeIds1            = NULL;
            theAttributeNames1          = NULL;
            theAttributeValCounts1      = NULL;
            theAttributeValues1         = NULL;
            theAttributeOptimizedUnits1 = NULL;

            ITK_CALL(ICS_ico_ask_attributes_optimized(
                ModuleClsObj,
                &theAttributeCount1,
                &theAttributeIds1,
                &theAttributeNames1,
                &theAttributeValCounts1,
                &theAttributeValues1,
                &theAttributeOptimizedUnits1));

            printf("[STEP 5] Total attributes for module [%s] cls obj [%d] : [%d]\n",
                   value_itemid, c, theAttributeCount1);
            printf("\n[STEP 5] Listing all attributes for module [%s]:\n", value_itemid);
            printf("%-5s | %-10s | %-30s | %s\n", "Idx", "Attr ID", "Attr Name", "Value");
            printf("------|------------|--------------------------------|---------------------------\n");
            fflush(stdout);

            /* Collect module attribute names, IDs and values */
            char **moduleAttrNames  = (char **) MEM_alloc(theAttributeCount1 * sizeof(char *));
            char **moduleAttrValues = (char **) MEM_alloc(theAttributeCount1 * sizeof(char *));
            char **moduleAttrIds    = (char **) MEM_alloc(theAttributeCount1 * sizeof(char *));

            for(i = 0; i < theAttributeCount1; i++)
            {
                tc_strcpy(attributeNameDup1,  "");
                tc_strcpy(attributeValueDup1, "");

                sprintf(attrId1, "%d", theAttributeIds1[i]);
                tc_strcpy(attributeNameDup1, theAttributeNames1[i]);

                for(x = 0; x < theAttributeValCounts1[i]; x++)
                {
                    tc_strcat(attributeValueDup1, theAttributeValues1[i][x]);
                }

                printf("%-5d | %-10s | %-30s | '%s'\n",
                       i, attrId1, attributeNameDup1, attributeValueDup1);
                fflush(stdout);

                moduleAttrIds[i]    = (char *) MEM_alloc((tc_strlen(attrId1)            + 1) * sizeof(char));
                moduleAttrNames[i]  = (char *) MEM_alloc((tc_strlen(attributeNameDup1)  + 1) * sizeof(char));
                moduleAttrValues[i] = (char *) MEM_alloc((tc_strlen(attributeValueDup1) + 1) * sizeof(char));
                tc_strcpy(moduleAttrIds[i],    attrId1);
                tc_strcpy(moduleAttrNames[i],  attributeNameDup1);
                tc_strcpy(moduleAttrValues[i], attributeValueDup1);
            }

            /* Compare remaining attrs against this module */
            printf("\n[STEP 5] Comparing [%d] remaining attrs against module [%s] cls obj [%d]:\n",
                   remainingAttrCount, value_itemid, c);
            printf("%-20s | %-30s | %-15s | %s\n",
                   "Attr ID", "Attr Name", "Found in Module?", "Value");
            printf("--------------------|--------------------------------|-----------------|------------------\n");
            fflush(stdout);

            for(i = 0; i < remainingAttrCount; i++)
            {
                int foundFlag    = 0;
                int emptyFlag    = 0;
				int matchedIdx   = -1;
                char *foundValue = "";

                for(int m = 0; m < theAttributeCount1; m++)
                {
                    if(tc_strcmp(remainingAttrNames[i], moduleAttrNames[m]) == 0)
                    {
                        foundFlag  = 1;
						matchedIdx = m;
                        foundValue = moduleAttrValues[m];

                        if(tc_strlen(moduleAttrValues[m]) == 0)
                        {
                            emptyFlag = 1;
                        }
                        break;
                    }
                }


    if(foundFlag && !emptyFlag)
    {
        remainingAttrFoundFlag[i] = 1;

        /* Fill ID if not already filled using saved matchedIdx */
        if(tc_strlen(remainingAttrIds[i]) == 0)
        {
            if(remainingAttrIds[i]) MEM_free(remainingAttrIds[i]);
            remainingAttrIds[i] = (char *) MEM_alloc((tc_strlen(moduleAttrIds[matchedIdx]) + 1) * sizeof(char));
            tc_strcpy(remainingAttrIds[i], moduleAttrIds[matchedIdx]);
        }

        printf("%-20s | %-30s | %-15s | '%s'\n",
               remainingAttrIds[i], remainingAttrNames[i], "FOUND-OK", foundValue);
    }
    else if(foundFlag && emptyFlag)
    {
        /* Fill ID if not already filled using saved matchedIdx */
        if(tc_strlen(remainingAttrIds[i]) == 0)
        {
            if(remainingAttrIds[i]) MEM_free(remainingAttrIds[i]);
            remainingAttrIds[i] = (char *) MEM_alloc((tc_strlen(moduleAttrIds[matchedIdx]) + 1) * sizeof(char));
            tc_strcpy(remainingAttrIds[i], moduleAttrIds[matchedIdx]);
        }

        printf("%-20s | %-30s | %-15s | %s\n",
               remainingAttrIds[i], remainingAttrNames[i], "FOUND-EMPTY", "''");

        char emptyModuleInfo[500];
        sprintf(emptyModuleInfo, "Module[%d]:%s", aa + 1, value_itemid);

        if(remainingAttrEmptyModules[i] == NULL)
        {
            remainingAttrEmptyModules[i] = (char *) MEM_alloc(5000 * sizeof(char));
            tc_strcpy(remainingAttrEmptyModules[i], emptyModuleInfo);
        }
        else
        {
            tc_strcat(remainingAttrEmptyModules[i], " | ");
            tc_strcat(remainingAttrEmptyModules[i], emptyModuleInfo);
        }
    }
    else
    {
        printf("%-20s | %-30s | %-15s | %s\n",
               remainingAttrIds[i], remainingAttrNames[i], "NOT FOUND", "N/A");
    }

  fflush(stdout);
            }

            /* Free module level arrays */
            for(i = 0; i < theAttributeCount1; i++)
            {
                if(moduleAttrIds[i])    MEM_free(moduleAttrIds[i]);
                if(moduleAttrNames[i])  MEM_free(moduleAttrNames[i]);
                if(moduleAttrValues[i]) MEM_free(moduleAttrValues[i]);
            }
            if(moduleAttrIds)    MEM_free(moduleAttrIds);
            if(moduleAttrNames)  MEM_free(moduleAttrNames);
            if(moduleAttrValues) MEM_free(moduleAttrValues);

        } /* end for each classification object */

    } /* end for each BOM child line */

    /* Close BOM window */
    ITKCALL(BOM_close_window(window));
    printf("\n[STEP 5] BOM window closed.\n");
    fflush(stdout);

    /* ===================== FINAL REPORT ===================== */
    FINAL_REPORT:

    printf("\n========================================================\n");
    printf("=       ATTRIBUTES NOT FOUND ACROSS VC AND MODULES     =\n");
    printf("========================================================\n");
    printf("%-20s | %s\n", "Attr ID", "Attr Name");
    printf("--------------------|------------------------------\n");
    fflush(stdout);

    totalNeverFound = 0;
    for(i = 0; i < remainingAttrCount; i++)
    {
        if(remainingAttrFoundFlag[i] == 0)
        {
            printf("%-20s | %s\n", remainingAttrIds[i], remainingAttrNames[i]);
            fflush(stdout);
            totalNeverFound++;
        }
    }

    printf("\n========================================================\n");
    printf("=                  FINAL SUMMARY                       =\n");
    printf("========================================================\n");
    printf("  Hybrid Class Used                    : [%s]\n", hybridClassName);
    printf("  Total Hybrid Attrs to compare        : [%d]\n", nHybridAttrs);
    printf("  Matched at VC level                  : [%d]\n", nHybridAttrs - remainingAttrCount);
    printf("  Carried forward to module check      : [%d]\n", remainingAttrCount);
    printf("  Found in modules                     : [%d]\n", remainingAttrCount - totalNeverFound);
    printf("  NOT FOUND anywhere (VC + modules)    : [%d]\n", totalNeverFound);
    printf("========================================================\n\n");
    fflush(stdout);

    Total_count = totalNeverFound;

    /* ===================== CLEANUP ===================== */
    for(i = 0; i < nHybridAttrs; i++)
    {
        if(hybridAttrNames[i]) MEM_free(hybridAttrNames[i]);
        if(hybridAttrIds[i])   MEM_free(hybridAttrIds[i]);
    }
    if(hybridAttrNames) MEM_free(hybridAttrNames);
    if(hybridAttrIds)   MEM_free(hybridAttrIds);

    for(i = 0; i < remainingAttrCount; i++)
    {
        if(remainingAttrNames[i]) MEM_free(remainingAttrNames[i]);
        if(remainingAttrIds[i])   MEM_free(remainingAttrIds[i]);
		if(remainingAttrEmptyModules[i]) MEM_free(remainingAttrEmptyModules[i]);
    }
    if(remainingAttrNames)     MEM_free(remainingAttrNames);
    if(remainingAttrIds)       MEM_free(remainingAttrIds);
    if(remainingAttrFoundFlag) MEM_free(remainingAttrFoundFlag);
	if(remainingAttrEmptyModules) MEM_free(remainingAttrEmptyModules);
	
    for(i = 0; i < theAttributeCount; i++)
    {
        if(vcAttrNames[i])  MEM_free(vcAttrNames[i]);
        if(vcAttrValues[i]) MEM_free(vcAttrValues[i]);
        if(vcAttrIds[i])    MEM_free(vcAttrIds[i]);
    }
    if(vcAttrNames)  MEM_free(vcAttrNames);
    if(vcAttrValues) MEM_free(vcAttrValues);
    if(vcAttrIds)    MEM_free(vcAttrIds);

    if(attrId)            MEM_free(attrId);
    if(attrId1)           MEM_free(attrId1);
    if(buPrefix)          MEM_free(buPrefix);
    if(hybridClassName)   MEM_free(hybridClassName);
    if(attributeNameDup)  MEM_free(attributeNameDup);
    if(attributeValueDup) MEM_free(attributeValueDup);
    if(attributeNameDup1) MEM_free(attributeNameDup1);
    if(attributeValueDup1)MEM_free(attributeValueDup1);
    if(tobeModaddress)    MEM_free(tobeModaddress);

    return Total_count;
}

//Start Rule Handler

/*
	Rule Handler		:		CM_Check_ClsObjForTechSpec
	Description			:		This Rule handler checks the clasified object for attached TechSpec with CCV
*/

//int CM_Check_ClsObjForTechSpec(EPM_rule_message_t msg)
extern EPM_decision_t DLLAPI CM_Check_ClsObjForTechSpec(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int i=0,j=0,k=0,status=ITK_ok;
	int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	int    n_bom_views=0;
	int    bom_view_index=0;
	int    noAttachment=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *dmlProjID=NULL;
	char *DMLDRstatus=NULL;
	char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;

    tag_t  rev=NULLTAG;
    tag_t  rev1=NULLTAG;
	tag_t  view_type= NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ItemObj = NULLTAG;
	tag_t  DcrItemObj=NULLTAG;
	tag_t  ctrlObjQry=NULLTAG;
	tag_t  implemRelationType_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  *qryResults=NULLTAG;
	tag_t  *DcrList=NULLTAG;
	tag_t  *taskList=NULLTAG;
	tag_t  *ItemsList=NULLTAG;
	tag_t  *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	tag_t  item=NULLTAG;
	tag_t  bom_view= NULLTAG;

	char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId                 = NULL;
	char        *SVRType                  = NULL;
	

	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   Childobject3=NULLTAG;
	tag_t   Childobject4=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	tag_t			dataset									= NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     errorflag4=0;
	int     errorflag1=0;
	int     errorflag2=0;
	int     errorflag34=0;
	tag_t  *options=NULL;
	char   *v2_text=NULL;
	//tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;

	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	int     n_lines2=0;
	int     n_lines3=0;
	int     n_lines4=0;
	int rulefound= 0;
	int     p2=0;
	int     ss=0;
	int     p36=0;
	char **rulename = NULL;
    char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	 tag_t  *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	int     p4=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	tag_t   *status_list          = NULLTAG;
	tag_t			relation_type							= NULLTAG;
	tag_t			relation_type1							= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_id156=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *ChildSVRname=NULL;
	tag_t *closurerule = NULL;
	char *child_bl_formula=NULL;
	tag_t  	objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		char   *TempVal			=NULL;
		tag_t close_tag;
	char *objectname=NULL;
	
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char	*Proj_BU		= NULL;
	char 	*Proj_DesgOwnUnit	= NULL;
	char	*Proj_ProtoUnit		= NULL;
	char	*Proj_VCSubClass		= NULL;
	//tag_t rev;
	tag_t	Project_t		= NULLTAG;
	tag_t SpecRel_tag = NULLTAG;
	int SpecCount=0;
	tag_t *SpecDoc_tags = NULLTAG;
	//int k;
	//int i;
	int rule_count;
	int count;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));
	char *parttype;
	char 	*ProjectID		= NULL;
	char *group_name	= NULL;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
	tag_t * 	secondary_objects ;
	tag_t			GroupMem								= NULLTAG;
	tag_t queryTag = NULLTAG;
	char
        *user_name_string;
		char *SesLoc;
		char *ccvRevId =NULL;
		int tscount;
    tag_t
        user;
		char* tsitem;
	tag_t	ccvMstrTag = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t *ClsObjTag = NULLTAG;
	tag_t *		techspec_objects;
	tag_t *t5_Project=NULLTAG;
	logical modB=FALSE;
	int status_count = 0;
	int structcount=0;
	int cnt		=0;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char NoSubSet[1900] = { 0 };
	char RevMisMatch[19000] = { 0 };
	int p34=0;
	int p3=0;
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	//char RevMisMatch[19000];
 

 printf("inside CM_Check_ClsObjForTechSpec Rule Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n CM_Check_ClsObjForTechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_Check_ClsObjForTechSpec Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=tags_found[0];
		char *id;
		char *Solid;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);

		
		
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
		//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
		printf( "reference item attachment count:%d\n", count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				char *VCClass;
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_string" , &Solid));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s",Solid,parttype,VCClass,ccvRevId);fflush(stdout);
				//return;
				
				if(tc_strcmp(parttype,"VC")!=0)
				{
				if(tc_strstr(parttype,"V")!=NULL)
				{
					CALLAPI(GRM_find_relation_type("T5_VCSpec", &SpecRel_tag));
					CALLAPI(GRM_list_secondary_objects_only(secondary_objects[i],SpecRel_tag,&SpecCount,&SpecDoc_tags));
					printf("\n TechSpec Header Count--: %d\n",SpecCount);fflush(stdout);
					
					if(SpecCount<=0)
					{
									sprintf(ErrMsg,"Tech Spec Header is not available to latest VC,so Ensure Tech Spec Header availability first for VC[%s]\n ,or  Contact PLM Support Team for more details",Solid);
									printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
									decision = EPM_nogo;
									MEM_free(ErrMsg);
									return decision;
					}
					
					// if(tc_strstr(ccvRevId,"NR")!=NULL)
					// {
					//char *projcode;
					//char *DRStatus;
					//tag_t  CurrentRoleTag = NULLTAG;
					//char       roleName[SA_name_size_c+1];
						printf("\n going to check Tech Spec and classification history"); fflush(stdout);
							//getting master from itemrev
							CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));	
							//find the classified object for above tech Spec
							if(ccvMstrTag)
							{
								//CALLAPI(AOM_ask_value_tags(secondary_objects[i],"IMAN_classification",&cnt,&ClsObjTag));
								CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
								printf("\n classified object count[%d] for CCV[%s] !!",cnt,Solid); fflush(stdout);
								if(cnt>0)
								{
									printf("\n classifiction obj found for attached CCV[%s] ",Solid); fflush(stdout);									
									decision = EPM_go;
									//return EPM_go;
								}
								else
								{
									//sprintf(ErrMsg,"Tech Spec has not been classified,so update the classified value first for CCV[%s]",Solid);
									sprintf(ErrMsg,"VC Attributes has not been filled for this VC/Tech Spec ,so update the VC Attributes value first for CCV[%s]",Solid);
									//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
									printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
									decision = EPM_nogo;
									MEM_free(ErrMsg);
									return decision;
								}
							}
						
					// }
					// else
					// {
						// printf("\n NON-NR revision is not eligible to create Tech Spec for Cluster SVR release process"); fflush(stdout);
					// }
					
					printf("\n End VC attributes check and classification history"); fflush(stdout);
					//start New Process to check NULL Value for mandatory attributes
					int TSBypass4MandAttrChkCnt=0;
					tag_t    *TSBypass4MandAttrChkObjSet=NULLTAG;
					printf("\n inside CM_Check_ClsObjForTechSpec for tm_MissMandatoryVCAttrCountFunc ");fflush(stdout);
					CALLAPI(getCntrlObj( "TSBypass4MandAttrChk",&TSBypass4MandAttrChkCnt ,&TSBypass4MandAttrChkObjSet));
					
					printf("\n inside CM_Check_ClsObjForTechSpec TSBypass4MandAttrChkCnt[%d]",TSBypass4MandAttrChkCnt);fflush(stdout);
					if(TSBypass4MandAttrChkCnt>0)
					{
									CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));	
											//find the classified object for above tech Spec
											if(ccvMstrTag)
											{
												printf("\n\nb4 call tm_MissMandatoryVCAttrCountFunc \n\n");
												int flag=0;
												//flag=((tm_MissMandatoryVCAttrCountFunc(ccvMstrTag))); 
												tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
												tag_t   qryTagCntrl1            = NULLTAG;
												int     n_entryCntrl1           = 3;
												char    *qry_entryCntrl1[3]     = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
												char    **qry_valuesCntrl1      = (char **) MEM_alloc(5 * sizeof(char *));
												int     control_number_found1   = 0;
												char    *vcAttrMode             = NULL;
										
												if(QRY_find2("Control Objects...", &qryTagCntrl1));
												if(qryTagCntrl1)
												{
													printf("\n Control Object Query Found \n"); fflush(stdout);
													qry_valuesCntrl1[0] = "TechSpecVCAttrChkModuleWise";
													qry_valuesCntrl1[1] = "Live";
													qry_valuesCntrl1[2] = "0";
										
													if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1,qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
													printf("\n Control Object count for TechSpecVCAttrChkModuleWise: [%d]\n", control_number_found1); fflush(stdout);
										
													if(control_number_found1 > 0)
													{
														printf("[CTRL] Calling New function Module Wise TechSpec Attr Check: tm_MissMandatoryVCAttrCountFunc_V2 \n");
														//New Function call
														flag = tm_MissMandatoryVCAttrCountFunc_V2(ccvMstrTag);
													}
													else
													{
														printf("\n Control Object not available for TechSpecVCAttrChkModuleWise. Defaulting to OLD function.\n"); fflush(stdout);
														//Old Function Call
														printf("[CTRL] Calling OLD function Module Wise TechSpec Attr Check: tm_MissMandatoryVCAttrCountFunc_V2 \n");
														fflush(stdout);
														flag = tm_MissMandatoryVCAttrCountFunc(ccvMstrTag);
												
													}
												}
												else
												{
													printf("\n Control Object Query not Found for TechSpecVCAttrChkModuleWise.\n"); fflush(stdout);
												}
												printf("\ntm_MissMandatoryVCAttrCountFunc the Flag value is %d",flag);
												if(flag>0)
													{
															
															printf("\n\nThe Attributes are missing for VC=%s\n\n",Solid);
															sprintf(ErrMsg,"Mandatory Tech Spec attributes are missing for this VC[%s] ,Therefore update the mandatory attributes value first \n Contact PLM Tech Spec Support team for more clarification ",Solid);
															//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
															printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
															EMH_clear_errors();
															EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
															decision = EPM_nogo;
															MEM_free(ErrMsg);
															return decision;
													}
													else
													{
														
															printf("\n\n\nAll the Attributes are Present\n\n\n");
																printf("\n no mandatory attributes missing for CCV[%s] ",Solid); fflush(stdout);									
															decision = EPM_go;
														  
													}
											}
					}
					printf("\n END CM_Check_ClsObjForTechSpec RH for mandatory attributes check ");fflush(stdout);
							
					//End New Process to check NULL Value for mandatory attributes		
				}
			}
			}
			printf("\nTech Spec object creation for CCV w.r.t SVR WF has completed");fflush(stdout);
  
		}
		
		
		}
		
	}
}
	decision = EPM_go;
	return decision;
}


//End Rule Handler


//Start Rule Handler

/*
	Rule Handler		:		RH_Check_TechSpecDocFile
	Description			:		This Rule handler checks the TechSpec Doc file with attached TechSpec header.
*/

//int RH_Check_TechSpecDocFile(EPM_rule_message_t msg)
extern EPM_decision_t DLLAPI RH_Check_TechSpecDocFile(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	tag_t  rootTask_t=NULLTAG;
	tag_t * 	secondary_objects ;
	tag_t * 	TechSpecObjs ;
	tag_t * TsDocobjs ;
	tag_t  *taskAttachments=NULLTAG;
	
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t TechSpecObjTag = NULLTAG;
	tag_t Attach_type_rel = NULLTAG;
	tag_t docobj = NULLTAG;
	tag_t Attachrelation_type=NULLTAG;
	
	char *obj_type=NULL;
	char *parttype=NULL;
	char *ccvRevId=NULL;
	char *relation_name=NULL;
	char *relation_name1=NULL;
	char *techspecid=NULL;
	char *techspecidDup=NULL;
	char *doctype=NULL;
	char *docname=NULL;
	char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));
	char *tobedocfilename=NULL;
	int i=0;
	int dc=0;
	int doccnt=0;
	int attachmentCount=0,Itemscnt=0;
	int count=0;
	int tscount;
	int docfound=0;
	int TScount=0;
 printf("inside RH_Check_TechSpecDocFile Rule Handler\n");fflush(stdout);
 
 
 
	// int TechSpecDocRHChkFlg=0;
	// printf("\n b4 call TechSpecDocRHChk func= %d func for RH_Check_TechSpecDocFile\n",TechSpecDocRHChkFlg);fflush(stdout);
	// TechSpecDocRHChkFlg=TechSpecDocRHChk();

	// printf("\n after RH_Check_TechSpecDocFile TechSpecDocRHChk func = %d\n",TechSpecDocRHChkFlg);fflush(stdout);
	// if(TechSpecDocRHChkFlg>0)
	// {
		// printf("\n TechSpecDocRHChk is bypassing as per configuration %d\n",TechSpecDocRHChkFlg);fflush(stdout);
		// decision = EPM_go;
		// return decision;
	// }
	
 
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n RH_Check_TechSpecDocFile attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n RH_Check_TechSpecDocFile Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=tags_found[0];
		char *id;
		char *Solid;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);


		int TechSpecDocRHChkFlg=0;
		printf("\n b4 call TechSpecDocRHChk func= %d func for RH_Check_TechSpecDocFile\n",TechSpecDocRHChkFlg);fflush(stdout);
		TechSpecDocRHChkFlg=TechSpecDocRHChk(id);

		printf("\n after RH_Check_TechSpecDocFile TechSpecDocRHChk func = %d\n",TechSpecDocRHChkFlg);fflush(stdout);
		if(TechSpecDocRHChkFlg>0)
		{
			printf("\n TechSpecDocRHChk is bypassing as per configuration %d\n",TechSpecDocRHChkFlg);fflush(stdout);
			decision = EPM_go;
			//break;
			return decision;
		}
		
		
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
		//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
		printf( "reference item attachment count:%d\n", count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				char *VCClass;
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_string" , &Solid));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s",Solid,parttype,VCClass,ccvRevId);fflush(stdout);
				//return;
				
				if(tc_strcmp(parttype,"VC")!=0)
				{
				if(tc_strstr(parttype,"V")!=NULL)
				{
					//if(tc_strstr(ccvRevId,"NR")!=NULL)
					//{
					//char *projcode;
					//char *DRStatus;
					//tag_t  CurrentRoleTag = NULLTAG;
					//char       roleName[SA_name_size_c+1];
					printf("\n going to check Tech Spec doc"); fflush(stdout);
					
					
					ITK_CALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
					printf("\n after T5_VCSpec relation find"); fflush(stdout);
					if(relation_type_tag != NULLTAG)
					{
						printf("\n inside T5_VCSpec relation found"); fflush(stdout);
						ITK_CALL(TCTYPE_ask_name2( relation_type_tag, &relation_name));
						printf("\n relation_name[%s]",relation_name); fflush(stdout);
						ITK_CALL(GRM_list_secondary_objects_only(secondary_objects[i],relation_type_tag,&TScount,&TechSpecObjs));
						printf("\n TScount: %d\n", TScount);fflush(stdout);
						if(TScount>0)
						{
							TechSpecObjTag=TechSpecObjs[0];
							
							ITK_CALL(AOM_ask_value_string(TechSpecObjTag,"item_id" , &techspecid));
							printf("\n techspecid: %s\n", techspecid);fflush(stdout);
							
							if(tc_strlen(techspecid)>0)
							{
								tc_strdup(techspecid,&techspecidDup);
								tobedocfilename=(char *) MEM_alloc(20);
								tc_strcpy(tobedocfilename,techspecid);
								tc_strcat(tobedocfilename,".doc");
								
							}
							printf("\n techspecidDup: %s\n", techspecidDup);fflush(stdout);
							
							ITK_CALL(GRM_find_relation_type("IMAN_specification",&Attach_type_rel));
								if(Attach_type_rel)
								{
									ITK_CALL(TCTYPE_ask_name2( Attach_type_rel, &relation_name1));
									printf("\n TS Doc relation_name[%s]",relation_name1); fflush(stdout);
									ITK_CALL(GRM_list_secondary_objects_only(TechSpecObjTag,Attach_type_rel,&doccnt,&TsDocobjs));
									printf("\n TS Doc count: %d\n", doccnt);fflush(stdout);
									if(doccnt<=0)
									{
										sprintf(ErrMsg,"Tech Spec Word Doc [%s] has not been attached with Tech Spec Header[%s],attach respective doc with the Tech Spec prior to Sign-off complete the DML Task",tobedocfilename,techspecidDup);
										printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
										decision = EPM_nogo;
										MEM_free(ErrMsg);
										return decision;
									}
									else
									{
										docfound=0;
										for(dc=0;dc<doccnt;dc++)
										{
											docobj=TsDocobjs[dc];
											ERROR_CHECK(AOM_ask_value_string(docobj,"object_name" , &docname));
											AOM_ask_value_string(docobj,"object_type",&doctype);
										   printf("\n object_type is :%s\n",doctype);fflush(stdout);
										   if(tc_strstr(docname,techspecidDup)!=NULL )
										   {
											   if(tc_strstr(doctype,"Word")!=NULL  )
											   {
												  printf("\n Word doc[%s] found in Tech Header [%s]\n",docname,techspecidDup);fflush(stdout);   
													//decision = EPM_go;
													docfound=1;	
													break;
													//return decision;
											   }
										   }
										}
										printf("\n docfound :%d\n",docfound);fflush(stdout);
										if(docfound<1)
										{
											
											sprintf(ErrMsg,"Tech Spec Word Doc [%s] has not been attached with Tech Spec Header[%s],attach respective doc with the Tech Spec prior to Sign-off complete the DML Task",tobedocfilename,techspecidDup);
											printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
											decision = EPM_nogo;
											MEM_free(ErrMsg);
											return decision;
										}
									}
								}
							
							
						}
					}
					
							
						
					
				}
			}
			}
			
  
		}
		
		
		}
		
	}
}
printf("\nTech Spec Doc attachment check Rule handler has been completed");fflush(stdout);
	decision = EPM_go;
	return decision;
}


//End Rule Handler



int TS_getClsValueFrmICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char   *Ptype_name=NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	ITK_CALL(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//ITK_CALL(TCTYPE_ask_name(objTypeTag,Ptype_name));
	ITK_CALL(TCTYPE_ask_name2(objTypeTag,&Ptype_name));
	printf("\n TS_getClsValueFrmICSTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
                tag_t* partRevTagObjs = NULLTAG;
                tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		char * 	theClassId =NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int i;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//ITK_CALL(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			ITK_CALL(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue));
			
			printf("\n AttrKeyValue=%s key_lov_id=%s",AttrKeyValue,key_lov_id); fflush(stdout);
			if(AttrKeyValue)
			{
			
			ITK_CALL(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			//ITK_CALL(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
				for(i=0;i<n_lov_entries;i++)								
				{
					printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
					
					if(tc_strcmp(AttrKeyValue,lov_keys[i])==0)
					{
						printf("\n Mascot lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);
						
						if(lov_values[i])
						{
							tc_strdup(lov_values[i],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}
					
					
					
				}
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}						
			printf("\n RetAttrVal=%s ",RetAttrVal); fflush(stdout);
			

	return ITK_ok;

}
	

//Added Rule Handler on 25122021 for CR-FY20-0160

/*
	Rule Handler		:		CM_Check_CmvrTypeNoOfVeh
	Description			:		This Rule handler checks the CMVR TYPE NO is available to vehicle/CCV or not
*/

//int CM_Check_CmvrTypeNoOfVeh(EPM_rule_message_t msg)
extern EPM_decision_t DLLAPI CM_Check_CmvrTypeNoOfVeh(EPM_rule_message_t msg)
{
	EPM_decision_t decision;
	int i=0,j=0,k=0,status=ITK_ok;
	int found,Dcrcnt = 0;
	int ifail=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	int    n_bom_views=0;
	int    bom_view_index=0;
	int    noAttachment=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *dmlProjID=NULL;
	char *DMLDRstatus=NULL;
	char *dmlRelType=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;

    tag_t  rev=NULLTAG;
    tag_t  rev1=NULLTAG;
	tag_t  view_type= NULLTAG;
	tag_t  rootTask_t=NULLTAG;
	tag_t  primary1=NULLTAG;
	tag_t  ItemObj = NULLTAG;
	tag_t  DcrItemObj=NULLTAG;
	tag_t  ctrlObjQry=NULLTAG;
	tag_t  implemRelationType_t=NULLTAG;
	tag_t  DcrProblmItemsRelType=NULLTAG;
	tag_t  DmlTaskRelationType_t=NULLTAG;
	tag_t  DmlItemsRelation_t=NULLTAG;
	tag_t  *taskAttachments=NULLTAG;
	tag_t  *qryResults=NULLTAG;
	tag_t  *DcrList=NULLTAG;
	tag_t  *taskList=NULLTAG;
	tag_t  *ItemsList=NULLTAG;
	tag_t  *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	tag_t  item=NULLTAG;
	tag_t  bom_view= NULLTAG;

	char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId                 = NULL;
	char        *SVRType                  = NULL;
	

	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   Childobject3=NULLTAG;
	tag_t   Childobject4=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	tag_t			dataset									= NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     errorflag4=0;
	int     errorflag1=0;
	int     errorflag2=0;
	int     errorflag34=0;
	tag_t  *options=NULL;
	char   *v2_text=NULL;
	//tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;

	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	int     n_lines2=0;
	int     n_lines3=0;
	int     n_lines4=0;
	int rulefound= 0;
	int     p2=0;
	int     ss=0;
	int     p36=0;
	char **rulename = NULL;
    char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	 tag_t  *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	int     p4=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	tag_t   *status_list          = NULLTAG;
	tag_t			relation_type							= NULLTAG;
	tag_t			relation_type1							= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_id156=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *ChildSVRname=NULL;
	tag_t *closurerule = NULL;
	char *child_bl_formula=NULL;
	tag_t  	objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
		int IntAtr5=0;
	char *objecttype=NULL;
		char   *TempVal			=NULL;
		tag_t close_tag;
	char *objectname=NULL;
	
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char	*Proj_BU		= NULL;
	char 	*Proj_DesgOwnUnit	= NULL;
	char	*Proj_ProtoUnit		= NULL;
	char	*Proj_VCSubClass		= NULL;
	//tag_t rev;
	tag_t	Project_t		= NULLTAG;
	//int k;
	//int i;
	int rule_count;
	int count;
	int		resultCount = 0;
	int		n_entries = 1;
	char *val;
	char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));
	char *parttype;
	char 	*ProjectID		= NULL;
	char *getAttrVal;
	char *group_name	= NULL;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char    *Proj_DesgOwnDept     =  (char *) MEM_alloc(10 * sizeof(char *));
	tag_t * 	secondary_objects ;
	tag_t			GroupMem								= NULLTAG;
	tag_t queryTag = NULLTAG;
	char
        *user_name_string;
		char *SesLoc;
		char *ccvRevId =NULL;
		int tscount;
    tag_t
        user;
		char* tsitem;
	tag_t	ccvMstrTag = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t *ClsObjTag = NULLTAG;
	tag_t ClsObj=NULLTAG;
	tag_t *		techspec_objects;
	tag_t *t5_Project=NULLTAG;
	logical modB=FALSE;
	int status_count = 0;
	int structcount=0;
	int cnt		=0;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char NoSubSet[1900] = { 0 };
	char RevMisMatch[19000] = { 0 };
	int p34=0;
	int p3=0;
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	//char RevMisMatch[19000];
 

 printf("inside CM_Check_CmvrTypeNoOfVeh Rule Handler\n");fflush(stdout);
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	//ITK_CALL(QRY_find2("Control Objects...",&ctrlObjQry));
	printf("\n CM_Check_CmvrTypeNoOfVeh attachmentCount = %d\n",attachmentCount);fflush(stdout);
if(attachmentCount>0)
{
	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	{
		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));
		printf("\n CM_Check_CmvrTypeNoOfVeh Object Type = %s\n",obj_type);fflush(stdout);
		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{

						printf("\n inside query \n");fflush(stdout);
		
		
		//platform_rev=tags_found[0];
		char *id;
		char *Solid;
		ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
		//AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id);
		printf("\n Task_id= %s",id);fflush(stdout);

		
		
		//	ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
		ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
		//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );
		printf( "CMHasSolutionItem attachment count:%d\n", count);fflush(stdout);
		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				char *VCClass;
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_string" , &Solid));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
				ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
				printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s",Solid,parttype,VCClass,ccvRevId);fflush(stdout);
				//return;
				
				if(tc_strcmp(parttype,"VC")!=0)
				{
				if(tc_strstr(parttype,"V")!=NULL)
				{
					// if(tc_strstr(ccvRevId,"NR")!=NULL)
					// {
					char *projcode;
					char *DRStatus;
					tag_t  CurrentRoleTag = NULLTAG;
					char       roleName[SA_name_size_c+1];
					char *ClsClass=NULL;
					char *Funcmvrattr=NULL;
					int n=0;
					printf("\n going to create Tech Spec"); fflush(stdout);
							//getting master from itemrev
							CALLAPI(ITEM_ask_item_of_rev(secondary_objects[i],&ccvMstrTag));	
							//find the classified object for above tech Spec
							if(ccvMstrTag)
							{
								//CALLAPI(AOM_ask_value_tags(secondary_objects[i],"IMAN_classification",&cnt,&ClsObjTag));
								CALLAPI(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
								ClsObj=*ClsObjTag;
								printf("\n classified object count[%d] for CCV[%s] !!",cnt,Solid); fflush(stdout);
								if(cnt>0)
								{
									printf("\n classifiction obj found for attached CCV[%s], now going to fetch CMVR TYPE value",Solid); fflush(stdout);

									for(n<0;n<cnt;n++)
									{
										//printObject(ClsObjTag[i]);
										ITK_CALL(AOM_ask_value_string(ClsObjTag[n],"cid" , &ClsClass));
										printf("\n ClsClass= %s",ClsClass);fflush(stdout);
									
										if(ClsClass)
										{
											TS_getCmvrattridItkFunc(ClsClass,&Funcmvrattr);
										printf("\n Funcmvrattr= %s",Funcmvrattr);fflush(stdout);
											if(Funcmvrattr)
											{
												ITK_CALL(TS_getClsValueFrmICSTag( ClsObj , Funcmvrattr,&getAttrVal));
											}
											else
											{
												ITK_CALL(TS_getClsValueFrmICSTag( ClsObj , "8171",&getAttrVal));
											}
										}
									}
									printf("\n getAttrVal[%s] !!",getAttrVal); fflush(stdout);
									
									if(tc_strlen(getAttrVal)>0)
									{
										decision = EPM_go;
									}
									else
									{
										sprintf(ErrMsg,"target VC/CCV[%s] does not have the CMVR Type Value",Solid);
										//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
										printf("\n ErrMsg:: [%s] ",ErrMsg); fflush(stdout);
										
										//Below is commented below with reference CR-FY23-0026
										//EMH_clear_errors();
										//EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
										//decision = EPM_nogo;		// ----Hard check
										//MEM_free(ErrMsg);
										//return decision;
									}

									//return EPM_go;
								}
								else
								{
									sprintf(ErrMsg,"target VC/CCV[%s] does not have the TechSpec",Solid);
									//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
									printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg);
									decision = EPM_nogo;
									MEM_free(ErrMsg);
									return decision;
								}
							}
						
					// }
					// else
					// {
					//	printf("\n NON-NR revision is not eligible to create Tech Spec for Cluster SVR release process"); fflush(stdout);
					// }
				}
			}
			}
			printf("\nCMVR Type value finding against target VC/CCV Rule Handler has completed");fflush(stdout);
  
		}
		
		
		}
		
	}
}
	decision = EPM_go;
	return decision;
}


//End Rule Handler




int TechSpec_register_rule_handlers()
{
	
	TC_write_syslog("going to register TechSpec_register_rule_handlers [CM_Check_ClsObjForTechSpec]..\n");
	EPM_register_rule_handler("CM_Check_ClsObjForTechSpec","Rule handler to check Classification Obj for TechSpec Obj for cluster SVR Release",(EPM_rule_handler_t)CM_Check_ClsObjForTechSpec);
	TC_write_syslog("Registered Rule Handler CM_Check_ClsObjForTechSpec..\n");
	
	TC_write_syslog("going to register TechSpec_register_rule_handlers [CM_Check_CmvrTypeNoOfVeh]..\n");
	EPM_register_rule_handler("CM_Check_CmvrTypeNoOfVeh","Rule handler to check CMVR Type value for taget CCV/Vehicle",(EPM_rule_handler_t)CM_Check_CmvrTypeNoOfVeh);
	TC_write_syslog("Registered Rule Handler CM_Check_CmvrTypeNoOfVeh..\n");
	
	TC_write_syslog("going to register TechSpec_register_rule_handlers [RH_Check_TechSpecDocFile]..\n");
	EPM_register_rule_handler("RH_Check_TechSpecDocFile","Rule handler to check the TechSpec Doc file with Tech Spec header for taget CCV/Vehicle",(EPM_rule_handler_t)RH_Check_TechSpecDocFile);
	TC_write_syslog("Registered Rule Handler RH_Check_TechSpecDocFile..\n");
	
	
	return ITK_ok;
}


//

// Func to getting Vehicle from Tech Spec Object 
extern DLLAPI int tm_getVehfrmallRevTechSpec(tag_t TechSpecObj,tag_t* VehFrmTS)
{

	 printf("\n Start func tm_getVehfrmallRevTechSpec\n");fflush(stdout);
	int ifail = ITK_ok;

	tag_t relType = NULLTAG;
	tag_t* primary_objects = NULL;
	int count=0;
	tag_t itemmstr=NULLTAG;
	int TechSpecRevCnt=0;
                tag_t* TechSpecRevTagObjs = NULLTAG;
                tag_t TechSpecRevTag = NULLTAG;
	ITKCALL(ITEM_ask_item_of_rev(TechSpecObj,&itemmstr));


                ITKCALL(ITEM_list_all_revs (itemmstr, &TechSpecRevCnt, &TechSpecRevTagObjs));
                printf("\n TechSpec Revision counts :%d\n",TechSpecRevCnt);fflush(stdout);
                
                if(TechSpecRevCnt>0)
                {
                                int i=0;

                                for(i=TechSpecRevCnt-1;i>=0;i--)
                                {
                                                TechSpecRevTag = TechSpecRevTagObjs[i];
                                                char* itemId = NULL;
                                                char* partRev = NULL;
                                                char* checkedOut = NULL;
                                                char* rel_status = NULL;
                                                ITKCALL(AOM_ask_value_string(TechSpecRevTag,"item_id",&itemId));
                                                ITKCALL(AOM_ask_value_string(TechSpecRevTag,"item_revision_id",&partRev));
                                                ITKCALL(AOM_UIF_ask_value(TechSpecRevTag, "release_status_list", &rel_status));
                                                
                                                //checked_out
                                                ITKCALL(AOM_UIF_ask_value(TechSpecRevTag,"checked_out",&checkedOut));
                                                printf("\ngetLatest TechSpec object[%d]==>  %s,%s. Checkedout==>%s, Release status==>%s\n",i,itemId,partRev,checkedOut,rel_status);fflush(stdout);
                                                
                                                //Skip the checked out part
                                                if(tc_strcmp(checkedOut, "Y") == 0 )
                                                {
                                                                continue;
                                                }
                                                
                                                //if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
                                                //{
													//setAddTagObj(cnt,partlist,TechSpecRevTag);
													//*partlist=TechSpecRevTag;
													
													
													ITKCALL(GRM_find_relation_type("T5_VCSpec", &relType));

													printf("\n TechSpecRevTag=%u relType=%u\n",TechSpecRevTag,relType);fflush(stdout);
													
													if( relType != NULLTAG )
													{
														ITKCALL(GRM_list_primary_objects_only(TechSpecRevTag,relType,&count,&primary_objects));
														printf("\n TSVehcount=%d \n",count);fflush(stdout);
														if(count > 0)
														{

														*VehFrmTS = primary_objects[0];
														break;
														}

													}
                                                     
                                                //}
                                                
                                                                                
                                }

                }
				else
				{
					 printf("\n No revision found - TechSpecRevCnt[%d]==>",TechSpecRevCnt); fflush(stdout);
					 *VehFrmTS=NULLTAG;
						
				}

	
	return ifail;	

	printf("\n End func tm_getVehfrmallRevTechSpec\n");fflush(stdout);

}

int TechSpecRelValidateFunc( tag_t techspecRevTag,tag_t VcRev)
{
	int ifail = ITK_ok;
	tag_t TSAtchedVehTag=NULLTAG;
	tag_t task_relation_type=NULLTAG;
	tag_t* secondaryobjs=NULLTAG;
	char *TSAtchedVehNo=NULL;
	char *InpVehPrtType=NULL;
	char *inpvehpartDup=NULL;
	char *inpVehNo=NULL;
	char *inpTechNo=NULL;
	char *InpVehAvlblTechNo=NULL;
	//char relation_name[TCTYPE_name_size_c+1];
	char *relation_name=NULL;
	int TScount=0;
	char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));
			printf("\n inside func TechSpecRelValidateFunc\n");fflush(stdout);
				CALLAPI(AOM_ask_value_string(techspecRevTag,"item_id",&inpTechNo));
				printf("\n inpTechNo=%s\n",inpTechNo);fflush(stdout);
				
				CALLAPI(AOM_ask_value_string(VcRev,"item_id",&inpVehNo));
				printf("\n inpVehNo=%s\n",inpVehNo);fflush(stdout);
				if(inpVehNo)
					{
						tc_strdup(inpVehNo,&inpvehpartDup);	
					}
					printf("\n inpvehpartDup=%s\n",inpvehpartDup);fflush(stdout);
				GRM_find_relation_type("T5_VCSpec",&task_relation_type);
				if(task_relation_type != NULLTAG)
					{
						//CALLAPI(TCTYPE_ask_name( task_relation_type, relation_name));
						CALLAPI(TCTYPE_ask_name2( task_relation_type, &relation_name));
						CALLAPI(GRM_list_secondary_objects_only(VcRev,task_relation_type,&TScount,&secondaryobjs));
						printf("\n TScount: %d\n", TScount);fflush(stdout);
						if(TScount>0)
						{
							CALLAPI(AOM_ask_value_string(secondaryobjs[0],"item_id",&InpVehAvlblTechNo));
							printf("\n InpVehAvlblTechNo=%s\n",InpVehAvlblTechNo);fflush(stdout);
							
							sprintf(ErrMsg,"TechSpec[%s] is already available in input VC[%s],more than one TechSpec header not allowed to attach",InpVehAvlblTechNo,inpVehNo);
							printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
							EMH_clear_errors();
							CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
							return ITK_err;
						}
					}

				
				printf("\n Calling func getVehfrmTechSpec\n");fflush(stdout);
			//CALLAPI(getVehfrmTechSpec(techspecRevTag,&TSAtchedVehTag));
			CALLAPI(tm_getVehfrmallRevTechSpec(techspecRevTag,&TSAtchedVehTag));

			printf("\n After func call getVehfrmTechSpec TSAtchedVehTag=%u input VcRev=%u\n",TSAtchedVehTag,VcRev);fflush(stdout);
			
			if(TSAtchedVehTag)
			{
				
				
				CALLAPI(AOM_ask_value_string(TSAtchedVehTag,"item_id",&TSAtchedVehNo));
				printf("\n TSAtchedVehNo=%s\n",TSAtchedVehNo);fflush(stdout);
				
				
				
				CALLAPI(AOM_ask_value_string(VcRev,"t5_PartType",&InpVehPrtType));
			printf("\n MT:InpVehPrtType = [%s] found in DB\n",InpVehPrtType);fflush(stdout);
				
				if(tc_strstr(InpVehPrtType,"VCCR")!=NULL || tc_strcmp(InpVehPrtType,"CCVC")==0||tc_strcmp(InpVehPrtType,"V")==0)
				{
					char *basepart=NULL;
					//char *inpvehpartDup=NULL;
					printf("\n 22inpvehpartDup=%s\n",inpvehpartDup);fflush(stdout);
					if(inpvehpartDup)
					{
					basepart=TS_subString(inpvehpartDup,1,8);
					printf("\n basepart=%s TSAtchedVehNo=%s\n",basepart,TSAtchedVehNo);fflush(stdout);
						if(tc_strstr(TSAtchedVehNo,basepart)!=NULL)
						{
							printf("\n allow to attach TechSpec with CRVC =%s \n",inpvehpartDup);fflush(stdout);
							
						}
						else
						{
							printf("\n input TechSpec [%s] attached to same/diffrent VC/BaseVC[%s] , hence it will not allow to attach TechSpec with same/other CRVC again \n",TSAtchedVehNo,inpvehpartDup);fflush(stdout);
							sprintf(ErrMsg,"Same Tech Spec[%s] can not be relate to same/diffrent VC/CRVC/BaseVC [%s],if TechSpec is already attached to different VC[%s]",inpTechNo,inpvehpartDup,TSAtchedVehNo);
							printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
							EMH_clear_errors();
							CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
							return ITK_err;
						}
					}
				}
				/*
				if(tc_strcmp(InpVehPrtType,"CCVC")==0||tc_strcmp(InpVehPrtType,"V")==0)
				{
					if(tc_strstr(TSAtchedVehNo,inpVehNo)!=NULL)
						{
							printf("\n allow to attach TechSpec with CRVC =%s \n",inpvehpartDup);fflush(stdout);
							
						}
						else
						{					
							printf("\n input TechSpec [%s] attached to same/diffrent VC/BaseVC[%s] if TechSpec is already available to VC, therefore it will not allow to attach TechSpec with same/other VC again \n",inpTechNo,TSAtchedVehNo);fflush(stdout);
			
							sprintf(ErrMsg,"Same Tech Spec[%s] can not be relate to same/diffrent VC/CRVC/BaseVC, if TechSpec is already available to VC[%s]",inpTechNo,TSAtchedVehNo);
							printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
							EMH_clear_errors();
							CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
							return ITK_err;
						}
				}
				*/
			}
			else
			{
				printf("\n allow to attach techspec=%s ,as it is not attached to any other VC/CRVC\n",inpTechNo);fflush(stdout);
			}
			printf("\n End func TechSpecRelValidateFunc\n");fflush(stdout);
	return ifail;
}

int TechSpec4CRVC(char **Info1)
{


    tag_t *cntrlObjSet=NULLTAG;
	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entryCntrl    = 3;
	int ifail=0;
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));	
	int  control_number_found=0;

			printf("\n start func TechSpec4CRVC Calling qry to decide whether this AH will required or not ....\n");
			//if(QRY_find("Control Objects...", &qryTagCntrl));
			if(QRY_find2("Control Objects...", &qryTagCntrl));
			if (qryTagCntrl)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl[0]="TechSpec4CRVC";
				qry_valuesCntrl[1]="Live";
				qry_valuesCntrl[2]="0";
				
				if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntrlObjSet));
			}
			else
			{
				printf("\n Control Object Query not Found .... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
			if(control_number_found>0)
			{
				char *path=NULL;
			printf("\n TechSpec4CRVC is byapssed , this is updating via schedule job with ifail[%d]\n",ifail);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(cntrlObjSet[0],"t5_Userinfo1",&path));
						
						printf("\npath==>%s\n",path);fflush(stdout);
						if(tc_strlen(path)>0)
						{
							*Info1=path;
						}
			
			ifail= control_number_found;
			 return ifail;
			}
		
printf("\n end the function TechSpec4CRVC with ifail [%d]\n",ifail);fflush(stdout);		
return ifail;
}

//CheckTechSpecNoMultiRel_pre_action :- added this post action to give GRM validation during VC to TechSpec Relation
extern DLLAPI int CheckTechSpecNoMultiRel_pre_action(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;
    tag_t primary_object=va_arg(args, tag_t);     /**< (I) Direction-setting object in the relation; 
							it is usually the independent object in the relation. */
    tag_t secondary_object =va_arg(args, tag_t);   /**< (I) This object is usually the dependent object in the relationship */
    tag_t relation_type=va_arg(args, tag_t);      /**< (I) This is a tag of the specified relationship type */
    tag_t user_data=NULLTAG;          		/**< (I) This is a tag that identifies some user data; 
						must be set to #NULLTAG if not used. */
    tag_t* relation=NULLTAG;            /**< (O) Tag of new relation, if successfully created. */
	//tag_t * 	AttachedRefItemObjs =NULLTAG ;
	tag_t VCToTechSpecrelation_type = NULLTAG;
	//tag_t *primaryobjs = NULLTAG;
	tag_t *TechSpecTags = NULLTAG;
	tag_t VehTag=NULLTAG;
	char *item_id=NULL;
    char *item_rev_id=NULL;
    char *item_type=NULL;
	char *Part_type=NULL;
    char *TechSpecNum=NULL;
	char *parttype = NULL;
	char *RefItem_itemid = NULL;
	char *ccvRevId = NULL;
	char *refitem_type = NULL;
	char *dropTechspecNo = NULL;
	char *TechSpecCls = NULL;
	char *TechSpecNo = NULL;
	char *sitem_type = NULL;
	char *b4VehNo     = NULL;
	char *VehNo     = NULL;
	char *ErrMsg = (char *) MEM_alloc(200 * sizeof(char *));
	
	//char *Task2DMLrelationName =NULL;
	//char relation_name[TCTYPE_name_size_c+1];
	char *relation_name=NULL;
	int i =0;
	int count=0;
	int tscount=0;
	tag_t    *TSbypassCntrlObjSet=NULLTAG;
	//t5_PartType
	//CMReferences
	//ITEM_copy_rev = for revise
	printf("\n inside CheckTechSpecNoMultiRel_pre_action function");fflush(stdout);
	//CALLAPI(TCTYPE_ask_name( relation_type, relation_name));
	CALLAPI(TCTYPE_ask_name2( relation_type, &relation_name));
	printf("\n inside CheckTechSpecNoMultiRel_pre_action relation_name[%s]",relation_name);fflush(stdout);
	CALLAPI(getCntrlObj( "TechRelBypass",&tscount ,&TSbypassCntrlObjSet));
	printf("\n inside CheckTechSpecNoMultiRel_pre_action tscount[%d]",tscount);fflush(stdout);
	if(tscount>0)
	//if(tscount<=0)
	{
	if(tc_strcmp(relation_name,"T5_VCSpec")==0)
	{	
		if(primary_object)
		{
		AOM_ask_value_string(primary_object,"object_type",&item_type);
		printf("\n CheckTechSpecNoMultiRel_pre_action:: type_name = %s\n", item_type);fflush(stdout);
		AOM_ask_value_string(primary_object,"item_id",&b4VehNo);
		printf( "\n CheckTechSpecNoMultiRel_pre_action::item_save_pre_action - item_id: %s\n", b4VehNo);fflush(stdout);
		}
		
		printf("\nbefore getting Tech Spec info for secondary_object");fflush(stdout);
		if(secondary_object)	
		{
			sitem_type=NULL;
			AOM_ask_value_string(secondary_object,"object_type",&sitem_type);
			printf("\n CheckTechSpecNoMultiRel_pre_action::Parttype_name = %s\n", sitem_type);fflush(stdout);
			//AOM_ask_value_string(secondary_object,"t5_PartType",&Part_type);
			//printf("\n CheckTechSpecNoMultiRel_pre_action::Part_type = %s\n", Part_type);fflush(stdout);
			AOM_ask_value_string(secondary_object,"item_id",&dropTechspecNo);
			printf("\n CheckTechSpecNoMultiRel_pre_action::item_save_pre_action - Partitem_id: %s\n", dropTechspecNo);fflush(stdout);
			//AOM_ask_value_string(secondary_object,"item_revision_id",&item_rev_id);
			//printf("\n CheckTechSpecNoMultiRel_pre_action::item_save_pre_action - Partitem_rev_id: %s\n", item_rev_id);fflush(stdout);
			//count=0;
			
			if(tc_strcmp(sitem_type,"T5_TSCompRevision")!=0)
			{
				sprintf(ErrMsg,"Secondary class is not valid to VC Spec Relation ,secondary must be Technical specification revision only, you are creating relation with [%s]",sitem_type);
				//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
				printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
				EMH_clear_errors();
				CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
				return ITK_err;
			}
			/*if(tc_strcmp(item_type,"T5_TSComp")==0)
			{
				sprintf(ErrMsg,"Tech Spec Master does not valid to attach with Vehicle/CCVC, Tech Spec Revision only allowed to make relation with VC [%s]",b4VehNo);
				//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
				printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
				EMH_clear_errors();
				CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
				return ITK_err;
			}
			*/
		
			/*printf("\n Calling func getVehfrmTechSpec\n");fflush(stdout);
			ITK_CALL(getVehfrmTechSpec(secondary_object,&VehTag));
			printf("\n After func call getVehfrmTechSpec VehTag=%u\n",VehTag);fflush(stdout);
			if(VehTag)
			{
				AOM_ask_value_string(VehTag,"item_id",&VehNo);
				printf("\n VehNo=%s ",VehNo);fflush(stdout);
				if(tc_strstr(b4VehNo,VehNo)!=NULL)
				{
					//OK
					printf("\n valid VehNo =%s for TechSpec [%s]",VehNo,dropTechspecNo);fflush(stdout);
				}
				else
				{
					sprintf(ErrMsg,"Single Tech Spec can not be relate to multiple VC [%s]",dropTechspecNo);
					//EMH_store_error_s2(EMH_severity_error,ITK_err,"Tech Spec has not been classified,so update the classified value first for TechSpec[%s]",tsitem);
					printf("\n ErrMsg[%s] ",ErrMsg); fflush(stdout);
					EMH_clear_errors();
					CALLAPI(EMH_store_error_s1(EMH_severity_error,ITK_err,ErrMsg));
					return ITK_err;
				}
			}
			*/
			
			char* username;
					tag_t user_tag=NULLTAG;

					//POM_get_user(&username,&user_tag);
					CALLAPI(POM_get_user_id (&username));
					printf("\n\n  username : %s\n",username); fflush(stdout);
					
						int count=0;
						tag_t    *TSbypassCntrlObjSet=NULLTAG;
						char *bypassuser=NULL;
						CALLAPI(getCntrlObj( "ByPassUser",&count,&TSbypassCntrlObjSet));
						printf("\n after ByPassUser count[%d]",count);fflush(stdout);
						if(count>0)
						{
							CALLAPI(AOM_ask_value_string(TSbypassCntrlObjSet[0],"t5_Syscd",&bypassuser));
						}
						printf("\n  bypassuser[%s]",bypassuser);fflush(stdout);

				if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0)  && (tc_strcmp(username,bypassuser)!=0))
				{
					printf("\n Calling func TechSpecRelValidateFunc\n");fflush(stdout);
					CALLAPI(TechSpecRelValidateFunc(secondary_object,primary_object));
					printf("\n after func TechSpecRelValidateFunc call successfully\n");fflush(stdout);
				}
				else
				{
					printf("\n Allow to attach multiple TechSpec with single VC by bypassed user =%s\n",username);fflush(stdout);
				}
			
		}
			
	
		
	}
}
	printf("\n End of CheckTechSpecNoMultiRel_pre_action function\n");fflush(stdout);
	
return ifail;
}


extern DLLAPI int ReviseTechSpec_Add_CMHasSolutionItem_post_action(METHOD_message_t *m, va_list args)
{
	int ifail=ITK_ok;
    tag_t primary_object=va_arg(args, tag_t);     /**< (I) Direction-setting object in the relation; 
							it is usually the independent object in the relation. */
    tag_t secondary_object =va_arg(args, tag_t);   /**< (I) This object is usually the dependent object in the relationship */
    tag_t relation_type=va_arg(args, tag_t);      /**< (I) This is a tag of the specified relationship type */
    tag_t user_data=NULLTAG;          		/**< (I) This is a tag that identifies some user data; 
						must be set to #NULLTAG if not used. */
    tag_t* relation=NULLTAG;            /**< (O) Tag of new relation, if successfully created. */
	tag_t * 	AttachedRefItemObjs =NULLTAG ;
	tag_t task_relation_type = NULLTAG;
	tag_t *primaryobjs = NULLTAG;
	tag_t *ERCDmlObjTags = NULLTAG;
	tag_t TechSpecObjTag = NULLTAG;
	tag_t  RefItemsRelTypeTag=NULLTAG;
	tag_t  SolItemsRelTypeTag=NULLTAG;
	tag_t	Task2DMLrelation_type=NULLTAG;
	tag_t	*ccvTags					=	NULLTAG;
	tag_t relationTag = NULLTAG;
	tag_t TSItemLatRev = NULLTAG;
	tag_t NewRevTSTag = NULLTAG;
	tag_t	Task_tag		= NULLTAG;
	tag_t	Ltst_Task_tag		= NULLTAG;
	tag_t	TSrelation_tag		= NULLTAG;
	tag_t* TSbypassCntrlObjSet=NULLTAG;
	char *item_id=NULL;
    char *item_rev_id=NULL;
    char *item_type=NULL;
	char *Part_type=NULL;
    char *TechSpecNum=NULL;
	char *parttype = NULL;
	char *RefItem_itemid = NULL;
	char *ccvRevId = NULL;
	char *refitem_type = NULL;
	//char *CMHasSolitem_type = NULL;
	char *ERCDMLCls = NULL;
	char *ErcDmlNo = NULL;
	char *DMLrlstype = NULL;
	char *b4taskid     = NULL;
	char *taskid     = NULL;
	//char *Task2DMLrelationName =NULL;
	//char relation_name[TCTYPE_name_size_c+1];
	char *relation_name=NULL;
	int i =0;
	int count=0;
	int refcount=0;
	int TScount=0;
	//t5_PartType
	//CMReferences
	//ITEM_copy_rev = for revise
	printf("\n*******************************inside ReviseTechSpec_Add_CMHasSolutionItem_post_action method***********************");fflush(stdout);
	int bypasscnt=0;
	printf("\n inside ReviseTechSpec_Add_CMHasSolutionItem_post_action ");fflush(stdout);
	CALLAPI(getCntrlObj("TechSpecAutoRev4RefFldrByPass",&bypasscnt ,&TSbypassCntrlObjSet));
	printf("\n inside ReviseTechSpec_Add_CMHasSolutionItem_post_action bypasscnt[%d]",bypasscnt);fflush(stdout);
	if(bypasscnt>0)
	{
		printf("\n Auto Revise Tech Spec header during reference folder attachment is bypassed. ");fflush(stdout);
		return ifail;
	}
	
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&SolItemsRelTypeTag));
	// if(RefItemsRelTypeTag)
	// {
		// AOM_ask_value_string(RefItemsRelTypeTag,"object_type",&refitem_type);
	// }
	
	// if(SolItemsRelTypeTag)
	// {
		// AOM_ask_value_string(SolItemsRelTypeTag,"object_type",&CMHasSolitem_type);
	// }
	// printf("\n CMHasSolitem_type=%s ",CMHasSolitem_type);fflush(stdout);
	
	
	ITK_CALL(AOM_ask_value_tags(primary_object,"CMReferences",&refcount,&ccvTags));
	printf("\nNo of  ccv/svr attached with DML : %d",refcount);fflush(stdout);
	
	
	AOM_ask_value_string(primary_object,"object_type",&item_type);
    printf("\n ReviseTechSpec_Add_CMHasSolutionItem_post_action:: type_name = %s\n", item_type);fflush(stdout);
    AOM_ask_value_string(primary_object,"item_id",&b4taskid);
    printf( "\n ReviseTechSpec_Add_CMHasSolutionItem_post_action::item_save_pre_action - item_id: %s\n", b4taskid);fflush(stdout);
	
	//Steps to get ERC DML & check release type
	GRM_find_relation_type("T5_DMLTaskRelation",&Task2DMLrelation_type);
	// if(Task2DMLrelation_type)
	// {
		// AOM_ask_value_string(Task2DMLrelation_type,"object_type",&Task2DMLrelationName);
	// }
	// printf("\n Task2DMLrelationName=%s ",Task2DMLrelationName);fflush(stdout);
	CALLAPI(GRM_list_primary_objects_only(primary_object,Task2DMLrelation_type,&count,&ERCDmlObjTags ));
	if(count>0)
	{
		CALLAPI(AOM_ask_value_string( ERCDmlObjTags[0], "t5_rlstype", &DMLrlstype));
		CALLAPI(AOM_ask_value_string( ERCDmlObjTags[0], "item_id", &ErcDmlNo));
		CALLAPI(AOM_ask_value_string(ERCDmlObjTags[0],"object_type" , &ERCDMLCls));
	}
	printf("\n ERCDMLCls=%s DMLrlstype[%s] ErcDmlNo[%s] \n",ERCDMLCls,DMLrlstype,ErcDmlNo);fflush(stdout);
	if(tc_strstr(DMLrlstype,"VCMDU")!=NULL)
	{	
	printf("\n*******************************Part Revision***********************");fflush(stdout);
	AOM_ask_value_string(secondary_object,"object_type",&item_type);
    printf("\n ReviseTechSpec_Add_CMHasRefItem_post_action::Parttype_name = %s\n", item_type);fflush(stdout);
	if(tc_strstr(item_type,"Design Revision")!=NULL)
	{
	AOM_ask_value_string(secondary_object,"t5_PartType",&Part_type);
    printf("\n ReviseTechSpec_Add_CMHasRefItem_post_action::Part_type = %s\n", Part_type);fflush(stdout);
    AOM_ask_value_string(secondary_object,"item_id",&item_id);
    printf("\n ReviseTechSpec_Add_CMHasRefItem_post_action::item_save_pre_action - Partitem_id: %s\n", item_id);fflush(stdout);
    AOM_ask_value_string(secondary_object,"item_revision_id",&item_rev_id);
    printf("\n ReviseTechSpec_Add_CMHasRefItem_post_action::item_save_pre_action - Partitem_rev_id: %s\n", item_rev_id);fflush(stdout);
	}
	count=0;
	
	ITK_CALL(ITEM_find_item(b4taskid, &Task_tag));
	ITK_CALL(ITEM_ask_latest_rev(Task_tag, &Ltst_Task_tag));
	AOM_ask_value_string(Ltst_Task_tag,"item_id",&taskid);
	printf("\n taskid=%s ",taskid);fflush(stdout);
	//ITK_CALL(GRM_find_relation_type("CMReferences",&RefItemsRelTypeTag));
	ITK_CALL(AOM_ask_value_tags(Ltst_Task_tag,"CMReferences",&refcount,&ccvTags));
	//AOM_ask_value_string(RefItemsRelTypeTag,"object_type",&refitem_type);
	printf("\n refcount=%d",refcount);fflush(stdout);
	//CALLAPI(GRM_list_secondary_objects_only(Ltst_Task_tag,RefItemsRelTypeTag,&count,&AttachedRefItemObjs ));
	 printf("\n count=%d ",count);fflush(stdout);
		// if(refcount>0)
		// {
			// for(i=0;i<refcount;i++)
			// {
				// char *VCClass;
				// CALLAPI(AOM_ask_value_string(ccvTags[i],"object_string" , &RefItem_itemid));
				// CALLAPI(AOM_ask_value_string(ccvTags[i],"t5_PartType" , &parttype));
				// CALLAPI(AOM_ask_value_string(ccvTags[i],"object_type" , &VCClass));
				// CALLAPI(AOM_ask_value_string(ccvTags[i],"item_revision_id" , &ccvRevId));
				// printf("\n RefItem_itemid = %s parttype=%s VCClass=%s ccvRevId=%s",RefItem_itemid,parttype,VCClass,ccvRevId);fflush(stdout);
				//return;
				
				
				//if(tc_strstr(Part_type,"V")!=NULL)
				if(tc_strcmp(Part_type,"V")==0 || tc_strcmp(Part_type,"CCVC")==0)
				{
					GRM_find_relation_type("T5_VCSpec",&task_relation_type);
					
					tag_t  CurrentRoleTag = NULLTAG;
					//char       roleName[SA_name_size_c+1];
					char       *roleName=NULL;

					CALLAPI(SA_ask_current_role(&CurrentRoleTag)); 
					//CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName));
					CALLAPI(SA_ask_role_name2(CurrentRoleTag,&roleName));
					printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
					
					char* username;
					tag_t user_tag=NULLTAG;

					//POM_get_user(&username,&user_tag);
					CALLAPI(POM_get_user_id (&username));
					printf("\n\n  username : %s\n",username); fflush(stdout);
					
						int count=0;
						tag_t    *TSbypassCntrlObjSet=NULLTAG;
						char *bypassuser=NULL;
						CALLAPI(getCntrlObj( "ByPassUser",&count,&TSbypassCntrlObjSet));
						printf("\n after ByPassUser count[%d]",count);fflush(stdout);
						if(count>0)
						{
							CALLAPI(AOM_ask_value_string(TSbypassCntrlObjSet[0],"t5_Syscd",&bypassuser));
						}
						printf("\n  bypassuser[%s]",bypassuser);fflush(stdout);
					
					if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,bypassuser)!=0))
					{
						//return ifail;
					
					
					if(task_relation_type != NULLTAG)
					{
						//CALLAPI(TCTYPE_ask_name( task_relation_type, relation_name));
						CALLAPI(TCTYPE_ask_name2( task_relation_type, &relation_name));
						CALLAPI(GRM_list_secondary_objects_only(secondary_object,task_relation_type,&TScount,&primaryobjs));
						printf("\n TScount: %d\n", TScount);fflush(stdout);
						if(TScount>0)
						{
							TechSpecObjTag=primaryobjs[0];
							printf("\n*******************************DML Revision***********************");fflush(stdout);
							AOM_ask_value_string(TechSpecObjTag,"item_id",&TechSpecNum);
							printf("\n TechSpecNum: %s\n", TechSpecNum);fflush(stdout);
							char* checkedOut = NULL;
                            char* rel_status = NULL;
							tag_t *relStatus_list = NULLTAG;
							int RlzStatusCnt=0;
							int RlzRevFlag=0;
							int ss=0;
						CALLAPI(AOM_UIF_ask_value(TechSpecObjTag, "release_status_list", &rel_status))
						
						//CALLAPI(WSOM_ask_release_status_list(TechSpecObjTag, &RlzStatusCnt, &relStatus_list));
						//printf("  RlzStatusCnt: %d",RlzStatusCnt);	fflush(stdout);
						//if (RlzStatusCnt > 0)
						//{
							//RlzRevFlag=0;
							//for(ss=0; ss<RlzStatusCnt ; ss++)
							//{
                        // if(AOM_ask_value_string(relStatus_list[ss],"object_name",&rel_status)!=ITK_ok)PrintErrorStack();
						printf("  rel_status: %s",rel_status);fflush(stdout);                       
						//checked_out
					//	CALLAPI(AOM_UIF_ask_value(TechSpecObjTag,"checked_out",&checkedOut));
						printf("\nTechSpecNum object[%s] Checkedout==>%s, Release status==>%s\n",TechSpecNum,checkedOut,rel_status);fflush(stdout);
						
						//Skip the checked out part
							// if(tc_strcmp(checkedOut, "Y") == 0 )
							// {
											// continue;
							// }
						
								if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
								{	
									//ITKCALL(ITEM_ask_latest_rev(primaryobjs[0],&TSItemLatRev));
									ITKCALL(ITEM_copy_rev(TechSpecObjTag,NULL,&NewRevTSTag));
									if(NewRevTSTag)
									{
										printf("\n Tech Spec [%s] Revised has done successfully  \n", TechSpecNum);fflush(stdout);
										ITKCALL(AOM_refresh(NewRevTSTag,0));
										printf("\n Inside CMHasSolutionItem Create rel between Task & TechSPec");fflush(stdout);
										ifail = GRM_create_relation(primary_object, NewRevTSTag, SolItemsRelTypeTag,NULLTAG, &relationTag);
										ifail = GRM_save_relation(relationTag);
										printf("\n After CMHasSolutionItem Create rel between Task & TechSPec");fflush(stdout);
										
										printf("\n Inside T5_VCSpec Create rel between CCV & latest revised TechSPec");fflush(stdout);
										//delete old techspec relation from ccv 
										TSrelation_tag=NULLTAG;
										CALLAPI(GRM_find_relation(secondary_object, TechSpecObjTag, task_relation_type, &TSrelation_tag));
										if(TSrelation_tag != NULLTAG)
										{
											ITKCALL(GRM_delete_relation(TSrelation_tag));
										}
										//End delete 
										//Start Create Relation
										relationTag=NULLTAG;
										ifail = GRM_create_relation(secondary_object, NewRevTSTag, task_relation_type,NULLTAG, &relationTag);
										ifail = GRM_save_relation(relationTag);
										printf("\n After CMHasSolutionItem Create rel between Task & TechSPec");fflush(stdout);
										
										
										//start status assign process
										if(NewRevTSTag)
										{
											char *Release_status = NULL;
											tag_t rel_status		   = NULLTAG;
											logical retain_released_date= TRUE;
											//ITK_CALL (CR_create_release_status("T5_LcsWorking",&rel_status));
											//ITK_CALL(EPM_add_release_status(rel_status,1,&NewRevTSTag ,retain_released_date));
											
											ITK_CALL(RELSTAT_create_release_status("T5_LcsWorking",&rel_status)); //similar new API for Teamcenter14
												if(rel_status)
												ITK_CALL(RELSTAT_add_release_status(rel_status,1,&NewRevTSTag,retain_released_date));  
											ITK_CALL(AOM_UIF_ask_value(NewRevTSTag,"release_status_list",&Release_status));
											printf ( "\nRelease_status_TechSpec : [%s]", Release_status ) ; fflush ( stdout) ;

										}			
										//End status assign process				
										//End
									}
								}
						//}
					//}
						}
					}
				}
				}
			}
		// }
		// else
		// {
			// printf("\n inside the else of ReviseTechSpec_Add_CMHasRefItem_post_action count=%d ",count);fflush(stdout);
		// }
	//}
	printf("\n End of ReviseTechSpec_Add_CMHasRefItem_post_action function\n");fflush(stdout);
	
return ifail;
}


//start Dynamic LOV process for datamining

		
/*dynamic generation of list of Major models available for TechSpec VC class */
/****************************************************************************
Function:       dynamic_TSMajModLovs
Description:    This function used dynamic generation of Major models available for TechSpec VC class to populate Major model LOV
Input:          None
Output:         None
Return value:   None
****************************************************************************/
static int dynamic_TSMajModLovs( char*** TSMajModLovVals) 
{

/* va_list for LOV_ask_values_msg */

 
	char   *user_name_string = NULL;
	int status;
	int j =0;
	tag_t*		list_of_WSO_cntrl_tags=NULLTAG;
	char  ***values = NULL;
	int        control_number_found;
	WSO_search_criteria_t  	criteria_control;
	int  ifail = ITK_ok;
	int max_char_size = 50;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t			group_tag			= NULLTAG;
	char *TSMajModDefaultVal = NULL;
	tag_t			*RetContrlObjs				=NULLTAG;
	int   n_found=0;
	//char				userid[SA_user_size_c+1]; 
	char				*userid=NULL; 
	char *TSMajModattrID=NULL;
	//Version =	  MEM_alloc(50000);
	tag_t  user = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	char *CmvrInitiatorUsr = NULL;
	int Lov_cnt=0;
	char *VCAttrNo=(char *) MEM_alloc(10 * sizeof(char *));
	char *VCattrList[500];
	//inpattrId =0;
	int p=0;
	   printf("\n inside func dynamic_TSMajModLovs");fflush(stdout);

		CALLAPI(SA_init_module());
		printf("\n SA_init_module");fflush(stdout);
		CALLAPI(POM_get_user(&user_name_string, &user));
		printf("\n POM_get_user");fflush(stdout);

	//set default value
	
	CALLAPI(getcntrlobjR( "TSMajModAttrList",&n_found ,&RetContrlObjs));  //SUBSYSCD=TSMajModDefVal
	printf("\n TSMajModDefaultVal n_found: %d\n",n_found);fflush(stdout);
	if(n_found>0)
	{
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo1", &TSMajModattrID);
		printf("\n TSMajModattrID: %s\n",TSMajModattrID);fflush(stdout);
		AOM_ask_value_string( RetContrlObjs[0], "t5_Userinfo2", &TSMajModDefaultVal);
		printf("\n TSMajModDefaultVal: %s\n",TSMajModDefaultVal);fflush(stdout);
		if(TSMajModDefaultVal)
		{
		setAddStrR(&Lov_cnt,TSMajModLovVals,TSMajModDefaultVal);
		}
	}
	//End
	//getLovValueFunc(char *key_lov_id,char*** TSMajModLovVal)
if(tc_strlen(TSMajModattrID)>0)
{
	
								VCAttrNo=strtok(TSMajModattrID,",");
								printf("inside strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
								p=0;
								 while (VCAttrNo != NULL)
								{
									printf("inside next strtok VCAttrNo=%s\n",VCAttrNo); fflush(stdout);
									VCattrList[p++] = VCAttrNo;
									VCAttrNo = strtok (NULL, ",");
									printf("\n2inside next strtok VCAttrNo=%s",VCAttrNo); fflush(stdout);
								}
								
							
}
int x=0;
char *tmpattrnostr=NULL;
int majmodattrint=0;
char atrid[10];

	for(x=0;x<p;x++)
	{
		printf("inside strtok VCattrList[x]=%s\n",VCattrList[x]); fflush(stdout);
		tmpattrnostr=VCattrList[x];
		printf("inside strtok tmpattrnostr=%s\n",tmpattrnostr); fflush(stdout);
		tc_strcpy(atrid,tmpattrnostr);			
			majmodattrint=atoi(tmpattrnostr);
			printf("inside strtok majmodattrint=%d",majmodattrint); fflush(stdout);


		char * 	key_lov_name;
		int  	options;
		//int i=0;
		int keyfound=0;
		int  	n_lov_entries;
		char ** 	lov_keys;
		char ** 	lov_values;
		logical * 	deprecated_staus;
		char * 	owning_site;
		int  	n_shared_sites;
		char ** 	shared_sites ;
		char * 	ClsAttrName=NULL;
		char *	ClsAttrshortName=NULL;
		char * 	ClsAttrUnit=NULL;
		int  	ClsAttrFormat=0;
				
				
				printf("\n  before ICS_describe_unct majmodattrint=%d",majmodattrint); fflush(stdout);
				CALLAPI(ICS_describe_unct(majmodattrint,&ClsAttrName,&ClsAttrshortName,&ClsAttrUnit,&ClsAttrFormat));
				printf("\n After ICS_describe_unct ifail[%d]",ifail); fflush(stdout);
				if(ifail != ITK_ok)
				{
				printf("\n  inpattrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",majmodattrint,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);						
				return ifail;	
				}
				printf("\n 2 inpattrId[%d] ClsAttrName[%s] ClsAttrshortName[%s] ClsAttrUnit[%s] ClsAttrFormat[%d]",majmodattrint,ClsAttrName,ClsAttrshortName,ClsAttrUnit,ClsAttrFormat); fflush(stdout);
				 char theKeyLOVId[10];
				//const char * 	key_lov_id;
				char * 	key_lov_id;
				if(ClsAttrFormat)
				{
								
					sprintf(theKeyLOVId, "%d", ClsAttrFormat);
					key_lov_id=theKeyLOVId;	
					printf("\n  key_lov_id[%s] theKeyLOVId[%s] ",key_lov_id,theKeyLOVId); fflush(stdout);
				}
			   printf("\n inside getLovValueFunc input key_lov_id=%s",key_lov_id ); fflush(stdout);
			   CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
					//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
					printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
					int lastkeyno=0;
					int intkeyset[n_lov_entries+1];
					int *arr;
					int n=0;
					if(n_lov_entries>0)
					{
						for(i=0;i<n_lov_entries;i++)								
						{
							printf("\n going to add Major model LOVs for attrid [%s] lov_keys=%s lov_values=%s",key_lov_id,lov_keys[i],lov_values[i]); fflush(stdout);
							
							setAddStrR(&Lov_cnt,TSMajModLovVals,lov_values[i]);
							
							
							
						}
					}
	
	
	}
				
 printf("\n End func dynamic_TSMajModLov !!");fflush(stdout);		
//end by Rajesh

    return Lov_cnt;
}



/****************************************************************************
Function:       dynamic_TSMajModLovMethod
Description:    This function used to register method for dynamic_TSMajModLovs
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_TSMajModLovMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_num_of_values_msg */
    tag_t lov_tag = va_arg (args, const tag_t); 
    int    *length = va_arg(args, int*); 
	
	
    char  **TSMajModLovVals=NULL;
  
    int ifail = ITK_ok;
   
  
   printf("\n inside dynamic_TSMajModLovMethod process	");fflush(stdout);
  //int attrid=6001; //here logic need to build for runtime value get for VC class from form
  *length=dynamic_TSMajModLovs(&TSMajModLovVals);
  printf("\n dynamic_TSMajModLovMethod with lov length===>[%d]",*length);fflush(stdout);
  
 
    return ifail; 
}

/****************************************************************************
Function:       dynamic_TSMajMod_ValuesMethod
Description:    This function used to get CMVR Initiator Value method
Input:          None
Output:         None
Return value:   None
****************************************************************************/

static int dynamic_TSMajMod_ValuesMethod( METHOD_message_t *msg, va_list  args ) 
{
    /* va_list for LOV_ask_values_msg */

               logical active = TRUE;
               tag_t lov_tag = va_arg (args, const tag_t); 
    int*  n_values = va_arg(args, int*); 
    char  ***values = va_arg(args, char***); 

    
    int   ifail = ITK_ok, ii = 0;
   
    char** LR_LovValue;
               int Lov_cnt=0;
   
  
                printf("\n inside dynamic_TSMajMod_ValuesMethod method");fflush(stdout);
                 //int majmodattrid=6001;
                *n_values=dynamic_TSMajModLovs(&LR_LovValue);
               printf("\n dynamic_pos_ValuesMethod==>[%d]",*n_values);fflush(stdout);
				*values = (char **) MEM_alloc (*n_values * sizeof (char*));
				//printf("\n memory allocated for *values" );fflush(stdout);
               memset (*values, 0,  *n_values * sizeof(char*));
			  // printf("\n memset memory allocated for *values with *n_values size[%d]",*n_values );fflush(stdout);
               for (ii = 0; ii < *n_values; ii++)
               { 
                               //printf("\n inside loop to new memory allocated for *values" );fflush(stdout);                                                          
                              (*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
							   //printf("\n after new memory allocated for *values" );fflush(stdout);    
                              tc_strcpy ((*values)[ii], LR_LovValue[ii]);
							  //printf("\n after dynamic lov copied to *values" );fflush(stdout);
                                                               
               } 
      printf("\n End of func dynamic_TSMajMod_ValuesMethod with ifail val[%d]",ifail );fflush(stdout);           
    return ifail; 
}

//End Dynamic LOV process for datamining


extern int TechSpec_register_methods(int *decision, va_list args)
{
                            

         printf("\n Start  *****TechSpec_register_methods\n");fflush(stdout);       
                 int ifail = ITK_ok;
                 METHOD_id_t  method1;
				METHOD_id_t  method2;
                METHOD_id_t  method3; 
				METHOD_id_t  method_TSRevise; 
                METHOD_id_t tsCheckOutMethod;
				METHOD_id_t TechSpec_item_create;
				METHOD_id_t methodMajModLovpos;
				METHOD_id_t methodMajModLovpos1;
                 *decision = ALL_CUSTOMIZATIONS;
				
				 //Registering Action handler with method which will build with same tm_techspec.so
				 ERROR_CHECK(TechSpec_register_action_handlers());
				 //End Action handler 
				 
				 //Registering Rule handler with method which will build with same tm_techspec.so
				 ERROR_CHECK(TechSpec_register_rule_handlers());
				 //End Rule handler 
				 
				 //Start Method registering 
				 
				 ifail=(METHOD_find_method("T5_TSComp", "ITEM_create", &TechSpec_item_create));
			
			if (TechSpec_item_create.id != 0)
			{	
				 printf("\n  before Rigister TechSpec_item_create\n");fflush(stdout);    
				TC_write_syslog("\n before Rigister TechSpec_item_create");
				ERROR_CHECK(METHOD_add_action(TechSpec_item_create,METHOD_post_action_type,(METHOD_function_t)T5TechSpecCre_post,NULL));
				TC_write_syslog("\n IN After Rigister TechSpec_item_create");
				 printf("\n  End Rigister TechSpec_item_create\n");fflush(stdout);   
			}
			else
			{
				printf("\n failed to Rigister TechSpec_item_create  == NULL");fflush(stdout);
			}
               ERROR_CHECK(METHOD_find_method("T5_TSComp", "IMAN_save", &method1));
			   printf("\n  *****METHOD_find_method\n");fflush(stdout);    

			   printf("\n TMML.c: MyType:method - ");fflush(stdout);			   
				if (method1.id != 0)
				{
					
					TC_write_syslog("\n  *****b4 T5TechSpecCre_Validation METHOD_add_pre_action\n");    
					ERROR_CHECK( METHOD_add_action(method1, METHOD_pre_action_type,(METHOD_function_t) T5TechSpecCre_pre, NULL));
					TC_write_syslog("\n  *****After T5TechSpecCre_Validation_pre METHOD_add_action\n");
					
					TC_write_syslog("\n  *****b4 METHOD_T5TechSpecCre_savepost add_Post_action\n");    
					//ERROR_CHECK( METHOD_add_action(method1, METHOD_post_action_type,(METHOD_function_t) T5TechSpecCre_savepost, NULL));
					TC_write_syslog("\n  *****After T5TechSpecCre_savepost  METHOD_add_action\n"); 		  

					
					
				}
				else
				{
					printf("\n failed to Rigister T5TechSpecCre_pre  == NULL");fflush(stdout);
				}
				

			//ERROR_CHECK(METHOD_find_method("T5_TSComp", "ITEM_create_msg", &TechSpec_item_create));
			
			
			
				//TC_write_syslog("\n  *****b4 METHOD_add_Post_action:ReviseTechSpec_Add_CMHasSolutionItem_post_action\n");   
			ifail = (METHOD_find_method("CMReferences", "GRM_create", &method2));
			if (method2.id != 0)
			{
				TC_write_syslog("\n  *****b4 METHOD_add_Post_action:ReviseTechSpec_Add_CMHasSolutionItem_post_action\n");
				ifail = (METHOD_add_action(method2, METHOD_post_action_type,(METHOD_function_t)ReviseTechSpec_Add_CMHasSolutionItem_post_action,NULL));
				TC_write_syslog("\n  *****After METHOD_add_Post_action:ReviseTechSpec_Add_CMHasSolutionItem_post_action\n");
			}
			else
			{
				printf("\n failed to register METHOD_add_Post_action:ReviseTechSpec_Add_CMHasSolutionItem_post_action  == NULL");fflush(stdout);
			}
									
			
			
			
				
			ifail = (METHOD_find_method("T5_VCSpec", "GRM_create", &method3));
			if (method3.id != 0)
			{
				TC_write_syslog("\n  *****b4 METHOD_add_Pre_action:CheckTechSpecNoMultiRel_pre_action\n");   
				ifail = (METHOD_add_action(method3, METHOD_pre_action_type,(METHOD_function_t)CheckTechSpecNoMultiRel_pre_action,NULL));
				TC_write_syslog("\n  *****After METHOD_add_Pre_action:CheckTechSpecNoMultiRel_pre_action\n");
			}
			else
			{
				printf("\n failed to register METHOD_add_Post_action:CheckTechSpecNoMultiRel_pre_action  == NULL");fflush(stdout);
			}
									
			
			
				
				//Hashed on 07/06/2024 as vaidation need to shift to Pre action
				// if (method3.id != NULLTAG)
				// {
					// printf("\n  *****b4 METHOD_add_Post_action:CheckTechSpecNoMultiRel_post_action\n");fflush(stdout);   
					// ifail = (METHOD_find_method("T5_VCSpec", "GRM_create", &method3));
					// if (method3.id != NULLTAG)
					// {
						// ifail = (METHOD_add_action(method3, METHOD_post_action_type,(METHOD_function_t)CheckTechSpecNoMultiRel_post_action,NULL));
					// }
					// printf("\n  *****After METHOD_add_Post_action:CheckTechSpecNoMultiRel_post_action\n");fflush(stdout);					
				// }
				
				
	 // CALLAPI(METHOD_find_method("T5_TSCompRevision", "ITEM_copy_rev", &method_TSRevise));
	 // if (method_TSRevise.id != NULLTAG)
    // {
        // CALLAPI(METHOD_add_action(method_TSRevise, METHOD_pre_action_type,(METHOD_function_t)Revise_Pre_Action_TechSpecRev,NULL));
		// TC_write_syslog("\n\nAfter Register Revise_Pre_Action_TechSpecRev\n");
		// printf("\n Registered as Revise_Pre_Action_TechSpecRev for Creation \n");fflush(stdout);
    // }
	// else
	// {
		// printf("\n Method Revise_Pre_Action_TechSpecRev not found! \n");fflush(stdout);
	// }
        
	
	
				//printf("\n  b4 METHOD_register_prop_method register\n");fflush(stdout); 		
				ERROR_CHECK(METHOD_register_prop_method("T5_TSCompRevision", "t5_TechSpecForPart",  PROP_ask_value_tag_msg, getVehRelationFrmTS, 0,  &method2 ));
				//printf("\n  After METHOD_register_prop_method register\n");fflush(stdout); 
				TC_write_syslog("\n  b4 METHOD_register_method for dynamic_TSMajModLovMethod \n"); 
		ITKCALL(METHOD_register_method( "T5_TSMajModDLov",LOV_ask_values_msg,&dynamic_TSMajMod_ValuesMethod, 0,&methodMajModLovpos));		
		ITKCALL(METHOD_register_method( "T5_TSMajModDLov",LOV_ask_num_of_values_msg,&dynamic_TSMajModLovMethod,0,&methodMajModLovpos1));
		TC_write_syslog("\n  After METHOD_register_method for dynamic_TSMajModLovMethod \n");			
return ifail;
}

//End


//Start for LOV Update option

int IcsLovUpdateServiceCall(void *retValue)
{
		const char				*prog_name 		="IcsLovUpdateServiceCall";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* LOVId  = NULL;
		char* insrtKey = NULL;
		int NoOfKeyToBeAdd = 0;
		char** keyOfLov = NULL;
		char** LovValue = NULL;		
		USERARG_get_string_argument(&LOVId); 
		USERARG_get_string_argument(&insrtKey);
		USERARG_get_int_argument(&NoOfKeyToBeAdd); 
		USERARG_get_string_array_argument(&array_size,&keyOfLov);	
		USERARG_get_string_array_argument(&array_size,&LovValue);
		printf("\nInside IcsLovUpdateServiceCall \n");fflush(stdout);
		printf("\n--->>>>> LOVId >> %s insrtKey=%s NoOfKeyToBeAdd=%d keyOfLov[0]=%s LovValue[0]=%s",LOVId,insrtKey,NoOfKeyToBeAdd,keyOfLov[0],LovValue[0]);fflush(stdout);
		//ERROR_CHECK(ICS_init_module());
		ERROR_CHECK(ICS_keylov_insert_entries(LOVId,NULL,NoOfKeyToBeAdd,keyOfLov,LovValue));
		printf("\n--->>>>> End of tm_ics_lov_insert_init_val function >> ");fflush(stdout);		
		printf ("\n IcsLovUpdateServiceCall  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int IcsLovUpdateServiceFunc(int *decision, va_list args)
extern int IcsLovUpdateServiceFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 5;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // The unique identifier of the KeyLOV
	inputArgTypes[1] = USERARG_STRING_TYPE; //  In front of this existing key the following keys are inserted. If theInsertKey = NULL or "" then the inserted keys are added at the end of the existing keys.
	inputArgTypes[2] = USERARG_INT_TYPE   ; // The number of keys to be added to the KeyLOV
	inputArgTypes[3] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // The KeyLOV keys to be added to the KeyLOV	
	inputArgTypes[4] = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE; // The values for the added keys 
	retValueType = USERARG_VOID_TYPE;
	//retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	TC_write_syslog("\n IcsLovUpdateServiceFunc before USERSERVICE_register_method");  
	ifail=USERSERVICE_register_method("IcsLovUpdateServiceCall",(USER_function_t)IcsLovUpdateServiceCall,nargs,inputArgTypes,retValueType);
	TC_write_syslog("\n IcsLovUpdateServiceFunc AfterUSERSERVICE_register_method");
	
	return ifail;
	
}

//End for LOV update option


//Start for user service for CpyTechSpecVCattrtoNewVC option

int CpyTechSpecVCattrtoNewVC(void *retValue)
{
		const char				*prog_name 		="CpyTechSpecVCattrtoNewVC";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* BaseVC  = NULL;
		char* NewVC = NULL;
		
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	BaseVCTag		= NULLTAG;
		tag_t	BaseVCRevTag		= NULLTAG;
		tag_t	NewVCTag		= NULLTAG;
		tag_t	NewVCRevTag		= NULLTAG;
				
				
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *BaseVCPartType=NULL;
				
		USERARG_get_string_argument(&BaseVC); 
		USERARG_get_string_argument(&NewVC);
		printf("\nInside CpyTechSpecVCattrtoNewVC \n");fflush(stdout);
		printf("\n--->>>>> BaseVC >> %s NewVC=%s ",BaseVC,NewVC);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="CpyTechSpec";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for CpyTechSpec.... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object CpyTechSpec CC  Found \n");fflush(stdout);
				
				
				ITK_CALL(ITEM_find_item(BaseVC, &BaseVCTag));
				ITK_CALL(ITEM_find_item(NewVC, &NewVCTag));
				if(BaseVCTag != NULLTAG && NewVCTag != NULLTAG)
				{
				ITK_CALL(ITEM_ask_latest_rev(BaseVCTag, &BaseVCRevTag));
				
				ITK_CALL(ITEM_ask_latest_rev(NewVCTag, &NewVCRevTag));
				
				ITK_CALL(AOM_ask_value_string(BaseVCRevTag,"t5_PartType",&BaseVCPartType));
				printf("\n BaseVCPartType=%s ",BaseVCPartType);fflush(stdout);
				
				if(tc_strcmp(BaseVCPartType,"VC")!=0)	//to skip part Type VC
						{
							if(tc_strstr(BaseVCPartType,"V")!=NULL)	//allowing CCV/V
							{
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for CpyTechSpec tm_CpyVCattrtoNewVC ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_CpyVCattrtoNewVC Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,BaseVC);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,NewVC);
									printf("\n before-- Calling shell file tm_CpyVCattrtoNewVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_CpyVCattrtoNewVC.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
							}
						}
				}
				else
				{
					printf ("\n Input Source VC or New VC input for Copy is not found in Teamcenter!! ");fflush(stdout);
				}
				
			}
			else
			{
				printf ("\n CpyTechSpecVCattrtoNewVC shellpath for CpyTechSpec is NULL as control object CpyTechSpec not found ");fflush(stdout);
			}
		
		
		
		printf ("\n CpyTechSpecVCattrtoNewVC  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int CpyTechSpecVCattrtoNewVCUsrServFunc(int *decision, va_list args)
extern int CpyTechSpecVCattrtoNewVCUsrServFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 2;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // Old VC No
	inputArgTypes[1] = USERARG_STRING_TYPE; //  New VC No
	retValueType = USERARG_VOID_TYPE;
	//retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	//printf("\n CpyTechSpecVCattrtoNewVCUsrServFunc before USERSERVICE_register_method");fflush(stdout);  
	ifail=USERSERVICE_register_method("CpyTechSpecVCattrtoNewVC",(USER_function_t)CpyTechSpecVCattrtoNewVC,nargs,inputArgTypes,retValueType);
// printf("\n CpyTechSpecVCattrtoNewVCUsrServFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for user service for CpyTechSpecVCattrtoNewVC option





//Start for user service for LoadUpdKeywordDescUsrServ option

int LoadUpdKeywordDescUsrServ(void *retValue)
{
		const char				*prog_name 		="LoadUpdKeywordDescUsrServ";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* inpKeyDescDatasetName  = NULL;
		char* NewVC = NULL;
		
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	inpKeyDescDatasetNameTag		= NULLTAG;
		tag_t	inpKeyDescDatasetNameRevTag		= NULLTAG;
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *inpKeyDescDatasetNamePartType=NULL;
				
		USERARG_get_string_argument(&inpKeyDescDatasetName); 
		//USERARG_get_string_argument(&NewVC);
		printf("\nInside LoadUpdKeywordDescUsrServ \n");fflush(stdout);
		printf("\n--->>>>> inpKeyDescDatasetName >> %s NewVC=%s ",inpKeyDescDatasetName,NewVC);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="LoadUpdKeywordDesc";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for LoadUpdKeywordDesc.... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object LoadUpdKeywordDesc CC  Found \n");fflush(stdout);
				
				
				//ITK_CALL(ITEM_find_item(inpKeyDescDatasetName, &inpKeyDescDatasetNameTag));
				//ITK_CALL(ITEM_ask_latest_rev(inpKeyDescDatasetNameTag, &inpKeyDescDatasetNameRevTag));
				//ITK_CALL(AOM_ask_value_string(inpKeyDescDatasetNameRevTag,"t5_PartType",&inpKeyDescDatasetNamePartType));
				ITK_CALL(AE_find_dataset2(inpKeyDescDatasetName, &inpKeyDescDatasetNameTag));
				printf("\n inpKeyDescDatasetNameTag=%u ",inpKeyDescDatasetNameTag);fflush(stdout);
				if(inpKeyDescDatasetNameTag!=NULLTAG)
				//if(tc_strcmp(inpKeyDescDatasetNamePartType,"VC")!=0)	//to skip part Type VC
						{
							//if(tc_strstr(inpKeyDescDatasetNamePartType,"V")!=NULL)	//allowing CCV/V
							//{
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for LoadUpdKeywordDesc tm_LoadUpdKeywordDesc ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_LoadUpdKeywordDesc Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,inpKeyDescDatasetName);
									printf("\n before-- Calling shell file tm_LoadUpdKeywordDesc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_LoadUpdKeywordDesc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
							//}
						}
				
				
			}
			else
			{
				printf ("\n LoadUpdKeywordDescUsrServ shellpath for LoadUpdKeywordDesc is NULL as control object LoadUpdKeywordDesc not found ");fflush(stdout);
			}
		
		
		
		printf ("\n LoadUpdKeywordDescUsrServ  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int LoadUpdKeywordDescUsrServFunc(int *decision, va_list args)
extern int LoadUpdKeywordDescUsrServFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 1;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // dataset name
	//inputArgTypes[1] = USERARG_STRING_TYPE; //  New VC No
	retValueType = USERARG_VOID_TYPE;
	//retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	//printf("\n LoadUpdKeywordDescUsrServFunc before USERSERVICE_register_method");fflush(stdout);  
	ifail=USERSERVICE_register_method("LoadUpdKeywordDescUsrServ",(USER_function_t)LoadUpdKeywordDescUsrServ,nargs,inputArgTypes,retValueType);
 //printf("\n LoadUpdKeywordDescUsrServFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for user service for LoadUpdKeywordDescUsrServ option

//Start for user service for TechSpecReportVcWise option

int TechSpecReportVcWise(void *retValue)
{
		const char				*prog_name 		="TechSpecReportVcWise";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* datasetname  = NULL;
		
		
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	BaseVCTag		= NULLTAG;
		tag_t	BaseVCRevTag		= NULLTAG;
		tag_t	NewVCTag		= NULLTAG;
		tag_t	NewVCRevTag		= NULLTAG;
				
				
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *BaseVCPartType=NULL;
				
		USERARG_get_string_argument(&datasetname); 
		
		printf("\nInside TechSpecReportVcWise \n");fflush(stdout);
		printf("\n--->>>>> datasetname >> %s",datasetname);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="RptVcWiseTechSpec";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for RptVcWiseTechSpec.... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object RptVcWiseTechSpec CC  Found \n");fflush(stdout);
				
				
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for RptVcWiseTechSpec tm_TechSpecReportVcWise ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_TechSpecReportVcWise Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,datasetname);
									
									printf("\n before-- Calling shell file tm_TechSpecReportVcWise.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_TechSpecReportVcWise.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
						
				
				
			}
			else
			{
				printf ("\n TechSpecReportVcWise shellpath for RptVcWiseTechSpec is NULL as control object RptVcWiseTechSpec not found ");fflush(stdout);
			}
		
		
		
		printf ("\n TechSpecReportVcWise  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int TechSpecReportVcWiseFunc(int *decision, va_list args)
extern int TechSpecReportVcWiseFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 1;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // dataset no
	retValueType = USERARG_VOID_TYPE;
	ifail=USERSERVICE_register_method("TechSpecReportVcWise",(USER_function_t)TechSpecReportVcWise,nargs,inputArgTypes,retValueType);
// printf("\n TechSpecReportVcWiseFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for user service for TechSpecReportVcWise option


//From date
//To date

//Start for user service for TechSpecReportDateRange option

int TechSpecReportDateRange(void *retValue)
{
		const char				*prog_name 		="TechSpecReportDateRange";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char *Datefrom =NULL;
		char *Dateto =NULL;
		
		
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	BaseVCTag		= NULLTAG;
		tag_t	BaseVCRevTag		= NULLTAG;
		tag_t	NewVCTag		= NULLTAG;
		tag_t	NewVCRevTag		= NULLTAG;
				
				
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *BaseVCPartType=NULL;
				
		USERARG_get_string_argument(&Datefrom);
		USERARG_get_string_argument(&Dateto);
		
		printf("\nInside TechSpecReportDateRange \n");fflush(stdout);
		printf("\n--->>>>> Datefrom >> %s Dateto=%s",Datefrom,Dateto);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="RptDateWiseTechSpec";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for RptDateRangeTechSpec.... \n");fflush(stdout);
				
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object RptDateRangeTechSpec CC  Found \n");fflush(stdout);
				
				
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for RptDateRangeTechSpec tm_TechSpecReportDateRange ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_TechSpecReportDateRange Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,Datefrom);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,Dateto);
									
									printf("\n before-- Calling shell file tm_TechSpecReportDateRange.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_TechSpecReportDateRange.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
						
				
				
			}
			else
			{
				printf ("\n TechSpecReportDateRange shellpath for RptDateRangeTechSpec is NULL as control object RptDateRangeTechSpec not found ");fflush(stdout);
			}
		
		
		
		printf ("\n TechSpecReportDateRange  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int TechSpecReportDateRangeFunc(int *decision, va_list args)
extern int TechSpecReportDateRangeFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 2;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // From Date
	inputArgTypes[1] = USERARG_STRING_TYPE; // To Date
	retValueType = USERARG_VOID_TYPE;
	ifail=USERSERVICE_register_method("TechSpecReportDateRange",(USER_function_t)TechSpecReportDateRange,nargs,inputArgTypes,retValueType);
// printf("\n TechSpecReportDateRangeFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}


//Start for user service for ColVCWiseTechSpecRpt option

int ColVCWiseTechSpecRpt(void *retValue)
{
		const char				*prog_name 		="ColVCWiseTechSpecRpt";
		char*   DMLNumber                      = NULL;
		tag_t dml_object = NULLTAG;
		int ifail = ITK_ok;
		
		char **bufferedXmlStrOut = NULL;
		int buff_cnt =0;
		USERSERVICE_array_t 	array_structure;
		int 					array_size 		= 0; 
		char 					**string_array 	= NULL;	
		
		
		char* datasetname  = NULL;
		
		
		tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
		tag_t   qryTagCntrl1     = NULLTAG;		
		tag_t	BaseVCTag		= NULLTAG;
		tag_t	BaseVCRevTag		= NULLTAG;
		tag_t	NewVCTag		= NULLTAG;
		tag_t	NewVCRevTag		= NULLTAG;
				
				
		int     n_entryCntrl1    = 3;
		char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
		char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
		int cntrlcnt=0;
		int  control_number_found1=0;
		char* shellpath = NULL;
		char* sysCmnd = NULL;
		char *BaseVCPartType=NULL;
				
		USERARG_get_string_argument(&datasetname); 
		
		printf("\nInside ColVCWiseTechSpecRpt \n");fflush(stdout);
		printf("\n--->>>>> datasetname >> %s",datasetname);fflush(stdout);
		
			//if(QRY_find("Control Objects...", &qryTagCntrl1));
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="RptColVcWiseTechSpec";
				qry_valuesCntrl1[1]="Live";
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object RptColVcWiseTechSpec Query not Found for RptVcWiseTechSpec.... \n");fflush(stdout);
				
			}	
			
			printf("\n RptColVcWiseTechSpec control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
			
			if(control_number_found1>0)
			{
				printf("\n Control Object RptColVcWiseTechSpec CC  Found \n");fflush(stdout);
				
				
								ITK_CALL(AOM_ask_value_string(list_of_WSO_cntrl_tags1[0],"t5_Userinfo1",&shellpath));
							
								printf("\nshellpath for  tm_ColVCWiseTechSpecRpt ==>%s\n",shellpath);fflush(stdout);
								if(tc_strlen(shellpath)>0)
								{
									printf("\ninside tm_ColVCWiseTechSpecRpt Execute through client code......\n");fflush(stdout);
									
									
									sysCmnd=(char *) MEM_alloc(400);
									tc_strcpy(sysCmnd,shellpath);
									tc_strcat(sysCmnd," ");
									tc_strcat(sysCmnd,datasetname);
									
									printf("\n before-- Calling shell file tm_ColVCWiseTechSpecRpt.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									system(sysCmnd);
									
									printf("\n after --- Calling shell file tm_ColVCWiseTechSpecRpt.sh using client system command: %s\n",sysCmnd);fflush(stdout);
									
									MEM_free(sysCmnd);
								}
						
				
				
			}
			else
			{
				printf ("\n ColVCWiseTechSpecRpt shellpath is NULL as control object not found ");fflush(stdout);
			}
		
		
		
		printf ("\n ColVCWiseTechSpecRpt  func Completed .. ");fflush(stdout);
		return ifail;
		
}
//extern int ColVCWiseTechSpecRptFunc(int *decision, va_list args)
extern int ColVCWiseTechSpecRptFunc()
{
	int ifail = ITK_ok;
	//int *decision = ALL_CUSTOMIZATIONS; 
	int nargs = 1;
	int retValueType;
	//int inputArgTypes[1] = {0};
	int *inputArgTypes = (int *) MEM_alloc ( nargs * sizeof (int) );
	/* Refer ict_userservice.h for more arg types*/
	inputArgTypes[0] = USERARG_STRING_TYPE; // dataset no
	retValueType = USERARG_VOID_TYPE;
	ifail=USERSERVICE_register_method("ColVCWiseTechSpecRpt",(USER_function_t)ColVCWiseTechSpecRpt,nargs,inputArgTypes,retValueType);
// printf("\n ColVCWiseTechSpecRptFunc AfterUSERSERVICE_register_method");fflush(stdout);
	
	return ifail;
	
}

//End for user service for ColVCWiseTechSpecRpt option

extern int techspechUsrServCall(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
 
 printf("\n inside the  techspechUsrServCall func");fflush(stdout);
 ERROR_CHECK(IcsLovUpdateServiceFunc());
 ERROR_CHECK(CpyTechSpecVCattrtoNewVCUsrServFunc());
 ERROR_CHECK(LoadUpdKeywordDescUsrServFunc());
 ERROR_CHECK(TechSpecReportVcWiseFunc());
 ERROR_CHECK(TechSpecReportDateRangeFunc());
 ERROR_CHECK(ColVCWiseTechSpecRptFunc());
 printf("\n End the  techspechUsrServCall func");fflush(stdout);
 
 }


extern DLLAPI int tm_techspec_register_callbacks ()
{
    ECHO("techspec_register_callbacks\n");

	printf("\ntechspec_register_callbacks");fflush(stdout);

	ERROR_CHECK(CUSTOM_register_exit ( "tm_techspec", "USER_init_module",(CUSTOM_EXIT_ftn_t) TechSpec_register_methods ));
	//ERROR_CHECK(CUSTOM_register_exit ( "tm_techspec", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  IcsLovUpdateServiceFunc));
	ERROR_CHECK(CUSTOM_register_exit ( "tm_techspec", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)  techspechUsrServCall));

    return ITK_ok;
}


