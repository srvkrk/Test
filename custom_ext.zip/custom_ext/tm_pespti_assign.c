/*******************************************************************************************************************************
* CVS: $Id
*
* COPYRIGHT 2018 TATA Motors.  ALL RIGHTS RESERVED
*
*
* *-----------------------------------------------------------------------------------------------------------------------------
** Filename		:	tm_pespti_assign.c
*
* Description	: > This register custom user service. Implemented Custom ITK functions for PE Spare tool indent functionlities.
*				  > This ITK functions are called in Rich Client 
* Module  		        
* Since		    :   14-07-2025
* ENVIRONMENT	:   C,C++, ITK

*
* History

*------------------------------------------------------------------------------------------------------------------------------
* Date         	 Developer Name													Description of Change
* 14-07-2025  	 Sanjay Jadhav /Akshata Mahadik /Sunny kumar					Base Code for user assignment
* 			

* -----------------------------------------------------------------------------------------------------------------------------
* 
*******************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#define ITK_err 919002
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <assert.h>
#include <string.h>
#include <sys/stat.h>
#include <Fnd0Participant/participant.h>
#include <fclasses/tc_date.h>
#define ITK_errStore 91900002

#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define PLM_error (EMH_USER_error_base + 100)

static int report_error( char *file, int line, char *function, int return_code)
{
 
                if (return_code != ITK_ok)
                {
                                int                                                           index = 0;
                                int                                                           n_ifails = 0;
                                const int*                            severities = 0;
                                const int*                            ifails = 0;
                                const char**      texts = NULL;
 
                                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                                printf("%3d error(s)\n", n_ifails);
                                for( index=0; index<n_ifails; index++)
                                {
                                                printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                                                TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                                }
                                EMH_clear_errors();
				 }
                return return_code;
 
}

/*
 
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
/*
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
 
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
*/


void setAddTAG_1(int *count,tag_t **objlist,tag_t obj ) 

{

	*count=*count+1;

	if(*count==1)

	{

		//printf("\n ****setAddTAG_11");fflush(stdout);

		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}

	else

	{

		//printf("\n ****setAddTAG_12");fflush(stdout);

		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));

	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}
 

int Assign_PE_Indent_Create(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_PESPTI_Designer=0;

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	

	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));


	printf("\n Inside Assign_PE_Indent_Create \n");

	(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n pespti : Assign_pespti_Planner:  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n pespti for Assign_pespti_Planner  :%s \n", Temp_Task_no);fflush(stdout);
	
	


	ITK_CALL(SA_find_group("PESPTI",&group_tag));
	
	printf("\n PESPTI Group Name  tag found \n");fflush(stdout);

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		printf("\n No of Participant found in PESPTI Designer Group are :%d\n",num_of_roles);fflush(stdout);

	}
		

	if(num_of_roles>0)
	{
		FlaggAssign_PESPTI_Designer = 0;//added
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n value of i : [%d] and  Role Name is :[%s]\n",i,rolename);fflush(stdout);
			
		

			if((tc_strstr(rolename, "PESPTI") != NULL) && (tc_strstr(rolename, "Designer") != NULL))
			{
				
				printf("\n Match Found for PESPTI Designer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Designer found in Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;

					for (b=0;b<num_of_members ;b++)
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Designer : User ID Name :[%s]\n",userid);fflush(stdout);

						FlaggAssign_PESPTI_Designer = 1;

							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							printf("\n Analyst ------------1 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Analyst ------------2\n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Analyst ------------3\n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssign_PESPTI_Designer==1)
				{
					printf("\n FlaggAssign_PESPTI_Designer : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	
	printf("\n FlaggAssign_PESPTI_Designer for default : [%d]\n",FlaggAssign_PESPTI_Designer);fflush(stdout);

	
	return ITK_ok;

}

int PE_Spare_Tool_Indent_Review(tag_t object_type)							
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssignPE_Spare_Tool_Indent_Review=0;
		

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	

	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));


	printf("\n Inside PE_Spare_Tool_Indent_Review  \n");

	ITK_CALL(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n PE_Spare_Tool_Indent_Review task no :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n PE_Spare_Tool_Indent_Review Temp_Task_no  :%s \n", Temp_Task_no);fflush(stdout);
	

	

	ITK_CALL(SA_find_group("PESPTI",&group_tag));
	
	printf("\n PE_Spare_Tool_Indent_Review  group tag :\n");fflush(stdout);

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

		printf("\n No of Role found in PESPTI Group are :%d\n",num_of_roles);fflush(stdout);

	}
	

	if(num_of_roles>0)
	{
		FlaggAssignPE_Spare_Tool_Indent_Review = 0;
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n value of i :[%d] Role Name :[%s]\n",i,rolename);fflush(stdout);
			
			
			if((tc_strstr(rolename, "PESPTI") != NULL) && (tc_strstr(rolename, "Reviewer") != NULL))
			{
				
				printf("\n Match Found for PE_Spare_Tool_Indent_Review => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Members found in Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n PESPTI Reviewer User ID Name :[%s]\n",userid);

						FlaggAssignPE_Spare_Tool_Indent_Review = 1;

							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);      //T5_DMUReviewer
							printf("\n ChangeSpecialist1-------------1\n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n ChangeSpecialist1 ------------2\n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n ChangeSpecialist1-------------3\n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssignPE_Spare_Tool_Indent_Review==1)
				{
					printf("\n FlaggAssignPE_Spare_Tool_Indent_Review : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}
	//
	printf("\n FlaggAssignPE_Spare_Tool_Indent_Review value : [%d]\n",FlaggAssignPE_Spare_Tool_Indent_Review);fflush(stdout);

	
	return ITK_ok;

}


int Updation_Of_Work_Order(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_Updation_Of_Work_Order=0;

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n Inside Updation_Of_Work_Order \n");

	ITK_CALL(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n pespti : Updation_Of_Work_Order:  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n pespti for Updation_Of_Work_Order  :%s \n", Temp_Task_no);fflush(stdout);
	
	

	ITK_CALL(SA_find_group("PESPTI",&group_tag));
	
	printf("\n PESPTI Group Name  tag found \n");fflush(stdout);

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

		printf("\n No of Participant found in PESPTI Designer Group are :%d\n",num_of_roles);fflush(stdout);

	}
	

	if(num_of_roles>0)
	{
		FlaggAssign_Updation_Of_Work_Order = 0;
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n value of i : [%d] and  Role Name is :[%s]\n",i,rolename);fflush(stdout);
			
		

			if((tc_strstr(rolename, "PESPTI") != NULL) && (tc_strstr(rolename, "WO_Updater") != NULL))
			{
				
				printf("\n Match Found for PESPTI Designer => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Designer found in Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Designer : User ID Name :[%s]\n",userid);

						FlaggAssign_Updation_Of_Work_Order = 1;

							TCTYPE_find_type("ChangeReviewBoard", "ChangeReviewBoard", &participant_type);
							printf("\n ChangeReviewBoard ------------1 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n ChangeReviewBoard ------------2\n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n ChangeReviewBoard ------------3\n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssign_Updation_Of_Work_Order==1)
				{
					printf("\n FlaggAssign_Updation_Of_Work_Order : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}

	
	
	printf("\n FlaggAssign_Updation_Of_Work_Order for default : [%d]\n",FlaggAssign_Updation_Of_Work_Order);fflush(stdout);

	
	return ITK_ok;

}


int Updation_Of_PO(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_PO_Updater=0;

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n Inside Updation_Of_PO \n");

	ITK_CALL(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n pespti : Updation_Of_PO:  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n pespti for Updation_Of_PO  :%s \n", Temp_Task_no);fflush(stdout);
	
	

	ITK_CALL(SA_find_group("PESPTI",&group_tag));
	
	printf("\n PESPTI Group Name  tag found \n");fflush(stdout);

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

		printf("\n No of Participant found in PESPTI Designer Group are :%d\n",num_of_roles);fflush(stdout);

	}
	

	if(num_of_roles>0)
	{
		FlaggAssign_PO_Updater = 0;
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n value of i : [%d] and  Role Name is :[%s]\n",i,rolename);fflush(stdout);
			
		

			if((tc_strstr(rolename, "PESPTI") != NULL) && (tc_strstr(rolename, "PO_Updater") != NULL))
			{
				
				printf("\n Match Found for PESPTI PO_Updater => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Designer found in Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{
				
					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Designer : User ID Name :[%s]\n",userid);

						FlaggAssign_PO_Updater= 1;

							TCTYPE_find_type("Requestor", "Requestor", &participant_type);
							printf("\n Requestor ------------1 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n Requestor ------------2\n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n Requestor ------------3\n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssign_PO_Updater==1)
				{
					printf("\n FlaggAssign_PO_Updater : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}

	
	
	printf("\n FlaggAssign_PO_Updater for default : [%d]\n",FlaggAssign_PO_Updater);fflush(stdout);

	
	return ITK_ok;

}

int Updation_Of_Receipt_Qty(tag_t object_type)
{
	
	char*			Task_no				= NULL;
	char*			Dsgn_No				= NULL;
	char*			Dsgn1				= NULL;
	char*			Dsgn2				= NULL;
	char*			PLT_Code			= NULL;
	char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			PLT_CodeS			= NULL;
	char*			Object_Name			= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t			qryTagCntrl1		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	tag_t*			GmFound1			= NULLTAG;
	tag_t*			list_of_WSO_cntrl_tags1=NULLTAG;
	
	int				ifail				= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int Gmcnt1=0;
	int ProjectAccessFound=0;
	int FlaggAssignPlanner=0;
	int countt=0;
	int b=0;
	int z=0;
	int cntrlcnt=0;
	int  control_number_found1=0;
	int     n_entryCntrl1    = 3;
	int FlaggAssign_RCPT_QTY_Updater=0;

	
	char  Projj[40];
	
	char *PltCodeFrmCntrl 	  = NULL;
	char Aggregt[40];
	
	//
	char*	Temp_Task_no	= NULL;
	int max_char_size = 80;
    Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//

	printf("\n Inside Updation_Of_Receipt_Qty \n");

	ITK_CALL(AOM_ask_value_string(object_type,"item_id",&Task_no));
	
	printf("\n pespti : Updation_Of_Receipt_Qty:  is :%s \n",Task_no);	fflush(stdout);
	tc_strcpy(Temp_Task_no, Task_no);
    printf("\n pespti for Updation_Of_Receipt_Qty  :%s \n", Temp_Task_no);fflush(stdout);
	
	

	ITK_CALL(SA_find_group("PESPTI",&group_tag));
	
	printf("\n PESPTI Group Name  tag found \n");fflush(stdout);

	if (group_tag != NULLTAG)
	{
		ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

		printf("\n No of Participant found in PESPTI Designer Group are :%d\n",num_of_roles);fflush(stdout);

	}
	

	if(num_of_roles>0)
	{
		FlaggAssign_RCPT_QTY_Updater = 0;
		for (i=0;i<num_of_roles ;i++ )
		{
			ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
			printf("\n value of i : [%d] and  Role Name is :[%s]\n",i,rolename);fflush(stdout);
			
		

			if((tc_strstr(rolename, "PESPTI") != NULL) && (tc_strstr(rolename, "RCPT_QTY_Updater") != NULL))
			{
				
				printf("\n Match Found for PESPTI RCPT_QTY_Updater => %s \n",rolename);fflush(stdout);
				role_tag = role_tags[i];
				ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
				printf("\n No of Group Designer found in Role are :%d\n",num_of_members);fflush(stdout);
				
				if(num_of_members>0)
				{

					tag_t*	ptypes		= NULLTAG;
					tag_t*	ptypes2		= NULLTAG;
					int p1=0;
					int p2=0;
					for (b=0;b<num_of_members ;b++  )
					{
						ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
						ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\n Designer : User ID Name :[%s]\n",userid);

						FlaggAssign_RCPT_QTY_Updater= 1;

							TCTYPE_find_type("T5_DMUReviewer", "T5_DMUReviewer", &participant_type);
							printf("\n T5_DMUReviewer ------------1 \n");fflush(stdout);
							setAddTAG_1(&p1,&ptypes,participant_type);
							printf("\n T5_DMUReviewer ------------2\n");fflush(stdout);
							setAddTAG_1(&p2,&ptypes2,member_tags[b]);
							printf("\n T5_DMUReviewer ------------3\n");fflush(stdout);
						
					}
					tag_t* participant_list = NULLTAG;
					logical bypass_assignable_check =true;
					int k = 0;

					tag_t   type1TypeTag			= NULLTAG;

					char*    type1type_name;
					printf("\n p1 => %d and p2 => %d \n",p1,p2);fflush(stdout);
					for(k=0;k<p2;k++)
					{
						tag_t type1 = ptypes[k];
						if(type1 != NULLTAG )
						{
							if(TCTYPE_ask_object_type(type1,&type1TypeTag));
							if(TCTYPE_ask_name2(type1TypeTag,&type1type_name));
							printf("\n type1type_name => %s\n", type1type_name);fflush(stdout);
						}
						else
						{
							printf("\n type is NULL \n");fflush(stdout);
						}
					}

					ITK_CALL(PARTICIPANT_add_participants(object_type,bypass_assignable_check,p2,ptypes2,ptypes,&participant_list));
				}
				if(FlaggAssign_RCPT_QTY_Updater==1)
				{
					printf("\n FlaggAssign_RCPT_QTY_Updater : Break \n");fflush(stdout);
					break;
				}
			}
			
		}
		

	}

	
	
	printf("\n FlaggAssign_RCPT_QTY_Updater for default : [%d]\n",FlaggAssign_RCPT_QTY_Updater);fflush(stdout);

	
	return ITK_ok;

}

int pespti_task_assigment(EPM_action_message_t msg)
{

    int error_code = ITK_ok;
    int ifail = 0;

    char *Proj_Code = NULL;
    char *item_type = NULL;
     char	*type_name				=	NULL;
    char *object_name1 = NULL;
    char *DML_no = NULL;
    char **DesignGroupList;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    char *ecntypeVal = NULL;

    int TaskCnt = 0;
    int count = 0;
    int noAttachment, noTaskAttachment = 0;
    tag_t APLTaskRevT = NULLTAG;
    tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
    tag_t relation_type = NULLTAG;
    tag_t *TaskRevision = NULLTAG;



    printf("\n Inside Registered Action Handler pespti_task_assigment \n ");
    fflush(stdout);

    if (EPM_ask_root_task(msg.task, &rootTask))
        ;
	if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask))
        ;
    printf("\n CurrentTask of pespti :%s\n", CurrentTask);
    if (AOM_ask_value_string(rootTask, "object_name", &parent_name))
        ;
    printf("\n Parent Name pespti:%s\n", parent_name);
    fflush(stdout);
    if (EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments))
        ;
    printf("\n Target Attachment pespti:%d\n", noAttachment);
    fflush(stdout);
    if (noAttachment > 0)
    {
        dml_rev_tag = attachments[0];
        if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
            ;
        if (TCTYPE_ask_name2(objTypeTag, &type_name))
            ;
        printf("\n type_name changes done: for workspaceobject  :%s\n", type_name);
        fflush(stdout);
    }

    if (strcmp(type_name, "T5_PEIndRevision") == 0)
	{
       printf("\n inside class T5_PEIndRevision......\n");
        fflush(stdout);
       AOM_ask_value_string(dml_rev_tag, "object_name", &object_name1);
		printf("\n inside class object_name...... ;%s\n", object_name1);
		fflush(stdout);
        AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no);fflush(stdout);
		printf("\n inside class current_id......  ;%s\n", DML_no );
		fflush(stdout);
        printf("\n calling function to  assign the user for the task : %s having assugnment  / PE Indent Create / PE Spare Tool Indent Review /  Updation Of Work Order / Updation Of PO  / Updation Of Receipt Qty  \n",object_name1);fflush(stdout);
	
		printf("\n assigning Assign_PE_Indent_Create \n");fflush(stdout);
		ITK_CALL(Assign_PE_Indent_Create(dml_rev_tag));// Analyst 

		printf("\n assigning PE_Spare_Tool_Indent_Review \n");fflush(stdout);
		ITK_CALL(PE_Spare_Tool_Indent_Review(dml_rev_tag));//ChangeSpecialist1

		printf("\n assigning Updation_Of_Work_Order \n");fflush(stdout);
		ITK_CALL(Updation_Of_Work_Order(dml_rev_tag));//ChangeReviewBoard

		printf("\n assigning Updation_Of_PO \n");fflush(stdout);
		ITK_CALL(Updation_Of_PO(dml_rev_tag));//Requestor

		printf("\n assigning Updation_Of_Receipt_Qty \n");fflush(stdout);
		ITK_CALL(Updation_Of_Receipt_Qty(dml_rev_tag));//T5_DMUReviewer
		

 
	}
    else
    {
        printf("\n class T5_PEIndRevision not found......\n");
        fflush(stdout);
    }

    return error_code;
}

/*int tm_pespti_SendMail(EPM_action_message_t msg)
{
        int ifail = ITK_ok;
        tag_t resourcePool = NULLTAG;
        tag_t tRootTask = NULLTAG;
        ITK_CALL(EPM_ask_root_task(msg.task, &tRootTask));
        int no;
        tag_t *tSignoffs;
        tag_t *members = NULLTAG;
        tag_t tTask = msg.task;
        int n=0;
        int i;
        int j;
        
		int val_count=0;
		tag_t *prop_values=NULLTAG;
		char *prop_val_name=NULL;
        char *role=NULL;
        char *group=NULL;
        char *pcArgVal=NULL;
        char *pcArgName=NULL;
        char *arg=NULL;
        char *epaplant=NULL;
        char *epaplant1=NULL;
        tag_t grouptag=NULLTAG;
        tag_t roletag=NULLTAG;
        tag_t user_tag=NULLTAG;
        tag_t group_tag=NULLTAG;
        tag_t envelope=NULLTAG;
        tag_t usertag=NULLTAG;
		tag_t *recievers= NULLTAG;
		int countenvelop=0;
        // char env_subject[300] = {'\0'};
		// char env_body[1000]= {'\0'};

		char* env_subject	= NULL;
		char* env_body		= NULL;							
		env_subject	= (char *) MEM_alloc(500 * sizeof(char ));
		env_body		= (char *) MEM_alloc(50000 * sizeof(char ));

		tag_t qryTagCntrl1 = NULLTAG;
		char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
		char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
		int n_entryCntrl1 = 3;
		int control_number_found1 = 0;
		tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

		QRY_find2("Control Objects...", &qryTagCntrl1);
        if (qryTagCntrl1)
    	{
        	printf("\n Control Object Query Found For tm_pespti_SendMail\n");fflush(stdout);
			qry_valuesCntrl1[0] = "MailSend";
        	qry_valuesCntrl1[1] = "MailSend";
        	qry_valuesCntrl1[2] = "0";
			ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			printf("\nNumber of control object found tm_pespti_SendMail :%d", control_number_found1);fflush(stdout);
        }
        if(control_number_found1>0)
        {
			printf("==========================================New mail Sent - tm_pespti_SendMail ========================================");fflush(stdout);

			int count=0;
			tag_t *attachments=NULLTAG;
			tag_t objTag=NULLTAG;
			char *type=NULL;
			char *mode=NULL;
			char *pe_spare_partno_Number=NULL;
			char *Synopsis=NULL;
			char *sub_notification=NULL;
			char* Condition = NULL;

			sub_notification=(char *) MEM_alloc(500 * sizeof(char ));
			Condition = (char *) MEM_alloc(500 * sizeof(char ));

			ITK_CALL(EPM_ask_attachments (tRootTask,EPM_target_attachment,&count,&attachments));
			printf("\n No of attachments:%d",count);fflush(stdout);
			if(count>0)
			{
			objTag=attachments[0];
			ITK_CALL(AOM_ask_value_string(objTag,"object_type",&type));
			if(tc_strcmp(type,"T5_PEIndRevision")==0)
			

			ITK_CALL(AOM_ask_value_string(objTag,"item_id",&pe_spare_partno_Number));
			ITK_CALL(AOM_ask_value_string(objTag,"object_name",&Synopsis));
			ITK_CALL(AOM_ask_value_string(objTag,"item_id",&sub_notification));

				printf("\n pe_spare_partno_Number:%s,Synopsis:%s,sub_notification:%s,",pe_spare_partno_Number,Synopsis,sub_notification);fflush(stdout);
			}
			int iNoOfArgs = TC_number_of_arguments(msg.arguments);
			if (iNoOfArgs >= 1)
			{
				for (i = 0; i < iNoOfArgs; i++)
				{
					arg = TC_next_argument(msg.arguments);
					ITK_ask_argument_named_value((char*) arg, &pcArgName, &pcArgVal);
					if ((pcArgName != NULL))
						{
							if(tc_strcmp(pcArgName, "role") == 0)
							{
								if (pcArgVal != NULL)
								{
									role = (char*) MEM_alloc((strlen(pcArgVal) + 5) * sizeof (char));
									tc_strcat(role, pcArgVal);
								}
							}
							else if (tc_strcmp(pcArgName, "group") == 0)
							{
								if (pcArgVal != NULL)
								{
									group = (char*) MEM_alloc((strlen(pcArgVal) + 3) * sizeof (char));
									tc_strcpy(group, pcArgVal);
								}
							}
									
												
						}                
						printf("\n %d pcArgName==%s,pcArgVal==%s",i,pcArgName,pcArgVal);fflush(stdout);
				}                    
			}   //if (iNoOfArgs >= 1) loop closed

			tc_strcpy(env_subject,"");
			tc_strcpy(env_body,"");
			tc_strcpy(Condition,"");
			printf("\n Condition = %s",Condition);fflush(stdout);

			printf("\n Role==%s group===%s",role,group);fflush(stdout);
			ITK_CALL(SA_find_groupmember_by_rolename (role,group,NULL,&no,&members));
			ITK_CALL(SA_find_group(group,&grouptag));
			ITK_CALL(SA_find_role2(role,&roletag));
			tc_strcat(env_subject,"Notification Mail to complete assignment: ");

			if (strcmp(role, "PESPTI_Designer") == 0)
			{
				tc_strcat(sub_notification,"/");
				tc_strcat(sub_notification,"PE indent Create");
				tc_strcat(Condition,"PE indent Create");
				printf("\n PESPTI_Designer sub_notification ==%s Condition ==%s",sub_notification,Condition);fflush(stdout);
			}
			else if (strcmp(role, "PESPTI_Reviewer") == 0)
			{
				tc_strcat(sub_notification,"/");
				tc_strcat(sub_notification,"PE Spare Tool Indent Review");
				tc_strcat(Condition,"PE Spare Tool Indent Review");
				printf("\n PESPTI_Reviewer sub_notification ==%s Condition ==%s",sub_notification,Condition);fflush(stdout);
			}
			else if (strcmp(role, "PESPTI_PO_Updater") == 0)
			{
				tc_strcat(sub_notification,"/");
				tc_strcat(sub_notification,"Updation of PO");
				tc_strcat(Condition,"Updation of PO");
				printf("\n PESPTI_PO_Updater sub_notification==%s Condition ==%s",sub_notification,Condition);fflush(stdout);

			}
			else if (strcmp(role, "PESPTI_WO_Updater") == 0)
			{
				tc_strcat(sub_notification,"/");
				tc_strcat(sub_notification,"Updation of Work Order");
				tc_strcat(Condition,"Updation of Work Order");
				printf("\n PESPTI_WO_Updater sub_notification==%s Condition ==%s",sub_notification,Condition);fflush(stdout);

			}
			else if (strcmp(role, "PESPTI_RCPT_QTY_Updater") == 0)
			{
				tc_strcat(sub_notification,"/");
				tc_strcat(sub_notification,"Updation of Receipt Qty");
				tc_strcat(Condition,"Updation of Receipt Qty");
				printf("\n PESPTI_RCPT_QTY_Updater sub_notification==%s Condition ==%s",sub_notification,Condition);fflush(stdout);
			}
			else
			{

				printf("\n sub_notification==%s Condition ==%s",sub_notification,Condition);fflush(stdout);
			}
		
			tc_strcat(env_subject,sub_notification);

			tc_strcat(env_body,"\nAssignment: ");
			tc_strcat(env_body,Condition);
			tc_strcat(env_body,"\n");
			tc_strcat(env_body,"\n\nName: ");
			tc_strcat(env_body,pe_spare_partno_Number);
			tc_strcat(env_body,"\nClass: ");
			tc_strcat(env_body,"PE Spare Tool Indent");
			tc_strcat(env_body,"\nItem Description: ");
			tc_strcat(env_body,Synopsis);
			tc_strcat(env_body,"\nItem type: ");
			tc_strcat(env_body,"PE Ind Revision");
			tc_strcat(env_body,"\n");
			tc_strcat(env_body,"\nRegards,\nPLM Team\n");

			printf("\n env_subject %s",env_subject);fflush(stdout);
			printf("\n env_body %s",env_body);fflush(stdout);

			ITK_CALL(MAIL_create_envelope(env_subject,env_body,&envelope));
			if(envelope != NULLTAG)
			{
				printf("\n Before Mail Send");                  
				ITK_CALL(MAIL_initialize_envelope2(envelope,env_subject,env_body));
				printf("\n no = %d",no);
				for(j=0;j<no;j++)
				{
					printf("\n Inside for no = %d",no);
					ITK_CALL(SA_ask_groupmember_user(members[j],&usertag));
					ITK_CALL(MAIL_add_envelope_receiver(envelope,usertag));
					printf("\n Inside for no = %d",no);
					
				}

				// ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"sanjayj1.ttl@tatamotors.com"));
				// ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"am927460.ttl@tatamotors.com"));
			
				
				//ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));

				//printf("\n countenvelop : %d",countenvelop);fflush(stdout);

				ITK_CALL(MAIL_send_envelope(envelope));
				
				printf("\n Mail Send Successfully");
			}

			MEM_free(env_body);
			MEM_free(env_subject);

		}
		else
		{
			printf("\n Control Object MailSend not found......\n");fflush(stdout);
		}
    	
	return ifail;
}*/
EPM_decision_t Pespti_PE_Part_signoff_validation(EPM_rule_message_t msg) 
{
	EPM_decision_t decision;

	tag_t *pTagAttch;
	tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
	tag_t IndentPartRel = NULLTAG;
	tag_t *PartTag = NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

    char* CurrentTask = NULL;
    char* parent_name = NULL;
	char* type_name	= NULL;
	char* Validation = NULL;
	char* PEPrtTab = NULL;
	char* PETISPWO = NULL;
	char* PrtProjPETISPWO = NULL;
	char* PETISPPO = NULL;
	char* PrtProjPETISPPO = NULL;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
    
	int iNumAttch = 0;
	int control_number_found1 = 0;
	int n_entryCntrl1 = 3;
    int noAttachment = 0;
	int PartCnt = 0;
	int i,j=0;
	int flg = 0;
    	 
	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For Pespti_PE_Part_signoff_validation\n");fflush(stdout);
		qry_valuesCntrl1[0] = "RuleValid";
		qry_valuesCntrl1[1] = "RuleValid";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found Pespti_PE_Part_signoff_validation :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{
		Validation = (char *)MEM_alloc(3000 * sizeof(char));
		tc_strcpy(Validation," ");

		printf("\n Inside Registered Rule Handler Pespti_PE_Part_signoff_validation \n ");
		fflush(stdout);

		if (EPM_ask_root_task(msg.task, &rootTask))
			;
		if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask))
			;
		printf("\n CurrentTask of pespti :%s\n", CurrentTask);
		if (AOM_ask_value_string(rootTask, "object_name", &parent_name))
			;
		printf("\n Parent Name pespti:%s\n", parent_name);
		fflush(stdout);
		if (EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments))
			;
		printf("\n Target Attachment pespti:%d\n", noAttachment);
		fflush(stdout);
		if (noAttachment > 0)
		{
			dml_rev_tag = attachments[0];
			if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag))
				;
			if (TCTYPE_ask_name2(objTypeTag, &type_name))
				;
			printf("\n type_name changes done: for workspaceobject  :%s\n", type_name);
			fflush(stdout);
		}

		ITKCALL(GRM_find_relation_type("T5_PETISpHasPart", &IndentPartRel));
		if(IndentPartRel!=NULLTAG)
		{
			printf("\n Relation found \n");fflush(stdout);
			ITKCALL(GRM_list_secondary_objects_only(dml_rev_tag, IndentPartRel, &PartCnt, &PartTag));
		}
		else
		{
			printf("\n Relation not found \n");
			fflush(stdout);
		}

		if ((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "PE Indent Create") == 0))
		{
			

			if(PartCnt>0)
			{
				printf("\n Part_Projcode attached to PE Spare Tool Indent \n");fflush(stdout);
				decision = EPM_go;
			}
			else
			{
				printf("\n Part_Projcode not attached to PE Spare Tool Indent \n");fflush(stdout);
				tc_strcat(Validation,"\n Part_Projcode is not attached to PE Spare Tool Indent. Please checkout and add the Part_Projcode!!!");
				EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
				decision = EPM_nogo;
				//return ITK_errStore1;
			}

			

		}
		else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of Work Order") == 0))
		{
			printf("\n  type_name : %s CurrentTask : %s \n",type_name,CurrentTask);fflush(stdout);

			AOM_ask_value_string(dml_rev_tag,"t5_PETISPWO",&PETISPWO);
			printf("\n  PETISPWO : %s \n",PETISPWO);fflush(stdout);
			tc_strcpy(Validation,"");

			if(PartCnt>0)
			{
				flg = 1;
				for(i=0;i<PartCnt;i++)
				{
					
					AOM_ask_value_string(PartTag[i],"t5_PrtProjPETISPWO",&PrtProjPETISPWO);
					printf("\n  PrtProjPETISPWO : %s \n",PrtProjPETISPWO);fflush(stdout);

					//if((tc_strcmp(PETISPWO, "") == 0) || (tc_strcmp(PrtProjPETISPWO, "") == 0))
					if((tc_strcmp(PETISPWO, "") == 0) && (flg==1))
					{
						printf("\n WO Not updated for Part_Projcode and PE Spare Tool Indent \n");fflush(stdout);
						tc_strcat(Validation,"\n Please fill the Work Order no then proceed");
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
						decision = EPM_nogo;
					}
					else
					{
						printf("\n WO already updated for Part_Projcode and PE Spare Tool Indent \n");fflush(stdout);
						decision = EPM_go;
					}
					flg++;
					

				}

			}
			

		}
		else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of PO") == 0))
		{
			printf("\n  type_name : %s CurrentTask : %s \n",type_name,CurrentTask);
			fflush(stdout);

			AOM_ask_value_string(dml_rev_tag,"t5_PETISPPO",&PETISPPO);
			printf("\n  PETISPPO : %s \n",PETISPPO);fflush(stdout);
			tc_strcpy(Validation,"");

			if(PartCnt>0)
			{
				flg = 1;
				for(j=0;j<PartCnt;j++)
				{
					
					AOM_ask_value_string(PartTag[j],"t5_PrtProjPETISPPO",&PrtProjPETISPPO);
					printf("\n  PrtProjPETISPPO : %s \n",PrtProjPETISPPO);fflush(stdout);

					//if((tc_strcmp(PETISPPO, "") == 0) || (tc_strcmp(PrtProjPETISPPO, "") == 0))
					if((tc_strcmp(PETISPPO, "") == 0) && (flg==1))
					{
						printf("\n WO Not updated for Part_Projcode and PE Spare Tool Indent \n");fflush(stdout);
						tc_strcat(Validation,"\n Please fill the PO no then proceed");
						EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
						decision = EPM_nogo;
					}
					else
					{
						printf("\n PO already updated for Part_Projcode and PE Spare Tool Indent \n");fflush(stdout);
						decision = EPM_go;
					}

					flg++;

				}

			}
		}
		// else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of Receipt Qty") == 0))
		// {
		// 	printf("\n  type_name : %s CurrentTask : %s \n",type_name,CurrentTask);
		// 	fflush(stdout);
		// }
		else
		{
			printf("\n Invalid type_name : %s CurrentTask : %s \n",type_name,CurrentTask);
			fflush(stdout);
		}
	}
	else
	{
		printf("\n Control Object for Rule Handler not found......\n");fflush(stdout);
	}
	

	return decision;
}
int PESPTI_Checkin_PreCond_Validation(METHOD_message_t* msg, va_list args)
{
	
	
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	char* newid = NULL;
	char* PCod = NULL;
	char* PrtNm = NULL;
	char* Primary_Obj_name = NULL;	
	char* Open_WO_NO = NULL;
	char* Validation = NULL;
	char* PCodeValidation = NULL;
	char* OrdrQty = NULL;
	char* ROL = NULL;
	char* PeAgncy = NULL;

	int n_entryCntrl1 = 3;
	int	ifail = 0;
	int control_number_found1 = 0;
	int TabCnt = 0;
	int i=0;
	int RowCnt = 0;

	tag_t qryTagCntrl1 = NULLTAG;
	tag_t Primary_Obj_Type = NULLTAG;
	tag_t *TabTags = NULLTAG;
	tag_t *RowTag = NULLTAG;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	Validation = (char *)MEM_alloc(3000 * sizeof(char));
	PCodeValidation = (char *)MEM_alloc(3000 * sizeof(char));
	

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For PESPTI_Checkin_PreCond_Validation\n");fflush(stdout);
		qry_valuesCntrl1[0] = "CheckinPreCnd";
		qry_valuesCntrl1[1] = "CheckinPreCnd";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found PESPTI_Checkin_PreCond_Validation :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{
		tag_t Primary_Obj = va_arg(args, tag_t);
		ITKCALL(TCTYPE_ask_object_type(Primary_Obj, &Primary_Obj_Type));
		ITKCALL(TCTYPE_ask_name2(Primary_Obj_Type, &Primary_Obj_name));

		if ((tc_strcmp(Primary_Obj_name, "T5_PEIndRevision") == 0))
		{
			ITKCALL(AOM_ask_value_tags(Primary_Obj,"t5_PEPrtTab",&TabCnt,&TabTags));
			printf("\n Table found  : %d",TabCnt);fflush(stdout);
			int flag = 0;
			int PEflag = 0;

			if (TabCnt > 0)
			{
				ITKCALL(AOM_UIF_ask_value(Primary_Obj,"item_id",&newid));						
				printf("\n item_id :%s\n",newid);fflush(stdout);
				ITKCALL(AOM_UIF_ask_value(Primary_Obj,"t5_PeAgncy",&PeAgncy));						
				printf("\n PeAgncy :%s\n",PeAgncy);fflush(stdout);

				ITKCALL(AOM_ask_table_rows(Primary_Obj,"t5_PEPrtTab", &RowCnt,&RowTag));				
				printf("\n\t Row count111  :%d\n",RowCnt);fflush(stdout);

				for(i=0;i<RowCnt;i++)
				{
					//Row = RowTag[RowCnt];
					tc_strcpy(Validation,"");
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PrtNm", &PrtNm));	
					printf("\n\t  PrtNm  :%s\n",PrtNm);fflush(stdout);
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PCod", &PCod));
					printf("\n\t PCod :%s\n",PCod);fflush(stdout);
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_OpnWoNo", &Open_WO_NO));
					printf("\n\t Open_WO_NO :%s\n",Open_WO_NO);fflush(stdout);
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_ROL", &ROL));
					printf("\n\t ROL :%s\n",ROL);fflush(stdout);
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_OrdrQty", &OrdrQty));
					printf("\n\t OrdrQty :%s\n",OrdrQty);fflush(stdout);
					
					if(tc_strcmp(PeAgncy,"PE Planning")==0)
					{
						
						printf("\n PeAgncy :%s\n",PeAgncy);fflush(stdout);
						printf("\n Open_WO_NO :%s\n",Open_WO_NO);fflush(stdout);
						printf("\n PEflag :%d\n",PEflag);fflush(stdout);
						if(PEflag==0)
						{
							tc_strcat(Validation,"\n Please Enter The");
						}
						if((tc_strcmp(Open_WO_NO,"")==0))
						{
							PEflag = 1;
							printf("\n PEflag111 :%d\n",PEflag);fflush(stdout);
							if((tc_strcmp(PrtNm,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," PrtNm");
							}
							if((tc_strcmp(PCod,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," PCod");
							}
							if((tc_strcmp(ROL,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," ROL");
							}	
							if((tc_strcmp(OrdrQty,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," OrdrQty");
							}
							if(PEflag>1)
							{
								tc_strcat(Validation," And Then Proceed.");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
								return ITK_errStore1;
							}
							PEflag= 0;
							
						}
						else
						{
							PEflag = 1;
							printf("\n PEflag222 :%d\n",PEflag);fflush(stdout);
							if((tc_strcmp(PrtNm,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," PrtNm");
							}
							if((tc_strcmp(PCod,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," PCod");
							}
							if((tc_strcmp(ROL,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," ROL");
							}	
							if((tc_strcmp(OrdrQty,"")==0))
							{
								PEflag++;
								tc_strcat(Validation," OrdrQty");
							}
							if(PEflag==1)
							{
								tc_strcpy(Validation,"");
								tc_strcat(Validation," If agency is PE Planning Open_WO_NO Not Required!!!");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
								return ITK_errStore1;
							}
							if(PEflag>1)
							{
								tc_strcat(Validation," And Then Proceed.");
								tc_strcat(Validation," \n");
								tc_strcat(Validation," If agency is PE Planning Open_WO_NO Not Required!!!");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
								return ITK_errStore1;
							}
							PEflag= 0;
							
						}
						
						
					}
					else if (tc_strcmp(PeAgncy,"PE Planning")!=0)
					{
						
						printf("\n\t Table details are blank11111 \n");fflush(stdout);
						printf("\n Other PeAgncy :%s\n",PeAgncy);fflush(stdout);
						printf("\n flag :%d\n",flag);fflush(stdout);

						if(flag==0)
						{
							tc_strcat(Validation,"\n Please Enter The");
						}
						if((tc_strcmp(PrtNm,"")==0))
						{
							flag++;
							tc_strcat(Validation," PrtNm");
						}
						if((tc_strcmp(PCod,"")==0))
						{
							flag++;
							tc_strcat(Validation," PCod");
						}
						if((tc_strcmp(ROL,"")==0))
						{
							flag++;
							tc_strcat(Validation," ROL");
						}	
						if((tc_strcmp(OrdrQty,"")==0))
						{
							flag++;
							tc_strcat(Validation," OrdrQty");
						}
						if((tc_strcmp(Open_WO_NO,"")==0))
						{
							flag++;
							tc_strcat(Validation," Open_WO_NO");
						}
						if(flag>0)
						{
							tc_strcat(Validation," And Then Proceed.");
							EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
							return ITK_errStore1;
						}
						
					}
					else
					{
						printf("\n\t Table details are not blank \n");fflush(stdout);

					}

				}
				if(RowCnt==i)
				{
					printf("\n\t RowCnt : %d and i : %d\n",RowCnt,i);fflush(stdout);
					char* TraversPCod = NULL;
					char* TraversPrtNm = NULL;
					for(i=0;i<RowCnt;i++)
					{
						ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PrtNm", &TraversPrtNm));	
						printf("\n\t  TraversPrtNm  :%s\n",TraversPrtNm);fflush(stdout);
						ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PCod", &TraversPCod));
						printf("\n\t TraversPCod :%s\n",TraversPCod);fflush(stdout);
						tc_strcpy(Validation,"");
						tag_t qryPartProjcode = NULLTAG;
						tag_t *QryTag = NULLTAG;

						int n_entries = 2;
						int num_to_sort = 1;
						int Qry_Found;
						int j=0;
						
						char *keys[1] = {"creation_date"};
						int orders[1] = {2};
						char* qry_entries[2] = {"PartNumber","ProjCode"};
						char* qry_values[2] = {TraversPrtNm,TraversPCod};
						char* PrtNm1 = NULL;
						char* PrjCd = NULL;

						QRY_find2("PARTPROJCODE_Qry", &qryPartProjcode);
						if(qryPartProjcode != NULLTAG)
						{
							QRY_execute_with_sort(qryPartProjcode, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &Qry_Found, &QryTag);
							printf("\n\t Qry_Found :%d\n",Qry_Found);fflush(stdout);
							if(Qry_Found>0)
							{
								printf("\n\t Part_Projcode combination found!!! \n");fflush(stdout);

								for(int j=0;j<Qry_Found;j++)
								{
									printf("\n\t Printing the Part_Projcode PrtNm1 and PrjCd Values : \n");fflush(stdout);
									ITKCALL(AOM_ask_value_string(QryTag[j], "t5_PrtN", &PrtNm1));	
									printf("\n\t  PrtNm1  :%s\n",PrtNm);fflush(stdout);
									ITKCALL(AOM_ask_value_string(QryTag[j], "t5_PrjCd", &PrjCd));
									printf("\n\t PrjCd :%s\n",PrjCd);fflush(stdout);

									printf("\n\t We can add Relation !!! \n");fflush(stdout);

								}
								
							}
							else
							{
								
								int n_entries1 = 1;
								int s = 0;
								int qcount = 0;
								int qryflg = 0;

								tag_t qryPartProjcode1 = NULLTAG;
								tag_t* qtag = NULLTAG;

								char* qry_entries1[1] = {"PartNumber"};
								char* qry_values1[1] = {TraversPrtNm};
								char* PrjCd1 = NULL;

								tc_strcpy(PCodeValidation,"");
								QRY_find2("PARTPROJCODE_Qry", &qryPartProjcode1);
								if(qryPartProjcode1!=NULLTAG)
								{
									QRY_execute(qryPartProjcode1,n_entries1,qry_entries1,qry_values1,&qcount,&qtag);
									if(qcount>0)
									{
										printf("\n\t Part found in Part_Projcode \n");fflush(stdout);
										for(s=0;s<qcount;s++)
										{
											qryflg = 1;
											ITKCALL(AOM_ask_value_string(qtag[s], "t5_PrjCd", &PrjCd1));
											printf("\n\t PrjCd1 :%s\n",PrjCd1);fflush(stdout);
											if(s==0)
											{
												tc_strcat(PCodeValidation,PrjCd1);
											}
											else
											{
												tc_strcat(PCodeValidation,", ");
												tc_strcat(PCodeValidation,PrjCd1);
											}
											
											printf("\n\t PCodeValidation :%s\n",PCodeValidation);fflush(stdout);
										}
									}
									else
									{
										printf("\n\t Part Not found in Part_Projcode \n");fflush(stdout);
									}

								}
								if(qryflg>0)
								{
									printf("\n\t Validation \n");fflush(stdout);
									tc_strcat(Validation,"\n Part ");
									tc_strcat(Validation,TraversPrtNm);
									tc_strcat(Validation," Doesn't Exists in PART_PROJCODE Against Mention P_CODE.");
									tc_strcat(Validation,"\n");
									tc_strcat(Validation,"Please try with ");
									tc_strcat(Validation,PCodeValidation);
									tc_strcat(Validation," P_CODE and then try. ");
									
								}
								else
								{
									printf("\n\t Validation \n");fflush(stdout);
									tc_strcat(Validation,"\n Part ");
									tc_strcat(Validation,TraversPrtNm);
									tc_strcat(Validation," Doesn't Exists in PART_PROJCODE Against ANY P_CODE.");
									tc_strcat(Validation,"\n");
									tc_strcat(Validation,"Please Add it into PART_PROJCODE and then try. ");
									
								}
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,Validation);
								return ITK_errStore1;

							}
						}
					}
				}
			}

		}
		else
		{
			printf("\n Other than T5_PEIndRevision \n");
			fflush(stdout);
		}
	}
	else
	{
		printf("\n Control Object for PreCondition not found......\n");fflush(stdout);
	}

	return ifail;

}
int PESPTI_Post_Partattach(METHOD_message_t *msg, va_list args)
{
	int ifail = 0;
	int isNew = 0;
	tag_t PESPTITag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t *TabTags = NULLTAG;
	tag_t *RowTag = NULLTAG;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;
	

	char* type_name = NULL;
	char* PESPTIid = NULL;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	char* Validation = NULL;

	va_list largs;    
	va_copy( largs, args ); 
	tag_t		PESPTIRevTag			= va_arg(largs, tag_t);
	isNew = va_arg(largs, int);
	va_end( largs );

	int TabCnt = 0;
	int i=0;
	int RowCnt = 0;
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;

	ITEM_ask_item_of_rev(PESPTIRevTag,&PESPTITag);
   
    printf("\n Inside PESPTI_Post_Partattach \n");fflush(stdout);

	Validation = (char *)MEM_alloc(3000 * sizeof(char));

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For PESPTI_Post_Partattach\n");fflush(stdout);
		qry_valuesCntrl1[0] = "CheckinPostCnd";
		qry_valuesCntrl1[1] = "CheckinPostCnd";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found PESPTI_Post_Partattach :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{
		if (TCTYPE_ask_object_type(PESPTIRevTag, &objTypeTag));
		if (TCTYPE_ask_name2(objTypeTag, &type_name));
		printf("\n PESPTI_Post_Partattach type_name %s\n", type_name);fflush(stdout);

		printf("\n PESPTI_Post_Partattach isNew  %d \n",isNew);fflush(stdout);

		//if((tc_strcmp(type_name,"T5_PEIndRevision") == 0) && (isNew == 1))
		if((tc_strcmp(type_name,"T5_PEIndRevision") == 0))
		{
			ITKCALL(AOM_ask_value_tags(PESPTIRevTag,"t5_PEPrtTab",&TabCnt,&TabTags));
			printf("\n PESPTI_Post_Partattach Table found  : %d",TabCnt);fflush(stdout);

			if (TabCnt > 0)
			{
				ITKCALL(AOM_UIF_ask_value(PESPTIRevTag,"item_id",&PESPTIid));						
				printf("\n item_id :%s\n",PESPTIid);fflush(stdout);
				
				ITKCALL(AOM_ask_table_rows(PESPTIRevTag,"t5_PEPrtTab", &RowCnt,&RowTag));				
				printf("\n\t Row count :%d\n",RowCnt);fflush(stdout);

				for(i=0;i<RowCnt;i++)
				{
					char* PCod = NULL;
					char* PrtNm = NULL;
					tag_t IndentPartRel = NULLTAG;
					tag_t relation = NULLTAG;
					tag_t PartIndentRel = NULLTAG;
					tag_t Revrelation = NULLTAG;

					tc_strcpy(Validation,"");
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PrtNm", &PrtNm));	
					printf("\n\t  PrtNm  :%s\n",PrtNm);fflush(stdout);
					ITKCALL(AOM_ask_value_string(RowTag[i], "t5_PCod", &PCod));
					printf("\n\t PCod :%s\n",PCod);fflush(stdout);

					tag_t qryPartProjcode = NULLTAG;
					tag_t *QryTag = NULLTAG;

					int n_entries = 2;
					int num_to_sort = 1;
					int Qry_Found;
					int j=0;
					
					char *keys[1] = {"creation_date"};
					int orders[1] = {2};
					char* qry_entries[2] = {"PartNumber","ProjCode"};
					char* qry_values[2] = {PrtNm,PCod};

					QRY_find2("PARTPROJCODE_Qry", &qryPartProjcode);
					if(qryPartProjcode != NULLTAG)
					{
						QRY_execute_with_sort(qryPartProjcode, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &Qry_Found, &QryTag);
						printf("\n\t Qry_Found :%d\n",Qry_Found);fflush(stdout);
						if(Qry_Found>0)
						{
							printf("\n\t Part_Projcode combination found!!! \n");fflush(stdout);

							for(int j=0;j<Qry_Found;j++)
							{
								GRM_find_relation_type("T5_PETISpHasPart", &IndentPartRel);
								GRM_create_relation(PESPTIRevTag, QryTag[j], IndentPartRel, NULLTAG, &relation);
								GRM_save_relation(relation);

								printf("\n\t Relation has been created Successfully for T5_PETISpHasPart !!! \n");fflush(stdout);

								GRM_find_relation_type("T5_PrtHasPETISP", &PartIndentRel);
								GRM_create_relation(QryTag[j],PESPTIRevTag, PartIndentRel, NULLTAG, &Revrelation);
								GRM_save_relation(Revrelation);

								printf("\n\t Relation has been created Successfully for T5_PrtHasPETISP!!! \n");fflush(stdout);

							}
							
						}
						else
						{
							printf("\n\t Inside Relation attach else \n");fflush(stdout);

						}
					}
					

					
				}
			}
		}
	}
    else
	{
		printf("\n Control Object for PostCondition not found......\n");fflush(stdout);
	}

	return ifail;
}
int PESPTI_Post_Property(METHOD_message_t *msg, va_list args)
{
	int ifail = 0;
	int isNew = 0;
	tag_t PESPTITag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t *TabTags = NULLTAG;
	tag_t *RowTag = NULLTAG;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
	tag_t qryTagCntrl1 = NULLTAG;
	tag_t* ActuatedInteractiveTsks = NULLTAG;
	tag_t* PartTag = NULLTAG;
	tag_t IndentPartRel = NULLTAG;
	tag_t* PartTag1 = NULLTAG;
	tag_t IndentPartRel1 = NULLTAG;

	

	char* type_name = NULL;
	char* PETISPWO = NULL;
	char* PETISPPO = NULL;
	char* PESPTIid = NULL;
	char* currentTask = NULL;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	char* Validation = NULL;

	va_list largs;    
	va_copy( largs, args ); 
	tag_t		PESPTIRevTag			= va_arg(largs, tag_t);
	isNew = va_arg(largs, int);
	va_end( largs );

	int TabCnt = 0;
	int i,j,k=0;
	int RowCnt = 0;
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	int count = 0;
	int PartCnt = 0;
	int PartCnt1 = 0;

	ITEM_ask_item_of_rev(PESPTIRevTag,&PESPTITag);
   
    printf("\n Inside PESPTI_Post_Property \n");fflush(stdout);

	Validation = (char *)MEM_alloc(3000 * sizeof(char));

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For PESPTI_Post_Property\n");fflush(stdout);
		qry_valuesCntrl1[0] = "SavePostCnd";
		qry_valuesCntrl1[1] = "SavePostCnd";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found PESPTI_Post_Property :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{
		if (TCTYPE_ask_object_type(PESPTIRevTag, &objTypeTag));
		if (TCTYPE_ask_name2(objTypeTag, &type_name));
		printf("\n PESPTI_Post_Property type_name %s\n", type_name);fflush(stdout);

		printf("\n PESPTI_Post_Property isNew  %d \n",isNew);fflush(stdout);

		AOM_ask_value_tags(PESPTIRevTag,"fnd0ActuatedInteractiveTsks",&count,&ActuatedInteractiveTsks);
		printf("\n PESPTI_Post_Property count  %d \n",count);fflush(stdout);

		if(count>0)
		{
			for(i=0;i<count;i++)
			{
				AOM_UIF_ask_value(ActuatedInteractiveTsks[i],"current_name",&currentTask);
				printf("\n PESPTI_Post_Property currentTask  %s \n",currentTask);fflush(stdout);

				if((tc_strcmp(type_name,"T5_PEIndRevision") == 0) && (tc_strcmp(currentTask,"Updation Of Work Order") == 0))
				{
					AOM_ask_value_string(PESPTIRevTag,"t5_PETISPWO",&PETISPWO);
					printf("\n PETISPWO  %s \n",PETISPWO);fflush(stdout);

					if((tc_strcmp(PETISPWO,"") != 0))
					{
						ITKCALL(GRM_find_relation_type("T5_PETISpHasPart", &IndentPartRel));
						if(IndentPartRel!=NULLTAG)
						{
							printf("\n Relation found \n");fflush(stdout);
							ITKCALL(GRM_list_secondary_objects_only(PESPTIRevTag, IndentPartRel, &PartCnt, &PartTag));
							printf("\n PartCnt  %d \n",PartCnt);fflush(stdout);
							if(PartCnt>0)
							{
								for(j=0;j<PartCnt;j++)
								{
									AOM_lock(PartTag[j]);
									AOM_set_value_string(PartTag[j],"t5_PrtProjPETISPWO",PETISPWO);
									AOM_save_without_extensions(PartTag[j]);
									AOM_unlock(PartTag[j]);
									printf("\n After property update of t5_PrtProjPETISPWO \n");
									fflush(stdout);

								}
							}
							else
							{
								printf("\n Part not attached \n");
								fflush(stdout);
							}
							
						}
						else
						{
							printf("\n Relation not found \n");
							fflush(stdout);
						}
					}
					else
					{
						printf("\n PETISPWO  %s \n",PETISPWO);fflush(stdout);
					}
				}
				else if((tc_strcmp(type_name,"T5_PEIndRevision") == 0) && (tc_strcmp(currentTask,"Updation Of PO") == 0))
				{
					AOM_ask_value_string(PESPTIRevTag,"t5_PETISPPO",&PETISPPO);
					printf("\n PETISPPO  %s \n",PETISPPO);fflush(stdout);

					if((tc_strcmp(PETISPPO,"") != 0))
					{
						ITKCALL(GRM_find_relation_type("T5_PETISpHasPart", &IndentPartRel1));
						if(IndentPartRel1!=NULLTAG)
						{
							printf("\n Relation found \n");fflush(stdout);
							ITKCALL(GRM_list_secondary_objects_only(PESPTIRevTag, IndentPartRel1, &PartCnt1, &PartTag1));
							printf("\n PartCnt  %d \n",PartCnt);fflush(stdout);
							if(PartCnt1>0)
							{
								for(k=0;k<PartCnt1;k++)
								{
									AOM_lock(PartTag1[k]);
									AOM_set_value_string(PartTag1[k],"t5_PrtProjPETISPPO",PETISPPO);
									AOM_save_without_extensions(PartTag1[k]);
									AOM_unlock(PartTag1[k]);
									printf("\n After property update of t5_PrtProjPETISPPO \n");
									fflush(stdout);

								}
							}
							else
							{
								printf("\n Part not attached \n");
								fflush(stdout);
							}
							
						}
						else
						{
							printf("\n Relation not found \n");
							fflush(stdout);
						}
					}
					else
					{
						printf("\n PETISPWO  %s \n",PETISPWO);fflush(stdout);
					}
				}
				else
				{
					printf("\n Other task \n");fflush(stdout);
				}
			}
		}

		
	}
    else
	{
		printf("\n Control Object for PESPTI_Post_Property not found......\n");fflush(stdout);
	}

	return ifail;
}
int tm_pespti_pe_part_pestimail(EPM_action_message_t msg)
{
	int Status=0;
	int	ifail = 0;
	tag_t pe_rootTask = NULLTAG;
	tag_t *pTagAttch;

    char *CurrentTask = NULL;
    char *parent_name = NULL;
	char *type_name	= NULL;
	char *partname	= NULL;
    FILE *fpM= NULL;
	int iNumAttch = 0;
	char *StrMailTmpl = NULL;
	char *StrMailSubj = NULL;
	char *StrMailText = NULL;
	char *MailDup = NULL;
	char *StrFullPathShell = NULL;
    int noAttachment = 0;
    int m = 0;
    int UserIterator = 0;
    int petisphasPartcount = 0;
    tag_t dml_rev_tag = NULLTAG;
    tag_t *petisphasPartcount_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    //tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
	tag_t PESPTIQryTag = NULLTAG;
    tag_t PESPTITag = NULLTAG;
    tag_t *PESPTIUserTags = NULLTAG;
    int PESPTIUserCount = 0;
    char *PESPTIUserOSName = NULL;
    char *peSpareToolIntRev = NULL;
    tag_t PESPTIPersonTag = NULLTAG;
    char *PESPTI_Analyst_email_addr = NULL;
    char *PESPTIUserMailConcat = NULL;
	StrMailTmpl = (char*) MEM_alloc(2000);
	StrMailSubj = (char*) MEM_alloc(400);
	partname = (char*) MEM_alloc(400);
	StrMailText = (char*) MEM_alloc(2000);
	StrFullPathShell=(char*) MEM_alloc(400);
	PESPTIUserMailConcat=(char*) MEM_alloc(400);
	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For MailNotification\n");fflush(stdout);
		qry_valuesCntrl1[0] = "Mail_Notification";
		qry_valuesCntrl1[1] = "Mail_Notification";
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{

		fpM = fopen("/tmp/PESPTIMail.cfg", "w");
		if(fpM ==NULL)
		{
			printf("Unable to Open file ");
			return -1;
		}
		else
		{
			printf("\nFile Open Successfully");
		}
		printf("\n Inside Registered Action Handler Pespti_PE_Part_PETISMail\n ");
		fflush(stdout);
		char    *PESPTIqry_entry[2]  = {"Status","Name"};
		char    **PESPTIqry_values= (char **) MEM_alloc(5 * sizeof(char *));
		char* t5_Userinfo1 = NULL;
		Status = QRY_find2("PESPTI_USER",&PESPTIQryTag);  //PESPTI_USER
		if(PESPTIQryTag!=NULLTAG)
		{
	
			printf("\n PESPTI_USER object query found");
			PESPTIqry_values[0] = "0";
			PESPTIqry_values[1] = "PESPTI";  //PESPTI
			Status = QRY_execute(PESPTIQryTag, 2, PESPTIqry_entry, PESPTIqry_values, &PESPTIUserCount, &PESPTIUserTags);
		
			printf("Query Count %d",PESPTIUserCount);
			for(UserIterator=0;UserIterator<PESPTIUserCount;UserIterator++)
			{
			
			printf("PESPTI User OS Name :  \n");
		
			Status = AOM_ask_value_tag(PESPTIUserTags[UserIterator],"person",&PESPTIPersonTag);
			Status = SA_ask_person_email_address(PESPTIPersonTag,&PESPTI_Analyst_email_addr);
		
			printf("PESPTI User Mail Address %s : \n",PESPTI_Analyst_email_addr);
			
			}

			//added 
			tc_strcpy(PESPTIUserMailConcat,"");
			tc_strcat(PESPTIUserMailConcat,"sanjayj1.ttl@tatamotors.com");
			tc_strcat(PESPTIUserMailConcat,",");
			tc_strcat(PESPTIUserMailConcat,"am927460.ttl@tatamotors.com");
			tc_strcat(PESPTIUserMailConcat,",");
			tc_strcat(PESPTIUserMailConcat,"sk923111.ttl@tatamotors.com");
			
			printf("\n~~~~~email id list %s ~~~~\n",PESPTIUserMailConcat);
		
			printf("PESPTI User Mail Concat list \n ");
			if (EPM_ask_root_task(msg.task, &pe_rootTask));
			if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
			printf("\n CurrentTask of pespti :%s\n", CurrentTask);
			if (AOM_ask_value_string(pe_rootTask, "object_name", &parent_name));
			printf("\n Parent Name pespti:%s\n", parent_name);
			fflush(stdout);
			if (EPM_ask_attachments(pe_rootTask, EPM_target_attachment, &noAttachment, &attachments)) ;
			printf("\n Target Attachment pespti:%d\n", noAttachment);
			fflush(stdout);
			if (noAttachment > 0)
			{
				dml_rev_tag = attachments[0];
				if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag));
				if (TCTYPE_ask_name2(objTypeTag, &type_name));
				Status=(AOM_ask_value_string(dml_rev_tag,"item_id",&peSpareToolIntRev));
				printf("\n type_name changes done: for workspaceobject  :%s\n", type_name);
				fflush(stdout);
			}
			tag_t relatn = NULLTAG;
			
			if(tc_strcmp(type_name, "T5_PEIndRevision") == 0)
			{
			
				Status=(GRM_find_relation_type("T5_PETISpHasPart",&relatn));
				Status=(GRM_list_secondary_objects_only(dml_rev_tag,relatn,&petisphasPartcount,&petisphasPartcount_tag));
				printf("\n~~~~~~~No of Part Count %d~~~~~~~~~~~",petisphasPartcount);
				if(petisphasPartcount>0)
				{
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:WO/PO Given For PE Spare Tool Indent : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Please find the Below Details for PE Spare Tool Indent:");
					tc_strcat(StrMailText, peSpareToolIntRev );
					tc_strcat(StrMailText, ".\n");
					//tc_strcat(StrMailText, ".Please find the below details.Request you to please update the required details which is blank :- \n");
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width = '600'>");
					tc_strcat(StrMailText, "<TR style='background-color:#FF7900'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "PartNumber");
					tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "PO");
					tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "WO");
					tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");
					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
					for(m=0;m<petisphasPartcount;m++)
					{
						char *workorder=NULL;
						char *po_number=NULL;
						Status=(AOM_ask_value_string(petisphasPartcount_tag[m],"t5_PrtN",&partname));	
						printf("\n~~~~~~~Part Number ~~~~~~~~~~~ %s",partname);
						Status=(AOM_ask_value_string(petisphasPartcount_tag[m],"t5_PrtProjPETISPPO",&po_number));	
						printf("\n~~~~~~~po number ~~~~~~~~~~~ %s",partname);
						Status=(AOM_ask_value_string(petisphasPartcount_tag[m],"t5_PrtProjPETISPWO",&workorder));	
						printf("\n~~~~~~~workorder~~~~~~~~~~~ %s",partname);
						tc_strcpy(StrMailText, "<TR style='background-color:#F8B88B'>");
						tc_strcat(StrMailText, "<TD>");
						tc_strcat(StrMailText, partname);
						tc_strcat(StrMailText, "</TD>");
						tc_strcat(StrMailText, "<TD>");
						tc_strcat(StrMailText, po_number);
						
						tc_strcat(StrMailText, "</TD>");
						tc_strcat(StrMailText, "<TD>");
						tc_strcat(StrMailText, workorder);
						
						tc_strcat(StrMailText, "</TD>");	
						tc_strcat(StrMailText, "</TR>");
						fprintf(fpM, StrMailText);//
					}
				}
				tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
				Status =AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &t5_Userinfo1);

				printf("t5_Userinfo1 path for the mail command = %s", t5_Userinfo1);

				tc_strcpy(StrFullPathShell,"");

				tc_strcat(StrFullPathShell,t5_Userinfo1);
		
				printf("Mail Excuting Command = %s", StrFullPathShell);
		
				system(StrFullPathShell);
			}

		}

    }
	else
	{
		printf("\n  Sunny .....Mail Notification Control Object not found");
	}
    	 
    return 0;

}
//sunny new changes allnode mail notification

int tm_pespti_pe_part_pestimailAllNode(EPM_action_message_t msg)
{
	int Status=0;
	int	ifail = 0;
	tag_t pe_rootTask = NULLTAG;
	tag_t *pTagAttch;

    char *CurrentTask = NULL;
    char *parent_name = NULL;
	char *type_name	= NULL;
	char *partname	= NULL;
    FILE *fpM= NULL;
	int iNumAttch = 0;
	char *StrMailTmpl = NULL;
	char *StrMailSubj = NULL;
	char *StrMailText = NULL;
	char *MailDup = NULL;
	char *StrFullPathShell = NULL;
    int noAttachment = 0;
    int m = 0;
    int UserIterator = 0;
    int petisphasPartcount = 0;
    tag_t dml_rev_tag = NULLTAG;
    tag_t *petisphasPartcount_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    //tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
	tag_t PESPTIQryTag = NULLTAG;
    tag_t PESPTITag = NULLTAG;
    tag_t *PESPTIUserTags = NULLTAG;
    int PESPTIUserCount = 0;
    char *PESPTIUserOSName = NULL;
    char *peSpareToolIntRev = NULL;
	char* PESPTIDescp = NULL;
    tag_t PESPTIPersonTag = NULLTAG;
    char *PESPTI_Analyst_email_addr = NULL;
    char *PESPTIUserMailConcat = NULL;
	StrMailTmpl = (char*) MEM_alloc(2000);
	StrMailSubj = (char*) MEM_alloc(400);
	partname = (char*) MEM_alloc(400);
	StrMailText = (char*) MEM_alloc(2000);
	StrFullPathShell=(char*) MEM_alloc(400);
	PESPTIUserMailConcat=(char*) MEM_alloc(400);
	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
	char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
	tag_t relatn = NULLTAG;

	printf("\n ---------------tm_pespti_pe_part_pestimailAllNode ----------------");

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For MailNotification\n");fflush(stdout);
		qry_valuesCntrl1[0] = "Mail_NotificationAllNode";
		qry_valuesCntrl1[1] = "Mail_NotificationAllNode";
		
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\n Number of control object found_Allnode:%d", control_number_found1);fflush(stdout);
	}
	if(control_number_found1>0)
	{

		fpM = fopen("/tmp/PESPTIMail_ALL.cfg", "w");
		if(fpM ==NULL)
		{
			printf("Unable to Open file ");
			return -1;
		}
		else
		{
			printf("\nFile Open Successfully");
		}
		printf("\n Inside Registered Action Handler Mail_NotificationAllNode \n ");
		fflush(stdout);
		char    *PESPTIqry_entry[2]  = {"Status","Name"};
		char    **PESPTIqry_values= (char **) MEM_alloc(5 * sizeof(char *));
		char* t5_Userinfo1 = NULL;
		Status = QRY_find2("PESPTI_USER",&PESPTIQryTag);  //PESPTI_USER
		//if(PESPTIQryTag!=NULLTAG)
		{
	
			printf("\n PESPTI_USER object query found");
			PESPTIqry_values[0] = "0";
			PESPTIqry_values[1] = "PESPTI";  //PESPTI
			Status = QRY_execute(PESPTIQryTag, 2, PESPTIqry_entry, PESPTIqry_values, &PESPTIUserCount, &PESPTIUserTags);
		
			printf("Query Count %d",PESPTIUserCount);
			for(UserIterator=0;UserIterator<PESPTIUserCount;UserIterator++)
			{
			
			printf("PESPTI User OS Name :  \n");
		
			Status = AOM_ask_value_tag(PESPTIUserTags[UserIterator],"person",&PESPTIPersonTag);
			Status = SA_ask_person_email_address(PESPTIPersonTag,&PESPTI_Analyst_email_addr);
		
			printf("PESPTI User Mail Address %s : \n",PESPTI_Analyst_email_addr);
			
			}

			//added 
			tc_strcpy(PESPTIUserMailConcat,"");
			tc_strcat(PESPTIUserMailConcat,"sanjayj1.ttl@tatamotors.com");
			tc_strcat(PESPTIUserMailConcat,",");
			tc_strcat(PESPTIUserMailConcat,"am927460.ttl@tatamotors.com");
			tc_strcat(PESPTIUserMailConcat,",");
			tc_strcat(PESPTIUserMailConcat,"sk923111.ttl@tatamotors.com");
			
			printf("\n~~~~~email id list %s ~~~~\n",PESPTIUserMailConcat);
		
			printf("PESPTI User Mail Concat list \n ");
			if (EPM_ask_root_task(msg.task, &pe_rootTask));
			if (AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
			printf("\n CurrentTask of pespti :%s\n", CurrentTask);
			if (AOM_ask_value_string(pe_rootTask, "object_name", &parent_name));
			printf("\n Parent Name pespti:%s\n", parent_name);
			fflush(stdout);
			if (EPM_ask_attachments(pe_rootTask, EPM_target_attachment, &noAttachment, &attachments)) ;
			printf("\n Target Attachment pespti:%d\n", noAttachment);
			fflush(stdout);
			if (noAttachment > 0)
			{
				dml_rev_tag = attachments[0];
				if (TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag));
				if (TCTYPE_ask_name2(objTypeTag, &type_name));
				Status=(AOM_ask_value_string(dml_rev_tag,"item_id",&peSpareToolIntRev));
				printf("\n type_name changes done: for workspaceobject  :%s\n", type_name);
				fflush(stdout);
				Status=(AOM_ask_value_string(dml_rev_tag,"object_desc",&PESPTIDescp));
				printf("\n Object description_Allnode:%s\n", PESPTIDescp);
				fflush(stdout);
			}
			

		
			
			if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "PE Indent Create") == 0))
			{
					printf("\n CurrentTask-----------------1 :%s\n", CurrentTask);
			
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:Notification Mail to complete assignment : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Following are the assignment details for :");
					tc_strcat(StrMailText,  peSpareToolIntRev);
					tc_strcat(StrMailText, ".\n");

					//added
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width='600' style='border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;'>");
					//tc_strcat(StrMailText, "<TR style='background-color:#8EEBEC'>");
					tc_strcat(StrMailText, "<TR style='background-color:#2E8B57;color:white;font-weight:bold;'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Process Name");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, peSpareToolIntRev);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Current Task");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, CurrentTask);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F5FFFA'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item Description");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, PESPTIDescp);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item type");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, type_name);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");



					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
			
				
				 tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
	
			}
			else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "PE Spare Tool Indent Review") == 0))
			{
				printf("\n CurrentTask-----------------2 :%s\n", CurrentTask);
			
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:Notification Mail to complete assignment : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Following are the assignment details for :");
					tc_strcat(StrMailText,  peSpareToolIntRev);
					tc_strcat(StrMailText, ".\n");

					//added
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width='600' style='border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;'>");
					//tc_strcat(StrMailText, "<TR style='background-color:#8EEBEC'>");
					tc_strcat(StrMailText, "<TR style='background-color:#2E8B57;color:white;font-weight:bold;'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Process Name");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, peSpareToolIntRev);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Current Task");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, CurrentTask);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F5FFFA'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item Description");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, PESPTIDescp);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item type");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, type_name);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");



					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
			
				
				 tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
			}
			else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of Work Order") == 0))
			{
				printf("\n CurrentTask-----------------3 :%s\n", CurrentTask);
			
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:Notification Mail to complete assignment : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Following are the assignment details for :");
					tc_strcat(StrMailText,  peSpareToolIntRev);
					tc_strcat(StrMailText, ".\n");

					//added
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width='600' style='border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;'>");
					//tc_strcat(StrMailText, "<TR style='background-color:#8EEBEC'>");
					tc_strcat(StrMailText, "<TR style='background-color:#2E8B57;color:white;font-weight:bold;'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Process Name");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, peSpareToolIntRev);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Current Task");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, CurrentTask);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F5FFFA'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item Description");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, PESPTIDescp);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item type");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, type_name);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");



					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
			
				
				 tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
			}
			else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of PO") == 0))
			{
				printf("\n CurrentTask-----------------4 :%s\n", CurrentTask);
			
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:Notification Mail to complete assignment : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Following are the assignment details for :");
					tc_strcat(StrMailText,  peSpareToolIntRev);
					tc_strcat(StrMailText, ".\n");

					//added
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width='600' style='border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;'>");
					//tc_strcat(StrMailText, "<TR style='background-color:#8EEBEC'>");
					tc_strcat(StrMailText, "<TR style='background-color:#2E8B57;color:white;font-weight:bold;'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Process Name");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, peSpareToolIntRev);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Current Task");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, CurrentTask);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F5FFFA'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item Description");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, PESPTIDescp);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item type");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, type_name);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");



					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
			
				
				 tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
			}
			else if((tc_strcmp(type_name, "T5_PEIndRevision") == 0) && (tc_strcmp(CurrentTask, "Updation Of Receipt Qty") == 0))
			{
					printf("\n CurrentTask-----------------5 :%s\n", CurrentTask);
			
					tc_strcpy(StrMailTmpl, "To:");
					tc_strcat(StrMailTmpl,PESPTIUserMailConcat);
					tc_strcat(StrMailTmpl, ";");
					tc_strcat(StrMailTmpl, MailDup);										
					tc_strcat(StrMailTmpl, "\n");
					sprintf(StrMailSubj, "SUBJECT:Notification Mail to complete assignment : %s ",peSpareToolIntRev);
					tc_strcat(StrMailTmpl,StrMailSubj);
					tc_strcat(StrMailTmpl,"\n");
					tc_strcat(StrMailTmpl, "MIME-Version: 1.0\n");
					tc_strcat(StrMailTmpl, "Content-Type: text/html; charset='us-ascii'\n");
					tc_strcat(StrMailTmpl, "Content-Disposition: inline\n");
					printf("StrMailTmpl : [%s]\n", StrMailTmpl);fflush(stdout);
					fprintf(fpM, StrMailTmpl);
					
					tc_strcpy(StrMailText, "<SPAN>");
					tc_strcat(StrMailText, "<FONT FACE='verdana' COLOR='DarkBlue'>Dear All,<BR/><BR/>");
					tc_strcat(StrMailText, "Following are the assignment details for :");
					tc_strcat(StrMailText,  peSpareToolIntRev);
					tc_strcat(StrMailText, ".\n");

					//added
					tc_strcat(StrMailText, "<BR/><BR/>");
					tc_strcat(StrMailText, "<TABLE BORDER='1' width='600' style='border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;'>");
					//tc_strcat(StrMailText, "<TR style='background-color:#8EEBEC'>");
					tc_strcat(StrMailText, "<TR style='background-color:#2E8B57;color:white;font-weight:bold;'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Process Name");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, peSpareToolIntRev);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Current Task");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, CurrentTask);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F5FFFA'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item Description");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, PESPTIDescp);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");

					tc_strcat(StrMailText, "<TR style='background-color:#F0FFF0'>");
					tc_strcat(StrMailText, "<TD>");
					tc_strcat(StrMailText, "Item type");
					tc_strcat(StrMailText, "</TD>");

					tc_strcat(StrMailText, "<TD>");
					 tc_strcat(StrMailText, type_name);
					 tc_strcat(StrMailText, "</TD>");
					tc_strcat(StrMailText, "</TR>");



					fprintf(fpM, StrMailText);
					printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
			
				
				 tc_strcpy(StrMailText, "</TABLE>");
				tc_strcat(StrMailText, "<BR/><BR/>--<BR/>Regards<BR/>PLM TEAM<BR/><BR/><BR/>** NOTE : This is a system generated e-mail and please do not reply to sender.<BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>");
				tc_strcat(StrMailText, "</SPAN>");
				printf("StrMailText : [%s]\n", StrMailText);fflush(stdout);
				fprintf(fpM, StrMailText);  
				
				if(fpM) fclose(fpM); 
				printf("1StrMailText : [%s]\n", StrMailText);	fflush(stdout);
				
			}
			else
			{
				printf(" \n Invalid condition ");
			}

			Status =AOM_ask_value_string(list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &t5_Userinfo1);

			printf("t5_Userinfo1 path for the mail command = %s", t5_Userinfo1);

			tc_strcpy(StrFullPathShell,"");

			tc_strcat(StrFullPathShell,t5_Userinfo1);
	
			printf("Mail Excuting Command = %s", StrFullPathShell);
	
			system(StrFullPathShell);

		}

    }
	else
	{
		printf("\n  Sunny .....Mail Notification Control Object not found");
	}
    	 
    return 0;

}


//sunny end

//validation
int pespti_indentqty_rptqty_check(EPM_action_message_t msg)
{

    int error_code = ITK_ok;
    int ifail = 0;

    char *Proj_Code = NULL;
    char *item_type = NULL;
     char	*type_name				=	NULL;
    char *object_name1 = NULL;
    char *DML_no = NULL;
    char **DesignGroupList;
    char *CurrentTask = NULL;
    char *parent_name = NULL;
    char *ecntypeVal = NULL;

    int TaskCnt = 0;
    int count = 0;
    int noAttachment, noTaskAttachment = 0;
    tag_t APLTaskRevT = NULLTAG;
    tag_t dml_rev_tag = NULLTAG;
    tag_t objTypeTag = NULLTAG;
    tag_t rootTask = NULLTAG;
    tag_t *attachments = NULLTAG;
    tag_t relation_type = NULLTAG;
    tag_t *TaskRevision = NULLTAG;
	int PEIndQtyflag=0;

    printf("\n Inside Registered Action Handler pespti_indentqty_rptqty_check \n ");
    fflush(stdout);

    ITK_CALL(EPM_ask_root_task(msg.task, &rootTask));
	ITK_CALL(AOM_ask_value_string(msg.task, "object_name", &CurrentTask));
    printf("\n CurrentTask of pespti-- :%s\n", CurrentTask);
	ITK_CALL(AOM_ask_value_string(rootTask, "object_name", &parent_name));
    printf("\n Parent Name pespti--:%s\n", parent_name);
    fflush(stdout);
    ITK_CALL(EPM_ask_attachments(rootTask, EPM_target_attachment, &noAttachment, &attachments));
    printf("\n Target Attachment pespti--:%d\n", noAttachment);
    fflush(stdout);
    if (noAttachment > 0)
    {
        dml_rev_tag = attachments[0];
        ITK_CALL(TCTYPE_ask_object_type(dml_rev_tag, &objTypeTag));
       ITK_CALL (TCTYPE_ask_name2(objTypeTag, &type_name));
        printf("\n type_name changes done: for workspaceobject--  :%s\n", type_name);
        fflush(stdout);
    }

    if (strcmp(type_name, "T5_PEIndRevision") == 0)
	{
       printf("\n --inside class T5_PEIndRevision......\n");
        fflush(stdout);
       AOM_ask_value_string(dml_rev_tag, "object_name", &object_name1);
		printf("\n --inside class object_name...... ;%s\n", object_name1);
		fflush(stdout);
        AOM_ask_value_string(dml_rev_tag, "current_id", &DML_no);fflush(stdout);
		printf("\n --inside class current_id......  ;%s\n", DML_no );
		fflush(stdout);

		int PEIndQty=0;

		int PEIndRcptQty=0;

		AOM_ask_value_int(dml_rev_tag, "t5_PEIndQty", &PEIndQty);
		printf("\n inside class object_name...... %d\n", PEIndQty);
		fflush(stdout);
        AOM_ask_value_int(dml_rev_tag, "t5_PEIndRcptQty", &PEIndRcptQty);fflush(stdout);
		printf("\n inside class current_id......  %d\n", PEIndRcptQty );
		fflush(stdout);


		//if (PEIndQty>=PEIndRcptQty)
		if (PEIndQty<=PEIndRcptQty)
		{
			printf("\n condition matched\n" );fflush(stdout);
			PEIndQtyflag++;

		}
		else
		{
			printf("\n condition not found \n" );fflush(stdout);

		}

        printf("\n calling function to  assign the user for the task : %s having assugnment  / PE Indent Create / PE Spare Tool Indent Review /  Updation Of Work Order / Updation Of PO  / Updation Of Receipt Qty  \n",object_name1);fflush(stdout);

	}
    else
    {
        printf("\n class T5_PEIndRevision not found......\n");
        fflush(stdout);
    }

	printf("\n PEIndQtyflag......  %d\n", PEIndQtyflag );
		fflush(stdout);

		if(PEIndQtyflag>0)
		{
			return ITK_ok;

		}
		else
		{
			return ITK_errStore;	
		}

    return 0;
}
extern int tm_pespti_assign_register_method(int *decision, va_list args)							
{
	
	int	ifail = 0;
	*decision = ALL_CUSTOMIZATIONS;
	METHOD_id_t  method_pespti_checkin;
	METHOD_id_t  method_pespti_checkin1;
	METHOD_id_t method_pespti_save;
	if (ifail == EPM_register_action_handler("pespti_task_assigment", "", pespti_task_assigment))
    {
        printf("\n Registered Action Handler pespti_task_assigment \n");
        fflush(stdout);
    }
    else
    {
        printf("\n FAILED to register Action Handler pespti_task_assigment \n");
        fflush(stdout);
    }

	// if (ifail == EPM_register_action_handler("tm_pespti_SendMail","",tm_pespti_SendMail))
    // {
    //     printf("\n Registered Action Handler tm_pespti_SendMail \n");
    //     fflush(stdout);
    // }
    // else
    // {
    //     printf("\n FAILED to register Action Handler tm_pespti_SendMail \n");
    //     fflush(stdout);
    // }

	if(ifail == EPM_register_rule_handler("Pespti_PE_Part_signoff_validation","This Handler is used to display message",(EPM_rule_handler_t)Pespti_PE_Part_signoff_validation))
	{
		printf("\n Registered Rule Handler Pespti_PE_Part_signoff_validation \n");
        fflush(stdout);
	}
	else
	{
		printf("\n FAILED to register Rule Handler Pespti_PE_Part_signoff_validation \n");
        fflush(stdout);
	}

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_pespti_checkin));
	if (method_pespti_checkin.id != NULL)
	{
		
		
		ITK_CALL(METHOD_add_pre_condition(method_pespti_checkin, (METHOD_function_t)PESPTI_Checkin_PreCond_Validation, NULL));
		printf("\n method_pespti_checkin found\n"); fflush(stdout);
	}
	else
	{
		printf("\n method_pespti_checkin not found\n"); fflush(stdout);
		
	}

	ITK_CALL(METHOD_find_method(RES_Type, RES_checkin_msg, &method_pespti_checkin1));
    if (method_pespti_checkin1.id != NULL)
    {
        ITK_CALL(METHOD_add_action(method_pespti_checkin1, METHOD_post_action_type, (METHOD_function_t)PESPTI_Post_Partattach, NULL));
        printf("\n method_pespti_checkin1 found\n"); fflush(stdout);
    }
    else
    {
        printf("\n method_pespti_checkin1 not found\n"); fflush(stdout);
    }

    if (ifail == EPM_register_action_handler("tm_pespti_pe_part_pestimail","",tm_pespti_pe_part_pestimail))
    {
        printf("\n Registered Action Handler tm_pespti_pe_part_pestimail \n");
        fflush(stdout);
    }
    else
    {
        printf("\n FAILED to register Action Handler tm_pespti_pe_part_pestimail \n");
        fflush(stdout);
    }

	ITK_CALL(METHOD_find_method("T5_PEIndRevision", TC_save_msg, &method_pespti_save));
    if (method_pespti_save.id != NULL)
    {
        ITK_CALL(METHOD_add_action(method_pespti_save, METHOD_post_action_type, (METHOD_function_t)PESPTI_Post_Property, NULL));
        printf("\n method_pespti_save found\n"); fflush(stdout);
    }
    else
    {
        printf("\n method_pespti_save not found\n"); fflush(stdout);
    }

    //sunny
	if (ifail == EPM_register_action_handler("tm_pespti_pe_part_pestimailAllNode","",tm_pespti_pe_part_pestimailAllNode))
    {
        printf("\n Registered Action Handler tm_pespti_pe_part_pestimailAllNode \n");
        fflush(stdout);
    }
    else
    {
        printf("\n FAILED to register Action Handler tm_pespti_pe_part_pestimailAllNode \n");
	}

	//validation

	if (ifail == EPM_register_action_handler("pespti_indentqty_rptqty_check","",pespti_indentqty_rptqty_check))
    {
        printf("\n Registered Action Handler pespti_indentqty_rptqty_check \n");
        fflush(stdout);
    }
    else
    {
        printf("\n FAILED to register Action Handler pespti_indentqty_rptqty_check \n");
	}

return ifail;	
}


extern DLLAPI int tm_pespti_assign_register_callbacks()
{
    CUSTOM_register_exit("tm_pespti_assign", "USER_init_module", (CUSTOM_EXIT_ftn_t)tm_pespti_assign_register_method);
 
    printf("\n register function tm_pespti_assign \n");
    fflush(stdout);
 
    return (ITK_ok);
}