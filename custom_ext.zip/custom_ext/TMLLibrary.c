#include "TMLLibrary_server_exits.h"

#include "tml_action_handlers/CM_Remove_Subprocesses.c"
#include "tml_action_handlers/CM_Gen_DML_PrintReport.c"
#include "tml_action_handlers/DCR_ChngSpeclist_assign.c"
#include "tml_action_handlers/data_share_process.c"
#include "tml_action_handlers/CM_ImpactAnalysisReport.c"
#include "tml_action_handlers/tm_POChkStopAtF.c"
#include "tml_action_handlers/tm_GMDpartDRUpd.c"
#include "tml_action_handlers/tm_MDMpartMSUpd.c"
#include "tml_action_handlers/tm_ConnectedDML.c"
#include "tml_action_handlers/tm_DMLPrintRpt.c"
#include "tml_action_handlers/tm_CheckVCMSforNOPO.c"
#include "tml_action_handlers/tm_ExpMulLevelForGMD.c"
#include "tml_action_handlers/CM_FillInstru.c"
#include "tml_action_handlers/CM_SetOccEff.c"
#include "tml_action_handlers/tm_vc_stamp.c"
#include "tml_action_handlers/CM_SetAttr.c"
#include "tml_action_handlers/CM_MR_SetOccEff.c"
#include "tml_action_handlers/CM_DM_SetEff.c"
#include "tml_action_handlers/tm_VMLTReviewerForTask.c"
#include "tml_action_handlers/tm_ERC_DML_Release_Report.c"
#include "tml_action_handlers/tm_DML_Mail_WF_AH_Func.c"
#include "tml_action_handlers/tm_ChkStandaloneVC.c"
#include "tml_action_handlers/tm_00TaskCheck.c"
#include "tml_action_handlers/tm_taskCheck21.c"
#include "tml_action_handlers/tm_NPIDR2act.c"
#include "tml_action_handlers/tm_TANChk_act.c"
#include "tml_action_handlers/CM_DCR_MailApproval.c"
#include "tml_action_handlers/tm_color_PartChk.c"

#include "tml_pre_actions/SVR_ChildSVR_Rel.c"
//#include "tml_pre_actions/Set_UIDpre.c"
#include "tml_post_actions/SnapShotFormSave.c"
//#include "tml_post_actions/Set_Chasis_details.c"
//#include "tml_post_actions/Set_OccUID.c"
#include "tml_post_actions/Set_tskdesc.c"

#include "tml_rule_handlers/CM_Check_Implements_Objects.c"
#include "tml_rule_handlers/CM_Check_DCR_Objects.c"
#include "tml_rule_handlers/CM_Check_SVRappli.c"
#include "tml_rule_handlers/tm_POChkStopAtFVali.c"
#include "tml_rule_handlers/tm_POChkMangVali.c"
#include "tml_rule_handlers/tm_PTModuleCheck.c"
#include "tml_rule_handlers/tm_Check_SVR_WrkFlw.c"
#include "tml_rule_handlers/tm_Check_VC_WrkFlw.c"
#include "tml_rule_handlers/CM_Update_Variant_Formula.c"
#include "tml_rule_handlers/CM_checkOcc.c"
#include "tml_rule_handlers/tm_MRQty_Check.c"
#include "tml_rule_handlers/CM_Checklist_Signoff.c"
#include "tml_rule_handlers/tm_BOMcompleteness.c"
#include "tml_rule_handlers/tm_WeightRollupValid.c"
#include "tml_rule_handlers/tm_Rule_Veh_taskSignOffRule.c"
#include "tml_rule_handlers/tm_ModuleAddPlatFormValiRule.c"
#include "tml_rule_handlers/tm_NPICode_Review.c"
#include "tml_rule_handlers/tm_TANReview.c"
#include "tml_rule_handlers/tm_SCOPEReview.c"
#include "tml_rule_handlers/tm_DRGatewayChk.c"
#include "tml_rule_handlers/tm_ECUChk.c"
#include "tml_rule_handlers/tm_WeightRollupChk.c"
//#include "tml_rule_handlers/tm_Veh_Task_Check.c"

int ifail=ITK_ok;
METHOD_id_t  method1;
METHOD_id_t  method2;
METHOD_id_t  method3;
METHOD_id_t  method4;
METHOD_id_t  method5;

extern DLLAPI int TMLLibrary_register_callbacks()
{
	CUSTOM_register_exit("TMLLibrary", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t) TML_register_custom_handlers);
	return ITK_ok;
}

extern DLLAPI int TML_register_custom_handlers(int *decision, va_list args)
{
	//int ifail=ITK_ok;
	
	ifail=TML_register_action_handlers();
	ifail=TML_register_rule_handlers();
	ifail=TML_register_pre_actions();
	ifail=TML_register_post_actions();
	
	
	*decision=ALL_CUSTOMIZATIONS;
	return ifail;
}

int TML_register_action_handlers()
{
	ITK_CALL(EPM_register_action_handler("CM_Gen_DML_PrintReport", "Action Handler to Generate DML Print Report and attach to DML", CM_Gen_DML_PrintReport));
	TC_write_syslog("Registered Action Handler CM_Gen_DML_PrintReport..\n");
	ITK_CALL(EPM_register_action_handler("CM_Remove_Subprocesses", "Action Handler to Remove DML Task Subprocesses", CM_Remove_Subprocesses));
	TC_write_syslog("Registered Action Handler CM_Remove_Subprocesses..\n");

	ITK_CALL(EPM_register_action_handler("DCR_ChngSpeclist_assign", "Action Handler to Assign ChngSpeclist to DCR", DCR_ChngSpeclist_assign));
	TC_write_syslog("Registered Action Handler DCR_ChngSpeclist_assign..\n");

	ITK_CALL(EPM_register_action_handler("data_share_process", "Action Handler to trasnfer date thru share data utility", data_share_process));
	TC_write_syslog("Registered Action Handler data_share_process..\n");
    
	ITK_CALL(EPM_register_action_handler("CM_ImpactAnalysisReport", "Action Handler to impact analysis report", CM_ImpactAnalysisReport));
	TC_write_syslog("Registered Action Handler CM_ImpactAnalysisReport..\n");

	ITK_CALL(EPM_register_action_handler("CM_CreateCCVfromSVR", "Action Handler to impact analysis report", CM_CreateCCVfromSVR));
	TC_write_syslog("Registered Action Handler CM_CreateCCVfromSVR..\n");

	ITK_CALL(EPM_register_action_handler("CM_CreateSnapShotfromSVR", "Action Handler to impact analysis report", CM_CreateSnapShotfromSVR));
	TC_write_syslog("Registered Action Handler CM_CreateSnapShotfromSVR..\n");

	ITK_CALL(EPM_register_action_handler("CM_CreateCCVfromSingleSVR", "Action Handler to impact analysis report", CM_CreateCCVfromSingleSVR));
	TC_write_syslog("Registered Action Handler CM_CreateCCVfromSingleSVR..\n");

	ITK_CALL(EPM_register_action_handler("CM_CreateSnapShotfromSingleSVR", "Action Handler to impact analysis report", CM_CreateSnapShotfromSingleSVR));
	TC_write_syslog("Registered Action Handler CM_CreateSnapShotfromSingleSVR..\n");

	ITK_CALL(EPM_register_action_handler("tm_POChkStopAtF", "PO check for DR4", tm_POChkStopAtF));
	TC_write_syslog("Registered Action Handler tm_POChkStopAtF..\n");

	ITK_CALL(EPM_register_action_handler("tm_GMDpartDRUpd", "PO check for DR4", tm_GMDpartDRUpd));
	TC_write_syslog("Registered Action Handler tm_GMDpartDRUpd..\n");
	
	ITK_CALL(EPM_register_action_handler("tm_MDMpartMSUpd", "PO check for DR4", tm_MDMpartMSUpd));
	TC_write_syslog("Registered Action Handler tm_MDMpartMSUpd..\n");

	ITK_CALL(EPM_register_action_handler("tm_ConnectedDML", "Action Handler for Dependent DML", tm_ConnectedDML));
	TC_write_syslog("Registered Action Handler tm_ConnectedDML..\n");

	ITK_CALL(EPM_register_action_handler("tm_DMLPrintRpt", "Action Handler for Print Report", tm_DMLPrintRpt));
	TC_write_syslog("Registered Action Handler tm_DMLPrintRpt..\n");

	ITK_CALL(EPM_register_action_handler("tm_CheckVCMSforNOPO", "PO check for DR4", tm_CheckVCMSforNOPO));
	TC_write_syslog("Registered Action Handler tm_CheckVCMSforNOPO..\n");

	ITK_CALL(EPM_register_action_handler("tm_ExpMulLevelForGMD", "Exp till N level for GMD", tm_ExpMulLevelForGMD));
	TC_write_syslog("Registered Action Handler tm_ExpMulLevelForGMD..\n");

	ITK_CALL(EPM_register_action_handler("CM_FillInstru", "Fill instruction on perform task", CM_FillInstru));
	TC_write_syslog("Registered Action Handler CM_FillInstru..\n");

	ITK_CALL(EPM_register_action_handler("CM_SetOccEff", "update varient formula on signoff", CM_SetOccEff));
	TC_write_syslog("Registered Action Handler CM_SetOccEff..\n");

	ITK_CALL(EPM_register_action_handler("tm_vc_stamp", "Fill instruction on perform task", tm_vc_stamp));
	TC_write_syslog("Registered Action Handler tm_vc_stamp..\n");

	ITK_CALL(EPM_register_action_handler("CM_SetAttr", "CM_SetAttr on perform task", CM_SetAttr));
	TC_write_syslog("Registered Action Handler CM_SetAttr..\n");

	ITK_CALL(EPM_register_action_handler("CM_MR_SetOccEff", "CM_MR_SetOccEff on perform task", CM_MR_SetOccEff));
	TC_write_syslog("Registered Action Handler CM_MR_SetOccEff..\n");

	ITK_CALL(EPM_register_action_handler("CM_DM_SetEff", "CM_DM_SetEff on perform task", CM_DM_SetEff));
	TC_write_syslog("Registered Action Handler CM_DM_SetEff..\n");

	ITK_CALL(EPM_register_action_handler("CM_ApplyOccuEffect", "Fill instruction on perform task", CM_ApplyOccuEffect));
	TC_write_syslog("Registered Action Handler CM_ApplyOccuEffect..\n");

	ITK_CALL(EPM_register_action_handler("tm_VMLTReviewerForTask", "VMTL Reviewer Set", tm_VMLTReviewerForTask));
	TC_write_syslog("Registered Action Handler tm_VMLTReviewerForTask..\n");

	ITK_CALL(EPM_register_action_handler("tm_ERC_DML_Release_Report", "DML Release Report", tm_ERC_DML_Release_Report));
	TC_write_syslog("Registered Action Handler tm_ERC_DML_Release_Report..\n");

	ITK_CALL(EPM_register_action_handler("tm_DML_Mail_WF_AH_Func", "DML Release mail", tm_DML_Mail_WF_AH_Func));
	TC_write_syslog("Registered Action Handler tm_DML_Mail_WF_AH_Func..\n");

	//tm_ChkStandaloneVC
	ITK_CALL(EPM_register_action_handler("tm_ChkStandaloneVC", "Check Standalone VC", tm_ChkStandaloneVC));
	TC_write_syslog("Registered Action Handler tm_ChkStandaloneVC..\n");
	//tm_00TaskCheck
	ITK_CALL(EPM_register_action_handler("tm_00TaskCheck", "Check 00 task", tm_00TaskCheck));
	TC_write_syslog("Registered Action Handler tm_00TaskCheck..\n");

	ITK_CALL(EPM_register_action_handler("tm_taskCheck21", "Check 21 and 50 task", tm_taskCheck21));
	TC_write_syslog("Registered Action Handler tm_taskCheck21..\n");

	ITK_CALL(EPM_register_action_handler("tm_NPIDR2act", "Check NPI task", tm_NPIDR2act));
	TC_write_syslog("Registered Action Handler tm_NPIDR2act..\n");

	ITK_CALL(EPM_register_action_handler("tm_TANChk_act", "Check TAN task", tm_TANChk_act));
	TC_write_syslog("Registered Action Handler tm_TANChk_act..\n");

	ITK_CALL(EPM_register_action_handler("tm_color_PartChk", "BOM_Review_Validate", tm_color_PartChk));
	TC_write_syslog("Registered Action Handler tm_color_PartChk..\n");

	ITK_CALL(EPM_register_action_handler("CM_DCR_MailApproval", "VMTL Reviewer Set", CM_DCR_MailApproval));
	TC_write_syslog("Registered Action Handler CM_DCR_MailApproval..\n");

	ITK_CALL(EPM_register_action_handler("tm_CreateCCVCAndSnapSfrmSVRforCV", "Action Handler for CCVC-Bom of CV", tm_CreateCCVCAndSnapSfrmSVRforCV));
	TC_write_syslog("Registered Action Handler tm_CreateCCVCAndSnapSfrmSVRforCV..\n");

	ITK_CALL(EPM_register_action_handler("tm_IsAtrozWayCreateVC", "Action Handler for VC creation by Altroz-way", tm_IsAtrozWayCreateVC));
	TC_write_syslog("Registered Action Handler tm_IsAtrozWayCreateVC..\n");

	return ITK_ok;
}

int TML_register_rule_handlers()
{
	EPM_register_rule_handler("CM_Check_Implements_Objects","Rule handler to validate DCR implemented by DML",CM_Check_Implements_Objects);
	TC_write_syslog("Registered rule Handler CM_Check_Implements_Objects..\n");
	EPM_register_rule_handler("CM_Check_DCR_Objects","Rule handler to validate DCR implemented by DML",CM_Check_DCR_Objects);
	TC_write_syslog("Registered rule Handler CM_Check_DCR_Objects..\n");
	EPM_register_rule_handler("CM_Check_SVRappli","Rule handler to check SVR applicability",CM_Check_SVRappli);
	TC_write_syslog("Registered rule Handler CM_Check_SVRappli..\n");

	EPM_register_rule_handler("tm_POChkStopAtFVali","Rule handler to check basic PO Validations",tm_POChkStopAtFVali);
	TC_write_syslog("Registered rule Handler tm_POChkStopAtFVali..\n");
	EPM_register_rule_handler("tm_POChkMangVali","Rule handler to check basic PO Validations",tm_POChkMangVali);
	TC_write_syslog("Registered rule Handler tm_POChkMangVali..\n");

	EPM_register_rule_handler("tm_PTModuleCheck","Rule handler to check module release for TCE",tm_PTModuleCheck);
	TC_write_syslog("Registered rule Handler tm_PTModuleCheck..\n");
	EPM_register_rule_handler("ChkPTModule","Rule handler to check module release for TCE",ChkPTModule);
	TC_write_syslog("Registered rule Handler ChkPTModule..\n");

	EPM_register_rule_handler("tm_Check_SVR_WrkFlw","Rule handler to check module release for TCE",tm_Check_SVR_WrkFlw);
	TC_write_syslog("Registered rule Handler tm_Check_SVR_WrkFlw..\n");

	EPM_register_rule_handler("tm_Check_VC_WrkFlw","Rule handler to check module release for TCE",tm_Check_VC_WrkFlw);
	TC_write_syslog("Registered rule Handler tm_Check_VC_WrkFlw..\n");

	EPM_register_rule_handler("CM_Update_Variant_Formula","Rule handler to check module Variant formula",CM_Update_Variant_Formula);
	TC_write_syslog("Registered rule Handler CM_Update_Variant_Formula..\n");

	EPM_register_rule_handler("CM_checkOcc","Rule handler to check if Occurance option enable or disable",CM_checkOcc);
	TC_write_syslog("Registered rule Handler CM_checkOcc..\n");

	EPM_register_rule_handler("tm_MRQty_Check","Rule handler to check if Module has 0 Qty or Dummy Part Type in BOM",tm_MRQty_Check);
	TC_write_syslog("Registered rule Handler tm_MRQty_Check..\n");

	EPM_register_rule_handler("CM_Checklist_Signoff","Rule handler to check if manager has filled all required attributes",CM_Checklist_Signoff);
	TC_write_syslog("Registered rule Handler CM_Checklist_Signoff..\n");

	EPM_register_rule_handler("tm_BOMcompleteness","Rule handler to check BOM completeness",tm_BOMcompleteness);
	TC_write_syslog("Registered rule Handler tm_BOMcompleteness..\n");

	EPM_register_rule_handler("tm_WeightRollupValid","Rule handler to check BOM completeness",tm_WeightRollupValid);
	TC_write_syslog("Registered rule Handler tm_WeightRollupValid..\n");
	
	EPM_register_rule_handler("tm_Rule_Veh_taskSignOffRule","Rule for CV Veh DML signOff",tm_Rule_Veh_taskSignOffRule);
	TC_write_syslog("Registered rule Handler tm_Rule_Veh_taskSignOffRule..\n");

	EPM_register_rule_handler("tm_ModuleAddPlatFormValiRule","Rule for Modular BOM Check",tm_ModuleAddPlatFormValiRule);
	TC_write_syslog("Registered rule Handler tm_ModuleAddPlatFormValiRule..\n");
	//tm_NPICode_Review
	EPM_register_rule_handler("tm_NPICode_Review","Rule for NPI Review",tm_NPICode_Review);
	TC_write_syslog("Registered rule Handler tm_NPICode_Review..\n");

	EPM_register_rule_handler("tm_TANReview","Rule for TAN Review",tm_TANReview);
	TC_write_syslog("Registered rule Handler tm_TANReview..\n");

	EPM_register_rule_handler("tm_SCOPEReview","Rule for DML Scope Review",tm_SCOPEReview);
	TC_write_syslog("Registered rule Handler tm_SCOPEReview..\n");

	EPM_register_rule_handler("tm_DRGatewayChk","Rule for Checklist Review",tm_DRGatewayChk);
	TC_write_syslog("Registered rule Handler tm_DRGatewayChk..\n");

	EPM_register_rule_handler("tm_ECUChk","Rule for ECU Chk",tm_ECUChk);
	TC_write_syslog("Registered rule Handler tm_ECUChk..\n");

	EPM_register_rule_handler("tm_WeightRollupChk","Rule for WeightRollupChk",tm_WeightRollupChk);
	TC_write_syslog("Registered rule Handler tm_WeightRollupChk..\n");



	/*//tm_Veh_Task_Check
	EPM_register_rule_handler("tm_Veh_Task_Check","Rule for Veh Task check",tm_Veh_Task_Check);
	TC_write_syslog("Registered rule Handler tm_Veh_Task_Check..\n");*/

	EPM_register_rule_handler("CM_DMLCheckList","Rule handler to check DML Checklist",CM_DMLCheckList);
	TC_write_syslog("Registered rule Handler CM_DMLCheckList..\n");

	EPM_register_rule_handler("CM_IncompleteVC","Rule handler to check DML Checklist",CM_IncompleteVC);   // Under file - tm_PTModuleCheck.c
	TC_write_syslog("Registered rule Handler CM_IncompleteVC..\n");

	return ITK_ok;
}

//int TML_register_pre_actions()
//{
//	if(METHOD_find_method("T5_HasChassisTypeNo", GRM_create_msg, &method1)!=ITK_ok);
//   if( ifail == ITK_ok )
//   {
//	    printf("\n Before register method for GRM_create_msg for Set_Chasis_details \n");fflush(stdout);
//	    if (method1.id != NULLTAG)
//	    {
//			if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) Set_Chasis_details, NULL)!=ITK_ok)
//			printf("Registered as METHOD_pre_action_type for Set_Chasis_details \n");fflush(stdout);
//	    }else
//		printf("Method not found!GRM_create_msg\n");fflush(stdout);
//	}
//	return ITK_ok;
//}

int TML_register_pre_actions()
{
	if(METHOD_find_method("T5_HasChildSVR", GRM_create_msg, &method2)!=ITK_ok);
   if( ifail == ITK_ok )
   {
	    printf("\n Before register method for GRM_create_msg for SVR_ChildSVR_Rel \n");fflush(stdout);
	    if (method2.id != NULLTAG)
	    {
			if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) SVR_ChildSVR_Rel, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for SVR_ChildSVR_Rel \n");fflush(stdout);
	    }else
		printf("Method not found!GRM_create_msg\n");fflush(stdout);
	}

//	if(METHOD_find_method("T5_ModuleVF_to_Change", IMAN_save_msg, &method5)!=ITK_ok);
//   if( ifail == ITK_ok )
//   {
//	    printf("\n Before register method for IMAN_save_msg for Set_UIDpre \n");fflush(stdout);
//	    if (method5.id != NULLTAG)
//	    {
//			if( METHOD_add_action(method5, METHOD_pre_action_type, (METHOD_function_t) Set_UIDpre, NULL)!=ITK_ok)
//			printf("Registered as METHOD_pre_action_type for Set_OccUIDpre \n");fflush(stdout);
//	    }else
//		printf("Method not found!IMAN_save_msg111111111\n");fflush(stdout);
//	}

	
	return ITK_ok;
}

int TML_register_post_actions()
{
	if(METHOD_find_method("T5_SnapShot", IMAN_save_msg, &method3)!=ITK_ok);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for Snapshot save \n");fflush(stdout);
		if (method3.id != NULLTAG)
		{
			if( METHOD_add_action(method3, METHOD_post_action_type, (METHOD_function_t) SnapShotFormSave, NULL)!=ITK_ok)
			printf("Registered as METHOD_post_action_type for snapshor form create \n");fflush(stdout);
		}else
		printf("Method not found!IMAN_Save\n");fflush(stdout);
	}

//	if(METHOD_find_method("T5_ModuleVF_to_Change", IMAN_save_msg, &method4)!=ITK_ok);
//   if( ifail == ITK_ok )
//   {
//	    printf("\n Before register method for IMAN_save_msg for Set_OccUID \n");fflush(stdout);
//	    if (method4.id != NULLTAG)
//	    {
//			if( METHOD_add_action(method4, METHOD_post_action_type, (METHOD_function_t) Set_OccUID, NULL)!=ITK_ok)
//			printf("Registered as METHOD_post_action_type for Set_OccUID \n");fflush(stdout);
//	    }else
//		printf("Method not found!IMAN_save_msg111111111\n");fflush(stdout);
///	}
 
	if(METHOD_find_method("T5_ChangeTask", TC_save_msg, &method4)!=ITK_ok);
	if( ifail == ITK_ok )
	{
		printf("\n Before register method for TC_save_msg for Set_tskdesc \n");fflush(stdout);
		if (method4.id != NULLTAG)
		{
			if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) Set_tskdesc, NULL)!=ITK_ok)
			printf("Registered as METHOD_pre_action_type for Set_tskdesc \n");fflush(stdout);
		}
		else
		{
			printf("\n <<<<< Method not found TC_save_msg >>>>>\n");fflush(stdout);
		}
	}
	return ITK_ok;
}
