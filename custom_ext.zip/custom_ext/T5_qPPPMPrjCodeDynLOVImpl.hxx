//@<COPYRIGHT>@
//==================================================
//Copyright $2024.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object T5_qPPPMPrjCodeDynLOVImpl
//

#ifndef TRL001__T5_QPPPMPRJCODEDYNLOVIMPL_HXX
#define TRL001__T5_QPPPMPRJCODEDYNLOVIMPL_HXX

#include <T5_tm_qPPPMPrjCodelib/T5_qPPPMPrjCodeDynLOVGenImpl.hxx>

#include <T5_tm_qPPPMPrjCodelib/libt5_tm_qpppmprjcodelib_exports.h>


namespace TRL001
{
    class T5_qPPPMPrjCodeDynLOVImpl; 
    class T5_qPPPMPrjCodeDynLOVDelegate;
}

class  T5_TM_QPPPMPRJCODELIB_API TRL001::T5_qPPPMPrjCodeDynLOVImpl
    : public TRL001::T5_qPPPMPrjCodeDynLOVGenImpl
{
public:


    ///
    /// Returns List Of Values based on Dynamic LOV definition and user search criteria.
    /// @param operationInputTag - Operation Input containing the modified values.
    /// @param propertyName - Name of the selected property.
    /// @param searchString - User entered search string.
    /// @param sortByProp - Property to use for sorting.
    /// @param sortOrder - order for sorting (0=Ascending, 1=Descending).
    /// @param nResults - Number of returned results.
    /// @param results - Returned Values for LOV.
    /// @return - Zero (0) if everything is alright otherwise the error code.
    ///
    int  fnd0askLOVValuesBase( const tag_t operationInputTag, const std::string *propertyName, const std::string *searchString, const char *sortByProp, const int sortOrder, int *nResults, tag_t **results ) const;

protected:
    ///
    /// Constructor for a T5_qPPPMPrjCodeDynLOV
    explicit T5_qPPPMPrjCodeDynLOVImpl( T5_qPPPMPrjCodeDynLOV& busObj );

    ///
    /// Destructor
    virtual ~T5_qPPPMPrjCodeDynLOVImpl();

private:
    ///
    /// Default Constructor for the class
    T5_qPPPMPrjCodeDynLOVImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    T5_qPPPMPrjCodeDynLOVImpl( const T5_qPPPMPrjCodeDynLOVImpl& );

    ///
    /// Copy constructor
    T5_qPPPMPrjCodeDynLOVImpl& operator=( const T5_qPPPMPrjCodeDynLOVImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class TRL001::T5_qPPPMPrjCodeDynLOVDelegate;

};

#include <T5_tm_qPPPMPrjCodelib/libt5_tm_qpppmprjcodelib_undef.h>
#endif // TRL001__T5_QPPPMPRJCODEDYNLOVIMPL_HXX
