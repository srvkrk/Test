
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_Certification.c
*
* Description		: > This is related to STN Module in TCUA .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 10/12/2024   	Sanjoy Mondal			    change as per Teamcenter 14.3
* 21/05/2025	Sanjoy Mondal				bug fix in size of structure

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <property/idgeneration.h>
#include <Fnd0Participant/participant.h>
#include <tccore/item_msg.h>
#include<fclasses/tc_date.h>
#include<bom/bom_msg.h>

#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}	



#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 3)

 char* t5STN_SubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
//function added //


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}
int isLiveForBOMSave(logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  isLiveForBOMSave...\nCheck for control object CreOccEff....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "CreOccEff";
	qry_values[1] = "CreOccEff";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\n Control objects CreOccEff: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));

			
			//printf("\nName:%s\nDelete Indicator:%d\n",name,delInd);fflush(stdout);
			
			
			if(!delInd)
			{
				*result = TRUE;
			}
			
		}

	}

	return ifail;
}

int isCreOccNewFunction(logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  isCreOccNewFunction...\nCheck for control object OccEffNew....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "OccEffNew";
	qry_values[1] = "OccEffNew";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\n Control objects CreOccEff: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));

			
			//printf("\nName:%s\nDelete Indicator:%d\n",name,delInd);fflush(stdout);
			
			
			if(!delInd)
			{
				*result = TRUE;
			}
			
		}

	}

	return ifail;
}

int isUVFDMULive(logical *result)
{
	int ifail = ITK_ok;
	printf("\nIn function  isUVFDMULive...\nCheck for control object UVFDmuLive....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "UVFDmuLive";
	qry_values[1] = "UVFDmuLive";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\n Control objects CreOccEff: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		//char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));

			
			//printf("\nName:%s\nDelete Indicator:%d\n",name,delInd);fflush(stdout);
			
			
			if(!delInd)
			{
				*result = TRUE;
			}
			
		}

	}

	return ifail;
}

void  t5GetCurrentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


int tdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void t5NextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= tdays( month, year );//calling tdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void t5CurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	//printf("\n t5CurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	//printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	//printf("Date:%d\n",(timeptr->tm_mday));
	//printf("Month:%d\n",(timeptr->tm_mon)+1);
	//printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}


//declaration of date structure

struct date{
	int dd,mm,yy;
	};
//function to get yesterday's (previous) date
void getYesterdayDate(struct date *d){
	if(d->dd==1){
		if(d->mm==4||d->mm==6||d->mm==9||d->mm==11){
			d->dd=31;
			d->mm--;
		}
		else if(d->mm==3){
			if((d->yy%4)==0 && ((d->yy%100)!=0 || (d->yy%400)==0)) d->dd=29;
			else d->dd=28;
			d->mm--;
		}
		else if(d->mm==1){
			d->dd=31;
			d->yy--;
			d->mm=12;
		}
		else if(d->mm==2){
			d->dd=31;
			d->mm--;
		}
		else{
			d->dd=30;
			d->mm--;
		}
	}
	else{
		d->dd--;
	}
}


void t5GetPrevDate(char cprevAccessDate[30])
{
	int day, month, year, nd, nm, ny;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	
	struct date dt;

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	
	dt.dd = day;
	dt.mm = month;
	dt.yy = year;
	
	printf( "Given date is %d:%d:%d\n", day, month, year );
   
	getYesterdayDate(&dt);
	nd = dt.dd;
	nm = dt.mm;
	ny = dt.yy;
	
    printf( "Prev  days date is %d:%d:%d\n", nd, nm, ny );
	t5GetCurrentMonth(nm,cMonth);
	//printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cprevAccessDate,strDay);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,cMonth);
	tc_strcat(cprevAccessDate,"-");
	tc_strcat(cprevAccessDate,strYear);
	tc_strcat(cprevAccessDate," ");
	tc_strcat(cprevAccessDate,"00:00");
	//printf("\n cprevAccessDate:%s\n",cprevAccessDate);
}

void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	//printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	//printf("Date:%d\n",(timeptr->tm_mday));
	//printf("Month:%d\n",(timeptr->tm_mon)+1);
	//printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int Create_occurance_effectivity_OnBOMSave(tag_t primaryObj, char* objectId, char* objectrevId, char* arcPlatform)
{
	int		ifail			= ITK_ok;
	int		iy				= 0;
	int		iz				= 0;
	int		bvr_count		= 0;
	int		n_occs			= 0;
	int		Item_count		= 0;
	int		effcnt			= 0;	

	tag_t	*bvrs;
	tag_t   *occsal;
	tag_t	ChildItem		= NULLTAG;
	tag_t	*rev_list		= NULLTAG;
	tag_t	bvr				= NULLTAG;
	tag_t	bvrchild		= NULLTAG;
	tag_t	*Effobbj		= NULLTAG;
	tag_t	EffecTag		= NULLTAG;

	char	*dataset_name1	= NULL;
	char	*t5Des_Rev		= NULL;

	date_t	date_end		= NULLDATE;
	
	date_t dcreation_date;
	char* ccreation_date	= NULL;
	char* end_date			= NULL;
	ccreation_date = malloc(30 * sizeof (char *) );
	end_date = malloc(30 * sizeof (char *) );

	char* Effecsta			 = NULL;
	char* EffecEnd			 = NULL;

	char EffecRange[200];
	char EffecName[200];
	
	int i_ChildCount		 = 0;
	int iChldPrts			 = 0;
	int uidType				 = 0;
	int Uidlatest            = 0;
	tag_t  t_BomLineWindow	 = NULLTAG;
	tag_t  t_Rule			 = NULLTAG;
	tag_t  t_TopLine		 = NULLTAG;
	tag_t  *t_PartChildren	 = NULLTAG;
	tag_t  t_Childobject	 = NULLTAG;
	char   *Child_SeqId		 = NULL;
	char   *ChildUID		 = NULL;
	char   *child_Uid   	 = NULL;
	
	date_t start_date;
	char * startDate;
	startDate = malloc(30 * sizeof (char *) );

	ifail = ITK_string_to_date("31-Dec-2099 00:00", &date_end);
	
	//Get current date
	char cCurrentAccessDate[20]={0};
	char cPrevAccessDate[20]={0};
	
	t5GetCurrentDateTime(cCurrentAccessDate);
	

	printf("\n Eff:Current date  is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
	
	t5GetPrevDate(cPrevAccessDate);
	
	printf("\n Eff:Yesterday date  is..:[%s]\n",cPrevAccessDate);fflush(stdout);
	
	//if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &start_date )))
	if(ITK_ok != (ifail = ITK_string_to_date(cPrevAccessDate, &start_date )))
	{
		return ifail;
	}	

	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);
	printf("\nXXX: CM_MR_SetOccEff bvr count is...%d",bvr_count);fflush(stdout);
	if (bvr_count)
	{

		int occCnt = 0;
		tag_t* occList = NULL;
		int occNtFndCnt = 0;
		tag_t* occNtFndList = NULL;		
		int effIdCnt = 0;
		char** effIdLst = NULL;
		int effIdCnt1 = 0;
		char** effIdLst1 = NULL;
		int effIdCnt2 = 0;
		char** effIdLst2 = NULL;
		bvr = bvrs[0];
		ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
		printf("\n CM_MR_SetOccEff n_occs count is...%d",n_occs);fflush(stdout);
		for (iy = 0; iy<n_occs; iy++)
		{
			ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

			if (ChildItem)
			{
				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

				
				ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);

				if(Item_count > 0)
				{
					for (iz = 0; iz<Item_count; iz++)
					{
						ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
						//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
						
						if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
						{
							t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
						}
						

					}
				}
			}
		}
		
		printf("\nOccurance Count==============>%d\n",occCnt);fflush(stdout);
		
		if(occCnt==1)
		{
			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);

					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							

							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
							  tc_strcpy(EffecName,"");
							  tc_strcat(EffecName,dataset_name1);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,t5Des_Rev);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,arcPlatform);
							  tc_strcat(EffecName,"_");
							  tc_strcat(EffecName,"1");

							 // printf("\n CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);

							  ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
							  ITK_date_to_string(dcreation_date, &ccreation_date);
							  ITK_date_to_string(date_end, &end_date);
							  //printf("\n\t CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
							  //printf("\n\t CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
							  
								ITK_date_to_string(start_date, &startDate);

								//Effecsta=subString(ccreation_date,0,11);
								//Effecsta=subString(startDate,0,11);
								Effecsta = startDate;
								EffecEnd=subString(end_date,0,11);

								tc_strcpy(EffecRange,"");

								tc_strcat(EffecRange,Effecsta);
								tc_strcat(EffecRange," to ");
								tc_strcat(EffecRange,EffecEnd);

								//printf("\n CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

								ifail =  AOM_lock( bvr );

								ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

								//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
								
								
								
								if (effcnt == 0)
								{
									ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

									if (EffecTag)
									{
										//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

										ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

										ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,EffecRange,FALSE);

										ifail = AOM_save_without_extensions(EffecTag);
										ifail = AOM_refresh(EffecTag, 0);

										//ifail = AOM_refresh(bvr, 1);
										ifail = AOM_save_without_extensions(bvr);
										ifail = AOM_unlock( bvr );

									}
								}
							}
						}
					}
				}
			}
						
		}
		
		
		
		//for multi occurance case
		if(occCnt>1)
		{
			
			int k=0;
			for(k=0;k<occCnt;k++)
			{
				tag_t occTag = NULLTAG;
				occTag = occList[k];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\t CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								// int effcnt = 0;
								// tag_t Effobbj = NULLTAG;
					
								char str1[20];
								sprintf(str1, "%d", k+1);
								tc_strcpy(EffecName,"");
								tc_strcat(EffecName,dataset_name1);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,t5Des_Rev);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,arcPlatform);
								tc_strcat(EffecName,"_");
								tc_strcat(EffecName,str1);								  

								//printf("\nSAN: adding to the set..EffecName... [ %s ]\n",EffecName);fflush(stdout);
								t5AddStrToSet(&effIdCnt, &effIdLst,EffecName);
								

								
								ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);
								
								if(effcnt ==0)
								{
									//printf("\nSAN: adding to the set. not found .EffecName... [ %s ]\n",EffecName);fflush(stdout);
									t5AddStrToSet(&effIdCnt1, &effIdLst1,EffecName);
									t5AddTagObjToSet(&occNtFndCnt,&occNtFndList,occTag);
								}
								
								if(effcnt>0)
								{
									char* effId = NULL;
									tag_t effObj = NULLTAG;
									int flag =0;
									effObj= Effobbj[0];
									ifail = PS_occ_eff_ask_id(bvr,occTag,effObj, &effId);
									//printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
									
									if(effId==NULL )
									{
										flag++;
									}
									else if(tc_strcmp(effId,"")==0)
									{
										flag++;
									}
									//printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
									
									if(flag==0)									
									{
										//printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
										t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
									}
									if(flag>=1)
									{
										//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
										ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
									}
								}

								
								
							}
						}
					}
							
				}
				
								
				
			}

		}
		
		//printf("\nSAN: ====> effIdCnt==> %d\n",effIdCnt);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt1==> %d\n",effIdCnt1);fflush(stdout);
		//printf("\nSAN: ====> effIdCnt2==> %d\n",effIdCnt2);fflush(stdout);
		//printf("\nSAN: ====> occNtFndCnt==> %d\n",occNtFndCnt);fflush(stdout);
		//for multi occurance case
		
		if(occNtFndCnt>0)
		{
			int jk=0;
			for(jk=0;jk<occNtFndCnt;jk++)
			{
				tag_t occTag = NULLTAG;
				occTag = occNtFndList[jk];
				ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
				if (ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					//printf("\n XXX: CM_MR_SetOccEff Master name is  :%s ",dataset_name1);fflush(stdout);	

					
					ifail = ITEM_list_all_revs(ChildItem, &Item_count, &rev_list);
					if(Item_count > 0)
					{
						for (iz = 0; iz<Item_count; iz++)
						{
							ifail = AOM_ask_value_string(rev_list[iz],"item_revision_id",&t5Des_Rev);
							//printf("\n\tXXXX: CM_MR_SetOccEff released rev id is  >>>>>>>>>> [ %s ]",t5Des_Rev); fflush(stdout);
							
							if ((tc_strcmp(dataset_name1,objectId)==0) && (tc_strcmp(t5Des_Rev,objectrevId)==0))
							{
								
								int ij=0;
								for(ij=0;ij<occCnt;ij++)
								{
									int found =0;
									char str1[20];
									sprintf(str1, "%d", ij+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,dataset_name1);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,t5Des_Rev);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);								
								  

									//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									//printf("\nFound==>%d\n",found);fflush(stdout);
									
									if(found==0)
									{
										ifail = AOM_ask_value_date(rev_list[iz],"creation_date",&dcreation_date);
										ITK_date_to_string(dcreation_date, &ccreation_date);
										ITK_date_to_string(date_end, &end_date);
										//printf("\n\t XXX:CM_MR_SetOccEff creation_date is  >>>>>>>>>> [ %s ]",ccreation_date); fflush(stdout);
										//printf("\n\t XXX: CM_MR_SetOccEff end_date is  >>>>>>>>>> [ %s ]",end_date); fflush(stdout);
										
										ITK_date_to_string(start_date, &startDate);

										//Effecsta=subString(ccreation_date,0,11);
										//Effecsta=subString(startDate,0,11);
										Effecsta = startDate;
										EffecEnd=subString(end_date,0,11);

										tc_strcpy(EffecRange,"");

										tc_strcat(EffecRange,Effecsta);
										tc_strcat(EffecRange," to ");
										tc_strcat(EffecRange,EffecEnd);

										//printf("\n XXX:CM_MR_SetOccEff Date range is = [ %s ]",EffecRange);fflush(stdout);

										ifail =  AOM_lock( bvr );

										ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);

										//printf("\n CM_MR_SetOccEff effcnt count is...%d",effcnt);fflush(stdout);
										

										
										if (effcnt == 0)
										{
										
											ifail = PS_occ_eff_create(bvr,occTag,&EffecTag);

											if (EffecTag)
											{
												//printf("\n CM_MR_SetOccEff setting effe 2...%d",effcnt);fflush(stdout);

												ifail = PS_occ_eff_set_id(bvr,occTag,EffecTag,EffecName);

												ifail = PS_occ_eff_set_date_range(bvr,occTag,EffecTag,EffecRange,FALSE);

												ifail = AOM_save_without_extensions(EffecTag);
												ifail = AOM_refresh(EffecTag, 0);
												ifail = AOM_save_without_extensions(bvr);
												ifail = AOM_unlock( bvr );

											}
											t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);
										}
										
										break;
										
									}
									
								}
							}
						}
					}						
				}					
			}
		}
				
	}

	return ifail;
}



struct modstruct
 {  
	   //part details

		char SapUID[100];
		char transmat[1000];

 } childstr[10000];
 

int Create_occurance_effectivity_new(tag_t primaryObj,tag_t childObjTag, date_t date_start, date_t date_end, char* OccUIDattr,char* arcPlatform)
{
	int		ifail		= ITK_ok;
	int		bvr_count = 0;	
	int		g = 0;	
	int		effcnt = 0;	
	int		effcnt1 = 0;	
	int	in = 0;	
	tag_t   bom_window=NULLTAG;
	tag_t  *bomchild=NULLTAG;
	
	tag_t  *Effobbj=NULLTAG;
	tag_t  *Effobbj1=NULLTAG;
	int		iy = 0;	
	int	cnt = 0;	
	int	cnt1 = 0;	
	int PrtRelStus_cnt;
	int ii,n;
	int n_occs=0;
	int n_occs1=0;
	int gy=0;
	int z=0;
	int noocc=0;
	int Occuidfl=0;
	int Effocc=0;
	char cNextDate[20]={0};
	char EffecName[200];
	char EffecName1[200];
	char EffecRange[200];
	char EffecRange1[200];
	date_t *Rel_start_end_values	= NULL;
	tag_t			EffecTag						= NULLTAG;
	tag_t			EffecTag1						= NULLTAG;
	tag_t *Crevsn_list		= NULL;
	tag_t			revTag1						= NULLTAG;
	tag_t			revTag12						= NULLTAG;
	tag_t			EffecTagrr						= NULLTAG;
	tag_t			*EffecTagrrww						= NULLTAG;
	tag_t			bvr						= NULLTAG;
	tag_t			ChildItem						= NULLTAG;
	tag_t			bom_rule,bomtop_line;
	char			*mycusdate1				= NULL;
	char			*dataset_name1				= NULL;
	char			*child_item_id				= NULL;
	char			*dataset_name12				= NULL;
	char			*dataset_name123				= NULL;
	char			*t5Des_Rev				= NULL;
	char			*t5Des_Rev1				= NULL;
	char			*Effeids				= NULL;
	char			*Effeid				= NULL;
	int rev_count;
	char *tempmat=NULL;
	tag_t *PrtRelStusTg     = NULL;
	tag_t			bvrchild						= NULLTAG;
	tag_t			note_type						= NULLTAG;
	tag_t			clientdata						= NULLTAG;
	tag_t			*bvrs ;	
	char*	 PrtRelStus		= NULL;
	char	*note_name			= NULL;
	int NRFlag =0;
	int mulocc =0;
	int incmul =0;

	date_t			test_date_1				= NULLDATE;
	date_t			test_date_2				= NULLDATE;
	date_t			test_date_3				= NULLDATE;
	date_t			Ltest_date_2				= NULLDATE;
	date_t			Ltest_date_1				= NULLDATE;
	//WSOM_open_ended_status_t  	EFFECTIVITY_closed  ; san
	
	int EFFECTIVITY_closed =0;
	char cCurrentAccessDate[20]={0};
	char	*old_to_date			= NULL;
	char	*current_to_date			= NULL;
	char	*NextDateS			= NULL;
	char	*UPdateS			= NULL;
	char	*UPdateSe			= NULL;
	char	*note_text			= NULL;

	char* EffecEnd = NULL;
	char* Effecsta = NULL;
	char* Effecsta1 = NULL;
	char* EffecEnd1 = NULL;

	char* Effecoccname = NULL;
	char* Effecid = NULL;
	char *tempmat1=NULL;
	char *Rev=NULL;
	char *itemid=NULL;
	char *subseq=NULL;

	char* EFF_OLD = NULL;
	char* EFF_CURRENT = NULL;
	char * 	id ;
	char * 	olduid =NULL;
	logical date_is_valid  ;
	logical effext  ;
	logical isalleff  ;
	tag_t  *occs=NULL;
	WSOM_effectivity_info_t** effeinf;

	date_t  *eff_dates_arr;
	date_t  *eff_dates_arr1;
	date_t  *eff_dates_arr2;
	date_t  *Lstart_end_date;


	tag_t *occsal;
	tag_t *occsal1;
	
	//for updation 
	int	   j = 0;
	int	   Updflg = 0;
	int	   nooccret = 0;
	int	   Updcnt = 0;
	int    bl_config=0;
	//int    fndid=0;
	//int    uidType=0;
	//int    uidTypenew=0;
	//int    fndidlatest=0;
	//int    Uidlatest=0;
	int	   Updchldcnt=0;
	int	   count=0;
	//int    Uidkey=0;
	//int xform_matrix1 = 0;
	char PartNum[300];
	char transcpy[1000];

	tag_t   window=NULLTAG;
	tag_t	rule;
	tag_t	line;

	tag_t   Updbom_window=NULLTAG;
	tag_t	Updbom_rule;
	tag_t	Updbom_line;
	tag_t  *Updbomchild=NULLTAG;
	tag_t  *child=NULLTAG;
	tag_t  uidTag=NULLTAG;
	double mat[4][4];
	//double * mat1;
	double divInt=1000;
	int imat=0;
	int jmat=0;

	char			*child_fndid				= NULL;
	char			*child_fndid_latest				= NULL;
	char			*child_Uidlatest				= NULL;
	char			*Updchld				= NULL;
	char			*chldid				= NULL;
	char *			newuid =NULL;
	char * 			uidltswrk =NULL;
	char * 			uidocc =NULL;
	char			*child_Uidkey				= NULL;
	char *xform_matrix_str = NULL;

	char* ChildUID=NULL;
	char* EffecIdsub=NULL;
	char* ChildUIDNEW=NULL;
	char str[20];    //create an empty string to store number
   //float number;
	
	char		*sep				= "_";
	char 		*test 				= (char*)MEM_alloc(sizeof(char) * 3000);
	//char		*final				= (char*)MEM_alloc(sizeof(char) * 3000);
	//const char *uid[1];

	logical bl_config_log;
	
	tag_t* occList = NULL;
	int occCnt = 0;
	
	char** effIdLst2 = NULL;
	int effIdCnt2 = NULLTAG;
	tag_t* occNtFndList = NULL;
	int occNtFndCnt = 0;
	int found =0;
	int seq = 0;

	int flagBL = 100;
	//int blFormula = 0;
	char* child_blFormula = NULL;


	ifail = ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs);

	printf("\n Create_occurance_effectivity_new...bvr count is...%d",bvr_count);fflush(stdout);

	printf("\nRevision not found1144...!!\n");fflush(stdout);

	t5GetCurrentDateTime(cCurrentAccessDate);
	printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
	t5NextDate(cNextDate);
	printf("\n cNextDate:%s",cNextDate);
	//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

	if(ITK_ok != (ifail = ITK_string_to_date("01-Jan-2017 00:00", &test_date_1 )))
	{
		return ifail;
	}
	if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-2099 00:00", &test_date_3 )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &test_date_2 )))
	{
		return ifail;
	}


	eff_dates_arr = (date_t*)malloc(sizeof(date_start) * 2);

	eff_dates_arr[0] = test_date_1;
	eff_dates_arr[1] = test_date_2;



	eff_dates_arr2 = (date_t*)malloc(sizeof(date_start) * 2);



	eff_dates_arr2[0] = test_date_2;
	eff_dates_arr2[1] = test_date_3;


	if(ITK_ok != (ifail = DATE_date_to_string(test_date_1,"%d-%b-%Y %H:%M", &NextDateS )))
	{
		return ifail;
	}

	if(ITK_ok != (ifail = DATE_date_to_string(test_date_2,"%d-%b-%Y %H:%M", &UPdateS )))
	{
		return ifail;
	}

		if(ITK_ok != (ifail = DATE_date_to_string(test_date_3,"%d-%b-%Y %H:%M", &UPdateSe )))
	{
		return ifail;
	}

	ifail = ITEM_ask_latest_rev(childObjTag, &revTag1);
    if (revTag1)
	{
		//NRFlag=NRFlag+1;
		ifail = AOM_ask_value_string(revTag1, "item_id", &dataset_name12);
		printf("\n Revi master name is first :>>>>>%s ",dataset_name12);fflush(stdout);


		ifail = AOM_ask_value_string(revTag1,"item_revision_id",&t5Des_Rev);
		printf("\n\n\t\t t5Des_Rev is first :>>>>>%s",t5Des_Rev); fflush(stdout);



		tc_strcpy(EffecName,"");
		tc_strcat(EffecName,dataset_name12);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,t5Des_Rev);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,arcPlatform);			
	}
	else
	{

		ifail = ITEM_ask_latest_rev(childObjTag, &revTag1);
		ifail = AOM_ask_value_string(revTag1, "item_id", &dataset_name12);
		printf("\n Revi master name is  :%s ",dataset_name12);fflush(stdout);


		ifail = AOM_ask_value_string(revTag1,"item_revision_id",&t5Des_Rev);
		printf("\n\n\t\t t5Des_Rev is :%s",t5Des_Rev); fflush(stdout);



		tc_strcpy(EffecName,"");
		tc_strcat(EffecName,dataset_name12);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,t5Des_Rev);
		tc_strcat(EffecName,"_");
		tc_strcat(EffecName,arcPlatform);		

	}
		
	printf("\n EFFECTIVITY NAME IS BEFORE EXPANSION :::>>>>>>> [%s]\n",EffecName);fflush(stdout);


	if (EffecTag)
	{
		printf("\nRevision not found11444...!!\n");fflush(stdout);

	}


	if (bvr_count)

	{
		bvr = bvrs[0];


		if(BOM_create_window(&window)!=ITK_ok);
		if(CFM_find( "Latest Working", &rule )!=ITK_ok);
		if(BOM_set_window_config_rule(window,rule )!=ITK_ok);
		if(BOM_set_window_pack_all(window, false)!=ITK_ok);
		if(BOM_set_window_top_line(window, null_tag,primaryObj , null_tag, &line)!=ITK_ok);

		if(BOM_set_window_top_line_bvr(window,bvr,&line));

		if(BOM_line_ask_all_child_lines(line,&count,&child));
		printf("\n count::::::::>>>>>>>> %d\n",count);

		for (j = 0; j<count; j++)
		{
			if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
			
			printf("\n\t t5childitems_id in Update loop ===> :: %s <<>> %s \n",chldid,dataset_name12); fflush(stdout);

			if	(tc_strcmp(chldid,dataset_name12)==0)
			{
				ITK__convert_tag_to_uid(child[j],&uidltswrk);
				printf("\n uidltswrk... [%s]\n",uidltswrk);fflush(stdout);

				//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&fndid));
				if(AOM_ask_value_string(child[j],"bl_occ_t5_uidsap",&child_fndid));
				printf("\n child_fndid===============>>>>>>1111 %s\n",child_fndid);

				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child[j], "bl_occurrence_uid", &ChildUID));
				printf("\n ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);

				//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
				if(AOM_ask_value_string(child[j],"bl_formula",&child_blFormula));	
				printf("\n child_blFormula1 all===============>>>>>> %s\n",child_blFormula);
				
				if (strlen(child_fndid)==0)
				{
					if(AOM_set_value_string(child[j], "bl_occ_t5_uidsap",ChildUID));
				}
				else
				{
					if ((tc_strstr(OccUIDattr,ChildUID)!= NULL))
					{
						printf("\n Inside comparing uid 1 ChildUID & OccUIDattr \n");fflush(stdout);

						// xform_matrix1=0;
		
						// if ( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
						 //printf("\n***********xform_matrix1:%d\n",xform_matrix1);
						 if(AOM_ask_value_string(child[j], "bl_plmxml_abs_xform", &xform_matrix_str));
						 printf( " child xform matrix 11--------------> %s\n",xform_matrix_str);fflush(stdout);


						tc_strcpy(childstr[Occuidfl].SapUID,ChildUID); 
						tc_strcpy(childstr[Occuidfl].transmat,xform_matrix_str); 
						//childstr[p1].child=n_lines2; 
						printf("\ngggg  j====>%d\n",j);fflush(stdout);
						printf("\n structure IS: %s %s \n",childstr[j].SapUID,childstr[j].transmat);fflush(stdout);
						Occuidfl++;
						
						//check the bomline have Variant formula

						printf("\n child_blFormula11===============>>>>>> %s\n",child_blFormula);
						if(child_blFormula==NULL)
						{
							flagBL = 0;
						}
						else 
						{
							if(strlen(child_blFormula)==0)
							{
								printf("\n No variant formula...\n");fflush(stdout);
								flagBL = 0;
							}
						}
							

					}
				}
			}
				
		}
		printf("\n Occuidfl===============>>>>>> %d\n",Occuidfl);
	
		
/* 		Occuidfl = 0;
		printf("\nEND*****************************\n");fflush(stdout);
		return ifail; */

		if (Occuidfl > 0)
		{
			ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );

			//Sanjoy

			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );
				
				if(ChildItem)
				{
					ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
					printf("\nSAN:CM_SetOccEff Master name is  :%s==========>%s ",dataset_name1,dataset_name12);fflush(stdout);	
					
					if ((tc_strcmp(dataset_name1,dataset_name12)==0))
					{
						printf("\nAdd to the set occList..........%s \n",dataset_name12);fflush(stdout);
						t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
											
					}				

				}
				
			}
			printf("\nSAN:Occurance Count occCnt==============>%d\n",occCnt);fflush(stdout);
			if(occCnt>0)
			{
				
				int k=0;
				for(k=0;k<occCnt;k++)
				{
					tag_t occTag = NULLTAG;
					occTag = occList[k];
					ifail = PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild );
					if(ChildItem)
					{
						
						
						ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
	
	

						
						ifail = PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj);
						
						if(effcnt==0)
						{
							printf("\nSAN: effectivity  not found ... [ %s ]\n");fflush(stdout);
							
							t5AddTagObjToSet(&occNtFndCnt,&occNtFndList,occTag);
						}
						if(effcnt>0)
						{
							char* effId = NULL;
							tag_t effObj = NULLTAG;
							int flag =0;
							effObj= Effobbj[0];
							ifail = PS_occ_eff_ask_id(bvr,occTag,effObj, &effId);
							printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
							
							if(effId==NULL )
							{
								flag++;
							}
							else if(tc_strcmp(effId,"")==0)
							{
								flag++;
							}
							printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
							
							if(flag==0)									
							{
								printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
								t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
							}
							if(flag>=1)
							{
								//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
								//ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
							}
						}
						
					}
					else
					{
						printf("\nChildItem is NULLTAG\n");fflush(stdout);
					}
								
					
				}

			}

			printf("\nSAN: ====> effIdCnt2==> %d\n",effIdCnt2);fflush(stdout);
			printf("\nSAN: ====> occNtFndCnt==> %d\n",occNtFndCnt);fflush(stdout);				

			//End Sanjoy				
			
			for (iy = 0; iy<n_occs; iy++)
			{
				ifail = PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild );

				ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				printf("\n Master name is  :%s ",dataset_name1);fflush(stdout);

				ITK__convert_tag_to_uid(occsal[iy],&uidocc);
				printf("\n uidocc... [%s]\n",uidocc);fflush(stdout);

				if (tc_strstr(OccUIDattr,uidocc)!= NULL)
				{


					if	(tc_strcmp(dataset_name1,dataset_name12)==0)
					{

						ifail =  AOM_lock( bvr );
						//	ifail = CFM_occ_set_effectivity(bvr,occsal[iy],EffecTag);
						printf("\nRevision not found33...!!\n");fflush(stdout);

						ifail = PS_occ_eff_ask_effs(bvr,occsal[iy],&effcnt,&Effobbj);

						printf("\n count is...%d",effcnt);fflush(stdout);

						if (effcnt == 0)
						{
							int ij=0;
							if(occCnt>0)
							{
								found =0;
								seq =0;
								for(;;)
								{
									char str1[20];
									sprintf(str1, "%d", seq+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,dataset_name1);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,t5Des_Rev);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);


									printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									printf("\nXXXXX....Found==>%d\n",found);fflush(stdout);
									if(found==0)
									{
										
										break;
									}
									else
									{
										seq++;
									}
									
								}
							}
							
							if(found ==0)
							{
								ifail = PS_occ_eff_create(bvr,occsal[iy],&EffecTag);

								ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

								ifail = AOM_save_without_extensions(EffecTag);
								ifail = AOM_refresh(EffecTag, 0);
								t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);
							}




							if (EffecTag)
							{



								ifail = PS_occ_eff_set_id(bvr,occsal[iy],EffecTag,EffecName);

								ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);

								printf("\n setting effe 2...%d",effcnt);fflush(stdout);

								//ifail = PS_occ_eff_set_dates(bvr,occsal[iy],EffecTag,2,eff_dates_arr,EFFECTIVITY_closed,false);

								printf("\n setting effe 3...%d",effcnt);fflush(stdout);

								//ifail = AOM_refresh(bvr, 1);
								ifail = AOM_save_without_extensions(bvr);
								ifail = AOM_unlock( bvr );
								//ifail = AOM_refresh(bvr, 0);

								ifail = AOM_refresh(childObjTag, 1);
								ifail = AOM_save_without_extensions(childObjTag);
								ifail = AOM_unlock( childObjTag );
								ifail = AOM_refresh(childObjTag, 0);

								ifail = AOM_refresh(primaryObj, 1);
								ifail = AOM_save_without_extensions(primaryObj);
								ifail = AOM_unlock( primaryObj );
								ifail = AOM_refresh(primaryObj, 0);

								

							}

							

						}
						else 
						{

							ifail = PS_occ_eff_ask_dates(bvr,occsal[iy],Effobbj[0],&g,&Rel_start_end_values,&EFFECTIVITY_closed);

							ifail = PS_occ_eff_ask_id(bvr,occsal[iy],Effobbj[0],&Effecid);
							printf("\n Effecid >>>>>>>>>>>>>> %s",Effecid);fflush(stdout);

							ifail = PS_ask_occurrence_name(bvr,Effobbj[0],&Effecoccname);

							printf("\n Effecoccname >>>>>>>>>>>>>> %s",Effecoccname);fflush(stdout);



							if(g > 0)
							{
								if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
								{
									return ifail;
								}
								printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
								if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
								{
									return ifail;
								}
								printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
								if(date_is_valid != true)
								{
									printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
								}
								else
								{
									printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
									printf("\n Eff:cCurrentAccessDate:[%s] ",cCurrentAccessDate);fflush(stdout);

									EFF_OLD=subString(old_to_date,0,11);
									EFF_CURRENT=subString(cCurrentAccessDate,0,11);

									printf("\n new old andcurrent dates are:[%s %s] ",EFF_OLD,EFF_CURRENT);fflush(stdout);

										if ((tc_strcmp(EFF_OLD,EFF_CURRENT)==0))
									{
										printf("\n CC available Variant formula not available \n"); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err, "Cannot Create Multiple Occurance on same day",dataset_name12);
										return ITK_err;
									}
								}
							}


								
							printf("\n EffecName is: >>>>>>>>>>>>>>>>>> [%s] ",EffecName);fflush(stdout);

							EffecIdsub=subString(Effecid,0,18);
							printf("\n Eff:EffecIdsub Value is:>>>>>>>>>>>>>>> [%s] ",EffecIdsub);fflush(stdout);
							if ((tc_strcmp(EffecName,EffecIdsub)==0) || (tc_strcmp(EffecName,Effecoccname)==0))
							{
								Effocc++;
							}



							Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
							Lstart_end_date[0] = Ltest_date_1;
							Lstart_end_date[1] = Ltest_date_2;

							Effecsta=subString(old_to_date,0,11);
							//EffecEnd=subString(cCurrentAccessDate,0,11);
							
							//Check if already bl_formula is not present 
						
							
							//EffecEnd = "31-Dec-2099"; //todo
							printf("\n flagBL==>%d\n",flagBL);fflush(stdout);
							if(flagBL==0)
							{
								EffecEnd = "31-Dec-2099";
							}
							else
							{
								EffecEnd=subString(cCurrentAccessDate,0,11);
							}

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,Effecsta);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EffecEnd);

							printf("\n Eff:ctest is..:[%s]",EffecRange);fflush(stdout);

							ifail = AOM_lock( bvr );
							ifail = AOM_lock( Effobbj[0] );



							ifail = PS_occ_eff_set_date_range(bvr,occsal[iy],Effobbj[0],EffecRange,false);

							ifail = AOM_save_without_extensions(Effobbj[0]);
							ifail = AOM_refresh(Effobbj[0], 0);

							ifail = AOM_save_without_extensions(bvr);
							ifail = AOM_unlock( bvr );
							//ifail = AOM_refresh(bvr, 0);

							ifail = AOM_refresh(childObjTag, 1);
							ifail = AOM_save_without_extensions(childObjTag);
							ifail = AOM_unlock( childObjTag );
							ifail = AOM_refresh(childObjTag, 0);

							ifail = AOM_refresh(primaryObj, 1);
							ifail = AOM_save_without_extensions(primaryObj);
							ifail = AOM_unlock( primaryObj );
							ifail = AOM_refresh(primaryObj, 0);



						}

							// to handle multiple occurrence
							mulocc++;

					}
				}
		
			}
			printf("\n mulocc count is :%d ",mulocc);fflush(stdout);
			nooccret=0;

			// for adding new occurrence
			for (incmul = 0; incmul<mulocc; incmul++)
			{
				ifail = PS_list_occurrences_of_bvr( bvr,&n_occs1, &occsal1 );
				printf("\n\t n_occs1=======> :: %d",n_occs1); fflush(stdout);
				if(BOM_create_window(&bom_window)!=ITK_ok);
				if(CFM_find( "Latest Working", &bom_rule )!=ITK_ok);
				if(BOM_set_window_config_rule(bom_window, bom_rule )!=ITK_ok);
				if(BOM_set_window_pack_all(bom_window, false)!=ITK_ok);
				if(BOM_set_window_top_line(bom_window, null_tag,primaryObj , null_tag, &bomtop_line)!=ITK_ok);

				if(BOM_set_window_top_line_bvr(bom_window,bvr,&bomtop_line));

				ifail = ITEM_ask_latest_rev(childObjTag, &revTag12);

				if (revTag12)
				{
					
					ifail = AOM_ask_value_string(revTag12, "item_id", &dataset_name123);
					printf("\n Revi master name is  second :%s ",dataset_name123);fflush(stdout);

					ifail = AOM_ask_value_string(revTag12,"item_revision_id",&t5Des_Rev1);
					printf("\n\n\t\t t5Des_Rev is second :%s",t5Des_Rev1); fflush(stdout);

					found =0;
					seq =0;
					for(;;)
					{
						char str1[20];
						sprintf(str1, "%d", seq+1);
						tc_strcpy(EffecName1,"");
						tc_strcat(EffecName1,dataset_name123);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,t5Des_Rev1);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,arcPlatform);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,str1);


						printf("\n XXXX oooooooo CM_MR_SetOccEff EffecName1... [ %s ]\n",EffecName1);fflush(stdout);

						t5FindStrInSet(effIdLst2,effIdCnt2,EffecName1,&found);
						printf("\nXXXXX. ttttt...Found==>%d\n",found);fflush(stdout);
						if(found==0)
						{

							break;
						}
						else
						{
							seq++;
						}

					}


				}
				printf("\n XXXX final CM_MR_SetOccEff EffecName1... [ %s ]\n",EffecName1);fflush(stdout);
				if(BOM_line_ask_all_child_lines(bomtop_line,&gy,&bomchild));
				printf("\n BOM_line_ask_all_child_lines %d\n",gy);
				printf("\n EffecName1===============>>>>>> %s\n",EffecName1);

				noocc=0;
				for (cnt = 0; cnt<gy; cnt++)
				{
									


					if(AOM_ask_value_string(bomchild[cnt], "bl_item_item_id", &dataset_name1));
					//printf("\n\t t5childitems_id ===> :: %s",dataset_name1); fflush(stdout);

					printf("\n\t t5childitems_id in 0th loop ===> :: %s,%s \n",dataset_name1,dataset_name12); fflush(stdout);

					if	(tc_strcmp(dataset_name1,dataset_name12)==0)
					{
						printf("\n\t t5childitems_id in 1st loop ===> :: %s,%s \n",dataset_name1,dataset_name12); fflush(stdout);
						noocc++;

						ifail = BOM_line_ask_unit_occurrence_effectivity(bomchild[cnt],false,&effext,&isalleff,&effcnt1,&effeinf);
						printf("\n\t effcnt1=======> :: %d",effcnt1); fflush(stdout);


					}

				}
				printf("\n\t noocc=======> :: %d",noocc); fflush(stdout);
				printf("\n\t nooccret=======> :: %d",nooccret); fflush(stdout);
				if ((noocc == 0) || (nooccret > 0))
				{
					char* seq_no = NULL;
					double qty = 0.00;
					
					// for getting trans matrix

					tc_strcpy(transcpy,childstr[nooccret].transmat);

					printf("\n\t trans before stamp=======> :: %s",transcpy); fflush(stdout);

					tempmat1=tc_strtok(transcpy," ");

					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							if(imat==0 && jmat==0)
							{
								printf("\n inside if"); fflush(stdout);
								mat[imat][jmat]=strtod(tempmat1,NULL);
							}else
							{
								printf("\n inside else"); fflush(stdout);
								tempmat=tc_strtok(NULL," ");
								mat[imat][jmat]=strtod(tempmat,NULL);
							}
						}
					}


					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							printf("%10lf,",mat[imat][jmat]);
						}
						printf("\n");
					}

					// end trans matrix


					ifail = AOM_lock( bvr );

					if  (PS_create_occurrences( bvr, revTag12, NULLTAG,1, &occs ));
					if(PS_set_plmxml_transform(bvr, occs[0], *mat));

					ifail = PS_occ_eff_create(bvr,occs[0],&EffecTag1);
					ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,EffecName1);
					//Set sequence no.													

					printf("\nset find nos...\n");fflush(stdout);
					if(USER_ask_new_default_sequence_number(bvr, revTag12,&seq_no));	
					if(PS_set_seq_no(bvr,occs[0],seq_no));
					
					
					//End Setting Seq no.
					
					//Get quantity
					ifail = PS_ask_occurrence_qty(bvr, occs[0],&qty);
					printf("\nThe quantity for the newly created occurence===> %lf\n",qty);fflush(stdout);
					if(qty > 0)
					{
						printf("\nAlready there is quantity. No need to set the quantity for the newly created occurence...\n");fflush(stdout);
					}
					else
					{
						ifail = PS_set_occurrence_qty(bvr, occs[0],1);
						printf("\nSetting the quantity for the newly created occurence...\n");fflush(stdout);
					}
					

					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);

					Effecsta1=subString(cCurrentAccessDate,0,11);
					EffecEnd1=subString(UPdateSe,0,11);

					tc_strcpy(EffecRange1,"");

					tc_strcat(EffecRange1,Effecsta1);
					tc_strcat(EffecRange1," to ");
					tc_strcat(EffecRange1,EffecEnd1);


					printf("\n Eff:ctest is range is ..:[%s]",EffecRange1);fflush(stdout);


					ifail = PS_occ_eff_set_date_range(bvr,occs[0],EffecTag1,EffecRange1,false);

					//ifail = PS_occ_eff_set_dates(bvr,occs[0],EffecTag1,2,eff_dates_arr2,EFFECTIVITY_closed,false);

					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);

					ifail = AOM_save_without_extensions(bvr);
					ifail = AOM_refresh(bvr,1);
					ifail = AOM_unlock( bvr );

					ifail = AOM_refresh(childObjTag, 1);
					ifail = AOM_save_without_extensions(childObjTag);
					ifail = AOM_unlock( childObjTag );
					ifail = AOM_refresh(childObjTag, 0);

					ifail = AOM_refresh(primaryObj, 1);
					ifail = AOM_save_without_extensions(primaryObj);
					ifail = AOM_unlock( primaryObj );
					ifail = AOM_refresh(primaryObj, 0);
					nooccret++;
				}
				// for adding new occurrence end
				ifail = AOM_lock( bvr );//change
				// for Updating attribute Value
				Updflg=0;
				if(BOM_create_window(&Updbom_window)!=ITK_ok);
				if(CFM_find( "Latest Working", &Updbom_rule )!=ITK_ok);
				if(BOM_set_window_config_rule(Updbom_window, bom_rule )!=ITK_ok);
				if(BOM_set_window_pack_all(Updbom_window, false)!=ITK_ok);
				if(BOM_set_window_top_line(Updbom_window, null_tag,primaryObj , null_tag, &Updbom_line)!=ITK_ok);

				if(BOM_set_window_top_line_bvr(Updbom_window,bvr,&Updbom_line));

				if(BOM_line_ask_all_child_lines(Updbom_line,&Updchldcnt,&Updbomchild));
				printf("\n BOM_line_ask_all_child_lines22222222222 %d\n",Updchldcnt);

				for (Updcnt = 0; Updcnt<Updchldcnt; Updcnt++)
				{
					if(AOM_ask_value_string(Updbomchild[Updcnt], "bl_item_item_id", &Updchld));
					
					printf("\n\t t5childitems_id in Update loop ===> :: %s <<>> %s \n",Updchld,dataset_name12); fflush(stdout);

					if	(tc_strcmp(Updchld,dataset_name12)==0)
					{
						//setting UID
						ITK__convert_tag_to_uid(Updbomchild[Updcnt],&newuid);
						printf("\n newuid... [%s]\n",newuid);fflush(stdout);
																
						//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
						if(AOM_ask_value_string(Updbomchild[Updcnt],"bl_occ_t5_uidsap",&child_Uidlatest));
						printf("\n child_Uidlatest===============>>>>>> %s\n",child_Uidlatest);

						//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidTypenew));
						if(AOM_ask_value_string(Updbomchild[Updcnt], "bl_occurrence_uid", &ChildUIDNEW));
						printf("\n ChildUIDNEW ===============>>>>>> %s \n",ChildUIDNEW);fflush(stdout);

						printf("\n child_fndid in last expansion ===============>>>>>> %s\n",child_fndid);

						if(AOM_set_value_string(Updbomchild[Updcnt], "bl_occ_t5_uidsap",ChildUIDNEW));

						if((childstr[Updflg].SapUID)!=NULL) 
						tc_strcpy(PartNum,childstr[Updflg].SapUID);


						tc_strcpy(test,"");
						tc_strcpy(test,PartNum);
						tc_strcat(test,sep);
						tc_strcat(test,ChildUIDNEW);

						Updflg++;

						//if(BOM_line_look_up_attribute("bl_occ_t5_uidsapkey",&Uidkey));
						if(AOM_ask_value_string(Updbomchild[Updcnt],"bl_occ_t5_uidsapkey",&child_Uidkey));
						printf("\n child_Uidkey===============>>>>>> %s\n",child_Uidkey);

						if(AOM_set_value_string(Updbomchild[Updcnt],"bl_occ_t5_uidsapkey",test));

						// setting Attribute False
						//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
						if(AOM_ask_value_string(Updbomchild[Updcnt],"bl_occ_t5_upd_vf_form",&child_fndid_latest));
						printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);
						if	(tc_strcmp(child_fndid_latest,"False")==0)
						{
							
							printf("\n child_fndid_latest value ==>>[%s] Value Update not needed\n",child_fndid_latest);
						}
						else
						{
							
							printf("\n child_fndid_latest value ==>>[%s] Value Changing to False\n",child_fndid_latest);
							if(AOM_set_value_string(Updbomchild[Updcnt], "bl_occ_t5_upd_vf_form","False"));
						}
					}
				}
				
				ifail = AOM_save_without_extensions(bvr);
				ifail = AOM_refresh(bvr,1);
				ifail = AOM_unlock( bvr );

				ifail = AOM_refresh(Updbomchild[Updcnt], 1);
				ifail = AOM_save_without_extensions(Updbomchild[Updcnt]);
				ifail = AOM_unlock( Updbomchild[Updcnt] );
				ifail = AOM_refresh(Updbomchild[Updcnt], 0);

				ifail = AOM_refresh(primaryObj, 1);
				ifail = AOM_save_without_extensions(primaryObj);
				ifail = AOM_unlock( primaryObj );
				ifail = AOM_refresh(primaryObj, 0);
				
				// for Updating attribute Value end

			}
				

			MEM_free(bvrs);
			MEM_free(test);
			if(ifail == ITK_ok)
			{
				printf("\nValue updated...!!");fflush(stdout);
			}
		
		}
	}

	return ITK_ok;
}
int tm_SetUVFClrPartfn(EPM_action_message_t msg)
{
		int ifail				= ITK_ok;
		tag_t  rootTask			= NULLTAG;
		tag_t  *attachments	= NULLTAG;
		int no_attach			= 0;
		tag_t  DMLTag = NULLTAG;
		tag_t  dml_tagCL = NULLTAG;
		char   *Item_id = NULL;
		char   *DMLProjS = NULL;
		char   *Item_idCL = NULL;
		char   *DMLIDNo = NULL;

		tag_t  objTypTag		= NULLTAG;
		tag_t  DmlItemsRelation	= NULLTAG;
        char command[512];
		tag_t CLqryTag = NULLTAG;
		int CL_n_entry = 1;
		int CL_rsltCount = 0;
		char *CL_qry_entry[1] = {"SYSCD"};
		tag_t *CLCntrlObjectTag = NULLTAG;
		char **CL_qry_values2 =  (char **) MEM_alloc(10 * sizeof(char *));
		char *CLinfo3 = NULL;
		char *CLinfo4 = NULL;
      printf("\n Start tm_SetUVFClrPartfn----------> \n"); fflush(stdout);

       EPM_ask_root_task(msg.task,&rootTask);
	   printf("\n EPM_ask_root_task----------> \n"); fflush(stdout);
	   ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&no_attach, &attachments);
	   printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);
       if(no_attach > 0) 
		{		
			DMLTag = attachments[0];		
		}
          
		if ( DMLTag != NULLTAG )
		{		
			AOM_ask_value_string(DMLTag,"item_id",&Item_idCL);
			printf("\n DML Item_id for CL is : %s\n",Item_idCL);fflush(stdout);

			DMLIDNo = subString(Item_idCL,0,10);
			printf("\n DMLIDNo----------->%s\n",DMLIDNo); fflush(stdout);

           ITEM_find_item(DMLIDNo, &dml_tagCL);
		if (dml_tagCL != NULLTAG)
		{

         if(QRY_find2("ControlObjects", &CLqryTag));
			if (CLqryTag)
			{
				printf("\n CLCHECK:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CLCHECK:Not Found Query ControlObjects \n");fflush(stdout);
			}

			CL_qry_values2[0] = "UVFCLCHECK";
			if(QRY_execute(CLqryTag, CL_n_entry, CL_qry_entry, CL_qry_values2, &CL_rsltCount, &CLCntrlObjectTag));
			printf(" \n CLCHECK:CL_rsltCount:%d:", CL_rsltCount); fflush(stdout);
			if(CL_rsltCount > 0)
			{
				if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo3",&CLinfo3)!=ITK_ok);//   PrintErrorStack();
				if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo4",&CLinfo4)!=ITK_ok);//   PrintErrorStack();

				printf("\n CL-info3: [%s]  CLinfo4: [%s] \n", CLinfo3, CLinfo4);fflush(stdout);
				if(tc_strstr(CLinfo3,"CLCHECKOFF")==NULL)
				{
					if(tc_strstr(CLinfo3,"CLCHECKUAPROD")!=NULL)
					{
						printf("\n UAPROD:Task name: %s ", DMLIDNo);fflush(stdout);
						sprintf(command,"/user/grr920210/Gajanan/Colour/UFVClrBOM/UVFClrBOM.sh %s",DMLIDNo);
						TC_write_syslog("Command = %s\n",command);
						system(command);
					}
					else if(tc_strstr(CLinfo3,"CLCHECKCMITEST")!=NULL)
					{
						printf("\n CMITEST: Task name: %s ", DMLIDNo);fflush(stdout);
						sprintf(command,"/user/testcmi/devgroups/Gajanan/ClrBOMGen/UVFClrBOM.sh %s",DMLIDNo);
						TC_write_syslog("Command = %s\n",command);
						system(command);
					}
					else
					{
						printf("\n CL-TASK:Other client.. \n");fflush(stdout);
					}
				}
			}


		}

		   
		}
     


	return ifail;
}
/*CR-FY23-0144 - Start */

int isCreOccNewFunctionNew(logical *result, tag_t* cntrlTag)
{
	int ifail = ITK_ok;
	printf("\nIn function  isCreOccNewFunctionNew...\nCheck for control object OccEffNew....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "OccEffNew";
	qry_values[1] = "OccEffNew";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\n Control objects CreOccEff: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));

			
			//printf("\nName:%s\nDelete Indicator:%d\n",name,delInd);fflush(stdout);
			
			*cntrlTag = cntrlObj;
			if(!delInd)
			{
				*result = TRUE;
				//*cntrlTag = cntrlObj;
			}
			
		}

	}

	return ITK_ok;
}

typedef struct ModVFVector_
{
 int id;
 char *occIdList;
} *ModVFVector; 

void setAddModVFVector(int *count,ModVFVector **objlist,ModVFVector obj )
{

	*count=*count+1;
	//printf("\n ****count==>%d", *count);fflush(stdout);
	if(*count==1)
	{
		//printf("\n ****setAddBomLineVector1");fflush(stdout);
		(*objlist) = (ModVFVector *)malloc((*count ) * sizeof(ModVFVector ));
		//printf("\n ***setAddBomLineVector2");fflush(stdout);
	}
	else
	{
		//printf("\n **setAddBomLineVector3");fflush(stdout);
		(*objlist) = (ModVFVector *)realloc((*objlist),(*count) * sizeof(ModVFVector ));
		//printf("\n ***setAddBomLineVector4");fflush(stdout);
		//printf("\n **setAddBomLineVector5");fflush(stdout);
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
	//printf("\n **setAddBomLineVector6");fflush(stdout);
}

/**************************New Logic ****************************/
int Create_occurance_effectivity_newlogic_packed(tag_t primaryObj,tag_t childObjTag, date_t date_start, date_t date_end, char* OccUIDattr,char* arcPlatform)
{
	int ifail = ITK_ok;
	int		bvr_count = 0;
	int		bv_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t line = NULLTAG;
	int count =0;
	tag_t* child = NULL;
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULL;
	tag_t bv = NULLTAG;
	char* arch_modl_id = NULL;
	printf("\n********************Start    -   Create_occurance_effectivity_newlogic_packed *************************************\n");fflush(stdout);
	
	if(AOM_ask_value_string(primaryObj, "item_id", &arch_modl_id));
	if(ITEM_ask_item_of_rev(primaryObj, &archModuleItemTag));
	if(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	printf("\nOCC: [%s] BV Count: %d\n",arch_modl_id,bv_count);fflush(stdout);
	//printf("\nOCC: BV Count: %d\n",bv_count);fflush(stdout);
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}	
	if(ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs));	
	printf("\nOCC:BVR Count: %d\n",bvr_count);fflush(stdout);				
	if(bvr_count)
	{
		bvr = bvrs[0];
		MEM_free(bvrs);
			
	}
	else
	{
		printf("\n No BVR Found.. Exiting....\n");
		return ITK_ok;
	}	

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}		
	if(bvr==NULLTAG)
	{
		return ITK_ok;
	}
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window(&window));
	if(CFM_find( "Latest Working", &rule ));
	if(BOM_set_window_config_rule(window,rule ));
	if(BOM_set_window_pack_all(window, false));
	if(BOM_set_window_top_line(window, NULLTAG,primaryObj,NULLTAG, &line));
	if(BOM_set_window_top_line_bvr(window,bvr,&line));		
	if(BOM_line_ask_all_child_lines(line,&count,&child));
	printf("\nOCC: Child count::::::::>>>>>>>> %d\n",count);
	
	int j = 0;
	char* chldid = NULL;
	char* chldrevid = NULL;
	tag_t moduleRevTag = NULLTAG;
	char* module_item_id = NULL;
	char* module_item_rev = NULL;
	//int fndid = 0;
	char* child_fndid = NULL;	
	//int uidType = 0;
	char* ChildUID = NULL;	
	//int blFormula = 0;
	char* child_blFormula = NULL;	
	int SapUIDCnt = 0;
	char** SapUIDList = NULL;	
	int TransMatCnt = 0;	
	char** TransMatList = NULL;	
	//int xform_matrix = 0;
	char* xform_matrix_str = NULL;	
	int flagBL = 100;
	char** effIdLst2 = NULLTAG;
	int effIdCnt2 = NULLTAG;
	
	char** vFormulaList = NULL;
	int vFormulaCnt = 0;
	
	
	//Get the item_id of the module rev
	if(ITEM_ask_latest_rev(childObjTag, &moduleRevTag));
	if(AOM_ask_value_string(moduleRevTag, "item_id", &module_item_id));
	if(AOM_ask_value_string(moduleRevTag, "item_revision_id", &module_item_rev));
	
	
	for (j = 0; j<count; j++)
	{
		if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
		
		//printf("\nOCC:Module Rev item id :%s <<<<>>>>>>child_line id : [%s] ",module_item_id,chldid);fflush(stdout);
		if(tc_strcmp(chldid,module_item_id)==0)
		{
			
			//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&fndid));
			if(AOM_ask_value_string(child[j],"bl_occ_t5_uidsap",&child_fndid));
			//printf("\nOCC:child_fndid===============> %s\n",child_fndid);

			//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
			if(AOM_ask_value_string(child[j], "bl_occurrence_uid", &ChildUID));
			//printf("\nOCC: ChildUID ===============>%s \n",ChildUID);fflush(stdout);

			if (strlen(child_fndid)==0)
			{
				if(AOM_set_value_string(child[j], "bl_occ_t5_uidsap",ChildUID));
			}

			//printf("\nOCC:  ChildUID [%s] \t OccUIDattr[%s]",ChildUID,OccUIDattr);fflush(stdout);
			if((tc_strstr(OccUIDattr,ChildUID)!= NULL))
			{
				//printf("\nOCC: Inside comparing uid 1 ChildUID & OccUIDattr \n");fflush(stdout);
				printf("\nOCC:Module Rev item id :%s <<<<>>>>>>child_line id : [%s] ",module_item_id,chldid);fflush(stdout);
				printf("\nOCC:  ChildUID [%s] \t OccUIDattr [%s]",ChildUID,OccUIDattr);fflush(stdout);
				
				//if ( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix));
				
				if(AOM_ask_value_string(child[j], "bl_plmxml_abs_xform", &xform_matrix_str));
				printf("\tchild xform_matrix_str: [%s]\n",xform_matrix_str);fflush(stdout);
			
				t5AddStrToSet(&SapUIDCnt, &SapUIDList,ChildUID);
				t5AddStrToSet(&TransMatCnt, &TransMatList,xform_matrix_str);
				
				//VF 
				//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
				if(AOM_ask_value_string(child[j],"bl_formula",&child_blFormula));
				
				if(child_blFormula == NULL)
					child_blFormula = "";
				//child_blFormula="Test VF";
				//if(tc_strcmp(ChildUID,"wbqFfFuGbNpHNC")==0)
					//child_blFormula="Test VF 22";
				t5AddStrToSet(&vFormulaCnt, &vFormulaList,child_blFormula);


			}
		
			
			
			
		}
		
	}


	printf("\nOCC: SapUIDCnt [%d] \t TransMatCnt [%d] \t vFormulaCnt [%d] \n",SapUIDCnt,TransMatCnt,vFormulaCnt);fflush(stdout);
	//Start Test
	//Data Structure to hold the uid - VF 

	int mVfCnt = 0;
	ModVFVector * mVfList = NULL;	
	int ix = 0;
	int id = 0;
	
	int uidCnt1 = 0;
	char** uidList1 = NULL;	
	for(ix=0;ix<vFormulaCnt;ix++)
	{
		int uidCnt = 0;
		char** uidList = NULL;
		int vfCnt1 = 0;
		char** vfList1 = NULL;			

		//printf("[ix: %d]\n",ix);fflush(stdout);
		int fnd = 0;
		t5FindStrInSet(uidList1,uidCnt1,SapUIDList[ix],&fnd);
		if(fnd==0)
		{
			int jx = 0;
			id++;
			t5AddStrToSet(&vfCnt1, &vfList1,vFormulaList[ix]);
			t5AddStrToSet(&uidCnt, &uidList,SapUIDList[ix]);
			t5AddStrToSet(&uidCnt1, &uidList1,SapUIDList[ix]);	
			for(jx=0;jx<vFormulaCnt;jx++)
			{

				//printf("[jx: %d]\n",jx);fflush(stdout);
				if(tc_strcmp(vFormulaList[ix],vFormulaList[jx])==0 && tc_strcmp(SapUIDList[ix],SapUIDList[jx])!=0)
				{
										
					t5AddStrToSet(&vfCnt1, &vfList1,vFormulaList[jx]);
					t5AddStrToSet(&uidCnt, &uidList,SapUIDList[jx]);					
					t5AddStrToSet(&uidCnt1, &uidList1,SapUIDList[jx]);	
				}
				
			}
			printf("\n vfCnt1 ===> %d \n",vfCnt1);fflush(stdout);
			printf("\n uidCnt ===> %d \n",uidCnt);fflush(stdout);
			//printf("\n uidCnt1 ===> %d \n",uidCnt1);fflush(stdout);
			ModVFVector mvf = NULL;
			mvf = (ModVFVector)malloc(sizeof(ModVFVector));
			mvf->id = id;
			mvf->occIdList = NULL;
			
			mvf->occIdList = (char*)malloc(uidCnt*100*sizeof(char*));
			int px =0;
			tc_strcpy(mvf->occIdList,"");
			for(px=0;px<uidCnt;px++)
			{
				tc_strcat(mvf->occIdList,SapUIDList[px]);
				tc_strcat(mvf->occIdList,",");
			}
								
			setAddModVFVector(&mVfCnt,&mVfList,mvf);
			

			
		}
		

	}
	
	printf("\n Module VF Count mVfCnt ===> %d\n", mVfCnt);fflush(stdout);

	int py =0;
	for(py=0;py<mVfCnt;py++)
	{
		printf("\n id:[%d]    uid: [%s]", mVfList[py]->id, mVfList[py]->occIdList);fflush(stdout);
		
	}	
	

	if(SapUIDCnt > 0 && (SapUIDCnt == TransMatCnt) && mVfCnt > 0)
	{
		printf("\n Module [%s;%s] found for this  Architecture Node [%s]. Implement logic for this Node and module.\n",module_item_id,module_item_rev,arch_modl_id);fflush(stdout);		
		
		int n_occs = 0;
		tag_t* occsal = NULL;
		int i = 0;
		int iy = 0;
		int occCnt = 0;
		tag_t* occList = NULL;
		tag_t ChildItem = NULLTAG;
		tag_t bvrchild = NULLTAG;
		char* child_itemId = NULL;
		char* child_itemId1 = NULL;
		char* child_itemIdMul = NULL;
		if(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
		
		printf("\nOCC: n_occs =================> %d \n",n_occs);fflush(stdout);
		
		for (iy = 0; iy<n_occs; iy++)
		{
			if(PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild ));
			
			if(ChildItem!= NULLTAG)
			{
				char* child_itemId = NULL;
				ifail = AOM_ask_value_string(ChildItem, "item_id", &child_itemId);
				//printf("\nOCC:CM_SetOccEff Master name is  :%s==========>%s ",child_itemId,module_item_id);fflush(stdout);	
				
				if ((tc_strcmp(child_itemId,module_item_id)==0))
				{
					//printf("\nAdd to the set occList..........%s \n",child_itemId);fflush(stdout);
					t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
					tc_strdup(child_itemId, &child_itemIdMul);
										
				}				

			}
			
		}
		printf("\nOCC:Occurance[%s] , Count occCnt [%d] \n",child_itemIdMul,occCnt);fflush(stdout);
		
		//To add the effective name in a set - to generate multi occ id.
		int k = 0;
		tag_t * Effobbj = NULL;
		int effcnt = 0;
		

		for(k=0;k<occCnt;k++)
		{
			tag_t occTag = NULLTAG;
			occTag = occList[k];
			
			if(PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild ));
			if(ChildItem!= NULLTAG)
			{
				//ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				effcnt = 0;
				Effobbj = NULLTAG;
				if(PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj));
				if(effcnt>0)
				{
					char* effId = NULL;
					tag_t effObj = NULLTAG;
					int flag =0;
					effObj= Effobbj[0];
					if(PS_occ_eff_ask_id(bvr,occTag,effObj, &effId));
					//printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
					
					if(effId==NULL )
					{
						flag++;
						
					}
					else if(tc_strcmp(effId,"")==0)
					{
						flag++;
					}
					//printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
					
					if(flag==0)									
					{
						//printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
						t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
					}
					if(flag>=1)
					{
						//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
						//ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
						//ifail = PS_occ_eff_set_id(bvr,occTag,effObj,effId);
					}
				}
								
				
			}
			
		}
		
		printf("\nOCC: effIdCnt2 [%d]\n",effIdCnt2);fflush(stdout);
						
		//loop through bom lines
		for (j = 0; j<count; j++)
		{
			flagBL = 100;
			if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
			if(AOM_ask_value_string(child[j], "bl_rev_item_revision_id", &chldrevid));

			if(tc_strcmp(chldid,module_item_id)==0)
			{
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child[j], "bl_occurrence_uid", &ChildUID));				
				if((tc_strstr(OccUIDattr,ChildUID)!= NULL))
				{
					int flagOcc = 0;
					tag_t occTg = NULLTAG;
					
					//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
					if(AOM_ask_value_string(child[j],"bl_formula",&child_blFormula));
					printf("\nchild_blFormula11===============>>>>>> %s\n",child_blFormula);
					if(child_blFormula==NULL)
					{
						flagBL = 0;
					}
					else 
					{
						if(strlen(child_blFormula)==0)
						{
							printf("\n No variant formula...\n");fflush(stdout);
							flagBL = 0;
						}
					}					
					//flagBL =100;//test
					//Get the occurence tag.
					for (i = 0; i <n_occs; i++)
					{
						char* uidocc = NULL;
						if(PS_ask_occurrence_child( bvr,occsal[i], &ChildItem, &bvrchild ));
						if(AOM_ask_value_string(ChildItem, "item_id", &child_itemId1));
						//printf("\nOCC: Child Item Master ID is  :%s ",child_itemId);fflush(stdout);

						ITK__convert_tag_to_uid(occsal[i],&uidocc);
						//printf("\n uidocc... [%s]\n",uidocc);fflush(stdout);
						if(tc_strcmp(ChildUID,uidocc)==0)
						{
							if(tc_strcmp(child_itemId1,module_item_id)==0)
							{
								flagOcc ++;
								occTg = occsal[i];
								break;
							}
						}
						
					}
					printf("\n Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
										
					if(occTg != NULLTAG)
					{
						if(PS_occ_eff_ask_effs(bvr,occTg,&effcnt,&Effobbj));
						printf("\nOCC: Effectivity count is...%d",effcnt);fflush(stdout);
						//If No effectivity then create it
						if (effcnt == 0)
						{
							printf("\nOccurence Effectivity not found for %s;%s, uid[%s]. Going to create ......\n", chldid,chldrevid,ChildUID);fflush(stdout);
							int ij=0;
							int found =0;
							int seq = 0;						
							char EffecName[200];
							tag_t EffecTag = NULLTAG;
							if(occCnt > 0)
							{
								found =0;
								seq =0;
								for(;;)
								{
									char str1[20];
									sprintf(str1, "%d", seq+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,chldid);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,chldrevid);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);

									//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									//printf("\n EffecName [%s]....Found==>%d\n",EffecName,found);fflush(stdout);
									if(found==0)
									{
										
										break;
									}
									else
									{
										seq++;
									}
									
								}
								
								
								if(found ==0)
								{
									ifail = AOM_lock( bvr );
									
									if(PS_occ_eff_create(bvr,occTg,&EffecTag));
								
								
									if(EffecTag != NULLTAG)		
									{


										if(PS_occ_eff_set_id(bvr,occTg,EffecTag,EffecName));
										//ifail = PS_occ_eff_set_id(bvr,occTg,EffecTag,EffecName);
																			
										
										char EffecRange1[200];
										char* EffecEnd1 = NULL;
										char cCurrentAccessDate1[20]={0};
										
										t5GetCurrentDateTime(cCurrentAccessDate1);
										printf("\n111..flagBL==>%d\n",flagBL);fflush(stdout);
										if(flagBL==0)
										{
											EffecEnd1 = "31-Dec-2099";
										}
										else
										{
											EffecEnd1=subString(cCurrentAccessDate1,0,11);
										}									
										
										tc_strcpy(EffecRange1,"");

										tc_strcat(EffecRange1,"1-Jan-2005");
										tc_strcat(EffecRange1," to ");
										tc_strcat(EffecRange1,EffecEnd1);

										printf("\nOCC:111new effective range of the occurence %s;%s  id[%s]  is..:[%s]",module_item_id,chldrevid,ChildUID,EffecRange1);fflush(stdout);									

										//ifail = PS_occ_eff_set_date_range(bvr,occTg,EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);
										if(PS_occ_eff_set_date_range(bvr,occTg,EffecTag,EffecRange1,FALSE));
										
										if(AOM_save_without_extensions(EffecTag));
										if(AOM_refresh(EffecTag, 0));
										t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);											

										//if(AOM_refresh(bvr, 1));									
										ifail =  AOM_save_without_extensions(bvr);
										ifail =  AOM_unlock( bvr );
										//if(AOM_refresh(bvr, 0));
								
										ifail = AOM_refresh(childObjTag, 1);
										ifail = AOM_save_without_extensions(childObjTag);
										ifail = AOM_unlock( childObjTag );
										ifail = AOM_refresh(childObjTag, 0);

										ifail = AOM_refresh(primaryObj, 1);
										ifail = AOM_save_without_extensions(primaryObj);
										ifail = AOM_unlock( primaryObj );
										ifail = AOM_refresh(primaryObj, 0);								


										printf("\n Occurence Effectivity Created successfully for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);

									}
									else
									{
										printf("\n Occurence Effectivity NOT Created for part %s;%s, uid[%s]. Pls check with admin\n", chldid,chldrevid,ChildUID);fflush(stdout);
									}
									ifail = AOM_unlock( bvr );
									
								}
								
								
								
							}
							
						}
						else
						{
							int n_dates = 0;
							date_t*  start_end_values = NULL;
							int EFFECTIVITY_closed =0;
							char* Effecid = NULL;
							//char* Effecoccname = NULL;
							char* old_to_date = NULL;
							char* old_from_date = NULL;
							char cCurrentAccessDate[20]={0};
							//Occurence Effectivity already present.
							//Get date range of an occurrence effectivity as an array
							if(PS_occ_eff_ask_dates(bvr,occTg,Effobbj[0],&n_dates,&start_end_values,&EFFECTIVITY_closed));

							if(PS_occ_eff_ask_id(bvr,occTg,Effobbj[0],&Effecid));
							//printf("\nEffecid >>>>>>>>>>>>>> %s",Effecid);fflush(stdout);


							//ifail = PS_ask_occurrence_name(bvr,occTg,&Effecoccname);

							//printf("\n Effecoccname >>>>>>>>>>>>>> %s",Effecoccname);fflush(stdout);
							
							//printf("\n The size of the array of start-end values==> %d\n",n_dates);fflush(stdout);
							t5GetCurrentDateTime(cCurrentAccessDate);
							//printf("\nOCC:cCurrentAccessDate:[%s] ",cCurrentAccessDate);fflush(stdout);
							
							if(n_dates > 0)
							{
								date_t Ltest_date_1 = NULLDATE;
								logical date_is_valid = false;
								
								ifail = DATE_date_to_string(start_end_values[0],"%d-%b-%Y %H:%M", &old_from_date );
									
								ifail = DATE_date_to_string(start_end_values[1],"%d-%b-%Y %H:%M", &old_to_date );
									
								printf("\nold_from_date: [%s] , old_to_date[%s]\n",old_from_date,old_to_date);fflush(stdout);
								
								ifail = DATE_string_to_date_t(old_from_date, &date_is_valid,&Ltest_date_1 );
								
								if(date_is_valid != true)
								{
									printf("\n OCC:date_is_valid is not true .....");fflush(stdout);
								}
								else
								{
									
									char* EFF_OLD = NULL;
									char* EFF_CURRENT = NULL;
									
									
									EFF_OLD=subString(old_from_date,0,11);
									EFF_CURRENT=subString(cCurrentAccessDate,0,11);

									printf("\nOCC: new old andcurrent dates are:[%s %s] ",EFF_OLD,EFF_CURRENT);fflush(stdout);
									if ((tc_strcmp(EFF_OLD,EFF_CURRENT)==0))
									{
										printf("\n Cannot Create Multiple Occurance on same day of [%s;%s, uid[%s] \n",module_item_id,chldrevid,ChildUID ); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err, "Cannot Create Multiple Occurance on same day",module_item_id);
										return ITK_err;
									}
									
								}
								
							}
							else
							{
								printf("\nOCC: wrong dates... Check with admin\n");fflush(stdout);
							}
							
							//Set the end effective date of the occurence to today's date if no VF
							char* Effecsta = NULL;
							char* EffecEnd = NULL;
							
							Effecsta=subString(old_from_date,0,11);
							
							printf("\nflagBL==>%d\n",flagBL);fflush(stdout);
							if(flagBL==0)
							{
								EffecEnd = "31-Dec-2099";
							}
							else
							{
								EffecEnd=subString(cCurrentAccessDate,0,11);
							}
							
							char EffecRange[200];

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,Effecsta);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EffecEnd);

							printf("\nOCC:new effective range of the occurence %s;%s  id[%s]  is..:[%s]",module_item_id,chldrevid,ChildUID,EffecRange);fflush(stdout);

							ifail = AOM_lock( bvr );
							/*if(ifail = 43021)
							{
								printf("\nOCC: Error!!!!!!! The BOM View Revision cannot be modified. It is locked. \n");fflush(stdout);
								return ITK_err;
							*/
							ifail = AOM_lock( Effobbj[0] );



							if(PS_occ_eff_set_date_range(bvr,occTg,Effobbj[0],EffecRange,false));

							ifail = AOM_save_without_extensions(Effobbj[0]);
							ifail = AOM_refresh(Effobbj[0], 0);
							//if(AOM_unlock( Effobbj[0] ));
															
							ifail = AOM_save_without_extensions(bvr);
							ifail = AOM_unlock( bvr );
							//if(AOM_refresh(bvr, 0));
					
							ifail = AOM_refresh(childObjTag, 1);
							ifail = AOM_save_without_extensions(childObjTag);
							ifail = AOM_unlock( childObjTag );
							ifail = AOM_refresh(childObjTag, 0);

							ifail = AOM_refresh(primaryObj, 1);
							ifail = AOM_save_without_extensions(primaryObj);
							ifail = AOM_unlock( primaryObj );
							ifail = AOM_refresh(primaryObj, 0);	
							
						}							
						
					
					
					
					}
					

				}				
				
			}

			
			
		}//End of For Loop
				
		
	}
	else
	{
		printf("\n Skip this Architecture Node[%s] as the Module[%s;%s] is not applicable for this node.....\n",arch_modl_id,module_item_id,module_item_rev);fflush(stdout);		
	}
	
	
	if(BOM_close_window(window));
	//Update the attributes.
	
	int k =0;
	//char transcpy[10000];
	char* transcpy = NULL;
	char *tempmat1=NULL;
	double mat[4][4];
	char *tempmat=NULL;
	
	tag_t window1 = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t line1 = NULLTAG;
	count =0;
	tag_t* child1 = NULL;
	int newIDCnt = 0;
	char** newIDList = NULL;
	int oldIDCnt = 0;
	char** oldIDList = NULL;
	int vfCnt = 0;
	char** vfList = NULL;	
	char* seq_no  = NULL;
	//int newSeqCnt = 0;
	//char** newSeqList = NULL;	
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
	if(BOM_create_window(&window1));
	if(CFM_find( "Latest Working", &rule1 ));
	if(BOM_set_window_config_rule(window1,rule1 ));
	if(BOM_set_window_pack_all(window1, false));
	if(BOM_set_window_top_line(window1, NULLTAG,primaryObj,NULLTAG, &line1));

	if(BOM_set_window_top_line_bvr(window1,bvr,&line1));
	if(BOM_line_ask_all_child_lines(line1,&count,&child1));
	printf("\nOCC: Child count 2222222>>>>>>>> %d\n",count);	
	
	int k1 =0;
	for(k1=0;k1<mVfCnt;k1++)
	{	

		int l =0;
		
		if(USER_ask_new_default_sequence_number(bvr, moduleRevTag,&seq_no));
		for(l=0;l<count;l++)
		{
			flagBL = 100;
			//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
			if(AOM_ask_value_string(child1[l], "bl_occurrence_uid", &ChildUID));
			//printf("\nOCC:ChildUID ===============>%s \n",ChildUID);fflush(stdout);
			
			//if(tc_strcmp(ChildUID,SapUIDList[k])==0)
			if(tc_strstr(mVfList[k1]->occIdList,ChildUID)!=NULL)	
			{
				if(AOM_ask_value_string(child1[l], "bl_item_item_id", &chldid));
				if(AOM_ask_value_string(child1[l], "bl_rev_item_revision_id", &chldrevid));
				printf("\nOCC: 111..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
				
				//if the variant formula is blank then don't create any occurence. Only update the vflag as true.
				//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
				if(AOM_ask_value_string(child1[l],"bl_formula",&child_blFormula));
				if(child_blFormula==NULL)
				{
					flagBL = 0;
				}
				else 
				{
					if(strlen(child_blFormula)==0)
					{
						printf("\nOCC.111 No variant formula...\n");fflush(stdout);
						flagBL = 0;
					}
				}
				//flagBL = 100;//test
							
				if(flagBL !=0)
				{
					
					
					int found1 =0;
					int seq1 =0;
					char EffecName1[200];
					int imat =0;
					int jmat =0;
					for(;;)
					{
						char str2[20];
						sprintf(str2, "%d", seq1+1);
						tc_strcpy(EffecName1,"");
						tc_strcat(EffecName1,chldid);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,chldrevid);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,arcPlatform);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,str2);


						//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
						
						t5FindStrInSet(effIdLst2,effIdCnt2,EffecName1,&found1);
						//printf("\n EffecName1 [%s]....Found==>%d\n",EffecName1,found1);fflush(stdout);
						if(found1==0)
						{
							
							break;
						}
						else
						{
							seq1++;
						}
						
					}//end of for
					transcpy = (char *) MEM_alloc(tc_strlen(TransMatList[k])*sizeof(char) + 100);
					tc_strcpy(transcpy,TransMatList[k]);
					
					printf("\nOCC: trans before stamp=======> :: %s\n",transcpy); fflush(stdout);
					
					tempmat1=tc_strtok(transcpy," ");
					
					
					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							if(imat==0 && jmat==0)
							{
								//printf("\n inside if"); fflush(stdout);
								mat[imat][jmat]=strtod(tempmat1,NULL);
							}else
							{
								//printf("\n inside else"); fflush(stdout);
								tempmat=tc_strtok(NULL," ");
								mat[imat][jmat]=strtod(tempmat,NULL);
							}
						}
					}


					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							printf("%10lf,",mat[imat][jmat]);
						}
						printf("\n");
					}				

					ifail = AOM_lock( bvr );
					
					tag_t* occs = NULL;
					tag_t EffecTag1 = NULLTAG;
					char cCurrentAccessDate2[20]={0};
					char* Effecsta1 = NULL;
					char* EffecEnd1 = NULL;
					char EffecRange1[200];
					char* newoccId = NULL;

					if(PS_create_occurrences( bvr, moduleRevTag, NULLTAG,1, &occs ));
					if(occs[0] == NULLTAG)
					{
						printf("\n Occurence Creation Failed. Skip....\n");fflush(stdout);
						continue;
					}
					if(PS_set_plmxml_transform(bvr, occs[0], *mat));
					
					if(PS_occ_eff_create(bvr,occs[0],&EffecTag1));
					ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,EffecName1);
					
					if(ifail == 710079)
					{
						printf("\n Duplicate ID -Duplicate name : Effectivity info with name %s already exists\n",EffecName1);fflush(stdout);
						char newEffName[200];
						tc_strcpy(newEffName,EffecName1);
						tc_strcat(newEffName,"_1");
						ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,newEffName);
						
						t5AddStrToSet(&effIdCnt2, &effIdLst2,newEffName);
						t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName1);
						//continue;
					}
					//Set sequence no.
					if(PS_set_seq_no(bvr,occs[0],seq_no));
					printf("\n UserInfo2 ==> PACKEDLOGIC. Implementing Packed logic to set find nos...\n");fflush(stdout);
					//End Setting Seq no.
					//Set Quantity
					double qty = 0.00;
					ifail = PS_ask_occurrence_qty(bvr, occs[0],&qty);
					printf("\nThe quantity for the newly created occurence===> %lf\n",qty);fflush(stdout);
					if(qty > 0)
					{
						printf("\nAlready there is quantity. No need to set the quantity for the newly created occurence...\n");fflush(stdout);
					}
					else
					{
						ifail = PS_set_occurrence_qty(bvr, occs[0],1);
						printf("\nSetting the quantity for the newly created occurence...\n");fflush(stdout);
					}					
					
					//End Quantity
					
					t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName1);

					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);
					
					t5GetCurrentDateTime(cCurrentAccessDate2);
					
					Effecsta1=subString(cCurrentAccessDate2,0,11);
					EffecEnd1 = "31-Dec-2099";
					

					tc_strcpy(EffecRange1,"");

					tc_strcat(EffecRange1,Effecsta1);
					tc_strcat(EffecRange1," to ");
					tc_strcat(EffecRange1,EffecEnd1);


					printf("\n Eff:ctest is range is ..:[%s]",EffecRange1);fflush(stdout);


					if(PS_occ_eff_set_date_range(bvr,occs[0],EffecTag1,EffecRange1,false));

			
					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);

					ifail = AOM_save_without_extensions(bvr);
					ifail = AOM_refresh(bvr,1);
					ifail = AOM_unlock( bvr );

					ifail = AOM_refresh(childObjTag, 1);
					ifail = AOM_save_without_extensions(childObjTag);
					ifail = AOM_unlock( childObjTag );
					ifail = AOM_refresh(childObjTag, 0);

					ifail = AOM_refresh(primaryObj, 1);
					ifail = AOM_save_without_extensions(primaryObj);
					ifail = AOM_unlock( primaryObj );
					ifail = AOM_refresh(primaryObj, 0);
					
					
					if(transcpy) MEM_free(transcpy);
					
					ITK__convert_tag_to_uid(occs[0],&newoccId);
					printf("\n newoccId... [%s]\n",newoccId);fflush(stdout);
					t5AddStrToSet(&newIDCnt, &newIDList,newoccId);
					
					t5AddStrToSet(&oldIDCnt, &oldIDList,ChildUID);
					//t5AddStrToSet(&newSeqCnt, &newSeqList,sequence_number);
					
					
				}
				else
				{
					//only update the VF flag.
					// setting Attribute False
					//int fndidlatest = 0;
					char* child_fndid_latest = NULL;
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
					if(AOM_ask_value_string(child1[l],"bl_occ_t5_upd_vf_form",&child_fndid_latest));
					//printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);
					if(tc_strcmp(child_fndid_latest,"False")==0)
					{
						
						//printf("\n child_fndid_latest value ==>>[%s] Value Update not needed\n",child_fndid_latest);fflush(stdout);
					}
					else
					{
						
						//printf("\n child_fndid_latest value ==>>[%s] Value Changing to False\n",child_fndid_latest);fflush(stdout);
						if(AOM_set_value_string(child1[l], "bl_occ_t5_upd_vf_form","False"));
					}
					
					
				}
				
				
				

				
			}

			
			
		}
			
		

		


		
	}
	if(BOM_close_window(window1));
	
	printf("\nnewIDCnt==>%d, oldIDCnt ==> %d\n",newIDCnt,oldIDCnt);fflush(stdout);
	
	//Update the other attributes,
	count = 0;
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
	if(BOM_create_window(&window1));
	if(CFM_find( "Latest Working", &rule1 ));
	if(BOM_set_window_config_rule(window1,rule1 ));
	if(BOM_set_window_pack_all(window1, false));
	if(BOM_set_window_top_line(window1, NULLTAG,primaryObj,NULLTAG, &line1));

	if(BOM_set_window_top_line_bvr(window1,bvr,&line1));
	if(BOM_line_ask_all_child_lines(line1,&count,&child1));
	printf("\nOCC: Child count 33333>>>>>>>> %d\n",count);		
	
	
	//int Uidlatest = 0;
	int Uidkey = 0;
	char* child_Uidlatest = NULL;
	char* child_Uidkey = NULL;
	//int fndidlatest1 = 0;
	char* child_fndid_latest1 = NULL;
	int m = 0;
	int m1 = 0;
	//Case when new occurence created.
	if(newIDCnt > 0 && newIDCnt == oldIDCnt)
	{
		printf("\nOCC: Update the attributes of the newly created occurences \n");fflush(stdout);
		m = 0;
		m1 = 0;
		for(m1=0;m1<newIDCnt;m1++)
		{
			for(m=0;m<count;m++)
			{
				flagBL = 100;
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child1[m], "bl_occurrence_uid", &ChildUID));

				if(tc_strcmp(ChildUID,newIDList[m1])==0)
				{
					if(AOM_ask_value_string(child1[m], "bl_item_item_id", &chldid));
					if(AOM_ask_value_string(child1[m], "bl_rev_item_revision_id", &chldrevid));
					printf("\nOCC: 222..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsap",&child_Uidlatest));
					//printf("\n child_Uidlatest===============>>>>>> %s\n",child_Uidlatest);

					if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsap",ChildUID));
					
					char * tmpStr = NULL;
					tmpStr = (char*)MEM_alloc(200*sizeof(char));
					tc_strcpy(tmpStr,oldIDList[m1]);
					tc_strcat(tmpStr,"_");
					tc_strcat(tmpStr,ChildUID);
					printf("\n UID_SAP_Key: [%s] \n",tmpStr);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsapkey",&Uidkey));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsapkey",&child_Uidkey));
					printf("\n child_Uidkey===============>>>>>> %s\n",child_Uidkey);

					if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsapkey",tmpStr));
					
					MEM_free(tmpStr);
					
				
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
					//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
					if(tc_strcmp(child_fndid_latest1,"False")==0)
					{
						
						//printf("\n111 child_fndid_latest1 value ==>>[%s] Value Update not needed\n",child_fndid_latest1);fflush(stdout);
					}
					else
					{
						
						//printf("\n 111 child_fndid_latest1 value ==>>[%s] Value Changing to False\n",child_fndid_latest1);fflush(stdout);
						if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","False"));
					}								
					
					
				}
				
				//Update the VF flag to True for the line item which is effective out. so that it cannot be updated.
				if(tc_strcmp(ChildUID,oldIDList[m1])==0)
				{
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
					//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
					if(tc_strcmp(child_fndid_latest1,"False")==0)
					{
						printf("\n Updating effective out  child child_fndid_latest1 value ==>>[%s] Value Changing to True\n",child_fndid_latest1);fflush(stdout);
						if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","True"));						
					}							
					
				}

				
			}
			
		}		
		
		
		
	}
	
	//Case when no new occurence created and the modules attached to the VF DML is having blank VF.
	if(newIDCnt ==0 && SapUIDCnt >0)
	{
		printf("\nOCC: Update the attributes VF_Flag as False of the occurences if BL_flag is non zero \n");fflush(stdout);
		
		m = 0;
		m1 = 0;
		for(m1=0;m1<SapUIDCnt;m1++)
		{
			for(m=0;m<count;m++)
			{
				flagBL = 100;
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child1[m], "bl_occurrence_uid", &ChildUID));

				if(tc_strcmp(ChildUID,SapUIDList[m1])==0)
				{
					if(AOM_ask_value_string(child1[m], "bl_item_item_id", &chldid));
					if(AOM_ask_value_string(child1[m], "bl_rev_item_revision_id", &chldrevid));
					//printf("\nOCC: 222..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsap",&child_Uidlatest));
					//printf("\n child_Uidlatest===============>>>>>> %s\n",child_Uidlatest);
					
					if(tc_strcmp(child_Uidlatest,ChildUID) != 0)
					{
						if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsap",ChildUID));
					}
					
									
					//if the variant formula is blank  update the vflag as true.
					//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
					if(AOM_ask_value_string(child1[m],"bl_formula",&child_blFormula));
					if(child_blFormula==NULL)
					{
						flagBL = 0;
					}
					else 
					{
						if(strlen(child_blFormula)==0)
						{
							//printf("\nOCC.111 No variant formula...\n");fflush(stdout);
							flagBL = 0;
						}
					}
					if(flagBL == 0)
					{
						
						//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
						if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
						//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
						if(tc_strcmp(child_fndid_latest1,"False")==0)
						{
							
							//printf("\n111 child_fndid_latest1 value ==>>[%s] Value Update not needed\n",child_fndid_latest1);fflush(stdout);
						}
						else
						{
							
							//printf("\n 111 child_fndid_latest1 value ==>>[%s] Value Changing to False\n",child_fndid_latest1);fflush(stdout);
							if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","False"));
						}				
						
					}
								
					
					
				}			
			}
			
		}		
				
	
	}
	
	//if(BOM_save_window(window1));
	if(BOM_close_window(window1));
	if(ifail== ITK_ok)
	{
		printf("\nOccurence created and updated successfully....\n");fflush(stdout);
	}	
	
	printf("\n********************End    -   Create_occurance_effectivity_newlogic_packed  *************************************\n");fflush(stdout);
	
	return ITK_ok;
}


int Create_occurance_effectivity_newlogic(tag_t primaryObj,tag_t childObjTag, date_t date_start, date_t date_end, char* OccUIDattr,char* arcPlatform)
{
	int ifail = ITK_ok;
	int		bvr_count = 0;
	int		bv_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t line = NULLTAG;
	int count =0;
	tag_t* child = NULL;
	tag_t archModuleItemTag = NULLTAG;
	tag_t* bvs = NULL;
	tag_t bv = NULLTAG;
	char* arch_modl_id = NULL;
	printf("\n********************Start    -   Create_occurance_effectivity_newlogic  *************************************\n");fflush(stdout);	
	if(AOM_ask_value_string(primaryObj, "item_id", &arch_modl_id));
	
	if(ITEM_ask_item_of_rev(primaryObj, &archModuleItemTag));
	if(ITEM_list_bom_views(archModuleItemTag, &bv_count, &bvs ));
	printf("\nOCC: [%s] BV Count: %d\n",arch_modl_id,bv_count);fflush(stdout);
	if(bv_count)
	{
		bv = bvs[0];
		MEM_free(bvs);
	}	
	if(ITEM_rev_list_bom_view_revs(primaryObj,&bvr_count, &bvrs));	
	printf("\nOCC: [ %s ]BVR Count: %d\n",arch_modl_id,bvr_count);fflush(stdout);				
	if(bvr_count)
	{
		bvr = bvrs[0];
		MEM_free(bvrs);
			
	}
	else
	{
		printf("\n No BVR Found.. Exiting....\n");
		return ITK_ok;
	}	

	if ( bv != NULLTAG )
	{
		ifail = AOM_unload( bv );					
			
	}		
	if(bvr==NULLTAG)
	{
		return ITK_ok;
	}
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window(&window));
	if(CFM_find( "Latest Working", &rule ));
	if(BOM_set_window_config_rule(window,rule ));
	if(BOM_set_window_pack_all(window, false));
	if(BOM_set_window_top_line(window, NULLTAG,primaryObj,NULLTAG, &line));
	if(BOM_set_window_top_line_bvr(window,bvr,&line));		
	if(BOM_line_ask_all_child_lines(line,&count,&child));
	printf("\nOCC: Child count::::::::>>>>>>>> %d\n",count);
	
	int j = 0;
	char* chldid = NULL;
	char* chldrevid = NULL;
	tag_t moduleRevTag = NULLTAG;
	char* module_item_id = NULL;
	char* module_item_rev = NULL;
	//int fndid = 0;
	char* child_fndid = NULL;	
	//int uidType = 0;
	char* ChildUID = NULL;	
	//int blFormula = 0;
	char* child_blFormula = NULL;	
	int SapUIDCnt = 0;
	char** SapUIDList = NULL;	
	int TransMatCnt = 0;	
	char** TransMatList = NULL;	
	//int xform_matrix = 0;
	char* xform_matrix_str = NULL;	
	int flagBL = 100;
	char** effIdLst2 = NULLTAG;
	int effIdCnt2 = NULLTAG;
	

	
	//Get the item_id of the module rev
	if(ITEM_ask_latest_rev(childObjTag, &moduleRevTag));
	if(AOM_ask_value_string(moduleRevTag, "item_id", &module_item_id));
	if(AOM_ask_value_string(moduleRevTag, "item_revision_id", &module_item_rev));
	
	
	for (j = 0; j<count; j++)
	{
		if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
		
		//printf("\nOCC:Module Rev item id :%s <<<<>>>>>>child_line id : [%s] ",module_item_id,chldid);fflush(stdout);
		if(tc_strcmp(chldid,module_item_id)==0)
		{
			
			//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&fndid));
			if(AOM_ask_value_string(child[j],"bl_occ_t5_uidsap",&child_fndid));
			//printf("\nOCC:child_fndid===============> %s\n",child_fndid);

			//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
			if(AOM_ask_value_string(child[j], "bl_occurrence_uid", &ChildUID));
			//printf("\nOCC: ChildUID ===============>%s \n",ChildUID);fflush(stdout);

			if (strlen(child_fndid)==0)
			{
				if(AOM_set_value_string(child[j], "bl_occ_t5_uidsap",ChildUID));
			}

			//printf("\nOCC:  ChildUID [%s] \t OccUIDattr[%s]",ChildUID,OccUIDattr);fflush(stdout);
			if((tc_strstr(OccUIDattr,ChildUID)!= NULL))
			{
				//printf("\nOCC: Inside comparing uid 1 ChildUID & OccUIDattr \n");fflush(stdout);
				printf("\nOCC:Module Rev item id :%s <<<<>>>>>>child_line id : [%s] ",module_item_id,chldid);fflush(stdout);
				printf("\nOCC:  ChildUID [%s] \t OccUIDattr [%s]",ChildUID,OccUIDattr);fflush(stdout);
				
				//if ( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix));
				
				if(AOM_ask_value_string(child[j], "bl_plmxml_abs_xform", &xform_matrix_str));
				printf("\tchild xform_matrix_str: [%s]\n",xform_matrix_str);fflush(stdout);
			
				t5AddStrToSet(&SapUIDCnt, &SapUIDList,ChildUID);
				t5AddStrToSet(&TransMatCnt, &TransMatList,xform_matrix_str);
				
			}
		
			
			
			
		}
		
	}


	printf("\nOCC: SapUIDCnt [%d] \t TransMatCnt [%d]\n",SapUIDCnt,TransMatCnt);fflush(stdout);

	if(SapUIDCnt > 0 && (SapUIDCnt == TransMatCnt))
	{
		printf("\n Module [%s;%s] found for this  Architecture Node [%s]. Implement logic for this Node and module.\n",module_item_id,module_item_rev,arch_modl_id);fflush(stdout);
		
		int n_occs = 0;
		tag_t* occsal = NULL;
		int i = 0;
		int iy = 0;
		int occCnt = 0;
		tag_t* occList = NULL;
		tag_t ChildItem = NULLTAG;
		tag_t bvrchild = NULLTAG;
		char* child_itemId = NULL;
		char* child_itemId1 = NULL;
		char* child_itemIdMul = NULL;
		if(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
		
		printf("\nOCC: n_occs =================> %d \n",n_occs);fflush(stdout);
		
		for (iy = 0; iy<n_occs; iy++)
		{
			if(PS_ask_occurrence_child( bvr,occsal[iy], &ChildItem, &bvrchild ));
			
			if(ChildItem!= NULLTAG)
			{
				char* child_itemId = NULL;
				ifail = AOM_ask_value_string(ChildItem, "item_id", &child_itemId);
				//printf("\nOCC:CM_SetOccEff Master name is  :%s==========>%s ",child_itemId,module_item_id);fflush(stdout);	
				
				if ((tc_strcmp(child_itemId,module_item_id)==0))
				{
					//printf("\nAdd to the set occList..........%s \n",child_itemId);fflush(stdout);
					t5AddTagObjToSet(&occCnt,&occList,occsal[iy]);
					tc_strdup(child_itemId, &child_itemIdMul);
										
				}				

			}
			
		}
		printf("\nOCC:Occurance[%s] , Count occCnt [%d] \n",child_itemIdMul,occCnt);fflush(stdout);
		
		//To add the effective name in a set - to generate multi occ id.
		int k = 0;
		tag_t * Effobbj = NULL;
		int effcnt = 0;
		

		for(k=0;k<occCnt;k++)
		{
			tag_t occTag = NULLTAG;
			occTag = occList[k];
			
			if(PS_ask_occurrence_child( bvr,occTag, &ChildItem, &bvrchild ));
			if(ChildItem!= NULLTAG)
			{
				//ifail = AOM_ask_value_string(ChildItem, "item_id", &dataset_name1);
				effcnt = 0;
				Effobbj = NULLTAG;
				if(PS_occ_eff_ask_effs(bvr,occTag,&effcnt,&Effobbj));
				if(effcnt>0)
				{
					char* effId = NULL;
					tag_t effObj = NULLTAG;
					int flag =0;
					effObj= Effobbj[0];
					if(PS_occ_eff_ask_id(bvr,occTag,effObj, &effId));
					//printf("\nSAN111111: effId==> %s\n",effId);fflush(stdout);
					
					if(effId==NULL )
					{
						flag++;
						
					}
					else if(tc_strcmp(effId,"")==0)
					{
						flag++;
					}
					//printf("\nSAN2222: flag==> %d\n",flag);fflush(stdout);
					
					if(flag==0)									
					{
						//printf("\nSAN: adding to the set effIdLst2 ..effId... [ %s ]\n",effId);fflush(stdout);
						t5AddStrToSet(&effIdCnt2, &effIdLst2,effId);
					}
					if(flag>=1)
					{
						//printf("\nSAN: Removed effectivity\n",effId);fflush(stdout);
						//ifail= PS_occ_eff_remove_eff(bvr,occTag,effObj);
						//ifail = PS_occ_eff_set_id(bvr,occTag,effObj,effId);
					}
				}
								
				
			}
			
		}
		
		printf("\nOCC: effIdCnt2 [%d]\n",effIdCnt2);fflush(stdout);
						
		//loop through bom lines
		for (j = 0; j<count; j++)
		{
			flagBL = 100;
			if(AOM_ask_value_string(child[j], "bl_item_item_id", &chldid));
			if(AOM_ask_value_string(child[j], "bl_rev_item_revision_id", &chldrevid));

			if(tc_strcmp(chldid,module_item_id)==0)
			{
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child[j], "bl_occurrence_uid", &ChildUID));				
				if((tc_strstr(OccUIDattr,ChildUID)!= NULL))
				{
					int flagOcc = 0;
					tag_t occTg = NULLTAG;
					
					//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
					if(AOM_ask_value_string(child[j],"bl_formula",&child_blFormula));
					printf("\nchild_blFormula11===============>>>>>> %s\n",child_blFormula);
					if(child_blFormula==NULL)
					{
						flagBL = 0;
					}
					else 
					{
						if(strlen(child_blFormula)==0)
						{
							printf("\n No variant formula...\n");fflush(stdout);
							flagBL = 0;
						}
					}					
					//flagBL =100;//test
					//Get the occurence tag.
					for (i = 0; i <n_occs; i++)
					{
						char* uidocc = NULL;
						if(PS_ask_occurrence_child( bvr,occsal[i], &ChildItem, &bvrchild ));
						if(AOM_ask_value_string(ChildItem, "item_id", &child_itemId1));
						//printf("\nOCC: Child Item Master ID is  :%s ",child_itemId);fflush(stdout);

						ITK__convert_tag_to_uid(occsal[i],&uidocc);
						//printf("\n uidocc... [%s]\n",uidocc);fflush(stdout);
						if(tc_strcmp(ChildUID,uidocc)==0)
						{
							if(tc_strcmp(child_itemId1,module_item_id)==0)
							{
								flagOcc ++;
								occTg = occsal[i];
								break;
							}
						}
						
					}
					printf("\n Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
										
					if(occTg != NULLTAG)
					{
						if(PS_occ_eff_ask_effs(bvr,occTg,&effcnt,&Effobbj));
						printf("\nOCC: Effectivity count is...%d",effcnt);fflush(stdout);
						//If No effectivity then create it
						if (effcnt == 0)
						{
							printf("\nOccurence Effectivity not found for %s;%s, uid[%s]. Going to create ......\n", chldid,chldrevid,ChildUID);fflush(stdout);
							int ij=0;
							int found =0;
							int seq = 0;						
							char EffecName[200];
							tag_t EffecTag = NULLTAG;
							if(occCnt > 0)
							{
								found =0;
								seq =0;
								for(;;)
								{
									char str1[20];
									sprintf(str1, "%d", seq+1);
									tc_strcpy(EffecName,"");
									tc_strcat(EffecName,chldid);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,chldrevid);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,arcPlatform);
									tc_strcat(EffecName,"_");
									tc_strcat(EffecName,str1);

									//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
									
									t5FindStrInSet(effIdLst2,effIdCnt2,EffecName,&found);
									//printf("\n EffecName [%s]....Found==>%d\n",EffecName,found);fflush(stdout);
									if(found==0)
									{
										
										break;
									}
									else
									{
										seq++;
									}
									
								}
								
								
								if(found ==0)
								{
									ifail = AOM_lock( bvr );
									
									if(PS_occ_eff_create(bvr,occTg,&EffecTag));
								
								
									if(EffecTag != NULLTAG)		
									{


										if(PS_occ_eff_set_id(bvr,occTg,EffecTag,EffecName));
										//ifail = PS_occ_eff_set_id(bvr,occTg,EffecTag,EffecName);
																			
										
										char EffecRange1[200];
										char* EffecEnd1 = NULL;
										char cCurrentAccessDate1[20]={0};
										
										t5GetCurrentDateTime(cCurrentAccessDate1);
										printf("\n111..flagBL==>%d\n",flagBL);fflush(stdout);
										if(flagBL==0)
										{
											EffecEnd1 = "31-Dec-2099";
										}
										else
										{
											EffecEnd1=subString(cCurrentAccessDate1,0,11);
										}									
										
										tc_strcpy(EffecRange1,"");

										tc_strcat(EffecRange1,"1-Jan-2005");
										tc_strcat(EffecRange1," to ");
										tc_strcat(EffecRange1,EffecEnd1);

										printf("\nOCC:111new effective range of the occurence %s;%s  id[%s]  is..:[%s]",module_item_id,chldrevid,ChildUID,EffecRange1);fflush(stdout);									

										//ifail = PS_occ_eff_set_date_range(bvr,occTg,EffecTag,"1-Jan-2005 to 31-Dec-2099",FALSE);
										if(PS_occ_eff_set_date_range(bvr,occTg,EffecTag,EffecRange1,FALSE));
										
										ifail = AOM_save_without_extensions(EffecTag);
										ifail = AOM_refresh(EffecTag, 0);
										t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName);
										
										ifail = AOM_save_without_extensions(bvr);
										ifail = AOM_refresh(bvr,1);
										ifail = AOM_unlock( bvr );

										ifail = AOM_refresh(childObjTag, 1);
										ifail = AOM_save_without_extensions(childObjTag);
										ifail = AOM_unlock( childObjTag );
										ifail = AOM_refresh(childObjTag, 0);

										ifail = AOM_refresh(primaryObj, 1);
										ifail = AOM_save_without_extensions(primaryObj);
										ifail = AOM_unlock( primaryObj );
										ifail = AOM_refresh(primaryObj, 0);										

										printf("\n Occurence Effectivity Created successfully for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);

									}
									else
									{
										printf("\n Occurence Effectivity NOT Created for part %s;%s, uid[%s]. Pls check with admin\n", chldid,chldrevid,ChildUID);fflush(stdout);
									}
									ifail = AOM_unlock( bvr );
									
								}
								
								
								
							}
							
						}
						else
						{
							int n_dates = 0;
							date_t*  start_end_values = NULL;
							int EFFECTIVITY_closed =0;
							char* Effecid = NULL;
							//char* Effecoccname = NULL;
							char* old_to_date = NULL;
							char* old_from_date = NULL;
							char cCurrentAccessDate[20]={0};
							//Occurence Effectivity already present.
							//Get date range of an occurrence effectivity as an array
							if(PS_occ_eff_ask_dates(bvr,occTg,Effobbj[0],&n_dates,&start_end_values,&EFFECTIVITY_closed));

							if(PS_occ_eff_ask_id(bvr,occTg,Effobbj[0],&Effecid));
							//printf("\nEffecid >>>>>>>>>>>>>> %s",Effecid);fflush(stdout);


							//ifail = PS_ask_occurrence_name(bvr,occTg,&Effecoccname);

							//printf("\n Effecoccname >>>>>>>>>>>>>> %s",Effecoccname);fflush(stdout);
							
							//printf("\n The size of the array of start-end values==> %d\n",n_dates);fflush(stdout);
							t5GetCurrentDateTime(cCurrentAccessDate);
							//printf("\nOCC:cCurrentAccessDate:[%s] ",cCurrentAccessDate);fflush(stdout);
							
							if(n_dates > 0)
							{
								date_t Ltest_date_1 = NULLDATE;
								logical date_is_valid = false;
								
								ifail = DATE_date_to_string(start_end_values[0],"%d-%b-%Y %H:%M", &old_from_date );
									
								ifail = DATE_date_to_string(start_end_values[1],"%d-%b-%Y %H:%M", &old_to_date );
									
								printf("\nold_from_date: [%s] , old_to_date[%s]\n",old_from_date,old_to_date);fflush(stdout);
								
								ifail = DATE_string_to_date_t(old_from_date, &date_is_valid,&Ltest_date_1 );
								
								if(date_is_valid != true)
								{
									printf("\n OCC:date_is_valid is not true .....");fflush(stdout);
								}
								else
								{
									
									char* EFF_OLD = NULL;
									char* EFF_CURRENT = NULL;
									
									
									EFF_OLD=subString(old_from_date,0,11);
									EFF_CURRENT=subString(cCurrentAccessDate,0,11);

									printf("\nOCC: new old andcurrent dates are:[%s %s] ",EFF_OLD,EFF_CURRENT);fflush(stdout);
									if ((tc_strcmp(EFF_OLD,EFF_CURRENT)==0))
									{
										printf("\n Cannot Create Multiple Occurance on same day of [%s;%s, uid[%s] \n",module_item_id,chldrevid,ChildUID ); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s2(EMH_severity_error,ITK_err, "Cannot Create Multiple Occurance on same day",module_item_id);
										return ITK_err;
									}
									
								}
								
							}
							else
							{
								printf("\nOCC: wrong dates... Check with admin\n");fflush(stdout);
							}
							
							//Set the end effective date of the occurence to today's date if no VF
							char* Effecsta = NULL;
							char* EffecEnd = NULL;
							
							Effecsta=subString(old_from_date,0,11);
							
							printf("\nflagBL==>%d\n",flagBL);fflush(stdout);
							if(flagBL==0)
							{
								EffecEnd = "31-Dec-2099";
							}
							else
							{
								EffecEnd=subString(cCurrentAccessDate,0,11);
							}
							
							char EffecRange[200];

							tc_strcpy(EffecRange,"");

							tc_strcat(EffecRange,Effecsta);
							tc_strcat(EffecRange," to ");
							tc_strcat(EffecRange,EffecEnd);

							printf("\nOCC:new effective range of the occurence %s;%s  id[%s]  is..:[%s]",module_item_id,chldrevid,ChildUID,EffecRange);fflush(stdout);

							ifail = AOM_lock( bvr );
							/*if(ifail = 43021)
							{
								printf("\nOCC: Error!!!!!!! The BOM View Revision cannot be modified. It is locked. \n");fflush(stdout);
								return ITK_err;
							*/
							ifail = AOM_lock( Effobbj[0] );



							if(PS_occ_eff_set_date_range(bvr,occTg,Effobbj[0],EffecRange,false));

							ifail = AOM_save_without_extensions(Effobbj[0]);
							ifail = AOM_refresh(Effobbj[0], 0);
							//if(AOM_unlock( Effobbj[0] ));


							ifail = AOM_save_without_extensions(bvr);
							ifail = AOM_refresh(bvr,1);
							ifail = AOM_unlock( bvr );

							ifail = AOM_refresh(childObjTag, 1);
							ifail = AOM_save_without_extensions(childObjTag);
							ifail = AOM_unlock( childObjTag );
							ifail = AOM_refresh(childObjTag, 0);

							ifail = AOM_refresh(primaryObj, 1);
							ifail = AOM_save_without_extensions(primaryObj);
							ifail = AOM_unlock( primaryObj );
							ifail = AOM_refresh(primaryObj, 0);							
							
							
							
						}							
						
					
					
					
					}
					

				}				
				
			}

			
			
		}//End of For Loop
				
		
	}
	else
	{
		printf("\n Skip this Architecture Node[%s] as the Module[%s;%s] is not applicable for this node.....\n",arch_modl_id,module_item_id,module_item_rev);fflush(stdout);
	}
	
	
	if(BOM_close_window(window));
	//Update the attributes.
	
	int k =0;
	//char transcpy[10000];
	char* transcpy = NULL;
	char *tempmat1=NULL;
	double mat[4][4];
	char *tempmat=NULL;
	
	tag_t window1 = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t line1 = NULLTAG;
	count =0;
	tag_t* child1 = NULL;
	int newIDCnt = 0;
	char** newIDList = NULL;
	int oldIDCnt = 0;
	char** oldIDList = NULL;
	int vfCnt = 0;
	char** vfList = NULL;	
	char* seq_no  = NULL;
	//int newSeqCnt = 0;
	//char** newSeqList = NULL;	
	
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
	if(BOM_create_window(&window1));
	if(CFM_find( "Latest Working", &rule1 ));
	if(BOM_set_window_config_rule(window1,rule1 ));
	if(BOM_set_window_pack_all(window1, false));
	if(BOM_set_window_top_line(window1, NULLTAG,primaryObj,NULLTAG, &line1));

	if(BOM_set_window_top_line_bvr(window1,bvr,&line1));
	if(BOM_line_ask_all_child_lines(line1,&count,&child1));
	printf("\nOCC: Child count 2222222>>>>>>>> %d\n",count);	
	
	
	for(k=0;k<SapUIDCnt;k++)
	{
		int l =0;
		
		if(USER_ask_new_default_sequence_number(bvr, moduleRevTag,&seq_no));
		for(l=0;l<count;l++)
		{
			flagBL = 100;
			//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
			if(AOM_ask_value_string(child1[l], "bl_occurrence_uid", &ChildUID));
			//printf("\nOCC:ChildUID ===============>%s \n",ChildUID);fflush(stdout);
			
			if(tc_strcmp(ChildUID,SapUIDList[k])==0)	
			{
				if(AOM_ask_value_string(child1[l], "bl_item_item_id", &chldid));
				if(AOM_ask_value_string(child1[l], "bl_rev_item_revision_id", &chldrevid));
				printf("\nOCC: 111..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
				
				//if the variant formula is blank then don't create any occurence. Only update the vflag as true.
				//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
				if(AOM_ask_value_string(child1[l],"bl_formula",&child_blFormula));
				if(child_blFormula==NULL)
				{
					flagBL = 0;
				}
				else 
				{
					if(strlen(child_blFormula)==0)
					{
						printf("\nOCC.111 No variant formula...\n");fflush(stdout);
						flagBL = 0;
					}
				}
				//flagBL = 100;//test
							
				if(flagBL !=0)
				{
					
					
					int found1 =0;
					int seq1 =0;
					char EffecName1[200];
					int imat =0;
					int jmat =0;
					for(;;)
					{
						char str2[20];
						sprintf(str2, "%d", seq1+1);
						tc_strcpy(EffecName1,"");
						tc_strcat(EffecName1,chldid);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,chldrevid);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,arcPlatform);
						tc_strcat(EffecName1,"_");
						tc_strcat(EffecName1,str2);


						//printf("\n XXXX: yyyyyy CM_MR_SetOccEff EffecName... [ %s ]\n",EffecName);fflush(stdout);
						
						t5FindStrInSet(effIdLst2,effIdCnt2,EffecName1,&found1);
						//printf("\n EffecName1 [%s]....Found==>%d\n",EffecName1,found1);fflush(stdout);
						if(found1==0)
						{
							
							break;
						}
						else
						{
							seq1++;
						}
						
					}//end of for
					transcpy = (char *) MEM_alloc(tc_strlen(TransMatList[k])*sizeof(char) + 100);
					tc_strcpy(transcpy,TransMatList[k]);
					
					printf("\nOCC: trans before stamp=======> :: %s\n",transcpy); fflush(stdout);
					
					tempmat1=tc_strtok(transcpy," ");
					
					
					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							if(imat==0 && jmat==0)
							{
								//printf("\n inside if"); fflush(stdout);
								mat[imat][jmat]=strtod(tempmat1,NULL);
							}else
							{
								//printf("\n inside else"); fflush(stdout);
								tempmat=tc_strtok(NULL," ");
								mat[imat][jmat]=strtod(tempmat,NULL);
							}
						}
					}


					for(imat=0;imat<4;imat++)
					{
						for(jmat=0;jmat<4;jmat++)
						{
							printf("%10lf,",mat[imat][jmat]);
						}
						printf("\n");
					}				

					ifail = AOM_lock( bvr );
					
					tag_t* occs = NULL;
					tag_t EffecTag1 = NULLTAG;
					char cCurrentAccessDate2[20]={0};
					char* Effecsta1 = NULL;
					char* EffecEnd1 = NULL;
					char EffecRange1[200];
					char* newoccId = NULL;

					if(PS_create_occurrences( bvr, moduleRevTag, NULLTAG,1, &occs ));
					if(occs[0] == NULLTAG)
					{
						printf("\n Occurence Creation Failed. Skip....\n");fflush(stdout);
						continue;
					}
					if(PS_set_plmxml_transform(bvr, occs[0], *mat));
					
					if(PS_occ_eff_create(bvr,occs[0],&EffecTag1));
					ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,EffecName1);
					
					if(ifail == 710079)
					{
						printf("\n Duplicate ID -Duplicate name : Effectivity info with name %s already exists\n",EffecName1);fflush(stdout);
						char newEffName[200];
						tc_strcpy(newEffName,EffecName1);
						tc_strcat(newEffName,"_1");
						ifail = PS_occ_eff_set_id(bvr,occs[0],EffecTag1,newEffName);
						
						t5AddStrToSet(&effIdCnt2, &effIdLst2,newEffName);
						t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName1);
						//continue;
					}
					//Set sequence no.													

					printf("\n UserInfo2 ==> Blank or invalid. No Packed logic applied to set find nos...\n");fflush(stdout);
					if(USER_ask_new_default_sequence_number(bvr, moduleRevTag,&seq_no));	
					if(PS_set_seq_no(bvr,occs[0],seq_no));
					
					
					//End Setting Seq no.
					//Set Quantity
					double qty = 0.00;
					ifail = PS_ask_occurrence_qty(bvr, occs[0],&qty);
					printf("\nThe quantity for the newly created occurence===> %lf\n",qty);fflush(stdout);
					if(qty > 0)
					{
						printf("\nAlready there is quantity. No need to set the quantity for the newly created occurence...\n");fflush(stdout);
					}
					else
					{
						ifail = PS_set_occurrence_qty(bvr, occs[0],1);
						printf("\nSetting the quantity for the newly created occurence...\n");fflush(stdout);
					}					
					
					//End Quantity					
					
					t5AddStrToSet(&effIdCnt2, &effIdLst2,EffecName1);
					
					
					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);
					
					t5GetCurrentDateTime(cCurrentAccessDate2);
					
					Effecsta1=subString(cCurrentAccessDate2,0,11);
					EffecEnd1 = "31-Dec-2099";
					

					tc_strcpy(EffecRange1,"");

					tc_strcat(EffecRange1,Effecsta1);
					tc_strcat(EffecRange1," to ");
					tc_strcat(EffecRange1,EffecEnd1);


					printf("\n Eff:ctest is range is ..:[%s]",EffecRange1);fflush(stdout);


					if(PS_occ_eff_set_date_range(bvr,occs[0],EffecTag1,EffecRange1,false));
					
					ifail = AOM_save_without_extensions(EffecTag1);
					ifail = AOM_refresh(EffecTag1, 0);

					ifail = AOM_save_without_extensions(bvr);
					ifail = AOM_refresh(bvr,1);
					ifail = AOM_unlock( bvr );

					ifail = AOM_refresh(childObjTag, 1);
					ifail = AOM_save_without_extensions(childObjTag);
					ifail = AOM_unlock( childObjTag );
					ifail = AOM_refresh(childObjTag, 0);

					ifail = AOM_refresh(primaryObj, 1);
					ifail = AOM_save_without_extensions(primaryObj);
					ifail = AOM_unlock( primaryObj );
					ifail = AOM_refresh(primaryObj, 0);
					
					if(transcpy) MEM_free(transcpy);
					
					ITK__convert_tag_to_uid(occs[0],&newoccId);
					printf("\n newoccId... [%s]\n",newoccId);fflush(stdout);
					t5AddStrToSet(&newIDCnt, &newIDList,newoccId);
					
					t5AddStrToSet(&oldIDCnt, &oldIDList,ChildUID);
					
					
				}
				else
				{
					//only update the VF flag.
					// setting Attribute False
					//int fndidlatest = 0;
					char* child_fndid_latest = NULL;
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest));
					if(AOM_ask_value_string(child1[l],"bl_occ_t5_upd_vf_form",&child_fndid_latest));
					//printf("\n child_fndid_latest===============>>>>>> %s\n",child_fndid_latest);
					if(tc_strcmp(child_fndid_latest,"False")==0)
					{
						
						//printf("\n child_fndid_latest value ==>>[%s] Value Update not needed\n",child_fndid_latest);fflush(stdout);
					}
					else
					{
						
						//printf("\n child_fndid_latest value ==>>[%s] Value Changing to False\n",child_fndid_latest);fflush(stdout);
						if(AOM_set_value_string(child1[l], "bl_occ_t5_upd_vf_form","False"));
					}					
				
					
				}
				
				
				

				
			}

			
			
		}
			
		

		
	}

	
	
	if(BOM_close_window(window1));
	
	printf("\nnewIDCnt==>%d, oldIDCnt ==> %d\n",newIDCnt,oldIDCnt);fflush(stdout);
	
	//Update the other attributes,
	count = 0;
	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
	if(BOM_create_window(&window1));
	if(CFM_find( "Latest Working", &rule1 ));
	if(BOM_set_window_config_rule(window1,rule1 ));
	if(BOM_set_window_pack_all(window1, false));
	if(BOM_set_window_top_line(window1, NULLTAG,primaryObj,NULLTAG, &line1));

	if(BOM_set_window_top_line_bvr(window1,bvr,&line1));
	if(BOM_line_ask_all_child_lines(line1,&count,&child1));
	printf("\nOCC: Child count 33333>>>>>>>> %d\n",count);		
	
	
	//int Uidlatest = 0;
	//int Uidkey = 0;
	char* child_Uidlatest = NULL;
	char* child_Uidkey = NULL;
	//int fndidlatest1 = 0;
	char* child_fndid_latest1 = NULL;
	int m = 0;
	int m1 = 0;
	//Case when new occurence created.
	if(newIDCnt > 0 && newIDCnt == oldIDCnt)
	{
		printf("\nOCC: Update the attributes of the newly created occurences \n");fflush(stdout);
		m = 0;
		m1 = 0;
		for(m1=0;m1<newIDCnt;m1++)
		{
			for(m=0;m<count;m++)
			{
				flagBL = 100;
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child1[m], "bl_occurrence_uid", &ChildUID));

				if(tc_strcmp(ChildUID,newIDList[m1])==0)
				{
					if(AOM_ask_value_string(child1[m], "bl_item_item_id", &chldid));
					if(AOM_ask_value_string(child1[m], "bl_rev_item_revision_id", &chldrevid));
					printf("\nOCC: 222..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsap",&child_Uidlatest));
					//printf("\n child_Uidlatest===============>>>>>> %s\n",child_Uidlatest);

					if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsap",ChildUID));
					
					char * tmpStr = NULL;
					tmpStr = (char*)MEM_alloc(200*sizeof(char));
					tc_strcpy(tmpStr,oldIDList[m1]);
					tc_strcat(tmpStr,"_");
					tc_strcat(tmpStr,ChildUID);
					printf("\n UID_SAP_Key: [%s] \n",tmpStr);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsapkey",&Uidkey));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsapkey",&child_Uidkey));
					printf("\n child_Uidkey===============>>>>>> %s\n",child_Uidkey);

					if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsapkey",tmpStr));
					
					MEM_free(tmpStr);
					
				
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
					//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
					if(tc_strcmp(child_fndid_latest1,"False")==0)
					{
						
						//printf("\n111 child_fndid_latest1 value ==>>[%s] Value Update not needed\n",child_fndid_latest1);fflush(stdout);
					}
					else
					{
						
						//printf("\n 111 child_fndid_latest1 value ==>>[%s] Value Changing to False\n",child_fndid_latest1);fflush(stdout);
						if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","False"));
					}								
					
					
				}
				
				//Update the VF flag to True for the line item which is effective out. so that it cannot be updated.
				if(tc_strcmp(ChildUID,oldIDList[m1])==0)
				{
					//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
					//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
					if(tc_strcmp(child_fndid_latest1,"False")==0)
					{
						printf("\n Updating effective out  child child_fndid_latest1 value ==>>[%s] Value Changing to True\n",child_fndid_latest1);fflush(stdout);
						if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","True"));						
					}							
					
				}

				
			}
			
		}		
		
		
		
	}
	
	//Case when no new occurence created and the modules attached to the VF DML is having blank VF.
	if(newIDCnt ==0 && SapUIDCnt >0)
	{
		printf("\nOCC: Update the attributes VF_Flag as False of the occurences if BL_flag is non zero \n");fflush(stdout);
		
		m = 0;
		m1 = 0;
		for(m1=0;m1<SapUIDCnt;m1++)
		{
			for(m=0;m<count;m++)
			{
				flagBL = 100;
				//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
				if(AOM_ask_value_string(child1[m], "bl_occurrence_uid", &ChildUID));

				if(tc_strcmp(ChildUID,SapUIDList[m1])==0)
				{
					if(AOM_ask_value_string(child1[m], "bl_item_item_id", &chldid));
					if(AOM_ask_value_string(child1[m], "bl_rev_item_revision_id", &chldrevid));
					//printf("\nOCC: 222..Got Occurence Tag for part %s;%s, uid[%s].\n", chldid,chldrevid,ChildUID);fflush(stdout);
					
					//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
					if(AOM_ask_value_string(child1[m],"bl_occ_t5_uidsap",&child_Uidlatest));
					//printf("\n child_Uidlatest===============>>>>>> %s\n",child_Uidlatest);
					
					if(tc_strcmp(child_Uidlatest,ChildUID) != 0)
					{
						if(AOM_set_value_string(child1[m], "bl_occ_t5_uidsap",ChildUID));
					}
					
									
					//if the variant formula is blank  update the vflag as true.
					//if(BOM_line_look_up_attribute("bl_formula",&blFormula));
					if(AOM_ask_value_string(child1[m],"bl_formula",&child_blFormula));
					if(child_blFormula==NULL)
					{
						flagBL = 0;
					}
					else 
					{
						if(strlen(child_blFormula)==0)
						{
							//printf("\nOCC.111 No variant formula...\n");fflush(stdout);
							flagBL = 0;
						}
					}
					if(flagBL == 0)
					{
						
						//if(BOM_line_look_up_attribute("bl_occ_t5_upd_vf_form",&fndidlatest1));
						if(AOM_ask_value_string(child1[m],"bl_occ_t5_upd_vf_form",&child_fndid_latest1));
						//printf("\n 111. child_fndid_latest===============>>>>>> %s\n",child_fndid_latest1);
						if(tc_strcmp(child_fndid_latest1,"False")==0)
						{
							
							//printf("\n111 child_fndid_latest1 value ==>>[%s] Value Update not needed\n",child_fndid_latest1);fflush(stdout);
						}
						else
						{
							
							//printf("\n 111 child_fndid_latest1 value ==>>[%s] Value Changing to False\n",child_fndid_latest1);fflush(stdout);
							if(AOM_set_value_string(child1[m], "bl_occ_t5_upd_vf_form","False"));
						}						
						
					}
								
					
					
				}			
			}
			
		}		
				
	
	}
	
	//if(BOM_save_window(window1));
	if(BOM_close_window(window1));
	
	if(ifail== ITK_ok)
	{
		printf("\nOccurence created and updated successfully....\n");fflush(stdout);
	}
	
	printf("\n********************End    -   Create_occurance_effectivity_newlogic  *************************************\n");fflush(stdout);
	
	return ITK_ok;
}



/**************************End New Logic **************************************/

/*CR-FY23-0144 - End*/

/****************** Color Change Option in VF DML Start****************************/
int isLiveForColorReview(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	//printf("\nUVF:: Check for control object VFColorREV....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "VFColorREV";
	qry_values[1] = "VFColorREV";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	//printf("\nUVFControl objects VFColorREV: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		//char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			char* cntrlStr = NULL;
			if(AOM_ask_value_string(cntrlObj,"object_string",&cntrlStr));
			printf("\nUVF: Control object ===>%s", cntrlStr);fflush(stdout);
			
			*result = TRUE;
			*contrlTag = cntrlObj;
			printf("\nUVF::isLiveForColorReview Live for Color Review parts through lifecycle\n");fflush(stdout);
			
		}
		
	}
	
	return ITK_ok;
}



int getOptionValueStr(tag_t ConfigCtx,char* child_bl_formula,char * optionStr, char** optionValueStr)
{

	printf( "\n\t**********In checkClrSchemeChange funtion now ***************");
	int ifail = ITK_ok;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   *Config_CtxType = NULL;
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;

	if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
	if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
	printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

	if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
	printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);fflush(stdout);

	if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
	printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);fflush(stdout);


	char *qry_entriesOptFam[] = {"ID"};
	char **qry_valuesOptFam = (char **) MEM_alloc(50 * sizeof(char *));
	tag_t Optfmly_tag = NULLTAG;
	tag_t queryTagOptFam = NULLTAG;
	tag_t *revOptFam=NULL;
	int resultCountOptFam=0,n_entriesOptFam=1,j=0;

	char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
	char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t OptfmlyVal_tag = NULLTAG;
	tag_t queryTagOptFamVal = NULLTAG;
	tag_t *revOptFamVal=NULL;
	int resultCountOptFamVal=0,n_entriesOptFamVal=2,i=0;
	char* OptValName=NULL;
	char* OptfmlyName=NULL;
	char* VariantFormulaStr=NULL;
	char* VariantFormulaStrOptionVal=NULL;
	VariantFormulaStr=(char *)MEM_alloc(300);
	VariantFormulaStrOptionVal=(char *)MEM_alloc(300);

	if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
	printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);
	if (queryTagOptFam)
	{
		printf("2.Found Query \n");fflush(stdout);
	}
	else
	{
		printf("Not Found Query");fflush(stdout);
	}
	 qry_valuesOptFam[0] = SmCrIDContext;
	if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
	printf(" \n resultCountOptFam : %d\n", resultCountOptFam); fflush(stdout);

	for (j=0;j<resultCountOptFam;j++ )
	{
		printf( "\n\t****************In option family loop now *************");

		int Flag_child_bl_Found=0;
		int Flag_other_bl_Found=0;
		Optfmly_tag = revOptFam[j];
		ifail = AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName);
		//printf("\n\t OptfmlyName Object String Type is :%s",OptfmlyName);	fflush(stdout);
		
		if(tc_strcmp(OptfmlyName,optionStr)!=0)
		{
			printf("\nSkip it... As optionStr[%s] and OptfmlyName[%s] not same\n",optionStr,OptfmlyName);fflush(stdout);
			continue;
		}
		tc_strcpy(VariantFormulaStr,"");
		if (tc_strstr(OptfmlyName," ")!=NULL)
		{
			tc_strcat(VariantFormulaStr,"'");
			tc_strcat(VariantFormulaStr,OptfmlyName);
			tc_strcat(VariantFormulaStr,"'");
		}
		else
		{
			tc_strcat(VariantFormulaStr,OptfmlyName);
		}
		tc_strcat(VariantFormulaStr," = ");
		printf("\n\t VariantFormulaStr is :<%s>",VariantFormulaStr);	fflush(stdout);



		if(QRY_find2("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTagOptFamVal));
		//printf("\n After IFERR_REPORT : QRY_find2 \n");fflush(stdout);
		if (queryTagOptFamVal)
		{
			//printf("Found Query __Cfg0OptionValuesFromOptionFamilyIDs \n");fflush(stdout);
		}
		else
		{
			//printf("Not Found Query __Cfg0OptionValuesFromOptionFamilyIDs ");fflush(stdout);
		}
		qry_valuesOptFamVal[0]= OptfmlyName;
		qry_valuesOptFamVal[1]= SmCrIDContext;
		if(QRY_execute(queryTagOptFamVal, n_entriesOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &resultCountOptFamVal, &revOptFamVal));
		for (i=0;i<resultCountOptFamVal;i++ )
		{
			printf("\n\t***************** In option value loop now *******************");

			OptfmlyVal_tag = revOptFamVal[i];
			ifail = AOM_ask_value_string(OptfmlyVal_tag,"object_name",&OptValName);
			printf("\n\t Value Object String  is :%s",OptValName);	fflush(stdout);
			
			tc_strcpy(VariantFormulaStrOptionVal,"");
			tc_strcat(VariantFormulaStrOptionVal,VariantFormulaStr);

			if (tc_strstr(OptValName," ")!=NULL)
			{
				tc_strcat(VariantFormulaStrOptionVal,"'");
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
				tc_strcat(VariantFormulaStrOptionVal,"'");
			}
			else
			{
				tc_strcat(VariantFormulaStrOptionVal,OptValName);
			}

			printf("\n\t Final VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
			
			if (tc_strstr(child_bl_formula,VariantFormulaStrOptionVal)!=NULL)
			{
				printf("\n\t child_bl_formula =[%s] &&  VariantFormulaStrOptionVal = [%s] \n",child_bl_formula,VariantFormulaStrOptionVal);

				printf("\n\t Matched for VariantFormulaStr is :<%s> \n",VariantFormulaStrOptionVal);	fflush(stdout);
				*optionValueStr = VariantFormulaStrOptionVal;
				return ITK_ok;
				
			}
			else
			{

			}


		}/// end of option value loop
		

	}/// end of option family loop
	
	return ITK_ok;
}


int checkClrVF(tag_t ConfigCtx, char* child_bl_formula_prev, char* child_bl_formula_curr, logical* flag)
{
	int ifail = ITK_ok;
	
	char* optionValuePrevStr = NULL;
	char* optionValueCurrStr = NULL;
	
	char* optValSchemeNoCurrStr = NULL;
	char* optValSchemeNoPrevStr = NULL;
	
	
	
	
	
	printf("\nchild_bl_formula_prev[%s]\nchild_bl_formula_curr[%s]\n",child_bl_formula_prev,child_bl_formula_curr); fflush(stdout);
	
	if(child_bl_formula_prev != NULL || child_bl_formula_curr != NULL)
	{
		
		if(tc_strlen(child_bl_formula_prev)> 0)
		{
			ifail = getOptionValueStr(ConfigCtx,child_bl_formula_prev,"COLOUR-BOM", &optionValuePrevStr);
			ifail = getOptionValueStr(ConfigCtx,child_bl_formula_prev,"SCHEME-NO", &optValSchemeNoPrevStr);

			if(tc_strlen(child_bl_formula_curr) > 0)
			{
							
				ifail = getOptionValueStr(ConfigCtx,child_bl_formula_curr,"COLOUR-BOM", &optionValueCurrStr);
				ifail = getOptionValueStr(ConfigCtx,child_bl_formula_curr,"SCHEME-NO", &optValSchemeNoCurrStr);	

				
				printf("\n For Prev line item COLOR-BOM Value is==============> %s\n",optionValuePrevStr);
				printf("\n For Current line item COLOR-BOM Value is==============> %s\n",optionValueCurrStr);

				printf("\n For Prev line item SCHEME-NO Value is==============> %s\n",optValSchemeNoPrevStr);
				printf("\n For Current line item SCHEME-NO Value is==============> %s\n",optValSchemeNoCurrStr);	
					
				
				
				//if(tc_strcmp(optionValuePrevStr,optionValueCurrStr)!=0 || tc_strcmp(optValSchemeNoPrevStr,optValSchemeNoCurrStr)!=0 )
				if((tc_strlen(optionValuePrevStr) <=0 ||  tc_strlen(optValSchemeNoPrevStr) <=0 ) && (tc_strlen(optionValueCurrStr) > 0 ||  tc_strlen(optionValueCurrStr) > 0))
				{
					*flag = true;
					printf("\nSAN:Color related options added");fflush(stdout);
					return ITK_ok;
				}
				
			}
			else
			{
				printf("\n child_bl_formula_curr is blank");fflush(stdout);
			}
			
		}
		else
		{
			printf("\n child_bl_formula_prev is blank");fflush(stdout);
		}
				
		
	}
	else
	{
		printf("\nEither prev or curr line items has null VF.Exiting...\n");fflush(stdout);
	}

	
	
	return ITK_ok;
}


int tmCheckColorChange(tag_t ArcModRevTag,tag_t moduleObject,tag_t ConfigCtx, char* objectId, char* objectrevId, char* child_bl_formula_prev, char* occ_effec_prev,char* occUidOnRel, char* occuid ,logical* allowed)
{
	int ifail = ITK_ok;
	
	printf("\nCreOCC: Inside ----tmCheckColorChange ...to implement the logic........\n");
	
	printf("\noccUidOnRel: [%s]  occuid: [%s]",occUidOnRel,occuid);fflush(stdout);
	
	
	int bvr_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	ifail = ITEM_rev_list_bom_view_revs(ArcModRevTag,&bvr_count, &bvrs);

	printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
	if (bvr_count)
	{
		bvr = bvrs[0];
	}
	else
	{
		return ITK_ok;
	}
	
	int n_occs = 0;
	tag_t* occsal = NULL;
	ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
	
	printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
	
	
	
	//Get the item_id of the Arch Module
	char* archId = NULL;
	
	ifail = AOM_ask_value_string(ArcModRevTag,"item_id",&archId);
	
	printf("\nSAN:tmCheckColorChange: Checking for ArchID[%s], Child Module[%s;%s], old occ id:[%s] \nVariant formula prev[%s]\n Occ Effectivity prev : [%s]",archId,objectId,objectrevId,occuid,child_bl_formula_prev,occ_effec_prev);fflush(stdout);
	
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t* chldTagLst = NULL;
	int chldCnt = 0;


	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window (&window));
	if(CFM_find( "Latest Working", &rule ));
	
	
	if(BOM_set_window_config_rule( window, rule ));
	if(BOM_set_window_pack_all (window, false));
	if(BOM_set_window_top_line (window, NULLTAG,ArcModRevTag, NULLTAG, &top_line));
	if(BOM_set_window_top_line_bvr(window,bvr,&top_line));

	//if(BOM_line_ask_all_child_lines(top_line,&count,&child));
	//printf("\n count::::::::>>>>>>>> %d\n",count);		
	
	if(top_line != NULLTAG)
	{
		tag_t* child_lines = NULL;
		int nChld = 0;
		int ij=0;
		//int childId = 0;
		//int childRevSeq = 0;
		char* child_id = NULL;
		char* child_rev_seq = NULL;			
		
		
		if(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
		//CALLAPI(BOM_line_ask_all_child_lines (top_line, &nChld, &child_lines));
		
		printf("\nNo of child objects of  Arc Mod Rev are : %d",nChld);fflush(stdout);
		//if(BOM_line_look_up_attribute("bl_item_item_id",&childId));
		//if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
		
		for(ij=0;ij<nChld;ij++)
		{
			if(AOM_ask_value_string(child_lines[ij],"bl_item_item_id",&child_id));
			if(AOM_ask_value_string(child_lines[ij],"bl_rev_item_revision_id",&child_rev_seq));

			printf("\n %d ==> child_id [%s;%s]",ij+1,child_id,child_rev_seq);fflush(stdout);
			
			if(tc_strcmp(child_id,objectId)==0 && tc_strcmp(child_rev_seq,objectrevId)==0)
			{
				//add to the set to compare the VF change.
				t5AddTagObjToSet(&chldCnt,&chldTagLst,child_lines[ij]);
			}

			
		}

		
	}
	
	printf("\nChild Line Tag count to compare for change in Color VF===> %d",chldCnt);fflush(stdout);
	
	if(chldCnt > 0)
	{
		int i=0;
		//int occEffec = 0;
		char* occ_effec_curr = NULL;
		char* child_bl_formula_curr = NULL;
		//if(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
		for(i=0;i<chldCnt;i++)
		{
			
			if(AOM_ask_value_string(chldTagLst[i],"bl_occ_effectivity",&occ_effec_curr));
			if(AOM_ask_value_string(chldTagLst[i], "bl_formula", &child_bl_formula_curr));
			printf("\nocc_effec_curr[%s]\t child_bl_formula_curr[%s]\n",occ_effec_curr,child_bl_formula_curr); fflush(stdout);
			
			ifail = checkClrVF(ConfigCtx,child_bl_formula_prev,child_bl_formula_curr,allowed);
			

			
		}
	}
	
	
	ifail = BOM_close_window(window);	
	
	
	
	return ITK_ok;
}


int checkClrVFNew(tag_t ConfigCtx, char* child_bl_formula_prev, char* child_bl_formula_curr, logical* flag)
{
	int ifail = ITK_ok;
	
	char* optionValuePrevStr = NULL;
	char* optionValueCurrStr = NULL;
	
	char* optValSchemeNoCurrStr = NULL;
	char* optValSchemeNoPrevStr = NULL;
	
	
	
	
	
	printf("\ncheckClrVFNew: child_bl_formula_prev[%s]\nchild_bl_formula_curr[%s]\n",child_bl_formula_prev,child_bl_formula_curr); fflush(stdout);
	
	if(child_bl_formula_prev != NULL || child_bl_formula_curr != NULL)
	{
		
		if(tc_strlen(child_bl_formula_prev)> 0)
		{
			ifail = getOptionValueStr(ConfigCtx,child_bl_formula_prev,"COLOUR-BOM", &optionValuePrevStr);
			ifail = getOptionValueStr(ConfigCtx,child_bl_formula_prev,"SCHEME-NO", &optValSchemeNoPrevStr);

			if(tc_strlen(child_bl_formula_curr) > 0)
			{
							
				ifail = getOptionValueStr(ConfigCtx,child_bl_formula_curr,"COLOUR-BOM", &optionValueCurrStr);
				ifail = getOptionValueStr(ConfigCtx,child_bl_formula_curr,"SCHEME-NO", &optValSchemeNoCurrStr);	

				
				printf("\n For Prev line item COLOR-BOM Value is==============> %s\n",optionValuePrevStr);
				printf("\n For Current line item COLOR-BOM Value is==============> %s\n",optionValueCurrStr);

				printf("\n For Prev line item SCHEME-NO Value is==============> %s\n",optValSchemeNoPrevStr);
				printf("\n For Current line item SCHEME-NO Value is==============> %s\n",optValSchemeNoCurrStr);	
					
				
				
				if(tc_strcmp(optionValuePrevStr,optionValueCurrStr)!=0 || tc_strcmp(optValSchemeNoPrevStr,optValSchemeNoCurrStr)!=0 )
				{
					*flag = true;
					printf("\nSAN:checkClrVFNew: Color related options changed");fflush(stdout);
					return ITK_ok;
				}
				
			}
			else
			{
				printf("\n child_bl_formula_curr is blank");fflush(stdout);
			}
			
		}
		else
		{
			printf("\n child_bl_formula_prev is blank");fflush(stdout);
		}
				
		
	}
	else
	{
		printf("\nEither prev or curr line items has null VF.Exiting...\n");fflush(stdout);
	}

	
	
	return ITK_ok;
}


int tmCheckColorChangeNew(tag_t ArcModRevTag,tag_t moduleObject,tag_t ConfigCtx, char* objectId, char* objectrevId, char* child_bl_formula_prev, char* occ_effec_prev,char* occUidOnRel, char* occuid ,logical* allowed)
{
	int ifail = ITK_ok;
	
	printf("\nCreOCC: Inside ----tmCheckColorChangeNew ...........\n");
	
	printf("\noccUidOnRel: [%s]  occuid: [%s]",occUidOnRel,occuid);fflush(stdout);
	
	
	int bvr_count = 0;
	tag_t* bvrs = NULL;
	tag_t bvr = NULLTAG;
	ifail = ITEM_rev_list_bom_view_revs(ArcModRevTag,&bvr_count, &bvrs);

	printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
	if (bvr_count)
	{
		bvr = bvrs[0];
	}
	else
	{
		return ITK_ok;
	}
	
	int n_occs = 0;
	tag_t* occsal = NULL;
	ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
	
	printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
	
	
	
	//Get the item_id of the Arch Module
	char* archId = NULL;
	
	ifail = AOM_ask_value_string(ArcModRevTag,"item_id",&archId);
	
	printf("\nSAN:tmCheckColorChange: Checking for ArchID[%s], Child Module[%s;%s], old occ id:[%s] \nVariant formula prev[%s]\n Occ Effectivity prev : [%s]",archId,objectId,objectrevId,occuid,child_bl_formula_prev,occ_effec_prev);fflush(stdout);
	
	tag_t window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t* chldTagLst = NULL;
	int chldCnt = 0;


	if(PREF_set_logical_value("PSEShowUnconfigdEffPref",false));
	if(BOM_create_window (&window));
	if(CFM_find( "Latest Working", &rule ));
	
	
	if(BOM_set_window_config_rule( window, rule ));
	if(BOM_set_window_pack_all (window, false));
	if(BOM_set_window_top_line (window, NULLTAG,ArcModRevTag, NULLTAG, &top_line));
	if(BOM_set_window_top_line_bvr(window,bvr,&top_line));

	//if(BOM_line_ask_all_child_lines(top_line,&count,&child));
	//printf("\n count::::::::>>>>>>>> %d\n",count);		
	
	if(top_line != NULLTAG)
	{
		tag_t* child_lines = NULL;
		int nChld = 0;
		int ij=0;
		//int childId = 0;
		//int childRevSeq = 0;
		char* child_id = NULL;
		char* child_rev_seq = NULL;			
		
		
		if(BOM_line_ask_child_lines (top_line, &nChld, &child_lines));
		//CALLAPI(BOM_line_ask_all_child_lines (top_line, &nChld, &child_lines));
		
		printf("\nNo of child objects of  Arc Mod Rev are : %d",nChld);fflush(stdout);
		//if(BOM_line_look_up_attribute("bl_item_item_id",&childId));
		//if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq));
		
		for(ij=0;ij<nChld;ij++)
		{
			if(AOM_ask_value_string(child_lines[ij],"bl_item_item_id",&child_id));
			if(AOM_ask_value_string(child_lines[ij],"bl_rev_item_revision_id",&child_rev_seq));

			printf("\n %d ==> child_id [%s;%s]",ij+1,child_id,child_rev_seq);fflush(stdout);
			
			if(tc_strcmp(child_id,objectId)==0 && tc_strcmp(child_rev_seq,objectrevId)==0)
			{
				//add to the set to compare the VF change.
				t5AddTagObjToSet(&chldCnt,&chldTagLst,child_lines[ij]);
			}

			
		}

		
	}
	
	printf("\nChild Line Tag count to compare for change in Color VF===> %d",chldCnt);fflush(stdout);
	
	if(chldCnt > 0)
	{
		int i=0;
		//int occEffec = 0;
		char* occ_effec_curr = NULL;
		char* child_bl_formula_curr = NULL;
		//if(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
		for(i=0;i<chldCnt;i++)
		{
			
			if(AOM_ask_value_string(chldTagLst[i],"bl_occ_effectivity",&occ_effec_curr));
			if(AOM_ask_value_string(chldTagLst[i], "bl_formula", &child_bl_formula_curr));
			printf("\nocc_effec_curr[%s]\t child_bl_formula_curr[%s]\n",occ_effec_curr,child_bl_formula_curr); fflush(stdout);
			
			ifail = checkClrVFNew(ConfigCtx,child_bl_formula_prev,child_bl_formula_curr,allowed);
			

			
		}
	}
	
	
	
	
	ifail = BOM_close_window(window);	
	
	
	
	return ITK_ok;
}


int  tm_UVFIsColorOptionsModifiedFun(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	const char * prog_name ="tm_UVFIsColorOptionsModifiedFun";
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	int appl = 0;
	
	//Certification_Review_Check
	ifail =isLiveForColorReview(&cntrlObj,&liveFlag);
	printf("\nUVF::tm_UVFIsColorOptionsModifiedFun.. Live for Color Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nUVF:: NOT Live for Color Review- Check for control object VFColorREV");fflush(stdout);
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
		return ITK_ok;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		tag_t rootTask = NULLTAG;
		int targetobjects_count = 0;
		tag_t* targetobjects = NULL;
		ifail = EPM_ask_root_task(msg.task,&rootTask);
		printf("\nUVF:: Root task found");fflush(stdout);
		
		ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects);
		
		if(targetobjects_count > 0)
		{
			int i=0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;
			
			
			
			
			for(i=0;i<targetobjects_count;i++)
			{
				ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
				if(objectTypeTag != NULLTAG) {
					ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
				}
				printf("\nUVF: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					char* dmlReleaseType = NULL;
					char* dmlRelTypeDisplayStr = NULL;
					char** moduleList = NULL;
					int moduleCnt = 0;
					
					ifail = AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType);
					ifail = AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr);
					
					printf("\nUVF DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					
					if(tc_strcmp(dmlReleaseType,"UVF")==0)
					{
						//Get the DML Task
						tag_t *dmlTaskTagObjects = NULL;
						tag_t dmlTaskTag = NULLTAG;
						int taskCnt = 0;
						
						//Set the BOM expansion preference to true
						logical prefOrig = false;
						logical pref = false;
						char* userInfo1 = NULL;
						ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
						
						if(userInfo1 == NULL) userInfo1 = "";
						printf("\n USER INFO1 ====================> %s\n",userInfo1);fflush(stdout);
						
						ifail = PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&prefOrig);
						printf("\n Before: PSEShowUnconfigdEffPref====================> %d\n",prefOrig);fflush(stdout);
						
						ifail = PREF_set_logical_value("PSEShowUnconfigdEffPref",true);
						ifail = PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref);
						printf("\n After: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);

						
						ifail = AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects);
						printf("\nUVF DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
						
						if(taskCnt>0)
						{
							int jt = 0;
							char* object_type	=	NULL;
							for(jt=0;jt<taskCnt;jt++)
							{
								dmlTaskTag = dmlTaskTagObjects[jt];
								ifail = AOM_ask_value_string(dmlTaskTag,"object_type",&object_type);
								printf("\nUVF DML Task object_type is :%s\n",object_type);fflush(stdout);
								
								if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
								{
									
									tag_t DmlItemsRelation = NULLTAG;
									int count = 0;
									tag_t* moduleObjects = NULL;
									//Get the attached modules.
									
									if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
									if(DmlItemsRelation != NULLTAG)
									{
										if(GRM_list_secondary_objects_only(dmlTaskTag,DmlItemsRelation,&count,&moduleObjects));
										printf("\n Module count is : %d",count);
										if(count >0)
										{
											int j=0;
											char* objecttype = NULL;
											char* objectId = NULL;
											char* objectrevId = NULL;
											char* objectdesc = NULL;
											char* objectrelstatus = NULL;
											char* objectDRstatus = NULL;
											char* Part_type = NULL;
											
											tag_t probj = NULLTAG;
											tag_t primaryobjtype = NULLTAG;
											char  *primaryobj_name = NULL;
											char   *OccUIDattr				= NULL;
											
											
											for(j=0;j<count;j++)
											{
												printf("\n************************* %d SAN:Start********************************\n",j+1);fflush(stdout);
												logical allowed = FALSE;
												ifail = AOM_ask_value_string(moduleObjects[j],"object_type",&objecttype);
												ifail = AOM_ask_value_string(moduleObjects[j],"item_id",&objectId);
												ifail = AOM_ask_value_string(moduleObjects[j],"item_revision_id",&objectrevId);
												ifail = AOM_ask_value_string(moduleObjects[j],"object_desc",&objectdesc);
												ifail = AOM_UIF_ask_value(moduleObjects[j],"release_status_list",&objectrelstatus);
												ifail = AOM_ask_value_string(moduleObjects[j],"t5_PartStatus",&objectDRstatus);
												ifail = AOM_ask_value_string(moduleObjects[j],"t5_PartType",&Part_type);

												printf("\nmoduleObjects Part_type  is :%s\n",Part_type);	fflush(stdout);
												printf("moduleObjects objecttype = [%s]\n",objecttype);fflush(stdout);
												printf("moduleObjects objectId = [%s]\n",objectId);fflush(stdout);
												printf("moduleObjects objectrevId = [%s]\n",objectrevId);fflush(stdout);
												printf("moduleObjects objectdesc = [%s]\n",objectdesc);fflush(stdout);
												printf("moduleObjects objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
												printf("moduleObjects objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
												
												//Get Occurence ID on Part
												
												if(GRM_find_relation(dmlTaskTag,moduleObjects[j],DmlItemsRelation,&probj));
												if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
												if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
												printf("\nSAN:ColorVF: primaryobj_name-------->  :%s\n", primaryobj_name);fflush(stdout);
												if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
												{
													printf("\nSAN:ColorVF: Inside getting BOMUID Attr \n"); fflush(stdout);
													ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
													printf("\n SAN:ColorVF: OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
												
												}
												
												
												if(tc_strcmp(Part_type,"M")==0)
												{
													int n_parents			= 0;
													int *levels				= 0;
													tag_t* parents = NULL;
													int jd = 0;
													tag_t ArchAssyTag = NULLTAG;
													char* ChildUID = NULL;
													int flagArc = 0;
													char* child_bl_formula = NULL;
													char* occ_effec_old = NULL;
													//int occEffec = 0;
													tag_t ConfigCtx = NULLTAG;
													ifail = PS_where_used_all(moduleObjects[j],1,&n_parents,&levels,&parents);
													printf("\nSAN:ColorVF: where_used count of objects are : %d",n_parents); fflush(stdout);
													
													for (jd=0;jd<n_parents;jd++ )
													{
														ArchAssyTag = NULLTAG;
														char* Arch_obj = NULL;
														tag_t  ArchobjTypeTag	= NULLTAG;
														char   *Archtype_name = NULL;
														
														
														ArchAssyTag=parents[jd];
														
														ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj);//PrintErrorStack();
														//printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

														ifail = TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag);//PrintErrorStack();
														ifail = TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name);//PrintErrorStack();
														printf("\nSAN:ColorVF: Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout);
														
														if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
														{
															tag_t master = NULLTAG;
															char* Arch_obj_str = NULL;
															tag_t relation_dep=	NULLTAG;
															int countConfigCtx = 0;
															tag_t  *ConfigCtxSecObject	= NULLTAG;
															//flagArc = 0;
															
															//printf("\n to do....\n");fflush(stdout);
															printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);fflush(stdout);
															
															ifail = ITEM_ask_item_of_rev(ArchAssyTag, &master);
															ifail = AOM_ask_value_string(master,"item_id",&Arch_obj_str);//PrintErrorStack();
															printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

															ifail = GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep);//PrintErrorStack();
															if(relation_dep != NULLTAG)
															{
																printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
																ifail = GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject);//PrintErrorStack();
															}

															
															printf("\n\t Configuration Context count is : %d",countConfigCtx);
															//test sanjoy
															//countConfigCtx = 1;
															if(countConfigCtx > 0)
															{
																ConfigCtx = NULLTAG;
																//ConfigCtx=ConfigCtxSecObject[0];
																tag_t window = NULLTAG;
																tag_t rule = NULLTAG;
																tag_t top_line = NULLTAG;
																
																int n_occs = 0;
																tag_t* occsal = NULL;
																
																int bvr_count = 0;
																tag_t* bvrs = NULL;
																tag_t bvr = NULLTAG;
																ifail = ITEM_rev_list_bom_view_revs(ArchAssyTag,&bvr_count, &bvrs);

																printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
																if (bvr_count)
																{
																	bvr = bvrs[0];
																}
																else
																{
																	return ifail;
																}
																													
																ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
																
																printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
																

																//PSEShowUnconfigdEffPref
																ConfigCtx=ConfigCtxSecObject[0];
																if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
																if(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
																printf("\n After1111: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);													
																if(BOM_create_window (&window)!=ITK_ok);
																if(CFM_find( "Latest Working", &rule )!=ITK_ok);
																if(BOM_set_window_config_rule( window, rule )!=ITK_ok);
																if(BOM_set_window_pack_all (window, false)!=ITK_ok);
																if(BOM_set_window_top_line (window, NULLTAG,ArchAssyTag, NULLTAG, &top_line)!=ITK_ok);
																
																if(top_line != NULLTAG)
																{
																	int n_BL = 0;
																	int p = 0;
																	tag_t* children = NULL;
																	//CALLAPI(BOM_line_ask_child_lines(top_line, &n_BL, &children))
																	if(BOM_line_ask_all_child_lines (top_line, &n_BL, &children));
																	//CALLAPI(BOM_line_subset_child_lines_occs(top_line,n_occs,occsal,&n_BL, &children));
																	printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
																	
																	for (p=0;p<n_BL ;p++ )
																	{
																		tag_t Childobject = NULLTAG;
																		char* child_item_id = NULL;
																		child_bl_formula = NULL;
																		//int uidType = 0;
																		ChildUID = NULL;
																		occ_effec_old = NULL;

																		Childobject=children[p];
																		
																		//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
																		if(AOM_ask_value_string(Childobject, "bl_occurrence_uid", &ChildUID));
																		printf("\n SAN:ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);

																		if((tc_strstr(OccUIDattr,ChildUID)!=NULL))
																		{
																			if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
																			printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

																			if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
																			printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);												
																			//printf("\n uid not equal %s\t-  %s",ChildUID,OccUIDattr);fflush(stdout);
																			//if(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
																			if(AOM_ask_value_string(Childobject,"bl_occ_effectivity",&occ_effec_old));																	
																			flagArc++;
																			break;
																			
																		}
																		

																		

																		
																	
																		
																	}
																	
																	
																	
																}
																
																ifail = BOM_close_window(window);
																
															}

															
															
														}
														
														printf("\n flagArc=============> %d\n",flagArc);fflush(stdout);
														if(flagArc >0)
														{
															break;
														}
														
														
													}
													
													//To write function to check the logic.
													printf("\n flagArc1111=============> %d\n",flagArc);fflush(stdout);
													if(flagArc >0)
													{
														allowed = FALSE;
														if(tc_strcmp(userInfo1,"LOGIC1")==0)
														{
															tmCheckColorChangeNew(ArchAssyTag,moduleObjects[j],ConfigCtx, objectId,objectrevId,child_bl_formula,occ_effec_old,OccUIDattr,ChildUID, &allowed);

														}
														else
														{
															tmCheckColorChange(ArchAssyTag,moduleObjects[j],ConfigCtx, objectId,objectrevId,child_bl_formula,occ_effec_old,OccUIDattr,ChildUID, &allowed);

														}
														
														
														if(allowed)
														{
															t5AddStrToSet(&moduleCnt, &moduleList,objectId);
															
														}													
													}
													
														
													
												}

												printf("\n************************* %d SAN:End********************************\n",j+1);fflush(stdout);
																			
											}
										}
									}
														
									
								}
								
							}
						}
					
						if(PREF_set_logical_value("PSEShowUnconfigdEffPref",prefOrig));
						if(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
						printf("\n Revert to original state: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);
					}
					
					printf("\nmoduleCnt=========> %d\n",moduleCnt);fflush(stdout);
					if(moduleCnt > 0)
					{
						printf("\n Go to Color Team Review\n");fflush(stdout);
						appl++;
						ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
						break;
						
					}
					else
					{
						printf("\n Go to Normal workflow\n");fflush(stdout);
						ifail = ITK_ok;
						
					}
				
				}
				
			}
		}
		
	}

	if(appl >0)
	{
		printf("\n Go to Color Team Review\n");fflush(stdout);
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
		return ITK_ok;
	}
	else
	{
		printf("\n Go to Normal workflow\n");fflush(stdout);
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
		return ITK_ok;
	}
		
	
	//return ifail;
	
}



int  tm_IsColorOptionsUpdInVFFn(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	const char * prog_name ="tm_IsColorOptionsUpdInVFFn";
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	
	ifail =isLiveForColorReview(&cntrlObj,&liveFlag);
	printf("\nUVF::tm_IsColorOptionsUpdInVFFn.. Live for Color Review for valid DML type==>%d\n",liveFlag);fflush(stdout);	
	if(!liveFlag)
	{
		printf("\nUVF:: NOT Live for Color Review- Check for control object VFColorREV");fflush(stdout);
		return ITK_ok;
	}
	
	if(cntrlObj != NULLTAG && liveFlag)
	{
		tag_t rootTask = NULLTAG;
		int targetobjects_count = 0;
		tag_t* targetobjects = NULL;
		ifail = EPM_ask_root_task(msg.task,&rootTask);
		printf("\nUVF:: Root task found");fflush(stdout);
		
		ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects);
		
		if(targetobjects_count > 0)
		{
			int i=0;
			tag_t objectTypeTag = NULLTAG;
			char *type_name = NULL;			
			
			for(i=0;i<targetobjects_count;i++)
			{
				ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
				if(objectTypeTag != NULLTAG) {
					ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
				}
				printf("\nUVF: type_name ==> %s\n", type_name);fflush(stdout);
				
				if (tc_strcmp(type_name,"ChangeRequestRevision")==0)
				{
					tag_t dmlTag = NULLTAG;
					dmlTag = targetobjects[i];
					char* dmlReleaseType = NULL;
					char* dmlRelTypeDisplayStr = NULL;
					char** moduleList = NULL;
					int moduleCnt = 0;
					
					ifail = AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType);
					ifail = AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr);
					
					printf("\nUVF DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					
					if(tc_strcmp(dmlReleaseType,"UVF")==0)
					{
						//Get the DML Task
						tag_t *dmlTaskTagObjects = NULL;
						tag_t dmlTaskTag = NULLTAG;
						int taskCnt = 0;
						
						//Set the BOM expansion preference to true
						logical prefOrig = false;
						logical pref = false;
						char* userInfo1 = NULL;
						ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
						
						if(userInfo1 == NULL) userInfo1 = "";
						printf("\n USER INFO1 ====================> %s\n",userInfo1);fflush(stdout);
						
						ifail = PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&prefOrig);
						printf("\n Before: PSEShowUnconfigdEffPref====================> %d\n",prefOrig);fflush(stdout);
						
						ifail = PREF_set_logical_value("PSEShowUnconfigdEffPref",true);
						ifail = PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref);
						printf("\n After: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);

						
						ifail = AOM_ask_value_tags(dmlTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects);
						printf("\nUVF DML ERC Task Count:%d\n",taskCnt);fflush(stdout);
						
						if(taskCnt>0)
						{
							int jt = 0;
							char* object_type	=	NULL;
							for(jt=0;jt<taskCnt;jt++)
							{
								dmlTaskTag = dmlTaskTagObjects[jt];
								ifail = AOM_ask_value_string(dmlTaskTag,"object_type",&object_type);
								printf("\nUVF DML Task object_type is :%s\n",object_type);fflush(stdout);
								
								if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
								{
									
									tag_t DmlItemsRelation = NULLTAG;
									int count = 0;
									tag_t* moduleObjects = NULL;
									//Get the attached modules.
									
									if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
									if(DmlItemsRelation != NULLTAG)
									{
										if(GRM_list_secondary_objects_only(dmlTaskTag,DmlItemsRelation,&count,&moduleObjects));
										printf("\n Module count is : %d",count);
										if(count >0)
										{
											int j=0;
											char* objecttype = NULL;
											char* objectId = NULL;
											char* objectrevId = NULL;
											char* objectdesc = NULL;
											char* objectrelstatus = NULL;
											char* objectDRstatus = NULL;
											char* Part_type = NULL;
											
											tag_t probj = NULLTAG;
											tag_t primaryobjtype = NULLTAG;
											char  *primaryobj_name = NULL;
											char   *OccUIDattr				= NULL;
											
											
											for(j=0;j<count;j++)
											{
												printf("\n************************* %d SAN:Start********************************\n",j+1);fflush(stdout);
												logical allowed = FALSE;
												ifail = AOM_ask_value_string(moduleObjects[j],"object_type",&objecttype);
												ifail = AOM_ask_value_string(moduleObjects[j],"item_id",&objectId);
												ifail = AOM_ask_value_string(moduleObjects[j],"item_revision_id",&objectrevId);
												ifail = AOM_ask_value_string(moduleObjects[j],"object_desc",&objectdesc);
												ifail = AOM_UIF_ask_value(moduleObjects[j],"release_status_list",&objectrelstatus);
												ifail = AOM_ask_value_string(moduleObjects[j],"t5_PartStatus",&objectDRstatus);
												ifail = AOM_ask_value_string(moduleObjects[j],"t5_PartType",&Part_type);

												printf("\nmoduleObjects Part_type  is :%s\n",Part_type);	fflush(stdout);
												printf("moduleObjects objecttype = [%s]\n",objecttype);fflush(stdout);
												printf("moduleObjects objectId = [%s]\n",objectId);fflush(stdout);
												printf("moduleObjects objectrevId = [%s]\n",objectrevId);fflush(stdout);
												printf("moduleObjects objectdesc = [%s]\n",objectdesc);fflush(stdout);
												printf("moduleObjects objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
												printf("moduleObjects objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
												
												//Get Occurence ID on Part
												
												if(GRM_find_relation(dmlTaskTag,moduleObjects[j],DmlItemsRelation,&probj));
												if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
												if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
												printf("\nSAN:ColorVF: primaryobj_name-------->  :%s\n", primaryobj_name);fflush(stdout);
												if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
												{
													printf("\nSAN:ColorVF: Inside getting BOMUID Attr \n"); fflush(stdout);
													ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
													printf("\n SAN:ColorVF: OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
												
												}
												
												
												if(tc_strcmp(Part_type,"M")==0)
												{
													int n_parents			= 0;
													int *levels				= 0;
													tag_t* parents = NULL;
													int jd = 0;
													tag_t ArchAssyTag = NULLTAG;
													char* ChildUID = NULL;
													int flagArc = 0;
													char* child_bl_formula = NULL;
													char* occ_effec_old = NULL;
													//int occEffec = 0;
													tag_t ConfigCtx = NULLTAG;
													ifail = PS_where_used_all(moduleObjects[j],1,&n_parents,&levels,&parents);
													printf("\nSAN:ColorVF: where_used count of objects are : %d",n_parents); fflush(stdout);
													
													for (jd=0;jd<n_parents;jd++ )
													{
														ArchAssyTag = NULLTAG;
														char* Arch_obj = NULL;
														tag_t  ArchobjTypeTag	= NULLTAG;
														char  *Archtype_name = NULL;
														
														
														ArchAssyTag=parents[jd];
														
														ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj);//PrintErrorStack();
														//printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

														ifail = TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag);//PrintErrorStack();
														ifail = TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name);//PrintErrorStack();
														printf("\nSAN:ColorVF: Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout);
														
														if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
														{
															tag_t master = NULLTAG;
															char* Arch_obj_str = NULL;
															tag_t relation_dep=	NULLTAG;
															int countConfigCtx = 0;
															tag_t  *ConfigCtxSecObject	= NULLTAG;
															//flagArc = 0;
															
															//printf("\n to do....\n");fflush(stdout);
															printf("\nSAN:ColorVF: Architecture Object Drag Drop is :%s",Arch_obj);fflush(stdout);
															
															ifail = ITEM_ask_item_of_rev(ArchAssyTag, &master);
															ifail = AOM_ask_value_string(master,"item_id",&Arch_obj_str);//PrintErrorStack();
															printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

															ifail = GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep);//PrintErrorStack();
															if(relation_dep != NULLTAG)
															{
																printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
																ifail = GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject);//PrintErrorStack();
															}

															
															printf("\n\t Configuration Context count is : %d",countConfigCtx);
															//test sanjoy
															//countConfigCtx = 1;
															if(countConfigCtx > 0)
															{
																ConfigCtx = NULLTAG;
																//ConfigCtx=ConfigCtxSecObject[0];
																tag_t window = NULLTAG;
																tag_t rule = NULLTAG;
																tag_t top_line = NULLTAG;
																
																int n_occs = 0;
																tag_t* occsal = NULL;
																
																int bvr_count = 0;
																tag_t* bvrs = NULL;
																tag_t bvr = NULLTAG;
																ifail = ITEM_rev_list_bom_view_revs(ArchAssyTag,&bvr_count, &bvrs);

																printf("\n test...bvr count is...%d",bvr_count);fflush(stdout);	
																if (bvr_count)
																{
																	bvr = bvrs[0];
																}
																else
																{
																	return ifail;
																}
																													
																ifail = PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal );
																
																printf("\n test...n_occs is...%d",n_occs);fflush(stdout);
																

																//PSEShowUnconfigdEffPref
																ConfigCtx=ConfigCtxSecObject[0];
																if(PREF_set_logical_value("PSEShowUnconfigdEffPref",true));
																if(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
																printf("\n After1111: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);													
																if(BOM_create_window (&window)!=ITK_ok);
																if(CFM_find( "Latest Working", &rule )!=ITK_ok);
																if(BOM_set_window_config_rule( window, rule )!=ITK_ok);
																if(BOM_set_window_pack_all (window, false)!=ITK_ok);
																if(BOM_set_window_top_line (window, NULLTAG,ArchAssyTag, NULLTAG, &top_line)!=ITK_ok);
																
																if(top_line != NULLTAG)
																{
																	int n_BL = 0;
																	int p = 0;
																	tag_t* children = NULL;
																	//CALLAPI(BOM_line_ask_child_lines(top_line, &n_BL, &children))
																	if(BOM_line_ask_all_child_lines (top_line, &n_BL, &children));
																	//CALLAPI(BOM_line_subset_child_lines_occs(top_line,n_occs,occsal,&n_BL, &children));
																	printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
																	
																	for (p=0;p<n_BL ;p++ )
																	{
																		tag_t Childobject = NULLTAG;
																		char* child_item_id = NULL;
																		child_bl_formula = NULL;
																		//int uidType = 0;
																		ChildUID = NULL;
																		occ_effec_old = NULL;

																		Childobject=children[p];
																		
																		//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
																		if(AOM_ask_value_string(Childobject, "bl_occurrence_uid", &ChildUID));
																		printf("\n SAN:ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);

																		if((tc_strstr(OccUIDattr,ChildUID)!=NULL))
																		{
																			if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
																			printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

																			if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
																			printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);												
																			//printf("\n uid not equal %s\t-  %s",ChildUID,OccUIDattr);fflush(stdout);
																			//if(BOM_line_look_up_attribute("bl_occ_effectivity",&occEffec));
																			if(AOM_ask_value_string(Childobject,"bl_occ_effectivity",&occ_effec_old));																	
																			flagArc++;
																			break;
																			
																		}
																		

																		

																		
																	
																		
																	}
																	
																	
																	
																}
																
																ifail = BOM_close_window(window);
																
															}

															
															
														}
														
														printf("\n flagArc=============> %d\n",flagArc);fflush(stdout);
														if(flagArc >0)
														{
															break;
														}
														
														
													}
													
													//To write function to check the logic.
													printf("\n flagArc1111=============> %d\n",flagArc);fflush(stdout);
													if(flagArc >0)
													{
														allowed = FALSE;
														if(tc_strcmp(userInfo1,"LOGIC1")==0)
														{
															tmCheckColorChangeNew(ArchAssyTag,moduleObjects[j],ConfigCtx, objectId,objectrevId,child_bl_formula,occ_effec_old,OccUIDattr,ChildUID, &allowed);

														}
														else
														{
															tmCheckColorChange(ArchAssyTag,moduleObjects[j],ConfigCtx, objectId,objectrevId,child_bl_formula,occ_effec_old,OccUIDattr,ChildUID, &allowed);

														}
														
														
														if(allowed)
														{
															t5AddStrToSet(&moduleCnt, &moduleList,objectId);
															
														}													
													}
													
														
													
												}

												printf("\n************************* %d SAN:End********************************\n",j+1);fflush(stdout);
																			
											}
										}
									}
														
									
								}
								
							}
						}
					
						if(PREF_set_logical_value("PSEShowUnconfigdEffPref",prefOrig));
						if(PREF_ask_logical_value("PSEShowUnconfigdEffPref",0,&pref));
						printf("\n Revert to original state: PSEShowUnconfigdEffPref====================> %d\n",pref);fflush(stdout);
					}
					
					printf("\nmoduleCnt=========> %d\n",moduleCnt);fflush(stdout);
					if(moduleCnt > 0)
					{
						printf("\n Go to Color Team Review\n");fflush(stdout);
						ifail = 1002;
						break;
						
					}
					else
					{
						printf("\n Go to Normal workflow\n");fflush(stdout);
						ifail = ITK_ok;
						
					}
				
				}
				
			}
		}
		
	}

	if(ifail==1002)
	{
		return ifail;
	}
	else
		return ITK_ok;
	
	//return ifail;
	
}

/****************** Color Change Option in VF DML End****************************/

int CM_SetOccEffn(EPM_action_message_t msg)
{
	int Flag				=0;
	int ifail				= ITK_ok;
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int no_attach			= 0;
	int count				= 0;
	int countDep			= 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *primary_obj		= NULLTAG;
	tag_t  primaryObj		= NULLTAG;
	tag_t  childObjTag		= NULLTAG;
	tag_t  ArchobjTypeTag	=NULLTAG;
	tag_t ArchAssyTag =NULLTAG;
	tag_t  primaryobjtype			= NULLTAG;
	tag_t  probj			= NULLTAG;
	

	char   *ObjTyp = NULL;
	char   *Archtype_name = NULL;
	char   *primaryobj_name = NULL;
	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectrevId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *type_name		=NULL;
	char   *archId		=NULL;
	char   *OccUIDattr				= NULL;

	date_t			date_start				= NULLDATE;
	date_t			date_end				= NULLDATE;

	int n_parents=0;
	int *levels = 0;
	tag_t *parents = NULL;
	
	char *username;
	tag_t user_tag=NULLTAG;
	char *userid;
	//EPM_decision_t decision = EPM_go;
	logical res = false;
	tag_t cntrlTag = NULLTAG;
	char* userInfo1 = NULL;
	char* userInfo2 = NULL;
	char* userInfo3 = NULL;
	char* userInfo4 = NULL;
	
	logical clientflag = false;
	
	printf("\n *********** ::start here:: **********");fflush(stdout);

	ifail = EPM_ask_root_task(msg.task, &roottask);
	ifail = EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments);
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		//implement logic.
		isCreOccNewFunctionNew(&res, &cntrlTag);
		if(cntrlTag != NULLTAG)
		{
			printf("\nUVF:Got control obj: occEffNew... res[%d]\n",res);fflush(stdout);
			if(AOM_ask_value_string(cntrlTag,"t5_Userinfo1",&userInfo1));			
			if(AOM_ask_value_string(cntrlTag,"t5_Userinfo2",&userInfo2));			
			if(AOM_ask_value_string(cntrlTag,"t5_Userinfo3",&userInfo3));			
			if(AOM_ask_value_string(cntrlTag,"t5_Userinfo4",&userInfo4));
			
								
		}
		if(userInfo1 == NULL) userInfo1 = "";
		if(userInfo2 == NULL) userInfo2 = "";
		if(userInfo3 == NULL) userInfo3 = "";
		if(userInfo4 == NULL) userInfo4 = "";
		printf("\nUVF:Live? [%d], User Info1:[%s] User Info2:[%s] User Info3:[%s] User Info4:[%s]\n",res,userInfo1,userInfo2,userInfo3,userInfo4);fflush(stdout);
		
		//Client logic.
		if(tc_strcmp(userInfo3,"CLIENTLOGIC")==0)
		{
			//Execute client logic...
			
			if(!res)
			{
				printf("\nUVF: Not live for client logic...\n");fflush(stdout);
				return ITK_ok;
			}
			else
			{
				printf("\nUVF:Execute Client logic.....\n");fflush(stdout);
				clientflag = true;
			}
			
		}	
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				printf("\nUVF:clientflag ===> %d\n",clientflag);fflush(stdout);
				if(clientflag)
				{
					char* sysCmnd = NULL;
					char* dmlTaskNmb = NULL;
					
					ifail = AOM_ask_value_string(taskAttachments[i],"item_id",&dmlTaskNmb);
					printf("\nUVF:Execute Client logic shell script... for DML Task no [%s]\n", dmlTaskNmb);fflush(stdout);
					
					sysCmnd=(char *) MEM_alloc(400);
					tc_strcpy(sysCmnd,userInfo4); //userinfo4 is the shell path
					tc_strcat(sysCmnd," ");
					tc_strcat(sysCmnd,dmlTaskNmb);
					printf("\n Start-- Calling shell file tm_uvfDmlCreOcc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
					system(sysCmnd);
					
					printf("\n End of Execution of  shell file tm_uvfDmlCreOcc.sh using client system command: %s\n",sysCmnd);fflush(stdout);
					
					MEM_free(sysCmnd);					
					
				}
				else
				{
					printf("\nUVF:Execute handler logic.. ...\n");fflush(stdout);
					ifail = GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation);
					if(DmlItemsRelation != NULLTAG)
					{
						printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
						ifail = GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject);
						printf("\n\t count is : %d",count);
						if(count >0)
						{
							for(j=0;j<count;j++)
							{
							  ifail = AOM_ask_value_string(SecObject[j],"t5_PartType",&objecttype);
							  ifail = AOM_ask_value_string(SecObject[j],"item_revision_id",&objectrevId);
							  ifail = AOM_ask_value_string(SecObject[j],"item_id",&objectId);
							  ifail = AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus);

							  printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
							  printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
							  printf("SecObject objectrevId = [%s]\n",objectrevId);fflush(stdout);
							  printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
							  //if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && (tc_strstr(objectrevId,"NR")== NULL) && (tc_strcmp(objecttype,"M")==0 ))
							//IFD Module/ECU to be considered for VF
							 // if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL) || (tc_strstr(objectrelstatus,"ERC Released")!= NULL) && ((tc_strcmp(objecttype,"M")==0 ) || (tc_strcmp(objecttype,"IM")==0 ) || (tc_strcmp(objecttype,"EM")==0 ) ))
							 if ((tc_strstr(objectrelstatus,"T5_LcsErcRlzd")!= NULL || tc_strstr(objectrelstatus,"T5_LcsReview")!= NULL || tc_strstr(objectrelstatus,"ERC Review")!= NULL || tc_strstr(objectrelstatus,"ERC Released")!= NULL || tc_strstr(objectrelstatus,"ERC Working")!= NULL || tc_strstr(objectrelstatus,"T5_LcsWorking")!= NULL) && ((tc_strcmp(objecttype,"M")==0 ) || (tc_strcmp(objecttype,"IM")==0 ) || (tc_strcmp(objecttype,"EM")==0 ) ))	 
							  {	  
								  if(GRM_find_relation(taskAttachments[i],SecObject[j],DmlItemsRelation,&probj));
								  if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
								  if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
								  printf("\n CM_SetOccEff primaryobj_name -------->  :%s\n", primaryobj_name);fflush(stdout);
								  if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
								  {
									  printf("\n\t Inside getting BOMUID Attr \n"); fflush(stdout);
									  ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
									  printf("\n Set_OccUID OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
								  }
								  
								  if(PS_where_used_all(SecObject[j],1,&n_parents,&levels,&parents));
								  printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
								  if(n_parents >0)
								  {
									  for (k=0;k<n_parents;k++)
									  {
										 // primaryObj=primary_obj[k];
										 //TCTYPE_ask_object_type(primaryObj,&objTypeTag);
										 // TCTYPE_ask_name(objTypeTag,type_name);

										 ArchAssyTag=parents[k];

										  ifail = AOM_UIF_ask_value(ArchAssyTag,"object_type",&type_name);
										 
										  if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
										  if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
										  printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

										if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
										{
											  printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
		//									  printf( "\n type_name :%s ..\n",type_name);
		//									  if (tc_strcmp(type_name,"T5_ArchModuleRevision")==0)
		//									  {
											  
											 // childObjTag=SecObject[j];

											 ifail = AOM_ask_value_string(ArchAssyTag,"item_id",&archId);

											  printf("\n\tArchitecture ID is := %s", archId);fflush(stdout); //ItemRevision

											  ifail = ITEM_find_item(objectId, &childObjTag);
											  
											  if((ArchAssyTag != NULLTAG) && (childObjTag != NULLTAG))
											  {
												  char* arcPlatform = NULL;
												  printf("\n !!...To call FUNCTION...!!");fflush(stdout);
												  ifail = ITK_string_to_date("24-May-2019 00:00", &date_start);
												  ifail = ITK_string_to_date("31-Dec-9999 00:00", &date_end);

													POM_get_user(&username,&user_tag);
													SA_ask_user_identifier2	(user_tag,&userid)	;
													printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
													
													if(AOM_ask_value_string(ArchAssyTag,"t5_ArchPlatform",&arcPlatform));
													printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);												
													if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0 && tc_strcmp(userid,"su_mdm")!=0 && tc_strcmp(userid,"infodba")!=0)
													{
														//Call the funtion to create occurence.
														
														printf("\nUse NEWLOGIC res...==> %d\n",res);fflush(stdout);
														if(res)
														{
															printf("\nSAN: new occ function...\n");fflush(stdout);
																
															if(tc_strcmp(userInfo1,"NEWLOGIC")==0)
															{
																if(tc_strcmp(userInfo2,"PACKEDLOGIC")==0)
																{
																	printf("\n Packed logic to set find no\n");fflush(stdout);
																	ifail = Create_occurance_effectivity_newlogic_packed(ArchAssyTag, childObjTag, date_start,date_end,OccUIDattr,arcPlatform);
																}
																else
																{
																	printf("\n New logic to set find no\n");fflush(stdout);
																	ifail = Create_occurance_effectivity_newlogic(ArchAssyTag, childObjTag, date_start,date_end,OccUIDattr,arcPlatform);
																}
																
															}
															else
															{
																ifail = Create_occurance_effectivity_new(ArchAssyTag, childObjTag, date_start,date_end,OccUIDattr,arcPlatform);
															}
															
														}
														else
														{
															ifail = Create_occurance_effectivity_new(ArchAssyTag, childObjTag, date_start,date_end,OccUIDattr,arcPlatform);
														}
														
													}
											  }
										  }
									  }
								  }
							  }
							}
						}
					}
				
				}
			}
		}
		
	}	
	return ifail;
		
}


EPM_decision_t CM_Update_Variant_FormulaNewFn(EPM_rule_message_t msg)
{
	int i					= 0;
	int j					= 0;
	int k					= 0;
	int l					= 0;
	int	n					= 0;
	int no_attach			= 0;
	int count				= 0;
	int taskcount			= 0;
	int flagVC				= 0;
	int n_parents			= 0;
	int *levels				= 0;

	tag_t  roottask			= NULLTAG;
	tag_t  *taskAttachments	= NULLTAG;
	tag_t  objTypTag		= NULLTAG;
	tag_t  DmlItemsRelation	= NULLTAG;
	tag_t  Taskrelation_type= NULLTAG;
	tag_t  *SecObject		= NULLTAG;
	tag_t  *taskObject		= NULLTAG;
	tag_t   DMLObject		= NULLTAG;
	tag_t	objTypeTag		= NULLTAG;
	tag_t	AssyTag			= NULLTAG;
	tag_t	ArchAssyTag		= NULLTAG;
	tag_t  *parents			= NULL;
	tag_t  ArchobjTypeTag	= NULLTAG;
	tag_t  *children1		= NULLTAG;
	tag_t  Childobject		= NULLTAG;
	tag_t   window,rule,item_tag = null_tag,top_line;
	

	char   *objecttype		=NULL;
	char   *objectId		=NULL;
	char   *objectdesc		=NULL;
	char   *objectrelstatus	=NULL;
	char   *objectDRstatus	=NULL;
	char   *Part_type	=NULL;
	char   *DMLDRstauts		=NULL;
	char   *value			=NULL;
	char   *Arch_obj		=NULL;
	char   *child_bl_formula=NULL;

	char   *ObjTyp = NULL;
	char   *type_name = NULL;
	char   *Archtype_name = NULL;

	char* child_bl_formula_cmp = NULL;

	//BOM_LINE
	char *child_rev_id = NULL;
 	char *child_rev_seq = NULL;
	char *child_rev_stat = NULL;
	char *child_objType = NULL;
	char *mod_addr = NULL;
 	//int			revid			= 0;
 	//int			revseq			= 0;
 	//int			revstat			= 0;
 	//int			blobjType		= 0;
 	//int			modadd			= 0;
 	int			Variantflag		= 0;
 	int			Variantflag1		= 0;
	int	ifail = 0;
	char *username;
	char *userid;
	tag_t user_tag=NULLTAG;
	char *designer_role = NULL;
	char *manager_role = NULL;
	int designer_found=0,manager_found=0;
	tag_t * 	list;
	tag_t top_bom_line=NULLTAG;
	
	tag_t  probj			= NULLTAG;
	tag_t  primaryobjtype			= NULLTAG;
	char   *primaryobj_name = NULL;
	char   *OccUIDattr				= NULL;
	

	EPM_decision_t decision = EPM_go;
	
	printf("\n *********** ::start here:: **********");fflush(stdout);

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
	printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(i=0;i<no_attach;i++)
		{
			printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);

			if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				if(GRM_find_relation_type("T5_ModuleVF_to_Change",&DmlItemsRelation));
				if(DmlItemsRelation != NULLTAG)
				{
					printf("\n\t DmlItemsRelation relation found......");fflush(stdout);
					if(GRM_list_secondary_objects_only(taskAttachments[i],DmlItemsRelation,&count,&SecObject));
					printf("\n\t count is : %d",count);
					
					if(count >0)
					{
						flagVC=0;
						for(j=0;j<count;j++)
						{
							if(AOM_ask_value_string(SecObject[j],"object_type",&objecttype));
							if(AOM_ask_value_string(SecObject[j],"item_id",&objectId));
							if(AOM_ask_value_string(SecObject[j],"object_desc",&objectdesc));
							if(AOM_UIF_ask_value(SecObject[j],"release_status_list",&objectrelstatus));
							if(AOM_ask_value_string(SecObject[j],"t5_PartStatus",&objectDRstatus));
							if(AOM_ask_value_string(SecObject[j],"t5_PartType",&Part_type));

							printf("\n\n\t CP Part_no  is :%s",Part_type);	fflush(stdout);
							printf("SecObject objecttype = [%s]\n",objecttype);fflush(stdout);
							printf("SecObject objectId = [%s]\n",objectId);fflush(stdout);
							printf("SecObject objectdesc = [%s]\n",objectdesc);fflush(stdout);
							printf("SecObject objectrelstatus = [%s]\n",objectrelstatus);fflush(stdout);
							printf("SecObject objectDRstatus = [%s]\n",objectDRstatus);fflush(stdout);
							
							//Get the occurance uid on relationship
							if(GRM_find_relation(taskAttachments[i],SecObject[j],DmlItemsRelation,&probj));
							if (TCTYPE_ask_object_type(probj,&primaryobjtype)!=ITK_ok);
							if (TCTYPE_ask_name2(primaryobjtype,&primaryobj_name)!=ITK_ok);
							printf("\nSAN:UVF:Rule Handler -------->  :%s\n", primaryobj_name);fflush(stdout);
							if(tc_strcmp(primaryobj_name,"T5_ModuleVF_to_Change")==0) 
							{
								printf("\n\tSAN:UVF: Inside getting BOMUID Attr \n"); fflush(stdout);
								ifail = AOM_UIF_ask_value(probj,"t5_Occurance_UID",&OccUIDattr);
								printf("\n SAN:UVF: OccUIDattr--------> :%s\n",OccUIDattr);fflush(stdout);
							}							
							
							if(strcmp(Part_type,"M")==0)								
							{
								AssyTag=SecObject[j];
								if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
								if(TCTYPE_ask_name2(objTypeTag,&type_name));
								printf("\n\t CP AssyTag type_name := %s", type_name);fflush(stdout); //ItemRevision

								if(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
								printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout); // 1
								
								/////////Module Variant Formula  Validation////////
								int parent_item_seq=0;
								tag_t itemrev =NULLTAG;
								char* Trgt_bl_formula=NULL;
								char*  Part_no =NULL;
								int jd=0;

								int n_BL=0;
								int p1=0;
								char* child_item_id = NULL;
								char* child_bl_formula = NULL;
								tag_t  	master =	NULLTAG;
								char*  Arch_obj_str = NULL;
								tag_t relation_dep=	NULLTAG;
								int countConfigCtx = 0;
								tag_t  *ConfigCtxSecObject	= NULLTAG;
								tag_t ConfigCtx = NULLTAG;
								tag_t  ConfigCtxObjTypeTag=NULLTAG;
								char   *Config_CtxType = NULL;
								char*	 SmVCContext			= NULL;
								char*	 SmCrIDContext			= NULL;
								char*	 ContextobjName			= NULL;

								tag_t	qry_t1	= NULLTAG;
								char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entr1 = 1;
								char    *qry_entr1[1]  = {"SYSCD"};
								int rsltCunt1=0;
								tag_t *CntrlObjTag1=NULL;

								tag_t	queryTag	= NULLTAG;
								char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
								int n_entries = 1;
								int resultCount=0;
								char *qry_entries[1] = {"ID"};

								tag_t *ConId  = NULL;
								int j=0;
								tag_t Optfmly_tag = NULLTAG;

								int dmlIncnt =0;
								int CmpleteVrf=0;
								char *username1;
								tag_t user_tag1=NULLTAG;
								char *userid1;
								
								if(n_parents>0)
								{
									for (jd=0;jd<n_parents;jd++ )
									{
										ArchAssyTag=parents[jd];
										if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));//PrintErrorStack();
										printf("\n\t Architecture Object Drag Drop is :%s",Arch_obj);	fflush(stdout);

										if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));//PrintErrorStack();
										if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));//PrintErrorStack();
										printf("\n\t Drag Drop Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

										if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
										{
											printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);

											if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
											if(AOM_ask_value_string(master,"item_id",&Arch_obj_str));//PrintErrorStack();
											printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

											if(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));//PrintErrorStack();
											if(relation_dep != NULLTAG)
											{
												printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
											}

											if(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));//PrintErrorStack();
											printf("\n\t Configuration Context count is : %d",countConfigCtx);


											if(countConfigCtx>0)
											{
												ConfigCtx=ConfigCtxSecObject[0];
												if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
												if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
												if(top_line!=NULLTAG)
												{
													if(BOM_line_ask_child_lines(top_line, &n_BL, &children1));//PrintErrorStack();
													printf("\n\t No of child objects are n : %d",n_BL);fflush(stdout);
													if (n_BL >0)
													{
														
														for (p1=0;p1<n_BL ;p1++ )
														{
															int Result=1;
															if(Childobject) Childobject=NULLTAG;
															Childobject=children1[p1];
															if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));//PrintErrorStack();
															printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

															if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula_cmp ));//PrintErrorStack();
																printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula_cmp); fflush(stdout);
															

															if(tc_strcmp(objectId,child_item_id)==0)
															{

																

																if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula));
																printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

																if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag))PrintErrorStack();
																if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType))PrintErrorStack();
																printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

																if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext))PrintErrorStack();
																printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

																if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext))PrintErrorStack();
																printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

																if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag))PrintErrorStack();
																printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
																if (queryTag)
																{
																	printf("\n\tFound Query");fflush(stdout);
																}else
																{
																	printf("\n\tNot Found Query");fflush(stdout);
																}

																qry_values[0] = SmCrIDContext;

																if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ConId))PrintErrorStack();
																printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);

																if(POM_get_user(&username1,&user_tag1));
																SA_ask_user_identifier2	(user_tag1,&userid1)	;
																printf ("Logged in userid1:::::%s %s\n",userid1,username1);fflush(stdout);
																if(tc_strcmp(userid1,"ercpsup")!=0 && tc_strcmp(userid1,"loader")!=0 && tc_strcmp(userid1,"su_mdm")!=0 && tc_strcmp(userid1,"infodba")!=0)
																{
																if (tc_strcmp(type_name,"T5_ClrPartRevision")!=0)
																{
																	
																	if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
																	{
																		printf("\n CC available Variant formula not available \n"); fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",objectId);
																		decision = EPM_nogo;
																		return decision;
																		//return ITK_errStore;
																	}
																}
																}
																	
									
															}
														}
													}//
												}
											}
										}
									}


								}
								else
								{
									printf("\n Module not attached to any architecture node. \n"); fflush(stdout);

								}
								


								tag_t ArchAssyTag =NULLTAG;
								char* Arch_obj= NULL;
								tag_t ArchobjTypeTag=NULLTAG;
								char  *Archtype_name = NULL;
								tag_t window=NULLTAG;
								tag_t  rule=NULLTAG;
								tag_t top_line =NULLTAG;
								tag_t *children1= NULL;
								tag_t Childobject=NULLTAG;
								
								//Sanjoy
								//int    uidType=0;
								char* ChildUID = NULL;
								


								if(n_parents>0)
								{
									for (k=0;k<n_parents;k++ )
									{
										ArchAssyTag=parents[k];
										if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj));
										printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

										if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag));
										if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name));
										printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); //ItemRevision

										if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
										{
											printf("\n\t Inside T5_ArchModuleRevision........");fflush(stdout);
											if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
											if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
											if(top_line!=NULLTAG)
											{
												if(BOM_line_ask_child_lines (top_line, &n, &children1));
												printf("\n\t No of child objects are n : %d",n);fflush(stdout);
												if (n >0)
												{
													for (l=0;l<n ;l++ )
													{
														if(Childobject) Childobject=NULLTAG;
														Childobject=children1[l];
														if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula));
														printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);
														if(Childobject != NULLTAG)
														{
															
															printf("\n Validate VF handler called \n");fflush(stdout);
															//if(BOM_line_look_up_attribute("bl_item_item_id",&revid))PrintErrorStack();
															//if(BOM_line_look_up_attribute("bl_rev_item_revision_id",&revseq))PrintErrorStack();
															//if(BOM_line_look_up_attribute ("bl_rev_release_status_list",&revstat))PrintErrorStack();
															//if(BOM_line_look_up_attribute ("bl_item_object_type",&blobjType))PrintErrorStack();
															if(AOM_ask_value_string(Childobject,"bl_item_item_id",&child_rev_id))PrintErrorStack();
															if(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&child_rev_seq))PrintErrorStack();
															if(AOM_ask_value_string(Childobject, "bl_rev_release_status_list", &child_rev_stat))PrintErrorStack();
															if(AOM_ask_value_string(Childobject, "bl_item_object_type", &child_objType))PrintErrorStack();
															printf("\n Part:%s %s Status:%s  child_objType <%s> \n",child_rev_id,child_rev_seq,child_rev_stat,child_objType);fflush(stdout);
															
															//Todo - Check for only those module which are attached to the Variantformula dml.
															//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
															if(AOM_ask_value_string(Childobject, "bl_occurrence_uid", &ChildUID));
															printf("\n SAN:ChildUID ===============>>>>>>1111 %s \n",ChildUID);fflush(stdout);
															
															if(!(tc_strstr(OccUIDattr,ChildUID)!=NULL))
															{
																printf("\n uid not equal %s\t-  %s",ChildUID,OccUIDattr);fflush(stdout);
																continue;
																
															}

															

															if (tc_strcmp(child_objType,"Colour Part")==0)
															{
																//return ITK_ok;
																return EPM_go;
															}

															if(BOM_line_ask_window(Childobject,&window))PrintErrorStack();
															if(window != NULLTAG)
															{
																if(BOM_ask_window_top_line(window,&top_bom_line))PrintErrorStack();
																if(top_bom_line != NULLTAG)
																{
																	//if(BOM_line_look_up_attribute ("fnd0bl_line_object_type",&blobjType))PrintErrorStack();
																	if(AOM_ask_value_string(top_bom_line, "fnd0bl_line_object_type", &child_objType))PrintErrorStack();
																	if (tc_strcmp(child_objType,"T5_PlatformRevision")==0)
																	{
																		POM_get_user(&username,&user_tag);
																		SA_ask_user_identifier2	(user_tag,&userid)	;
																		printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
																		if(tc_strcmp(userid,"ercpsup")!=0 && tc_strcmp(userid,"loader")!=0)
																		{
																			printf("\n Variant formula with X4 Context Not Allowed \n");fflush(stdout);
																			EMH_clear_errors();
																			EMH_store_error_s2(EMH_severity_error,ITK_err,"Variant formula can't be updated at platform level","Send architecture node separately to Structure Manager to edit variant formula of the module");
																			decision = EPM_nogo;
																			return decision;
																			//return ITK_errStore;
																		}
																	}
																}
															}

															if((tc_strstr(child_rev_stat,"Release") != NULL) && (tc_strstr(child_rev_seq,"NR") != NULL))
															{
																printf ("\n NOT Allowed to updte Variant Formula as child_rev_stat:- ERC Release & child_rev_seq:- is NR \n");fflush(stdout);
																Variantflag++;
															}

															else if((tc_strcmp(child_rev_stat,"ERC Review") == 0) && (tc_strstr(child_rev_seq,"NR") == NULL))
															{
																printf ("\n NOT Allowed to updte Variant Formula as child_rev_stat:- ERC Release & child_rev_seq:- is not NR \n");fflush(stdout);
																Variantflag1++;
															}

															else if((tc_strstr(child_rev_stat,"Release") != NULL) && (tc_strstr(child_rev_seq,"NR") == NULL))
															{
																printf ("\n Allowed to updte Variant Formula as child_rev_stat:- ERC Release & child_rev_seq:- not NR \n");fflush(stdout);
																Variantflag++;
															}							
															else if((tc_strcmp(child_rev_stat,"ERC Review") == 0) && (tc_strstr(child_rev_seq,"NR") != NULL))
															{
																printf ("\n Allowed to updte Variant Formula child_rev_stat:- ERC Reviev & child_rev_seq:- NR \n");fflush(stdout);
																Variantflag1++;
															}

															if (Variantflag1>0)
															{
																POM_get_user(&username,&user_tag);
																SA_ask_user_identifier2	(user_tag,&userid)	;
																printf ("Logged in user:%s %s\n",userid,username);fflush(stdout);
																if((tc_strcmp(userid,"su_mdm")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
																{
																	printf("\n Released Part, Variant Formula change is not allowed:%s %s\n",child_rev_id,child_rev_seq);fflush(stdout);
																	/*EMH_clear_errors();
																	EMH_store_error_s3(EMH_severity_error,ITK_err,"\nVariant formula updation is allowed if Module Revision =NR and Release Status =ERC Review","For Revision other than NR kindly take Update variant formula type DML",child_rev_id);
																	decision = EPM_nogo;
																	return decision;*/
																	//return ITK_errStore;
																}
															}
															if (Variantflag>0)
															{
																POM_get_user(&username,&user_tag);
																SA_ask_user_identifier2	(user_tag,&userid)	;
																printf ("Logged in user:%s\n",userid);fflush(stdout);
																if((tc_strcmp(userid,"su_mdm")!=0)) //&& (tc_strcmp(userid,"infodba")!=0)
																{
														//if(BOM_line_look_up_attribute("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();

																	if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ModuleAddress", &mod_addr))PrintErrorStack();
																	printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);
																	if(mod_addr != NULL && strlen(mod_addr) > 0)
																	{

																		designer_role = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Designers")) * sizeof(char));
																		strcpy(designer_role,mod_addr);
																		strcat(designer_role,"_Designers");
																		manager_role  = (char *)MEM_alloc ((strlen(mod_addr) + strlen("_Managers")) * sizeof(char));
																		strcpy(manager_role,mod_addr);
																		strcat(manager_role,"_Managers");
																		printf("\nsearch for role:%s OR %s\n",designer_role,manager_role);fflush(stdout);

																		if(SA_find_groupmember_by_rolename(designer_role,"ERC_Designers_Group",userid,&designer_found,&list))PrintErrorStack();
																		if(SA_find_groupmember_by_rolename(manager_role,"ERC_Designers_Group",userid,&manager_found,&list))PrintErrorStack();
																		printf("\n designer_found:%d manager_found:%d\n",designer_found,manager_found); fflush(stdout);
																		if(designer_found == 0 && manager_found == 0)
																		{
																			//EMH_clear_errors();
																			//EMH_store_error_s3(EMH_severity_error,ITK_err,"\nYou don't have access to update variant formula for this module","Contact PLM Admin to get access",userid);
																			//decision = EPM_nogo;
																			//return decision;
																			//return ITK_errStore;
																		}

																	}
																	else
																	{
																			EMH_clear_errors();
																			EMH_store_error_s3(EMH_severity_error,ITK_err,"\nModule Address is blank for this module","Contact PLM Team to update Module Address",userid);
																			decision = EPM_nogo;
																			return decision;
																			//return ITK_errStore;
																	}
																
																	
																}	
															}
															
														}

													}

												}

											}

										}
										
									}



								}
							}

						}
					}	
				}
			}
		}
	}
	
	return decision;
}

/*************************DMU reviewer***************/

EPM_decision_t UVF_IsDMUReviewerAssigned(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	tag_t root_task = NULLTAG;
	char* CurrentTask = NULL;
	int ifail = ITK_ok;
	logical isLive = FALSE;
	int no_attach = 0;
	tag_t* taskAttachments = NULL;

	printf("\nUVF:Inside UVF_IsDMUReviewerAssigned....\n");fflush(stdout);
	
	//logic to be implemented...
	
	ifail = EPM_ask_root_task(msg.task,&root_task);
	ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	
	
	
	ifail = isUVFDMULive(&isLive);
	printf("\nUVF:isLive for DMU Review\n");fflush(stdout);
	if(isLive)
	{
		//implementaion of logic here
		ifail = EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &taskAttachments);
		printf("\nUVF:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);
		if(no_attach >0)
		{
			int i = 0;
			tag_t  objTypTag		= NULLTAG;
			char   *ObjTyp = NULL;
			char   *type_name = NULL;
			for(i=0;i<no_attach;i++)
			{
				if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\nUVF:Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
				
				if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
				{
					//check for release type.
					tag_t dmlTag = NULLTAG;
					dmlTag = taskAttachments[i];
					char* dmlReleaseType = NULL;
					char* dmlRelTypeDisplayStr = NULL;
					
					ifail = AOM_ask_value_string(dmlTag,"t5_rlstype",&dmlReleaseType);
					ifail = AOM_UIF_ask_value(dmlTag,"t5_rlstype",&dmlRelTypeDisplayStr);
					
					printf("\nUVF DML Release Type:%s===>%s\n",dmlReleaseType,dmlRelTypeDisplayStr);fflush(stdout);
					
					if(tc_strcmp(dmlReleaseType,"UVF")==0)
					{
						//apply logic here
						tag_t dml_Prty_rel_type = NULLTAG;
						ifail = GRM_find_relation_type("HasParticipant",&dml_Prty_rel_type);
						if (dml_Prty_rel_type!=NULLTAG)
						{
							int Prtycount = 0;
							tag_t* DmlCRB = NULL;
							char* DMLno = NULL;
							ifail = AOM_ask_value_string(dmlTag,"item_id",&DMLno);
							printf("\nUVF: DMLno:%s DMLtp:%s\n",DMLno,dmlReleaseType);	fflush(stdout);

							ifail = GRM_list_secondary_objects_only(dmlTag,dml_Prty_rel_type,&Prtycount,&DmlCRB);
							printf("\nUVF: DmlCRB count: %d",Prtycount);fflush(stdout);
							
							if(Prtycount > 0)
							{
								int jk = 0;
								int DMUFlag = 0;
								for (jk=0;jk<Prtycount ;jk++ )
								{
									tag_t DmlCRBTag = NULLTAG;
									tag_t ObjTypDmlCRB = NULLTAG;
									char* Prty_typ = NULL;
									DmlCRBTag = DmlCRB[jk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
									if(TCTYPE_ask_name2(ObjTypDmlCRB,&Prty_typ));
									if(Prty_typ == NULL) Prty_typ="";
									
									printf("\nUVF:Prty_typ:[%s]",Prty_typ);fflush(stdout);
									if (tc_strcmp(Prty_typ,"T5_DMUReviewer")==0)
									{
										printf("\nUVF:111\n");fflush(stdout);
										DMUFlag=1;
										///break;
									}
								}
								printf("\nDMU Flag:[%d]",DMUFlag);fflush(stdout);
								if(DMUFlag == 0)
								{
									printf("\nERROR:UVF:DMU review for UVF DML"); fflush(stdout);
									EMH_clear_errors();
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR:UVF: DMU reviewer not assigned to the DML, \nPlease assign the DMU Reviewer. \nUse: Select DML : Tools->Assign Participant->Select DMU Reviewer");
									return EPM_nogo;
								}
							}
						}
					}
					
				}
			}
		}
		
	}
	
	
	

	return EPM_go;
	
}


extern DLLAPI int  Save_Structure_method_occ(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	logical isLive = FALSE;
	
	
	va_list largs;
	va_copy( largs, args );
		
	tag_t window_tag = va_arg( largs, tag_t );
	
	va_end( largs );
	
	printf("\n Inside Save_Structure_method_occ - \n");fflush(stdout);
	
	if(isLiveForBOMSave(&isLive));
	printf("\n isLive==> %d\n",isLive);fflush(stdout);
	if(!isLive)
	{
		return ifail;
	}
	
	if(window_tag !=NULLTAG && isLive)
	{
		//Get the Top line
		tag_t top_bom_line = NULLTAG;
		ifail=BOM_ask_window_top_line(window_tag, &top_bom_line);
		
		if(top_bom_line!=NULLTAG)
		{
			char* objTypeArchStr = NULL;
			printf("\n SAN: Got the top line of the BOM window\n");fflush(stdout);
			if(AOM_ask_value_string(top_bom_line,"bl_item_object_type",&objTypeArchStr));
			
			printf("\nSAN: Object Type of the Top line : %s\n",objTypeArchStr);fflush(stdout);
			
			if(tc_strcmp(objTypeArchStr,"T5_ArchModule")==0)
			{
				char* archID = NULL;
				tag_t ArchNodeTag = NULLTAG;
				tag_t ArchNodeRevTag = NULLTAG;
				tag_t* lines = NULL;
				int n_lines = 0;
				//tag_t rule = NULLTAG;
				tag_t	*bvrs = NULLTAG;
				int bvr_count = 0;
				char* arcPlatform = NULL;
				int chldCnt = 0;
				char ** chldList = NULL;
				
				
				if(AOM_ask_value_string(top_bom_line,"bl_item_item_id",&archID));
				printf("\nSAN:Arch ID===> [%s]\n",archID);fflush(stdout);
				
				
				ifail= ITEM_find_item(archID, &ArchNodeTag);
				
				if(ArchNodeTag!=NULLTAG)
				{
					printf("\nSAN:Got the Architecheral Master Node\n");fflush(stdout);
					
					if(ITEM_ask_latest_rev(ArchNodeTag, &ArchNodeRevTag));
					
					if(ArchNodeRevTag!=NULLTAG)
					{
						printf("\nSAN:Got the Architecheral Revision Node\n");fflush(stdout);
						
						ifail = ITEM_rev_list_bom_view_revs(ArchNodeRevTag,&bvr_count, &bvrs);
						
						
						if(AOM_ask_value_string(ArchNodeRevTag,"t5_ArchPlatform",&arcPlatform));
						printf("\nSAN:Arch Platform===> [%s]\n",arcPlatform);fflush(stdout);
					}
					
				}
				
				printf("\n bvr_count==> %d\n",bvr_count);fflush(stdout);
				if(BOM_set_window_pack_all(window_tag, FALSE));	
				if(BOM_line_ask_child_lines(top_bom_line, &n_lines, &lines));
				printf("\n SAN:n_lines: %d\n", n_lines);fflush(stdout);
				
				if(n_lines>0)
				{
					int i=0;
					tag_t child_line = NULLTAG;
					for (i=0;i<n_lines ;i++ )
					{
						char* child_item_id = NULL;
						char* child_item_rev_id = NULL;
						char* child_part_type = NULL;
						char* child_object_type = NULL;
						logical verdict = FALSE;

						
						
						if(child_line) child_line=NULLTAG;
						
						child_line=lines[i];
						if(AOM_ask_value_string(child_line, "bl_item_item_id", &child_item_id ));
						if(AOM_ask_value_string(child_line,"bl_rev_item_revision_id",&child_item_rev_id));
						if(AOM_ask_value_string(child_line,"bl_Design Revision_t5_PartType",&child_part_type));
						if(AOM_ask_value_string(child_line,"bl_item_object_type",&child_object_type));
						

						printf("\n SAN:[%d] child_item_id[%s],child_item_rev_id[%s], child_part_type[%s], child_object_type[%s]",i+1,child_item_id,child_item_rev_id,child_part_type,child_object_type);fflush(stdout);
						

						//Add logic for ECU and IFD module also
						if((tc_strcmp(child_object_type,"Design")==0 || tc_strcmp(child_object_type,"Colour Part")==0) && (tc_strcmp(child_part_type,"M")==0 || tc_strcmp(child_part_type,"IM")==0 || tc_strcmp(child_part_type,"EM")==0))
						{
							verdict = FALSE;
							if(BOM_line_is_packed(child_line, &verdict));
							printf("\n Verdict[%d]\n",verdict);fflush(stdout);
							
							if(verdict)
							{
								if(tc_strcmp(child_object_type,"Colour Part")!=0)
								{
									EMH_store_error_s1(EMH_severity_error,ITK_err,"\nKindly Unpack bomline then save. Go to View-->Unpack All");
									return ITK_errStore;	
								}						
							}					
							else 
							{
																						
								char chldStr[200];
								int chldFound =0;
								//int uidType	 = 0;
								//int Uidlatest =0;
								char   *ChildUID		 = NULL;
								char * childSAPID = NULL;
								
								//SAP ID
								//if( BOM_line_look_up_attribute ("bl_occurrence_uid",&uidType));
								if(AOM_ask_value_string(child_line, "bl_occurrence_uid", &ChildUID));
								printf("\n CM_MR_SetOccEff ChildUID ======>>> %s \n",ChildUID);fflush(stdout);
								
								// ifail = AOM_lock( child_line );

								//if(BOM_line_look_up_attribute("bl_occ_t5_uidsap",&Uidlatest));
								if(AOM_ask_value_string(child_line, "bl_occ_t5_uidsap", &childSAPID));
								if(childSAPID==NULL)
								{
									if(AOM_set_value_string(child_line, "bl_occ_t5_uidsap",ChildUID));
								}
								else if(tc_strcmp(childSAPID,"")==0)
								{
									if(AOM_set_value_string(child_line, "bl_occ_t5_uidsap",ChildUID));
								}
								
								
															
								
								tc_strcpy(chldStr,"");
								tc_strcat(chldStr,child_item_id);
								tc_strcat(chldStr,"_");
								tc_strcat(chldStr,child_item_rev_id);
								
								printf("\nAdding %s to child Set\n",chldStr);fflush(stdout);
								
								t5FindStrInSet(chldList,chldCnt,chldStr,&chldFound);
								printf("\nChild found in the set==>%d\n",chldFound);fflush(stdout);
								
								if(chldFound==0)
								{
									Create_occurance_effectivity_OnBOMSave(ArchNodeRevTag,child_item_id,child_item_rev_id,arcPlatform);
									t5AddStrToSet(&chldCnt, &chldList,chldStr);								
								}
								

								
							}
						}
						

						

					}
				}
				
				
				
				
			}
			
		}		
	}

	

	return ifail;
}


extern int tm_CreOccEffOnBomSave_register_method(int *decision, va_list args)
{
    int ifail = ITK_ok;
    METHOD_id_t  method1 ;
    *decision = ALL_CUSTOMIZATIONS;  

	printf("\n\n tm_CreOccEffOnBomSave.c:it, via Custom Exits.\n");fflush(stdout);
	
	METHOD_id_t method;

	if (METHOD_find_method("BOMWindow", BOMWindow_save_msg, &method1) !=ITK_ok);
 
    if (method1.id != NULL)
	{
		printf("\n Method is found for BOMWindow_save_msg on Design Revision\n");fflush(stdout);
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) Save_Structure_method_occ, NULL)!=ITK_ok);
   
		if( ifail != ITK_ok )
		{
			EMH_store_error( EMH_severity_error, ifail );
		}
	}else
	{
		printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");fflush(stdout);
	}
	
	//Action handler
	
	 printf("\n SAN: tm_CreOccEffOnBomSave_register_method: Before registering handlers....");
	 ifail = EPM_register_action_handler("CM_SetOccEffNew", "CM_SetOccEffNew",CM_SetOccEffn);
	 
     //Action handler
	
	 printf("\n SAN: tm_CreOccEffOnBomSave_register_method: Before registering handlers....");
	 ifail = EPM_register_action_handler("TM_SetUVFClrPart", "TM_SetUVFClrPart",tm_SetUVFClrPartfn);
	 
	 //Action Handler -
	 ifail = EPM_register_action_handler("tm_IsColorOptionsUpdInVF", "tm_IsColorOptionsUpdInVF",tm_IsColorOptionsUpdInVFFn);
	 
	  //Action Handler - to set the custom sesult
	 ifail = EPM_register_action_handler("tm_UVF_IsColorOptionsModified", "tm_UVF_IsColorOptionsModified",tm_UVFIsColorOptionsModifiedFun);

	 //Rule handler
   	ifail = EPM_register_rule_handler (
							"CM_Update_Variant_FormulaNew",
							"CM_Update_Variant_FormulaNew",
							(EPM_rule_handler_t)CM_Update_Variant_FormulaNewFn
							);	 
	 
	ifail = EPM_register_rule_handler (
							"UVF_IsDMUReviewerAssigned",
							"UVF_IsDMUReviewerAssigned",
							(EPM_rule_handler_t)UVF_IsDMUReviewerAssigned
							);	
	
	printf("\n  tm_CreOccEffOnBomSave_register_method: Finished registering action and rule handlers....");	 

    return ifail;
}

extern DLLAPI int tm_CreOccEffOnBomSave_register_callbacks()
{
      CUSTOM_register_exit ( "tm_CreOccEffOnBomSave", "USER_init_module", (CUSTOM_EXIT_ftn_t) tm_CreOccEffOnBomSave_register_method);
	  printf("\n registered function tm_CreOccEffOnBomSave_register_method......\n");	fflush(stdout);      
	  return ( ITK_ok );
}
