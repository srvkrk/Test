#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h>
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <epm/signoff.h>
#include <epm/epm_task_template_itk.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>


#define ITK_err 919006
#define ITK_errStore (EMH_USER_error_base+2)
#define ITK_err2 (EMH_USER_error_base+3)
#define ITK_err1 (EMH_USER_error_base+4)
#define ALPHA_SIZE 26
#define DIGIT_SIZE 10
#define CLASS_IS_ITEM       0
#define CLASS_IS_DATASET    1
#define FIRST_DS_REV_ID "0"
#define FIRST_REV_ID "NR"

#define PROJ_id_size_c   64
#define PROJ_name_size_c   32
#define t9ModSumSheetCre_Val001 (EMH_USER_error_base+21)
#define t9ModIPTVHistryCre_Val001 (EMH_USER_error_base+21)
#define t9ModTargetCre_Val001 (EMH_USER_error_base+21)


#define ITK_CALL1(x) {           \
    int stat;                     \
    char *err_string;             \
    if( (stat = (x)) != ITK_ok)   \
    {                             \
    EMH_ask_error_text(stat, &err_string);                 \
    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
    if(err_string) MEM_free(err_string);                                \
    exit (EXIT_FAILURE);                                                   \
    }                                                                    \
}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}



static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

#define IFERR_ABORT(X) (report_error (__FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error (__FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
        Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
                Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
        Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return pErrCdeLst[i];//ITK_ok;
}

static int report_error(char *file, int line, char *call, int status,logical exit_on_error)
{
    if (status != ITK_ok)
    {
         int n_errors = 0;
         const int *severities = NULL;
         const int   *statuses = NULL;
                 const char
         **messages = NULL;

        EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
        if (n_errors > 0)
        {
            ECHO(("\n%s\n",(char *) messages[n_errors-1]));
            printf("\n%s\n", messages[n_errors-1]);fflush(stdout);
            EMH_clear_errors ();
        }
        else
        {
            char *error_message_string;
            EMH_ask_error_text(status, &error_message_string);
            ECHO (("\n%s\n", error_message_string));
            printf("\n%s\n", error_message_string);fflush(stdout);
        }

                         ECHO(("error %d at line %d in %s\n", status, line, file));
             printf("error %d at line %d in %s\n", status, line, file);fflush(stdout);
                         ECHO(("%s\n", call));
             printf("%s\n", call);fflush(stdout);

        if (exit_on_error)
        {
            ECHO(("\nExiting program!\n"));
            printf("\nExiting program!\n");fflush(stdout);
            exit (status);
        }
    }
    return status;
}

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

char *subString1(char *val)
{

                char *newval = (char*) malloc(12);

                strncpy(newval, val,11);
                printf("\n newval=%s",newval);fflush(stdout);

                return newval;
}

int tm_AwEPATryOut_assign_responsible_party(EPM_action_message_t msg)
{
                int ifail = ITK_ok;
                tag_t resourcePool = NULLTAG;
        tag_t tRootTask = NULLTAG;
        ITK_CALL1(EPM_ask_root_task(msg.task, &tRootTask));int no;
        tag_t *tSignoffs;
        tag_t *members;
        tag_t tTask = msg.task;
        int n=0;
        int i;
                char *role=NULL;
                char *group=NULL;
        char *pcArgVal=NULL;
        char *pcArgName=NULL;
        char *arg=NULL;
        char *epaplant="CVBU JSR";
        char *epaplant1=NULL;
                printf("cccccc===%d",msg.action);fflush(stdout);
        if (msg.action == EPM_start_action  && msg.proposed_state == EPM_started)
        {

        int count=0;
        tag_t *attachments=NULLTAG;
        tag_t objTag=NULLTAG;
        char *type=NULL;
        char *mode=NULL;
        ITK_CALL1(EPM_ask_attachments (tRootTask,EPM_target_attachment,&count,&attachments));
        printf("\n No of attachments:%d",count);
                if(count>0)
        {
           objTag=attachments[0];
           ITK_CALL1(AOM_ask_value_string(objTag,"object_type",&type));
           if(tc_strcmp(type,"T5_EPARevision")==0)
           ITK_CALL1(AOM_ask_value_string(objTag,"t5_EpaPlantA",&epaplant));
        }

           int iNoOfArgs = TC_number_of_arguments(msg.arguments);



            if (iNoOfArgs >= 1)
                        {
            for (i = 0; i < iNoOfArgs; i++)
                        {
                arg = TC_next_argument(msg.arguments);
                ITK_ask_argument_named_value((char*) arg, &pcArgName, &pcArgVal);
                if ((pcArgName != NULL))
                                {
                    if(tc_strcmp(pcArgName, "role") == 0)
                                        {
                        if (pcArgVal != NULL)
                                                {
                                                         role = (char*) MEM_alloc((strlen(pcArgVal) + 5) * sizeof (char));
                                                         printf("\n %s",epaplant);
                                                         /* if(tc_strcmp(epaplant,"CVBU PUNE")==0)
                                                         {
                                                         tc_strcpy(role, "PNE_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU JSR")==0)
                                                         {
                                                         tc_strcpy(role, "JSR_");
                                                         }*/

                                                         if(tc_strcmp(epaplant,"CVBU PUNE")==0)
                                                         {
                                                         tc_strcpy(role, "PNE_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU JSR")==0)
                                                         {
                                                         tc_strcpy(role, "JSR_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU PNR")==0)
                                                         {
                                                         tc_strcpy(role, "PNR_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU LKO")==0)
                                                         {
                                                         tc_strcpy(role,"LKO_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"DHARWAD")==0)
                                                         {
                                                         tc_strcpy(role,"DWD_");
                                                         }

                                                         tc_strcat(role, pcArgVal);
                                                 }
                        }
                                            else if (tc_strcmp(pcArgName, "group") == 0)
                                                {
                                                        if (pcArgVal != NULL)
                                                        {
                                                          group = (char*) MEM_alloc((strlen(pcArgVal) + 3) * sizeof (char));
                                                        tc_strcpy(group, pcArgVal);
                                                        //tc_strcat(group, "++");
                                                        }
                                                }

                                                else if (tc_strcmp(pcArgName, "mode") == 0)
                                                {
                                                        if (pcArgVal != NULL)
                                                        {
                                                          mode = (char*) MEM_alloc((strlen(pcArgVal) + 1) * sizeof (char));
                                                        tc_strcpy(mode, pcArgVal);
                                                        }
                                                }
                    }                 //if ((pcArgName != NULL)) Braket closed
                                printf("\n %d pcArgName==%s,pcArgVal==%s",i,pcArgName,pcArgVal);fflush(stdout);

                                }                    //for (i = 0; i < iNoOfArgs; i++) Braket closed
                        }   //if (iNoOfArgs >= 1) Bracket closed

                            printf("\n Role==%s group===%s mode=======%s",role,group,mode);fflush(stdout);
                                if(tc_strcmp(mode,"usr")==0)
                                {
                                ITK_CALL1(SA_find_groupmember_by_rolename (role,group,NULL,&no,&members));

                                if(no>0)
                                {
                                tag_t usertag=NULLTAG;
                                ITK_CALL1(SA_ask_groupmember_user(members[0],&usertag));
                                ITK_CALL1( EPM_assign_responsible_party(tTask, usertag ));
                                }
                                }
                                else if(tc_strcmp(mode,"grp")==0)
                {

                tag_t grouptag=NULLTAG;
                tag_t roletag=NULLTAG;
                ITK_CALL1(SA_find_group(group,&grouptag));
                ITK_CALL1(SA_find_role2(role,&roletag));
                ITK_CALL1(EPM_get_resource_pool(grouptag, roletag, FALSE, &resourcePool));
                ECHO("  resourcePool = %d\n", resourcePool);

                ITK_CALL1( EPM_assign_responsible_party(tTask, resourcePool ));
                }

    return ifail;
}
}


int tm_AwEPATryOut_create_resource_pool_adhoc_signoff(EPM_action_message_t msg)
{
                int ifail = ITK_ok;
                tag_t tRootTask = NULLTAG;
                ITK_CALL1(EPM_ask_root_task(msg.task, &tRootTask));
                int no;
                tag_t *tSignoffs;
                tag_t *members;
                tag_t tTask = msg.task;
                int n=0;
                int i;
                char *role=NULL;
                char *group=NULL;
        char *pcArgVal=NULL;
        char *pcArgName=NULL;
        char *arg=NULL;
        char *epaplant="CVBU JSR";
        char *epaplant1=NULL;
        if (msg.action == EPM_start_action  && msg.proposed_state == EPM_started)
        {

        int count=0;
        tag_t *attachments=NULLTAG;
        tag_t objTag=NULLTAG;
        char  *type=NULL;
        ITK_CALL1(EPM_ask_attachments (tRootTask,EPM_target_attachment,&count,&attachments));
        printf("\n No of attachments:%d",count);

        if(count>0)
        {
          objTag=attachments[0];
          ITK_CALL1(AOM_ask_value_string(objTag,"object_type",&type));
          if(tc_strcmp(type,"T5_EPARevision")==0)
          ITK_CALL1(AOM_ask_value_string(objTag,"t5_EpaPlantA",&epaplant));
        }
                int iNoOfArgs = TC_number_of_arguments(msg.arguments);
        if (iNoOfArgs >= 1)
                {
            for (i = 0; i < iNoOfArgs; i++)
                        {
                arg = TC_next_argument(msg.arguments);
                ITK_ask_argument_named_value((char*) arg, &pcArgName, &pcArgVal);
                if ((pcArgName != NULL))
                                {
                    if (tc_strcmp(pcArgName, "role") == 0)
                                        {
                        if (pcArgVal != NULL)
                                                {
                        role = (char*) MEM_alloc((strlen(pcArgVal) + 5) * sizeof (char));
                        printf("\n %s",epaplant);
                        if(tc_strcmp(epaplant,"CVBU PUNE")==0)
                        {
                        tc_strcpy(role, "PNE_");
                        }
                        else if(tc_strcmp(epaplant,"CVBU JSR")==0)
                        {
                        tc_strcpy(role, "JSR_");
                        }
                        else if(tc_strcmp(epaplant,"CVBU PNR")==0)
                        {
                        tc_strcpy(role, "PNR_");
                        }
                        else if(tc_strcmp(epaplant,"CVBU LKO")==0)
                        {
                        tc_strcpy(role,"LKO_");
                        }
                        else if(tc_strcmp(epaplant,"DHARWAD")==0)
                        {
                        tc_strcpy(role,"DWD_");
                        }
                        tc_strcat(role, pcArgVal);
                        }
                                        }
                        else if (tc_strcmp(pcArgName, "group") == 0)
                                                {
                        if (pcArgVal != NULL)
                                                {
                        group = (char*) MEM_alloc((strlen(pcArgVal) + 3) * sizeof (char));
                        tc_strcpy(group, pcArgVal);
                        tc_strcat(group, "++");
                        }
                                                }
                  }

                                printf("\n %d pcArgName==%s,pcArgVal==%s",i,pcArgName,pcArgVal);fflush(stdout);

                                }
                        }
                                 printf("\n Role==%s group===%s",role,group);fflush(stdout);
                ITK_CALL1(SA_find_groupmember_by_rolename (role,group,NULL,&no,&members));
                                int j;
                                const char*  signoff_required="";
                                for(j=0;j<no;j++)
                                {
                                        ITK_CALL1( EPM_create_adhoc_signoff_with_requirement(tTask, members[j], signoff_required,&n, &tSignoffs));
                                 // ITK_CALL1( EPM_create_adhoc_signoff(tTask, members[j], &n, &tSignoffs));
                                }
                                ITK_CALL1( EPM_set_adhoc_signoff_selection_done(tTask, TRUE));
        }     // if (msg.action == EPM_start_action  && msg.proposed_state == EPM_started) loop closed
    return ifail;
}


extern EPM_decision_t DLLAPI Epa_Chk_Validation (EPM_rule_message_t msg)
{
        char *username =NULL;
        char *dmlTaskNo = NULL;
        char *parent_name =NULL;
        char *class_name = NULL;
        char *TempTaskId = NULL;
        char *arg = NULL;
        char *pcArgName = NULL;
        char *pcArgVal= NULL;
        char *PropValue= NULL;
        char *epadec= NULL;
        char *DStatus =NULL;
        char *Userinfo1Dup =NULL;
        char *Userinfo1 =NULL;
        char *Userinfo2Dup =NULL;
        char *Userinfo2 =NULL;
        char *Userinfo3Dup =NULL;
        char *Userinfo3 =NULL;
        char *Userinfo4Dup =NULL;
        char *Userinfo4 =NULL;
        char *qry_entries[1] = {"SYSCD"};
        char *qry_values[1] = {"*"};
        char *CurrentTask= NULL;
        char *PdcaNumberDup= NULL;
        char *PdcaNumber= NULL;
        char *DocNameDup= NULL;
        char *DocName= NULL;
        char *AQSt1PrtAvalDateForTrailStr= NULL;
        tag_t class_id=NULLTAG;
        tag_t rootTask= NULLTAG;
        tag_t DML_tag= NULLTAG;
        tag_t *attachments= NULLTAG;
        tag_t DMLTaskTag= NULLTAG;
        tag_t DMLRevTag= NULLTAG;
        tag_t PdcaqryTag= NULLTAG;
        tag_t *PdcaCntrlObjectTag= NULLTAG;
        tag_t relation_type= NULLTAG;
        tag_t *pdca_objects= NULLTAG;
        date_t AQSt1PrtAvalDateForTrail= NULLDATE;

        EPM_decision_t decision;
        int status = ITK_ok;
        int EPAUpdateNotAllow=0;
        int ifail=0;
        int n_entries = 1;
        int n_pdcattchs = 0;
        int i = 0;
        int FileFoundflag = 0;
        int noAttachment = 0;
        decision = EPM_go;


        ITK_CALL1(POM_get_user_id (&username));
            printf("\n Inside the Epa_Chk_Validation Session User is : %s \n",username); fflush(stdout);

        if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
        {
                ITK_CALL1(EPM_ask_root_task(msg.task,&rootTask));
                printf("\n Inside the Epa_Chk_Validation ...\n");fflush(stdout);

                ITK_CALL1(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
                printf("\n Epa_Chk_Validation- CurrentTask: %s \n",CurrentTask);fflush(stdout);

                ITK_CALL1(AOM_ask_value_string(rootTask,"object_name",&parent_name));
                printf("\n Epa_Chk_Validation- Parent Name: %s \n",parent_name);fflush(stdout);

                ITK_CALL1(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
                printf("\n Epa_Chk_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);

                if(noAttachment > 0)
                {
                        printf("\n Inside for --Epa_Chk_Validation- Target Attachment:%d \n",noAttachment);fflush(stdout);
                        DMLTaskTag = attachments[0];
                        AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo);
                        printf("\n Epa_Chk_Validation- EPA No: [%s] \n", dmlTaskNo);fflush(stdout); //getting dml number here
                        ITEM_find_item(dmlTaskNo, &DML_tag);
                        if (DML_tag != NULLTAG)
                        {
                                printf("\n DML tag is not null for Epa_Chk_Validation- DML No: [%s] \n", dmlTaskNo);fflush(stdout);
                                ITEM_ask_latest_rev(DML_tag, &DMLRevTag);
                                ITK_CALL1(POM_class_of_instance(DMLRevTag,&class_id));
                                ITK_CALL1(POM_name_of_class(class_id,&class_name));
                                printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);
                                if(tc_strcmp(class_name,"T5_EPARevision")==0)
                                {
                                        TempTaskId = (char*) MEM_alloc((strlen(dmlTaskNo) + 10) * sizeof (char));
                                        tc_strcpy(TempTaskId,dmlTaskNo);
                                        tc_strcat(TempTaskId,"*");
                                        int iNoOfArgs = TC_number_of_arguments(msg.arguments);
                                        if (iNoOfArgs >= 1)
                                        {
                                                for (i = 0; i < iNoOfArgs; i++)
                                                {
                                                        arg = TC_next_argument(msg.arguments);
                                                        ITK_ask_argument_named_value((char*) arg, &pcArgName, &pcArgVal);
                                                        if ((pcArgName != NULL))
                                                        {
                                                                if (tc_strcmp(pcArgName, "property") == 0)
                                                                {
                                                                        if (pcArgVal != NULL)
                                                                        {
                                                                                PropValue = (char*) MEM_alloc((strlen(pcArgVal) + 10) * sizeof (char));
                                                                                tc_strcpy(PropValue, pcArgVal);
                                                                                printf("\nAssignmentName :[%s]",PropValue);fflush(stdout);
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                        EPAUpdateNotAllow = 0;
                                        //AOM_ask_value_date(DMLRevTag,PropValue,&AQSt1PrtAvalDateForTrail);
                                        AOM_UIF_ask_value(DMLRevTag,PropValue,&AQSt1PrtAvalDateForTrailStr);
                                        //AOM_UIF
                                        printf("\n AQSt1PrtAvalDateForTrailStr :[%s]",AQSt1PrtAvalDateForTrailStr);fflush(stdout);
                                        if(AQSt1PrtAvalDateForTrailStr!=NULL && tc_strlen(AQSt1PrtAvalDateForTrailStr)>0)
                                        {
                                                EPAUpdateNotAllow = 0;
                                        }
//                                      if(DATE_IS_NULL(AQSt1PrtAvalDateForTrail) == 0)
//                                      {
//                                              EPAUpdateNotAllow=0;
//                                      }
                                        else
                                        {
                                                EPAUpdateNotAllow++;
                                        }
                                        //printf("\nepadec :[%s]",epadec);fflush(stdout);

                                        printf("\n  EPAUpdateNotAllow is:[%d]\n",EPAUpdateNotAllow);fflush(stdout);
                                        if(EPAUpdateNotAllow>0)
                                        {
                                                EMH_clear_errors();
                                                EMH_store_error_s3(EMH_severity_error,ITK_err,PropValue,"Has null value","Pleasde update this property of EPA Revisio;");
                                                //return ITK_err;
                                                //EMH_store_error_s1(EMH_severity_error,ITK_err, "EPA Revison Property has blank value, Please fill the value.");
                                                decision = EPM_nogo;
                                                return decision;
                                        }

                                }
                                ///DMLRevTag ----> EPA Revision Object....
                        }
                }
        }
        return decision;
}

/*
extern DLLAPI int tm_AwEPATryOut_action_handler(EPM_action_message_t message)
{
                int count,
        n_attachments = 0;
                tag_t *attachments = NULL, group = NULLTAG,job = NULLTAG,resourcePool = NULLTAG,role = NULLTAG, root_task = NULLTAG,signoff = NULLTAG,*unassigned_profiles = NULL;

    ECHO("tm_AwEPATryOut_action_handler\n");

    ITK_CALL(EPM_ask_root_task( message.task, &root_task));
    ECHO("  root_task = %d\n", root_task);

    ITK_CALL(EPM_ask_attachments(root_task, EPM_target_attachment,
        &n_attachments, &attachments));
    if (n_attachments == 0) return 1;  // fail

    ITK_CALL(AOM_ask_group(attachments[0], &group));
    ECHO("  group = %d\n", group);

    if (attachments) MEM_free(attachments);

    ITK_CALL(SA_ask_group_default_role(group, &role) );
    ECHO("  role = %d\n", role);

    ITK_CALL(EPM_get_resource_pool(group, role, FALSE, &resourcePool));
    ECHO("  resourcePool = %d\n", resourcePool);

    ITK_CALL(EPM_ask_job(message.task, &job));
    ECHO("  job = %d\n", job);

    ITK_CALL(EPM_ask_unassigned_profiles(job, message.task, &count,
        &unassigned_profiles));
    ECHO("  count = %d\n", count);
    if (count == 0) return 1;  // fail

    ITK_CALL(EPM_create_profile_signoff(message.task, resourcePool,
        unassigned_profiles[0], &signoff));
    ECHO("  signoff = %d\n", signoff);

    if (unassigned_profiles) MEM_free(unassigned_profiles);

    ECHO("  Done returning ITK_ok\n");

    return ITK_ok;
}
*/

int tm_EPATryOut_SendMail(EPM_action_message_t msg)
{
                int ifail = ITK_ok;
                tag_t resourcePool = NULLTAG;
        tag_t tRootTask = NULLTAG;
        ITK_CALL1(EPM_ask_root_task(msg.task, &tRootTask));
                int no;
        tag_t *tSignoffs;
        tag_t *members;
        tag_t tTask = msg.task;
        int n=0;
        int i;
                int j;
        
int val_count=NULL;
tag_t *prop_values=NULLTAG;
char *prop_val_name=NULL;
        char *role=NULL;
                char *group=NULL;
        char *pcArgVal=NULL;
        char *pcArgName=NULL;
        char *arg=NULL;
        char *epaplant=NULL;
        char *epaplant1=NULL;
            tag_t grouptag=NULLTAG;
        tag_t roletag=NULLTAG;
            tag_t user_tag=NULLTAG;
        tag_t group_tag=NULLTAG;
        tag_t envelope=NULLTAG;
        tag_t usertag=NULLTAG;
	tag_t *recievers= NULLTAG;
	int countenvelop=0;
        char env_subject[300] = {'\0'};
	char env_body[90000]= {'\0'};

                printf("==========================================New mail Sent - Sanjay========================================%d",msg.action);fflush(stdout);
        if (msg.action == EPM_start_action  && msg.proposed_state == EPM_started)
        {

        int count=0;
        tag_t *attachments=NULLTAG;
        tag_t objTag=NULLTAG;
        char *type=NULL;
        char *mode=NULL;
        char *ECR_Number=NULL;
        char *Synopsis=NULL;
        char *sub_notification=NULL;
        ITK_CALL1(EPM_ask_attachments (tRootTask,EPM_target_attachment,&count,&attachments));
        printf("\n No of attachments:%d",count);fflush(stdout);
        if(count>0)
        {
           objTag=attachments[0];
           ITK_CALL1(AOM_ask_value_string(objTag,"object_type",&type));
           if(tc_strcmp(type,"T5_EPARevision")==0)
           ITK_CALL1(AOM_ask_value_string(objTag,"t5_EpaPlantA",&epaplant));

           ITK_CALL1(AOM_ask_value_string(objTag,"item_id",&ECR_Number));
           ITK_CALL1(AOM_ask_value_string(objTag,"object_name",&Synopsis));
           ITK_CALL1(AOM_ask_value_string(objTag,"object_string",&sub_notification));
       	ITK_CALL1(AOM_ask_value_tags(objTag,"fnd0StartedWorkflowTasks",&val_count,&prop_values));
	printf("\n val_count:%d",val_count);fflush(stdout);
	//	ITK_CALL1(WSOM_ask_name2(prop_values[1],&prop_val_name));




		printf("\n prop_val_name:%s",prop_val_name);fflush(stdout);
        }



           int iNoOfArgs = TC_number_of_arguments(msg.arguments);



            if (iNoOfArgs >= 1)
                        {
            for (i = 0; i < iNoOfArgs; i++)
                        {
                arg = TC_next_argument(msg.arguments);
                ITK_ask_argument_named_value((char*) arg, &pcArgName, &pcArgVal);
                if ((pcArgName != NULL))
                                {
                    if(tc_strcmp(pcArgName, "role") == 0)
                                        {
                        if (pcArgVal != NULL)
                                                {
                                                         role = (char*) MEM_alloc((strlen(pcArgVal) + 5) * sizeof (char));
                                                         printf("\n %s",epaplant);
                                                         if(tc_strcmp(epaplant,"CVBU PUNE")==0)
                                                         {
                                                         tc_strcpy(role, "PNE_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU JSR")==0)
                                                         {
                                                         tc_strcpy(role, "JSR_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU PNR")==0)
                                                         {
                                                         tc_strcpy(role, "PNR_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"CVBU LKO")==0)
                                                         {
                                                         tc_strcpy(role,"LKO_");
                                                         }
                                                         else if(tc_strcmp(epaplant,"DHARWAD")==0)
                                                         {
                                                         tc_strcpy(role,"DWD_");
                                                         }

                                                         tc_strcat(role, pcArgVal);
                                                 }
                        }
                                            else if (tc_strcmp(pcArgName, "group") == 0)
                                                {
                                                        if (pcArgVal != NULL)
                                                        {
                                                          group = (char*) MEM_alloc((strlen(pcArgVal) + 3) * sizeof (char));
                                                      tc_strcpy(group, pcArgVal);
                                                          //tc_strcat(group, "++");
                                                        }
                                                }
                                        /*
                                                else if (tc_strcmp(pcArgName, "mode") == 0)
                                                {
                                                        if (pcArgVal != NULL)
                                                        {
                                                          mode = (char*) MEM_alloc((strlen(pcArgVal) + 1) * sizeof (char));
                                                           tc_strcpy(mode, pcArgVal);
                                                        }
                                                }
                                                */
                    }                 //if ((pcArgName != NULL)) lopp closed

                         


                                printf("\n %d pcArgName==%s,pcArgVal==%s",i,pcArgName,pcArgVal);fflush(stdout);

                                }                    //for (i = 0; i < iNoOfArgs; i++) loop closed
                        }   //if (iNoOfArgs >= 1) loop closed

                            printf("\n Role==%s group===%s",role,group);fflush(stdout);

                                ITK_CALL1(SA_find_groupmember_by_rolename (role,group,NULL,&no,&members));
/*                                if(no>0)
                                {
                                ITK_CALL1(SA_ask_groupmember_user(members[0],&usertag));
                                }

*/

                ITK_CALL1(SA_find_group(group,&grouptag));
                ITK_CALL1(SA_find_role2(role,&roletag));


                                //for(j=0;j<count;j++)
                                {
                                

					        tc_strcpy(env_subject,"Notification Mail to complete assignment:-");
                                                tc_strcat(env_subject,sub_notification);
                                                tc_strcpy(env_body,"Hi,\n");
                                                tc_strcat(env_body,"Below assigment has been assigned \n");
                                                tc_strcat(env_body,"EPA NO:-");
                                                tc_strcat(env_body,ECR_Number);
                                                tc_strcat(env_body,"\nSynopsis:-");
                                                tc_strcat(env_body,Synopsis);
                                                tc_strcat(env_body,"\n\nRegards,\nPLM Team ");


                                        ITK_CALL1(MAIL_create_envelope(env_subject,env_body,&envelope));
                                	if(envelope != NULLTAG)
                                        {
                                                
                                        ITK_CALL1(MAIL_initialize_envelope2(envelope,env_subject,env_body));
					for(j=0;j<no;j++)
					{
					ITK_CALL1(SA_ask_groupmember_user(members[j],&usertag));
                                        ITK_CALL1(MAIL_add_envelope_receiver(envelope,usertag));
					}

                                        ITK_CALL1(MAIL_add_external_receiver(envelope, MAIL_send_cc,"sanjayj1.ttl@tatamotors.com"));
                                        ITK_CALL1(MAIL_add_external_receiver(envelope, MAIL_send_cc,"ketanb.ttl@tatamotors.com"));
                                        ITK_CALL1(MAIL_add_external_receiver(envelope, MAIL_send_cc,"dhrubak.ttl@tatamotors.com"));
					
					//ITK_CALL1(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
                                        
					//printf("\n countenvelop %d\n",countenvelop);fflush(stdout);
                                        ITK_CALL1(MAIL_send_envelope(envelope));
                                        
                                        printf("\n Mail Send Successfully");
                                        }
                                        

                                }

    return ifail;
}
}
extern DLLAPI int tm_AwEPATryOut_register_action_handler(int *decision, va_list args)
{
    *decision = ALL_CUSTOMIZATIONS;
//     ECHO("tm_AwEPATryOut_register_action_handler\n");

    ITK_CALL1(EPM_register_action_handler("tm_AwEPATryOut_create_resource_pool_adhoc_signoff","Placement: Assign Task Action of select-signoff-team task",tm_AwEPATryOut_create_resource_pool_adhoc_signoff));
    ITK_CALL1(EPM_register_action_handler("tm_AwEPATryOut_assign_responsible_party","Placement: Assign Task",tm_AwEPATryOut_assign_responsible_party));
    ITK_CALL1(EPM_register_rule_handler ("tm_EPANullValueCheck","Check Validation for EPA", (EPM_rule_handler_t) Epa_Chk_Validation))
    ITK_CALL1(EPM_register_action_handler("tm_EPATryOut_SendMail","",tm_EPATryOut_SendMail));
    //printf("\n tm_EPATryOut_SendMail Handler register sucessfully=======================================================================================================");
    return ITK_ok;
}


extern DLLAPI int tm_AwEPATryOut_register_callbacks ()
{
//     ECHO("tm_AwEPATryOut_register_callbacks\n");

    ITK_CALL1(CUSTOM_register_exit ( "tm_AwEPATryOut", "USER_init_module",(CUSTOM_EXIT_ftn_t) tm_AwEPATryOut_register_action_handler ));


    return ITK_ok;
}



