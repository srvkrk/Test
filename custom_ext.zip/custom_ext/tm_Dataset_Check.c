#include "TMLLibrary_server_exits.h"


EPM_decision_t tm_Dataset_Check(EPM_rule_message_t msg)
{
	EPM_decision_t decision = EPM_go;
	tag_t  roottask			                      = NULLTAG;
	tag_t  Rev   			                      = NULLTAG;
	tag_t  *Attachments	                          = NULLTAG;
	tag_t	DmlRev_tag		                      = NULLTAG;
	tag_t	Reftag		                          = NULLTAG;
	tag_t   sec_obj                               = NULLTAG;
	tag_t*	secondary_objects	                  = NULLTAG;							              
	char*       Obj_N                   = NULL;
	char*       Obj_S                   = NULL;
	int no_attach                                 = 0;
	int error_code			                      = ITK_ok;
	int i           		                      = ITK_ok;
	int jm           		                      = ITK_ok;
    int	ifail                 		        	  = ITK_ok;
	int   count                                   = 0;
	tag_t	objTypTag			=NULLTAG;
	char*   ObjTyp= NULL;

	printf("\n tm_Dataset_Check Function started...");fflush(stdout);
	TC_write_syslog("\n tm_Dataset_Check Function started...");

	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
    if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &Attachments)!=ITK_ok)PrintErrorStack();
	printf("\tm_part_type_Action:No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);

	if(no_attach >0)
	{
		for(jm=0;jm<no_attach;jm++)
		{
			Rev=Attachments[jm];
			if(TCTYPE_ask_object_type(Rev,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n : Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				ifail = ITEM_ask_latest_rev(Rev,&DmlRev_tag); 
				ifail = GRM_find_relation_type("IMAN_reference",&Reftag);
				ifail = GRM_list_secondary_objects_only(DmlRev_tag,Reftag,&count,&secondary_objects);
				printf("\n :Dataset Count is : %d\n ",count);fflush(stdout);

				for (i=0; i< count; i++)
				{
					sec_obj=secondary_objects[i];

					ifail=AOM_UIF_ask_value(sec_obj,"object_name",&Obj_N);
					printf("\n :object_name : %s\n ",Obj_N);fflush(stdout);

					ifail=AOM_UIF_ask_value(sec_obj,"object_string",&Obj_S);
					printf("\n :object_string : %s\n ",Obj_S);fflush(stdout);

					if((tc_strstr(Obj_S,"_DML_Release_Letter_")!=NULL) || (tc_strstr (Obj_S,"_ERCdmlreport_")!=NULL))
					{
						ifail=AOM_UIF_ask_value(sec_obj,"object_name",&Obj_N);
						printf("\n :object_name : %s\n ",Obj_N);fflush(stdout);
						
						ifail=AOM_UIF_ask_value(sec_obj,"object_string",&Obj_S);
						printf("\n :object_string : %s\n ",Obj_S);fflush(stdout);
						printf("*********Dataset is available**********\n");
						
						decision = EPM_go;
						return decision;
					}
					else
					{
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"Please attach below Dataset.\n _DML_Release_Letter\n _ERCdmlreport_\n Above dataset is missing Kindly attach and procced.\n");
						return ITK_err;

						printf("*********_DML_Release_Letter and _ERCdmlreport_ Dataset is not available**********\n");

						decision = EPM_nogo;
						return decision;
					}
				}
			}
	   }

	   /*  if(Obj_name){MEM_free(Obj_name);}
		 if(Obj_N){MEM_free(Obj_N);}
	   if(Obj_S){MEM_free(Obj_S);}*/
	}
	printf("\n tm_Dataset_Check Function end...");fflush(stdout);
	TC_write_syslog("\n tm_Dataset_Check Function end...");
	return decision;
}