/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Relation Between Module And SubModule Details After Reading Data From Input File 
*  File Name    :   tm_ModuleToSubModuleRelCreate.c
*  Created on   :   Jun 12th, 2024
*  Usage        :   tm_ModuleToSubModuleRelCreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* Module_Str = NULL;
	char* Module_StrDup = NULL;
	char* SubModule_Str = NULL;
	char* SubModule_StrDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tObjCreate_Input = NULLTAG;
	tag_t tObj_Type = NULLTAG;
	tag_t new_object = NULLTAG;
	tag_t tSubModuleqryobj = NULLTAG;
	int n_submoduleentries = 1;
	int n_submoduleitemobj_found = 0;
	tag_t* tsubmoduleitemobj_results = NULLTAG;
	tag_t tmod_rev = NULLTAG;
	tag_t tsubmodule_rev = NULLTAG;
	tag_t relation_foraward_type = NULLTAG;
	tag_t relation_backward_type = NULLTAG;
	tag_t relation_forward_found = NULLTAG;
	tag_t relation_backward_found = NULLTAG;
	tag_t relation_back_new = NULLTAG;
	tag_t relation_for_new = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			Module_Str=strtok(Buffer,"^");
			SubModule_Str=strtok(NULL,"^");
			
            if(Module_Str!=NULL)tc_strdup(Module_Str,&Module_StrDup);
            if(SubModule_Str!=NULL)tc_strdup(SubModule_Str,&SubModule_StrDup);
			if(Module_StrDup!=NULL)trimwhitespace(Module_StrDup);
			if(SubModule_StrDup!=NULL)trimwhitespace(SubModule_StrDup);
			
			printf(" Module(Module_StrDup): [%s]\n",Module_StrDup);
			printf(" SubModule(SubModule_StrDup): [%s]\n",SubModule_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryModule",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryModule] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {Module_StrDup};
				//char *cValues[1]  = {"POWERTRAIN"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryModule] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" [SubModuleLibraryModule] Revision Exist So Continue For Relation Creation with SubModule Library..!!\n");fflush(stdout);
				    tmod_rev = titemobj_results[0];
				    printf("\n ~~~~~~~~ R E L A T I O N   C R E A T I O N    S T A R T ~~~~~~~~\n");fflush(stdout); 
					if(tmod_rev != NULLTAG)
					{
						ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tSubModuleqryobj));
						if(tSubModuleqryobj != NULLTAG)
						{
							printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
							char *cSubModuleEntries[1]  = {"ID"};
							char *cSubModuleValues[1]  = {SubModule_StrDup};
							//char *cAggrValues[1]  = {"POWERTRAIN"};
							ITK_CALL(QRY_execute(tSubModuleqryobj, n_submoduleentries, cSubModuleEntries, cSubModuleValues, &n_submoduleitemobj_found, &tsubmoduleitemobj_results));
							printf("\n -----------------------------------------------\n");fflush(stdout);
							printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_submoduleitemobj_found);fflush(stdout);
							printf("\n -----------------------------------------------\n");fflush(stdout);
                            if(n_submoduleitemobj_found > 0)
				            {
								tsubmodule_rev = tsubmoduleitemobj_results[0];
								ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel", &relation_foraward_type)); //Module To SubModule Relation
								ITK_CALL(GRM_find_relation_type("T5_Submdlbsubmodrel", &relation_backward_type)); //SubModule To Module Relation
								ITK_CALL(GRM_find_relation(tmod_rev, tsubmodule_rev, relation_foraward_type ,&relation_forward_found));
								ITK_CALL(GRM_find_relation(tsubmodule_rev, tmod_rev, relation_backward_type ,&relation_backward_found));
								if(relation_forward_found)
								{
									printf("\n Forward Relation Already Exist with Module and SubModule Revision \n");fflush(stdout);
								}
								else
								{
									ITK_CALL(GRM_create_relation(tmod_rev, tsubmodule_rev, relation_foraward_type, NULLTAG, &relation_for_new));
									ITK_CALL(GRM_save_relation(relation_for_new));
									printf("\n Module and SubModule Revision Relation Created");fflush(stdout);
								}
								if(relation_backward_found)
								{
									printf("\n Backward Relation Already Exist with SubModule Revision And Module\n");fflush(stdout);
								}
								else
								{
									ITK_CALL(GRM_create_relation(tsubmodule_rev, tmod_rev, relation_backward_type, NULLTAG, &relation_back_new));
									ITK_CALL(GRM_save_relation(relation_back_new));
									printf("\n SubModule And Module Revision Relation Created");fflush(stdout);
								}
							}
                            else
                            {
								printf(" SubModule Library Details Not Found..!!\n");fflush(stdout);
							}								
						}
						else
						{
						  printf(" Query Tag [SubModuleLibraryDetails] NULL..!!\n");fflush(stdout);
						}		
					}
					else
					{
						printf(" Module Revision Input Tag NULL..!!\n");fflush(stdout);
					}
					printf("\n ~~~~~~~~ R E L A T I O N  C R E A T I O N   E N D ~~~~~~~~\n");fflush(stdout); 
				}
                else
                {
				   printf(" Module Not Found..!!");fflush(stdout);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryModule] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			} 
            if(tsubmoduleitemobj_results)
			{
			   MEM_free(tsubmoduleitemobj_results);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ModuleToSubModuleRelCreate.c
* // ./linkitk -o tm_ModuleToSubModuleRelCreate tm_ModuleToSubModuleRelCreate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleToSubModuleRelCreate/tm_ModuleToSubModuleRelCreate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleToSubModuleRelCreate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleToSubModuleRelCreate/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleToSubModuleRelCreate/usage.txt .
* // ./tm_ModuleToSubModuleRelCreate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ModuleToSubModuleRelCreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/
