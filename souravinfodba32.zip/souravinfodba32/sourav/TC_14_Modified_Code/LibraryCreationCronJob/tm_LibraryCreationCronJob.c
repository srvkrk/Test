/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   MCC
*  Description  :   Library Creation Cron Job
*  File Name    :   tm_LibraryCreationCronJob.c
*  Created on   :   Nov 25th, 2024
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/11/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_ModuleAddrStatus(char* InpModAddr)
{
	
	trimwhitespace(InpModAddr);
	char* ResModAdd = NULL;
	char* Info1 = NULL;
	char* Info2 = NULL;
	char* Info3 = NULL;
	char* Info4 = NULL;
	char* Info5 = NULL;
	char* Info6 = NULL;
	char* Info7 = NULL;
	char* Info8 = NULL;
	char* Info9 = NULL;
	char* Info10 = NULL;
	char* Fundesresponse = NULL;
	Fundesresponse = (char *) malloc(2000*sizeof(char ));
	printf("\n Control Object Check Started..!!\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	printf("\n Control Object Query Tag Found Successfully...!!\n");
	char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cPathValues[4]  = {"MCCInvalidAdd","MCCInvalidAddSub","MCCInvalidAddCntObj","0"};
	ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_path_ctrlobj_found > 0)
	{
		printf("\n Control Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &Info1));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &Info2));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo3", &Info3));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo4", &Info4));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo5", &Info5));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo6", &Info6));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo7", &Info7));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo8", &Info8));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo9", &Info9));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_userinfo10", &Info10));
		tc_strcpy(Fundesresponse,Info1);
		tc_strcat(Fundesresponse,Info2);
		tc_strcat(Fundesresponse,Info3);
		tc_strcat(Fundesresponse,Info4);
		tc_strcat(Fundesresponse,Info5);
		tc_strcat(Fundesresponse,Info6);
		tc_strcat(Fundesresponse,Info7);
		tc_strcat(Fundesresponse,Info8);
		tc_strcat(Fundesresponse,Info9);
		tc_strcat(Fundesresponse,Info10);
		printf("\n Concatinated Module_Address: --------> [%s]\n",Fundesresponse);fflush(stdout);
		if(tc_strstr(Fundesresponse,InpModAddr) != NULL)
		{
			tc_strdup("INVALID",&ResModAdd);
		}
		else
		{
			tc_strdup("VALID",&ResModAdd);
		}
	}
	else
	{
		tc_strdup("VALID",&ResModAdd);
		printf("\nControl Object Not Found So, Taking As Valid Case...");fflush(stdout);
	}
	
	return ResModAdd;	
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

char* TC_ERC_DTReleased(tag_t PartRev_tag)
{
	int	status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *Dt_Rlzd = NULL;
	char *Dt_RlzdDup = NULL;
	int j = 0;
	
    ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));
    for(j=0;j<Stat_Cnt;j++)
	{
		Stat_tag = Stat_list[j];
		ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
		printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
        if((tc_strstr(RlzStatusName,"T5_LcsRlzd") != NULL) || (tc_strstr(RlzStatusName,"T5_LcsErcRlzd") != NULL))
		{
			ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
			printf(" \n ERC-Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
             
		}
	}
	if(tc_strlen(Dt_Rlzd)>0)
	{
	   tc_strdup(Dt_Rlzd,&Dt_RlzdDup);
	}
	else
	{
	   tc_strdup(" ",&Dt_RlzdDup);
	}
	return Dt_RlzdDup;
}

char* TC_ERC_DTCreated(tag_t PartRev_tag)
{
	int	status = 0;
	char *Dt_Created = NULL;
	char *Dt_CreatedDup = NULL;
	
    ITK_CALL(AOM_UIF_ask_value(PartRev_tag, "creation_date", &Dt_Created));
	if(tc_strlen(Dt_Created)>0)
	{
	   tc_strdup(Dt_Created,&Dt_CreatedDup);
	}
	else
	{
	   tc_strdup(" ",&Dt_CreatedDup);
	}
	return Dt_CreatedDup;
}

char* TC_BOMLine_DTCreated(char* PSrc,char* PRevSeqSrc)
{
	trimwhitespace(PSrc);
	trimwhitespace(PRevSeqSrc);
	tag_t tcrQryobj = NULLTAG;
	int ncr_entries = 2;
	int ncr_Qryobj_found = 0;
	tag_t* tcrQryobj_results = NULLTAG;
	int s = 0;
	char *Dt_Created = NULL;
	char *Dt_CreatedDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PSrc);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrc);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tcrQryobj));
    if(tcrQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *CREntries[2]  = {"Revision","ID"};
		char *CRValues[2]  = {PRevSeqSrc,PSrc};
		ITK_CALL(QRY_execute(tcrQryobj, ncr_entries, CREntries, CRValues, &ncr_Qryobj_found, &tcrQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",ncr_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(ncr_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (s = 0; s < ncr_Qryobj_found; s++)
			{
				tag_t crrev_tags_found = NULLTAG;
				crrev_tags_found = tcrQryobj_results[s];
				if(crrev_tags_found != NULLTAG)
				{	
					ITK_CALL(AOM_UIF_ask_value(crrev_tags_found, "creation_date", &Dt_Created));
				}
				else
				{
					printf("\nSorry! Revision Tag Not Found..!!\n");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\nSorry! Entered Revision Not Found..!!\n");fflush(stdout);
		}
		
	}
	else
	{
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
	}
	if(tc_strlen(Dt_Created)>0)
	{
	   tc_strdup(Dt_Created,&Dt_CreatedDup);
	}
	else
	{
	   tc_strdup(" ",&Dt_CreatedDup);
	}
	
	return Dt_CreatedDup;	
}

char* TC_BOMLine_DTReleased(char* PartSrc,char* PartRevSeqSrc)
{
	trimwhitespace(PartSrc);
	trimwhitespace(PartRevSeqSrc);
	tag_t trlQryobj = NULLTAG;
	int nrl_entries = 2;
	int nrl_Qryobj_found = 0;
	tag_t* trlQryobj_results = NULLTAG;
	int h = 0;
	int	status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *Dt_Rlzd = NULL;
	char *Dt_RlzdDup = NULL;
	int t = 0;
	
	printf("\n Searched Part Number Value: [%s]\n", PartSrc);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PartRevSeqSrc);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&trlQryobj));
    if(trlQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *RLEntries[2]  = {"Revision","ID"};
		char *RLValues[2]  = {PartRevSeqSrc,PartSrc};
		ITK_CALL(QRY_execute(trlQryobj, nrl_entries, RLEntries, RLValues, &nrl_Qryobj_found, &trlQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nrl_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nrl_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (h = 0; h < nrl_Qryobj_found; h++)
			{
				tag_t rlrev_tags_found = NULLTAG;
				rlrev_tags_found = trlQryobj_results[h];
				ITK_CALL(WSOM_ask_release_status_list(rlrev_tags_found,&Stat_Cnt,&Stat_list));
				for(t = 0; t < Stat_Cnt; t++)
				{
					Stat_tag = Stat_list[t];
					ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
					printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
					if((tc_strstr(RlzStatusName,"T5_LcsRlzd") != NULL) || (tc_strstr(RlzStatusName,"T5_LcsErcRlzd") != NULL))
					{
						ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
						printf(" \n ERC-Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);	 
					}
				}
			}
		}
		else
		{
			printf("\nSorry! Entered Revision Not Found..!!\n");fflush(stdout);
		}
		
	}
	else
	{
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
	}
	if(tc_strlen(Dt_Rlzd)>0)
	{
	   tc_strdup(Dt_Rlzd,&Dt_RlzdDup);
	}
	else
	{
	   tc_strdup(" ",&Dt_RlzdDup);
	}
	return Dt_RlzdDup;
}

int bom_sub_child(char* DNo, tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, FILE* FP_TxtOutputReport, FILE* FP_VehLinkOutputReport, FILE* FP_MaxARDROutputReport)
{
	    int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		int cLevel = 0;
		char* cItem_Id = NULL;
		char* cSubAggrGrp = NULL;
		char* cSubAggr = NULL;
		char* cSubModGrp = NULL;
		char* cSubMod = NULL;
		char* cSubModAddress = NULL;
		char* cSubItem_RevSeq = NULL;
		char* cSubItem_Desc = NULL;
		char* cSubItem_Rev = NULL;
		char* cSubItem_Seq = NULL;
		char* cSubPlatform = NULL;
		char* cSubPlatformDup = NULL;
		char* cSubProjCode = NULL;
		char* cSubProjCodeDup = NULL;
		char* cSubArDrStatus = NULL;
		char* cSubArDrStatusDup = NULL;
		char* cSubPartType = NULL;
		char* cSubPartTypeDup = NULL;
		char* cSubType = NULL;
		char* cSubTypeDup = NULL;
		tag_t* tSubChild = NULLTAG;
		char *Module_Address_Status = NULL;
        char *Module_Address_StatusDup = NULL;
		char *Module_Created = NULL;
		char *Module_CreatedDup = NULL;
		char *Module_Rlzd = NULL;
		char *Module_RlzdDup = NULL;
		char *cSubAggrGrpDup = NULL;
		char *cSubAggrDup = NULL;
		char *cSubModGrpDup = NULL;
		char *cSubModDup = NULL;
		
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////  P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
		/////////////////////////////////////////////////////////////////////////////////////////////////////
		char CurDate[100] = "";
		char* CurDateDup = NULL;
		char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
		strftime(CurDate,100,"%d-%b-%Y",&when);
		trimwhitespace(CurDate);
		if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
		tc_strcpy(CurDateFinalDup,CurDateDup);
		printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
		////////////////////////////////////////////////////////////////////////////////////////////////////

	
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	        
	        ITK_CALL(AOM_ask_value_int(tBOM_Sub_Children[j], "bl_level_starting_0", &cLevel));
			printf("\n Part Level: [%d]\n", cLevel);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_AggregateGroup", &cSubAggrGrp));
			if(cSubAggrGrp!=NULL)trimwhitespace(cSubAggrGrp);
			printf("\n Part Aggregate Group Value After Trim: [%s]\n", cSubAggrGrp);fflush(stdout);
			if(tc_strlen(cSubAggrGrp)>0)
			{
				tc_strdup(cSubAggrGrp,&cSubAggrGrpDup);
			}
			else
			{
				tc_strdup(" ",&cSubAggrGrpDup);
				printf("\n Aggregate Group Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Aggregate", &cSubAggr));
			if(cSubAggr!=NULL)trimwhitespace(cSubAggr);
			printf("\n Part Aggregate Value After Trim: [%s]\n", cSubAggr);fflush(stdout);
			if(tc_strlen(cSubAggr)>0)
			{
				tc_strdup(cSubAggr,&cSubAggrDup);
			}
			else
			{
				tc_strdup(" ",&cSubAggrDup);
				printf("\n Aggregate Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Module_Group", &cSubModGrp));
			if(cSubModGrp!=NULL)trimwhitespace(cSubModGrp);
			printf("\n Part Module Group Value After Trim: [%s]\n", cSubModGrp);fflush(stdout);
			if(tc_strlen(cSubModGrp)>0)
			{
				tc_strdup(cSubModGrp,&cSubModGrpDup);
			}
			else
			{
				tc_strdup(" ",&cSubModGrpDup);
				printf("\n Module Group Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Module", &cSubMod));
			if(cSubMod!=NULL)trimwhitespace(cSubMod);
			printf("\n Part Module Value After Trim: [%s]\n", cSubMod);fflush(stdout);
			if(tc_strlen(cSubMod)>0)
			{
				tc_strdup(cSubMod,&cSubModDup);
			}
			else
			{
				tc_strdup(" ",&cSubModDup);
				printf("\n Module Value is NULL");fflush(stdout);
			}
			
			cSubModAddress = subString(cItem_Id, 4, 5);
			if(cSubModAddress!=NULL)trimwhitespace(cSubModAddress);
			printf("\n Part Module Address Value: [%s]", cSubModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cSubItem_RevSeq));
			if(cSubItem_RevSeq!=NULL)trimwhitespace(cSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cSubItem_RevSeq);fflush(stdout);
			
			cSubItem_Desc = TC_PartDesc(cItem_Id,cSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", cSubItem_Desc);fflush(stdout);
			
			printf("\n SubFunction: Module Creation Date Find Start");fflush(stdout);
			Module_Created = TC_BOMLine_DTCreated(cItem_Id,cSubItem_RevSeq);
			Module_CreatedDup=strtok(Module_Created," ");
			//tc_strdup(Module_Created,&Module_CreatedDup);
			printf("\n SubFunction:  Module Creation Date Find End");fflush(stdout);
												
			printf("\n SubFunction: Module Released Date Find Start");fflush(stdout);
			Module_Rlzd = TC_BOMLine_DTReleased(cItem_Id,cSubItem_RevSeq);
			Module_RlzdDup=strtok(Module_Rlzd," ");
			//tc_strdup(Module_Rlzd,&Module_RlzdDup);
			printf("\n SubFunction:  Module Released Date Find End");fflush(stdout);
			
			cSubItem_Rev=strtok(cSubItem_RevSeq,";");
			cSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Platform", &cSubPlatform));
			if(tc_strlen(cSubPlatform)>0)
			{
				tc_strdup(cSubPlatform,&cSubPlatformDup);
			}
			else
			{
				tc_strdup(" ",&cSubPlatformDup);
				printf("\n Part Platform Value is NULL");fflush(stdout);
			}
			if(cSubPlatformDup!=NULL)trimwhitespace(cSubPlatformDup);
			printf("\n Part Platform Value After Dup & Trim: [%s]\n", cSubPlatformDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_ProjectCode", &cSubProjCode));
			if(tc_strlen(cSubProjCode)>0)
			{
				tc_strdup(cSubProjCode,&cSubProjCodeDup);
			}
			else
			{
				tc_strdup(" ",&cSubProjCodeDup);
				printf("\n Part Project Code Value is NULL");fflush(stdout);
			}
			if(cSubProjCodeDup!=NULL)trimwhitespace(cSubProjCodeDup);
			printf("\n Part Project Code Value After Dup & Trim: [%s]\n", cSubProjCodeDup);fflush(stdout);
		
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cSubArDrStatus));
			if(tc_strlen(cSubArDrStatus)>0)
			{
				tc_strdup(cSubArDrStatus,&cSubArDrStatusDup);
			}
			else
			{
				tc_strdup(" ",&cSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			if(cSubArDrStatusDup!=NULL)trimwhitespace(cSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cSubPartType));
			if(tc_strlen(cSubPartType)>0)
			{
				tc_strdup(cSubPartType,&cSubPartTypeDup);
			}
			else
			{
				tc_strdup(" ",&cSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			if(cSubPartTypeDup!=NULL)trimwhitespace(cSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cSubPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_object_type", &cSubType));
			if(tc_strlen(cSubType)>0)
			{
				tc_strdup(cSubType,&cSubTypeDup);
			}
			else
			{
				tc_strdup(" ",&cSubTypeDup);
				printf("\n Item Type Value is NULL");fflush(stdout);
			}
			if(cSubTypeDup!=NULL)trimwhitespace(cSubTypeDup);
			printf("\n Item Type Value After Dup & Trim: [%s]", cSubTypeDup);fflush(stdout);
			
			printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
			Module_Address_Status = TC_ModuleAddrStatus(cSubModAddress);
			tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
			printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Count: [%d]", cLevel);
			printf("\nChild_Level DML No: [%s]", DNo);
			printf("\nChild_Level Aggregate Group: [%s]", cSubAggrGrpDup);
			printf("\nChild_Level Aggregate: [%s]", cSubAggrDup);
			printf("\nChild_Level Module Group: [%s]", cSubModGrpDup);
			printf("\nChild_Level Module: [%s]", cSubModDup);
			printf("\nChild_Level Module Address: [%s]", cSubModAddress);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Description: [%s]", cSubItem_Desc);
			printf("\nChild_Level Rev: [%s]", cSubItem_Rev);
			printf("\nChild_Level Seq: [%s]", cSubItem_Seq);
			printf("\nChild_Level Platform: [%s]", cSubPlatformDup);
			printf("\nChild_Level Project Code: [%s]", cSubProjCodeDup);
			printf("\nChild_Level AR/DR: [%s]", cSubArDrStatusDup);
			printf("\nChild_Level Part Type: [%s]", cSubPartTypeDup);
			printf("\nChild_Level Item Type: [%s]", cSubTypeDup);
            printf("\nChild_Level Module_Address Status Check: [%s]", Module_Address_StatusDup);			
			printf("\n-------------------------------------------------------------------------\n");
			
			if(tc_strlen(cSubPartTypeDup)>0)
		    {
				if((tc_strcmp(cSubPartTypeDup,"Module")==0) && (tc_strstr(cSubTypeDup,"Design") != NULL) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
				{
				   fprintf(FP_OutputReport,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DNo,cSubAggrGrp,cSubAggr,cSubModGrp,cSubMod,cSubModAddress,cItem_Id,cSubItem_Desc,cSubItem_Rev,cSubItem_Seq,cSubPlatformDup,cSubProjCodeDup,cSubArDrStatusDup,cSubPartTypeDup,cSubTypeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(FP_OutputReport);
				   fprintf(FP_TxtOutputReport,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",cSubAggrGrpDup,cSubAggrDup,cSubModGrpDup,cSubModDup,cSubModAddress,cItem_Id,cSubItem_Desc,cSubItem_Rev,cSubItem_Seq,cSubPlatformDup,cSubProjCodeDup,cSubArDrStatusDup,cSubPartTypeDup,cSubTypeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(FP_TxtOutputReport);
				   fprintf(FP_VehLinkOutputReport,"%s^%s^%s^%s^\n",cSubModAddress,cItem_Id,cSubItem_Rev,cSubItem_Seq);fflush(FP_VehLinkOutputReport);
                   fprintf(FP_MaxARDROutputReport,"%s,%s,\n",cItem_Id,cSubModAddress);fflush(FP_MaxARDROutputReport);
				}
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if((iNumber_SubChild > 0) && (cLevel<6))
			{
				bom_sub_child(DNo,tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
	return iFail;
}

int TC_VehChild_Details(char* DMLNo,char* Vehicle,char* VehicleRS,char* VehicleRev,char* VehicleSeq,FILE* VehRpt,FILE* VehTxtFile,FILE* VehLinkFile,FILE* VehMaxARDRFile)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	int ctopLevel = 0;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubModAddress = NULL;
	char* ctopSubPlatform = NULL;
	char* ctopSubPlatformDup = NULL;
	char* ctopSubProjCode = NULL;
	char* ctopSubProjCodeDup = NULL;
	char* ctopSubDesGrp = NULL;
	char* ctopSubDesGrpDup = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	char* ctopSubAggrGrp = NULL;
	char* ctopSubAggr = NULL;
	char* ctopSubModGrp = NULL;
	char* ctopSubMod = NULL;
	char* ctopSubType = NULL;
	char* ctopSubTypeDup = NULL;
	PIE_scope_t scope;
    scope = PIE_TEAMCENTER;
	char* ctopSubAggrGrpDup = NULL;
	char* ctopSubAggrDup = NULL;
	char* ctopSubModGrpDup = NULL;
	char* ctopSubModDup = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",scope, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			ITK_CALL(AOM_ask_value_int(t_top_Sub_Child, "bl_level_starting_0", &ctopLevel));
			printf("\n Part Level: [%d]\n", ctopLevel);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			if(ctopSubItem_Id!=NULL)trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_AggregateGroup", &ctopSubAggrGrp));
			if(ctopSubAggrGrp!=NULL)trimwhitespace(ctopSubAggrGrp);
			printf("\n Aggregate Group Value After Trim: [%s]\n", ctopSubAggrGrp);fflush(stdout);
			if(tc_strlen(ctopSubAggrGrp)>0)
			{
				tc_strdup(ctopSubAggrGrp,&ctopSubAggrGrpDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubAggrGrpDup);
				printf("\n Aggregate Group Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Aggregate", &ctopSubAggr));
			if(ctopSubAggr!=NULL)trimwhitespace(ctopSubAggr);
			printf("\n Aggregate Value After Trim: [%s]\n", ctopSubAggr);fflush(stdout);
			if(tc_strlen(ctopSubAggr)>0)
			{
				tc_strdup(ctopSubAggr,&ctopSubAggrDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubAggrDup);
				printf("\n Aggregate Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Module_Group", &ctopSubModGrp));
			if(ctopSubModGrp!=NULL)trimwhitespace(ctopSubModGrp);
			printf("\n Module Group Value After Trim: [%s]\n", ctopSubModGrp);fflush(stdout);
			if(tc_strlen(ctopSubModGrp)>0)
			{
				tc_strdup(ctopSubModGrp,&ctopSubModGrpDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubModGrpDup);
				printf("\n Module Group Value is NULL");fflush(stdout);
			}
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Module", &ctopSubMod));
			if(ctopSubMod!=NULL)trimwhitespace(ctopSubMod);
			printf("\n Module Value After Trim: [%s]\n", ctopSubMod);fflush(stdout);
			if(tc_strlen(ctopSubMod)>0)
			{
				tc_strdup(ctopSubMod,&ctopSubModDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubModDup);
				printf("\n Module Value is NULL");fflush(stdout);
			}
			
			ctopSubModAddress = subString(ctopSubItem_Id, 4, 5);
			if(ctopSubModAddress!=NULL)trimwhitespace(ctopSubModAddress);
			printf("\n Part Module Address Value: [%s]", ctopSubModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			if(ctopSubItem_RevSeq!=NULL)trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Platform", &ctopSubPlatform));
			if(tc_strlen(ctopSubPlatform)>0)
			{
				tc_strdup(ctopSubPlatform,&ctopSubPlatformDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubPlatformDup);
				printf("\n Platform Value is NULL");fflush(stdout);
			}
			if(ctopSubPlatformDup!=NULL)trimwhitespace(ctopSubPlatformDup);
			printf("\n Platform Value After Dup & Trim: [%s]\n", ctopSubPlatformDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_ProjectCode", &ctopSubProjCode));
			if(tc_strlen(ctopSubProjCode)>0)
			{
				tc_strdup(ctopSubProjCode,&ctopSubProjCodeDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			if(ctopSubProjCodeDup!=NULL)trimwhitespace(ctopSubProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", ctopSubProjCodeDup);fflush(stdout);
		
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			if(ctopSubArDrStatusDup!=NULL)trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			if(ctopSubPartTypeDup!=NULL)trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_object_type", &ctopSubType));
			if(tc_strlen(ctopSubType)>0)
			{
				tc_strdup(ctopSubType,&ctopSubTypeDup);
			}
			else
			{
				tc_strdup(" ",&ctopSubTypeDup);
				printf("\n Item Type Value is NULL");fflush(stdout);
			}
			if(ctopSubTypeDup!=NULL)trimwhitespace(ctopSubTypeDup);
			printf("\n Item Type Value After Dup & Trim: [%s]", ctopSubTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Count: [%d]", ctopLevel);
			printf("\nTop_Level DML No: [%s]", DMLNo);
			printf("\nTop_Level Aggregate Group: [%s]", ctopSubAggrGrp);
			printf("\nTop_Level Aggregate: [%s]", ctopSubAggr);
			printf("\nTop_Level Module Group: [%s]", ctopSubModGrp);
			printf("\nTop_Level Module: [%s]", ctopSubMod);
			printf("\nTop_Level Module Address: [%s]", ctopSubModAddress);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Platform: [%s]", ctopSubPlatformDup);
			printf("\nTop_Level Project Code: [%s]", ctopSubProjCodeDup);
			printf("\nTop_Level AR/DR: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\nTop_Level Item Type: [%s]", ctopSubTypeDup);		
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if((tc_strcmp(ctopSubPartTypeDup,"Module")==0) && (tc_strcmp(ctopSubTypeDup,"Design Revision")==0))
				{
				   fprintf(VehRpt,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DMLNo,ctopSubAggrGrp,ctopSubAggr,ctopSubModGrp,ctopSubMod,ctopSubModAddress,ctopSubItem_Id,ctopSubItem_Desc,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubPlatformDup,ctopSubProjCodeDup,ctopSubArDrStatusDup,ctopSubPartTypeDup,ctopSubTypeDup);fflush(VehRpt);
				   fprintf(VehTxtFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",ctopSubAggrGrp,ctopSubAggr,ctopSubModGrp,ctopSubMod,ctopSubModAddress,ctopSubItem_Id,ctopSubItem_Desc,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubPlatformDup,ctopSubProjCodeDup,ctopSubArDrStatusDup,ctopSubPartTypeDup,ctopSubTypeDup);fflush(VehTxtFile);
				   fprintf(VehLinkFile,"%s^%s^%s^%s^\n",ctopSubModAddress,ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq);fflush(VehLinkFile);
				   fprintf(VehMaxARDRFile,"%s,%s,\n",ctopSubItem_Id,ctopSubModAddress);fflush(VehMaxARDRFile);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			//if((itopSubNumber_Child>0) && (ctopLevel<6))
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(DMLNo, ttop_BOM_Children, itopSubNumber_Child, VehRpt, VehTxtFile, VehLinkFile, VehMaxARDRFile);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}


int TC_VehVCCRRlzd_DML_Details(FILE* VehVCCRDMLRptFile,FILE* VehVCCRDMLTxtRptFile,FILE* VehVCCRDMLVehLinkRptFile,FILE* VehVCCRDMLMaxARDRRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tVItemobj     = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tvitemobj_results = NULLTAG;
	int n_ventries = 5;
	int n_vitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Comitem_revseq_str = NULL;
	char *Comitem_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////  P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tVItemobj));
    if(tVItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cvEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cvValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"Veh"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","Veh"};
		ITK_CALL(QRY_execute(tVItemobj, n_ventries, cvEntries, cvValues, &n_vitemobj_found, &tvitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Vehicle Released): [%d]\n",n_vitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vitemobj_found > 0)
		{
			printf(" Release Type(Vehicle Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_vitemobj_found; i++)
			{
				ErcDMLTag = tvitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"Veh")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Vehicle Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Comitem_revseq_str));
									tc_strdup(Comitem_revseq_str,&Comitem_revseq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Vehicle Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Vehicle Complete Revision & Sequence: [%s]\n",Comitem_revseq_strDup);fflush(stdout);
									printf("\n  Vehicle Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Vehicle Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									if(((tc_strcmp(item_ptype_strDup,"V")==0) || (tc_strcmp(item_ptype_strDup,"VCCR")==0)) && (tc_strcmp(item_typeDup,"Design Revision")==0))
									{
										printf("\n tm_LibraryCreationCronJob - This Vehicle or Vehicle Combination CR is Applicable For Expansion..!!\n");fflush(stdout);
										printf("\n Function1: Vehicle Child Details Find Start\n");fflush(stdout);
										TC_VehChild_Details(DmlNo,item_id_strDup,Comitem_revseq_strDup,item_rev_strDup,item_seq_strDup,VehVCCRDMLRptFile,VehVCCRDMLTxtRptFile,VehVCCRDMLVehLinkRptFile,VehVCCRDMLMaxARDRRptFile);
										printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Vehicle Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Vehicle Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_ECUPartRlzd_DML_Details(FILE* ECURptFile,FILE* ECUTxtRptFile,FILE* ECUVehLinkRptFile,FILE* ECUMaxARDRRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tECUItemobj  = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tecuitemobj_results = NULLTAG;
	int n_ecuentries = 5;
	int n_ecuitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_Created = NULL;
	char *Module_CreatedDup = NULL;
	char *Module_Rlzd = NULL;
	char *Module_RlzdDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tECUItemobj));
    if(tECUItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cecuEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cecuValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"EP"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","EP"};
		ITK_CALL(QRY_execute(tECUItemobj, n_ecuentries, cecuEntries, cecuValues, &n_ecuitemobj_found, &tecuitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(ECU Part Release): [%d]\n",n_ecuitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_ecuitemobj_found > 0)
		{
			printf(" Release Type(ECU Part Release) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_ecuitemobj_found; i++)
			{
				ErcDMLTag = tecuitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"EP")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [ECU Part Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									printf("\n SubFunction: Module Creation Date Find Start");fflush(stdout);
									Module_Created = TC_ERC_DTCreated(revTag);
									Module_CreatedDup=strtok(Module_Created," ");
									//tc_strdup(Module_Created,&Module_CreatedDup);
									printf("\n SubFunction:  Module Creation Date Find End");fflush(stdout);
																		
									printf("\n SubFunction: Module Released Date Find Start");fflush(stdout);
									Module_Rlzd = TC_ERC_DTReleased(revTag);
									Module_RlzdDup=strtok(Module_Rlzd," ");
									//tc_strdup(Module_Rlzd,&Module_RlzdDup);
									printf("\n SubFunction:  Module Released Date Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"EM")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(ECURptFile,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(ECURptFile);
                                        fprintf(ECUTxtRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(ECUTxtRptFile);
                                        fprintf(ECUVehLinkRptFile,"%s^%s^%s^%s^\n",item_modaddr_str,item_id_strDup,item_rev_strDup,item_seq_strDup);fflush(ECUVehLinkRptFile);
                                        fprintf(ECUMaxARDRRptFile,"%s,%s,\n",item_id_strDup,item_modaddr_str);fflush(ECUMaxARDRRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not ECU Part Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--ECU Part Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_ModuleSpareKitRlzd_DML_Details(FILE* ModSpKitRptFile,FILE* ModSpKitTxtRptFile,FILE* ModSpKitVehLinkRptFile,FILE* ModSpKitMaxARDRRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tMSPKItemobj  = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tmspkitemobj_results = NULLTAG;
	int n_mspkentries = 5;
	int n_mspkitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_Created = NULL;
	char *Module_CreatedDup = NULL;
	char *Module_Rlzd = NULL;
	char *Module_RlzdDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tMSPKItemobj));
    if(tMSPKItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cmspkEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cmspkValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"TSKR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","TSKR"};
		ITK_CALL(QRY_execute(tMSPKItemobj, n_mspkentries, cmspkEntries, cmspkValues, &n_mspkitemobj_found, &tmspkitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Module with Spare Kit Release): [%d]\n",n_mspkitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_mspkitemobj_found > 0)
		{
			printf(" Release Type(Module with Spare Kit Release) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_mspkitemobj_found; i++)
			{
				ErcDMLTag = tmspkitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"TSKR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Module with Spare Kit Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									printf("\n SubFunction: Module Creation Date Find Start");fflush(stdout);
									Module_Created = TC_ERC_DTCreated(revTag);
									Module_CreatedDup=strtok(Module_Created," ");
									//tc_strdup(Module_Created,&Module_CreatedDup);
									printf("\n SubFunction:  Module Creation Date Find End");fflush(stdout);
																		
									printf("\n SubFunction: Module Released Date Find Start");fflush(stdout);
									Module_Rlzd = TC_ERC_DTReleased(revTag);
									Module_RlzdDup=strtok(Module_Rlzd," ");
									//tc_strdup(Module_Rlzd,&Module_RlzdDup);
									printf("\n SubFunction:  Module Released Date Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(ModSpKitRptFile,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(ModSpKitRptFile);
                                        fprintf(ModSpKitTxtRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(ModSpKitTxtRptFile);
                                        fprintf(ModSpKitVehLinkRptFile,"%s^%s^%s^%s^\n",item_modaddr_str,item_id_strDup,item_rev_strDup,item_seq_strDup);fflush(ModSpKitVehLinkRptFile);
                                        fprintf(ModSpKitMaxARDRRptFile,"%s,%s,\n",item_id_strDup,item_modaddr_str);fflush(ModSpKitMaxARDRRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Module with Spare Kit Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Module with Spare Kit Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_ModuleRlzd_DML_Details(FILE* VehDMLRptFile,FILE* VehDMLTxtRptFile,FILE* VehDMLVehLinkRptFile,FILE* VehDMLMaxARDRRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tVItemobj     = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tvitemobj_results = NULLTAG;
	int n_ventries = 5;
	int n_vitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_Created = NULL;
	char *Module_CreatedDup = NULL;
	char *Module_Rlzd = NULL;
	char *Module_RlzdDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////  P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tVItemobj));
    if(tVItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cvEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cvValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"MR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","MR"};
		ITK_CALL(QRY_execute(tVItemobj, n_ventries, cvEntries, cvValues, &n_vitemobj_found, &tvitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Module Released): [%d]\n",n_vitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vitemobj_found > 0)
		{
			printf(" Release Type(Module Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_vitemobj_found; i++)
			{
				ErcDMLTag = tvitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"MR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [Module Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									printf("\n SubFunction: Module Creation Date Find Start");fflush(stdout);
									Module_Created = TC_ERC_DTCreated(revTag);
									Module_CreatedDup=strtok(Module_Created," ");
									//tc_strdup(Module_Created,&Module_CreatedDup);
									printf("\n SubFunction:  Module Creation Date Find End");fflush(stdout);
																		
									printf("\n SubFunction: Module Released Date Find Start");fflush(stdout);
									Module_Rlzd = TC_ERC_DTReleased(revTag);
									Module_RlzdDup=strtok(Module_Rlzd," ");
									//tc_strdup(Module_Rlzd,&Module_RlzdDup);
									printf("\n SubFunction:  Module Released Date Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(VehDMLRptFile,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(VehDMLRptFile);
										fprintf(VehDMLTxtRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(VehDMLTxtRptFile);
										fprintf(VehDMLVehLinkRptFile,"%s^%s^%s^%s^\n",item_modaddr_str,item_id_strDup,item_rev_strDup,item_seq_strDup);fflush(VehDMLVehLinkRptFile);
										fprintf(VehDMLMaxARDRRptFile,"%s,%s,\n",item_id_strDup,item_modaddr_str);fflush(VehDMLMaxARDRRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not Module Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--Module Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_GMRlzd_DML_Details(FILE* GMDMLRptFile,FILE* GMDMLTxtRptFile,FILE* GMDMLVehLinkRptFile,FILE* GMDMLMaxARDRRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tGMItemobj    = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tgmitemobj_results = NULLTAG;
	int n_gmentries = 5;
	int n_gmitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Part_Desc         = NULL;
	char *Part_DescDup      = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	char *item_aggrp_str = NULL;
	char *item_aggrp_strDup = NULL;
	char *item_aggr_str = NULL;
	char *item_aggr_strDup = NULL;
	char *item_modgrp_str = NULL;
	char *item_modgrp_strDup = NULL;
	char *item_mod_str = NULL;
	char *item_mod_strDup = NULL;
	char *item_modaddr_str = NULL;
	char *item_plat_str = NULL;
	char *item_plat_strDup = NULL;
	char *item_pcode_str = NULL;
	char *item_pcode_strDup = NULL;
	char *item_ptype_str = NULL;
	char *item_ptype_strDup = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_Created = NULL;
	char *Module_CreatedDup = NULL;
	char *Module_Rlzd = NULL;
	char *Module_RlzdDup = NULL;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    C U R R E N T   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	printf("\n Formatted Current Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y   B E F O R E   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDay[100] = "";
	char* BfrDayDup = NULL;
	char *BfrDayFinalDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1); 
	nextinfo = localtime(&t3);
	strftime(BfrDay,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDay);
	if(BfrDay!=NULL)tc_strdup(BfrDay,&BfrDayDup);
	tc_strcpy(BfrDayFinalDup,BfrDayDup);
	printf(" [1]: Input Formatted Before Day(BfrDayFinalDup): [%s]\n",BfrDayFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	tc_strcpy(AfterDTStamp,BfrDayFinalDup);
	tc_strcat(AfterDTStamp," 00:00");
	printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
	tc_strcpy(BeforeDTStamp,BfrDayFinalDup);
	tc_strcat(BeforeDTStamp," 23:50");
	printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tGMItemobj));
    if(tGMItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cgmEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cgmValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"TODR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","TODR"};
		ITK_CALL(QRY_execute(tGMItemobj, n_gmentries, cgmEntries, cgmValues, &n_gmitemobj_found, &tgmitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(GM Released): [%d]\n",n_gmitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_gmitemobj_found > 0)
		{
			printf(" Release Type(GM Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_gmitemobj_found; i++)
			{
				ErcDMLTag = tgmitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_LibraryCreationCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_LibraryCreationCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_LibraryCreationCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_LibraryCreationCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"TODR")==0)
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type: [GM Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_LibraryCreationCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags));
							printf("\n tm_LibraryCreationCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								if(tc_strlen(item_id_str)>0)
								{
									tc_strdup(item_id_str,&item_id_strDup);
								}
								else
								{
									tc_strdup(" ",&item_id_strDup);
									printf("\n Part_No Value is NULL..!!");fflush(stdout);
								}
								ITK_CALL(AOM_ask_value_string(revTag,"t5_AggregateGroup",&item_aggrp_str));
								if(tc_strlen(item_aggrp_str)>0)
								{
									tc_strdup(item_aggrp_str,&item_aggrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggrp_strDup);
									printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Aggregate",&item_aggr_str));
								if(tc_strlen(item_aggr_str)>0)
								{
									tc_strdup(item_aggr_str,&item_aggr_strDup);
								}
								else
								{
									tc_strdup(" ",&item_aggr_strDup);
									printf("\n Aggregate Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module_Group",&item_modgrp_str));
								if(tc_strlen(item_modgrp_str)>0)
								{
									tc_strdup(item_modgrp_str,&item_modgrp_strDup);
								}
								else
								{
									tc_strdup(" ",&item_modgrp_strDup);
									printf("\n Module Group Value is NULL..!!");fflush(stdout);
								}
								
								ITK_CALL(AOM_ask_value_string(revTag,"t5_Module",&item_mod_str));
								if(tc_strlen(item_mod_str)>0)
								{
									tc_strdup(item_mod_str,&item_mod_strDup);
								}
								else
								{
									tc_strdup(" ",&item_mod_strDup);
									printf("\n Module Value is NULL..!!");fflush(stdout);
								}
								
								item_modaddr_str = subString(item_id_strDup, 4, 5);
								trimwhitespace(item_modaddr_str);
								printf("\n Part Module Address Value: [%s]", item_modaddr_str);fflush(stdout);
								
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_LibraryCreationCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Part_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Part_Desc,&Part_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&item_plat_str));
									if(tc_strlen(item_plat_str)>0)
									{
										tc_strdup(item_plat_str,&item_plat_strDup);
									}
									else
									{
										tc_strdup(" ",&item_plat_strDup);
										printf("\n Platform Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_ProjectCode",&item_pcode_str));
									if(tc_strlen(item_pcode_str)>0)
									{
										tc_strdup(item_pcode_str,&item_pcode_strDup);
									}
									else
									{
										tc_strdup(" ",&item_pcode_strDup);
										printf("\n Project_Code Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									if(tc_strlen(item_drar_str)>0)
									{
										tc_strdup(item_drar_str,&item_drar_strDup);
									}
									else
									{
										tc_strdup(" ",&item_drar_strDup);
										printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
									}

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&item_ptype_str));
									if(tc_strlen(item_ptype_str)>0)
									{
										tc_strdup(item_ptype_str,&item_ptype_strDup);
									}
									else
									{
										tc_strdup(" ",&item_ptype_strDup);
										printf("\n Part Type Value is NULL..!!");fflush(stdout);
									}
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  DML Number: [%s]\n",DmlNo);fflush(stdout);
									printf("\n  Aggregate_Group: [%s]\n",item_aggrp_strDup);fflush(stdout);
									printf("\n  Aggregate: [%s]\n",item_aggr_strDup);fflush(stdout);
									printf("\n  Module_Group: [%s]\n",item_modgrp_strDup);fflush(stdout);
									printf("\n  Module: [%s]\n",item_mod_strDup);fflush(stdout);
									printf("\n  Module_Address: [%s]\n",item_modaddr_str);fflush(stdout);
									printf("\n  Part Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Part Description: [%s]\n",Part_DescDup);fflush(stdout);
									printf("\n  Part Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Part Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Part Platform: [%s]\n",item_plat_strDup);fflush(stdout);
									printf("\n  Part Project_Code: [%s]\n",item_pcode_strDup);fflush(stdout);
									printf("\n  Part DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Part_Type: [%s]\n",item_ptype_strDup);fflush(stdout);
									printf("\n  Object_Type: [%s]\n",item_typeDup);fflush(stdout);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
									Module_Address_Status = TC_ModuleAddrStatus(item_modaddr_str);
									tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
									printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
									
									printf("\n SubFunction: Module Creation Date Find Start");fflush(stdout);
									Module_Created = TC_ERC_DTCreated(revTag);
									Module_CreatedDup=strtok(Module_Created," ");
									//tc_strdup(Module_Created,&Module_CreatedDup);
									printf("\n SubFunction:  Module Creation Date Find End");fflush(stdout);
									
									printf("\n SubFunction: Module Released Date Find Start");fflush(stdout);
									Module_Rlzd = TC_ERC_DTReleased(revTag);
									Module_RlzdDup=strtok(Module_Rlzd," ");
									//tc_strdup(Module_Rlzd,&Module_RlzdDup);
									printf("\n SubFunction:  Module Released Date Find End");fflush(stdout);
									
									if((tc_strcmp(item_ptype_strDup,"M")==0) && (tc_strcmp(item_typeDup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0))
									{
										fprintf(GMDMLRptFile,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",DmlNo,item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(GMDMLRptFile);
										fprintf(GMDMLTxtRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",item_aggrp_strDup,item_aggr_strDup,item_modgrp_strDup,item_mod_strDup,item_modaddr_str,item_id_strDup,Part_DescDup,item_rev_strDup,item_seq_strDup,item_plat_strDup,item_pcode_strDup,item_drar_strDup,item_ptype_strDup,item_typeDup,Module_CreatedDup,Module_RlzdDup,CurDateFinalDup);fflush(GMDMLTxtRptFile);
										fprintf(GMDMLVehLinkRptFile,"%s^%s^%s^%s^\n",item_modaddr_str,item_id_strDup,item_rev_strDup,item_seq_strDup);fflush(GMDMLVehLinkRptFile);
										fprintf(GMDMLMaxARDRRptFile,"%s,%s,\n",item_id_strDup,item_modaddr_str);fflush(GMDMLMaxARDRRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_LibraryCreationCronJob--DML Release Type is Not GM Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_LibraryCreationCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_LibraryCreationCronJob--GM Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_LibraryCreationCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	int ifail = ITK_ok;
	char *RptFile = (char *) malloc(100*sizeof(char));
	FILE *fpOutput_file = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"mcc_valid_system_submodule");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
	char *TxtRptFile = (char *) malloc(400*sizeof(char));
	FILE *fpTxtOutput_file = NULL;
	printf("\n Generating Text Report File Name..!!");fflush(stdout);
	tc_strcpy(TxtRptFile,"mcc_valid_system_submodule");
	//tc_strcat(TxtRptFile,"_");
	//tc_strcat(TxtRptFile,GenDate);
	tc_strcat(TxtRptFile,".txt");
	printf("\n Text Report File Name: [%s]", TxtRptFile);fflush(stdout);
	printf("\n Text Report File Generated..!!");fflush(stdout);
	
	char *VehLinkRptFile = (char *) malloc(400*sizeof(char));
	FILE *fpVehLinkOutput_file = NULL;
	printf("\n Generating Vehicle Link Status Input File Name..!!");fflush(stdout);
	tc_strcpy(VehLinkRptFile,"input_vehiclelink_mcc_valid_system_submodule");
	//tc_strcat(VehLinkRptFile,"_");
	//tc_strcat(VehLinkRptFile,GenDate);
	tc_strcat(VehLinkRptFile,".txt");
	printf("\n Vehicle Link Status Input File Name: [%s]", VehLinkRptFile);fflush(stdout);
	printf("\n Vehicle Link Status Input File Generated..!!");fflush(stdout);
	
	char *MaxardrRptFile = (char *) malloc(400*sizeof(char));
	FILE *fpMaxaradrOutput_file = NULL;
	printf("\n Generating Max AR/DR Status Input File Name..!!");fflush(stdout);
	tc_strcpy(MaxardrRptFile,"input_maxardr_mcc_valid_system_submodule");
	//tc_strcat(MaxardrRptFile,"_");
	//tc_strcat(MaxardrRptFile,GenDate);
	tc_strcat(MaxardrRptFile,".txt");
	printf("\n Max AR/DR Input File Name: [%s]", MaxardrRptFile);fflush(stdout);
	printf("\n Max AR/DR Input File Generated..!!");fflush(stdout);
	
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	fpTxtOutput_file = fopen(TxtRptFile, "w");
	if(fpTxtOutput_file == NULL)
	{
	    printf("\n Unable to Create Text Report File: --------> [%s]",TxtRptFile);fflush(stdout);
		return 0;
	}
	fpVehLinkOutput_file = fopen(VehLinkRptFile, "w");
	if(fpVehLinkOutput_file == NULL)
	{
	    printf("\n Unable to Create Text VehicleLink File: --------> [%s]",VehLinkRptFile);fflush(stdout);
		return 0;
	}
	fpMaxaradrOutput_file = fopen(MaxardrRptFile, "w");
	if(fpMaxaradrOutput_file == NULL)
	{
	    printf("\n Unable to Create Text Max AR/DR File: --------> [%s]",MaxardrRptFile);fflush(stdout);
		return 0;
	}
	printf("\n tm_LibraryCreationCronJob--Started \n");fflush(stdout);
	printf("\n Function1: DML Release Type - Module Release(MR) Details Find Start");fflush(stdout);
	TC_ModuleRlzd_DML_Details(fpOutput_file,fpTxtOutput_file,fpVehLinkOutput_file,fpMaxaradrOutput_file);
	printf("\n Function1: DML Release Type - Module Release(MR) Details Find End\n");fflush(stdout);
	printf("\n Function2: DML Release Type - Gate Maturation(TODR) Details Find Start");fflush(stdout);
	TC_GMRlzd_DML_Details(fpOutput_file,fpTxtOutput_file,fpVehLinkOutput_file,fpMaxaradrOutput_file);
	printf("\n Function2: DML Release Type - Gate Maturation(TODR) Details Find End\n");fflush(stdout);
	printf("\n Function3: DML Release Type - Module with Spare Kit Release(TSKR) Details Find Start");fflush(stdout);
	TC_ModuleSpareKitRlzd_DML_Details(fpOutput_file,fpTxtOutput_file,fpVehLinkOutput_file,fpMaxaradrOutput_file);
	printf("\n Function3: DML Release Type - Module with Spare Kit Release(TSKR) Details Find End\n");fflush(stdout);
	printf("\n Function4: DML Release Type - ECU Part Release(EP) Details Find Start");fflush(stdout);
	TC_ECUPartRlzd_DML_Details(fpOutput_file,fpTxtOutput_file,fpVehLinkOutput_file,fpMaxaradrOutput_file);
	printf("\n Function4: DML Release Type - ECU Part Release(EP) Details Find End\n");fflush(stdout);
	printf("\n Function5: DML Release Type - Vehicle Release(Veh) Details Find Start");fflush(stdout);
	TC_VehVCCRRlzd_DML_Details(fpOutput_file,fpTxtOutput_file,fpVehLinkOutput_file,fpMaxaradrOutput_file);
	printf("\n Function5: DML Release Type - Vehicle Release(Veh) Details Find End\n");fflush(stdout);
	printf("\n tm_LibraryCreationCronJob--Completed \n");fflush(stdout);
    fclose(fpOutput_file);
	fclose(fpTxtOutput_file);
	fclose(fpVehLinkOutput_file);
	fclose(fpMaxaradrOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_LibraryCreationCronJob.c
* // ./linkitk -o tm_LibraryCreationCronJob tm_LibraryCreationCronJob.o
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/LibraryCreationCronJob/tm_LibraryCreationCronJob .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/LibraryCreationCronJob/exepatch.sh .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/LibraryCreationCronJob/usage.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/LibraryCreationCronJob/SendEmail.sh .
* // ./tm_LibraryCreationCronJob -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_LibraryCreationCronJob -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/