/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Latest ERC Released Vehicle Details & Print its Properties on Reports  
*  File Name    :   tm_VehicleDataReport.c
*  Created on   :   May 15th, 2024
*  Usage        :   tm_VehicleDataReport
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     15/05/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

int ICS_keylov_get_keylov (const char *key_lov_id, char **key_lov_name, int *options, int *n_lov_entries, char ***lov_keys, char ***lov_values, logical **deprecated_staus, char **owning_site, int *n_shared_sites, char ***shared_sites);
int ICS_describe_unct (int unctNo, char **unctName, char **shortName, char **unctUnit, int *unctFormat);
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int getClsValueFrmICSTag_pm( tag_t  IcsClsTag_pm , char *clsKeyAtrrId_pm,char **AttrVal)
{
	tag_t objTypeTag_pm=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name_pm[TCTYPE_name_size_c+1];
	char   *Ptype_name_pm	=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag_pm,&objTypeTag_pm));
	//if(TCTYPE_ask_name(objTypeTag_pm,Ptype_name_pm));
	if(TCTYPE_ask_name2(objTypeTag_pm,&Ptype_name_pm)); // TC 14.3 Upgrade

	
	if(IcsClsTag_pm!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId_pm); fflush(stdout);
			//char keyPrefix[10];
			//tc_strcpy(keyPrefix,"-");
			//tc_strcat(keyPrefix,clsKeyAtrrId);
			int intid2 = 0;
			char * 	unctName = NULL;
		    char *	shortName = NULL;
		    char * 	unctUnit = NULL;
		    int  unctFormat = 0;
			intid2=atoi(clsKeyAtrrId_pm);
			printf("\n  input intid2[%d]",intid2); fflush(stdout);
	 
			printf("\n  111"); fflush(stdout);
			ITKCALL(ICS_describe_unct(intid2,&unctName,&shortName,&unctUnit,&unctFormat));
			printf("\n  222 ifail[%d]",ifail); fflush(stdout);
			if(ifail != ITK_ok)
			{
				printf("\n FAIL:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);						
				return ifail;	
			}
			
			printf("\n SUCCESS:  intid2[%d] unctName[%s] shortName[%s] unctUnit[%s] unctFormat[%d]",intid2,unctName,shortName,unctUnit,unctFormat); fflush(stdout);
			//printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			//const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char theKeyLOVId[10];
			const char * 	key_lov_id;
			if(unctFormat)
			{

				sprintf(theKeyLOVId, "%d", unctFormat);
				key_lov_id=theKeyLOVId;	
			}
			char * 	key_lov_name;
			int  	options;
			int t = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites;
			theICOTag=IcsClsTag_pm;
			ITKCALL(ICS_ask_attribute_value(theICOTag,clsKeyAtrrId_pm,&AttrKeyValue));
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(t=0;t<n_lov_entries;t++)								
				{
					//printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
					
					//if(tc_strcasecmp(AttrKeyValue,lov_keys[t])==0)
					if(tc_strstr(lov_keys[t],AttrKeyValue) != NULL)
					{
						printf("\n AttrKeyValue: [%s]",AttrKeyValue);fflush(stdout);
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[t],lov_values[t]);fflush(stdout);
						
						if(lov_values[t])
						{
							tc_strdup(lov_values[t],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						printf("\n Before Break RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

int getClsValueFrmICSTag( tag_t  IcsClsTag , char *clsKeyAtrrId,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	//char   Ptype_name[TCTYPE_name_size_c+1];
	char	*Ptype_name		=	NULL;
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	
	

	if(TCTYPE_ask_object_type(IcsClsTag,&objTypeTag));
	//if(TCTYPE_ask_name(objTypeTag,Ptype_name));
	if(TCTYPE_ask_name2(objTypeTag,&Ptype_name));  // TC 14.3 API Change
	//printf("\n getClsValueFrmICSTag IcsClsTag  Ptype_name :: %s\n", Ptype_name); fflush(stdout);

	
	//Create Relation between Intent and Vehicle.
	int partRevCnt=0;
    tag_t* partRevTagObjs = NULLTAG;
    tag_t partRevTag = NULLTAG;
	if(IcsClsTag!=NULLTAG)
	{
		    char * 	theClassId = NULL;
			int  	theAttributeCount;
			int * 	theAttributeIds;
			int * 	theAttributeValCounts;
			char ** 	theAttributeValues;
			tag_t 	theICOTag=NULLTAG;
			printf("\n  input clsKeyAtrrId[%s]",clsKeyAtrrId); fflush(stdout);
			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * 	key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * 	key_lov_name;
			int  	options;
			int q = 0;
			int keyfound=0;
			int  	n_lov_entries;
			char ** 	lov_keys;
			char ** 	lov_values;
			logical * 	deprecated_staus;
			char * 	owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int  	n_shared_sites;
			char ** 	shared_sites ;
			theICOTag=IcsClsTag;
			//CALLAPI(ICS_ask_attribute_value(theICOTag,"8066",&AttrKeyValue))
			if(ICS_ask_attribute_value(IcsClsTag,clsKeyAtrrId,&AttrKeyValue))
			
			printf("\n AttrKeyValue: [%s]  key_lov_id: [%s]",AttrKeyValue,key_lov_id); fflush(stdout);
			
			if(AttrKeyValue)
			{
				*AttrVal = AttrKeyValue;
			
			    if(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    //CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
			    printf("\n key_lov_name: [%s] n_lov_entries: [%d] options: [%d]",key_lov_name,n_lov_entries,options); fflush(stdout);
 				for(q=0;q<n_lov_entries;q++)								
				{
					printf("\n lov_keys: [%s] lov_values: [%s]",lov_keys[q],lov_values[q]);fflush(stdout);
					
					if(tc_strcasecmp(AttrKeyValue,lov_keys[q])==0)
					{
						printf("\n Mascot lov_keys: [%s] lov_values: [%s]",lov_keys[q],lov_values[q]);fflush(stdout);
						
						if(lov_values[q])
						{
							tc_strdup(lov_values[q],&RetAttrVal);
						}
						*AttrVal=RetAttrVal;
						break;
					}	
				} 
			}
			else
			{
				*AttrVal="";
				return ITK_ok;
			}
	}
    printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
	printf("\n RetAttrVal: [%s]",RetAttrVal);fflush(stdout);
	printf("\n @@@@@@@@@@@@@@@@@@@@@@");fflush(stdout);	
			
	return ITK_ok;
}

char* TC_WBS_Description(char* VehWBS)
{
	trimwhitespace(VehWBS);
	tag_t tWOQryobj = NULLTAG;
	int nWO_entries = 1;
	int nWO_Qryobj_found = 0;
	tag_t* tWOQryobj_results = NULLTAG;
	int z = 0;
	char* VehWBSDesc = NULL;
	char* VehWBSDesDup = NULL;
	
	printf("\n Searched WBS Value: [%s]\n", VehWBS);fflush(stdout);
    ITK_CALL(QRY_find2("Work_Order",&tWOQryobj));
    if(tWOQryobj!=NULLTAG)
	{
		printf("\n Work_Order Query Found Successfully..!!\n");fflush(stdout);
		char *WOEntries[1]  = {"Work Order Number"};
		char *WOValues[1]  = {VehWBS};
		ITK_CALL(QRY_execute(tWOQryobj, nWO_entries, WOEntries, WOValues, &nWO_Qryobj_found, &tWOQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of WBS Found: [%d]\n",nWO_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nWO_Qryobj_found > 0)
		{
			printf(" Quiried WBS Found..!!\n");fflush(stdout);
			for (z = 0; z < nWO_Qryobj_found; z++)
			{
				tag_t WO_rev_tags_found = NULLTAG;
				WO_rev_tags_found = tWOQryobj_results[z];
				if(WO_rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tWOQryobj_results[z],"t5ERCWODesc",&VehWBSDesc);
					printf("\n WBS Description Before Dup & Trim:  <%s> \n",VehWBSDesc);fflush(stdout);
					if(tc_strlen(VehWBSDesc)>0)
					{
						tc_strdup(VehWBSDesc,&VehWBSDesDup);
					}
					else
					{
						tc_strdup("--",&VehWBSDesDup);
						printf("\n WBS Description Value is NULL..!!\n");fflush(stdout);
					}
					trimwhitespace(VehWBSDesDup);
					printf("\n WBS Description After Dup & Trim: [%s]\n", VehWBSDesDup);fflush(stdout);
					STRNG_replace_str(VehWBSDesDup,","," ",&VehWBSDesDup);
					STRNG_replace_str(VehWBSDesDup,";"," ",&VehWBSDesDup);
					STRNG_replace_str(VehWBSDesDup,"\n"," ",&VehWBSDesDup);
					STRNG_replace_str(VehWBSDesDup,"'"," ",&VehWBSDesDup);
					printf("\n WBS Description Final Value: [%s]\n", VehWBSDesDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&VehWBSDesDup);
					printf("\n Sorry! WBS Revision Tag Not Found...\n");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&VehWBSDesDup);
			printf("\n Sorry! Entered WBS Not Found...\n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&VehWBSDesDup);
		printf("\n Sorry! Work_Order Query Tag Not Found...\n");fflush(stdout);
	}
	
	return VehWBSDesDup;	
}

char* TC_ESO_Details(tag_t ESO_veh_tag)
{
	int	status = 0;
	tag_t RelationFindESO = NULLTAG;
	int sec_counteso = 0;
	tag_t *sec_esoobjects = NULLTAG;
	char *esono_str = NULL;
	char *esono_strDup = NULL;
	
	ITK_CALL(GRM_find_relation_type("T5_PartEsoRel",&RelationFindESO));
	if(RelationFindESO!=NULLTAG)
	{									
		printf("\n Sudo Folder Part Has ESO Status(T5_PartEsoRel) Relation Found..!!\n");fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(ESO_veh_tag, RelationFindESO, &sec_counteso, &sec_esoobjects));
		printf("\n Total ESO Objects Found(T5_PartEsoRel): [%d]\n", sec_counteso);
		if(sec_counteso > 0)
		{
			ITK_CALL(AOM_ask_value_string(sec_esoobjects[0],"object_string",&esono_str));
			printf("\n ESO No: [%s]\n",esono_str);fflush(stdout);
			if(tc_strlen(esono_str)>0)
			{
				tc_strdup(esono_str,&esono_strDup);
				trimwhitespace(esono_strDup);
			}
			else
			{
				tc_strdup("--",&esono_strDup);
				printf("\n ESO Number Value is NULL..!!");fflush(stdout);
			}
		}
		else
		{
			tc_strdup("--",&esono_strDup);
			printf("\n ESO Not Attached with Vehicle..!!");fflush(stdout);
		}
    }
	else
	{
		tc_strdup("--",&esono_strDup);
		printf("\n Sudo Folder Part Has ESO Status(T5_PartEsoRel) Tag Not Found..!!");fflush(stdout);
	}
	
	return esono_strDup;
}

char* TC_FDJ_Details(tag_t FDJ_veh_tag)
{
	int	status = 0;
	tag_t RelationFindFDJ = NULLTAG;
	int sec_countfdj = 0;
	tag_t *sec_fdjobjects = NULLTAG;
	char *fdjno_str = NULL;
	char *fdjno_strDup = NULL;
	
	ITK_CALL(GRM_find_relation_type("T5_AssmhasFDJ",&RelationFindFDJ));
	if(RelationFindFDJ!=NULLTAG)
	{									
		printf("\n Sudo Folder VC Has FDJ Status(T5_AssmhasFDJ) Relation Found..!!\n");fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(FDJ_veh_tag, RelationFindFDJ, &sec_countfdj, &sec_fdjobjects));
		printf("\n Total FDJ Objects Found(T5_PartEsoRel): [%d]\n", sec_countfdj);
		if(sec_countfdj > 0)
		{
			ITK_CALL(AOM_ask_value_string(sec_fdjobjects[0],"object_string",&fdjno_str));
			printf("\n FDJ No: [%s]\n",fdjno_str);fflush(stdout);
			if(tc_strlen(fdjno_str)>0)
			{
				tc_strdup(fdjno_str,&fdjno_strDup);
				trimwhitespace(fdjno_strDup);
			}
			else
			{
				tc_strdup("--",&fdjno_strDup);
				printf("\n FDJ Number Value is NULL..!!");fflush(stdout);
			}
		}
		else
		{
			tc_strdup("--",&fdjno_strDup);
			printf("\n FDJ Not Attached with Vehicle..!!");fflush(stdout);
		}
    }
	else
	{
		tc_strdup("--",&fdjno_strDup);
		printf("\n Sudo Folder VC Has FDJ Status(T5_AssmhasFDJ) Tag Not Found..!!");fflush(stdout);
	}
	
	return fdjno_strDup;
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision PartType",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision PartType Query Found Successfully..!!\n");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL..!!\n");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]\n", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]\n", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...\n");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...\n");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision PartType Query Tag Not Found...\n");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

char* TC_PlantWise_ReleasedDate(tag_t Inpvtag, char* InpRelStatus)
{
	int  status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* Rev_Rel_Status = NULL;
	char* dt_rlzd = NULL;
	char* dt_rlzdDup = NULL;
	ITK_CALL(WSOM_ask_release_status_list(Inpvtag, &status_count, &relStatus_list));
	printf("\n No of Release Status Found:   <%d> \n",status_count);fflush(stdout);
	if(status_count>0)
	{
		int k = 0;
		for(k = 0; k<status_count; k++)
		{
		    ITK_CALL(AOM_ask_value_string(relStatus_list[k],"object_name",&Rev_Rel_Status));
			printf("\n Latest_Rev_Rel_Status:  <%s> \n",Rev_Rel_Status);fflush(stdout);
			if(tc_strcmp(Rev_Rel_Status,InpRelStatus) == 0)
			{							
                ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
				printf(" \n Release Status Date Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
				if(tc_strlen(dt_rlzd)>0)
				{
					tc_strdup(dt_rlzd,&dt_rlzdDup);
				    trimwhitespace(dt_rlzdDup);
					printf("\n Date Released Value --------> [%s]\n", dt_rlzdDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&dt_rlzdDup);
					printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
				}
			}
		}
		if(tc_strlen(dt_rlzdDup)>0)
	    {
			printf("\n Date Released Value Avaialble..!!\n");fflush(stdout);
		}
		else
		{
			tc_strdup("--",&dt_rlzdDup);
			printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
		}
	}
	else
	{
		tc_strdup("--",&dt_rlzdDup);
		printf("\n Date Released Value is NULL For Given Release Status..!!\n");fflush(stdout);
	}
	
	return dt_rlzdDup;
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
		char* cItem_Id = NULL;
		char* cModAggr = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cLowerVal = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			cModAggr=subString(cItem_Id,4,3);
			printf("\n Module Aggregate Value After Trim: [%s]\n", cModAggr);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			if(tc_strcmp(cArDrStatusDup,"NA")==0)
			{
				tc_strdup("0",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR0")==0) || (tc_strcmp(cArDrStatusDup,"AR0")==0))
			{
				tc_strdup("1",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR1")==0) || (tc_strcmp(cArDrStatusDup,"AR1")==0))
			{
				tc_strdup("2",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR2")==0) || (tc_strcmp(cArDrStatusDup,"AR2")==0))
			{
				tc_strdup("3",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR3")==0) || (tc_strcmp(cArDrStatusDup,"AR3")==0) || (tc_strcmp(cArDrStatusDup,"DR3P")==0) || (tc_strcmp(cArDrStatusDup,"AR3P")==0))
			{
				tc_strdup("4",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR4")==0) || (tc_strcmp(cArDrStatusDup,"AR4")==0))
			{
				tc_strdup("5",&cLowerVal);
			}
			else if((tc_strcmp(cArDrStatusDup,"DR5")==0) || (tc_strcmp(cArDrStatusDup,"AR5")==0))
			{
				tc_strdup("6",&cLowerVal);
			}
			else
			{
				tc_strdup("0",&cLowerVal);
				printf("\n Top Lower Value is Blank..!!");fflush(stdout);
			}
			printf("\n Lower Value: [%s]\n", cLowerVal);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Module Aggregate: [%s]", cModAggr);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Lower Value: [%s]", cLowerVal);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
				   fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^\n",cItem_Id,cModAggr,cArDrStatusDup,cLowerVal,cPartTypeDup);fflush(FP_OutputReport);
				}
			}
		}
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopLowerVal = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopModAggr = NULL;
	
	PIE_scope_t scope;
	scope = PIE_TEAMCENTER;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);
		
        //Closure_Rule BOMViewClosureRuleERC Used		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		//Closure_Rule BOMViewClosureRuleERC Used
		
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ctopModAggr=subString(ctopSubItem_Id,4,3);
			trimwhitespace(ctopModAggr);
			printf("\n Module Aggregate Value After Trim: [%s]\n", ctopModAggr);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("NA",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			if(tc_strcmp(ctopSubArDrStatusDup,"NA")==0)
			{
				tc_strdup("0",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR0")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR0")==0))
			{
				tc_strdup("1",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR1")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR1")==0))
			{
				tc_strdup("2",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR2")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR2")==0))
			{
				tc_strdup("3",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR3")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR3")==0) || (tc_strcmp(ctopSubArDrStatusDup,"DR3P")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR3P")==0))
			{
				tc_strdup("4",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR4")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR4")==0))
			{
				tc_strdup("5",&ctopLowerVal);
			}
			else if((tc_strcmp(ctopSubArDrStatusDup,"DR5")==0) || (tc_strcmp(ctopSubArDrStatusDup,"AR5")==0))
			{
				tc_strdup("6",&ctopLowerVal);
			}
			else
			{
				tc_strdup("0",&ctopLowerVal);
				printf("\n Top Lower Value is Blank..!!");fflush(stdout);
			}
			printf("\n Lower Value: [%s]\n", ctopLowerVal);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Module Aggregate: [%s]", ctopModAggr);
			printf("\nTop_Level Part AR/DR Status: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Lower Value: [%s]", ctopLowerVal);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0)
				{
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^\n",ctopSubItem_Id,ctopModAggr,ctopSubArDrStatusDup,ctopLowerVal,ctopSubPartTypeDup);fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");fflush(stdout);
			printf("\n No of Child Found(First Level): [%d]\n",itopSubNumber_Child);fflush(stdout);
			printf("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *DRStatus = NULL;
	char *DRStatusDup = NULL;
	char *Platform = NULL;
	char *PlatformDup = NULL;
	char *FDJNoDup = NULL;
	char *ESONoDup = NULL;
	char *cItem_RevSeq = NULL;
	cItem_RevSeq = (char *) malloc(20*sizeof(char));
	char *cItem_LCDetails = NULL;
	char *VehRevSeq = NULL;
	char *ERCStat = "T5_LcsErcRlzd";
	char *MBOMStat = "T5_MBOMReleased";
	char *APLPStat = "T5_LcsAplpRlzd";
	char *APLJStat = "T5_LcsApljRlzd";
	char *APLLStat = "T5_LcsApllRlzd";
	char *APLDStat = "T5_LcsApldRlzd";
	char *APLUStat = "T5_LcsApluRlzd";
	char *APLSStat = "T5_LcsAplsRlzd";
	char *APLCStat = "T5_LcsAplRlzd";
	char *APLAStat = "T5_LcsAplaRlzd";
	char *APLVStat = "T5_LcsAplvRlzd";
	char *wbsdesc = NULL;
    wbsdesc = (char *) malloc(200*sizeof(char));
	char Buffer1[MAX_LINE_LENGTH];
	char Buffer2[MAX_LINE_LENGTH];
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	//tc_strcpy(RptFile,"Vehicle_Details_Rpt_File");
	//tc_strcat(RptFile,"_");
	//tc_strcat(RptFile,GenDate);
	tc_strcpy(RptFile,"dc_vehicle_details_from_plm");
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"VEHICLE, REVISION, SEQUENCE, VEHICLE_DESC, VEHICLE_DR_STATUS, VEHICLE_CLASS, FDJ, ESO, NPI_CODE, WBS, WBS_DESC, PPPM_PROJ_CODE, PPPM_VAR_CODE, REMARKS, Release_Status, ERC Released, MBOM Released, APLP Released, APLJ Released, APLL Released, APLD Released, APLU Released, A1A(TIPPER BODY), A1B(CARGO BODY), A1C(SPECIAL APPLICATION), A9Z(CARGO BODY-MFG), D1A(BIW), D1B(CLOSURES & MECHANISM), D1C(EXTERIOR TRIMS), D1D(SCV LOAD BODY), D2A(COCKPIT & CONSOLE), D2B(INTERIOR TRIMS), D2C(SEATS & BERTH), D2D(SAFETY & RESTRANTS), D3A(HVAC), D4A(AMBULANCE), D9W(BIW PAINT COSUMABLES-MFG), D9X(ASSLY BIW COMPLETE-MFG), D9Y(PAINTED BODY SHELL-MFG), D9Z(ASSEMBLED CABIN-MFG), F1A(CHASSIS FRAME), F1B(FIFTH WHEEL COUPLING), F1C(PNEUMATIC SYSTEM), F1D(WINCH SYSTEM), F1E(CHASSIS CONTROLS), F2A(FRONT AXLE/LIFT AXLE), F2B(STEERING SYSTEM), F2C(PROPELLER SHAFT), F2D(LIFT SUSPENSION), F3A(FUEL SYSTEM), F3B(EXHAUST SYSTEM), F3C(ENGINE MOUNTS), F4A(FRONT SUSPENSION), F4B(REAR SUSPENSION), F4C(NA), F5A(BRAKING SYSTEM), F5B(WHEELS AND TYRES), F9Y(FRAME WITH FITMENT (BOLTED/WELDED)), F9Z(ROLLING CHASSIS MFG), G1A(EDS), G1B(SWITCHES), G1C(STARTING CHARGING & WIPING SYSTEM), G2A(LIGHTINGS), G3A(CONNECTIVITY), G3B(DASHBOARD MOUNTED DRIVER INFO SYS-HMI), G4A(POWERTRAIN & DRIVELINE CONTROLLERS), G4B(SAFETY CONTROL), G4C(VEHICLE FUNCTION CONTROLLER), H1A(ENGINE ASSY), H2A(CLUTCH), H2B(FRONT AXLE LIVE), H2C(GEARBOX & SHIFTING), H2D(REAR AXLE), H2E(TRANSFER CASE), H2F(TRANSAXLE), H3A(EV POWERTRAIN & CONTROL), H3B(FC POWERTRAIN &CONTROL), H9W(REAR AXLE ASSY-MFG), H9X(FRONT AXLE ASSY-MFG), H9Y(GEARBOX ASSY-MFG), H9Z(ENGINE ASSY-MFG), K1A(TOOLS & ACCESSORIES), K2A(SOFTWARE CALIBRATION)\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	printf("\n Finding Query[Latest Released Design Revision for ERC]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query Latest Released Design Revision for ERC Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Item ID","Part Type","Type"};
		char *cValues[3]  = {"*","V","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Latest ERC Released Total Vehicle Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
		   //for(i = 0; i < 11; i++)
			{
				DesRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
			    if(tc_strlen(item_id_str)>0)
				{
					tc_strdup(item_id_str,&item_id_strDup);
					trimwhitespace(item_id_strDup);
				}
				else
			    {
					tc_strdup("--",&item_id_strDup);
					printf("\n Vehicle Number Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
			    if(tc_strlen(item_revseq_str)>0)
				{
					tc_strdup(item_revseq_str,&item_revseq_strDup);
					item_rev_strDup=strtok(item_revseq_strDup,";");
			        item_seq_strDup=strtok(NULL,";");
					printf("\n Vehicle Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
					printf("\n Vehicle Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
				}
				else
			    {
					tc_strdup("--",&item_revseq_strDup);
					tc_strdup("--",&item_rev_strDup);
					tc_strdup("--",&item_seq_strDup);
					printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
				printf("\n Vehicle Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
				if(tc_strlen(cItem_Desc)>0)
				{
					tc_strdup(cItem_Desc,&cItem_DescDup);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\n Vehicle Description Value is NULL..!!");fflush(stdout);
				}
				trimwhitespace(cItem_DescDup);
				printf("\n Vehicle Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
			    STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
			    STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
			    STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,""""," ",&cItem_DescDup);
				STRNG_replace_str(cItem_DescDup,"''"," ",&cItem_DescDup);
				printf("\n Vehicle Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&DRStatus));
			    if(tc_strlen(DRStatus)>0)
				{
					tc_strdup(DRStatus,&DRStatusDup);
				}
				else
			    {
					tc_strdup("--",&DRStatusDup);
					printf("\n DR Status Value is NULL..!!");fflush(stdout);
				}
				
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&Platform));
				if(tc_strlen(Platform)>0)
				{
					tc_strdup(Platform,&PlatformDup);
				}
				else
				{
					tc_strdup("--",&PlatformDup);
					printf("\n Platform Value is NULL..!!");fflush(stdout);
				}
				
				printf("\n Function1: FDJ Details Find Start");fflush(stdout);
				FDJNoDup = TC_FDJ_Details(DesRev_tag);
			    printf("\n Function1: FDJ Details Find End\n");fflush(stdout);
				
				printf("\n Function2: ESO Details Find Start");fflush(stdout);
				ESONoDup = TC_ESO_Details(DesRev_tag);
			    printf("\n Function2: ESO Details Find End\n");fflush(stdout);
				
				printf("\n Function3: Classification Attribute Find Start");fflush(stdout);
				tag_t Vc_spec_relation_type = NULLTAG;
				int vcspec_count_f = 0;
				tag_t* Vc_specObjects_f = NULLTAG;
				char *vcspec_item_id_f = NULL;
				char *vcclass_f = NULL;
				tag_t VehMstrTag = NULLTAG;
				int cnt	= 0;
				tag_t *ClsObjTag_results = NULLTAG;
				tag_t ClsObj_f = NULLTAG;
				char *npival = NULL;
				npival = (char *) malloc(100*sizeof(char));
				char *wbsval = NULL;
				wbsval = (char *) malloc(100*sizeof(char));
				char *pppmcodeval = NULL;
				pppmcodeval = (char *) malloc(100*sizeof(char));
				char *pppmvarcodeval = NULL;
				pppmvarcodeval = (char *) malloc(100*sizeof(char));
				char *remarks = NULL;
				remarks = (char *) malloc(10*sizeof(char));

				ITK_CALL(GRM_find_relation_type("T5_VCSpec",&Vc_spec_relation_type));
				if(Vc_spec_relation_type != NULLTAG)
				{
					ITK_CALL(GRM_list_secondary_objects_only(DesRev_tag, Vc_spec_relation_type, &vcspec_count_f, &Vc_specObjects_f));
					printf("\n ----------------------------------------------");fflush(stdout);
					printf("\n Total Tech_Spech Attached with Vehicle: [%d]",vcspec_count_f);fflush(stdout);
					printf("\n ----------------------------------------------\n");fflush(stdout);
					if(vcspec_count_f > 0)
					{
						ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"item_id",&vcspec_item_id_f));
						printf("\n Tech_Spech No: [%s]\n",vcspec_item_id_f);fflush(stdout);
																
						ITK_CALL(AOM_ask_value_string(Vc_specObjects_f[0],"t5_VCClassName",&vcclass_f));
						printf("\n Vehicle Class: [%s]",vcclass_f);fflush(stdout);
						
						if(tc_strlen(vcclass_f) > 0)
						{
							char *getnpicodeval_id = NULL;
							getnpicodeval_id = (char *) malloc(100*sizeof(char));
							char *getwbsval_id = NULL;
							getwbsval_id = (char *) malloc(100*sizeof(char));
							char *getpppmcodeval_id = NULL;
							getpppmcodeval_id = (char *) malloc(100*sizeof(char));
							char *getpppmvarcodeval_id = NULL;
							getpppmvarcodeval_id = (char *) malloc(100*sizeof(char));
							
							if(tc_strcmp(vcclass_f,"MCV")==0)
							{
								printf("\n Attribute_ID Start: [MCV] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"5172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_MCV: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_MCV: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_MCV: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_MCV: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [MCV] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"HCV")==0)
							{
								printf("\n Attribute_ID Start: [HCV] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"6172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_HCV: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_HCV: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_HCV: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_HCV: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [HCV] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"LCV")==0)
							{
								printf("\n Attribute_ID Start: [LCV] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"4172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_LCV: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_LCV: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_LCV: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_LCV: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [LCV] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"LMV")==0)
							{
								printf("\n Attribute_ID Start: [LMV] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"2172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_LMV: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_LMV: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_LMV: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_LMV: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [LMV] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"BUS")==0)
							{
								printf("\n Attribute_ID Start: [BUS] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"7172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_BUS: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_BUS: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_BUS: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_BUS: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [BUS] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"UV_VAN")==0)
							{
								printf("\n Attribute_ID Start: [UV_VAN] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"10172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_UV_VAN: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_UV_VAN: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_UV_VAN: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_UV_VAN: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [UV_VAN] \n");fflush(stdout);
							}
							else if(tc_strcmp(vcclass_f,"ICV")==0)
							{
								printf("\n Attribute_ID Start: [ICV] \n");fflush(stdout);
								tc_strcpy(getnpicodeval_id,"3172");
								tc_strcpy(getwbsval_id,"6100");
								tc_strcpy(getpppmcodeval_id,"6702");
								tc_strcpy(getpppmvarcodeval_id,"6703");
																	
								printf("\n getnpicodeval_id_ICV: [%s]",getnpicodeval_id);fflush(stdout);
								printf("\n getwbsval_id_ICV: [%s]",getwbsval_id);fflush(stdout);
								printf("\n getpppmcodeval_id_ICV: [%s]",getpppmcodeval_id);fflush(stdout);
								printf("\n getpppmvarcodeval_id_ICV: [%s]",getpppmvarcodeval_id);fflush(stdout);
								printf("\n Attribute_ID End: [ICV] \n");fflush(stdout);
							}
							else
							{
								printf("\n VC Class Not Matched..!! \n");fflush(stdout);
							}
							ITK_CALL(ITEM_ask_item_of_rev(DesRev_tag,&VehMstrTag));
							ITK_CALL(AOM_ask_value_tags(VehMstrTag,"IMAN_classification",&cnt,&ClsObjTag_results));
							printf("\n Vehicle Master Object Count: [%d]\n", cnt); fflush(stdout);
							if(cnt > 0)
							{
								ClsObj_f=*ClsObjTag_results;	
								ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getnpicodeval_id,&npival));
								ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getwbsval_id,&wbsval));
								//ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getpppmcodeval_id,&pppmcodeval));
								//ITK_CALL(getClsValueFrmICSTag(ClsObj_f,getpppmvarcodeval_id,&pppmvarcodeval));
								trimwhitespace(getpppmcodeval_id);
								ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getpppmcodeval_id,&pppmcodeval));
								ITK_CALL(getClsValueFrmICSTag_pm(ClsObj_f,getpppmvarcodeval_id,&pppmvarcodeval));
								
                                if(npival!=NULL)trimwhitespace(npival);
                                if(wbsval!=NULL)trimwhitespace(wbsval);						
								printf("\n NPI_CODE: [%s]",npival);fflush(stdout);
								printf("\n WBS: [%s]",wbsval);fflush(stdout);
								printf("\n PPPM Code: [%s]",pppmcodeval); fflush(stdout);
								printf("\n PPPM Varient Code: [%s]",pppmvarcodeval); fflush(stdout);
							}
							else
							{
								printf("\n VC Master Not Found..!! \n");fflush(stdout);
								tc_strcpy(npival,"--");
								tc_strcpy(wbsval,"--");
								tc_strcpy(pppmcodeval,"--");
								tc_strcpy(pppmvarcodeval,"--");
							}				
						}
						else
						{
							printf("\n VC Class Not Found..!! \n");fflush(stdout);
							tc_strcpy(npival,"--");
							tc_strcpy(wbsval,"--");
							tc_strcpy(pppmcodeval,"--");
							tc_strcpy(pppmvarcodeval,"--");
						}
					}
					else
					{
						printf("\n No Tech_Spech Attached with Vehicle..!! \n");fflush(stdout);
						tc_strcpy(npival,"--");
						tc_strcpy(wbsval,"--");
						tc_strcpy(pppmcodeval,"--");
						tc_strcpy(pppmvarcodeval,"--");
					}
				}
				//tc_strcpy(pppmcodeval,"--");
				//tc_strcpy(pppmvarcodeval,"--");
				tc_strcpy(remarks,"--");
				printf("\n Function3: Classification Attribute Find End");fflush(stdout);
				
				printf("\n WBS Value: [%s]",wbsval);fflush(stdout);
				if(tc_strlen(wbsval) > 2)
				{
					printf("\n Function4: WBS Description Find Start");fflush(stdout);
					wbsdesc = TC_WBS_Description(wbsval);
					printf("\n Function4: WBS Description Find End\n");fflush(stdout);
				}
				else
				{
					printf("\n WBS Value Blank So Copy [--]");fflush(stdout);
					tc_strcpy(wbsdesc,"--");
				}
				
				printf("\n Function5: Release Status List Find Start..!!\n");fflush(stdout);
				tc_strcpy(cItem_RevSeq,item_rev_strDup);
	            tc_strcat(cItem_RevSeq,"*");
	            tc_strcat(cItem_RevSeq,item_seq_strDup);
	            printf("Item RevSeq: [%s] \n", cItem_RevSeq);fflush(stdout);
				cItem_LCDetails = TC_PartLCDetails(item_id_strDup,cItem_RevSeq);
			    printf("\n Vehicle Release Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
				printf("\n Function5: Release Status List Find End..!!\n");fflush(stdout);
				
				char *ERC_Status = NULL;
				char *MBOM_Status = NULL;
				char *APLP_Status = NULL;
				char *APLJ_Status = NULL;
				char *APLL_Status = NULL;
				char *APLD_Status = NULL;
				char *APLU_Status = NULL;
				char *APLS_Status = NULL;
				char *APLC_Status = NULL;
				char *APLA_Status = NULL;
				char *APLV_Status = NULL;
				printf("\n Function6: Various Plants Release Date Find Start..!!\n");fflush(stdout);
				ERC_Status = TC_PlantWise_ReleasedDate(DesRev_tag, ERCStat);
				MBOM_Status = TC_PlantWise_ReleasedDate(DesRev_tag, MBOMStat);
				APLP_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLPStat);
				APLJ_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLJStat);
				APLL_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLLStat);
				APLD_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLDStat);
				APLU_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLUStat);
				APLS_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLSStat);
				APLC_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLCStat);
				APLA_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLAStat);
				APLV_Status = TC_PlantWise_ReleasedDate(DesRev_tag, APLVStat);
				printf("\n Function6: Various Plants Release Date Find End..!!\n");fflush(stdout);
				
				char *VehFile = (char *) malloc(50*sizeof(char));
				FILE *VehOutput_file = NULL;
				printf("\n Vehicle Child[First Level] Generation Start..!!");fflush(stdout);
				printf("\n Generating Vehicle Child[99 Level] File Name..!!");fflush(stdout);
				//tc_strcpy(VehFile,"/tmp/");
				tc_strcpy(VehFile,item_id_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,item_rev_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,item_seq_strDup);
				tc_strcat(VehFile,"_");
				tc_strcat(VehFile,GenDate);
				tc_strcat(VehFile,".txt");
				printf("\n Vehicle Child[First Level] Report File Name: [%s]", VehFile);fflush(stdout);
				printf("\n Vehicle Child[First Level] Report File Generated..!!\n");fflush(stdout);
				
				VehOutput_file = fopen(VehFile, "w");
				if(VehOutput_file == NULL)
				{
					printf("\n Unable to Create Vehicle Child[First Level] Report File: --------> [%s]",VehFile);fflush(stdout);
					return 0;
				}
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&VehRevSeq));
				printf("\n Vehicle Vehicle Rev&Seq Before Dup & Trim: ---> <%s> \n",VehRevSeq);fflush(stdout);
				trimwhitespace(VehRevSeq);
				printf("\n Vehicle Vehicle Rev&Seq After Dup & Trim: ---> <%s> \n",VehRevSeq);fflush(stdout);
				printf("\n Vehicle No: [%s]", item_id_strDup);fflush(stdout);
				printf("\n Vehicle Rev&Seq: [%s]", VehRevSeq);fflush(stdout);
				printf("\n Function7: Vehicle Child[First level] Details Find Start");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,VehRevSeq,VehOutput_file);
			    printf("\n Function7: Vehicle Child[First level] Details Find End\n");fflush(stdout);
				fclose(VehOutput_file);
				printf("\n Vehicle Child[First Level] Report File Closed..!!\n");fflush(stdout);
				
				char *DRARFile = NULL;
				DRARFile = (char *) malloc(3000*sizeof(char));
				char *MasterModAgg_Str = NULL;
	            char *ModNo_Str = NULL;
	            char *ModAgg_Str = NULL;
	            char *ModDrAr_Str = NULL;
	            char *ModStat_Str = NULL;
				FILE *fpMaster_List = fopen("/user/cvprod/sourav/VehicleDataReport/MasterList.txt", "r");
				tc_strcpy(DRARFile,"");
                if(fpMaster_List != NULL)
				{
					printf(" Master_File Not Null..!!\n");fflush(stdout);
					while(fgets(Buffer1,MAX_LINE_LENGTH,fpMaster_List)!=NULL)
                    {
						int FinalModStat_Str = 6;
						char *LowestDrArDup = NULL;
                        MasterModAgg_Str=strtok(Buffer1,"^");
                        if(MasterModAgg_Str!=NULL)trimwhitespace(MasterModAgg_Str);
                        printf(" Master Mod Aggregate(MasterModAgg_Str): [%s]\n",MasterModAgg_Str);fflush(stdout);
                        FILE *fpPart_List = fopen(VehFile, "r");						
						if(fpPart_List != NULL)
						{
							printf(" Input_File Not Null..!!\n");fflush(stdout);
							while(fgets(Buffer2,MAX_LINE_LENGTH,fpPart_List)!=NULL)
							{
								ModNo_Str=strtok(Buffer2,"^");
								ModAgg_Str=strtok(NULL,"^");
								ModDrAr_Str=strtok(NULL,"^");
								ModStat_Str=strtok(NULL,"^");
								if(ModAgg_Str!=NULL)trimwhitespace(ModAgg_Str);
								if(ModDrAr_Str!=NULL)trimwhitespace(ModDrAr_Str);
								if(ModStat_Str!=NULL)trimwhitespace(ModStat_Str);
								printf(" Input_File Module Aggregate(ModAgg_Str): [%s]\n",ModAgg_Str);fflush(stdout);
								printf(" Input_File Module AR/DR(ModDrAr_Str): [%s]\n",ModDrAr_Str);fflush(stdout);
								printf(" Input_File Module Status(ModStat_Str): [%s]\n",ModStat_Str);fflush(stdout);
								int ModStat = atoi(ModStat_Str);
								printf(" Module Status(ModStat) in Integer: [%d]\n",ModStat);fflush(stdout);
								if(tc_strcmp(MasterModAgg_Str,ModAgg_Str)==0)
								{
									if(ModStat<=FinalModStat_Str)
									{
										tc_strdup(ModDrAr_Str,&LowestDrArDup);
										FinalModStat_Str = ModStat;
										printf("\n Module Aggregate Matched..!!\n");fflush(stdout);
									}
								}
								else
								{
									printf("\n Module Aggregate Not Matched..!!\n");fflush(stdout);
								}
							}
						}
						else 
						{
							printf("\n Input_File is NULL..!!\n");fflush(stdout);
						}
						fclose(fpPart_List);
						if(tc_strlen(LowestDrArDup)>0)
						{
						  tc_strcat(DRARFile,LowestDrArDup);
						}
						else
						{
						  tc_strcat(DRARFile,"No_Module_Found");
						}
				        tc_strcat(DRARFile,",");
					}
				}
				else 
				{
					printf("\n Master_File is NULL..!!\n");fflush(stdout);
				}
				fclose(fpMaster_List);
				printf("\n AR/DR File: [%s]\n",DRARFile);fflush(stdout);
				
				printf("\n >>>>>>>>>>>>>>> Vehicle Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
				printf("[1] Vehicle_No: [%s]\n",item_id_strDup);fflush(stdout);
				printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
				printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
				printf("[4] Description: [%s]\n",cItem_DescDup);fflush(stdout);
				printf("[5] DR/AR Status: [%s]\n",DRStatusDup);fflush(stdout);
				printf("[6] PlatForm: [%s]\n",PlatformDup);fflush(stdout);
				printf("[7] FDJ[VC Has FDJ Status]: [%s]\n",FDJNoDup);fflush(stdout);
				printf("[8] ESO[Part Has ESO Status]: [%s]\n",ESONoDup);fflush(stdout);
				printf("[9] NPI Code: [%s]\n",npival);fflush(stdout);
				printf("[10] WBS: [%s]\n",wbsval);fflush(stdout);
				printf("[11] WBS Description: [%s]\n",wbsdesc);fflush(stdout);
				printf("[12] PPPM Project Code: [%s]\n",pppmcodeval);fflush(stdout);
				printf("[13] PPPM Variant Code: [%s]\n",pppmvarcodeval);fflush(stdout);
				printf("[14] Remarks: [%s]\n",remarks);fflush(stdout);
				printf("[15] Release Status Details: [%s]\n",cItem_LCDetails);fflush(stdout);
				printf("[16] ERC Release Date: [%s]\n",ERC_Status);fflush(stdout);
				printf("[17] MBOM Release Date: [%s]\n",MBOM_Status);fflush(stdout);
				printf("[18] APLP Release Date: [%s]\n",APLP_Status);fflush(stdout);
				printf("[19] APLJ Release Date: [%s]\n",APLJ_Status);fflush(stdout);
				printf("[20] APLL Release Date: [%s]\n",APLL_Status);fflush(stdout);
				printf("[21] APLD Release Date: [%s]\n",APLD_Status);fflush(stdout);
				printf("[22] APLU Release Date: [%s]\n",APLU_Status);fflush(stdout);
				printf("[23] APLS Release Date: [%s]\n",APLS_Status);fflush(stdout);
				printf("[24] APLC Release Date: [%s]\n",APLC_Status);fflush(stdout);
				printf("[25] APLA Release Date: [%s]\n",APLA_Status);fflush(stdout);
				printf("[26] APLV Release Date: [%s]\n",APLV_Status);fflush(stdout);
				printf("[27] AR/DR File: [%s]\n",DRARFile);fflush(stdout);
				printf("\n >>>>>>>>>>>>>>> Vehicle Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
				
				fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,DRStatusDup,PlatformDup,FDJNoDup,ESONoDup,npival,wbsval,wbsdesc,pppmcodeval,pppmvarcodeval,remarks,cItem_LCDetails,ERC_Status,MBOM_Status,APLP_Status,APLJ_Status,APLL_Status,APLD_Status,APLU_Status,DRARFile);fflush(fpOutput_file);
			}			
		}
		else
        {
			printf(" Vehicle Found Zero[0] on Latest Released Design Revision for ERC..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_VehicleDataReport.c
* // ./linkitk -o tm_VehicleDataReport tm_VehicleDataReport.o
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/VehicleDataReport/tm_VehicleDataReport .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/VehicleDataReport/exepatch.sh .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/VehicleDataReport/usage.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/VehicleDataReport/SendEmail.sh .
* // ./tm_VehicleDataReport -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_VehicleDataReport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/