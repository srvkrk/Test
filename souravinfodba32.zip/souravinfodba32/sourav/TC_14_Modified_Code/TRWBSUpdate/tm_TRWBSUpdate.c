/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Test Request
*  Description  :   Query Test Request & Update WBS & Desc on Test Request
*  File Name    :   tm_TRWBSUpdate.c
*  Created on   :   Sept 05th, 2024
*  Usage        :   tm_TRWBSUpdate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     05/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* MonthAbbreviation (char* MonthNo)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month No in String: --------> [%s]\n", MonthNo);fflush(stdout);
	int monno = atoi(MonthNo);
	printf("\n Input Month No in Integer: --------> [%d]\n", monno);fflush(stdout);
	switch(monno)
   {
	case 1:
	       tc_strcpy(ResponseMonth,"Jan");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 2:
	       tc_strcpy(ResponseMonth,"Feb");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 3:
	       tc_strcpy(ResponseMonth,"Mar");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 4:
	       tc_strcpy(ResponseMonth,"Apr");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 5:
	       tc_strcpy(ResponseMonth,"May");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 6:
	       tc_strcpy(ResponseMonth,"Jun");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 7:
	       tc_strcpy(ResponseMonth,"Jul");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 8:
	       tc_strcpy(ResponseMonth,"Aug");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 9:
	       tc_strcpy(ResponseMonth,"Sep");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 10:
	       tc_strcpy(ResponseMonth,"Oct");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 11:
	       tc_strcpy(ResponseMonth,"Nov");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 12:
	       tc_strcpy(ResponseMonth,"Dec");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	default:
	       printf("Invalid Number");
	       break;
      }
	  
	  return ResponseMonth;
}

char* InputDateFormatConstruct (char* InputDt)
{
	char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpDay=strtok(InputDt,"/");
	InpMonth=strtok(NULL,"/");
	InpYear=strtok(NULL,"/");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
												
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Month Abbreviated Form: [%s]\n", RespMonth);fflush(stdout);
												
	tc_strcpy(FormatDtRlzd,InpDay);
	tc_strcat(FormatDtRlzd,"-");
	tc_strcat(FormatDtRlzd,RespMonth);
	tc_strcat(FormatDtRlzd,"-");
    tc_strcat(FormatDtRlzd,InpYear);
    printf("\n Formatted Input Date: [%s]\n", FormatDtRlzd);fflush(stdout);
	  
	return FormatDtRlzd;
}

char* DateFormatConstruct (char* InputDt)
{
	char* FormatCrDate = (char *) malloc(40*sizeof(char));
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpDay=strtok(InputDt,"-");
	InpMonth=strtok(NULL,"-");
	InpRemainDay=strtok(NULL,"-");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Remain Day: [%s]\n", InpRemainDay);fflush(stdout);
												
	InpYear=strtok(InpRemainDay," ");
	InpRemainMinHour=strtok(NULL," ");
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
	printf("\n Input Remain Minute & Hour: [%s]\n", InpRemainMinHour);fflush(stdout);
												
	InpHour=strtok(InpRemainMinHour,":");
	InpMin=strtok(NULL,":");
												
	printf("\n Input Hour: [%s]\n", InpHour);fflush(stdout);
	printf("\n Input Minute: [%s]\n", InpMin);fflush(stdout);
	
	if(tc_strcmp(InpMonth,"Jan")== 0)
	{
		STRNG_replace_str(InpMonth,"Jan","01",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Feb")== 0)
	{
		STRNG_replace_str(InpMonth,"Feb","02",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Mar")== 0)
	{
		STRNG_replace_str(InpMonth,"Mar","03",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Apr")== 0)
	{
		STRNG_replace_str(InpMonth,"Apr","04",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"May")== 0)
	{
		STRNG_replace_str(InpMonth,"May","05",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Jun")== 0)
	{
		STRNG_replace_str(InpMonth,"Jun","06",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Jul")== 0)
	{
		STRNG_replace_str(InpMonth,"Jul","07",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Aug")== 0)
	{
		STRNG_replace_str(InpMonth,"Aug","08",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Sep")== 0)
	{
		STRNG_replace_str(InpMonth,"Sep","09",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Oct")== 0)
	{
		STRNG_replace_str(InpMonth,"Oct","10",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Nov")== 0)
	{
		STRNG_replace_str(InpMonth,"Nov","11",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Dec")== 0)
	{
		STRNG_replace_str(InpMonth,"Dec","12",&InpMonth);
	}
	else
	{
		printf("Invalid Month");fflush(stdout);
	}
	
	printf("\n Input Month Abbreviated Form: [%s]\n", InpMonth);fflush(stdout);
												
	tc_strcpy(FormatCrDate,InpYear);
	tc_strcat(FormatCrDate,"/");
	tc_strcat(FormatCrDate,InpMonth);
	tc_strcat(FormatCrDate,"/");
    tc_strcat(FormatCrDate,InpDay);
	tc_strcat(FormatCrDate," ");
    tc_strcat(FormatCrDate,InpHour);
    tc_strcat(FormatCrDate,":");
    tc_strcat(FormatCrDate,InpMin);
    printf("\n Formatted Created TimeStamp: [%s]\n", FormatCrDate);fflush(stdout);
	  
	return FormatCrDate;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *RqNo_str = NULL;
	char *Rq_domain_str = NULL;
	char *RqNo_strDup = NULL;
	char *Rq_domain_strDup = NULL;
	int i, k = 0;
	char *From_date_final_strDup = (char *) malloc(400*sizeof(char));
	char *To_date_final_strDup = (char *) malloc(400*sizeof(char));
	char *tr_itemid = NULL;
	char *tr_itemidDup = NULL;
	tag_t tr_tag = NULLTAG;
	tag_t tr_rev_tag = NULLTAG;
	//char *task_template = NULL;
	
	char *tr_bunit = NULL;
	char *tr_bunitDup = NULL;
	char *tr_wbs = NULL;
	char *tr_wbsDup = NULL;
	char *tr_wbsdesc = NULL;
	char *tr_wbsdescDup = NULL;
	char *tr_aggr = NULL;
	char *tr_aggrDup = NULL;
	char *tr_descomp = NULL;
	char *tr_descompDup = NULL;
	char *tr_projcode = NULL;
	char *tr_projcodeDup = NULL;
	char *tr_projdes = NULL;
	char *tr_projdesDup = NULL;
	char *tr_program = NULL;
	char *tr_programDup = NULL;
	char *tr_anlyst = NULL;
	char *tr_anlystDup = NULL;
	char *tr_subgrp = NULL;
	char *tr_subgrpDup = NULL;
	char *tr_testagenloc = NULL;
	char *tr_testagenlocDup = NULL;
	char *tr_LCStatus = NULL;
	char *tr_LCStatusDup = NULL;
	char *tr_PatName = NULL;
	char *tr_PatNameDup = NULL;
	char *tr_lstmodby = NULL;
	char *tr_lstmodbyDup = NULL;
	tag_t RelationFindFIRRpt = NULLTAG;
	tag_t *sec_firrptobjects = NULLTAG;
	int sec_countfirrpt	= 0;
	char *tr_testitemno = NULL;
	char *tr_testitemnoDup = NULL;
	tag_t RelationFindDesRev = NULLTAG;
	tag_t *sec_desrevobjects = NULLTAG;
	int sec_countdesrev	= 0;
	char *tr_partno = NULL;
	char *TR_Part_No = (char *) malloc(100*sizeof(char));
	char *TR_Pending_User = (char *) malloc(5000*sizeof(char));
	char *TR_WFStuck_User = (char *) malloc(5000*sizeof(char));
	char *TR_WFStart_User = (char *) malloc(5000*sizeof(char));
	char *TR_pendingOn = (char *) malloc(5000*sizeof(char));
	char *tr_drwno = NULL;
	char *tr_drwnoDup = NULL;
	char *tr_modfno = NULL;
	char *tr_modfnoDup = NULL;
	char *tr_make = NULL;
	char *tr_makeDup = NULL;
	char *tr_sampleno = NULL;
	char *tr_samplenoDup = NULL;
	char *tr_reqby = NULL;
	char *tr_reqbyDup = NULL;
	char *tr_eqpmnts = NULL;
	char *tr_eqpmntsDup = NULL;
	char *tr_regreq = NULL;
	char *tr_regreqDup = NULL;
	char *tr_tstreason = NULL;
	char *tr_tstreasonDup = NULL;
	char *tr_dtcreate = NULL;
	char *tr_dtcreateDup = NULL;
	char* FormatCreateDate = NULL;
	char *tr_JobName = NULL;
	char *tr_JobNameDup = NULL;
	tag_t tWFobj = NULLTAG;
	int n_WFentries = 2;
	int n_WFobj_found = 0;
	tag_t* tWFobj_results = NULLTAG;
	tag_t WF_Process = NULLTAG;
	int m = 0;
	char *tr_wftaskname = NULL;
	char *tr_wfeventtype = NULL;
	char *tr_wftaskstat = NULL;
	char *tr_wfperformer = NULL;
	char *tr_wftimestampin = NULL;
	char *tr_wftimestampinDup = NULL;
	char *LatestTimeStampIn = NULL;
	//char *tr_pendingon = (char *) malloc(50*sizeof(char));
	//char *tr_tstamp = (char *) malloc(50*sizeof(char));
	
	int tr_MainWFCount = 0;
	tag_t* tr_MainWFObjects = NULLTAG;
	int tr_ActiveWFCount = 0;
	tag_t* tr_ActiveWFObjects = NULLTAG;
	int Req_ActiveWFCount = 0;
	char* tr_WFName = NULL;
	char* tr_Assignee = NULL;
	char* tr_Status = NULL;
	char* tr_StepName = NULL;
	char *tr_Taskstatus = (char *) malloc(50*sizeof(char));
	char *tr_Taskpendingon = (char *) malloc(50*sizeof(char));
	char *tr_Tasktstamp = (char *) malloc(50*sizeof(char));
	
	int tr_JobCount = 0;
	tag_t* tr_JobObj = NULLTAG;
	char* tr_PendingSigUser = NULL;
	char* tr_PendingSigUserDup = NULL;
	
	char* current_name = NULL;
	char* StartDate = NULL;
	int JobCount = 0;
	tag_t* JobObj = NULLTAG;
	int p = 0;
	tag_t JobObjtag = NULLTAG;
	char* Status = NULL;
	char* PendingSigUser = NULL;
	char* StepName = NULL;
	char* tr_creator = NULL;
	char* StuckSigUser = NULL;
	char* StartSigUser = NULL;
	char* From_date_str1 = NULL;
	char* To_date_str1 = NULL;
	char *Rq_domain_str1 = (char *) malloc(50*sizeof(char));
	//int sec_countfirrpt = 0;
	//tag_t* sec_firrptobjects = NULLTAG;
	tag_t tfir_rev = NULLTAG;
	char* tr_firno = NULL;
	char* tr_firpdfdocno = NULL;
	char* DocumentNo_str = NULL;
	char* DocumentNo_strDup = NULL;
	

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	RqNo_str = ITK_ask_cli_argument("-TR=");
	Rq_domain_str = ITK_ask_cli_argument("-RD=");
	//DocumentNo_str = ITK_ask_cli_argument("-DN=");
	
	if(tc_strcmp(Rq_domain_str,"caf")==0)
	{
	  tc_strcpy(Rq_domain_str1,"1D_CAE-Climate_Control");
	}
	else if(tc_strcmp(Rq_domain_str,"caa")==0)
	{
	  tc_strcpy(Rq_domain_str1,"CAE-Aerothermal");
	}
	else if(tc_strcmp(Rq_domain_str,"cac")==0)
	{
	  tc_strcpy(Rq_domain_str1,"CAE-Crash");
	}
	else if(tc_strcmp(Rq_domain_str,"cad")==0)
	{
	  tc_strcpy(Rq_domain_str1,"CAE-Durability");
	}
	else if(tc_strcmp(Rq_domain_str,"cam")==0)
	{
	  tc_strcpy(Rq_domain_str1,"CAE-MBD");
	}
	else if(tc_strcmp(Rq_domain_str,"can")==0)
	{
	  tc_strcpy(Rq_domain_str1,"CAE-NVH");
	}
	else if(tc_strcmp(Rq_domain_str,"tsm")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Climate");
	}
	else if(tc_strcmp(Rq_domain_str,"tsc")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Crash");
	}
	else if(tc_strcmp(Rq_domain_str,"tse")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Engines");
	}
	else if(tc_strcmp(Rq_domain_str,"tsi")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Indoor");
	}
	else if(tc_strcmp(Rq_domain_str,"tmt")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Metallurgy");
	}
	else if(tc_strcmp(Rq_domain_str,"tsn")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-NVH");
	}
	else if(tc_strcmp(Rq_domain_str,"tso")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Outdoor");
	}
	else if(tc_strcmp(Rq_domain_str,"tst")==0)
	{
	  tc_strcpy(Rq_domain_str1,"Testing-Transmission");
	}
	else
	{
	  tc_strcpy(Rq_domain_str1,"NA");
	}
	
	trimwhitespace(RqNo_str);
	trimwhitespace(Rq_domain_str1);
	if(RqNo_str!=NULL)tc_strdup(RqNo_str,&RqNo_strDup);
	if(Rq_domain_str1!=NULL)tc_strdup(Rq_domain_str1,&Rq_domain_strDup);
	//if(DocumentNo_str!=NULL)tc_strdup(DocumentNo_str,&DocumentNo_strDup);
	printf(" [1]: Input Request No(RqNo_strDup): [%s]\n",RqNo_strDup);
	printf(" [2]: Input Request Domain(Rq_domain_strDup): [%s]\n",Rq_domain_strDup);
	//printf(" [2]: Input Test Item Number(DocumentNo_strDup): [%s]\n",DocumentNo_strDup);
	
	ITK_CALL(QRY_find2("Test Request Query",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Test Request Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"ID","Request Domain"};
		char *cValues[2]  = {RqNo_strDup,Rq_domain_strDup};
		//char *cValues[2]  = {"Testing-Indoor-UA/00278","Testing-Indoor"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Test-Request Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Test Request Query Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&tr_itemid));
				if(tc_strlen(tr_itemid)>0)
				{
					tc_strdup(tr_itemid,&tr_itemidDup);
				}
				else
				{
					tc_strdup("NA",&tr_itemidDup);
					printf("\n Test Request No is NULL..!!");fflush(stdout);
				}
				if(tc_strlen(tr_itemidDup)>0)
				{
					printf("\n Test Request No Found..!!");fflush(stdout);
					ITK_CALL(ITEM_find_item(tr_itemidDup, &tr_tag));
                    ITK_CALL(ITEM_find_revision(tr_tag,"A;1",&tr_rev_tag)) ;
                    if(tr_rev_tag  != NULLTAG)
		            {
						ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"last_mod_user",&tr_lstmodby));
						printf("\n Last Modified By Before Dup & Trim:  <%s> \n",tr_lstmodby);fflush(stdout);
						if(tc_strlen(tr_lstmodby)>0)
						{
							tc_strdup(tr_lstmodby,&tr_lstmodbyDup);
						}
						else
						{
							tc_strdup("NA",&tr_lstmodbyDup);
							printf("\n Last Modified By Value is NULL");fflush(stdout);
						}
						trimwhitespace(tr_lstmodbyDup);
						printf("\n Last Modified By After Dup & Trim: [%s]", tr_lstmodbyDup);fflush(stdout);
						STRNG_replace_str(tr_lstmodbyDup,","," ",&tr_lstmodbyDup);
						STRNG_replace_str(tr_lstmodbyDup,";"," ",&tr_lstmodbyDup);
						STRNG_replace_str(tr_lstmodbyDup,"\n"," ",&tr_lstmodbyDup);
						STRNG_replace_str(tr_lstmodbyDup,"'"," ",&tr_lstmodbyDup);
						printf("\n Last Modified By Final Value: [%s]", tr_lstmodbyDup);fflush(stdout);
						
						printf("\n WBS & WBS Desc Update Start..!!\n");fflush(stdout);
						ITK_CALL(AOM_lock(tr_rev_tag));
						ITK_CALL(AOM_set_value_string(tr_rev_tag,"t5_WbsDesc","Caltrop Patronus : High Duty Tipper with"));
						ITK_CALL(AOM_set_value_string(tr_rev_tag,"t5_WBS","P.23.EA.538"));
						ITK_CALL(AOM_save_without_extensions(tr_rev_tag));
						ITK_CALL(AOM_unlock(tr_rev_tag));
						ITK_CALL(AOM_refresh(tr_rev_tag,0));
						printf("\n WBS & WBS Desc Update End..!!\n");fflush(stdout);
				    }
				    else
				    {
					  printf("\n Test Request Rev Tag is NULL..!!\n");fflush(stdout);
				    }
			    }
				else
		        {
			       printf("\n Test Request No is NULL..!!");fflush(stdout);
		        }
		    }
		}
		else
		{
			printf("\n Test Request Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Test Request Query Tag is NULL..!!");fflush(stdout);
	}
	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_TRWBSUpdate.c
* // ./linkitk -o tm_TRWBSUpdate tm_TRWBSUpdate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/TRWBSUpdate/tm_TRWBSUpdate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/TRWBSUpdate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/TRWBSUpdate/usage.txt .
* // ./tm_TRWBSUpdate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -TR="Testing-Transmission-UA/00043" -RD="tst"
* // ./tm_TRWBSUpdate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -TR="Testing-Transmission-UA/00043" -RD="tst"
*
***************************************************************************/