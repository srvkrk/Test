/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   MCC
*  Description  :   Vehicle Compliance Cron Part2
*  File Name    :   tm_VehComplianceCronPart2.c
*  Created on   :   Nov 07th, 2024
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     07/11/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_DSSet(char *FDSName, char *VSFile)
{	
	trimwhitespace(FDSName);
	tag_t tDSNQryobj = NULLTAG;
	int nds_entries = 1;
	int ds_Qryobj_found = 0;
	tag_t* tdsQryobj_results = NULLTAG;
	int u = 0;
	char temp[10000];
	char *VID_Str = NULL;
	char *VR_Str = NULL;
	char *VS_Str = NULL;
	char *VDes_Str = NULL;
	char *VPlat_Str = NULL;
	char *VDr_Str = NULL;
	char *VTotal_Str = NULL;
	char *VPresent_Str = NULL;
	char *VNotPresent_Str = NULL;
	char *VAbove_Str = NULL;
	char *VBelow_Str = NULL;
	char *VMax_Str = NULL;
	char *VAll_Str = NULL;
	char *VDT_Str = NULL;
	char *STData = (char *) malloc(500*sizeof(char));
	FILE *fpres_List = NULL;
	int iFail = ITK_ok;
	tag_t PropName_AttrID = NULLTAG;
	
	printf("\n Searched Dataset Name: [%s]\n", FDSName);fflush(stdout);
	printf("\n Searched File Name with Location: [%s]\n", VSFile);fflush(stdout);
    ITK_CALL(QRY_find2("Dataset Name",&tDSNQryobj));
    if(tDSNQryobj!=NULLTAG)
	{
		printf("\n Dataset Name Query Found Successfully..!!");fflush(stdout);
		char *DSEntries[1]  = {"Dataset Name"};
		char *DSValues[1]  = {FDSName};
		ITK_CALL(QRY_execute(tDSNQryobj, nds_entries, DSEntries, DSValues, &ds_Qryobj_found, &tdsQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Dataset Name Found: [%d]\n",ds_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(ds_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (u = 0; u < ds_Qryobj_found; u++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tdsQryobj_results[u];
				if(rev_tags_found != NULLTAG)
				{	
			        fpres_List = fopen(VSFile,"r");
					if(fpres_List != NULL)
					{	
						printf("\n Output Response File Not Null Moving Forward..!!");fflush(stdout);
						while(fgets(temp, 10000, fpres_List)!= NULL)
						{
							VID_Str=strtok(temp,"^");
							VR_Str=strtok(NULL,"^");
							VS_Str=strtok(NULL,"^");
							VDes_Str=strtok(NULL,"^");
							VPlat_Str=strtok(NULL,"^");
							VDr_Str=strtok(NULL,"^");
							VTotal_Str=strtok(NULL,"^");
							VPresent_Str=strtok(NULL,"^");
							VNotPresent_Str=strtok(NULL,"^");
							VAbove_Str=strtok(NULL,"^");
							VBelow_Str=strtok(NULL,"^");
							VMax_Str=strtok(NULL,"^");
							VAll_Str=strtok(NULL,"^");
							VDT_Str=strtok(NULL,"^");
							
							tc_strcpy(STData,VID_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VR_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VS_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VDes_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VPlat_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VDr_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VTotal_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VPresent_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VNotPresent_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VAbove_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VBelow_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VMax_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VAll_Str);
							tc_strcat(STData,",");
							tc_strcat(STData,VDT_Str);
							tc_strcat(STData,",");
							trimwhitespace(STData);
							printf("\n Response Data1: [%s]", STData);fflush(stdout);
						}
						fclose(fpres_List) ;           
				        printf("\n All Output data Read Successfully From The File..!!\n");fflush(stdout);
					}
					printf("\n Response Data2: [%s]", STData);fflush(stdout);
					printf("\n Output Data Stamp Start..!!\n");fflush(stdout);
					printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
					ITK_CALL(AOM_refresh(tdsQryobj_results[u], POM_modify_lock));
					printf("\n Lock..!!\n");
					ITK_CALL(POM_attr_id_of_attr("object_desc", "Dataset", &PropName_AttrID));
					printf("\n Property Name Tag Found..!!\n");
					//ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID, item_propvalue_strDup));
					//item_propvalue_strDupInt = atoi(item_propvalue_strDup);
					//ITK_CALL(POM_set_attr_string(1, &tdsQryobj_results[u], PropName_AttrID, "51530535R,B,2,712 LPT DCR35HSD 125B6M5 TT,ILMCV_LPT,DR3,0.000000,17_Jul_2024_18_04_01,"));
					ITK_CALL(POM_set_attr_string(1, &tdsQryobj_results[u], PropName_AttrID, STData));
					printf("\n Set Property Value..!!\n");
					ITK_CALL(POM_save_instances(1, &tdsQryobj_results[u], true));
					printf("\n Save...!!\n");
					ITK_CALL(AOM_refresh(tdsQryobj_results[u], POM_no_lock));
					printf("\n Unlock..!!\n");
					printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
					printf("\n Output Data Stamp End..!!\n");fflush(stdout);
				}
				else
				{
					printf("\n Revision Tag Not Found..!!");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n Entered Dataset Name Not Found..!!");fflush(stdout);
		}	
	}
	else
	{
		printf("\n Dataset Name Tag Not Found..!!");fflush(stdout);
	}
	
	return iFail;	
}

int TC_Folder_Attach(char* FAttachRptFile, char* VDetFile, char* PartNum, char* PartRevision, char* PartSequence, char* PartDRAR, char* GenDate)
{
	int iFail = ITK_ok;
	printf("\n Report File Attach To [VEHICLE_SUBMODULE_COMPLIANCE_REPORT] Folder Start..!!\n");fflush(stdout);
	char *item_rs_strDup = NULL;
	char *item_rs_str= (char *) malloc(20*sizeof(char));
	tc_strcpy(item_rs_str,PartRevision);
	tc_strcat(item_rs_str,"*");
	tc_strcat(item_rs_str,PartSequence);
	if(item_rs_str!=NULL)tc_strdup(item_rs_str,&item_rs_strDup);
	printf(" Item Rev & Seq(item_rs_strDup): [%s]\n",item_rs_strDup);
	//char *Filename = NULL;
	//char *FileLoc = NULL;
	//char *dataSetName = NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	//dataSetName = (char *) MEM_alloc(100 * sizeof(char));
	char *dataSetName = (char *) malloc(100*sizeof(char));
	tc_strcpy(dataSetName,"VCR");
	tc_strcat(dataSetName,"_");
	tc_strcat(dataSetName,PartNum);
	tc_strcat(dataSetName,"_");
	tc_strcat(dataSetName,PartRevision);
	tc_strcat(dataSetName,"_");
	tc_strcat(dataSetName,PartSequence);
	tc_strcat(dataSetName,"_");
	tc_strcat(dataSetName,PartDRAR);
	tc_strcat(dataSetName,"_");
	tc_strcat(dataSetName,GenDate);
	printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
	
	//Filename = (char *) MEM_alloc(100 * sizeof(char));
	//FileLoc = (char *) MEM_alloc(100 * sizeof(char));
	char *Filename = (char *) malloc(100*sizeof(char));
	char *FileLoc = (char *) malloc(100*sizeof(char));
	tc_strcpy(Filename,FAttachRptFile);
	printf(" File Name: [%s]\n", Filename);fflush(stdout);

	//tc_strcpy(FileLoc,"/user/cvprod/sourav/ReportBuilderPartAppRpt/");
	//tc_strcat(FileLoc,Filename);
	tc_strcpy(FileLoc,Filename);
	printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

	ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
	ITK_CALL(AE_find_tool2("MSExcel", &tool));
	ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
	ITK_CALL(AOM_save_without_extensions(Newdataset));	
	ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
	if(filetag == NULLTAG)
	{
		printf(" File Tag Not Found..!!\n");fflush(stdout);
	}
	ITK_CALL(AOM_refresh(Newdataset,TRUE));
	ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
	ITK_CALL(AOM_save_without_extensions(Newdataset));
	ITK_CALL(AOM_refresh(Newdataset,FALSE));
	
	tag_t tFolder = NULLTAG;
	int n_fentries = 2;
	int n_fitemobj_found = 0;
	tag_t* ftitemobj_results = NULLTAG;
	int t = 0;
	printf("\n Finding Query[General...]..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("General...",&tFolder));
	if(tFolder != NULLTAG)
	{
		printf("\n General... Query Found Successfully..!!\n");fflush(stdout);
		char *fEntries[2]  = {"Name","Type"};
		char *fValues[2]  = {"VEHICLE_SUBMODULE_COMPLIANCE_REPORT","Folder"};
		//char *cValues[2]  = {"VEHICLE_SUBMODULE_COMPLIANCE_REPORT","Folder"};
		ITK_CALL(QRY_execute(tFolder, n_fentries, fEntries, fValues, &n_fitemobj_found, &ftitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Folder Found: [%d]\n",n_fitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_fitemobj_found > 0)
		{
			printf(" Folder[VEHICLE_SUBMODULE_COMPLIANCE_REPORT] Found..!!\n");fflush(stdout);
			for(t = 0; t < n_fitemobj_found; t++)
			{
				tHomeFolder = ftitemobj_results[t];
			}
		}
		else
		{
			printf(" Folder[VEHICLE_SUBMODULE_COMPLIANCE_REPORT] Not Found..!!\n");fflush(stdout);
		}
	}
	//ITK_CALL(SA_find_user2(user_id_strDup,&tUser));
	//ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
	ITK_CALL(AOM_lock(tHomeFolder));
	ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
	ITK_CALL(AOM_save_without_extensions(tHomeFolder));
	ITK_CALL(AOM_unlock(tHomeFolder));
	printf("\n Report File Attach To [VEHICLE_SUBMODULE_COMPLIANCE_REPORT] Folder End..!!\n");fflush(stdout);
	printf("\n Report File Attach To [VEHICLE REVISION REFERENCE FOLDER] Start..!!\n");fflush(stdout);
	tag_t tVRItemobj = NULLTAG;
	int n_vrentries = 2;
	int n_vritemobj_found = 0;
	tag_t* tvritemobj_results = NULLTAG;
	int s = 0;
	tag_t vhrevision_tag = NULLTAG;
	ITK_CALL(QRY_find2("DesignRevision Sequence",&tVRItemobj));
    if(tVRItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
		char *cVREntries[2]  = {"Revision","ID"};
		char *cVRValues[2]  = {item_rs_strDup,PartNum};
		//char *cValues[2]  = {"A;2","51642352R"};
	    ITK_CALL(QRY_execute(tVRItemobj, n_vrentries, cVREntries, cVRValues, &n_vritemobj_found, &tvritemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_vritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vritemobj_found > 0)
		{
			for (s = 0; s < n_vritemobj_found; s++)
		    {
				vhrevision_tag = tvritemobj_results[s];
				tag_t relation_type = NULLTAG;
				tag_t relation = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type));
				ITK_CALL(GRM_create_relation(vhrevision_tag,Newdataset,relation_type,NULLTAG,&relation));
				ITK_CALL(GRM_save_relation(relation));
			}
		}
	}
	printf("\n Report File Attach To [VEHICLE REVISION REFERENCE FOLDER] End..!!\n");fflush(stdout);
	printf(" Property Stamp Start..!!\n");fflush(stdout);
	TC_DSSet(dataSetName, VDetFile);
	printf(" Property Stamp End..!!\n");fflush(stdout);
	
	return iFail;
}

char* TC_LibraryStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* SubModStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup("Yes",&SubModStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("No",&SubModStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("No",&SubModStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("No",&SubModStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModStatus;
}

char* TC_LibraryRevStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* SubModRevStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModRev,&SubModRevStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModRevStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModRevStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModRevStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModRevStatus;
}

char* TC_LibrarySeqStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* SubModSeqStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModSeq,&SubModSeqStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModSeqStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModSeqStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModSeqStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModSeqStatus;
}

char* TC_LibraryGateStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* Tbl_SubModDrAr = NULL;
	char* SubModDrArStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_drarstatus", &Tbl_SubModDrAr));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					printf("\n Table SubModule AR/DR: [%s]",Tbl_SubModDrAr);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					if(Tbl_SubModDrAr!=NULL)trimwhitespace(Tbl_SubModDrAr);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModDrAr,&SubModDrArStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModDrArStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModDrArStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModDrArStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModDrArStatus;
}

char* TC_LibraryMaxGateStatus(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* Tbl_SubModDrAr = NULL;
	char* Tbl_SubModMaxDrAr = NULL;
	char* SubModMaxDrArStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_drarstatus", &Tbl_SubModDrAr));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_info3", &Tbl_SubModMaxDrAr));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					printf("\n Table SubModule AR/DR: [%s]",Tbl_SubModDrAr);fflush(stdout);
					printf("\n Table SubModule Max AR/DR: [%s]",Tbl_SubModMaxDrAr);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					if(Tbl_SubModDrAr!=NULL)trimwhitespace(Tbl_SubModDrAr);
					if(Tbl_SubModMaxDrAr!=NULL)trimwhitespace(Tbl_SubModMaxDrAr);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModMaxDrAr,&SubModMaxDrArStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModMaxDrArStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModMaxDrArStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModMaxDrArStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModMaxDrArStatus;
}

char* TC_LibraryVehLinkFreq(char* SAddr, char* SNo, char* SRev, char* SSeq)
{
	trimwhitespace(SAddr);
	trimwhitespace(SNo);
	trimwhitespace(SRev);
	trimwhitespace(SSeq);
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
    char* Tbl_SubModNo = NULL;
	char* Tbl_SubModRev = NULL;
	char* Tbl_SubModSeq = NULL;
	char* Tbl_SubModDrAr = NULL;
	char* Tbl_SubModVehLink = NULL;
	char* SubModVehLinkFreqStatus = NULL;
	
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {SAddr};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\n SubModule Address Revision Exist So Continue To Check Submodule Present or Not..!!\n");fflush(stdout);
			tsubmodlib_rev = titemobj_results[0];
			ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
			printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SAddr);fflush(stdout);
			if(n_valid_rows>0)
			{
				for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
				{
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_submoduleno", &Tbl_SubModNo));	
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_rev", &Tbl_SubModRev));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_seq", &Tbl_SubModSeq));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_drarstatus", &Tbl_SubModDrAr));
					ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt], "t5_info1", &Tbl_SubModVehLink));
					printf("\n Table SubModule No: [%s]",Tbl_SubModNo);fflush(stdout);
					printf("\n Table SubModule Rev: [%s]",Tbl_SubModRev);fflush(stdout);
					printf("\n Table SubModule Seq: [%s]",Tbl_SubModSeq);fflush(stdout);
					printf("\n Table SubModule AR/DR: [%s]",Tbl_SubModDrAr);fflush(stdout);
					printf("\n Table SubModule Vehicle Link Frequency: [%s]",Tbl_SubModVehLink);fflush(stdout);
					if(Tbl_SubModNo!=NULL)trimwhitespace(Tbl_SubModNo);
					if(Tbl_SubModRev!=NULL)trimwhitespace(Tbl_SubModRev);
					if(Tbl_SubModSeq!=NULL)trimwhitespace(Tbl_SubModSeq);
					if(Tbl_SubModDrAr!=NULL)trimwhitespace(Tbl_SubModDrAr);
					if(Tbl_SubModVehLink!=NULL)trimwhitespace(Tbl_SubModVehLink);
					//if((tc_strcmp(SNo,Tbl_SubModNo)==0) && (tc_strcmp(SRev,Tbl_SubModRev)==0) && (tc_strcmp(SSeq,Tbl_SubModSeq)==0))
					if(tc_strcmp(SNo,Tbl_SubModNo)==0)
					{
						printf("\n Input SubModule No And Table SubModule No Matched So Exit..!!\n");fflush(stdout);
						tc_strdup(Tbl_SubModVehLink,&SubModVehLinkFreqStatus);
                        goto jump;						
					}
					else
					{
						printf("\n Input SubModule No And Table SubModule Not Matched..!!\n");fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n No Table Row Found For Input SubModule Address: [%s], SAddr\n");fflush(stdout);
				tc_strdup("NA",&SubModVehLinkFreqStatus);
			}    
		}
		else
		{
		   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
		   tc_strdup("NA",&SubModVehLinkFreqStatus);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
		tc_strdup("NA",&SubModVehLinkFreqStatus);
	}
	
	jump:
	   printf("\n Input SubModule No And Table SubModule No Matched..!!\n");fflush(stdout);
	   
	return SubModVehLinkFreqStatus;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport, char* VNo, char* VRev, char* VSeq, char* VRpt, FILE* FP_VComRpt, char* VFResData, char* MainDesc, char* MainDrAr)
{
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cItem_Desc = NULL;
		char* cModAddress = NULL;
		char* cProdLine = NULL;
		char* cProdLineDup = NULL;
		char* cPlatform = NULL;
		char* cPlatformDup = NULL;
		char* cProjCode = NULL;
	    char* cProjCodeDup = NULL;
	    char* cDesGrp = NULL;
	    char* cDesGrpDup = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
	    tag_t PrtMstrTag = NULLTAG;
	    char *MstrUOMTag = NULL;
	    char *MstrUOMTagDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* LibStatus = NULL;
		char* LibRevStatus = NULL;
		char* LibSeqStatus = NULL;
		char* LibGateStatus = NULL;
		char* LibMaxGateStatus = NULL;
		char* LibVehLinkFreqStatus = NULL;
		int yescount = 0;
		int nocount = 0;
		int maxdrpasscount = 0;
		int maxdrfailcount = 0;
		int compliance = 0;
		int totalcount = 0;
		double finalcompliance;
		char total[10];
		char totalpresent[10];
		char totalnotpresent[10];
		char complianceper[10];
		char maxdrpasscountdup[10];
		char maxdrfailcountdup[10];
		int maxcompliance = 0;
		int allcompliance = 0;
		double maxdrfinalcompliance;
		double alldrfinalcompliance;
		char* totalpresentDup = NULL;
		char* totalnotpresentDup = NULL;
		char* maxdrpasscountdupfinal = NULL;
		char* maxdrfailcountdupfinal = NULL;
		char *PreVCompFile = (char *) malloc(100*sizeof(char));
		int slno = 1;
		char finalslno[10];
		char DTStamp[100] = "";
		time_t 	dtnow;
		struct 	tm dtwhen;
		time(&dtnow);
		dtwhen = *localtime(&dtnow);
		strftime(DTStamp,100,"%d_%b_%Y_%H_%M_%S",&dtwhen);
		printf(" Current TimeStamp: [%s]\n", DTStamp);fflush(stdout);
		
		printf("\n Generating XML Report File Name..!!");fflush(stdout);
		tc_strcpy(PreVCompFile,"/tmp/");
		tc_strcat(PreVCompFile,"VehicleComplianceReport");
		tc_strcat(PreVCompFile,"_");
		tc_strcat(PreVCompFile,DTStamp);
		tc_strcat(PreVCompFile,".xml");
		//Report = fopen("/tmp/VehicleComplianceReport.xml","w");
		printf("\n Pre Vehicle Compliance Report File Name: [%s]", PreVCompFile);fflush(stdout);
		
		Report = fopen(PreVCompFile,"w");
		if(Report == NULL)
		{
			printf("ERROR: Unable To Open XML File..!!\n");
			return -1;
		}
		else
		{
			printf("XML File Opened Successfully..!!\n");
		}
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	    write2xml(Report,"<VehCompliance>\n");
		for(j = 0; j < iSubSubNumber_Child; j++)
		{	
	
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Desc = TC_PartDesc(cItem_Id,cItem_RevSeq);
			printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			cModAddress = subString(cItem_Id, 4, 5);
			trimwhitespace(cModAddress);
			printf("\n Part Module Address Value: [%s]", cModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Platform", &cProdLine));
			if(tc_strlen(cProdLine)>0)
			{
				tc_strdup(cProdLine,&cProdLineDup);
			}
			else
			{
				tc_strdup("--",&cProdLineDup);
				printf("\n Product Line Value is NULL");fflush(stdout);
			}
			trimwhitespace(cProdLineDup);
			printf("\n Product Line Value After Dup & Trim: [%s]\n", cProdLineDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_Platform", &cPlatform));
			if(tc_strlen(cPlatform)>0)
			{
				tc_strdup(cPlatform,&cPlatformDup);
			}
			else
			{
				tc_strdup("--",&cPlatformDup);
				printf("\n Platform Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPlatformDup);
			printf("\n Platform Value After Dup & Trim: [%s]\n", cPlatformDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_ProjectCode", &cProjCode));
			if(tc_strlen(cProjCode)>0)
			{
				tc_strdup(cProjCode,&cProjCodeDup);
			}
			else
			{
				tc_strdup("--",&cProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(cProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", cProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_DesignGrp", &cDesGrp));
			if(tc_strlen(cDesGrp)>0)
			{
				tc_strdup(cDesGrp,&cDesGrpDup);
			}
			else
			{
				tc_strdup("--",&cDesGrpDup);
				printf("\n Design Group Value is NULL");fflush(stdout);
			}
			trimwhitespace(cDesGrpDup);
			printf("\n Design Group Value After Dup & Trim: [%s]\n", cDesGrpDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			if(tc_strlen(cQuantity)>0)
			{
				tc_strdup(cQuantity,&cQuantityDup);
			}
			else
			{
				tc_strdup("--",&cQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(cQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(cItem_Id,&PrtMstrTag));
			if(PrtMstrTag != NULLTAG)
			{
			   ITK_CALL(AOM_UIF_ask_value(PrtMstrTag,"uom_tag",&MstrUOMTag));
			}
			if(MstrUOMTag!=NULL)
			{
				tc_strdup(MstrUOMTag,&MstrUOMTagDup);
			}
			else
			{
				tc_strdup("--",&MstrUOMTagDup);
				printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
			}
			printf("\n Master Unit of Measure Tag[uom_tag]: [%s]\n", MstrUOMTagDup);fflush(stdout);
			tostring(finalslno, slno);
			
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nSerial No: [%s]", finalslno);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Description: [%s]", cItem_Desc);
			printf("\nChild_Level Part Address: [%s]", cModAddress);
			printf("\nChild_Level Part Product Line: [%s]", cProdLineDup);
			printf("\nChild_Level Part Platform: [%s]", cPlatformDup);
			printf("\nChild_Level Project Code: [%s]", cProjCodeDup);
			printf("\nChild_Level Design Group: [%s]", cDesGrpDup);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\nChild_Level Part Quantity: [%s]", cQuantityDup);
			printf("\nChild_Level UOM Tag: [%s]", MstrUOMTagDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0)
				{
					totalcount = totalcount + 1;
					printf("\n Function2: SubModule Library Status Find Start\n");fflush(stdout);
                    LibStatus = TC_LibraryStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function2: SubModule Library Status Find End\n");fflush(stdout);
					printf("\n Function3: SubModule Library Rev Status Find Start\n");fflush(stdout);
                    LibRevStatus = TC_LibraryRevStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function3: SubModule Library Rev Status Find End\n");fflush(stdout);
					printf("\n Function4: SubModule Library Seq Status Find Start\n");fflush(stdout);
                    LibSeqStatus = TC_LibrarySeqStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function4: SubModule Library Seq Status Find End\n");fflush(stdout);
					printf("\n Function5: SubModule Library Gateway Status Find Start\n");fflush(stdout);
                    LibGateStatus = TC_LibraryGateStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function5: SubModule Library Gateway Status Find End\n");fflush(stdout);
					printf("\n Function6: SubModule Library Max Gateway Status Find Start\n");fflush(stdout);
                    LibMaxGateStatus = TC_LibraryMaxGateStatus(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function6: SubModule Library Max Gateway Status Find End\n");fflush(stdout);
					printf("\n Function7: SubModule Library Vehicle Linkage Frequency Find Start\n");fflush(stdout);
                    LibVehLinkFreqStatus = TC_LibraryVehLinkFreq(cModAddress,cItem_Id,cItem_Rev,cItem_Seq);
					printf("\n Function7: SubModule Library Vehicle Linkage Frequency Find End\n");fflush(stdout);
					if(tc_strcmp(LibStatus,"Yes")==0)
					{
						yescount = yescount + 1;
						if((tc_strcmp(LibMaxGateStatus,"DR4")==0) || (tc_strcmp(LibMaxGateStatus,"AR4")==0) || (tc_strcmp(LibMaxGateStatus,"DR5")==0) || (tc_strcmp(LibMaxGateStatus,"AR5")==0))
						{
							maxdrpasscount = maxdrpasscount + 1;
						}
						else
						{
							maxdrfailcount = maxdrfailcount + 1;
						}
					}
					else
					{
						nocount = nocount + 1;
					}
				    fprintf(FP_OutputReport,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",finalslno,cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,cModAddress,cProdLineDup,cPlatformDup,cProjCodeDup,cDesGrpDup,cArDrStatusDup,cPartTypeDup,cQuantityDup,MstrUOMTagDup,LibVehLinkFreqStatus,LibStatus,LibRevStatus,LibSeqStatus,LibGateStatus,LibMaxGateStatus);fflush(FP_OutputReport);
					if(cItem_Desc != NULL)
					{
						STRNG_replace_str(cItem_Desc,"&","&amp;",&cItem_Desc);
						STRNG_replace_str(cItem_Desc,"<","&lt;",&cItem_Desc);
						STRNG_replace_str(cItem_Desc,">","&gt;",&cItem_Desc);
					}
					write2xml(Report,"<Compliance>\n");
					write2xml(Report,"<SlNo>"); if(tc_strlen(finalslno)>0) write2xml(Report,finalslno); else write2xml(Report,"NA"); write2xml(Report,"</SlNo>\n");
					write2xml(Report,"<PartNo>"); if(tc_strlen(cItem_Id)>0) write2xml(Report,cItem_Id); else write2xml(Report,"NA"); write2xml(Report,"</PartNo>\n");
					write2xml(Report,"<PartRev>"); if(tc_strlen(cItem_Rev)>0) write2xml(Report,cItem_Rev); else write2xml(Report,"NA"); write2xml(Report,"</PartRev>\n");
					write2xml(Report,"<PartSeq>"); if(tc_strlen(cItem_Seq)>0) write2xml(Report,cItem_Seq); else write2xml(Report,"NA"); write2xml(Report,"</PartSeq>\n");
					write2xml(Report,"<PartDesc>"); if(tc_strlen(cItem_Desc)>0) write2xml(Report,cItem_Desc); else write2xml(Report,"NA"); write2xml(Report,"</PartDesc>\n");
					write2xml(Report,"<PartAddr>"); if(tc_strlen(cModAddress)>0) write2xml(Report,cModAddress); else write2xml(Report,"NA"); write2xml(Report,"</PartAddr>\n");
					write2xml(Report,"<ProdLine>"); if(tc_strlen(cProdLineDup)>0) write2xml(Report,cProdLineDup); else write2xml(Report,"NA"); write2xml(Report,"</ProdLine>\n");
					write2xml(Report,"<Platform>"); if(tc_strlen(cPlatformDup)>0) write2xml(Report,cPlatformDup); else write2xml(Report,"NA"); write2xml(Report,"</Platform>\n");
					write2xml(Report,"<ProjCode>"); if(tc_strlen(cProjCodeDup)>0) write2xml(Report,cProjCodeDup); else write2xml(Report,"NA"); write2xml(Report,"</ProjCode>\n");
					write2xml(Report,"<DesGrp>"); if(tc_strlen(cDesGrpDup)>0) write2xml(Report,cDesGrpDup); else write2xml(Report,"NA"); write2xml(Report,"</DesGrp>\n");
					write2xml(Report,"<DrAr>"); if(tc_strlen(cArDrStatusDup)>0) write2xml(Report,cArDrStatusDup); else write2xml(Report,"NA"); write2xml(Report,"</DrAr>\n");
					write2xml(Report,"<PartType>"); if(tc_strlen(cPartTypeDup)>0) write2xml(Report,cPartTypeDup); else write2xml(Report,"NA"); write2xml(Report,"</PartType>\n");
					write2xml(Report,"<Qty>"); if(tc_strlen(cQuantityDup)>0) write2xml(Report,cQuantityDup); else write2xml(Report,"NA"); write2xml(Report,"</Qty>\n");
					write2xml(Report,"<UOM>"); if(tc_strlen(MstrUOMTagDup)>0) write2xml(Report,MstrUOMTagDup); else write2xml(Report,"NA"); write2xml(Report,"</UOM>\n");
					write2xml(Report,"<VehFreq>"); if(tc_strlen(LibVehLinkFreqStatus)>0) write2xml(Report,LibVehLinkFreqStatus); else write2xml(Report,"NA"); write2xml(Report,"</VehFreq>\n");
					write2xml(Report,"<Status>"); if(tc_strlen(LibStatus)>0) write2xml(Report,LibStatus); else write2xml(Report,"No"); write2xml(Report,"</Status>\n");
					write2xml(Report,"<LibRev>"); if(tc_strlen(LibRevStatus)>0) write2xml(Report,LibRevStatus); else write2xml(Report,"No"); write2xml(Report,"</LibRev>\n");
					write2xml(Report,"<LibSeq>"); if(tc_strlen(LibSeqStatus)>0) write2xml(Report,LibSeqStatus); else write2xml(Report,"No"); write2xml(Report,"</LibSeq>\n");
					write2xml(Report,"<LibGate>"); if(tc_strlen(LibGateStatus)>0) write2xml(Report,LibGateStatus); else write2xml(Report,"NA"); write2xml(Report,"</LibGate>\n");
					write2xml(Report,"<LibMax>"); if(tc_strlen(LibMaxGateStatus)>0) write2xml(Report,LibMaxGateStatus); else write2xml(Report,"NA"); write2xml(Report,"</LibMax>\n");
					write2xml(Report,"</Compliance>\n");
					
				    slno = slno + 1;
				}
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				printf("\n!!!!!!!!!! I N N E R  C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
		compliance = (yescount * 100);
		maxcompliance = (maxdrpasscount * 100);
		//allcompliance = (maxdrfailcount * 100);
		finalcompliance = (double) compliance / totalcount;
		maxdrfinalcompliance = (double) maxcompliance / totalcount;
		alldrfinalcompliance = (double) compliance / totalcount;
		tostring(total, totalcount);
		tostring(totalpresent, yescount);
		tostring(totalnotpresent, nocount);
		tostring(maxdrpasscountdup, maxdrpasscount);
		tostring(maxdrfailcountdup, maxdrfailcount);
		if(tc_strlen(totalpresent)>0)
		{
			tc_strdup(totalpresent,&totalpresentDup);
		}
		else
		{
			tc_strdup("0",&totalpresentDup);
			printf("\n Total Present Value is NULL");fflush(stdout);
		}
		if(tc_strlen(totalnotpresent)>0)
		{
			tc_strdup(totalnotpresent,&totalnotpresentDup);
		}
		else
		{
			tc_strdup("0",&totalnotpresentDup);
			printf("\n Total Not Present Value is NULL");fflush(stdout);
		}
		if(tc_strlen(maxdrpasscountdup)>0)
		{
			tc_strdup(maxdrpasscountdup,&maxdrpasscountdupfinal);
		}
		else
		{
			tc_strdup("0",&maxdrpasscountdupfinal);
			printf("\n No of Max DR4 and Above Submodules is NULL");fflush(stdout);
		}
		if(tc_strlen(maxdrfailcountdup)>0)
		{
			tc_strdup(maxdrfailcountdup,&maxdrfailcountdupfinal);
		}
		else
		{
			tc_strdup("0",&maxdrfailcountdupfinal);
			printf("\n No of Below DR4 Submodules is NULL");fflush(stdout);
		}
		printf("\n############ R E P O R T ############\n");fflush(stdout);
		printf("Total: %s\n", total);fflush(stdout);
		printf("Total Present: %s\n", totalpresentDup);fflush(stdout);
		printf("Total Not Present: %s\n", totalnotpresentDup);fflush(stdout); 
		printf("Compliance in Double: %lf\n", finalcompliance);fflush(stdout);
		char sfinalcompliance[100]; 
		sprintf(sfinalcompliance, "%.2f", finalcompliance); 
		printf("Compliance in String: [%s]", sfinalcompliance);fflush(stdout);
		char smaxdrfinalcompliance[100];
		char salldrfinalcompliance[100]; 
		sprintf(smaxdrfinalcompliance, "%.2f", maxdrfinalcompliance);
		sprintf(salldrfinalcompliance, "%.2f", alldrfinalcompliance); 
		printf("DR4 and Above Compliance in String: [%s]", smaxdrfinalcompliance);fflush(stdout);
		printf("All DR Status Compliance in String: [%s]", salldrfinalcompliance);fflush(stdout);
		printf("\n############ R E P O R T ############\n");fflush(stdout);
		fprintf(FP_OutputReport,"\n\n\n\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, [VEHICLE COMPLIANCE REPORT] ,,,,");fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Veh_No: [%s]",VNo);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Veh_Rev: [%s]",VRev);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Veh_Seq: [%s]",VSeq);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Veh_Description: [%s]",MainDesc);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Veh_DR/AR: [%s]",MainDrAr);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Revision_Rule: [%s]","ERC release and above");fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Closure_Rule: [%s]","BOMViewClosureRuleERC");fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Total Modules[In Vehicles First Level]: [%s]",total);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Total Modules Present[In SubModule Library]: [%s]",totalpresentDup);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Total Modules Not Present[In SubModule Library]: [%s]",totalnotpresentDup);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, No of MAX DR4 and Above Submodules: [%s]",maxdrpasscountdupfinal);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, No of Below DR4 Submodules: [%s]",maxdrfailcountdupfinal);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, DR4 and Above Compliance Percentage: [%s]",smaxdrfinalcompliance);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, All DR Status Compliance Percentage: [%s]",salldrfinalcompliance);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n ,,,, Report_TimeStamp: [%s]",VRpt);fflush(FP_OutputReport);
		fprintf(FP_OutputReport,"\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(FP_OutputReport);
		write2xml(Report,"<ComplianceStatus>\n");
		write2xml(Report,"<VehNo>"); if(tc_strlen(VNo)>0) write2xml(Report,VNo); else write2xml(Report,"NA"); write2xml(Report,"</VehNo>\n");
		write2xml(Report,"<VehRev>"); if(tc_strlen(VRev)>0) write2xml(Report,VRev); else write2xml(Report,"NA"); write2xml(Report,"</VehRev>\n");
		write2xml(Report,"<VehSeq>"); if(tc_strlen(VSeq)>0) write2xml(Report,VSeq); else write2xml(Report,"NA"); write2xml(Report,"</VehSeq>\n");
		write2xml(Report,"<VehDesc>"); if(tc_strlen(MainDesc)>0) write2xml(Report,MainDesc); else write2xml(Report,"NA"); write2xml(Report,"</VehDesc>\n");
		write2xml(Report,"<VehDrAr>"); if(tc_strlen(MainDrAr)>0) write2xml(Report,MainDrAr); else write2xml(Report,"NA"); write2xml(Report,"</VehDrAr>\n");
		write2xml(Report,"<RevRule>"); if(tc_strlen(VNo)>0) write2xml(Report,"ERC release and above"); else write2xml(Report,"NA"); write2xml(Report,"</RevRule>\n");
		write2xml(Report,"<ClosureRule>"); if(tc_strlen(VNo)>0) write2xml(Report,"BOMViewClosureRuleERC"); else write2xml(Report,"NA"); write2xml(Report,"</ClosureRule>\n");
		write2xml(Report,"<TotalMod>"); if(tc_strlen(total)>0) write2xml(Report,total); else write2xml(Report,"NA"); write2xml(Report,"</TotalMod>\n");
		write2xml(Report,"<PresentMod>"); if(tc_strlen(totalpresentDup)>0) write2xml(Report,totalpresentDup); else write2xml(Report,"NA"); write2xml(Report,"</PresentMod>\n");
		write2xml(Report,"<NotPresentMod>"); if(tc_strlen(totalnotpresentDup)>0) write2xml(Report,totalnotpresentDup); else write2xml(Report,"NA"); write2xml(Report,"</NotPresentMod>\n");
		write2xml(Report,"<AboveMod>"); if(tc_strlen(maxdrpasscountdupfinal)>0) write2xml(Report,maxdrpasscountdupfinal); else write2xml(Report,"NA"); write2xml(Report,"</AboveMod>\n");
		write2xml(Report,"<BelowMod>"); if(tc_strlen(maxdrfailcountdupfinal)>0) write2xml(Report,maxdrfailcountdupfinal); else write2xml(Report,"NA"); write2xml(Report,"</BelowMod>\n");
		write2xml(Report,"<MaxPercent>"); if(tc_strlen(smaxdrfinalcompliance)>0) write2xml(Report,smaxdrfinalcompliance); else write2xml(Report,"NA"); write2xml(Report,"</MaxPercent>\n");
		write2xml(Report,"<AllPercent>"); if(tc_strlen(salldrfinalcompliance)>0) write2xml(Report,salldrfinalcompliance); else write2xml(Report,"NA"); write2xml(Report,"</AllPercent>\n");
		write2xml(Report,"<TimeStamp>"); if(tc_strlen(VRpt)>0) write2xml(Report,VRpt); else write2xml(Report,"NA"); write2xml(Report,"</TimeStamp>\n");
		write2xml(Report,"</ComplianceStatus>\n");
		write2xml(Report,"</VehCompliance>\n");
	    fclose(Report);
		tc_strcat(VFResData,total);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,totalpresentDup);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,totalnotpresentDup);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,maxdrpasscountdupfinal);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,maxdrfailcountdupfinal);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,smaxdrfinalcompliance);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,salldrfinalcompliance);
		tc_strcat(VFResData,"^");
		tc_strcat(VFResData,VRpt);
		tc_strcat(VFResData,"^");
		printf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");fflush(stdout);
		printf("Present SubModule in Library: [%s]\n", totalpresentDup);fflush(stdout);
		printf("Not Present SubModule in Library: [%s]\n", totalnotpresentDup);fflush(stdout);
		printf("Total Submodules: [%s]\n", total);fflush(stdout);
		printf("No of MAX DR4 and Above Submodules: [%s]\n", maxdrpasscountdupfinal);fflush(stdout); 
		printf("No of Below DR4 Submodules: [%s]\n", maxdrfailcountdupfinal);fflush(stdout);
		printf("DR4 and Above Compliance Percentage: [%s]\n", smaxdrfinalcompliance);fflush(stdout);
		printf("ALL DR Status Compliance Percentage: [%s]\n", salldrfinalcompliance);fflush(stdout);
		printf("Final Response: [%s]\n", VFResData);fflush(stdout);
		printf("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");fflush(stdout);
		fprintf(FP_VComRpt,"%s\n",VFResData);fflush(FP_VComRpt);
		
		/* printf("Current File To Original File Move Start..!!\n");fflush(stdout);
		char* ShellCommandLine = NULL;
	    ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
		tc_strcpy(ShellCommandLine,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehicleCompliance/RemoveProcessFiles.sh");
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,"TEST");
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,"TEST");
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,"TEST");
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,"TEST");
		tc_strcat(ShellCommandLine," ");
		tc_strcat(ShellCommandLine,PreVCompFile);
		system(ShellCommandLine);
		printf("Current File To Original File Move End..!!\n");fflush(stdout); */
		
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRev,char* VehicleSeq,char* VDesc,char* VDrAr,char* RptDate,char* VehicleRS,FILE* VehRpt,FILE* VComRpt,char* VFData)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubModAddress = NULL;
	char* ctopSubProdLine = NULL;
	char* ctopSubProdLineDup = NULL;
	char* ctopSubPlatform = NULL;
	char* ctopSubPlatformDup = NULL;
	char* ctopSubProjCode = NULL;
	char* ctopSubProjCodeDup = NULL;
	char* ctopSubDesGrp = NULL;
	char* ctopSubDesGrpDup = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	tag_t PartMasterTag	= NULLTAG;
	char *MstrUnitTag = NULL;
	char *MstrUnitTagDup = NULL;
	PIE_scope_t scope;
    scope=PIE_TEAMCENTER;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {	
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules2("BOMViewClosureRuleERC",scope, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules2] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ctopSubModAddress = subString(ctopSubItem_Id, 4, 5);
			trimwhitespace(ctopSubModAddress);
			printf("\n Part Module Address Value: [%s]", ctopSubModAddress);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Platform", &ctopSubProdLine));
			if(tc_strlen(ctopSubProdLine)>0)
			{
				tc_strdup(ctopSubProdLine,&ctopSubProdLineDup);
			}
			else
			{
				tc_strdup("--",&ctopSubProdLineDup);
				printf("\n Product Line Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubProdLineDup);
			printf("\n Product Line Value After Dup & Trim: [%s]\n", ctopSubProdLineDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_Platform", &ctopSubPlatform));
			if(tc_strlen(ctopSubPlatform)>0)
			{
				tc_strdup(ctopSubPlatform,&ctopSubPlatformDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPlatformDup);
				printf("\n Platform Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPlatformDup);
			printf("\n Platform Value After Dup & Trim: [%s]\n", ctopSubPlatformDup);fflush(stdout);
			
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_ProjectCode", &ctopSubProjCode));
			if(tc_strlen(ctopSubProjCode)>0)
			{
				tc_strdup(ctopSubProjCode,&ctopSubProjCodeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubProjCodeDup);
				printf("\n Project Code Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubProjCodeDup);
			printf("\n Project Code Value After Dup & Trim: [%s]\n", ctopSubProjCodeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_DesignGrp", &ctopSubDesGrp));
			if(tc_strlen(ctopSubDesGrp)>0)
			{
				tc_strdup(ctopSubDesGrp,&ctopSubDesGrpDup);
			}
			else
			{
				tc_strdup("--",&ctopSubDesGrpDup);
				printf("\n Design Group Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubDesGrpDup);
			printf("\n Design Group Value After Dup & Trim: [%s]\n", ctopSubDesGrpDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_quantity", &ctopSubQuantity));
			if(tc_strlen(ctopSubQuantity)>0)
			{
				tc_strdup(ctopSubQuantity,&ctopSubQuantityDup);
			}
			else
			{
				tc_strdup("--",&ctopSubQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", ctopSubQuantityDup);fflush(stdout);
			
			ITK_CALL(ITEM_find_item(ctopSubItem_Id,&PartMasterTag));
			if(PartMasterTag != NULLTAG)
			{
			   ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&MstrUnitTag));
			}
			if(MstrUnitTag!=NULL)
			{
				tc_strdup(MstrUnitTag,&MstrUnitTagDup);
			}
			else
			{
				tc_strdup("--",&MstrUnitTagDup);
				printf("\n Master Unit of Measure Tag[uom_tag] is NULL..!!\n");fflush(stdout);
			}
			printf("\n Master Unit of Measure Tag[uom_tag]: [%s]\n", MstrUnitTagDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level Module Address: [%s]", ctopSubModAddress);
			printf("\nTop_Level Product Line: [%s]", ctopSubProdLineDup);
			printf("\nTop_Level Platform: [%s]", ctopSubPlatformDup);
			printf("\nTop_Level Project Code: [%s]", ctopSubProjCodeDup);
			printf("\nTop_Level Design Group: [%s]", ctopSubDesGrpDup);
			printf("\nTop_Level AR/DR: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\nTop_Level QTY: [%s]", ctopSubQuantityDup);
			printf("\nTop_Level UOM Tag: [%s]", MstrUnitTagDup);		
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0)
				{
				   fprintf(VehRpt,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n","0",ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubItem_Desc,ctopSubModAddress,ctopSubProdLineDup,ctopSubPlatformDup,ctopSubProjCodeDup,ctopSubDesGrpDup,ctopSubArDrStatusDup,ctopSubPartTypeDup,ctopSubQuantityDup,MstrUnitTagDup,"NA","Yes","NA","NA","NA","NA");fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt, Vehicle, VehicleRev, VehicleSeq, RptDate, VComRpt, VFData, VDesc, VDrAr);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int TC_VehRlzd_DML_Details(FILE* VehDMLRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tVItemobj     = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tvitemobj_results = NULLTAG;
	int n_ventries = 5;
	int n_vitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *BUnitInfo1	= NULL;
	char *RelTypeInfo2  = NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Veh_Desc          = NULL;
	char *Veh_DescDup       = NULL;
	char *vplat_str         = NULL;
	char *vplat_strDup      = NULL;
	char *PartType          = NULL;
	char *PartTypeDup       = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	
	
	char* timestamp = NULL;
	char* subtime = NULL;
	char* Hr = NULL;
	char* Mm = NULL;
	char *FinalTime = (char *) malloc(100*sizeof(char));
	double FinalTimef = 0.0;
	/////////////////////////////////////////////////////////////////////////
	/////// P R I N T     C U R R E N T   T I M E   I N   HH.MM  ////////////
	/////////////////////////////////////////////////////////////////////////
	time_t curtime = time(NULL);
    timestamp = ctime(&curtime);
    printf("Current time: %s",timestamp);
	printf("\n\n Real Time is -----> %s", timestamp);fflush(stdout);
	STRNG_replace_str(timestamp," ","_",&timestamp);
	subtime = subString(timestamp,11,8);
	printf("\n\n After String Replace Substring Time is  -----> [%s] ",subtime);fflush(stdout);
	Hr=tc_strtok(subtime,":");
	Mm=tc_strtok(NULL,":");
	printf("\n\n Hour Value  -----> [%s] ",Hr);fflush(stdout);
	printf("\n\n Minute Value  -----> [%s] ",Mm);fflush(stdout);
	tc_strcpy(FinalTime, Hr);
	tc_strcat(FinalTime, ".");
	tc_strcat(FinalTime, Mm);
	printf("\n\n Concatinated String  -----> [%s] ",FinalTime);fflush(stdout);
	FinalTimef = atof(FinalTime);
	printf("\n\n Converted String  -----> [%.2f] ",FinalTimef);fflush(stdout);
	/////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	char GenToDate[100] = "";
	char *GenToDateDup = NULL;
	time_t 	todt;
	struct 	tm todttime;
	time(&todt);
	todttime = *localtime(&todt);
	strftime(GenToDate,100,"%d-%b-%Y",&todttime);
	printf(" \nCurrent DateStamp: [%s]\n", GenToDate);fflush(stdout);
	trimwhitespace(GenToDate);
	if(GenToDate!=NULL)tc_strdup(GenToDate,&GenToDateDup);
	printf("\n\n Current Formatted Date: [%s] ",GenToDateDup);fflush(stdout);

	if((FinalTimef>=6.30) && (FinalTimef<16.30))
	{
		tc_strcpy(AfterDTStamp,GenToDateDup);
		tc_strcat(AfterDTStamp," 00:00");
		printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
		tc_strcpy(BeforeDTStamp,GenToDateDup);
		tc_strcat(BeforeDTStamp," 16:00");
		printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	}
	else if((FinalTimef>=16.30) && (FinalTimef<23.30))
	{
		tc_strcpy(AfterDTStamp,GenToDateDup);
		tc_strcat(AfterDTStamp," 16:00");
		printf("\n\n Second Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
		tc_strcpy(BeforeDTStamp,GenToDateDup);
		tc_strcat(BeforeDTStamp," 23:00");
		printf("\n\n Second Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	}
	else
	{
		printf("\n Hi! Time Stamp Not Matched with Cron Time..!!\n");fflush(stdout);
	}
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tVItemobj));
    if(tVItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cvEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cvValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"Veh"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","Veh"};
		ITK_CALL(QRY_execute(tVItemobj, n_ventries, cvEntries, cvValues, &n_vitemobj_found, &tvitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(Veh Released): [%d]\n",n_vitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vitemobj_found > 0)
		{
			printf(" Release Type(Vehicle Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_vitemobj_found; i++)
			{
				ErcDMLTag = tvitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_VehComplianceCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_VehComplianceCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_VehComplianceCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_VehComplianceCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"Veh")==0)
					{
						printf("\n tm_VehComplianceCronJob--DML Release Type: [Vehicle Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_VehComplianceCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMHasSolutionItem",&partcount,&PartTags));
							printf("\n tm_VehComplianceCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								tc_strdup(item_id_str,&item_id_strDup);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_VehComplianceCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Veh_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Veh_Desc,&Veh_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&vplat_str));
									tc_strdup(vplat_str,&vplat_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									tc_strdup(item_drar_str,&item_drar_strDup);

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&PartType));
									tc_strdup(PartType,&PartTypeDup);
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  Vehicle Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Vehicle Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Vehicle Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Vehicle Description: [%s]\n",Veh_DescDup);fflush(stdout);
									printf("\n  Vehicle Platform: [%s]\n",vplat_strDup);fflush(stdout);
									printf("\n  Vehicle DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Vehicle Part Type: [%s]\n",PartTypeDup);fflush(stdout);
									printf("\n  Vehicle Object Type: [%s]\n",item_typeDup);fflush(stdout);
									
									if(((tc_strcmp(PartTypeDup,"V")==0) || (tc_strcmp(PartTypeDup,"VCCR")==0)) && (tc_strcmp(item_typeDup,"Design Revision")==0))
									{
										fprintf(VehDMLRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_id_strDup,item_rev_strDup,item_seq_strDup,Veh_DescDup,vplat_strDup,item_drar_strDup,PartTypeDup);fflush(VehDMLRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_VehComplianceCronJob--DML Release Type is Not Vehicle Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_VehComplianceCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_VehComplianceCronJob--Vehicle Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_VehComplianceCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int TC_GMRlzd_DML_Details(FILE* GMDMLRptFile)
{
	int iFail = ITK_ok;
	tag_t ErcDMLTag		= NULLTAG;
	tag_t qry_tg		= NULLTAG;
	tag_t tGMItemobj    = NULLTAG;
	tag_t revTag        = NULLTAG;
	tag_t* ContObjTags	= NULLTAG;
	tag_t *DmlTasksTags = NULLTAG;
	tag_t *PartTags     = NULLTAG;
	tag_t* tgmitemobj_results = NULLTAG;
	int n_gmentries = 5;
	int n_gmitemobj_found = 0;
	int i = 0;
	int t =0;
	int p = 0;
	int taskcount = 0;
	int partcount = 0;
	char *object_type	= NULL;
	char *DmlBUnit	    = NULL;
	char *DmlRelType	= NULL;
	char *DmlNo			= NULL;
	char *BUnitInfo1	= NULL;
	char *RelTypeInfo2  = NULL;
	char *item_id_str   = NULL;
	char *item_id_strDup  = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_str = NULL;
	char *Newitem_revseq_strDup = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *Veh_Desc          = NULL;
	char *Veh_DescDup       = NULL;
	char *vplat_str         = NULL;
	char *vplat_strDup      = NULL;
	char *PartType          = NULL;
	char *PartTypeDup       = NULL;
	char *item_type         = NULL;
	char *item_typeDup      = NULL;
	
	
	char* timestamp = NULL;
	char* subtime = NULL;
	char* Hr = NULL;
	char* Mm = NULL;
	char *FinalTime = (char *) malloc(100*sizeof(char));
	double FinalTimef = 0.0;
	/////////////////////////////////////////////////////////////////////////
	/////// P R I N T     C U R R E N T   T I M E   I N   HH.MM  ////////////
	/////////////////////////////////////////////////////////////////////////
	time_t curtime = time(NULL);
    timestamp = ctime(&curtime);
    printf("Current time: %s",timestamp);
	printf("\n\n Real Time is -----> %s", timestamp);fflush(stdout);
	STRNG_replace_str(timestamp," ","_",&timestamp);
	subtime = subString(timestamp,11,8);
	printf("\n\n After String Replace Substring Time is  -----> [%s] ",subtime);fflush(stdout);
	Hr=tc_strtok(subtime,":");
	Mm=tc_strtok(NULL,":");
	printf("\n\n Hour Value  -----> [%s] ",Hr);fflush(stdout);
	printf("\n\n Minute Value  -----> [%s] ",Mm);fflush(stdout);
	tc_strcpy(FinalTime, Hr);
	tc_strcat(FinalTime, ".");
	tc_strcat(FinalTime, Mm);
	printf("\n\n Concatinated String  -----> [%s] ",FinalTime);fflush(stdout);
	FinalTimef = atof(FinalTime);
	printf("\n\n Converted String  -----> [%.2f] ",FinalTimef);fflush(stdout);
	/////////////////////////////////////////////////////////////////////////
	char *AfterDTStamp = (char *) malloc(50*sizeof(char));
	char *BeforeDTStamp = (char *) malloc(50*sizeof(char));
	char GenToDate[100] = "";
	char *GenToDateDup = NULL;
	time_t 	todt;
	struct 	tm todttime;
	time(&todt);
	todttime = *localtime(&todt);
	strftime(GenToDate,100,"%d-%b-%Y",&todttime);
	printf(" \nCurrent DateStamp: [%s]\n", GenToDate);fflush(stdout);
	trimwhitespace(GenToDate);
	if(GenToDate!=NULL)tc_strdup(GenToDate,&GenToDateDup);
	printf("\n\n Current Formatted Date: [%s] ",GenToDateDup);fflush(stdout);

	if((FinalTimef>=6.30) && (FinalTimef<16.30))
	{
		tc_strcpy(AfterDTStamp,GenToDateDup);
		tc_strcat(AfterDTStamp," 00:00");
		printf("\n\n First Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
		tc_strcpy(BeforeDTStamp,GenToDateDup);
		tc_strcat(BeforeDTStamp," 16:00");
		printf("\n\n First Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	}
	else if((FinalTimef>=16.30) && (FinalTimef<23.30))
	{
		tc_strcpy(AfterDTStamp,GenToDateDup);
		tc_strcat(AfterDTStamp," 16:00");
		printf("\n\n Second Job-Time:Date Released After(date_released_after): [%s]\n",AfterDTStamp);fflush(stdout);
		tc_strcpy(BeforeDTStamp,GenToDateDup);
		tc_strcat(BeforeDTStamp," 23:00");
		printf("\n\n Second Job-Time:Date Released Before(date_released_before): [%s]\n",BeforeDTStamp);fflush(stdout);
	}
	else
	{
		printf("\n Hi! Time Stamp Not Matched with Cron Time..!!\n");fflush(stdout);
	}
	
	printf("\n Finding Query[ERCDMLReleased_Type]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tGMItemobj));
    if(tGMItemobj != NULLTAG)
	{
		printf("\n Query[ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cgmEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cgmValues[5]  = {"*","T5_LcsErcRlzd",AfterDTStamp,BeforeDTStamp,"TODR"};
		//char *cvValues[5]  = {"*","T5_LcsErcRlzd","01-Jan-1900 00:00","01-Jan-1900 16:00","Veh"};
		ITK_CALL(QRY_execute(tGMItemobj, n_gmentries, cgmEntries, cgmValues, &n_gmitemobj_found, &tgmitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of DML Found(GM Released): [%d]\n",n_gmitemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_gmitemobj_found > 0)
		{
			printf(" Release Type(GM Released) DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_gmitemobj_found; i++)
			{
				ErcDMLTag = tgmitemobj_results[i];
				ITK_CALL(AOM_ask_value_string(ErcDMLTag,"object_type",&object_type));
				printf("\n tm_VehComplianceCronJob--Object Type: [%s]\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
				{
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_ERCBusiUt",&DmlBUnit));
					printf("\n tm_VehComplianceCronJob--Business Unit: [%s]\n",DmlBUnit);fflush(stdout);
					
					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"t5_rlstype",&DmlRelType));
					printf("\n tm_VehComplianceCronJob--ERC DML Release Type: [%s]\n",DmlRelType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(ErcDMLTag,"item_id",&DmlNo));
					printf("\n tm_VehComplianceCronJob--ERC DML Number: [%s]\n",DmlNo);fflush(stdout);
					if(tc_strcmp(DmlRelType,"TODR")==0)
					{
						printf("\n tm_VehComplianceCronJob--DML Release Type: [GM Release]\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_tags(ErcDMLTag,"T5_DMLTaskRelation",&taskcount,&DmlTasksTags));
						printf("\n tm_VehComplianceCronJob--DML Task Count: [%d]\n",taskcount);fflush(stdout);
						for(t=0;t<taskcount;t++)
						{
							ITK_CALL(AOM_ask_value_tags(DmlTasksTags[t],"CMReferences",&partcount,&PartTags));
							printf("\n tm_VehComplianceCronJob--No of Parts Found: [%d]\n",partcount);fflush(stdout);
							for(p=0;p<partcount;p++)
							{
								revTag = PartTags[p];
								ITK_CALL(AOM_ask_value_string(revTag,"item_id",&item_id_str));
								tc_strdup(item_id_str,&item_id_strDup);
								if((tc_strstr(item_id_strDup,"MBOM")!=NULL) || (tc_strstr(item_id_strDup,"APLD")!=NULL) || (tc_strstr(item_id_strDup,"APLC")!=NULL) || (tc_strstr(item_id_strDup,"APLJ")!=NULL) || (tc_strstr(item_id_strDup,"APLL")!=NULL) || (tc_strstr(item_id_strDup,"APLA")!=NULL) || (tc_strstr(item_id_strDup,"APLU")!=NULL) || (tc_strstr(item_id_strDup,"APLS")!=NULL) || (tc_strstr(item_id_strDup,"APLV")!=NULL))
								{
									continue;
								}
								else
								{
									printf("\n tm_VehComplianceCronJob--Task is Not MBOM or Planning..!!\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&item_revseq_str));
									tc_strdup(item_revseq_str,&item_revseq_strDup);
									
									Veh_Desc = TC_PartDesc(item_id_strDup,item_revseq_strDup);
									tc_strdup(Veh_Desc,&Veh_DescDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"t5_Platform",&vplat_str));
									tc_strdup(vplat_str,&vplat_strDup);
									
									ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&Newitem_revseq_str));
									tc_strdup(Newitem_revseq_str,&Newitem_revseq_strDup);
									item_rev_str=strtok(Newitem_revseq_strDup,";");
									item_seq_str=strtok(NULL,";");
									if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
									if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"t5_PartStatus",&item_drar_str));
									tc_strdup(item_drar_str,&item_drar_strDup);

									ITK_CALL(AOM_ask_value_string(revTag,"t5_PartType",&PartType));
									tc_strdup(PartType,&PartTypeDup);
									
									ITK_CALL(AOM_UIF_ask_value(revTag,"object_type",&item_type));
									tc_strdup(item_type,&item_typeDup);
									
									printf("\n  Vehicle Number: [%s]\n",item_id_strDup);fflush(stdout);
									printf("\n  Vehicle Revision: [%s]\n",item_rev_strDup);fflush(stdout);
									printf("\n  Vehicle Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
									printf("\n  Vehicle Description: [%s]\n",Veh_DescDup);fflush(stdout);
									printf("\n  Vehicle Platform: [%s]\n",vplat_strDup);fflush(stdout);
									printf("\n  Vehicle DR & AR Value: [%s]\n",item_drar_strDup);fflush(stdout);
									printf("\n  Vehicle Part Type: [%s]\n",PartTypeDup);fflush(stdout);
									printf("\n  Vehicle Object Type: [%s]\n",item_typeDup);fflush(stdout);
									
									if(((tc_strcmp(PartTypeDup,"V")==0) || (tc_strcmp(PartTypeDup,"VCCR")==0)) && (tc_strcmp(item_typeDup,"Design Revision")==0))
									{
										fprintf(GMDMLRptFile,"%s^%s^%s^%s^%s^%s^%s^%s^\n",DmlNo,item_id_strDup,item_rev_strDup,item_seq_strDup,Veh_DescDup,vplat_strDup,item_drar_strDup,PartTypeDup);fflush(GMDMLRptFile);
									}
								}
							}
						}
					}
					else
					{
						printf("\n tm_VehComplianceCronJob--DML Release Type is Not GM Release\n");fflush(stdout);
					}
			    }
				else
				{
					printf("\n tm_VehComplianceCronJob--DML is Not ERC DML\n");fflush(stdout);
				}
		    }
	    }
		else
		{
			printf("\n tm_VehComplianceCronJob--GM Release DML Not Found\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n tm_VehComplianceCronJob--Query[ERCDMLReleased_Type] Tag Not Found\n");fflush(stdout);
	}
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	int ifail = ITK_ok;
	char *inp_file_str = NULL;
	char *RptFile = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *dml_no_str      = NULL;
	char *dml_no_strDup   = NULL;
	char *item_id_str     = NULL;
	char *item_id_strDup  = NULL;
	char *item_rev_str    = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_str    = NULL;
	char *item_seq_strDup = NULL;
	char *Veh_Desc        = NULL;
	char *Veh_DescDup     = NULL;
	char *Vplat_str       = NULL;
	char *Vplat_strDup    = NULL;
	char *item_drar_str   = NULL;
	char *item_drar_strDup  = NULL;
	char *item_parttype_str = NULL;
	char *item_parttype_strDup  = NULL;
	char *item_revseq_strDup = (char *) malloc(50*sizeof(char));
	char *VCompFile = (char *) malloc(100*sizeof(char));
	char *VFData = (char *) malloc(500*sizeof(char));
	char *FinalRptFile = (char *) malloc(100*sizeof(char));
	
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}

    inp_file_str = ITK_ask_cli_argument("-File=");
	trimwhitespace(inp_file_str);
	if(inp_file_str!=NULL)tc_strdup(inp_file_str,&RptFile);
	printf(" [1]: Input Report File(RptFile): [%s]\n",RptFile);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	fpPart_List = fopen(RptFile,"r");
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			dml_no_str=strtok(Buffer,"^");
			item_id_str=strtok(NULL,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			Veh_Desc=strtok(NULL,"^");
			Vplat_str=strtok(NULL,"^");
			item_drar_str=strtok(NULL,"^");
			item_parttype_str=strtok(NULL,"^");
			
			if(dml_no_str!=NULL)tc_strdup(dml_no_str,&dml_no_strDup);
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			if(Veh_Desc!=NULL)tc_strdup(Veh_Desc,&Veh_DescDup);
			if(Vplat_str!=NULL)tc_strdup(Vplat_str,&Vplat_strDup);
			if(item_drar_str!=NULL)tc_strdup(item_drar_str,&item_drar_strDup);
			if(item_parttype_str!=NULL)tc_strdup(item_parttype_str,&item_parttype_strDup);
			
			if(dml_no_strDup!=NULL)trimwhitespace(dml_no_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			if(Veh_DescDup!=NULL)trimwhitespace(Veh_DescDup);
			if(Vplat_strDup!=NULL)trimwhitespace(Vplat_strDup);
			if(item_drar_strDup!=NULL)trimwhitespace(item_drar_strDup);
			if(item_parttype_strDup!=NULL)trimwhitespace(item_parttype_strDup);
			
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,";");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			
			printf("\n DML_No(dml_no_strDup): [%s]\n",dml_no_strDup);
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Description(Veh_DescDup): [%s]\n",Veh_DescDup);
			printf("\n Part Platform(Vplat_strDup): [%s]\n",Vplat_strDup);
			printf("\n Part DR/AR(item_drar_strDup): [%s]\n",item_drar_strDup);
			printf("\n Part Type(item_parttype_strDup): [%s]\n",item_parttype_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			
			printf("\n Creating Output Response..!!");fflush(stdout);
			//tc_strcpy(VFData,"/tmp/");
			//tc_strcat(VFData,item_id_strDup);
			tc_strcpy(VFData,item_id_strDup);
			tc_strcat(VFData,"^");
			tc_strcat(VFData,item_rev_strDup);
			tc_strcat(VFData,"^");
			tc_strcat(VFData,item_seq_strDup);
			tc_strcat(VFData,"^");
			tc_strcat(VFData,Veh_DescDup);
			tc_strcat(VFData,"^");
			tc_strcat(VFData,Vplat_strDup);
			tc_strcat(VFData,"^");
			tc_strcat(VFData,item_drar_strDup);
			tc_strcat(VFData,"^");
			printf("\n Response Data: [%s]", VFData);fflush(stdout);
			printf("\n Creating Output Response..!!");fflush(stdout);
								
			printf("\n Generating Vehicle Compliance Percentage File Name..!!");fflush(stdout);
			tc_strcpy(VCompFile,"/tmp/");
			tc_strcat(VCompFile,"VCR");
			tc_strcat(VCompFile,"_");
			tc_strcat(VCompFile,item_id_strDup);
			tc_strcat(VCompFile,"_");
			tc_strcat(VCompFile,item_rev_strDup);
			tc_strcat(VCompFile,"_");
			tc_strcat(VCompFile,item_seq_strDup);
			tc_strcat(VCompFile,"_");
			tc_strcat(VCompFile,item_drar_strDup);
			tc_strcat(VCompFile,"_");
			tc_strcat(VCompFile,GenDate);
			tc_strcat(VCompFile,".txt");
			printf("\n Vehicle Compliance Percentage File Name: [%s]", VCompFile);fflush(stdout);
			printf("\n Vehicle Compliance Percentage File Name Generated..!!");fflush(stdout);
								
			printf("\n Generating Report File Name..!!");fflush(stdout);
			tc_strcpy(FinalRptFile,"/tmp/");
			tc_strcat(FinalRptFile,"VCR");
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,item_id_strDup);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,item_rev_strDup);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,item_seq_strDup);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,item_drar_strDup);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,GenDate);
			tc_strcat(FinalRptFile,".csv");
			printf("\n Final Report File Name: [%s]", FinalRptFile);fflush(stdout);
			printf("\n Final Report File Name Generated..!!");fflush(stdout);
			FILE* fpvcomp_file = fopen(VCompFile, "w");
			FILE* fpop_file = fopen(FinalRptFile, "w");
			fprintf(fpop_file,"SL_NO, PART_NO, PART_REV, PART_SEQ, PART_DESCRIPTION, ADDRESS, PRODUCT_LINE, PLATFORM, PROJECT_CODE, DESIGN_GROUP, PART_AR/DR, PART_TYPE, QTY, UOM, VEHICLE_LINK_FREQUENCY, PRESENT_IN_LIBRARY?, LIBRARY_REV, LIBRARY_SEQ, LIBRARY_AR/DR, LIBRARY_MAX_AR_DR\n");fflush(fpop_file);
			if(fpop_file == NULL)
			{
				printf("\n Unable to Create Report File: --------> [%s]",FinalRptFile);fflush(stdout);
				return 0;
			}
			if(fpvcomp_file == NULL)
			{
				printf("\n Unable to Vehicle Compliance Report File: --------> [%s]",VCompFile);fflush(stdout);
				return 0;
			}
			
			printf("\n Function3: Vehicle Child Details Find Start\n");fflush(stdout);
			TC_VehChild_Details(item_id_strDup,item_rev_strDup,item_seq_strDup,Veh_DescDup,item_drar_strDup,GenDate,item_revseq_strDup,fpop_file,fpvcomp_file,VFData);
			printf("\n Function3: Vehicle Child Details Find End\n");fflush(stdout);
			fclose(fpvcomp_file);
			fclose(fpop_file);
			printf("\n Function4: Report Attach To Folder[VEHICLE_SUBMODULE_COMPLIANCE_REPORT] Start\n");fflush(stdout);
			TC_Folder_Attach(FinalRptFile,VCompFile,item_id_strDup,item_rev_strDup,item_seq_strDup,item_drar_strDup,GenDate);
			printf("\n Function4: Report Attach To Folder[VEHICLE_SUBMODULE_COMPLIANCE_REPORT] End\n");fflush(stdout);
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	printf("\n Function5: Mail Notification Send Start\n");fflush(stdout);
	char command[512];
	printf("\n Email Shell Call Started...");fflush(stdout);
	sprintf(command,"/user/cvprod/MCCVEHCOMPLIANCE/SendEmail.sh %s",RptFile);
	system(command);
	printf("\n Email Shell Call Ended...");
	printf("\n Function5: Mail Notification Send End\n");fflush(stdout);
	printf("\n tm_VehComplianceCronJob--Completed \n");fflush(stdout);	
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_VehComplianceCronPart2.c
* // ./linkitk -o tm_VehComplianceCronPart2 tm_VehComplianceCronPart2.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/VehComplianceCronPart2/tm_VehComplianceCronPart2 .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/VehComplianceCronPart2/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/VehComplianceCronPart2/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/VehComplianceCronPart2/SendEmail.sh .
* // ./tm_VehComplianceCronPart2 -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -File="VehComp_CronJob_Rpt_File_28_Oct_2024_22_44_18.txt"
* // ./tm_VehComplianceCronPart2 -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -File="VehComp_CronJob_Rpt_File_28_Oct_2024_22_44_18.txt"
*
***************************************************************************/