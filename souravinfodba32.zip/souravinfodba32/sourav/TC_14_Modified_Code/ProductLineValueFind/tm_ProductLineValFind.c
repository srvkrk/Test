/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   After Reading Project Code From File Find Product Line Details From PartPlatform Control Table  
*  File Name    :   tm_ProductLineValFind.c
*  Created on   :   Feb 18th, 2025
*  Usage        :   tm_ProductLineValFind
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/02/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
	char *inp_projcode_str = NULL;
	char *inp_projcode_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	fpPart_List = fopen("PartList.txt","r");
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Product_Line_Property_Details");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"MODULE_NO, PROJECT_CODE, PRODUCT_LINE\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	if(fpPart_List != NULL)
	{
		printf("\n Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inp_id_str=strtok(Buffer,"^");
			inp_projcode_str=strtok(NULL,"^");
			if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
			if(inp_projcode_str!=NULL)tc_strdup(inp_projcode_str,&inp_projcode_strDup);
			if(inp_id_strDup!=NULL)trimwhitespace(inp_id_strDup);
			if(inp_projcode_strDup!=NULL)trimwhitespace(inp_projcode_strDup);
			printf("\n Inp Item_ID(inp_id_strDup):  <%s> \n",inp_id_strDup);fflush(stdout);
			printf("\n Inp Project_Code(inp_projcode_strDup):  <%s> \n",inp_projcode_strDup);fflush(stdout);
			
			char *Inf2val = (char *) malloc(20*sizeof(char));
			tc_strcpy(Inf2val,"*");
			tc_strcat(Inf2val,inp_projcode_strDup);
			tc_strcat(Inf2val,"*");
			printf("\n Information-2 Value: [%s]\n", Inf2val);fflush(stdout);
			tag_t tSysQryobj = NULLTAG;
			int nSys_entries = 2;
			int nSys_Qryobj_found = 0;
			tag_t* tSysQryobj_results = NULLTAG;
			int n = 0;
			char* ProductLine = NULL;
			ITK_CALL(QRY_find2("Control Objects...",&tSysQryobj));
			if(tSysQryobj!=NULLTAG)
			{
				printf("\n Control Objects... Query Found Successfully..!!\n");fflush(stdout);
				char *SysEntries[2]  = {"SYSCD","Information-2"};
				char *SysValues[2]  = {"PartPlatform",Inf2val};
				ITK_CALL(QRY_execute(tSysQryobj, nSys_entries, SysEntries, SysValues, &nSys_Qryobj_found, &tSysQryobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Object Found: [%d]\n",nSys_Qryobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				if(nSys_Qryobj_found > 0)
				{
					printf(" No of Objects Found..!!\n");fflush(stdout);
					//for (n = 0; n < nSys_Qryobj_found; n++)
					for (n = 0; n < 1; n++)
					{	
						AOM_ask_value_string(tSysQryobj_results[n],"t5_Userinfo3",&ProductLine);
						printf("\n Product Line Value:  <%s> \n",ProductLine);fflush(stdout);
						printf("\n >>>>>>>>>>>>>>> Item Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
						printf("[1] Module_No: [%s]\n",inp_id_strDup);fflush(stdout);
						printf("[2] Project_Code: [%s]\n",inp_projcode_strDup);fflush(stdout);
						printf("[3] Product Line: [%s]\n",ProductLine);fflush(stdout);
						printf("\n >>>>>>>>>>>>>>> Item Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
						if(tc_strlen(ProductLine)>0)
						{
							fprintf(fpOutput_file,"%s,%s,%s\n",inp_id_strDup,inp_projcode_strDup,ProductLine);fflush(fpOutput_file);
						}
						else
						{
							fprintf(fpOutput_file,"%s,%s,%s\n",inp_id_strDup,inp_projcode_strDup,"-");fflush(fpOutput_file);
						}
					}	
				}
				else
				{
					printf("\n No Objects Found For Input Project Code..!!\n");fflush(stdout);
					fprintf(fpOutput_file,"%s,%s,%s\n",inp_id_strDup,inp_projcode_strDup,"-");fflush(fpOutput_file);
				}
            }
            else
			{
				printf("\n Main Control Objects... Query Tag Not Found..!!\n");fflush(stdout);
			}
		}
	}
	else
	{
		printf("\n Input File is NULL..!!\n");fflush(stdout);
	}	
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ProductLineValFind.c
* // ./linkitk -o tm_ProductLineValFind tm_ProductLineValFind.o
* // scp infodba@172.22.97.32:/user/infodba/sourav/TC_14_Modified_Code/ProductLineValueFind/tm_ProductLineValFind .
* // scp infodba@172.22.97.32:/user/infodba/sourav/TC_14_Modified_Code/ProductLineValueFind/exepatch.sh .
* // scp infodba@172.22.97.32:/user/infodba/sourav/TC_14_Modified_Code/ProductLineValueFind/usage.txt .
* // scp infodba@172.22.97.32:/user/infodba/sourav/TC_14_Modified_Code/ProductLineValueFind/SendEmail.sh .
* // ./tm_ProductLineValFind -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ProductLineValFind -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/