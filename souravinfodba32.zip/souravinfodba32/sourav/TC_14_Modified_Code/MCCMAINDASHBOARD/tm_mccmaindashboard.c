/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create MCC Main Dashboard After Reading Data From Input File
*  File Name    :   tm_mccmaindashboard.c
*  Created on   :   Sept 13th, 2024
*  Usage        :   tm_mccmaindashboard
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     13/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

FILE *Report = NULL;
int ctr = 0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char [], int);

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_SubModuleProductLineStatus(char* InpModAddr,char* InpModNo)
{
	
	trimwhitespace(InpModAddr);
	trimwhitespace(InpModNo);
	char* ResSubModProdStat = NULL;
	char* PLine = NULL;
	char* PLineDup = NULL;
	printf("\n ProductLine Check Started..!!\n");fflush(stdout);
	tag_t tProdLineobj = NULLTAG;
	tag_t* tProdLineobj_results = NULLTAG;
	int n_prodlinepathentries = 3;
	int n_prodline_obj_found = 0;
	ITK_CALL(QRY_find2("SubModuleLibraryTableDetails_Vehicle_Linked",&tProdLineobj));
	printf("\n Query[SubModuleLibraryTableDetails_Vehicle_Linked] Tag Found Successfully...!!\n");
	char *cProdLineEntries[3]  = {"ID","SubModule No","Vehicle Linked?"};
	char *cProdLineValues[3]  = {InpModAddr,InpModNo,"Yes"};
	ITK_CALL(QRY_execute(tProdLineobj, n_prodlinepathentries, cProdLineEntries, cProdLineValues, &n_prodline_obj_found, &tProdLineobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Object Found: [%d]\n",n_prodline_obj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_prodline_obj_found > 0)
	{
		printf("\n Vehicle Linked Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tProdLineobj_results[0], "t5_productline", &PLine));
		trimwhitespace(PLine);
	    if(PLine!=NULL)tc_strdup(PLine,&PLineDup);
		if(tc_strlen(PLineDup)>0)
		{
			tc_strdup(PLineDup,&ResSubModProdStat);
		}
		else
		{
			tc_strdup("NOTFOUND",&ResSubModProdStat);
		}	
	}
	else
	{
		tc_strdup("NOTFOUND",&ResSubModProdStat);
		printf("\n As Vehcile Link Object Not Found So, Taking ProductLine As NOTFOUND Case...");fflush(stdout);
	}
	printf("\n ProductLine Check Ended..!!\n");fflush(stdout);
	return ResSubModProdStat;	
}

char* TC_SubModuleVehicleLinkStatus(char* InpModAddr,char* InpModNo)
{
	
	trimwhitespace(InpModAddr);
	trimwhitespace(InpModNo);
	char* ResSubModStat = NULL;
	printf("\n Query Check Started..!!\n");fflush(stdout);
	tag_t tVehLinkobj = NULLTAG;
	tag_t* tVehLinkobj_results = NULLTAG;
	int n_vehlinkpathentries = 3;
	int n_vehlink_obj_found = 0;
	ITK_CALL(QRY_find2("SubModuleLibraryTableDetails_Vehicle_Linked",&tVehLinkobj));
	printf("\n Query[SubModuleLibraryTableDetails_Vehicle_Linked] Tag Found Successfully...!!\n");
	char *cVehLinkEntries[3]  = {"ID","SubModule No","Vehicle Linked?"};
	char *cVehLinkValues[3]  = {InpModAddr,InpModNo,"Yes"};
	ITK_CALL(QRY_execute(tVehLinkobj, n_vehlinkpathentries, cVehLinkEntries, cVehLinkValues, &n_vehlink_obj_found, &tVehLinkobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Object Found: [%d]\n",n_vehlink_obj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_vehlink_obj_found > 0)
	{
		printf("\n Vehicle Linked Object Found..!!\n");fflush(stdout);
		tc_strdup("LINK",&ResSubModStat);
	}
	else
	{
		tc_strdup("NOTLINK",&ResSubModStat);
		printf("\n As Vehcile Link Object Not Found So, Taking As [NOTLINK] Case...\n");fflush(stdout);
	}
	printf("\n Query Check Ended..!!\n");fflush(stdout);
	return ResSubModStat;	
}

char* TC_ModuleAddrStatus(char* InpModAddr)
{
	
	trimwhitespace(InpModAddr);
	char* ResModAdd = NULL;
	char* Info1 = NULL;
	char* Info2 = NULL;
	char* Info3 = NULL;
	char* Info4 = NULL;
	char* Info5 = NULL;
	char* Info6 = NULL;
	char* Info7 = NULL;
	char* Info8 = NULL;
	char* Info9 = NULL;
	char* Info10 = NULL;
	char* Fundesresponse = NULL;
	Fundesresponse = (char *) malloc(2000*sizeof(char ));
	printf("\n Control Object Check Started..!!\n");fflush(stdout);
	tag_t tCtrlobj = NULLTAG;
	tag_t* tPathctrlobj_results = NULLTAG;
	int n_pathentries = 4;
	int n_path_ctrlobj_found = 0;
	ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
	printf("\n Control Object Query Tag Found Successfully...!!\n");
	char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
	char *cPathValues[4]  = {"MCCInvalidAdd","MCCInvalidAddSub","MCCInvalidAddCntObj","0"};
	ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
	printf("\n ----------------------------------- \n");fflush(stdout);
	printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
	printf("\n ----------------------------------- \n");fflush(stdout);
	if(n_path_ctrlobj_found > 0)
	{
		printf("\n Control Object Found..!!\n");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &Info1));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &Info2));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo3", &Info3));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo4", &Info4));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo5", &Info5));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo6", &Info6));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo7", &Info7));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo8", &Info8));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo9", &Info9));
		ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_userinfo10", &Info10));
		tc_strcpy(Fundesresponse,Info1);
		tc_strcat(Fundesresponse,Info2);
		tc_strcat(Fundesresponse,Info3);
		tc_strcat(Fundesresponse,Info4);
		tc_strcat(Fundesresponse,Info5);
		tc_strcat(Fundesresponse,Info6);
		tc_strcat(Fundesresponse,Info7);
		tc_strcat(Fundesresponse,Info8);
		tc_strcat(Fundesresponse,Info9);
		tc_strcat(Fundesresponse,Info10);
		printf("\n Concatinated Module_Address: --------> [%s]\n",Fundesresponse);fflush(stdout);
		if(tc_strstr(Fundesresponse,InpModAddr) != NULL)
		{
			tc_strdup("INVALID",&ResModAdd);
		}
		else
		{
			tc_strdup("VALID",&ResModAdd);
		}
	}
	else
	{
		tc_strdup("VALID",&ResModAdd);
		printf("\nControl Object Not Found So, Taking As Valid Case...");fflush(stdout);
	}
	
	return ResModAdd;	
}

char* TC_MonthName(int monno)
{
	char *monname = NULL;
	switch(monno) 
	{
        case 1 : 
                tc_strdup("Jan",&monname);				
				break;
        case 2 : 
				tc_strdup("Feb",&monname);
          		break;
        case 3 : 
				tc_strdup("Mar",&monname);
				break;
        case 4 : 
                tc_strdup("Apr",&monname);				
				break;
        case 5 : 
				tc_strdup("May",&monname);
				break;
        case 6 : 
				tc_strdup("Jun",&monname);
				break;
        case 7 : 
				tc_strdup("Jul",&monname);
				break;
        case 8 : 
				tc_strdup("Aug",&monname);
				break;
        case 9 : 
                tc_strdup("Sep",&monname);				
				break;
        case 10 : 
				tc_strdup("Oct",&monname);
				break;
        case 11 : 
                tc_strdup("Nov",&monname);				
				break;
        case 12 : 
				tc_strdup("Dec",&monname);
				break;
        default : printf("Input Number is Wrong..!!\n");
    }
	
   return monname;
}

char* TC_LeapYrChk(int yrno)
{
   char *leapstatus = NULL;
    if((yrno%4==0) && ((yrno%400==0) || (yrno%100!=0)))  
    {  
        tc_strdup("yes",&leapstatus);
    } 
	else 
	{  
        tc_strdup("no",&leapstatus); 
    }  
   return leapstatus;
}

int TC_CVDS6(FILE* CVRpt6)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	int TotalHCV = 0;
	int TotalBUS = 0;
	int TotalILMCV = 0;
	int TotalSCV = 0;
	int TotalILMCVBUS = 0;
	int TotalHCVILMCV = 0;
	int TotalBUSSCV = 0;
	int TotalHCVBUS = 0;
	int TotalHCVSCV = 0;
	int TotalILMCVSCV = 0;
	int TotalHCVILMCVSCV = 0;
	int TotalHCVILMCVBUS = 0;
	int TotalILMCVBUSSCV = 0;
	int TotalHCVILMCVBUSSCV = 0;
	int TotalHCVILMCVBUSILMCVDEFENCE = 0;
	int TotalHCVILMCVBUSILMCVDEFENCESCV = 0;
	int TotalHCVILMCVILMCVDEFENCE = 0;
	int TotalBUSILMCVDEFENCE = 0;
	int TotalHCVDEFENCEILMCVBUS = 0;
	int TotalILMCVBUSILMCVDEFENCE = 0;
	int TotalILMCVILMCVDEFENCE = 0;
	int TotalHCVDEFENCE = 0;
	int TotalILMCVDEFENCE = 0;
	int TotalHCVPOC = 0;
	int TotalILMCVPOC = 0;
	int TotalBUSPOC = 0;
	int TotalSCVPOC = 0;
	
	
	write2xml(CVRpt6,"<DataSheet7>\n");
	write2xml(CVRpt6,"<DS7Col1>\n");
	write2xml(CVRpt6,"<DS7Row11>"); write2xml(CVRpt6,"Exclusive to PL"); write2xml(CVRpt6,"</DS7Row11>\n");
	write2xml(CVRpt6,"<DS7Row12>"); write2xml(CVRpt6,"Shared between 2 PLs"); write2xml(CVRpt6,"</DS7Row12>\n");
	write2xml(CVRpt6,"<DS7Row13>"); write2xml(CVRpt6,"Shared between 3 PLs"); write2xml(CVRpt6,"</DS7Row13>\n");
	write2xml(CVRpt6,"<DS7Row14>"); write2xml(CVRpt6,"Shared across all PLs"); write2xml(CVRpt6,"</DS7Row14>\n");
	write2xml(CVRpt6,"<DS7Row15>"); write2xml(CVRpt6,"Shared with Defence"); write2xml(CVRpt6,"</DS7Row15>\n");
	write2xml(CVRpt6,"<DS7Row16>"); write2xml(CVRpt6,"POC"); write2xml(CVRpt6,"</DS7Row16>\n");
	write2xml(CVRpt6,"</DS7Col1>\n");
	
	printf("\n Generating Sheet6 Data Print Start - Column2\n");fflush(stdout);
	write2xml(CVRpt6,"<DS7Col2>\n");
	write2xml(CVRpt6,"<DS7Row21>"); write2xml(CVRpt6,"Row Labels"); write2xml(CVRpt6,"</DS7Row21>\n");
	write2xml(CVRpt6,"<DS7Row22>"); write2xml(CVRpt6,"HCV"); write2xml(CVRpt6,"</DS7Row22>\n");
	write2xml(CVRpt6,"<DS7Row23>"); write2xml(CVRpt6,"CVP"); write2xml(CVRpt6,"</DS7Row23>\n");
	write2xml(CVRpt6,"<DS7Row24>"); write2xml(CVRpt6,"ILMCV"); write2xml(CVRpt6,"</DS7Row24>\n");
	write2xml(CVRpt6,"<DS7Row25>"); write2xml(CVRpt6,"SCV"); write2xml(CVRpt6,"</DS7Row25>\n");
	write2xml(CVRpt6,"<DS7Row26>"); write2xml(CVRpt6,"ILMCV/CVP"); write2xml(CVRpt6,"</DS7Row26>\n");
	write2xml(CVRpt6,"<DS7Row27>"); write2xml(CVRpt6,"HCV/ILMCV"); write2xml(CVRpt6,"</DS7Row27>\n");
	write2xml(CVRpt6,"<DS7Row28>"); write2xml(CVRpt6,"CVP/SCV"); write2xml(CVRpt6,"</DS7Row28>\n");
	write2xml(CVRpt6,"<DS7Row29>"); write2xml(CVRpt6,"HCV/CVP"); write2xml(CVRpt6,"</DS7Row29>\n");
	write2xml(CVRpt6,"<DS7Row210>"); write2xml(CVRpt6,"HCV/SCV"); write2xml(CVRpt6,"</DS7Row210>\n");
	write2xml(CVRpt6,"<DS7Row211>"); write2xml(CVRpt6,"ILMCV/SCV"); write2xml(CVRpt6,"</DS7Row211>\n");
	write2xml(CVRpt6,"<DS7Row212>"); write2xml(CVRpt6,"HCV/ILMCV/SCV"); write2xml(CVRpt6,"</DS7Row212>\n");
	write2xml(CVRpt6,"<DS7Row213>"); write2xml(CVRpt6,"HCV/ILMCV/CVP"); write2xml(CVRpt6,"</DS7Row213>\n");
	write2xml(CVRpt6,"<DS7Row214>"); write2xml(CVRpt6,"ILMCV/CVP/SCV"); write2xml(CVRpt6,"</DS7Row214>\n");
	write2xml(CVRpt6,"<DS7Row215>"); write2xml(CVRpt6,"HCV/ILMCV/CVP/SCV"); write2xml(CVRpt6,"</DS7Row215>\n");
	write2xml(CVRpt6,"<DS7Row216>"); write2xml(CVRpt6,"HCV/ILMCV/CVP/ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row216>\n");
	write2xml(CVRpt6,"<DS7Row217>"); write2xml(CVRpt6,"HCV/ILMCV/CVP/ILMCV-DEFENCE/SCV"); write2xml(CVRpt6,"</DS7Row217>\n");
	write2xml(CVRpt6,"<DS7Row218>"); write2xml(CVRpt6,"HCV/ILMCV/ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row218>\n");
	write2xml(CVRpt6,"<DS7Row219>"); write2xml(CVRpt6,"CVP/ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row219>\n");
	write2xml(CVRpt6,"<DS7Row220>"); write2xml(CVRpt6,"HCV-DEFENCE/ILMCV/CVP"); write2xml(CVRpt6,"</DS7Row220>\n");
	write2xml(CVRpt6,"<DS7Row221>"); write2xml(CVRpt6,"ILMCV/CVP/ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row221>\n");
	write2xml(CVRpt6,"<DS7Row222>"); write2xml(CVRpt6,"ILMCV/ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row222>\n");
	write2xml(CVRpt6,"<DS7Row223>"); write2xml(CVRpt6,"HCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row223>\n");
	write2xml(CVRpt6,"<DS7Row224>"); write2xml(CVRpt6,"ILMCV-DEFENCE"); write2xml(CVRpt6,"</DS7Row224>\n");
	write2xml(CVRpt6,"<DS7Row225>"); write2xml(CVRpt6,"HCV-POC"); write2xml(CVRpt6,"</DS7Row225>\n");
	write2xml(CVRpt6,"<DS7Row226>"); write2xml(CVRpt6,"ILMCV-POC"); write2xml(CVRpt6,"</DS7Row226>\n");
	write2xml(CVRpt6,"<DS7Row227>"); write2xml(CVRpt6,"CVP-POC"); write2xml(CVRpt6,"</DS7Row227>\n");
	write2xml(CVRpt6,"<DS7Row228>"); write2xml(CVRpt6,"SCV-POC"); write2xml(CVRpt6,"</DS7Row228>\n");
	write2xml(CVRpt6,"</DS7Col2>\n");
	printf("\n Generating Sheet6 Data Print End - Column2\n");fflush(stdout);
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						for(j = 0; j < sec_countaggr; j++)
			            {
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
									for(k = 0; k < sec_countmod; k++)
									{
										ModRev_tag = sec_modobjects[k];
                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												for(l = 0; l < sec_countsubmod; l++)
												{
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]\n", n_valid_rows);fflush(stdout);
													if(n_valid_rows>0)
													{
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															trimwhitespace(Tbl_SubModProd);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															printf("\n Table SubModule Productline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															
															if((tc_strcmp(Tbl_SubModProddup,"HCV")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV_TRACTOR")==0) || (tc_strcmp(Tbl_SubModProddup,"MHCV")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV_TRUCK")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV_TIPPER")==0) || (tc_strcmp(Tbl_SubModProddup,"HTK-HCV_TRUCK")==0) || (tc_strcmp(Tbl_SubModProddup,"HTI-HCV_TIPPER")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV IB")==0) || (tc_strcmp(Tbl_SubModProddup,"HTR-HCV_TRACTOR")==0))
															{
															   printf("\n As Product Line: HCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCV = TotalHCV + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"BUS")==0) || (tc_strcmp(Tbl_SubModProddup,"BUS_ILMCV_LPO")==0)) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: BUS, So Incrementing Count..!!\n");fflush(stdout);
															   TotalBUS = TotalBUS + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"ILMCV")==0) || (tc_strcmp(Tbl_SubModProddup,"ILCV")==0) || (tc_strcmp(Tbl_SubModProddup,"ILMCV_ULTRA_NARROW")==0))
															{
															   printf("\n As Product Line: ILMCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCV = TotalILMCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"SCV")==0)
															{
															   printf("\n As Product Line: SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalSCV = TotalSCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV/BUS")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: ILMCV/CVP, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVBUS = TotalILMCVBUS + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV")==0)
															{
															   printf("\n As Product Line: HCV/ILMCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCV = TotalHCVILMCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"BUS/SCV")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: BUS/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalBUSSCV = TotalBUSSCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/BUS")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV/BUS, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVBUS = TotalHCVBUS + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/SCV")==0)
															{
															   printf("\n As Product Line: HCV/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVSCV = TotalHCVSCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV/SCV")==0)
															{
															   printf("\n As Product Line: ILMCV/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVSCV = TotalILMCVSCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/SCV")==0)
															{
															   printf("\n As Product Line: HCV/ILMCV/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVSCV = TotalHCVILMCVSCV + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/BUS")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV/BUS/SCV")==0)) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV/ILMCV/BUS, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVBUS = TotalHCVILMCVBUS + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV/BUS/SCV")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: ILMCV/BUS/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVBUSSCV = TotalILMCVBUSSCV + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/BUS/SCV")==0)  //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV/ILMCV/BUS/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVBUSSCV = TotalHCVILMCVBUSSCV + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/BUS/ILMCV-DEFENCE")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV/BUS/ILMCV-DEFENCE")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/ILMCV-DEFENCE/SCV")==0))  //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV/ILMCV/BUS/ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVBUSILMCVDEFENCE = TotalHCVILMCVBUSILMCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/BUS/ILMCV-DEFENCE/SCV")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV/ILMCV/BUS/ILMCV-DEFENCE/SCV, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVBUSILMCVDEFENCESCV = TotalHCVILMCVBUSILMCVDEFENCESCV + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV/ILMCV-DEFENCE")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV/ILMCV-DEFENCE")==0))
															{
															   printf("\n As Product Line: HCV/ILMCV/ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVILMCVILMCVDEFENCE = TotalHCVILMCVILMCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"BUS/ILMCV-DEFENCE")==0)
															{
															   printf("\n As Product Line: BUS/ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalBUSILMCVDEFENCE = TotalBUSILMCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV-DEFENCE/ILMCV/BUS")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: HCV-DEFENCE/ILMCV/BUS, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVDEFENCEILMCVBUS = TotalHCVDEFENCEILMCVBUS + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV/BUS/ILMCV-DEFENCE")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: ILMCV/BUS/ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVBUSILMCVDEFENCE = TotalILMCVBUSILMCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV/ILMCV-DEFENCE")==0)
															{
															   printf("\n As Product Line: ILMCV/ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVILMCVDEFENCE = TotalILMCVILMCVDEFENCE + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"HCV-DEFENCE")==0) || (tc_strcmp(Tbl_SubModProddup,"HCV_DEFENCE")==0))
															{
															   printf("\n As Product Line: HCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVDEFENCE = TotalHCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"ILMCV-DEFENCE")==0)
															{
															   printf("\n As Product Line: ILMCV-DEFENCE, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVDEFENCE = TotalILMCVDEFENCE + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"HCV-POC")==0)
															{
															   printf("\n As Product Line: HCV-POC, So Incrementing Count..!!\n");fflush(stdout);
															   TotalHCVPOC = TotalHCVPOC + 1;
															}
															else if((tc_strcmp(Tbl_SubModProddup,"ILMCV-POC")==0) || (tc_strcmp(Tbl_SubModProddup,"ILCV-POC")==0))
															{
															   printf("\n As Product Line: ILMCV-POC, So Incrementing Count..!!\n");fflush(stdout);
															   TotalILMCVPOC = TotalILMCVPOC + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"BUS-POC")==0) //As BUS is Treated As CVP
															{
															   printf("\n As Product Line: BUS-POC, So Incrementing Count..!!\n");fflush(stdout);
															   TotalBUSPOC = TotalBUSPOC + 1;
															}
															else if(tc_strcmp(Tbl_SubModProddup,"SCV-POC")==0)
															{
															   printf("\n As Product Line: SCV-POC, So Incrementing Count..!!\n");fflush(stdout);
															   TotalSCVPOC = TotalSCVPOC + 1;
															}
															else
															{
															   printf("\n Product Line is Blanked or Not Mapped..!!\n");fflush(stdout);
															}		
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule..!!\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found..!!\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found..!\n");fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found..!!\n");fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" SubModuleLibraryAggrGrp Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	printf("\n >>>>>>>>>>>>>>> Product Line Variety Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
	printf("[1] HCV: [%d]\n",TotalHCV);fflush(stdout);
	printf("[2] BUS: [%d]\n",TotalBUS);fflush(stdout);
	printf("[3] ILMCV: [%d]\n",TotalILMCV);fflush(stdout);
	printf("[4] SCV: [%d]\n",TotalSCV);fflush(stdout);
	printf("[5] ILMCV/BUS: [%d]\n",TotalILMCVBUS);fflush(stdout);
	printf("[6] HCV/ILMCV: [%d]\n",TotalHCVILMCV);fflush(stdout);
	printf("[7] BUS/SCV: [%d]\n",TotalBUSSCV);fflush(stdout);
	printf("[8] HCV/BUS: [%d]\n",TotalHCVBUS);fflush(stdout);
	printf("[9] HCV/SCV: [%d]\n",TotalHCVSCV);fflush(stdout);
	printf("[10] ILMCV/SCV: [%d]\n",TotalILMCVSCV);fflush(stdout);
	printf("[11] HCV/ILMCV/SCV: [%d]\n",TotalHCVILMCVSCV);fflush(stdout);
	printf("[12] HCV/ILMCV/BUS: [%d]\n",TotalHCVILMCVBUS);fflush(stdout);
	printf("[13] ILMCV/BUS/SCV: [%d]\n",TotalILMCVBUSSCV);fflush(stdout);
	printf("[14] HCV/ILMCV/BUS/SCV: [%d]\n",TotalHCVILMCVBUSSCV);fflush(stdout);
	printf("[15] HCV/ILMCV/BUS/ILMCV-DEFENCE: [%d]\n",TotalHCVILMCVBUSILMCVDEFENCE);fflush(stdout);
	printf("[16] HCV/ILMCV/BUS/ILMCV-DEFENCE/SCV: [%d]\n",TotalHCVILMCVBUSILMCVDEFENCESCV);fflush(stdout);
	printf("[17] HCV/ILMCV/ILMCV-DEFENCE: [%d]\n",TotalHCVILMCVILMCVDEFENCE);fflush(stdout);
	printf("[18] BUS/ILMCV-DEFENCE: [%d]\n",TotalBUSILMCVDEFENCE);fflush(stdout);
	printf("[19] HCV-DEFENCE/ILMCV/BUS: [%d]\n",TotalHCVDEFENCEILMCVBUS);fflush(stdout);
	printf("[20] ILMCV/BUS/ILMCV-DEFENCE: [%d]\n",TotalILMCVBUSILMCVDEFENCE);fflush(stdout);
	printf("[21] ILMCV/ILMCV-DEFENCE: [%d]\n",TotalILMCVILMCVDEFENCE);fflush(stdout);
	printf("[22] HCV-DEFENCE: [%d]\n",TotalHCVDEFENCE);fflush(stdout);
	printf("[23] ILMCV-DEFENCE: [%d]\n",TotalILMCVDEFENCE);fflush(stdout);
	printf("[24] HCV-POC: [%d]\n",TotalHCVPOC);fflush(stdout);
	printf("[25] ILMCV-POC: [%d]\n",TotalILMCVPOC);fflush(stdout);
	printf("[26] BUS-POC: [%d]\n",TotalBUSPOC);fflush(stdout);
	printf("[27] SCV-POC: [%d]\n",TotalSCVPOC);fflush(stdout);
	printf("\n >>>>>>>>>>>>>>> Product Line Variety Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
	
	int exctopl = 0;
	int sharedbet2pl = 0;
	int sharedbet3pl = 0;
	int sharedacpl = 0;
	int shareddef = 0;
	int poc = 0;
	int allplttotal = 0;
	float exctoplper;
	float sharedbet2plper;
	float sharedbet3plper;
	float sharedacplper;
	float shareddefper;
	float pocper;
	
	exctopl = TotalHCV + TotalBUS + TotalILMCV + TotalSCV;
	sharedbet2pl = TotalILMCVBUS + TotalHCVILMCV + TotalBUSSCV + TotalHCVBUS + TotalHCVSCV + TotalILMCVSCV;
	sharedbet3pl = TotalHCVILMCVSCV + TotalHCVILMCVBUS + TotalILMCVBUSSCV;
	sharedacpl = TotalHCVILMCVBUSSCV;
	shareddef = TotalHCVILMCVBUSILMCVDEFENCE + TotalHCVILMCVBUSILMCVDEFENCESCV + TotalHCVILMCVILMCVDEFENCE + TotalBUSILMCVDEFENCE + TotalHCVDEFENCEILMCVBUS + TotalILMCVBUSILMCVDEFENCE + TotalILMCVILMCVDEFENCE + TotalHCVDEFENCE + TotalILMCVDEFENCE;
	poc = TotalHCVPOC + TotalILMCVPOC + TotalBUSPOC + TotalSCVPOC;
	allplttotal = exctopl + sharedbet2pl + sharedbet3pl + sharedacpl + shareddef + poc;
	
	/* exctoplper = (float)((exctopl * 100) / allplttotal);
	sharedbet2plper = (float)((sharedbet2pl * 100) / allplttotal);
	sharedbet3plper = (float)((sharedbet3pl * 100) / allplttotal);
	sharedacplper = (float)((sharedacpl * 100) / allplttotal);
	shareddefper = (float)((shareddef * 100) / allplttotal);
	pocper = (float)((poc * 100) / allplttotal); */
	
	exctoplper = (float)exctopl*100/allplttotal;
	sharedbet2plper = (float)sharedbet2pl*100/allplttotal;
	sharedbet3plper = (float)sharedbet3pl*100/allplttotal;
	sharedacplper = (float)sharedacpl*100/allplttotal;
	shareddefper = (float)shareddef*100/allplttotal;
	pocper = (float)poc*100/allplttotal;
	
	
	char TotalHCVstr[10];
    char TotalBUSstr[10];
	char TotalILMCVstr[10];
	char TotalSCVstr[10];
	char TotalILMCVBUSstr[10];
	char TotalHCVILMCVstr[10];
    char TotalBUSSCVstr[10];
	char TotalHCVBUSstr[10];
	char TotalHCVSCVstr[10];
	char TotalILMCVSCVstr[10];
	char TotalHCVILMCVSCVstr[10];
    char TotalHCVILMCVBUSstr[10];
	char TotalILMCVBUSSCVstr[10];
	char TotalHCVILMCVBUSSCVstr[10];
	char TotalHCVILMCVBUSILMCVDEFENCEstr[10];
	char TotalHCVILMCVBUSILMCVDEFENCESCVstr[10];
    char TotalHCVILMCVILMCVDEFENCEstr[10];
	char TotalBUSILMCVDEFENCEstr[10];
	char TotalHCVDEFENCEILMCVBUSstr[10];
	char TotalILMCVBUSILMCVDEFENCEstr[10];
	char TotalILMCVILMCVDEFENCEstr[10];
	char TotalHCVDEFENCEstr[10];
	char TotalILMCVDEFENCEstr[10];
	char TotalHCVPOCstr[10];
	char TotalILMCVPOCstr[10];
	char TotalBUSPOCstr[10];
	char TotalSCVPOCstr[10];
	char exctoplstr[10];
	char sharedbet2plstr[10];
	char sharedbet3plstr[10];
	char sharedacplstr[10];
	char shareddefstr[10];
	char pocstr[10];
	char exctoplperstr[10];
	char sharedbet2plperstr[10];
	char sharedbet3plperstr[10];
	char sharedacplperstr[10];
	char shareddefperstr[10];
	char pocperstr[10];
	char allplttotalstr[10];
	
	tostring(TotalHCVstr, TotalHCV);
	tostring(TotalBUSstr, TotalBUS);
	tostring(TotalILMCVstr, TotalILMCV);
	tostring(TotalSCVstr, TotalSCV);
	tostring(TotalILMCVBUSstr, TotalILMCVBUS);
	tostring(TotalHCVILMCVstr, TotalHCVILMCV);
	tostring(TotalBUSSCVstr, TotalBUSSCV);
	tostring(TotalHCVBUSstr, TotalHCVBUS);
	tostring(TotalHCVSCVstr, TotalHCVSCV);
	tostring(TotalILMCVSCVstr, TotalILMCVSCV);
	tostring(TotalHCVILMCVSCVstr, TotalHCVILMCVSCV);
	tostring(TotalHCVILMCVBUSstr, TotalHCVILMCVBUS);
	tostring(TotalILMCVBUSSCVstr, TotalILMCVBUSSCV);
	tostring(TotalHCVILMCVBUSSCVstr, TotalHCVILMCVBUSSCV);
	tostring(TotalHCVILMCVBUSILMCVDEFENCEstr, TotalHCVILMCVBUSILMCVDEFENCE);
	tostring(TotalHCVILMCVBUSILMCVDEFENCESCVstr, TotalHCVILMCVBUSILMCVDEFENCESCV);
	tostring(TotalHCVILMCVILMCVDEFENCEstr, TotalHCVILMCVILMCVDEFENCE);
	tostring(TotalBUSILMCVDEFENCEstr, TotalBUSILMCVDEFENCE);
	tostring(TotalHCVDEFENCEILMCVBUSstr, TotalHCVDEFENCEILMCVBUS);
	tostring(TotalILMCVBUSILMCVDEFENCEstr, TotalILMCVBUSILMCVDEFENCE);
	tostring(TotalILMCVILMCVDEFENCEstr, TotalILMCVILMCVDEFENCE);
	tostring(TotalHCVDEFENCEstr, TotalHCVDEFENCE);
	tostring(TotalILMCVDEFENCEstr, TotalILMCVDEFENCE);
	tostring(TotalHCVPOCstr, TotalHCVPOC);
	tostring(TotalILMCVPOCstr, TotalILMCVPOC);
	tostring(TotalBUSPOCstr, TotalBUSPOC);
	tostring(TotalSCVPOCstr, TotalSCVPOC);
	tostring(exctoplstr, exctopl);
	tostring(sharedbet2plstr, sharedbet2pl);
	tostring(sharedbet3plstr, sharedbet3pl);
	tostring(sharedacplstr, sharedacpl);
	tostring(shareddefstr, shareddef);
	tostring(pocstr, poc);
	//tostring(exctoplperstr, exctoplper);
	//tostring(sharedbet2plperstr, sharedbet2plper);
	//tostring(sharedbet3plperstr, sharedbet3plper);
	//tostring(sharedacplperstr, sharedacplper);
	//tostring(shareddefperstr, shareddefper);
	//tostring(pocperstr, pocper);
	sprintf(exctoplperstr, "%.3f", exctoplper);
	sprintf(sharedbet2plperstr, "%.3f", sharedbet2plper);
	sprintf(sharedbet3plperstr, "%.3f", sharedbet3plper);
	sprintf(sharedacplperstr, "%.3f", sharedacplper);
	sprintf(shareddefperstr, "%.3f", shareddefper);
	sprintf(pocperstr, "%.3f", pocper);
	tostring(allplttotalstr, allplttotal);
	
	printf("\n Generating Sheet6 Data Print Start - Column3\n");fflush(stdout);
	write2xml(CVRpt6,"<DS7Col3>\n");
	write2xml(CVRpt6,"<DS7Row31>"); write2xml(CVRpt6,"Count"); write2xml(CVRpt6,"</DS7Row31>\n");
	write2xml(CVRpt6,"<DS7Row32>"); if(tc_strlen(TotalHCVstr)>0) write2xml(CVRpt6,TotalHCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row32>\n");
	write2xml(CVRpt6,"<DS7Row33>"); if(tc_strlen(TotalBUSstr)>0) write2xml(CVRpt6,TotalBUSstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row33>\n");
	write2xml(CVRpt6,"<DS7Row34>"); if(tc_strlen(TotalILMCVstr)>0) write2xml(CVRpt6,TotalILMCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row34>\n");
	write2xml(CVRpt6,"<DS7Row35>"); if(tc_strlen(TotalSCVstr)>0) write2xml(CVRpt6,TotalSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row35>\n");
	write2xml(CVRpt6,"<DS7Row36>"); if(tc_strlen(TotalILMCVBUSstr)>0) write2xml(CVRpt6,TotalILMCVBUSstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row36>\n");
	write2xml(CVRpt6,"<DS7Row37>"); if(tc_strlen(TotalHCVILMCVstr)>0) write2xml(CVRpt6,TotalHCVILMCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row37>\n");
	write2xml(CVRpt6,"<DS7Row38>"); if(tc_strlen(TotalBUSSCVstr)>0) write2xml(CVRpt6,TotalBUSSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row38>\n");
	write2xml(CVRpt6,"<DS7Row39>"); if(tc_strlen(TotalHCVBUSstr)>0) write2xml(CVRpt6,TotalHCVBUSstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row39>\n");
	write2xml(CVRpt6,"<DS7Row310>"); if(tc_strlen(TotalHCVSCVstr)>0) write2xml(CVRpt6,TotalHCVSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row310>\n");
	write2xml(CVRpt6,"<DS7Row311>"); if(tc_strlen(TotalILMCVSCVstr)>0) write2xml(CVRpt6,TotalILMCVSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row311>\n");
	write2xml(CVRpt6,"<DS7Row312>"); if(tc_strlen(TotalHCVILMCVSCVstr)>0) write2xml(CVRpt6,TotalHCVILMCVSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row312>\n");
	write2xml(CVRpt6,"<DS7Row313>"); if(tc_strlen(TotalHCVILMCVBUSstr)>0) write2xml(CVRpt6,TotalHCVILMCVBUSstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row313>\n");
	write2xml(CVRpt6,"<DS7Row314>"); if(tc_strlen(TotalILMCVBUSSCVstr)>0) write2xml(CVRpt6,TotalILMCVBUSSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row314>\n");
	write2xml(CVRpt6,"<DS7Row315>"); if(tc_strlen(TotalHCVILMCVBUSSCVstr)>0) write2xml(CVRpt6,TotalHCVILMCVBUSSCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row315>\n");
	write2xml(CVRpt6,"<DS7Row316>"); if(tc_strlen(TotalHCVILMCVBUSILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalHCVILMCVBUSILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row316>\n");
	write2xml(CVRpt6,"<DS7Row317>"); if(tc_strlen(TotalHCVILMCVBUSILMCVDEFENCESCVstr)>0) write2xml(CVRpt6,TotalHCVILMCVBUSILMCVDEFENCESCVstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row317>\n");
	write2xml(CVRpt6,"<DS7Row318>"); if(tc_strlen(TotalHCVILMCVILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalHCVILMCVILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row318>\n");
	write2xml(CVRpt6,"<DS7Row319>"); if(tc_strlen(TotalBUSILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalBUSILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row319>\n");
	write2xml(CVRpt6,"<DS7Row320>"); if(tc_strlen(TotalHCVDEFENCEILMCVBUSstr)>0) write2xml(CVRpt6,TotalHCVDEFENCEILMCVBUSstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row320>\n");
	write2xml(CVRpt6,"<DS7Row321>"); if(tc_strlen(TotalILMCVBUSILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalILMCVBUSILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row321>\n");
	write2xml(CVRpt6,"<DS7Row322>"); if(tc_strlen(TotalILMCVILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalILMCVILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row322>\n");
	write2xml(CVRpt6,"<DS7Row323>"); if(tc_strlen(TotalHCVDEFENCEstr)>0) write2xml(CVRpt6,TotalHCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row323>\n");
	write2xml(CVRpt6,"<DS7Row324>"); if(tc_strlen(TotalILMCVDEFENCEstr)>0) write2xml(CVRpt6,TotalILMCVDEFENCEstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row324>\n");
	write2xml(CVRpt6,"<DS7Row325>"); if(tc_strlen(TotalHCVPOCstr)>0) write2xml(CVRpt6,TotalHCVPOCstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row325>\n");
	write2xml(CVRpt6,"<DS7Row326>"); if(tc_strlen(TotalILMCVPOCstr)>0) write2xml(CVRpt6,TotalILMCVPOCstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row326>\n");
	write2xml(CVRpt6,"<DS7Row327>"); if(tc_strlen(TotalBUSPOCstr)>0) write2xml(CVRpt6,TotalBUSPOCstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row327>\n");
	write2xml(CVRpt6,"<DS7Row328>"); if(tc_strlen(TotalSCVPOCstr)>0) write2xml(CVRpt6,TotalSCVPOCstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row328>\n");
	write2xml(CVRpt6,"<DS7Row329>"); if(tc_strlen(allplttotalstr)>0) write2xml(CVRpt6,allplttotalstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row329>\n");
	write2xml(CVRpt6,"</DS7Col3>\n");
	printf("\n Generating Sheet6 Data Print End - Column3\n");fflush(stdout);
	
	printf("\n Generating Sheet6 Data Print Start - Column4\n");fflush(stdout);
	write2xml(CVRpt6,"<DS7Col4>\n");
	write2xml(CVRpt6,"<DS7Row41>"); write2xml(CVRpt6,"Total submodules"); write2xml(CVRpt6,"</DS7Row41>\n");
	write2xml(CVRpt6,"<DS7Row42>"); if(tc_strlen(exctoplstr)>0) write2xml(CVRpt6,exctoplstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row42>\n");
	write2xml(CVRpt6,"<DS7Row43>"); if(tc_strlen(sharedbet2plstr)>0) write2xml(CVRpt6,sharedbet2plstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row43>\n");
	write2xml(CVRpt6,"<DS7Row44>"); if(tc_strlen(sharedbet3plstr)>0) write2xml(CVRpt6,sharedbet3plstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row44>\n");
	write2xml(CVRpt6,"<DS7Row45>"); if(tc_strlen(sharedacplstr)>0) write2xml(CVRpt6,sharedacplstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row45>\n");
	write2xml(CVRpt6,"<DS7Row46>"); if(tc_strlen(shareddefstr)>0) write2xml(CVRpt6,shareddefstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row46>\n");
	write2xml(CVRpt6,"<DS7Row47>"); if(tc_strlen(pocstr)>0) write2xml(CVRpt6,pocstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row47>\n");
	write2xml(CVRpt6,"<DS7Row48>"); if(tc_strlen(allplttotalstr)>0) write2xml(CVRpt6,allplttotalstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row48>\n");
	write2xml(CVRpt6,"</DS7Col4>\n");
	printf("\n Generating Sheet6 Data Print End - Column4\n");fflush(stdout);
	
	printf("\n Generating Sheet6 Data Print Start - Column5\n");fflush(stdout);
	write2xml(CVRpt6,"<DS7Col5>\n");
	write2xml(CVRpt6,"<DS7Row51>"); write2xml(CVRpt6,"Percentage"); write2xml(CVRpt6,"</DS7Row51>\n");
	write2xml(CVRpt6,"<DS7Row52>"); if(tc_strlen(exctoplperstr)>0) write2xml(CVRpt6,exctoplperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row52>\n");
	write2xml(CVRpt6,"<DS7Row53>"); if(tc_strlen(sharedbet2plperstr)>0) write2xml(CVRpt6,sharedbet2plperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row53>\n");
	write2xml(CVRpt6,"<DS7Row54>"); if(tc_strlen(sharedbet3plperstr)>0) write2xml(CVRpt6,sharedbet3plperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row54>\n");
	write2xml(CVRpt6,"<DS7Row55>"); if(tc_strlen(sharedacplperstr)>0) write2xml(CVRpt6,sharedacplperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row55>\n");
	write2xml(CVRpt6,"<DS7Row56>"); if(tc_strlen(shareddefperstr)>0) write2xml(CVRpt6,shareddefperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row56>\n");
	write2xml(CVRpt6,"<DS7Row57>"); if(tc_strlen(pocperstr)>0) write2xml(CVRpt6,pocperstr); else write2xml(CVRpt6,"0"); write2xml(CVRpt6,"</DS7Row57>\n");
	write2xml(CVRpt6,"</DS7Col5>\n");
	printf("\n Generating Sheet6 Data Print End - Column5\n");fflush(stdout);
	
	write2xml(CVRpt6,"</DataSheet7>\n");
	return iFail;
}

int TC_CVDS5(FILE* CVRpt5)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tsubmodlib_rev = NULLTAG;
	char *SubModAddr_Str = NULL;
	char *SubModAddr_StrDup = NULL;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *LbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fplb_file = NULL;
	char *MstrLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fmstrplb_file = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Vehicle Count Report File Name..!!");fflush(stdout);
	tc_strcpy(LbRptFile,"/tmp/");
	tc_strcat(LbRptFile,"SubModVehCount");
	tc_strcat(LbRptFile,"_");
	tc_strcat(LbRptFile,GenDate);
	tc_strcat(LbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", LbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Master Submodule Vehicle Count Report File Name..!!");fflush(stdout);
	tc_strcpy(MstrLbRptFile,"/tmp/");
	tc_strcat(MstrLbRptFile,"MasterSubModVehCount");
	tc_strcat(MstrLbRptFile,"_");
	tc_strcat(MstrLbRptFile,GenDate);
	tc_strcat(MstrLbRptFile,".txt");
	printf("\n Master Submodule Vehicle Count Report File Name: [%s]", MstrLbRptFile);fflush(stdout);
	printf("\n Master Submodule Vehicle Count Report File Generated..!!");fflush(stdout);
	fplb_file = fopen(LbRptFile, "w");
	//fmstrplb_file = fopen(MstrLbRptFile, "w");
	
	printf("\n Submodule Vehicle Count Report File Generated..!!");fflush(stdout);
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nSubModule Address Revision Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tsubmodlib_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tsubmodlib_rev,"item_id",&SubModAddr_Str));
				trimwhitespace(SubModAddr_Str);
				if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
				ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
				printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
				if(n_valid_rows>0)
				{
					int iValCnt=0;
					for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
					{
						char* Tbl_SubModNo = NULL;
						char* Tbl_SubModNodup = NULL;
						char* Tbl_SubModFreq = NULL;
						char* Tbl_SubModFreqdup = NULL;
						printf("\n [Start] Printing of Table Row: [%d]\n",iValCnt);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_info1",&Tbl_SubModFreq));
						trimwhitespace(Tbl_SubModNo);
						trimwhitespace(Tbl_SubModFreq);
						if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
						if(Tbl_SubModFreq!=NULL)tc_strdup(Tbl_SubModFreq,&Tbl_SubModFreqdup);
						if(tc_strlen(Tbl_SubModNodup)>0)
						{
						  fprintf(fplb_file,"%s^%s^\n",Tbl_SubModNodup,Tbl_SubModFreqdup);fflush(fplb_file);
						}  
						printf("\n [End] Printing of Table Row: [%d]",iValCnt);fflush(stdout);
					}
				}
				else
				{
					printf("\n No Table Row Found Zero For Input SubModule Address: [%s]\n", SubModAddr_StrDup);fflush(stdout);
				}
			}				
		}
		else
		{
		   printf("\n SubModule Address Revision Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fplb_file);
	
	char command[512];
	printf("\n File Short Shell Call Started...");fflush(stdout);
	sprintf(command,"/user/cvprod/sourav/MCCMAINDASHBOARD/FileShort.sh %s %s",LbRptFile,MstrLbRptFile);
	system(command);
	printf("\n File Short Shell Call Ended...");

	char *item_id_str = NULL;
	char *item_freq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_freq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer1[MAX_LINE_LENGTH];
	int i = 0;
	int valrange1 = 0;
	int valrange2 = 0;
	int valrange3 = 0;
	int valrange4 = 0;
	int valrange5 = 0;
	int freqrange;
	fpPart_List = fopen(MstrLbRptFile,"r");
	
	if(fpPart_List == NULL)
	{
	    printf("\n Unable to Open Input File \n");fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer1,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer1,"^");
			item_freq_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_freq_str!=NULL)tc_strdup(item_freq_str,&item_freq_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_freq_strDup!=NULL)trimwhitespace(item_freq_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Frequency(item_plat_strDup): [%s]\n",item_freq_strDup);
			
	        freqrange = atoi(item_freq_strDup);
	        printf("\nFrequency Range[INT]: [%d]\n", freqrange);fflush(stdout);
			
			if(freqrange==1)
			{
				valrange1 = valrange1 + 1;
			}
			else if((freqrange>1) && (freqrange<6))
			{
				valrange2 = valrange2 + 1;
			}
			else if((freqrange>5) && (freqrange<16))
			{
				valrange3 = valrange3 + 1;
			}
			else if((freqrange>15) && (freqrange<100))
			{
				valrange4 = valrange4 + 1;
			}
			else if(freqrange>=100)
			{
				valrange5 = valrange5 + 1;
			}
			else
			{
				printf("\n!!...Frequency Not Matched..!!\n");fflush(stdout);
			}
		}
		
		int allvalrangetotal = 0;
		allvalrangetotal = valrange1 + valrange2 + valrange3 + valrange4 + valrange5;
		float valrange1per;
		float valrange2per;
		float valrange3per;
		float valrange4per;
		float valrange5per;
		char valrange1perstr[10];
		char valrange2perstr[10];
		char valrange3perstr[10];
		char valrange4perstr[10];
		char valrange5perstr[10];
		
		valrange1per = (float)valrange1*100/allvalrangetotal;
		valrange2per = (float)valrange2*100/allvalrangetotal;
		valrange3per = (float)valrange3*100/allvalrangetotal;
		valrange4per = (float)valrange4*100/allvalrangetotal;
		valrange5per = (float)valrange5*100/allvalrangetotal;
		sprintf(valrange1perstr, "%.3f", valrange1per);
		sprintf(valrange2perstr, "%.3f", valrange2per);
		sprintf(valrange3perstr, "%.3f", valrange3per);
		sprintf(valrange4perstr, "%.3f", valrange4per);
		sprintf(valrange5perstr, "%.3f", valrange5per);
		
		char valrange1str[10];
		char valrange2str[10];
		char valrange3str[10];
		char valrange4str[10];
		char valrange5str[10];
		char allvalrangetotalstr[10];
		tostring(valrange1str, valrange1);
		tostring(valrange2str, valrange2);
		tostring(valrange3str, valrange3);
		tostring(valrange4str, valrange4);
		tostring(valrange5str, valrange5);
		tostring(allvalrangetotalstr, allvalrangetotal);

		write2xml(CVRpt5,"<DataSheet5>\n");
		write2xml(CVRpt5,"<DS5Col1>"); write2xml(CVRpt5,valrange1str); write2xml(CVRpt5,"</DS5Col1>\n");
		write2xml(CVRpt5,"<DS5Col1Per>"); write2xml(CVRpt5,valrange1perstr); write2xml(CVRpt5,"</DS5Col1Per>\n");
		write2xml(CVRpt5,"<DS5Col2>"); write2xml(CVRpt5,valrange2str); write2xml(CVRpt5,"</DS5Col2>\n");
		write2xml(CVRpt5,"<DS5Col2Per>"); write2xml(CVRpt5,valrange2perstr); write2xml(CVRpt5,"</DS5Col2Per>\n");
		write2xml(CVRpt5,"<DS5Col3>"); write2xml(CVRpt5,valrange3str); write2xml(CVRpt5,"</DS5Col3>\n");
		write2xml(CVRpt5,"<DS5Col3Per>"); write2xml(CVRpt5,valrange3perstr); write2xml(CVRpt5,"</DS5Col3Per>\n");
		write2xml(CVRpt5,"<DS5Col4>"); write2xml(CVRpt5,valrange4str); write2xml(CVRpt5,"</DS5Col4>\n");
		write2xml(CVRpt5,"<DS5Col4Per>"); write2xml(CVRpt5,valrange4perstr); write2xml(CVRpt5,"</DS5Col4Per>\n");
		write2xml(CVRpt5,"<DS5Col5>"); write2xml(CVRpt5,valrange5str); write2xml(CVRpt5,"</DS5Col5>\n");
		write2xml(CVRpt5,"<DS5Col5Per>"); write2xml(CVRpt5,valrange5perstr); write2xml(CVRpt5,"</DS5Col5Per>\n");
		write2xml(CVRpt5,"<DS5Col5Total>"); write2xml(CVRpt5,allvalrangetotalstr); write2xml(CVRpt5,"</DS5Col5Total>\n");
		write2xml(CVRpt5,"</DataSheet5>\n");
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	
	return iFail;
}

int SUBTC_CVDS4(char* colhead, char* startdate, char* enddate, FILE* SUBCVRpt4, int colcst)
{
	int iFail = ITK_ok;
	char colc[10];
	tostring(colc, colcst);
	tag_t tItemobj = NULLTAG;
	int n_entries = 5;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tdes_rev = NULLTAG;
	char *desrev_partno_str = NULL;
	char *desrev_partno_strdup = NULL;
	char *desrev_platform_str = NULL;
	char *desrev_platform_strdup = NULL;
	char *VLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fpvlb_file = NULL;
	char *SData = (char *) malloc(100*sizeof(char));
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(VLbRptFile,"/tmp/");
	tc_strcat(VLbRptFile,"DS4VehDataDetails");
	tc_strcat(VLbRptFile,"_");
	tc_strcat(VLbRptFile,GenDate);
	tc_strcat(VLbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", VLbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	fpvlb_file = fopen(VLbRptFile, "w");
	
    printf("\n Vehicle Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cValues[5]  = {"*",startdate,enddate,"V","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","V","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tdes_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tdes_rev,"item_id",&desrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tdes_rev,"t5_Platform",&desrev_platform_str));
				trimwhitespace(desrev_partno_str);
				trimwhitespace(desrev_platform_str);
				if(desrev_partno_str!=NULL)tc_strdup(desrev_partno_str,&desrev_partno_strdup);
				if(desrev_platform_str!=NULL)tc_strdup(desrev_platform_str,&desrev_platform_strdup);
				printf("\n Part No: [%d]\n", desrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%d]\n", desrev_platform_strdup);fflush(stdout);
				printf("\n [Start] Printing of Data: [%d]\n",k);fflush(stdout);
				if(tc_strlen(desrev_partno_strdup)>0)
				{
					fprintf(fpvlb_file,"%s^%s^\n",desrev_partno_strdup,desrev_platform_strdup);fflush(fpvlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",k);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	printf("\n Vehicle Data Details Find End..!!\n");fflush(stdout);
	tag_t tvccrItemobj = NULLTAG;
	int n_vccrentries = 5;
	int n_vccritemobj_found = 0;
	tag_t* tvccritemobj_results = NULLTAG;
	int g = 0;
	tag_t tvccrdes_rev = NULLTAG;
	char *vccrdesrev_partno_str = NULL;
	char *vccrdesrev_partno_strdup = NULL;
	char *vccrdesrev_platform_str = NULL;
	char *vccrdesrev_platform_strdup = NULL;
	printf("\n Vehicle Combination CR Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tvccrItemobj));
	if(tvccrItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cvccrEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cvccrValues[5]  = {"*",startdate,enddate,"VCCR","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","VCCR","Design Revision"};
		ITK_CALL(QRY_execute(tvccrItemobj, n_vccrentries, cvccrEntries, cvccrValues, &n_vccritemobj_found, &tvccritemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_vccritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vccritemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(g = 0; g < n_vccritemobj_found; g++)
			{
				tvccrdes_rev = tvccritemobj_results[g];
				ITK_CALL(AOM_ask_value_string(tvccrdes_rev,"item_id",&vccrdesrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tvccrdes_rev,"t5_Platform",&vccrdesrev_platform_str));
				trimwhitespace(vccrdesrev_partno_str);
				trimwhitespace(vccrdesrev_platform_str);
				if(vccrdesrev_partno_str!=NULL)tc_strdup(vccrdesrev_partno_str,&vccrdesrev_partno_strdup);
				if(vccrdesrev_platform_str!=NULL)tc_strdup(vccrdesrev_platform_str,&vccrdesrev_platform_strdup);
				printf("\n Part No: [%d]\n", vccrdesrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%d]\n", vccrdesrev_platform_strdup);fflush(stdout);
				printf("\n [Start] Printing of Data: [%d]\n",g);fflush(stdout);
				if(tc_strlen(vccrdesrev_partno_strdup)>0)
				{
					fprintf(fpvlb_file,"%s^%s^\n",vccrdesrev_partno_strdup,vccrdesrev_platform_strdup);fflush(fpvlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",g);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	printf("\n Vehicle Combination CR Data Details Find End..!!\n");fflush(stdout);
	fclose(fpvlb_file);
	
	printf("\n SubModule Data Details Find Start..!!\n");fflush(stdout);
	tag_t tSMItemobj = NULLTAG;
	int n_sm_entries = 5;
	int n_sm_itemobj_found = 0;
	tag_t* tsmitemobj_results = NULLTAG;
	int p = 0;
	tag_t tsmdes_rev = NULLTAG;
	char *smdesrev_partno_str = NULL;
	char *smdesrev_partno_strdup = NULL;
	char *smdesrev_platform_str = NULL;
	char *smdesrev_platform_strdup = NULL;
	char *smdesrev_item_type = NULL;
	char *smdesrev_item_typedup = NULL;
	char *smdesrev_modaddr_str = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_VehLink_Status = NULL;
	char *Module_VehLink_StatusDup = NULL;
	char *Module_ProdLine_Status = NULL;
	char *Module_ProdLine_StatusDup = NULL;
	char *SMLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fpsmlb_file = NULL;
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(SMLbRptFile,"/tmp/");
	tc_strcat(SMLbRptFile,"DS4SubmoduleDataDetails");
	tc_strcat(SMLbRptFile,"_");
	tc_strcat(SMLbRptFile,GenDate);
	tc_strcat(SMLbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", SMLbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	fpsmlb_file = fopen(SMLbRptFile, "w");
	printf("\n SubModule Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tSMItemobj));
	if(tSMItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cSMEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cSMValues[5]  = {"*",startdate,enddate,"M","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","M","Design Revision"};
		ITK_CALL(QRY_execute(tSMItemobj, n_sm_entries, cSMEntries, cSMValues, &n_sm_itemobj_found, &tsmitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_sm_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_sm_itemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(p = 0; p < n_sm_itemobj_found; p++)
			{
				tsmdes_rev = tsmitemobj_results[p];
				ITK_CALL(AOM_ask_value_string(tsmdes_rev,"item_id",&smdesrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tsmdes_rev,"t5_Platform",&smdesrev_platform_str));
				ITK_CALL(AOM_UIF_ask_value(tsmdes_rev,"object_type",&smdesrev_item_type));
				trimwhitespace(smdesrev_partno_str);
				trimwhitespace(smdesrev_platform_str);
				if(smdesrev_partno_str!=NULL)tc_strdup(smdesrev_partno_str,&smdesrev_partno_strdup);
				if(smdesrev_platform_str!=NULL)tc_strdup(smdesrev_platform_str,&smdesrev_platform_strdup);
				if(smdesrev_item_type!=NULL)tc_strdup(smdesrev_item_type,&smdesrev_item_typedup);
				smdesrev_modaddr_str = subString(smdesrev_partno_strdup, 4, 5);
				trimwhitespace(smdesrev_modaddr_str);
				printf("\n Part Module Address Value: [%s]", smdesrev_modaddr_str);fflush(stdout);
				printf("\n Part No: [%s]\n", smdesrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%s]\n", smdesrev_platform_strdup);fflush(stdout);
				printf("\n Object Type: [%s]\n", smdesrev_item_typedup);fflush(stdout);
				printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
				Module_Address_Status = TC_ModuleAddrStatus(smdesrev_modaddr_str);
				tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
				printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
				printf("\n SubFunction: SubModule Vehicle Link Status Find Start");fflush(stdout);
				Module_VehLink_Status = TC_SubModuleVehicleLinkStatus(smdesrev_modaddr_str,smdesrev_partno_strdup);
				tc_strdup(Module_VehLink_Status,&Module_VehLink_StatusDup);
				printf("\n SubFunction: SubModule Vehicle Link Status Find End");fflush(stdout);
				printf("\n SubFunction: SubModule Product Line Status Find Start");fflush(stdout);
				Module_ProdLine_Status = TC_SubModuleProductLineStatus(smdesrev_modaddr_str,smdesrev_partno_strdup);
				tc_strdup(Module_ProdLine_Status,&Module_ProdLine_StatusDup);
				printf("\n SubFunction: SubModule Product Line Status Find End");fflush(stdout);
				
				printf("\n [Start] Printing of Data: [%d]\n",p);fflush(stdout);
				if((tc_strlen(smdesrev_partno_strdup)>0) && (tc_strlen(smdesrev_partno_strdup)==14) && (tc_strcmp(smdesrev_item_typedup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0) && (tc_strcmp(Module_VehLink_StatusDup,"LINK")==0) && (tc_strcmp(Module_ProdLine_StatusDup,"NOTFOUND")!=0))
				{
					fprintf(fpsmlb_file,"%s^%s^\n",smdesrev_partno_strdup,Module_ProdLine_StatusDup);fflush(fpsmlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",p);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fpsmlb_file);
	printf("\n SubModule Data Details Find End..!!\n");fflush(stdout);
	

	char *vitem_id_str = NULL;
	char *vitem_plat_str = NULL;
	char *vitem_id_strDup = NULL;
	char *vitem_plat_strDup = NULL;
	char *smitem_id_str = NULL;
	char *smitem_plat_str = NULL;
	char *smitem_id_strDup = NULL;
	char *smitem_plat_strDup = NULL;
	FILE *fpVPart_List = NULL;
	FILE *fpSMPart_List = NULL;
	char Buffer4[MAX_LINE_LENGTH];
	char Buffer5[MAX_LINE_LENGTH];
	int i = 0;
	int vhcvcount = 0;
	int vilmcvcount = 0;
	int vscvcount = 0;
	int vpasscount = 0;
	int vcvcount = 0;
	int smhcvcount = 0;
	int smilmcvcount = 0;
	int smscvcount = 0;
	int smpasscount = 0;
	int smcvcount = 0;
	float rhcvcount;
	float rilmcvcount;
	float rscvcount;
	float rpasscount;
	float rcvcount;
	fpVPart_List = fopen(VLbRptFile,"r");
	fpSMPart_List = fopen(SMLbRptFile,"r");
	
	if(fpVPart_List == NULL)
	{
	    printf("\n Unable to Open Input File: [%s]\n", VLbRptFile);fflush(stdout);
		return 0;
	}
	if(fpSMPart_List == NULL)
	{
	    printf("\n Unable to Open Input File: [%s]\n", SMLbRptFile);fflush(stdout);
		return 0;
	}
	if((fpVPart_List != NULL) && (fpSMPart_List != NULL))
	{
		printf(" Both Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer4,MAX_LINE_LENGTH,fpVPart_List)!=NULL)
		{
			vitem_id_str=strtok(Buffer4,"^");
			vitem_plat_str=strtok(NULL,"^");
			
			if(vitem_id_str!=NULL)tc_strdup(vitem_id_str,&vitem_id_strDup);
			if(vitem_plat_str!=NULL)tc_strdup(vitem_plat_str,&vitem_plat_strDup);
			
			if(vitem_id_strDup!=NULL)trimwhitespace(vitem_id_strDup);
			if(vitem_plat_strDup!=NULL)trimwhitespace(vitem_plat_strDup);
			
			printf("\n Part No(vitem_id_strDup): [%s]\n",vitem_id_strDup);
			printf("\n Part Platform(vitem_plat_strDup): [%s]\n",vitem_plat_strDup);
			
			if(tc_strstr(vitem_plat_strDup,"HCV")!=NULL)
			{
				vhcvcount = vhcvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"ILMCV")!=NULL)
			{
				vilmcvcount = vilmcvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"SCV")!=NULL)
			{
				vscvcount = vscvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"BUS")!=NULL)
			{
				vpasscount = vpasscount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		vcvcount = vhcvcount + vilmcvcount + vscvcount + vpasscount;
		char vhcvcountstr[10];
		char vilmcvcountstr[10];
		char vscvcountstr[10];
		char vpasscountstr[10];
		char vcvcountstr[10];
		tostring(vhcvcountstr, vhcvcount);
		tostring(vilmcvcountstr, vilmcvcount);
		tostring(vscvcountstr, vscvcount);
		tostring(vpasscountstr, vpasscount);
		tostring(vcvcountstr, vcvcount);
		
		while(fgets(Buffer5,MAX_LINE_LENGTH,fpSMPart_List)!=NULL)
		{
			smitem_id_str=strtok(Buffer5,"^");
			smitem_plat_str=strtok(NULL,"^");
			
			if(smitem_id_str!=NULL)tc_strdup(smitem_id_str,&smitem_id_strDup);
			if(smitem_plat_str!=NULL)tc_strdup(smitem_plat_str,&smitem_plat_strDup);
			
			if(smitem_id_strDup!=NULL)trimwhitespace(smitem_id_strDup);
			if(smitem_plat_strDup!=NULL)trimwhitespace(smitem_plat_strDup);
			
			printf("\n Part No(smitem_id_strDup): [%s]\n",smitem_id_strDup);
			printf("\n Part Platform(smitem_plat_strDup): [%s]\n",smitem_plat_strDup);
			
			if((tc_strstr(smitem_plat_strDup,"HCV")!=NULL) || (tc_strstr(smitem_plat_strDup,"MHCV")!=NULL))
			{
				smhcvcount = smhcvcount + 1;
			}
			else if((tc_strstr(smitem_plat_strDup,"ILMCV")!=NULL) || (tc_strstr(smitem_plat_strDup,"ILCV")!=NULL))
			{
				smilmcvcount = smilmcvcount + 1;
			}
			else if(tc_strstr(smitem_plat_strDup,"SCV")!=NULL)
			{
				smscvcount = smscvcount + 1;
			}
			else if(tc_strstr(smitem_plat_strDup,"BUS")!=NULL)
			{
				smpasscount = smpasscount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		smcvcount = smhcvcount + smilmcvcount + smscvcount + smpasscount;
		char smhcvcountstr[10];
		char smilmcvcountstr[10];
		char smscvcountstr[10];
		char smpasscountstr[10];
		char smcvcountstr[10];
		tostring(smhcvcountstr, smhcvcount);
		tostring(smilmcvcountstr, smilmcvcount);
		tostring(smscvcountstr, smscvcount);
		tostring(smpasscountstr, smpasscount);
		tostring(smcvcountstr, smcvcount);
		
		
		rhcvcount = (float)vhcvcount/smhcvcount;
		rilmcvcount = (float)vilmcvcount/smilmcvcount;
		rscvcount = (float)vscvcount/smscvcount;
		rpasscount = (float)vpasscount/smpasscount;
		rcvcount = (float)vcvcount/smcvcount;

		char rhcvcountstr[10];
		char rilmcvcountstr[10];
		char rscvcountstr[10];
		char rpasscountstr[10];
		char rcvcountstr[10];
		sprintf(rhcvcountstr, "%.3f", rhcvcount);
		sprintf(rilmcvcountstr, "%.3f", rilmcvcount);
		sprintf(rscvcountstr, "%.3f", rscvcount);
		sprintf(rpasscountstr, "%.3f", rpasscount);
		sprintf(rcvcountstr, "%.3f", rcvcount);
		
		if(tc_strcmp(colc,"2")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col2>\n");
			write2xml(SUBCVRpt4,"<DS4Col2Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col2Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col2>\n");
		}
		else if(tc_strcmp(colc,"3")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col3>\n");
			write2xml(SUBCVRpt4,"<DS4Col3Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col3Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col3>\n");
		}
		else if(tc_strcmp(colc,"4")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col4>\n");
			write2xml(SUBCVRpt4,"<DS4Col4Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col4Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col4>\n");
		}
		else if(tc_strcmp(colc,"5")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col5>\n");
			write2xml(SUBCVRpt4,"<DS4Col5Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col5Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col5>\n");
		}
		else if(tc_strcmp(colc,"6")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col6>\n");
			write2xml(SUBCVRpt4,"<DS4Col6Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col6Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col6>\n");
		}
		else if(tc_strcmp(colc,"7")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col7>\n");
			write2xml(SUBCVRpt4,"<DS4Col7Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col7Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col7>\n");
		}
		else if(tc_strcmp(colc,"8")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col8>\n");
			write2xml(SUBCVRpt4,"<DS4Col8Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col8Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col8>\n");
		}
		else if(tc_strcmp(colc,"9")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col9>\n");
			write2xml(SUBCVRpt4,"<DS4Col9Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col9Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col9>\n");
		}
		else if(tc_strcmp(colc,"10")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col10>\n");
			write2xml(SUBCVRpt4,"<DS4Col10Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col10Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col10>\n");
		}
		else if(tc_strcmp(colc,"11")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col11>\n");
			write2xml(SUBCVRpt4,"<DS4Col11Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col11Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col11>\n");
		}
		else if(tc_strcmp(colc,"12")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col12>\n");
			write2xml(SUBCVRpt4,"<DS4Col12Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col12Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col12>\n");
		}
		else if(tc_strcmp(colc,"13")==0)
	    {
			write2xml(SUBCVRpt4,"<DS4Col13>\n");
			write2xml(SUBCVRpt4,"<DS4Col13Det>"); write2xml(SUBCVRpt4,colhead); write2xml(SUBCVRpt4,"</DS4Col13Det>\n");
			write2xml(SUBCVRpt4,"<VDS4HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt4,vhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt4,vilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt4,vscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<VDS4PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt4,vpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<VDS4CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt4,vcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</VDS4CVData>\n");
			write2xml(SUBCVRpt4,"<SDS4HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt4,smhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt4,smilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt4,smscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<SDS4PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt4,smpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<SDS4CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt4,smcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</SDS4CVData>\n");
			write2xml(SUBCVRpt4,"<RDS4HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt4,rhcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4HCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt4,rilmcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4ILMCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt4,rscvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4SCVData>\n");
			write2xml(SUBCVRpt4,"<RDS4PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt4,rpasscountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4PASSData>\n");
			write2xml(SUBCVRpt4,"<RDS4CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt4,rcvcountstr); else write2xml(SUBCVRpt4,"0"); write2xml(SUBCVRpt4,"</RDS4CVData>\n");
			write2xml(SUBCVRpt4,"</DS4Col13>\n");
		}
		else
		{
			printf("\n !!!! COLUMN DATA NOT MATCHED !!!!\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpVPart_List);
	fclose(fpSMPart_List);
	
	return iFail;
}

int TC_CVDS4(FILE* CVRpt4)
{
	int iFail = ITK_ok;
	
	write2xml(CVRpt4,"<DataSheet4>\n");
	write2xml(CVRpt4,"<DS4Col1>\n");
	write2xml(CVRpt4,"<DS4Col1Det>"); write2xml(CVRpt4,"PLATFORM"); write2xml(CVRpt4,"</DS4Col1Det>\n");
	write2xml(CVRpt4,"<VDS4HCV>"); write2xml(CVRpt4,"HCV"); write2xml(CVRpt4,"</VDS4HCV>\n");
	write2xml(CVRpt4,"<VDS4ILMCV>"); write2xml(CVRpt4,"ILMCV"); write2xml(CVRpt4,"</VDS4ILMCV>\n");
	write2xml(CVRpt4,"<VDS4SCV>"); write2xml(CVRpt4,"SCV"); write2xml(CVRpt4,"</VDS4SCV>\n");
	write2xml(CVRpt4,"<VDS4PASS>"); write2xml(CVRpt4,"CV PASS"); write2xml(CVRpt4,"</VDS4PASS>\n");
	write2xml(CVRpt4,"<VDS4CV>"); write2xml(CVRpt4,"CV"); write2xml(CVRpt4,"</VDS4CV>\n");
	write2xml(CVRpt4,"<SDS4HCV>"); write2xml(CVRpt4,"HCV"); write2xml(CVRpt4,"</SDS4HCV>\n");
	write2xml(CVRpt4,"<SDS4ILMCV>"); write2xml(CVRpt4,"ILMCV"); write2xml(CVRpt4,"</SDS4ILMCV>\n");
	write2xml(CVRpt4,"<SDS4SCV>"); write2xml(CVRpt4,"SCV"); write2xml(CVRpt4,"</SDS4SCV>\n");
	write2xml(CVRpt4,"<SDS4PASS>"); write2xml(CVRpt4,"CV PASS"); write2xml(CVRpt4,"</SDS4PASS>\n");
	write2xml(CVRpt4,"<SDS4CV>"); write2xml(CVRpt4,"CV"); write2xml(CVRpt4,"</SDS4CV>\n");
	write2xml(CVRpt4,"<RDS4HCV>"); write2xml(CVRpt4,"HCV"); write2xml(CVRpt4,"</RDS4HCV>\n");
	write2xml(CVRpt4,"<RDS4ILMCV>"); write2xml(CVRpt4,"ILMCV"); write2xml(CVRpt4,"</RDS4ILMCV>\n");
	write2xml(CVRpt4,"<RDS4SCV>"); write2xml(CVRpt4,"SCV"); write2xml(CVRpt4,"</RDS4SCV>\n");
	write2xml(CVRpt4,"<RDS4PASS>"); write2xml(CVRpt4,"CV PASS"); write2xml(CVRpt4,"</RDS4PASS>\n");
	write2xml(CVRpt4,"<RDS4CV>"); write2xml(CVRpt4,"CV"); write2xml(CVRpt4,"</RDS4CV>\n");
	write2xml(CVRpt4,"</DS4Col1>\n");
	
	printf("\n *********** Start Of Date-Time Calculate ************* \n");fflush(stdout);					
    char *did_str = NULL;
    char *mid_str = NULL;
    char *yid_str = NULL;
    
    char GenDate[100] = "";
	char GenYr[100] = "";
	char FullYr[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d-%m-%Y",&when);
	printf("\nCurrent TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(GenYr,100,"%y",&when);
	printf("\nCurrent TimeStamp(Only Year): [%s]\n", GenYr);fflush(stdout);
	strftime(FullYr,100,"%Y",&when);
	printf("\nCurrent TimeStamp(Full Year): [%s]\n", FullYr);fflush(stdout);
	did_str=strtok(GenDate,"-");
	mid_str=strtok(NULL,"-");
	yid_str=strtok(NULL,"-");
	printf("\nDAY: [%s]", did_str);fflush(stdout);
	printf("\nMONTH[STRING]: [%s]", mid_str);fflush(stdout);
	printf("\nYEAR: [%s]", yid_str);fflush(stdout);
	int val;
	val = atoi(mid_str);
	printf("\nMONTH[INT]: [%d]\n", val);fflush(stdout);
	int yrval;
	yrval = atoi(GenYr);
	printf("\nYEAR[INT]: [%d]\n", yrval);fflush(stdout);
	int fullyrval;
	fullyrval = atoi(FullYr);
	printf("\nFULL YEAR[INT]: [%d]\n", fullyrval);fflush(stdout);
	int preyrval;
	preyrval = fullyrval - 1;
	printf("\nPRE YEAR[INT]: [%d]\n", preyrval);fflush(stdout);
	int i = 0;
	int change = 0;
	char *MonStatus = NULL;
	char *colhead = (char *) malloc(20*sizeof(char));
	char *sdate = (char *) malloc(20*sizeof(char));
	char *edate = (char *) malloc(20*sizeof(char));
	char newyrvalstr[10];
	char *YrStatus = NULL;
	char preyrvalstr[10];
	int colcnt = 2;
	for(i = 0; i <= 11; i++)
	{
	    if(val<1)
		{
		   val = 12;
		   MonStatus = TC_MonthName(val);
		   val = val -1;
		   tc_strcpy(colhead,MonStatus);
		   change = change + 1;
		}
		else
		{
			MonStatus = TC_MonthName(val);
			val = val -1;
		}
		
		if(change == 0)
		{
			tc_strcpy(colhead,MonStatus);
	        tc_strcat(colhead,"-");
	        tc_strcat(colhead,GenYr);
			YrStatus = TC_LeapYrChk(fullyrval);
			if(tc_strcmp(MonStatus,"Jan")==0)
			{
				//tc_strcpy(sdate,"01-01-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Jan-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"yes")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"29-Feb-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"no")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"28-Feb-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Mar")==0)
			{
				//tc_strcpy(sdate,"01-03-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Mar-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Apr")==0)
			{
				//tc_strcpy(sdate,"01-04-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Apr-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"May")==0)
			{
				//tc_strcpy(sdate,"01-05-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-May-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jun")==0)
			{
				//tc_strcpy(sdate,"01-06-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Jun-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jul")==0)
			{
				//tc_strcpy(sdate,"01-07-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Jul-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Aug")==0)
			{
				//tc_strcpy(sdate,"01-08-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Aug-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Sep")==0)
			{
				//tc_strcpy(sdate,"01-09-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Sep-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Oct")==0)
			{
				//tc_strcpy(sdate,"01-10-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Oct-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Nov")==0)
			{
				//tc_strcpy(sdate,"01-11-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Nov-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Dec")==0)
			{
				//tc_strcpy(sdate,"01-12-");
	            //tc_strcat(sdate,FullYr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Dec-");
	            tc_strcat(edate,FullYr);
				tc_strcat(edate," 23:59");
			}
			else
			{
				printf("\n !!..Not Matched..!!");fflush(stdout);
			}
		}
		else
		{
			int newyrval = 0;
			newyrval = yrval - 1;
			tostring(newyrvalstr, newyrval);
			tc_strcpy(colhead,MonStatus);
	        tc_strcat(colhead,"-");
	        tc_strcat(colhead,newyrvalstr);
			YrStatus = TC_LeapYrChk(fullyrval-1);
			tostring(preyrvalstr, preyrval);
			if(tc_strcmp(MonStatus,"Jan")==0)
			{
				//tc_strcpy(sdate,"01-01-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Jan-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"yes")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"29-Feb-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if((tc_strcmp(YrStatus,"no")==0) && (tc_strcmp(MonStatus,"Feb")==0))
			{
				//tc_strcpy(sdate,"01-02-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"28-Feb-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Mar")==0)
			{
				//tc_strcpy(sdate,"01-03-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Mar-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Apr")==0)
			{
				//tc_strcpy(sdate,"01-04-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Apr-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"May")==0)
			{
				//tc_strcpy(sdate,"01-05-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-May-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jun")==0)
			{
				//tc_strcpy(sdate,"01-06-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Jun-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Jul")==0)
			{
				//tc_strcpy(sdate,"01-07-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Jul-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Aug")==0)
			{
				//tc_strcpy(sdate,"01-08-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Aug-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Sep")==0)
			{
				//tc_strcpy(sdate,"01-09-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Sep-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Oct")==0)
			{
				//tc_strcpy(sdate,"01-10-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Oct-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Nov")==0)
			{
				//tc_strcpy(sdate,"01-11-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"30-Nov-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else if(tc_strcmp(MonStatus,"Dec")==0)
			{
				//tc_strcpy(sdate,"01-12-");
	            //tc_strcat(sdate,preyrvalstr);
				tc_strcpy(sdate,"01-Jan-1900");
				tc_strcat(sdate," 00:00");
				
				tc_strcpy(edate,"31-Dec-");
	            tc_strcat(edate,preyrvalstr);
				tc_strcat(edate," 23:59");
			}
			else
			{
				printf("\n !!..Not Matched..!!");fflush(stdout);
			}
		}
		
		printf("\nMonth Name: [%s] | Column Heading: [%s] | Start Date: [%s] | End Date: [%s]", MonStatus,colhead,sdate,edate);fflush(stdout);
		printf("\n Function: Generating Sheet4 Data - Start\n");fflush(stdout);
	    SUBTC_CVDS4(colhead,sdate,edate,CVRpt4,colcnt);
	    printf("\n Function1: Generating Sheet4 Data - End\n");fflush(stdout);
		colcnt = colcnt + 1;
	}

	printf("\n*********** End Of Date-Time Calculate ************* \n");fflush(stdout);
	
	write2xml(CVRpt4,"</DataSheet4>\n");
	return iFail;
}

int SUBTC_CVDS3(char* startdate, char* enddate, FILE* SUBCVRpt3, char* colnum)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 5;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tdes_rev = NULLTAG;
	char *desrev_partno_str = NULL;
	char *desrev_partno_strdup = NULL;
	char *desrev_platform_str = NULL;
	char *desrev_platform_strdup = NULL;
	char *VLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fpvlb_file = NULL;
	//char *SData = (char *) malloc(100*sizeof(char));
	char *SKData = (char *) malloc(100*sizeof(char));
	char *fval = NULL;
	char *SData = NULL;
	char *tval = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(VLbRptFile,"/tmp/");
	tc_strcat(VLbRptFile,"VehDataDetails");
	tc_strcat(VLbRptFile,"_");
	tc_strcat(VLbRptFile,GenDate);
	tc_strcat(VLbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", VLbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	fpvlb_file = fopen(VLbRptFile, "w");
	
	if(tc_strcmp(colnum,"2")==0)
	{
		/* tc_strcpy(SData,"COLUMN1");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN1");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"3")==0)
	{
		/* tc_strcpy(SData,"COLUMN2");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN2");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"4")==0)
	{
		/* tc_strcpy(SData,"COLUMN3");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN3");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"5")==0)
	{
		/* tc_strcpy(SData,"COLUMN4");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN4");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"6")==0)
	{
		/* tc_strcpy(SData,"COLUMN5");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN5");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"7")==0)
	{
		/* tc_strcpy(SData,"COLUMN6");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN6");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"8")==0)
	{
		/* tc_strcpy(SData,"COLUMN7");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN7");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else if(tc_strcmp(colnum,"9")==0)
	{
		/* tc_strcpy(SData,"COLUMN8");
		tc_strcat(SData,"(");
		tc_strcat(SData,startdate);
		tc_strcat(SData," to ");
		tc_strcat(SData,enddate);
		tc_strcat(SData,")"); */
		tc_strcpy(SKData,"COLUMN8");
		tc_strcat(SKData," ");
		tc_strcat(SKData,enddate);

		fval=strtok(SKData," ");
		SData=strtok(NULL," ");
		tval=strtok(NULL," ");
	}
	else
	{
		printf("\n !!!! COLUMN VALUE NOT MATCHED !!!!\n");fflush(stdout);
	}
	printf("\n SData Value: [%s]\n",SData);fflush(stdout);
	
    printf("\n Vehicle Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cValues[5]  = {"*",startdate,enddate,"V","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","V","Design Revision"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tdes_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tdes_rev,"item_id",&desrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tdes_rev,"t5_Platform",&desrev_platform_str));
				trimwhitespace(desrev_partno_str);
				trimwhitespace(desrev_platform_str);
				if(desrev_partno_str!=NULL)tc_strdup(desrev_partno_str,&desrev_partno_strdup);
				if(desrev_platform_str!=NULL)tc_strdup(desrev_platform_str,&desrev_platform_strdup);
				printf("\n Part No: [%d]\n", desrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%d]\n", desrev_platform_strdup);fflush(stdout);
				printf("\n [Start] Printing of Data: [%d]\n",k);fflush(stdout);
				if(tc_strlen(desrev_partno_strdup)>0)
				{
					fprintf(fpvlb_file,"%s^%s^\n",desrev_partno_strdup,desrev_platform_strdup);fflush(fpvlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",k);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	printf("\n Vehicle Data Details Find End..!!\n");fflush(stdout);
	tag_t tvccrItemobj = NULLTAG;
	int n_vccrentries = 5;
	int n_vccritemobj_found = 0;
	tag_t* tvccritemobj_results = NULLTAG;
	int g = 0;
	tag_t tvccrdes_rev = NULLTAG;
	char *vccrdesrev_partno_str = NULL;
	char *vccrdesrev_partno_strdup = NULL;
	char *vccrdesrev_platform_str = NULL;
	char *vccrdesrev_platform_strdup = NULL;
	printf("\n Vehicle Combination CR Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tvccrItemobj));
	if(tvccrItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cvccrEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cvccrValues[5]  = {"*",startdate,enddate,"VCCR","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","VCCR","Design Revision"};
		ITK_CALL(QRY_execute(tvccrItemobj, n_vccrentries, cvccrEntries, cvccrValues, &n_vccritemobj_found, &tvccritemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_vccritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_vccritemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(g = 0; g < n_vccritemobj_found; g++)
			{
				tvccrdes_rev = tvccritemobj_results[g];
				ITK_CALL(AOM_ask_value_string(tvccrdes_rev,"item_id",&vccrdesrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tvccrdes_rev,"t5_Platform",&vccrdesrev_platform_str));
				trimwhitespace(vccrdesrev_partno_str);
				trimwhitespace(vccrdesrev_platform_str);
				if(vccrdesrev_partno_str!=NULL)tc_strdup(vccrdesrev_partno_str,&vccrdesrev_partno_strdup);
				if(vccrdesrev_platform_str!=NULL)tc_strdup(vccrdesrev_platform_str,&vccrdesrev_platform_strdup);
				printf("\n Part No: [%d]\n", vccrdesrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%d]\n", vccrdesrev_platform_strdup);fflush(stdout);
				printf("\n [Start] Printing of Data: [%d]\n",g);fflush(stdout);
				if(tc_strlen(vccrdesrev_partno_strdup)>0)
				{
					fprintf(fpvlb_file,"%s^%s^\n",vccrdesrev_partno_strdup,vccrdesrev_platform_strdup);fflush(fpvlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",g);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	printf("\n Vehicle Combination CR Data Details Find End..!!\n");fflush(stdout);
	fclose(fpvlb_file);
	
	printf("\n SubModule Data Details Find Start..!!\n");fflush(stdout);
	tag_t tSMItemobj = NULLTAG;
	int n_sm_entries = 5;
	int n_sm_itemobj_found = 0;
	tag_t* tsmitemobj_results = NULLTAG;
	int p = 0;
	tag_t tsmdes_rev = NULLTAG;
	char *smdesrev_partno_str = NULL;
	char *smdesrev_partno_strdup = NULL;
	char *smdesrev_platform_str = NULL;
	char *smdesrev_platform_strdup = NULL;
	char *smdesrev_item_type = NULL;
	char *smdesrev_item_typedup = NULL;
	char *smdesrev_modaddr_str = NULL;
	char *Module_Address_Status = NULL;
	char *Module_Address_StatusDup = NULL;
	char *Module_VehLink_Status = NULL;
	char *Module_VehLink_StatusDup = NULL;
	char *Module_ProdLine_Status = NULL;
	char *Module_ProdLine_StatusDup = NULL;
	char *SMLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fpsmlb_file = NULL;
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(SMLbRptFile,"/tmp/");
	tc_strcat(SMLbRptFile,"SubmoduleDataDetails");
	tc_strcat(SMLbRptFile,"_");
	tc_strcat(SMLbRptFile,GenDate);
	tc_strcat(SMLbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", SMLbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	fpsmlb_file = fopen(SMLbRptFile, "w");
	printf("\n SubModule Data Details Find Start..!!\n");fflush(stdout);
	ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tSMItemobj));
	if(tSMItemobj != NULLTAG)
	{
		printf("Query[Latest Released Design Revision for ERC] Found Successfully..!!\n");fflush(stdout);
		char *cSMEntries[5]  = {"Item ID", "Released After", "Released Before", "Part Type", "Type"};
		char *cSMValues[5]  = {"*",startdate,enddate,"M","Design Revision"};
		//char *cValues[5]  = {"*","11-Sep-2024 00:00","18-Sep-2024 23:59","M","Design Revision"};
		ITK_CALL(QRY_execute(tSMItemobj, n_sm_entries, cSMEntries, cSMValues, &n_sm_itemobj_found, &tsmitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Latest Released Design Revision for ERC] Found: [%d]\n",n_sm_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_sm_itemobj_found > 0)
		{
			printf("\nLatest Released Design Revision for ERC Found..!!\n");fflush(stdout);
			for(p = 0; p < n_sm_itemobj_found; p++)
			{
				tsmdes_rev = tsmitemobj_results[p];
				ITK_CALL(AOM_ask_value_string(tsmdes_rev,"item_id",&smdesrev_partno_str));
				ITK_CALL(AOM_ask_value_string(tsmdes_rev,"t5_Platform",&smdesrev_platform_str));
				ITK_CALL(AOM_UIF_ask_value(tsmdes_rev,"object_type",&smdesrev_item_type));
				trimwhitespace(smdesrev_partno_str);
				trimwhitespace(smdesrev_platform_str);
				if(smdesrev_partno_str!=NULL)tc_strdup(smdesrev_partno_str,&smdesrev_partno_strdup);
				if(smdesrev_platform_str!=NULL)tc_strdup(smdesrev_platform_str,&smdesrev_platform_strdup);
				if(smdesrev_item_type!=NULL)tc_strdup(smdesrev_item_type,&smdesrev_item_typedup);
				smdesrev_modaddr_str = subString(smdesrev_partno_strdup, 4, 5);
				trimwhitespace(smdesrev_modaddr_str);
				printf("\n Part Module Address Value: [%s]", smdesrev_modaddr_str);fflush(stdout);
				printf("\n Part No: [%s]\n", smdesrev_partno_strdup);fflush(stdout);
				printf("\n Part Platform: [%s]\n", smdesrev_platform_strdup);fflush(stdout);
				printf("\n Object Type: [%s]\n", smdesrev_item_typedup);fflush(stdout);
				printf("\n SubFunction: Module Address Valid/Invalid Status Find Start");fflush(stdout);
				Module_Address_Status = TC_ModuleAddrStatus(smdesrev_modaddr_str);
				tc_strdup(Module_Address_Status,&Module_Address_StatusDup);
				printf("\n SubFunction: Module Address Valid/Invalid Status Find End");fflush(stdout);
				printf("\n SubFunction: SubModule Vehicle Link Status Find Start");fflush(stdout);
				Module_VehLink_Status = TC_SubModuleVehicleLinkStatus(smdesrev_modaddr_str,smdesrev_partno_strdup);
				tc_strdup(Module_VehLink_Status,&Module_VehLink_StatusDup);
				printf("\n SubFunction: SubModule Vehicle Link Status Find End");fflush(stdout);
				printf("\n SubFunction: SubModule Product Line Status Find Start");fflush(stdout);
				Module_ProdLine_Status = TC_SubModuleProductLineStatus(smdesrev_modaddr_str,smdesrev_partno_strdup);
				tc_strdup(Module_ProdLine_Status,&Module_ProdLine_StatusDup);
				printf("\n SubFunction: SubModule Product Line Status Find End");fflush(stdout);
				
				printf("\n [Start] Printing of Data: [%d]\n",p);fflush(stdout);
				if((tc_strlen(smdesrev_partno_strdup)>0) && (tc_strlen(smdesrev_partno_strdup)==14) && (tc_strcmp(smdesrev_item_typedup,"Design Revision")==0) && (tc_strcmp(Module_Address_StatusDup,"VALID")==0) && (tc_strcmp(Module_VehLink_StatusDup,"LINK")==0) && (tc_strcmp(Module_ProdLine_StatusDup,"NOTFOUND")!=0))
				{
					fprintf(fpsmlb_file,"%s^%s^\n",smdesrev_partno_strdup,Module_ProdLine_StatusDup);fflush(fpsmlb_file);
				}  
				printf("\n [End] Printing of Data: [%d]\n",p);fflush(stdout);
			}				
		}
		else
		{
		   printf("\n Object [Latest Released Design Revision for ERC] Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[Latest Released Design Revision for ERC] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fpsmlb_file);
	printf("\n SubModule Data Details Find End..!!\n");fflush(stdout);
	

	char *vitem_id_str = NULL;
	char *vitem_plat_str = NULL;
	char *vitem_id_strDup = NULL;
	char *vitem_plat_strDup = NULL;
	char *smitem_id_str = NULL;
	char *smitem_plat_str = NULL;
	char *smitem_id_strDup = NULL;
	char *smitem_plat_strDup = NULL;
	FILE *fpVPart_List = NULL;
	FILE *fpSMPart_List = NULL;
	char Buffer2[MAX_LINE_LENGTH];
	char Buffer3[MAX_LINE_LENGTH];
	int i = 0;
	int vhcvcount = 0;
	int vilmcvcount = 0;
	int vscvcount = 0;
	int vpasscount = 0;
	int vcvcount = 0;
	int smhcvcount = 0;
	int smilmcvcount = 0;
	int smscvcount = 0;
	int smpasscount = 0;
	int smcvcount = 0;
	float rhcvcount;
	float rilmcvcount;
	float rscvcount;
	float rpasscount;
	float rcvcount;
	fpVPart_List = fopen(VLbRptFile,"r");
	fpSMPart_List = fopen(SMLbRptFile,"r");
	
	if(fpVPart_List == NULL)
	{
	    printf("\n Unable to Open Input File: [%s]\n", VLbRptFile);fflush(stdout);
		return 0;
	}
	if(fpSMPart_List == NULL)
	{
	    printf("\n Unable to Open Input File: [%s]\n", SMLbRptFile);fflush(stdout);
		return 0;
	}
	if((fpVPart_List != NULL) && (fpSMPart_List != NULL))
	{
		printf(" Both Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer2,MAX_LINE_LENGTH,fpVPart_List)!=NULL)
		{
			vitem_id_str=strtok(Buffer2,"^");
			vitem_plat_str=strtok(NULL,"^");
			
			if(vitem_id_str!=NULL)tc_strdup(vitem_id_str,&vitem_id_strDup);
			if(vitem_plat_str!=NULL)tc_strdup(vitem_plat_str,&vitem_plat_strDup);
			
			if(vitem_id_strDup!=NULL)trimwhitespace(vitem_id_strDup);
			if(vitem_plat_strDup!=NULL)trimwhitespace(vitem_plat_strDup);
			
			printf("\n Part No(vitem_id_strDup): [%s]\n",vitem_id_strDup);
			printf("\n Part Platform(vitem_plat_strDup): [%s]\n",vitem_plat_strDup);
			
			if(tc_strstr(vitem_plat_strDup,"HCV")!=NULL)
			{
				vhcvcount = vhcvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"ILMCV")!=NULL)
			{
				vilmcvcount = vilmcvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"SCV")!=NULL)
			{
				vscvcount = vscvcount + 1;
			}
			else if(tc_strstr(vitem_plat_strDup,"BUS")!=NULL)
			{
				vpasscount = vpasscount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		vcvcount = vhcvcount + vilmcvcount + vscvcount + vpasscount;
		char vhcvcountstr[10];
		char vilmcvcountstr[10];
		char vscvcountstr[10];
		char vpasscountstr[10];
		char vcvcountstr[10];
		tostring(vhcvcountstr, vhcvcount);
		tostring(vilmcvcountstr, vilmcvcount);
		tostring(vscvcountstr, vscvcount);
		tostring(vpasscountstr, vpasscount);
		tostring(vcvcountstr, vcvcount);
		
		while(fgets(Buffer3,MAX_LINE_LENGTH,fpSMPart_List)!=NULL)
		{
			smitem_id_str=strtok(Buffer3,"^");
			smitem_plat_str=strtok(NULL,"^");
			
			if(smitem_id_str!=NULL)tc_strdup(smitem_id_str,&smitem_id_strDup);
			if(smitem_plat_str!=NULL)tc_strdup(smitem_plat_str,&smitem_plat_strDup);
			
			if(smitem_id_strDup!=NULL)trimwhitespace(smitem_id_strDup);
			if(smitem_plat_strDup!=NULL)trimwhitespace(smitem_plat_strDup);
			
			printf("\n Part No(smitem_id_strDup): [%s]\n",smitem_id_strDup);
			printf("\n Part Platform(smitem_plat_strDup): [%s]\n",smitem_plat_strDup);
			
			if((tc_strstr(smitem_plat_strDup,"HCV")!=NULL) || (tc_strstr(smitem_plat_strDup,"MHCV")!=NULL))
			{
				smhcvcount = smhcvcount + 1;
			}
			else if((tc_strstr(smitem_plat_strDup,"ILMCV")!=NULL) || (tc_strstr(smitem_plat_strDup,"ILCV")!=NULL))
			{
				smilmcvcount = smilmcvcount + 1;
			}
			else if(tc_strstr(smitem_plat_strDup,"SCV")!=NULL)
			{
				smscvcount = smscvcount + 1;
			}
			else if(tc_strstr(smitem_plat_strDup,"BUS")!=NULL)
			{
				smpasscount = smpasscount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		smcvcount = smhcvcount + smilmcvcount + smscvcount + smpasscount;
		char smhcvcountstr[10];
		char smilmcvcountstr[10];
		char smscvcountstr[10];
		char smpasscountstr[10];
		char smcvcountstr[10];
		tostring(smhcvcountstr, smhcvcount);
		tostring(smilmcvcountstr, smilmcvcount);
		tostring(smscvcountstr, smscvcount);
		tostring(smpasscountstr, smpasscount);
		tostring(smcvcountstr, smcvcount);
		
		
		rhcvcount = (float)vhcvcount/smhcvcount;
		rilmcvcount = (float)vilmcvcount/smilmcvcount;
		rscvcount = (float)vscvcount/smscvcount;
		rpasscount = (float)vpasscount/smpasscount;
		rcvcount = (float)vcvcount/smcvcount;

		char rhcvcountstr[10];
		char rilmcvcountstr[10];
		char rscvcountstr[10];
		char rpasscountstr[10];
		char rcvcountstr[10];
		sprintf(rhcvcountstr, "%.3f", rhcvcount);
		sprintf(rilmcvcountstr, "%.3f", rilmcvcount);
		sprintf(rscvcountstr, "%.3f", rscvcount);
		sprintf(rpasscountstr, "%.3f", rpasscount);
		sprintf(rcvcountstr, "%.3f", rcvcount);
		
		if(tc_strcmp(colnum,"2")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col2>\n");
			write2xml(SUBCVRpt3,"<DS3Col2Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col2Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col2>\n");
		}
		else if(tc_strcmp(colnum,"3")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col3>\n");
			write2xml(SUBCVRpt3,"<DS3Col3Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col3Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col3>\n");
		}
		else if(tc_strcmp(colnum,"4")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col4>\n");
			write2xml(SUBCVRpt3,"<DS3Col4Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col4Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col4>\n");
		}
		else if(tc_strcmp(colnum,"5")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col5>\n");
			write2xml(SUBCVRpt3,"<DS3Col5Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col5Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col5>\n");
		}
		else if(tc_strcmp(colnum,"6")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col6>\n");
			write2xml(SUBCVRpt3,"<DS3Col6Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col6Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col6>\n");
		}
		else if(tc_strcmp(colnum,"7")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col7>\n");
			write2xml(SUBCVRpt3,"<DS3Col7Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col7Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col7>\n");
		}
		else if(tc_strcmp(colnum,"8")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col8>\n");
			write2xml(SUBCVRpt3,"<DS3Col8Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col8Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col8>\n");
		}
		else if(tc_strcmp(colnum,"9")==0)
	    {
			write2xml(SUBCVRpt3,"<DS3Col9>\n");
			write2xml(SUBCVRpt3,"<DS3Col9Det>"); write2xml(SUBCVRpt3,SData); write2xml(SUBCVRpt3,"</DS3Col9Det>\n");
			write2xml(SUBCVRpt3,"<VDS3HCVData>"); if(tc_strlen(vhcvcountstr)>0) write2xml(SUBCVRpt3,vhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3ILMCVData>"); if(tc_strlen(vilmcvcountstr)>0) write2xml(SUBCVRpt3,vilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3SCVData>"); if(tc_strlen(vscvcountstr)>0) write2xml(SUBCVRpt3,vscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<VDS3PASSData>"); if(tc_strlen(vpasscountstr)>0) write2xml(SUBCVRpt3,vpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<VDS3CVData>"); if(tc_strlen(vcvcountstr)>0) write2xml(SUBCVRpt3,vcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</VDS3CVData>\n");
			write2xml(SUBCVRpt3,"<SDS3HCVData>"); if(tc_strlen(smhcvcountstr)>0) write2xml(SUBCVRpt3,smhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3ILMCVData>"); if(tc_strlen(smilmcvcountstr)>0) write2xml(SUBCVRpt3,smilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3SCVData>"); if(tc_strlen(smscvcountstr)>0) write2xml(SUBCVRpt3,smscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<SDS3PASSData>"); if(tc_strlen(smpasscountstr)>0) write2xml(SUBCVRpt3,smpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<SDS3CVData>"); if(tc_strlen(smcvcountstr)>0) write2xml(SUBCVRpt3,smcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</SDS3CVData>\n");
			write2xml(SUBCVRpt3,"<RDS3HCVData>"); if(tc_strlen(rhcvcountstr)>0) write2xml(SUBCVRpt3,rhcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3HCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3ILMCVData>"); if(tc_strlen(rilmcvcountstr)>0) write2xml(SUBCVRpt3,rilmcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3ILMCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3SCVData>"); if(tc_strlen(rscvcountstr)>0) write2xml(SUBCVRpt3,rscvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3SCVData>\n");
			write2xml(SUBCVRpt3,"<RDS3PASSData>"); if(tc_strlen(rpasscountstr)>0) write2xml(SUBCVRpt3,rpasscountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3PASSData>\n");
			write2xml(SUBCVRpt3,"<RDS3CVData>"); if(tc_strlen(rcvcountstr)>0) write2xml(SUBCVRpt3,rcvcountstr); else write2xml(SUBCVRpt3,"0"); write2xml(SUBCVRpt3,"</RDS3CVData>\n");
			write2xml(SUBCVRpt3,"</DS3Col9>\n");
		}
		else
		{
			printf("\n !!!! COLUMN DATA NOT MATCHED !!!!\n");fflush(stdout);
		}
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpVPart_List);
	fclose(fpSMPart_List);
	
	return iFail;
}

int TC_CVDS3(FILE* CVRpt3)
{
	int iFail = ITK_ok;
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" \nCurrent TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    W4 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char CurDate[100] = "";
	char* CurDateDup = NULL;
	char *CurDateFinalDup = (char *) malloc(50*sizeof(char));
	strftime(CurDate,100,"%d-%b-%Y",&when);
	trimwhitespace(CurDate);
	if(CurDate!=NULL)tc_strdup(CurDate,&CurDateDup);
	tc_strcpy(CurDateFinalDup,CurDateDup);
	tc_strcat(CurDateFinalDup," 23:59");
	printf(" W4-->To_Date(CurDateFinalDup): [%s]\n",CurDateFinalDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    W4 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate[100] = "";
	char* BfrDateDup = NULL;
	char *W4FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo4;
	time_t t4;
	time_t t4new;
	t4new = time(&now);
	t4 = shiftDate(t4new,-7); 
	nextinfo4 = localtime(&t4);
	strftime(BfrDate,100,"%d-%b-%Y", nextinfo4);
	trimwhitespace(BfrDate);
	if(BfrDate!=NULL)tc_strdup(BfrDate,&BfrDateDup);
	//tc_strcpy(W4FromDateDup,BfrDateDup);
	//tc_strcat(W4FromDateDup," 00:00");
	tc_strcpy(W4FromDateDup,"01-Jan-1900");
	tc_strcat(W4FromDateDup," 00:00");
	printf(" W4-->From_Date(W4FromDateDup): [%s]\n",W4FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    W3 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *W3ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(W3ToDateDup,BfrDateDup);
	tc_strcat(W3ToDateDup," 23:59");
	printf(" W3-->To_Date(W3ToDateDup): [%s]\n",W3ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    W3 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate1[100] = "";
	char* BfrDateDup1 = NULL;
	char *W3FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo3;
	time_t t3;
	time_t t3new;
	t3new = time(&now);
	t3 = shiftDate(t3new,-14); 
	nextinfo3 = localtime(&t3);
	strftime(BfrDate1,100,"%d-%b-%Y", nextinfo3);
	trimwhitespace(BfrDate1);
	if(BfrDate1!=NULL)tc_strdup(BfrDate1,&BfrDateDup1);
	//tc_strcpy(W3FromDateDup,BfrDateDup1);
	//tc_strcat(W3FromDateDup," 00:00");
	tc_strcpy(W3FromDateDup,"01-Jan-1900");
	tc_strcat(W3FromDateDup," 00:00");
	printf(" W3-->From_Date(W3FromDateDup): [%s]\n",W3FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    W2 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *W2ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(W2ToDateDup,BfrDateDup1);
	tc_strcat(W2ToDateDup," 23:59");
	printf(" W2-->To_Date(W2ToDateDup): [%s]\n",W2ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    W2 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate2[100] = "";
	char* BfrDateDup2 = NULL;
	char *W2FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo2;
	time_t t2;
	time_t t2new;
	t2new = time(&now);
	t2 = shiftDate(t2new,-21); 
	nextinfo2 = localtime(&t2);
	strftime(BfrDate2,100,"%d-%b-%Y", nextinfo2);
	trimwhitespace(BfrDate2);
	if(BfrDate2!=NULL)tc_strdup(BfrDate2,&BfrDateDup2);
	//tc_strcpy(W2FromDateDup,BfrDateDup2);
	//tc_strcat(W2FromDateDup," 00:00");
	tc_strcpy(W2FromDateDup,"01-Jan-1900");
	tc_strcat(W2FromDateDup," 00:00");
	printf(" W2-->From_Date(W2FromDateDup): [%s]\n",W2FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    W1 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *W1ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(W1ToDateDup,BfrDateDup2);
	tc_strcat(W1ToDateDup," 23:59");
	printf(" W1-->To_Date(W1ToDateDup): [%s]\n",W1ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    W1 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate3[100] = "";
	char* BfrDateDup3 = NULL;
	char *W1FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo1;
	time_t t1;
	time_t t1new;
	t1new = time(&now);
	t1 = shiftDate(t1new,-28); 
	nextinfo1 = localtime(&t1);
	strftime(BfrDate3,100,"%d-%b-%Y", nextinfo1);
	trimwhitespace(BfrDate3);
	if(BfrDate3!=NULL)tc_strdup(BfrDate3,&BfrDateDup3);
	//tc_strcpy(W1FromDateDup,BfrDateDup3);
	//tc_strcat(W1FromDateDup," 00:00");
	tc_strcpy(W1FromDateDup,"01-Jan-1900");
	tc_strcat(W1FromDateDup," 00:00");
	printf(" W1-->From_Date(W1FromDateDup): [%s]\n",W1FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    PW4 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *PW4ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(PW4ToDateDup,BfrDateDup3);
	tc_strcat(PW4ToDateDup," 23:59");
	printf(" PW4-->To_Date(PW4ToDateDup): [%s]\n",PW4ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    PW4 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char PBfrDate[100] = "";
	char* PBfrDateDup = NULL;
	char *PW4FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *pnextinfo4;
	time_t pt4;
	time_t pt4new;
	pt4new = time(&now);
	pt4 = shiftDate(pt4new,-35); 
	pnextinfo4 = localtime(&pt4);
	strftime(PBfrDate,100,"%d-%b-%Y", pnextinfo4);
	trimwhitespace(PBfrDate);
	if(PBfrDate!=NULL)tc_strdup(PBfrDate,&PBfrDateDup);
	//tc_strcpy(PW4FromDateDup,PBfrDateDup);
	//tc_strcat(PW4FromDateDup," 00:00");
	tc_strcpy(PW4FromDateDup,"01-Jan-1900");
	tc_strcat(PW4FromDateDup," 00:00");
	printf(" PW4-->From_Date(PW4FromDateDup): [%s]\n",PW4FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    PW3 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *PW3ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(PW3ToDateDup,PBfrDateDup);
	tc_strcat(PW3ToDateDup," 23:59");
	printf(" PW3-->To_Date(PW3ToDateDup): [%s]\n",PW3ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    PW3 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char PBfrDate1[100] = "";
	char* PBfrDateDup1 = NULL;
	char *PW3FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *pnextinfo3;
	time_t pt3;
	time_t pt3new;
	pt3new = time(&now);
	pt3 = shiftDate(pt3new,-42); 
	pnextinfo3 = localtime(&pt3);
	strftime(PBfrDate1,100,"%d-%b-%Y", pnextinfo3);
	trimwhitespace(PBfrDate1);
	if(PBfrDate1!=NULL)tc_strdup(PBfrDate1,&PBfrDateDup1);
	//tc_strcpy(PW3FromDateDup,PBfrDateDup1);
	//tc_strcat(PW3FromDateDup," 00:00");
	tc_strcpy(PW3FromDateDup,"01-Jan-1900");
	tc_strcat(PW3FromDateDup," 00:00");
	printf(" PW3-->From_Date(PW3FromDateDup): [%s]\n",PW3FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    PW2 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *PW2ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(PW2ToDateDup,PBfrDateDup1);
	tc_strcat(PW2ToDateDup," 23:59");
	printf(" PW2-->To_Date(PW2ToDateDup): [%s]\n",PW2ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    PW2 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char PBfrDate2[100] = "";
	char* PBfrDateDup2 = NULL;
	char *PW2FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *pnextinfo2;
	time_t pt2;
	time_t pt2new;
	pt2new = time(&now);
	pt2 = shiftDate(pt2new,-49); 
	pnextinfo2 = localtime(&pt2);
	strftime(PBfrDate2,100,"%d-%b-%Y", pnextinfo2);
	trimwhitespace(PBfrDate2);
	if(PBfrDate2!=NULL)tc_strdup(PBfrDate2,&PBfrDateDup2);
	//tc_strcpy(PW2FromDateDup,PBfrDateDup2);
	//tc_strcat(PW2FromDateDup," 00:00");
	tc_strcpy(PW2FromDateDup,"01-Jan-1900");
	tc_strcat(PW2FromDateDup," 00:00");
	printf(" PW2-->From_Date(PW2FromDateDup): [%s]\n",PW2FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    PW1 ---> T O   D A T E  //////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
	char *PW1ToDateDup = (char *) malloc(50*sizeof(char));
	tc_strcpy(PW1ToDateDup,PBfrDateDup2);
	tc_strcat(PW1ToDateDup," 23:59");
	printf(" PW1-->To_Date(PW1ToDateDup): [%s]\n",PW1ToDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////// P R I N T     F O R M A T T E D    PW1 ---> F R O M   D A T E  ////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char PBfrDate3[100] = "";
	char* PBfrDateDup3 = NULL;
	char *PW1FromDateDup = (char *) malloc(50*sizeof(char));
	struct tm *pnextinfo1;
	time_t pt1;
	time_t pt1new;
	pt1new = time(&now);
	pt1 = shiftDate(pt1new,-56); 
	pnextinfo1 = localtime(&pt1);
	strftime(PBfrDate3,100,"%d-%b-%Y", pnextinfo1);
	trimwhitespace(PBfrDate3);
	if(PBfrDate3!=NULL)tc_strdup(PBfrDate3,&PBfrDateDup3);
	//tc_strcpy(PW1FromDateDup,PBfrDateDup3);
	//tc_strcat(PW1FromDateDup," 00:00");
	tc_strcpy(PW1FromDateDup,"01-Jan-1900");
	tc_strcat(PW1FromDateDup," 00:00");
	printf(" PW1-->From_Date(PW1FromDateDup): [%s]\n",PW1FromDateDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	write2xml(CVRpt3,"<DataSheet3>\n");
	write2xml(CVRpt3,"<DS3Col1>\n");
	write2xml(CVRpt3,"<DS3Col1Det>"); write2xml(CVRpt3,"PLATFORM"); write2xml(CVRpt3,"</DS3Col1Det>\n");
	write2xml(CVRpt3,"<VDS3HCV>"); write2xml(CVRpt3,"HCV"); write2xml(CVRpt3,"</VDS3HCV>\n");
	write2xml(CVRpt3,"<VDS3ILMCV>"); write2xml(CVRpt3,"ILMCV"); write2xml(CVRpt3,"</VDS3ILMCV>\n");
	write2xml(CVRpt3,"<VDS3SCV>"); write2xml(CVRpt3,"SCV"); write2xml(CVRpt3,"</VDS3SCV>\n");
	write2xml(CVRpt3,"<VDS3PASS>"); write2xml(CVRpt3,"CV PASS"); write2xml(CVRpt3,"</VDS3PASS>\n");
	write2xml(CVRpt3,"<VDS3CV>"); write2xml(CVRpt3,"CV"); write2xml(CVRpt3,"</VDS3CV>\n");
	write2xml(CVRpt3,"<SDS3HCV>"); write2xml(CVRpt3,"HCV"); write2xml(CVRpt3,"</SDS3HCV>\n");
	write2xml(CVRpt3,"<SDS3ILMCV>"); write2xml(CVRpt3,"ILMCV"); write2xml(CVRpt3,"</SDS3ILMCV>\n");
	write2xml(CVRpt3,"<SDS3SCV>"); write2xml(CVRpt3,"SCV"); write2xml(CVRpt3,"</SDS3SCV>\n");
	write2xml(CVRpt3,"<SDS3PASS>"); write2xml(CVRpt3,"CV PASS"); write2xml(CVRpt3,"</SDS3PASS>\n");
	write2xml(CVRpt3,"<SDS3CV>"); write2xml(CVRpt3,"CV"); write2xml(CVRpt3,"</SDS3CV>\n");
	write2xml(CVRpt3,"<RDS3HCV>"); write2xml(CVRpt3,"HCV"); write2xml(CVRpt3,"</RDS3HCV>\n");
	write2xml(CVRpt3,"<RDS3ILMCV>"); write2xml(CVRpt3,"ILMCV"); write2xml(CVRpt3,"</RDS3ILMCV>\n");
	write2xml(CVRpt3,"<RDS3SCV>"); write2xml(CVRpt3,"SCV"); write2xml(CVRpt3,"</RDS3SCV>\n");
	write2xml(CVRpt3,"<RDS3PASS>"); write2xml(CVRpt3,"CV PASS"); write2xml(CVRpt3,"</RDS3PASS>\n");
	write2xml(CVRpt3,"<RDS3CV>"); write2xml(CVRpt3,"CV"); write2xml(CVRpt3,"</RDS3CV>\n");
	write2xml(CVRpt3,"</DS3Col1>\n");
	
	printf("\n Function1: Generating W4 Data Print Start - Column2\n");fflush(stdout);
	SUBTC_CVDS3(W4FromDateDup,CurDateFinalDup,CVRpt3,"2");
	printf("\n Function1: Generating W4 Data Print End - Column2\n");fflush(stdout);
	printf("\n Function2: Generating W3 Data Print Start - Column3\n");fflush(stdout);
	SUBTC_CVDS3(W3FromDateDup,W3ToDateDup,CVRpt3,"3");
	printf("\n Function2: Generating W3 Data Print End - Column3\n");fflush(stdout);
	printf("\n Function3: Generating W2 Data Print Start - Column4\n");fflush(stdout);
	SUBTC_CVDS3(W2FromDateDup,W2ToDateDup,CVRpt3,"4");
	printf("\n Function3: Generating W2 Data Print End - Column4\n");fflush(stdout);
	printf("\n Function4: Generating W1 Data Print Start - Column5\n");fflush(stdout);
	SUBTC_CVDS3(W1FromDateDup,W1ToDateDup,CVRpt3,"5");
	printf("\n Function4: Generating W1 Data Print End - Column5\n");fflush(stdout);
	printf("\n Function5: Generating PW4 Data Print Start - Column6\n");fflush(stdout);
	SUBTC_CVDS3(PW4FromDateDup,PW4ToDateDup,CVRpt3,"6");
	printf("\n Function5: Generating PW4 Data Print End - Column6\n");fflush(stdout);
	printf("\n Function6: Generating PW3 Data Print Start - Column7\n");fflush(stdout);
	SUBTC_CVDS3(PW3FromDateDup,PW3ToDateDup,CVRpt3,"7");
	printf("\n Function6: Generating PW3 Data Print End - Column7\n");fflush(stdout);
	printf("\n Function7: Generating PW2 Data Print Start - Column8\n");fflush(stdout);
	SUBTC_CVDS3(PW2FromDateDup,PW2ToDateDup,CVRpt3,"8");
	printf("\n Function7: Generating PW2 Data Print End - Column8\n");fflush(stdout);
	printf("\n Function8: Generating PW1 Data Print Start - Column9\n");fflush(stdout);
	SUBTC_CVDS3(PW1FromDateDup,PW1ToDateDup,CVRpt3,"9");
	printf("\n Function8: Generating PW1 Data Print End - Column9\n");fflush(stdout);
	
	write2xml(CVRpt3,"</DataSheet3>\n");
	return iFail;
}

int TC_CVDS24(FILE* VarRpt)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_name = NULL;
				char* aggrgrp_namedup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				
				STRNG_replace_str(aggrgrp_namedup,"&","and",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","and",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				char aggrvariety[100];
				char modvariety[100];
				char submodvariety[100];
				char variety[100];
				int TotalAgrVar = 0;
				int TotalModVar = 0;
				int TotalSubModVar = 0;
				int TotalVar = 0;
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						TotalAgrVar = TotalAgrVar + sec_countaggr;
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL;
							
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","and",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","and",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}	
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
						            TotalModVar = TotalModVar + sec_countmod;
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","and",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","and",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												TotalSubModVar = TotalSubModVar + sec_countsubmod;
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
													char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
													char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","and",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","and",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														//TotalVar = TotalVar + n_valid_rows;
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
															char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
															char* Tbl_SubModDRARdup = NULL;
															char* Tbl_SubModVLink = NULL;
															char* Tbl_SubModVLinkdup = NULL;
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_VehLink",&Tbl_SubModVLink));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
															if(Tbl_SubModVLink!=NULL)tc_strdup(Tbl_SubModVLink,&Tbl_SubModVLinkdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															printf("\n Table SubModule Vehicle Link(Tbl_SubModVLinkdup): [%s]",Tbl_SubModVLinkdup);fflush(stdout);
															
															if(tc_strcmp(Tbl_SubModVLinkdup,"Yes")==0)
															{
															   printf("\n As SubModule Linked with Vehicle, So Incrementing Count..!!\n");fflush(stdout);
															   TotalVar = TotalVar + 1;
															}
															else
															{
															   printf("\n SubModule not Linked with Vehicle..!!\n");fflush(stdout);
															}
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[2] Aggregate_Variety: [%d]\n",TotalAgrVar);fflush(stdout);
															printf("[3] Module_Variety: [%d]\n",TotalModVar);fflush(stdout);
															printf("[4] SubModule Variety: [%d]\n",TotalSubModVar);fflush(stdout);
															printf("[5] SubModule Details Variety: [%d]\n",TotalVar);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
															
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
				tostring(aggrvariety, TotalAgrVar);
				tostring(modvariety, TotalModVar);
				tostring(submodvariety, TotalSubModVar);
				tostring(variety, TotalVar);
				printf("Final Aggregate Variety: [%s]\n",aggrvariety);fflush(stdout);
				printf("Final Module Variety: [%s]\n",modvariety);fflush(stdout);
				printf("Final SubModule Variety: [%s]\n",submodvariety);fflush(stdout);
				printf("Final Variety: [%s]\n",variety);fflush(stdout);
				write2xml(VarRpt,"<LinkSubmoduleVariety>\n");
				write2xml(VarRpt,"<LinkAggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(VarRpt,aggrgrp_namedup); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</LinkAggregateGrpName>\n");
				write2xml(VarRpt,"<LinkAggregateVar>"); if(tc_strlen(aggrvariety)>0) write2xml(VarRpt,aggrvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</LinkAggregateVar>\n");
				write2xml(VarRpt,"<LinkModuleVar>"); if(tc_strlen(modvariety)>0) write2xml(VarRpt,modvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</LinkModuleVar>\n");
				write2xml(VarRpt,"<LinkSubModuleVar>"); if(tc_strlen(submodvariety)>0) write2xml(VarRpt,submodvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</LinkSubModuleVar>\n");
				write2xml(VarRpt,"<LinkDetailsVar>"); if(tc_strlen(variety)>0) write2xml(VarRpt,variety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</LinkDetailsVar>\n");
				write2xml(VarRpt,"</LinkSubmoduleVariety>\n");
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	return iFail;
}

int TC_CVDS23(FILE* CVVarRpt)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		char aggrgrpvariety[100];
		char aggrvariety[100];
		char modvariety[100];
		char submodvariety[100];
		char variety[100];
		int TotalAgrGrpVar = 0;
		int TotalAgrVar = 0;
		int TotalModVar = 0;
		int TotalSubModVar = 0;
		int TotalVar = 0;
		char* aggrgrp_name = NULL;
		char* aggrgrp_namedup = NULL;
		if(n_itemobj_found > 0)
		{
			TotalAgrGrpVar = TotalAgrGrpVar + n_itemobj_found;
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				
				STRNG_replace_str(aggrgrp_namedup,"&","and",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","and",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						TotalAgrVar = TotalAgrVar + sec_countaggr;
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL;
							
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","and",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","and",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}	
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
						            TotalModVar = TotalModVar + sec_countmod;
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","and",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","and",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												TotalSubModVar = TotalSubModVar + sec_countsubmod;
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
													char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
													char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","and",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","and",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														//TotalVar = TotalVar + n_valid_rows;
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
															char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
															char* Tbl_SubModDRARdup = NULL;
															char* Tbl_SubModVLink = NULL;
															char* Tbl_SubModVLinkdup = NULL;
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_VehLink",&Tbl_SubModVLink));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
															if(Tbl_SubModVLink!=NULL)tc_strdup(Tbl_SubModVLink,&Tbl_SubModVLinkdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															printf("\n Table SubModule Vehicle Linked(Tbl_SubModVLinkdup): [%s]",Tbl_SubModVLinkdup);fflush(stdout);
															
															if(tc_strcmp(Tbl_SubModVLinkdup,"Yes")==0)
															{
															   printf("\n As SubModule Linked with Vehicle, So Incrementing Count..!!\n");fflush(stdout);
															   TotalVar = TotalVar + 1;
															}
															else
															{
															   printf("\n SubModule not Linked with Vehicle..!!\n");fflush(stdout);
															}
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[2] Aggregate_Variety: [%d]\n",TotalAgrVar);fflush(stdout);
															printf("[3] Module_Variety: [%d]\n",TotalModVar);fflush(stdout);
															printf("[4] SubModule Variety: [%d]\n",TotalSubModVar);fflush(stdout);
															printf("[5] SubModule Details Variety: [%d]\n",TotalVar);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
															
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}
			tostring(aggrgrpvariety, TotalAgrGrpVar);
            tostring(aggrvariety, TotalAgrVar);
			tostring(modvariety, TotalModVar);
			tostring(submodvariety, TotalSubModVar);
			tostring(variety, TotalVar);
			printf("Final Aggregate Group Variety: [%s]\n",aggrgrpvariety);fflush(stdout);
			printf("Final Aggregate Variety: [%s]\n",aggrvariety);fflush(stdout);
			printf("Final Module Variety: [%s]\n",modvariety);fflush(stdout);
			printf("Final SubModule Variety: [%s]\n",submodvariety);fflush(stdout);
			printf("Final Variety: [%s]\n",variety);fflush(stdout);
			write2xml(CVVarRpt,"<LinkSubmoduleVariety>\n");
			write2xml(CVVarRpt,"<LinkAggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(CVVarRpt,"CVBU"); else write2xml(CVVarRpt,"CVBU"); write2xml(CVVarRpt,"</LinkAggregateGrpName>\n");
			write2xml(CVVarRpt,"<LinkAggregateVar>"); if(tc_strlen(aggrvariety)>0) write2xml(CVVarRpt,aggrvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</LinkAggregateVar>\n");
			write2xml(CVVarRpt,"<LinkModuleVar>"); if(tc_strlen(modvariety)>0) write2xml(CVVarRpt,modvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</LinkModuleVar>\n");
			write2xml(CVVarRpt,"<LinkSubModuleVar>"); if(tc_strlen(submodvariety)>0) write2xml(CVVarRpt,submodvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</LinkSubModuleVar>\n");
			write2xml(CVVarRpt,"<LinkDetailsVar>"); if(tc_strlen(variety)>0) write2xml(CVVarRpt,variety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</LinkDetailsVar>\n");
			write2xml(CVVarRpt,"</LinkSubmoduleVariety>\n");			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	return iFail;
}

int TC_CVDS22(FILE* VarRpt)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_name = NULL;
				char* aggrgrp_namedup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				
				STRNG_replace_str(aggrgrp_namedup,"&","and",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","and",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				char aggrvariety[100];
				char modvariety[100];
				char submodvariety[100];
				char variety[100];
				int TotalAgrVar = 0;
				int TotalModVar = 0;
				int TotalSubModVar = 0;
				int TotalVar = 0;
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						TotalAgrVar = TotalAgrVar + sec_countaggr;
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL;
							
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","and",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","and",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}	
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
						            TotalModVar = TotalModVar + sec_countmod;
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","and",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","and",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												TotalSubModVar = TotalSubModVar + sec_countsubmod;
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
													char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
													char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","and",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","and",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														TotalVar = TotalVar + n_valid_rows;
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
															char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
															char* Tbl_SubModDRARdup = NULL;
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[2] Aggregate_Variety: [%d]\n",TotalAgrVar);fflush(stdout);
															printf("[3] Module_Variety: [%d]\n",TotalModVar);fflush(stdout);
															printf("[4] SubModule Variety: [%d]\n",TotalSubModVar);fflush(stdout);
															printf("[5] SubModule Details Variety: [%d]\n",TotalVar);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
															
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
				tostring(aggrvariety, TotalAgrVar);
				tostring(modvariety, TotalModVar);
				tostring(submodvariety, TotalSubModVar);
				tostring(variety, TotalVar);
				printf("Final Aggregate Variety: [%s]\n",aggrvariety);fflush(stdout);
				printf("Final Module Variety: [%s]\n",modvariety);fflush(stdout);
				printf("Final SubModule Variety: [%s]\n",submodvariety);fflush(stdout);
				printf("Final Variety: [%s]\n",variety);fflush(stdout);
				write2xml(VarRpt,"<SubmoduleVariety>\n");
				write2xml(VarRpt,"<AggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(VarRpt,aggrgrp_namedup); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</AggregateGrpName>\n");
				write2xml(VarRpt,"<AggregateVar>"); if(tc_strlen(aggrvariety)>0) write2xml(VarRpt,aggrvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</AggregateVar>\n");
				write2xml(VarRpt,"<ModuleVar>"); if(tc_strlen(modvariety)>0) write2xml(VarRpt,modvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</ModuleVar>\n");
				write2xml(VarRpt,"<SubModuleVar>"); if(tc_strlen(submodvariety)>0) write2xml(VarRpt,submodvariety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</SubModuleVar>\n");
				write2xml(VarRpt,"<DetailsVar>"); if(tc_strlen(variety)>0) write2xml(VarRpt,variety); else write2xml(VarRpt,"NA"); write2xml(VarRpt,"</DetailsVar>\n");
				write2xml(VarRpt,"</SubmoduleVariety>\n");
			}			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	return iFail;
}

int TC_CVDS21(FILE* CVVarRpt)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;
    tag_t AggrGrpRev_tag = NULLTAG;
	tag_t AggrGrpToAggrRel = NULLTAG;
	int sec_countaggr = 0;
	tag_t* sec_aggrobjects = NULLTAG;
	tag_t AggrRev_tag = NULLTAG;
	tag_t AggrToModRel = NULLTAG;
	int sec_countmod = 0;
	tag_t* sec_modobjects = NULLTAG;
	tag_t ModRev_tag = NULLTAG;
	tag_t ModToSubModRel = NULLTAG;
	int sec_countsubmod = 0;
	tag_t* sec_submodobjects = NULLTAG;
	tag_t SubModRev_tag = NULLTAG;
	int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
	int iValCnt = 0;
	tag_t ttablerow_rev = NULLTAG;
	
	printf("\n Finding Query[SubModuleLibraryAggrGrp]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("SubModuleLibraryAggrGrp",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("\n Query SubModuleLibraryAggrGrp Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		printf("\n Total SubModule Library Aggregate Group: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
		char aggrgrpvariety[100];
		char aggrvariety[100];
		char modvariety[100];
		char submodvariety[100];
		char variety[100];
		int TotalAgrGrpVar = 0;
		int TotalAgrVar = 0;
		int TotalModVar = 0;
		int TotalSubModVar = 0;
		int TotalVar = 0;
		char* aggrgrp_name = NULL;
		char* aggrgrp_namedup = NULL;
		if(n_itemobj_found > 0)
		{
			TotalAgrGrpVar = TotalAgrGrpVar + n_itemobj_found;
			for(i = 0; i < n_itemobj_found; i++)
			{
				char* aggrgrp_no = NULL;
	            char* aggrgrp_nodup = NULL;
				char* aggrgrp_desc = NULL;
				char* aggrgrp_descdup = NULL;
	
				AggrGrpRev_tag = titemobj_results[i];
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"item_id",&aggrgrp_no));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_name",&aggrgrp_name));
				ITK_CALL(AOM_ask_value_string(AggrGrpRev_tag,"object_desc",&aggrgrp_desc));
				trimwhitespace(aggrgrp_no);
				trimwhitespace(aggrgrp_name);
				trimwhitespace(aggrgrp_desc);
				if(aggrgrp_no!=NULL)tc_strdup(aggrgrp_no,&aggrgrp_nodup);
				if(aggrgrp_name!=NULL)tc_strdup(aggrgrp_name,&aggrgrp_namedup);
				if(aggrgrp_desc!=NULL)tc_strdup(aggrgrp_desc,&aggrgrp_descdup);
				printf("\n Aggregate Group No(aggrgrp_nodup): [%s]\n", aggrgrp_nodup);
				printf("\n Aggregate Group Name(aggrgrp_namedup): [%s]\n", aggrgrp_namedup);
				printf("\n Aggregate Group Description(aggrgrp_descdup): [%s]\n", aggrgrp_descdup);
				
				STRNG_replace_str(aggrgrp_namedup,"&","and",&aggrgrp_namedup);
				STRNG_replace_str(aggrgrp_descdup,"&","and",&aggrgrp_descdup);
				
				if(aggrgrp_namedup != NULL)
				{
					STRNG_replace_str(aggrgrp_namedup,"&","&amp;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,"<","&lt;",&aggrgrp_namedup);
					STRNG_replace_str(aggrgrp_namedup,">","&gt;",&aggrgrp_namedup);
				}
				if(aggrgrp_descdup != NULL)
				{
					STRNG_replace_str(aggrgrp_descdup,"&","&amp;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,"<","&lt;",&aggrgrp_descdup);
					STRNG_replace_str(aggrgrp_descdup,">","&gt;",&aggrgrp_descdup);
				}
				
				ITK_CALL(GRM_find_relation_type("T5_Submdlbagrpagrrel",&AggrGrpToAggrRel));
				if(AggrGrpToAggrRel!=NULLTAG)
				{									
				    printf("\n Sudo Folder Aggregate Details(T5_Submdlbagrpagrrel) Relation Found..!!\n");fflush(stdout);
					ITK_CALL(GRM_list_secondary_objects_only(AggrGrpRev_tag, AggrGrpToAggrRel, &sec_countaggr, &sec_aggrobjects));
				    printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
					if(sec_countaggr > 0)
					{
						TotalAgrVar = TotalAgrVar + sec_countaggr;
						for(j = 0; j < sec_countaggr; j++)
			            {
							char* aggr_no = NULL;
	                        char* aggr_nodup = NULL;
							char* aggr_name = NULL;
							char* aggr_namedup = NULL;
							char* aggr_desc = NULL;
							char* aggr_descdup = NULL;
							
						    AggrRev_tag = sec_aggrobjects[j];
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"item_id",&aggr_no));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_name",&aggr_name));
							ITK_CALL(AOM_ask_value_string(AggrRev_tag,"object_desc",&aggr_desc));
							trimwhitespace(aggr_no);
							trimwhitespace(aggr_name);
							trimwhitespace(aggr_desc);
							if(aggr_no!=NULL)tc_strdup(aggr_no,&aggr_nodup);
							if(aggr_name!=NULL)tc_strdup(aggr_name,&aggr_namedup);
							if(aggr_desc!=NULL)tc_strdup(aggr_desc,&aggr_descdup);
						    printf("\n Aggregate No(aggr_nodup): [%s]\n", aggr_nodup);
							printf("\n Aggregate Name(aggr_namedup): [%s]\n", aggr_namedup);
							printf("\n Aggregate Description(aggr_descdup): [%s]\n", aggr_descdup);
							
							STRNG_replace_str(aggr_namedup,"&","and",&aggr_namedup);
				            STRNG_replace_str(aggr_descdup,"&","and",&aggr_descdup);
							
							if(aggr_namedup != NULL)
							{
								STRNG_replace_str(aggr_namedup,"&","&amp;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,"<","&lt;",&aggr_namedup);
								STRNG_replace_str(aggr_namedup,">","&gt;",&aggr_namedup);
							}	
							if(aggr_descdup != NULL)
							{
								STRNG_replace_str(aggr_descdup,"&","&amp;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,"<","&lt;",&aggr_descdup);
								STRNG_replace_str(aggr_descdup,">","&gt;",&aggr_descdup);
							}
							
							ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel",&AggrToModRel));
							if(AggrToModRel!=NULLTAG)
							{									
								printf("\n Sudo Folder Module Details(T5_Submdlbagrmodrel) Relation Found..!!\n");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AggrRev_tag, AggrToModRel, &sec_countmod, &sec_modobjects));
								printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
								if(sec_countmod > 0)
								{
						            TotalModVar = TotalModVar + sec_countmod;
									for(k = 0; k < sec_countmod; k++)
									{
										char* mod_no = NULL;
	                                    char* mod_nodup = NULL;
										char* mod_name = NULL;
										char* mod_namedup = NULL;
										char* mod_desc = NULL;
										char* mod_descdup = NULL;
										
										ModRev_tag = sec_modobjects[k];
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"item_id",&mod_no));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_name",&mod_name));
										ITK_CALL(AOM_ask_value_string(ModRev_tag,"object_desc",&mod_desc));
										trimwhitespace(mod_no);
										trimwhitespace(mod_name);
										trimwhitespace(mod_desc);
										if(mod_no!=NULL)tc_strdup(mod_no,&mod_nodup);
										if(mod_name!=NULL)tc_strdup(mod_name,&mod_namedup);
										if(mod_desc!=NULL)tc_strdup(mod_desc,&mod_descdup);
										printf("\n Module No(mod_nodup): [%s]\n", mod_nodup);
										printf("\n Module Name(mod_name): [%s]\n", mod_namedup);
										printf("\n Module Description(mod_desc): [%s]\n", mod_descdup);
										
										STRNG_replace_str(mod_namedup,"&","and",&mod_namedup);
				                        STRNG_replace_str(mod_descdup,"&","and",&mod_descdup);
										
										if(mod_namedup != NULL)
										{
											STRNG_replace_str(mod_namedup,"&","&amp;",&mod_namedup);
											STRNG_replace_str(mod_namedup,"<","&lt;",&mod_namedup);
											STRNG_replace_str(mod_namedup,">","&gt;",&mod_namedup);
										}
										if(mod_descdup != NULL)
										{
											STRNG_replace_str(mod_descdup,"&","&amp;",&mod_descdup);
											STRNG_replace_str(mod_descdup,"<","&lt;",&mod_descdup);
											STRNG_replace_str(mod_descdup,">","&gt;",&mod_descdup);
										}

                                        ITK_CALL(GRM_find_relation_type("T5_Submdlbmodsubrel",&ModToSubModRel));
										if(ModToSubModRel!=NULLTAG)
										{									
											printf("\n Sudo Folder SubModule Details(T5_Submdlbmodsubrel) Relation Found..!!\n");fflush(stdout);
											ITK_CALL(GRM_list_secondary_objects_only(ModRev_tag, ModToSubModRel, &sec_countsubmod, &sec_submodobjects));
											printf("\n Total Objects Found(T5_Submdlbagrpagrrel): [%d]\n", sec_countaggr);
											if(sec_countsubmod > 0)
											{
												TotalSubModVar = TotalSubModVar + sec_countsubmod;
												for(l = 0; l < sec_countsubmod; l++)
												{
													char* submod_no = NULL;
													char* submod_nodup = NULL;
													char* submod_name = NULL;
													char* submod_namedup = NULL;
													char* submod_desc = NULL;
													char* submod_descdup = NULL;
													char* submod_address = NULL;
													char* submod_addressdup = NULL;
	
													SubModRev_tag = sec_submodobjects[l];
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"item_id",&submod_no));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_name",&submod_name));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"object_desc",&submod_desc));
													ITK_CALL(AOM_ask_value_string(SubModRev_tag,"t5_ModuleAddrSL",&submod_address));
													trimwhitespace(submod_no);
													trimwhitespace(submod_name);
													trimwhitespace(submod_desc);
													trimwhitespace(submod_address);
													if(submod_no!=NULL)tc_strdup(submod_no,&submod_nodup);
													if(submod_name!=NULL)tc_strdup(submod_name,&submod_namedup);
													if(submod_desc!=NULL)tc_strdup(submod_desc,&submod_descdup);
													if(submod_address!=NULL)tc_strdup(submod_address,&submod_addressdup);
													printf("\n SubModule No(submod_nodup): [%s]\n", submod_nodup);
													printf("\n SubModule Name(submod_namedup): [%s]\n", submod_namedup);
													printf("\n SubModule Description(submod_descdup): [%s]\n", submod_descdup);
													printf("\n Module Address(submod_addressdup): [%s]\n", submod_addressdup);
													
													STRNG_replace_str(submod_namedup,"&","and",&submod_namedup);
				                                    STRNG_replace_str(submod_descdup,"&","and",&submod_descdup);
													STRNG_replace_str(submod_namedup,"""","",&submod_namedup);
													STRNG_replace_str(submod_descdup,"""","",&submod_descdup);
													
													if(submod_namedup != NULL)
													{
														STRNG_replace_str(submod_namedup,"&","&amp;",&submod_namedup);
														STRNG_replace_str(submod_namedup,"<","&lt;",&submod_namedup);
														STRNG_replace_str(submod_namedup,">","&gt;",&submod_namedup);
													}
													if(submod_descdup != NULL)
													{
														STRNG_replace_str(submod_descdup,"&","&amp;",&submod_descdup);
														STRNG_replace_str(submod_descdup,"<","&lt;",&submod_descdup);
														STRNG_replace_str(submod_descdup,">","&gt;",&submod_descdup);
													}
													
													ITK_CALL(AOM_ask_table_rows(SubModRev_tag,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
													printf("\n No of Table Row [%d]  For SubModule  [%s]\n", n_valid_rows, submod_nodup);fflush(stdout);
													if(n_valid_rows>0)
													{
														TotalVar = TotalVar + n_valid_rows;
														for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
														{
															char* Tbl_SubModNo = NULL;
															char* Tbl_SubModNodup = NULL;
															char* Tbl_SubModRev = NULL;
															char* Tbl_SubModRevdup = NULL;
															char* Tbl_SubModSeq = NULL;
															char* Tbl_SubModSeqdup = NULL;
															char* Tbl_SubModDesc = NULL;
															char* Tbl_SubModDescdup = NULL;
															char* Tbl_SubModProd = NULL;
															char* Tbl_SubModProddup = NULL;
															char* Tbl_SubModPlat = NULL;
															char* Tbl_SubModPlatdup = NULL;
															char* Tbl_SubModProj = NULL;
															char* Tbl_SubModProjdup = NULL;
															char* Tbl_SubModDRAR = NULL;
															char* Tbl_SubModDRARdup = NULL;
															
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));	
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_rev",&Tbl_SubModRev));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_seq",&Tbl_SubModSeq));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_desc",&Tbl_SubModDesc));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModPlat));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_projectcode",&Tbl_SubModProj));
															ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_drarstatus",&Tbl_SubModDRAR));
															
															trimwhitespace(Tbl_SubModNo);
															trimwhitespace(Tbl_SubModRev);
															trimwhitespace(Tbl_SubModSeq);
															trimwhitespace(Tbl_SubModDesc);
				                                            printf("\n SubModule Description Value Before Dup & Trim: --------> <%s>", Tbl_SubModDesc);fflush(stdout);
															STRNG_replace_str(Tbl_SubModDesc,","," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,";"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"\n"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"'"," ",&Tbl_SubModDesc);
															STRNG_replace_str(Tbl_SubModDesc,"&","And",&Tbl_SubModDesc);
															trimwhitespace(Tbl_SubModProd);
															trimwhitespace(Tbl_SubModPlat);
															trimwhitespace(Tbl_SubModProj);
															trimwhitespace(Tbl_SubModDRAR);
													        if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
															if(Tbl_SubModRev!=NULL)tc_strdup(Tbl_SubModRev,&Tbl_SubModRevdup);
															if(Tbl_SubModSeq!=NULL)tc_strdup(Tbl_SubModSeq,&Tbl_SubModSeqdup);
															if(Tbl_SubModDesc!=NULL)tc_strdup(Tbl_SubModDesc,&Tbl_SubModDescdup);
															if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
															if(Tbl_SubModPlat!=NULL)tc_strdup(Tbl_SubModPlat,&Tbl_SubModPlatdup);
															if(Tbl_SubModProj!=NULL)tc_strdup(Tbl_SubModProj,&Tbl_SubModProjdup);
															if(Tbl_SubModDRAR!=NULL)tc_strdup(Tbl_SubModDRAR,&Tbl_SubModDRARdup);
													        printf("\n Table SubModule No(Tbl_SubModNodup): [%s]\n", Tbl_SubModNodup);
															printf("\n Table SubModule Rev(Tbl_SubModRevdup): [%s]",Tbl_SubModRevdup);fflush(stdout);
															printf("\n Table SubModule Seq(Tbl_SubModSeqdup): [%s]",Tbl_SubModSeqdup);fflush(stdout);
															printf("\n Table SubModule Description(Tbl_SubModDescdup): [%s]",Tbl_SubModDescdup);fflush(stdout);
															printf("\n Table SubModule Peoductline(Tbl_SubModProddup): [%s]",Tbl_SubModProddup);fflush(stdout);
															printf("\n Table SubModule Platform(Tbl_SubModPlatdup): [%s]",Tbl_SubModPlatdup);fflush(stdout);
															printf("\n Table SubModule Project Code(Tbl_SubModProjdup): [%s]",Tbl_SubModProjdup);fflush(stdout);
															printf("\n Table SubModule DR/AR(Tbl_SubModDRARdup): [%s]",Tbl_SubModDRARdup);fflush(stdout);
															
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
															printf("[1] Aggregate_Group_Name: [%s]\n",aggrgrp_namedup);fflush(stdout);
															printf("[2] Aggregate_Variety: [%d]\n",TotalAgrVar);fflush(stdout);
															printf("[3] Module_Variety: [%d]\n",TotalModVar);fflush(stdout);
															printf("[4] SubModule Variety: [%d]\n",TotalSubModVar);fflush(stdout);
															printf("[5] SubModule Details Variety: [%d]\n",TotalVar);fflush(stdout);
															printf("\n >>>>>>>>>>>>>>> SubModule Library Variety Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
															
															if(tc_strlen(Tbl_SubModDescdup)>0) STRNG_replace_str(Tbl_SubModDescdup,"&","&amp;",&Tbl_SubModDescdup);
				                                            if(tc_strlen(Tbl_SubModProddup)>0) STRNG_replace_str(Tbl_SubModProddup,"&","&amp;",&Tbl_SubModProddup);
													        if(tc_strlen(Tbl_SubModPlatdup)>0) STRNG_replace_str(Tbl_SubModPlatdup,"&","&amp;",&Tbl_SubModPlatdup);
															
														}
													}
													else
													{
														printf("\n No Table Row Found For Input SubModule: [%s], submod_nodup\n");fflush(stdout);
													} 
												}
											}
											else
											{
												printf("\n SubModule Not Found For Module: [%s]\n", mod_nodup);fflush(stdout);
											}
										}
										else
										{
											printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
										}										
									}
								}
								else
								{
									printf("\n Module Not Found For Aggregate: [%s]\n", aggr_nodup);fflush(stdout);
								}
							}
							else
							{
								printf("\n Module Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n Aggregate Not Found For Aggregate Group: [%s]\n", aggrgrp_nodup);fflush(stdout);
					}
				}
				else
				{
					printf("\n Aggregate Details(T5_Submdlbagrpagrrel) Relation Tag Not Found..!!\n");fflush(stdout);
				}
			}
			tostring(aggrgrpvariety, TotalAgrGrpVar);
            tostring(aggrvariety, TotalAgrVar);
			tostring(modvariety, TotalModVar);
			tostring(submodvariety, TotalSubModVar);
			tostring(variety, TotalVar);
			printf("Final Aggregate Group Variety: [%s]\n",aggrgrpvariety);fflush(stdout);
			printf("Final Aggregate Variety: [%s]\n",aggrvariety);fflush(stdout);
			printf("Final Module Variety: [%s]\n",modvariety);fflush(stdout);
			printf("Final SubModule Variety: [%s]\n",submodvariety);fflush(stdout);
			printf("Final Variety: [%s]\n",variety);fflush(stdout);
			write2xml(CVVarRpt,"<SubmoduleVariety>\n");
			write2xml(CVVarRpt,"<AggregateGrpName>"); if(tc_strlen(aggrgrp_namedup)>0) write2xml(CVVarRpt,"CVBU"); else write2xml(CVVarRpt,"CVBU"); write2xml(CVVarRpt,"</AggregateGrpName>\n");
			write2xml(CVVarRpt,"<AggregateVar>"); if(tc_strlen(aggrvariety)>0) write2xml(CVVarRpt,aggrvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</AggregateVar>\n");
			write2xml(CVVarRpt,"<ModuleVar>"); if(tc_strlen(modvariety)>0) write2xml(CVVarRpt,modvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</ModuleVar>\n");
			write2xml(CVVarRpt,"<SubModuleVar>"); if(tc_strlen(submodvariety)>0) write2xml(CVVarRpt,submodvariety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</SubModuleVar>\n");
			write2xml(CVVarRpt,"<DetailsVar>"); if(tc_strlen(variety)>0) write2xml(CVVarRpt,variety); else write2xml(CVVarRpt,"NA"); write2xml(CVVarRpt,"</DetailsVar>\n");
			write2xml(CVVarRpt,"</SubmoduleVariety>\n");			
		}
		else
        {
			printf(" Aggregate Group Found Zero[0] on SubModuleLibraryAggrGrp..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	return iFail;
}

int TC_CVDS2(FILE* CVRpt2)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int k = 0;
	tag_t tsubmodlib_rev = NULLTAG;
	char *SubModAddr_Str = NULL;
	char *SubModAddr_StrDup = NULL;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *LbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fplb_file = NULL;
	char *MstrLbRptFile = (char *) malloc(100*sizeof(char));
	FILE *fmstrplb_file = NULL;
	char *Tbl_SubModVehLink = NULL;
	char *Tbl_SubModVehLinkDup = NULL;
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(LbRptFile,"/tmp/");
	tc_strcat(LbRptFile,"SubModDetails");
	tc_strcat(LbRptFile,"_");
	tc_strcat(LbRptFile,GenDate);
	tc_strcat(LbRptFile,".txt");
	printf("\n Submodule Library Report File Name: [%s]", LbRptFile);fflush(stdout);
	printf("\n Submodule Library Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Master Submodule Library Report File Name..!!");fflush(stdout);
	tc_strcpy(MstrLbRptFile,"/tmp/");
	tc_strcat(MstrLbRptFile,"MasterSubModDetails");
	tc_strcat(MstrLbRptFile,"_");
	tc_strcat(MstrLbRptFile,GenDate);
	tc_strcat(MstrLbRptFile,".txt");
	printf("\n Master Submodule Library Report File Name: [%s]", MstrLbRptFile);fflush(stdout);
	printf("\n Master Submodule Library Report File Generated..!!");fflush(stdout);
	fplb_file = fopen(LbRptFile, "w");
	//fmstrplb_file = fopen(MstrLbRptFile, "w");
	
	printf("\n Submodule Library Report Report File Generated..!!");fflush(stdout);
	ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
	if(tItemobj != NULLTAG)
	{
		printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {"*"};
		//char *cValues[1]  = {"A1A01"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf("\nSubModule Address Revision Found..!!\n");fflush(stdout);
			for(k = 0; k < n_itemobj_found; k++)
			{
				tsubmodlib_rev = titemobj_results[k];
				ITK_CALL(AOM_ask_value_string(tsubmodlib_rev,"item_id",&SubModAddr_Str));
				trimwhitespace(SubModAddr_Str);
				if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
				ITK_CALL(AOM_ask_table_rows(tsubmodlib_rev,"t5_Submoduledetail", &n_valid_rows,&valid_rowsTag));
				printf("\n No of Table Row: [%d]  For SubModule Address:  [%s]\n", n_valid_rows, SubModAddr_StrDup);fflush(stdout);
				if(n_valid_rows>0)
				{
					int iValCnt=0;
					for(iValCnt=0;iValCnt<n_valid_rows;iValCnt++)
					{
						char* Tbl_SubModNo = NULL;
						char* Tbl_SubModNodup = NULL;
						char* Tbl_SubModProd = NULL;
						char* Tbl_SubModProddup = NULL;
						printf("\n [Start] Printing of Table Row: [%d]\n",iValCnt);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_submoduleno",&Tbl_SubModNo));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_productline",&Tbl_SubModProd));
						ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_VehLink",&Tbl_SubModVehLink));
						//ITK_CALL(AOM_ask_value_string(valid_rowsTag[iValCnt],"t5_Platform",&Tbl_SubModProd));
						trimwhitespace(Tbl_SubModNo);
						trimwhitespace(Tbl_SubModProd);
						trimwhitespace(Tbl_SubModVehLink);
						if(Tbl_SubModNo!=NULL)tc_strdup(Tbl_SubModNo,&Tbl_SubModNodup);
						if(Tbl_SubModProd!=NULL)tc_strdup(Tbl_SubModProd,&Tbl_SubModProddup);
						if(Tbl_SubModVehLink!=NULL)tc_strdup(Tbl_SubModVehLink,&Tbl_SubModVehLinkDup);
						if((tc_strlen(Tbl_SubModNodup)>0) && (tc_strcmp(Tbl_SubModVehLinkDup,"Yes")==0))
						{
						  fprintf(fplb_file,"%s^%s^\n",Tbl_SubModNodup,Tbl_SubModProddup);fflush(fplb_file);
						}  
						printf("\n [End] Printing of Table Row: [%d]",iValCnt);fflush(stdout);
					}
				}
				else
				{
					printf("\n No Table Row Found Zero For Input SubModule Address: [%s]\n", SubModAddr_StrDup);fflush(stdout);
				}
			}				
		}
		else
		{
		   printf("\n SubModule Address Revision Not Found..!!\n");fflush(stdout);
		}					
	}
	else
	{
		printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
	}
	fclose(fplb_file);
	
	char command[512];
	printf("\n File Short Shell Call Started...");fflush(stdout);
	sprintf(command,"/user/cvprod/sourav/MCCMAINDASHBOARD/FileShort.sh %s %s",LbRptFile,MstrLbRptFile);
	system(command);
	printf("\n File Short Shell Call Ended...");

	char *item_id_str = NULL;
	char *item_plat_str = NULL;
	char *item_id_strDup = NULL;
	char *item_plat_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer1[MAX_LINE_LENGTH];
	int i = 0;
	int hcvcount = 0;
	int ilmcvcount = 0;
	int scvcount = 0;
	int passcount = 0;
	int cvcount = 0;
	fpPart_List = fopen(MstrLbRptFile,"r");
	
	if(fpPart_List == NULL)
	{
	    printf("\n Unable to Open Input File \n");fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer1,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer1,"^");
			item_plat_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_plat_str!=NULL)tc_strdup(item_plat_str,&item_plat_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_plat_strDup!=NULL)trimwhitespace(item_plat_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Platform(item_plat_strDup): [%s]\n",item_plat_strDup);
			
			if((tc_strstr(item_plat_strDup,"HCV")!=NULL) || (tc_strstr(item_plat_strDup,"MHCV")!=NULL))
			{
				hcvcount = hcvcount + 1;
			}
			else if((tc_strstr(item_plat_strDup,"ILMCV")!=NULL) || (tc_strstr(item_plat_strDup,"ILCV")!=NULL))
			{
				ilmcvcount = ilmcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"SCV")!=NULL)
			{
				scvcount = scvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"BUS")!=NULL)
			{
				passcount = passcount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		cvcount = hcvcount + ilmcvcount + scvcount + passcount;
		char hcvcountstr[10];
		char ilmcvcountstr[10];
		char scvcountstr[10];
		char passcountstr[10];
		char cvcountstr[10];
		tostring(hcvcountstr, hcvcount);
		tostring(ilmcvcountstr, ilmcvcount);
		tostring(scvcountstr, scvcount);
		tostring(passcountstr, passcount);
		tostring(cvcountstr, cvcount);

		write2xml(CVRpt2,"<DataSheet2>\n");
		write2xml(CVRpt2,"<Details2>"); write2xml(CVRpt2,"Total Submodules(SM)"); write2xml(CVRpt2,"</Details2>\n");
		write2xml(CVRpt2,"<DS2HCV>"); write2xml(CVRpt2,"HCV"); write2xml(CVRpt2,"</DS2HCV>\n");
		write2xml(CVRpt2,"<DS2HCVData>"); write2xml(CVRpt2,hcvcountstr); write2xml(CVRpt2,"</DS2HCVData>\n");
		write2xml(CVRpt2,"<DS2ILMCV>"); write2xml(CVRpt2,"ILMCV"); write2xml(CVRpt2,"</DS2ILMCV>\n");
		write2xml(CVRpt2,"<DS2ILMCVData>"); write2xml(CVRpt2,ilmcvcountstr); write2xml(CVRpt2,"</DS2ILMCVData>\n");
		write2xml(CVRpt2,"<DS2SCV>"); write2xml(CVRpt2,"SCV"); write2xml(CVRpt2,"</DS2SCV>\n");
		write2xml(CVRpt2,"<DS2SCVData>"); write2xml(CVRpt2,scvcountstr); write2xml(CVRpt2,"</DS2SCVData>\n");
		write2xml(CVRpt2,"<DS2PASS>"); write2xml(CVRpt2,"PASS(BUS)"); write2xml(CVRpt2,"</DS2PASS>\n");
		write2xml(CVRpt2,"<DS2PASSData>"); write2xml(CVRpt2,passcountstr); write2xml(CVRpt2,"</DS2PASSData>\n");
		write2xml(CVRpt2,"<DS2CV>"); write2xml(CVRpt2,"CV"); write2xml(CVRpt2,"</DS2CV>\n");
		write2xml(CVRpt2,"<DS2CVData>"); write2xml(CVRpt2,cvcountstr); write2xml(CVRpt2,"</DS2CVData>\n");
		write2xml(CVRpt2,"</DataSheet2>\n");
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	
	return iFail;
}

int TC_CVDS1(FILE* CVRpt1)
{
	int iFail = ITK_ok;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_plat_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	char *item_plat_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	int i = 0;
	int hcvcount = 0;
	int ilmcvcount = 0;
	int scvcount = 0;
	int passcount = 0;
	int cvcount = 0;
	fpPart_List = fopen("/user/cvprod/sourav/MCCMAINDASHBOARD/PartList.txt","r");
	
	if(fpPart_List == NULL)
	{
	    printf("\n Unable to Open Input File \n");fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
	    while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			item_plat_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			if(item_plat_str!=NULL)tc_strdup(item_plat_str,&item_plat_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			if(item_plat_strDup!=NULL)trimwhitespace(item_plat_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Platform(item_plat_strDup): [%s]\n",item_plat_strDup);
			
			if(tc_strstr(item_plat_strDup,"HCV")!=NULL)
			{
				hcvcount = hcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"ILMCV")!=NULL)
			{
				ilmcvcount = ilmcvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"SCV")!=NULL)
			{
				scvcount = scvcount + 1;
			}
			else if(tc_strstr(item_plat_strDup,"BUS")!=NULL)
			{
				passcount = passcount + 1;
			}
			else
			{
				printf("\n!!...Platform Not Matched..!!\n");fflush(stdout);
			}
		}
		cvcount = hcvcount + ilmcvcount + scvcount + passcount;
		char hcvcountstr[10];
		char ilmcvcountstr[10];
		char scvcountstr[10];
		char passcountstr[10];
		char cvcountstr[10];
		tostring(hcvcountstr, hcvcount);
		tostring(ilmcvcountstr, ilmcvcount);
		tostring(scvcountstr, scvcount);
		tostring(passcountstr, passcount);
		tostring(cvcountstr, cvcount);

		write2xml(CVRpt1,"<DataSheet1>\n");
		write2xml(CVRpt1,"<Details1>"); write2xml(CVRpt1,"Total Vehicle(s) Applicable, All Live VCs"); write2xml(CVRpt1,"</Details1>\n");
		write2xml(CVRpt1,"<DS1HCV>"); write2xml(CVRpt1,"HCV"); write2xml(CVRpt1,"</DS1HCV>\n");
		write2xml(CVRpt1,"<DS1HCVData>"); write2xml(CVRpt1,hcvcountstr); write2xml(CVRpt1,"</DS1HCVData>\n");
		write2xml(CVRpt1,"<DS1ILMCV>"); write2xml(CVRpt1,"ILMCV"); write2xml(CVRpt1,"</DS1ILMCV>\n");
		write2xml(CVRpt1,"<DS1ILMCVData>"); write2xml(CVRpt1,ilmcvcountstr); write2xml(CVRpt1,"</DS1ILMCVData>\n");
		write2xml(CVRpt1,"<DS1SCV>"); write2xml(CVRpt1,"SCV"); write2xml(CVRpt1,"</DS1SCV>\n");
		write2xml(CVRpt1,"<DS1SCVData>"); write2xml(CVRpt1,scvcountstr); write2xml(CVRpt1,"</DS1SCVData>\n");
		write2xml(CVRpt1,"<DS1PASS>"); write2xml(CVRpt1,"PASS(BUS)"); write2xml(CVRpt1,"</DS1PASS>\n");
		write2xml(CVRpt1,"<DS1PASSData>"); write2xml(CVRpt1,passcountstr); write2xml(CVRpt1,"</DS1PASSData>\n");
		write2xml(CVRpt1,"<DS1CV>"); write2xml(CVRpt1,"CV"); write2xml(CVRpt1,"</DS1CV>\n");
		write2xml(CVRpt1,"<DS1CVData>"); write2xml(CVRpt1,cvcountstr); write2xml(CVRpt1,"</DS1CVData>\n");
		write2xml(CVRpt1,"</DataSheet1>\n");
	}
	else
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	char STDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	strftime(STDate,100,"%d %b, %Y (%A)",&when);
	printf(" Stylesheet TimeStamp: [%s]\n", STDate);fflush(stdout);

	char *PreVCompFile = (char *) malloc(100*sizeof(char));
	printf("\n Generating XML Report File Name..!!");fflush(stdout);
	tc_strcpy(PreVCompFile,"/tmp/");
	tc_strcat(PreVCompFile,"MCCMainDashboardReport");
	tc_strcat(PreVCompFile,"_");
	tc_strcat(PreVCompFile,GenDate);
	tc_strcat(PreVCompFile,".xml");
	//Report = fopen("/tmp/MCCMainDashboardReport.xml","w");
	printf("\n Pre MCC Main Dashboard Report File Name: [%s]", PreVCompFile);fflush(stdout);
	
	Report = fopen(PreVCompFile,"w");
	if(Report == NULL)
	{
		printf("ERROR: Unable To Open XML File..!!\n");
	}
	else
	{
		printf("XML File Opened Successfully..!!\n");
	}
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"<MCCMainDashboardRpt>\n");
	write2xml(Report,"<DataRefreshDate>\n");
	write2xml(Report,"<LastDate>"); write2xml(Report,STDate); write2xml(Report,"</LastDate>\n");
	write2xml(Report,"</DataRefreshDate>\n");
	printf(" Input_File Not Null..!!\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function1: TCUA-CV Data Sheet1 Print Start");fflush(stdout);
	//TC_CVDS1(Report);
	printf("\n Function1: TCUA-CV Data Sheet1 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2: TCUA-CV Data Sheet2 Print Start");fflush(stdout);
	//TC_CVDS2(Report);
	printf("\n Function2: TCUA-CV Data Sheet2 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2.1: TCUA-CV Data Sheet2.1 Print Start");fflush(stdout);
	//TC_CVDS21(Report);
	printf("\n Function2.1: TCUA-CV Data Sheet2.1 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111122222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2.2: TCUA-CV Data Sheet2.2 Print Start");fflush(stdout);
	//TC_CVDS22(Report);
	printf("\n Function2.2: TCUA-CV Data Sheet2.2 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111122222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111133333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2.3: TCUA-CV Data Sheet2.3 Print Start");fflush(stdout);
	//TC_CVDS23(Report);
	printf("\n Function2.3: TCUA-CV Data Sheet2.3 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111133333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111144444444444444444444444444<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2.4: TCUA-CV Data Sheet2.4 Print Start");fflush(stdout);
	//TC_CVDS24(Report);
	printf("\n Function2.4: TCUA-CV Data Sheet2.4 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222221111111111111111111111111144444444444444444444444444<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>333333333333333333333333333333333333333333333333333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function3: TCUA-CV Data Sheet3 Print Start");fflush(stdout);
	//TC_CVDS3(Report);
	printf("\n Function3: TCUA-CV Data Sheet3 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>333333333333333333333333333333333333333333333333333333333333333333333333<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>444444444444444444444444444444444444444444444444444444444444444444444444<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function4: TCUA-CV Data Sheet4 Print Start");fflush(stdout);
	//TC_CVDS4(Report);
	printf("\n Function4: TCUA-CV Data Sheet4 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>444444444444444444444444444444444444444444444444444444444444444444444444<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>555555555555555555555555555555555555555555555555555555555555555555555555<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function5: TCUA-CV Data Sheet5 Print Start");fflush(stdout);
	//TC_CVDS5(Report);
	printf("\n Function5: TCUA-CV Data Sheet5 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>555555555555555555555555555555555555555555555555555555555555555555555555<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>666666666666666666666666666666666666666666666666666666666666666666666666<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function6: TCUA-CV Data Sheet6 Print Start");fflush(stdout);
	TC_CVDS6(Report);
	printf("\n Function6: TCUA-CV Data Sheet6 Print End\n");fflush(stdout);
	printf("\n >>>>>>>>>>666666666666666666666666666666666666666666666666666666666666666666666666<<<<<<<<<<<\n");fflush(stdout);
	write2xml(Report,"</MCCMainDashboardRpt>\n");
	fclose(Report);		
	printf("\n All Details Written Successfully on the XML File....\n");fflush(stdout);
		
	printf("Current File To Original File Move Start..!!\n");fflush(stdout);
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tc_strcpy(ShellCommandLine,"/user/cvprod/sourav/MCCMAINDASHBOARD/RemoveProcessFiles.sh");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,"TEST");
	tc_strcat(ShellCommandLine," ");
	tc_strcat(ShellCommandLine,PreVCompFile);
	system(ShellCommandLine);
	printf("Current File To Original File Move End..!!\n");fflush(stdout);

	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_mccmaindashboard.c
* // ./linkitk -o tm_mccmaindashboard tm_mccmaindashboard.o
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCCMAINDASHBOARD/tm_mccmaindashboard .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCCMAINDASHBOARD/exepatch.sh .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCCMAINDASHBOARD/PartList.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCCMAINDASHBOARD/usage.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/MCCMAINDASHBOARD/SendEmail.sh .
* // ./tm_mccmaindashboard -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mccmaindashboard -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_mccmaindashboard -u=infodba -p=loader123 -g=dba
*
***************************************************************************/