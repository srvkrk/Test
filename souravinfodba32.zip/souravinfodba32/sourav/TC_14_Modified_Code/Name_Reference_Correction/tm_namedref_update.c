/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update Named Reference of Attached Dataset  
*  File Name    :   tm_namedref_update.c
*  Created on   :   Sep 19th, 2023
*  Usage        :   tm_namedref_update
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     19/09/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_revseq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t PropName_AttrID = NULLTAG;
	int i = 0;
	tag_t IMANSpecType = NULLTAG;
	tag_t IMANRefType = NULLTAG;
	tag_t IMANRenType = NULLTAG;
	tag_t* IMANSpecAttach = NULLTAG;
	int IMANSpecCnt = 0;
	tag_t* IMANRefAttach = NULLTAG;
	int IMANRefCnt = 0;
	tag_t* IMANRenAttach = NULLTAG;
	int IMANRenCnt = 0;
	int j = 0;
	tag_t dataset = NULLTAG;
	AE_reference_type_t RefType;
	char* RefName = NULL;
	//char   RefName[AE_reference_size_c + 1];
	tag_t SecObjTypeTag = NULLTAG;
	char* SecObjTypeName = NULL;
	//char SecObjTypeName[TCTYPE_name_size_c+1];
	int ReferenceCount = 0;
	int k = 0;
	tag_t RefObject = NULLTAG;
	char* Orginal_Name = NULL;
	//char   Orginal_Name[IMF_filename_size_c + 1];
	char* object_type = NULL;
	char* Data_Name  = NULL;
	char* ItemIDChk = NULL;
	char* New_Name= (char *) malloc(400*sizeof(char));
	char* SecObjName = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		ITK_CALL(GRM_find_relation_type("IMAN_specification",&IMANSpecType));
		ITK_CALL(GRM_find_relation_type("IMAN_reference",&IMANRefType));
	    ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&IMANRenType));
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_revseq_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_revseq_str!=NULL)tc_strdup(item_revseq_str,&item_revseq_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_revseq_strDup!=NULL)trimwhitespace(item_revseq_strDup);
			
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" Part RevSeq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				for (i = 0; i < n_itemobj_found; i++)
		        {
					
					printf(" ------- I M A N    R E N D E R I N G   S T A R T -------\n");fflush(stdout);
					if(IMANRenType != NULLTAG)
	                {	
						ITK_CALL(GRM_list_secondary_objects_only(titemobj_results[i],IMANRenType,&IMANRenCnt,&IMANRenAttach));
						printf("IMANRenCnt: [%d]\n",IMANRenCnt);fflush(stdout);
						if(IMANRenCnt > 0)
						{
							for (j = 0; j < IMANRenCnt; j++)
							{
								dataset = IMANRenAttach[j];
								ITK_CALL(WSOM_ask_object_id_string(dataset,&SecObjName));
								printf("SecObjName: [%s]\n",SecObjName);fflush(stdout);
								ITK_CALL(AE_find_dataset_named_ref2(dataset,k,&RefName,&RefType,&RefObject));
						        ITK_CALL(IMF_ask_original_file_name2(RefObject,&Orginal_Name));
                                printf("Before Set Orginal File Name: [%s]\n",Orginal_Name);fflush(stdout);
								char* class_name = NULL;
							    tag_t class_id = NULLTAG;
								logical	log1;
								ITK_CALL(POM_class_of_instance(RefObject,&class_id));
								ITK_CALL(POM_name_of_class(class_id,&class_name));
								printf("\n Class_Name: [%s]\n", class_name);fflush(stdout);
								ITK_CALL(POM_unload_instances(1,&RefObject));
								ITK_CALL(POM_load_instances(1,&RefObject,class_id,1));
								ITK_CALL(POM_is_loaded(RefObject,&log1));
								if(log1 == 1)
								{
									printf(" Load Success\n");fflush(stdout);
								}
								else
								{
									printf(" Load Failure\n" );fflush(stdout);
								}
								//ITK_CALL(IMF_set_original_file_name2(RefObject,"505383100002.jt"));
								ITK_CALL(IMF_ask_original_file_name2(RefObject,&Orginal_Name));
                                printf("After Set Orginal File Name: [%s]\n",Orginal_Name);fflush(stdout);
								ITK_CALL(POM_save_instances(1,&RefObject,1));
                                ITK_CALL(POM_refresh_instances(1,&RefObject,class_id,2));
                                ITK_CALL(AOM_lock(RefObject));
                                ITK_CALL(AOM_save_without_extensions(RefObject));
                                ITK_CALL(AOM_refresh(RefObject,1));
								ITK_CALL(AOM_unlock(RefObject));
								printf(" UnLocked..!!\n" );fflush(stdout);
								
								/* char* ShellCommandLine = NULL;
		                        ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
								ITK_CALL(AE_export_named_ref(dataset, "JTPART", "/user/cvprod/sourav/Name_Reference_Update/"));
								printf(" Exported..!!\n");fflush(stdout);
								printf("\n SHELL CALL: Start\n");fflush(stdout);
								tc_strcpy(ShellCommandLine,"/user/cvprod/sourav/Name_Reference_Update/Execution_Shell.sh");
								printf("\n CommandLine: -------> [%s]",ShellCommandLine);fflush(stdout);
								system(ShellCommandLine);
								printf("\n SHELL CALL: End\n");fflush(stdout);
								ITK_CALL(AOM_refresh(dataset, 1));
								printf(" Checkedout..!!\n");fflush(stdout);
								ITK_CALL(AE_remove_dataset_named_ref2(dataset, "JTPART"));
								printf(" Removed..!!\n");fflush(stdout);
								ITK_CALL(AOM_save_without_extensions(titemobj_results[i]));
							    printf(" Saved..!!\n");fflush(stdout);
								ITK_CALL(AOM_refresh(dataset, 0));
								printf(" Checkedin..!!\n");fflush(stdout);
								ITK_CALL(AOM_refresh(dataset, 1));
								printf(" Checkedout..!!\n");fflush(stdout);
                                ITK_CALL(AE_import_named_ref(dataset,"JTPART","/user/cvprod/sourav/Name_Reference_Update/505383100002.jt",SecObjName,SS_BINARY));
				                printf(" Imported..!!\n");fflush(stdout);
				                ITK_CALL(AE_save_myself(dataset));
				                printf(" Saved..!!\n");fflush(stdout);
								ITK_CALL(AOM_refresh(dataset, 0));
								printf(" Checkedin..!!\n");fflush(stdout);
								exit(0); */
								
								ITK_CALL(TCTYPE_ask_object_type(dataset,&SecObjTypeTag));
				                //ITK_CALL(TCTYPE_ask_name(SecObjTypeTag,SecObjTypeName));
								ITK_CALL(TCTYPE_ask_name2(SecObjTypeTag,&SecObjTypeName));
								printf("SecObjTypeName: [%s]\n",SecObjTypeName);fflush(stdout);
                                ITK_CALL(AE_ask_dataset_ref_count(dataset,&ReferenceCount));
								printf("ReferenceCount: [%d]\n",ReferenceCount);fflush(stdout);
								if (ReferenceCount > 0)
								{
									for(k=0; k < ReferenceCount; k++)
					                {
										/* ITK_CALL(AE_find_dataset_named_ref2(dataset,k,&RefName,&RefType,&RefObject));
						                ITK_CALL(IMF_ask_original_file_name2(RefObject,&Orginal_Name));
                                        printf("Orginal File Name: [%s]\n",Orginal_Name);fflush(stdout); */
										ITK_CALL(AOM_ask_value_string(dataset,"object_type",&object_type));
										printf("Object Type: [%s]\n",object_type);fflush(stdout);
										if(tc_strcmp(Orginal_Name," ")==0)
										{
											printf("WARNING: No Named Reference File Attached For Item:[%s] & Revision:[%s] with Dataset Type [%s]..!!\n",item_id_str,item_revseq_strDup,SecObjTypeName);
										}
                                        else if(tc_strcmp(object_type,"DirectModel")==0)
										{
											ITK_CALL(AOM_ask_value_string(dataset,"object_name",&Data_Name));
											printf("Data_Name: [%s]\n",Data_Name);fflush(stdout);
											ItemIDChk = tc_strtok(Orginal_Name,".");
											printf("ItemIDChk: [%s]\n",ItemIDChk);fflush(stdout);
											if(tc_strcmp(ItemIDChk,Data_Name)!=0)
											{
												printf("Dataset: [%s] & Name Reference [%s] Different..!!\n",Data_Name,SecObjTypeName);fflush(stdout);
												tc_strcpy(New_Name,"");
												tc_strcat(New_Name,Data_Name);
												tc_strcat(New_Name,".jt");
												printf("New File Name: [%s]\n",New_Name);fflush(stdout);
												/* char* class_name = NULL;
										        tag_t class_id = NULLTAG;
										        ITK_CALL(POM_class_of_instance(RefObject,&class_id));
										        ITK_CALL(POM_name_of_class(class_id,&class_name));
										        printf("\n Class_Name: [%s]\n", class_name);fflush(stdout); */
												
												printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
												ITK_CALL(AOM_refresh(RefObject, POM_modify_lock));
												printf("\n Lock..!!\n");
												ITK_CALL(POM_attr_id_of_attr("original_file_name", class_name, &PropName_AttrID));
												printf("\n Property Tag Found..!!\n");
												ITK_CALL(POM_set_attr_string(1, &RefObject, PropName_AttrID, New_Name));
												printf("\n Set Property Value..!!\n");
												ITK_CALL(POM_save_instances(1, &RefObject, true));
												printf("\n Save...!!\n");
												ITK_CALL(AOM_refresh(RefObject, POM_no_lock));
												printf("\n Unlock..!!\n");
												printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
												
											}
										}
                                        else if(tc_strcmp(object_type,"PDF")==0)
										{
											ITK_CALL(AOM_ask_value_string(dataset,"object_name",&Data_Name));
											ItemIDChk = tc_strtok(Orginal_Name,".");
											if(tc_strcmp(ItemIDChk,Data_Name)!=0)
											{
												printf(" Dataset: [%s] & Name Reference [%s] Different..!!\n",Data_Name,SecObjTypeName);fflush(stdout);
												tc_strcpy(New_Name,"");
												tc_strcat(New_Name,Data_Name);
												tc_strcat(New_Name,".pdf");
												printf("New File Name: [%s]\n",New_Name);fflush(stdout);
												printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
												ITK_CALL(AOM_lock(RefObject));
												printf(" Lock..!!\n");fflush(stdout);
												ITK_CALL(AOM_set_value_string(RefObject, "original_file_name", New_Name));
												printf(" Set Value..!!\n");fflush(stdout);
												ITK_CALL(AOM_save_without_extensions(RefObject));
												printf(" Save..!!\n");fflush(stdout);
												ITK_CALL(AOM_refresh(RefObject,1));
												printf(" Unlock..!!\n");fflush(stdout);
												printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
											}
										}
                                        else
                                        {
											printf(" All OK..!!\n");fflush(stdout);
										}											
									}
								}
                                else
								{
									printf(" WARNING: No Named Reference File Attached For Item:[%s] & Revision:[%s] with Dataset Type [%s]..!!\n",item_id_str,item_revseq_strDup,SecObjTypeName);fflush(stdout);
								}									
							}
						}
						else
						{
							printf(" No Secondary Objects Found on Relation: IMAN_Rendering..!!\n");fflush(stdout);
						}
					}
					printf(" ------- I M A N    R E N D E R I N G   E N D -------\n");fflush(stdout);						
				}
			}
		    else
			{
				printf(" Query Tag Not Found..!!\n");fflush(stdout);
			}
			if(titemobj_results)
			{
				MEM_free(titemobj_results);
			}
            /* if(SecObjTypeName)
            {
				MEM_free(SecObjTypeName);
			}  
            if(RefName)
            {
				MEM_free(RefName);
			} */			 

		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_namedref_update.c
* // ./linkitk -o tm_namedref_update tm_namedref_update.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Correction/tm_namedref_update .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Correction/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Correction/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Correction/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Name_Reference_Correction/SendEmail.sh .
* // tm_namedref_update -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_namedref_update -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_namedref_update -u=loader -p=loader123 -g=dba
*
***************************************************************************/