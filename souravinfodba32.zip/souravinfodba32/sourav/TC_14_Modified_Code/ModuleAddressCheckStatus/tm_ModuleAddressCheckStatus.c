/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Module Address Check Status
*  Description  :   Check Module Address Status After Reading SubModule Address From Input File.
*  File Name    :   tm_ModuleAddressCheckStatus.c
*  Created on   :   Oct 4th, 2024
*  Usage        :   tm_ModuleAddressCheckStatus
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     04/10/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* SubModAddr_Str = NULL;
	char* SubModAddr_StrDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
    int n_valid_rows=0;
	tag_t* valid_rowsTag = NULLTAG;
    int iValCnt = 0;
	char *RptFile = (char *) malloc(70*sizeof(char));
	FILE *fpOutput_file = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Submodule_Address_Status");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			SubModAddr_Str=strtok(Buffer,"^");
			
            if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);	
			if(SubModAddr_StrDup!=NULL)trimwhitespace(SubModAddr_StrDup);
			printf(" Address(SubModAddr_StrDup): [%s]\n",SubModAddr_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {SubModAddr_StrDup};
				//char *cValues[1]  = {"A1A01"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				  printf(" SubModule Address Present in MCC Library..!!\n");fflush(stdout);
				  fprintf(fpOutput_file,"%s,%s\n",SubModAddr_StrDup,"Present");fflush(fpOutput_file);    
				}
                else
                {
				   printf("\n SubModule Address Not Present in MCC Library..!!\n");fflush(stdout);
				   fprintf(fpOutput_file,"%s,%s\n",SubModAddr_StrDup,"Not_Present");fflush(fpOutput_file);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
			} 
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	if(titemobj_results)
	{
	   MEM_free(titemobj_results);
	}
	fclose(fpPart_List);
	fclose(fpOutput_file);	
    printf("\n All Data Written Successfully on the Output File....\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_ModuleAddressCheckStatus.c
* // ./linkitk -o tm_ModuleAddressCheckStatus tm_ModuleAddressCheckStatus.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressCheckStatus/tm_ModuleAddressCheckStatus .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressCheckStatus/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressCheckStatus/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleAddressCheckStatus/usage.txt .
* // ./tm_ModuleAddressCheckStatus -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_ModuleAddressCheckStatus -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/