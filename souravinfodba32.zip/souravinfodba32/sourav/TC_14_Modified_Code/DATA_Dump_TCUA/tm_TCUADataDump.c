/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   POM
*  Description  :   Generate TCUA Data Dump  
*  File Name    :   tm_TCUADataDump.c
*  Created on   :   Dec 9th, 2023
*  Usage        :   tm_TCUADataDump
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     09/12/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ValidateString (char *B)
{
    int i;
    for (i = 0; B[i] != '\0'; i++)
    {
        if (!(B[i] >= 65 && B[i] <= 90) && !(B[i] >= 97 && B[i] <= 122) && !(B[i] >= 44 && B[i] <= 57) && !(B[i] >31 && B[i] <= 32))
        {
            return 0;
        }
    }
       return 1;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	char *RptFile1 = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	FILE *fpOutput_file1 = NULL;
	char *Part_No = NULL;
	char *Part_RevSeq = NULL;
	char *Part_RevSeqDup = NULL;
	char *Part_Rev = NULL;
	char *Part_Seq = NULL;
	char *Part_Owner = NULL;
	char *Part_OwnerDup = NULL;
	char *Part_Group = NULL;
	char *Part_GroupDup = NULL;
	char *Part_Type = NULL;
	char *Part_TypeDup = NULL;
	char *Colour_Ind = NULL;
	char *Colour_IndDup = NULL;
	char *Comp_Code = NULL;
	char *Comp_CodeDup = NULL;
	char *resstatus = (char *) malloc(400*sizeof(char));
	char *Input_File = (char *) malloc(400*sizeof(char));
	int z=0;
	tag_t iteamrev2 = NULLTAG;
	char *Aggr = NULL;
	char *AggrGrp = NULL;
	char *Mod = NULL;
	char *ModGrp = NULL;
	char *Mod_Add = NULL;
	char *modnamestatus = (char *) malloc(400*sizeof(char));
	char *modstatus = (char *) malloc(400*sizeof(char));
	char *Mod_Name = NULL;
	char *Input_ModFile = (char *) malloc(400*sizeof(char));
	tag_t RelationFind4D = NULLTAG;
    tag_t *sec_objects = NULLTAG;
	char *part4dstatus = (char *) malloc(400*sizeof(char));
	tag_t RelationFindRefDfmea = NULLTAG;
    tag_t *sec_refdfmeaobjects = NULLTAG;
	char *partrefdfmeastatus = (char *) malloc(400*sizeof(char));
	char *docstatus = (char *) malloc(400*sizeof(char));
	


    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char *start_limit = NULL;
	char *end_limit = NULL;
	start_limit = ITK_ask_cli_argument("-s=");
	end_limit = ITK_ask_cli_argument("-e=");
	trimwhitespace(start_limit);
	trimwhitespace(end_limit);
	printf(" [1]: Input Starting(start_limit): [%s]\n",start_limit);fflush(stdout);
	printf(" [2]: Input Ending(end_limit): [%s]\n",end_limit);fflush(stdout);
	
	int strtl = 0;
	int endl = 0;
	if (start_limit != NULL)
	{
		strtl = atoi(start_limit);
	}
	if (end_limit != NULL)
	{
		endl = atoi(end_limit);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Text Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"TCUA_DataDump_");
	tc_strcat(RptFile,"From");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,start_limit);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,"To");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,end_limit);
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".txt");
	printf("\n Text Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Text Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating CSV Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"TCUA_DataDump_");
	tc_strcat(RptFile1,"From");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,start_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,"To");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,end_limit);
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".csv");
	printf("\n CSV Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n CSV Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
	fpOutput_file1 = fopen(RptFile1, "w");
	fprintf(fpOutput_file1,"PART_NO, PART_REV, PART_SEQ, PART_OWNER, PART_GROUP, PART_TYPE, COLOUR_INDICATOR, COMP_CODE, STATUS, INPUT_FILE, AGGREGATE, AGGREGATE_GROUP, MODULE, MODULE_GROUP, MODULE_ADDRESS, MODULE_NAME, MODULE_STATUS, INPUT_MODULE_FILE, PART HAS 4D, REF 4D DFMEA, 4D_STATUS\n");fflush(fpOutput_file1); 
	int objtyplen = 1;
	int rlztyplen = 3;
	//int ownUsrlen = 1;
	const char* object_type_data[]={"Design Revision"};
	const char* fnd_lat_ERCRlz_lst=NULL;
	//const char* select_attrs[]={"item_id","item_revision_id","creation_date","last_mod_date","puid"};
	const char* select_attrs[]={"puid","item_revision_id"};
	const char *select_attrs_Item[] = { "item_id" };
	//const char* release_status_data[]={"T5_LcsErcRlzd"};
	const char* release_status_data[]={"T5_LcsWorking","T5_LcsReview","T5_LcsErcRlzd"};
	//const char* owning_user_data[]={"loader"};
	int  rows = 0, columns = 0;
	void ***report;
	char *pQry = "fnd_lat_ERCRlz_lst";
	ITK_CALL(POM_enquiry_create(pQry));
	ITK_CALL(POM_enquiry_add_select_attrs (pQry,"ItemRevision",1,select_attrs));
	ITK_CALL(POM_enquiry_add_select_attrs(pQry, "Item", 1,select_attrs_Item));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"object_type_expr",objtyplen,object_type_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_object_type_in","ItemRevision","object_type",POM_enquiry_in,"object_type_expr"));
 
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr1","ItemRevision", "items_tag", POM_enquiry_equal, "Item", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr2","ItemRevision", "release_status_list", POM_enquiry_equal, "ReleaseStatus", "puid"));
	ITK_CALL(POM_enquiry_set_join_expr(pQry, "join_expr3","ItemRevision", "owning_user", POM_enquiry_equal, "User", "puid"));
 
	ITK_CALL(POM_enquiry_set_string_value (pQry,"release_stat_expr",rlztyplen,release_status_data,POM_enquiry_bind_value));
	ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_rlz_stat_in","ReleaseStatus","name",POM_enquiry_in,"release_stat_expr"));
 
	//ITK_CALL(POM_enquiry_set_string_value (pQry,"own_user_expr",ownUsrlen,owning_user_data,POM_enquiry_bind_value));
	//ITK_CALL(POM_enquiry_set_attr_expr (pQry,"expr_own_user_in","User","user_id",POM_enquiry_in,"own_user_expr"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr","join_expr1", POM_enquiry_and, "join_expr2"));
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr1","combine_expr",POM_enquiry_and,"expr_object_type_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr2","combine_expr1",POM_enquiry_and,"join_expr3"));
	//ITK_CALL(POM_enquiry_set_expr (pQry,"combine_expr3","combine_expr2",POM_enquiry_and,"expr_own_user_in"));
 
	ITK_CALL(POM_enquiry_set_expr (pQry,"expr_AND_expression","combine_expr2",POM_enquiry_and,"expr_rlz_stat_in"));
	ITK_CALL(POM_enquiry_set_where_expr (pQry,"expr_AND_expression"));
 
	ITK_CALL(POM_enquiry_add_order_attr (pQry, "Item", "item_id", POM_enquiry_asc_order));
 
	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_execute(pQry, &rows, &columns, &report));
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_delete(pQry));
	printf(" \n Number of Rows [%d] and Number of Coloumns [%d]\n",rows,columns);fflush(stdout);
	//exit(0);
	if (endl > rows)
	{
		endl = rows;
	}
	if(rows > 0 && strtl < rows)
	{
		for(z=strtl;z < endl; z++)
		{
			//iteamrev2 = titemobj_results[z];
			iteamrev2 = *(tag_t*)(report[z][0]);
			ITK_CALL(AOM_ask_value_string(iteamrev2,"item_id",&Part_No));
			if(Part_No!=NULL)
			{
				ITK_CALL(AOM_ask_value_string(iteamrev2,"item_revision_id",&Part_RevSeq));
				if(tc_strlen(Part_RevSeq)>0)
				{
					tc_strdup(Part_RevSeq,&Part_RevSeqDup);
				}
				Part_Rev=strtok(Part_RevSeqDup,";");
				Part_Seq=strtok(NULL,";");
				
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"owning_user",&Part_Owner));
				if(tc_strlen(Part_Owner)>0)
				{
					tc_strdup(Part_Owner,&Part_OwnerDup);
				}
				else
				{
					tc_strdup("--",&Part_OwnerDup);
					printf("\n Part Owner Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_UIF_ask_value(iteamrev2,"owning_group",&Part_Group));
				if(tc_strlen(Part_Group)>0)
				{
					tc_strdup(Part_Group,&Part_GroupDup);
				}
				else
				{
					tc_strdup("--",&Part_GroupDup);
					printf("\n Part Group ID Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PartType",&Part_Type));
				if(tc_strlen(Part_Type)>0)
				{
					tc_strdup(Part_Type,&Part_TypeDup);
				}
				else
				{
					tc_strdup("--",&Part_TypeDup);
					printf("\n Part Type Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_ColourInd",&Colour_Ind));
				if(tc_strlen(Colour_Ind)>0)
				{
					tc_strdup(Colour_Ind,&Colour_IndDup);
				}
				else
				{
					tc_strdup("--",&Colour_IndDup);
					printf("\n Colour Indicator Value is NULL..!!");fflush(stdout);
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_PrtCatCode",&Comp_Code));
				if(tc_strlen(Comp_Code)>0)
				{
					tc_strdup(Comp_Code,&Comp_CodeDup);
				}
				else
				{
					tc_strdup("--",&Comp_CodeDup);
					printf("\n Comp Code Value is NULL..!!");fflush(stdout);
				}
				if((tc_strcmp(Colour_IndDup,"Y") == 0) && (Comp_CodeDup!=NULL))
				{
					tc_strcpy(resstatus,"OK");
				}
				else
				{
					tc_strcpy(resstatus,"Not_OK");
				}
				if(tc_strcmp(resstatus,"Not_OK") == 0)
				{
					tc_strcpy(Input_File,Part_No);
					tc_strcat(Input_File,"^");
					tc_strcat(Input_File,Part_Rev);
					tc_strcat(Input_File,"^");
					tc_strcat(Input_File,Part_Seq);
					tc_strcat(Input_File,"^");
				}
				else
				{
					tc_strcpy(Input_File,"OK");
				}
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Aggregate",&Aggr));
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_AggregateGroup",&AggrGrp));
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Module",&Mod));
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_Module_Group",&ModGrp));
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_ModuleAddress",&Mod_Add));
				ITK_CALL(AOM_ask_value_string(iteamrev2,"t5_ModuleName",&Mod_Name));
				if(Aggr!=NULL)
			    {
					STRNG_replace_str(Aggr,","," ",&Aggr);
					STRNG_replace_str(Aggr,";"," ",&Aggr);
					STRNG_replace_str(Aggr,"\n"," ",&Aggr);
					STRNG_replace_str(Aggr,"'"," ",&Aggr);
					printf("\n Aggregate Final Value: [%s]\n", Aggr);fflush(stdout);
				}
				if(AggrGrp!=NULL)
			    {
					STRNG_replace_str(AggrGrp,","," ",&AggrGrp);
					STRNG_replace_str(AggrGrp,";"," ",&AggrGrp);
					STRNG_replace_str(AggrGrp,"\n"," ",&AggrGrp);
					STRNG_replace_str(AggrGrp,"'"," ",&AggrGrp);
					printf("\n Aggregate Group Final Value: [%s]\n", AggrGrp);fflush(stdout);
				}
				if(Mod!=NULL)
			    {
					STRNG_replace_str(Mod,","," ",&Mod);
					STRNG_replace_str(Mod,";"," ",&Mod);
					STRNG_replace_str(Mod,"\n"," ",&Mod);
					STRNG_replace_str(Mod,"'"," ",&Mod);
					printf("\n Module Final Value: [%s]\n", Mod);fflush(stdout);
				}
				if(ModGrp!=NULL)
			    {
					STRNG_replace_str(ModGrp,","," ",&ModGrp);
					STRNG_replace_str(ModGrp,";"," ",&ModGrp);
					STRNG_replace_str(ModGrp,"\n"," ",&ModGrp);
					STRNG_replace_str(ModGrp,"'"," ",&ModGrp);
					printf("\n Module Group Final Value: [%s]\n", ModGrp);fflush(stdout);
				}
				if(Mod_Add!=NULL)
			    {
					STRNG_replace_str(Mod_Add,","," ",&Mod_Add);
					STRNG_replace_str(Mod_Add,";"," ",&Mod_Add);
					STRNG_replace_str(Mod_Add,"\n"," ",&Mod_Add);
					STRNG_replace_str(Mod_Add,"'"," ",&Mod_Add);
					printf("\n Module Address Final Value: [%s]\n", Mod_Add);fflush(stdout);
				}
				if(ValidateString(Mod_Name))
				{
				  printf ("Module Name Valid..!!");fflush(stdout);
				  tc_strcpy(modnamestatus,"OK");
				  STRNG_replace_str(Mod_Name,","," ",&Mod_Name);
				  STRNG_replace_str(Mod_Name,";"," ",&Mod_Name);
				  STRNG_replace_str(Mod_Name,"\n"," ",&Mod_Name);
				  STRNG_replace_str(Mod_Name,"'"," ",&Mod_Name);
				  printf("\n Module Name Final Value: [%s]\n", Mod_Name);fflush(stdout);
				}
				else
				{
				  printf ("Module Name In-Valid(JUNK-CHARACTER-FOUND)..!!");fflush(stdout);
				  tc_strcpy(modnamestatus,"Not_OK");
				}
				if(tc_strstr(Part_TypeDup,"M")!=NULL)
				{
					if((tc_strcmp(Part_TypeDup,"M") == 0) || (tc_strcmp(Part_TypeDup,"IM") == 0))
					{
						if((tc_strcmp(modnamestatus,"OK") == 0) && (Aggr!=NULL) && (AggrGrp!=NULL) && (Mod!=NULL) && (ModGrp!=NULL) && (Mod_Add!=NULL) && (Mod_Name!=NULL))
						{
						  tc_strcpy(modstatus,"OK");
						}
						else
						{
						  tc_strcpy(modstatus,"Not_OK");
						}
					}
					else if(tc_strcmp(Part_TypeDup,"CM") == 0)
					{
						if(tc_strcmp(modnamestatus,"OK") == 0)
						{
						  tc_strcpy(modstatus,"OK");
						}
						else
						{
						  tc_strcpy(modstatus,"Not_OK");
						}
					}
					else
					{
						if(tc_strcmp(modnamestatus,"OK") == 0)
						{
						  tc_strcpy(modstatus,"OK");
						}
						else
						{
						  tc_strcpy(modstatus,"Not_OK");
						}
					}
				}
				else
				{
					//if((Mod_Name!=NULL) || (Aggr!=NULL) || (AggrGrp!=NULL) || (Mod!=NULL) || (ModGrp!=NULL) || (Mod_Add!=NULL))
					//if((Mod_Name==NULL) && (Aggr==NULL) && (AggrGrp==NULL) && (Mod==NULL) && (ModGrp==NULL) && (Mod_Add==NULL))
					if((tc_strlen(Mod_Name)>0) || (tc_strlen(Aggr)>0) || (tc_strlen(AggrGrp)>0) || (tc_strlen(Mod)>0) || (tc_strlen(ModGrp)>0) || (tc_strlen(Mod_Add)>0))
					{
						tc_strcpy(modstatus,"Not_OK");
						//tc_strcpy(modstatus,"OK");
					}
					else
					{
						tc_strcpy(modstatus,"OK");
						//tc_strcpy(modstatus,"Not_OK");
					}
				}
				if(tc_strcmp(modstatus,"Not_OK") == 0)
				{
					tc_strcpy(Input_ModFile,Part_No);
					tc_strcat(Input_ModFile,"~");
					tc_strcat(Input_ModFile,Part_Rev);
				    tc_strcat(Input_ModFile,"~");
					tc_strcat(Input_ModFile,Part_Seq);
					tc_strcat(Input_ModFile,"~");
					tc_strcat(Input_ModFile," ");
					tc_strcat(Input_ModFile,"~");
				}
				else
				{
					tc_strcpy(Input_ModFile,"OK");
				}
				
				int sec_count4D	= 0;
				ITK_CALL(GRM_find_relation_type("T5_PartHas4D",&RelationFind4D));
				if(RelationFind4D!=NULLTAG)
				{									
				  printf("\n Sudo Folder Part Has 4D(T5_PartHas4D) Relation Found..!!\n");fflush(stdout);
				  ITK_CALL(GRM_list_secondary_objects_only(iteamrev2, RelationFind4D, &sec_count4D, &sec_objects));
				  printf("\n Total Objects Found(T5_PartHas4D): [%d]\n", sec_count4D);
				  if(sec_count4D > 0)
				  {
					 tc_strcpy(part4dstatus,"OK");
				  }
				  else
				  {
					tc_strcpy(part4dstatus,"Not_OK");
				  }

				}
				else
				{
					tc_strcpy(part4dstatus,"Not_OK");
				}
				
				int sec_countrefdfmea	= 0;
				ITK_CALL(GRM_find_relation_type("T5_PartHasRef4DDfmea",&RelationFindRefDfmea));
				if(RelationFindRefDfmea!=NULLTAG)
				{									
				  printf("\n Sudo Folder Part Has Ref4D Dfmea(T5_PartHasRef4DDfmea) Relation Found..!!\n");fflush(stdout);
				  ITK_CALL(GRM_list_secondary_objects_only(iteamrev2, RelationFindRefDfmea, &sec_countrefdfmea, &sec_refdfmeaobjects));
				  printf("\n Total Objects Found(T5_PartHasRef4DDfmea): [%d]\n", sec_countrefdfmea);
				  if(sec_countrefdfmea > 0)
				  {
					 tc_strcpy(partrefdfmeastatus,"OK");
				  }
				  else
				  {
					tc_strcpy(partrefdfmeastatus,"Not_OK");
				  }

				}
				else
				{
				   tc_strcpy(partrefdfmeastatus,"Not_OK");
				}
				
				if((tc_strcmp(part4dstatus,"OK") == 0) || (tc_strcmp(partrefdfmeastatus,"OK") == 0))
				{
					tc_strcpy(docstatus,"OK");
				}
				else
				{
					tc_strcpy(docstatus,"Not_OK");
				}
				
				printf(" Part Details Start...!!\n");fflush(stdout);
				printf("[1] Part_No: [%s]\n",Part_No);fflush(stdout);
				printf("[2] Part_Rev: [%s]\n",Part_Rev);fflush(stdout);
				printf("[3] Part_Seq: [%s]\n",Part_Seq);fflush(stdout);
				printf("[4] Part_Owner: [%s]\n",Part_OwnerDup);fflush(stdout);
				printf("[5] Part_Group: [%s]\n",Part_GroupDup);fflush(stdout);
				printf("[6] Part_Type: [%s]\n",Part_TypeDup);fflush(stdout);
				printf("[7] Colour_Indicator: [%s]\n",Colour_IndDup);fflush(stdout);
				printf("[8] Comp_Code: [%s]\n",Comp_CodeDup);fflush(stdout);
				printf("[9] Status: [%s]\n",resstatus);fflush(stdout);
				printf("[10] Input File: [%s]\n",Input_File);fflush(stdout);
				printf("[11] Aggregate: [%s]\n",Aggr);fflush(stdout);
				printf("[12] Aggregate_Group: [%s]\n",AggrGrp);fflush(stdout);
				printf("[13] Module: [%s]\n",Mod);fflush(stdout);
				printf("[14] Module_Group: [%s]\n",ModGrp);fflush(stdout);
				printf("[15] Module_Address: [%s]\n",Mod_Add);fflush(stdout);
				printf("[16] Module_Name: [%s]\n",Mod_Name);fflush(stdout);
				printf("[17] Module_Status: [%s]\n",modstatus);fflush(stdout);
				printf("[18] Input_Module_File: [%s]\n",Input_ModFile);fflush(stdout);
				printf("[19] Part_Has_4D: [%s]\n",part4dstatus);fflush(stdout);
				printf("[20] Part_Has_4D_DFMEA: [%s]\n",partrefdfmeastatus);fflush(stdout);
				printf("[21] 4D_Status: [%s]\n",docstatus);fflush(stdout);
				printf(" Part Details End...!!\n");fflush(stdout);
				
				fprintf(fpOutput_file,"%s^%s^%s^\n",Part_No,Part_Rev,Part_Seq);fflush(fpOutput_file);
				fprintf(fpOutput_file1,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",Part_No,Part_Rev,Part_Seq,Part_OwnerDup,Part_GroupDup,Part_TypeDup,Colour_IndDup,Comp_CodeDup,resstatus,Input_File,Aggr,AggrGrp,Mod,ModGrp,Mod_Add,Mod_Name,modstatus,Input_ModFile,part4dstatus,partrefdfmeastatus,docstatus);fflush(fpOutput_file1);
				
				//ifail = (AOM_ask_value_string(iteamrev2,"item_id",&PartID)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				//ifail = (AOM_ask_value_string(iteamrev2,"item_revision_id",&PartRevSeq)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				//ifail = (AOM_UIF_ask_value(iteamrev2,"owning_user",&PartOwner)); if(ifail != 0){ printf("\nError"); fflush(stdout); continue; }
				//printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
            }
            else
            {
				printf("\n Part Number is NULL..!!");fflush(stdout);
			}				
		}
	}
	fprintf(fpOutput_file1,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file1);
	fclose(fpOutput_file); 
	fclose(fpOutput_file1);
	printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_TCUADataDump.c
* // ./linkitk -o tm_TCUADataDump tm_TCUADataDump.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATA_Dump_TCUA/tm_TCUADataDump .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATA_Dump_TCUA/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATA_Dump_TCUA/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/DATA_Dump_TCUA/SendEmail.sh .
* // ./tm_TCUADataDump -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
* // ./tm_TCUADataDump -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -s=0 -e=100000
*
***************************************************************************/