/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Update User's Password  
*  File Name    :   tm_updatepassword.c
*  Created on   :   Nov 12th, 2024
*  Usage        :   tm_updatepassword
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/11/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *user_id_str = NULL;
    char *oldpass_str = NULL;
	char *newpass_str = NULL;
	char *user_id_strDup = NULL;
	char *oldpass_strDup = NULL;
    char *newpass_strDup = NULL;
	FILE *fpPart_List = NULL;
	tag_t user_tag = NULLTAG;
	char* username = NULL;
	char *email_addr  = NULL;
	tag_t person_tag  = NULLTAG;
	char Buffer[MAX_LINE_LENGTH];
	
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t PropName_AttrID1 = NULLTAG;
	tag_t PropName_AttrID2 = NULLTAG;
	int i = 0;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			user_id_str=strtok(Buffer,"^");
			oldpass_str=strtok(NULL,"^");
			newpass_str=strtok(NULL,"^");
			
			if(user_id_str!=NULL)tc_strdup(user_id_str,&user_id_strDup);
			if(oldpass_str!=NULL)tc_strdup(oldpass_str,&oldpass_strDup);
			if(newpass_str!=NULL)tc_strdup(newpass_str,&newpass_strDup);
			
			if(user_id_strDup!=NULL)trimwhitespace(user_id_strDup);
			if(oldpass_strDup!=NULL)trimwhitespace(oldpass_strDup);
			if(newpass_strDup!=NULL)trimwhitespace(newpass_strDup);
			
			printf(" User_ID(user_id_strDup): [%s]\n",user_id_strDup);
			printf(" Old_Password(oldpass_strDup): [%s]\n",oldpass_strDup);
			printf(" New_Password(newpass_strDup): [%s]\n",newpass_strDup);
			
			ITK_CALL(QRY_find2("UserFind",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n UserFind Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"Id"};
				char *cValues[1]  = {user_id_strDup};
				//char *cValues[1]  = {"skk919708"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of User Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				for (i = 0; i < n_itemobj_found; i++)
		        {
					user_tag = titemobj_results[i];
					//if((tc_strcmp(oldpass_strDup," ") !=0) && (tc_strcmp(newpass_strDup," ") !=0)
					if(tc_strcmp(newpass_strDup," ") !=0)
					{
					    printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout);  
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_modify_lock));
						printf("\n Lock..!!\n");
						ITK_CALL(POM_set_password(user_tag, oldpass_strDup, newpass_strDup));
						//ITK_CALL(POM_attr_id_of_attr("password", "POM_user", &PropName_AttrID1));
						//ITK_CALL(POM_attr_id_of_attr("newpassword", "POM_user", &PropName_AttrID2));
						//printf("\n Property Name Tag Found..!!\n");
						//ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID1, newpass_strDup));
						//ITK_CALL(POM_set_attr_string(1, &titemobj_results[i], PropName_AttrID2, newpass_strDup));
						//item_propvalue_strDupInt = atoi(item_propvalue_strDup);
						//ITK_CALL(POM_set_attr_int(1, &titemobj_results[i], PropName_AttrID, item_propvalue_strDupInt));
						printf("\n Set Property Value..!!\n");
						ITK_CALL(POM_save_instances(1, &titemobj_results[i], true));
						printf("\n Save...!!\n");
						ITK_CALL(AOM_refresh(titemobj_results[i], POM_no_lock));
						printf("\n Unlock..!!\n");
						printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");fflush(stdout);
					}
                    else
                    {
						printf("\n New_Password Value NULL..!!");
					}						
				}
			}
		    else
			{
				printf("\n After Query Execution No User Found..!!");fflush(stdout);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_updatepassword.c
* // ./linkitk -o tm_updatepassword tm_updatepassword.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdatePassword/tm_updatepassword .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdatePassword/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdatePassword/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdatePassword/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/UpdatePassword/SendEmail.sh .
* // tm_updatepassword -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_updatepassword -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // tm_updatepassword -u=loader -p=loader123 -g=dba
*
***************************************************************************/