/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Part Usage Report Calling Exe  
*  File Name    :   tm_PartUsgRpt.c
*  Created on   :   Apr 8th, 2024
*  Usage        :   tm_PartUsgRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     08/04/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tc/tc_startup.h>
#include <fclasses/tc_string.h>

int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of Part Applicability Main Function ************* \n");fflush(stdout);
	
	char*	sysCmnd	=	NULL;
	char* PrtStr = ITK_ask_cli_argument( "-Part=");
	char* RevStr = ITK_ask_cli_argument( "-Rev=");
	char* SeqStr = ITK_ask_cli_argument( "-Seq=");
	char* UsrStr = ITK_ask_cli_argument( "-User=");
	char* EmlStr = ITK_ask_cli_argument( "-Email=");
	sysCmnd=(char *) MEM_alloc(400);
	tc_strcpy(sysCmnd,"/user/cvprod/shells/PartUsageRpt/CallingShell.sh ");
	tc_strcat(sysCmnd,PrtStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,RevStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,SeqStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,UsrStr);
	tc_strcat(sysCmnd," ");
	tc_strcat(sysCmnd,EmlStr);
	
	printf("\n Command: [%s]\n",sysCmnd);fflush(stdout);
	system(sysCmnd);
	MEM_free(sysCmnd);
						

	printf("\n*********** End Of Part Applicability Main Function ************* \n");fflush(stdout);	
	return ifail;
}

/***************************************************************************
*
* // ./compile tm_PartUsgRpt.c
* // ./linkitk -o tm_PartUsgRpt tm_PartUsgRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PartAppRpt/tm_PartUsgRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PartAppRpt/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/PartAppRpt/SendEmail.sh .
*
***************************************************************************/