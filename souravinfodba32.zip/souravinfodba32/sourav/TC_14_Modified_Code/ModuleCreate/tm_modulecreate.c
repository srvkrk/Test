/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Module Revision Object After Reading Data From Input File 
*  File Name    :   tm_modulecreate.c
*  Created on   :   Jun 12th, 2024
*  Usage        :   tm_modulecreate
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     12/06/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* Aggr_Str = NULL;
	char* Aggr_StrDup = NULL;
	char* Module_Str = NULL;
	char* Module_StrDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tObjCreate_Input = NULLTAG;
	tag_t tObj_Type = NULLTAG;
	tag_t new_object = NULLTAG;
	tag_t tModuleqryobj = NULLTAG;
	int n_moduleentries = 1;
	int n_moduleitemobj_found = 0;
	tag_t* tmoduleitemobj_results = NULLTAG;
	tag_t taggr_rev = NULLTAG;
	tag_t tmodule_rev = NULLTAG;
	tag_t relation_type;
	tag_t relation_found = NULLTAG;
	tag_t relation_new = NULLTAG;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			Aggr_Str=strtok(Buffer,"^");
			Module_Str=strtok(NULL,"^");
			
            if(Aggr_Str!=NULL)tc_strdup(Aggr_Str,&Aggr_StrDup);
            if(Module_Str!=NULL)tc_strdup(Module_Str,&Module_StrDup);			
			if(Aggr_StrDup!=NULL)trimwhitespace(Aggr_StrDup);
			if(Module_StrDup!=NULL)trimwhitespace(Module_StrDup);
			
			printf(" Aggregate(Aggr_StrDup): [%s]\n",Aggr_StrDup);
			printf(" Module(Module_StrDup): [%s]\n",Module_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryAggr",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryAggr] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {Aggr_StrDup};
				//char *cValues[1]  = {"POWERTRAIN"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryAggr] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" [SubModuleLibraryAggr] Revision Exist So Continue For Module Revision Creation..!!\n");fflush(stdout);
				    taggr_rev = titemobj_results[0];
				    printf("\n ~~~~~~~~ C R E A T I O N   S T A R T ~~~~~~~~\n");fflush(stdout); 
				    ITK_CALL(TCTYPE_find_type("T5_Submdlbmod", NULL, &tObj_Type));
					ITK_CALL(TCTYPE_construct_create_input(tObj_Type, &tObjCreate_Input));
					if(tObjCreate_Input != NULLTAG)
					{
						printf(" Input Tag Not NULL..!!\n");fflush(stdout);
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_name",Module_StrDup));
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"object_desc",Module_StrDup));
						ITK_CALL(AOM_set_value_string(tObjCreate_Input,"item_id",Module_StrDup));
						ITK_CALL(TCTYPE_create_object(tObjCreate_Input, &new_object));
						if(new_object != NULLTAG) 
						{
							printf(" Objects[SubModuleLibraryModule] Revision Created..!! \n");fflush(stdout);
						}
						else
						{
							printf(" Objects[SubModuleLibraryModule] Revision Not Created..!! \n");fflush(stdout);
						}
						ITK_CALL(AOM_save_with_extensions(new_object));
						printf("\n Save...!!\n");
						ITK_CALL(AOM_unlock(new_object));
						printf("\n Unlock..!!\n");
						ITK_CALL(QRY_find2("SubModuleLibraryModule",&tModuleqryobj));
						if(tModuleqryobj != NULLTAG)
						{
							printf("Query[SubModuleLibraryModule] Found Successfully..!!\n");fflush(stdout);
							char *cModuleEntries[1]  = {"ID"};
							char *cModuleValues[1]  = {Module_StrDup};
							//char *cAggrValues[1]  = {"POWERTRAIN"};
							ITK_CALL(QRY_execute(tModuleqryobj, n_moduleentries, cModuleEntries, cModuleValues, &n_moduleitemobj_found, &tmoduleitemobj_results));
							printf("\n -----------------------------------------------\n");fflush(stdout);
							printf("\n No of Objects[SubModuleLibraryModule] Found: [%d]\n",n_moduleitemobj_found);fflush(stdout);
							printf("\n -----------------------------------------------\n");fflush(stdout);
                            if(n_moduleitemobj_found > 0)
				            {
								tmodule_rev = tmoduleitemobj_results[0];
								ITK_CALL(GRM_find_relation_type("T5_Submdlbagrmodrel", &relation_type));
								ITK_CALL(GRM_find_relation(taggr_rev, tmodule_rev, relation_type ,&relation_found));
								if(relation_found)
								{
									printf("\n Relation Already Exist with Same Aggregate and Module Revision \n");fflush(stdout);
								}
								else
								{
									ITK_CALL(GRM_create_relation(taggr_rev, tmodule_rev, relation_type, NULLTAG, &relation_new));
									ITK_CALL(GRM_save_relation(relation_new));
									printf("\n Module Revision Created and Attached with Aggregate Revision");fflush(stdout);
								}
							}
                            else
                            {
								printf(" Module Revision Not Found..!!\n");fflush(stdout);
							}								
						}
						else
						{
						  printf(" Query Tag [SubModuleLibraryModule] NULL..!!\n");fflush(stdout);
						}		
					}
					else
					{
						printf(" Object Create Input Tag NULL..!!\n");fflush(stdout);
					}
					printf("\n ~~~~~~~~ C R E A T I O N   E N D ~~~~~~~~\n");fflush(stdout); 
				}
                else
                {
				   printf(" Aggregate Not Found..!!");fflush(stdout);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryAggr] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			} 
            if(tmoduleitemobj_results)
			{
			   MEM_free(tmoduleitemobj_results);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_modulecreate.c
* // ./linkitk -o tm_modulecreate tm_modulecreate.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleCreate/tm_modulecreate .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleCreate/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleCreate/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/ModuleCreate/usage.txt .
* // ./tm_modulecreate -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_modulecreate -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/
