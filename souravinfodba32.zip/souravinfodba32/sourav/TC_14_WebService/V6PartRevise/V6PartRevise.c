/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   WebService For Part Attached with ERC DML In Designer Working Status Check
*  File Name    :   V6PartRevise.c
*  Created on   :   August 21st, 2024
*  Usage        :   V6PartRevise.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     21/08/2024                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "V6PartRevise.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

/*int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}*/

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* ERC_DML_Part_LC_Details(char* DmlNumber)
{
	tag_t dml_task_rel = NULLTAG;
	int	task_count = 0;
	tag_t *task_tag	= NULL;
    tag_t dml_tag = NULLTAG;
	tag_t rev_tag = NULLTAG;
    tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	char* item_type = NULL;
	int	status_count = 0;
	tag_t* relStatus_list = NULLTAG;
	char* latest_rev_Rel_Status = NULL;
	char* latest_rev_Rel_StatusDup = NULL;
	char *Funresult = (char *) malloc(400*sizeof(char));
			
	ITK_CALL(ITEM_find_item(DmlNumber, &dml_tag));
	if (dml_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Tag Found !!!!!!\n");fflush(stdout);
	}
	ITK_CALL(ITEM_ask_type2(dml_tag, &item_type));
	printf("\n DML Item_Types: [%s] \n",item_type);fflush(stdout);
	//Find the DML-Revision tag.
	//ITK_CALL(ITEM_find_revision(dml_tag,"NR",&dml_rev_tag)) ;
	ITK_CALL(ITEM_ask_latest_rev(dml_tag,&rev_tag)) ;
	if(rev_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Revision Tag Found !!!!!!");fflush(stdout);
	}
	if(TCTYPE_ask_object_type(rev_tag, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n Revision Type: [%s]\n", RevTyp);fflush(stdout);
	if(tc_strcmp(RevTyp,"ChangeRequestRevision")==0)
	{
		WSOM_ask_release_status_list(rev_tag, &status_count, &relStatus_list);
		printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
		if(status_count>0)
		{
			int m = 0;
			for(m = 0; m<status_count; m++)
			{		  
				AOM_ask_value_string(relStatus_list[m],"object_name",&latest_rev_Rel_StatusDup);
				printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
                tc_strcpy(Funresult,latest_rev_Rel_StatusDup);				
			}
		}
		else
		{
			printf("\n Sorry!! No Release Status Found..!!");fflush(stdout);
			tc_strcpy(Funresult,"T5_LcsErcRlzd");
		}
	}
	else
	{
		printf("\n Sorry!! RevType is Not ChangeRequestRevision..!!");fflush(stdout);
		tc_strcpy(Funresult,"T5_LcsErcRlzd");
	}
	
	return Funresult;	
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number with Revision & Sequence> (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    //register int i = 0;
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   //ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
   //fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
-      //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
       //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;

int ns__getItemData(struct soap* soap,char *Input_line_str,struct ns__CharArray1 *aString_test)
{
        int iFail =0;
		int ifail =0;
		int	tt1	= 0;
		char* Print_Report = NULL;
		char**	ReportSetSTR = NULL;
		char *loggedInUser = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/V6PartRevise.txt", "w", stdout);
		char *Input_line_strDup = NULL;
		char* resultstring = NULL;
		resultstring=(char *)MEM_alloc(200);
		char *Part_No_Str = NULL;
		char *RevSeq_Str = NULL;
		char *Rev_Str = NULL;
		char *Seq_Str = NULL;
		char *Part_No_StrDup = NULL;
		char *Rev_StrDup = NULL;
		char *Seq_StrDup = NULL;
		tag_t tQryDesRev = NULL;
		char *To_date_strDup = NULL;
		char *Rq_domain_strDup = NULL;
		int i = 0;
		char *Rev_Seq_strDup = (char *) malloc(400*sizeof(char));
		char *SrcPart_No = NULL;
		char *SrcRevSeq = NULL;
		char *SrcProjCode = NULL;
		char *SrcDesGroup = NULL;
		int	n_reffound = 0;
		int *n_level;
		tag_t *referencers = NULLTAG;
		char **relations =  NULL;
		int j = 0;
		int k = 0;
		tag_t tsk_dml_rel_type = NULLTAG;
		int dmlcnt = 0;
		tag_t *DMLRev =	NULLTAG;
		char *DMLNo = NULL;
		char *DMLType = NULL;
		char* responsestring = NULL;
	    responsestring=(char *)MEM_alloc(200);
		char* responseString1 = NULL;
		responseString1=(char *)MEM_alloc(200);
		tag_t tQryobj = NULLTAG;
		int n_entries = 2;
		int n_Qryobj_found = 0;
		tag_t* tQryobj_results = NULLTAG;
		char* PartDesGroup = NULL;
		PartDesGroup = (char *) malloc(10*sizeof(char));
		char* Info1 = NULL;
		char* Info2 = NULL;
		char* Info3 = NULL;
		char* Info4 = NULL;
		char* Info5 = NULL;
		char* Info6 = NULL;
		char* Info7 = NULL;
		char* Info8 = NULL;
		char* Info9 = NULL;
		char* Info10 = NULL;
		char* Fundesresponse = NULL;
	    Fundesresponse = (char *) malloc(2000*sizeof(char ));

		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);

		trimwhitespace(Input_line_str);
	    if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
	    printf(" [1]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
	    Part_No_Str=strtok(Input_line_strDup,"^");
	    RevSeq_Str=strtok(NULL,"^");
	    printf("\n Part_Number String: [%s]", Part_No_Str);fflush(stdout);
	    printf("\n Part_Rev_Seq String: [%s]", RevSeq_Str);fflush(stdout);
	    Rev_Str=strtok(RevSeq_Str,".");
	    Seq_Str=strtok(NULL,".");

		if((tc_strlen(Part_No_Str)>0) && (tc_strlen(Rev_Str)>0) && (tc_strlen(Rev_Str)>0))
		{
			tc_strdup(Part_No_Str,&Part_No_StrDup);
			tc_strdup(Rev_Str,&Rev_StrDup);
			tc_strdup(Seq_Str,&Seq_StrDup);
		}
		else
		{
			tc_strdup("",&Part_No_StrDup);
			tc_strdup("",&Rev_StrDup);
			tc_strdup("",&Seq_StrDup);
			printf("\n Part Rev-Seq Value is NULL \n");fflush(stdout);
		}
		trimwhitespace(Part_No_StrDup);
		trimwhitespace(Rev_StrDup);
		trimwhitespace(Seq_StrDup);
		printf("\n Part_No Value After Dup & Trim: [%s]\n", Part_No_StrDup);fflush(stdout);
		printf("\n Revision Value After Dup & Trim: [%s]\n", Rev_StrDup);fflush(stdout);
		printf("\n Sequence Value After Dup & Trim: [%s]\n", Seq_StrDup);fflush(stdout);
		
		tc_strcpy(Rev_Seq_strDup,Rev_StrDup);
		tc_strcat(Rev_Seq_strDup,"*");
		tc_strcat(Rev_Seq_strDup,Seq_StrDup);
		printf(" Final: Rev-Seq Value(Rev_Seq_strDup): [%s]\n",Rev_Seq_strDup);
		
		ITK_CALL(QRY_find2("DesignRevision Sequence",&tQryobj));
        printf("\n DesignRevision Sequence Query Tag Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {Rev_Seq_strDup,Part_No_StrDup};
		ITK_CALL(QRY_execute(tQryobj, n_entries, cEntries, cValues, &n_Qryobj_found, &tQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found --------> [%d]\n",n_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_Qryobj_found > 0)
		{
			tQryDesRev = tQryobj_results[0];
			ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_id",&SrcPart_No));
			ITK_CALL(AOM_ask_value_string(tQryDesRev,"item_revision_id",&SrcRevSeq));
			ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_ProjectCode",&SrcProjCode));
			ITK_CALL(AOM_ask_value_string(tQryDesRev,"t5_DesignGrp",&SrcDesGroup));
			printf("Searched Part Details: ----> Part_No: [%s], Part_RevSeq: [%s], Project_Code: [%s], Design_Group: [%s]\n",SrcPart_No,SrcRevSeq,SrcProjCode,SrcDesGroup);fflush(stdout);
			//tc_strcpy(PartDesGroup,"*");
		    //tc_strcat(PartDesGroup,SrcDesGroup);
		    //tc_strcat(PartDesGroup,"*");
			tc_strcpy(PartDesGroup,SrcDesGroup);
			printf(" Final: Design Group(PartDesGroup): [%s]\n",PartDesGroup);
		
			printf("\n Control Object Check STARTED..!!\n");fflush(stdout);
			tag_t tCtrlobj = NULLTAG;
			tag_t* tPathctrlobj_results = NULLTAG;
			int n_pathentries = 4;
			int n_path_ctrlobj_found = 0;
			ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
			printf("\n Control Object Query Tag Found Successfully...!!\n");
			char *cPathEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
			char *cPathValues[4]  = {SrcProjCode,"V6Revconsubsys","V6ReviseCntObj","0"};
			ITK_CALL(QRY_execute(tCtrlobj, n_pathentries, cPathEntries, cPathValues, &n_path_ctrlobj_found, &tPathctrlobj_results));
			printf("\n ----------------------------------- \n");fflush(stdout);
			printf("\n No of Control Object Found: [%d]\n",n_path_ctrlobj_found);fflush(stdout);
			printf("\n ----------------------------------- \n");fflush(stdout);
			if(n_path_ctrlobj_found > 0)
		    {
				printf("\n Control Object Found Against Input Part Project Code..!!\n");fflush(stdout);
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo1", &Info1));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo2", &Info2));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo3", &Info3));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo4", &Info4));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo5", &Info5));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo6", &Info6));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo7", &Info7));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo8", &Info8));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_Userinfo9", &Info9));
				ITK_CALL(AOM_ask_value_string(tPathctrlobj_results[0], "t5_userinfo10", &Info10));
				tc_strcpy(Fundesresponse,Info1);
				tc_strcat(Fundesresponse,Info2);
				tc_strcat(Fundesresponse,Info3);
				tc_strcat(Fundesresponse,Info4);
				tc_strcat(Fundesresponse,Info5);
				tc_strcat(Fundesresponse,Info6);
				tc_strcat(Fundesresponse,Info7);
				tc_strcat(Fundesresponse,Info8);
				tc_strcat(Fundesresponse,Info9);
				tc_strcat(Fundesresponse,Info10);
				printf("\n Concatinated Design Group: --------> [%s]\n",Fundesresponse);fflush(stdout);
				if(tc_strstr(Fundesresponse,PartDesGroup) != NULL)
				{
					ITK_CALL(WSOM_where_referenced(tQryDesRev,1,&n_reffound,&n_level,&referencers,&relations));
					printf("\n -----------------------------------------------\n");fflush(stdout);
					printf("\n No of Reference Found: [%d]\n",n_reffound);fflush(stdout);
					printf("\n -----------------------------------------------\n\n");fflush(stdout);
					if(n_reffound>0)
					{
					    for(j = 0; j < n_reffound; j++)
						{
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							ITK_CALL(GRM_list_primary_objects_only(referencers[j],tsk_dml_rel_type,&dmlcnt,&DMLRev));
							printf("No of Object Found: [%d]\n",dmlcnt);fflush(stdout);
							if(dmlcnt>0)
							{
								for(k = 0; k <dmlcnt; k++)
								{
									ITK_CALL(AOM_ask_value_string(DMLRev[k],"object_type",&DMLType));
									printf("Object_Type: [%s]\n",DMLType);fflush(stdout);
									if(tc_strcmp(DMLType,"ChangeRequestRevision")==0)
									{
										printf("!!!!!! ERC DML Found !!!!!!\n");fflush(stdout);
										ITK_CALL(AOM_ask_value_string(DMLRev[k],"item_id",&DMLNo));
										printf("DML No is:------> [%s]\n",DMLNo);fflush(stdout);
										printf("Function: ERC DML Part LC Details Calling Start\n");fflush(stdout);
										resultstring = ERC_DML_Part_LC_Details(DMLNo);
										printf("Function: ERC DML Part LC Details Calling End\n");fflush(stdout);
										printf("ResultString Before Trim: [%s]\n",resultstring);fflush(stdout);
										trimwhitespace(resultstring);
										printf("ResultString After Trim: [%s]\n",resultstring);fflush(stdout);
										//if(tc_strcmp(resultstring,"In Designer Working") == 0)
										if((tc_strstr(resultstring,"T5_LcsErcRlzd") != NULL) || (tc_strstr(resultstring,"ERC Released") != NULL))
										{
											printf("\n !!!!!! DML LC State[ERC Released] Found, So Jump..!!!!!!\n");fflush(stdout);
											tc_strcpy(responsestring,"FALSE");
											goto jump1;	   
										}
										else
										{
											printf("\n !!!!!! DML LC State[Working or Review] Found, So Jump..!!!!!!\n");fflush(stdout);
											tc_strcpy(responsestring,"TRUE");
											goto jump2;
										}
									}
									else
									{
										printf("ERC DML Not Found, So Continue..!!\n\n");fflush(stdout);
									}
								}
							}
							else
							{
								printf("DML Count Zero[0] Continue..!!\n\n");fflush(stdout);
							}
						}
                        tc_strcpy(responsestring,"FALSE");
						goto jump3;  						
					}
					else
					{
						printf("\n Design Revision Not Attached with Any Task..!!");fflush(stdout);
						tc_strcpy(responsestring,"FALSE");
					}	
				}
				else
				{
					printf("\n Control Object Not Found For Input Part Project Code and Design Group ..!!\n");fflush(stdout);
					tc_strcpy(responsestring,"FALSE");
				}		
			}
			else
			{
				printf("\n Control Object Not Found For Input Part Project Code..!!\n");fflush(stdout);
				tc_strcpy(responsestring,"FALSE");
			}
		}
		else
		{
			printf("\n Entered Part Not Found ..!!\n");fflush(stdout);
			tc_strcpy(responsestring,"FALSE");
		}
		
		jump1:
		     printf("\n !!!!!! DML LC State[ERC Released] Found, In [Jump1] Block..!!!!!!\n");
			 
		jump2:
		     printf("\n !!!!!! DML LC State[Working or Review] Found, In [Jump2] Block..!!!!!!\n");
			 
		jump3:
		     printf("\n !!!!!! DML Not Found in Where_Referenced, In [Jump3] Block..!!!!!!\n");
		
		if(tc_strlen(responsestring)>0)
		{
			printf("\nResponse Already Received, So Skip..!!\n");fflush(stdout);
		}
		else
		{
			printf("\nResponse Not Received, So Copy..!!\n");fflush(stdout);
			tc_strcpy(responsestring,"TRUE");
		}
		printf("\n############################################\n");fflush(stdout);
		printf("\n Part Number: -----> <%s> \n",Part_No_StrDup);fflush(stdout);
		printf("\n Part Revision & Sequence: -----> <%s> \n",Rev_Seq_strDup);fflush(stdout);
		printf("\n Response: ------> <%s> \n",responsestring);fflush(stdout);
		printf("\n############################################\n");fflush(stdout);

        tc_strcpy(responseString1,"STATUS=");
		tc_strcat(responseString1,responsestring);
		setAddStr(&tt1,&ReportSetSTR,responseString1);

		aString_test-> __size =tt1;
		//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
		aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
		int m = 0;
		for(m=0;m<tt1;m++)
		{
			/* aString_test->__ptrItem[m].PROJECT_ID = malloc(30 * sizeof(char *) );
			strcpy(aString_test->__ptrItem[m].PROJECT_ID,responseString1); // PROJECT_ID

			aString_test->__ptrItem[m].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
			strcpy(aString_test->__ptrItem[m].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
			Print_Report = ReportSetSTR[m];
			printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

			aString_test->__ptrDetails[m].PartIDDetails = malloc(500 * sizeof(char *) );
			strcpy(aString_test->__ptrDetails[m].PartIDDetails,Print_Report);

		}
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;
}