/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Rajan Singh
*  Module       :   BOM
*  Description  :   WebService For First Level BOM Details From TCUA CV and PV
*  File Name    :   CmislbUA.c
*  Created on   :   July 15th, 2024
*  Usage        :   CmislbUA.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     15/07/2024                 Rajan Singh
***************************************************************************/

#include "soapH.h"
#include "CmislbUA.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
#define atoa(x) #x
#define MAX_STRINGS 100
#define MAX_LENGTH 200

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

void tostring(char [], int);
void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}
char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -inp=<Creation Date From, Creation Date To & Request Domain > (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

/* void tmSetFindStr(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}

void tmSetAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

} */
char* revseqformat (char* revseqs)
{
	char* revseqstrtk = (char *) malloc(20*sizeof(char));
	char* seq = NULL;
	char* rev = NULL;
	rev=strtok(revseqs,";");
	seq=strtok(NULL,";");
	printf("\n Revision is : [%s]\n", rev);fflush(stdout);
	printf("\n Sequence is: [%s]\n", seq);fflush(stdout);
	tc_strcpy(revseqstrtk,rev);
	tc_strcat(revseqstrtk,"*");
	tc_strcat(revseqstrtk,seq);
    printf("\n Formatted Rev Seq: [%s]\n", revseqstrtk);fflush(stdout);
	return revseqstrtk;
}

/* tag_t revtagfunction(char *item, char *revseqs)
{
		printf("\n GId rev seq is...%s", revseqs);
		char *strtk = NULL;
	 	char *token;
		char rev[10], seq[10];
		token = strtok(revseqs, ";");
		if (token != NULL)
		{
			strcpy(rev, token);
		}
		token = strtok(NULL, ";");
		if (token != NULL)
		{
			strcpy(seq, token);
		}
		printf("Revision is :%s\n", rev);
		printf("Sequence is :%s\n", seq);
		
		//tc_strcpy(strtk,"");
		tc_strcpy(strtk,rev);
		tc_strcat(strtk,"*");
		tc_strcat(strtk,seq);
		
		char *strtk = NULL;
		strtk = revseqformat(revseqs);
		
	
	
	int iFail =0;
	tag_t tItemobjfn = NULLTAG;
	int n_entriesfn = 2;
	int n_itemobj_foundfn = 0;
	tag_t *titemobj_resultsfn = NULLTAG;
	tag_t fnreturn = NULLTAG;
	printf("\n  Gid Part...%s", item);
	printf("\n GId rev seq is...%s", strtk); //RS
	ITK_CALL(QRY_find2("DesignRevision Sequence", &tItemobjfn));
	printf("\n Return Value From ItemRev Query API is --------> %d", iFail);
	fflush(stdout);
	printf("\n ItemRev Query Found Successfully In Function");
	fflush(stdout);
	char *cEntriesfn[2] = {"Revision", "ID"};
	char *cValuesfn[2] = {strtk, item}; //RS
	printf("\n ItemRev Query Found Successfully In function");fflush(stdout);

	// char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
	ITK_CALL(QRY_execute(tItemobjfn, n_entriesfn, cEntriesfn, cValuesfn, &n_itemobj_foundfn, &titemobj_resultsfn));
	printf("\n Return Value From ItemRev Query Execute API is --------> %d", iFail);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
	printf("\n No of Part Found --------> %d\n", n_itemobj_foundfn);fflush(stdout);
	printf("\n -----------------------------------------------\n");fflush(stdout);
	fnreturn = titemobj_resultsfn[0];
	return fnreturn;
} */

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;

int ns__DetailsAll(struct soap* soap,char *Input_line_str,struct ns__CharArray *aString)
{
         int iFail = 0;
	// int i = 0;
	char *cError = NULL;
	char *username = NULL;
	FILE *fpPart_List = NULL;
	char *PNo_Str = NULL;
	char *RevSeq_Str = NULL;
	char *ClosureTimeStamp_Str = NULL;
	freopen("/tmp/CmiUAData.txt", "w", stdout);
	// char* LastUpdate_Str = NULL;
	// char* CreationDate_Str = NULL;
	char *PNo_StrDup = NULL;
	char *RevSeq_StrDup = NULL;
	char *ClosureTimeStamp_StrDup = NULL;
	// char* LastUpdate_StrDup = NULL;
	// char* CreationDate_StrDup = NULL;
	char *Part_Id = NULL;
	char *Rev_Seq = NULL;
	char *PartType = NULL;
	char *PartTypeDup = NULL;
	char *NewPartType = NULL;
	char *NewPartTypeDup = NULL;
	tag_t tuser = NULLTAG;
	tag_t tItemobj = NULLTAG;

	char temp[10000];
	char env_subject[300] = {'\0'};
	char env_body[300] = {'\0'};
	tag_t envelope = NULLTAG;
	tag_t *recievers = NULLTAG;
	int countenvelop = 0;
	int no_ref = 0;
	int j = 0;
	time_t temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char *RptFile = (char *)malloc(400 * sizeof(char));
	FILE *fpOutput_file = NULL;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t *titemobj_results = NULLTAG;

	char *cUSERID = NULL;
	char *cPASS = NULL;
	char *cGroup = NULL;

	char *InpYear = NULL;
	char *InpMonth = NULL;
	char *InpRemainDay = NULL;
	char *InpSeperate = NULL;
	char *InpHour = NULL;
	char *InpMin = NULL;
	char *InpSec = NULL;
	char *InpRemainMinHour = NULL;
	char *InpDay = NULL;
	char *FormatDtRlzd = (char *)malloc(400 * sizeof(char));
	char *Up_dt_rlzd = NULL;
	char *RespMonth = NULL;
	date_t FormatDtRlzd1 = NULLDATE;
	date_t Req_Dt_Rlzd_tag;
	tag_t Stat_tag = NULLTAG;
	tag_t RlzStat_AttrID = NULLTAG;
	char *message;
	char *loggedInUser = NULL;
	int *levels = 0;
	tag_t *parents = NULLTAG;
	tag_t itemrev = NULLTAG;
	char *partType = NULL;
	char *partTypeGId = NULL;

	char *objDescPrt = NULL;
	char *keywordDescPrt = NULL;
	char *qtyPrt = NULL;
	char *partMaterialPrt = NULL;
	char *weightPrt = NULL;
	char *leftPartPrt = NULL;
	char *rightPartPrt = NULL;
	char *rolledUp_weightPrt = NULL;
	char *revseqs = NULL;
	char *revseqGId = NULL;
	char *objDescGId = NULL;
	char *keywordDescGId = NULL;
	tag_t rule = NULLTAG;
	tag_t rule1 = NULLTAG;
	tag_t iteamrev2 = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t fun = NULLTAG;
	tag_t parentTag = NULLTAG;

	int rulefound = 0;
	tag_t *tRevList = NULLTAG;
	tag_t tWindow = NULLTAG;
	tag_t tWindow1 = NULLTAG;
	tag_t tBOMLine = NULLTAG;
	tag_t tBOMLine1 = NULLTAG;
	tag_t tBOMLine2 = NULLTAG;

	char **rulename = NULL;
	char **rulevalue = NULL;

	tag_t *tBOM_Children = NULLTAG;
	tag_t *tBOM_ChildrenGId = NULLTAG;
	int iNumber_Child = 0;
	int iNumber_ChildGId = 0;
	char* responseString = NULL;
	responseString=(char *)MEM_alloc(10000);
	char *Input_line_strDup = NULL;
	int d = 0;
	int fd = dup(fileno(stdout));
	fpos_t pos;
	fgetpos(stdout, &pos);
	
	char ** PartDetailsStrReplicated = NULL;
	int cnt = 0;
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
	fflush(stdout);
	ITK_CALL(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE));
	ITK_CALL(ITK_set_journalling(TRUE));
	status = ITK_auto_login();
	if (status != ITK_ok)
	{
		EMH_ask_error_text(status, &message);
		printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
		MEM_free(message);
		return status;
	}
	else
	{
		printf(" Auto Login Successfull\n");
		fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n", loggedInUser);
		fflush(stdout);
	}
	
	trimwhitespace(Input_line_str);
	if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
    printf(" [1]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
	PNo_Str=strtok(Input_line_strDup,"^");
	RevSeq_Str=strtok(NULL,"^");
		
	printf("\n Part Number String --------> %s", PNo_Str);fflush(stdout);
	printf("\n Revision & Sequence String --------> %s", RevSeq_Str);fflush(stdout);

	if (tc_strlen(PNo_Str) > 0)
	{
		tc_strdup(PNo_Str, &PNo_StrDup);
		tc_strdup(RevSeq_Str, &RevSeq_StrDup);
	}
	else
	{
		tc_strdup("", &PNo_StrDup);
		tc_strdup("", &RevSeq_StrDup);
		printf("\n Part Number & Rev-Seq Value is NULL \n");
		fflush(stdout);
	}
	trimwhitespace(PNo_StrDup);
	trimwhitespace(RevSeq_StrDup);
	printf("\n Part Number Value After Dup & Trim --------> %s\n", PNo_StrDup);fflush(stdout);
	printf("\n Revision & Sequence Value After Dup & Trim --------> %s\n", RevSeq_StrDup);fflush(stdout);

	ITK_CALL(QRY_find2("DesignRevision Sequence", &tItemobj));
	printf("\n Return Value From ItemRev Query API is --------> %d", iFail);fflush(stdout);
		
	if (tItemobj != NULLTAG)
	{
		printf("\n RevSeq_StrDup is...%s", RevSeq_StrDup);fflush(stdout);
		printf("\n PNo_StrDup is -- %s", PNo_StrDup);fflush(stdout);
		printf("\n ItemRev Query Found Successfully...");fflush(stdout);
		char *cEntries[2] = {"Revision", "ID"};
		char *cValues[2] = {RevSeq_StrDup, PNo_StrDup};
		printf("\n ItemRev Query Found Successfully...");fflush(stdout);

		// char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n Return Value From ItemRev Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Part Found --------> [%d]\n", n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		
		if (n_itemobj_found > 0)
		{
			tag_t rev_tags_found = NULLTAG;
			tag_t item_t = NULLTAG;
			int n_tskfund = 0;
			int task = 0;
			size_t len;
			int status_count = 0;
			tag_t *relStatus_list = NULLTAG;
			char *latest_rev_Rel_Status = NULL;
			char *latest_rev_Rel_StatusDup = NULL;
			char *latest_rev_Part_Type = NULL;
			char *PrtShellCommandLine = NULL;
			PrtShellCommandLine = (char *)MEM_alloc(1000 * sizeof(char));
			char *dt_rlzd = NULL;
			char *dt_rlzdDup = NULL;
			rev_tags_found = titemobj_results[0];
			tag_t objTypeRefTag = NULLTAG;
	
			char *ObjectName = NULL;
			char *cLevel = NULL;
			char *cRev_Name = NULL;
			char *cItem_Id = NULL;
			char *cItem_GId = NULL;
			char *qtyGId = NULL;
			char *weightGId = NULL;
			char *partMaterialGId = NULL;
			char *rolledUp_weightGId = NULL;
			char *rightPartGId = NULL;
			char *leftPartGId = NULL;
			char *PartDetails = NULL;
			PartDetails = NULL;
			PartDetails = (char *)MEM_alloc(2000);
			int i = 0;

			if (rev_tags_found != NULLTAG)
			{

				ITK_CALL(BOM_create_window(&tWindow));
				//	printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
				iFail = CFM_find("Latest Working", &rule);
				iFail = BOM_set_window_config_rule(tWindow, rule);

				ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleERC", PIE_TEAMCENTER, &rulefound, &closurerule));
				printf("\n No of Rule Found --------> %d\n", rulefound);fflush(stdout);
				if (rulefound > 0)
				{
					close_tag = closurerule[0];
				}
				ITK_CALL(BOM_window_set_closure_rule(tWindow, close_tag, 0, rulename, rulevalue));
				printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout);

				ITK_CALL(BOM_set_window_top_line(tWindow, NULLTAG, rev_tags_found, NULLTAG, &tBOMLine1));
				ITK_CALL(BOM_window_show_suppressed(tWindow));
				ITK_CALL(AOM_UIF_ask_value(tBOMLine1, "bl_level_starting_0", &cLevel));
				ITK_CALL(AOM_UIF_ask_value(tBOMLine1, "bl_rev_object_name", &cRev_Name));
				ITK_CALL(BOM_line_ask_all_child_lines(tBOMLine1, &iNumber_Child, &tBOM_Children));
				printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
				printf("\n No of Children Found of Main Parent---------> %d\n", iNumber_Child);fflush(stdout);

				if(iNumber_Child > 0)
				{
					d = iNumber_Child;	aString->__size = d;
		            aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );
					
					//char array[MAX_STRINGS][MAX_LENGTH]; // Array to hold strings
					//int num_strings = 0;				 // Current number of strings in the array
					for (i = 0; i < iNumber_Child; i++)
					{
						parentTag = tBOM_Children[i];
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_item_item_id", &cItem_Id));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_PartType", &partType));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_rev_item_revision_id", &revseqs));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_item_object_desc", &objDescPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_CategoryName", &keywordDescPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_quantity", &qtyPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_Weight", &weightPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_Material", &partMaterialPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_RolledupWt", &rolledUp_weightPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_rightPart", &rightPartPrt));
						ITK_CALL(AOM_UIF_ask_value(parentTag, "bl_Design Revision_t5_leftPart", &leftPartPrt));
                        tc_strcpy(responseString," ");
						tc_strcpy(responseString,"Item_id: ");
						tc_strcat(responseString,cItem_Id);
						tc_strcat(responseString," ~Rev_Seq: ");
						tc_strcat(responseString,revseqs);
						tc_strcat(responseString," ~Part_Type: ");
						tc_strcat(responseString,partType);

                        aString->__ptr[i] = (char *) malloc( (10000) * sizeof(char));
                        tc_strcpy(aString->__ptr[i], responseString);						
					}
				}
				else
				{
					printf("\n Child Item Not Found For Input Data..!!");fflush(stdout);
				}
				ITK_CALL(BOM_close_window(tWindow));
				printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
			}
			else
			{
				printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
			}
		}
		else
		{
			printf("\n Item not Found [0]...");fflush(stdout);
		}
	}
	else
	{
		printf("\n Query Tag Not Found...");fflush(stdout);
	}
		
		if (titemobj_results)
		{
		  MEM_free(titemobj_results);
		}
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	return SOAP_OK;
}