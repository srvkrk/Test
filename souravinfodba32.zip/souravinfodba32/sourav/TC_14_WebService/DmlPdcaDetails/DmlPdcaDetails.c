//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
#include "soapH.h"
#include "DmlPdcaDetails.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
	//fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;

char *GetDmlReasonDisplay(char *DmlReasonCode)
{
	char	*Dml_ReasonDisplay			= NULL;

	Dml_ReasonDisplay=(char *)MEM_alloc(200);

	printf("\n Print DmlReasonCode==> [%s]",DmlReasonCode);fflush(stdout);
	if(tc_strcmp(DmlReasonCode,"DR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DR");
		tc_strcpy(Dml_ReasonDisplay,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"AD")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"AD");
		tc_strcpy(Dml_ReasonDisplay,"ALTERNATE SOURCE DEVELOPMENT");
	}
	if(tc_strcmp(DmlReasonCode,"QU")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QU");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY");
	}
	if(tc_strcmp(DmlReasonCode,"CM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CM");
		tc_strcpy(Dml_ReasonDisplay,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT");
	}
	if(tc_strcmp(DmlReasonCode,"RR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RR");
		tc_strcpy(Dml_ReasonDisplay,"REGULATORY REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"CR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CR");
		tc_strcpy(Dml_ReasonDisplay,"COST REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"ATR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ATR");
		tc_strcpy(Dml_ReasonDisplay,"ATTRIBUTE REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"EM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EM");
		tc_strcpy(Dml_ReasonDisplay,"ENGINEERING MATURITY (CAE, STYLING, VALIDATION, PROTO FEEDBACK ETC.)");
	}
	if(tc_strcmp(DmlReasonCode,"DFAF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFAF");
		tc_strcpy(Dml_ReasonDisplay,"DFA FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"DFSF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFSF");
		tc_strcpy(Dml_ReasonDisplay,"DFS FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"DFCF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFCF");
		tc_strcpy(Dml_ReasonDisplay,"DFC FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"CMR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CMR");
		tc_strcpy(Dml_ReasonDisplay,"COMMONIZATION/STANDARDIZATION/COMPLEXITY REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"CSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CSC");
		tc_strcpy(Dml_ReasonDisplay,"CONDITION OF SUPPLY CHANGE");
	}
	if(tc_strcmp(DmlReasonCode,"SC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SC");
		tc_strcpy(Dml_ReasonDisplay,"SCOPE CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"RSP")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSP");
		tc_strcpy(Dml_ReasonDisplay,"RELEASE OF SPARES/KITS (NO NEW PART DEVELOPMENT)");
	}
	if(tc_strcmp(DmlReasonCode,"WR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WR");
		tc_strcpy(Dml_ReasonDisplay,"WEIGHT REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"IFD")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"IFD");
		tc_strcpy(Dml_ReasonDisplay,"INFO-FITMENT DRAWING (IFD)");
	}
	if(tc_strcmp(DmlReasonCode,"ECFR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ECFR");
		tc_strcpy(Dml_ReasonDisplay,"ECU CALIBRATION FILE RELEASE");
	}
	if(tc_strcmp(DmlReasonCode,"SA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SA");
		tc_strcpy(Dml_ReasonDisplay,"SAMPLES TO BE APPROVED");
	}
	if(tc_strcmp(DmlReasonCode,"DFM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFM");
		tc_strcpy(Dml_ReasonDisplay,"DFM");
	}
	if(tc_strcmp(DmlReasonCode,"NR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"NR");
		tc_strcpy(Dml_ReasonDisplay,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
	}
	if(tc_strcmp(DmlReasonCode,"CFL")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CFL");
		tc_strcpy(Dml_ReasonDisplay,"CHANGE IN FEATURE LIST");
	}
	if(tc_strcmp(DmlReasonCode,"RSR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSR");
		tc_strcpy(Dml_ReasonDisplay,"REGULATORY / SAFETY REQUIREMENTS");
	}
	if(tc_strcmp(DmlReasonCode,"DM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DM");
		tc_strcpy(Dml_ReasonDisplay,"DESIGN MATURATION");
	}
	if(tc_strcmp(DmlReasonCode,"SCAS")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SCAS");
		tc_strcpy(Dml_ReasonDisplay,"STYLING SURFACES (CAS)");
	}
	if(tc_strcmp(DmlReasonCode,"EVI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EVI");
		tc_strcpy(Dml_ReasonDisplay,"EVI REPLACEMENTS (BLACK BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"FA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FA");
		tc_strcpy(Dml_ReasonDisplay,"FEATURE ADDITION");
	}
	if(tc_strcmp(DmlReasonCode,"BTSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"BTSC");
		tc_strcpy(Dml_ReasonDisplay,"BTS SUPPLIER CHANGE (GREY BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"DVLO")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DVLO");
		tc_strcpy(Dml_ReasonDisplay,"DVLO ISSUES");
	}
	if(tc_strcmp(DmlReasonCode,"4DCHANGE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"4DCHANGE");
		tc_strcpy(Dml_ReasonDisplay,"4D CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"VCAE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VCAE");
		tc_strcpy(Dml_ReasonDisplay,"VALIDATION / CAE FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"FMPCQRI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FMPCQRI");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICWCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICWCR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"MMDMR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"MMDMR");
		tc_strcpy(Dml_ReasonDisplay,"MODULE MASTER DATA MANAGEMENT REQUEST");
	}
	if(tc_strcmp(DmlReasonCode,"VAC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VAC");
		tc_strcpy(Dml_ReasonDisplay,"VC Attribute Change");
	}
	if(tc_strcmp(DmlReasonCode,"WCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WCR");
		tc_strcpy(Dml_ReasonDisplay,"WARRANTY COST REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"PQ")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"PQ");
		tc_strcpy(Dml_ReasonDisplay,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
	}
	if(tc_strcmp(DmlReasonCode,"QR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QR");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY & RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"FM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FM");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING");
	}
	if(tc_strcmp(DmlReasonCode,"SR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SR");
		tc_strcpy(Dml_ReasonDisplay,"SAFETY REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION");
	}
	printf("\n Print Dml_ReasonDisplay==> [%s]",Dml_ReasonDisplay);fflush(stdout);
	return Dml_ReasonDisplay;
}

int ns__getItemData(struct soap* soap,char *Dml_no,struct ns__CharArray1 *aString_test)
{
        int ifail =0;
		int i,j = 0;
		int n_tags_found = 0;
		int num = 0;
		int d = 0;
		int row = 7;

		tag_t *tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t itemRev_t = NULLTAG;

		char*	dmlNo		= NULL;
		char*	Design_grp		= NULL;
		char **DesignGroupList;

		char*			responseString			= NULL;
		char*			responseString1			= NULL;
		char*			responseString2			= NULL;
		char*			responseString3			= NULL;
		char*			responseString4			= NULL;
		char*			responseString5			= NULL;
		char*			responseString6			= NULL;
		char*			responseString7         = NULL;
		char*			responseString8         = NULL;

		char*          DMLSynops         =NULL;
		char*          DMLProj         =NULL;
		char*          BusUnit         =NULL;
		char*          DMLCretor         =NULL;
		char*          DMLCretordate         =NULL;
		char*          DMLReason         =NULL;
		char*          GetDmlReasonDisplayValue         =NULL;
		date_t  DMLCredate		= NULLDATE;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/DmlPdcaDetails.txt", "w", stdout);
		


		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		



		printf("\n Input .. %s",Dml_no);fflush(stdout);
		if((Dml_no !=NULL) && (tc_strcmp(Dml_no,"")!=0))
		{
			const char *attrs[1];
			const char *values[1];
			attrs[0] ="item_id";
			//attrs[1] ="object_type";
			values[0] = (char *)Dml_no;
			//values[1] = "ERC DML";
			printf("\n values[0] <%s> \n",values[0] );fflush(stdout);

			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

			printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
			if(n_tags_found>0)
			{
				responseString1=(char *)MEM_alloc(200);
				responseString2=(char *)MEM_alloc(200);
				responseString3=(char *)MEM_alloc(200);
				responseString4=(char *)MEM_alloc(200);
				responseString5=(char *)MEM_alloc(200);
				responseString6=(char *)MEM_alloc(200);
				responseString7=(char *)MEM_alloc(200);
				responseString8=(char *)MEM_alloc(200);

				item_t = tags_found[0];
				ITEM_ask_latest_rev(item_t,&itemRev_t);
				//itemRev_t = tags_found[0];
				AOM_ask_value_string(itemRev_t,"item_id",&dmlNo);
				printf("\n dmlNo <%s> \n",dmlNo);fflush(stdout);
				tc_strcpy(responseString1,"DML No:");
				tc_strcat(responseString1,dmlNo);

				AOM_ask_value_strings(itemRev_t,"t5_crdesigngroup",&num,&DesignGroupList);
				if(num > 0)
				{
					for(d=0;d<num;d++)
					{
						printf("\n DesignGroupList2 <%s> \n",DesignGroupList[d]);fflush(stdout);
						Design_grp = DesignGroupList[d];
					}
					printf("\n Design_grp <%s> \n",Design_grp);fflush(stdout);
					tc_strcpy(responseString2,"Design Group:");
					tc_strcat(responseString2,Design_grp);
				}
				AOM_ask_value_string(itemRev_t,"object_name",&DMLSynops);
				printf("\n DMLSynops <%s> \n",DMLSynops);fflush(stdout);
				tc_strcpy(responseString3,"DML Synopsis:"); 
				tc_strcat(responseString3,DMLSynops);

				AOM_ask_value_string(itemRev_t,"t5_cprojectcode",&DMLProj);
				printf("\n DMLProj <%s> \n",DMLProj);fflush(stdout);
				tc_strcpy(responseString4,"Project code:"); 
				tc_strcat(responseString4,DMLProj);

				AOM_ask_value_string(itemRev_t,"t5_ERCBusiUt",&BusUnit);
				printf("\n BusUnit <%s> \n",BusUnit);fflush(stdout);
				tc_strcpy(responseString5,"Bussines Unit:"); 
				tc_strcat(responseString5,BusUnit);

				AOM_ask_value_string(itemRev_t,"requestor_user_id",&DMLCretor);
				printf("\n DMLCretor <%s> \n",DMLCretor);fflush(stdout);
				tc_strcpy(responseString6,"creator:"); 
				tc_strcat(responseString6,DMLCretor);

				AOM_ask_value_date(itemRev_t,"creation_date",&DMLCredate);
				ITK_date_to_string(DMLCredate, &DMLCretordate);
				printf("\n DMLCretordate <%s> \n",DMLCretordate);fflush(stdout);
				tc_strcpy(responseString7,"Creation Date:");
				tc_strcat(responseString7,DMLCretordate);

				AOM_ask_value_string(itemRev_t,"t5_reason",&DMLReason);
				GetDmlReasonDisplayValue = GetDmlReasonDisplay(DMLReason);
				printf("\n GetDmlReasonDisplayValue <%s> \n",GetDmlReasonDisplayValue);fflush(stdout);
				tc_strcpy(responseString8,"Reason Code:"); 
				tc_strcat(responseString8,GetDmlReasonDisplayValue);

				aString_test-> __size =1;
				aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				for(i=0;i<1;i++)
				{
					aString_test->__ptrItem[i].DML_NO = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_NO,responseString1); // DML NO

					aString_test->__ptrItem[i].DESIGN_GRP = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DESIGN_GRP,responseString2); // Design Group

					aString_test->__ptrItem[i].DML_DESC = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_DESC,responseString3); // DML Desc

					aString_test->__ptrItem[i].DML_PRJCODE = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_PRJCODE,responseString4); // DML Project

					aString_test->__ptrItem[i].DML_BU = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_BU,responseString5); // DML Business Unit

					aString_test->__ptrItem[i].DML_CRE = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_CRE,responseString6); // DML Creator

					aString_test->__ptrItem[i].DML_CREDATE = malloc(50 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_CREDATE,responseString7); // DML Creation Date

					aString_test->__ptrItem[i].DML_REASON = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].DML_REASON,responseString8); // DML Reason
				}
			}
		}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

		return SOAP_OK;
}

