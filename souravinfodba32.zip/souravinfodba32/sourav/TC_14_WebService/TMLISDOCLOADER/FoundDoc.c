/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   TMLISDOCUPLOAD.c
*  Author		 :   Sudhir
*  Module		 :   TMLISDOCUPLOAD create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100

#define CONST_MAX_YEAR			 2100
#define CONST_MIN_YEAR			 1975
#define CONST_MAX_MONTH			 11
#define CONST_MIN_MONTH			 0
#define CONST_MIN_DAY			 1
#define CONST_MAX_DAY			 31
#define CONST_MIN_HOUR			 00
#define CONST_MAX_HOUR		     23
#define CONST_MIN_MINUTE		 00
#define CONST_MAX_MINUTE		 59
#define CONST_MIN_SECOND		 00
#define CONST_MAX_SECOND		 59
#define NotLoad		 "/user/bsd05818/sudhir/TMLISDOCLOADER/RevisionExist.txt"
//#define NotLoad		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/TotalExist.txt"
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct func
{
	 char TMLStdNo[100];
	 char TMLStdIssueNo[100];
} tmlisdocobjupload[800000];

static FILE* out_fp;
logical IsValideDate(date_t *date)
{
	logical isFlag		= false;
	date_t  localdate  = NULLDATE;

	localdate = *date;	
	
	//Check if date is null
	if(DATE_IS_NULL(localdate) != 1)
	{
		if(date->year < CONST_MIN_YEAR)
			date->year = CONST_MIN_YEAR;

		if (date->year > CONST_MAX_YEAR)
			date->year = CONST_MAX_YEAR;
		
		if(date->month < CONST_MIN_MONTH)
			date->month = CONST_MIN_MONTH;

		if(date->month > CONST_MAX_MONTH)
			date->month = CONST_MAX_MONTH;

		if(date->day < CONST_MIN_DAY)
			date->day = CONST_MIN_DAY;

		if(date->day > CONST_MAX_DAY)
			date->day = CONST_MAX_DAY;

		if(date->hour < CONST_MIN_HOUR)
			date->hour = CONST_MIN_HOUR;

		if(date->hour > CONST_MAX_HOUR)
			date->hour = CONST_MAX_HOUR;

		if(date->minute < CONST_MIN_MINUTE)
			date->minute = CONST_MIN_MINUTE;

		if(date->minute > CONST_MAX_MINUTE)
			date->minute = CONST_MAX_MINUTE;

		if(date->second < CONST_MIN_SECOND)
			date->second = CONST_MIN_SECOND;

		if(date->second > CONST_MAX_SECOND)
			date->second = CONST_MAX_SECOND;

		//For the months of April, June, September and November, check the date to be less than or equal to 30
		if (date->month == 3 || date->month == 5 || date->month == 8 || date->month == 10)
		{
			if (date->day > 30)
				date->day = 30;
		}

		//For the month of February,
		/////If the year is a leap year, then check the date to be less than or equal to 29
		/////Else, check the date to be less than or equal to 28
		if (date->month == 1)
		{
			if((date->year % 4 == 0 && date->year % 100 != 0) || date->year % 400 == 0)
			{
				if (date->day > 29)
					date->day = 29;
			}
			else
			{
				if (date->day > 28)
					date->day = 28;
			}
		}
		
		//Set the Flag true
		isFlag = true;
	}

	return isFlag;
}

static int TML_token_to_int( const char *str )
{
	return (int) strtol( str, NULL, 10);
}

int PdfUploadFunction(tag_t DocrevTag,char *pdfname,char *pdflocation)
{
	int		ifail			= 0;
	int		iCountSecondary	= 0;
	int		pdfcnt			= 0;
	int		pdfdelete		= 0;

	char *TMLStdDocId		= NULL;
	char *TMLStdDocDesc		= NULL;
	char *pdfdatasetname	= NULL;
	char *format			= NULL;
	char **ref_list;

	tag_t	NewPdfdataset	= NULLTAG;
	tag_t	datasettype		= NULLTAG;
	tag_t	tool			= NULLTAG;
	tag_t	filetag			= NULLTAG;
	tag_t	relation_type	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	*PdfObjects		= NULLTAG;
	tag_t	PdfObject		= NULLTAG;
	tag_t	pdfrel_tag		= NULLTAG;

	logical			checkout = 0;

	IMF_file_t	fileDescriptor;
	AE_reference_type_t	tagRefType = 1;

	int		ref_count;

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	printf("\n PdfUploadFunction::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	AOM_ask_value_string(DocrevTag,"object_desc",&TMLStdDocDesc);
	printf("\n TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n pdfname .......[%s]",pdfname);fflush(stdout);
	printf("\n pdflocation .......[%s]",pdflocation);fflush(stdout);
	pdfdatasetname = strtok(pdfname , ".");
	printf("\nDataset name ---> %s",pdfdatasetname);fflush(stdout);
	if(pdfdatasetname!=NULL)
	{
		format = strtok(NULL , ".");
		printf("\nDataset format Else---->%s",format);fflush(stdout);
	}

	

	if(tc_strcmp(format,"pdf")==0 || tc_strcmp(format,"PDF")==0)
	{
		printf("\n Step 1 --->");fflush(stdout);
		AE_find_datasettype("PDF", &datasettype);
		printf("\n Step 2 --->");fflush(stdout);
		AE_create_dataset_with_id(datasettype,pdfdatasetname,TMLStdDocDesc, NULL, NULL, &NewPdfdataset);
		printf("\n Step 3 --->");fflush(stdout);
		AE_set_dataset_format(NewPdfdataset, "BINARY_REF");
		printf("\n Step 4 --->");fflush(stdout);
		AE_ask_datasettype_def_tool(datasettype, &tool);
		printf("\n Step 5 --->");fflush(stdout);
		AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
		printf("\n Step 6 --->");fflush(stdout);
		IMF_import_file(pdflocation,NULL, SS_BINARY, &filetag, &fileDescriptor);
		printf("\n Step 7 --->");fflush(stdout);
		AOM_save(filetag);
		printf("\n Step 8 --->");fflush(stdout);
		AE_add_dataset_named_ref(NewPdfdataset,ref_list[0],tagRefType,filetag);
		printf("\n Step 9 --->");fflush(stdout);
		AE_set_dataset_tool(NewPdfdataset,tool);
		printf("\n Step 10 --->");fflush(stdout);
		AOM_save(NewPdfdataset);
		printf("\n Step 11 --->");fflush(stdout);

		RES_is_checked_out(DocrevTag,&checkout);
		GRM_find_relation_type("IMAN_Rendering", &relation_type);
		if (checkout==1)
		{
			GRM_list_secondary_objects_only(DocrevTag, relation_type, &iCountSecondary, &PdfObjects);
			printf("\n Step 12 iCountSecondary --->%d",iCountSecondary);fflush(stdout);
		}
		if(iCountSecondary>0)
		{
			for(pdfcnt=0;pdfcnt<iCountSecondary;pdfcnt++)
			{
				PdfObject = PdfObjects[pdfcnt];
				printf("\n Step 13 --->");fflush(stdout);
				GRM_find_relation(DocrevTag, PdfObject, relation_type, &pdfrel_tag);
				printf("\n Step 14 --->");fflush(stdout);
				GRM_delete_relation(pdfrel_tag);
				printf("\n Step 15 --->");fflush(stdout);
				AOM_save(DocrevTag);
				printf("\n Step 16 --->");fflush(stdout);
				pdfdelete++;
			}
			
			
		}
		if(iCountSecondary==0 || pdfdelete>0)
		{
			printf("\n Step 17 --->");fflush(stdout);
			GRM_create_relation(DocrevTag, NewPdfdataset, relation_type, NULLTAG, &relation);
			printf("\n Step 18 --->");fflush(stdout);
			GRM_save_relation(relation);
			printf("\n Step 19 --->");fflush(stdout);
		}
		
		
	}

	return ITK_ok;
}

int TML_Change_Creation_Date(tag_t revTag,date_t mod_date,date_t release_date)
{
	int		iCnt		= 0;
	int		ifail		= 0;
	tag_t	Doc_ModDate = NULLTAG;
	tag_t	Doc_ReleseDate = NULLTAG;

	if(DATE_IS_NULL(mod_date) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 003 \n");fflush(stdout);
		POM_attr_id_of_attr("t5_TSMod_Date", "T5_TMLStdRevision", &Doc_ModDate);
		POM_set_attr_date(1, &revTag, Doc_ModDate, mod_date);
		
		printf("\n Debugging ==> 004 \n");fflush(stdout);

		//ifail = AOM_save(revTag);

		
		
		POM_save_instances(1, &revTag, false);
		

		ifail = AOM_refresh(revTag,false);
		
	}
	if(DATE_IS_NULL(release_date) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 003 \n");fflush(stdout);

		POM_attr_id_of_attr("t5_TSRelDate", "T5_TMLStdRevision", &Doc_ReleseDate);
		POM_set_attr_date(1, &revTag, Doc_ReleseDate, release_date);
		
		printf("\n Debugging ==> 004 \n");fflush(stdout);

		//ifail = AOM_save(revTag);

		
		
		POM_save_instances(1, &revTag, false);
		

		ifail = AOM_refresh(revTag,false);
		
	}

	return ITK_ok;
}

static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;	

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==>%s 000899999 \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{		
		printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;
		
		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==> %d \n",month);fflush(stdout);
		printf("\n day ==> %d \n",day);fflush(stdout);
		printf("\n year ==> %d \n",year);fflush(stdout);
		printf("\n hour ==> %d \n",hour);fflush(stdout);
		printf("\n minute ==> %d \n",minute);fflush(stdout);
		printf("\n second ==> %d \n",second);fflush(stdout);

	}
	printf("\n date ==> %d \n",date);fflush(stdout);
	return date;
}

int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;
	
	tag_t *TMLISDOCUMENTOBJS	    = NULLTAG;
	tag_t TMLISDOCUMENT_tag			= NULLTAG;
	tag_t *t_allrevdocs				= NULLTAG;
	tag_t t_docrev					= NULLTAG;
	tag_t tmlisdocrevobject			= NULLTAG;
	tag_t query						= NULLTAG;
	
	FILE* fptr = NULL;
	
	
	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* argstring1 = NULL;

	char *TMLStdNoDup					= NULL;
	char *TMLStdIssueNoDup				= NULL;
	
	char *TMLStdDocNumber				= NULL;
	char *TMLStdDocRevision				= NULL;
	


	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};
	

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};

	char *FileLocation					= NULL;


	
	
	char	*f	=NULL;
	char	store[80000]  ;

	 int
        n_entries = 2,
        n_tags_found = 0;
        int n_tags_found_other = 0;
		int create_flag = 0;
		int i = 0;
		int cnt = 0;
		int TMLStdSeqValue = 0;
		int TMLStdSeqIdValue = 0;
		int n_tags_found1 = 0;
		int docrevcnt = 0;
		int copyrev = 0;
		int checkoutrev = 0;
		int	c2,c4,c1,elmt1	= 0;
		int	found = 0;
		int	otherFound = 0;
		int	n_rev_entries = 3;

	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");

	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");
	}

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	argstring1 = ITK_ask_cli_argument( "-i=");
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		printf("\n\n\t Login Successfull\n ");fflush(stdout);
		FileLocation=(char *)MEM_alloc(200);
		//tc_strcpy(FileLocation,"/user/infodba01/sudhir/TMLISDOCUPLOAD/");
		
		/*CMITEST*/
		//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
		//tc_strcat(FileLocation,argstring1);

		/*UAPROD*/
		tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
		tc_strcat(FileLocation,argstring1);
		printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
		
		fptr=fopen(FileLocation,"r");
		out_fp=fopen(NotLoad,"a+");
		printf("\n file read .......");fflush(stdout);
		if(fptr!=NULL)
		{
			printf("\n file open .......");fflush(stdout);
		}
		else
		{
			printf("\n file not read .......");fflush(stdout);
		}
		fprintf(out_fp,"TML STD DOC NO~REVISION~AVAILABLE");
		fprintf(out_fp,"\n");


		while(fgets(store, 500000, fptr)!=NULL)
		{
			for (i = 0; i < strlen(store); i++)
			{
				if ( store[i] == '\n' || store[i] == '\r' )
					store[i] = '\0';
			}
			c1  =0; 
			for(i=1; i<=60 && store[c1]!='\0'; i++)
			{ 
				c2=0;
				switch(i)
				{ 
						/*** TMLStdNo ***/
						case 1:					
						for(;store[c1]!='~'; c1++)
						{
							tmlisdocobjupload[elmt1].TMLStdNo[c2]=store[c1];
							c2++;
						}
						tmlisdocobjupload[elmt1].TMLStdNo[c2]='\0';
						printf("\n TMLStdNo IS:%s",tmlisdocobjupload[elmt1].TMLStdNo);fflush(stdout);
						break;
						/*** TMLStdIssueNo ***/
						case 2:					
						for(;store[c1]!='~'; c1++)
						{
							tmlisdocobjupload[elmt1].TMLStdIssueNo[c2]=store[c1];
							c2++;
						}
						tmlisdocobjupload[elmt1].TMLStdIssueNo[c2]='\0';
						printf("\n TMLStdIssueNo IS:%s",tmlisdocobjupload[elmt1].TMLStdIssueNo);fflush(stdout);
						break;
				} // End of Switch case.

				c1++;

			} // End of For Loop.

		   elmt1++;

		} // End of while Loop.

		printf("\n elmt1 .......%d",elmt1);fflush(stdout);

		for(c4=0; c4<elmt1; c4++)
		{
			
				if(tmlisdocobjupload[c4].TMLStdNo) TMLStdNoDup = strdup(tmlisdocobjupload[c4].TMLStdNo);
				if(tmlisdocobjupload[c4].TMLStdIssueNo) TMLStdIssueNoDup = strdup(tmlisdocobjupload[c4].TMLStdIssueNo);
				

				printf("\n TMLStdNoDup .......%s",TMLStdNoDup);fflush(stdout);
				printf("\n TMLStdIssueNoDup .......%s",TMLStdIssueNoDup);fflush(stdout);
				
				
				

				values[0] = TMLStdNoDup;
				values[1] = "T5_TMLStd";
				
				printf("\n values[0] .......[%s]",values[0]);fflush(stdout);
				printf("\n values[1] .......[%s]",values[1]);fflush(stdout);

				ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &TMLISDOCUMENTOBJS);
				printf("\n Number of TMLStd=>%d", n_tags_found);fflush(stdout);
				printf("\n otherFound=>%d", otherFound);fflush(stdout);
				fprintf(out_fp,"\n");
				if(n_tags_found==0)
				{
					fprintf(out_fp,"%s",TMLStdNoDup);
					fprintf(out_fp,"~");
					fprintf(out_fp,"NOT AVAILABLE");
					fprintf(out_fp,"~");
					fprintf(out_fp,"NOT AVAILABLE");
					fprintf(out_fp,"~");
					
				}
				else
				{
					printf("\n in else n_tags_found .......%d",n_tags_found);fflush(stdout);
					for(cnt=0;cnt<n_tags_found;cnt++)
					{
						
						TMLISDOCUMENT_tag = TMLISDOCUMENTOBJS[cnt];

						AOM_ask_value_string(TMLISDOCUMENT_tag,"item_id",&TMLStdDocNumber);
						printf("\n TMLStdDocNumber .......%s",TMLStdDocNumber);fflush(stdout);
						fprintf(out_fp,"%s",TMLStdNoDup);
						fprintf(out_fp,"~");

						qry_values[0] = TMLStdDocNumber;
						qry_values[1] = "TML Std Revision";
						qry_values[2] = TMLStdIssueNoDup;

						QRY_find("Item Revision...", &query);
						if(query!=NULLTAG)
						{
							printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
							printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
							printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
							QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &t_allrevdocs);
						}
						printf("\n n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
						if(n_tags_found1==0)
						{
							ITEM_ask_latest_rev(TMLISDOCUMENT_tag,&tmlisdocrevobject);
							fprintf(out_fp,"NOT REVISION");
							fprintf(out_fp,"~");
							fprintf(out_fp,"REVISION NOT AVAILABLE");
							fprintf(out_fp,"~");
						}
						else
						{
							tmlisdocrevobject = t_allrevdocs[0];
							AOM_ask_value_string(tmlisdocrevobject,"item_revision_id",&TMLStdDocRevision);
							printf("\n TMLStdDocRevision .......%s",TMLStdDocRevision);fflush(stdout);

							if(tc_strcmp(TMLStdDocRevision,TMLStdIssueNoDup)==0)
							{
								fprintf(out_fp,"REVISION AVAILABLE");
								fprintf(out_fp,"~");
								fprintf(out_fp,"AVAILABLE");
								fprintf(out_fp,"~");
							}
						}
					}
				}
		}
		MEM_free(TMLISDOCUMENTOBJS);
	}
	fclose(fptr);
	fclose(out_fp);
	return ITK_ok;
}