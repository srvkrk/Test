/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   TMLISDOCUPLOAD.c
*  Author		 :   Sudhir
*  Module		 :   TMLISDOCUPLOAD create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100

#define CONST_MAX_YEAR			 2100
#define CONST_MIN_YEAR			 1975
#define CONST_MAX_MONTH			 11
#define CONST_MIN_MONTH			 0
#define CONST_MIN_DAY			 1
#define CONST_MAX_DAY			 31
#define CONST_MIN_HOUR			 00
#define CONST_MAX_HOUR		     23
#define CONST_MIN_MINUTE		 00
#define CONST_MAX_MINUTE		 59
#define CONST_MIN_SECOND		 00
#define CONST_MAX_SECOND		 59
#define NotLoad		 "/home/uadev/devgroups/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/Exist.txt"
#define NotLoaded		 "/home/uadev/devgroups/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/Result.txt"
#define RelationNotLoaded		 "/home/uadev/devgroups/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/Relation.txt"
//#define NotLoad		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/ISDATALOAD/Exist.txt"
//#define NotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/ISDATALOAD/Result.txt"
//#define RelationNotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/ISDATALOAD/Relation.txt"
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct func
{
	 char IsStdNo[100];
	 char IsStdIssueNo[100];
	 char IsStdSeq[500];
	 char IsStdInd[500];
	 char IsStdPar[1000];
	 char IsStdSec[1000];
	 char IsStdYear[1000];
	 char Reaffimed[1000];
	 char ISDocumentDescription[1000];
	 char Amendment[1000];
	 char DateRecd[1000];
	 char StdCost[1000];
	 char StdVendor[1000];
	 char StdVendor1[1000];
	 char StdCurrency[200];
	 char OrderDetails[200];
	 char Remarks[200];
	 char SubjCode[200];
	 char SupplNo[1000];
	 char HBRef[1000];
	 char CtrlCpy[1000];
	 char AmmDate[200];
	 char TsRqBy[200];
	 char DocClass[200];
	 char PrintTmlStdDocNumber[1000];
	 char PDFName[200];
	 char pdfdoc_full_path[200];
	 


} isdocobjupload[800000];

static FILE* out_fp;
static FILE* output_fp;
static FILE* output_fp1;
logical IsValideDate(date_t *date)
{
	logical isFlag		= false;
	date_t  localdate  = NULLDATE;

	localdate = *date;	
	
	//Check if date is null
	if(DATE_IS_NULL(localdate) != 1)
	{
		if(date->year < CONST_MIN_YEAR)
			date->year = CONST_MIN_YEAR;

		if (date->year > CONST_MAX_YEAR)
			date->year = CONST_MAX_YEAR;
		
		if(date->month < CONST_MIN_MONTH)
			date->month = CONST_MIN_MONTH;

		if(date->month > CONST_MAX_MONTH)
			date->month = CONST_MAX_MONTH;

		if(date->day < CONST_MIN_DAY)
			date->day = CONST_MIN_DAY;

		if(date->day > CONST_MAX_DAY)
			date->day = CONST_MAX_DAY;

		if(date->hour < CONST_MIN_HOUR)
			date->hour = CONST_MIN_HOUR;

		if(date->hour > CONST_MAX_HOUR)
			date->hour = CONST_MAX_HOUR;

		if(date->minute < CONST_MIN_MINUTE)
			date->minute = CONST_MIN_MINUTE;

		if(date->minute > CONST_MAX_MINUTE)
			date->minute = CONST_MAX_MINUTE;

		if(date->second < CONST_MIN_SECOND)
			date->second = CONST_MIN_SECOND;

		if(date->second > CONST_MAX_SECOND)
			date->second = CONST_MAX_SECOND;

		//For the months of April, June, September and November, check the date to be less than or equal to 30
		if (date->month == 3 || date->month == 5 || date->month == 8 || date->month == 10)
		{
			if (date->day > 30)
				date->day = 30;
		}

		//For the month of February,
		/////If the year is a leap year, then check the date to be less than or equal to 29
		/////Else, check the date to be less than or equal to 28
		if (date->month == 1)
		{
			if((date->year % 4 == 0 && date->year % 100 != 0) || date->year % 400 == 0)
			{
				if (date->day > 29)
					date->day = 29;
			}
			else
			{
				if (date->day > 28)
					date->day = 28;
			}
		}
		
		//Set the Flag true
		isFlag = true;
	}

	return isFlag;
}

static int TML_token_to_int( const char *str )
{
	return (int) strtol( str, NULL, 10);
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

int TMLSTD_CreateRelation_ISDOC(tag_t DocrevTag,char *ReferedStdNumber)
{
	int		ifail			= 0;
	int		tt1				= 0;
	int		tt2				= 0;
	int		sr,sb			= 0;
	int		n_tags_found	= 0;
	int		relcount		= 0;
	int		doc				= 0;
	

	char *TMLStdDocId		= NULL;
	char**	RefStdIsDocSet	= NULL;
	char**	RefStdBRIndSet	= NULL;
	char * pch1				= NULL;
	char * pch2				= NULL;
	char * Doc_Num			= NULL;
	char * Doc_Rev			= NULL;
	char * TempDoc_Rev		= NULL;
	char * Doc_Seq			= NULL;
	char * DocRevId			= NULL;
	char * DocId			= NULL;
	char *ReferedDocNum		= NULL;
	char *ReferedDocBRInd	= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	tag_t	relation_type1	= NULLTAG;
	tag_t	*t_allrevdocs	= NULLTAG;
	tag_t	*AvailObjects	= NULLTAG;
	tag_t	Avail_Object	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	query			= NULLTAG;
	
	//RefStdIsDocSet = (char**)MEM_alloc( 1 * sizeof *RefStdIsDocSet );
	//RefStdBRIndSet = (char**)MEM_alloc( 1 * sizeof *RefStdBRIndSet );

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	
	printf("\n TMLSTD_CreateRelation_ISDOC::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n TMLSTD_CreateRelation_ISDOC::ReferedStdNumber .......[%s]",ReferedStdNumber);fflush(stdout);

	GRM_find_relation_type("T5_TSISR", &relation_type1);

	output_fp1=fopen(RelationNotLoaded,"a+");

	if(tc_strlen(ReferedStdNumber)>0)
	{
		
		pch1 = tc_strtok(ReferedStdNumber,";");
		printf("\n pch1 .......[%s]",pch1);fflush(stdout);
		if(pch1!=NULL)
		{
			setAddStr(&tt1,&RefStdIsDocSet,pch1);
		}
		while(pch1 != NULL)
		{
			pch1 = tc_strtok(NULL, ";");
			printf("\n pch1 .......[%s]",pch1);fflush(stdout);
			if(pch1!=NULL)
			{
				setAddStr(&tt1,&RefStdIsDocSet,pch1);
			}
		}
	}

	printf("\n tt1 .......[%d]",tt1);fflush(stdout);
	if(tt1>0)
	{
		for(sr = 0; sr < tt1; sr++)
		{
			ReferedDocNum = RefStdIsDocSet[sr];
			
			printf("\n ReferedDocNum .......[%s]",ReferedDocNum);fflush(stdout);
			
			if(ReferedDocNum!=NULL)
			{
				Doc_Num = tc_strtok(ReferedDocNum,"-");
				Doc_Rev= tc_strtok(NULL, "-");
				Doc_Seq= tc_strtok(NULL, "-");
				printf("\n Doc_Num .......[%s]",Doc_Num);fflush(stdout);
				printf("\n Doc_Rev .......[%s]",Doc_Rev);fflush(stdout);
				printf("\n Doc_Seq .......[%s]",Doc_Seq);fflush(stdout);
				

				qry_values[0] = Doc_Num;
				qry_values[1] = "TML Std Revision";
				if(tc_strlen(Doc_Rev)>0)
				{
					qry_values[2] = Doc_Rev;
				}

				else
				{
					TempDoc_Rev=(char *)MEM_alloc(10);
					tc_strcpy(TempDoc_Rev,"1");
					qry_values[2] = TempDoc_Rev;
				}

				

				QRY_find("Item Revision...", &query);
				if(query!=NULLTAG)
				{
					if(t_allrevdocs!=NULLTAG) MEM_free(t_allrevdocs); t_allrevdocs = NULLTAG;
					printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
					printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
					printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
					QRY_execute(query, 3, qry_entries, qry_values, &n_tags_found, &t_allrevdocs);
				}
				//ITEM_find_item_revs_by_key_attributes(2,attrs, values,Doc_Rev,&n_tags_found, &t_allrevdocs);
				if(n_tags_found>0)
				{
					GRM_list_primary_objects_only(DocrevTag, relation_type1, &relcount, &AvailObjects);
					if(relcount>0)
					{
						for(doc=0;doc<relcount;doc++)
						{
							Avail_Object = AvailObjects[doc];
							if(Avail_Object!=NULLTAG)
							{
							
								AOM_ask_value_string(Avail_Object,"item_id",&DocId);
								printf("\n TMLSTD_CreateRelation_ISDOC::DocId .......%s",DocId);fflush(stdout);

								AOM_ask_value_string(Avail_Object,"item_revision_id",&DocRevId);
								printf("\n TMLSTD_CreateRelation_ISDOC::DocRevId .......%s",DocRevId);fflush(stdout);
								if(tc_strcmp(DocId,Doc_Num)==0 && tc_strcmp(DocRevId,Doc_Rev)==0)
								{
									printf("\n TMLSTD_CreateRelation_ISDOC::Relation Exist!!");fflush(stdout);
								}
								else
								{
									printf("\n TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
									GRM_create_relation(Avail_Object, DocrevTag, relation_type1, NULLTAG, &relation);
									GRM_save_relation(relation);
									printf("\n TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
								}
							}
						}
					}
					else
					{
						printf("\n ELSE::TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
						Avail_Object = t_allrevdocs[0];
						GRM_create_relation(Avail_Object, DocrevTag, relation_type1, NULLTAG, &relation);
						GRM_save_relation(relation);
						printf("\n ELSE::TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
					}
				}
				else
				{
					printf("\n TML STD DOC is not yet Loaded!!");fflush(stdout);
					fprintf(output_fp1,"%s",Doc_Num);
					fprintf(output_fp1,"~");
					fprintf(output_fp1,"NOT LOADED");
					fprintf(output_fp1,"\n");
				}
				
			}			
		}
	}
	//MEM_free(t_allrevdocs);
	//MEM_free(AvailObjects);
	//MEM_free(RefStdIsDocSet);
	return ITK_ok;
}

int TML_IS_DOC_Result_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;
	char *strSeqIdValue		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_IStd";
	
	printf("\n TML_IS_DOC_Result_Avaialble::ISStdNo .......[%s]",TMLStdNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::ISStdIssueNo .......[%s]",TMLStdIssueNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::ISStdSeq .......[%s]",TMLStdSeq);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);
	strSeqIdValue=(char *)MEM_alloc(200);




	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of T5_IStd=>%d", n_tags_found);fflush(stdout);
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		qry_values[0] = TMLStdNo;
		qry_values[1] = "IS Standard Class Revision";
		qry_values[2] = TMLStdIssueNo;
		QRY_find("All Sequences", &query);
		if(query!=NULLTAG)
		{
			QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			if(n_tags_found1==0)
			{
				fprintf(output_fp,"%s",TMLStdNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);
					sprintf(strSeqIdValue,"%d",SeqIdValue);

					fprintf(output_fp,"%s",TMLStdNo);
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",DocRevision);
					fprintf(output_fp,"~");
					fprintf(output_fp,"REVISION IS LOADED");
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",strSeqIdValue);
					fprintf(output_fp,"~");
					fprintf(output_fp,"\n");
				}
			}
		}
	}
	MEM_free(DOCUMENTOBJS);
	MEM_free(allrevdocs);

	return ITK_ok;
}

int TML_IS_DOC_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_IStd";
	
	printf("\n TML_IS_DOC_Avaialble::values[0] .......[%s]",values[0]);fflush(stdout);
	printf("\n TML_IS_DOC_Avaialble::values[1] .......[%s]",values[1]);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);

	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of TMLStd=>%d", n_tags_found);fflush(stdout);
	//fprintf(output_fp,"TML STD DOC NO~REVISION~STATUS");
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT AVAILABLE");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		for(cnt=0;cnt<n_tags_found;cnt++)
		{
			doc_tag = DOCUMENTOBJS[cnt];
			AOM_ask_value_string(doc_tag,"item_id",&DocNumber);
			printf("\n TML_IS_DOC_Avaialble::DocNumber .......%s",DocNumber);fflush(stdout);
			fprintf(output_fp,"%s",DocNumber);
			fprintf(output_fp,"~");

			qry_values[0] = DocNumber;
			qry_values[1] = "IS Standard Class Revision";
			qry_values[2] = TMLStdIssueNo;

			QRY_find("All Sequences", &query);
			if(query!=NULLTAG)
			{
				printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
				printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
				printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
				QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			}
			printf("\n TML_IS_DOC_Avaialble::n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
			if(n_tags_found1==0)
			{
				//ITEM_ask_latest_rev(doc_tag,&docrevobject);
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);

					if(tc_strcmp(DocRevision,TMLStdIssueNo)==0)
					{
						if(SeqIdValue==DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"LOADED");
						}
						if(SeqIdValue!=DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"NOT LOADED");
							fprintf(output_fp,"~");
						}
					}
				}
			}
		}
	}

	return ITK_ok;
}
int PdfUploadFunction(tag_t DocrevTag,char *pdfname,char *pdflocation)
{
	int		ifail			= 0;
	int		iCountSecondary	= 0;
	int		pdfcnt			= 0;
	int		pdfdelete		= 0;
	int		pdfcount		= 0;

	char *TMLStdDocId		= NULL;
	char *TMLStdDocDesc		= NULL;
	char *pdfdatasetname	= NULL;
	char *format			= NULL;
	char **ref_list;

	tag_t	NewPdfdataset	= NULLTAG;
	tag_t	datasettype		= NULLTAG;
	tag_t	tool			= NULLTAG;
	tag_t	filetag			= NULLTAG;
	tag_t	relation_type	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	*PdfObjects		= NULLTAG;
	tag_t	PdfObject		= NULLTAG;
	tag_t	pdfrel_tag		= NULLTAG;
	tag_t	PdfObject1		= NULLTAG;
	tag_t	relation_type1	= NULLTAG;
	tag_t	pdfrel_tag1		= NULLTAG;
	tag_t	*AvailPdfObjects= NULLTAG;

	logical			checkout = 0;

	IMF_file_t	fileDescriptor;
	AE_reference_type_t	tagRefType = 1;

	int		ref_count;

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	printf("\n PdfUploadFunction::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	AOM_ask_value_string(DocrevTag,"object_desc",&TMLStdDocDesc);
	printf("\n TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n pdfname .......[%s]",pdfname);fflush(stdout);
	printf("\n pdflocation .......[%s]",pdflocation);fflush(stdout);
	pdfdatasetname = strtok(pdfname , ".");
	printf("\nDataset name ---> %s",pdfdatasetname);fflush(stdout);
	if(pdfdatasetname!=NULL)
	{
		format = strtok(NULL , ".");
		printf("\nDataset format Else---->%s",format);fflush(stdout);
	}
	GRM_find_relation_type("IMAN_Rendering", &relation_type1);
	GRM_find_relation(DocrevTag, PdfObject1, relation_type1, &pdfrel_tag1);
	GRM_list_secondary_objects_only(DocrevTag, relation_type1, &pdfcount, &AvailPdfObjects);

	if(pdfcount>0)
	{
		printf("\n PDF IS AVAILABLE");fflush(stdout);
	}
	else
	{
		if(tc_strcmp(format,"pdf")==0 || tc_strcmp(format,"PDF")==0)
		{
			printf("\n Step 1 --->");fflush(stdout);
			AE_find_datasettype("PDF", &datasettype);
			printf("\n Step 2 --->");fflush(stdout);
			AE_create_dataset_with_id(datasettype,pdfdatasetname,TMLStdDocDesc, NULL, NULL, &NewPdfdataset);
			printf("\n Step 3 --->");fflush(stdout);
			AE_set_dataset_format(NewPdfdataset, "BINARY_REF");
			printf("\n Step 4 --->");fflush(stdout);
			AE_ask_datasettype_def_tool(datasettype, &tool);
			printf("\n Step 5 --->");fflush(stdout);
			AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
			printf("\n Step 6 --->");fflush(stdout);
			IMF_import_file(pdflocation,NULL, SS_BINARY, &filetag, &fileDescriptor);
			printf("\n Step 7 --->");fflush(stdout);
			AOM_save(filetag);
			printf("\n Step 8 --->");fflush(stdout);
			AE_add_dataset_named_ref(NewPdfdataset,ref_list[0],tagRefType,filetag);
			printf("\n Step 9 --->");fflush(stdout);
			AE_set_dataset_tool(NewPdfdataset,tool);
			printf("\n Step 10 --->");fflush(stdout);
			AOM_save(NewPdfdataset);
			printf("\n Step 11 --->");fflush(stdout);

			RES_is_checked_out(DocrevTag,&checkout);
			GRM_find_relation_type("IMAN_Rendering", &relation_type);
			if (checkout==1)
			{
				GRM_list_secondary_objects_only(DocrevTag, relation_type, &iCountSecondary, &PdfObjects);
				printf("\n Step 12 iCountSecondary --->%d",iCountSecondary);fflush(stdout);
			}
			if(iCountSecondary>0)
			{
				for(pdfcnt=0;pdfcnt<iCountSecondary;pdfcnt++)
				{
					PdfObject = PdfObjects[pdfcnt];
					printf("\n Step 13 --->");fflush(stdout);
					GRM_find_relation(DocrevTag, PdfObject, relation_type, &pdfrel_tag);
					printf("\n Step 14 --->");fflush(stdout);
					GRM_delete_relation(pdfrel_tag);
					printf("\n Step 15 --->");fflush(stdout);
					AOM_save(DocrevTag);
					printf("\n Step 16 --->");fflush(stdout);
					pdfdelete++;
				}
				
				
			}
			if(iCountSecondary==0 || pdfdelete>0)
			{
				printf("\n Step 17 --->");fflush(stdout);
				GRM_create_relation(DocrevTag, NewPdfdataset, relation_type, NULLTAG, &relation);
				printf("\n Step 18 --->");fflush(stdout);
				GRM_save_relation(relation);
				printf("\n Step 19 --->");fflush(stdout);
			}
			
			
		}
	}
	MEM_free(AvailPdfObjects);

	

	return ITK_ok;
}

int TML_Change_Creation_Date(tag_t revTag,date_t mod_date,date_t release_date)
{
	int		iCnt		= 0;
	int		ifail		= 0;
	tag_t	Doc_ModDate = NULLTAG;
	tag_t	Doc_ReleseDate = NULLTAG;

	if(DATE_IS_NULL(mod_date) == 0)
	{
		if(IsValideDate(&mod_date))
		{
			printf("\n Debugging ==> 003 \n");fflush(stdout);
			ifail = AOM_refresh(revTag,true);
			printf("\n Debugging ==> 003 \n");fflush(stdout);
			POM_attr_id_of_attr("t5_DateRecd", "T5_IStdRevision", &Doc_ModDate);
			POM_set_attr_date(1, &revTag, Doc_ModDate, mod_date);
			printf("\n Debugging ==> 004 \n");fflush(stdout);
			POM_save_instances(1, &revTag, false);
			ifail = AOM_refresh(revTag,false);
		}
	}
	if(DATE_IS_NULL(release_date) == 0)
	{
		if(IsValideDate(&release_date))
		{
			printf("\n Debugging ==> 003 \n");fflush(stdout);
			ifail = AOM_refresh(revTag,true);
			printf("\n Debugging ==> 003 \n");fflush(stdout);
			POM_attr_id_of_attr("t5_AmmDate", "T5_IStdRevision", &Doc_ReleseDate);
			POM_set_attr_date(1, &revTag, Doc_ReleseDate, release_date);
			printf("\n Debugging ==> 004 \n");fflush(stdout);
			POM_save_instances(1, &revTag, false);
			ifail = AOM_refresh(revTag,false);
		}
	}
	return ITK_ok;
}

static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;	

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==>%s 000899999 \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{		
		printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;
		
		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==> %d \n",month);fflush(stdout);
		printf("\n day ==> %d \n",day);fflush(stdout);
		printf("\n year ==> %d \n",year);fflush(stdout);
		printf("\n hour ==> %d \n",hour);fflush(stdout);
		printf("\n minute ==> %d \n",minute);fflush(stdout);
		printf("\n second ==> %d \n",second);fflush(stdout);

	}
	printf("\n date ==> %d \n",date);fflush(stdout);
	return date;
}

char* removeChar(char *str, char garbage) 
{

	int i=0;
    char s[50];
	char *retstr = NULL; 
	retstr=(char *)MEM_alloc(200);
	strcpy( s, str);
	printf("\n 1 FILENAME IS -->[%s]",s);fflush(stdout);
	printf("\n garbage -->[%c]",garbage);fflush(stdout);
    while(s[i]!='\0')
    {
        printf("\n2 FILENAME IS -->[%c]",s[i]);fflush(stdout);
		if(s[i]==garbage)
        {
            s[i]='-';
        }
        i++;
    }  
	printf("\nFILENAME IS -->[%s]",s);fflush(stdout);
	strcpy( retstr, s);
	printf("\nretstr IS -->[%s]",retstr);fflush(stdout);

	return retstr;
}

int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;
	
	
	
	FILE* fptr = NULL;
	FILE* fptr1 = NULL;
	FILE* otherfptr = NULL;
	
	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* argstring1 = NULL;

	int	r = 0;
	int	strcnt = 0;
	int	len = 0;


	char *FileLocation					= NULL;
	char *OtherFileLocation				= NULL;
	char *FileLoc						= NULL;
	char *inputline						= NULL;
	char *TempISStdNoDup				= NULL;
	char *tempfilename					= NULL;
	char *result1					= NULL;
	char *retstr					= NULL;
	char	*f	=NULL;
	//char	result1 [ 100000 ] ;
	char	result2 [ 100000 ] ;
	

	

	

	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");fflush(stdout);

	
	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");fflush(stdout);
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");
	}
	
	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	argstring1 = ITK_ask_cli_argument( "-i=");
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		printf("\n\n\t Login Successfull\n ");fflush(stdout);
		
		FileLoc=(char *)MEM_alloc(200);
		//OtherFileLocation=(char *)MEM_alloc(200);
		
		//tc_strcpy(FileLocation,"/user/infodba01/sudhir/TMLISDOCUPLOAD/");
		
		/*CMITEST*/
		//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
		
		//tc_strcpy(FileLoc,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/ISDATALOAD/");

		/*UAPROD*/
		//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
		//tc_strcpy(FileLoc,"/user/bsd05818/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/");
		tc_strcpy(FileLoc,"/home/uadev/devgroups/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/");

		tc_strcpy(FileLoc,argstring1);
		printf("\n\n\t FileLoc-->[%s]\n",FileLoc);fflush(stdout);

		
		
		fptr1=fopen(FileLoc,"r");
		//out_fp=fopen(NotLoad,"a+");
		if(fptr1!=NULL)
		{
			printf("\n file1 open .......");fflush(stdout);
		}
		else
		{
			printf("\n file1 not read .......");fflush(stdout);
		}
		if(fptr1!=NULL)
		{
			if(inputline)MEM_free(inputline);
			inputline=(char *) MEM_alloc(50000);
			while(fgets(inputline,50000,fptr1)!=NULL)
			{
				for(r=0;r< strlen(inputline);r++)
				{
					if(inputline[r] == '\n' || inputline[r] == '\r' )
					{
						inputline[r] = '\0';
					}
				}
				while(1)
				{
					f = strstr(inputline,",,");
					if(f==NULL)
					{
						break;
					}

					strcpy(result2,f+1);					
					*(f+1)=' ';
					*(f+2)='\0';
					strcat(f,result2);
				}
				result1=(char *) MEM_alloc(200);
				strcpy(result1,inputline);
				printf("\n inputline .......%s\n",result1);fflush(stdout);
				//if(TempISStdNoDup)MEM_free(TempISStdNoDup);
				TempISStdNoDup=(char *)MEM_alloc(200);
				retstr=(char *)MEM_alloc(200);
				if(tempfilename!=NULL) MEM_free(tempfilename); tempfilename = NULL;
				tempfilename=(char *)MEM_alloc(200);
				//if(FileLocation)MEM_free(FileLocation);
				FileLocation=(char *)MEM_alloc(200);
				tc_strcpy(TempISStdNoDup,result1);
				printf("\n TempISStdNoDup .......%s\n",TempISStdNoDup);fflush(stdout);
				len = tc_strlen(TempISStdNoDup);
				char str[len+1];
				strcpy(str, TempISStdNoDup);
				str[len+1] = '\0';
				char *broken = strtok(str, "#");
				printf("\n broken .......%s\n",broken);fflush(stdout);
				for(strcnt=0;strcnt<len;strcnt++)
				{
					printf("\n str[strcnt] .......[%c]\n",str[strcnt]);fflush(stdout);
					if(str[strcnt]=='\n')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==' ')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='/')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='\\')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='\0')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==',')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==';')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='.')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='&')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='(')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==')')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='-')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='\"')
					{
						str[strcnt]='-';
					}

				}
				strcpy( tempfilename, str);
				printf("\n tempfilename .......[%s]\n",tempfilename);fflush(stdout);

				//tc_strcpy(tempfilename,"");
				/*
				if(tc_strstr(TempISStdNoDup,"\n")!=NULL)
				{
					printf("\n For New Line-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, '\n');
				}
				else if(tc_strstr(TempISStdNoDup," ")!=NULL)
				{
					printf("\n For Space-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, ' ');
					tempfilename = removeChar(tempfilename, '.');
					tempfilename = removeChar(tempfilename, '/');
				}
				else if(tc_strstr(TempISStdNoDup,"/")!=NULL)
				{
					printf("\n For FSlash-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, '/');
				}
				else if(tc_strstr(TempISStdNoDup,"\\")!=NULL)
				{
					printf("\n For BSlash-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, '\\');
				}
				else if(tc_strstr(TempISStdNoDup,"\0")!=NULL)
				{
					printf("\n For ExtraCHar-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, '\0');
				}
				else if(tc_strstr(TempISStdNoDup,";")!=NULL)
				{
					printf("\n For SEMICOLON-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, ';');
				}
				else if(tc_strstr(TempISStdNoDup,",")!=NULL)
				{
					printf("\n For COMMA-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, ',');
				}
				else if(tc_strstr(TempISStdNoDup,".")!=NULL)
				{
					printf("\n For DOT-->");fflush(stdout);
					tempfilename = removeChar(TempISStdNoDup, '.');
				}
				else 
				{
					printf("\n For NOTHING-->");fflush(stdout);
					tc_strcpy(tempfilename,result1);
				}
				*/
				MEM_free(TempISStdNoDup);

				printf("\n\n\t tempfilename-->[%s]\n",tempfilename);fflush(stdout);
				//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/ITMLISDOCLOADER/ISDATALOAD/");
				//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/");
				tc_strcpy(FileLocation,"/home/uadev/devgroups/sudhir/TMLISDOCLOADER_AferDeployment/ISDATALOAD_AferDeployment/");
				tc_strcat(FileLocation,tempfilename);
				tc_strcat(FileLocation,".txt");
				printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
				//MEM_free(tempfilename);
				
				fptr=fopen(FileLocation,"r");
				//MEM_free(FileLocation);
				if(fptr!=NULL)
				{
					
					int elmt1 = 0;
					int	otherFound = 0;
					int create_flag = 0;
					int copyrev = 0;
					int checkoutrev = 0;
					int ISStdSeqValue = 0;
					int ISStdSeqIdValue = 0;
					char	store[80000]  ;

					 int
						n_entries = 2,
						n_tags_found = 0;
						int n_tags_found_other = 0;
						
						int i = 0;
						int cnt = 0;
						
						int n_tags_found1 = 0;
						int docrevcnt = 0;
						
						int	c2,c4,c1	= 0;
						int	found = 0;
						
						int	n_rev_entries = 3;
						
						int	c5= 0;

					tag_t *ISDOCUMENTOBJS			= NULLTAG;
					tag_t *otherobjects			    = NULLTAG;
					tag_t ISStd_type_tag			= NULLTAG;
					tag_t ISStd_type_Revtag			= NULLTAG;
					tag_t object_create_input_tag   = NULLTAG;
					tag_t object_create_input_revtag= NULLTAG;
					tag_t new_isdocobject			= NULLTAG;
					tag_t new_isdocrevobject		= NULLTAG;
					tag_t ISDOCUMENT_tag			= NULLTAG;
					tag_t *t_allrevdocs				= NULLTAG;
					tag_t t_docrev					= NULLTAG;
					tag_t new_rev_tag				= NULLTAG;
					tag_t attr_id					= NULLTAG;
					tag_t isdocrevobject			= NULLTAG;
					tag_t FoundTag					= NULLTAG;
					tag_t query						= NULLTAG;
					tag_t TMLStdquery				= NULLTAG;


					char *IsStdNoDup					= NULL;
					char *IsStdIssueNoDup				= NULL;
					char *IsStdSeqDup					= NULL;
					char *IsStdIndDup					= NULL;
					char *IsStdParDup					= NULL;
					char *IsStdSecDup					= NULL;
					char *IsStdYearDup					= NULL;
					char *ReaffimedDup					= NULL;
					char *ISDocumentDescriptionDup		= NULL;
					char *AmendmentDup					= NULL;
					char *DateRecdDup					= NULL;
					char *StdCostDup					= NULL;
					char *StdVendorDup					= NULL;
					char *StdVendor1Dup					= NULL;
					char *StdCurrencyDup				= NULL;
					char *OrderDetailsDup				= NULL;
					char *RemarksDup					= NULL;
					char *SubjCodeDup					= NULL;
					char *SupplNoDup					= NULL;
					char *HBRefDup						= NULL;
					char *CtrlCpyDup					= NULL;
					char *AmmDateDup					= NULL;
					char *TsRqByDup						= NULL;
					char *PrintTmlStdDocNumberDup		= NULL;
					char *PDFNameDup					= NULL;
					char *pdfdoc_full_pathDup			= NULL;
					char *DocClassDup					= NULL;

					char *IsStdNo_Dup					= NULL;
					char *IsStdIssueNo_Dup				= NULL;
					char *IsStdSeq_Dup					= NULL;
					char *IsStdInd_Dup					= NULL;
					char *IsStdPar_Dup					= NULL;
					char *IsStdSec_Dup					= NULL;
					char *IsStdYear_Dup					= NULL;
					char *Reaffimed_Dup					= NULL;
					char *ISDocumentDescription_Dup		= NULL;
					char *Amendment_Dup					= NULL;
					char *DateRecd_Dup					= NULL;
					char *StdCost_Dup					= NULL;
					char *StdVendor_Dup					= NULL;
					char *StdVendor1_Dup				= NULL;
					char *StdCurrency_Dup				= NULL;
					char *OrderDetails_Dup				= NULL;
					char *Remarks_Dup					= NULL;
					char *SubjCode_Dup					= NULL;
					char *SupplNo_Dup					= NULL;
					char *HBRef_Dup						= NULL;
					char *CtrlCpy_Dup					= NULL;
					char *AmmDate_Dup					= NULL;
					char *TsRqBy_Dup					= NULL;
					char *PrintTmlStdDocNumber_Dup		= NULL;
					char *PDFName_Dup					= NULL;
					char *pdfdoc_full_path_Dup			= NULL;
					char *DocClass_Dup					= NULL;
					
					char *ISStdDocNumber				= NULL;
					char *ISStdDocRevision				= NULL;
					char *ISStdIssueRev				= NULL;
					char *revi							= NULL;
					char *TempTMDelIndDup				= NULL;
					char *TempTMRemarkDup				= NULL;
					char *ISStdDocSequenceId			= NULL;
					char *FoundObj_ItemId				= NULL;
					char *FoundObj_Type					= NULL;

					char * pch;
					char *PrintISStdDocNumbers			= NULL;
					char *PrintISStdDocNumber			= NULL;
					char *TempISDocumentDescriptionDup	= NULL;
					char *ISStdDocNumberDup	= NULL;
					char *IsStdIssueNo	= NULL;
					

					const char	   reason;
					const char     change_id;
					const char     dir_name;

					date_t  ISDateRecd	= NULLDATE;
					date_t  ISAmmDate	= NULLDATE;


					char
						*attrs[2] = {"ID","Type"},
						*values[2]	= {"*","*"};
					
						const char
						*otherattrs[1] = {"item_id"},
						*othervalues[1]	= {"*"};

					const char
						*attrs1[2] = {"item_id","object_type"},
						*values1[2]	= {"*","*"};

					char
						*qry_entries[3] = {"Item ID","Type","Revision"},
						*qry_values[3]	= {"*","*","*"};
					printf("\n file open .......%d",elmt1);fflush(stdout);

					char	*ft	=NULL;
					char	*input_line	=NULL;
					char	result1t [ 100000 ] ;
					char	result2t [ 100000 ] ;
					input_line=(char *) MEM_alloc(500000);

					while(fgets(input_line, 500000, fptr)!=NULL)
					{
						for (i = 0; i < strlen(input_line); i++)
						{
							if ( input_line[i] == '\n' || input_line[i] == '\r' )
								input_line[i] = '\0';
						}
						while(1)
						{
							ft = strstr(input_line,",,");
							if(ft==NULL)
							{
								break;
							}

							strcpy(result2t,ft+1);					
							*(ft+1)=' ';
							*(ft+2)='\0';
							strcat(ft,result2t);
						}
						strcpy(result1t,input_line);
						printf("\n inputline .......%s\n",result1t);fflush(stdout);
						fputs(result1t,stdout);
						IsStdNo_Dup=tc_strtok(result1t,"~");
						IsStdIssueNo_Dup=tc_strtok(NULL,"~");
						IsStdSeq_Dup=tc_strtok(NULL,"~");
						IsStdInd_Dup=tc_strtok(NULL,"~");
						IsStdPar_Dup=tc_strtok(NULL,"~");
						IsStdSec_Dup=tc_strtok(NULL,"~");
						IsStdYear_Dup=tc_strtok(NULL,"~");
						Reaffimed_Dup=tc_strtok(NULL,"~");
						ISDocumentDescription_Dup=tc_strtok(NULL,"~");
						Amendment_Dup=tc_strtok(NULL,"~");
						DateRecd_Dup=tc_strtok(NULL,"~");
						StdCost_Dup=tc_strtok(NULL,"~");
						StdVendor_Dup=tc_strtok(NULL,"~");
						StdVendor1_Dup=tc_strtok(NULL,"~");
						StdCurrency_Dup=tc_strtok(NULL,"~");
						OrderDetails_Dup=tc_strtok(NULL,"~");
						Remarks_Dup=tc_strtok(NULL,"~");
						SubjCode_Dup=tc_strtok(NULL,"~");
						SupplNo_Dup=tc_strtok(NULL,"~");
						HBRef_Dup=tc_strtok(NULL,"~");
						CtrlCpy_Dup=tc_strtok(NULL,"~");
						AmmDate_Dup=tc_strtok(NULL,"~");
						TsRqBy_Dup=tc_strtok(NULL,"~");
						DocClass_Dup=tc_strtok(NULL,"~");
						PrintTmlStdDocNumber_Dup=tc_strtok(NULL,"~");
						PDFName_Dup=tc_strtok(NULL,"~");
						pdfdoc_full_path_Dup=tc_strtok(NULL,"~");

						if(IsStdNo_Dup)IsStdNoDup = strdup(IsStdNo_Dup);
						if(IsStdIssueNo_Dup)IsStdIssueNoDup = strdup(IsStdIssueNo_Dup);
						if(IsStdSeq_Dup)IsStdSeqDup = strdup(IsStdSeq_Dup);
						if(IsStdPar_Dup)IsStdParDup = strdup(IsStdPar_Dup);
						if(IsStdSec_Dup)IsStdSecDup = strdup(IsStdSec_Dup);
						if(IsStdYear_Dup)IsStdYearDup = strdup(IsStdYear_Dup);
						if(Reaffimed_Dup)ReaffimedDup = strdup(Reaffimed_Dup);
						if(ISDocumentDescription_Dup)ISDocumentDescriptionDup = strdup(ISDocumentDescription_Dup);
						if(Amendment_Dup)AmendmentDup = strdup(Amendment_Dup);
						if(DateRecd_Dup)DateRecdDup = strdup(DateRecd_Dup);
						if(StdCost_Dup)StdCostDup = strdup(StdCost_Dup);
						if(StdVendor_Dup)StdVendorDup = strdup(StdVendor_Dup);
						if(StdVendor1_Dup)StdVendor1Dup = strdup(StdVendor1_Dup);
						if(StdCurrency_Dup)StdCurrencyDup = strdup(StdCurrency_Dup);
						if(OrderDetails_Dup)OrderDetailsDup = strdup(OrderDetails_Dup);
						if(Remarks_Dup)RemarksDup = strdup(Remarks_Dup);
						if(SubjCode_Dup)SubjCodeDup = strdup(SubjCode_Dup);
						if(SupplNo_Dup)SupplNoDup = strdup(SupplNo_Dup);
						if(HBRef_Dup)HBRefDup = strdup(HBRef_Dup);
						if(CtrlCpy_Dup)CtrlCpyDup = strdup(CtrlCpy_Dup);
						if(AmmDate_Dup)AmmDateDup = strdup(AmmDate_Dup);
						if(TsRqBy_Dup)TsRqByDup = strdup(TsRqBy_Dup);
						if(DocClass_Dup)DocClassDup = strdup(DocClass_Dup);
						if(PrintTmlStdDocNumber_Dup)PrintTmlStdDocNumberDup = strdup(PrintTmlStdDocNumber_Dup);
						if(PDFName_Dup)PDFNameDup = strdup(PDFName_Dup);
						if(pdfdoc_full_path_Dup)pdfdoc_full_pathDup = strdup(pdfdoc_full_path_Dup);

						printf("\n IsStdNoDup .......%s",IsStdNoDup);fflush(stdout);
						printf("\n IsStdIssueNoDup .......%s",IsStdIssueNoDup);fflush(stdout);
						printf("\n IsStdSeqDup .......%s",IsStdSeqDup);fflush(stdout);
						printf("\n IsStdIndDup .......%s",IsStdIndDup);fflush(stdout);
						printf("\n IsStdParDup .......%s",IsStdParDup);fflush(stdout);
						printf("\n IsStdSecDup .......%s",IsStdSecDup);fflush(stdout);
						printf("\n IsStdYearDup .......%s",IsStdYearDup);fflush(stdout);
						printf("\n ReaffimedDup .......%s",ReaffimedDup);fflush(stdout);
						printf("\n ISDocumentDescriptionDup .......%s",ISDocumentDescriptionDup);fflush(stdout);
						printf("\n AmendmentDup .......%s",AmendmentDup);fflush(stdout);
						printf("\n DateRecdDup .......%s",DateRecdDup);fflush(stdout);
						printf("\n StdCostDup .......%s",StdCostDup);fflush(stdout);
						printf("\n StdVendorDup .......%s",StdVendorDup);fflush(stdout);
						printf("\n StdVendor1Dup .......%s",StdVendor1Dup);fflush(stdout);
						printf("\n StdCurrencyDup .......%s",StdCurrencyDup);fflush(stdout);
						printf("\n OrderDetailsDup .......%s",OrderDetailsDup);fflush(stdout);
						printf("\n RemarksDup .......%s",RemarksDup);fflush(stdout);
						printf("\n SubjCodeDup .......%s",SubjCodeDup);fflush(stdout);
						printf("\n SupplNoDup .......%s",SupplNoDup);fflush(stdout);
						printf("\n HBRefDup .......%s",HBRefDup);fflush(stdout);
						printf("\n CtrlCpyDup .......%s",CtrlCpyDup);fflush(stdout);
						printf("\n AmmDateDup .......%s",AmmDateDup);fflush(stdout);
						printf("\n TsRqByDup .......%s",TsRqByDup);fflush(stdout);
						printf("\n DocClassDup .......%s",DocClassDup);fflush(stdout);
						printf("\n PrintTmlStdDocNumberDup .......%s",PrintTmlStdDocNumberDup);fflush(stdout);
						printf("\n PDFNameDup .......%s",PDFNameDup);fflush(stdout);
						printf("\n pdfdoc_full_pathDup .......%s",pdfdoc_full_pathDup);fflush(stdout);

						if(tc_strcmp(ISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)>128)
						{
							TempISDocumentDescriptionDup=subString(ISDocumentDescriptionDup,0,127);
						}

						if(tc_strcmp(DateRecdDup,"null")!=0)
						{
							ISDateRecd  = TML_token_to_date( DateRecdDup );
						}
						if(tc_strcmp(AmmDateDup,"null")!=0)
						{
							ISAmmDate  = TML_token_to_date( AmmDateDup );
						}

						if(tc_strlen(IsStdIndDup)==0)
						{
							IsStdIndDup = "NA";
						}

						ISStdSeqValue=TML_token_to_int(IsStdSeqDup);
						printf("\n ISStdSeqValue .......%d",ISStdSeqValue);fflush(stdout);

						values[0] = IsStdNoDup;
						values[1] = "IS Standard Class";
						QRY_find("tm_IStdDoc", &TMLStdquery);
						if(TMLStdquery!=NULLTAG)
						{
							printf("\n values[0] .......%s",values[0]);fflush(stdout);
							printf("\n values[1] .......%s",values[1]);fflush(stdout);
							
							QRY_execute(TMLStdquery, 2, attrs, values, &n_tags_found, &ISDOCUMENTOBJS);
						}
						printf("\n Number of n_tags_found=>%d", n_tags_found);fflush(stdout);
						if(n_tags_found==0)							
						{
							create_flag = 0;
							ITK_CALL(TCTYPE_find_type("T5_IStd", "T5_IStd", &ISStd_type_tag));
							ITK_CALL(TCTYPE_construct_create_input(ISStd_type_tag, &object_create_input_tag));

							ITK_CALL(TCTYPE_find_type("T5_IStdRevision", "T5_IStdRevision", &ISStd_type_Revtag));
							ITK_CALL(TCTYPE_construct_create_input(ISStd_type_Revtag, &object_create_input_revtag));

							if(IsStdNoDup!=NULL && strlen(IsStdNoDup)>0 && object_create_input_revtag!=NULLTAG && object_create_input_tag!=NULLTAG)
							{
								ITK_CALL(AOM_set_value_string(object_create_input_tag,"item_id",IsStdNoDup));
								ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",IsStdNoDup));
								
								AOM_set_value_string(object_create_input_revtag, "object_name", IsStdNoDup);
								if(tc_strcmp(IsStdIssueNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "item_revision_id", IsStdIssueNoDup);
								AOM_set_value_string(object_create_input_revtag, "object_desc", ISDocumentDescriptionDup);
								if(tc_strcmp(IsStdIndDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_IsStdIndicator", IsStdIndDup);
								if(tc_strcmp(ISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)<=128)AOM_set_value_string(object_create_input_revtag, "t5_IsStdDesc", ISDocumentDescriptionDup);
								else if(tc_strcmp(TempISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)>128)AOM_set_value_string(object_create_input_revtag, "t5_IsStdDesc", TempISDocumentDescriptionDup);
								if(tc_strcmp(IsStdParDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_IsStdPar", IsStdParDup);
								if(tc_strcmp(IsStdSecDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_IsStdSec", IsStdSecDup);
								if(tc_strcmp(IsStdYearDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_IsStdYear", IsStdYearDup);
								if(tc_strcmp(ReaffimedDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_Reaffimed", ReaffimedDup);
								if(tc_strcmp(AmendmentDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_Amendment", AmendmentDup);
								if(tc_strcmp(StdCostDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_StdCost", StdCostDup);
								if(tc_strcmp(StdVendorDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_StdVendor", StdVendorDup);
								if(tc_strcmp(StdVendor1Dup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_StdVendor1", StdVendor1Dup);
								if(tc_strcmp(StdCurrencyDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_StdCurrency", StdCurrencyDup);
								if(tc_strcmp(OrderDetailsDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_OrderDetails", OrderDetailsDup);
								if(tc_strcmp(RemarksDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_Remarks", RemarksDup);
								if(tc_strcmp(SubjCodeDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_SubjCode", SubjCodeDup);
								if(tc_strcmp(SupplNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_SupplNo", SupplNoDup);
								if(tc_strcmp(HBRefDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_HBRef", HBRefDup);
								if(tc_strcmp(CtrlCpyDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_CtrlCpy", CtrlCpyDup);
								
								

								AOM_set_value_tag(object_create_input_tag, "revision",object_create_input_revtag);
								create_flag++;
							}
							printf("\n create_flag=>%d", create_flag);fflush(stdout);
							if(create_flag>0)
							{
								ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_isdocobject));
								printf("\n new_isdocobject");fflush(stdout);
								
								if(new_isdocobject !=NULLTAG)
								{
									
									printf("\n created new_isdocobject");fflush(stdout);
									ITK_CALL(AOM_save(new_isdocobject));
									printf("\n AOM_save new_isdocobject");fflush(stdout);
									ITEM_ask_latest_rev(new_isdocobject,&new_isdocrevobject);
									printf("\n avail new_isdocrevobject");fflush(stdout);
									if(AOM_lock(new_isdocrevobject))
									ITK_CALL(AOM_set_value_string(new_isdocrevobject,"object_name",IsStdNoDup));
									ITK_CALL(AOM_set_value_string(new_isdocrevobject,"object_desc",ISDocumentDescriptionDup));
									
									ITK_CALL(AOM_save(new_isdocrevobject));
									if(AOM_unlock(new_isdocrevobject));
									printf("\n CREATED %s",IsStdNoDup);fflush(stdout);

									TML_Change_Creation_Date(new_isdocrevobject,ISDateRecd,ISAmmDate);

									if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
									{
										PdfUploadFunction(new_isdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
									}
									//if(PrintTmlStdDocNumberDup!="null" && tc_strlen(PrintTmlStdDocNumberDup)>0)
									//{
										//TMLSTD_CreateRelation_ISDOC(new_isdocrevobject,PrintTmlStdDocNumberDup);
									//}
								}
							}
						}
						else
						{
							printf("\n in else n_tags_found .......%d",n_tags_found);fflush(stdout);
							for(cnt=0;cnt<n_tags_found;cnt++)
							{
								
								ISDOCUMENT_tag = ISDOCUMENTOBJS[cnt];
								copyrev=0;
								checkoutrev=0;
								printf("\n IsStdNoDup .......%s",IsStdNoDup);fflush(stdout);
								printf("\n IsStdIssueNoDup .......%s",IsStdIssueNoDup);fflush(stdout);
								printf("\n IsStdSeqDup .......%s",IsStdSeqDup);fflush(stdout);
								printf("\n IsStdIndDup .......%s",IsStdIndDup);fflush(stdout);
								printf("\n IsStdParDup .......%s",IsStdParDup);fflush(stdout);
								printf("\n IsStdSecDup .......%s",IsStdSecDup);fflush(stdout);
								printf("\n IsStdYearDup .......%s",IsStdYearDup);fflush(stdout);
								printf("\n ReaffimedDup .......%s",ReaffimedDup);fflush(stdout);
								printf("\n ISDocumentDescriptionDup .......%s",ISDocumentDescriptionDup);fflush(stdout);
								printf("\n AmendmentDup .......%s",AmendmentDup);fflush(stdout);
								printf("\n DateRecdDup .......%s",DateRecdDup);fflush(stdout);
								printf("\n StdCostDup .......%s",StdCostDup);fflush(stdout);
								printf("\n StdVendorDup .......%s",StdVendorDup);fflush(stdout);
								printf("\n StdVendor1Dup .......%s",StdVendor1Dup);fflush(stdout);
								printf("\n StdCurrencyDup .......%s",StdCurrencyDup);fflush(stdout);
								printf("\n OrderDetailsDup .......%s",OrderDetailsDup);fflush(stdout);
								printf("\n RemarksDup .......%s",RemarksDup);fflush(stdout);
								printf("\n SubjCodeDup .......%s",SubjCodeDup);fflush(stdout);
								printf("\n SupplNoDup .......%s",SupplNoDup);fflush(stdout);
								printf("\n HBRefDup .......%s",HBRefDup);fflush(stdout);
								printf("\n CtrlCpyDup .......%s",CtrlCpyDup);fflush(stdout);
								printf("\n AmmDateDup .......%s",AmmDateDup);fflush(stdout);
								printf("\n TsRqByDup .......%s",TsRqByDup);fflush(stdout);
								printf("\n PrintTmlStdDocNumberDup .......%s",PrintTmlStdDocNumberDup);fflush(stdout);
								printf("\n PDFNameDup .......%s",PDFNameDup);fflush(stdout);
								printf("\n pdfdoc_full_pathDup .......%s",pdfdoc_full_pathDup);fflush(stdout);

								AOM_ask_value_string(ISDOCUMENT_tag,"item_id",&ISStdDocNumber);
								printf("\n ISStdDocNumber .......%s",ISStdDocNumber);fflush(stdout);
								if(ISStdDocNumber)ISStdDocNumberDup = strdup(ISStdDocNumber);
								if(IsStdIssueNoDup)IsStdIssueNo = strdup(IsStdIssueNoDup);

								qry_values[0] = ISStdDocNumberDup;
								qry_values[1] = "IS Standard Class Revision";
								qry_values[2] = IsStdIssueNo;

								

								QRY_find("Item Revision...", &query);
								if(query!=NULLTAG)
								{
									//if(t_allrevdocs!=NULLTAG) MEM_free(t_allrevdocs); t_allrevdocs = NULL;
									printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
									printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
									printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
									QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &t_allrevdocs);
								}
								
								//ITEM_find_item_revs_by_key_attributes(2,attrs1, values1,TMLStdIssueNoDup,&n_tags_found1, &t_allrevdocs);
								printf("\n n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
								if(n_tags_found1==0)
								{
									ITEM_ask_latest_rev(ISDOCUMENT_tag,&isdocrevobject);
									copyrev++;
								}
								else
								{
									isdocrevobject = t_allrevdocs[0];
									AOM_ask_value_int(isdocrevobject,"sequence_id",&ISStdSeqIdValue);
									printf("\n TMLStdSeqIdValue .......%d",ISStdSeqIdValue);fflush(stdout);


									AOM_ask_value_string(isdocrevobject,"item_revision_id",&ISStdDocRevision);
									printf("\n ISStdDocRevision .......%s",ISStdDocRevision);fflush(stdout);
									printf("\n ISStdSeqValue .......%d",ISStdSeqValue);fflush(stdout);

									if(tc_strcmp(ISStdDocRevision,IsStdIssueNoDup)==0)
									{
										if(ISStdSeqIdValue != ISStdSeqValue)
										{
											checkoutrev++;
										}
									}
								}
								if(isdocrevobject!=NULLTAG)
								{
									printf("\n copyrev .......%d",copyrev);fflush(stdout);
									printf("\n checkoutrev .......%d",checkoutrev);fflush(stdout);
									if(copyrev>0)
									{
										ITEM_copy_rev(isdocrevobject,NULL,&new_rev_tag);
										if(new_rev_tag!=NULLTAG)
										{
											AOM_lock(new_rev_tag);
											
											POM_attr_id_of_attr("item_revision_id", "T5_IStdRevision", &attr_id);
											POM_set_attr_string(1, &new_rev_tag, attr_id,IsStdIssueNoDup);
											POM_save_instances(1, &new_rev_tag, false);

											

											AOM_set_value_string(new_rev_tag, "object_desc", ISDocumentDescriptionDup);
											if(tc_strcmp(IsStdIndDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_IsStdIndicator", IsStdIndDup);
											if(tc_strcmp(ISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)<=128)AOM_set_value_string(new_rev_tag, "t5_IsStdDesc", ISDocumentDescriptionDup);
											else if(tc_strcmp(TempISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)>128)AOM_set_value_string(new_rev_tag, "t5_IsStdDesc", TempISDocumentDescriptionDup);
											if(tc_strcmp(IsStdParDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_IsStdPar", IsStdParDup);
											if(tc_strcmp(IsStdSecDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_IsStdSec", IsStdSecDup);
											if(tc_strcmp(IsStdYearDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_IsStdYear", IsStdYearDup);
											if(tc_strcmp(ReaffimedDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_Reaffimed", ReaffimedDup);
											if(tc_strcmp(AmendmentDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_Amendment", AmendmentDup);
											if(tc_strcmp(StdCostDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_StdCost", StdCostDup);
											if(tc_strcmp(StdVendorDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_StdVendor", StdVendorDup);
											if(tc_strcmp(StdVendor1Dup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_StdVendor1", StdVendor1Dup);
											if(tc_strcmp(StdCurrencyDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_StdCurrency", StdCurrencyDup);
											if(tc_strcmp(OrderDetailsDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_OrderDetails", OrderDetailsDup);
											if(tc_strcmp(RemarksDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_Remarks", RemarksDup);
											if(tc_strcmp(SubjCodeDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_SubjCode", SubjCodeDup);
											if(tc_strcmp(SupplNoDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_SupplNo", SupplNoDup);
											if(tc_strcmp(HBRefDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_HBRef", HBRefDup);
											if(tc_strcmp(CtrlCpyDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_CtrlCpy", CtrlCpyDup);

											ITK_CALL(AOM_save(new_rev_tag));
											AOM_unlock(new_rev_tag);

											TML_Change_Creation_Date(new_rev_tag,ISDateRecd,ISAmmDate);
											if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
											{
												PdfUploadFunction(new_rev_tag,PDFNameDup,pdfdoc_full_pathDup);
											}
											//if(PrintTmlStdDocNumberDup!="null" && tc_strlen(PrintTmlStdDocNumberDup)>0)
											//{
												//TMLSTD_CreateRelation_ISDOC(new_rev_tag,PrintTmlStdDocNumberDup);
											//}
											
										}
									}
									if(checkoutrev>0)
									{
										RES_checkout(isdocrevobject,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE);

										AOM_set_value_string(isdocrevobject, "object_desc", ISDocumentDescriptionDup);
										if(tc_strcmp(IsStdIndDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdIndicator", IsStdIndDup);
										if(tc_strcmp(ISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)<=128)AOM_set_value_string(isdocrevobject, "t5_IsStdDesc", ISDocumentDescriptionDup);
										else if(tc_strcmp(TempISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)>128)AOM_set_value_string(isdocrevobject, "t5_IsStdDesc", TempISDocumentDescriptionDup);
										if(tc_strcmp(IsStdParDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdPar", IsStdParDup);
										if(tc_strcmp(IsStdSecDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdSec", IsStdSecDup);
										if(tc_strcmp(IsStdYearDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdYear", IsStdYearDup);
										if(tc_strcmp(ReaffimedDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Reaffimed", ReaffimedDup);
										if(tc_strcmp(AmendmentDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Amendment", AmendmentDup);
										if(tc_strcmp(StdCostDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdCost", StdCostDup);
										if(tc_strcmp(StdVendorDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdVendor", StdVendorDup);
										if(tc_strcmp(StdVendor1Dup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdVendor1", StdVendor1Dup);
										if(tc_strcmp(StdCurrencyDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdCurrency", StdCurrencyDup);
										if(tc_strcmp(OrderDetailsDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_OrderDetails", OrderDetailsDup);
										if(tc_strcmp(RemarksDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Remarks", RemarksDup);
										if(tc_strcmp(SubjCodeDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_SubjCode", SubjCodeDup);
										if(tc_strcmp(SupplNoDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_SupplNo", SupplNoDup);
										if(tc_strcmp(HBRefDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_HBRef", HBRefDup);
										if(tc_strcmp(CtrlCpyDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_CtrlCpy", CtrlCpyDup);
										
										TML_Change_Creation_Date(isdocrevobject,ISDateRecd,ISAmmDate);
										//ITK_CALL(AOM_save(isdocrevobject));

										
										if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
										{
											PdfUploadFunction(isdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
										}
										//if(PrintTmlStdDocNumberDup!="null" && tc_strlen(PrintTmlStdDocNumberDup)>0)
										//{
											//TMLSTD_CreateRelation_ISDOC(isdocrevobject,PrintTmlStdDocNumberDup);
										//}
										RES_checkin(isdocrevobject);
									}
									/*
									if(copyrev==0 || checkoutrev==0)
									{
										AOM_lock(isdocrevobject);
										AOM_set_value_string(isdocrevobject, "object_desc", ISDocumentDescriptionDup);
										if(tc_strcmp(IsStdIndDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdIndicator", IsStdIndDup);
										if(tc_strcmp(ISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)<=128)AOM_set_value_string(isdocrevobject, "t5_IsStdDesc", ISDocumentDescriptionDup);
										else if(tc_strcmp(TempISDocumentDescriptionDup,"null")!=0 && tc_strlen(ISDocumentDescriptionDup)>128)AOM_set_value_string(isdocrevobject, "t5_IsStdDesc", TempISDocumentDescriptionDup);
										if(tc_strcmp(IsStdParDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdPar", IsStdParDup);
										if(tc_strcmp(IsStdSecDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdSec", IsStdSecDup);
										if(tc_strcmp(IsStdYearDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_IsStdYear", IsStdYearDup);
										if(tc_strcmp(ReaffimedDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Reaffimed", ReaffimedDup);
										if(tc_strcmp(AmendmentDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Amendment", AmendmentDup);
										if(tc_strcmp(StdCostDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdCost", StdCostDup);
										if(tc_strcmp(StdVendorDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdVendor", StdVendorDup);
										if(tc_strcmp(StdVendor1Dup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdVendor1", StdVendor1Dup);
										if(tc_strcmp(StdCurrencyDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_StdCurrency", StdCurrencyDup);
										if(tc_strcmp(OrderDetailsDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_OrderDetails", OrderDetailsDup);
										if(tc_strcmp(RemarksDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_Remarks", RemarksDup);
										if(tc_strcmp(SubjCodeDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_SubjCode", SubjCodeDup);
										if(tc_strcmp(SupplNoDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_SupplNo", SupplNoDup);
										if(tc_strcmp(HBRefDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_HBRef", HBRefDup);
										if(tc_strcmp(CtrlCpyDup,"null")!=0)AOM_set_value_string(isdocrevobject, "t5_CtrlCpy", CtrlCpyDup);
										
										TML_Change_Creation_Date(isdocrevobject,ISDateRecd,ISAmmDate);
										ITK_CALL(AOM_save(isdocrevobject));
										AOM_unlock(isdocrevobject);

										
										if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
										{
											PdfUploadFunction(isdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
										}
										if(PrintTmlStdDocNumberDup!="null" && tc_strlen(PrintTmlStdDocNumberDup)>0)
										{
											TMLSTD_CreateRelation_ISDOC(isdocrevobject,PrintTmlStdDocNumberDup);
										}
									}
									*/
								}
								MEM_free(t_allrevdocs);
							}
						}
							//TML_IS_DOC_Avaialble(ISStdNoDup,ISStdIssueNoDup,ISStdSeqDup);
							//TML_IS_DOC_Result_Avaialble(IsStdNoDup,IsStdIssueNoDup,IsStdSeqDup);
							//if(PrintTmlStdDocNumberDup!="null" && tc_strlen(PrintTmlStdDocNumberDup)>0)
							//{
								//TMLSTD_CreateRelation_ISDOC(new_rev_tag,PrintTmlStdDocNumberDup);
							//}


					  

					} // End of while Loop.
					MEM_free(ISDOCUMENTOBJS);
				} // fptr
				else
				{
					printf("\n file not read .......");fflush(stdout);
				}
				if(fptr!=NULL)fclose(fptr); fptr = NULL;
				//MEM_free(ISDOCUMENTOBJS);
				//MEM_free(FileLocation);
			}

		}
		//fclose(fptr1);
		if(fptr1!=NULL)fclose(fptr1); fptr1 = NULL;
		//MEM_free(ISDOCUMENTOBJS);
		//MEM_free(otherobjects);
	}
	
	//fclose(out_fp);
	//fclose(output_fp);
	//fclose(output_fp1);
	return ITK_ok;
}