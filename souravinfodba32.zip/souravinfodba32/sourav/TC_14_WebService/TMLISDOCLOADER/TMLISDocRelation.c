/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   TMLISDOCUPLOAD.c
*  Author		 :   Sudhir
*  Module		 :   TMLISDOCUPLOAD create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100

#define CONST_MAX_YEAR			 2100
#define CONST_MIN_YEAR			 1975
#define CONST_MAX_MONTH			 11
#define CONST_MIN_MONTH			 0
#define CONST_MIN_DAY			 1
#define CONST_MAX_DAY			 31
#define CONST_MIN_HOUR			 00
#define CONST_MAX_HOUR		     23
#define CONST_MIN_MINUTE		 00
#define CONST_MAX_MINUTE		 59
#define CONST_MIN_SECOND		 00
#define CONST_MAX_SECOND		 59
#define NotLoad		 "/user/cvprod/sudhir/TMLISDOCLOADER_AferDeployment/Exist.txt"
#define NotLoaded		 "/user/cvprod/sudhir/TMLISDOCLOADER_AferDeployment/Result.txt"
#define RelationNotLoaded		 "/user/cvprod/sudhir/TMLISDOCLOADER_AferDeployment/Relation.txt"
//#define NotLoad		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Exist.txt"
//#define NotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Result.txt"
//#define RelationNotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Relation.txt"
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct func
{
	 char TMLStdNo[100];
	 char TMLStdIssueNo[100];
	 char TMLStdSeq[500];
	 char TMLSuperseded[500];
	 char TMLFrozen[1000];
	 char TMTSOwner[1000];
	 char TMTSHrmStdNo[1000];
	 char TMTSAinNo[1000];
	 char TMDocumentDescription[1000];
	 char TMTSJsrDept[1000];
	 char TMTSLkhDept[1000];
	 char TMTSPunDept[1000];
	 char TMRespParty[1000];
	 char TMOwnerName[1000];
	 char TMDVolNo[200];
	 char TMTSKeyword1[200];
	 char TMTSKeyword2[200];
	 char TMTSKeyword3[200];
	 char TMAlterationRemark[1000];
	 char TMBulkReplicate[1000];
	 char TMLastModBy[1000];
	 char TMRepDate[200];
	 char TMRepFrom[200];
	 char TMRepStat[200];
	 char TMRepTo[200];
	 char TMVerCreator[200];
	 char TMWitholdIssueInd[200];
	 char TMDelInd[200];
	 char TMRelDate[200];
	 char TMMod_Date[200];
	 char TMRemark[200];
	 char TMDateUpdated[200];
	 char TEMPTMRefISNo[2000];
	 char TMIsStdBRInd[2000];
	 char TMAuthor[200];
	 char TMAuthorDate[200];
	 char TMAddressee[200];
	 char TMCCAddressee[200];
	 char TMClass[200];
	 char PDFName[200];
	 char pdfdoc_full_path[200];
	 


} tmlisdocobjupload[800000];

static FILE* out_fp;
static FILE* output_fp;
static FILE* output_fp1;
logical IsValideDate(date_t *date)
{
	logical isFlag		= false;
	date_t  localdate  = NULLDATE;

	localdate = *date;	
	
	//Check if date is null
	if(DATE_IS_NULL(localdate) != 1)
	{
		if(date->year < CONST_MIN_YEAR)
			date->year = CONST_MIN_YEAR;

		if (date->year > CONST_MAX_YEAR)
			date->year = CONST_MAX_YEAR;
		
		if(date->month < CONST_MIN_MONTH)
			date->month = CONST_MIN_MONTH;

		if(date->month > CONST_MAX_MONTH)
			date->month = CONST_MAX_MONTH;

		if(date->day < CONST_MIN_DAY)
			date->day = CONST_MIN_DAY;

		if(date->day > CONST_MAX_DAY)
			date->day = CONST_MAX_DAY;

		if(date->hour < CONST_MIN_HOUR)
			date->hour = CONST_MIN_HOUR;

		if(date->hour > CONST_MAX_HOUR)
			date->hour = CONST_MAX_HOUR;

		if(date->minute < CONST_MIN_MINUTE)
			date->minute = CONST_MIN_MINUTE;

		if(date->minute > CONST_MAX_MINUTE)
			date->minute = CONST_MAX_MINUTE;

		if(date->second < CONST_MIN_SECOND)
			date->second = CONST_MIN_SECOND;

		if(date->second > CONST_MAX_SECOND)
			date->second = CONST_MAX_SECOND;

		//For the months of April, June, September and November, check the date to be less than or equal to 30
		if (date->month == 3 || date->month == 5 || date->month == 8 || date->month == 10)
		{
			if (date->day > 30)
				date->day = 30;
		}

		//For the month of February,
		/////If the year is a leap year, then check the date to be less than or equal to 29
		/////Else, check the date to be less than or equal to 28
		if (date->month == 1)
		{
			if((date->year % 4 == 0 && date->year % 100 != 0) || date->year % 400 == 0)
			{
				if (date->day > 29)
					date->day = 29;
			}
			else
			{
				if (date->day > 28)
					date->day = 28;
			}
		}
		
		//Set the Flag true
		isFlag = true;
	}

	return isFlag;
}

static int TML_token_to_int( const char *str )
{
	return (int) strtol( str, NULL, 10);
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

int TMLSTD_CreateRelation_ISDOC(tag_t DocrevTag,char *ReferedStdNumber,char *BRIndicator)
{
	int		ifail			= 0;
	int		tt1				= 0;
	int		tt2				= 0;
	int		sr,sb			= 0;
	int		n_tags_found	= 0;
	int		relcount		= 0;
	int		doc				= 0;
	int		relatiocount	= 0;
	

	char *TMLStdDocId		= NULL;
	char**	RefStdIsDocSet	= NULL;
	char**	RefStdBRIndSet	= NULL;
	char * pch1				= NULL;
	char * pch2				= NULL;
	char * Doc_Num			= NULL;
	char * Doc_Rev			= NULL;
	char * Doc_Seq			= NULL;
	char * DocRevId			= NULL;
	char * DocRevIdDup		= NULL;
	char * DocId			= NULL;
	char * DocIdDup			= NULL;
	char *ReferedDocNum		= NULL;
	char *ReferedDocBRInd	= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	tag_t	relation_type1	= NULLTAG;
	tag_t	*t_allrevdocs	= NULLTAG;
	tag_t	*AvailObjects	= NULLTAG;
	tag_t	Avail_Object	= NULLTAG;
	tag_t	Avail_Object1	= NULLTAG;
	tag_t	Avail_Object2	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	Query_Object	= NULLTAG;
	tag_t	rel_tags		= NULLTAG;
	
	//RefStdIsDocSet = (char**)MEM_alloc( 1 * sizeof *RefStdIsDocSet );
	//RefStdBRIndSet = (char**)MEM_alloc( 1 * sizeof *RefStdBRIndSet );

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	
	printf("\n TMLSTD_CreateRelation_ISDOC::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n TMLSTD_CreateRelation_ISDOC::ReferedStdNumber .......[%s]",ReferedStdNumber);fflush(stdout);
	printf("\n TMLSTD_CreateRelation_ISDOC::BRIndicator .......[%s]",BRIndicator);fflush(stdout);

	GRM_find_relation_type("T5_TSISR", &relation_type1);

	//output_fp1=fopen(RelationNotLoaded,"a+");

	if(ReferedStdNumber!=NULL && tc_strlen(ReferedStdNumber)>0)
	{
		
		pch1 = tc_strtok(ReferedStdNumber,";");
		printf("\n pch1 .......[%s]",pch1);fflush(stdout);
		if(pch1!=NULL)
		{
			setAddStr(&tt1,&RefStdIsDocSet,pch1);
		}
		while(pch1 != NULL)
		{
			pch1 = tc_strtok(NULL, ";");
			printf("\n pch1 .......[%s]",pch1);fflush(stdout);
			if(pch1!=NULL)
			{
				setAddStr(&tt1,&RefStdIsDocSet,pch1);
			}
		}
	}
	if(BRIndicator!=NULL)
	{
		
		pch2 = tc_strtok(BRIndicator,";");
		printf("\n pch2 .......[%s]",pch2);fflush(stdout);
		if(pch2!=NULL)
		{
			setAddStr(&tt2,&RefStdBRIndSet,pch2);
		}
		while(pch2 != NULL)
		{
			pch2= tc_strtok(NULL, ";");
			printf("\n pch2 .......[%s]",pch2);fflush(stdout);
			if(pch2!=NULL)
			{
				setAddStr(&tt2,&RefStdBRIndSet,pch2);
			}
		}
	}
	printf("\n tt1 .......[%d]",tt1);fflush(stdout);
	printf("\n tt2 .......[%d]",tt2);fflush(stdout);
	if(tt1>0)
	{
		for(sr = 0, sb = 0; sr < tt1 && sb <tt2; sr++, sb++)
		{
			ReferedDocNum = RefStdIsDocSet[sr];
			ReferedDocBRInd = RefStdBRIndSet[sb];
			printf("\n ReferedDocNum .......[%s]",ReferedDocNum);fflush(stdout);
			printf("\n ReferedDocBRInd .......[%s]",ReferedDocBRInd);fflush(stdout);
			if(ReferedDocNum!=NULL && tc_strlen(ReferedDocNum)>0)
			{
				if(tc_strstr(ReferedDocNum,"TS")!=NULL)
				{
					Doc_Num = tc_strtok(ReferedDocNum,"-");
					Doc_Rev= tc_strtok(NULL, "-");
					Doc_Seq= tc_strtok(NULL, "-");

					qry_values[0] = Doc_Num;
					qry_values[1] = "TML Std Revision";
					qry_values[2] = Doc_Rev;
				}
				else
				{
					Doc_Num = tc_strtok(ReferedDocNum,"-");
					Doc_Rev= tc_strtok(NULL, "-");
					Doc_Seq= tc_strtok(NULL, "-");

					qry_values[0] = Doc_Num;
					qry_values[1] = "IS Standard Class Revision";
					qry_values[2] = Doc_Rev;
				}
				
				printf("\n Doc_Num .......[%s]",Doc_Num);fflush(stdout);
				printf("\n Doc_Rev .......[%s]",Doc_Rev);fflush(stdout);
				printf("\n Doc_Seq .......[%s]",Doc_Seq);fflush(stdout);

				QRY_find("All Sequences", &query);
				
				printf("\n qry_values[0] .......[%s]",qry_values[0]);fflush(stdout);
				printf("\n qry_values[1] .......[%s]",qry_values[1]);fflush(stdout);
				printf("\n qry_values[2] .......[%s]",qry_values[2]);fflush(stdout);
				//ITEM_find_item_revs_by_key_attributes(2,attrs, values,Doc_Rev,&n_tags_found, &t_allrevdocs);
				QRY_execute(query, 3, qry_entries, qry_values, &n_tags_found, &t_allrevdocs);
				printf("\n n_tags_found .......[%d]",n_tags_found);fflush(stdout);
				if(n_tags_found>0)
				{
					/*
					for(doc=0;doc<n_tags_found;doc++)
					{
						Query_Object = t_allrevdocs[doc];
						GRM_find_relation(DocrevTag, Query_Object, relation_type1,&rel_tags);
						if(rel_tags!=NULLTAG)
						{
							printf("\n Relation exist");fflush(stdout);
						}
						else
						{
							printf("\n Relation does not exist");fflush(stdout);
							GRM_create_relation(DocrevTag, Query_Object, relation_type1, NULLTAG, &relation);
							GRM_save_relation(relation);
							AOM_save(DocrevTag);
							printf("\n 3 TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
						}
					}
					*/
					
					GRM_list_secondary_objects_only(DocrevTag, relation_type1, &relcount, &AvailObjects);
					printf("\n relcount .......[%d]",relcount);fflush(stdout);
					if(relcount>0)
					{
						for(doc=0;doc<relcount;doc++)
						{
							Avail_Object = AvailObjects[doc];
							AOM_ask_value_string(Avail_Object,"item_id",&DocId);
							if(DocId!=NULL) DocIdDup = strdup(DocId);
							printf("\n TMLSTD_CreateRelation_ISDOC::DocId .......%s",DocIdDup);fflush(stdout);

							AOM_ask_value_string(Avail_Object,"item_revision_id",&DocRevId);
							if(DocRevId!=NULL) DocRevIdDup = strdup(DocRevId);
							printf("\n TMLSTD_CreateRelation_ISDOC::DocRevId .......%s",DocRevIdDup);fflush(stdout);
							if(tc_strcmp(DocIdDup,Doc_Num)==0 && tc_strcmp(DocRevIdDup,Doc_Rev)==0 && tc_strlen(Doc_Num)>0)
							{
								printf("\n 1 TMLSTD_CreateRelation_ISDOC::Relation Exist!!");fflush(stdout);
							}
							else
							{
								printf("\n 2 TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
								Avail_Object1= t_allrevdocs[0];
								GRM_create_relation(DocrevTag, Avail_Object1, relation_type1, NULLTAG, &relation);
								GRM_save_relation(relation);
								AOM_save(DocrevTag);
								printf("\n 3 TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n 4 ELSE::TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
						Avail_Object2 = t_allrevdocs[0];
						GRM_create_relation(DocrevTag, Avail_Object2, relation_type1, NULLTAG, &relation);
						GRM_save_relation(relation);
						AOM_save(DocrevTag);
						printf("\n 5 ELSE::TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
					}
					
				}
				else
				{
					printf("\n TML STD DOC is not yet Loaded!!");fflush(stdout);
					//fprintf(output_fp1,"%s",Doc_Num);
					//fprintf(output_fp1,"~");
					//fprintf(output_fp1,"NOT LOADED");
					//fprintf(output_fp1,"\n");
				}
				
			}			
		}

		//MEM_free(AvailObjects);
		//MEM_free(t_allrevdocs);
		//MEM_free(RefStdIsDocSet);
		//MEM_free(RefStdBRIndSet);
	}
	
	
	return ITK_ok;
}

int TML_IS_DOC_Result_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;
	char *strSeqIdValue		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_TMLStd";
	
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdNo .......[%s]",TMLStdNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdIssueNo .......[%s]",TMLStdIssueNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdSeq .......[%s]",TMLStdSeq);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);
	strSeqIdValue=(char *)MEM_alloc(200);




	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of TMLStd=>%d", n_tags_found);fflush(stdout);
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		qry_values[0] = TMLStdNo;
		qry_values[1] = "TML Std Revision";
		qry_values[2] = TMLStdIssueNo;
		QRY_find("All Sequences", &query);
		if(query!=NULLTAG)
		{
			QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			if(n_tags_found1==0)
			{
				fprintf(output_fp,"%s",TMLStdNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);
					sprintf(strSeqIdValue,"%d",SeqIdValue);

					fprintf(output_fp,"%s",TMLStdNo);
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",DocRevision);
					fprintf(output_fp,"~");
					fprintf(output_fp,"REVISION IS LOADED");
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",strSeqIdValue);
					fprintf(output_fp,"~");
					fprintf(output_fp,"\n");
				}
			}
		}
	}

	return ITK_ok;
}

int TML_IS_DOC_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_TMLStd";
	
	printf("\n TML_IS_DOC_Avaialble::values[0] .......[%s]",values[0]);fflush(stdout);
	printf("\n TML_IS_DOC_Avaialble::values[1] .......[%s]",values[1]);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);

	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of TMLStd=>%d", n_tags_found);fflush(stdout);
	//fprintf(output_fp,"TML STD DOC NO~REVISION~STATUS");
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT AVAILABLE");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		for(cnt=0;cnt<n_tags_found;cnt++)
		{
			doc_tag = DOCUMENTOBJS[cnt];
			AOM_ask_value_string(doc_tag,"item_id",&DocNumber);
			printf("\n TML_IS_DOC_Avaialble::DocNumber .......%s",DocNumber);fflush(stdout);
			fprintf(output_fp,"%s",DocNumber);
			fprintf(output_fp,"~");

			qry_values[0] = DocNumber;
			qry_values[1] = "TML Std Revision";
			qry_values[2] = TMLStdIssueNo;

			QRY_find("All Sequences", &query);
			if(query!=NULLTAG)
			{
				printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
				printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
				printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
				QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			}
			printf("\n TML_IS_DOC_Avaialble::n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
			if(n_tags_found1==0)
			{
				//ITEM_ask_latest_rev(doc_tag,&docrevobject);
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);

					if(tc_strcmp(DocRevision,TMLStdIssueNo)==0)
					{
						if(SeqIdValue==DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"LOADED");
						}
						if(SeqIdValue!=DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"NOT LOADED");
							fprintf(output_fp,"~");
						}
					}
				}
			}
		}
	}

	return ITK_ok;
}
int PdfUploadFunction(tag_t DocrevTag,char *pdfname,char *pdflocation)
{
	int		ifail			= 0;
	int		iCountSecondary	= 0;
	int		pdfcnt			= 0;
	int		pdfdelete		= 0;
	int		pdfcount		= 0;
	int		tt1				= 0;
	int		tt2				= 0;
	int		sp				= 0;
	int		sl				= 0;

	char *TMLStdDocId		= NULL;
	char *TMLStdDocDesc		= NULL;
	char *pdfdatasetname	= NULL;
	char *pdfdataname		= NULL;
	char *pdfdatasetloc		= NULL;
	char *format			= NULL;
	char **ref_list;
	char * pch1				= NULL;
	char * pch2				= NULL;
	char**	PDFNameSet		= NULL;
	char**	PDFLocSet		= NULL;

	tag_t	NewPdfdataset	= NULLTAG;
	tag_t	datasettype		= NULLTAG;
	tag_t	tool			= NULLTAG;
	tag_t	filetag			= NULLTAG;
	tag_t	relation_type	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	*PdfObjects		= NULLTAG;
	tag_t	PdfObject		= NULLTAG;
	tag_t	pdfrel_tag		= NULLTAG;
	tag_t	PdfObject1		= NULLTAG;
	tag_t	relation_type1	= NULLTAG;
	tag_t	pdfrel_tag1		= NULLTAG;
	tag_t	*AvailPdfObjects= NULLTAG;

	logical			checkout = 0;

	IMF_file_t	fileDescriptor;
	AE_reference_type_t	tagRefType = 1;

	int		ref_count;

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	printf("\n PdfUploadFunction::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	AOM_ask_value_string(DocrevTag,"object_desc",&TMLStdDocDesc);
	printf("\n TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n pdfname .......[%s]",pdfname);fflush(stdout);
	printf("\n pdflocation .......[%s]",pdflocation);fflush(stdout);

	if(pdfname!=NULL && tc_strlen(pdfname)>0)
	{
		
		pch1 = tc_strtok(pdfname,";");
		printf("\n pch1 .......[%s]",pch1);fflush(stdout);
		if(pch1!=NULL)
		{
			setAddStr(&tt1,&PDFNameSet,pch1);
		}
		while(pch1 != NULL)
		{
			pch1 = tc_strtok(NULL, ";");
			printf("\n pch1 .......[%s]",pch1);fflush(stdout);
			if(pch1!=NULL)
			{
				setAddStr(&tt1,&PDFNameSet,pch1);
			}
		}
	}

	if(pdflocation!=NULL && tc_strlen(pdflocation)>0)
	{
		
		pch2 = tc_strtok(pdflocation,";");
		printf("\n pch2 .......[%s]",pch2);fflush(stdout);
		if(pch2!=NULL)
		{
			setAddStr(&tt2,&PDFLocSet,pch2);
		}
		while(pch2 != NULL)
		{
			pch2 = tc_strtok(NULL, ";");
			printf("\n pch2 .......[%s]",pch2);fflush(stdout);
			if(pch2!=NULL)
			{
				setAddStr(&tt2,&PDFLocSet,pch2);
			}
		}
	}

	if(tt1>0)
	{
		GRM_find_relation_type("IMAN_Rendering", &relation_type1);
		GRM_list_secondary_objects_only(DocrevTag, relation_type1, &pdfcount, &AvailPdfObjects);
		for(sp = 0, sl = 0; sp < tt1 && sl <tt2; sp++, sl++)
		{
			pdfdataname = PDFNameSet[sp];
			pdfdatasetloc = PDFLocSet[sl];

			pdfdatasetname = strtok(pdfdataname , ".");
			printf("\n Dataset name ---> %s",pdfdatasetname);fflush(stdout);
			printf("\n pdfdatasetloc ---> %s",pdfdatasetloc);fflush(stdout);
			if(pdfdatasetname!=NULL && tc_strlen(pdfdatasetname)>0 && pdfdatasetloc!=NULL && tc_strlen(pdfdatasetloc)>0)
			{
				format = strtok(NULL , ".");
				printf("\nDataset format Else---->%s",format);fflush(stdout);

				if(pdfcount>0)
				{
					printf("\n PDF IS AVAILABLE");fflush(stdout);
				}
				else
				{
					if(tc_strcmp(format,"pdf")==0 || tc_strcmp(format,"PDF")==0)
					{
						printf("\n Step 1 --->");fflush(stdout);
						AE_find_datasettype("PDF", &datasettype);
						printf("\n Step 2 --->");fflush(stdout);
						AE_create_dataset_with_id(datasettype,pdfdatasetname,TMLStdDocDesc, NULL, NULL, &NewPdfdataset);
						printf("\n Step 3 --->");fflush(stdout);
						AE_set_dataset_format(NewPdfdataset, "BINARY_REF");
						printf("\n Step 4 --->");fflush(stdout);
						AE_ask_datasettype_def_tool(datasettype, &tool);
						printf("\n Step 5 --->");fflush(stdout);
						AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
						printf("\n Step 6 --->");fflush(stdout);
						IMF_import_file(pdfdatasetloc,NULL, SS_BINARY, &filetag, &fileDescriptor);
						printf("\n Step 7 --->");fflush(stdout);
						AOM_save(filetag);
						printf("\n Step 8 --->");fflush(stdout);
						AE_add_dataset_named_ref(NewPdfdataset,ref_list[0],tagRefType,filetag);
						printf("\n Step 9 --->");fflush(stdout);
						AE_set_dataset_tool(NewPdfdataset,tool);
						printf("\n Step 10 --->");fflush(stdout);
						AOM_save(NewPdfdataset);
						printf("\n Step 11 --->");fflush(stdout);

						RES_is_checked_out(DocrevTag,&checkout);
						GRM_find_relation_type("IMAN_Rendering", &relation_type);
						if (checkout==1)
						{
							GRM_list_secondary_objects_only(DocrevTag, relation_type, &iCountSecondary, &PdfObjects);
							printf("\n Step 12 iCountSecondary --->%d",iCountSecondary);fflush(stdout);
						}
						if(iCountSecondary>0)
						{
							for(pdfcnt=0;pdfcnt<iCountSecondary;pdfcnt++)
							{
								PdfObject = PdfObjects[pdfcnt];
								printf("\n Step 13 --->");fflush(stdout);
								GRM_find_relation(DocrevTag, PdfObject, relation_type, &pdfrel_tag);
								printf("\n Step 14 --->");fflush(stdout);
								GRM_delete_relation(pdfrel_tag);
								printf("\n Step 15 --->");fflush(stdout);
								AOM_save(DocrevTag);
								printf("\n Step 16 --->");fflush(stdout);
								pdfdelete++;
							}
							
							
						}
						if(iCountSecondary==0 || pdfdelete>0)
						{
							printf("\n Step 17 --->");fflush(stdout);
							GRM_create_relation(DocrevTag, NewPdfdataset, relation_type, NULLTAG, &relation);
							printf("\n Step 18 --->");fflush(stdout);
							GRM_save_relation(relation);
							printf("\n Step 19 --->");fflush(stdout);
						}
						
						
					}
				}
			}
		}
	}

	/*
	pdfdatasetname = strtok(pdfname , ".");
	printf("\nDataset name ---> %s",pdfdatasetname);fflush(stdout);
	if(pdfdatasetname!=NULL)
	{
		format = strtok(NULL , ".");
		printf("\nDataset format Else---->%s",format);fflush(stdout);
	}
	GRM_find_relation_type("IMAN_Rendering", &relation_type1);
	GRM_list_secondary_objects_only(DocrevTag, relation_type1, &pdfcount, &AvailPdfObjects);

	if(pdfcount>0)
	{
		printf("\n PDF IS AVAILABLE");fflush(stdout);
	}
	else
	{
		if(tc_strcmp(format,"pdf")==0 || tc_strcmp(format,"PDF")==0)
		{
			printf("\n Step 1 --->");fflush(stdout);
			AE_find_datasettype("PDF", &datasettype);
			printf("\n Step 2 --->");fflush(stdout);
			AE_create_dataset_with_id(datasettype,pdfdatasetname,TMLStdDocDesc, NULL, NULL, &NewPdfdataset);
			printf("\n Step 3 --->");fflush(stdout);
			AE_set_dataset_format(NewPdfdataset, "BINARY_REF");
			printf("\n Step 4 --->");fflush(stdout);
			AE_ask_datasettype_def_tool(datasettype, &tool);
			printf("\n Step 5 --->");fflush(stdout);
			AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
			printf("\n Step 6 --->");fflush(stdout);
			IMF_import_file(pdflocation,NULL, SS_BINARY, &filetag, &fileDescriptor);
			printf("\n Step 7 --->");fflush(stdout);
			AOM_save(filetag);
			printf("\n Step 8 --->");fflush(stdout);
			AE_add_dataset_named_ref(NewPdfdataset,ref_list[0],tagRefType,filetag);
			printf("\n Step 9 --->");fflush(stdout);
			AE_set_dataset_tool(NewPdfdataset,tool);
			printf("\n Step 10 --->");fflush(stdout);
			AOM_save(NewPdfdataset);
			printf("\n Step 11 --->");fflush(stdout);

			RES_is_checked_out(DocrevTag,&checkout);
			GRM_find_relation_type("IMAN_Rendering", &relation_type);
			if (checkout==1)
			{
				GRM_list_secondary_objects_only(DocrevTag, relation_type, &iCountSecondary, &PdfObjects);
				printf("\n Step 12 iCountSecondary --->%d",iCountSecondary);fflush(stdout);
			}
			if(iCountSecondary>0)
			{
				for(pdfcnt=0;pdfcnt<iCountSecondary;pdfcnt++)
				{
					PdfObject = PdfObjects[pdfcnt];
					printf("\n Step 13 --->");fflush(stdout);
					GRM_find_relation(DocrevTag, PdfObject, relation_type, &pdfrel_tag);
					printf("\n Step 14 --->");fflush(stdout);
					GRM_delete_relation(pdfrel_tag);
					printf("\n Step 15 --->");fflush(stdout);
					AOM_save(DocrevTag);
					printf("\n Step 16 --->");fflush(stdout);
					pdfdelete++;
				}
				
				
			}
			if(iCountSecondary==0 || pdfdelete>0)
			{
				printf("\n Step 17 --->");fflush(stdout);
				GRM_create_relation(DocrevTag, NewPdfdataset, relation_type, NULLTAG, &relation);
				printf("\n Step 18 --->");fflush(stdout);
				GRM_save_relation(relation);
				printf("\n Step 19 --->");fflush(stdout);
			}
			
			
		}
	}
	*/

	MEM_free(AvailPdfObjects);
	MEM_free(PdfObjects);

	return ITK_ok;
}

int TML_Change_Creation_Date(tag_t revTag,date_t mod_date,date_t release_date,date_t Date_Received,date_t Auth_date)
{
	int		iCnt		= 0;
	int		ifail		= 0;
	tag_t	Doc_ModDate = NULLTAG;
	tag_t	Doc_ReleseDate = NULLTAG;
	tag_t	Doc_ReceiveDate = NULLTAG;
	tag_t	Doc_AuthDate = NULLTAG;

	if(DATE_IS_NULL(mod_date) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 001 \n");fflush(stdout);
		POM_attr_id_of_attr("t5_TSMod_Date", "T5_TMLStdRevision", &Doc_ModDate);
		POM_set_attr_date(1, &revTag, Doc_ModDate, mod_date);
		
		printf("\n Debugging ==> 002 \n");fflush(stdout);

		//ifail = AOM_save(revTag);

		
		
		POM_save_instances(1, &revTag, false);
		

		ifail = AOM_refresh(revTag,false);
		
	}
	if(DATE_IS_NULL(release_date) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 003 \n");fflush(stdout);

		POM_attr_id_of_attr("t5_TSRelDate", "T5_TMLStdRevision", &Doc_ReleseDate);
		POM_set_attr_date(1, &revTag, Doc_ReleseDate, release_date);
		
		printf("\n Debugging ==> 004 \n");fflush(stdout);

		//ifail = AOM_save(revTag);

		
		
		POM_save_instances(1, &revTag, false);
		

		ifail = AOM_refresh(revTag,false);
		
	}
	if(DATE_IS_NULL(Date_Received) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 005 \n");fflush(stdout);
		POM_attr_id_of_attr("t5_DateReceived", "T5_TMLStdRevision", &Doc_ReceiveDate);
		POM_set_attr_date(1, &revTag, Doc_ReceiveDate, Date_Received);		
		printf("\n Debugging ==> 006 \n");fflush(stdout);
		POM_save_instances(1, &revTag, false);		
		ifail = AOM_refresh(revTag,false);
		
	}
	if(DATE_IS_NULL(Auth_date) == 0)
	{
		ifail = AOM_refresh(revTag,true);
		
		printf("\n Debugging ==> 007 \n");fflush(stdout);
		POM_attr_id_of_attr("t5_DocCreateDate", "T5_TMLStdRevision", &Doc_AuthDate);
		POM_set_attr_date(1, &revTag, Doc_AuthDate, Auth_date);	
		printf("\n Debugging ==> 008 \n");fflush(stdout);
		POM_save_instances(1, &revTag, false);	
		ifail = AOM_refresh(revTag,false);
	}

	return ITK_ok;
}

static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;	

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==>%s 000899999 \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{		
		printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;
		
		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==> %d \n",month);fflush(stdout);
		printf("\n day ==> %d \n",day);fflush(stdout);
		printf("\n year ==> %d \n",year);fflush(stdout);
		printf("\n hour ==> %d \n",hour);fflush(stdout);
		printf("\n minute ==> %d \n",minute);fflush(stdout);
		printf("\n second ==> %d \n",second);fflush(stdout);

	}
	printf("\n date ==> %d \n",date);fflush(stdout);
	return date;
}

char* removeChar(char *str, char garbage) 
{

	int i=0;
    char s[50];
	char *retstr = NULL;
	char garbage1= '.';
	char garbage2= '\"';
	retstr=(char *)MEM_alloc(200);
	printf("garbage IS -->%c",garbage);
	strcpy( s, str);
    while(s[i]!='\0')
    {
        if(s[i]==garbage)
        {
            s[i]='-';
        }
		if(s[i]==garbage1)
        {
            s[i]='-';
        }
		if(s[i]==garbage2)
        {
            s[i]='-';
        }
        i++;
    }  
	printf("FILENAME IS -->%s",s);
	strcpy( retstr, s);
	printf("\nretstr IS -->%s",retstr);

	return retstr;
}

int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;
	
	tag_t *TMLISDOCUMENTOBJS	    = NULLTAG;
	tag_t *otherobjects			    = NULLTAG;
	tag_t TmlStd_type_tag			= NULLTAG;
	tag_t TmlStd_type_Revtag		= NULLTAG;
	tag_t object_create_input_tag   = NULLTAG;
	tag_t object_create_input_revtag= NULLTAG;
	tag_t new_tmlisdocobject        = NULLTAG;
	tag_t new_tmlisdocrevobject     = NULLTAG;
	tag_t TMLISDOCUMENT_tag			= NULLTAG;
	tag_t *t_allrevdocs				= NULLTAG;
	tag_t t_docrev					= NULLTAG;
	tag_t new_rev_tag				= NULLTAG;
	tag_t attr_id					= NULLTAG;
	tag_t tmlisdocrevobject			= NULLTAG;
	tag_t FoundTag					= NULLTAG;
	tag_t query						= NULLTAG;
	tag_t TMLStdquery				= NULLTAG;
	
	FILE* fptr = NULL;
	FILE* fptr1 = NULL;
	FILE* otherfptr = NULL;
	
	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* argstring1 = NULL;

	char *TMLStdNoDup					= NULL;
	char *TMLStdIssueNoDup				= NULL;
	char *TMLStdSeqDup					= NULL;
	char *TMLSupersededDup				= NULL;
	char *TMLFrozenDup					= NULL;
	char *TMTSOwnerDup					= NULL;
	char *TMTSAinNoDup					= NULL;
	char *TMTSHrmStdNoDup				= NULL;
	char *TMDocumentDescriptionDup		= NULL;
	char *TMTSJsrDeptDup				= NULL;
	char *TMTSLkhDeptDup				= NULL;
	char *TMTSPunDeptDup				= NULL;
	char *TMRespPartyDup				= NULL;
	char *TMOwnerNameDup				= NULL;
	char *TMDVolNoDup					= NULL;
	char *TMTSKeyword1Dup				= NULL;
	char *TMTSKeyword2Dup				= NULL;
	char *TMTSKeyword3Dup				= NULL;
	char *TMAlterationRemarkDup			= NULL;
	char *TMBulkReplicateDup			= NULL;
	char *TMLastModByDup				= NULL;
	char *TMRepDateDup					= NULL;
	char *TMRepFromDup					= NULL;
	char *TMRepStatDup					= NULL;
	char *TMRepToDup					= NULL;
	char *TMVerCreatorDup				= NULL;
	char *TMWitholdIssueIndDup			= NULL;
	char *TMDelIndDup					= NULL;
	char *TMRelDateDup					= NULL;
	char *TMMod_DateDup					= NULL;
	char *TMRemarkDup					= NULL;
	char *TMDateUpdatedDup				= NULL;
	char *TEMPTMRefISNoDup				= NULL;
	char *TMIsStdBRIndDup				= NULL;
	char *BL_Space1Dup					= NULL;
	char *BL_Space2Dup					= NULL;
	char *PDFNameDup					= NULL;
	char *pdfdoc_full_pathDup			= NULL;
	char *TMLStdDocNumber				= NULL;
	char *TMLStdDocRevision				= NULL;
	char *TMLStdIssueRev				= NULL;
	char *revi							= NULL;
	char *TempTMDelIndDup				= NULL;
	char *TempTMRemarkDup				= NULL;
	char *TMLStdDocSequenceId			= NULL;
	char *FoundObj_ItemId				= NULL;
	char *FoundObj_Type					= NULL;
	char *TempTMLStdNoDup				= NULL;
	char *tempfilename					= NULL;
	char *TMAuthorDup					= NULL;
	char *TMAuthorDateDup				= NULL;
	char *TMAddresseeDup				= NULL;
	char *TMCCAddresseeDup				= NULL;
	char *TMClassDup					= NULL;

	
	

	const char	   reason;
	const char     change_id;
	const char     dir_name;


	char
        *attrs[2] = {"ID","Type"},
        *values[2]	= {"*","*"};
	
		const char
        *otherattrs[1] = {"item_id"},
        *othervalues[1]	= {"*"};

	const char
        *attrs1[2] = {"item_id","object_type"},
        *values1[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	char *FileLocation					= NULL;
	char *FileLoc						= NULL;
	char *OtherFileLocation				= NULL;
	char *inputline						= NULL;
	char	*f	=NULL;
	char	result1 [ 100000 ] ;
	char	result2 [ 100000 ] ;
	

	date_t  TMDocModDate	= NULLDATE;
	date_t  TMDocRelDate	= NULLDATE;
	date_t  TMDateUpd		= NULLDATE;
	date_t  TMAuthDate		= NULLDATE;

	char	store[80000]  ;

	 int
        n_entries = 2,
        n_tags_found = 0;
        int n_tags_found_other = 0;
		int create_flag = 0;
		int i = 0;
		int cnt = 0;
		int TMLStdSeqValue = 0;
		int TMLStdSeqIdValue = 0;
		int n_tags_found1 = 0;
		int docrevcnt = 0;
		int copyrev = 0;
		int checkoutrev = 0;
		int	c2,c4,c1,elmt1	= 0;
		int	found = 0;
		int	otherFound = 0;
		int	n_rev_entries = 3;
		int	tt = 0;
		int	r = 0;

	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");

	z=ITK_CALL(ITK_auto_login());
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");
	}
	else
	{
	  printf("\n\n\t Login Successfull\n ");
	}

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	argstring1 = ITK_ask_cli_argument( "-i=");
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		printf("\n\n\t Login Successfull\n ");fflush(stdout);
		FileLocation=(char *)MEM_alloc(200);
		FileLoc=(char *)MEM_alloc(200);
		OtherFileLocation=(char *)MEM_alloc(200);
		TempTMDelIndDup=(char *)MEM_alloc(200);
		TempTMRemarkDup=(char *)MEM_alloc(200);
		TempTMLStdNoDup=(char *)MEM_alloc(200);
		tempfilename=(char *)MEM_alloc(200);

		
		
		/*CMITEST*/
		//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
		//tc_strcpy(FileLoc,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");

		/*UAPROD*/
		//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
		//tc_strcpy(FileLoc,"/user/bsd05818/sudhir/TMLISDOCLOADER_AferDeployment/");
		tc_strcpy(FileLoc,"/user/cvprod/sudhir/TMLISDOCLOADER_AferDeployment/");

		//tc_strcpy(TempTMLStdNoDup,argstring1);
		//if(tc_strstr(TempTMLStdNoDup,"\n")!=NULL)removeChar(TempTMLStdNoDup, '\n');
		//else if(tc_strstr(TempTMLStdNoDup," ")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ' ');
		//else if(tc_strstr(TempTMLStdNoDup,"/")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '/');
		//else if(tc_strstr(TempTMLStdNoDup,"\\")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\\');
		//else if(tc_strstr(TempTMLStdNoDup,"\0")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\0');
		//else if(tc_strstr(TempTMLStdNoDup,";")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ';');
		//else if(tc_strstr(TempTMLStdNoDup,",")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ',');
		//else tc_strcpy(tempfilename,argstring1);
		//printf("\n\n\t tempfilename-->[%s]\n",tempfilename);fflush(stdout);
		//tc_strcat(FileLocation,tempfilename);
		//tc_strcat(FileLocation,".txt");
		//printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
		//MEM_free(tempfilename);
		tc_strcpy(FileLoc,argstring1);
		printf("\n\n\t FileLoc-->[%s]\n",FileLoc);fflush(stdout);
		
		//fptr=fopen(FileLocation,"r");
		fptr1=fopen(FileLoc,"r");
		out_fp=fopen(NotLoad,"a+");
		
		
		//if(fptr!=NULL)
		//{
			//printf("\n file open .......");fflush(stdout);
		//}
		//else
		//{
			//printf("\n file not read .......");fflush(stdout);
		//}
		if(fptr1!=NULL)
		{
			printf("\n file1 open .......");fflush(stdout);
		}
		else
		{
			printf("\n file1 not read .......");fflush(stdout);
		}

		if(fptr1!=NULL)
		{
			inputline=(char *) MEM_alloc(50000);
			while(fgets(inputline,50000,fptr1)!=NULL)
			{
				for(r=0;r< strlen(inputline);r++)
				{
					if(inputline[r] == '\n' || inputline[r] == '\r' )
					{
						inputline[r] = '\0';
					}
				}
				while(1)
				{
					f = strstr(inputline,",,");
					if(f==NULL)
					{
						break;
					}

					strcpy(result2,f+1);					
					*(f+1)=' ';
					*(f+2)='\0';
					strcat(f,result2);
				 }
				 strcpy(result1,inputline);
				 printf("\n inputline .......%s\n",result1);fflush(stdout);
				 tc_strcpy(TempTMLStdNoDup,result1);
				 if(tempfilename!=NULL) MEM_free(tempfilename); tempfilename = NULL;
				 tempfilename=(char *)MEM_alloc(200);
				if(tc_strstr(TempTMLStdNoDup,"\n")!=NULL)removeChar(TempTMLStdNoDup, '\n');
				else if(tc_strstr(TempTMLStdNoDup," ")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ' ');
				else if(tc_strstr(TempTMLStdNoDup,"/")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '/');
				else if(tc_strstr(TempTMLStdNoDup,"\\")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\\');
				else if(tc_strstr(TempTMLStdNoDup,"\0")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\0');
				else if(tc_strstr(TempTMLStdNoDup,";")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ';');
				else if(tc_strstr(TempTMLStdNoDup,",")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ',');
				else if(tc_strstr(TempTMLStdNoDup,"\"")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\"');
				else if(tc_strstr(TempTMLStdNoDup,"_")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '_');
				else tc_strcpy(tempfilename,result1);
				printf("\n\n\t tempfilename-->[%s]\n",tempfilename);fflush(stdout);
				//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
				//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER_AferDeployment/");
				tc_strcpy(FileLocation,"/user/cvprod/sudhir/TMLISDOCLOADER_AferDeployment/");
				tc_strcat(FileLocation,tempfilename);
				tc_strcat(FileLocation,".txt");
				printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
				//MEM_free(tempfilename);
				fptr=fopen(FileLocation,"r");
				if(fptr!=NULL)
				{
					printf("\n file open .......");fflush(stdout);
					char	*ft	=NULL;
					char	*input_line	=NULL;
					char	result1t [ 100000 ] ;
					char	result2t [ 100000 ] ;
					input_line=(char *) MEM_alloc(500000);

					while(fgets(input_line, 500000, fptr)!=NULL)
					{
						for (i = 0; i < strlen(input_line); i++)
						{
							if ( input_line[i] == '\n' || input_line[i] == '\r' )
								input_line[i] = '\0';
						}
						while(1)
						{
							ft = strstr(input_line,",,");
							if(ft==NULL)
							{
								break;
							}

							strcpy(result2t,ft+1);					
							*(ft+1)=' ';
							*(ft+2)='\0';
							strcat(ft,result2t);
						}
						strcpy(result1t,input_line);
						printf("\n inputline .......%s\n",result1t);fflush(stdout);
						fputs(result1t,stdout);

						TMLStdNoDup=tc_strtok(result1t,"~");
						TMLStdIssueNoDup=tc_strtok(NULL,"~");
						TMLStdSeqDup=tc_strtok(NULL,"~");
						TMLSupersededDup=tc_strtok(NULL,"~");
						TMLFrozenDup=tc_strtok(NULL,"~");
						TMTSOwnerDup=tc_strtok(NULL,"~");
						TMTSHrmStdNoDup=tc_strtok(NULL,"~");
						TMTSAinNoDup=tc_strtok(NULL,"~");
						TMDocumentDescriptionDup=tc_strtok(NULL,"~");
						TMTSJsrDeptDup=tc_strtok(NULL,"~");
						TMTSLkhDeptDup=tc_strtok(NULL,"~");
						TMTSPunDeptDup=tc_strtok(NULL,"~");
						TMRespPartyDup=tc_strtok(NULL,"~");
						TMOwnerNameDup=tc_strtok(NULL,"~");
						TMDVolNoDup=tc_strtok(NULL,"~");
						TMTSKeyword1Dup=tc_strtok(NULL,"~");
						TMTSKeyword2Dup=tc_strtok(NULL,"~");
						TMTSKeyword3Dup=tc_strtok(NULL,"~");
						TMAlterationRemarkDup=tc_strtok(NULL,"~");
						TMBulkReplicateDup=tc_strtok(NULL,"~");
						TMLastModByDup=tc_strtok(NULL,"~");
						TMRepDateDup=tc_strtok(NULL,"~");
						TMRepFromDup=tc_strtok(NULL,"~");
						TMRepStatDup=tc_strtok(NULL,"~");
						TMRepToDup=tc_strtok(NULL,"~");
						TMVerCreatorDup=tc_strtok(NULL,"~");
						TMWitholdIssueIndDup=tc_strtok(NULL,"~");
						TMDelIndDup=tc_strtok(NULL,"~");
						TMRelDateDup=tc_strtok(NULL,"~");
						TMMod_DateDup=tc_strtok(NULL,"~");
						TMRemarkDup=tc_strtok(NULL,"~");
						TMDateUpdatedDup=tc_strtok(NULL,"~");
						TEMPTMRefISNoDup=tc_strtok(NULL,"~");
						TMIsStdBRIndDup=tc_strtok(NULL,"~");
						TMAuthorDup=tc_strtok(NULL,"~");
						TMAuthorDateDup=tc_strtok(NULL,"~");
						TMAddresseeDup=tc_strtok(NULL,"~");
						TMCCAddresseeDup=tc_strtok(NULL,"~");
						TMClassDup=tc_strtok(NULL,"~");
						PDFNameDup=tc_strtok(NULL,"~");
						pdfdoc_full_pathDup=tc_strtok(NULL,"~");

						printf("\n TMLStdNoDup .......%s",TMLStdNoDup);fflush(stdout);
						printf("\n TMLStdIssueNoDup .......%s",TMLStdIssueNoDup);fflush(stdout);
						printf("\n TMLStdSeqDup .......%s",TMLStdSeqDup);fflush(stdout);
						printf("\n TMLSupersededDup .......%s",TMLSupersededDup);fflush(stdout);
						printf("\n TMLFrozenDup .......%s",TMLFrozenDup);fflush(stdout);
						printf("\n TMTSOwnerDup .......%s",TMTSOwnerDup);fflush(stdout);
						printf("\n TMTSHrmStdNoDup .......%s",TMTSHrmStdNoDup);fflush(stdout);
						printf("\n TMTSAinNoDup .......%s",TMTSAinNoDup);fflush(stdout);
						printf("\n TMDocumentDescriptionDup .......%s",TMDocumentDescriptionDup);fflush(stdout);
						printf("\n TMTSJsrDeptDup .......%s",TMTSJsrDeptDup);fflush(stdout);
						printf("\n TMTSLkhDeptDup .......%s",TMTSLkhDeptDup);fflush(stdout);
						printf("\n TMTSPunDeptDup .......%s",TMTSPunDeptDup);fflush(stdout);
						printf("\n TMRespPartyDup .......%s",TMRespPartyDup);fflush(stdout);
						printf("\n TMOwnerNameDup .......%s",TMOwnerNameDup);fflush(stdout);
						printf("\n TMDVolNoDup .......%s",TMDVolNoDup);fflush(stdout);
						printf("\n TMTSKeyword1Dup .......%s",TMTSKeyword1Dup);fflush(stdout);
						printf("\n TMTSKeyword2Dup .......%s",TMTSKeyword2Dup);fflush(stdout);
						printf("\n TMTSKeyword3Dup .......%s",TMTSKeyword3Dup);fflush(stdout);
						printf("\n TMAlterationRemarkDup .......%s",TMAlterationRemarkDup);fflush(stdout);
						printf("\n TMBulkReplicateDup .......%s",TMBulkReplicateDup);fflush(stdout);
						printf("\n TMLastModByDup .......%s",TMLastModByDup);fflush(stdout);
						printf("\n TMRepDateDup .......%s",TMRepDateDup);fflush(stdout);
						printf("\n TMRepFromDup .......%s",TMRepFromDup);fflush(stdout);
						printf("\n TMRepStatDup .......%s",TMRepStatDup);fflush(stdout);
						printf("\n TMRepToDup .......%s",TMRepToDup);fflush(stdout);
						printf("\n TMVerCreatorDup .......%s",TMVerCreatorDup);fflush(stdout);
						printf("\n TMWitholdIssueIndDup .......%s",TMWitholdIssueIndDup);fflush(stdout);
						printf("\n TMDelIndDup .......%s",TMDelIndDup);fflush(stdout);
						printf("\n TMRelDateDup .......%s",TMRelDateDup);fflush(stdout);
						printf("\n TMMod_DateDup .......%s",TMMod_DateDup);fflush(stdout);
						printf("\n TMRemarkDup .......%s",TMRemarkDup);fflush(stdout);
						printf("\n TMDateUpdatedDup .......%s",TMDateUpdatedDup);fflush(stdout);
						printf("\n TEMPTMRefISNoDup .......%s",TEMPTMRefISNoDup);fflush(stdout);
						printf("\n TMIsStdBRIndDup .......%s",TMIsStdBRIndDup);fflush(stdout);
						printf("\n TMAuthorDup .......%s",TMAuthorDup);fflush(stdout);
						printf("\n TMAuthorDateDup .......%s",TMAuthorDateDup);fflush(stdout);
						printf("\n TMAddresseeDup .......%s",TMAddresseeDup);fflush(stdout);
						printf("\n TMCCAddresseeDup .......%s",TMCCAddresseeDup);fflush(stdout);
						printf("\n TMClassDup .......%s",TMClassDup);fflush(stdout);
						printf("\n PDFNameDup .......%s",PDFNameDup);fflush(stdout);
						printf("\n pdfdoc_full_pathDup .......%s",pdfdoc_full_pathDup);fflush(stdout);

						values[0] = TMLStdNoDup;
						values[1] = "TML Standard Class";
						QRY_find("tm_TMLStdDoc", &TMLStdquery);
						if(TMLStdquery!=NULLTAG)
						{
							printf("\n values[0] .......%s",values[0]);fflush(stdout);
							printf("\n values[1] .......%s",values[1]);fflush(stdout);
							
							QRY_execute(TMLStdquery, 2, attrs, values, &n_tags_found, &TMLISDOCUMENTOBJS);
						}
						printf("\n TMLStdNoDup .......[%s]",TMLStdNoDup);fflush(stdout);

						if(n_tags_found>0)
						{
							printf("\n TMLStdNo [%s] Found",TMLStdNoDup);fflush(stdout);
							qry_values[0] = TMLStdNoDup;
							qry_values[1] = "TML Std Revision";
							qry_values[2] = TMLStdIssueNoDup;

							QRY_find("All Sequences", &query);
							if(query!=NULLTAG)
							{
								printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
								printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
								printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
								QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &t_allrevdocs);
								if(n_tags_found1>0)
								{
									printf("\n TMLStdNo [%s]-->Revision [%s] Found",TMLStdNoDup,TMLStdIssueNoDup);fflush(stdout);
									for(cnt=0;cnt<n_tags_found1;cnt++)
									{
										tmlisdocrevobject = t_allrevdocs[cnt];
										TMLSTD_CreateRelation_ISDOC(tmlisdocrevobject,TEMPTMRefISNoDup,TMIsStdBRIndDup);
										//PdfUploadFunction(tmlisdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
									}										
								}
							}
						}
						

					} // End of while Loop.
				}// fptr
				else
				{
					printf("\n file not read .......");fflush(stdout);
				}
				MEM_free(TMLISDOCUMENTOBJS);
				if(fptr!=NULL)fclose(fptr); fptr = NULL;
			}
		}
		
		
	}
	if(fptr1!=NULL)fclose(fptr1); fptr1 = NULL;
	return ITK_ok;
}