/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   TMLISDOCUPLOAD.c
*  Author		 :   Sudhir
*  Module		 :   TMLISDOCUPLOAD create in TCUA
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100

#define CONST_MAX_YEAR			 2100
#define CONST_MIN_YEAR			 1975
#define CONST_MAX_MONTH			 11
#define CONST_MIN_MONTH			 0
#define CONST_MIN_DAY			 1
#define CONST_MAX_DAY			 31
#define CONST_MIN_HOUR			 00
#define CONST_MAX_HOUR		     23
#define CONST_MIN_MINUTE		 00
#define CONST_MAX_MINUTE		 59
#define CONST_MIN_SECOND		 00
#define CONST_MAX_SECOND		 59
#define NotLoad		 "/user/cvprod/sudhir/TMLISDOCLOADER/Exist.txt"
#define NotLoaded		 "/user/cvprod/sudhir/TMLISDOCLOADER/Result.txt"
#define RelationNotLoaded		 "/user/cvprod/sudhir/TMLISDOCLOADER/Relation.txt"
//#define NotLoad		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Exist.txt"
//#define NotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Result.txt"
//#define RelationNotLoaded		 "/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/Relation.txt"
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

struct func
{
	 char TMLStdNo[100];
	 char TMLStdIssueNo[100];
	 char TMLStdSeq[500];
	 char TMLSuperseded[500];
	 char TMLFrozen[1000];
	 char TMTSOwner[1000];
	 char TMTSHrmStdNo[1000];
	 char TMTSAinNo[1000];
	 char TMDocumentDescription[1000];
	 char TMTSJsrDept[1000];
	 char TMTSLkhDept[1000];
	 char TMTSPunDept[1000];
	 char TMRespParty[1000];
	 char TMOwnerName[1000];
	 char TMDVolNo[200];
	 char TMTSKeyword1[200];
	 char TMTSKeyword2[200];
	 char TMTSKeyword3[200];
	 char TMAlterationRemark[1000];
	 char TMBulkReplicate[1000];
	 char TMLastModBy[1000];
	 char TMRepDate[200];
	 char TMRepFrom[200];
	 char TMRepStat[200];
	 char TMRepTo[200];
	 char TMVerCreator[200];
	 char TMWitholdIssueInd[200];
	 char TMDelInd[200];
	 char TMRelDate[200];
	 char TMMod_Date[200];
	 char TMRemark[200];
	 char TMDateUpdated[200];
	 char TEMPTMRefISNo[200];
	 char TMIsStdBRInd[200];
	 char BL_Space1[200];
	 char BL_Space2[200];
	 char PDFName[200];
	 char pdfdoc_full_path[200];
	 


} tmlisdocobjupload[800000];
static FILE* out_fp;
static FILE* output_fp;
static FILE* output_fp1;
logical IsValideDate(date_t *date)
{
	logical isFlag		= false;
	date_t  localdate  = NULLDATE;

	localdate = *date;	
	
	//Check if date is null
	if(DATE_IS_NULL(localdate) != 1)
	{
		if(date->year < CONST_MIN_YEAR)
			date->year = CONST_MIN_YEAR;

		if (date->year > CONST_MAX_YEAR)
			date->year = CONST_MAX_YEAR;
		
		if(date->month < CONST_MIN_MONTH)
			date->month = CONST_MIN_MONTH;

		if(date->month > CONST_MAX_MONTH)
			date->month = CONST_MAX_MONTH;

		if(date->day < CONST_MIN_DAY)
			date->day = CONST_MIN_DAY;

		if(date->day > CONST_MAX_DAY)
			date->day = CONST_MAX_DAY;

		if(date->hour < CONST_MIN_HOUR)
			date->hour = CONST_MIN_HOUR;

		if(date->hour > CONST_MAX_HOUR)
			date->hour = CONST_MAX_HOUR;

		if(date->minute < CONST_MIN_MINUTE)
			date->minute = CONST_MIN_MINUTE;

		if(date->minute > CONST_MAX_MINUTE)
			date->minute = CONST_MAX_MINUTE;

		if(date->second < CONST_MIN_SECOND)
			date->second = CONST_MIN_SECOND;

		if(date->second > CONST_MAX_SECOND)
			date->second = CONST_MAX_SECOND;

		//For the months of April, June, September and November, check the date to be less than or equal to 30
		if (date->month == 3 || date->month == 5 || date->month == 8 || date->month == 10)
		{
			if (date->day > 30)
				date->day = 30;
		}

		//For the month of February,
		/////If the year is a leap year, then check the date to be less than or equal to 29
		/////Else, check the date to be less than or equal to 28
		if (date->month == 1)
		{
			if((date->year % 4 == 0 && date->year % 100 != 0) || date->year % 400 == 0)
			{
				if (date->day > 29)
					date->day = 29;
			}
			else
			{
				if (date->day > 28)
					date->day = 28;
			}
		}
		
		//Set the Flag true
		isFlag = true;
	}

	return isFlag;
}

static int TML_token_to_int( const char *str )
{
	return (int) strtol( str, NULL, 10);
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

int TMLSTD_CreateRelation_ISDOC(tag_t DocrevTag,char *ReferedStdNumber,char *BRIndicator)
{
	int		ifail			= 0;
	int		tt1				= 0;
	int		tt2				= 0;
	int		sr,sb			= 0;
	int		n_tags_found	= 0;
	int		relcount		= 0;
	int		doc				= 0;
	

	char *TMLStdDocId		= NULL;
	char**	RefStdIsDocSet	= NULL;
	char**	RefStdBRIndSet	= NULL;
	char * pch1				= NULL;
	char * pch2				= NULL;
	char * Doc_Num			= NULL;
	char * Doc_Rev			= NULL;
	char * Doc_Seq			= NULL;
	char * DocRevId			= NULL;
	char * DocId			= NULL;
	char *ReferedDocNum		= NULL;
	char *ReferedDocBRInd	= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};


	tag_t	relation_type1	= NULLTAG;
	tag_t	*t_allrevdocs	= NULLTAG;
	tag_t	*AvailObjects	= NULLTAG;
	tag_t	Avail_Object	= NULLTAG;
	tag_t	relation		= NULLTAG;
	
	//RefStdIsDocSet = (char**)MEM_alloc( 1 * sizeof *RefStdIsDocSet );
	//RefStdBRIndSet = (char**)MEM_alloc( 1 * sizeof *RefStdBRIndSet );

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	
	printf("\n TMLSTD_CreateRelation_ISDOC::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n TMLSTD_CreateRelation_ISDOC::ReferedStdNumber .......[%s]",ReferedStdNumber);fflush(stdout);
	printf("\n TMLSTD_CreateRelation_ISDOC::BRIndicator .......[%s]",BRIndicator);fflush(stdout);

	GRM_find_relation_type("T5_TSISR", &relation_type1);

	output_fp1=fopen(RelationNotLoaded,"a+");

	if(ReferedStdNumber!=NULL)
	{
		
		pch1 = tc_strtok(ReferedStdNumber,";");
		printf("\n pch1 .......[%s]",pch1);fflush(stdout);
		if(pch1!=NULL)
		{
			setAddStr(&tt1,&RefStdIsDocSet,pch1);
		}
		while(pch1 != NULL)
		{
			pch1 = tc_strtok(NULL, ";");
			printf("\n pch1 .......[%s]",pch1);fflush(stdout);
			if(pch1!=NULL)
			{
				setAddStr(&tt1,&RefStdIsDocSet,pch1);
			}
		}
	}
	if(BRIndicator!=NULL)
	{
		
		pch2 = tc_strtok(BRIndicator,";");
		printf("\n pch2 .......[%s]",pch2);fflush(stdout);
		if(pch2!=NULL)
		{
			setAddStr(&tt2,&RefStdBRIndSet,pch2);
		}
		while(pch2 != NULL)
		{
			pch2= tc_strtok(NULL, ";");
			printf("\n pch2 .......[%s]",pch2);fflush(stdout);
			if(pch2!=NULL)
			{
				setAddStr(&tt2,&RefStdBRIndSet,pch2);
			}
		}
	}
	printf("\n tt1 .......[%d]",tt1);fflush(stdout);
	printf("\n tt2 .......[%d]",tt2);fflush(stdout);
	if(tt1>0)
	{
		for(sr = 0, sb = 0; sr < tt1 && sb <tt2; sr++, sb++)
		{
			ReferedDocNum = RefStdIsDocSet[sr];
			ReferedDocBRInd = RefStdBRIndSet[sb];
			printf("\n ReferedDocNum .......[%s]",ReferedDocNum);fflush(stdout);
			printf("\n ReferedDocBRInd .......[%s]",ReferedDocBRInd);fflush(stdout);
			if(ReferedDocNum!=NULL)
			{
				Doc_Num = tc_strtok(ReferedDocNum,"-");
				Doc_Rev= tc_strtok(NULL, "-");
				Doc_Seq= tc_strtok(NULL, "-");
				printf("\n Doc_Num .......[%s]",Doc_Num);fflush(stdout);
				printf("\n Doc_Rev .......[%s]",Doc_Rev);fflush(stdout);
				printf("\n Doc_Seq .......[%s]",Doc_Seq);fflush(stdout);
				values[0] = Doc_Num;
				if(tc_strstr(ReferedDocNum,"TS")!=NULL)
				{
					values[1] = "T5_TMLStdRevision";
				}
				else
				{
					values[1] = "T5_IStdRevision";
				}
				printf("\n values[0] .......[%s]",values[0]);fflush(stdout);
				printf("\n values[1] .......[%s]",values[1]);fflush(stdout);
				ITEM_find_item_revs_by_key_attributes(2,attrs, values,Doc_Rev,&n_tags_found, &t_allrevdocs);
				if(n_tags_found>0)
				{
					GRM_list_secondary_objects_only(DocrevTag, relation_type1, &relcount, &AvailObjects);
					if(relcount>0)
					{
						for(doc=0;doc<relcount;doc++)
						{
							Avail_Object = AvailObjects[doc];
							AOM_ask_value_string(Avail_Object,"item_id",&DocId);
							printf("\n TMLSTD_CreateRelation_ISDOC::DocId .......%s",DocId);fflush(stdout);

							AOM_ask_value_string(Avail_Object,"item_revision_id",&DocRevId);
							printf("\n TMLSTD_CreateRelation_ISDOC::DocRevId .......%s",DocRevId);fflush(stdout);
							if(tc_strcmp(DocId,Doc_Num)==0 && tc_strcmp(DocRevId,Doc_Rev)==0)
							{
								printf("\n TMLSTD_CreateRelation_ISDOC::Relation Exist!!");fflush(stdout);
							}
							else
							{
								printf("\n TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
								GRM_create_relation(DocrevTag, Avail_Object, relation_type1, NULLTAG, &relation);
								GRM_save_relation(relation);
								printf("\n TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n ELSE::TMLSTD_CreateRelation_ISDOC::Relation Not Exist!!");fflush(stdout);
						Avail_Object = t_allrevdocs[0];
						GRM_create_relation(DocrevTag, Avail_Object, relation_type1, NULLTAG, &relation);
						GRM_save_relation(relation);
						printf("\n ELSE::TMLSTD_CreateRelation_ISDOC::Relation Created !!");fflush(stdout);
					}
				}
				else
				{
					printf("\n TML STD DOC is not yet Loaded!!");fflush(stdout);
					fprintf(output_fp1,"%s",Doc_Num);
					fprintf(output_fp1,"~");
					fprintf(output_fp1,"NOT LOADED");
					fprintf(output_fp1,"\n");
				}
				
			}			
		}
	}
	return ITK_ok;
}

int TML_IS_DOC_Result_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;
	char *strSeqIdValue		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_TMLStd";
	
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdNo .......[%s]",TMLStdNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdIssueNo .......[%s]",TMLStdIssueNo);fflush(stdout);
	printf("\n TML_IS_DOC_Result_Avaialble::TMLStdSeq .......[%s]",TMLStdSeq);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);
	strSeqIdValue=(char *)MEM_alloc(200);




	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of TMLStd=>%d", n_tags_found);fflush(stdout);
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		qry_values[0] = TMLStdNo;
		qry_values[1] = "TML Std Revision";
		qry_values[2] = TMLStdIssueNo;
		QRY_find("All Sequences", &query);
		if(query!=NULLTAG)
		{
			QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			if(n_tags_found1==0)
			{
				fprintf(output_fp,"%s",TMLStdNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);
					sprintf(strSeqIdValue,"%d",SeqIdValue);

					fprintf(output_fp,"%s",TMLStdNo);
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",DocRevision);
					fprintf(output_fp,"~");
					fprintf(output_fp,"REVISION IS LOADED");
					fprintf(output_fp,"~");
					fprintf(output_fp,"%s",strSeqIdValue);
					fprintf(output_fp,"~");
					fprintf(output_fp,"\n");
				}
			}
		}
	}

	MEM_free(DOCUMENTOBJS);
	MEM_free(allrevdocs);
	return ITK_ok;
}

int TML_IS_DOC_Avaialble(char *TMLStdNo,char *TMLStdIssueNo,char *TMLStdSeq)
{
	int		ifail			= 0;

	int	n_tags_found		= 0;
	int	cnt					= 0;
	int	n_tags_found1		= 0;
	int	revcnt				= 0;
	int	n_rev_entries		= 3;
	int	SeqIdValue;
	int	DocSeqValue;

	tag_t	*DOCUMENTOBJS	= NULLTAG;
	tag_t	doc_tag			= NULLTAG;
	tag_t	query			= NULLTAG;
	tag_t	*allrevdocs		= NULLTAG;
	tag_t	docrevobject	= NULLTAG;

	char *DocNumber			= NULL;
	char *DocRevision		= NULL;

	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	char
        *qry_entries[3] = {"Item ID","Type","Revision"},
        *qry_values[3]	= {"*","*","*"};


	output_fp=fopen(NotLoaded,"a+");


	values[0] = TMLStdNo;
	values[1] = "T5_TMLStd";
	
	printf("\n TML_IS_DOC_Avaialble::values[0] .......[%s]",values[0]);fflush(stdout);
	printf("\n TML_IS_DOC_Avaialble::values[1] .......[%s]",values[1]);fflush(stdout);

	DocSeqValue=TML_token_to_int(TMLStdSeq);
	printf("\n TML_IS_DOC_Avaialble::DocSeqValue=>%d", DocSeqValue);fflush(stdout);

	ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &DOCUMENTOBJS);
	printf("\n TML_IS_DOC_Avaialble::Number of TMLStd=>%d", n_tags_found);fflush(stdout);
	//fprintf(output_fp,"TML STD DOC NO~REVISION~STATUS");
	fprintf(output_fp,"\n");
	if(n_tags_found==0)
	{
		fprintf(output_fp,"%s",TMLStdNo);
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT AVAILABLE");
		fprintf(output_fp,"~");
		fprintf(output_fp,"NOT LOADED");
		fprintf(output_fp,"~");
		
	}
	else
	{
		printf("\n TML_IS_DOC_Avaialble::in else n_tags_found .......%d",n_tags_found);fflush(stdout);
		for(cnt=0;cnt<n_tags_found;cnt++)
		{
			doc_tag = DOCUMENTOBJS[cnt];
			AOM_ask_value_string(doc_tag,"item_id",&DocNumber);
			printf("\n TML_IS_DOC_Avaialble::DocNumber .......%s",DocNumber);fflush(stdout);
			fprintf(output_fp,"%s",DocNumber);
			fprintf(output_fp,"~");

			qry_values[0] = DocNumber;
			qry_values[1] = "TML Std Revision";
			qry_values[2] = TMLStdIssueNo;

			QRY_find("All Sequences", &query);
			if(query!=NULLTAG)
			{
				printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
				printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
				printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
				QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &allrevdocs);
			}
			printf("\n TML_IS_DOC_Avaialble::n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
			if(n_tags_found1==0)
			{
				//ITEM_ask_latest_rev(doc_tag,&docrevobject);
				fprintf(output_fp,"%s",TMLStdIssueNo);
				fprintf(output_fp,"~");
				fprintf(output_fp,"REVISION NOT LOADED");
				fprintf(output_fp,"~");
			}
			else
			{
				for(revcnt=0;revcnt<n_tags_found1;revcnt++)
				{
					docrevobject = allrevdocs[revcnt];
					AOM_ask_value_string(docrevobject,"item_revision_id",&DocRevision);
					printf("\n TML_IS_DOC_Avaialble::DocRevision .......%s",DocRevision);fflush(stdout);

					AOM_ask_value_int(docrevobject,"sequence_id",&SeqIdValue);
					printf("\n TML_IS_DOC_Avaialble::SeqIdValue .......%d",SeqIdValue);fflush(stdout);

					if(tc_strcmp(DocRevision,TMLStdIssueNo)==0)
					{
						if(SeqIdValue==DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"LOADED");
						}
						if(SeqIdValue!=DocSeqValue)
						{
							fprintf(output_fp,"%s-%s",TMLStdIssueNo,TMLStdSeq);
							fprintf(output_fp,"~");
							fprintf(output_fp,"NOT LOADED");
							fprintf(output_fp,"~");
						}
					}
				}
			}
		}
	}

	return ITK_ok;
}
int PdfUploadFunction(tag_t DocrevTag,char *pdfname,char *pdflocation)
{
	int		ifail			= 0;
	int		iCountSecondary	= 0;
	int		pdfcnt			= 0;
	int		pdfdelete		= 0;
	int		pdfcount		= 0;

	char *TMLStdDocId		= NULL;
	char *TMLStdDocDesc		= NULL;
	char *pdfdatasetname	= NULL;
	char *format			= NULL;
	char **ref_list;

	tag_t	NewPdfdataset	= NULLTAG;
	tag_t	datasettype		= NULLTAG;
	tag_t	tool			= NULLTAG;
	tag_t	filetag			= NULLTAG;
	tag_t	relation_type	= NULLTAG;
	tag_t	relation		= NULLTAG;
	tag_t	*PdfObjects		= NULLTAG;
	tag_t	PdfObject		= NULLTAG;
	tag_t	pdfrel_tag		= NULLTAG;
	tag_t	PdfObject1		= NULLTAG;
	tag_t	relation_type1	= NULLTAG;
	tag_t	pdfrel_tag1		= NULLTAG;
	tag_t	*AvailPdfObjects= NULLTAG;

	logical			checkout = 0;

	IMF_file_t	fileDescriptor;
	AE_reference_type_t	tagRefType = 1;

	int		ref_count;

	AOM_ask_value_string(DocrevTag,"item_id",&TMLStdDocId);
	printf("\n PdfUploadFunction::TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	AOM_ask_value_string(DocrevTag,"object_desc",&TMLStdDocDesc);
	printf("\n TMLStdDocId .......[%s]",TMLStdDocId);fflush(stdout);
	printf("\n pdfname .......[%s]",pdfname);fflush(stdout);
	printf("\n pdflocation .......[%s]",pdflocation);fflush(stdout);
	pdfdatasetname = strtok(pdfname , ".");
	printf("\nDataset name ---> %s",pdfdatasetname);fflush(stdout);
	if(pdfdatasetname!=NULL)
	{
		format = strtok(NULL , ".");
		printf("\nDataset format Else---->%s",format);fflush(stdout);
	}
	GRM_find_relation_type("IMAN_Rendering", &relation_type1);
	GRM_find_relation(DocrevTag, PdfObject1, relation_type1, &pdfrel_tag1);
	GRM_list_secondary_objects_only(DocrevTag, relation_type1, &pdfcount, &AvailPdfObjects);

	if(pdfcount>0)
	{
		printf("\n PDF IS AVAILABLE");fflush(stdout);
	}
	else
	{
		if(tc_strcmp(format,"pdf")==0 || tc_strcmp(format,"PDF")==0)
		{
			printf("\n Step 1 --->");fflush(stdout);
			AE_find_datasettype("PDF", &datasettype);
			printf("\n Step 2 --->");fflush(stdout);
			AE_create_dataset_with_id(datasettype,pdfdatasetname,TMLStdDocDesc, NULL, NULL, &NewPdfdataset);
			printf("\n Step 3 --->");fflush(stdout);
			AE_set_dataset_format(NewPdfdataset, "BINARY_REF");
			printf("\n Step 4 --->");fflush(stdout);
			AE_ask_datasettype_def_tool(datasettype, &tool);
			printf("\n Step 5 --->");fflush(stdout);
			AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
			printf("\n Step 6 --->");fflush(stdout);
			IMF_import_file(pdflocation,NULL, SS_BINARY, &filetag, &fileDescriptor);
			printf("\n Step 7 --->");fflush(stdout);
			AOM_save(filetag);
			printf("\n Step 8 --->");fflush(stdout);
			AE_add_dataset_named_ref(NewPdfdataset,ref_list[0],tagRefType,filetag);
			printf("\n Step 9 --->");fflush(stdout);
			AE_set_dataset_tool(NewPdfdataset,tool);
			printf("\n Step 10 --->");fflush(stdout);
			AOM_save(NewPdfdataset);
			printf("\n Step 11 --->");fflush(stdout);

			RES_is_checked_out(DocrevTag,&checkout);
			GRM_find_relation_type("IMAN_Rendering", &relation_type);
			if (checkout==1)
			{
				GRM_list_secondary_objects_only(DocrevTag, relation_type, &iCountSecondary, &PdfObjects);
				printf("\n Step 12 iCountSecondary --->%d",iCountSecondary);fflush(stdout);
			}
			if(iCountSecondary>0)
			{
				for(pdfcnt=0;pdfcnt<iCountSecondary;pdfcnt++)
				{
					PdfObject = PdfObjects[pdfcnt];
					printf("\n Step 13 --->");fflush(stdout);
					GRM_find_relation(DocrevTag, PdfObject, relation_type, &pdfrel_tag);
					printf("\n Step 14 --->");fflush(stdout);
					GRM_delete_relation(pdfrel_tag);
					printf("\n Step 15 --->");fflush(stdout);
					AOM_save(DocrevTag);
					printf("\n Step 16 --->");fflush(stdout);
					pdfdelete++;
				}
				
				
			}
			if(iCountSecondary==0 || pdfdelete>0)
			{
				printf("\n Step 17 --->");fflush(stdout);
				GRM_create_relation(DocrevTag, NewPdfdataset, relation_type, NULLTAG, &relation);
				printf("\n Step 18 --->");fflush(stdout);
				GRM_save_relation(relation);
				printf("\n Step 19 --->");fflush(stdout);
			}
			
			
		}
	}

	

	return ITK_ok;
}


int TML_Change_Creation_Date(tag_t revTag,date_t mod_date,date_t release_date)
{
	int		iCnt		= 0;
	int		ifail		= 0;
	tag_t	Doc_ModDate = NULLTAG;
	tag_t	Doc_ReleseDate = NULLTAG;

	if(DATE_IS_NULL(mod_date) == 0)
	{
		if(IsValideDate(&mod_date))
		{
			ifail = AOM_refresh(revTag,true);
		
			printf("\n Debugging ==> 003 \n");fflush(stdout);
			POM_attr_id_of_attr("t5_TSMod_Date", "T5_TMLStdRevision", &Doc_ModDate);
			POM_set_attr_date(1, &revTag, Doc_ModDate, mod_date);
			
			printf("\n Debugging ==> 004 \n");fflush(stdout);

			//ifail = AOM_save(revTag);

			
			
			POM_save_instances(1, &revTag, false);
			

			ifail = AOM_refresh(revTag,false);
		}
		
		
	}
	if(DATE_IS_NULL(release_date) == 0)
	{
		if(IsValideDate(&release_date))
		{
			ifail = AOM_refresh(revTag,true);
		
			printf("\n Debugging ==> 003 \n");fflush(stdout);

			POM_attr_id_of_attr("t5_TSRelDate", "T5_TMLStdRevision", &Doc_ReleseDate);
			POM_set_attr_date(1, &revTag, Doc_ReleseDate, release_date);
			
			printf("\n Debugging ==> 004 \n");fflush(stdout);

			//ifail = AOM_save(revTag);

			
			
			POM_save_instances(1, &revTag, false);
			

			ifail = AOM_refresh(revTag,false);
		}
		
		
	}

	return ITK_ok;
}

static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;	

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==>%s 000899999 \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{		
		printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;
		
		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==> %d \n",month);fflush(stdout);
		printf("\n day ==> %d \n",day);fflush(stdout);
		printf("\n year ==> %d \n",year);fflush(stdout);
		printf("\n hour ==> %d \n",hour);fflush(stdout);
		printf("\n minute ==> %d \n",minute);fflush(stdout);
		printf("\n second ==> %d \n",second);fflush(stdout);

	}
	printf("\n date ==> %d \n",date);fflush(stdout);
	return date;
}

char* removeChar(char *str, char garbage) 
{

	int i=0;
    char s[50];
	char *retstr = NULL; 
	retstr=(char *)MEM_alloc(200);
	strcpy( s, str);
    while(s[i]!='\0')
    {
        if(s[i]==garbage)
        {
            s[i]='-';
        }
        i++;
    }  
	printf("FILENAME IS -->%s",s);
	strcpy( retstr, s);
	printf("\nretstr IS -->%s",retstr);

	return retstr;
}

int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;
	
	
	
	FILE* fptr = NULL;
	FILE* fptr1 = NULL;
	FILE* otherfptr = NULL;
	
	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* argstring1 = NULL;

	char *TempTMLStdNoDup				= NULL;
	char *tempfilename					= NULL;
	char *FileLocation					= NULL;
	char *FileLoc						= NULL;
	char *OtherFileLocation				= NULL;
	char *inputline						= NULL;
	char *result1					= NULL;
	char	*f	=NULL;
	//char	result1 [ 100000 ] ;
	char	result2 [ 100000 ] ;
	

	

	
		int	r = 0;
		int	strcnt = 0;
		int	len = 0;

	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (0));
	printf("\n\n\t Attempting Logging\n ");fflush(stdout);



	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	argstring1 = ITK_ask_cli_argument( "-i=");
	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		printf("\n\n\t Login Successfull\n ");fflush(stdout);
		//FileLocation=(char *)MEM_alloc(200);
		FileLoc=(char *)MEM_alloc(200);
		//OtherFileLocation=(char *)MEM_alloc(200);
		
		//TempTMLStdNoDup=(char *)MEM_alloc(200);
		//tempfilename=(char *)MEM_alloc(200);

		
		
		/*CMITEST*/
		//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
		
		//tc_strcpy(FileLoc,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");

		/*UAPROD*/
		//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
		//tc_strcpy(FileLoc,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
		tc_strcpy(FileLoc,"/user/cvprod/sudhir/TMLISDOCLOADER/");

		//tc_strcpy(TempTMLStdNoDup,argstring1);
		//if(tc_strstr(TempTMLStdNoDup,"\n")!=NULL)removeChar(TempTMLStdNoDup, '\n');
		//else if(tc_strstr(TempTMLStdNoDup," ")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ' ');
		//else if(tc_strstr(TempTMLStdNoDup,"/")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '/');
		//else if(tc_strstr(TempTMLStdNoDup,"\\")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\\');
		//else if(tc_strstr(TempTMLStdNoDup,"\0")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\0');
		//else if(tc_strstr(TempTMLStdNoDup,";")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ';');
		//else if(tc_strstr(TempTMLStdNoDup,",")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ',');
		//else tc_strcpy(tempfilename,argstring1);
		//printf("\n\n\t tempfilename-->[%s]\n",tempfilename);fflush(stdout);
		//tc_strcat(FileLocation,tempfilename);
		//tc_strcat(FileLocation,".txt");
		//printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
		//MEM_free(tempfilename);
		tc_strcpy(FileLoc,argstring1);
		printf("\n\n\t FileLoc-->[%s]\n",FileLoc);fflush(stdout);
		
		//fptr=fopen(FileLocation,"r");
		fptr1=fopen(FileLoc,"r");
		out_fp=fopen(NotLoad,"a+");
		
		
		//if(fptr!=NULL)
		//{
			//printf("\n file open .......");fflush(stdout);
		//}
		//else
		//{
			//printf("\n file not read .......");fflush(stdout);
		//}
		if(fptr1!=NULL)
		{
			printf("\n file1 open .......");fflush(stdout);
		}
		else
		{
			printf("\n file1 not read .......");fflush(stdout);
		}

		if(fptr1!=NULL)
		{
			if(inputline)MEM_free(inputline);
			inputline=(char *) MEM_alloc(50000);
			while(fgets(inputline,50000,fptr1)!=NULL)
			{
				for(r=0;r< strlen(inputline);r++)
				{
					if(inputline[r] == '\n' || inputline[r] == '\r' )
					{
						inputline[r] = '\0';
					}
				}
				while(1)
				{
					f = strstr(inputline,",,");
					if(f==NULL)
					{
						break;
					}

					strcpy(result2,f+1);					
					*(f+1)=' ';
					*(f+2)='\0';
					strcat(f,result2);
				 }
				result1=(char *) MEM_alloc(200);
				strcpy(result1,inputline);
				printf("\n inputline .......%s\n",result1);fflush(stdout);
				TempTMLStdNoDup=(char *)MEM_alloc(200);
				tempfilename=(char *)MEM_alloc(200);
				FileLocation=(char *)MEM_alloc(200);
				tc_strcpy(TempTMLStdNoDup,result1);
				printf("\n TempTMLStdNoDup .......%s\n",TempTMLStdNoDup);fflush(stdout);
				len = tc_strlen(TempTMLStdNoDup);
				char str[len+1];
				strcpy(str, TempTMLStdNoDup);
				str[len+1] = '\0';
				char *broken = strtok(str, "#");
				printf("\n broken .......%s\n",broken);fflush(stdout);
				for(strcnt=0;strcnt<len;strcnt++)
				{
					printf("\n str[strcnt] .......[%c]\n",str[strcnt]);fflush(stdout);
					if(str[strcnt]=='\n')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==' ')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='/')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='\\')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='\0')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==',')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==';')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='.')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='&')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='(')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]==')')
					{
						str[strcnt]='-';
					}
					if(str[strcnt]=='-')
					{
						str[strcnt]='-';
					}

				}
				strcpy( tempfilename, str);
				printf("\n tempfilename .......[%s]\n",tempfilename);fflush(stdout);
				MEM_free(TempTMLStdNoDup);

				/*
				if(tc_strstr(TempTMLStdNoDup,"\n")!=NULL)removeChar(TempTMLStdNoDup, '\n');
				else if(tc_strstr(TempTMLStdNoDup," ")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ' ');
				else if(tc_strstr(TempTMLStdNoDup,"/")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '/');
				else if(tc_strstr(TempTMLStdNoDup,"\\")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\\');
				else if(tc_strstr(TempTMLStdNoDup,"\0")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, '\0');
				else if(tc_strstr(TempTMLStdNoDup,";")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ';');
				else if(tc_strstr(TempTMLStdNoDup,",")!=NULL)tempfilename = removeChar(TempTMLStdNoDup, ',');
				else tc_strcpy(tempfilename,result1);
				*/
				
				//tc_strcpy(FileLocation,"/user/testcmi/devgroups/sudhir/TMLISDOCLOADER/");
				//tc_strcpy(FileLocation,"/user/bsd05818/sudhir/TMLISDOCLOADER/");
				tc_strcpy(FileLocation,"/user/cvprod/sudhir/TMLISDOCLOADER/");
				tc_strcat(FileLocation,tempfilename);
				tc_strcat(FileLocation,".txt");
				printf("\n\n\t FileLocation-->[%s]\n",FileLocation);fflush(stdout);
				MEM_free(tempfilename);
				fptr=fopen(FileLocation,"r");
				if(fptr!=NULL)
				{
					tag_t *TMLISDOCUMENTOBJS	    = NULLTAG;
					tag_t *otherobjects			    = NULLTAG;
					tag_t TmlStd_type_tag			= NULLTAG;
					tag_t TmlStd_type_Revtag		= NULLTAG;
					tag_t object_create_input_tag   = NULLTAG;
					tag_t object_create_input_revtag= NULLTAG;
					tag_t new_tmlisdocobject        = NULLTAG;
					tag_t new_tmlisdocrevobject     = NULLTAG;
					tag_t TMLISDOCUMENT_tag			= NULLTAG;
					tag_t *t_allrevdocs				= NULLTAG;
					tag_t t_docrev					= NULLTAG;
					tag_t new_rev_tag				= NULLTAG;
					tag_t attr_id					= NULLTAG;
					tag_t tmlisdocrevobject			= NULLTAG;
					tag_t FoundTag					= NULLTAG;
					tag_t query						= NULLTAG;

					char *TMLStdNoDup					= NULL;
					char *TMLStdIssueNoDup				= NULL;
					char *TMLStdSeqDup					= NULL;
					char *TMLSupersededDup				= NULL;
					char *TMLFrozenDup					= NULL;
					char *TMTSOwnerDup					= NULL;
					char *TMTSAinNoDup					= NULL;
					char *TMTSHrmStdNoDup				= NULL;
					char *TMDocumentDescriptionDup		= NULL;
					char *TMTSJsrDeptDup				= NULL;
					char *TMTSLkhDeptDup				= NULL;
					char *TMTSPunDeptDup				= NULL;
					char *TMRespPartyDup				= NULL;
					char *TMOwnerNameDup				= NULL;
					char *TMDVolNoDup					= NULL;
					char *TMTSKeyword1Dup				= NULL;
					char *TMTSKeyword2Dup				= NULL;
					char *TMTSKeyword3Dup				= NULL;
					char *TMAlterationRemarkDup			= NULL;
					char *TMBulkReplicateDup			= NULL;
					char *TMLastModByDup				= NULL;
					char *TMRepDateDup					= NULL;
					char *TMRepFromDup					= NULL;
					char *TMRepStatDup					= NULL;
					char *TMRepToDup					= NULL;
					char *TMVerCreatorDup				= NULL;
					char *TMWitholdIssueIndDup			= NULL;
					char *TMDelIndDup					= NULL;
					char *TMRelDateDup					= NULL;
					char *TMMod_DateDup					= NULL;
					char *TMRemarkDup					= NULL;
					char *TMDateUpdatedDup				= NULL;
					char *TEMPTMRefISNoDup				= NULL;
					char *TMIsStdBRIndDup				= NULL;
					char *BL_Space1Dup					= NULL;
					char *BL_Space2Dup					= NULL;
					char *PDFNameDup					= NULL;
					char *pdfdoc_full_pathDup			= NULL;
					char *TMLStdDocNumber				= NULL;
					char *TMLStdDocRevision				= NULL;
					char *TMLStdIssueRev				= NULL;
					char *revi							= NULL;
					char *TempTMDelIndDup				= NULL;
					char *TempTMRemarkDup				= NULL;
					char *TMLStdDocSequenceId			= NULL;
					char *FoundObj_ItemId				= NULL;
					char *FoundObj_Type					= NULL;
					char *TempTMLStdNoDup				= NULL;
					char *tempfilename					= NULL;
					char *TMAuthorDup					= NULL;
					char *TMAuthorDateDup				= NULL;
					char *TMAddresseeDup				= NULL;
					char *TMCCAddresseeDup				= NULL;
					char *TMClassDup					= NULL;

					date_t  TMDocModDate	= NULLDATE;
					date_t  TMDocRelDate	= NULLDATE;
					date_t  TMDateUpd		= NULLDATE;
					date_t  TMAuthDate		= NULLDATE;

					const char	   reason;
					const char     change_id;
					const char     dir_name;


					const char
						*attrs[2] = {"item_id","object_type"},
						*values[2]	= {"*","*"};
					
						const char
						*otherattrs[1] = {"item_id"},
						*othervalues[1]	= {"*"};

					const char
						*attrs1[2] = {"item_id","object_type"},
						*values1[2]	= {"*","*"};

					char
						*qry_entries[3] = {"Item ID","Type","Revision"},
						*qry_values[3]	= {"*","*","*"};

					char	store[80000]  ;

					 int
						n_entries = 2,
						n_tags_found = 0;
						int n_tags_found_other = 0;
						int create_flag = 0;
						int i = 0;
						int cnt = 0;
						int TMLStdSeqValue = 0;
						int TMLStdSeqIdValue = 0;
						int n_tags_found1 = 0;
						int docrevcnt = 0;
						int copyrev = 0;
						int checkoutrev = 0;
						int	c2,c4,c1,elmt1	= 0;
						int	found = 0;
						int	otherFound = 0;
						int	n_rev_entries = 3;
						int	tt = 0;
					printf("\n file open .......");fflush(stdout);

					TempTMDelIndDup=(char *)MEM_alloc(200);
					TempTMRemarkDup=(char *)MEM_alloc(200);

					while(fgets(store, 500000, fptr)!=NULL)
					{
						for (i = 0; i < strlen(store); i++)
						{
							if ( store[i] == '\n' || store[i] == '\r' )
								store[i] = '\0';
						}
						c1  =0; 
						for(i=1; i<=100 && store[c1]!='\0'; i++)
						{ 
							c2=0;
							switch(i)
							{ 
									/*** TMLStdNo ***/
									case 1:					
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLStdNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLStdNo[c2]='\0';
									printf("\n TMLStdNo IS:%s",tmlisdocobjupload[elmt1].TMLStdNo);fflush(stdout);
									break;
									/*** TMLStdIssueNo ***/
									case 2:					
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLStdIssueNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLStdIssueNo[c2]='\0';
									printf("\n TMLStdIssueNo IS:%s",tmlisdocobjupload[elmt1].TMLStdIssueNo);fflush(stdout);
									break;

									/*** TMLStdSeq ***/
									case 3:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLStdSeq[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLStdSeq[c2]='\0';
									printf("\n TMLStdSeq IS:%s",tmlisdocobjupload[elmt1].TMLStdSeq);fflush(stdout);
									break;

									/*** TMLSuperseded ***/
									case 4:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLSuperseded[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLSuperseded[c2]='\0';
									printf("\n TMLSuperseded IS:%s",tmlisdocobjupload[elmt1].TMLSuperseded);fflush(stdout);
									break;

									/*** TMLFrozen ***/
									case 5:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLFrozen[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLFrozen[c2]='\0';
									printf("\n TMLFrozen IS:%s",tmlisdocobjupload[elmt1].TMLFrozen);fflush(stdout);
									break;

									/*** TMTSOwner ***/
									case 6:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSOwner[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSOwner[c2]='\0';
									printf("\n TMTSOwner IS:%s",tmlisdocobjupload[elmt1].TMTSOwner);fflush(stdout);
									break;

									/*** TMTSHrmStdNo ***/
									case 7:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSHrmStdNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSHrmStdNo[c2]='\0';
									printf("\n TMTSHrmStdNo IS:%s",tmlisdocobjupload[elmt1].TMTSHrmStdNo);fflush(stdout);
									break;

									/*** TMTSAinNo ***/
									case 8:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSAinNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSAinNo[c2]='\0';
									printf("\n TMTSAinNo IS:%s",tmlisdocobjupload[elmt1].TMTSAinNo);fflush(stdout);
									break;

									/*** TMDocumentDescription ***/
									case 9:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMDocumentDescription[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMDocumentDescription[c2]='\0';
									printf("\n TMDocumentDescription IS:%s",tmlisdocobjupload[elmt1].TMDocumentDescription);fflush(stdout);
									break;

									/*** TMTSJsrDept ***/
									case 10:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSJsrDept[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSJsrDept[c2]='\0';
									printf("\n TMTSJsrDept IS:%s",tmlisdocobjupload[elmt1].TMTSJsrDept);fflush(stdout);
									break;

									/*** TMTSLkhDept ***/
									case 11:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSLkhDept[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSLkhDept[c2]='\0';
									printf("\n TMTSLkhDept IS:%s",tmlisdocobjupload[elmt1].TMTSLkhDept);fflush(stdout);
									break;

									/*** TMTSPunDept ***/
									case 12:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSPunDept[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSPunDept[c2]='\0';
									printf("\n TMTSPunDept IS:%s",tmlisdocobjupload[elmt1].TMTSPunDept);fflush(stdout);
									break;

									/*** TMRespParty ***/
									case 13:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRespParty[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRespParty[c2]='\0';
									printf("\n TMRespParty IS:%s",tmlisdocobjupload[elmt1].TMRespParty);fflush(stdout);
									break;

									/*** TMOwnerName ***/
									case 14:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMOwnerName[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMOwnerName[c2]='\0';
									printf("\n TMOwnerName IS:%s",tmlisdocobjupload[elmt1].TMOwnerName);fflush(stdout);
									break;

									/*** TMDVolNo ***/
									case 15:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMDVolNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMDVolNo[c2]='\0';
									printf("\n TMDVolNo IS:%s",tmlisdocobjupload[elmt1].TMDVolNo);fflush(stdout);
									break;

									/*** TMTSKeyword1 ***/
									case 16:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSKeyword1[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSKeyword1[c2]='\0';
									printf("\n TMTSKeyword1 IS:%s",tmlisdocobjupload[elmt1].TMTSKeyword1);fflush(stdout);
									break;

									/*** TMTSKeyword2 ***/
									case 17:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSKeyword2[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSKeyword2[c2]='\0';
									printf("\n TMTSKeyword2 IS:%s",tmlisdocobjupload[elmt1].TMTSKeyword2);fflush(stdout);
									break;

									/*** TMTSKeyword3 ***/
									case 18:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMTSKeyword3[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMTSKeyword3[c2]='\0';
									printf("\n TMTSKeyword3 IS:%s",tmlisdocobjupload[elmt1].TMTSKeyword3);fflush(stdout);
									break;

									/*** TMAlterationRemark ***/
									case 19:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMAlterationRemark[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMAlterationRemark[c2]='\0';
									printf("\n TMAlterationRemark IS:%s",tmlisdocobjupload[elmt1].TMAlterationRemark);fflush(stdout);
									break;

									/*** TMBulkReplicate ***/
									case 20:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMBulkReplicate[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMBulkReplicate[c2]='\0';
									printf("\n TMBulkReplicate IS:%s",tmlisdocobjupload[elmt1].TMBulkReplicate);fflush(stdout);
									break;

									/*** TMLastModBy ***/
									case 21:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMLastModBy[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMLastModBy[c2]='\0';
									printf("\n TMLastModBy IS:%s",tmlisdocobjupload[elmt1].TMLastModBy);fflush(stdout);
									break;

									/*** TMRepDate ***/
									case 22:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRepDate[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRepDate[c2]='\0';
									printf("\n TMRepDate IS:%s",tmlisdocobjupload[elmt1].TMRepDate);fflush(stdout);
									break;

									/*** TMRepFrom ***/
									case 23:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRepFrom[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRepFrom[c2]='\0';
									printf("\n TMRepFrom IS:%s",tmlisdocobjupload[elmt1].TMRepFrom);fflush(stdout);
									break;

									/*** TMRepStat ***/
									case 24:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRepStat[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRepStat[c2]='\0';
									printf("\n TMRepStat IS:%s",tmlisdocobjupload[elmt1].TMRepStat);fflush(stdout);
									break;

									/*** TMRepTo ***/
									case 25:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRepTo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRepTo[c2]='\0';
									printf("\n TMRepTo IS:%s",tmlisdocobjupload[elmt1].TMRepTo);fflush(stdout);
									break;

									/*** TMVerCreator ***/
									case 26:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMVerCreator[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMVerCreator[c2]='\0';
									printf("\n TMVerCreator IS:%s",tmlisdocobjupload[elmt1].TMVerCreator);fflush(stdout);
									break;

									/*** TMWitholdIssueInd ***/
									case 27:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMWitholdIssueInd[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMWitholdIssueInd[c2]='\0';
									printf("\n TMWitholdIssueInd IS:%s",tmlisdocobjupload[elmt1].TMWitholdIssueInd);fflush(stdout);
									break;

									/*** TMDelInd ***/
									case 28:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMDelInd[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMDelInd[c2]='\0';
									printf("\n TMDelInd IS:%s",tmlisdocobjupload[elmt1].TMDelInd);fflush(stdout);
									break;

									/*** TMRelDate ***/
									case 29:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRelDate[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRelDate[c2]='\0';
									printf("\n TMRelDate IS:%s",tmlisdocobjupload[elmt1].TMRelDate);fflush(stdout);
									break;

									/*** TMMod_Date ***/
									case 30:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMMod_Date[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMMod_Date[c2]='\0';
									printf("\n TMMod_Date IS:%s",tmlisdocobjupload[elmt1].TMMod_Date);fflush(stdout);
									break;

									/*** TMRemark ***/
									case 31:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMRemark[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMRemark[c2]='\0';
									printf("\n TMRemark IS:%s",tmlisdocobjupload[elmt1].TMRemark);fflush(stdout);
									break;

									/*** TMDateUpdated ***/
									case 32:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMDateUpdated[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMDateUpdated[c2]='\0';
									printf("\n TMDateUpdated IS:%s",tmlisdocobjupload[elmt1].TMDateUpdated);fflush(stdout);
									break;

									/*** TEMPTMRefISNo ***/
									case 33:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TEMPTMRefISNo[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TEMPTMRefISNo[c2]='\0';
									printf("\n TEMPTMRefISNo IS:%s",tmlisdocobjupload[elmt1].TEMPTMRefISNo);fflush(stdout);
									break;

									/*** TMIsStdBRInd ***/
									case 34:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].TMIsStdBRInd[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].TMIsStdBRInd[c2]='\0';
									printf("\n TMIsStdBRInd IS:%s",tmlisdocobjupload[elmt1].TMIsStdBRInd);fflush(stdout);
									break;

									/*** BLANK SPACE ***/
									case 35:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].BL_Space1[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].BL_Space1[c2]='\0';
									printf("\n BL_Space1 IS:%s",tmlisdocobjupload[elmt1].BL_Space1);fflush(stdout);
									break;

									/*** BLANK SPACE ***/
									case 36:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].BL_Space2[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].BL_Space2[c2]='\0';
									printf("\n BL_Space2 IS:%s",tmlisdocobjupload[elmt1].BL_Space2);fflush(stdout);
									break;

									/*** PDFName ***/
									case 37:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].PDFName[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].PDFName[c2]='\0';
									printf("\n PDFName IS:%s",tmlisdocobjupload[elmt1].PDFName);fflush(stdout);
									break;

									/*** pdfdoc_full_path ***/
									case 38:
									for(;store[c1]!='~'; c1++)
									{
										tmlisdocobjupload[elmt1].pdfdoc_full_path[c2]=store[c1];
										c2++;
									}
									tmlisdocobjupload[elmt1].pdfdoc_full_path[c2]='\0';
									printf("\n pdfdoc_full_path IS:%s",tmlisdocobjupload[elmt1].pdfdoc_full_path);fflush(stdout);
									break;


									
							} // End of Switch case.

							c1++;

						} // End of For Loop.

					   elmt1++;

					} // End of while Loop.

					printf("\n elmt1 .......%d",elmt1);fflush(stdout);
					for(c4=0; c4<elmt1; c4++)
					{
						
						if(tmlisdocobjupload[c4].TMLStdNo) TMLStdNoDup = strdup(tmlisdocobjupload[c4].TMLStdNo);
						if(tmlisdocobjupload[c4].TMLStdIssueNo) TMLStdIssueNoDup = strdup(tmlisdocobjupload[c4].TMLStdIssueNo);
						if(tmlisdocobjupload[c4].TMLStdSeq) TMLStdSeqDup = strdup(tmlisdocobjupload[c4].TMLStdSeq);
						if(tmlisdocobjupload[c4].TMLSuperseded) TMLSupersededDup = strdup(tmlisdocobjupload[c4].TMLSuperseded);
						if(tmlisdocobjupload[c4].TMLFrozen) TMLFrozenDup = strdup(tmlisdocobjupload[c4].TMLFrozen);
						if(tmlisdocobjupload[c4].TMTSOwner) TMTSOwnerDup = strdup(tmlisdocobjupload[c4].TMTSOwner);
						if(tmlisdocobjupload[c4].TMTSHrmStdNo) TMTSHrmStdNoDup = strdup(tmlisdocobjupload[c4].TMTSHrmStdNo);
						if(tmlisdocobjupload[c4].TMTSAinNo) TMTSAinNoDup = strdup(tmlisdocobjupload[c4].TMTSAinNo);
						if(tmlisdocobjupload[c4].TMDocumentDescription) TMDocumentDescriptionDup = strdup(tmlisdocobjupload[c4].TMDocumentDescription);
						if(tmlisdocobjupload[c4].TMTSJsrDept) TMTSJsrDeptDup = strdup(tmlisdocobjupload[c4].TMTSJsrDept);
						if(tmlisdocobjupload[c4].TMTSLkhDept) TMTSLkhDeptDup = strdup(tmlisdocobjupload[c4].TMTSLkhDept);
						if(tmlisdocobjupload[c4].TMTSPunDept) TMTSPunDeptDup = strdup(tmlisdocobjupload[c4].TMTSPunDept);
						if(tmlisdocobjupload[c4].TMRespParty) TMRespPartyDup = strdup(tmlisdocobjupload[c4].TMRespParty);
						if(tmlisdocobjupload[c4].TMOwnerName) TMOwnerNameDup = strdup(tmlisdocobjupload[c4].TMOwnerName);
						if(tmlisdocobjupload[c4].TMDVolNo) TMDVolNoDup = strdup(tmlisdocobjupload[c4].TMDVolNo);
						if(tmlisdocobjupload[c4].TMTSKeyword1) TMTSKeyword1Dup = strdup(tmlisdocobjupload[c4].TMTSKeyword1);
						if(tmlisdocobjupload[c4].TMTSKeyword2) TMTSKeyword2Dup = strdup(tmlisdocobjupload[c4].TMTSKeyword2);
						if(tmlisdocobjupload[c4].TMTSKeyword3) TMTSKeyword3Dup = strdup(tmlisdocobjupload[c4].TMTSKeyword3);
						if(tmlisdocobjupload[c4].TMAlterationRemark) TMAlterationRemarkDup = strdup(tmlisdocobjupload[c4].TMAlterationRemark);
						if(tmlisdocobjupload[c4].TMBulkReplicate) TMBulkReplicateDup = strdup(tmlisdocobjupload[c4].TMBulkReplicate);
						if(tmlisdocobjupload[c4].TMLastModBy) TMLastModByDup = strdup(tmlisdocobjupload[c4].TMLastModBy);
						if(tmlisdocobjupload[c4].TMRepDate) TMRepDateDup = strdup(tmlisdocobjupload[c4].TMRepDate);
						if(tmlisdocobjupload[c4].TMRepFrom) TMRepFromDup = strdup(tmlisdocobjupload[c4].TMRepFrom);
						if(tmlisdocobjupload[c4].TMRepStat) TMRepStatDup = strdup(tmlisdocobjupload[c4].TMRepStat);
						if(tmlisdocobjupload[c4].TMRepTo) TMRepToDup = strdup(tmlisdocobjupload[c4].TMRepTo);
						if(tmlisdocobjupload[c4].TMVerCreator) TMVerCreatorDup = strdup(tmlisdocobjupload[c4].TMVerCreator);
						if(tmlisdocobjupload[c4].TMWitholdIssueInd) TMWitholdIssueIndDup = strdup(tmlisdocobjupload[c4].TMWitholdIssueInd);
						if(tmlisdocobjupload[c4].TMDelInd) TMDelIndDup = strdup(tmlisdocobjupload[c4].TMDelInd);
						if(tmlisdocobjupload[c4].TMRelDate) TMRelDateDup = strdup(tmlisdocobjupload[c4].TMRelDate);
						if(tmlisdocobjupload[c4].TMMod_Date) TMMod_DateDup = strdup(tmlisdocobjupload[c4].TMMod_Date);
						if(tmlisdocobjupload[c4].TMRemark) TMRemarkDup = strdup(tmlisdocobjupload[c4].TMRemark);
						if(tmlisdocobjupload[c4].TMDateUpdated) TMDateUpdatedDup = strdup(tmlisdocobjupload[c4].TMDateUpdated);
						if(tmlisdocobjupload[c4].TEMPTMRefISNo) TEMPTMRefISNoDup = strdup(tmlisdocobjupload[c4].TEMPTMRefISNo);
						if(tmlisdocobjupload[c4].TMIsStdBRInd) TMIsStdBRIndDup = strdup(tmlisdocobjupload[c4].TMIsStdBRInd);
						if(tmlisdocobjupload[c4].PDFName) PDFNameDup = strdup(tmlisdocobjupload[c4].PDFName);
						if(tmlisdocobjupload[c4].pdfdoc_full_path) pdfdoc_full_pathDup = strdup(tmlisdocobjupload[c4].pdfdoc_full_path);
							
							

						printf("\n TMLStdNoDup .......%s",TMLStdNoDup);fflush(stdout);
						printf("\n TMLStdIssueNoDup .......%s",TMLStdIssueNoDup);fflush(stdout);
						printf("\n TMLStdSeqDup .......%s",TMLStdSeqDup);fflush(stdout);
						printf("\n TMLSupersededDup .......%s",TMLSupersededDup);fflush(stdout);
						printf("\n TMLFrozenDup .......%s",TMLFrozenDup);fflush(stdout);
						printf("\n TMTSOwnerDup .......%s",TMTSOwnerDup);fflush(stdout);
						printf("\n TMTSHrmStdNoDup .......%s",TMTSHrmStdNoDup);fflush(stdout);
						printf("\n TMTSAinNoDup .......%s",TMTSAinNoDup);fflush(stdout);
						printf("\n TMDocumentDescriptionDup .......%s",TMDocumentDescriptionDup);fflush(stdout);
						printf("\n TMTSJsrDeptDup .......%s",TMTSJsrDeptDup);fflush(stdout);
						printf("\n TMTSLkhDeptDup .......%s",TMTSLkhDeptDup);fflush(stdout);
						printf("\n TMTSPunDeptDup .......%s",TMTSPunDeptDup);fflush(stdout);
						printf("\n TMRespPartyDup .......%s",TMRespPartyDup);fflush(stdout);
						printf("\n TMOwnerNameDup .......%s",TMOwnerNameDup);fflush(stdout);
						printf("\n TMDVolNoDup .......%s",TMDVolNoDup);fflush(stdout);
						printf("\n TMTSKeyword1Dup .......%s",TMTSKeyword1Dup);fflush(stdout);
						printf("\n TMTSKeyword2Dup .......%s",TMTSKeyword2Dup);fflush(stdout);
						printf("\n TMTSKeyword3Dup .......%s",TMTSKeyword3Dup);fflush(stdout);
						printf("\n TMAlterationRemarkDup .......%s",TMAlterationRemarkDup);fflush(stdout);
						printf("\n TMBulkReplicateDup .......%s",TMBulkReplicateDup);fflush(stdout);
						printf("\n TMLastModByDup .......%s",TMLastModByDup);fflush(stdout);
						printf("\n TMRepDateDup .......%s",TMRepDateDup);fflush(stdout);
						printf("\n TMRepFromDup .......%s",TMRepFromDup);fflush(stdout);
						printf("\n TMRepStatDup .......%s",TMRepStatDup);fflush(stdout);
						printf("\n TMRepToDup .......%s",TMRepToDup);fflush(stdout);
						printf("\n TMVerCreatorDup .......%s",TMVerCreatorDup);fflush(stdout);
						printf("\n TMWitholdIssueIndDup .......%s",TMWitholdIssueIndDup);fflush(stdout);
						printf("\n TMDelIndDup .......%s",TMDelIndDup);fflush(stdout);
						printf("\n TMRelDateDup .......%s",TMRelDateDup);fflush(stdout);
						printf("\n TMMod_DateDup .......%s",TMMod_DateDup);fflush(stdout);
						printf("\n TMRemarkDup .......%s",TMRemarkDup);fflush(stdout);
						printf("\n TMDateUpdatedDup .......%s",TMDateUpdatedDup);fflush(stdout);
						printf("\n TEMPTMRefISNoDup .......%s",TEMPTMRefISNoDup);fflush(stdout);
						printf("\n TMIsStdBRIndDup .......%s",TMIsStdBRIndDup);fflush(stdout);
						printf("\n PDFNameDup .......%s",PDFNameDup);fflush(stdout);
						printf("\n pdfdoc_full_pathDup .......%s",pdfdoc_full_pathDup);fflush(stdout);

							if(tc_strcmp(TMDelIndDup,"N")==0)
							{
								tc_strcpy(TempTMDelIndDup,"N0");
							}
							else
							{
								tc_strcpy(TempTMDelIndDup,TMDelIndDup);
							}
							if(tc_strlen(TMRemarkDup)==0 || tc_strcmp(TMRemarkDup,"null")==0)
							{
								tc_strcpy(TempTMRemarkDup,"Y");
							}
							else
							{
								tc_strcpy(TempTMRemarkDup,TMRemarkDup);
							}



							if(tc_strcmp(TMMod_DateDup,"null")!=0)
							{
								TMDocModDate  = TML_token_to_date( TMMod_DateDup );
							}
							if(tc_strcmp(TMRelDateDup,"null")!=0)
							{
								TMDocRelDate  = TML_token_to_date( TMRelDateDup );
							}
							if(tc_strcmp(TMDateUpdatedDup,"null")!=0)
							{
								TMDateUpd  = TML_token_to_date( TMDateUpdatedDup );
							}
							if(tc_strcmp(TMAuthorDateDup,"null")!=0)
							{
								TMAuthDate  = TML_token_to_date( TMAuthorDateDup );
							}
							
							

							TMLStdSeqValue=TML_token_to_int(TMLStdSeqDup);
							printf("\n TMLStdSeqValue .......%d",TMLStdSeqValue);fflush(stdout);

							
							
							
							values[0] = TMLStdNoDup;
							values[1] = "T5_TMLStd";
							othervalues[0] = TMLStdNoDup;
							printf("\n values[0] .......[%s]",values[0]);fflush(stdout);
							printf("\n values[1] .......[%s]",values[1]);fflush(stdout);

							if(TMLISDOCUMENTOBJS!=NULLTAG) MEM_free(TMLISDOCUMENTOBJS); TMLISDOCUMENTOBJS =NULLTAG;
							ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &TMLISDOCUMENTOBJS);
							ITEM_find_items_by_key_attributes(1, otherattrs, othervalues, &n_tags_found_other, &otherobjects);
							if(n_tags_found_other>0)
							{
								for(found=0;found<n_tags_found_other;found++)
								{
									FoundTag = otherobjects[found];
									AOM_ask_value_string(FoundTag,"item_id",&FoundObj_ItemId);
									printf("\n FoundObj_ItemId .......[%s]",FoundObj_ItemId);fflush(stdout);

									AOM_ask_value_string(FoundTag,"object_type",&FoundObj_Type);
									printf("\n FoundObj_Type .......[%s]",FoundObj_Type);fflush(stdout);
									if(tc_strcmp(FoundObj_ItemId,TMLStdNoDup)==0 && (tc_strcmp(FoundObj_Type,"T5_TMLStd")!=0 && tc_strcmp(FoundObj_Type,"ManufacturerPart")!=0))
									{
										otherFound++;
										fprintf(out_fp,"\n");
										fprintf(out_fp,"%s",FoundObj_ItemId);
										fprintf(out_fp,"~");
										fprintf(out_fp,"%s",FoundObj_Type);
									}
								}
							}
							printf("\n Number of TMLStd=>%d", n_tags_found);fflush(stdout);
							printf("\n otherFound=>%d", otherFound);fflush(stdout);
							if(otherFound>0)
							{
								tc_strcpy(TempTMLStdNoDup,"TS_");
								tc_strcat(TempTMLStdNoDup,TMLStdNoDup);
							}
							if(otherFound==0)
							{
								tc_strcpy(TempTMLStdNoDup,TMLStdNoDup);
							}
							printf("\n TempTMLStdNoDup .......[%s]",TempTMLStdNoDup);fflush(stdout);
							printf("\n TMLStdNoDup .......[%s]",TMLStdNoDup);fflush(stdout);
							//if(n_tags_found==0 && otherFound==0)
							if(n_tags_found==0 && otherFound==0)
							{
								create_flag = 0;
								ITK_CALL(TCTYPE_find_type("T5_TMLStd", "T5_TMLStd", &TmlStd_type_tag));
								ITK_CALL(TCTYPE_construct_create_input(TmlStd_type_tag, &object_create_input_tag));

								ITK_CALL(TCTYPE_find_type("T5_TMLStdRevision", "T5_TMLStdRevision", &TmlStd_type_Revtag));
								ITK_CALL(TCTYPE_construct_create_input(TmlStd_type_Revtag, &object_create_input_revtag));

								if(TMLStdNoDup!=NULL && strlen(TMLStdNoDup)>0 && object_create_input_revtag!=NULLTAG && object_create_input_tag!=NULLTAG)
								{
									ITK_CALL(AOM_set_value_string(object_create_input_tag,"item_id",TMLStdNoDup));
									ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",TMLStdNoDup));
									
									AOM_set_value_string(object_create_input_revtag, "object_name", TMLStdNoDup);
									if(tc_strcmp(TMLStdIssueNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "item_revision_id", TMLStdIssueNoDup);
									AOM_set_value_string(object_create_input_revtag, "object_desc", TMDocumentDescriptionDup);
									if(tc_strcmp(TMDVolNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_DVolNo", TMDVolNoDup);
									if(tc_strcmp(TempTMDelIndDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSDelInd", TempTMDelIndDup);
									if(tc_strcmp(TMTSAinNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSAinNo", TMTSAinNoDup);
									if(tc_strcmp(TempTMRemarkDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSRemark", TempTMRemarkDup);
									if(tc_strcmp(TMTSHrmStdNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSHrmStdNo", TMTSHrmStdNoDup);
									if(tc_strcmp(TMTSOwnerDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSOwner", TMTSOwnerDup);
									if(tc_strcmp(TMTSJsrDeptDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSJsrDept", TMTSJsrDeptDup);
									if(tc_strcmp(TMTSLkhDeptDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSLkhDept", TMTSLkhDeptDup);
									if(tc_strcmp(TMTSPunDeptDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSPunDept", TMTSPunDeptDup);
									if(tc_strcmp(TMTSKeyword1Dup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSKeyword1", TMTSKeyword1Dup);
									if(tc_strcmp(TMTSKeyword2Dup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSKeyword2", TMTSKeyword2Dup);
									if(tc_strcmp(TMTSKeyword3Dup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_TSKeyword3", TMTSKeyword3Dup);
									if(tc_strcmp(TMAlterationRemarkDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_AlterationRemark", TMAlterationRemarkDup);
									if(tc_strcmp(TMWitholdIssueIndDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_WitholdIssueInd", TMWitholdIssueIndDup);
									//if(tc_strcmp(TEMPTMRefISNoDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_RefISNo", TEMPTMRefISNoDup);
									if(tc_strcmp(TMIsStdBRIndDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_IsStdBRInd", TMIsStdBRIndDup);
									
									//if(tc_strcmp(TMAuthorDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_Author", TMAuthorDup);
									//if(tc_strcmp(TMAddresseeDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_Addressee", TMAddresseeDup);
									//if(tc_strcmp(TMCCAddresseeDup,"null")!=0)AOM_set_value_string(object_create_input_revtag, "t5_CCAddressee", TMCCAddresseeDup);
									

									AOM_set_value_tag(object_create_input_tag, "revision",object_create_input_revtag);
									create_flag++;
								}
								printf("\n create_flag=>%d", create_flag);fflush(stdout);
								if(create_flag>0)
								{
									ITK_CALL(TCTYPE_create_object(object_create_input_tag, &new_tmlisdocobject));
									printf("\n new_tmlisdocobject");fflush(stdout);
									
									if(new_tmlisdocobject !=NULLTAG)
									{
										
										printf("\n created new_tmlisdocobject");fflush(stdout);
										ITK_CALL(AOM_save(new_tmlisdocobject));
										printf("\n AOM_save new_tmlisdocobject");fflush(stdout);
										ITEM_ask_latest_rev(new_tmlisdocobject,&new_tmlisdocrevobject);
										printf("\n avail new_tmlisdocrevobject");fflush(stdout);
										if(AOM_lock(new_tmlisdocrevobject))
										ITK_CALL(AOM_set_value_string(new_tmlisdocrevobject,"object_name",TMLStdNoDup));
										ITK_CALL(AOM_set_value_string(new_tmlisdocrevobject,"object_desc",TMDocumentDescriptionDup));
										//if(tc_strlen(TMLStdSeqDup)>0)ITK_CALL(AOM_set_value_string(new_tmlisdocrevobject,"sequence_id",TMLStdSeq));
										
										ITK_CALL(AOM_save(new_tmlisdocrevobject));
										//if(AOM_refresh(new_tmlisdocrevobject,1));
										if(AOM_unlock(new_tmlisdocrevobject));
										printf("\n CREATED %s",TMLStdNoDup);fflush(stdout);

										TML_Change_Creation_Date(new_tmlisdocrevobject,TMDocModDate,TMDocRelDate);

										if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
										{
											PdfUploadFunction(new_tmlisdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
										}
										//TMLSTD_CreateRelation_ISDOC(new_tmlisdocobject,TEMPTMRefISNoDup,TMIsStdBRIndDup);
									}
								}
							}
							else
							{
								printf("\n in else n_tags_found .......%d",n_tags_found);fflush(stdout);
								for(cnt=0;cnt<n_tags_found;cnt++)
								{
									
									TMLISDOCUMENT_tag = TMLISDOCUMENTOBJS[cnt];
									copyrev=0;
									checkoutrev=0;
									printf("\n TMLStdNoDup .......%s",TMLStdNoDup);fflush(stdout);
									printf("\n TMLStdIssueNoDup .......%s",TMLStdIssueNoDup);fflush(stdout);
									printf("\n TMLStdSeqDup .......%s",TMLStdSeqDup);fflush(stdout);
									printf("\n TMLSupersededDup .......%s",TMLSupersededDup);fflush(stdout);
									printf("\n TMLFrozenDup .......%s",TMLFrozenDup);fflush(stdout);
									printf("\n TMTSOwnerDup .......%s",TMTSOwnerDup);fflush(stdout);
									printf("\n TMTSHrmStdNoDup .......%s",TMTSHrmStdNoDup);fflush(stdout);
									printf("\n TMTSAinNoDup .......%s",TMTSAinNoDup);fflush(stdout);
									printf("\n TMDocumentDescriptionDup .......%s",TMDocumentDescriptionDup);fflush(stdout);
									printf("\n TMTSJsrDeptDup .......%s",TMTSJsrDeptDup);fflush(stdout);
									printf("\n TMTSLkhDeptDup .......%s",TMTSLkhDeptDup);fflush(stdout);
									printf("\n TMTSPunDeptDup .......%s",TMTSPunDeptDup);fflush(stdout);
									printf("\n TMRespPartyDup .......%s",TMRespPartyDup);fflush(stdout);
									printf("\n TMOwnerNameDup .......%s",TMOwnerNameDup);fflush(stdout);
									printf("\n TMDVolNoDup .......%s",TMDVolNoDup);fflush(stdout);
									printf("\n TMTSKeyword1Dup .......%s",TMTSKeyword1Dup);fflush(stdout);
									printf("\n TMTSKeyword2Dup .......%s",TMTSKeyword2Dup);fflush(stdout);
									printf("\n TMTSKeyword3Dup .......%s",TMTSKeyword3Dup);fflush(stdout);
									printf("\n TMAlterationRemarkDup .......%s",TMAlterationRemarkDup);fflush(stdout);
									printf("\n TMBulkReplicateDup .......%s",TMBulkReplicateDup);fflush(stdout);
									printf("\n TMLastModByDup .......%s",TMLastModByDup);fflush(stdout);
									printf("\n TMRepDateDup .......%s",TMRepDateDup);fflush(stdout);
									printf("\n TMRepFromDup .......%s",TMRepFromDup);fflush(stdout);
									printf("\n TMRepStatDup .......%s",TMRepStatDup);fflush(stdout);
									printf("\n TMRepToDup .......%s",TMRepToDup);fflush(stdout);
									printf("\n TMVerCreatorDup .......%s",TMVerCreatorDup);fflush(stdout);
									printf("\n TMWitholdIssueIndDup .......%s",TMWitholdIssueIndDup);fflush(stdout);
									printf("\n TMDelIndDup .......%s",TMDelIndDup);fflush(stdout);
									printf("\n TMRelDateDup .......%s",TMRelDateDup);fflush(stdout);
									printf("\n TMMod_DateDup .......%s",TMMod_DateDup);fflush(stdout);
									printf("\n TMRemarkDup .......%s",TMRemarkDup);fflush(stdout);
									printf("\n TMDateUpdatedDup .......%s",TMDateUpdatedDup);fflush(stdout);
									printf("\n TEMPTMRefISNoDup .......%s",TEMPTMRefISNoDup);fflush(stdout);
									printf("\n TMIsStdBRIndDup .......%s",TMIsStdBRIndDup);fflush(stdout);
									
									printf("\n PDFNameDup .......%s",PDFNameDup);fflush(stdout);
									printf("\n pdfdoc_full_pathDup .......%s",pdfdoc_full_pathDup);fflush(stdout);

									if(tc_strcmp(TMDelIndDup,"N")==0)
									{
										tc_strcpy(TempTMDelIndDup,"N0");
									}
									else
									{
										tc_strcpy(TempTMDelIndDup,TMDelIndDup);
									}
									printf("\n TempTMDelIndDup .......%s",TempTMDelIndDup);fflush(stdout);

									if(tc_strlen(TMRemarkDup)==0 || tc_strcmp(TMRemarkDup,"null")==0)
									{
										tc_strcpy(TempTMRemarkDup,"Y");
									}
									else
									{
										tc_strcpy(TempTMRemarkDup,TMRemarkDup);
									}
									printf("\n TempTMRemarkDup .......%s",TempTMRemarkDup);fflush(stdout);

									AOM_ask_value_string(TMLISDOCUMENT_tag,"item_id",&TMLStdDocNumber);
									printf("\n TMLStdDocNumber .......%s",TMLStdDocNumber);fflush(stdout);

									qry_values[0] = TMLStdDocNumber;
									qry_values[1] = "TML Std Revision";
									qry_values[2] = TMLStdIssueNoDup;

									QRY_find("Item Revision...", &query);
									if(query!=NULLTAG)
									{
										printf("\n qry_values[0] .......%s",qry_values[0]);fflush(stdout);
										printf("\n qry_values[1] .......%s",qry_values[1]);fflush(stdout);
										printf("\n qry_values[2] .......%s",qry_values[2]);fflush(stdout);
										QRY_execute(query, n_rev_entries, qry_entries, qry_values, &n_tags_found1, &t_allrevdocs);
									}
									
									//ITEM_find_item_revs_by_key_attributes(2,attrs1, values1,TMLStdIssueNoDup,&n_tags_found1, &t_allrevdocs);
									printf("\n n_tags_found1 .......%d",n_tags_found1);fflush(stdout);
									if(n_tags_found1==0)
									{
										ITEM_ask_latest_rev(TMLISDOCUMENT_tag,&tmlisdocrevobject);
										copyrev++;
									}
									else
									{
										tmlisdocrevobject = t_allrevdocs[0];
										printf("\n Before Call PdfUploadFunction .......");fflush(stdout);
										PdfUploadFunction(tmlisdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
										printf("\n After Call PdfUploadFunction .......");fflush(stdout);
										printf("\n Before Call TMLSTD_CreateRelation_ISDOC .......");fflush(stdout);
										//TMLSTD_CreateRelation_ISDOC(tmlisdocrevobject,TEMPTMRefISNoDup,TMIsStdBRIndDup);
										printf("\n After Call TMLSTD_CreateRelation_ISDOC .......");fflush(stdout);
										AOM_ask_value_int(tmlisdocrevobject,"sequence_id",&TMLStdSeqIdValue);
										printf("\n TMLStdSeqIdValue .......%d",TMLStdSeqIdValue);fflush(stdout);


										AOM_ask_value_string(tmlisdocrevobject,"item_revision_id",&TMLStdDocRevision);
										printf("\n TMLStdDocRevision .......%s",TMLStdDocRevision);fflush(stdout);
										printf("\n TMLStdSeqValue .......%d",TMLStdSeqValue);fflush(stdout);

										if(tc_strcmp(TMLStdDocRevision,TMLStdIssueNoDup)==0)
										{
											if(TMLStdSeqIdValue != TMLStdSeqValue)
											{
												checkoutrev++;
											}
										}
									}
									if(tmlisdocrevobject!=NULLTAG)
									{
										if(copyrev>0)
										{
											ITEM_copy_rev(tmlisdocrevobject,NULL,&new_rev_tag);
											if(new_rev_tag!=NULLTAG)
											{
												AOM_lock(new_rev_tag);
												
												POM_attr_id_of_attr("item_revision_id", "T5_TMLStdRevision", &attr_id);
												POM_set_attr_string(1, &new_rev_tag, attr_id,TMLStdIssueNoDup);
												POM_save_instances(1, &new_rev_tag, false);

												AOM_set_value_string(new_rev_tag, "object_desc", TMDocumentDescriptionDup);
												if(tc_strcmp(TMDVolNoDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_DVolNo", TMDVolNoDup);
												if(tc_strcmp(TempTMDelIndDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSDelInd", TempTMDelIndDup);
												if(tc_strcmp(TMTSAinNoDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSAinNo", TMTSAinNoDup);
												if(tc_strcmp(TempTMRemarkDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSRemark", TempTMRemarkDup);
												if(tc_strcmp(TMTSHrmStdNoDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSHrmStdNo", TMTSHrmStdNoDup);
												if(tc_strcmp(TMTSOwnerDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSOwner", TMTSOwnerDup);
												if(tc_strcmp(TMTSJsrDeptDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSJsrDept", TMTSJsrDeptDup);
												if(tc_strcmp(TMTSLkhDeptDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSLkhDept", TMTSLkhDeptDup);
												if(tc_strcmp(TMTSPunDeptDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSPunDept", TMTSPunDeptDup);
												if(tc_strcmp(TMTSKeyword1Dup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSKeyword1", TMTSKeyword1Dup);
												if(tc_strcmp(TMTSKeyword2Dup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSKeyword2", TMTSKeyword2Dup);
												if(tc_strcmp(TMTSKeyword3Dup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_TSKeyword3", TMTSKeyword3Dup);
												if(tc_strcmp(TMAlterationRemarkDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_AlterationRemark", TMAlterationRemarkDup);
												if(tc_strcmp(TMWitholdIssueIndDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_WitholdIssueInd", TMWitholdIssueIndDup);
												//if(tc_strcmp(TEMPTMRefISNoDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_RefISNo", TEMPTMRefISNoDup);
												if(tc_strcmp(TMIsStdBRIndDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_IsStdBRInd", TMIsStdBRIndDup);
												
												//if(tc_strcmp(TMAuthorDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_Author", TMAuthorDup);
												//if(tc_strcmp(TMAddresseeDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_Addressee", TMAddresseeDup);
												//if(tc_strcmp(TMCCAddresseeDup,"null")!=0)AOM_set_value_string(new_rev_tag, "t5_CCAddressee", TMCCAddresseeDup);

												//if(tc_strlen(TMLStdSeqDup)>0)ITK_CALL(AOM_set_value_string(new_rev_tag,"sequence_id",TMLStdSeq));
												
												ITK_CALL(AOM_save(new_rev_tag));
												AOM_unlock(new_rev_tag);

												//TML_Change_Creation_Date(new_rev_tag,TMDocModDate,TMDocRelDate);
												TML_Change_Creation_Date(new_rev_tag,TMDocModDate,TMDocRelDate);
												if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
												{
													PdfUploadFunction(new_rev_tag,PDFNameDup,pdfdoc_full_pathDup);
												}
												//TMLSTD_CreateRelation_ISDOC(new_rev_tag,TEMPTMRefISNoDup,TMIsStdBRIndDup);
												
											}
										}
										if(checkoutrev>0)
										{
											RES_checkout(tmlisdocrevobject,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE);
											//AOM_lock(tmlisdocrevobject);

											AOM_set_value_string(tmlisdocrevobject, "object_desc", TMDocumentDescriptionDup);
											if(tc_strcmp(TMDVolNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_DVolNo", TMDVolNoDup);
											if(tc_strcmp(TempTMDelIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSDelInd", TempTMDelIndDup);
											if(tc_strcmp(TMTSAinNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSAinNo", TMTSAinNoDup);
											if(tc_strcmp(TempTMRemarkDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSRemark", TempTMRemarkDup);
											if(tc_strcmp(TMTSHrmStdNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSHrmStdNo", TMTSHrmStdNoDup);
											if(tc_strcmp(TMTSOwnerDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSOwner", TMTSOwnerDup);
											if(tc_strcmp(TMTSJsrDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSJsrDept", TMTSJsrDeptDup);
											if(tc_strcmp(TMTSLkhDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSLkhDept", TMTSLkhDeptDup);
											if(tc_strcmp(TMTSPunDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSPunDept", TMTSPunDeptDup);
											if(tc_strcmp(TMTSKeyword1Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword1", TMTSKeyword1Dup);
											if(tc_strcmp(TMTSKeyword2Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword2", TMTSKeyword2Dup);
											if(tc_strcmp(TMTSKeyword3Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword3", TMTSKeyword3Dup);
											if(tc_strcmp(TMAlterationRemarkDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_AlterationRemark", TMAlterationRemarkDup);
											if(tc_strcmp(TMWitholdIssueIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_WitholdIssueInd", TMWitholdIssueIndDup);
											//if(tc_strcmp(TEMPTMRefISNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_RefISNo", TEMPTMRefISNoDup);
											if(tc_strcmp(TMIsStdBRIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_IsStdBRInd", TMIsStdBRIndDup);
											
											//if(tc_strcmp(TMAuthorDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_Author", TMAuthorDup);
											//if(tc_strcmp(TMAddresseeDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_Addressee", TMAddresseeDup);
											//if(tc_strcmp(TMCCAddresseeDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_CCAddressee", TMCCAddresseeDup);

											//if(tc_strlen(TMLStdSeqDup)>0)ITK_CALL(AOM_set_value_string(tmlisdocrevobject,"sequence_id",TMLStdSeq));
											
											ITK_CALL(AOM_save(tmlisdocrevobject));
											
											if(pdfdoc_full_pathDup!="null" && PDFNameDup!="null" && tc_strlen(PDFNameDup)>0 && tc_strlen(pdfdoc_full_pathDup)>0)
											{
												PdfUploadFunction(tmlisdocrevobject,PDFNameDup,pdfdoc_full_pathDup);
											}
											TML_Change_Creation_Date(tmlisdocrevobject,TMDocModDate,TMDocRelDate);
											//TML_Change_Creation_Date(tmlisdocrevobject,TMDocModDate,TMDocRelDate,TMDateUpd,TMAuthDate);
											//TMLSTD_CreateRelation_ISDOC(tmlisdocrevobject,TEMPTMRefISNoDup,TMIsStdBRIndDup);
											RES_checkin(tmlisdocrevobject);
										}
										/*
										if(copyrev==0 || checkoutrev==0)
										{
											AOM_lock(tmlisdocrevobject);
											AOM_set_value_string(tmlisdocrevobject, "object_desc", TMDocumentDescriptionDup);
											if(tc_strcmp(TMDVolNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_DVolNo", TMDVolNoDup);
											if(tc_strcmp(TempTMDelIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSDelInd", TempTMDelIndDup);
											if(tc_strcmp(TMTSAinNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSAinNo", TMTSAinNoDup);
											if(tc_strcmp(TempTMRemarkDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSRemark", TempTMRemarkDup);
											if(tc_strcmp(TMTSHrmStdNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSHrmStdNo", TMTSHrmStdNoDup);
											if(tc_strcmp(TMTSOwnerDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSOwner", TMTSOwnerDup);
											if(tc_strcmp(TMTSJsrDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSJsrDept", TMTSJsrDeptDup);
											if(tc_strcmp(TMTSLkhDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSLkhDept", TMTSLkhDeptDup);
											if(tc_strcmp(TMTSPunDeptDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSPunDept", TMTSPunDeptDup);
											if(tc_strcmp(TMTSKeyword1Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword1", TMTSKeyword1Dup);
											if(tc_strcmp(TMTSKeyword2Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword2", TMTSKeyword2Dup);
											if(tc_strcmp(TMTSKeyword3Dup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_TSKeyword3", TMTSKeyword3Dup);
											if(tc_strcmp(TMAlterationRemarkDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_AlterationRemark", TMAlterationRemarkDup);
											if(tc_strcmp(TMWitholdIssueIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_WitholdIssueInd", TMWitholdIssueIndDup);
											//if(tc_strcmp(TEMPTMRefISNoDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_RefISNo", TEMPTMRefISNoDup);
											if(tc_strcmp(TMIsStdBRIndDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_IsStdBRInd", TMIsStdBRIndDup);
											if(tc_strcmp(TMAuthorDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_Author", TMAuthorDup);
											if(tc_strcmp(TMAddresseeDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_Addressee", TMAddresseeDup);
											if(tc_strcmp(TMCCAddresseeDup,"null")!=0)AOM_set_value_string(tmlisdocrevobject, "t5_CCAddressee", TMCCAddresseeDup);

											//if(tc_strlen(TMLStdSeqDup)>0)ITK_CALL(AOM_set_value_string(tmlisdocrevobject,"sequence_id",TMLStdSeq));
											TML_Change_Creation_Date(tmlisdocrevobject,TMDocModDate,TMDocRelDate,TMDateUpd,TMAuthDate);
											ITK_CALL(AOM_save(tmlisdocrevobject));
											AOM_unlock(tmlisdocrevobject);
										}
										*/
									}
								}
							}

							//TML_IS_DOC_Avaialble(TMLStdNoDup,TMLStdIssueNoDup,TMLStdSeqDup);
							TML_IS_DOC_Result_Avaialble(TMLStdNoDup,TMLStdIssueNoDup,TMLStdSeqDup);
					}///
					if(elmt1==0)
					{
						char *rev					= NULL;
						char *seq					= NULL;
						char *docno					= NULL;
						rev=(char *)MEM_alloc(200);
						seq=(char *)MEM_alloc(200);
						docno=(char *)MEM_alloc(200);
						tc_strcpy(rev,"1");
						tc_strcpy(seq,"1");
						tc_strcpy(docno,argstring1);
						//TML_IS_DOC_Avaialble(docno,rev,seq);
						TML_IS_DOC_Result_Avaialble(docno,rev,seq);
					}
				}// fptr
				else
				{
					printf("\n file not read .......");fflush(stdout);
				}
				if(fptr!=NULL)fclose(fptr);
			}
		}
		fclose(fptr1);
		//MEM_free(TMLISDOCUMENTOBJS);
		//MEM_free(otherobjects);
	}
	//fclose(fptr);
	//fclose(out_fp);
	return ITK_ok;
}