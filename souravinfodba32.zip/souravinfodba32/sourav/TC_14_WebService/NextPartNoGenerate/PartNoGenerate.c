//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
#include "soapH.h"
#include "PartNoGenerate.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int TC_PartSrch(char* PNSrch)
{
	int iFail = 0;
	tag_t* tItem_results = NULLTAG;
	trimwhitespace(PNSrch);
	printf("\n Searched Part Number Value After Trim --------> %s\n", PNSrch);fflush(stdout);
	tag_t tPartobj = NULLTAG;
	ITK_CALL(QRY_find2("Item ID",&tPartobj));
	printf("\n Return Value From ItemRev Query API is --------> %d", iFail);fflush(stdout);
    if(tPartobj != NULLTAG)
	{
		printf("\n ItemID Query Found Successfully...");fflush(stdout);
		int n_entrie = 1;
		char *cQry_entry[1] = {"Item ID"};
		char *cQry_values[1] = {PNSrch};
		//char *cQry_values[1] = {"5137D1D0270001_WE"};
	    int nItem_found = 0;
	    ITK_CALL(QRY_execute(tPartobj, n_entrie, cQry_entry, cQry_values, &nItem_found, &tItem_results));
		printf("\n Return Value From ItemRev Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Part Found --------> %d\n",nItem_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nItem_found > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		printf("\n Sorry!! Query Tag Not Found...");fflush(stdout);
	}
	if (tItem_results)
    {
		MEM_free(tItem_results);
	}			
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number 10 Digit> (Required)\n"
        );	
}	

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    //register int i = 0;
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   //ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
   //fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
-      //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
       //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

}
;


int ns__getItemData(struct soap* soap,char *PartNumberTen,struct ns__CharArray1 *aString_test)
{
        int iFail =0;
		int ifail =0;
		int	tt1	= 0;
			
		//char* PartNumberTen = NULL;
	    char* PartNumberTenDup = NULL;
	    char* PartNo = NULL;
	    PartNo = (char *) MEM_alloc(20*sizeof(char ));

			
		char* responseString = NULL;
		char* responseString1 = NULL;
		char* responseString2 = NULL;
		char* Print_Report = NULL;

		char**	ReportSetSTR = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/PartNoGenerateReport.txt", "w", stdout);

		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		printf("\n Input .. %s",PartNumberTen);fflush(stdout);
		if((PartNumberTen !=NULL) && (tc_strcmp(PartNumberTen,"")!=0))
		{
			
			if(tc_strlen(PartNumberTen)>0)
		    {
			   tc_strdup(PartNumberTen,&PartNumberTenDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&PartNumberTenDup);
			   printf("\n Part No Value is NULL");fflush(stdout);
		    }
            trimwhitespace(PartNumberTenDup);
			tc_strcpy(PartNo,PartNumberTenDup);
	        tc_strcat(PartNo,"*");
			printf("\n Final Part Number After Trim Concat & Dup --------> %s", PartNo);fflush(stdout);
			tag_t tItemobj = NULLTAG;			
			ITK_CALL(QRY_find2("Item Revision...",&tItemobj));
			printf("\n Return Value From Item Revision Query API is --------> %d", iFail);fflush(stdout);

			if(tItemobj!=NULLTAG)
			{
				
				printf("\n Item Revision... Query Found Successfully");fflush(stdout);
				int n_entries = 2;
				char *cEntries[2] = {"Item ID","Type"};
                char *cValues[2] = {PartNo,"Design Revision"};
				int num_to_sort = 1;
				//char *keys[1] = {"object_name"};
				char *keys[1] = {"creation_date"};
				int orders[1] = {2};
				int n_itemobj_found = 0;
				tag_t* titemobj_results = NULLTAG;
				
				ITK_CALL(QRY_execute_with_sort(tItemobj, n_entries, cEntries, cValues, num_to_sort, keys, orders, &n_itemobj_found, &titemobj_results));
                printf("\n Return Value From Query Execute with Sort API is --------> %d", iFail);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n Total Parts Found --------> %d\n",n_itemobj_found);fflush(stdout);
				printf("\n -----------------------------------------------\n");fflush(stdout);
				char* DescPartNo = NULL;
				char* cFstNo = NULL;
				char* cSrNo = NULL;

				if(n_itemobj_found>0)
			    {
					
					ITK_CALL(AOM_ask_value_string(titemobj_results[0], "item_id", &DescPartNo));
					printf("\n DESC Order Part No[First] --------> %s", DescPartNo);fflush(stdout);
					cFstNo=subString(DescPartNo,0,10);
					printf("\n First Ten Digit After Substring --------> %s", cFstNo);fflush(stdout);
					cSrNo=subString(DescPartNo,10,2);
					printf("\n Last Two Digit After Substring --------> %s", cSrNo);fflush(stdout);
					int cStart,counter = 0;
					cStart = atoi(cSrNo);
					char* PartNoSrch = NULL;
	                PartNoSrch = (char *) MEM_alloc(20*sizeof(char ));
					tc_strcpy(PartNoSrch,cFstNo);
					printf("\n Part No Value Without Last Two Digit --------> %s", PartNoSrch);fflush(stdout);
					char* vsr = NULL;
					char* FinalPartNoSrch = NULL;
	                FinalPartNoSrch = (char *) MEM_alloc(20*sizeof(char ));
					int RStatus = 0;

                    for(counter=(cStart+1);counter<=999;counter++)
		            {
						if(counter<10)
						{
							sprintf(vsr,"%d",counter);
							tc_strcpy(FinalPartNoSrch,PartNoSrch);
							tc_strcat(FinalPartNoSrch,"00");
							tc_strcat(FinalPartNoSrch,vsr); 
						}
						else if((counter>9) && (counter<=99))
						{
							sprintf(vsr,"%d",counter);
							tc_strcpy(FinalPartNoSrch,PartNoSrch);
							tc_strcat(FinalPartNoSrch,"0");
							tc_strcat(FinalPartNoSrch,vsr); 
						}
						else
						{
						  sprintf(vsr,"%d",counter);
						  tc_strcpy(FinalPartNoSrch,PartNoSrch);
						  tc_strcat(FinalPartNoSrch,vsr);
						}
						printf("\n Final Part No Value For Searching --------> %s", FinalPartNoSrch);fflush(stdout);
						printf("\n Part Search Function Call Start");fflush(stdout);
						RStatus = TC_PartSrch(FinalPartNoSrch);
						printf("\n Part Search Function Call End");fflush(stdout);
						if(RStatus == 1)
						{
							printf("\n Part No Already Exist So Continue...");fflush(stdout);
							continue;
						}
						if(RStatus == 0)
						{
							printf("\n Final Part No Received So Break...");fflush(stdout);
							break;
						}
					}					
					
					responseString1=(char *)MEM_alloc(200);
					responseString2=(char *)MEM_alloc(200);

					if(FinalPartNoSrch>0)
					{
						
						printf("\n Input Part Number: -----> <%s> \n",PartNumberTen);fflush(stdout);
					
						tc_strcpy(responseString1,"INPUT_PART_NUMBER=");
						tc_strcat(responseString1,PartNumberTen);
						setAddStr(&tt1,&ReportSetSTR,responseString1);
						
						tc_strcpy(responseString2,"GENERATED_PART_NUMBER=");
						if(tc_strlen(FinalPartNoSrch)>0)
						{
		                    tc_strcat(responseString2,FinalPartNoSrch);
						}
						else
						{
							tc_strcat(responseString2,"NULL");
						}
						setAddStr(&tt1,&ReportSetSTR,responseString2);
				
						aString_test-> __size =tt1;
						//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
						aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
						int i =0;
						for(i=0;i<tt1;i++)
						{
							/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
							strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

							aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
							strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
							Print_Report = ReportSetSTR[i];
							printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

							aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
							strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

						}
					}
				}
			}
		}///
		//}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

		return SOAP_OK;
}