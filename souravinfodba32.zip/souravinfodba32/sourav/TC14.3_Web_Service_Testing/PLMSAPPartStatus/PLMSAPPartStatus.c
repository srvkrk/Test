/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Provide Part Information From SAP via Webservice For TCUA - CV  
*  File Name    :   PLMSAPPartStatus.c
*  Created on   :   June 11th, 2024
*  Usage        :   PLMSAPPartStatus
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/06/2024                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "PLMSAPPartStatus.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <fclasses/tc_date.h>
#include <user_exits/epm_toolkit_utils.h>
#include <unistd.h>
#include "wmhelpe.h"
#include "bapi.h"
#include "saprfc.h"
#include "sapitab.h"
#include "t.h"
#include "malloc.h"
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
#define atoa(x) #x

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}

void rfc_error(char *);
void cll_zrfc_ac_view_create(void);
void cll_zbapi_material_savedata_mrp(void);
RFC_HANDLE BapiLogon(void);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
RFC_RC allocate_insp_type(void);
RFC_RC allocate_insp_type_vc(void);
int FetchPlantSpecificData(char* PCode);
RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
RFC_RC WIN_DLL_EXPORT_FLAGS zpprfc_revisionnum_change(RFC_HANDLE hRfc,AENNR *eAennr,CCMATNR *eMatnr,CC_REVLV *eRevlv,BAPIRET2 *iMessg,SYST_SUBRC *iRetval,char *xException);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);


char* InpPrt_str = NULL;
char* InpPlnt_str = NULL;
char* InpPrt_strDup = NULL;
char* InpPlnt_strDup = NULL;
char* plantcode = NULL;

WERKS_D eWerks;
static MATNR eMatnr;

char *proc_type;
char *inputPart = NULL;
char *iPlantCode = NULL;
char *iSapServer = "CVP";
char *sap_proc_type = NULL;
char *sap_spproc_type = NULL;
char *SAPpstat = NULL;
char *MRPpstat = NULL;
char pstat;
char *Plant_StoreLoc = NULL;
char *Plant_MakeBuy = NULL;
char *profit_centre2 = NULL;
char *plan_calendar2 = NULL;
char *overhd_grp2 = NULL;
char *origin_group2 = NULL;
char *origin_group = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *sloc1_type = NULL;
char *sloc2_type = NULL;

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
	   printf("Test");
    }
    return ITK_ok;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

char* TC_PartCS(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmCS = NULL;
	PartPlmCS = (char *) malloc(500*sizeof(char));
	char* PartPlmCSVal = NULL;
	char* PartPlmCSValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PunMakeBuyIndicator"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_CarMakeBuyIndicator"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmCS,"t5_DwdMakeBuyIndicator"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_JsrMakeBuyIndicator"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmCS,"t5_LkoMakeBuyIndicator"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmCS,"t5_PnrMakeBuyIndicator"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_AhdMakeBuyIndicator"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_JdlMakeBuyIndicator"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmCS,"t5_PunUVMakeBuyIndicator"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmCS);
	printf("\n Part PLM CS(PartPlmCS):  [%s] \n",PartPlmCS);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmCS,&PartPlmCSVal));
	if(tc_strlen(PartPlmCSVal)>0)
	{
		tc_strdup(PartPlmCSVal,&PartPlmCSValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmCSValDup);
		printf("\n Part PLM CS Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM CS Final Value(PartPlmCSValDup):  [%s]\n",PartPlmCSValDup);fflush(stdout);
	return PartPlmCSValDup;	
}

char* TC_PartSLOC(tag_t PartRevtag, char* PartPlantName)
{
	
	trimwhitespace(PartPlantName);
	char *PartPlmSloc = NULL;
	PartPlmSloc = (char *) malloc(20*sizeof(char));
	char* PartPlmSlocVal = NULL;
	char* PartPlmSlocValDup = NULL;
	
	printf("\n Part Plant Name Value: [%s]\n", PartPlantName);fflush(stdout);
	if(tc_strcmp(PartPlantName,"1001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PunStoreLocation"); //APLP
	}
	else if(tc_strcmp(PartPlantName,"1100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_CarStoreLocation"); //APLC
	}
	else if(tc_strcmp(PartPlantName,"1500")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_DwdStoreLocation"); //APLD
	}
	else if(tc_strcmp(PartPlantName,"2001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_JsrStoreLocation"); //APLJ
	}
	else if(tc_strcmp(PartPlantName,"3001")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_LkoStoreLocation"); //APLL
	}
	else if(tc_strcmp(PartPlantName,"3100")==0)
	{
		tc_strcpy(PartPlmSloc,"t5_PnrStoreLocation"); //APLU
	}
	else if(tc_strcmp(PartPlantName,"E201")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_AhdStoreLocation"); //APLA
	}
	else if(tc_strcmp(PartPlantName,"7501")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_JdlStoreLocation"); //APLS
	}
	else if(tc_strcmp(PartPlantName,"1140")==0) 
	{
		tc_strcpy(PartPlmSloc,"t5_PunUVStoreLocation"); //APLV
	}
	else
	{
		printf(" Plant Code Invalid..!!\n");fflush(stdout);
	}
	trimwhitespace(PartPlmSloc);
	printf("\n Part PLM SLOC(PartPlmSloc):  [%s] \n",PartPlmSloc);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(PartRevtag,PartPlmSloc,&PartPlmSlocVal));
	if(tc_strlen(PartPlmSlocVal)>0)
	{
		tc_strdup(PartPlmSlocVal,&PartPlmSlocValDup);
	}
	else
	{
		tc_strdup("Blank",&PartPlmSlocValDup);
		printf("\n Part PLM SLOC Value is NULL");fflush(stdout);
	}
	printf("\n Part PLM SLOC Final Value(PartPlmSlocValDup):  [%s]\n",PartPlmSlocValDup);fflush(stdout);
	return PartPlmSlocValDup;	
}

RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;


	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		default: ;
	}
	return RfcRc;
}

char* GetSAPCS(char* InpPrt_strDup, char* plantcode)
{
    char *xException = NULL;
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;
	char *SAPCSVal = NULL;
	SAPCSVal = (char *) malloc(50*sizeof(char));

    printf("\n In Function[GetSAPCS] ---> Part_NO: [%s]   Plant_Code: [%s]",InpPrt_strDup,plantcode);
    hRfc = BapiLogon();
    sap_proc_type = (char *) malloc(20*sizeof(char));
	sap_spproc_type = (char *) malloc(20*sizeof(char));
	
	SETCHAR(eMatnr.Matnr,InpPrt_strDup);
    SETCHAR(eWerks.WerksD,plantcode);
	
    RfcRc = export_CSpastat(hRfc
				,&eMatnr
				,&eWerks
				,&iMrpView
				,&iView
				,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n In RFC_OK[GetSAPCS] case..!!\n");fflush(stdout);
			GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);
			GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);
			
			printf("\n In Function[GetSAPCS] ---> sap_proc_type: [%s]    sap_spproc_type: [%s]\n",sap_proc_type,sap_spproc_type);
			trimwhitespace(sap_proc_type);
			trimwhitespace(sap_spproc_type);
			/* if(tc_strlen(sap_proc_type)>0)
			{
				tc_strcpy(SAPCSVal,sap_proc_type);
				if(tc_strlen(sap_spproc_type)>0)
			    {
				   tc_strcat(SAPCSVal,sap_spproc_type);
				}
				else
				{
				   printf("\n Part SAP Special Procurement Type is Blank so, will not Concatinate with Procurement Type");fflush(stdout);
				}	
			}
			else
			{
				tc_strcpy(SAPCSVal,"Blank");
				printf("\n Part SAP CS Value is Blank");fflush(stdout);
			}	 */
            /* if(sap_proc_type)
			{
			   printf("Part SAP CS Value is NULL or Blank");
			   tc_strcpy(SAPCSVal,"Blank");
			}
			else
			{
			   printf("Part SAP CS Value is not NULL or Blank");
			   tc_strcpy(SAPCSVal,sap_proc_type);
			   if(sap_spproc_type)
			   {
				 printf("\n Part SAP Special Procurement Type is Blank or NULL so, will not Concatinate with Procurement Type");fflush(stdout);  
			   }
			   else
			   {
				  printf("Part SAP Special Procurement Type Value is not NULL or Blank");
				  tc_strcat(SAPCSVal,sap_spproc_type);
			   }
			} */
			if((tc_strcmp(sap_proc_type,"")!=0) && (tc_strcmp(sap_proc_type," ")!=0) && (tc_strcmp(sap_proc_type,"    ")!=0))
			{
				printf("Part SAP CS Value is not NULL or Blank");
			    tc_strcpy(SAPCSVal,sap_proc_type);
				if((tc_strcmp(sap_spproc_type,"")!=0) && (tc_strcmp(sap_spproc_type," ")!=0) && (tc_strcmp(sap_spproc_type,"    ")!=0))
			    {
					printf("Part SAP Special Procurement Type Value is not NULL or Blank");
					tc_strcat(SAPCSVal,sap_spproc_type);
				}
				else
				{
					printf("\n Part SAP Special Procurement Type is Blank or NULL so, will not Concatinate with Procurement Type");fflush(stdout);
				}
			}
            else
            {
				printf("Part SAP CS Value is NULL or Blank");
			    tc_strcpy(SAPCSVal,"Blank");
			}
			
		break;
		
		case RFC_EXCEPTION:
			printf("\n RFC Exception: [%s]",xException);fflush(stdout);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\n System Exception Raised..!!\n");fflush(stdout);
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\n Failure..!!\n");fflush(stdout);
			exit(0);
		break;
		default:
			printf("\n Other Failure..!!\n");fflush(stdout);
			exit(0);
	}
	
    RfcClose(hRfc);
	trimwhitespace(SAPCSVal);
    return SAPCSVal;
}

char* GetSAPSLOC(char* InpPrt_strDup, char* plantcode)
{
    char *xException = NULL;
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;
	char *SAPSLOCVal = NULL;
	SAPSLOCVal = (char *) malloc(50*sizeof(char));

    printf("\n In Function[GetSAPSLOC] ---> Part_NO: [%s]   Plant_Code: [%s]",InpPrt_strDup,plantcode);
    hRfc = BapiLogon();
    sloc1_type = (char *) malloc(20*sizeof(char));
	//sloc2_type = (char *) malloc(20*sizeof(char));
	
	SETCHAR(eMatnr.Matnr,InpPrt_strDup);
    SETCHAR(eWerks.WerksD,plantcode);
	
    RfcRc = export_CSpastat(hRfc
				,&eMatnr
				,&eWerks
				,&iMrpView
				,&iView
				,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\n In RFC_OK[GetSAPSLOC] case..!!\n");fflush(stdout);
			GETCHAR(iMrpView.ISS_ST_LOC, sloc1_type);
			//GETCHAR(iMrpView.SLOC_EXPRC, sloc2_type);
			
			printf("\n In Function[GetSAPSLOC] ---> sap_prod_storeloc: [%s]\n",sloc1_type);
			trimwhitespace(sloc1_type);
			/* if(tc_strlen(sloc1_type)>0)
			{
				tc_strcpy(SAPSLOCVal,sloc1_type);
			}
			else
			{
				tc_strcpy(SAPSLOCVal,"Blank");
				printf("\n Part SAP SLOC Value is Blank");fflush(stdout);
			} */
            /* if(sloc1_type)
			{
				printf("Part SAP SLOC Value is NULL or Blank");
				tc_strcpy(SAPSLOCVal,"Blank");
			}
			else
			{
			   printf("Part SAP SLOC Value is not NULL or Blank");
			   tc_strcpy(SAPSLOCVal,sloc1_type);
			} */
            if((tc_strcmp(sloc1_type,"")!=0) && (tc_strcmp(sloc1_type," ")!=0) && (tc_strcmp(sloc1_type,"    ")!=0))
			{
				printf("Part SAP SLOC Value is not NULL or Blank");
			    tc_strcpy(SAPSLOCVal,sloc1_type);
			}
            else
            {
				printf("Part SAP SLOC Value is NULL or Blank");
				tc_strcpy(SAPSLOCVal,"Blank");
			}
			
		break;
		
		case RFC_EXCEPTION:
			printf("\n RFC Exception: [%s]",xException);fflush(stdout);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\n System Exception Raised..!!\n");fflush(stdout);
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\n Failure..!!\n");fflush(stdout);
			exit(0);
		break;
		default:
			printf("\n Other Failure..!!\n");fflush(stdout);
			exit(0);
	}
	
    RfcClose(hRfc);
    return SAPSLOCVal;
}

int FetchPlantSpecificData(char* plantcode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	PlantSuffix  = strtok ( NULL, "_" );
	
	if(QRY_find2("Control Objects...", &PlantCodeQryTag));
	if(PlantCodeQryTag)
	{
		printf("\n Function[FetchPlantSpecificData] Found Query[Control Objects...]!!\n"); fflush(stdout);
		char *qry_MakeValue[2] = {"MAKEBUY",plantcode};
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\n Function[FetchPlantSpecificData]: Plant Code: [%s]	  Plant_MakeBuy: [%s]	  Plant_StoreLoc: [%s]\n",plantcode,Plant_MakeBuy,Plant_StoreLoc);fflush(stdout);
		}
		else
		{
			printf("\n Function[FetchPlantSpecificData]: Plant Code: [%s] does not have entry in Control Object[MAKEBUY] hence exiting..!!\n",plantcode);fflush(stdout);
			goto CLEANUP;
		}

		char *qry_PlantValue[2] = {"PLANTDATA",plantcode};
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\n Function[FetchPlantSpecificData]: Plant code:  [%s]",plantcode);
			printf("\n Function[FetchPlantSpecificData]: Profit_Centre:  [%s]",profit_centre_sap);
			printf("\n Function[FetchPlantSpecificData]: Plan_Calendar:  [%s]",plan_calendar);
			printf("\n Function[FetchPlantSpecificData]: Overhd_Group:  [%s]",overhd_grp);
			printf("\n Function[FetchPlantSpecificData]: Origin_Group:  [%s]",origin_group);
		}
	}

	CLEANUP:
	return ContObjCnt;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;
	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;
	tag_t SapServerQry = NULLTAG;
	tag_t *SSQObjTags = NULLTAG;
	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char *two_fields[2] = {"SYSCD","SUBSYSCD"};
	if(QRY_find2("Control Objects...", &SapServerQry));
	if(SapServerQry)
	{
		printf("\n Found Control Objects[SAPSERVER]..!!\n"); fflush(stdout);
		char *two_value[2] = {"SAPCON",iSapServer};
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));
		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi(SSSysnr);
			printf("\n Connecting to SAP Server:  [%s]\n",iSapServer);fflush(stdout);

			RfcOptions.destination = SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname = SSHostName;
			RfcConnoptR3only.gateway_host = SSHostName;
			RfcConnoptR3only.gateway_service = SSGateway;
			RfcConnoptR3only.sysnr = nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\n SAP Server: [%s] details not found exiting..!!\n",iSapServer);fflush(stdout);
			exit(0);
		}

		printf("\n Connecting to:  [%s] [%s] [%s]",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\n ERROR RECEIVED CPIC-ERROR..!!\n");fflush(stdout);
			exit(0);
		}
		else
		{
			printf("\n Connected with SAP Server..!!\n");fflush(stdout);
			RfcEnvironment(&RfcEnv);
		}
	}
	return hRfc;
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new());

}
;


int ns__getItemData(struct soap* soap,char *Input_line_str,struct ns__CharArray1 *aString_test)
{
        int ifail = 0;
		int	tt1	= 0;
		char *loggedInUser = NULL;
		int iFail = 0;
        int n_tags_found = 0;
		tag_t* tags_found = NULLTAG;
		tag_t rev_tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t query = NULLTAG; 
		char* responseString1 = NULL;
		char* responseString2 = NULL;
		char* responseString3 = NULL;
		char* responseString4 = NULL;
		char* responseString5 = NULL;
		//char* responseString6 = NULL;
		//char* responseString7 = NULL;
		char* Print_Report = NULL;
		char* cProjectDes  = NULL;
        char* Proj_id  = NULL;
		char** ReportSetSTR = NULL;
		size_t len;
		int	status_count = 0;
		tag_t*	relStatus_list = NULLTAG;
		char *latest_rev_Rel_Status = NULL;
		char *latest_rev_Part_Type = NULL;
		char *LCState = NULL;
		LCState = (char *) malloc(50*sizeof(char));
		int n_entries = 2;
		static RFC_RC RfcRc;
		plantcode=(char *) malloc (500 * sizeof(char));
		sap_proc_type = (char *)malloc(500 * sizeof(char));
		sap_spproc_type = (char *)malloc(500 * sizeof(char));
		SAPpstat = (char *)malloc(500 * sizeof(char));
		MRPpstat = (char *)malloc(500 * sizeof(char));
		profit_centre_sap = (char *)malloc(500 * sizeof(char));
		sloc1_type = (char *) malloc(500*sizeof(char));
		sloc2_type = (char *) malloc(500*sizeof(char));
		char *Input_line_strDup = NULL;
		char *rspstring = NULL;
	    rspstring = (char *) malloc(100*sizeof(char));
		
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/PLMSAPPartStatusReport.txt", "w", stdout);

        printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
		
		trimwhitespace(Input_line_str);
		if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
		printf(" [0]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
		InpPrt_str=tc_strtok(Input_line_strDup,",");
		InpPlnt_strDup=tc_strtok(NULL,",");
		
		if(InpPrt_str!=NULL)tc_strdup(InpPrt_str,&InpPrt_strDup);
		if(InpPlnt_str!=NULL)tc_strdup(InpPlnt_str,&InpPlnt_strDup);
		printf(" [1]: Input Part(InpPrt_strDup): [%s]\n",InpPrt_strDup);
		printf(" [2]: Input Plant(InpPlnt_strDup): [%s]\n",InpPlnt_strDup);
		
		if(tc_strcmp(InpPlnt_strDup,"1001")==0)
		{
			tc_strcpy(LCState,"T5_LcsAplpRlzd"); //APLP
		}
		else if(tc_strcmp(InpPlnt_strDup,"1100")==0)
		{
			tc_strcpy(LCState,"T5_LcsAplRlzd"); //APLC
		}
		else if(tc_strcmp(InpPlnt_strDup,"1500")==0)
		{
			tc_strcpy(LCState,"T5_LcsApldRlzd"); //APLD
		}
		else if(tc_strcmp(InpPlnt_strDup,"2001")==0)
		{
			tc_strcpy(LCState,"T5_LcsApljRlzd"); //APLJ
		}
		else if(tc_strcmp(InpPlnt_strDup,"3001")==0)
		{
			tc_strcpy(LCState,"T5_LcsApllRlzd"); //APLL
		}
		else if(tc_strcmp(InpPlnt_strDup,"3100")==0)
		{
			tc_strcpy(LCState,"T5_LcsApluRlzd"); //APLU
		}
		else if(tc_strcmp(InpPlnt_strDup,"E201")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplaRlzd"); //APLA
		}
		else if(tc_strcmp(InpPlnt_strDup,"7501")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplsRlzd"); //APLS
		}
		else if(tc_strcmp(InpPlnt_strDup,"1140")==0) 
		{
			tc_strcpy(LCState,"T5_LcsAplvRlzd"); //APLV
		}
		else
		{
			printf(" Plant Code Invalid..!!\n");fflush(stdout);
		}
		
		tag_t QryTag = NULLTAG;
		char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
		int num_to_sort = 1;
		int sort_order[1]  ={2};
		char *keysAttr[1] = {"creation_date"};
		int resultcount = 0;
		tag_t* titemobj_results = NULLTAG;
		tag_t LatestRev = NULLTAG;
		char* LatRevName = NULL;
		char* OwnerName = NULL;
		char* OwnerNameDup = NULL;
		char* PrtRev = NULL;
		char* PrtRevDup = NULL;
		char* PartRelStatus = NULL;
		char* Part_No = NULL;
		char* PPLM_CS = NULL;
		char* PPLM_SLOC = NULL;
		char* PSAP_CS = NULL;
		char* PSAP_SLOC = NULL;
		
		ITK_CALL(QRY_find2("Driver VC Query",&QryTag));
		char *qry_entries[] = {"Item ID","Release Status"};
		qry_values[0] = InpPrt_strDup;
		qry_values[1] = LCState;
		ITK_CALL(QRY_execute_with_sort(QryTag, n_entries, qry_entries, qry_values, num_to_sort, keysAttr, sort_order, &resultcount, &titemobj_results));
		
		if(resultcount > 0)
		{
			//responseString1=(char *)MEM_alloc(200);
			//responseString2=(char *)MEM_alloc(200);
			responseString1=(char *)MEM_alloc(200);
			responseString2=(char *)MEM_alloc(200);
			responseString3=(char *)MEM_alloc(200);
			responseString4=(char *)MEM_alloc(200);
			responseString5=(char *)MEM_alloc(200);
			
			LatestRev = titemobj_results[0];
			ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
			tc_strdup(OwnerName,&OwnerNameDup);
			ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
			PrtRevDup=strtok(PrtRev,";");
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));
			ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&Part_No));
			
			printf("\n Part No: [%s]\n",Part_No);fflush(stdout);
			printf("\n Part Revision: [%s]\n",PrtRevDup);fflush(stdout);
			printf("\n Part Details: [%s]\n",LatRevName);fflush(stdout);
			printf("\n Owner Name: [%s]\n",OwnerNameDup);fflush(stdout);
			printf("\n Release Status: [%s]\n",PartRelStatus);fflush(stdout);
			
			if(FetchPlantSpecificData(InpPlnt_strDup)>0)
			{
				printf("\n Got Plant Specific Data..!!\n");fflush(stdout);
			}
			else
			{
				printf("\n Error in Fetching Plant Specific Data..!!\n");fflush(stdout);
				//goto CLEANUP;
			}
			tc_strdup(InpPlnt_strDup,&plantcode);
			printf("\n Function[1]: GetSAPCS() Start..!!\n");fflush(stdout);
			tc_strcpy(sap_proc_type,"");
			tc_strcpy(sap_spproc_type,"");
			tc_strcpy(SAPpstat,"");
			tc_strcpy(MRPpstat,"");
			//GetCSPstat(/*Part_No*/);
			PSAP_CS = GetSAPCS(InpPrt_strDup, plantcode);
			printf("\n Function[1]: GetSAPCS() End..!!\n");fflush(stdout);
			
			printf("\n Function[2]: GetSAPSLOC() Start..!!\n");fflush(stdout);
			PSAP_SLOC = GetSAPSLOC(InpPrt_strDup, plantcode);
			printf("\n Function[2]: GetSAPSLOC() End..!!\n");fflush(stdout);
			
			printf("\n Function[3]: TC_PartCS() Start..!!\n");fflush(stdout);
			PPLM_CS = TC_PartCS(LatestRev, plantcode);
			printf("\n Function[3]: TC_PartCS() End..!!\n");fflush(stdout);
			
			printf("\n Function[4]: TC_PartSLOC() Start..!!\n");fflush(stdout);
			PPLM_SLOC = TC_PartSLOC(LatestRev, plantcode);
			printf("\n Function[4]: TC_PartSLOC() End..!!\n");fflush(stdout);
			
			if((tc_strcmp(PPLM_CS,PSAP_CS)==0) && (tc_strcmp(PPLM_SLOC,PSAP_SLOC)==0))
			{
				tc_strcpy(rspstring,"Yes");
				//tc_strcat(rspstring,plantcode);
			}
			else
			{
				tc_strcpy(rspstring,"No");
				//tc_strcat(rspstring,plantcode);
			}
			
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			printf("\n Part No(InpPrt_strDup): [%s]", InpPrt_strDup);fflush(stdout);
			printf("\n Plant Name(plantcode): [%s]", plantcode);fflush(stdout);
			printf("\n Part SAP CS Response(PSAP_CS): [%s]", PSAP_CS);fflush(stdout);
			printf("\n Part SAP SLOC Response(PSAP_SLOC): [%s]", PSAP_SLOC);fflush(stdout);
			printf("\n Part PLM CS Response(PPLM_CS): [%s]", PPLM_CS);fflush(stdout);
			printf("\n Part PLM SLOC Response(PPLM_SLOC): [%s]", PPLM_SLOC);fflush(stdout);
			printf("\n Material Status(rspstring): [%s]", rspstring);fflush(stdout);
			printf("\n#---------------------------------------------------------#");fflush(stdout);
			
			//tc_strcpy(responseString1,"MATERIAL_NUMBER=");
			//tc_strcat(responseString1,InpPrt_strDup);
			//setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			//tc_strcpy(responseString2,"PLANT_CODE=");
			//tc_strcat(responseString2,plantcode);
			//setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString1,"PLM_CS=");
			tc_strcat(responseString1,PPLM_CS);
			setAddStr(&tt1,&ReportSetSTR,responseString1);
			
			tc_strcpy(responseString2,"SAP_CS=");
			tc_strcat(responseString2,PSAP_CS);
			setAddStr(&tt1,&ReportSetSTR,responseString2);
			
			tc_strcpy(responseString3,"PLM_SLOC=");
			tc_strcat(responseString3,PPLM_SLOC);
			setAddStr(&tt1,&ReportSetSTR,responseString3);
			
			tc_strcpy(responseString4,"SAP_SLOC=");
			tc_strcat(responseString4,PSAP_SLOC);
			setAddStr(&tt1,&ReportSetSTR,responseString4);
			
			tc_strcpy(responseString5,"MATERIAL_STATUS=");
			tc_strcat(responseString5,rspstring);
			setAddStr(&tt1,&ReportSetSTR,responseString5);
			
			aString_test-> __size =tt1;
			//aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
			aString_test->__ptrDetails = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrDetails) );
			int i =0;
			for(i=0;i<tt1;i++)
			{
				/* aString_test->__ptrItem[i].PROJECT_ID = malloc(30 * sizeof(char *) );
			    strcpy(aString_test->__ptrItem[i].PROJECT_ID,responseString1); // PROJECT_ID

				aString_test->__ptrItem[i].ORGANIZATION_ID = malloc(30 * sizeof(char *) );
				strcpy(aString_test->__ptrItem[i].ORGANIZATION_ID,responseString2); // ORGANIZATION_ID */
								
				Print_Report = ReportSetSTR[i];
				printf("\n Print_Report: -----> <%s> \n",Print_Report);fflush(stdout);

				aString_test->__ptrDetails[i].PartIDDetails = malloc(500 * sizeof(char *) );
				strcpy(aString_test->__ptrDetails[i].PartIDDetails,Print_Report);

			}	
		}
		else
		{
			printf("\n Latest Revision Not Found..!!");fflush(stdout);
		}
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	return SOAP_OK;
}
