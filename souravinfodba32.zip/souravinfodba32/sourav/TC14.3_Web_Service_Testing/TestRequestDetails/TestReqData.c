/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Test Request Revision
*  Description  :   WebService For Different Domain Test Request Lifecycle Details From TCUA CV and PV
*  File Name    :   TestReqData.c
*  Created on   :   April 25th, 2024
*  Usage        :   TestReqData.c
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     25/04/2024                 Sourav Karak
***************************************************************************/

#include "soapH.h"
#include "TestReqData.nsmap"
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128
#define atoa(x) #x

#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

void tostring(char [], int);
void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}
char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* MonthAbbreviation (char* MonthNo)
{
	char *ResponseMonth = (char *) malloc(400*sizeof(char));
	printf("\n Input Month No in String: --------> [%s]\n", MonthNo);fflush(stdout);
	int monno = atoi(MonthNo);
	printf("\n Input Month No in Integer: --------> [%d]\n", monno);fflush(stdout);
	switch(monno)
   {
	case 1:
	       tc_strcpy(ResponseMonth,"Jan");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 2:
	       tc_strcpy(ResponseMonth,"Feb");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 3:
	       tc_strcpy(ResponseMonth,"Mar");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 4:
	       tc_strcpy(ResponseMonth,"Apr");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 5:
	       tc_strcpy(ResponseMonth,"May");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 6:
	       tc_strcpy(ResponseMonth,"Jun");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 7:
	       tc_strcpy(ResponseMonth,"Jul");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 8:
	       tc_strcpy(ResponseMonth,"Aug");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 9:
	       tc_strcpy(ResponseMonth,"Sep");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 10:
	       tc_strcpy(ResponseMonth,"Oct");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 11:
	       tc_strcpy(ResponseMonth,"Nov");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	case 12:
	       tc_strcpy(ResponseMonth,"Dec");
	       printf("\nIn Function - Month Abbreviated Name:  --------> [%s]", ResponseMonth);fflush(stdout);
	       break;
	default:
	       printf("Invalid Number");
	       break;
      }
	  
	  return ResponseMonth;
}

char* InputDateFormatConstruct (char* InputDt)
{
	char* FormatDtRlzd = (char *) malloc(400*sizeof(char));
	char* RespMonth = NULL;
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpSec = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpDay=strtok(InputDt,"/");
	InpMonth=strtok(NULL,"/");
	InpYear=strtok(NULL,"/");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
												
	RespMonth = MonthAbbreviation(InpMonth);
	printf("\n Input Month Abbreviated Form: [%s]\n", RespMonth);fflush(stdout);
												
	tc_strcpy(FormatDtRlzd,InpDay);
	tc_strcat(FormatDtRlzd,"-");
	tc_strcat(FormatDtRlzd,RespMonth);
	tc_strcat(FormatDtRlzd,"-");
    tc_strcat(FormatDtRlzd,InpYear);
    printf("\n Formatted Input Date: [%s]\n", FormatDtRlzd);fflush(stdout);
	  
	return FormatDtRlzd;
}

char* DateFormatConstruct (char* InputDt)
{
	char* FormatCrDate = (char *) malloc(40*sizeof(char));
	char* InpYear = NULL;
	char* InpMonth = NULL;
	char* InpRemainDay = NULL;
	char* InpSeperate = NULL;
	char* InpHour = NULL;
	char* InpMin = NULL;
	char* InpRemainMinHour = NULL;
	char* InpDay = NULL;
	
	InpDay=strtok(InputDt,"-");
	InpMonth=strtok(NULL,"-");
	InpRemainDay=strtok(NULL,"-");
	printf("\n Input Day: [%s]\n", InpDay);fflush(stdout);
	printf("\n Input Month: [%s]\n", InpMonth);fflush(stdout);
	printf("\n Input Remain Day: [%s]\n", InpRemainDay);fflush(stdout);
												
	InpYear=strtok(InpRemainDay," ");
	InpRemainMinHour=strtok(NULL," ");
	printf("\n Input Year: [%s]\n", InpYear);fflush(stdout);
	printf("\n Input Remain Minute & Hour: [%s]\n", InpRemainMinHour);fflush(stdout);
												
	InpHour=strtok(InpRemainMinHour,":");
	InpMin=strtok(NULL,":");
												
	printf("\n Input Hour: [%s]\n", InpHour);fflush(stdout);
	printf("\n Input Minute: [%s]\n", InpMin);fflush(stdout);
	
	if(tc_strcmp(InpMonth,"Jan")== 0)
	{
		STRNG_replace_str(InpMonth,"Jan","01",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Feb")== 0)
	{
		STRNG_replace_str(InpMonth,"Feb","02",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Mar")== 0)
	{
		STRNG_replace_str(InpMonth,"Mar","03",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Apr")== 0)
	{
		STRNG_replace_str(InpMonth,"Apr","04",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"May")== 0)
	{
		STRNG_replace_str(InpMonth,"May","05",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Jun")== 0)
	{
		STRNG_replace_str(InpMonth,"Jun","06",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Jul")== 0)
	{
		STRNG_replace_str(InpMonth,"Jul","07",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Aug")== 0)
	{
		STRNG_replace_str(InpMonth,"Aug","08",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Sep")== 0)
	{
		STRNG_replace_str(InpMonth,"Sep","09",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Oct")== 0)
	{
		STRNG_replace_str(InpMonth,"Oct","10",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Nov")== 0)
	{
		STRNG_replace_str(InpMonth,"Nov","11",&InpMonth);
	}
	else if(tc_strcmp(InpMonth,"Dec")== 0)
	{
		STRNG_replace_str(InpMonth,"Dec","12",&InpMonth);
	}
	else
	{
		printf("Invalid Month");fflush(stdout);
	}
	
	printf("\n Input Month Abbreviated Form: [%s]\n", InpMonth);fflush(stdout);
												
	tc_strcpy(FormatCrDate,InpYear);
	tc_strcat(FormatCrDate,"/");
	tc_strcat(FormatCrDate,InpMonth);
	tc_strcat(FormatCrDate,"/");
    tc_strcat(FormatCrDate,InpDay);
	tc_strcat(FormatCrDate," ");
    tc_strcat(FormatCrDate,InpHour);
    tc_strcat(FormatCrDate,":");
    tc_strcat(FormatCrDate,InpMin);
    printf("\n Formatted Created TimeStamp: [%s]\n", FormatCrDate);fflush(stdout);
	  
	return FormatCrDate;
}

char* WF_GetPendingOnUser (tag_t TR_REV, char* tr_itemno)
{
	int tr_MainWFCount = 0;
	tag_t* tr_MainWFObjects = NULLTAG;
	int k = 0;
	int tr_ActiveWFCount = 0;
	char* current_name = NULL;
	char* StartDate = NULL;
	int JobCount = 0;
	int p = 0;
	tag_t* JobObj = NULLTAG;
	tag_t JobObjtag = NULLTAG;
	char *TR_Pending_User = (char *) malloc(5000*sizeof(char));
    char *TR_WFStuck_User = (char *) malloc(5000*sizeof(char));
	char *TR_WFStart_User = (char *) malloc(5000*sizeof(char));
	char *TR_pendingOn = (char *) malloc(5000*sizeof(char));
	char* Status = NULL;
	char* PendingSigUser = NULL;
	char* StepName = NULL;
	char* StuckSigUser = NULL;
	char* StartSigUser = NULL;
	char* tr_creator = NULL;
	
	
	ITK_CALL(AOM_ask_value_tags(TR_REV,"fnd0AllWorkflows",&tr_MainWFCount,&tr_MainWFObjects));
	if(tr_MainWFCount == 0)
	{
		printf("\n Skipping as TestRequest [%s] not submitted in WF..!! \n",tr_itemno);fflush(stdout);
		tc_strcpy(TR_pendingOn,"Not Submitted");
		goto jump;
	}
	for(k = 0; k < tr_MainWFCount; k++)
	{
		ITK_CALL(AOM_UIF_ask_value(tr_MainWFObjects[k],"current_name",&current_name));
		printf("\n current_name: [%s]",current_name);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(tr_MainWFObjects[k],"fnd0StartDate",&StartDate));
		printf("\n StartDate:%s",StartDate);fflush(stdout);
								
		ITK_CALL(AOM_ask_value_tags(tr_MainWFObjects[k],"fnd0ActuatedInteractiveTsks",&JobCount,&JobObj));
	    printf(" >>>>>> Active JOB Count (JobCount) <<<<<<: [%d]\n",JobCount);fflush(stdout);
								
		tc_strcpy(TR_Pending_User,"@");
		tc_strcpy(TR_WFStuck_User,"@");
		tc_strcpy(TR_WFStart_User,"@");
	    //Logic Start For Test Request Submitted in WF//
		if(JobCount > 0)
		{
			for(p = 0; p < JobCount; p++)
			{
				JobObjtag = JobObj[p];
										
				ITK_CALL(AOM_UIF_ask_value(JobObjtag,"fnd0Status",&Status));
				printf(" WorkFlow Status(Status): [%s]\n",Status);fflush(stdout);
			    //Logic Start For Task Pending Cases//
				if((tc_strcmp(Status,"No Decision")==0) || (tc_strcmp(Status,"Pending")==0))
				{
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"object_name",&StepName));
					printf(" Task Name: [%s]\n",StepName);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"fnd0Assignee",&PendingSigUser));
					printf(" PendingSigUser: [%s]\n",PendingSigUser);fflush(stdout);
					tc_strcat(TR_Pending_User,PendingSigUser);
					tc_strcat(TR_Pending_User,",");
					printf(" PendingSigUser: [%s]\n",TR_Pending_User);fflush(stdout);
				}
				//Logic End For Task Pending Cases//
				//Logic Start For Workflow-Stuck Cases//
				if((tc_strcmp(Status,"Completed")==0) || (tc_strcmp(Status,"Approved")==0) || (tc_strcmp(Status,"Approve")==0))
				{
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"object_name",&StepName));
					printf(" Task Name: [%s]\n",StepName);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"fnd0Assignee",&StuckSigUser));
					printf(" StuckOnUser: [%s]\n",StuckSigUser);fflush(stdout);
					tc_strcat(TR_WFStuck_User,StuckSigUser);
					tc_strcat(TR_WFStuck_User,",");
					printf(" StuckOnUser: [%s]\n",TR_WFStuck_User);fflush(stdout);
				}
				//Logic End For Workflow-Stuck Cases//
				if(tc_strcmp(Status,"Started")==0)
				{
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"object_name",&StepName));
					printf(" Task Name: [%s]\n",StepName);fflush(stdout);
					ITK_CALL(AOM_UIF_ask_value(JobObjtag,"fnd0Assignee",&StartSigUser));
				    printf(" StartUser: [%s]\n",StartSigUser);fflush(stdout);
					tc_strcat(TR_WFStart_User,StartSigUser);
					tc_strcat(TR_WFStart_User,",");
					printf(" StartUser: [%s]\n",TR_WFStart_User);fflush(stdout);
				}
			}	
		}
		//Logic End For Test Request Submitted in WF//
		//Logic Start For Test Request Not Submitted in WF//
		else
		{
			ITK_CALL(AOM_UIF_ask_value(TR_REV,"owning_user",&tr_creator));
			tc_strcat(TR_Pending_User,tr_creator);
			tc_strcat(TR_Pending_User,",");
			tc_strcat(TR_WFStuck_User,tr_creator);
			tc_strcat(TR_WFStuck_User,",");
			tc_strcat(TR_WFStart_User,tr_creator);
			tc_strcat(TR_WFStart_User,",");
			printf("\n Active Job Count Zero[0]..!!\n");fflush(stdout);
	    }
		//Logic End For Test Request Not Submitted in WF//
		tc_strcat(TR_Pending_User,"#");
		tc_strcat(TR_WFStuck_User,"#");
		tc_strcat(TR_WFStart_User,"#");
		STRNG_replace_str(TR_Pending_User,"@","",&TR_Pending_User);
		STRNG_replace_str(TR_Pending_User,",#","",&TR_Pending_User);
		STRNG_replace_str(TR_Pending_User,"#","",&TR_Pending_User);
		STRNG_replace_str(TR_WFStuck_User,"@","",&TR_WFStuck_User);
		STRNG_replace_str(TR_WFStuck_User,",#","",&TR_WFStuck_User);
		STRNG_replace_str(TR_WFStuck_User,"#","",&TR_WFStuck_User);
		STRNG_replace_str(TR_WFStart_User,"@","",&TR_WFStart_User);
	    STRNG_replace_str(TR_WFStart_User,",#","",&TR_WFStart_User);
		STRNG_replace_str(TR_WFStart_User,"#","",&TR_WFStart_User);
		printf(" Pending User(TR_Pending_User): [%s]\n",TR_Pending_User);fflush(stdout);
		printf(" WF Stuck User(TR_WFStuck_User): [%s]\n",TR_WFStuck_User);fflush(stdout);
		printf(" WF Start User(TR_WFStart_User): [%s]\n",TR_WFStart_User);fflush(stdout);
								
		if(tc_strlen(TR_Pending_User)>0)
		{
			printf("\n TR_Pending_User Not Empty So This will be pendingOn Value..!!\n");fflush(stdout);
			//tc_strdup(TR_pendingOn,&TR_Pending_User);
			tc_strcpy(TR_pendingOn,TR_Pending_User);
		}
		else if((tc_strlen(TR_Pending_User)<1) && (tc_strlen(TR_WFStuck_User)>0))
		{
			printf("\n TR_Pending_User Empty & TR_WFStuck_User Not Empty So This will be pendingOn Value..!!\n");fflush(stdout);
			//tc_strdup(TR_pendingOn,&TR_WFStuck_User);
			tc_strcpy(TR_pendingOn,TR_WFStuck_User);
		}
		else
		{
			printf("\n TR_Pending_User & TR_WFStuck_User Both Empty..!!\n");fflush(stdout);
		    //tc_strdup(TR_pendingOn,&TR_WFStart_User);
			tc_strcpy(TR_pendingOn,TR_WFStart_User);
		}
		printf(" #########################################\n");fflush(stdout);
		printf(" Final pendingOn(TR_pendingOn): [%s]\n",TR_pendingOn);fflush(stdout);
		printf(" #########################################\n");fflush(stdout);
	}
	
	jump:
		printf("\n Test request Not Submitted in LifeCycle..!!\n");
	  
	return TR_pendingOn;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -inp=<Creation Date From, Creation Date To & Request Domain > (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    for ( i = 0; i < iNumErrs; i++ )
    {
	   printf("Test");
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n str %s",str);fflush(stdout);
	printf("\n setAddStr %d",*count);fflush(stdout);

	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	if(str!=NULL)
	{
		(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
		tc_strcpy((*strset)[*count-1],str);
		printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
	}
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;

int ns__TestReqDetailsAll(struct soap* soap,char *Input_line_str,struct ns__CharArray *aString)
{
        int iFail =0;
		int ifail =0;
		//int	tt1	= 0;
		char* Print_Report = NULL;
		//char**	ReportSetSTR = NULL;
		char *loggedInUser = NULL;
		size_t len;
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/TestReqData.txt", "w", stdout);
		char *Input_line_strDup = NULL;
		char* resultstring = NULL;
		resultstring=(char *)MEM_alloc(200);
		tag_t tItemobj = NULLTAG;
		int n_entries = 3;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		char *From_date_str = NULL;
		char *To_date_str = NULL;
		char *Rq_domain_str = NULL;
		char *From_date_strDup = NULL;
		char *To_date_strDup = NULL;
		char *Rq_domain_strDup = NULL;
		int i, k = 0;
		char *From_date_final_strDup = (char *) malloc(400*sizeof(char));
		char *To_date_final_strDup = (char *) malloc(400*sizeof(char));
		char *tr_itemid = NULL;
		char *tr_itemidDup = NULL;
		tag_t tr_tag = NULLTAG;
		tag_t tr_rev_tag = NULLTAG;
		//char *task_template = NULL;
		
		char *tr_bunit = NULL;
		char *tr_bunitDup = NULL;
		char *tr_wbs = NULL;
		char *tr_wbsDup = NULL;
		char *tr_wbsdesc = NULL;
		char *tr_wbsdescDup = NULL;
		char *tr_aggr = NULL;
		char *tr_aggrDup = NULL;
		char *tr_descomp = NULL;
		char *tr_descompDup = NULL;
		char *tr_projcode = NULL;
		char *tr_projcodeDup = NULL;
		char *tr_projdes = NULL;
		char *tr_projdesDup = NULL;
		char *tr_program = NULL;
		char *tr_programDup = NULL;
		char *tr_anlyst = NULL;
		char *tr_anlystDup = NULL;
		char *tr_subgrp = NULL;
		char *tr_subgrpDup = NULL;
		char *tr_testagenloc = NULL;
		char *tr_testagenlocDup = NULL;
		char *tr_LCStatus = NULL;
		char *tr_LCStatusDup = NULL;
		char *tr_PatName = NULL;
		char *tr_PatNameDup = NULL;
		char *tr_lstmodby = NULL;
		char *tr_lstmodbyDup = NULL;
		tag_t RelationFindGrnRpt = NULLTAG;
		tag_t *sec_grnrptobjects = NULLTAG;
		int sec_countgrnrpt	= 0;
		char *tr_testitemno = NULL;
		char *tr_testitemnoDup = NULL;
		tag_t RelationFindDesRev = NULLTAG;
		tag_t *sec_desrevobjects = NULLTAG;
		int sec_countdesrev	= 0;
		char *tr_partno = NULL;
		char *TR_Part_No = (char *) malloc(300*sizeof(char));
		//char *TR_Pending_User = (char *) malloc(200*sizeof(char));
		//char *TR_WFStuck_User = (char *) malloc(200*sizeof(char));
		//char *TR_WFStart_User = (char *) malloc(200*sizeof(char));
		//char *TR_pendingOn = (char *) malloc(200*sizeof(char));
		char *tr_drwno = NULL;
		char *tr_drwnoDup = NULL;
		char *tr_modfno = NULL;
		char *tr_modfnoDup = NULL;
		char *tr_make = NULL;
		char *tr_makeDup = NULL;
		char *tr_sampleno = NULL;
		char *tr_samplenoDup = NULL;
		char *tr_reqby = NULL;
		char *tr_reqbyDup = NULL;
		char *tr_eqpmnts = NULL;
		char *tr_eqpmntsDup = NULL;
		char *tr_regreq = NULL;
		char *tr_regreqDup = NULL;
		char *tr_tstreason = NULL;
		char *tr_tstreasonDup = NULL;
		char *tr_dtcreate = NULL;
		char *tr_dtcreateDup = NULL;
		char* FormatCreateDate = NULL;
		char *tr_JobName = NULL;
		char *tr_JobNameDup = NULL;
		tag_t tWFobj = NULLTAG;
		int n_WFentries = 2;
		int n_WFobj_found = 0;
		tag_t* tWFobj_results = NULLTAG;
		tag_t WF_Process = NULLTAG;
		int m = 0;
		char *tr_wftaskname = NULL;
		char *tr_wfeventtype = NULL;
		char *tr_wftaskstat = NULL;
		char *tr_wfperformer = NULL;
		char *tr_wftimestampin = NULL;
		char *tr_wftimestampinDup = NULL;
		char *LatestTimeStampIn = NULL;
		//char *tr_pendingon = (char *) malloc(50*sizeof(char));
		//char *tr_tstamp = (char *) malloc(50*sizeof(char));
		
		char* tr_StepName = NULL;
		//char *tr_Taskstatus = (char *) malloc(50*sizeof(char));
		//char *tr_Taskpendingon = (char *) malloc(50*sizeof(char));
		//char *tr_Tasktstamp = (char *) malloc(50*sizeof(char));
		
		int tr_JobCount = 0;
		tag_t* tr_JobObj = NULLTAG;
		char* tr_PendingSigUser = NULL;
		char* tr_PendingSigUserDup = NULL;
		
		char* Status = NULL;
		char* PendingSigUser = NULL;
		char* StepName = NULL;
		char* tr_creator = NULL;
		char* StuckSigUser = NULL;
		char* StartSigUser = NULL;
		char* From_date_str1 = NULL;
	    char* To_date_str1 = NULL;
	    char *Rq_domain_str1 = (char *) malloc(50*sizeof(char));
		char slNo[20];
		//int i = 0;
		int d = 0;
		char* tr_pending = NULL;
		tr_pending = (char *)MEM_alloc(5000);
		char* responseString = NULL;
		responseString=(char *)MEM_alloc(10000);
		char str[10];
		

		CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login( ));
		CALLAPI(ITK_set_journalling( TRUE ));
		
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);

		trimwhitespace(Input_line_str);
	    if(Input_line_str!=NULL)tc_strdup(Input_line_str,&Input_line_strDup);
	    printf(" [1]: Input Line(Input_line_str): [%s]\n",Input_line_strDup);
	    From_date_str=strtok(Input_line_strDup,"^");
	    To_date_str=strtok(NULL,"^");
		Rq_domain_str=strtok(NULL,"^");
	    
		From_date_str1 = InputDateFormatConstruct(From_date_str);
		To_date_str1 = InputDateFormatConstruct(To_date_str);
		
		if(tc_strcmp(Rq_domain_str,"caf")==0)
		{
		  tc_strcpy(Rq_domain_str1,"1D_CAE-Climate_Control");
		}
		else if(tc_strcmp(Rq_domain_str,"caa")==0)
		{
		  tc_strcpy(Rq_domain_str1,"CAE-Aerothermal");
		}
		else if(tc_strcmp(Rq_domain_str,"cac")==0)
		{
		  tc_strcpy(Rq_domain_str1,"CAE-Crash");
		}
		else if(tc_strcmp(Rq_domain_str,"cad")==0)
		{
		  tc_strcpy(Rq_domain_str1,"CAE-Durability");
		}
		else if(tc_strcmp(Rq_domain_str,"cam")==0)
		{
		  tc_strcpy(Rq_domain_str1,"CAE-MBD");
		}
		else if(tc_strcmp(Rq_domain_str,"can")==0)
		{
		  tc_strcpy(Rq_domain_str1,"CAE-NVH");
		}
		else if(tc_strcmp(Rq_domain_str,"tsm")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Climate");
		}
		else if(tc_strcmp(Rq_domain_str,"tsc")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Crash");
		}
		else if(tc_strcmp(Rq_domain_str,"tse")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Engines");
		}
		else if(tc_strcmp(Rq_domain_str,"tsi")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Indoor");
		}
		else if(tc_strcmp(Rq_domain_str,"tmt")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Metallurgy");
		}
		else if(tc_strcmp(Rq_domain_str,"tsn")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-NVH");
		}
		else if(tc_strcmp(Rq_domain_str,"tso")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Outdoor");
		}
		else if(tc_strcmp(Rq_domain_str,"tst")==0)
		{
		  tc_strcpy(Rq_domain_str1,"Testing-Transmission");
		}
		else
		{
		  tc_strcpy(Rq_domain_str1,"NA");
		}
		
		trimwhitespace(From_date_str1);
		trimwhitespace(To_date_str1);
		trimwhitespace(Rq_domain_str1);
		if(From_date_str1!=NULL)tc_strdup(From_date_str1,&From_date_strDup);
		if(To_date_str1!=NULL)tc_strdup(To_date_str1,&To_date_strDup);
		if(Rq_domain_str1!=NULL)tc_strdup(Rq_domain_str1,&Rq_domain_strDup);
		printf(" [1]: Input From Date(From_date_strDup): [%s]\n",From_date_strDup);
		printf(" [2]: Input To Date(To_date_strDup): [%s]\n",To_date_strDup);
		printf(" [3]: Input Request Domain(Rq_domain_strDup): [%s]\n",Rq_domain_strDup);
		
		tc_strcpy(From_date_final_strDup,From_date_strDup);
		tc_strcat(From_date_final_strDup," 00:00");
		printf(" Final: From Date Value(From_date_final_strDup): [%s]\n",From_date_final_strDup);
		
		tc_strcpy(To_date_final_strDup,To_date_strDup);
		tc_strcat(To_date_final_strDup," 00:00");
		printf(" Final: To Date Value(To_date_final_strDup): [%s]\n",To_date_final_strDup);
		
		ITK_CALL(QRY_find2("Test Request Query",&tItemobj));
		if(tItemobj != NULLTAG)
		{
			printf("\n Test Request Query Found Successfully..!!\n");fflush(stdout);
			char *cEntries[3]  = {"Creation Date From","Creation Date To","Request Domain"};
			char *cValues[3]  = {From_date_final_strDup,To_date_final_strDup,Rq_domain_strDup};
			//char *cValues[3]  = {"14-Apr-2024 00:00","21-Apr-2024 00:00","Testing-Indoor"};
			ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
			printf("\n -----------------------------------------------\n");fflush(stdout);
			printf("\n No of Test-Request Found: [%d]\n",n_itemobj_found);fflush(stdout);
			printf("\n -----------------------------------------------\n");fflush(stdout);
			if(n_itemobj_found > 0)
			{
				
				d = n_itemobj_found;	aString->__size = d;
		        aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );
				
				printf(" Test Request Query Found..!!\n");fflush(stdout);
				for(i = 0; i < n_itemobj_found; i++)
				{
					
					//tostring(str, i);
					sprintf(slNo,"%d",i);
					/*tc_strcpy(responseString1,"plm_id:");
					tc_strcat(responseString1,slNo);
					setAddStr(&tt1,&ReportSetSTR,responseString1); */
					
					ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&tr_itemid));
					if(tc_strlen(tr_itemid)>0)
					{
						tc_strdup(tr_itemid,&tr_itemidDup);
					}
					else
					{
						tc_strdup("NA",&tr_itemidDup);
						printf("\n Test Request No is NULL..!!");fflush(stdout);
					}
					/* tc_strcpy(responseString2,"plm_req_no: ");
				    tc_strcat(responseString2,tr_itemidDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString2); */
					
					
					printf("\n Test Request No Found..!!");fflush(stdout);
					ITK_CALL(ITEM_find_item(tr_itemidDup, &tr_tag));
					ITK_CALL(ITEM_find_revision(tr_tag,"A;1",&tr_rev_tag)) ;
						
					//ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"fnd0ActuatedInteractiveTsks",&task_template));
					//printf("\n Task Template: [%s]\n",task_template);fflush(stdout);
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_BU",&tr_bunit));
					if(tc_strlen(tr_bunit)>0)
				    {
						tc_strdup(tr_bunit,&tr_bunitDup);
					}
					else
					{
						tc_strdup("NA",&tr_bunitDup);
						printf("\n Business Unit is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_bunitDup,"&","and",&tr_bunitDup);
					/* tc_strcpy(responseString3,"business_unit: ");
				    tc_strcat(responseString3,tr_bunitDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString3); */
					
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_WBS",&tr_wbs));
					if(tc_strlen(tr_wbs)>0)
					{
						tc_strdup(tr_wbs,&tr_wbsDup);
					}
					else
					{
						tc_strdup("NA",&tr_wbsDup);
						printf("\n WBS is NULL..!!\n");fflush(stdout);
					}
					/* tc_strcpy(responseString4,"wbs: ");
				    tc_strcat(responseString4,tr_wbsDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString4); */
							
				    ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_WbsDesc",&tr_wbsdesc));
					if(tc_strlen(tr_wbsdesc)>0)
					{
						tc_strdup(tr_wbsdesc,&tr_wbsdescDup);
					}
					else
					{
					    tc_strdup("NA",&tr_wbsdescDup);
						printf("\n WBS Description is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_wbsdescDup,"&","and",&tr_wbsdescDup);
					/* tc_strcpy(responseString5,"wbs_desc: ");
				    tc_strcat(responseString5,tr_wbsdescDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString5); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqAggregate",&tr_aggr));
					if(tc_strlen(tr_aggr)>0)
				    {
						tc_strdup(tr_aggr,&tr_aggrDup);
					}
					else
					{
						tc_strdup("NA",&tr_aggrDup);
						printf("\n Aggregates is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_aggrDup,"&","and",&tr_aggrDup);
					/* tc_strcpy(responseString6,"aggregate: ");
				    tc_strcat(responseString6,tr_aggrDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString6); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_DescComp",&tr_descomp));
					if(tc_strlen(tr_descomp)>0)
					{
						tc_strdup(tr_descomp,&tr_descompDup);
					}
					else
					{
						tc_strdup("NA",&tr_descompDup);
						printf("\n Description Of Component is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_descompDup,","," ",&tr_descompDup);
					STRNG_replace_str(tr_descompDup,";"," ",&tr_descompDup);
					STRNG_replace_str(tr_descompDup,"\n"," ",&tr_descompDup);
					STRNG_replace_str(tr_descompDup,"'"," ",&tr_descompDup);
					STRNG_replace_str(tr_descompDup,"&","and",&tr_descompDup);
					/* tc_strcpy(responseString7,"comp_desc: ");
				    tc_strcat(responseString7,tr_descompDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString7); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProjCode",&tr_projcode));
					if(tc_strlen(tr_projcode)>0)
					{
					    tc_strdup(tr_projcode,&tr_projcodeDup);
					}
					else
					{
						tc_strdup("NA",&tr_projcodeDup);
						printf("\n Project Code is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_projcodeDup,"&","and",&tr_projcodeDup);
					/* tc_strcpy(responseString8,"projec_code: ");
				    tc_strcat(responseString8,tr_projcodeDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString8); */
							
				    ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProjDes",&tr_projdes));
					if(tc_strlen(tr_projdes)>0)
					{
						tc_strdup(tr_projdes,&tr_projdesDup);
					}
					else
					{
						tc_strdup("NA",&tr_projdesDup);
						printf("\n Project Description is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_projdesDup,"&","and",&tr_projdesDup);
					/* tc_strcpy(responseString9,"project_desc: ");
				    tc_strcat(responseString9,tr_projdesDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString9); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProgram",&tr_program));
					if(tc_strlen(tr_program)>0)
					{
						tc_strdup(tr_program,&tr_programDup);
					}
					else
					{
						tc_strdup("NA",&tr_programDup);
						printf("\n Program is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_programDup,"&","and",&tr_programDup);
					/* tc_strcpy(responseString10,"program: ");
				    tc_strcat(responseString10,tr_programDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString10); */
							
					if(tc_strlen(tr_anlyst)>0)
					{
						tc_strdup(tr_anlyst,&tr_anlystDup);
					}
					else
					{
						tc_strdup("NA",&tr_anlystDup);
						printf("\n Analyst is NULL..!!\n");fflush(stdout);
					}
					/* tc_strcpy(responseString11,"analyst: ");
				    tc_strcat(responseString11,tr_anlystDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString11); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_TestSubGrp",&tr_subgrp));
					if(tc_strlen(tr_subgrp)>0)
					{
						tc_strdup(tr_subgrp,&tr_subgrpDup);
					}
					else
					{
						tc_strdup("NA",&tr_subgrpDup);
						printf("\n Testing Sub-Group is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_subgrpDup,"&","and",&tr_subgrpDup);
					/* tc_strcpy(responseString12,"sub_group: ");
				    tc_strcat(responseString12,tr_subgrpDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString12); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_Testing_Agency_Loc",&tr_testagenloc));
					if(tc_strlen(tr_testagenloc)>0)
					{
						tc_strdup(tr_testagenloc,&tr_testagenlocDup);
					}
					else
					{
						tc_strdup("NA",&tr_testagenlocDup);
						printf("\n Testing Agency Location is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_testagenlocDup,"&","and",&tr_testagenlocDup);
					/* tc_strcpy(responseString13,"location: ");
				    tc_strcat(responseString13,tr_testagenlocDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString13); */
							
					ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"release_status_list",&tr_LCStatus));
					printf("\n Life Cycle Status Before Dup & Trim:  <%s> \n",tr_LCStatus);fflush(stdout);
					if(tc_strlen(tr_LCStatus)>0)
					{
						tc_strdup(tr_LCStatus,&tr_LCStatusDup);
					}
					else
					{
						tc_strdup("NA",&tr_LCStatusDup);
						printf("\n Life Cycle Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(tr_LCStatusDup);
					printf("\n Life Cycle Status After Dup & Trim: [%s]", tr_LCStatusDup);fflush(stdout);
					STRNG_replace_str(tr_LCStatusDup,","," ",&tr_LCStatusDup);
					STRNG_replace_str(tr_LCStatusDup,";"," ",&tr_LCStatusDup);
					STRNG_replace_str(tr_LCStatusDup,"\n"," ",&tr_LCStatusDup);
					STRNG_replace_str(tr_LCStatusDup,"'"," ",&tr_LCStatusDup);
					STRNG_replace_str(tr_LCStatusDup,"&","and",&tr_LCStatusDup);
					printf("\n Life Cycle Status Final Value: [%s]", tr_LCStatusDup);fflush(stdout);
					/* tc_strcpy(responseString14,"life_cycle_status: ");
				    tc_strcat(responseString14,tr_LCStatusDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString14); */
							
					printf("Function: Test Request Object Pending on User Details Calling Start\n");fflush(stdout);
					tr_pending = WF_GetPendingOnUser(tr_rev_tag, tr_itemidDup);
					printf("Function: Test Request Object Pending on User Details Calling End\n");fflush(stdout);
					printf("Test-Request PendingOn Before Trim: [%s]\n",tr_pending);fflush(stdout);
				    trimwhitespace(tr_pending);
					printf("Test-Request PendingOn After Trim: [%s]\n",tr_pending);fflush(stdout);	
					
					if(tc_strlen(tr_PatName)>0)
					{
					    tc_strdup(tr_PatName,&tr_PatNameDup);
				    }
					else
					{
						tc_strdup("NA",&tr_PatNameDup);
						printf("\n Pat Name is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_PatNameDup,"&","and",&tr_PatNameDup);
					/* tc_strcpy(responseString16,"patName: ");
				    tc_strcat(responseString16,tr_PatNameDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString16); */
							
					/* tc_strcpy(responseString17,"lifeCycleState: ");
				    tc_strcat(responseString17,tr_LCStatusDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString17); */
							
					ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"last_mod_user",&tr_lstmodby));
					printf("\n Last Modified By Before Dup & Trim:  <%s> \n",tr_lstmodby);fflush(stdout);
					if(tc_strlen(tr_lstmodby)>0)
					{
					    tc_strdup(tr_lstmodby,&tr_lstmodbyDup);
				    }
					else
					{
						tc_strdup("NA",&tr_lstmodbyDup);
						printf("\n Last Modified By Value is NULL");fflush(stdout);
					}
					trimwhitespace(tr_lstmodbyDup);
					printf("\n Last Modified By After Dup & Trim: [%s]", tr_lstmodbyDup);fflush(stdout);
					STRNG_replace_str(tr_lstmodbyDup,","," ",&tr_lstmodbyDup);
					STRNG_replace_str(tr_lstmodbyDup,";"," ",&tr_lstmodbyDup);
					STRNG_replace_str(tr_lstmodbyDup,"\n"," ",&tr_lstmodbyDup);
					STRNG_replace_str(tr_lstmodbyDup,"'"," ",&tr_lstmodbyDup);
					STRNG_replace_str(tr_lstmodbyDup,"&","and",&tr_lstmodbyDup);
					printf("\n Last Modified By Final Value: [%s]", tr_lstmodbyDup);fflush(stdout);
					/* tc_strcpy(responseString18,"lastModifiedBy: ");
				    tc_strcat(responseString18,tr_lstmodbyDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString18); */
							
					ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"last_mod_date",&tr_wftimestampin));
					if(tc_strlen(tr_wftimestampin)>0)
					{
						tc_strdup(tr_wftimestampin,&tr_wftimestampinDup);
						LatestTimeStampIn = DateFormatConstruct(tr_wftimestampinDup);
						tc_strdup(LatestTimeStampIn,&tr_wftimestampinDup);
					}
					else
					{
						tc_strdup("NA",&tr_wftimestampinDup);
						printf("\n TimeStampIn is NULL..!!\n");fflush(stdout);
					}
					/* tc_strcpy(responseString19,"timeStampIn: ");
				    tc_strcat(responseString19,tr_wftimestampinDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString19); */
							
					//ITK_CALL(GRM_find_relation_type("T5_TR_GR_REL",&RelationFindGrnRpt));
					ITK_CALL(GRM_find_relation_type("T5_TR_TP_REL",&RelationFindGrnRpt));
					if(RelationFindGrnRpt!=NULLTAG)
					{									
						//printf("\n Sudo Folder Test Request Has GreenReport(T5_TR_GR_REL) Relation Found..!!\n");fflush(stdout);
					    //ITK_CALL(GRM_list_secondary_objects_only(tr_rev_tag, RelationFindGrnRpt, &sec_countgrnrpt, &sec_grnrptobjects));
					    //printf("\n Total Objects Found(T5_TR_GR_REL): [%d]\n", sec_countgrnrpt);
						printf("\n Sudo Folder Test Request Has TestPlan(T5_TR_TP_REL) Relation Found..!!\n");fflush(stdout);
					    ITK_CALL(GRM_list_secondary_objects_only(tr_rev_tag, RelationFindGrnRpt, &sec_countgrnrpt, &sec_grnrptobjects));
					    printf("\n Total Objects Found(T5_TR_TP_REL): [%d]\n", sec_countgrnrpt);
						if(sec_countgrnrpt > 0)
						{
							//ITK_CALL(AOM_ask_value_string(sec_grnrptobjects[0],"t5_TestItmNoGr",&tr_testitemno));
							//ITK_CALL(AOM_ask_value_string(sec_grnrptobjects[0],"item_id",&tr_testitemno));
							ITK_CALL(AOM_ask_value_string(sec_grnrptobjects[0],"t5_TestItmNo",&tr_testitemno));
							if(tc_strlen(tr_testitemno)>0)
							{
								tc_strdup(tr_testitemno,&tr_testitemnoDup);
							}
							else
							{
								tc_strdup("NA",&tr_testitemnoDup);
								printf("\n Test Item No is NULL..!!\n");fflush(stdout);
							}
						}
						else
						{
							tc_strdup("NA",&tr_testitemnoDup);
							printf("\n GreenReport Not Found So Test Item No is NULL..!!\n");fflush(stdout);
						}
					}
					else
					{
						tc_strdup("NA",&tr_testitemnoDup);
						//printf("\n Test Request Has GreenReport(T5_TR_GR_REL) Relation Tag Not Found So Test Item No is NULL..!!\n");fflush(stdout);
						printf("\n Test Request Has TestPlan(T5_TR_TP_REL) Relation Tag Not Found So Test Item No is NULL..!!\n");fflush(stdout);
					}
					/* tc_strcpy(responseString20,"testItemNo: ");
				    tc_strcat(responseString20,tr_testitemnoDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString20); */
							
					ITK_CALL(GRM_find_relation_type("T5_TR_DesRev_Rel",&RelationFindDesRev));
					tc_strcpy(TR_Part_No,"@");
					if(RelationFindDesRev!=NULLTAG)
					{									
					    printf("\n Sudo Folder Test Request has Design revision(T5_TR_DesRev_Rel) Relation Found..!!\n");fflush(stdout);
						ITK_CALL(GRM_list_secondary_objects_only(tr_rev_tag, RelationFindDesRev, &sec_countdesrev, &sec_desrevobjects));
					    printf("\n Total Objects Found(T5_TR_DesRev_Rel): [%d]\n", sec_countdesrev);
						if(sec_countdesrev > 0)
						{
							for(k = 0; k < sec_countdesrev; k++)
							{
								ITK_CALL(AOM_ask_value_string(sec_desrevobjects[k],"item_id",&tr_partno));
								if(tc_strlen(tr_partno)>0)
								{
									tc_strcat(TR_Part_No,tr_partno);
									tc_strcat(TR_Part_No,",");
								}
								else
								{
									tc_strcat(TR_Part_No,"NA");
									printf("\n Part No is NULL..!!\n");fflush(stdout);
								}
							}
						}
						else
						{
							tc_strcat(TR_Part_No,"NA");
							printf("\n Design Revision Not Found So Part No is NULL..!!\n");fflush(stdout);
						}
					}
					else
					{
						tc_strcat(TR_Part_No,"NA");
						printf("\n Test Request Has Design Revision(T5_TR_DesRev_Rel) Relation Tag Not Found So Part No is NULL..!!\n");fflush(stdout);
					}
					tc_strcat(TR_Part_No,"#");
					STRNG_replace_str(TR_Part_No,"@","",&TR_Part_No);
					STRNG_replace_str(TR_Part_No,",#","",&TR_Part_No);
					STRNG_replace_str(TR_Part_No,"#","",&TR_Part_No);
					/* tc_strcpy(responseString21,"partNo: ");
				    tc_strcat(responseString21,TR_Part_No);
				    setAddStr(&tt1,&ReportSetSTR,responseString21); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_CtrDrwNo",&tr_drwno));
					if(tc_strlen(tr_drwno)>0)
					{
						tc_strdup(tr_drwno,&tr_drwnoDup);
					}
					else
					{
						tc_strdup("NA",&tr_drwnoDup);
						printf("\n Drawing No is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_drwnoDup," ","",&tr_drwnoDup);
					/* tc_strcpy(responseString22,"drawingNo: ");
				    tc_strcat(responseString22,tr_drwnoDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString22); */
							
					/* tc_strcpy(responseString23,"VehicleType: ");
				    tc_strcat(responseString23,tr_projdesDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString23); */
							
					if(tc_strlen(tr_modfno)>0)
					{
						tc_strdup(tr_modfno,&tr_modfnoDup);
					}
					else
					{
						tc_strdup("NA",&tr_modfnoDup);
						printf("\n Modification No is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_modfnoDup,"&","and",&tr_modfnoDup);
					/* tc_strcpy(responseString24,"modificationNo: ");
				    tc_strcat(responseString24,tr_modfnoDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString24); */
							
					if(tc_strlen(tr_make)>0)
					{
						tc_strdup(tr_make,&tr_makeDup);
					}
					else
					{
						tc_strdup("NA",&tr_makeDup);
						printf("\n Make is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_makeDup,"&","and",&tr_makeDup);
					/* tc_strcpy(responseString25,"make: ");
				    tc_strcat(responseString25,tr_makeDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString25); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqSmplNo",&tr_sampleno));
					if(tc_strlen(tr_sampleno)>0)
					{
						tc_strdup(tr_sampleno,&tr_samplenoDup);
				    }
					else
					{
						tc_strdup("NA",&tr_samplenoDup);
						printf("\n Number of Samples is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_samplenoDup,"&","and",&tr_samplenoDup);
					/* tc_strcpy(responseString26,"noOfSamples: ");
				    tc_strcat(responseString26,tr_samplenoDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString26); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqReqDep",&tr_reqby));
					if(tc_strlen(tr_reqby)>0)
					{
						tc_strdup(tr_reqby,&tr_reqbyDup);
					}
					else
					{
						tc_strdup("NA",&tr_reqbyDup);
						printf("\n Request Agency is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_reqbyDup,"&","and",&tr_reqbyDup);
					/* tc_strcpy(responseString27,"testRequestedBy: ");
				    tc_strcat(responseString27,tr_reqbyDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString27); */
							
					if(tc_strlen(tr_eqpmnts)>0)
					{
						tc_strdup(tr_eqpmnts,&tr_eqpmntsDup);
					}
					else
					{
						tc_strdup("NA",&tr_eqpmntsDup);
						printf("\n Equipments is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_eqpmntsDup,"&","and",&tr_eqpmntsDup);
					/* tc_strcpy(responseString28,"equipments: ");
				    tc_strcat(responseString28,tr_eqpmntsDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString28); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqRegulation",&tr_regreq));
					if(tc_strlen(tr_regreq)>0)
					{
						tc_strdup(tr_regreq,&tr_regreqDup);
					}
					else
					{
						tc_strdup("NA",&tr_regreqDup);
						printf("\n Regulatory Requirement is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_regreqDup,"&","and",&tr_regreqDup);
					/* tc_strcpy(responseString29,"regulatoryRequirement: ");
				    tc_strcat(responseString29,tr_regreqDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString29) */;
							
					/* tc_strcpy(responseString30,"testRequisitionReference: ");
				    tc_strcat(responseString30,tr_itemidDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString30); */
							
					ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqInvType",&tr_tstreason));
					if(tc_strlen(tr_tstreason)>0)
					{
						tc_strdup(tr_tstreason,&tr_tstreasonDup);
					}
					else
					{
						tc_strdup("NA",&tr_tstreasonDup);
						printf("\n Reason For Test is NULL..!!\n");fflush(stdout);
					}
					STRNG_replace_str(tr_tstreasonDup,"&","and",&tr_tstreasonDup);
					/* tc_strcpy(responseString31,"reasonForTest: ");
				    tc_strcat(responseString31,tr_tstreasonDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString31); */
							
					ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"creation_date",&tr_dtcreate));
					if(tc_strlen(tr_dtcreate)>0)
					{
						tc_strdup(tr_dtcreate,&tr_dtcreateDup);
						FormatCreateDate = DateFormatConstruct(tr_dtcreateDup);
						tc_strdup(FormatCreateDate,&tr_dtcreateDup);
					}
					else
				    {
						tc_strdup("NA",&tr_dtcreateDup);
						printf("\n Created TimeStamp is NULL..!!\n");fflush(stdout);
					}
					/* tc_strcpy(responseString32,"createdtimestamp: ");
				    tc_strcat(responseString32,tr_dtcreateDup);
				    setAddStr(&tt1,&ReportSetSTR,responseString32); */
							
						
					printf(" Test Request Details Start...!!\n");fflush(stdout);
					//printf("[1] plm_id: [%s]\n",str);fflush(stdout);
					printf("[1] plm_id: [%s]\n",slNo);fflush(stdout);
					printf("[2] plm_req_no: [%s]\n",tr_itemidDup);fflush(stdout);
					printf("[3] business_unit: [%s]\n",tr_bunitDup);fflush(stdout);
					printf("[4] wbs: [%s]\n",tr_wbsDup);fflush(stdout);
					printf("[5] wbs_desc: [%s]\n",tr_wbsdescDup);fflush(stdout);
					printf("[6] aggregate: [%s]\n",tr_aggrDup);fflush(stdout);
					printf("[7] comp_desc: [%s]\n",tr_descompDup);fflush(stdout);
					printf("[8] projec_code: [%s]\n",tr_projcodeDup);fflush(stdout);
					printf("[9] project_desc: [%s]\n",tr_projdesDup);fflush(stdout);
					printf("[10] program: [%s]\n",tr_programDup);fflush(stdout);
					printf("[11] analyst: [%s]\n",tr_anlystDup);fflush(stdout);
					printf("[12] sub_group: [%s]\n",tr_subgrpDup);fflush(stdout);
					printf("[13] location: [%s]\n",tr_testagenlocDup);fflush(stdout);
					printf("[14] life_cycle_status: [%s]\n",tr_LCStatusDup);fflush(stdout);
					printf("[15] pendingOn: [%s]\n",tr_pending);fflush(stdout);
					printf("[16] patName: [%s]\n",tr_PatNameDup);fflush(stdout);
					printf("[17] lifeCycleState: [%s]\n",tr_LCStatusDup);fflush(stdout);
					printf("[18] lastModifiedBy: [%s]\n",tr_lstmodbyDup);fflush(stdout);
					printf("[19] timeStampIn: [%s]\n",tr_wftimestampinDup);fflush(stdout);
					printf("[20] testItemNo: [%s]\n",tr_testitemnoDup);fflush(stdout);
					printf("[21] partNo: [%s]\n",TR_Part_No);fflush(stdout);
					printf("[22] drawingNo: [%s]\n",tr_drwnoDup);fflush(stdout);
					printf("[23] VehicleType [%s]\n",tr_projdesDup);fflush(stdout);
					printf("[24] modificationNo [%s]\n",tr_modfnoDup);fflush(stdout);
					printf("[25] make [%s]\n",tr_makeDup);fflush(stdout);
					printf("[26] noOfSamples [%s]\n",tr_samplenoDup);fflush(stdout);
					printf("[27] testRequestedBy [%s]\n",tr_reqbyDup);fflush(stdout);
					printf("[28] equipments [%s]\n",tr_eqpmntsDup);fflush(stdout);
					printf("[29] regulatoryRequirement [%s]\n",tr_regreqDup);fflush(stdout);
					printf("[30] testRequisitionReference [%s]\n",tr_itemidDup);fflush(stdout);
					printf("[31] reasonForTest [%s]\n",tr_tstreasonDup);fflush(stdout);
					printf("[32] createdtimestamp [%s]\n",tr_dtcreateDup);fflush(stdout);
					printf(" Test Request Details End...!!\n");fflush(stdout);
					
					tc_strcpy(responseString," ");
					tc_strcpy(responseString,"plm_id: ");
					tc_strcat(responseString,slNo);
					tc_strcat(responseString," ~plm_req_no: ");
					tc_strcat(responseString,tr_itemidDup);
					tc_strcat(responseString," ~BusUnit: ");
					tc_strcat(responseString,tr_bunitDup);
					tc_strcat(responseString," ~WBS: ");
					tc_strcat(responseString,tr_wbsDup);
					tc_strcat(responseString," ~WBSDesc: ");
					tc_strcat(responseString,tr_wbsdescDup);
					tc_strcat(responseString," ~Aggregate: ");
					tc_strcat(responseString,tr_aggrDup);
					tc_strcat(responseString," ~CompDesc: ");
					tc_strcat(responseString,tr_descompDup);
					tc_strcat(responseString," ~Project: ");
					tc_strcat(responseString,tr_projcodeDup);
					tc_strcat(responseString," ~ProDesc: ");
					tc_strcat(responseString,tr_projdesDup);
					tc_strcat(responseString," ~Program: ");
					tc_strcat(responseString,tr_programDup);
					tc_strcat(responseString," ~Analyst: ");
					tc_strcat(responseString,tr_anlystDup);
					tc_strcat(responseString," ~SubGroup: ");
					tc_strcat(responseString,tr_subgrpDup);
					tc_strcat(responseString," ~Location: ");
					tc_strcat(responseString,tr_testagenlocDup);
					tc_strcat(responseString," ~CurrentAssignment: ");
					tc_strcat(responseString,tr_LCStatusDup);
					tc_strcat(responseString," ~AssignmentAt: ");
					tc_strcat(responseString,tr_pending);
					tc_strcat(responseString," ~PATName: ");
					tc_strcat(responseString,tr_PatNameDup);
					tc_strcat(responseString," ~LifeCycleState: ");
					tc_strcat(responseString,tr_LCStatusDup);
					tc_strcat(responseString," ~LastModBy: ");
					tc_strcat(responseString,tr_lstmodbyDup);
					tc_strcat(responseString," ~TimeStampIn: ");
					tc_strcat(responseString,tr_wftimestampinDup);
					tc_strcat(responseString," ~TestItemNo: ");
					tc_strcat(responseString,tr_testitemnoDup);
					tc_strcat(responseString," ~PartNumber: ");
					tc_strcat(responseString,TR_Part_No);
					tc_strcat(responseString," ~DrawingNo: ");
					tc_strcat(responseString,tr_drwnoDup);
					tc_strcat(responseString," ~VehicleType : ");
					tc_strcat(responseString,tr_projdesDup);
					tc_strcat(responseString," ~ModificationNo : ");
					tc_strcat(responseString,tr_modfnoDup);
					tc_strcat(responseString," ~Make : ");
					tc_strcat(responseString,tr_makeDup);
					tc_strcat(responseString," ~No.Of.Samples: ");
					tc_strcat(responseString,tr_samplenoDup);
					tc_strcat(responseString," ~TestRequestedBy: ");
					tc_strcat(responseString,tr_reqbyDup);
					tc_strcat(responseString," ~Equipments: ");
					tc_strcat(responseString,tr_eqpmntsDup);
					tc_strcat(responseString," ~RegulatoryRequirement : ");
					tc_strcat(responseString,tr_regreqDup);
					tc_strcat(responseString," ~TestRequisitionReference : ");
					tc_strcat(responseString,tr_itemidDup);
					tc_strcat(responseString," ~ReasonForTest : ");
					tc_strcat(responseString,tr_tstreasonDup);
					tc_strcat(responseString," ~CreatedTimeStamp : ");
					tc_strcat(responseString,tr_dtcreateDup);
					

                    aString->__ptr[i] = (char *) malloc( (10000) * sizeof(char));
                    tc_strcpy(aString->__ptr[i], responseString);
						
				}
			}
			else
			{
				printf("\n No Test Request Found For Given Input Data..!!");fflush(stdout);
				d = 1;	aString->__size = d;
		        aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );

		        tc_strcpy(responseString,"Test Req Not Found");
		        aString->__ptr[0] = (char *) malloc( (20) * sizeof(char));
		        tc_strcpy(aString->__ptr[0], responseString);
			}
		}
		else
		{
			printf("\n Test Request Query Tag is NULL..!!");fflush(stdout);
		}
		
		if (titemobj_results)
		{
		  MEM_free(titemobj_results);
		}
		printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
		
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	return SOAP_OK;
}