/**********************************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* Program Name	  :AplDmlPend.c
* Author		  : Dayanand
* Created on	  : Saturday, March 31, 2007
* Project         : TATA MOTORS - ECN Pending Report
* Methods Defined : AplDmlPend
*
*PURPOSE:
*
*     1. If Input is Clinet code exe
*     1. If Input is ".log" or ".txt" File --> To register JT file in TC, then Checkin to "WIP Vault" then Freeze.
*
*MAIN LOGIC OF THE PROGRAM:
*     1. This Program is specially used for Assorted JT View JT Files and Log Files.
*
* Modification History :
* S.No    Date        CR No      Modified By            Modification Notes
*
*
*********************************************************************************************/
//static char *_rcsvid ="$Id: EPASummaryRptTcra.c,v 1.1 2016/05/13 07:53:07 dpa06577 Exp $";


char* subString
(
  char* mainStringf ,
  int fromCharf     ,
  int toCharf
)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}


#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <oi.h>
#include <ui.h>

int startDatePendingEpasTcra(string fromDate, string plant, string Args)
{
	char *mod_name = "startDatePendingEpasTcra";

	integer mfail = USC_OKAY;
	status	dstat = OKAY;

	SqlPtr EpaCntQry	    = NULL;
	integer pendingEpas     = 0;
	integer finalizedEpas   = 0;

	printf("\n Inside startDatePendingEpasTcra Fun() FromDate:%s, Plant:%s",fromDate, plant); fflush(stdout);
	////  1st Step: take out total no. of EPAs which were created before fromDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, CreationDateAttr, fromDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;

	//printf("Args-->Length in startDatePendingEpasTcra %d",nlsStrLen(Args)); fflush(stdout);
	//printf("\nLength and ARGS---->startDatePendingEpasTcra %d %s",nlsStrLen(Args),Args); fflush(stdout);

	if(!nlsIsStrNull(Args))
	{
		if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}

	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &pendingEpas, &mfail)) goto EXIT;
	printf("\nNo. of EPAs Created before %s are:%d",fromDate,pendingEpas); fflush(stdout);

	EpaCntQry  = NULL;
	printf("Args :: %s",Args); fflush(stdout);

	//// 2nd Step: take out no. of EPAs which were finalized before fromDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, ClosureTimeStampAttr, fromDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;

	printf("\nARGS---> %s",Args); fflush(stdout);
	if(!nlsIsStrNull(Args))
	{
		if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}


	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &finalizedEpas, &mfail)) goto EXIT;
	printf("\nNo. of EPAs Finalized before %s are:%d",fromDate,finalizedEpas); fflush(stdout);

	return (pendingEpas - finalizedEpas);

	CLEANUP :
	EXIT :
		printf("In the EXIT of startDatePendingEpasTcra"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);
		return 0;
}

int endDatePendingEpasTcra(string toDate, string plant, string Args)
{
	char *mod_name = "endDatePendingEpasTcra";
	integer mfail = USC_OKAY;
	status	dstat = OKAY;

	SqlPtr EpaCntQry	= NULL;
	integer pendingEpas = 0;
	integer finalizedEpas = 0;

	printf("\n Inside endDatePendingEpasTcra Fun() ToDate:%s, Plant:%s",toDate, plant); fflush(stdout);
	printf("\nArgs :: %s",Args); fflush(stdout);
	////  5th Step: take out total no. of EPAs which were created before toDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, CreationDateAttr, toDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;

	printf("\nARGS----->endDatePendingEpasTcra %s",Args); fflush(stdout);
	if(!nlsIsStrNull(Args))
	{
		if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}



	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &pendingEpas, &mfail)) goto EXIT;
	printf("\nNo. of EPAs Created before %s are:%d",toDate,pendingEpas); fflush(stdout);

	EpaCntQry  = NULL;
	printf("Args :: %s",Args); fflush(stdout);
	//// 6th Step: take out no. of EPAs which were finalized before toDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, ClosureTimeStampAttr, toDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;

//	printf("Args length :: %d",nlsStrLen(Args)); fflush(stdout);
//	printf("\nARGS---->2 %s",Args);
	if(!nlsIsStrNull(Args))
	{
	    if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}

	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &finalizedEpas, &mfail)) goto EXIT;
	printf("\nNo. of EPAs Finalized before %s are:%d",toDate,finalizedEpas); fflush(stdout);

	return (pendingEpas - finalizedEpas);


	CLEANUP :
	EXIT :
		printf("In the EXIT of endDatePendingEpasTcra"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);
		return 0;
}

int flzdEpasBetDtTcra(string fromDate, string toDate, string plant, string Args)
{
	char *mod_name = "flzdEpasBetDtTcra";
	integer mfail = USC_OKAY;
	status	dstat = OKAY;

	SqlPtr EpaCntQry	= NULL;
	integer EpaFlzdBetDt;

	printf("\n Inside flzdEpasBetDtTcra Fun() FromDate:%s, toDate:%s, Plant:%s",fromDate,toDate,plant); fflush(stdout);
	printf("Args :: %s",Args);
	//// 3rd Step: take out no. of EPAs finalized between fromDate and toDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereGT(EpaCntQry, ClosureTimeStampAttr, fromDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, ClosureTimeStampAttr, toDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;

//	printf("\nARGS----->flzdEpasBetDtTcra %s",Args);
	if(!nlsIsStrNull(Args))
	{
		if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}


	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &EpaFlzdBetDt, &mfail)) goto EXIT;
	//printf("\nNo. of EPAs finalized betn dates:%d",EpaFlzdBetDt); fflush(stdout);
	return EpaFlzdBetDt;


	CLEANUP :
	EXIT :
		printf("In the EXIT of flzdEpasBetDtTcra"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);
		return 0;
}

int createdEpasBetDtTcra(string fromDate, string toDate, string plant, string Args)
{
	char *mod_name = "createdEpasBetDtTcra";
	integer mfail = USC_OKAY;
	status	dstat = OKAY;

	SqlPtr EpaCntQry	= NULL;
	integer EpaCreaBetDt;

	printf("\n Inside createdEpasBetDtTcra Fun() FromDate:%s, toDate:%s, Plant:%s",fromDate,toDate,plant); fflush(stdout);
	printf("Args :: %s",Args);
	//// 4th Step: take out no. of EPAs Created between fromDate and toDate
	if(dstat = oiSqlCreateSelect(&EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereGT(EpaCntQry, CreationDateAttr, fromDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereLE(EpaCntQry, CreationDateAttr, toDate)) goto EXIT;
	if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
	if(dstat = oiSqlWhereEQ(EpaCntQry, EpaPlantAAttr, plant)) goto EXIT;
	if(!nlsIsStrNull(Args))
	{
		if(nlsStrLen(Args)==1)
		{
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"N")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code1Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code1Attr)) goto EXIT;
			}
		}
		else if(nlsStrLen(Args)>=2)
		{
			printf("\nArgs %s",Args); fflush(stdout);
			if(dstat = oiSqlWhereAND(EpaCntQry)) goto EXIT;
			if(nlsStrCmp(Args,"NO")!=0)
			{
				if(dstat = oiSqlWhereEQ(EpaCntQry, t5Category_code4Attr, Args)) goto EXIT;
			}
			else
			{
				if(dstat = oiSqlWhereIsNull(EpaCntQry, t5Category_code4Attr)) goto EXIT;
			}
		}
		else
		{
			printf("\nPlease select any one option"); fflush(stdout);
		}
	}


	if(dstat = QueryDbCount(t5StdDmlClass, EpaCntQry, SC_SCOPE_OF_SESSION, &EpaCreaBetDt, &mfail)) goto EXIT;
	//printf("\nNo. of EPAs created betn dates:%d",EpaCreaBetDt); fflush(stdout);
	return EpaCreaBetDt;



	CLEANUP :
	EXIT :
		printf("In the EXIT of createdEpasBetDtTcra"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);
		return 0;
}
//********************Modified By Sumit**********************************************//

void ReasonOfEPATcra(string fromDate, string toDate, string plant,SetOfStrings* datastr)
{

	char *mod_name = "ReasonOfEPA";
	char *EpaReasons[] = {"A","B","C","P","Q","R","S","U","N"}; //here N means No EPA Reason was selected while creating EPA
	status	dstat = OKAY;
	int i,ReasonArrLen=9;

	string Args    = NULL;
	string ArgsDup = NULL;

	integer pendEpaStartDate  = 0;
	integer pendEpaEndDate	  = 0;
	integer EpaFlzdBtDate     = 0;
	integer EpaCreaBtDate     = 0;

	string pendEpaStartDateStr = NULL;
	string pendEpaEndDateStr   = NULL;
	string EpaFlzdBtDateStr    = NULL;
	string EpaCreaBtDateStr    = NULL;
	string EPACategory	       = NULL;

	pendEpaStartDateStr	= nlsStrAlloc(5);
	pendEpaEndDateStr	= nlsStrAlloc(5);
	EpaFlzdBtDateStr	= nlsStrAlloc(5);
	EpaCreaBtDateStr	= nlsStrAlloc(5);
	EPACategory	        = nlsStrAlloc(45);
	Args                = nlsStrAlloc(5);
	ArgsDup             = nlsStrAlloc(5);

	//datastr                = setCreate(50);

	for(i=0; i<ReasonArrLen;i++)
	{
		printf("\n======== Inside Reason Of EPA=======  %s<-->%d",EpaReasons[i],i);
		nlsStrCpy(Args,EpaReasons[i]);

		pendEpaStartDate = pendEpaEndDate = EpaFlzdBtDate = EpaCreaBtDate = 0;
		pendEpaStartDateStr	= NULL; pendEpaEndDateStr	= NULL; EpaFlzdBtDateStr = NULL; EpaCreaBtDateStr = NULL;
		pendEpaStartDateStr	= nlsStrAlloc(5); pendEpaEndDateStr	= nlsStrAlloc(5); EpaFlzdBtDateStr = nlsStrAlloc(5); EpaCreaBtDateStr = nlsStrAlloc(5);
		EPACategory	= NULL; EPACategory	= nlsStrAlloc(45);
		//printf("**********Inside For Loop******);

		if(nlsStrCmp(Args,"A")==0)
		{
						nlsStrCpy(EPACategory, "AESTHETICS IMPROVEMENT");
						printf("\n\n\nFor EPA Reason: AESTHETICS IMPROVEMENT"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"B")==0)
		{
						nlsStrCpy(EPACategory, "MODIFICATIONS FOR SAFETY");
						printf("\n\n\nFor EPA Reason: MODIFICATIONS FOR SAFETY"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"C")==0)
		{
						nlsStrCpy(EPACategory, "COST REDUCTION");
						printf("\n\n\nFor EPA Reason: COST REDUCTION"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"P")==0)
		{
						nlsStrCpy(EPACategory, "PROCESS IMPROVEMENT");
						printf("\n\n\nFor EPA Reason: PROCESS IMPROVEMENT"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"Q")==0)
		{
						nlsStrCpy(EPACategory, "QUALITY , RELIABILITY ETC.");
						printf("\n\n\nFor EPA Reason: s"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"R")==0)
		{
						nlsStrCpy(EPACategory, "REGULATORY,STATUTORY,HOMOLOGATION");
						printf("\n\n\nFor EPA Reason: REGULATORY,STATUTORY,HOMOLOGATION"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"S")==0)
		{
						nlsStrCpy(EPACategory, "SERVICE FEEDBACK,CUST REQ/COMPLAINTS");
						printf("\n\n\nFor EPA Reason: SERVICE FEEDBACK,CUST REQ/COMPLAINTS"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"U")==0)
		{
						nlsStrCpy(EPACategory, "COST REDUCTION:MORE THAN Rs.50/- PER VEH");
						printf("\n\n\nFor EPA Reason: COST REDUCTION:MORE THAN Rs.50/- PER VEH"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"N")==0)
		{
						nlsStrCpy(EPACategory, "No EPA Category Selected");
						printf("\n\n\nFor EPA Reason: No EPA Category Selected"); fflush(stdout);
		}



		ArgsDup = nlsStrDup(Args);

		pendEpaStartDate = startDatePendingEpasTcra(fromDate, plant, ArgsDup);
		printf("\nNo. of pending EPAs on or before start date:%d",pendEpaStartDate); fflush(stdout);
		sprintf(pendEpaStartDateStr,"%d",pendEpaStartDate);
		printf("\n---------pendEpaStartDateStr = %s",pendEpaStartDateStr);fflush(stdout);

		pendEpaEndDate = endDatePendingEpasTcra(toDate, plant, ArgsDup);
		printf("\nNo. of pending EPAs on or before end date:%d",pendEpaEndDate); fflush(stdout);
		sprintf(pendEpaEndDateStr,"%d",pendEpaEndDate);
		printf("\n---------pendEpaEndDateStr = %s",pendEpaEndDateStr);fflush(stdout);

		EpaFlzdBtDate = flzdEpasBetDtTcra(fromDate,toDate, plant,ArgsDup);
		printf("\nNo. of Finalized EPAs between dates are:%d",EpaFlzdBtDate); fflush(stdout);
		sprintf(EpaFlzdBtDateStr,"%d",EpaFlzdBtDate);
		printf("\n---------EpaFlzdBtDateStr = %s",EpaFlzdBtDateStr);fflush(stdout);

		EpaCreaBtDate = createdEpasBetDtTcra(fromDate,toDate, plant,ArgsDup);
		printf("\nNo. of Created EPAs between dates are:%d",EpaCreaBtDate); fflush(stdout);
		sprintf(EpaCreaBtDateStr,"%d",EpaCreaBtDate);
		printf("\n---------EpaCreaBtDateStr = %s",EpaCreaBtDateStr);fflush(stdout);

		if(dstat = ulyValueLines(EPACategory,TRUE,1,45,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaStartDateStr,FALSE,51,56,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaFlzdBtDateStr,FALSE,68,73,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaCreaBtDateStr,FALSE,83,88,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaEndDateStr,FALSE,98,103,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines("-----------------------------------------------------------------------------------------------------------",TRUE,1,108,108, datastr)) goto EXIT;

		nlsStrCpy(Args,"");

	}


	CLEANUP :
	EXIT :
		printf("In the EXIT of ReasonOfEPA"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);

}

//End code of EPA Reason...........................

//Code Starts for Factory Wise Report................//

//**************Sumit Added**************************//

void FactoryWiseTcra(string fromDate,string toDate,string plant,SetOfStrings* datastr)
{


	char *mod_name = "FactoryWiseTcra";
	status	dstat = OKAY;
	int i,FactoryArrLen=27;


	string Args    = NULL;
	string ArgsDup = NULL;

    char *FactoryList[] = {"AX" ,"BW" ,"CB" ,"E1" ,"E2" ,"EN" ,"FL" ,"GB" ,"GR" ,"HB" ,"ID" ,"PT" ,"PV" ,"SA" ,"SU" ,"T1" ,"T2" ,"TM" ,"TX" ,"XN" ,"XO" ,"HM" ,"IV" ,"SM" ,"ICVT","ICVB","NO"};


	integer pendEpaStartDate  = 0;
	integer pendEpaEndDate	  = 0;
	integer EpaFlzdBtDate     = 0;
	integer EpaCreaBtDate     = 0;

	string pendEpaStartDateStr = NULL;
	string pendEpaEndDateStr   = NULL;
	string EpaFlzdBtDateStr    = NULL;
	string EpaCreaBtDateStr    = NULL;


	string FactoryType	    = NULL;
	pendEpaStartDateStr	    = nlsStrAlloc(5);
	pendEpaEndDateStr	    = nlsStrAlloc(5);
	EpaFlzdBtDateStr	    = nlsStrAlloc(5);
	EpaCreaBtDateStr	    = nlsStrAlloc(5);
	FactoryType	            = nlsStrAlloc(45);
	Args	                = nlsStrAlloc(5);
	ArgsDup                 = nlsStrAlloc(5);


	printf("\n Inside Factory Func()\n"); fflush(stdout);


	for(i=0; i<FactoryArrLen;i++)
	{
		printf("\n========inside factory========= %s<-->%d",FactoryList[i],i); fflush(stdout);
//		printf("\n Size of Args :->%d",setSize(Args));
		printf("\n Args contains %s",Args); fflush(stdout);

		nlsStrCpy(Args,FactoryList[i]);
		printf("\n Arguments after copying %s",Args);

		if(nlsStrCmp(Args,"AX")==0)
		{
						printf("\n inside If Condtion.....Factory Code....\n");fflush(stdout);
						nlsStrCpy(FactoryType, "Axles");
						printf("\n\n\n For Args: Axles"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"BW")==0)
		{
						nlsStrCpy(FactoryType, "BIW");
						printf("\n\n\nFor Args: BIW"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"CB")==0)
		{
						nlsStrCpy(FactoryType, "CUB");
						printf("\n\n\nFor Args: CUB"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"E1")==0)
		{
						nlsStrCpy(FactoryType, "E-Fabrication/Frame");
						printf("\n\n\nFor Args: E-Fabrication/Frame"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"E2")==0)
		{
						nlsStrCpy(FactoryType, "E/D-Fitment Line");
						printf("\n\n\nFor Args:E/D-Fitment Line"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"EN")==0)
		{
						nlsStrCpy(FactoryType, "Engines");
						printf("\n\n\nFor Args: Engines"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"FL")==0)
		{
						nlsStrCpy(FactoryType, "FIAL");
						printf("\n\n\nFor Args: FIAL"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"GB")==0)
		{
						nlsStrCpy(FactoryType, "Gear Box");
						printf("\n\n\nFor Args: Gear Box"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"GR")==0)
		{
						nlsStrCpy(FactoryType, "GRANDE");
						printf("\n\n\nFor Args: GRANDE"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"HB")==0)
		{
						nlsStrCpy(FactoryType, "H-Block");
						printf("\n\n\nFor Args: H-Block"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"ID")==0)
		{
						nlsStrCpy(FactoryType, "Indirect");
						printf("\n\n\nFor Args: Indirect"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"PT")==0)
		{
						nlsStrCpy(FactoryType, "Paint");
						printf("\n\n\nFor Args: Paint"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"PV")==0)
		{
						nlsStrCpy(FactoryType, "PANEL VAN / WINGER");
						printf("\n\n\nFor Args: PANEL VAN / WINGER"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"SA")==0)
		{
						nlsStrCpy(FactoryType, "SAFARI");
						printf("\n\n\nFor Args:SAFARI"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"SU")==0)
		{
						nlsStrCpy(FactoryType, "SUMO");
						printf("\n\n\nFor Args:SUMO"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"T1")==0)
		{
						nlsStrCpy(FactoryType, "TCF 1");
						printf("\n\n\nFor Args:TCF 1"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"T2")==0)
		{
						nlsStrCpy(FactoryType, "TCF 2");
						printf("\n\n\nFor Args:TCF 2"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"TM")==0)
		{
						nlsStrCpy(FactoryType, "TATAMOBILE");
						printf("\n\n\nFor Args:TATAMOBILE"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"TX")==0)
		{
						nlsStrCpy(FactoryType, "Transaxle");
						printf("\n\n\nFor Args:Transaxle"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"XN")==0)
		{
						nlsStrCpy(FactoryType, "XENON");
						printf("\n\n\nFor Args:XENON"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"XO")==0)
		{
						nlsStrCpy(FactoryType, "XOVER");
						printf("\n\n\nFor Args:XOVER"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"HM")==0)
		{
						nlsStrCpy(FactoryType, "HCVMCV");
						printf("\n\n\nFor Args:HCVMCV"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"IV")==0)
		{
						nlsStrCpy(FactoryType, "ICV");
						printf("\n\n\nFor Args:ICV"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"SM")==0)
		{
						nlsStrCpy(FactoryType, "STORME");
						printf("\n\n\nFor Args:STORME"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"ICVT")==0)
		{
						nlsStrCpy(FactoryType, "ICVTRUCK");
						printf("\n\n\nFor Args:ICVT"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"ICVB")==0)
		{
						nlsStrCpy(FactoryType, "ICVBUS");
						printf("\n\n\nFor Args:ICVB"); fflush(stdout);
		}
		if(nlsStrCmp(Args,"NO")==0)
		{
						nlsStrCpy(FactoryType, "No Factory Type Selected");
						printf("\n\n\nArgs: No EPA Category Selected"); fflush(stdout);
		}

		ArgsDup =nlsStrDup(Args);
		printf("\n ArgsDup------------Args %s %s",ArgsDup,Args);
		pendEpaStartDate = startDatePendingEpasTcra(fromDate, plant, ArgsDup);
		printf("\nNo. of pending EPAs on or before start date:%d",pendEpaStartDate); fflush(stdout);
		sprintf(pendEpaStartDateStr,"%d",pendEpaStartDate);
		printf("\n---------pendEpaStartDateStr = %s",pendEpaStartDateStr);fflush(stdout);


		pendEpaEndDate = endDatePendingEpasTcra(toDate, plant, ArgsDup);
		printf("\nNo. of pending EPAs on or before end date:%d",pendEpaEndDate); fflush(stdout);
		sprintf(pendEpaEndDateStr,"%d",pendEpaEndDate);
		printf("\n---------pendEpaEndDateStr = %s",pendEpaEndDateStr);fflush(stdout);


		EpaFlzdBtDate = flzdEpasBetDtTcra(fromDate,toDate, plant,ArgsDup);
		printf("\nNo. of Finalized EPAs between dates are:%d",EpaFlzdBtDate); fflush(stdout);
		sprintf(EpaFlzdBtDateStr,"%d",EpaFlzdBtDate);
		printf("\n---------EpaFlzdBtDateStr = %s",EpaFlzdBtDateStr);fflush(stdout);

		EpaCreaBtDate = createdEpasBetDtTcra(fromDate,toDate, plant,ArgsDup);
		printf("\nNo. of Created EPAs between dates are:%d",EpaCreaBtDate); fflush(stdout);
		sprintf(EpaCreaBtDateStr,"%d",EpaCreaBtDate);
		printf("\n---------EpaCreaBtDateStr = %s",EpaCreaBtDateStr);fflush(stdout);

		if(dstat = ulyValueLines(FactoryType,TRUE,1,45,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaStartDateStr,FALSE,51,56,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaFlzdBtDateStr,FALSE,68,73,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaCreaBtDateStr,FALSE,83,88,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaEndDateStr,FALSE,98,103,108, datastr)) goto EXIT;
		if(dstat = ulyValueLines("-----------------------------------------------------------------------------------------------------------",TRUE,1,108,108, datastr)) goto EXIT;

		nlsStrCpy(Args,"");

	}

	CLEANUP :
	EXIT :
		printf("In the EXIT of Factory_Wise"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);

}
;


int main(int argc, char *argv[])
{
	FILE		*fp	;

    MODNAME ("EPASummaryRptTcra");
    int  i  =0;
	status dstat =OKAY;
	string fromDate     = NULL;
	string toDate	    = NULL;
	string fromDateCpy  = NULL;
	string toDateCpy	= NULL;
	string plant	    = NULL;
	string flPthDup		= NULL;
	string filename		= NULL;
	string WrklcDup		= NULL;
	string HstName		= NULL;
	string HstNameDup	= NULL;
	string usr		    = NULL;
	string usrDup		= NULL;
	string Agency		= NULL;
	string FirstDt		= NULL;
	string Finalzed		= NULL;
	string Created		= NULL;
	string LastDt		= NULL;
    string         FrameName = NULL;
    string         EnvName = NULL;
    string         EmailID = NULL;
    string         sesUsrNameDup = NULL;
    string         sesUsrName = NULL;

	int					mfail				    = OKAY;

    string t5ReportCategory11		= NULL;
	string t5ReportCategory11Dup	= NULL;

	integer pendEpaStartDate=0;
	integer pendEpaEndDate=0;
	integer EpaFlzdBtDate=0;
	integer EpaCreaBtDate=0;

	string pendEpaStartDateStr	=NULL;
	string pendEpaEndDateStr	=NULL;
	string EpaFlzdBtDateStr		=NULL;
	string EpaCreaBtDateStr		=NULL;
	SetOfStrings datastr = NULL;
	ObjectPtr TaskCreateDia = NULL ;
	SetOfStrings		 ExtStrs  = NULL;
	SetOfObjects     ExtObjs = NULL;
	char buff[90240];
    SqlPtr Sql_ptr1 = NULL ;
	SetOfStrings         soCreator              = NULL;

    datastr                = setCreate(500);

	fromDate	= nlsStrAlloc(11);
	toDate		= nlsStrAlloc(11);
	plant		= nlsStrAlloc(15);
	fromDateCpy	= nlsStrAlloc(15);
	toDateCpy	= nlsStrAlloc(15);
	EnvName	= nlsStrAlloc(100);
	EmailID	= nlsStrAlloc(500);


	pendEpaStartDateStr	= nlsStrAlloc(5);
	pendEpaEndDateStr	= nlsStrAlloc(5);
	EpaFlzdBtDateStr	= nlsStrAlloc(5);
	EpaCreaBtDateStr	= nlsStrAlloc(5);

	t5ReportCategory11Dup = nlsStrAlloc(20);
	t5ReportCategory11	= nlsStrAlloc(10);

	printf("\nReport Generation for EPA Summary starts...."); fflush(stdout);

	printf("\ndumped object"); fflush(stdout);

	/* enable multibyte features of Metaphase */
	if(dstat = clInitMB2(argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	if(dstat = clTestNetwork ());

	/*  Initialize the command line session.    */
	if(dstat = clInitialize2 (FALSE));

//	if(dstat = clLogin2 ("Loader", "123loader", &dstat));
	if(dstat = clLogin2 ("Loader", "123loader", &dstat));

	if (dstat != OKAY)
	{
		printf("\n Invalid User Name or StrUsrPasswd : Loader, **** \n");
		goto EXIT;
	}

	plant	= nlsStrAlloc(nlsStrLen(argv[1])+1);
	filename	= nlsStrAlloc(nlsStrLen(argv[2])+1);
	WrklcDup	= nlsStrAlloc(nlsStrLen(argv[50])+1);
	t5ReportCategory11Dup	= nlsStrAlloc(nlsStrLen(argv[10])+1);
	fromDate	= nlsStrAlloc(nlsStrLen(argv[11])+1);
	toDate	= nlsStrAlloc(nlsStrLen(argv[11])+1);

	plant	= argv[1];
	filename	= argv[2];
	WrklcDup	= argv[3];
	t5ReportCategory11Dup	= argv[4];
	fromDate	= argv[5];
	toDate	= argv[6];


	if(filename)
	{
	 nlsStrCpy(EnvName,filename);
	 nlsStrCat(EnvName,".txt");
	}
    fp=fopen(EnvName,"ab+");
	if(fp==NULL)
	{
	 printf("\n%s:file is not created...!!!!\n",EnvName);fflush(stdout);
	}
	fflush(fp);
	fprintf(fp,"\n");

	nlsStrCpy(fromDateCpy,t5ChngDateFormat(fromDate,"yyyy/mm/dd","dd/mm/yyyy"));
	nlsStrCpy(toDateCpy,t5ChngDateFormat(toDate,"yyyy/mm/dd","dd/mm/yyyy"));

	if(dstat = ulyValueLines("EPA Summary Report",TRUE,49,67,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines("===========================================================================================================",TRUE,1,108,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines("Total Pending EPA",TRUE,1,18,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines(fromDateCpy,FALSE,49,60,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines("Finalized",FALSE,65,74,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines("Created",FALSE,81,88,108, &datastr)) goto EXIT;
	if(dstat = ulyValueLines(toDateCpy,FALSE,97,107,108, &datastr)) goto EXIT;

		pendEpaStartDate = startDatePendingEpasTcra(fromDate, plant, NULL);
		printf("\nNo. of pending EPAs on or before start date:%d",pendEpaStartDate); fflush(stdout);
		sprintf(pendEpaStartDateStr,"%d",pendEpaStartDate);
		printf("\npendEpaStartDateStr :%s",pendEpaStartDateStr); fflush(stdout);

		printf("\n\npendEpaStartDate %d",pendEpaStartDate);

		pendEpaEndDate = endDatePendingEpasTcra(toDate, plant, NULL);
		printf("\nNo. of pending EPAs on or before end date:%d",pendEpaEndDate); fflush(stdout);
		sprintf(pendEpaEndDateStr,"%d",pendEpaEndDate);
		printf("\npendEpaEndDateStr :%s",pendEpaEndDateStr); fflush(stdout);

		printf("\n\npendEpaStartDate %d",pendEpaEndDate);

		EpaFlzdBtDate = flzdEpasBetDtTcra(fromDate,toDate, plant,NULL);
		printf("\nNo. of Finalized EPAs between dates are:%d",EpaFlzdBtDate); fflush(stdout);
		sprintf(EpaFlzdBtDateStr,"%d",EpaFlzdBtDate);
		printf("\n\npendEpaStartDate %d",EpaFlzdBtDate);


		EpaCreaBtDate = createdEpasBetDtTcra(fromDate,toDate, plant,NULL);
		printf("\nNo. of Created EPAs between dates are:%d",EpaCreaBtDate); fflush(stdout);
		sprintf(EpaCreaBtDateStr,"%d",EpaCreaBtDate);
		printf("\n\npendEpaStartDate %d",EpaCreaBtDate);fflush(stdout);


		printf("\n\n----Sumit check---- %s %s %s %s %s",pendEpaEndDateStr,pendEpaStartDateStr,EpaFlzdBtDateStr,EpaCreaBtDateStr,pendEpaEndDateStr);fflush(stdout);


		if(dstat = ulyValueLines(pendEpaEndDateStr,TRUE,7,11,108, &datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaStartDateStr,FALSE,51,56,108, &datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaFlzdBtDateStr,FALSE,68,73,108, &datastr)) goto EXIT;
		if(dstat = ulyValueLines(EpaCreaBtDateStr,FALSE,83,88,108, &datastr)) goto EXIT;
		if(dstat = ulyValueLines(pendEpaEndDateStr,FALSE,98,103,108, &datastr)) goto EXIT;
		if(dstat = ulyValueLines("===========================================================================================================",TRUE,1,108,108, &datastr)) goto EXIT;


/*------------  Sumit Added--------------*/
//    printf("\nCheckFrReasonOrFactory1..........%s",CheckFrReasonOrFactory1); fflush(stdout);

	printf("\n Size of Data Str :%d",setSize(datastr)); fflush(stdout);

	if (nlsStrCmp(t5ReportCategory11Dup,"ERW")==0)
	{
		printf("\ncalling EPA ReasonWise function");
		ReasonOfEPATcra(fromDate,toDate,plant,&datastr);
	}
	else if(nlsStrCmp(t5ReportCategory11Dup,"FW")==0)
	{
		printf("\ncalling FactoryWiseTcra function");
		FactoryWiseTcra(fromDate,toDate,plant,&datastr);
	}
	else
	{
		printf("\n**********Invalid Arguments**************");
	}

	printf("\n Size of Data Str retruned from function :%d",setSize(datastr));
	for(i=0;i<setSize(datastr);i++)
	{
		printf("\n%s",low_set_get_str(datastr,i));

		fprintf(fp,low_set_get_str(datastr,i));
		fprintf(fp,"\n");

		if (!nlsStrStr(low_set_get_str(datastr,i),"-----------")  && (i !=0 &&  i !=1 &&  i !=2 &&  i !=3  &&  i !=4  ))
		{
     		Agency=strtok(low_set_get_str(datastr,i),"               ");
     		FirstDt=strtok(NULL,"               ");
     		Finalzed=strtok(NULL,"               ");
     		Created=strtok(NULL,"               ");
     		LastDt=strtok(NULL,"               ");
	       printf("\n Agency:%s , FirstDt :%s: , Finalzed :%s: , Created :%s: , LastDt :%s:",Agency,FirstDt,Finalzed,Created,LastDt);
			if(dstat = SetUpDialog("EpaConSd",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
			if (dstat = ConstructItem("EpaConSd",&mfail,&TaskCreateDia)) goto EXIT;

			if(Agency			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"Class","EpaConSd")) goto EXIT;
			if(Agency			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PENDING_EPA_GRP",Agency)) goto EXIT;
			if(FirstDt			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PENDING_START_DT",FirstDt)) goto EXIT;
			if(Finalzed			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"FINALISED_EPA",Finalzed)) goto EXIT;
			if(Created			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"CREATED_EPA",Created)) goto EXIT;
		   if(LastDt			!=NULL) 	if(dstat=objSetAttribute(TaskCreateDia,"PENDING_END_DT",LastDt)) goto EXIT;

			if(dstat = BeginDbFrame("EpaConSd",&FrameName,&mfail))
			  goto EXIT;
			if(mfail)
			  goto CLEANUP;
			if(dstat = InsertDbItem(TaskCreateDia,&mfail))
			  goto EXIT;
			if(mfail)
			  goto CLEANUP;
			if(dstat = EndDbFrame("EpaConSd",FrameName,&mfail))
			  goto EXIT;
			if(mfail)
			  goto CLEANUP;
		}
  }
		if(fp) fclose(fp); fp=NULL;

		smGetSessionUsrName(&sesUsrNameDup);
		if(sesUsrNameDup)  sesUsrName=nlsStrDup(sesUsrNameDup);

		sprintf(buff,"echo | nail -a %s -s \"EPA Summary Report for Graph \"  ",EnvName);//For Linux

		if(dstat = oiSqlCreateSelect(&Sql_ptr1)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(Sql_ptr1,"Participant",sesUsrName)) goto CLEANUP;
		if(dstat = QueryDbObject(UsrClass,Sql_ptr1,0,TRUE,SC_SCOPE_OF_SESSION,&soCreator,&mfail))goto CLEANUP;

		   printf("\n\n set size of user ===== %d\n",setSize(soCreator));fflush(stdout);
		   if(Sql_ptr1) oiSqlDispose(Sql_ptr1); Sql_ptr1 = NULL;

		   if (setSize(soCreator)>0)
		   {
				if(dstat = objGetAttribute((ObjectPtr)setGet(soCreator,0),EmailAddrAttr,&EmailID)) goto CLEANUP;
				printf("\n\n Creator EmailID =====%s\n",EmailID);
				if (nlsStrLen(EmailID)>0)
				{
					nlsStrCat(buff,EmailID);
					nlsStrCat(buff," ");
				}
		   }

		nlsStrCat(buff," Dayanand.Amdapure@tatatechnologies.com ");
		nlsStrCat(buff," ");
    	nlsStrCat(buff," Awadhut.Natekar@tatatechnologies.com ");
		nlsStrCat(buff," ");
    	nlsStrCat(buff," sunil.chaudhari@tatamotors.com ");
		nlsStrCat(buff," ");
		nlsStrCat(buff," ");
    	system(buff);

		printf("\n---------EpaCreaBtDateStr ");fflush(stdout);

		dstat = clReleaseServers ();
		CLEANUP:

		   clLogout ();
		   clTerminate ();

		EXIT:
		   if (dstat != OKAY)
		      uiShowFatalError (dstat, WHERE);
		return (dstat);
}
;

