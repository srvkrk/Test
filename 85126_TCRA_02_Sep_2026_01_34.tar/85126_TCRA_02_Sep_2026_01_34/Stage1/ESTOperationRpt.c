/**********************************************************************************
*  File            :   UpdPlmEpa.c
*  Project         :   Denis to PLM
*  Purpose         :   Updating different fields of PLM EPAs
*  Arguments	   :   EPA_No
***********************************************************************************/

/*
EPAtrans epano t ----- transfer(epano)
EPAtrans epano r ----- rollback(epano); transfer(epano)

*/


#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>

#include <string.h>
#include <msgtel.h>
#include <status.h>


#include <msgomf.h>
#include <nls.h>
#include <pdmc.h>

#include <Mtimsgh.h>
#include <msgomfU.h>



#define Get_Data_SIZE 100
#define _CLMAIN_DEFNS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <msgapc.h>
#include <msgomf.h>
#include <nls.h>
#include <pdmc.h>
#include <msgtel.h>
#include <Mtimsgh.h>
#include <msgomfU.h>
#include <tel.h>



struct EpaFields
{
	char EpaSubject[260];
	char FactoryCode[5];
	char EpaReason[5];
	char EpaAgency[5];
};

struct 	EpaFields *EpaFieldVals;

//functions
char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

status t0UpdateObject(ObjectPtr *itemObj,int *mfail)
{
	char   *mod_name = "t0UpdateObject";
    status dstat = OKAY;
    string SclsName = NULL;
	string SframeName = NULL;
	string SclsNameDup = NULL;

	//printf("\n .... inside t0UpdateObject ...  updating object ... \n"); fflush(stdout);
	if ( dstat = objGetAttribute(*itemObj,ClassAttr,&SclsName)) goto CLEANUP;
	//printf("\n ....  SclsName ...  updating object ... %s \n", SclsName);

	SclsNameDup = nlsStrDup(SclsName);
	//printf("\n ....  SclsNameDup ...  updating object ... %s \n", SclsNameDup);

	if(dstat = BeginDbFrame(SclsNameDup,&SframeName,mfail))	goto CLEANUP;
    if(*mfail) goto CLEANUP;
	//printf("\n .... after BeginDbFrame ...  updating object ... \n"); fflush(stdout);

    if (dstat = UpdateDbObject(*itemObj,mfail)) goto CLEANUP;
	//printf("\n .... after UpdateDbObject ...  updating object ... \n"); fflush(stdout);

    if (*mfail != 0)
    {
		if (dstat = ClearDbFrame(SclsNameDup,SframeName,mfail))
		goto CLEANUP;
        goto CLEANUP;
    }

    if (dstat = EndDbFrame(SclsNameDup,SframeName,mfail)) goto CLEANUP;
    if (*mfail) goto CLEANUP;
	//printf("\n .... after EndDbFrame ...  updating object ... \n");  fflush(stdout);

	CLEANUP:
		//printf("\n.... in cleanup t0UpdateObject ...."); fflush(stdout);
	EXIT:
		if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
		return (dstat);
}


status t5GetEsExplosion
	(
		ObjectPtr		partObj,
		integer			reqLevel,
		ObjectPtr       contextObj,
		SetOfObjects	*childObjs,
		SetOfObjects	*childRelObjs,
		//SetOfStrings	*levels,
		integer*		level,
		integer*		mfail
	)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5GetEsExplosion";
	SetOfObjects    itemObjs    = NULL;
	SetOfObjects    relObjs     = NULL;
	SetOfObjects    itemObjSet  = NULL;
   	ObjectPtr		relObj		= NULL;
   	ObjectPtr		itemObj		= NULL;
   	integer			cnt			= 0;
	NVSET		    textInserts	= NULL;
   	*mfail 		= USC_OKAY;

	if( *level >= reqLevel )
		   return (dstat);
	if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;

	itemObjSet = NULL;
    itemObjSet = setCreate(1);

	if(dstat = ulyCopyObjectToSet(partObj, &itemObjSet)) goto CLEANUP;
	if (*mfail) goto CLEANUP;

	printf("\n Calling t5GetEsExplosion...................\n");fflush(stdout);
	if (dstat = ExpandObject("AsRevRev",partObj,"PartsInAssembly",&itemObjs,&relObjs,mfail)) goto EXIT;

	printf("\n Uses Part Are Found--->[%d]\n",setSize(itemObjs));fflush(stdout);
	printf("\n Uses Part Rel Are Found--->[%d]\n",setSize(relObjs));fflush(stdout);

	if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg2", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;
    if (*mfail)	goto CLEANUP;

	*level = *level + 1;
	for( cnt=0; cnt<setSize(itemObjs); cnt++)
	{
		itemObj = setGet(itemObjs, cnt);
		relObj  = setGet(relObjs, cnt);

		if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
		if(dstat = ulyCopyObjectToSet(relObj,  childRelObjs)) goto CLEANUP;

		printf("\n recursive calling t5GetEsExplosion function..............\n");fflush(stdout);
		if( dstat = t5GetEsExplosion(itemObj, reqLevel, contextObj, childObjs, childRelObjs, /*levels,*/ level, mfail)) goto CLEANUP;
		if(*mfail) goto CLEANUP;
		if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE)) goto CLEANUP;
	}
	*level = *level - 1;

CLEANUP:
	if(itemObjs)  objDisposeAll(itemObjs); itemObjs = NULL;
	if(relObjs)	  objDisposeAll(relObjs); relObjs = NULL;

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}


status t5MulLvlExplEsForPart(ObjectPtr partObj, integer reqLevel, ObjectPtr contextObj, SetOfObjects* childObjs, SetOfObjects* childRelObjs, /*SetOfStrings* levels,*/ integer* mfail)
{
	char	  *mod_name   = "t5MulLvlExplEsForPart";
	integer	  level		  = 0;
   	NVSET	  textInserts = NULL;
	status	  dstat		  = OKAY;
	*mfail 	              = USC_OKAY;

	printf("\n t5MulLvlExplEsForPart is calling..........\n");fflush(stdout);
	if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;
	if( dstat = t5GetEsExplosion(partObj, reqLevel, contextObj, childObjs, childRelObjs, /*levels,*/ &level, mfail))goto CLEANUP;
	if(*mfail) goto CLEANUP;

CLEANUP:

EXIT:
	printf("\n t5MulLvlExplEsForPart is calling..........\n");fflush(stdout);
}


int main(int argc,char * argv[])
{
	MODNAME ("main:UpdPlmEpa");
	status		dstat		 = OKAY ;
	int stat = 0;

	int cnt_tt = 0;
	int cnt_tp = 0;

    int cnt_pt = 0;
	int cnt_pp = 0;

    int cnt_bt = 0;
	int cnt_bp = 0;

    int cnt_pmt = 0;
	int cnt_pmp = 0;

    int cnt_nt = 0;
	int cnt_np = 0;

    int cnt_prt = 0;
	int cnt_prp = 0;

    int cnt_pat = 0;
	int cnt_pap = 0;

    int cnt_ft = 0;
	int cnt_fp = 0;

    int cnt_nat = 0;
	int cnt_nap = 0;


	string  cnt_ttStr = NULL;
	string cnt_tpStr = NULL;

	string cnt_ptStr = NULL;
	string cnt_ppStr = NULL;

    string cnt_btStr = NULL;
	string cnt_bpStr = NULL;

    string cnt_pmtStr = NULL;
	string cnt_pmpStr = NULL;

    string cnt_ntStr = NULL;
	string cnt_npStr = NULL;

    string cnt_prtStr = NULL;
	string cnt_prpStr = NULL;

    string cnt_patStr = NULL;
	string cnt_papStr = NULL;

    string cnt_ftStr = NULL;
	string cnt_fpStr = NULL;

    string cnt_natStr = NULL;
	string cnt_napStr = NULL;


	integer mfail = 0;

    int		lineLen,j= 0;
	int		endCol			= 0;
 	string	 t5PEPartNumber	= NULL;
 	string	 FileName	= NULL;
 	string	 t5PEShopName	= NULL;
 	string	 t5PEShopNameDup	= NULL;
 	string	 t5PEProsheet	= NULL;
	string plant	    = NULL;
	string filename		= NULL;
	string WrklcDup		= NULL;
	string fromDate     = NULL;
	string toDate	    = NULL;
	string EnvName	    = NULL;
	string sesUsrNameDup	    = NULL;
	string sesUsrName	    = NULL;
	string EmailID	    = NULL;


	SetOfStrings		 ExtStrs  = NULL;
	SetOfObjects     ExtObjs = NULL;
	char buff[90240];
    SqlPtr Sql_ptr1 = NULL ;
	SetOfStrings         soCreator              = NULL;
	ObjectPtr TaskCreateDia = NULL ;
    string         FrameName = NULL;

	SetOfObjects	soPartObjs	= NULL;
	SetOfObjects	soEstObjs	= NULL;
	SetOfObjects	soOperaObjs	= NULL;
	ObjectPtr		OpEstOp	    = NULL;
	ObjectPtr		OpObje	    = NULL;
	ObjectPtr		OpPartOp	    = NULL;

	 SetOfStrings	ESTParts = NULL;

	SqlPtr			PSql_ptr		= NULL;
	SqlPtr			ESql_ptr		= NULL;
  	FILE		*fp	;


	//string agencyVal	=	NULL;
	int i = 0 ;

	t5CheckDstat(clInitMB2 (argc, &argv, NULL));
	t5CheckDstat(clTestNetwork ());
	t5CheckDstat(clInitialize2 (FALSE));
	t5CheckDstat(clLogin2 ("Loader","123loader",&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS :  \n");  fflush(stdout);
		goto EXIT;
	}
   ESTParts = setCreate(1);
   setAddStr(ESTParts, " ");

	lineLen = 180;
	endCol = lineLen;
	FileName = "OperationReport.csv";
	fp       = fopen(FileName,"ab+");
	if(fp==NULL)
	{
	 printf("\n%s:file is not created...!!!!\n",FileName);fflush(stdout);
	}
	fflush(fp);
	fprintf(fp,"\n");
	cnt_ttStr	= nlsStrAlloc(5);
	cnt_tpStr	= nlsStrAlloc(5);

	cnt_ptStr	= nlsStrAlloc(5);
	cnt_ppStr	= nlsStrAlloc(5);

	cnt_btStr	= nlsStrAlloc(5);
	cnt_bpStr	= nlsStrAlloc(5);

	cnt_pmtStr	= nlsStrAlloc(5);
	cnt_pmpStr	= nlsStrAlloc(5);

	cnt_ntStr	= nlsStrAlloc(5);
	cnt_npStr	= nlsStrAlloc(5);

	cnt_prtStr	= nlsStrAlloc(5);
	cnt_prpStr	= nlsStrAlloc(5);

	cnt_patStr	= nlsStrAlloc(5);
	cnt_papStr	= nlsStrAlloc(5);

	cnt_ftStr	= nlsStrAlloc(5);
	cnt_fpStr	= nlsStrAlloc(5);

	cnt_natStr	= nlsStrAlloc(5);
	cnt_napStr	= nlsStrAlloc(5);


	EnvName	= nlsStrAlloc(100);
	EmailID	= nlsStrAlloc(500);

	plant	= nlsStrAlloc(nlsStrLen(argv[1])+1);
	filename	= nlsStrAlloc(nlsStrLen(argv[2])+1);
	WrklcDup	= nlsStrAlloc(nlsStrLen(argv[50])+1);
	fromDate	= nlsStrAlloc(nlsStrLen(argv[11])+1);
	toDate	= nlsStrAlloc(nlsStrLen(argv[11])+1);

	plant	= argv[1];
	filename	= argv[2];
	WrklcDup	= argv[3];
	fromDate	= argv[4];
	toDate	= argv[5];

	if(filename)
	{
	 nlsStrCpy(EnvName,filename);
	 nlsStrCat(EnvName,".txt");
	}
    fp=fopen(EnvName,"ab+");
	if(fp==NULL)
	{
	 printf("\n%s:file is not created...!!!!\n",EnvName);fflush(stdout);
	}
	fflush(fp);
	fprintf(fp,"\n");

	if(dstat = oiSqlCreateSelect(&PSql_ptr));
	if(dstat = oiSqlWhereEQ(PSql_ptr,t5PEPlantNameAttr,"CVBU PUNE"));
	if(dstat = oiSqlWhereAND(PSql_ptr)) goto EXIT;
	if(dstat = oiSqlWhereGE(PSql_ptr,CreationDateAttr,fromDate));
	if(dstat = oiSqlWhereAND(PSql_ptr)) goto EXIT;
	if(dstat = oiSqlWhereLE(PSql_ptr,CreationDateAttr,toDate));
	if(dstat = QueryDbObject(t5PeEstClass,PSql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&soPartObjs,&mfail));
	if(mfail) goto CLEANUP;
	if(PSql_ptr) oiSqlDispose(PSql_ptr);PSql_ptr = NULL;

    printf("\n setSize(soPartObjs) :: %d \n",setSize(soPartObjs));fflush(stdout);

  for (j=0;j<setSize(soPartObjs);j++)
  {
			 OpPartOp = setGet(soPartObjs,j);
             if (dstat = objGetAttribute(OpPartOp,t5PEPartNumberAttr,&t5PEPartNumber)) goto EXIT;
     	 	 printf("\n j+++++++++++++++ [%d]",j); fflush(stdout);
     	 	 printf("\n t5PEPartNumber [%s]",t5PEPartNumber); fflush(stdout);

			  if(low_set_find_str (ESTParts,t5PEPartNumber)>=0)
			  {
					continue;
			  }

			 low_set_add_str_unique(ESTParts,t5PEPartNumber);

			if(dstat = oiSqlCreateSelect(&ESql_ptr));
		    if(dstat = oiSqlWhereEQ(ESql_ptr,t5PEPartNumberAttr,t5PEPartNumber)) goto EXIT;
			if(dstat = oiSqlWhereAND(ESql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereEQ(ESql_ptr,t5PEPlantNameAttr,"CVBU PUNE"));
			if(dstat = oiSqlDescOrder(ESql_ptr, CreationDateAttr)) goto EXIT;
			if(dstat = QueryDbObject(t5PeEstClass,ESql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&soEstObjs,&mfail));
			if(mfail) goto CLEANUP;
			if(ESql_ptr) oiSqlDispose(ESql_ptr);ESql_ptr = NULL;
            printf("\n setSize(soEstObjs) :: %d \n",setSize(soEstObjs));fflush(stdout);

			OpEstOp = setGet(soEstObjs,0);

			if (dstat = objGetAttribute(OpEstOp,t5PEShopNameAttr,&t5PEShopName)) goto EXIT;
            if(t5PEShopName) t5PEShopNameDup=nlsStrDup(t5PEShopName);

	    	if ( dstat = ExpandObject5("t5PrEEE", OpEstOp,"EshEl", SC_SCOPE_OF_SESSION, &soOperaObjs, &mfail) )    goto CLEANUP;
    	   printf("\n setSize(soOperaObjs) :: %d \n",setSize(soOperaObjs));fflush(stdout);
	       for (i=0;i<setSize(soOperaObjs);i++)
	       {
		      OpObje = setGet(soOperaObjs,i);
              if (dstat = objGetAttribute(OpObje,t5PEProsheetAttr,&t5PEProsheet)) goto EXIT;
     	      printf("\n t5PEProsheet [%s]",t5PEProsheet); fflush(stdout);
       	 	 printf("\n  t5PEShopNameDup  [%s]",t5PEShopNameDup); fflush(stdout);
			  if (nlsStrCmp(t5PEShopNameDup,"TCF")==0)
			  {
				 cnt_tt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_tp ++;
				 }
			   }
			   else if(nlsStrCmp(t5PEShopNameDup,"Paint")==0)
				 {
				 cnt_pt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_pp ++;
				 }
				 }
		      else if(nlsStrCmp(t5PEShopNameDup,"BIW")==0)
				 {
				 cnt_bt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_bp ++;
				 }
				 }
		      else if(nlsStrCmp(t5PEShopNameDup,"PWT Machining")==0)
				 {
				 cnt_pmt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_pmp ++;
				 }
				 }
		     else if(nlsStrCmp(t5PEShopNameDup,"NA")==0)
				 {
				 cnt_nt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_np ++;
				 }
				 }
		   else if(nlsStrCmp(t5PEShopNameDup,"Press")==0)
				 {
				 cnt_prt ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_prp ++;
				 }
				 }
		   else if(nlsStrCmp(t5PEShopNameDup,"PWT ASM")==0)
				 {
				 cnt_pat ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_pap ++;
				 }
				 }
		   else if(nlsStrCmp(t5PEShopNameDup,"FRAME")==0)
				 {
				 cnt_ft ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_fp ++;
				 }
				 }
		   else if(nlsStrCmp(t5PEShopNameDup,"na")==0)
				 {
				 cnt_nat ++;
				 if (nlsStrCmp(t5PEProsheet,"+")==0)
				 {
				  cnt_nap ++;
				 }
				 }
		   }
	  printf("\n InTCF [%d][%d],",cnt_tt,cnt_tp);fflush(stdout);
	  printf("\n InPaint [%d][%d],",cnt_pt,cnt_pp);fflush(stdout);
	  printf("\n InBIW [%d][%d],",cnt_bt,cnt_bp);fflush(stdout);
	  printf("\n InPWT Machining [%d][%d],",cnt_pmt,cnt_pmp);fflush(stdout);
	  printf("\n InNA [%d][%d],",cnt_nt,cnt_np);fflush(stdout);
	  printf("\n InPress [%d][%d],",cnt_prt,cnt_prp);fflush(stdout);
	  printf("\n InPWT ASM [%d][%d],",cnt_pat,cnt_pap);fflush(stdout);
	  printf("\n InFRAME [%d][%d],",cnt_ft,cnt_fp);fflush(stdout);
	  printf("\n Inna [%d][%d],",cnt_nat,cnt_nap);fflush(stdout);


   }


		  printf("\n TCF [%d][%d],",cnt_tt,cnt_tp);fflush(stdout);
		  printf("\n Paint [%d][%d],",cnt_pt,cnt_pp);fflush(stdout);
		  printf("\n BIW [%d][%d],",cnt_bt,cnt_bp);fflush(stdout);
		  printf("\n PWT Machining [%d][%d],",cnt_pmt,cnt_pmp);fflush(stdout);
		  printf("\n NA [%d][%d],",cnt_nt,cnt_np);fflush(stdout);
		  printf("\n Press [%d][%d],",cnt_prt,cnt_prp);fflush(stdout);
		  printf("\n PWT ASM [%d][%d],",cnt_pat,cnt_pap);fflush(stdout);
		  printf("\n FRAME [%d][%d],",cnt_ft,cnt_fp);fflush(stdout);
		  printf("\n na [%d][%d],",cnt_nat,cnt_nap);fflush(stdout);

		  fprintf(fp,"\n Agency                  [Total Options][EstSheet Optins]");fflush(stdout);
		  fprintf(fp,"\n ===========              =============  ===============");fflush(stdout);
		  fprintf(fp,"\n TCF                     [%d]                     [%d],",cnt_tt,cnt_tp);fflush(stdout);
		  fprintf(fp,"\n Paint                   [%d]                     [%d],",cnt_pt,cnt_pp);fflush(stdout);
		  fprintf(fp,"\n BIW                     [%d]                     [%d],",cnt_bt,cnt_bp);fflush(stdout);
		  fprintf(fp,"\n PWT Machining           [%d]                     [%d],",cnt_pmt,cnt_pmp);fflush(stdout);
		  fprintf(fp,"\n NA                      [%d]                     [%d],",cnt_nt,cnt_np);fflush(stdout);
		  fprintf(fp,"\n Press                   [%d]                      [%d],",cnt_prt,cnt_prp);fflush(stdout);
		  fprintf(fp,"\n PWT ASM                 [%d]                     [%d],",cnt_pat,cnt_pap);fflush(stdout);
		  fprintf(fp,"\n FRAME                   [%d]                     [%d],",cnt_ft,cnt_fp);fflush(stdout);
		  fprintf(fp,"\n na                      [%d]                      [%d],",cnt_nat,cnt_nap);fflush(stdout);

    	sprintf(cnt_ttStr,"%d",cnt_tt);
     	sprintf(cnt_tpStr,"%d",cnt_tp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","TCF")) goto EXIT;
		if(cnt_ttStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_ttStr)) goto EXIT;
		if(cnt_tpStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_tpStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_ptStr,"%d",cnt_pt);
    	sprintf(cnt_ppStr,"%d",cnt_pp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","Paint")) goto EXIT;
		if(cnt_ptStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_ptStr)) goto EXIT;
		if(cnt_ppStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_ppStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_btStr,"%d",cnt_bt);
    	sprintf(cnt_bpStr,"%d",cnt_bp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","BIW")) goto EXIT;
		if(cnt_btStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_btStr)) goto EXIT;
		if(cnt_bpStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_bpStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_pmtStr,"%d",cnt_pmt);
    	sprintf(cnt_pmpStr,"%d",cnt_pmp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","PWT Machining")) goto EXIT;
		if(cnt_pmtStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_pmtStr)) goto EXIT;
		if(cnt_pmpStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_pmpStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_ntStr,"%d",cnt_nt);
    	sprintf(cnt_npStr,"%d",cnt_np);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","NA")) goto EXIT;
		if(cnt_ntStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_ntStr)) goto EXIT;
		if(cnt_npStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_npStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_prtStr,"%d",cnt_prt);
    	sprintf(cnt_prpStr,"%d",cnt_prp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","Press")) goto EXIT;
		if(cnt_prtStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_prtStr)) goto EXIT;
		if(cnt_prpStr		!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_prpStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_patStr,"%d",cnt_pat);
    	sprintf(cnt_papStr,"%d",cnt_pap);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","PWT ASM")) goto EXIT;
		if(cnt_patStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_patStr)) goto EXIT;
		if(cnt_papStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_papStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_ftStr,"%d",cnt_ft);
    	sprintf(cnt_fpStr,"%d",cnt_fp);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","FRAME")) goto EXIT;
		if(cnt_ftStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_ftStr)) goto EXIT;
		if(cnt_fpStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_fpStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

    	sprintf(cnt_natStr,"%d",cnt_nat);
    	sprintf(cnt_napStr,"%d",cnt_nap);
		if(dstat = SetUpDialog("OpnProcC",NULL,"CreateDialogC",&ExtStrs,&ExtObjs,&TaskCreateDia,&mfail)) goto EXIT;
		if (dstat = ConstructItem("OpnProcC",&mfail,&TaskCreateDia)) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"Class","OpnProcC")) goto EXIT;
		 if(dstat=objSetAttribute(TaskCreateDia,"EST_AGENCY","na")) goto EXIT;
		if(cnt_natStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"OPN_SHEET_COUNT",cnt_natStr)) goto EXIT;
		if(cnt_napStr			!=NULL) if(dstat=objSetAttribute(TaskCreateDia,"PROC_SHEET_COUNT",cnt_napStr)) goto EXIT;
		if(dstat = BeginDbFrame("OpnProcC",&FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = InsertDbItem(TaskCreateDia,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;
		if(dstat = EndDbFrame("OpnProcC",FrameName,&mfail))
		  goto EXIT;
		if(mfail)
		  goto CLEANUP;

 if(fp) fclose(fp); fp=NULL;

		smGetSessionUsrName(&sesUsrNameDup);
		if(sesUsrNameDup)  sesUsrName=nlsStrDup(sesUsrNameDup);

		sprintf(buff,"echo | nail -a %s -s \" ESTSheet Summary Report for Graph \"  ",EnvName);//For Linux

		if(dstat = oiSqlCreateSelect(&Sql_ptr1)) goto CLEANUP;
		if(dstat = oiSqlWhereEQ(Sql_ptr1,"Participant",sesUsrName)) goto CLEANUP;
		if(dstat = QueryDbObject(UsrClass,Sql_ptr1,0,TRUE,SC_SCOPE_OF_SESSION,&soCreator,&mfail))goto CLEANUP;

		   printf("\n\n set size of user ===== %d\n",setSize(soCreator));fflush(stdout);
		   if(Sql_ptr1) oiSqlDispose(Sql_ptr1); Sql_ptr1 = NULL;

		   if (setSize(soCreator)>0)
		   {
				if(dstat = objGetAttribute((ObjectPtr)setGet(soCreator,0),EmailAddrAttr,&EmailID)) goto CLEANUP;
				printf("\n\n Creator EmailID =====%s\n",EmailID);
				if (nlsStrLen(EmailID)>0)
				{
					nlsStrCat(buff,EmailID);
					nlsStrCat(buff," ");
				}
		   }

		nlsStrCat(buff," Dayanand.Amdapure@tatatechnologies.com ");
		nlsStrCat(buff," ");
       nlsStrCat(buff," Awadhut.Natekar@tatatechnologies.com ");
		nlsStrCat(buff," ");
    	nlsStrCat(buff," Preeti.Mehendale@tatatechnologies.com ");
		nlsStrCat(buff," ");
		nlsStrCat(buff," ");
    	system(buff);


	CLEANUP:
	EXIT:
		printf("\nIn the EXIT of main:UpdPlmEpa"); fflush(stdout);
		if(dstat!=OKAY)
			uiShowFatalError(dstat,WHERE);
		return 0;
}
