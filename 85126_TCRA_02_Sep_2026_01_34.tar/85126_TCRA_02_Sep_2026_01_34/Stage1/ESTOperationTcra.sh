#!/bin/ksh
. /user/omfprod/.bash_profile
echo "Argument Passed to Exec"
echo $1
echo $2
echo $3
echo $4
echo $5

sqlplus -s supprod/pcolour <<!
truncate table OpnProcC;
commit;
EXIT;
!

echo "Calling shell of omfprod"
/user/omfprod/shells/APL/TCRAReports/ESTOperationRpt $1 $2 $3 $4 $5  > /tmp/Act_$2.log &
#/user/omf9dev/devgroups/Dayanand/ESTOperationRpt/ESTOperationRpt $1 $2 $3 $4 $5  > /tmp/Act_$2.log &
