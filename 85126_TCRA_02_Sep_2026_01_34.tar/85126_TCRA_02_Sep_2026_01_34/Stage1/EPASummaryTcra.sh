#!/bin/ksh
. /user/omfprod/.bash_profile
echo "Argument Passed to Exec"
echo $1
echo $2
echo $3
echo $4
echo $5
echo $6

sqlplus -s supprod/pcolour <<!
truncate table EpaConSd;
commit;
EXIT;
!

echo "Calling shell of omfprod"
/user/omfprod/shells/APL/TCRAReports/EPASummaryRptTcra $1 $2 $3 $4 $5 $6 > /tmp/Act_$2.log &
#/user/omf9dev/devgroups/Dayanand/EPASummaryRpt/EPASummaryRptTcra $1 $2 $3 $4 $5 $6 > /tmp/Act_$2.log &
