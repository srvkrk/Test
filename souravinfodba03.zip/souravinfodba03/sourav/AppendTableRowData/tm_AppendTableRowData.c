/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Append Table Rows Data into SubModule Library After Reading Data From Input File 
*  File Name    :   tm_AppendTableRowData.c
*  Created on   :   Aug 18th, 2024
*  Usage        :   tm_AppendTableRowData
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/08/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char* SubModAddr_Str = NULL;
	char* SubModNo_Str = NULL;
	char* SubModDesc_Str = NULL;
	char* SubModRev_Str = NULL;
	char* SubModSeq_Str = NULL;
	char* SubModProd_Str = NULL;
	char* SubModPlat_Str = NULL;
	char* SubModProj_Str = NULL;
	char* SubModStatus_Str = NULL;
	char* SubModVLink_Str = NULL;
	char* SubModVCount_Str = NULL;
	char* SubModVPlat_Str = NULL;  
	char* SubModAddr_StrDup = NULL;
	char* SubModNo_StrDup = NULL;
	char* SubModDesc_StrDup = NULL;
	char* SubModRev_StrDup = NULL;
	char* SubModSeq_StrDup = NULL;
	char* SubModProd_StrDup = NULL;
	char* SubModPlat_StrDup = NULL;
	char* SubModProj_StrDup = NULL;
	char* SubModStatus_StrDup = NULL;
	char* SubModVLink_StrDup = NULL;
	char* SubModVCount_StrDup = NULL;
	char* SubModVPlat_StrDup = NULL;
	char str[10];
	int num = 1;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	tag_t tsubmodlib_rev = NULLTAG;
	char *RptFile = (char *) malloc(200*sizeof(char));
	FILE *fpOutput_file = NULL;
 
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Module_Address_Missing_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
	fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"ADDRESS, STATUS \n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}

	fpPart_List = fopen("InputList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{	
			SubModAddr_Str=strtok(Buffer,"^");
			SubModNo_Str=strtok(NULL,"^");
			SubModDesc_Str=strtok(NULL,"^");
			SubModRev_Str=strtok(NULL,"^");
			SubModSeq_Str=strtok(NULL,"^");
			SubModProd_Str=strtok(NULL,"^");
			SubModPlat_Str=strtok(NULL,"^");
			SubModProj_Str=strtok(NULL,"^");
			SubModStatus_Str=strtok(NULL,"^");
			SubModVLink_Str=strtok(NULL,"^");
			SubModVCount_Str=strtok(NULL,"^");
			SubModVPlat_Str=strtok(NULL,"^");
			
			
            if(SubModAddr_Str!=NULL)tc_strdup(SubModAddr_Str,&SubModAddr_StrDup);
            if(SubModNo_Str!=NULL)tc_strdup(SubModNo_Str,&SubModNo_StrDup);
			if(SubModDesc_Str!=NULL)tc_strdup(SubModDesc_Str,&SubModDesc_StrDup);
            if(SubModRev_Str!=NULL)tc_strdup(SubModRev_Str,&SubModRev_StrDup);
            if(SubModSeq_Str!=NULL)tc_strdup(SubModSeq_Str,&SubModSeq_StrDup);
			if(SubModProd_Str!=NULL)tc_strdup(SubModProd_Str,&SubModProd_StrDup);
			if(SubModPlat_Str!=NULL)tc_strdup(SubModPlat_Str,&SubModPlat_StrDup);
			if(SubModProj_Str!=NULL)tc_strdup(SubModProj_Str,&SubModProj_StrDup);
            if(SubModStatus_Str!=NULL)tc_strdup(SubModStatus_Str,&SubModStatus_StrDup);
			if(SubModVLink_Str!=NULL)tc_strdup(SubModVLink_Str,&SubModVLink_StrDup);
			if(SubModVCount_Str!=NULL)tc_strdup(SubModVCount_Str,&SubModVCount_StrDup);
			if(SubModVPlat_Str!=NULL)tc_strdup(SubModVPlat_Str,&SubModVPlat_StrDup);
			
			if(SubModAddr_StrDup!=NULL)trimwhitespace(SubModAddr_StrDup);
			if(SubModNo_StrDup!=NULL)trimwhitespace(SubModNo_StrDup);
			if(SubModDesc_StrDup!=NULL)trimwhitespace(SubModDesc_StrDup);
			if(SubModRev_StrDup!=NULL)trimwhitespace(SubModRev_StrDup);
			if(SubModSeq_StrDup!=NULL)trimwhitespace(SubModSeq_StrDup);
			if(SubModProd_StrDup!=NULL)trimwhitespace(SubModProd_StrDup);
			if(SubModPlat_StrDup!=NULL)trimwhitespace(SubModPlat_StrDup);
			if(SubModProj_StrDup!=NULL)trimwhitespace(SubModProj_StrDup);
			if(SubModStatus_StrDup!=NULL)trimwhitespace(SubModStatus_StrDup);
			if(SubModVLink_StrDup!=NULL)trimwhitespace(SubModVLink_StrDup);
			if(SubModVCount_StrDup!=NULL)trimwhitespace(SubModVCount_StrDup);
			//if(SubModVPlat_StrDup!=NULL)trimwhitespace(SubModVPlat_StrDup);
			
			printf(" Address(SubModAddr_StrDup): [%s]\n",SubModAddr_StrDup);
			printf(" No(SubModNo_StrDup): [%s]\n",SubModNo_StrDup);
			printf(" Description(SubModDesc_StrDup): [%s]\n",SubModDesc_StrDup);
			printf(" Rev(SubModRev_StrDup): [%s]\n",SubModRev_StrDup);
			printf(" Seq(SubModSeq_StrDup): [%s]\n",SubModSeq_StrDup);
			printf(" Product-Line(SubModProd_StrDup): [%s]\n",SubModProd_StrDup);
			printf(" Platform(SubModPlat_StrDup): [%s]\n",SubModPlat_StrDup);
			printf(" Project(SubModProj_StrDup): [%s]\n",SubModProj_StrDup);
			printf(" DR/AR Status(SubModStatus_StrDup): [%s]\n",SubModStatus_StrDup);
			printf(" Vehicle-Link Status(SubModVLink_StrDup): [%s]\n",SubModVLink_StrDup);
			printf(" Vehicle-Link Count(SubModVCount_StrDup): [%s]\n",SubModVCount_StrDup);
			printf(" Vehicle Platform(SubModVPlat_StrDup): [%s]\n",SubModVPlat_StrDup);

			ITK_CALL(QRY_find2("SubModuleLibraryDetails",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("Query[SubModuleLibraryDetails] Found Successfully..!!\n");fflush(stdout);
				char *cEntries[1]  = {"ID"};
				char *cValues[1]  = {SubModAddr_StrDup};
				//char *cValues[1]  = {"A1A01"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Objects[SubModuleLibraryDetails] Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
				    printf(" SubModule Address revision Exist So Continue For Table Data Append..!!\n");fflush(stdout);
				    tsubmodlib_rev = titemobj_results[0];
					
					int row_new_index = 0;
					tag_t* table_rows_tag = NULLTAG;
					int property_index = 0;
					ITK_CALL(AOM_lock(tsubmodlib_rev));
					ITK_CALL(AOM_append_table_rows(tsubmodlib_rev, "t5_Submoduledetail",1, &row_new_index, &table_rows_tag));
					
					tostring(str, num);
					
					ITK_CALL(AOM_lock(table_rows_tag[0]));
					//ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_srno",str));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_submoduleno",SubModNo_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_desc",SubModDesc_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_rev",SubModRev_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_seq",SubModSeq_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_productline",SubModProd_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_Platform",SubModPlat_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_projectcode",SubModProj_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_drarstatus",SubModStatus_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_VehLink",SubModVLink_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_info1",SubModVCount_StrDup));
					ITK_CALL(AOM_set_value_string(table_rows_tag[0],"t5_info2",SubModVPlat_StrDup));
					ITK_CALL(AOM_save(table_rows_tag[0]));
					ITK_CALL(AOM_unlock(table_rows_tag[0]));
					ITK_CALL(AOM_refresh(table_rows_tag[0],TRUE));
								
					ITK_CALL(AOM_save(tsubmodlib_rev));
					ITK_CALL(AOM_unlock(tsubmodlib_rev));
					ITK_CALL(AOM_refresh(tsubmodlib_rev,TRUE));
					    
				}
                else
                {
				   printf("\n SubModule Library Not Found..!!\n");fflush(stdout);
				   fprintf(fpOutput_file,"%s,%s\n",SubModAddr_StrDup,"Not_Present");fflush(fpOutput_file);
				}					
			}
		    else
			{
				printf(" Query[SubModuleLibraryDetails] Tag Not Found..!!");fflush(stdout);
			}
			if(titemobj_results)
			{
			   MEM_free(titemobj_results);
			}
			num = num + 1;
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
    printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_AppendTableRowData.c
* // ./linkitk -o tm_AppendTableRowData tm_AppendTableRowData.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AppendTableRowData/tm_AppendTableRowData .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AppendTableRowData/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AppendTableRowData/InputList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/AppendTableRowData/usage.txt .
* // ./tm_AppendTableRowData -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_AppendTableRowData -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_AppendTableRowData -u=infodba -p=infodba123 -g=dba
*
***************************************************************************/