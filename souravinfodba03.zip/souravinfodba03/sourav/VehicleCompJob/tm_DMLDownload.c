/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   MCC
*  Description  :   Query Vehicle Release and GM DML Release DML From Last One Day & Write in a File
*  File Name    :   tm_DMLDownload.c
*  Created on   :   Sept 24th, 2024
*  Usage        :   tm_DMLDownload
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     24/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

int TC_DMRel(FILE* VehRpt,char* dtrlzdaftr,char* dtrlzdbfr,char* reltype)
{
	int iFail = ITK_ok;
	tag_t tItemobj = NULLTAG;
	int n_entries = 5;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *DMLNo = NULL;
	char *DMLNoDup = NULL;
	ITK_CALL(QRY_find2("ERCDMLReleased_Type",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Query [ERCDMLReleased_Type] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[5]  = {"ID","Name","date_released_after","date_released_before","Release Type"};
		char *cValues[5]  = {"*","T5_LcsErcRlzd",dtrlzdaftr,dtrlzdbfr,reltype};
		//char *cValues[5]  = {"*","T5_LcsErcRlzd","22-Sep-2024 00:00","22-Sep-2024 23:59","Veh"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of ERC Released DML Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" ERC Released DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&DMLNo));
				if(tc_strlen(DMLNo)>0)
				{
					tc_strdup(DMLNo,&DMLNoDup);
				}
				else
				{
					printf("\n DML No is NULL..!!");fflush(stdout);
				}
				printf("\n DML No(DMLNoDup): [%s]\n",DMLNoDup);fflush(stdout);
				if(tc_strlen(DMLNoDup)>0)
				{
					fprintf(VehRpt,"%s^\n",DMLNoDup);fflush(VehRpt);
				}
				else
				{
					printf("\n !!!!!!! DML_No is Blank !!!!!!!");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n ERC Released DML Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Query Tag[ERCDMLReleased_Type] is NULL..!!");fflush(stdout);
	}
	
	return iFail;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(50*sizeof(char));
	FILE *fpOutput_file = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"DMLList.txt");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////// P R I N T     F O R M A T T E D    1 - D A Y S   B E F O R E   D A T E  ////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char BfrDate[100] = "";
	char* BfrDateDup = NULL;
	char *BfrDateFinalFromDup = (char *) malloc(50*sizeof(char));
	char *BfrDateFinalToDup = (char *) malloc(50*sizeof(char));
	struct tm *nextinfo;
	time_t t3;
	time_t t1;
	t1 = time(&now);
	t3 = shiftDate(t1,-1);
	nextinfo = localtime(&t3);
	strftime(BfrDate,100,"%d-%b-%Y", nextinfo);
	trimwhitespace(BfrDate);
	if(BfrDate!=NULL)tc_strdup(BfrDate,&BfrDateDup);
	tc_strcpy(BfrDateFinalFromDup,BfrDateDup);
	tc_strcat(BfrDateFinalFromDup," 00:00");
	printf("\n [1]: Input Formatted Before Date From(BfrDateFinalFromDup): [%s]\n",BfrDateFinalFromDup);
	tc_strcpy(BfrDateFinalToDup,BfrDateDup);
	tc_strcat(BfrDateFinalToDup," 23:59");
	printf("\n [2]: Input Formatted Before Date To(BfrDateFinalToDup): [%s]\n",BfrDateFinalToDup);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	fpOutput_file = fopen(RptFile, "w");
	if(fpOutput_file == NULL)
	{
		printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function1: Release Type - Vehicle Release Start");fflush(stdout);
	TC_DMRel(fpOutput_file,BfrDateFinalFromDup,BfrDateFinalToDup,"Veh");
	printf("\n Function1: Release Type - Vehicle Release End\n");fflush(stdout);
	printf("\n >>>>>>>>>>111111111111111111111111111111111111111111111111111111111111111111111111<<<<<<<<<<<\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	printf("\n Function2: Release Type - Gate Maturation Release Start");fflush(stdout);
	TC_DMRel(fpOutput_file,BfrDateFinalFromDup,BfrDateFinalToDup,"TODR");
	printf("\n Function2: Release Type - Gate Maturation Release End\n");fflush(stdout);
	printf("\n >>>>>>>>>>222222222222222222222222222222222222222222222222222222222222222222222222<<<<<<<<<<<\n");fflush(stdout);
	
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_DMLDownload.c
* // ./linkitk -o tm_DMLDownload tm_DMLDownload.o
* // scp infodba03@172.27.128.199:/user/infodba03/sourav/VehicleCompJob/tm_DMLDownload .
* // scp infodba03@172.27.128.199:/user/infodba03/sourav/VehicleCompJob/exepatch.sh .
* // ./tm_DMLDownload -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_DMLDownload -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/