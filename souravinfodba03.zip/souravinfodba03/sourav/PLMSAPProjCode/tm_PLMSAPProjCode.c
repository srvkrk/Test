/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   PLM-SAP
*  Description  :   Query DML & Check It's Project Code is Live or Not For Material Transfer
*  File Name    :   tm_PLMSAPProjCode.c
*  Created on   :   Sept 23rd, 2024
*  Usage        :   tm_PLMSAPProjCode
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     23/09/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
 
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = '\0';
}

char* TC_SNoStatus(char* Inf1,char* Inf2,char* Inf3)
{
	tag_t tSNItemobj = NULLTAG;
	int n_sn_entries = 6;
	int n_sn_itemobj_found = 0;
	tag_t* tsnitemobj_results = NULLTAG;
	char* SNoStatus = NULL;
	
	ITK_CALL(QRY_find2("Control Objects...",&tSNItemobj));
	if(tSNItemobj != NULLTAG)
	{
		printf("\n Query[Control Objects...] Found Successfully..!!\n");fflush(stdout);
		char *cSNEntries[6]  = {"SYSCD","SUBSYSCD","Information-1","Information-2","Information-3","Information-4"};
		char *cSNValues[6]  = {"XFRDML","*",Inf1,Inf2,Inf3,"SAPLIVE"};
		//char *cSNValues[6]  = {"XFRDML","*","APLJ","STDJ","2001","SAPLIVE"};
		ITK_CALL(QRY_execute(tSNItemobj, n_sn_entries, cSNEntries, cSNValues, &n_sn_itemobj_found, &tsnitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Control Objects...] Found: [%d]\n",n_sn_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_sn_itemobj_found > 0)
		{
			printf("\n Control Objects Found So, Continue..!!\n");fflush(stdout);
			char snostr[10];
		    tostring(snostr, n_sn_itemobj_found);
		    tc_strdup(snostr,&SNoStatus);
		}
		else
		{
			printf("\n No Control Object Found in XFRDML..!!\n");fflush(stdout);
			tc_strdup("1",&SNoStatus);
		}					
	}
	else
	{
		printf(" Query[Control Objects...] Tag Not Found..!!");fflush(stdout);
		tc_strdup("1",&SNoStatus);
	}
	   
	return SNoStatus;
}

char* TC_ProjCodeStatus(char* PCode, char* PlantCode)
{
	trimwhitespace(PCode);
	trimwhitespace(PlantCode);
	tag_t tPItemobj = NULLTAG;
	int n_p_entries = 6;
	int n_p_itemobj_found = 0;
	tag_t* tpitemobj_results = NULLTAG;
	char* PCodeStatus = NULL;
	char* SRFind = NULL;
	char* Info1val = NULL;
	char* Info2val = NULL;
	
	if(tc_strcmp(PlantCode,"1001")==0)
	{
		tc_strdup("APLP",&Info1val);
		tc_strdup("STDP",&Info2val);
	}
	else if(tc_strcmp(PlantCode,"2001")==0)
	{
		tc_strdup("APLJ",&Info1val);
		tc_strdup("STDJ",&Info2val);
	}
	else if(tc_strcmp(PlantCode,"3001")==0)
	{
		tc_strdup("APLL",&Info1val);
		tc_strdup("STDL",&Info2val);
	}
	else if(tc_strcmp(PlantCode,"1500")==0)
	{
		tc_strdup("APLD",&Info1val);
		tc_strdup("STDD",&Info2val);
	}
	else if(tc_strcmp(PlantCode,"3100")==0)
	{
		tc_strdup("APLU",&Info1val);
		tc_strdup("STDU",&Info2val);
	}
	else
	{
	   printf("\n Plant Code Not Valid..!!\n");fflush(stdout);
	}
	
	ITK_CALL(QRY_find2("Control Objects...",&tPItemobj));
	if(tPItemobj != NULLTAG)
	{
		printf("\n Query[Control Objects...] Found Successfully..!!\n");fflush(stdout);
		char *cPEntries[6]  = {"SYSCD","SUBSYSCD","Information-1","Information-2","Information-3","Information-4"};
		char *cPValues[6]  = {"XFRDML",PCode,Info1val,Info2val,PlantCode,"SAPLIVE"};
		//char *cPValues[6]  = {"XFRDML","5185","APLJ","STDJ","2001","SAPLIVE"};
		ITK_CALL(QRY_execute(tPItemobj, n_p_entries, cPEntries, cPValues, &n_p_itemobj_found, &tpitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Objects[Control Objects...] Found: [%d]\n",n_p_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_p_itemobj_found > 0)
		{
			printf("\n Control Objects Already Present For project Code: [%s]\n",PCode);fflush(stdout);
		    tc_strdup("Yes",&PCodeStatus);
		}
		else
		{
			printf("\n Control Objects Already Not Present For project Code: [%s]\n",PCode);fflush(stdout);
			printf("\n Project Code Live Control Object Creation Start..!!\n");fflush(stdout);
			SRFind = TC_SNoStatus(Info1val,Info2val,PlantCode);
			int SRFindIn;
			SRFindIn = atoi(SRFind);
			SRFindIn = SRFindIn + 1;
			printf("\n Final Serial No: [%d]\n",SRFindIn);fflush(stdout);
			char SRFindInStr[10];
		    tostring(SRFindInStr, SRFindIn);
			printf("\n Final Serial No: [%s]\n",SRFindInStr);fflush(stdout);
			
			char command[512];
			printf("\n Shell Call Started...");fflush(stdout);
			sprintf(command,"/user/cvprod/PLMSAP/shell/PLMSAPMatInterface/ProjCodeLive.sh %s %s %s %s %s",PCode,Info1val,Info2val,PlantCode,SRFindInStr);
			system(command);
			printf("\n Shell Call Ended...");
			printf("\n Project Code Live Control Object Creation End..!!\n");fflush(stdout);
			tc_strdup("Yes",&PCodeStatus);
		}					
	}
	else
	{
		printf(" Query[Control Objects...] Tag Not Found..!!");fflush(stdout);
		tc_strdup("No",&PCodeStatus);
	}
	   
	return PCodeStatus;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 1;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *DMLNo = NULL;
	char *DMLNoDup = NULL;
	char *DMLPCode = NULL;
	char *DMLPCodeDup = NULL;
	char *DMLPCodeStatus = NULL;
	char *inp_dml_str = NULL;
	char *inp_dml_strDup = NULL;
	char *inp_plant_str = NULL;
	char *inp_plant_strDup = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	inp_dml_str = ITK_ask_cli_argument("-dml=");
    inp_plant_str = ITK_ask_cli_argument("-plant=");

	trimwhitespace(inp_dml_str);
	trimwhitespace(inp_plant_str);
	if(inp_dml_str!=NULL)tc_strdup(inp_dml_str,&inp_dml_strDup);
	if(inp_plant_str!=NULL)tc_strdup(inp_plant_str,&inp_plant_strDup);

	printf(" [1]: Input DML_No(inp_dml_strDup): [%s]\n",inp_dml_strDup);
	printf(" [2]: Input Plant_Name(inp_plant_strDup): [%s]\n",inp_plant_strDup);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	ITK_CALL(QRY_find2("APL_DML_PLMSAP",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Query [APL_DML_PLMSAP] Found Successfully..!!\n");fflush(stdout);
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {inp_dml_strDup};
		//char *cValues[1]  = {"24AM802004_APLJ"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Planning Released DML Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Planning Released DML Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&DMLNo));
				if(tc_strlen(DMLNo)>0)
				{
					tc_strdup(DMLNo,&DMLNoDup);
				}
				else
				{
					printf("\n DML No is NULL..!!");fflush(stdout);
				}
				printf("\n DML No(DMLNoDup): [%s]\n",DMLNoDup);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_cprojectcode",&DMLPCode));
				if(tc_strlen(DMLPCode)>0)
				{
					tc_strdup(DMLPCode,&DMLPCodeDup);
				}
				else
				{
					printf("\n DML Project Code No is NULL..!!");fflush(stdout);
				}
				printf("\n DML Project Code(DMLPCodeDup): [%s]\n",DMLPCodeDup);fflush(stdout);
				DMLPCodeStatus = TC_ProjCodeStatus(DMLPCodeDup,inp_plant_strDup);
				if(tc_strcmp(DMLPCodeStatus,"Yes")==0)
				{
					printf("\n Project Code Control Object Already Live or Created..!!");fflush(stdout);
				}
				else
				{
					printf("\n !!!!!!! SERIOUS ISSUE REGARDING PROJECT CODE CONTROL OBJECT !!!!!!!");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n Planning Released DML Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Query Tag[APL_DML_PLMSAP] is NULL..!!");fflush(stdout);
	}
	
    if (titemobj_results)
	{
	  MEM_free(titemobj_results);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PLMSAPProjCode.c
* // ./linkitk -o tm_PLMSAPProjCode tm_PLMSAPProjCode.o
* // scp infodba03@172.27.128.199:/user/infodba03/sourav/PLMSAPProjCode/tm_PLMSAPProjCode .
* // scp infodba03@172.27.128.199:/user/infodba03/sourav/PLMSAPProjCode/exepatch.sh .
* // scp infodba03@172.27.128.199:/user/infodba03/sourav/PLMSAPProjCode/usage.txt .
* // ./tm_PLMSAPProjCode -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -dml="24AM802004_APLJ" -plant="2001"
* // ./tm_PLMSAPProjCode -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dml="24AM802004_APLJ" -plant="2001"
*
***************************************************************************/