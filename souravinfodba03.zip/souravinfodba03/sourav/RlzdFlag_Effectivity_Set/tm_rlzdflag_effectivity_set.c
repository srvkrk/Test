/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Create Released Flag & Set Effectivity on it.  
*  File Name    :   tm_rlzdflag_effectivity_set.c
*  Created on   :   Jan 29th, 2025
*  Usage        :   tm_rlzdflag_effectivity_set
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     29/01/2025                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *Part_item_id = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_rlzdflg_str = NULL;
	char *item_id_strDup = NULL;
    char *item_rev_strDup = NULL;
    char *item_seq_strDup = NULL;
    char *item_rlzdflg_strDup = NULL;	
	char *item_rlzddt_str = NULL;
	char *item_efffromdt_str = NULL;
	char *item_efftodt_str = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *item_revseq_strDup = (char *) malloc(20*sizeof(char));
	tag_t tQryDesRev = NULLTAG;
	tag_t trelease_status = NULLTAG;
	logical retain_released_date=false;
	date_t erc_test_date_1;
	date_t erc_test_date_2;
	tag_t teffdt = NULLTAG;
	date_t item_rlzddt_dt;
	tag_t DateRlzdDtAttrId = NULLTAG;
	date_t *erc_start_end_date = NULL;
	date_t *aplstd_start_end_date = NULL;
	date_t aplstd_test_date_1;
	date_t aplstd_test_date_2;
	char *rlzdflag_orgname = NULL;
	rlzdflag_orgname = (char *) malloc(100*sizeof(char));
							
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");

	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			item_id_str=strtok(Buffer,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			item_rlzdflg_str=strtok(NULL,"^");
			item_rlzddt_str=strtok(NULL,"^");
			item_efffromdt_str=strtok(NULL,"^");
			item_efftodt_str=strtok(NULL,"^");
			
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			if(item_rlzdflg_str!=NULL)tc_strdup(item_rlzdflg_str,&item_rlzdflg_strDup);
			
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			if(item_rlzdflg_strDup!=NULL)trimwhitespace(item_rlzdflg_strDup);
			
			printf(" Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf(" Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf(" Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf(" Part Released Flag(item_rlzdflg_strDup): [%s]\n",item_rlzdflg_strDup);
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,"*");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);

			if(tc_strcmp(item_rlzdflg_strDup,"ERCReview")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsReview"); //ERC Review
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"ERCReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsErcRlzd"); //ERC Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"MBOMReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_MBOMReleased"); //MOBOM Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLAReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsAplaRlzd"); //APLA Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLCReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsAplRlzd"); //APL Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLDReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsApldRlzd"); //APLD Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLJReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsApljRlzd"); //APLJ Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLLReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsApllRlzd"); //APLL Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLPReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsAplpRlzd"); //APLP Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLSReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsAplsRlzd"); //APLS Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLUReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsApluRlzd"); //APLU Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"APLVReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsAplvRlzd"); //APLV Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIAReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdaRlzd"); //STDSIA Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSICReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdRlzd"); //STDSIC Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIDReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStddRlzd"); //STDSID Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIJReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdjRlzd"); //STDSIJ Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSILReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdlRlzd"); //STDSIL Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIPReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdpRlzd"); //STDSIP Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSISReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdsRlzd"); //STDSIS Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIUReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStduRlzd"); //STDSIU Released
			}
			else if(tc_strcmp(item_rlzdflg_strDup,"STDSIVReleased")==0)
			{
				tc_strcpy(rlzdflag_orgname,"T5_LcsStdvRlzd"); //STDSIV Released
			}
			else
			{
				printf("\n !!..Input Release Status Flag Not Matched..!!\n");fflush(stdout);
			}
	
	        printf("\n >>>>>>>>>>>>>> Input Release Flag: [%s] <<<<<<<<<<<<<<<",item_rlzdflg_strDup);fflush(stdout);
			printf("\n >>>>>>>>>>>>>> Original Release Flag: [%s] <<<<<<<<<<<<<<<\n",rlzdflag_orgname);fflush(stdout);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"H*2","51780142R"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf("\n Design Revision Found Successfully..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						tQryDesRev = titemobj_results[i];
						if((tc_strcmp(rlzdflag_orgname,"T5_LcsReview")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsErcRlzd")==0))
						{
							printf("\n Effectivity and Release Status Stamp Start..!! [ERC Review|ERC Released]\n");fflush(stdout);
							//ITK_CALL(CR_create_release_status(rlzdflag_orgname,&trelease_status));
							//ITK_CALL(EPM_add_release_status(trelease_status,1,&tQryDesRev,retain_released_date));
							ITK_CALL(RELSTAT_create_release_status(rlzdflag_orgname,&trelease_status));
							ITK_CALL(RELSTAT_add_release_status(trelease_status,1,&tQryDesRev,retain_released_date));

							ITK_CALL(ITK_string_to_date(item_efffromdt_str, &erc_test_date_1));
							ITK_CALL(ITK_string_to_date(item_efftodt_str, &erc_test_date_2));
							
							erc_start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

							erc_start_end_date[0] = erc_test_date_1;
							erc_start_end_date[1] = erc_test_date_2;

							ITK_CALL(WSOM_status_clear_effectivities(trelease_status));
							ITK_CALL(WSOM_effectivity_create_with_dates(trelease_status, NULLTAG, 2,erc_start_end_date, EFFECTIVITY_closed, &teffdt));
							ITK_CALL(AOM_save_with_extensions(teffdt));
							ITK_CALL(AOM_save_with_extensions(trelease_status));
							ITK_CALL(AOM_refresh(trelease_status, 0));
							printf("\n Effectivity and Release Status Stamp End..!! [ERC Review|ERC Released]\n");fflush(stdout);
							
                            printf("\n Date_Released Stamp on Release Status Flag Stamp Start..!! [ERC Review|ERC Released]\n");fflush(stdout);
							ITK_CALL(ITK_string_to_date(item_rlzddt_str, &item_rlzddt_dt));
                            ITK_CALL(AOM_refresh(trelease_status,POM_modify_lock));
                            printf("\n Lock..!!\n");							
							ITK_CALL(POM_attr_id_of_attr("date_released","ReleaseStatus",&DateRlzdDtAttrId));
							printf("\n Property Name Tag Found..!!\n");
							ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							ITK_CALL(POM_set_attr_date(1,&trelease_status,DateRlzdDtAttrId,item_rlzddt_dt));
							printf("\n Set Property Value..!!\n");
							ITK_CALL(POM_save_instances(1, &trelease_status, true));
							printf("\n Save...!!\n");
							ITK_CALL(AOM_refresh(trelease_status, POM_no_lock));
							printf("\n Unlock..!!\n");
							printf("\n Date_Released Stamp on Release Status Flag Stamp End..!! [ERC Review|ERC Released]\n");fflush(stdout);
						}
						else if((tc_strcmp(rlzdflag_orgname,"T5_MBOMReleased")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsAplaRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsAplRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsApldRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsApljRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsApllRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsAplpRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsAplsRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsApluRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsAplvRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdaRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStddRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdjRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdlRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdpRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdsRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStduRlzd")==0) || (tc_strcmp(rlzdflag_orgname,"T5_LcsStdvRlzd")==0))
						{
							printf("\n Effectivity and Release Status Stamp Start..!! [MBOM|APL|STD]\n");fflush(stdout);
							//ITK_CALL(CR_create_release_status(rlzdflag_orgname,&trelease_status));
							//ITK_CALL(EPM_add_release_status(trelease_status,1,&tQryDesRev,retain_released_date));
							ITK_CALL(RELSTAT_create_release_status(rlzdflag_orgname,&trelease_status));
							ITK_CALL(RELSTAT_add_release_status(trelease_status,1,&tQryDesRev,retain_released_date));

							ITK_CALL(ITK_string_to_date(item_efffromdt_str, &aplstd_test_date_1));
							//ITK_CALL(ITK_string_to_date(item_efftodt_str, &aplstd_test_date_2));
							
							aplstd_start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*1);

							aplstd_start_end_date[0] = aplstd_test_date_1;
							//aplstd_start_end_date[1] = aplstd_test_date_2;

							ITK_CALL(WSOM_status_clear_effectivities(trelease_status));
							ITK_CALL(WSOM_effectivity_create_with_dates(trelease_status, NULLTAG, 1,aplstd_start_end_date, EFFECTIVITY_open_ended, &teffdt));
							ITK_CALL(AOM_save_with_extensions(teffdt));
							ITK_CALL(AOM_save_with_extensions(trelease_status));
							ITK_CALL(AOM_refresh(trelease_status, 0));
							printf("\n Effectivity and Release Status Stamp End..!! [MBOM|APL|STD]\n");fflush(stdout);
							
                            printf("\n Date_Released Stamp on Release Status Flag Stamp Start..!! [MBOM|APL|STD]\n");fflush(stdout);
							ITK_CALL(ITK_string_to_date(item_rlzddt_str, &item_rlzddt_dt));
                            ITK_CALL(AOM_refresh(trelease_status,POM_modify_lock));
                            printf("\n Lock..!!\n");							
							ITK_CALL(POM_attr_id_of_attr("date_released","ReleaseStatus",&DateRlzdDtAttrId));
							printf("\n Property Name Tag Found..!!\n");
							ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
							ITK_CALL(POM_set_attr_date(1,&trelease_status,DateRlzdDtAttrId,item_rlzddt_dt));
							printf("\n Set Property Value..!!\n");
							ITK_CALL(POM_save_instances(1, &trelease_status, true));
							printf("\n Save...!!\n");
							ITK_CALL(AOM_refresh(trelease_status, POM_no_lock));
							printf("\n Unlock..!!\n");
							printf("\n Date_Released Stamp on Release Status Flag Stamp End..!! [MBOM|APL|STD]\n");fflush(stdout);
						}
						else
						{
							printf("\n Input Release Status Invalid..!!\n");fflush(stdout);
						}			
					}
				}
				else
				{
					printf("\n Query Revision Not Found..!!\n");fflush(stdout);
				}
			}
		    else
			{
				printf("\n Query[DesignRevision Sequence] Tag Not Found..!!\n");fflush(stdout);
			}
			if (titemobj_results)
			{
				MEM_free(titemobj_results);
			}
		}
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_rlzdflag_effectivity_set.c
* // ./linkitk -o tm_rlzdflag_effectivity_set tm_rlzdflag_effectivity_set.o
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/RlzdFlag_Effectivity_Set/tm_rlzdflag_effectivity_set .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/RlzdFlag_Effectivity_Set/exepatch.sh .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/RlzdFlag_Effectivity_Set/PartList.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/RlzdFlag_Effectivity_Set/usage.txt .
* // scp testcmi@172.22.97.28:/user/testcmi/sourav/TC_14_Modified_Code/RlzdFlag_Effectivity_Set/SendEmail.sh .
* // ./tm_rlzdflag_effectivity_set -u=loader -pf=user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_rlzdflag_effectivity_set -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_rlzdflag_effectivity_set -u=loader -p=loader123 -g=dba
*
***************************************************************************/