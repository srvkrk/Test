/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: projectfind.c
* Description	: This Utility Mainly Used For Project Property Find in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 27/10/2022   	   Sourav Karak			          Initial Code

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/project.h>
#include <tccore/aom_prop.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001

int Report_error(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}




int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	char* cError = NULL;
	//char* cUSERID = NULL;
	//char* cPASS = NULL;
	//char* cGroup = NULL;
	char* username = NULL;
	tag_t tUser = NULLTAG;
	char* cItemID = NULL;
	//tag_t tUser = NULLTAG;
	tag_t tProject = NULLTAG;
	char* cProjectDes = NULL;

	printf("\n Total Number of Argument Passed is : %d", argc);
	if (argc == 5)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");
			//cUSERID = ITK_ask_cli_argument("-u=");
			//cPASS = ITK_ask_cli_argument("-p=");
			//cGroup = ITK_ask_cli_argument("-g=");
			cItemID = ITK_ask_cli_argument("-project_id=");
			//Report_error(ITK_init_module(cUSERID, cPASS, cGroup));
			//iFail=ITK_init_module("infodba", "infodba", "dba");
			iFail = ITK_auto_login();
		    printf("\n Return Value From AutoLogin API is : %d", iFail);
			if (iFail == ITK_ok)
			{
				printf("\n Teamcenter Login Success...");
				POM_get_user(&username, &tUser);
				printf("\n Return Value For UserName API is : %d", iFail);
				printf("\n Current Loggedin User: %s", username);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nError is : %s", cError);
			}
			printf("\n Return Value For Teamcenter Login API is : %d", iFail);
			printf("\n Teamcenter Login Success...");
			Report_error(PROJ_find(cItemID,&tProject));
			printf("\n Return Value For Project Find API is : %d", iFail);
			printf("\n Project Find Success...");
			Report_error(AOM_ask_value_string(tProject,"t5_ProjOrgnId",&cProjectDes));
			printf("\n Project property Return Value From API is: %d", iFail);
			printf("\n Project Property Return Success...");
			printf("\n Project Oranization ID: %s",cProjectDes);fflush(stdout);
			Report_error(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API is : %d", iFail);
			printf("\n Teamcenter Logout Success...\n");
		    if (cProjectDes)
			{
				MEM_free(cProjectDes);
			}
		
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched");
	}
	return 0;
}


