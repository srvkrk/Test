#include "malloc.h"


#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>

#include "wmhelpe.h"
#include "bapi.h"
#include "saprfc.h"
#include "sapitab.h"
#include "t.h"
#include "replica.h"

#define PartCounterLimit 3000
static int PartCounter = 0;
static int PartbatchCounter = 0;
static int PartinspallocCounter = 0;

FILE * fsuccess;
FILE* fp=NULL;

char fsuccess_name[200];

WERKS_D eWerks;
static MATNR eMatnr;

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

struct MaterialBatches
{
	char part_noDup[50];
	char mat_type[50];
	char splantcode[50];
	char dml_no_arg[50];
	char overhd_grp[50];
	char origin_group[50];
};

struct MaterialBatches batches[PartCounterLimit];

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *OldMatNoDup=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *old_mat_no=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *dml_no_arg = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;


char *plantcode=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputPart=NULL;
char *iPlantCode=NULL;
char *iSapServer=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;


//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);

void cll_zrfc_ac_view_create(void);
RFC_RC new_zrfc_ac_view_create(RFC_HANDLE hRfc,NOAPPLLOG *eNOAPPLLOG,NOCHANGEDOC *eNOCHANGEDOC,TESTRUN *eTESTRUN,
INPFLDCHECK *eINPFLDCHECK,FLAG_CAD_CALL *eFLAG_CAD_CALL,NO_ROLLBACK_WORK *eNO_ROLLBACK_WORK,FLAG_ONLINE *eFLAG_ONLINE,
RMMG1_AENNR* eRMMG1_AENNR,BAPIRET2* iRETURN,ITAB_H thBAPIE1MATHEADER,ITAB_H thBAPIE1MBEW,ITAB_H thBAPIE1MBEWX,ITAB_H thBAPIRET2,char *xException);

void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(tc_strstr(SAPpstat,"K"))>0)
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	
   if(tc_strlen(tc_strstr(MRPpstat,"D"))>0)
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	
  if(tc_strlen(tc_strstr(MRPpstat,"B"))>0)
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}

FetchPlantSpecificData(char* plantcode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	PlantSuffix  = strtok ( NULL, "_" );
	
	//tc_strcpy(dml_no_arg,DMLNo);
	//tc_strcpy(dml_numAP1,DMLNo);

	//printf("\nDMLNo [%s]	PlantSuffix [%s]	Project Code [%s]", DMLNo,PlantSuffix,ProjCode);

	//char	*qry_value[3] = {"XFRDML",ProjCode,PlantSuffix};
	
	if(QRY_find("Control Objects...", &PlantCodeQryTag));

	if(PlantCodeQryTag)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		/*if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryApl,qry_value,&ContObjCnt,&ContorlObjTag));

		if (ContObjCnt==0)
		{
			if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryStd,qry_value,&ContObjCnt,&ContorlObjTag));
		}

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&plantcode);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&SAPLivFlg);
			printf("\nPlantSuffix [%s]	Plant Code [%s]",PlantSuffix,plantcode);
		}
		else
		{
			printf("\nProjectCode [%s] do not have entry in Control Object PlantDML for Suffix [%s] hence exiting!",ProjCode,PlantSuffix); fflush(stdout);
			goto CLEANUP;
		}*/

		char    *qry_MakeValue[2]  = {"MAKEBUY",plantcode};
		
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\nPlant Code [%s]	Plant_MakeBuy [%s]	Plant_StoreLoc [%s]",plantcode,Plant_MakeBuy,Plant_StoreLoc);
		}
		else
		{
			printf("\nPlantcode [%s] do not have entry in Control Object MAKEBUY hence exiting!",plantcode); fflush(stdout);
			goto CLEANUP;
		}



		char    *qry_PlantValue[2]  = {"PLANTDATA",plantcode};

		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\nplantcode      :[%s]",plantcode);
			printf("\nprofit_centre  :[%s]",profit_centre_sap);
			printf("\nplan_calendar  :[%s]",plan_calendar);
			printf("\noverhd_grp     :[%s]",overhd_grp);
			printf("\norigin_group   :[%s]",origin_group);
		}

	}

	CLEANUP:
	return ContObjCnt;
}

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 1;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}


void cll_zrfc_ac_view_create(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256] = { 0 };
	char retPartnumber[50] = { 0 };
	char s[1074] = { 0 };
	int PartIndex = 0;
	NOAPPLLOG eNOAPPLLOG;
	NOCHANGEDOC eNOCHANGEDOC;
	TESTRUN eTESTRUN;
	INPFLDCHECK eINPFLDCHECK;
	FLAG_CAD_CALL eFLAG_CAD_CALL;
	NO_ROLLBACK_WORK eNO_ROLLBACK_WORK;
	FLAG_ONLINE eFLAG_ONLINE;
	BAPIRET2 iRETURN;

	ITAB_H thBAPIE1MATHEADER = ITAB_NULL;
	ITAB_H thBAPIE1MBEW = ITAB_NULL;
	ITAB_H thBAPIE1MBEWX = ITAB_NULL;
	ITAB_H thBAPIRET2 = ITAB_NULL;

	BAPIE1MATHEADER *tBAPIE1MATHEADER;
	BAPIE1MBEW *tBAPIE1MBEW;
	BAPIE1MBEWX *tBAPIE1MBEWX;
	BAPIRET2 *tBAPIRET2;
	RMMG1_AENNR eRMMG1_AENNR;
	char sval_type[4] = {0};
	int crow = 0 ;
	char valuation_cat[2] = { "S" };
	char *myzeroDup4 = NULL;
	/*1,0110,2,0120,3,0230,4,0240,5,0250*/
	char aval_class[5][5]={"0110","0120","0230","0240","0250"};
	int val_type = 0;

	tc_strdup("0.0000",&myzeroDup4);

	printf("\nCreating Batches:");
	hRfc = BapiLogon();

	SETCHAR(eNOAPPLLOG.NOAPPLLOG,"");
	SETCHAR(eNOCHANGEDOC.NOCHANGEDOC,"");
	SETCHAR(eTESTRUN.TESTRUN,"");
	SETCHAR(eINPFLDCHECK.INPFLDCHECK,"");
	SETCHAR(eFLAG_CAD_CALL.FLAG_CAD_CALL,"");
	SETCHAR(eNO_ROLLBACK_WORK.NO_ROLLBACK_WORK,"");
	SETCHAR(eFLAG_ONLINE.FLAG_ONLINE,"");



	if (thBAPIE1MATHEADER==ITAB_NULL)
	{
		thBAPIE1MATHEADER = ItCreate("HEADDATA",sizeof(BAPIE1MATHEADER),0,0);
		if (thBAPIE1MATHEADER==ITAB_NULL) 
			rfc_error("ItCreate HEADDATA");
	}
	else if (ItFree(thBAPIE1MATHEADER) != 0) 
		rfc_error("ItFree HEADDATA");


	if (thBAPIE1MBEW==ITAB_NULL)
	{
		thBAPIE1MBEW = ItCreate("VALUATIONDATA",sizeof(BAPIE1MBEW),0,0);
		if (thBAPIE1MBEW==ITAB_NULL) rfc_error("ItCreate VALUATIONDATA");
	}
	else if (ItFree(thBAPIE1MBEW) != 0) 
		rfc_error("ItFree VALUATIONDATA");


	if (thBAPIE1MBEWX==ITAB_NULL)
	{
		thBAPIE1MBEWX = ItCreate("VALUATIONDATAX",sizeof(BAPIE1MBEWX),0,0);
		if (thBAPIE1MBEWX==ITAB_NULL) 
			rfc_error("ItCreate VALUATIONDATAX");
	}
	else if (ItFree(thBAPIE1MBEWX)!= 0) rfc_error("ItFree VALUATIONDATAX");

	if (thBAPIRET2==ITAB_NULL)
	{
		thBAPIRET2 = ItCreate("RETURNMESSAGES",sizeof(BAPIRET2),0,0);
		if (thBAPIRET2==ITAB_NULL)
		rfc_error("ItCreateBAPIRET2");
	}
	else
	{
		if (ItFree(thBAPIRET2) != 0)
		rfc_error("ItFreeBAPIRET2");
	}

	printf("\nbatches[PartIndex].part_noDup:%s",batches[PartIndex].part_noDup);
	printf("\nbatches[PartIndex].mat_type:%s",batches[PartIndex].mat_type);
	printf("\nbatches[PartIndex].splantcode:%s",batches[PartIndex].splantcode);

	
//	if (tBAPIE1MATHEADER == NULL) rfc_error("ItAppLine BAPIE1MATHEADER");
//	if (tBAPIE1MBEW == NULL) rfc_error("ItAppLine BAPIE1MBEW");
//	if (tBAPIE1MBEWX == NULL) rfc_error("ItAppLine BAPIE1MBEWX");

	printf("\n1");fflush(stdout);

	for(PartIndex = 0; PartIndex < PartbatchCounter ; PartIndex ++)
	{
		printf("\n2");fflush(stdout);

		tBAPIE1MATHEADER = ItAppLine(thBAPIE1MATHEADER) ;

		SETCHAR(tBAPIE1MATHEADER->FUNCTION ,"UPD");
		SETCHAR(tBAPIE1MATHEADER->MATERIAL,batches[PartIndex].part_noDup);
		SETCHAR(tBAPIE1MATHEADER->MATL_TYPE,"");
		SETCHAR(tBAPIE1MATHEADER->IND_SECTOR,"M");
		SETCHAR(tBAPIE1MATHEADER->BASIC_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->MRP_VIEW,batches[PartIndex].mat_type);
		SETCHAR(tBAPIE1MATHEADER->STORAGE_VIEW,"");
		if(tc_strcmp(batches[PartIndex].mat_type,"FERT") != 0)
		{
			SETCHAR(tBAPIE1MATHEADER->QUALITY_VIEW,"X");
		}
		else
		{
			SETCHAR(tBAPIE1MATHEADER->QUALITY_VIEW,"");
		}
		SETCHAR(tBAPIE1MATHEADER->ACCOUNT_VIEW,"X");
		SETCHAR(tBAPIE1MATHEADER->COST_VIEW,"X");
		SETCHAR(tBAPIE1MATHEADER->SALES_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->PURCHASE_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->FORECAST_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->WORK_SCHED_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->PRT_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->WAREHOUSE_VIEW,"");
		SETCHAR(tBAPIE1MATHEADER->MATERIAL_EXTERNAL,"");
		SETCHAR(tBAPIE1MATHEADER->MATERIAL_GUID,"");
		SETCHAR(tBAPIE1MATHEADER->MATERIAL_VERSION,"");

		printf("\n3");fflush(stdout);

		for (val_type = 0;val_type < 5 ;val_type++ )
		{
			F_OUTK("\nValuation class",10,30,aval_class[val_type]);
			strcpy(sval_type,"");
			sprintf(sval_type,"%d",(val_type+1));


			tBAPIE1MBEW = ItAppLine (thBAPIE1MBEW) ;
			tBAPIE1MBEWX  = ItAppLine (thBAPIE1MBEWX) ;

			/*SETCHAR(tBAPIE1MBEW->FUNCTION,"UPD");
			SETCHAR(tBAPIE1MBEW->MATERIAL,batches[PartIndex].part_noDup);
			SETCHAR(tBAPIE1MBEW->VAL_AREA,batches[PartIndex].splantcode);
			SETCHAR(tBAPIE1MBEW->VAL_CLASS,aval_class[val_type]);
			SETCHAR(tBAPIE1MBEW->VAL_TYPE,sval_type);
			SETCHAR(tBAPIE1MBEW->VAL_CAT,valuation_cat);
			SETCHAR(tBAPIE1MBEW->PRICE_CTRL,"");
			SETBCD(tBAPIE1MBEW->STD_PRICE,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->MOVING_PR,myzeroDup4,4);
			SETCHAR(tBAPIE1MBEW->MAT_ORIGIN,"");
			SETCHAR(tBAPIE1MBEW->ORIG_GROUP,batches[PartIndex].origin_group);
			SETCHAR(tBAPIE1MBEW->OVERHEAD_GRP,batches[PartIndex].overhd_grp);
			SETCHAR(tBAPIE1MBEW->QTY_STRUCT,"");
			SETCHAR(tBAPIE1MBEW->DEL_FLAG,"");
			SETBCD(tBAPIE1MBEW->PRICE_UNIT,"",0);
			SETCHAR(tBAPIE1MBEW->PR_CTRL_PP,"");
			SETBCD(tBAPIE1MBEW->MOV_PR_PP,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->STD_PR_PP,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PR_UNIT_PP,"0",1);
			SETCHAR(tBAPIE1MBEW->VCLASS_PP,"");
			SETCHAR(tBAPIE1MBEW->PR_CTRL_PY,"");
			SETBCD(tBAPIE1MBEW->MOV_PR_PY,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->STD_PR_PY,myzeroDup4,4);
			SETCHAR(tBAPIE1MBEW->VCLASS_PY,"");
			SETBCD(tBAPIE1MBEW->PR_UNIT_PY,"0",0);
			SETBCD(tBAPIE1MBEW->FUTURE_PR,myzeroDup4,4);
			SETDATE(tBAPIE1MBEW->VALID_FROM,"");
			SETBCD(tBAPIE1MBEW->TAXPRICE_1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->COMMPRICE1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->TAXPRICE_3,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->COMMPRICE3,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PLND_PRICE,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PLNDPRICE1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PLNDPRICE2,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PLNDPRICE3,myzeroDup4,4);
			SETDATE(tBAPIE1MBEW->PLNDPRDATE1,"");
			SETDATE(tBAPIE1MBEW->PLNDPRDATE2,"");
			SETDATE(tBAPIE1MBEW->PLNDPRDATE3,"");
			SETCHAR(tBAPIE1MBEW->LIFO_FIFO,"");
			SETCHAR(tBAPIE1MBEW->POOLNUMBER,"");
			SETBCD(tBAPIE1MBEW->TAXPRICE_2,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->COMMPRICE2,myzeroDup4,4);
			SETCHAR(tBAPIE1MBEW->DEVAL_IND,"00");
			SETCHAR(tBAPIE1MBEW->ML_ACTIVE,"");
			SETCHAR(tBAPIE1MBEW->ML_SETTLE,"");
			SETCHAR(tBAPIE1MBEW->ORIG_MAT,"X");
			SETCHAR(tBAPIE1MBEW->VM_SO_STK,"");
			SETCHAR(tBAPIE1MBEW->VM_P_STOCK,"");
			SETCHAR(tBAPIE1MBEW->MATL_USAGE,"");
			SETCHAR(tBAPIE1MBEW->IN_HOUSE,"");
			SETBCD(tBAPIE1MBEW->TAX_CML_UN,"0",0);
			SETCHAR(tBAPIE1MBEW->ACCOUNT_VIEW,"X");
			SETCHAR(tBAPIE1MBEW->COST_VIEW,"X");
			SETCHAR(tBAPIE1MBEW->MATERIAL_EXTERNAL,"");
			SETCHAR(tBAPIE1MBEW->MATERIAL_GUID,"");
			SETCHAR(tBAPIE1MBEW->MATERIAL_VERSION,"");

			SETCHAR(tBAPIE1MBEWX->FUNCTION,"UPD");
			SETCHAR(tBAPIE1MBEWX->MATERIAL,batches[PartIndex].part_noDup);
			SETCHAR(tBAPIE1MBEWX->VAL_AREA,batches[PartIndex].splantcode);
			SETCHAR(tBAPIE1MBEWX->VAL_TYPE,sval_type);
			SETCHAR(tBAPIE1MBEWX->VAL_CAT,"X");
			SETCHAR(tBAPIE1MBEWX->VAL_CLASS,"X");
			SETCHAR(tBAPIE1MBEWX->PRICE_CTRL,"");
			SETCHAR(tBAPIE1MBEWX->STD_PRICE,"");
			SETCHAR(tBAPIE1MBEWX->MOVING_PR,"");
			SETCHAR(tBAPIE1MBEWX->MAT_ORIGIN,"");
			SETCHAR(tBAPIE1MBEWX->ORIG_GROUP,"X");
			SETCHAR(tBAPIE1MBEWX->OVERHEAD_GRP,"X");
			SETCHAR(tBAPIE1MBEWX->QTY_STRUCT,"");
			SETCHAR(tBAPIE1MBEWX->DEL_FLAG,"");
			SETCHAR(tBAPIE1MBEWX->PRICE_UNIT,"");
			SETCHAR(tBAPIE1MBEWX->PR_CTRL_PP,"");
			SETCHAR(tBAPIE1MBEWX->MOV_PR_PP,"");
			SETCHAR(tBAPIE1MBEWX->STD_PR_PP,"");
			SETCHAR(tBAPIE1MBEWX->PR_UNIT_PP,"");
			SETCHAR(tBAPIE1MBEWX->VCLASS_PP,"");
			SETCHAR(tBAPIE1MBEWX->PR_CTRL_PY,"");
			SETCHAR(tBAPIE1MBEWX->MOV_PR_PY,"");
			SETCHAR(tBAPIE1MBEWX->STD_PR_PY,"");
			SETCHAR(tBAPIE1MBEWX->VCLASS_PY,"");
			SETCHAR(tBAPIE1MBEWX->PR_UNIT_PY,"");
			SETCHAR(tBAPIE1MBEWX->FUTURE_PR,"");
			SETCHAR(tBAPIE1MBEWX->VALID_FROM,"");
			SETCHAR(tBAPIE1MBEWX->TAXPRICE_1,"");
			SETCHAR(tBAPIE1MBEWX->COMMPRICE1,"");
			SETCHAR(tBAPIE1MBEWX->TAXPRICE_3,"");
			SETCHAR(tBAPIE1MBEWX->COMMPRICE3,"");
			SETCHAR(tBAPIE1MBEWX->PLND_PRICE,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRICE1,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRICE2,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRICE3,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRDATE1,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRDATE2,"");
			SETCHAR(tBAPIE1MBEWX->PLNDPRDATE3,"");
			SETCHAR(tBAPIE1MBEWX->LIFO_FIFO,"");
			SETCHAR(tBAPIE1MBEWX->POOLNUMBER,"");
			SETCHAR(tBAPIE1MBEWX->TAXPRICE_2,"");
			SETCHAR(tBAPIE1MBEWX->COMMPRICE2,"");
			SETCHAR(tBAPIE1MBEWX->DEVAL_IND,"");
			SETCHAR(tBAPIE1MBEWX->ML_ACTIVE,"");
			SETCHAR(tBAPIE1MBEWX->ML_SETTLE,"");
			SETCHAR(tBAPIE1MBEWX->ORIG_MAT,"X");
			SETCHAR(tBAPIE1MBEWX->VM_SO_STK,"");
			SETCHAR(tBAPIE1MBEWX->VM_P_STOCK,"");
			SETCHAR(tBAPIE1MBEWX->MATL_USAGE,"");
			SETCHAR(tBAPIE1MBEWX->IN_HOUSE,"");
			SETCHAR(tBAPIE1MBEWX->TAX_CML_UN,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_EXTERNAL,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_GUID,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_VERSION,"");*/
			SETCHAR(tBAPIE1MBEW->FUNCTION,"UPD");
			SETCHAR(tBAPIE1MBEW->Material,batches[PartIndex].part_noDup);
			SETCHAR(tBAPIE1MBEW->ValArea,batches[PartIndex].splantcode);
			SETCHAR(tBAPIE1MBEW->ValType,sval_type);
			SETCHAR(tBAPIE1MBEW->DelFlag,"");
			SETCHAR(tBAPIE1MBEW->PriceCtrl,"");
			SETBCD(tBAPIE1MBEW->MovingPr,"",4);
			SETBCD(tBAPIE1MBEW->StdPrice,"",4);
			SETBCD(tBAPIE1MBEW->PriceUnit,"",0);
			SETCHAR(tBAPIE1MBEW->ValClass,aval_class[val_type]);
			SETCHAR(tBAPIE1MBEW->PrCtrlPp,"");
			SETBCD(tBAPIE1MBEW->MovPrPp,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->StdPrPp,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PrUnitPp,"",0);
			SETCHAR(tBAPIE1MBEW->VclassPp,"");
			SETCHAR(tBAPIE1MBEW->PrCtrlPy,"");
			SETBCD(tBAPIE1MBEW->MovPrPy,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->StdPrPy,myzeroDup4,4);
			SETCHAR(tBAPIE1MBEW->VclassPy,"");
			SETBCD(tBAPIE1MBEW->PrUnitPy,"",0);
			SETCHAR(tBAPIE1MBEW->ValCat,valuation_cat);
			SETBCD(tBAPIE1MBEW->FuturePr,myzeroDup4,4);
			SETDATE(tBAPIE1MBEW->ValidFrom,"");
			SETBCD(tBAPIE1MBEW->Taxprice1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Commprice1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Taxprice3,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Commprice3,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->PlndPrice,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Plndprice1,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Plndprice2,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Plndprice3,myzeroDup4,4);
			SETDATE(tBAPIE1MBEW->Plndprdate1,"");
			SETDATE(tBAPIE1MBEW->Plndprdate2,"");
			SETDATE(tBAPIE1MBEW->Plndprdate3,"");
			SETCHAR(tBAPIE1MBEW->LifoFifo,"");
			SETCHAR(tBAPIE1MBEW->Poolnumber,"");
			SETBCD(tBAPIE1MBEW->Taxprice2,myzeroDup4,4);
			SETBCD(tBAPIE1MBEW->Commprice2,myzeroDup4,4);
			SETNUM(tBAPIE1MBEW->DevalInd,"");
			SETCHAR(tBAPIE1MBEW->OrigGroup,batches[PartIndex].origin_group);
			SETCHAR(tBAPIE1MBEW->OverheadGrp,batches[PartIndex].overhd_grp);
			SETCHAR(tBAPIE1MBEW->QtyStruct,"");
			SETCHAR(tBAPIE1MBEW->MlActive,"");
			SETCHAR(tBAPIE1MBEW->MlSettle,"");
			SETCHAR(tBAPIE1MBEW->OrigMat,"X");
			SETCHAR(tBAPIE1MBEW->VmSoStk,"");
			SETCHAR(tBAPIE1MBEW->VmPStock,"");
			SETCHAR(tBAPIE1MBEW->MatlUsage,"");
			SETCHAR(tBAPIE1MBEW->MatOrigin,"X");
			SETCHAR(tBAPIE1MBEW->InHouse,"");
			SETBCD(tBAPIE1MBEW->TaxCmlUn,"",0);
			SETCHAR(tBAPIE1MBEW->ACCOUNT_VIEW,"X");
			SETCHAR(tBAPIE1MBEW->COST_VIEW,"X");
			SETCHAR(tBAPIE1MBEW->MATERIAL_EXTERNAL,"");
			SETCHAR(tBAPIE1MBEW->MATERIAL_GUID,"");
			SETCHAR(tBAPIE1MBEW->MATERIAL_VERSION,"");


			SETCHAR(tBAPIE1MBEWX->FUNCTION,"UPD");
			SETCHAR(tBAPIE1MBEWX->Material,batches[PartIndex].part_noDup);
			SETCHAR(tBAPIE1MBEWX->ValArea,batches[PartIndex].splantcode);
			SETCHAR(tBAPIE1MBEWX->ValType,sval_type);
			SETCHAR(tBAPIE1MBEWX->DelFlag,"");
			SETCHAR(tBAPIE1MBEWX->PriceCtrl,"");
			SETCHAR(tBAPIE1MBEWX->MovingPr,"");
			SETCHAR(tBAPIE1MBEWX->StdPrice,"");
			SETCHAR(tBAPIE1MBEWX->PriceUnit,"");
			SETCHAR(tBAPIE1MBEWX->ValClass,"X");
			SETCHAR(tBAPIE1MBEWX->PrCtrlPp,"");
			SETCHAR(tBAPIE1MBEWX->MovPrPp,"");
			SETCHAR(tBAPIE1MBEWX->StdPrPp,"");
			SETCHAR(tBAPIE1MBEWX->PrUnitPp,"");
			SETCHAR(tBAPIE1MBEWX->VclassPp,"");
			SETCHAR(tBAPIE1MBEWX->PrCtrlPy,"");
			SETCHAR(tBAPIE1MBEWX->MovPrPy,"");
			SETCHAR(tBAPIE1MBEWX->StdPrPy,"");
			SETCHAR(tBAPIE1MBEWX->VclassPy,"");
			SETCHAR(tBAPIE1MBEWX->PrUnitPy,"");
			SETCHAR(tBAPIE1MBEWX->ValCat,"X");
			SETCHAR(tBAPIE1MBEWX->FuturePr,"");
			SETCHAR(tBAPIE1MBEWX->ValidFrom,"");
			SETCHAR(tBAPIE1MBEWX->Taxprice1,"");
			SETCHAR(tBAPIE1MBEWX->Commprice1,"");
			SETCHAR(tBAPIE1MBEWX->Taxprice3,"");
			SETCHAR(tBAPIE1MBEWX->Commprice3,"");
			SETCHAR(tBAPIE1MBEWX->PlndPrice,"");
			SETCHAR(tBAPIE1MBEWX->Plndprice1,"");
			SETCHAR(tBAPIE1MBEWX->Plndprice2,"");
			SETCHAR(tBAPIE1MBEWX->Plndprice3,"");
			SETCHAR(tBAPIE1MBEWX->Plndprdate1,"");
			SETCHAR(tBAPIE1MBEWX->Plndprdate2,"");
			SETCHAR(tBAPIE1MBEWX->Plndprdate3,"");
			SETCHAR(tBAPIE1MBEWX->LifoFifo,"");
			SETCHAR(tBAPIE1MBEWX->Poolnumber,"");
			SETCHAR(tBAPIE1MBEWX->Taxprice2,"");
			SETCHAR(tBAPIE1MBEWX->Commprice2,"");
			SETCHAR(tBAPIE1MBEWX->DevalInd,"");
			SETCHAR(tBAPIE1MBEWX->OrigGroup,"X");
			SETCHAR(tBAPIE1MBEWX->OverheadGrp,"X");
			SETCHAR(tBAPIE1MBEWX->QtyStruct,"");
			SETCHAR(tBAPIE1MBEWX->MlActive,"");
			SETCHAR(tBAPIE1MBEWX->MlSettle,"");
			SETCHAR(tBAPIE1MBEWX->OrigMat,"X");
			SETCHAR(tBAPIE1MBEWX->VmSoStk,"");
			SETCHAR(tBAPIE1MBEWX->VmPStock,"");
			SETCHAR(tBAPIE1MBEWX->MatlUsage,"");
			SETCHAR(tBAPIE1MBEWX->MatOrigin,"X");
			SETCHAR(tBAPIE1MBEWX->InHouse,"");
			SETCHAR(tBAPIE1MBEWX->TaxCmlUn,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_EXTERNAL,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_GUID,"");
			SETCHAR(tBAPIE1MBEWX->MATERIAL_VERSION,"");

		}
		//SETCHAR(eRMMG1_AENNR.Aennr,batches[PartIndex].dml_no_arg);
	}
	printf("\n4");fflush(stdout);
	SETCHAR(eRMMG1_AENNR.Aennr,dml_no_arg);

	printf("\nItFill(thBAPIE1MBEW):[%d]",ItFill(thBAPIE1MBEW));

	RfcRc = new_zrfc_ac_view_create(hRfc,&eNOAPPLLOG,&eNOCHANGEDOC,&eTESTRUN,&eINPFLDCHECK,&eFLAG_CAD_CALL,&eNO_ROLLBACK_WORK,
	&eFLAG_ONLINE,&eRMMG1_AENNR,& iRETURN,thBAPIE1MATHEADER,thBAPIE1MBEW,thBAPIE1MBEWX,thBAPIRET2,xException);
	printf("\n5");fflush(stdout);
	switch (RfcRc)
	{
		case RFC_OK:
			NL;
			NL;
			fprintf(fsuccess,"\n\n");
			F_OUTK("Batches create",10,30,"");

			GETCHAR(iRETURN.Type,s);
			F_OUTK("TYPE",10,30,s);
			GETCHAR(iRETURN.Id,s);
			F_OUTK("ID",10,30,s);
			GETNUM(iRETURN.Number,s);
			F_OUTK("NUMBER",10,30,s);
			GETCHAR(iRETURN.Message,s);
			F_OUTK("BATCHES CREATE MESSAGE",10,30,s);
			GETCHAR(iRETURN.Log_No,s);
			F_OUTK("LOG_NO",10,30,s);
			GETNUM(iRETURN.Log_Msg_No,s);
			F_OUTK("LOG_MSG_NO",10,30,s);
			GETCHAR(iRETURN.Message_V1,s);
			F_OUTK("MESSAGE_V1",10,30,s);
			GETCHAR(iRETURN.Message_V2,s);
			F_OUTK("MESSAGE_V2",10,30,s);
			GETCHAR(iRETURN.Message_V3,s);
			F_OUTK("MESSAGE_V3",10,30,s);
			GETCHAR(iRETURN.Message_V4,s);
			F_OUTK("MESSAGE_V4",10,30,s);
			GETCHAR(iRETURN.Parameter,s);
			F_OUTK("PARAMETER",10,30,s);
			GETINT(iRETURN.Row,s);
			F_OUTK("ROW",10,30,s);
			GETCHAR(iRETURN.Field,s);
			F_OUTK("FIELD",10,30,s);
			GETCHAR(iRETURN.System,s);
			F_OUTK("SYSTEM",10,30,s);
			NL;
			NL;

			printf("\nItFill(thBAPIRET2):[%d]\n",ItFill(thBAPIRET2));fflush(stdout);
			for (crow = 1;crow <= ItFill(thBAPIRET2); crow++)
			{
				tBAPIRET2 = ItGetLine(thBAPIRET2,crow);
				if (tBAPIRET2 == NULL)
					rfc_error("ItGetLineBAPIRET2");

				GETCHAR(tBAPIRET2->Type,s);
				stripBlanks(s);
				F_OUTK("TYPE",10,30,s);
				GETCHAR(tBAPIRET2->Id,s);
				stripBlanks(s);
				F_OUTK("ID",10,30,s);
				GETNUM(tBAPIRET2->Number,s);
				stripBlanks(s);
				F_OUTK("NUMBER",10,30,s);
				GETCHAR(tBAPIRET2->Message,s);
				stripBlanks(s);
				strcat(s," ");
				strcat(s,retPartnumber);
				F_OUTK("BATCHES CREATE MESSAGE",10,30,s);
				GETCHAR(tBAPIRET2->Log_No,s);
				stripBlanks(s);
				
				F_OUTK("LOG_NO",10,30,s);
				GETNUM(tBAPIRET2->Log_Msg_No,s);
				stripBlanks(s);
				
				F_OUTK("LOG_MSG_NO",10,30,s);
				GETCHAR(tBAPIRET2->Message_V1,s);
				stripBlanks(s);
				
				F_OUTK("MESSAGE_V1",10,30,s);
				stripBlanks(s);
				
				strcpy(retPartnumber,"");
				strcpy(retPartnumber,s);
				GETCHAR(tBAPIRET2->Message_V2,s);
				stripBlanks(s);
				
				F_OUTK("MESSAGE_V2",10,30,s);
				GETCHAR(tBAPIRET2->Message_V3,s);
				stripBlanks(s);
				
				F_OUTK("MESSAGE_V3",10,30,s);
				GETCHAR(tBAPIRET2->Message_V4,s);
				stripBlanks(s);
				
				F_OUTK("MESSAGE_V4",10,30,s);
				GETCHAR(tBAPIRET2->Parameter,s);
				F_OUTK("PARAMETER",10,30,s);
				stripBlanks(s);
				
				GETINT(tBAPIRET2->Row,s);
				stripBlanks(s);
				
				F_OUTK("ROW",10,30,s);
				GETCHAR(tBAPIRET2->Field,s);
				stripBlanks(s);
				
				F_OUTK("FIELD",10,30,s);
				GETCHAR(tBAPIRET2->System,s);
				stripBlanks(s);
				
				F_OUTK("SYSTEM",10,30,s);
				NL;

			}
			/*printf("\nItFill(thBAPIE1MBEW):[%d]\n",ItFill(thBAPIE1MBEW));fflush(stdout);
			printf("\nItFill(thBAPIE1MBEWX):[%d]\n",ItFill(thBAPIE1MBEWX));fflush(stdout);
			for (crow = 1;crow <= ItFill(thBAPIE1MBEW); crow++)
			{
				tBAPIE1MBEW = ItGetLine(thBAPIE1MBEW,crow);
				if (tBAPIE1MBEW == NULL)
					rfc_error("ItGetLineBAPIE1MBEWX");

				GETCHAR(tBAPIE1MBEW->FUNCTION,s); F_OUTK("FUNCTION",10,30,s);
				GETCHAR(tBAPIE1MBEW->Material,s); F_OUTK("Material",10,30,s);
				GETCHAR(tBAPIE1MBEW->ValArea,s); F_OUTK("ValArea",10,30,s);
				GETCHAR(tBAPIE1MBEW->ValType,s); F_OUTK("ValType",10,30,s);
				GETCHAR(tBAPIE1MBEW->ValClass,s); F_OUTK("ValClass",10,30,s);
				GETCHAR(tBAPIE1MBEW->ValCat,s); F_OUTK("ValCat",10,30,s);
				GETCHAR(tBAPIE1MBEW->OrigGroup,s); F_OUTK("OrigGroup",10,30,s);
				GETCHAR(tBAPIE1MBEW->OverheadGrp,s); F_OUTK("OverheadGrp",10,30,s);
				GETCHAR(tBAPIE1MBEW->OrigMat,s); F_OUTK("OrigMat",10,30,s);
			}

			for (crow = 1;crow <= ItFill(thBAPIE1MBEWX); crow++)
			{
				tBAPIE1MBEWX = ItGetLine(thBAPIE1MBEWX,crow);
				if (tBAPIE1MBEWX == NULL)
					rfc_error("ItGetLineBAPIE1MBEWX");

				GETCHAR(tBAPIE1MBEWX->FUNCTION,s); F_OUTK("FUNCTION",10,30,s);
				GETCHAR(tBAPIE1MBEWX->Material,s); F_OUTK("Material",10,30,s);
				GETCHAR(tBAPIE1MBEWX->ValArea,s); F_OUTK("ValArea",10,30,s);
				GETCHAR(tBAPIE1MBEWX->ValType,s); F_OUTK("ValType",10,30,s);
				GETCHAR(tBAPIE1MBEWX->ValClass,s); F_OUTK("ValClass",10,30,s);
				GETCHAR(tBAPIE1MBEWX->ValCat,s); F_OUTK("ValCat",10,30,s);
				GETCHAR(tBAPIE1MBEWX->OrigGroup,s); F_OUTK("OrigGroup",10,30,s);
				GETCHAR(tBAPIE1MBEWX->OverheadGrp,s); F_OUTK("OverheadGrp",10,30,s);
				GETCHAR(tBAPIE1MBEWX->OrigMat,s); F_OUTK("OrigMat",10,30,s);
			}*/
			break;
		case RFC_EXCEPTION:
			printf("\nRFC EXCEPTION: %s",xException);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			break;
		case RFC_FAILURE:
			printf("\nFailure");
			break;
		default:
			printf("\nOther Failure");
			break;
	}
	printf("\n5");fflush(stdout);
	if (ItDelete(thBAPIE1MATHEADER) != 0) rfc_error("ItDelete thBAPIE1MATHEADER");
	if (ItDelete(thBAPIE1MBEW) != 0) rfc_error("ItDelete thBAPIE1MBEW");
	if (ItDelete(thBAPIE1MBEWX) != 0) rfc_error("ItDelete thBAPIE1MBEWX");
	if (ItDelete(thBAPIRET2) != 0) rfc_error("ItDelete thBAPIE1MBEWX");
	printf("\n6");fflush(stdout);
	RfcClose(hRfc);

}

RFC_RC new_zrfc_ac_view_create(RFC_HANDLE hRfc,NOAPPLLOG *eNOAPPLLOG,NOCHANGEDOC *eNOCHANGEDOC,TESTRUN *eTESTRUN,
INPFLDCHECK *eINPFLDCHECK,FLAG_CAD_CALL *eFLAG_CAD_CALL,NO_ROLLBACK_WORK *eNO_ROLLBACK_WORK,FLAG_ONLINE *eFLAG_ONLINE,
RMMG1_AENNR* eRMMG1_AENNR,BAPIRET2* iRETURN,ITAB_H thBAPIE1MATHEADER,ITAB_H thBAPIE1MBEW,ITAB_H thBAPIE1MBEWX,ITAB_H thBAPIRET2,char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[9];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[5];
	char *RfcException = NULL;

	Exporting[0].name = "NOAPPLLOG";
	Exporting[0].nlen = 9;
	Exporting[0].type = handleOfNOAPPLLOG;
	Exporting[0].leng = sizeof(NOAPPLLOG);
	Exporting[0].addr = eNOAPPLLOG;

	Exporting[1].name = "NOCHANGEDOC";
	Exporting[1].nlen = 11;
	Exporting[1].type = handleOfNOCHANGEDOC;
	Exporting[1].leng = sizeof(NOCHANGEDOC);
	Exporting[1].addr = eNOCHANGEDOC;

	Exporting[2].name = "TESTRUN";
	Exporting[2].nlen = 7;
	Exporting[2].type = handleOfTESTRUN;
	Exporting[2].leng = sizeof(TESTRUN);
	Exporting[2].addr = eTESTRUN;

	Exporting[3].name = "INPFLDCHECK";
	Exporting[3].nlen = 11;
	Exporting[3].type = handleOfINPFLDCHECK;
	Exporting[3].leng = sizeof(INPFLDCHECK);
	Exporting[3].addr = eINPFLDCHECK;

	Exporting[4].name = "FLAG_CAD_CALL";
	Exporting[4].nlen = 13;
	Exporting[4].type = handleOfFLAG_CAD_CALL;
	Exporting[4].leng = sizeof(FLAG_CAD_CALL);
	Exporting[4].addr = eFLAG_CAD_CALL;

	Exporting[5].name = "NO_ROLLBACK_WORK";
	Exporting[5].nlen = 16;
	Exporting[5].type = handleOfNO_ROLLBACK_WORK;
	Exporting[5].leng = sizeof(NO_ROLLBACK_WORK);
	Exporting[5].addr = eNO_ROLLBACK_WORK;

	Exporting[6].name = "FLAG_ONLINE";
	Exporting[6].nlen = 11;
	Exporting[6].type = handleOfFLAG_ONLINE;
	Exporting[6].leng = sizeof(FLAG_ONLINE);
	Exporting[6].addr = eFLAG_ONLINE;


	Exporting[7].name = "CHANGE_NUMBER";
	Exporting[7].nlen = 13;
	Exporting[7].type = handleOfRMMG1_AENNR;
	Exporting[7].leng = sizeof(RMMG1_AENNR);
	Exporting[7].addr = eRMMG1_AENNR;


	Exporting[8].name = NULL;


	Tables[0].name     = "HEADDATA";
	Tables[0].nlen     = 8;
	Tables[0].type     = handleOfBAPIE1MATHEADER;
	Tables[0].ithandle = thBAPIE1MATHEADER;

	Tables[1].name     = "VALUATIONDATA";
	Tables[1].nlen     = 13;
	Tables[1].type     = handleOfBAPIE1MBEW;
	Tables[1].ithandle = thBAPIE1MBEW;

	Tables[2].name     = "VALUATIONDATAX";
	Tables[2].nlen     = 14;
	Tables[2].type     = handleOfBAPIE1MBEWX;
	Tables[2].ithandle = thBAPIE1MBEWX;

	Tables[3].name     = "RETURNMESSAGES";
	Tables[3].nlen     = 14;
	Tables[3].type     = handleOfBAPIRET2;
	Tables[3].ithandle = thBAPIRET2;


	Tables[4].name = NULL;


	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEREPLICA",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = handleOfBAPIRET2;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = iRETURN;

			Importing[1].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:;
			}
			default:;
	}
	return RfcRc;

}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2; //no. of query input arg
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* iFileName = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;

	static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];
	
	char text_line[500];
	FILE *InpFile = NULL;
	int lineCount = 1;

    plantcode=(char *) malloc (500 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(500 * sizeof(char));
	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));


	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	iFileName = ITK_ask_cli_argument("-f=");
	//inputPart = ITK_ask_cli_argument("-i=");
	iPlantCode = ITK_ask_cli_argument("-j=");
	//MatCrChFlag = ITK_ask_cli_argument("-f=");
	dml_no_arg = ITK_ask_cli_argument("-c=");
	iSapServer = ITK_ask_cli_argument("-s=");//uncomment 11.07.2023 Hrishikesh

	tc_strdup("CR",&MatCrChFlag);
	//tc_strdup("PVP",&iSapServer);


	InpFile = fopen(iFileName,"r");


	/*if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputPart,"")==0 || tc_strcmp(iPlantCode,"")==0 || tc_strcmp(MatCrChFlag,"")==0 || tc_strcmp(dml_no_arg,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nPartMatCreChangeUA -u=userid -p=password -i=inputPart -j=PlantCode -f=CRCHFlag -c=sap_change_no -s=PVP\n");fflush(stdout);
		goto CLEANUP;
	}*/

	//sprintf(fsuccess_name,"/user/uaprodtrl/PLMSAP/ONE_TIME_LOG/ValTypeCreate_.log");
	sprintf(fsuccess_name,"%s/PLMSAP/ONE_TIME_LOG/ValTypeCreate_%s_%s.log",getenv("ONLREP"),dml_no_arg,iSapServer); //added Hrishikesh 11.07.2023
	//sprintf(fsuccess_name,"APL_Sap_Mat_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	//if(QRY_find("QueryDesignRev", &queryTag));

	while (fscanf(InpFile, "%s", text_line)!=EOF)
	{

		printf("\nLine Number : %d\n",lineCount);
		printf("\n%s",text_line);

		tc_strdup(text_line,&inputPart);
		lineCount++;

		if(QRY_find("Driver VC Query", &queryTag));
		if (queryTag)
		{
			printf("\nFound Query QueryDesignRev\n");fflush(stdout);
		}
		else
		{
			printf("\nNotFound Query QueryDesignRev");fflush(stdout);
			goto CLEANUP;
		}
		
		printf("\nQueryig input Part %s\n ", inputPart);fflush(stdout);

		Lcs = (char *) MEM_alloc(1000);
		//tc_strcpy(Lcs,"APLC Released"); 
		//tc_strcpy(Lcs,"T5_LcsAplRlzd"); 

		//Added Hrishikesh 11.07.2023
		if (tc_strcmp(iPlantCode,"1100")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplRlzd"); 
		}
		
		if (tc_strcmp(iPlantCode,"1001")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplpRlzd"); 
		}

		if (tc_strcmp(iPlantCode,"3100")==0)
		{
			tc_strcpy(Lcs,"T5_LcsApluRlzd"); 
		}

		if (tc_strcmp(iPlantCode,"1500")==0)
		{
			tc_strcpy(Lcs,"T5_LcsApldRlzd"); 
		}
		//added Hrishikesh 02.10.2023
		if (tc_strcmp(iPlantCode,"E201")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplaRlzd"); 
		}
		//end Hrishikesh 02.10.2023


		qry_values[0] = inputPart;
		qry_values[1] = Lcs;

		//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
		//1-Ascending 2- Descending
		ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

		printf("\nPart Found Count %d", resultCount);fflush(stdout);

		if(resultCount>0)
		{
			LatestRev=outTag[0];
		}
		else
		{
			printf("\nPart %s Not found APL Released in TCUA\n", inputPart);fflush(stdout);
			continue;
		}

		ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
		printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

		//if(tc_strstr(PartRelStatus,"APLC Released")!=NULL || tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
		//added Hrishikesh 11.07.2023
		if(((tc_strcmp(iPlantCode,"1100")==0) && (tc_strstr(PartRelStatus,"APLC Released")!=NULL || tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"1001")==0) && (tc_strstr(PartRelStatus,"APLP Released")!=NULL || tc_strstr(PartRelStatus,"STDSIP Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"1500")==0) && (tc_strstr(PartRelStatus,"APLD Released")!=NULL || tc_strstr(PartRelStatus,"STDSID Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"3100")==0) && (tc_strstr(PartRelStatus,"APLU Released")!=NULL || tc_strstr(PartRelStatus,"STDSIU Released")!=NULL)) ||  //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"E201")==0) && (tc_strstr(PartRelStatus,"APLA Released")!=NULL || tc_strstr(PartRelStatus,"STDSIA Released")!=NULL)))   //added Hrishikesh 02.10.2023
		{
			printf("\nPartRelStatus: %s\n",PartRelStatus);
		}
		else
		{
			printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
			fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
			continue;
		}
			
		tc_strdup("ERC",&OrgIDDup);

		if(FetchPlantSpecificData(iPlantCode)>0)
		{
			printf("\nGot Plant Specific Data...\n");fflush(stdout);
		}
		else
		{
			printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
			goto CLEANUP;
		}
		
		tc_strdup(iPlantCode,&plantcode);

		if(tc_strcmp(plantcode,"")==0)
		{
			printf("\nPlant code is null hence exit"); fflush(stdout);
			fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
			goto CLEANUP;
		}

		strcpy(myzeroDup1,"0.0");
		strcpy(myzeroDup2,"0.00");
		strcpy(myzeroDup3,"0.000");
		strcpy(myzeroDup4,"0.0000");

		printf("\nCosting Overhead Group: %s", origin_group);

		ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
		tc_strdup(part_type,&part_typeDup);

		ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&part_noDup));

		printf("\nPart Type: %s", part_typeDup);
		printf("\npart_noDup: %s\n", part_noDup);

		if(	tc_strcmp(part_typeDup,"D")==0 ||
			tc_strcmp(part_typeDup,"DA")==0 ||
			tc_strcmp(part_typeDup,"DC")==0 ||
			tc_strcmp(part_typeDup,"IFD")==0 ||
			tc_strcmp(part_typeDup,"IM")==0 ||
			tc_strcmp(part_typeDup,"CP")==0)
		{
			printf("\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
			fprintf(fsuccess,"\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
			continue;
		}
		
		//CR-FY21-0218
		if (tc_strlen(part_noDup)==12)
		{
			if(STRNG_find_last_char(part_noDup,'R')!=NULL || STRNG_find_last_char(part_noDup,'L')!=NULL)
			{
				if (
					tc_strcmp(part_typeDup,"VC")==0 ||
					tc_strcmp(part_typeDup,"CCVC")==0 ||
					tc_strcmp(part_typeDup,"VCCR")==0 ||
					tc_strcmp(part_typeDup,"CKDVC") == 0 ||
					tc_strcmp(part_typeDup,"SKDVC") == 0
				 )
				{
					printf("\nPart %s and PartType %s Found OK\n",part_noDup,part_type);
				}
				else
				{
					printf("\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
					fprintf(fsuccess,"\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
					goto CLEANUP;
				}
			}
			else
			{
				printf("\nPart %s and PartType %s Normal 12-Digit Part\n",part_noDup,part_type);
			}
		}


		printf("\nPart Number : [%s] Part Type : [%s]",part_noDup,part_typeDup);

		strcpy(part_noDupDes,part_noDup);
		strcpy(part_noDupDesx,part_noDup);

		if(tc_strlen(part_type)>0)
		{
			if (tc_strcmp(part_typeDup, "C") == 0 ||
				tc_strcmp(part_typeDup, "A") == 0 ||
				tc_strcmp(part_typeDup, "G") == 0 )
			{
				tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "M") == 0)
			{
				tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "V") == 0)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "T") == 0)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if((tc_strcmp(part_typeDup, "VC") == 0)	||
					(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
					(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
					(tc_strcmp(part_typeDup, "CCVC") == 0)	||
					(tc_strcmp(part_typeDup, "VCCR") == 0)
					)
			{
				tc_strcpy(mat_type,"FERT");
			}
			else if (tc_strcmp(part_typeDup,"DTPL")==0)
			{
				tc_strcpy(mat_type, "HALB");
			}
			else if (tc_strcmp(part_typeDup,"SA")==0)  // added on 17.03.2016 for 16 digit stage assembly of 60R TPL disintegration 
			{
				tc_strcpy(mat_type, "HALB");
			}
			else if (len == 12 || len == 14)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if (len == 10 || len == 11)
			{
					tc_strcpy(mat_type,"ROH");
			}
			else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
			{
				if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
				{
					tc_strcpy(mat_type,"HALB");
				}
			}
			

			printf("\nMaterial Type: %s", mat_type); /*part_type = acr_ind*/
		}
		else
		{
			printf("\nPart Type for the part %s is NULL",part_noDup);
			fprintf(fsuccess,"\nMSG RCVD:Part Type for the part %s is NULL",part_noDup);
			continue;
		}

		if(tc_strcmp(mat_type,"FERT") != 0)
		{
				tc_strcpy(batches[PartbatchCounter].part_noDup,part_noDup);
				tc_strcpy(batches[PartbatchCounter].mat_type,mat_type);
				tc_strcpy(batches[PartbatchCounter].splantcode,plantcode);
				tc_strcpy(batches[PartbatchCounter].dml_no_arg,dml_no_arg);
				tc_strcpy(batches[PartbatchCounter].origin_group,origin_group);
				tc_strcpy(batches[PartbatchCounter].overhd_grp,overhd_grp);
				PartbatchCounter = PartbatchCounter + 1 ;
		}
		else
		{
			printf("\nMaterial Type is FERT, Skipping");
			continue;
		}

		PartCounter = PartCounter + 1 ;

	}//File Loop

	cll_zrfc_ac_view_create();

	/*	printf("\nList of %d parts with inspction alloc create\n",PartinspallocCounter);
	for ( i = 0 ; i < PartinspallocCounter ; i++ )
	{
		F_OUTK("INSP ALLOC MATERIAL",10,30,inspalloc[i].part_noDup);
	}
	*/
	printf("\nList of %d parts with batches create\n",PartbatchCounter);
	for ( i = 0 ; i < PartbatchCounter ; i++ )
	{
		F_OUTK("BATCHES MATERIAL",10,30,batches[i].part_noDup);
	}

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
