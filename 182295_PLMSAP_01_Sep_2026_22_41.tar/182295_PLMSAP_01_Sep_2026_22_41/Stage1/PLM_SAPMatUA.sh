. /user/uaprod/.bash_profile
tdate=`date +"%d-%h-%Y" --date="0 days ago"`
ydate=`date +"%d-%h-%Y" --date="1 days ago"`
stime="00:00"
inptime="$ydate $stime"
echo "Today's Date is :: $tdate"
echo "Yesterday's Input Date is :: $inptime"

echo "Getting Released ERC DMLs on Date :: $inptime"

/user/plmsap/PLMSAP/liveXfr/GetRelDmlList -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -d=$inptime

if test -s /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt`
	do
	echo "Transfering DML Number : $i"
		/user/plmsap/PLMSAP/liveXfr/ercSAPMatUA -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -d=$i -s=PVP
		/user/plmsap/PLMSAP/liveXfr/ercSAPMatUA -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -d=$i -s=CVP
	done

	for i in `cat /user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt`
	do
		if test -s /user/plmsap/PLMSAP/PLM_SAP_ERC_LOG/Erc_Sap_Mat_$i.log
		then
		grep -ie "has been created or extended" -ie "already exists" -ie "Revision Creation Message" /user/plmsap/PLMSAP/PLM_SAP_ERC_LOG/Erc_Sap_Mat_$i.log >> /user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/ERCTransferStat_$tdate.txt
		fi
	done
fi

if test -s /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt`
	do
	echo "Transfering DML Number : $i"
		/user/plmsap/PLMSAP/liveXfr/AplDmlSapMatCreateUA -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -d=$i -s=PVP
	done

	for i in `cat /user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt`
	do
		if test -s /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_$i.log
		then
		grep -ie "Mesage for Material Create" -ie "Message for Material" -ie "insptype_alloc" -ie "Batches Create" -ie "Makebuy indicator is NA" /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_$i.log >> /user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/APLTransferStat_$tdate.txt
		fi
	done
fi




ErcDmlFile=/user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_$ydate.txt
ERCFileConf=/tmp/ErcDmlReleasedOn_"$ydate".conf
ErcDmlMsgFile=/user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/ERCTransferStat_$tdate.txt

echo $ErcDmlFile
echo $ErcDmlMsgFile

rm -rf "$ERCFileConf"
touch "$ERCFileConf"
echo "To:devkantk.ttl@tatamotors.com, tusharr1.ttl@tatamotors.com, amoln.ttl@tatamotors.com, prasadb1.ttl@tatamotors.com, hs.ttl@tatamotors.com" >> "$ERCFileConf"
echo "Cc:manishaj.ttl@tatamotors.com" >> "$ERCFileConf"
echo "SUBJECT:ERC DML TCUA-SAP Transfer from UAPROD" >> "$ERCFileConf"
echo 'MIME-Version: 1.0' >> "$ERCFileConf"
echo 'Content-Type: text/html; charset='us-ascii'' >> "$ERCFileConf"
echo 'Content-Disposition: inline' >> "$ERCFileConf"
echo "" >> "$ERCFileConf"
echo '<SPAN><font face="verdana" color="red">'
echo "Dear All,<BR/><BR/>Below ERC DMLs transferred to SAP from UAPROD on $tdate.<BR/>" >> "$ERCFileConf"
while read line
do
echo $line >> "$ERCFileConf"
echo "<BR/>" >> "$ERCFileConf"
done < $ErcDmlFile
while read line
do
echo $line >> "$ERCFileConf"
echo "<BR/>" >> "$ERCFileConf"
done < $ErcDmlMsgFile
echo '</SPAN>' >>  "$ERCFileConf"
/usr/sbin/sendmail -i -t < "$ERCFileConf"


AplDmlFile=/user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_$ydate.txt
APLFileConf=/tmp/AplDmlReleasedOn_"$ydate".conf
AplDmlMsgFile=/user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/APLTransferStat_$tdate.txt

echo $AplDmlFile
echo $AplDmlMsgFile

rm -rf "$APLFileConf"
touch "$APLFileConf"
echo "To:To:devkantk.ttl@tatamotors.com, tusharr1.ttl@tatamotors.com, amoln.ttl@tatamotors.com, prasadb1.ttl@tatamotors.com, hs.ttl@tatamotors.com" >> "$APLFileConf"
echo "Cc:manishaj.ttl@tatamotors.com" >> "$APLFileConf"
echo "SUBJECT:APL DML TCUA-SAP Transfer from UAPROD" >> "$APLFileConf"
echo 'MIME-Version: 1.0' >> "$APLFileConf"
echo 'Content-Type: text/html; charset='us-ascii'' >> "$APLFileConf"
echo 'Content-Disposition: inline' >> "$APLFileConf"
echo "" >> "$APLFileConf"
echo '<SPAN><font face="verdana" color="red">'
echo "Dear All,<BR/><BR/>Below APL DMLs transferred to SAP from UAPROD on $tdate.<BR/>" >> "$APLFileConf"
while read line
do
echo $line >> "$APLFileConf"
echo "<BR/>" >> "$APLFileConf"
done < $AplDmlFile
while read line
do
echo $line >> "$APLFileConf"
echo "<BR/>" >> "$APLFileConf"
done < $AplDmlMsgFile
echo '</SPAN>' >>  "$APLFileConf"
/usr/sbin/sendmail -i -t < "$APLFileConf"
