/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : TaskSVRTransfer.c
* Created By                   : Devkant Kedar/Amol Narke
* Created On                   : 11/07/2021
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : Task Wise SVR Bom transfer to SAP
* Specific Notes               : TaskSVRTransfer -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -s=PVP -t=task_no
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <time.h>
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
//#include "bapi.h"
#include "svr.h"

//#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define GETCHAR(var,str) sprintf(str,"%.*s",sizeof(var),var)
#define GETINT(var,str) sprintf(str,"%ld",var);

int Basic2Mrp3ViewSvr(char*sVcMaterialNo, char* sKmatMaterialNo, char* sPlantCode, char** sap_opt_name, int* iSapOptCnt, char *sSvrRevision, char *dSvrDate);

char *iSapServer = NULL;
char *timestamp = NULL;

FILE* fsuccess;
char fsuccess_name[200];

int FindSendSVR(tag_t LatestRev);


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}


void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);
void rfc_error(char *operation);
RFC_HANDLE BapiLogon(void);

void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);

/*void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}*/

char *replaceWord(const char *s, const char *oldW, const char *newW) 
{ 
    char *result; 
    int i = 0;
	int cnt = 0; 
    int newWlen = strlen(newW); 
    int oldWlen = strlen(oldW); 
//	printf("\nstart");fflush(stdout);

//	printf("\ns:%s",s);fflush(stdout);
//	printf("\nnewWlen:%d:	newW:%s:",newWlen,newW);fflush(stdout);
//	printf("\noldWlen:%d:	oldW:%s:",oldWlen,oldW);fflush(stdout);
    // Counting the number of times old word 
    // occur in the string 
    for (i = 0; s[i] != '\0'; i++) 
    { 
        if (strstr(&s[i], oldW) == &s[i]) 
        { 
            cnt++; 
  
            // Jumping to index after the old word. 
            i += oldWlen - 1; 
        } 
    } 
//	printf("\nMid1");fflush(stdout);
//	printf("\nMid i:%d",i);fflush(stdout);
//	printf("\nMid cnt:%d",cnt);fflush(stdout);
    // Making new string of enough length 
//	printf("\ni + cnt * (newWlen - oldWlen) + 1:[%d]",(i + cnt * (newWlen - oldWlen) + 1));
    result = (char *)malloc(i + (cnt * (newWlen - oldWlen)) + 1); 
    //result = (char *)MEM_alloc(i + (cnt * (newWlen - oldWlen)) + 1); 
//	printf("\nMid2");fflush(stdout);
    i = 0; 
    while (*s) 
    { 
        // compare the substring with the result 
        if (strstr(s, oldW) == s) 
        { 
            strcpy(&result[i], newW); 
            i += newWlen; 
            s += oldWlen; 
        } 
        else
            result[i++] = *s++; 
    } 
  
    result[i] = '\0'; 
//	printf("\nresult:%s",result);fflush(stdout);
//	printf("\nEnd");fflush(stdout);
    return result; 
} 
static tag_t ask_item_revision_from_bom_line(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITK_CALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

RFC_RC zpprfc_config_mat_linking(
						RFC_HANDLE hRfc,
						MATNR_DK *eMATNR_DK,
						WERKS_D_DK *eWERKS_D_DK,
						STLAN_DK *eSTLAN_DK,
						STLAL_DK *eSTLAL_DK,
						BAPIRET2 *iRETURN,
						RETVAL *iSy_subrc_DK,
						char *xException)
{
		RFC_PARAMETER Exporting[5];
		//RFC_PARAMETER Exporting[1];
		//RFC_PARAMETER Importing[3];
		RFC_PARAMETER Importing[3];
		RFC_TABLE Tables[1];
		RFC_RC RfcRc;
		char *RfcException = NULL;

		Exporting[0].name = "MATERIAL";
		Exporting[0].nlen = 8;
		Exporting[0].type = handleOfMATNR_DK ;
		Exporting[0].leng = sizeof ( MATNR_DK ) ;
		Exporting[0].addr = eMATNR_DK ;

		Exporting[1].name = "PLANT";
		Exporting[1].nlen = 5;
		Exporting[1].type = handleOfWERKS_D_DK ;
		Exporting[1].leng = sizeof ( WERKS_D_DK ) ;
		Exporting[1].addr = eWERKS_D_DK ;

		Exporting[2].name = "BOM_USAGE";
		Exporting[2].nlen = 9;
		Exporting[2].type = handleOfSTLAN_DK ;
		Exporting[2].leng = sizeof (STLAN_DK ) ;
		Exporting[2].addr = eSTLAN_DK ;

		Exporting[3].name = "ALTERNATE_BOM";
		Exporting[3].nlen = 13;
		Exporting[3].type = handleOfSTLAL_DK ;
		Exporting[3].leng = sizeof ( STLAL_DK ) ;
		Exporting[3].addr = eSTLAL_DK ;

		Exporting[4].name = NULL;
		//Exporting[0].name = NULL;

		Tables[0].name = NULL;

		RfcRc = RfcCall(hRfc,"ZPPRFC_CONFIG_MAT_LINKING",Exporting,Tables);

		switch (RfcRc)
		{
			case RFC_OK :

				Importing[0].name = "RETVAL";
				Importing[0].nlen = 6;
				Importing[0].type = handleOfRETVAL;
				Importing[0].leng = sizeof(RETVAL);
				Importing[0].addr = iSy_subrc_DK;

				Importing[1].name = "MESSG";
				Importing[1].nlen = 5;
				Importing[1].type = handleOfBAPIRET2;
				Importing[1].leng = sizeof(BAPIRET2);
				Importing[1].addr = iRETURN;

				Importing[2].name = NULL;

				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

				switch (RfcRc)
				{
					case RFC_SYS_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					case RFC_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					default:;
				}
			break;
			default :
				printf("\nNOT RFC OK");
		}
  return RfcRc;
}

int cll_zpprfc_config_mat_linking ( char *VcNumber, char *Plant )
{
	RFC_HANDLE hRfc ;
	RFC_RC RfcRc ;
	char xException[256]  = { 0 } ;
	char s[1024]  = { 0 } ;
	MATNR_DK eMATNR_DK ;
	WERKS_D_DK eWERKS_D_DK ;
	STLAN_DK eSTLAN_DK ;
	STLAL_DK eSTLAL_DK ;
	RETVAL iSy_subrc_DK ;
	BAPIRET2 iReturn ;

	hRfc = BapiLogon ( ) ;

	SETCHAR(eMATNR_DK.MATERIAL,VcNumber);
	SETCHAR(eWERKS_D_DK.PLANT,Plant);
	SETCHAR(eSTLAN_DK.BOM_USAGE,"1");
	SETCHAR(eSTLAL_DK.ALTERNATE_BOM,"01");

	printf("\nLinking [%s,%s]\n",VcNumber,Plant);
	fprintf(fsuccess,"\nLinking [%s,%s]\n",VcNumber,Plant);
	printf("\ncalling ZPPRFC_CONFIG_MAT_LINKING");

	RfcRc = zpprfc_config_mat_linking 
					( 
						hRfc,
						&eMATNR_DK,
						&eWERKS_D_DK,
						&eSTLAN_DK,
						&eSTLAL_DK,
						&iReturn,
						&iSy_subrc_DK,
						xException
					);
	switch (RfcRc)
	{
		case RFC_OK :
			GETINT(iSy_subrc_DK.RETVAL,s);
			OUTS("RETVAL",10,30,s);

			GETCHAR(iReturn.Type,s);
            OUTS("TYPE",10,30,s);
            GETCHAR(iReturn.Id,s);
            OUTS("ID",10,30,s);
            GETNUM(iReturn.Number,s);
            OUTS("NUMBER",10,30,s);
            GETCHAR(iReturn.Message,s);
            OUTS("MESSAGE",10,30,s);
            GETCHAR(iReturn.LogNo,s);
            OUTS("LOG_NO",10,30,s);
            GETNUM(iReturn.LogMsgNo,s);
            OUTS("LOG_MSG_NO",10,30,s);
            GETCHAR(iReturn.MessageV1,s);
            OUTS("MESSAGE_V1",10,30,s);
            GETCHAR(iReturn.MessageV2,s);
            OUTS("MESSAGE_V2",10,30,s);
            GETCHAR(iReturn.MessageV3,s);
            OUTS("MESSAGE_V3",10,30,s);
            GETCHAR(iReturn.MessageV4,s);
            OUTS("MESSAGE_V4",10,30,s);
            GETCHAR(iReturn.Parameter,s);
            OUTS("PARAMETER",10,30,s);
            GETINT(iReturn.Row,s);
            OUTS("ROW",10,30,s);
            GETCHAR(iReturn.Field,s);
            OUTS("FIELD",10,30,s);
            GETCHAR(iReturn.System,s);
            OUTS("SYSTEM",10,30,s);
            //OUT("RETURN",8); 
		
		break;
		case RFC_EXCEPTION :
			printf("\n");
			rfc_error("RFC_EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION :
			printf("\n");
			rfc_error("RFC_SYS_EXCEPTION");
		break;
		case RFC_FAILURE :
			printf("\n");
			rfc_error("RFC_FAILURE");
		break;
		default :
			printf("\nOTHER FAILURE");
			rfc_error("default");
	}
	RfcClose(hRfc);
	return 0 ;
}

RFC_RC ZMATERIAL_SAVE_CONFIGURATION(RFC_HANDLE hRfc
									,MARA_MATNR *eMATNR1
									,SATNR *eSatnr
									,MARC_WERKS *eWerks
									,STDPD *eStdpd
									,REVLV *eREVLV
									,DATUV *eDATUV
									,BAPIRET2 *iRETURN
									,ITAB_H thE1CUCFG
									,ITAB_H thE1CUINS
									,ITAB_H thE1CUVAL
									,ITAB_H thE1CUCOM
									,ITAB_H thE1CUCFG_W
									,ITAB_H thE1CUINS_W
									,ITAB_H thE1CUVAL_W
									,ITAB_H thE1CUCOM_W
									,ITAB_H thE1CUCFG_V
									,ITAB_H thE1CUINS_V
									,ITAB_H thE1CUVAL_V
									,ITAB_H thE1CUCOM_V
									,ITAB_H thRETURNMESSAGES
									,char *xException
									)
{
	RFC_RC RfcRc;
	//RFC_PARAMETER Exporting[5];
	RFC_PARAMETER Exporting[7];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[10];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = TYPC;
	Exporting[0].leng = sizeof(MARA_MATNR);
	Exporting[0].addr = eMATNR1;

	Exporting[1].name = "CONF_MATL";
	Exporting[1].nlen = 9;
	Exporting[1].type = TYPC;
	Exporting[1].leng = sizeof(SATNR);
	Exporting[1].addr = eSatnr;

	Exporting[2].name = "PLANT";
	Exporting[2].nlen = 5;
	Exporting[2].type = TYPC;
	Exporting[2].leng = sizeof(MARC_WERKS);
	Exporting[2].addr = eWerks;

	Exporting[3].name = "CONF_MATL_PLANT";
	Exporting[3].nlen = 15;
	Exporting[3].type = TYPC;
	Exporting[3].leng = sizeof(STDPD);
	Exporting[3].addr = eStdpd;

	//Exporting[4].name = NULL;

	Exporting[4].name = "REV_LEVEL";
	Exporting[4].nlen = 9;
	Exporting[4].type = TYPC;
	Exporting[4].leng = sizeof(REVLV);
	Exporting[4].addr = eREVLV;

	Exporting[5].name = "DATE";
	Exporting[5].nlen = 4;
	Exporting[5].type = TYPDATE;
	Exporting[5].leng = sizeof(DATUV);
	Exporting[5].addr = eDATUV;

	Exporting[6].name = NULL;


	Tables[0].name     = "E1CUCFG";
	Tables[0].nlen     = 7;
	Tables[0].type     = handleOfE1CUCFG;
	Tables[0].ithandle = thE1CUCFG;

	Tables[1].name     = "E1CUINS";
	Tables[1].nlen     = 7;
	Tables[1].type     = handleOfE1CUINS;
	Tables[1].ithandle = thE1CUINS;

	Tables[2].name     = "E1CUVAL";
	Tables[2].nlen     = 7;
	Tables[2].type     = handleOfE1CUVAL;
	Tables[2].ithandle = thE1CUVAL;

	Tables[3].name     = "E1CUCOM";
	Tables[3].nlen     = 7;
	Tables[3].type     = handleOfE1CUCOM;
	Tables[3].ithandle = thE1CUCOM;

	Tables[4].name     = "E1CUCFG_W";
	Tables[4].nlen     = 9;
	Tables[4].type     = handleOfE1CUCFG_W;
	Tables[4].ithandle = thE1CUCFG_W;

	Tables[5].name     = "E1CUINS_W";
	Tables[5].nlen     = 9;
	Tables[5].type     = handleOfE1CUINS_W;
	Tables[5].ithandle = thE1CUINS_W;

	Tables[6].name     = "E1CUVAL_W";
	Tables[6].nlen     = 9;
	Tables[6].type     = handleOfE1CUVAL_W;
	Tables[6].ithandle = thE1CUVAL_W;

	Tables[7].name     = "E1CUCOM_W";
	Tables[7].nlen     = 9;
	Tables[7].type     = handleOfE1CUCOM_W;
	Tables[7].ithandle = thE1CUCOM_W;

	Tables[8].name     = "RETURNMESSAGES";
	Tables[8].nlen     = 14;
	Tables[8].type     = handleOfRETURNMESSAGES;
	Tables[8].ithandle = thRETURNMESSAGES;

	Tables[9].name = NULL;

	/*Tables[8].name     = "E1CUCFG_V";
	Tables[8].nlen     = 9;
	Tables[8].type     = handleOfE1CUCFG_V;
	Tables[8].ithandle = thE1CUCFG_V;

	Tables[9].name     = "E1CUINS_V";
	Tables[9].nlen     = 9;
	Tables[9].type     = handleOfE1CUINS_V;
	Tables[9].ithandle = thE1CUINS_V;

	Tables[10].name     = "E1CUVAL_V";
	Tables[10].nlen     = 9;
	Tables[10].type     = handleOfE1CUVAL_V;
	Tables[10].ithandle = thE1CUVAL_V;

	Tables[11].name     = "E1CUCOM_V";
	Tables[11].nlen     = 9;
	Tables[11].type     = handleOfE1CUCOM_V;
	Tables[11].ithandle = thE1CUCOM_V;

	Tables[12].name     = "RETURNMESSAGES";
	Tables[12].nlen     = 14;
	Tables[12].type     = handleOfRETURNMESSAGES;
	Tables[12].ithandle = thRETURNMESSAGES;

	Tables[13].name = NULL;
	*/

	//RfcRc = RfcCall(hRfc,"ZMATERIAL_SAVE_CONFIGURATION",Exporting,Tables);
	//RfcRc = RfcCall(hRfc,"ZMATERIAL_SAVE_CONFIGURATION_2",Exporting,Tables);
	RfcRc = RfcCall(hRfc,"ZMATERIAL_SAVE_CONFIG_NEW",Exporting,Tables);
	switch (RfcRc)
	{
		case RFC_OK :

			Importing[0].name = "RETURN";
			Importing[0].nlen = 6;
			Importing[0].type = handleOfBAPIRET2;
			Importing[0].leng = sizeof(BAPIRET2);
			Importing[0].addr = iRETURN;

			Importing[1].name = NULL;


			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
		
			switch (RfcRc)
			{
				case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:;
			}
		break;
		default :
			printf("\nin default");
	}
return RfcRc;
}

int Basic2Mrp3ViewSvr(char*sVcMaterialNo, char* sKmatMaterialNo, char* sPlantCode, char** sap_opt_name, int* iSapOptCnt, char *sSvrRevision, char *dSvrDate)
{
	char xException[256];
	char s[1024] = {0};
	int crow = 0;
	int iOptCntr = 0;
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MARA_MATNR eMATNR1;
	SATNR eSatnr;
	MARC_WERKS eWerks;
	STDPD eStdpd;
	REVLV eREVLV;
	DATUV eDATUV;


	BAPIRET2 iRETURN;
	ITAB_H thE1CUCFG = ITAB_NULL;
	E1CUCFG *tE1CUCFG;
	ITAB_H thE1CUINS = ITAB_NULL;
	E1CUINS *tE1CUINS;
	ITAB_H thE1CUVAL = ITAB_NULL;
	E1CUVAL *tE1CUVAL;
	ITAB_H thE1CUCOM = ITAB_NULL;
	E1CUCOM *tE1CUCOM;
	ITAB_H thE1CUCFG_W = ITAB_NULL;
	E1CUCFG_W *tE1CUCFG_W;
	ITAB_H thE1CUINS_W = ITAB_NULL;
	E1CUINS_W *tE1CUINS_W;
	ITAB_H thE1CUVAL_W = ITAB_NULL;
	E1CUVAL_W *tE1CUVAL_W;
	ITAB_H thE1CUCOM_W = ITAB_NULL;
	E1CUCOM_W *tE1CUCOM_W;
	ITAB_H thE1CUCFG_V = ITAB_NULL;
	E1CUCFG_V *tE1CUCFG_V;
	ITAB_H thE1CUINS_V = ITAB_NULL;
	E1CUINS_V *tE1CUINS_V;
	ITAB_H thE1CUVAL_V = ITAB_NULL;
	E1CUVAL_V *tE1CUVAL_V;
	ITAB_H thE1CUCOM_V = ITAB_NULL;
	E1CUCOM_V *tE1CUCOM_V;
	ITAB_H thRETURNMESSAGES = ITAB_NULL;
	RETURNMESSAGES *tRETURNMESSAGES;
	int lSapOptCnt = 0;
	hRfc = BapiLogon();

	printf("\n");fflush(stdout);
	OUTS("SVR",10,30,sVcMaterialNo);
	OUTS("KMAT",10,30,sKmatMaterialNo);
	OUTS("PlantCode",10,30,sPlantCode);

	printf("\nSVR Details : [%s,%s,%s,%s,%s]\n",sVcMaterialNo,sSvrRevision,sKmatMaterialNo,sPlantCode,dSvrDate);fflush(stdout);
	fprintf(fsuccess,"\nSVR Details : [%s,%s,%s,%s,%s]\n",sVcMaterialNo,sSvrRevision,sKmatMaterialNo,sPlantCode,dSvrDate);fflush(stdout);

	SETCHAR(eMATNR1,sVcMaterialNo);//sVcMaterialNo
	SETCHAR(eWerks,sPlantCode);//sPlantCode
	SETCHAR(eSatnr,sKmatMaterialNo);//kmat
	SETCHAR(eStdpd,sKmatMaterialNo);//kmat
	SETCHAR(eREVLV,sSvrRevision);//revision, dSvrDate
	SETDATE(eDATUV,dSvrDate);//date

	//table1
	if(thE1CUCFG==ITAB_NULL)
	{
		thE1CUCFG = ItCreate("E1CUCFG",sizeof(E1CUCFG), 0, 0);
		if(thE1CUCFG == ITAB_NULL)
			printf("\nItCreate E1CUCFG");
	}
	else if(ItFree(thE1CUCFG) != 0)
		printf("\nItFree E1CUCFG");

	tE1CUCFG = ItAppLine(thE1CUCFG);
	if (tE1CUCFG == NULL)
	printf("ItAppLine tE1CUCFG");

	SETCHAR(tE1CUCFG->POSEX,sPlantCode);
	SETCHAR(tE1CUCFG->CONFIG_ID,"000001");
	SETCHAR(tE1CUCFG->ROOT_ID,"00000001");
	SETCHAR(tE1CUCFG->SCE,"");
	SETCHAR(tE1CUCFG->KBNAME,"");
	SETCHAR(tE1CUCFG->KBVERSION,"");
	SETCHAR(tE1CUCFG->COMPLETE,"T");
	SETCHAR(tE1CUCFG->CONSISTENT,"T");
	SETCHAR(tE1CUCFG->CFGINFO,"");
	SETCHAR(tE1CUCFG->KBPROFILE,"");
	SETCHAR(tE1CUCFG->KBLANGUAGE,"");
	SETCHAR(tE1CUCFG->CBASE_ID,"");
	SETCHAR(tE1CUCFG->CBASE_ID_TYPE,"");
	//table2
	if(thE1CUINS==ITAB_NULL)
	{
		thE1CUINS = ItCreate("E1CUINS",sizeof(E1CUINS), 0, 0);
		if(thE1CUINS == ITAB_NULL)
			printf("\nItCreate E1CUINS");
	}
	else if(ItFree(thE1CUINS) != 0)
		printf("\nItFree E1CUINS");

	tE1CUINS = ItAppLine(thE1CUINS);
	if (tE1CUINS == NULL)
	printf("ItAppLine tE1CUINS");

	SETCHAR(tE1CUINS->INST_ID,"00000001");
	SETCHAR(tE1CUINS->OBJ_TYPE,"MARA");
	SETCHAR(tE1CUINS->CLASS_TYPE,"300");
	SETCHAR(tE1CUINS->OBJ_KEY,sKmatMaterialNo);//kmat
	SETCHAR(tE1CUINS->OBJ_TXT,"");
	SETCHAR(tE1CUINS->QUANTITY,"1");
	SETCHAR(tE1CUINS->AUTHOR,"");
	SETCHAR(tE1CUINS->QUANTITY_UNIT,"EA");
	SETCHAR(tE1CUINS->COMPLETE,"T");
	SETCHAR(tE1CUINS->CONSISTENT,"T");
	SETCHAR(tE1CUINS->OBJECT_GUID,sKmatMaterialNo);//kmat
	SETCHAR(tE1CUINS->PERSIST_ID,"");
	SETCHAR(tE1CUINS->PERSIST_ID_TYPE,"");

	//table4
	if(thE1CUCOM==ITAB_NULL)
	{
		thE1CUCOM = ItCreate("E1CUCOM",sizeof(E1CUCOM), 0, 0);
		if(thE1CUCOM == ITAB_NULL)
			printf("\nItCreate E1CUCOM");
	}
	else if(ItFree(thE1CUCOM) != 0)
		printf("\nItFree E1CUCOM");

	tE1CUCOM = ItAppLine(thE1CUCOM);
	if (tE1CUCOM == NULL)
	printf("ItAppLine tE1CUCOM");

	SETCHAR(tE1CUCOM->MSGFN,"023");
	SETCHAR(tE1CUCOM->C_PROFILE,sKmatMaterialNo);//PROFILE FOR X4 values was "X4" on QA
	SETCHAR(tE1CUCOM->CLASSTYPE ,"300");
	SETCHAR(tE1CUCOM->ORGAREAS,"");
	SETCHAR(tE1CUCOM->STATUS,"1");
	SETCHAR(tE1CUCOM->BOMAPPL,"");
	SETCHAR(tE1CUCOM->FLAVAILCH,"");
	SETCHAR(tE1CUCOM->BOMEXPL ,"1");
	SETCHAR(tE1CUCOM->TASKLEXPL,"");
	SETCHAR(tE1CUCOM->INITSCREEN,"");
	SETCHAR(tE1CUCOM->FLASSEMBLY,"");
	SETCHAR(tE1CUCOM->FLRESULT,"");
	SETCHAR(tE1CUCOM->FLMDATA,"");
	SETCHAR(tE1CUCOM->FLCASONLY,"");
	SETCHAR(tE1CUCOM->FLMANCHANG,"");
	SETCHAR(tE1CUCOM->FLHOLDBOM,"");
	SETCHAR(tE1CUCOM->FLDELETE,"");
	SETCHAR(tE1CUCOM->DESIGN,"");
	SETCHAR(tE1CUCOM->NEUTR,"");
	SETCHAR(tE1CUCOM->CHAR_VALU,"2");
	SETCHAR(tE1CUCOM->A_LAISO,"");
	SETCHAR(tE1CUCOM->SCOPE_CHAR,"");
	SETCHAR(tE1CUCOM->SCOPE_VALU,"");
	SETCHAR(tE1CUCOM->FL_EXCLUDE,"");
	SETCHAR(tE1CUCOM->DISPLAY,"");
	SETCHAR(tE1CUCOM->PRICING,"");
	SETCHAR(tE1CUCOM->CONFIGUR,"");
	SETCHAR(tE1CUCOM->DEFVALU_DE,"");
	SETCHAR(tE1CUCOM->FL_MARK,"");
	SETCHAR(tE1CUCOM->DEFVALU_CC,"");
	SETCHAR(tE1CUCOM->TYPM_SEL,"");
	SETCHAR(tE1CUCOM->TYPM_STRA,"");
	SETCHAR(tE1CUCOM->FL_SC_CHAR,"");
	SETCHAR(tE1CUCOM->FL_SC_DEP,"");
	SETCHAR(tE1CUCOM->FL_SC_KN,"");
	SETCHAR(tE1CUCOM->FL_SC_CMPF,"");
	SETCHAR(tE1CUCOM->MULTIL_STRU,"");
	SETCHAR(tE1CUCOM->FL_DPSEU,"");
	SETCHAR(tE1CUCOM->OB_FIX,"");
	SETCHAR(tE1CUCOM->OB_INST,"");
	SETCHAR(tE1CUCOM->FL_EOASL,"");
	SETCHAR(tE1CUCOM->FL_SAASL,"");
	SETCHAR(tE1CUCOM->FL_OBJ_MAT,"");
	SETCHAR(tE1CUCOM->FL_OBJ_DOC,"");
	SETCHAR(tE1CUCOM->FL_OBJ_CLS ,"");
	SETCHAR(tE1CUCOM->FL_OBJ_TXT,"");
	SETCHAR(tE1CUCOM->FL_SDREL,"");
	SETCHAR(tE1CUCOM->FL_KOREL,"");
	SETCHAR(tE1CUCOM->FL_FEREL,"");
	SETCHAR(tE1CUCOM->FL_INREL,"");
	SETCHAR(tE1CUCOM->FL_KAREL,"");
	SETCHAR(tE1CUCOM->POSTYPEN,"");
	SETCHAR(tE1CUCOM->SORTF1,"");
	SETCHAR(tE1CUCOM->SORTF2,"");
	SETCHAR(tE1CUCOM->SORTF3,"");
	SETCHAR(tE1CUCOM->SORTF4,"");
	SETCHAR(tE1CUCOM->SORTF5,"");
	SETCHAR(tE1CUCOM->CLASSF1,"");
	SETCHAR(tE1CUCOM->CLASSF2,"");
	SETCHAR(tE1CUCOM->CLASSF3,"");
	SETCHAR(tE1CUCOM->CLASSF4,"");
	SETCHAR(tE1CUCOM->CLASSF5,"");
	SETCHAR(tE1CUCOM->PRIO,"");
	SETCHAR(tE1CUCOM->PRSTL,"");
	SETCHAR(tE1CUCOM->UMBEW,"");
	SETCHAR(tE1CUCOM->FLBROWSER,"");
	SETCHAR(tE1CUCOM->FL_PROF_OBOM,"");

	//table5
	if(thE1CUCFG_W==ITAB_NULL)
	{
		thE1CUCFG_W = ItCreate("E1CUCFG_W",sizeof(E1CUCFG_W), 0, 0);
		if(thE1CUCFG_W == ITAB_NULL)
			printf("\nItCreate E1CUCFG_W");
	}
	else if(ItFree(thE1CUCFG_W) != 0)
		printf("\nItFree E1CUCFG_W");

	tE1CUCFG_W = ItAppLine(thE1CUCFG_W);
	if (tE1CUCFG_W == NULL)
	printf("ItAppLine tE1CUCFG_W");

	SETCHAR(tE1CUCFG_W->POSEX,sPlantCode);
	SETCHAR(tE1CUCFG_W->CONFIG_ID,"000001");
	SETCHAR(tE1CUCFG_W->ROOT_ID,"00000001");
	SETCHAR(tE1CUCFG_W->SCE,"");
	SETCHAR(tE1CUCFG_W->KBNAME,"");
	SETCHAR(tE1CUCFG_W->KBVERSION,"");
	SETCHAR(tE1CUCFG_W->COMPLETE,"T");
	SETCHAR(tE1CUCFG_W->CONSISTENT,"T");
	SETCHAR(tE1CUCFG_W->CFGINFO,"");
	SETCHAR(tE1CUCFG_W->KBPROFILE,"");
	SETCHAR(tE1CUCFG_W->KBLANGUAGE,"");
	SETCHAR(tE1CUCFG_W->CBASE_ID,"");
	SETCHAR(tE1CUCFG_W->CBASE_ID_TYPE,"");

	//table6
	if(thE1CUINS_W==ITAB_NULL)
	{
		thE1CUINS_W = ItCreate("E1CUINS_W",sizeof(E1CUINS_W), 0, 0);
		if(thE1CUINS_W == ITAB_NULL)
			printf("\nItCreate E1CUINS_W");
	}
	else if(ItFree(thE1CUINS_W) != 0)
		printf("\nItFree E1CUINS_W");


	tE1CUINS_W = ItAppLine(thE1CUINS_W);
	if (tE1CUINS_W == NULL)
	printf("ItAppLine tE1CUINS_W");

	SETCHAR(tE1CUINS_W->INST_ID,"00000001");
	SETCHAR(tE1CUINS_W->OBJ_TYPE,"MARA");
	SETCHAR(tE1CUINS_W->CLASS_TYPE,"300");
	SETCHAR(tE1CUINS_W->OBJ_KEY,sKmatMaterialNo);//kmat
	SETCHAR(tE1CUINS_W->OBJ_TXT,"");
	SETCHAR(tE1CUINS_W->QUANTITY,"1");
	SETCHAR(tE1CUINS_W->AUTHOR,"");
	SETCHAR(tE1CUINS_W->QUANTITY_UNIT,"EA");
	SETCHAR(tE1CUINS_W->COMPLETE,"T");
	SETCHAR(tE1CUINS_W->CONSISTENT,"T");
	SETCHAR(tE1CUINS_W->OBJECT_GUID,sKmatMaterialNo);//kmat
	SETCHAR(tE1CUINS_W->PERSIST_ID,"");
	SETCHAR(tE1CUINS_W->PERSIST_ID_TYPE,"");

	//table8
	if(thE1CUCOM_W==ITAB_NULL)
	{
		thE1CUCOM_W = ItCreate("E1CUCOM_W",sizeof(E1CUCOM_W), 0, 0);
		if(thE1CUCOM_W == ITAB_NULL)
			printf("\nItCreate E1CUCOM_W");
	}
	else if(ItFree(thE1CUCOM_W) != 0)
		printf("\nItFree E1CUCOM_W");

	tE1CUCOM_W = ItAppLine(thE1CUCOM_W);
	if (tE1CUCOM_W == NULL)
	printf("ItAppLine tE1CUCOM_W");

	SETCHAR(tE1CUCOM_W->MSGFN,"023");
	SETCHAR(tE1CUCOM_W->C_PROFILE,sKmatMaterialNo);//PROFILE FOR X4 values was "X4" on QA
	SETCHAR(tE1CUCOM_W->CLASSTYPE,"300");
	SETCHAR(tE1CUCOM_W->ORGAREAS,"");
	SETCHAR(tE1CUCOM_W->STATUS,"1");
	SETCHAR(tE1CUCOM_W->BOMAPPL,"");
	SETCHAR(tE1CUCOM_W->FLAVAILCH,"");
	SETCHAR(tE1CUCOM_W->BOMEXPL ,"1");
	SETCHAR(tE1CUCOM_W->TASKLEXPL,"");
	SETCHAR(tE1CUCOM_W->INITSCREEN,"");
	SETCHAR(tE1CUCOM_W->FLASSEMBLY,"");
	SETCHAR(tE1CUCOM_W->FLRESULT,"");
	SETCHAR(tE1CUCOM_W->FLMDATA,"");
	SETCHAR(tE1CUCOM_W->FLCASONLY,"");
	SETCHAR(tE1CUCOM_W->FLMANCHANG,"");
	SETCHAR(tE1CUCOM_W->FLHOLDBOM,"");
	SETCHAR(tE1CUCOM_W->FLDELETE,"");
	SETCHAR(tE1CUCOM_W->DESIGN,"");
	SETCHAR(tE1CUCOM_W->NEUTR,"");
	SETCHAR(tE1CUCOM_W->CHAR_VALU,"2");
	SETCHAR(tE1CUCOM_W->A_LAISO,"");
	SETCHAR(tE1CUCOM_W->SCOPE_CHAR,"");
	SETCHAR(tE1CUCOM_W->SCOPE_VALU,"");
	SETCHAR(tE1CUCOM_W->FL_EXCLUDE,"");
	SETCHAR(tE1CUCOM_W->DISPLAY,"");
	SETCHAR(tE1CUCOM_W->PRICING,"");
	SETCHAR(tE1CUCOM_W->CONFIGUR,"");
	SETCHAR(tE1CUCOM_W->DEFVALU_DE,"");
	SETCHAR(tE1CUCOM_W->FL_MARK,"");
	SETCHAR(tE1CUCOM_W->DEFVALU_CC,"");
	SETCHAR(tE1CUCOM_W->TYPM_SEL,"");
	SETCHAR(tE1CUCOM_W->TYPM_STRA,"");
	SETCHAR(tE1CUCOM_W->FL_SC_CHAR,"");
	SETCHAR(tE1CUCOM_W->FL_SC_DEP,"");
	SETCHAR(tE1CUCOM_W->FL_SC_KN,"");
	SETCHAR(tE1CUCOM_W->FL_SC_CMPF,"");
	SETCHAR(tE1CUCOM_W->MULTIL_STRU,"");
	SETCHAR(tE1CUCOM_W->FL_DPSEU,"");
	SETCHAR(tE1CUCOM_W->OB_FIX,"");
	SETCHAR(tE1CUCOM_W->OB_INST,"");
	SETCHAR(tE1CUCOM_W->FL_EOASL,"");
	SETCHAR(tE1CUCOM_W->FL_SAASL,"");
	SETCHAR(tE1CUCOM_W->FL_OBJ_MAT,"");
	SETCHAR(tE1CUCOM_W->FL_OBJ_DOC,"");
	SETCHAR(tE1CUCOM_W->FL_OBJ_CLS,"");
	SETCHAR(tE1CUCOM_W->FL_OBJ_TXT,"");
	SETCHAR(tE1CUCOM_W->FL_SDREL,"");
	SETCHAR(tE1CUCOM_W->FL_KOREL ,"");
	SETCHAR(tE1CUCOM_W->FL_FEREL,"");
	SETCHAR(tE1CUCOM_W->FL_INREL,"");
	SETCHAR(tE1CUCOM_W->FL_KAREL,"");
	SETCHAR(tE1CUCOM_W->POSTYPEN ,"");
	SETCHAR(tE1CUCOM_W->SORTF1,"");
	SETCHAR(tE1CUCOM_W->SORTF2,"");
	SETCHAR(tE1CUCOM_W->SORTF3,"");
	SETCHAR(tE1CUCOM_W->SORTF4,"");
	SETCHAR(tE1CUCOM_W->SORTF5,"");
	SETCHAR(tE1CUCOM_W->CLASSF1,"");
	SETCHAR(tE1CUCOM_W->CLASSF2,"");
	SETCHAR(tE1CUCOM_W->CLASSF3,"");
	SETCHAR(tE1CUCOM_W->CLASSF4,"");
	SETCHAR(tE1CUCOM_W->CLASSF5,"");
	SETCHAR(tE1CUCOM_W->PRIO,"");
	SETCHAR(tE1CUCOM_W->PRSTL,"");
	SETCHAR(tE1CUCOM_W->UMBEW,"");
	SETCHAR(tE1CUCOM_W->FLBROWSER,"");
	SETCHAR(tE1CUCOM_W->FL_PROF_OBOM,"");

	if(thRETURNMESSAGES==ITAB_NULL)
	{
		thRETURNMESSAGES = ItCreate("RETURNMESSAGES",sizeof(RETURNMESSAGES), 0, 0);
		if(thRETURNMESSAGES == ITAB_NULL)
			printf("\nItCreate RETURNMESSAGES");
	}
	else if(ItFree(thRETURNMESSAGES) != 0)
		printf("\nItFree RETURNMESSAGES");

	//table3
	if(thE1CUVAL==ITAB_NULL)
	{
		thE1CUVAL = ItCreate("E1CUVAL",sizeof(E1CUVAL), 0, 0);
		if(thE1CUVAL == ITAB_NULL)
			printf("\nItCreate E1CUVAL");
	}
	else if(ItFree(thE1CUVAL) != 0)
		printf("\nItFree E1CUVAL");

	//table7
	if(thE1CUVAL_W==ITAB_NULL)
	{
		thE1CUVAL_W = ItCreate("E1CUVAL_W",sizeof(E1CUVAL_W), 0, 0);
		if(thE1CUVAL_W == ITAB_NULL)
			printf("\nItCreate E1CUVAL_W");
	}
	else if(ItFree(thE1CUVAL_W) != 0)
		printf("\nItFree E1CUVAL_W");

	lSapOptCnt = *iSapOptCnt;
	//for( iOptCntr = 0; iOptCntr < 16; iOptCntr = iOptCntr + 2 )
	for( iOptCntr = 0; iOptCntr < lSapOptCnt; iOptCntr = iOptCntr + 2 )
	{
		//printf("\nsap_opt_name[%d]->[%40s] = [%60s]",iOptCntr,sap_opt_name[iOptCntr],sap_opt_name[iOptCntr+1]);

		/*if ( iOptCntr >= 426 )
		{
			break;
		}*/
		
		sap_opt_name[iOptCntr] = replaceWord(sap_opt_name[iOptCntr], "'", "");
		sap_opt_name[iOptCntr+1] = replaceWord(sap_opt_name[iOptCntr+1], "'", "");
		
		sap_opt_name[iOptCntr+1][31] = '\0';

		if ( sap_opt_name[iOptCntr+1][tc_strlen(sap_opt_name[iOptCntr+1])-1] == ' ')
		{
			sap_opt_name[iOptCntr+1][tc_strlen(sap_opt_name[iOptCntr+1])-1] = '\0';
		}

		
		if( tc_strstr ( sap_opt_name[iOptCntr] , "--SkipPack" ) != NULL )
		{
			printf("\n[%s] skipping from transfer --SkipPack",sap_opt_name[iOptCntr]);fflush(stdout);
			continue;
		}
		if( tc_strcmp ( sap_opt_name[iOptCntr] , "BASE_PACK" ) == 0 )
		{
			printf("\n[%s] skipping from transfer",sap_opt_name[iOptCntr]);fflush(stdout);
			continue;
		}
		if( tc_strcmp ( sap_opt_name[iOptCntr] , "BASE PACK" ) == 0 )
		{
			printf("\n[%s] skipping from transfer",sap_opt_name[iOptCntr]);fflush(stdout);
			continue;
		}
		if( tc_strcmp ( sap_opt_name[iOptCntr] , "CUSTOM PACK !" ) == 0 )
		{
			printf("\n[%s] skipping from transfer",sap_opt_name[iOptCntr]);fflush(stdout);
			continue;
		}
		/*if( tc_strcmp ( sap_opt_name[iOptCntr] , "SIDE_AIRBAG" ) == 0 )
		{
			printf("\tskipping from transfer");
			continue;
		}
		if( tc_strcmp ( sap_opt_name[iOptCntr] , "VEHICLE_AGGREGATE" ) == 0 )
		{
			printf("\tskipping from transfer");
			continue;
		}*/


		//OUTS(sap_opt_name[iOptCntr],10,30,sap_opt_name[iOptCntr+1]);
		//printf("\nTransferring [%d]->[%s] = [%s][%d]",iOptCntr,sap_opt_name[iOptCntr],sap_opt_name[iOptCntr+1],tc_strlen(sap_opt_name[iOptCntr+1]));

		printf("\nTransferring;%d;%s;%s;%d;",iOptCntr,sap_opt_name[iOptCntr],sap_opt_name[iOptCntr+1],tc_strlen(sap_opt_name[iOptCntr+1]));

		tE1CUVAL = ItAppLine(thE1CUVAL);
		if (tE1CUVAL == NULL)
		printf("ItAppLine tE1CUVAL");

		SETCHAR(tE1CUVAL->INST_ID,"00000001");
		SETCHAR(tE1CUVAL->CHARC,sap_opt_name[iOptCntr]);//option
		SETCHAR(tE1CUVAL->CHARC_TXT,"");
		SETCHAR(tE1CUVAL->VALUE,sap_opt_name[iOptCntr+1]);//value
		SETCHAR(tE1CUVAL->VALUE_TXT,"");
		SETCHAR(tE1CUVAL->AUTHOR,"");
		SETCHAR(tE1CUVAL->VALUE_TO,"");
		SETCHAR(tE1CUVAL->VALCODE,"1");

		
		tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
		if (tE1CUVAL_W == NULL)
		printf("ItAppLine tE1CUVAL_W");

		SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
		SETCHAR(tE1CUVAL_W->CHARC,sap_opt_name[iOptCntr]);//option
		SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
		SETCHAR(tE1CUVAL_W->VALUE,sap_opt_name[iOptCntr+1]);//val
		SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
		SETCHAR(tE1CUVAL_W->AUTHOR,"");
		SETCHAR(tE1CUVAL_W->VALUE_TO,"");
		SETCHAR(tE1CUVAL_W->VALCODE,"1");
	}

	/*tE1CUVAL = ItAppLine(thE1CUVAL);
	if (tE1CUVAL == NULL)
	printf("ItAppLine tE1CUVAL");

	SETCHAR(tE1CUVAL->INST_ID,"00000001");
	SETCHAR(tE1CUVAL->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL->CHARC_TXT,"");
	SETCHAR(tE1CUVAL->VALUE,"BIW");//value
	SETCHAR(tE1CUVAL->VALUE_TXT,"");
	SETCHAR(tE1CUVAL->AUTHOR,"");
	SETCHAR(tE1CUVAL->VALUE_TO,"");
	SETCHAR(tE1CUVAL->VALCODE,"1");

	tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
	if (tE1CUVAL_W == NULL)
	printf("ItAppLine tE1CUVAL_W");

	SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
	SETCHAR(tE1CUVAL_W->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
	SETCHAR(tE1CUVAL_W->VALUE,"BIW");//val
	SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
	SETCHAR(tE1CUVAL_W->AUTHOR,"");
	SETCHAR(tE1CUVAL_W->VALUE_TO,"");
	SETCHAR(tE1CUVAL_W->VALCODE,"1");

	
	tE1CUVAL = ItAppLine(thE1CUVAL);
	if (tE1CUVAL == NULL)
	printf("ItAppLine tE1CUVAL");

	SETCHAR(tE1CUVAL->INST_ID,"00000001");
	SETCHAR(tE1CUVAL->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL->CHARC_TXT,"");
	SETCHAR(tE1CUVAL->VALUE,"CHASSIS");//value
	SETCHAR(tE1CUVAL->VALUE_TXT,"");
	SETCHAR(tE1CUVAL->AUTHOR,"");
	SETCHAR(tE1CUVAL->VALUE_TO,"");
	SETCHAR(tE1CUVAL->VALCODE,"1");

	tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
	if (tE1CUVAL_W == NULL)
	printf("ItAppLine tE1CUVAL_W");

	SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
	SETCHAR(tE1CUVAL_W->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
	SETCHAR(tE1CUVAL_W->VALUE,"CHASSIS");//val
	SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
	SETCHAR(tE1CUVAL_W->AUTHOR,"");
	SETCHAR(tE1CUVAL_W->VALUE_TO,"");
	SETCHAR(tE1CUVAL_W->VALCODE,"1");

	tE1CUVAL = ItAppLine(thE1CUVAL);
	if (tE1CUVAL == NULL)
	printf("ItAppLine tE1CUVAL");

	SETCHAR(tE1CUVAL->INST_ID,"00000001");
	SETCHAR(tE1CUVAL->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL->CHARC_TXT,"");
	SETCHAR(tE1CUVAL->VALUE,"TRIM");//value
	SETCHAR(tE1CUVAL->VALUE_TXT,"");
	SETCHAR(tE1CUVAL->AUTHOR,"");
	SETCHAR(tE1CUVAL->VALUE_TO,"");
	SETCHAR(tE1CUVAL->VALCODE,"1");

	tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
	if (tE1CUVAL_W == NULL)
	printf("ItAppLine tE1CUVAL_W");

	SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
	SETCHAR(tE1CUVAL_W->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
	SETCHAR(tE1CUVAL_W->VALUE,"TRIM");//val
	SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
	SETCHAR(tE1CUVAL_W->AUTHOR,"");
	SETCHAR(tE1CUVAL_W->VALUE_TO,"");
	SETCHAR(tE1CUVAL_W->VALCODE,"1");

	
	tE1CUVAL = ItAppLine(thE1CUVAL);
	if (tE1CUVAL == NULL)
	printf("ItAppLine tE1CUVAL");

	SETCHAR(tE1CUVAL->INST_ID,"00000001");
	SETCHAR(tE1CUVAL->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL->CHARC_TXT,"");
	SETCHAR(tE1CUVAL->VALUE,"POWERTRAIN");//value
	SETCHAR(tE1CUVAL->VALUE_TXT,"");
	SETCHAR(tE1CUVAL->AUTHOR,"");
	SETCHAR(tE1CUVAL->VALUE_TO,"");
	SETCHAR(tE1CUVAL->VALCODE,"1");

	tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
	if (tE1CUVAL_W == NULL)
	printf("ItAppLine tE1CUVAL_W");

	SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
	SETCHAR(tE1CUVAL_W->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
	SETCHAR(tE1CUVAL_W->VALUE,"POWERTRAIN");//val
	SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
	SETCHAR(tE1CUVAL_W->AUTHOR,"");
	SETCHAR(tE1CUVAL_W->VALUE_TO,"");
	SETCHAR(tE1CUVAL_W->VALCODE,"1");

	tE1CUVAL = ItAppLine(thE1CUVAL);
	if (tE1CUVAL == NULL)
	printf("ItAppLine tE1CUVAL");

	SETCHAR(tE1CUVAL->INST_ID,"00000001");
	SETCHAR(tE1CUVAL->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL->CHARC_TXT,"");
	SETCHAR(tE1CUVAL->VALUE,"E & E");//value
	SETCHAR(tE1CUVAL->VALUE_TXT,"");
	SETCHAR(tE1CUVAL->AUTHOR,"");
	SETCHAR(tE1CUVAL->VALUE_TO,"");
	SETCHAR(tE1CUVAL->VALCODE,"1");

	tE1CUVAL_W = ItAppLine(thE1CUVAL_W);
	if (tE1CUVAL_W == NULL)
	printf("ItAppLine tE1CUVAL_W");

	SETCHAR(tE1CUVAL_W->INST_ID,"00000001");
	SETCHAR(tE1CUVAL_W->CHARC,"VEHICLE_AGGREGATE_1");//option
	SETCHAR(tE1CUVAL_W->CHARC_TXT,"");
	SETCHAR(tE1CUVAL_W->VALUE,"E & E");//val
	SETCHAR(tE1CUVAL_W->VALUE_TXT,"");
	SETCHAR(tE1CUVAL_W->AUTHOR,"");
	SETCHAR(tE1CUVAL_W->VALUE_TO,"");
	SETCHAR(tE1CUVAL_W->VALCODE,"1");*/
	//return 0;

	RfcRc = ZMATERIAL_SAVE_CONFIGURATION(hRfc
			,&eMATNR1
			,&eSatnr
			,&eWerks
			,&eStdpd
			,&eREVLV
			,&eDATUV
			,&iRETURN
			,thE1CUCFG
			,thE1CUINS
			,thE1CUVAL
			,thE1CUCOM
			,thE1CUCFG_W
			,thE1CUINS_W
			,thE1CUVAL_W
			,thE1CUCOM_W
			,thE1CUCFG_V
			,thE1CUINS_V
			,thE1CUVAL_V
			,thE1CUCOM_V
			,thRETURNMESSAGES
			,xException);

	switch (RfcRc)
	{
		case RFC_OK:


			printf("\n");fflush(stdout);
			GETCHAR(iRETURN.Message,s);
			OUTS("MESSAGE",10,30,s);
			/*printf("\nno of row fetched thE1CUCFG:[%d]",ItFill(thE1CUCFG));fflush(stdout);
			printf("\nno of row fetched thE1CUINS:[%d]",ItFill(thE1CUINS));fflush(stdout);
			printf("\nno of row fetched thE1CUVAL:[%d]",ItFill(thE1CUVAL));fflush(stdout);
			printf("\nno of row fetched thE1CUCOM:[%d]",ItFill(thE1CUCOM));fflush(stdout);

			printf("\nno of row fetched thE1CUCFG_W:[%d]",ItFill(thE1CUCFG_W));fflush(stdout);
			printf("\nno of row fetched thE1CUINS_W:[%d]",ItFill(thE1CUINS_W));fflush(stdout);
			printf("\nno of row fetched thE1CUVAL_W:[%d]",ItFill(thE1CUVAL_W));fflush(stdout);
			printf("\nno of row fetched thE1CUCOM_W:[%d]",ItFill(thE1CUCOM_W));fflush(stdout);*/

			printf("\nno of row fetched thRETURNMESSAGES:[%d]\n",ItFill(thRETURNMESSAGES));fflush(stdout);
			for (crow = 1;crow <= ItFill(thRETURNMESSAGES); crow++)
			{
				tRETURNMESSAGES = ItGetLine(thRETURNMESSAGES,crow);
				if (tRETURNMESSAGES == NULL)
					printf("ItGetLineBAPIRET2");

				GETCHAR(tRETURNMESSAGES->MESSAGE,s);
				OUTS("MESSAGE",10,30,s);
				GETCHAR(tRETURNMESSAGES->ID,s);
				OUTS("ID",10,30,s);
				GETCHAR(tRETURNMESSAGES->NUMBER,s);
				OUTS("NUMBER",10,30,s);
				GETNUM(tRETURNMESSAGES->MESSAGE,s);
				OUTS("MESSAGE",10,30,s);
				GETCHAR(tRETURNMESSAGES->LOG_NO,s);
				OUTS("LOG_NO",10,30,s);
				GETCHAR(tRETURNMESSAGES->LOG_MSG_NO,s);
				OUTS("LOG_MSG_NO",10,30,s);
				GETNUM(tRETURNMESSAGES->MESSAGE_V1,s);
				OUTS("MESSAGE_V1",10,30,s);
				GETCHAR(tRETURNMESSAGES->MESSAGE_V2,s);
				OUTS("MESSAGE_V2",10,30,s);
				GETCHAR(tRETURNMESSAGES->MESSAGE_V3,s);
				OUTS("MESSAGE_V3",10,30,s);
				GETCHAR(tRETURNMESSAGES->MESSAGE_V4,s);
				OUTS("MESSAGE_V4",10,30,s);
				GETCHAR(tRETURNMESSAGES->PARAMETER,s);
				OUTS("PARAMETER",10,30,s);
				GETCHAR(tRETURNMESSAGES->ROW,s);
				OUTS("ROW",10,30,s);
				GETINT(tRETURNMESSAGES->FIELD,s);
				OUTS("FIELD",10,30,s);
				GETCHAR(tRETURNMESSAGES->SYSTEM,s);
				OUTS("SYSTEM",10,30,s);
			}
		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);fflush(stdout);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");fflush(stdout);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");fflush(stdout);
		break;
		default:
			printf("\nOther Failure!");fflush(stdout);
	}
	RfcClose(hRfc);


return 0;
}

FindSendSVR(tag_t LatestRev)
{
	int status = ITK_ok;
	char *iVarRuleName = NULL;
	char *iNonColSVR = NULL;
	char *sSvrRevision = NULL;
	char *dSvrDate = NULL;
	char *sVcMaterialNo = NULL;
	char *sKmatMaterialNo = NULL;
	char *sPlantCode = NULL;
	tag_t *VariantRuleTags = NULLTAG;
	tag_t tVariantRuleTag = NULLTAG;
	tag_t ColourSVRTag = NULLTAG;
	int n_entries;
	tag_t VariantqueryTag = NULLTAG;
	int resultCount = 0;
	char* sVariantRuleText = NULL;
	char **attrs_name = NULL;
	char **sap_opt_name = NULL;
	char **sap_opt_value = NULL;
	int last_ioc = 0;
	int ioc = 0;
	char* tokstr = {"[" };
	char* option_token = NULL;
	int joc = 0;
	char* equaltok = NULL;
	char *resultRule_2 = NULL;
	char *resultRule_3 = NULL;
	char *resultRule_4 = NULL;
	int jCnt = 0;
	int resultCountOptFam = 0;
	tag_t Optfmly_tag = NULLTAG;
	tag_t *revOptFamVal=NULL;
	char* OptfmlyName=NULL;
	char* OptfmlyDesc=NULL;
	tag_t *revOptFam=NULL;
	char *aformula=NULL;
	char *qry_entries[1] = {"Name"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t queryTagOptFam = NULLTAG;
	char **qry_valuesOptFam = (char **) MEM_alloc(10 * sizeof(char *));
	int n_entriesOptFam = 1;
	char *qry_entriesOptFam[] = {"ID"};
	int koc = 0;
	int iOptCntr = 0;
	int iSapOptCnt = 0;
	char* Sap_opt_tok = NULL;
	char *Optfmly_type = NULL;
	char *SVR_Name = NULL;
	n_entries=1;
	int CSvrCount = 0;
	int Svrfound = 0;
	int c = 0;
	tag_t *ColourSVRTags = NULLTAG;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};
	
	char *CCVCNumber = NULL;
	char *PartRevSeq = NULL;
	char *PartRevDup = NULL;
	char *PartSeqDup = NULL;
	char *PartRelStatus = NULL;
	char *sSVR_Name		= NULL;
	char *sSVR_RelStat = NULL;

	iVarRuleName	= (char *) malloc(20 * sizeof(char));

	//sVcMaterialNo = ITK_ask_cli_argument("-f=");
	//sKmatMaterialNo = ITK_ask_cli_argument("-k=");
	//sPlantCode = ITK_ask_cli_argument("-c=");
	//sSvrRevision = ITK_ask_cli_argument("-r=");
	//dSvrDate = ITK_ask_cli_argument("-d=");	//YYYYMMDD

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_id",&CCVCNumber));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&PartRevSeq));
	PartRevDup = strtok(PartRevSeq,";");
	PartSeqDup = strtok(NULL, ";" );
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));	

	printf("\nCCVC : %s Revision : %s ReleaseStatus %s",CCVCNumber,PartRevDup,PartRelStatus);
	fprintf(fsuccess,"\nCCVC : %s Revision : %s ReleaseStatus %s",CCVCNumber,PartRevDup,PartRelStatus);
	
	tc_strdup(CCVCNumber,&sVcMaterialNo);
	tc_strdup("X4",&sKmatMaterialNo);
	tc_strdup("1100",&sPlantCode);
	tc_strdup(PartRevDup,&sSvrRevision);
	tc_strdup(timestamp,&dSvrDate);

	tc_strcpy(iVarRuleName,"");
	tc_strcpy(iVarRuleName,CCVCNumber);
	tc_strcat(iVarRuleName,"*");

	qry_values[0] = iVarRuleName;
	
	if(QRY_find("VariantRule", &VariantqueryTag));
	//if(QRY_execute(VariantqueryTag, n_entries, qry_entries, qry_values, &resultCount, &VariantRuleTags));
	ITK_CALL(QRY_execute_with_sort(VariantqueryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &VariantRuleTags));

	printf("\nSVR resultCount :%d:\n",resultCount);fflush(stdout);
	fprintf(fsuccess,"\nSVR resultCount :%d:\n",resultCount);fflush(stdout);
	if(resultCount>0)
	{
		printf("\nSVR Found : %s Query Executed Succesfully",iVarRuleName);fflush(stdout);
		tVariantRuleTag = VariantRuleTags[0];

		//current_name 
		ITK_CALL(AOM_ask_value_string(tVariantRuleTag,"current_name",&sSVR_Name));
		ITK_CALL(AOM_UIF_ask_value(tVariantRuleTag,"release_status_list",&sSVR_RelStat));

		
		if(tc_strstr(sSVR_RelStat,"ERC Released")!=NULL)
		{
			printf("\nSVR Name : %s LCS : %s",sSVR_Name,sSVR_RelStat);fflush(stdout);
			fprintf(fsuccess,"\nSVR Name : %s LCS : %s",sSVR_Name,sSVR_RelStat);fflush(stdout);
		}
		else
		{
			printf("\nSVR Name : %s LCS is not ERC Released",sSVR_Name,sSVR_RelStat);fflush(stdout);
			fprintf(fsuccess,"\nSVR Name : %s LCS is not ERC Released",sSVR_Name,sSVR_RelStat);fflush(stdout);
			return status;
		}

		/*ITK_CALL(AOM_ask_value_tags(tVariantRuleTag,"T5_HasColourSVR",&CSvrCount,&ColourSVRTags));

		for (c=0;c<CSvrCount;c++)
		{
			ColourSVRTag = ColourSVRTags[c];
			ITK_CALL(AOM_ask_value_string(ColourSVRTag,"current_name",&SVR_Name));
			if (tc_strcmp(SVR_Name,iVarRuleName)==0)
			{
				printf("\nColour SVR Found : %s On Non-Color SVR\n",SVR_Name);fflush(stdout);
				Svrfound=1;
				break;
			}
			else
			{
				continue;
			}
		}

		if (Svrfound==0)
		{
			printf("\nSVR Not %s found on Non-Color SVR",iVarRuleName);fflush(stdout); 
			//return status;
		}
		
		printf("\nColour SVR Found : %s\n",SVR_Name);fflush(stdout);*/

		//cfg0VariantRuleText
		ITK_CALL(AOM_ask_value_string(tVariantRuleTag,"cfg0VariantRuleText",&sVariantRuleText));

		if ( tc_strlen(sVariantRuleText)>0 )
		{

			//query optionname and description-----------------------
			if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTagOptFam));
			if (queryTagOptFam)
			{
				printf("\nCfg0OptionFamiliesFromIDs-QueryFound\n");fflush(stdout);
			}
			else
			{
				printf("\nNot Found\n");fflush(stdout);
			}
			qry_valuesOptFam[0] = "*";
			printf("Querying in table Cfg0OptionFamiliesFromIDs attribute [%s] value [%s]\n",qry_entriesOptFam[0],qry_valuesOptFam[0]);fflush(stdout);
			if(QRY_execute(queryTagOptFam, n_entriesOptFam, qry_entriesOptFam, qry_valuesOptFam, &resultCountOptFam, &revOptFam));
			printf("Cfg0OptionFamiliesFromIDs for %s resultCountOptFam1:%d\n",iVarRuleName, resultCountOptFam); fflush(stdout);fflush(stdout);
			//query optionname and description-------------------------

			printf("sVariantRuleText:%s\n\t\t\t",sVariantRuleText);fflush(stdout);
			fprintf(fsuccess,"\nsVariantRuleText : %s\n\t\t\t",sVariantRuleText);fflush(stdout);

			resultRule_2 = (char *)MEM_alloc(40000);
			tc_strcpy(resultRule_2,sVariantRuleText);
			resultRule_2 = replaceWord(resultRule_2, "AND (", "AND ");	//if any AND condition with multiple or are comming in SVR starting bracket
			resultRule_2 = replaceWord(resultRule_2, ") AND", " AND");	//if any AND condition with multiple or are comming in SVR ending bracket
			resultRule_2 = replaceWord(resultRule_2, "AND [Teamcenter]", "=");
			resultRule_2 = replaceWord(resultRule_2, "OR [Teamcenter]", "=");
			resultRule_2 = replaceWord(resultRule_2, "[Teamcenter]", "=");
			resultRule_2 = replaceWord(resultRule_2, " = ", "=");

			printf("\nresultRule_2:%s",resultRule_2);fflush(stdout);
			fprintf(fsuccess,"\nresultRule_2:%s",resultRule_2);fflush(stdout);
			
			//get list of characteristics
			attrs_name = (char **)MEM_alloc(2000 * sizeof(char *));
			ioc = 0;
			last_ioc = 0;
			option_token = strtok(sVariantRuleText,tokstr);	//tokenize char in string "[Teamcenter]" in rule
			while ( option_token != NULL )
			{
				
				attrs_name[ioc] = option_token;
				printf("ioc attrs_name[%d]:[%s]\n\t\t",ioc,attrs_name[ioc]);fflush(stdout);
				option_token = strtok ( NULL, tokstr );
				ioc = ioc + 1;
			}
			last_ioc = ioc;

			//tokenize string
			printf("no of options found in rule last_ioc:[%d]\n\t\t",last_ioc);fflush(stdout);
			
			for (joc = 0 ; joc < last_ioc ; joc++)
			{
					if(attrs_name[joc] != NULL)
					{
						printf("joc attrs_name[%d]:%s\n\t\t",joc,attrs_name[joc]);fflush(stdout);
						equaltok = strstr(attrs_name[joc],"=");
						if (equaltok != NULL )
						{
								*equaltok = '\0';
								resultRule_3 = replaceWord(attrs_name[joc], "Teamcenter]", "");
								resultRule_4 = replaceWord(resultRule_3, "'", "");
								resultRule_4[tc_strlen(resultRule_4)-1] = '\0';
								printf("Option Name in Rule:[%s]\n\t\t",resultRule_4);fflush(stdout);
						}
					}
			}
			aformula = (char *) malloc ( 40000 * sizeof ( char ) );
			tc_strcpy(aformula,"");
			tc_strcpy(aformula,resultRule_2);
			printf("formula after:%s\n\t\t",aformula);fflush(stdout);
			MEM_free(attrs_name);
			//----------------------------------
			
			sap_opt_name = (char **)MEM_alloc(2000 * sizeof(char *));
			sap_opt_value = (char **)MEM_alloc(2000 * sizeof(char *));
			
			Sap_opt_tok = strtok(resultRule_2,"=");	//tokenize char in string "[Teamcenter]" in rule
			while ( Sap_opt_tok != NULL )
			{
				sap_opt_name[koc] = Sap_opt_tok;
				printf("sap_opt_name[%d]:[%s]\n\t\t",koc,sap_opt_name[koc]);fflush(stdout);
				Sap_opt_tok = strtok ( NULL, "=" );
				koc = koc + 1;
			}
			printf("\nDone");fflush(stdout);
			iSapOptCnt = koc;
			printf("\niSapOptCnt:%d",iSapOptCnt);fflush(stdout);
			printf("\nkoc:%d",koc);fflush(stdout);
			for( iOptCntr = 0; iOptCntr < iSapOptCnt; iOptCntr = iOptCntr + 2 )
			{
				printf("\nProcessing:%d:%s",iOptCntr,sap_opt_name[iOptCntr]);fflush(stdout);
				//sap_opt_name[iOptCntr] = replaceWord(sap_opt_name[iOptCntr], "'", ""); printf ("\nleft done");fflush(stdout);
				//char newOptName = (char *) MEM_alloc(30 * sizeof(char ));
				char* newOptName = NULL;
				STRNG_replace_str(sap_opt_name[iOptCntr], "'", "", &newOptName );
				tc_strcpy(sap_opt_name[iOptCntr],newOptName);
				//printf ("\nleft done:%s:",newOptName);fflush(stdout);
				

				//sap_opt_name[iOptCntr+1] = replaceWord(sap_opt_name[iOptCntr+1], "'", "");printf ("\nright done");fflush(stdout);
				char* newOptVal = NULL;
				STRNG_replace_str(sap_opt_name[iOptCntr+1], "'", "", &newOptVal);
				tc_strcpy(sap_opt_name[iOptCntr+1],newOptVal);
				//printf ("\nright done:%s:",newOptVal);fflush(stdout);

				printf("\nsap_opt_name[%d]->[%s] = [%s]",iOptCntr,sap_opt_name[iOptCntr],sap_opt_name[iOptCntr+1]);fflush(stdout);
					
				//printf("\nresultCountOptFam1:%d",resultCountOptFam);
				for ( jCnt = 0; jCnt < resultCountOptFam; jCnt++ )
				{
					Optfmly_tag = revOptFam[jCnt];
					OptfmlyDesc=NULL;
					OptfmlyName=NULL;

					ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_type",&Optfmly_type));
					
					if ( tc_strcmp(Optfmly_type, "Cfg0PackageOptionFamily" ) == 0 )//skip all packs like infotainment/custom/Base
					{
						//printf("\tSkipping"); fflush(stdout);
						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
						if(tc_strcmp(sap_opt_name[iOptCntr],OptfmlyName)==0)
						{
							ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
							printf("3 sap_opt_name[iOptCntr] jCnt=%d OptfmlyName Object String Type is :[%s][%s]\n",jCnt,OptfmlyName,OptfmlyDesc);	fflush(stdout);

							char* newOptName1 = NULL;
							STRNG_replace_str(sap_opt_name[iOptCntr], sap_opt_name[iOptCntr], OptfmlyDesc, &newOptName1 );
							//tc_strcpy(sap_opt_name[iOptCntr],newOptName1);
							tc_strcpy(sap_opt_name[iOptCntr],"--SkipPack"); //for PACK which skipped from transfer
							printf ("\nleft done2:%s:",newOptName1);fflush(stdout);

							
							//sap_opt_name[iOptCntr] = replaceWord(sap_opt_name[iOptCntr], sap_opt_name[iOptCntr], OptfmlyDesc);
							break;
						}
						if(tc_strcmp(sap_opt_name[iOptCntr+1],OptfmlyName)==0)
						{
							ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
							printf("4 sap_opt_name[iOptCntr+1] jCnt=%d OptfmlyName Object String Type is :[%s][%s]\n",jCnt,OptfmlyName,OptfmlyDesc);	fflush(stdout);
							char* newOptVal1 = NULL;
							STRNG_replace_str(sap_opt_name[iOptCntr+1], sap_opt_name[iOptCntr+1], OptfmlyDesc, &newOptVal1);
							tc_strcpy(sap_opt_name[iOptCntr+1],newOptVal1);
							printf ("\nright done2:%s:",newOptVal1);fflush(stdout);
							//sap_opt_name[iOptCntr+1] = replaceWord(sap_opt_name[iOptCntr+1], sap_opt_name[iOptCntr+1], OptfmlyDesc);
							break;
						}
						//continue;
					}
					else
					{

						ITK_CALL(AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyName));
						if(tc_strcmp(sap_opt_name[iOptCntr],OptfmlyName)==0)
						{
							ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
							printf("1 sap_opt_name[iOptCntr] jCnt=%d OptfmlyName Object String Type is :[%s][%s]\n",jCnt,OptfmlyName,OptfmlyDesc);	fflush(stdout);

							char* newOptName1 = NULL;
							STRNG_replace_str(sap_opt_name[iOptCntr], sap_opt_name[iOptCntr], OptfmlyDesc, &newOptName1 );
							tc_strcpy(sap_opt_name[iOptCntr],newOptName1);
							printf ("\nleft done1:%s:",newOptName1);fflush(stdout);

							//sap_opt_name[iOptCntr] = replaceWord(sap_opt_name[iOptCntr], sap_opt_name[iOptCntr], OptfmlyDesc);
							break;
						}
						if(tc_strcmp(sap_opt_name[iOptCntr+1],OptfmlyName)==0)
						{
							ITK_CALL(AOM_ask_value_string(Optfmly_tag,"current_desc",&OptfmlyDesc));
							printf("2 sap_opt_name[iOptCntr+1] jCnt=%d OptfmlyName Object String Type is :[%s][%s]\n",jCnt,OptfmlyName,OptfmlyDesc);	fflush(stdout);
							char* newOptVal1 = NULL;
							STRNG_replace_str(sap_opt_name[iOptCntr+1], sap_opt_name[iOptCntr+1], OptfmlyDesc, &newOptVal1);
							tc_strcpy(sap_opt_name[iOptCntr+1],newOptVal1);
							printf ("\nright done1:%s:",newOptVal1);fflush(stdout);

							//sap_opt_name[iOptCntr+1] = replaceWord(sap_opt_name[iOptCntr+1], sap_opt_name[iOptCntr+1], OptfmlyDesc);
							break;
						}
					}
				}
			}

			printf("\nCall Basic2Mrp3ViewSvr");
			fprintf(fsuccess,"\nCall Basic2Mrp3ViewSvr");
			Basic2Mrp3ViewSvr ( sVcMaterialNo, sKmatMaterialNo, sPlantCode, sap_opt_name, &iSapOptCnt, sSvrRevision, dSvrDate ) ;
			
			printf("\nCall cll_zpprfc_config_mat_linking");
			fprintf(fsuccess,"\nCall cll_zpprfc_config_mat_linking");
			cll_zpprfc_config_mat_linking ( CCVCNumber, sPlantCode );

			printf("\nSVR Transfer Completed : %s\n",sSVR_Name);
			fprintf(fsuccess,"\nSVR Transfer Completed : %s\n",sSVR_Name);
		}
		else
		{
			printf("\n%s : Varient Formula - cfg0VariantRuleText is NULL\n",sSVR_Name);
			fprintf(fsuccess,"\n%s : Varient Formula - cfg0VariantRuleText is NULL\n",sSVR_Name);
			return status;
		}
	}
	else
	{ 
		printf("SVR Not found in TCUA for CCVC : %s ",iVarRuleName);fflush(stdout); 
		fprintf(fsuccess,"SVR Not found in TCUA for CCVC : %s ",iVarRuleName);fflush(stdout); 
		return status;
	}

	return status;
}

extern int ITK_user_main(int argc, char ** argv )
{
	int status = ITK_ok;
	int len=0;
	int tcount =0;
	int n_entries = 1;
	int	count_DML = 0;
	int	PartCnt=0;
	int	pcount=0;

	tag_t		queryTag			= NULLTAG;
	tag_t		docOPtr				= NULLTAG;
	tag_t		*outTag				= NULLTAG;
	tag_t		DMLTag				= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;
	tag_t		resultOutputTag		= NULLTAG;
	tag_t		LatestRev			= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t		DmlTaskRelTag		= NULLTAG;
	tag_t*		DMLRevTags			= NULLTAG;

	tag_t		*TaskRevision		= NULLTAG;
	tag_t		TaskRevTag			= NULLTAG;
	tag_t		*PartTags			= NULLTAG;

	char* sUserName		= NULL;
	char* sPassword		= NULL;
	char* inputDml		= NULL;
	char* iDmlTask		= NULL;

	char* DMLNum			= NULL;
	char* DMLNumDup			= NULL;
	char* DMLDesc			= NULL;
	char* DMLRelStatus		= NULL;
	char* TaskRelStatus     = NULL;
	char* DMLProjCode		= NULL;
	char* DMLProjCodeDup	= NULL;
	char* DMLRelType		= NULL;
	char* DMLEcnType		= NULL;
	char* SMDMLType			= NULL;
	char* DML_Owner			= NULL;
	char* object_type		= NULL;
	char* taskId			= NULL;
	char* DateStr			= NULL;
	char* PRTaskStr			= NULL;
	char* part_type			= NULL;
	char* Assy_no			= NULL;

	char  type_name[TCTYPE_name_size_c+1];

	static RFC_RC RfcRc;

	date_t APLRelDate;
	date_t STDRelDate;
	time_t NowTime;
	struct tm *timeinfo;
	timestamp		= (char *) MEM_alloc(20 * sizeof(char));

	char* APLRelDateStr = NULL;
	char* STDRelDateStr = NULL;

	int three = 3,CntObjCnt=0;
	tag_t   CntObjQryTag		= NULLTAG;
	tag_t   *CntObjTag			= NULLTAG;
	char    *CntObjEntry[3]		= {"SYSCD","SUBSYSCD","Information-1"};

	//char *qry_entries[1] = {"Name"};
	//char *qry_entries[1] = {"item_id"};
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	iSapServer = ITK_ask_cli_argument("-s=");
	iDmlTask = ITK_ask_cli_argument("-t=");

	time(&NowTime);
	timeinfo = localtime(&NowTime);
	//strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	strftime(timestamp, 20, "%Y%m%d", timeinfo);
	printf("\ntimestamp %s",timestamp);

	if (iDmlTask)
	{
		sprintf(fsuccess_name,"/user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SVR_BOM_Task_%s.log",iDmlTask);
		//sprintf(fsuccess_name,"SVR_BOM_Task_%s.log",iDmlTask);
		fsuccess = fopen(fsuccess_name,"a");

		if(QRY_find("Control Objects...", &CntObjQryTag));

		if(CntObjQryTag)
		{
			char	*SkipDML[3] = {"SAPSKIP",iDmlTask,iDmlTask};

			if(QRY_execute(CntObjQryTag,three,CntObjEntry,SkipDML,&CntObjCnt,&CntObjTag));

			if (CntObjCnt>0)
			{
				printf("\nDML %s Entry Found in Control Object to skip transfer\n",iDmlTask);
				fprintf(fsuccess,"DML %s Entry Found in Control Object to skip transfer\n",iDmlTask);
				goto CLEANUP;
			}
		}

		if(QRY_find("APLTaskRevisionQry", &queryTag));
		if (queryTag)
		{
			printf("\nQuery Found : APLTaskRevisionQry\n");fflush(stdout);
		}
		else
		{
			printf("\nQuery NotFound : APLTaskRevisionQry\n");fflush(stdout);
			goto CLEANUP;
		}

		printf("\nInput DML Task : %s\n ", iDmlTask);fflush(stdout);

		qry_values[0] = iDmlTask;

		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &tcount, &TaskRevision));

		printf("\nResultCount :%d:\n", tcount);fflush(stdout);
		if (tcount>0)
		{
			TaskRevTag = TaskRevision[tcount-1];

			ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskId));
			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"owning_user",&DML_Owner));
			ITK_CALL(AOM_ask_value_date(TaskRevTag,"date_released",&STDRelDate));
			ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"t5_PrTaskRelSTD",&PRTaskStr));

			printf("\nTask ID %s	object_type %s",taskId,object_type);fflush(stdout);
			fprintf(fsuccess,"\nTask ID : %s object_type %s",taskId,object_type);fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(TaskRevTag,"release_status_list",&TaskRelStatus));

			if(tc_strstr(TaskRelStatus,"STDSIC Released")==NULL && tc_strstr(TaskRelStatus,"STDSIC Restructured")==NULL)
			{
				printf("\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
				fprintf(fsuccess,"\nDML Task : %s is not STDSIC Released ... skipping from transfer.\n",taskId);fflush(stdout);
				goto CLEANUP;
			}
			else
			{
				printf("\nDML Task : %s Release Status %s\n",taskId,TaskRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nDML Task : %s Release Status %s\n",taskId,TaskRelStatus);fflush(stdout);
			}
			
			ITK_CALL(ITK_date_to_string(STDRelDate,&DateStr));
			if (tc_strlen(DateStr)==0)
			{
				printf("\nDML Number [%s] STD Release Date is NULL..Exiting!\n",taskId,tc_strlen(DateStr));
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",taskId,tc_strlen(DateStr));
				goto CLEANUP;
			}
			else
			{
				printf("\nDML Number [%s] STD Release Date [%s]\n",taskId,DateStr);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date [%s]\n",taskId,DateStr);
			}

			GRM_find_relation_type("T5_DMLTaskRelation",&DmlTaskRelTag);
			GRM_list_primary_objects_only(TaskRevTag,DmlTaskRelTag,&count_DML,&DMLRevTags);
			printf("\nDML Count : %d",count_DML);fflush(stdout);
			if (count_DML>0)
			{
				DMLTag	=	DMLRevTags[0];

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
				tc_strdup(DMLNum,&DMLNumDup);

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"t5_cprojectcode",&DMLProjCode));
				tc_strdup(DMLProjCode,&DMLProjCodeDup);

				ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_desc",&DMLDesc));
				ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
				
				if(tc_strcmp(DMLProjCode,"5445")==0)
				{
					printf("\nHornbill Porject\n");fflush(stdout);
				}
				else
				{
					printf("\nNot Hornbill Porject\n");fflush(stdout);
					fprintf(fsuccess,"\nNot Hornbill Porject\n");fflush(stdout);
					goto CLEANUP;
				}			

				ITK_CALL(ITK_date_to_string(STDRelDate,&DateStr));
				printf("\nDML [%s]\n",DMLNum);
				fprintf(fsuccess,"\nDML [%s]\n",DMLNum);

				if (tc_strcmp(DMLRelType,"TODR")==0)
				{
					printf("\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
					fprintf(fsuccess,"\nDML [%s] Release Type is [%s] Skipping DML Transfer\n",DMLNum,DMLRelType);
					goto CLEANUP;
				}

				if(tc_strstr(DMLNum,"AM")!=NULL)
				{
					ITK_CALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLEcnType));

					char	*Ecn_value[3] = {"ECNTYPE","AMDML",DMLEcnType};
					if(CntObjQryTag)
					{
						if(QRY_execute(CntObjQryTag,three,CntObjEntry,Ecn_value,&CntObjCnt,&CntObjTag));

						if (CntObjCnt>0)
						{
							printf("\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
							fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Ok!\n",DMLNum,DMLEcnType);
						}
						else
						{
							printf("\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
							fprintf(fsuccess,"\nDML [%s] ECN Type is [%s] Exiting!\n",DMLNum,DMLEcnType);
							goto CLEANUP;
						}
					}
				}

				if(tc_strstr(DMLNum,"SM")!=NULL)
				{
					ITK_CALL(AOM_ask_value_string(DMLTag,"t5_SMDMLType",&SMDMLType));

					char	*SM_value[3] = {"DMLTYPE","SMDML",SMDMLType};

					if(CntObjQryTag)
					{
						if(QRY_execute(CntObjQryTag,three,CntObjEntry,SM_value,&CntObjCnt,&CntObjTag));

						if (CntObjCnt>0)
						{
							printf("\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
							fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Ok!\n",DMLNum,SMDMLType);
						}
						else
						{
							printf("\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
							fprintf(fsuccess,"\nDML [%s] SMDML Type is [%s] Exiting!\n",DMLNum,SMDMLType);
							goto CLEANUP;
						}
					}
				}

				if (tc_strcmp(DMLEcnType,"TOODMLR")==0 && tc_strstr(taskId,"PR")!=NULL) //As per Pasha's mail on 14-May-2020
				{
					printf("\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					fprintf(fsuccess,"\nECN Type TOO DML Dependency Release hence Skipping PR Task transfer : %s\n",taskId);fflush(stdout);
					goto CLEANUP;
				}

				//if(FetchPlantSpecificData(DMLNumDup,DMLProjCodeDup)>0)
			
				/*if(tc_strcmp(plantcode,"")==0)
				{
					printf("\nPlant code is null hence exit"); fflush(stdout);
					fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
					goto CLEANUP;
				}*/
			}
			
			pcount=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
			printf("\nTask To Part Count : %d",pcount);fflush(stdout);
			fprintf(fsuccess,"\nTask To Part Count : %d",pcount);fflush(stdout);
			
			//Going SVR for BOM Creation 
			for (PartCnt=0;PartCnt<pcount;PartCnt++)
			{
				LatestRev=PartTags[PartCnt];
				ITK_CALL(AOM_ask_value_string(LatestRev,"current_name",&Assy_no));
				ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));

				if(	tc_strcmp(part_type,"CCVC")==0)
				{
					printf("\nFinding SVR of CCVC : %s\n",Assy_no);
					fprintf(fsuccess,"\nFinding SVR of CCVC : %s\n",Assy_no);
					FindSendSVR(LatestRev);

				}
				else
				{
					printf("\nNot CCVC Skipping : %s\n",Assy_no);
					fprintf(fsuccess,"\nNot CCVC Skipping : %s\n",Assy_no);
					continue;
				}
			}//Part loop

		}
	}

	CLEANUP:
	printf("\ncall POM_logout");
	ITK_CALL(POM_logout(false));
	return status;
}

RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}