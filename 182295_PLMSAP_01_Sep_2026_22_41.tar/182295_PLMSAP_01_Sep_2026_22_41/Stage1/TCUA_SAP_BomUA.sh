. /user/uaprod/.bash_profile
tdate=`date +"%d-%h-%Y" --date="0 days ago"`
ydate=`date +"%d-%h-%Y" --date="1 days ago"`
stime="00:00"
inptime="$ydate $stime"
echo "Today's Date is :: $tdate"
echo "Yesterday's Input Date is :: $inptime"

if test -s /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt`
	do
	echo "Transfering STD Released PR Task Number : $i"
		/user/plmsap/PLMSAP/liveXfr/SAPBomCreateChangeUA -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -s=PVP -t=$i
	done

	for i in `cat /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt`
	do
		if test -s /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SAP_BOM_Task_$i.log
		then
		grep -ie "ECN Type" -ie "Not STDSIC Released" -ie "MESSAGE FOR BOM" -ie "Message for Bom Change" -ie "Do not have structure" /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SAP_BOM_Task_$i.log >> /user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/STDBomStatus_$tdate.txt
		fi
	done
fi

StdTaskFile=/user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt
STDFileConf=/tmp/StdDmlReleasedOn_"$ydate".conf
StdDmlMsgFile=/user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/STDBomStatus_$tdate.txt

echo $StdTaskFile
echo $StdDmlMsgFile

rm -rf "$STDFileConf"
touch "$STDFileConf"
echo "To:devkantk.ttl@tatamotors.com, tusharr1.ttl@tatamotors.com, amoln.ttl@tatamotors.com, prasadb1.ttl@tatamotors.com" >> "$STDFileConf"
echo "Cc:manishaj.ttl@tatamotors.com" >> "$STDFileConf"
echo "SUBJECT:STD Released DML TCUA-SAP Transfer from UAPROD" >> "$STDFileConf"
echo 'MIME-Version: 1.0' >> "$STDFileConf"
echo 'Content-Type: text/html; charset='us-ascii'' >> "$STDFileConf"
echo 'Content-Disposition: inline' >> "$STDFileConf"
echo "" >> "$STDFileConf"
echo '<SPAN><font face="verdana" color="red">'
echo "Dear All,<BR/><BR/>Below STD Released DML Task transferred to SAP from UAPROD on $tdate.<BR/>" >> "$STDFileConf"

while read line
do
echo $line >> "$STDFileConf"
echo "<BR/>" >> "$STDFileConf"
done < $StdTaskFile

while read line
do
echo $line >> "$STDFileConf"
echo "<BR/>" >> "$STDFileConf"
done < $StdDmlMsgFile
echo '</SPAN>' >>  "$STDFileConf"
/usr/sbin/sendmail -i -t < "$STDFileConf"

echo "*****************************************SVR Transfer Job Started**********************************************************"

if test -s /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt
then
	for i in `cat /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt`
	do
	echo "Transfering STD Released PR Task Number : $i"
		/user/plmsap/PLMSAP/ModulerXfr/TaskSVRTransfer -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -s=PVP -t=$i
	done

	for i in `cat /user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_$ydate.txt`
	do
		if test -s /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SVR_BOM_Task_$i.log
		then
		grep -ie "SVR Transfer Completed" -ie "cfg0VariantRuleText is NULL" -ie "SVR Not found in TCUA for CCVC" -ie "LCS is not ERC Released" /user/plmsap/PLMSAP/PLM_SAP_APL_LOG/SVR_BOM_Task_$i.log >> /user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/SVR_Bom_Status_$tdate.txt
		fi
	done
fi

SVRMailFileConf=/tmp/SVRBomTransferedOn_"$ydate".conf
SvrBomMsgFile=/user/plmsap/PLMSAP/PLM_SAP_LOG_MESSAGE/SVR_Bom_Status_$tdate.txt

echo $StdTaskFile
echo $SvrBomMsgFile

rm -rf "$SVRMailFileConf"
touch "$SVRMailFileConf"
echo "To:devkantk.ttl@tatamotors.com, tusharr1.ttl@tatamotors.com, amoln.ttl@tatamotors.com, prasadb1.ttl@tatamotors.com" >> "$SVRMailFileConf"
echo "Cc:manishaj.ttl@tatamotors.com" >> "$SVRMailFileConf"
echo "SUBJECT:SVR BOM Transfer from UAPROD" >> "$SVRMailFileConf"
echo 'MIME-Version: 1.0' >> "$SVRMailFileConf"
echo 'Content-Type: text/html; charset='us-ascii'' >> "$SVRMailFileConf"
echo 'Content-Disposition: inline' >> "$SVRMailFileConf"
echo "" >> "$SVRMailFileConf"
echo '<SPAN><font face="verdana" color="red">'
echo "Dear All,<BR/><BR/>Below STD Released DML Task processed for SVR BOM transfer on $tdate.<BR/>" >> "$SVRMailFileConf"

while read line
do
echo $line >> "$SVRMailFileConf"
echo "<BR/>" >> "$SVRMailFileConf"
done < $StdTaskFile

while read line
do
echo $line >> "$SVRMailFileConf"
echo "<BR/>" >> "$SVRMailFileConf"
done < $SvrBomMsgFile
echo '</SPAN>' >>  "$SVRMailFileConf"
/usr/sbin/sendmail -i -t < "$SVRMailFileConf"