/*
scp tctst@172.22.224.175:/home/tctst/teldir/PLM_SAP/devkant/Ckd/CkdDml .
ar cr libBapi.a Bapi.o		creating archive to use in curretn code
*/
#define _CLMAIN_DEFNS
#include <cl.h>
#include <msgomf.h>
#include <msgapc.h>
#include <ZZ_sqlerr.h>
#include <AZ_ato.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Mtimsgh.h>
#include <usc.h>
#include <sc.h>
#include <pdmsessn.h>
#include <tel.h>

#include <malloc.h>
#include <cJSON.h>
#include <curl/curl.h>

char fgen_filename[200]={0};
struct node
{
	char sr_no[5];
	string part;
	float qty;
	char uq[4];
	char tempcsrel[2];
	char mat_prov_ind[2];
	struct node *next;
};
int ercDmlflag = 0;
char  EEDmlNumber[50] = {0};
char  EEDmlNumberST[50] = {0};
char  InputDmlOrPart[50];
FILE *fsuccess = NULL;
string sSAPServer = NULL;


static char SAPpstat[50] = {0};
static char MRPpstat[50] = {0};
static char pstat;
static char pstat_mrp;
static char pstat_acc;

void BomChange(ObjectPtr PartOPtr,char EEDmlNumber[]);
void BomCreate(ObjectPtr PartOPtr,char EEDmlNumber[]);
//void RefPartBomCreate(string AssyPartNumberDup,string ChildPartNumberDup,char EEDmlNumber[]);
int search(struct node* start,string part,float qty);
struct node* createnode(char sr_no[5],string part,float qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2]);
//void displayChange(struct node *head,string assy_noDup);
//void displayCreate(struct node *head,string assy_noDup);
//void cll_ccap_ecn_createST(SetOfObjects Dmlso,ObjectPtr VCObj);
//char* subString(char* mainStringf,int fromCharf,int toCharf);
int DZ_ckd_bapi_mat(ObjectPtr PartOPtr,string MatPartNumber,char EEDmlNumber[11],char shop_store);
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
status t5GetDocumentTypes(SetOfObjects docObjs, SetOfStrings* docTypes, integer* mfail);
status t5GetTypeDocuments(SetOfObjects docObjs,SetOfObjects docRelObjs,string docType,SetOfObjects* docTypeObjs,SetOfObjects* docTypeRelObjs,integer* mfail);
status t5GetLatestDocumnets(SetOfObjects docObjs,SetOfObjects docRelObjs,SetOfObjects* latestDocs,SetOfObjects* latestRelDocs,integer* mfail);
status t5GetDistinctAttributeValues(SetOfObjects objs,string attrName,SetOfStrings* distValues,integer* mfail);
status t0LatestBI(SetOfObjects itemObj,SetOfObjects itemRel,ObjectPtr *returnedObj,ObjectPtr *returnedRel,integer *mfail);
char* subString(char* mainStringf ,int fromCharf ,int toCharf);
void str2nbcd(char *str,unsigned char *bcd,size_t size, int decimals);
//void cll_ccap_ecn_create(SetOfObjects Dmlso,ObjectPtr VCObj);
void my_free(struct node* start);


struct memory {
  char *response;
  size_t size;
};

static size_t WriteCallback(char *data, size_t size, size_t nmemb, void *clientp)
{
  size_t realsize = size * nmemb;
  struct memory *mem = (struct memory *)clientp;
 
  char *ptr = realloc(mem->response, mem->size + realsize + 1);
  if(!ptr)
    return 0;  /* out of memory */
 
  mem->response = ptr;
  memcpy(&(mem->response[mem->size]), data, realsize);
  mem->size += realsize;
  mem->response[mem->size] = 0;
  
  printf("\nWriteCallback done"); fflush(stdout);
 
  return realsize;
}

int parse_json_object(const char *json_string,char *ParseType) 
{
    int i = 0;
	cJSON *json = cJSON_Parse(json_string);
	if (json == NULL) 
	{ 
        const char *error_ptr = cJSON_GetErrorPtr(); 
        if (error_ptr != NULL) 
		{ 
            printf("Error: %s\n", error_ptr); 
        } 
        cJSON_Delete(json); 
        return 1; 
    } 
	//printf("\njson_string : [%s]\n\n",json_string);//to see complete response
	printf("\ncJSON_GetArraySize(json) : [%d]\n\n",cJSON_GetArraySize(json));
	
	/********************************************/
//	char *out = cJSON_Print(json);
//	printf("\nformatted output : %s\n", out);
//	free(out);
	
	/********************************************/
	
	printf ("\nParseType : [%s]",ParseType);
	if ( nlsStrCmp ( ParseType, "PSTAT" ) == 0 )
	{
		//printf("\njson_string : [%s]\n\n",json_string);
		if( nlsStrStr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CLIENTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_KStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
				nlsStrCpy ( SAPpstat, tm_KStatMessage ) ;
			    printf("\nK-Flag Message: [%s]\n", tm_KStatMessage);fflush(stdout);
			}
		}
		if( nlsStrStr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "PLANTDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_DStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
				nlsStrCpy ( MRPpstat, tm_DStatMessage ) ;
			    printf("\nD-Flag Message: [%s]\n", tm_DStatMessage);fflush(stdout);
			}
		}
		if( nlsStrStr(json_string ,"BAPI_MATERIAL_GETALLResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "BAPI_MATERIAL_GETALLResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "VALUATIONDATA");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_BStatMessage = cJSON_GetObjectItem(moon_2, "MAINT_STAT")->valuestring;
			    printf("\nB-Flag Message: [%s]\n", tm_BStatMessage);fflush(stdout);
			}
		}
	}
	else if ( nlsStrCmp ( ParseType, "MAT_CREATE_CHANGE" ) == 0 )
	{
		//printf("\njson_string : [%s]\n\n",json_string);
		if( nlsStrStr(json_string ,"ZBAPI_MATERIAL_SAVEDATAResponse") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "ZBAPI_MATERIAL_SAVEDATAResponse");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "RETURN");
				
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_matcrexmsg = cJSON_GetObjectItem(moon_2, "MESSAGE")->valuestring;
				printf("\n@@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			    printf("\nSAP Msg for Material Create/Extend: [%s]\n", tm_matcrexmsg);fflush(stdout);
				printf("\n@@@@@@@@@@@@ MATERIAL CREATE/EXTEND STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
	else if ( nlsStrCmp ( ParseType, "CHANGE_NO" ) == 0 )
	{
		//printf("\njson_string : [%s]\n\n",json_string);
		if( nlsStrStr(json_string ,"addition") != NULL )
		{
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "addition");
			const cJSON *moon_2 = cJSON_GetObjectItemCaseSensitive(moon_1, "CcapEcnCreate_Exception");	
			for(i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				char *tm_changename = cJSON_GetObjectItem(moon_2, "Name")->valuestring;
				char *tm_changetext = cJSON_GetObjectItem(moon_2, "Text")->valuestring;
				printf("\n@@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				printf("\nChange_No Name: [%s]\n", tm_changename);fflush(stdout);
				printf("\nChange_No Text: [%s]\n", tm_changetext);fflush(stdout);
				printf("\nSAP Msg for Change_no Create/Extend: Change_no already maintained for this transaction/event\n");fflush(stdout);
				printf("\n@@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
		else
		{
			//const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreate");
			const cJSON *moon_1 = cJSON_GetObjectItemCaseSensitive(json, "CcapEcnCreateResponse");
			for (i = 0 ; i < cJSON_GetArraySize(json) ; i++)
			{
				printf("\n@@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
				char *tm_material = cJSON_GetObjectItem(moon_1, "ChangeNo")->valuestring;
				printf("\nChange_No [%s]\n", tm_material);fflush(stdout);
				printf("\nSAP Msg for Change_no Create/Extend: Transaction Completed Succesfully...\n");fflush(stdout);
				printf("\n@@@@@@@@@@@@ CHANGE_NO CREATE STATUS @@@@@@@@@@@@@@\n");fflush(stdout);
			}
		}
	}
			
	return 0;
}

void print_json_object(const char *json_string)
{
    cJSON *json = cJSON_Parse(json_string);
    char *formatted_json = cJSON_Print(json);
    printf("%s\n", formatted_json);
    cJSON_Delete(json);
    free(formatted_json);
}

char* subString(char* mainStringf,int fromCharf,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

/*
int GetCSPstat(string part_noDup)
{
	char xException[256];
	RFC_HANDLE hRfc;
	RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;
	char plantcode[5]={0};
	nlsStrCpy(plantcode,"1005");

	printf("\nProcessing GetCSPstat:[%s,%s]",part_noDup,plantcode); fflush(stdout);

	hRfc = BapiLogon();

	nlsStrCpy(SAPpstat,"");
	nlsStrCpy(MRPpstat,"");

	SETCHAR(eMatnr.Matnr,part_noDup);
	SETCHAR(eWerks.WerksD,plantcode);

	RfcRc = export_CSpastat(hRfc
					,&eMatnr
					,&eWerks
					,&iMrpView
					,&iView
					,xException);

	switch (RfcRc)
	{
		case RFC_OK:


			GETCHAR(iView.MAINT_STAT, SAPpstat);
			nlsStrTrimTrailWhiteSpace(SAPpstat);
			nlsStrTrimLeadWhiteSpace(SAPpstat);
			SAPpstat[nlsStrLen(SAPpstat)] = '\0';

			GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
			nlsStrTrimTrailWhiteSpace(MRPpstat);
			nlsStrTrimLeadWhiteSpace(MRPpstat);
			MRPpstat[nlsStrLen(MRPpstat)] = '\0';

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException); fflush(stdout);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!"); fflush(stdout);
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!"); fflush(stdout);
			exit(0);
		break;
		default:
			printf("\nOther Failure!"); fflush(stdout);
			exit(0);
	}

	RfcClose(hRfc);
	return 0;
}*/

int get_pstat_from_sap ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;

	//const char *data = readd_sap_request_json_file();

	//printf("\nFile request content as below : %s",data);

	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//ccap_ecn_create_DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential

	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_BAPI_MATERIAL_GETALL_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "PSTAT");

		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

		printf("\nfree"); fflush(stdout);

    curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int mat_pstat_json_cr ( char cMaterial[25], char *json_BAPI_MATERIAL_GETALL_req_obj )
{

	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *EXTENSIONOUT_req;
	cJSON *EXTENSIONOUT_item_req;

	cJSON *INTERNATIONARTICLENUMBERS_req;
	cJSON *INTERNATIONARTICLENUMBERS_item_req;

	cJSON *MATERIALDESCRIPTION_req;
	cJSON *MATERIALDESCRIPTION_item_req;

	cJSON *MATERIALTEXT_req;
	cJSON *MATERIALTEXT_item_req;

	cJSON *MATERIAL_EVG_req;

	cJSON *RETURN_req;
	cJSON *RETURN_item_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *TAXCLASSIFICATIONS_item_req;

	cJSON *UNITSOFMEASURE_req;
	cJSON *UNITSOFMEASURE_item_req;


	char *out;


	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	EXTENSIONOUT_req = cJSON_CreateObject();
	EXTENSIONOUT_item_req = cJSON_CreateObject();

	INTERNATIONARTICLENUMBERS_req = cJSON_CreateObject();
	INTERNATIONARTICLENUMBERS_item_req = cJSON_CreateObject();

	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	MATERIALDESCRIPTION_item_req = cJSON_CreateObject();

	MATERIALTEXT_req = cJSON_CreateObject();
	MATERIALTEXT_item_req = cJSON_CreateObject();

	MATERIAL_EVG_req = cJSON_CreateObject();

	RETURN_req = cJSON_CreateObject();
	RETURN_item_req = cJSON_CreateObject();

	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	TAXCLASSIFICATIONS_item_req = cJSON_CreateObject();

	UNITSOFMEASURE_req = cJSON_CreateObject();
	UNITSOFMEASURE_item_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "BAPI_MATERIAL_GETALL", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIAL", cJSON_CreateString(cMaterial));//dev=123456789999
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANT", cJSON_CreateString("1005"));//dev=1001


	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	strcpy(json_BAPI_MATERIAL_GETALL_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;

}

int GetCSPstat(char cMaterial[25])
{
	char *json_BAPI_MATERIAL_GETALL_req_obj = NULL;

	nlsStrCmp(SAPpstat,"");

	json_BAPI_MATERIAL_GETALL_req_obj = malloc(34000);
	mat_pstat_json_cr ( cMaterial, json_BAPI_MATERIAL_GETALL_req_obj );
	//printf("%s\n", json_BAPI_MATERIAL_GETALL_req_obj);

	get_pstat_from_sap ( json_BAPI_MATERIAL_GETALL_req_obj ) ;

	free(json_BAPI_MATERIAL_GETALL_req_obj);
	return 0;
}

int pstat_basicFun(void)
{
	printf("\n In pstat_basicFun function..[%s]   [%s]\n",SAPpstat,MRPpstat); fflush(stdout); fflush(stdout);

	if(!nlsIsStrNull(nlsStrStr(SAPpstat,"K")))
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	if(!nlsIsStrNull(nlsStrStr(MRPpstat,"D")))
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	if(!nlsIsStrNull(nlsStrStr(MRPpstat,"B")))
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	return 0;
}

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULL;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}


/*int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	AENNR eAennr;
	CCMATNR eMatnr;
	CC_REVLV eRevlv;
	MESSAGEINF iMessg;
	SYST_SUBRC iRetval;
	char xException[256];


	hRfc = BapiLogon();

	printf("\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);
	fprintf(fsuccess,"\nRevision Creation DmlNo.:[%s]\t PartNo.:[%s]\tRevSheetstatus:[%s]",sap_dml_no,sap_part_no,sap_rev_sheet_status);

	SETCHAR(eAennr.Aennr,sap_dml_no);
	SETCHAR(eMatnr.Ccmatnr,sap_part_no);
	SETCHAR(eRevlv.CcRevlv,sap_rev_sheet_status);


	RfcRc = zpprfc_revisionnum_change(hRfc,&eAennr,&eMatnr,&eRevlv,&iMessg,&iRetval,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			printf("\nRevision Creation Message	:%s",iMessg.Msgtx);
			fprintf(fsuccess,"\nRevision Creation Message	:%s",iMessg.Msgtx);
		break;
		case RFC_EXCEPTION:
			printf("\nRFC_EXCEPTION raised");
			fprintf(fsuccess,"\nRFC_EXCEPTION raised");
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
		case RFC_FAILURE:
			printf("\nfailure");
		break;
		default:
			printf("\nother failure");
	}
	RfcClose(hRfc);
	return 0;
}*/

int create_mat_rev_in_sap ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;

	//const char *data = readd_sap_request_json_file();

	//printf("\nFile request content as below : %s",data);

	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//ccap_ecn_create DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV_QA");
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential

	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZPPRFC_REVISIONNUM_CHANGE_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\nFile request content as below "); fflush(stdout);
	//print_json_object ( data ) ;

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "MAT_REV");

		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

		printf("\nfree"); fflush(stdout);

    curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int material_rev_json_cr ( char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3],char *json_mat_rev_cr_req_obj )
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	char *out;

	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	cJSON_AddItemToObject(rfc_root, "ZPPRFC_REVISIONNUM_CHANGE", exp_imp_tab_req);

	cJSON_AddItemToObject(exp_imp_tab_req, "AENNR", cJSON_CreateString(sap_dml_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "MATNR", cJSON_CreateString(sap_part_no));
	cJSON_AddItemToObject(exp_imp_tab_req, "REVLV", cJSON_CreateString(sap_rev_sheet_status));


	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);
	nlsStrCpy(json_mat_rev_cr_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
}

int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3])
{
	char *json_mat_rev_cr_req_obj = NULL;
	json_mat_rev_cr_req_obj = malloc(34000);
	material_rev_json_cr ( sap_dml_no, sap_part_no, sap_rev_sheet_status, json_mat_rev_cr_req_obj );
	//printf("%s\n", json_mat_rev_cr_req_obj);
	create_mat_rev_in_sap ( json_mat_rev_cr_req_obj );
	free(json_mat_rev_cr_req_obj);
	return 0;
}

int create_change_no_in_sap ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;

	//const char *data = readd_sap_request_json_file();

	//printf("\nFile request content as below : %s",data);

	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//ccap_ecn_create DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential

	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "CHANGE_NO");

		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

		printf("\nfree"); fflush(stdout);

    curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int change_no_json_cr( SetOfObjects Dmlso,ObjectPtr VCObj, char *json_req_obj)
{
	char SapChangeNo[13]={0};
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *AltDates_req;
	cJSON *AltDates_item_req;
	cJSON *ChangeHeader_req;
	cJSON *Effectivity_req;
	cJSON *Effectivity_item_req;
	cJSON *ObjectBom_req;
	cJSON *Object084_req;
	cJSON *ObjectBomCus_req;
	cJSON *ObjectBomDoc_req;
	cJSON *ObjectBomEqui_req;
	cJSON *ObjectBomLoc_req;
	cJSON *ObjectBomMat_req;
	cJSON *ObjectBomPsp_req;
	cJSON *ObjectBomStd_req;
	cJSON *ObjectChar_req;
	cJSON *ObjectCls_req;
	cJSON *ObjectClsMaint_req;
	cJSON *ObjectConfProf_req;
	cJSON *ObjectDep_req;
	cJSON *ObjectDoc_req;
	cJSON *ObjectHazmat_req;
	cJSON *ObjectMat_req;
	cJSON *ObjectO75_req;
	cJSON *ObjectO76_req;
	cJSON *ObjectO77_req;
	cJSON *ObjectO78_req;
	cJSON *ObjectO79_req;
	cJSON *ObjectO80_req;
	cJSON *ObjectO81_req;
	cJSON *ObjectO82_req;
	cJSON *ObjectO83_req;
	cJSON *ObjectO85_req;
	cJSON *ObjectO86_req;
	cJSON *ObjectO87_req;
	cJSON *ObjectO88_req;
	cJSON *ObjectO89_req;
	cJSON *ObjectO90_req;
	cJSON *ObjectO91_req;
	cJSON *ObjectO92_req;
	cJSON *ObjectO93_req;
	cJSON *ObjectO94_req;
	cJSON *ObjectO95_req;
	cJSON *ObjectO96_req;
	cJSON *ObjectO97_req;
	cJSON *ObjectO98_req;
	cJSON *ObjectO99_req;
	cJSON *ObjectPhrase_req;
	cJSON *ObjectPvs_req;
	cJSON *ObjectPvsAlt_req;
	cJSON *ObjectPvsRel_req;
	cJSON *ObjectPvsVar_req;
	cJSON *ObjectSubstance_req;
	cJSON *ObjectTlist_req;
	cJSON *ObjectTlistA_req;
	cJSON *ObjectTlistE_req;
	cJSON *ObjectTlistM_req;
	cJSON *ObjectTlistN_req;
	cJSON *ObjectTlistQ_req;
	cJSON *ObjectTlistR_req;
	cJSON *ObjectTlistS_req;
	cJSON *ObjectTlistT_req;
	cJSON *ObjectTlist_2_req;
	cJSON *ObjectValidMatvers_req;
	cJSON *ObjectVarTab_req;

	cJSON *Objmgrec_req;
	cJSON *Objmgrec_item_req;

	cJSON *Textheader_req;
	cJSON *Textheader_item_req;

	cJSON *Textlines_req;
	cJSON *Textlines_item_req;

	cJSON *ValueAssign_req;


	SetOfObjects taskObjs = NULL;
	SetOfObjects taskRevObjs = NULL;
	SetOfObjects DmlObjs = NULL;
	integer mfail = OKAY;
	status dstat = OKAY;
	string taskId = NULL;
	string taskIdDup = NULL;
	string SapDmlNo = NULL;
	string SapDmlNoDup = NULL;
	string SapDescription = NULL;
	string SapDescriptionDup = NULL;
	string date_updated = NULL;
	string date_updatedDup = NULL;
	SqlPtr sqlPtr = NULL;
	char std_release_date[11]={0};

	printf("\nchange no create");
//	hRfc = BapiLogon();
	printf("setSize(Dmlso):%d",setSize(Dmlso));
	if(setSize(Dmlso)<=0)
	{
		if(dstat = ExpandObject5("CmRslts",VCObj,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION ,&taskObjs,&mfail)) goto CLEANUP;
		if(dstat = objGetAttribute(setGet(taskObjs,0),"WbsID",&taskId))goto CLEANUP;
		if(!nlsIsStrNull(taskId))
		{
			taskIdDup = nlsStrDup(taskId);
		}
		if(dstat = oiSqlCreateSelect(&sqlPtr) | oiSqlWhereBegParen(sqlPtr) | oiSqlWhereEQ(sqlPtr,"WbsID",taskIdDup) | oiSqlWhereEndParen(sqlPtr))goto CLEANUP;
		if(dstat = QueryWhere3("CmTaskIt", sqlPtr, 1, SC_SCOPE_OF_SESSION, &taskRevObjs, &mfail))goto CLEANUP;
		if (setSize(taskRevObjs)==0)
		{
			printf("\nTask Not Found Can not create change no");
			fprintf(fsuccess,"\nTask Not Found Can not create change no");
			goto CLEANUP;
		}
		//printf("\n...1");
		fflush(stdout);
		if(dstat= ExpandObject5("CmPlRvRv",setGet(taskRevObjs,0),"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&DmlObjs,&mfail)) goto CLEANUP;
		if(setSize(DmlObjs)==0)
		{
			printf("\nNot Attached to any DML Can not create change no");
			fprintf(fsuccess,"\nNot Attached to any DML Can not create change no");
			goto CLEANUP;
		}
		//printf("\n...2");
		fflush(stdout);
	}
	else
	{
		DmlObjs = setCreate(setSize(Dmlso));
		setCopy(DmlObjs,Dmlso);
	}

	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsID",&SapDmlNo))goto CLEANUP;
	if(!nlsIsStrNull(SapDmlNo))
	{
		SapDmlNoDup = nlsStrDup(SapDmlNo);
		nlsStrCpy(SapChangeNo,SapDmlNoDup);
		nlsStrCat(SapChangeNo,"EE");
	}
	printf("\n...3");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsDescription",&SapDescription))goto CLEANUP;
	if(!nlsIsStrNull(SapDescription))
	{
		SapDescriptionDup = nlsStrDup(SapDescription);
	}
	printf("\n...4");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0), "ClosureTimeStamp", &date_updated))goto CLEANUP;
	if(!nlsIsStrNull(date_updated))
	{
		date_updatedDup = nlsStrDup(date_updated);
	}
	printf("\n...5:%s",date_updatedDup);
	fflush(stdout);
	std_release_date[0]=*(date_updatedDup+8);
	std_release_date[1]=*(date_updatedDup+9);
	std_release_date[2]='.';
	std_release_date[3]=*(date_updatedDup+5);
	std_release_date[4]=*(date_updatedDup+6);
	std_release_date[5]='.';
	std_release_date[6]=*(date_updatedDup+0);
	std_release_date[7]=*(date_updatedDup+1);
	std_release_date[8]=*(date_updatedDup+2);
	std_release_date[9]=*(date_updatedDup+3);
	std_release_date[10]='\0';

	printf("\n...");
	fflush(stdout);
	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);
	fflush(stdout);
	fprintf(fsuccess,"\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);


	printf("\nCalling json for change no"); fflush(stdout);
	char *out;



	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	AltDates_req = cJSON_CreateObject();
	AltDates_item_req = cJSON_CreateObject();
	ChangeHeader_req = cJSON_CreateObject();
	Effectivity_req = cJSON_CreateObject();
	Effectivity_item_req = cJSON_CreateObject();
	ObjectBom_req = cJSON_CreateObject();
	Object084_req = cJSON_CreateObject();
	ObjectBomCus_req = cJSON_CreateObject();
	ObjectBomDoc_req = cJSON_CreateObject();
	ObjectBomEqui_req = cJSON_CreateObject();
	ObjectBomLoc_req = cJSON_CreateObject();
	ObjectBomMat_req = cJSON_CreateObject();
	ObjectBomPsp_req = cJSON_CreateObject();
	ObjectBomStd_req = cJSON_CreateObject();
	ObjectChar_req = cJSON_CreateObject();
	ObjectCls_req = cJSON_CreateObject();
	ObjectClsMaint_req = cJSON_CreateObject();
	ObjectConfProf_req = cJSON_CreateObject();
	ObjectDep_req = cJSON_CreateObject();
	ObjectDoc_req = cJSON_CreateObject();
	ObjectHazmat_req = cJSON_CreateObject();
	ObjectMat_req = cJSON_CreateObject();
	ObjectO75_req = cJSON_CreateObject();
	ObjectO76_req = cJSON_CreateObject();
	ObjectO77_req = cJSON_CreateObject();
	ObjectO78_req = cJSON_CreateObject();
	ObjectO79_req = cJSON_CreateObject();
	ObjectO80_req = cJSON_CreateObject();
	ObjectO81_req = cJSON_CreateObject();
	ObjectO82_req = cJSON_CreateObject();
	ObjectO83_req = cJSON_CreateObject();
	ObjectO85_req = cJSON_CreateObject();
	ObjectO86_req = cJSON_CreateObject();
	ObjectO87_req = cJSON_CreateObject();
	ObjectO88_req = cJSON_CreateObject();
	ObjectO89_req = cJSON_CreateObject();
	ObjectO90_req = cJSON_CreateObject();
	ObjectO91_req = cJSON_CreateObject();
	ObjectO92_req = cJSON_CreateObject();
	ObjectO93_req = cJSON_CreateObject();
	ObjectO94_req = cJSON_CreateObject();
	ObjectO95_req = cJSON_CreateObject();
	ObjectO96_req = cJSON_CreateObject();
	ObjectO97_req = cJSON_CreateObject();
	ObjectO98_req = cJSON_CreateObject();
	ObjectO99_req = cJSON_CreateObject();
	ObjectPhrase_req = cJSON_CreateObject();
	ObjectPvs_req = cJSON_CreateObject();
	ObjectPvsAlt_req = cJSON_CreateObject();
	ObjectPvsRel_req = cJSON_CreateObject();
	ObjectPvsVar_req = cJSON_CreateObject();
	ObjectSubstance_req = cJSON_CreateObject();
	ObjectTlist_req = cJSON_CreateObject();
	ObjectTlistA_req = cJSON_CreateObject();
	ObjectTlistE_req = cJSON_CreateObject();
	ObjectTlistM_req = cJSON_CreateObject();
	ObjectTlistN_req = cJSON_CreateObject();
	ObjectTlistQ_req = cJSON_CreateObject();
	ObjectTlistR_req = cJSON_CreateObject();
	ObjectTlistS_req = cJSON_CreateObject();
	ObjectTlistT_req = cJSON_CreateObject();
	ObjectTlist_2_req = cJSON_CreateObject();
	ObjectValidMatvers_req = cJSON_CreateObject();
	ObjectVarTab_req = cJSON_CreateObject();

	Objmgrec_req = cJSON_CreateObject();
	Objmgrec_item_req = cJSON_CreateObject();

	Textheader_req = cJSON_CreateObject();
	Textheader_item_req = cJSON_CreateObject();

	Textlines_req = cJSON_CreateObject();
	Textlines_item_req = cJSON_CreateObject();

	ValueAssign_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "CcapEcnCreate", exp_imp_tab_req);

	/*cJSON_AddItemToObject(exp_imp_tab_req, "AltDates", AltDates_req);
		cJSON_AddItemToObject(AltDates_req, "item", AltDates_item_req);
			cJSON_AddItemToObject(AltDates_item_req, "AltDate", cJSON_CreateString(erc_release_date));//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "ValidFrom", cJSON_CreateString(erc_release_date));//07.02.2025//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "FlDelete", cJSON_CreateString(""));*/

	SapDescriptionDup[39] = '\0';
	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);


	cJSON_AddItemToObject(exp_imp_tab_req, "ChangeHeader", ChangeHeader_req);
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeNo", cJSON_CreateString(SapChangeNo));//dml_numER//"CORRCT070225"
		cJSON_AddItemToObject(ChangeHeader_req, "Status", cJSON_CreateString("01"));
		cJSON_AddItemToObject(ChangeHeader_req, "AuthGroup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ValidFrom", cJSON_CreateString(std_release_date));//07022025//erc_release_date
		//cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(DMLDescription));//DMLDescription//"DBK TEST REST API POC"
		cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(SapDescriptionDup));
		cJSON_AddItemToObject(ChangeHeader_req, "ReasonChg", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "DeletionMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "IndateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OutdateRule", cJSON_CreateString(""));

		cJSON_AddItemToObject(ChangeHeader_req, "Function", cJSON_CreateString(""));//Disable for with release key
		cJSON_AddItemToObject(ChangeHeader_req, "ReleaseKey", cJSON_CreateString(""));//Disable for with release key

		cJSON_AddItemToObject(ChangeHeader_req, "ChangeLeader", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "EffectivityType", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OverridingMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Rank", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "StatusProfile", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "TechRel", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "BasicChange", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Effectivity", Effectivity_req);
		cJSON_AddItemToObject(Effectivity_req, "item", Effectivity_item_req);
			cJSON_AddItemToObject(Effectivity_item_req, "ValidFrom", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "ValidTo", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "DateMark", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Material", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrLow", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrHigh", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Product", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Class", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Classty", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Startup", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Locno", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SernrOi", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "FlDelete", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "FlAle", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlCommitAndWait", cJSON_CreateString("X"));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlNoCommitWork", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "IvAccessUseCase", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBom", ObjectBom_req);
		cJSON_AddItemToObject(ObjectBom_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomCus", ObjectBomCus_req);
		cJSON_AddItemToObject(ObjectBomCus_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenDialog", cJSON_CreateString(""));


		cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomDoc", ObjectBomDoc_req);
		cJSON_AddItemToObject(ObjectBomDoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomEqui", ObjectBomEqui_req);
		cJSON_AddItemToObject(ObjectBomEqui_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomLoc", ObjectBomLoc_req);
		cJSON_AddItemToObject(ObjectBomLoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomMat", ObjectBomMat_req);
		cJSON_AddItemToObject(ObjectBomMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectBomMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomPsp", ObjectBomPsp_req);
		cJSON_AddItemToObject(ObjectBomPsp_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomStd", ObjectBomStd_req);
		cJSON_AddItemToObject(ObjectBomStd_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectChar", ObjectChar_req);
		cJSON_AddItemToObject(ObjectChar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectCls", ObjectCls_req);
		cJSON_AddItemToObject(ObjectCls_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectClsMaint", ObjectClsMaint_req);
		cJSON_AddItemToObject(ObjectClsMaint_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectConfProf", ObjectConfProf_req);
		cJSON_AddItemToObject(ObjectConfProf_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDep", ObjectDep_req);
		cJSON_AddItemToObject(ObjectDep_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDoc", ObjectDoc_req);
		cJSON_AddItemToObject(ObjectDoc_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectHazmat", ObjectHazmat_req);
		cJSON_AddItemToObject(ObjectHazmat_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectMat", ObjectMat_req);
		cJSON_AddItemToObject(ObjectMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO75", ObjectO75_req);
		cJSON_AddItemToObject(ObjectO75_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO76", ObjectO76_req);
		cJSON_AddItemToObject(ObjectO76_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO77", ObjectO77_req);
		cJSON_AddItemToObject(ObjectO77_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO78", ObjectO78_req);
		cJSON_AddItemToObject(ObjectO78_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO79", ObjectO79_req);
		cJSON_AddItemToObject(ObjectO79_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO80", ObjectO80_req);
		cJSON_AddItemToObject(ObjectO80_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO81", ObjectO81_req);
		cJSON_AddItemToObject(ObjectO81_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO82", ObjectO82_req);
		cJSON_AddItemToObject(ObjectO82_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO83", ObjectO83_req);
		cJSON_AddItemToObject(ObjectO83_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Object084", Object084_req);
		cJSON_AddItemToObject(Object084_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenDialog", cJSON_CreateString(""));




	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO85", ObjectO85_req);
		cJSON_AddItemToObject(ObjectO85_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO86", ObjectO86_req);
		cJSON_AddItemToObject(ObjectO86_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO87", ObjectO87_req);
		cJSON_AddItemToObject(ObjectO87_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO88", ObjectO88_req);
		cJSON_AddItemToObject(ObjectO88_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO89", ObjectO89_req);
		cJSON_AddItemToObject(ObjectO89_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO90", ObjectO90_req);
		cJSON_AddItemToObject(ObjectO90_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO91", ObjectO91_req);
		cJSON_AddItemToObject(ObjectO91_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO92", ObjectO92_req);
		cJSON_AddItemToObject(ObjectO92_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO93", ObjectO93_req);
		cJSON_AddItemToObject(ObjectO93_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO94", ObjectO94_req);
		cJSON_AddItemToObject(ObjectO94_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO95", ObjectO95_req);
		cJSON_AddItemToObject(ObjectO95_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO96", ObjectO96_req);
		cJSON_AddItemToObject(ObjectO96_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO97", ObjectO97_req);
		cJSON_AddItemToObject(ObjectO97_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO98", ObjectO98_req);
		cJSON_AddItemToObject(ObjectO98_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO99", ObjectO99_req);
		cJSON_AddItemToObject(ObjectO99_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPhrase", ObjectPhrase_req);
		cJSON_AddItemToObject(ObjectPhrase_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvs", ObjectPvs_req);
		cJSON_AddItemToObject(ObjectPvs_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsAlt", ObjectPvsAlt_req);
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsRel", ObjectPvsRel_req);
		cJSON_AddItemToObject(ObjectPvsRel_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenDialog", cJSON_CreateString(""));*/


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsVar", ObjectPvsVar_req);
		cJSON_AddItemToObject(ObjectPvsVar_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "MgtrecGen", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectSubstance", ObjectSubstance_req);
		cJSON_AddItemToObject(ObjectSubstance_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist", ObjectTlist_req);
		cJSON_AddItemToObject(ObjectTlist_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistA", ObjectTlistA_req);
		cJSON_AddItemToObject(ObjectTlistA_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistE", ObjectTlistE_req);
		cJSON_AddItemToObject(ObjectTlistE_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistM", ObjectTlistM_req);
		cJSON_AddItemToObject(ObjectTlistM_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistN", ObjectTlistN_req);
		cJSON_AddItemToObject(ObjectTlistN_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistQ", ObjectTlistQ_req);
		cJSON_AddItemToObject(ObjectTlistQ_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistR", ObjectTlistR_req);
		cJSON_AddItemToObject(ObjectTlistR_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistS", ObjectTlistS_req);
		cJSON_AddItemToObject(ObjectTlistS_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistT", ObjectTlistT_req);
		cJSON_AddItemToObject(ObjectTlistT_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist_2", ObjectTlist_2_req);
		cJSON_AddItemToObject(ObjectTlist_2_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectValidMatvers", ObjectValidMatvers_req);
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectVarTab", ObjectVarTab_req);
		cJSON_AddItemToObject(ObjectVarTab_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "Objmgrec", Objmgrec_req);
		cJSON_AddItemToObject(Objmgrec_req, "item", Objmgrec_item_req);
			cJSON_AddItemToObject(Objmgrec_item_req, "AltDate", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ChgObjtyp", cJSON_CreateString(""));//"4"
			cJSON_AddItemToObject(Objmgrec_item_req, "BomCat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomStdObject", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomUsage", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Chgtypeobj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DescrObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocVers", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocPart", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Equipment", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FuncLoc", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Material", cJSON_CreateString(""));/*PartNumC*/
			cJSON_AddItemToObject(Objmgrec_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PspElement", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsGuid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsNode", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsVariant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrder", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrderI", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistGrp", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ObjChglock", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "StatusProfObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FlDelete", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Textheader", Textheader_req);
		cJSON_AddItemToObject(Textheader_req, "item", Textheader_item_req);
			cJSON_AddItemToObject(Textheader_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdname", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdspras", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Textlines", Textlines_req);
		cJSON_AddItemToObject(Textlines_req, "item", Textlines_item_req);
			cJSON_AddItemToObject(Textlines_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdformat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdline", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ValueAssign", ValueAssign_req);
		cJSON_AddItemToObject(ValueAssign_req, "ValidFrom", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "ValidTo", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "DateMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Material", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrLow", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrHigh", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Product", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Class", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Classty", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Startup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Plant", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Locno", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SernrOi", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "FlDelete", cJSON_CreateString(""));*/

	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);

	strcpy(json_req_obj,out);

	free(out);
	cJSON_Delete(rfc_root);
	printf("\nend json for change no : [%zu]",strlen(json_req_obj)); fflush(stdout);
	CLEANUP:
	return 0;
}

int cll_ccap_ecn_create(SetOfObjects Dmlso,ObjectPtr VCObj)
{
	char *json_req_obj = NULL;
	json_req_obj = malloc(34000);
	change_no_json_cr ( Dmlso, VCObj, json_req_obj );
	//printf("%s\n", json_req_obj);

	create_change_no_in_sap ( json_req_obj ) ;

	free(json_req_obj);
	return 0;
}
/*void cll_ccap_ecn_create(SetOfObjects Dmlso,ObjectPtr VCObj)
{

	static RFC_RC RfcRc;
	RFC_HANDLE hRfc;

	char SapChangeNo[13]={0};

	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];
	SetOfObjects taskObjs = NULL;
	SetOfObjects taskRevObjs = NULL;
	SetOfObjects DmlObjs = NULL;
	integer mfail = OKAY;
	status dstat = OKAY;
	string taskId = NULL;
	string taskIdDup = NULL;
	string SapDmlNo = NULL;
	string SapDmlNoDup = NULL;
	string SapDescription = NULL;
	string SapDescriptionDup = NULL;
	string date_updated = NULL;
	string date_updatedDup = NULL;
	SqlPtr sqlPtr = NULL;
	char std_release_date[11]={0};

	printf("\nchange no create");
	hRfc = BapiLogon();
	printf("setSize(Dmlso):%d",setSize(Dmlso));
	if(setSize(Dmlso)<=0)
	{
		if(dstat = ExpandObject5("CmRslts",VCObj,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION ,&taskObjs,&mfail)) goto CLEANUP;
		if(dstat = objGetAttribute(setGet(taskObjs,0),"WbsID",&taskId))goto CLEANUP;
		if(!nlsIsStrNull(taskId))
		{
			taskIdDup = nlsStrDup(taskId);
		}
		if(dstat = oiSqlCreateSelect(&sqlPtr) | oiSqlWhereBegParen(sqlPtr) | oiSqlWhereEQ(sqlPtr,"WbsID",taskIdDup) | oiSqlWhereEndParen(sqlPtr))goto CLEANUP;
		if(dstat = QueryWhere3("CmTaskIt", sqlPtr, 1, SC_SCOPE_OF_SESSION, &taskRevObjs, &mfail))goto CLEANUP;
		if (setSize(taskRevObjs)==0)
		{
			printf("\nTask Not Found Can not create change no");
			fprintf(fsuccess,"\nTask Not Found Can not create change no");
			goto CLEANUP;
		}
		printf("\n...1");
		fflush(stdout);
		if(dstat= ExpandObject5("CmPlRvRv",setGet(taskRevObjs,0),"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&DmlObjs,&mfail)) goto CLEANUP;
		if(setSize(DmlObjs)==0)
		{
			printf("\nNot Attached to any DML Can not create change no");
			fprintf(fsuccess,"\nNot Attached to any DML Can not create change no");
			goto CLEANUP;
		}
		printf("\n...2");
		fflush(stdout);
	}
	else
	{
		DmlObjs = setCreate(setSize(Dmlso));
		setCopy(DmlObjs,Dmlso);
	}

	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsID",&SapDmlNo))goto CLEANUP;
	if(!nlsIsStrNull(SapDmlNo))
	{
		SapDmlNoDup = nlsStrDup(SapDmlNo);
		nlsStrCpy(SapChangeNo,SapDmlNoDup);
		nlsStrCat(SapChangeNo,"EE");
	}
	printf("\n...3");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsDescription",&SapDescription))goto CLEANUP;
	if(!nlsIsStrNull(SapDescription))
	{
		SapDescriptionDup = nlsStrDup(SapDescription);
	}
	printf("\n...4");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0), "ClosureTimeStamp", &date_updated))goto CLEANUP;
	if(!nlsIsStrNull(date_updated))
	{
		date_updatedDup = nlsStrDup(date_updated);
	}
	printf("\n...5:%s",date_updatedDup);
	fflush(stdout);
	std_release_date[0]=*(date_updatedDup+8);
	std_release_date[1]=*(date_updatedDup+9);
	std_release_date[2]='.';
	std_release_date[3]=*(date_updatedDup+5);
	std_release_date[4]=*(date_updatedDup+6);
	std_release_date[5]='.';
	std_release_date[6]=*(date_updatedDup+0);
	std_release_date[7]=*(date_updatedDup+1);
	std_release_date[8]=*(date_updatedDup+2);
	std_release_date[9]=*(date_updatedDup+3);
	std_release_date[10]='\0';

	printf("\n...");
	fflush(stdout);
	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);
	fflush(stdout);
	fprintf(fsuccess,"\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);



	SETCHAR(eChangeHeader.ChangeNo,SapChangeNo);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");
	SETCHAR(eChangeHeader.ValidFrom,std_release_date);
	SETCHAR(eChangeHeader.Descript,SapDescriptionDup);

	//Disable for with release key
	SETCHAR(eChangeHeader.Function,"");
	SETNUM(eChangeHeader.ReleaseKey,"");

	//Enable for with release key
	//SETCHAR(eChangeHeader.Function,"1");
	//SETNUM(eChangeHeader.ReleaseKey,"00");


	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"X");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"X");
	SETCHAR(eObjectPvsVar.MgtrecGen,"X");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");
	 if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	 }
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");


	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
			{
			case RFC_OK:
				printf("\necn create: %u",RFC_OK);
				fprintf(fsuccess,"\necn create: %d",RFC_OK);
		    	break;
			case RFC_EXCEPTION:
				printf("\nRFC Exception: %s",xException);
				break;
            default: ;
			}
	RfcClose(hRfc);
	CLEANUP:
		printf("\nChangeNumberCreation");
		fprintf(fsuccess,"\nChangeNumberCreation");
}
*/

int create_change_no_in_sapST ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;

	//const char *data = readd_sap_request_json_file();

	//printf("\nFile request content as below : %s",data);

	//curl_easy_setopt(curl, CURLOPT_URL, api_url);
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_DEV");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//ccap_ecn_create DEV
	//curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//ccap_ecn_create
	//curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential

	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_CcapEcnCreate_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");
    //curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);

	//curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, 12L);
	//curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\nFile request content as below "); fflush(stdout);
	print_json_object ( data ) ;

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

		printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

		printf("\ncurl_easy_setopt"); fflush(stdout);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

		printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	//printf ("\nresponse : [%s] [%d]",chunk.response,strlen(chunk.response)) ;
	printf("\ncurl_easy_perform");fflush(stdout);
	//print_json_object ( chunk.response ) ;
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "CHANGE_NO");

		printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

		printf("\nfree"); fflush(stdout);

    curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}

int change_no_json_crST( SetOfObjects Dmlso,ObjectPtr VCObj, char *json_req_objST)
{

	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *AltDates_req;
	cJSON *AltDates_item_req;
	cJSON *ChangeHeader_req;
	cJSON *Effectivity_req;
	cJSON *Effectivity_item_req;
	cJSON *ObjectBom_req;
	cJSON *Object084_req;
	cJSON *ObjectBomCus_req;
	cJSON *ObjectBomDoc_req;
	cJSON *ObjectBomEqui_req;
	cJSON *ObjectBomLoc_req;
	cJSON *ObjectBomMat_req;
	cJSON *ObjectBomPsp_req;
	cJSON *ObjectBomStd_req;
	cJSON *ObjectChar_req;
	cJSON *ObjectCls_req;
	cJSON *ObjectClsMaint_req;
	cJSON *ObjectConfProf_req;
	cJSON *ObjectDep_req;
	cJSON *ObjectDoc_req;
	cJSON *ObjectHazmat_req;
	cJSON *ObjectMat_req;
	cJSON *ObjectO75_req;
	cJSON *ObjectO76_req;
	cJSON *ObjectO77_req;
	cJSON *ObjectO78_req;
	cJSON *ObjectO79_req;
	cJSON *ObjectO80_req;
	cJSON *ObjectO81_req;
	cJSON *ObjectO82_req;
	cJSON *ObjectO83_req;
	cJSON *ObjectO85_req;
	cJSON *ObjectO86_req;
	cJSON *ObjectO87_req;
	cJSON *ObjectO88_req;
	cJSON *ObjectO89_req;
	cJSON *ObjectO90_req;
	cJSON *ObjectO91_req;
	cJSON *ObjectO92_req;
	cJSON *ObjectO93_req;
	cJSON *ObjectO94_req;
	cJSON *ObjectO95_req;
	cJSON *ObjectO96_req;
	cJSON *ObjectO97_req;
	cJSON *ObjectO98_req;
	cJSON *ObjectO99_req;
	cJSON *ObjectPhrase_req;
	cJSON *ObjectPvs_req;
	cJSON *ObjectPvsAlt_req;
	cJSON *ObjectPvsRel_req;
	cJSON *ObjectPvsVar_req;
	cJSON *ObjectSubstance_req;
	cJSON *ObjectTlist_req;
	cJSON *ObjectTlistA_req;
	cJSON *ObjectTlistE_req;
	cJSON *ObjectTlistM_req;
	cJSON *ObjectTlistN_req;
	cJSON *ObjectTlistQ_req;
	cJSON *ObjectTlistR_req;
	cJSON *ObjectTlistS_req;
	cJSON *ObjectTlistT_req;
	cJSON *ObjectTlist_2_req;
	cJSON *ObjectValidMatvers_req;
	cJSON *ObjectVarTab_req;

	cJSON *Objmgrec_req;
	cJSON *Objmgrec_item_req;

	cJSON *Textheader_req;
	cJSON *Textheader_item_req;

	cJSON *Textlines_req;
	cJSON *Textlines_item_req;

	cJSON *ValueAssign_req;


	SetOfObjects taskObjs = NULL;
	SetOfObjects taskRevObjs = NULL;
	SetOfObjects DmlObjs = NULL;
	integer mfail = OKAY;
	status dstat = OKAY;
	string taskId = NULL;
	string taskIdDup = NULL;
	string SapDmlNo = NULL;
	string SapDmlNoDup = NULL;
	string SapDescription = NULL;
	string SapDescriptionDup = NULL;
	string date_updated = NULL;
	string date_updatedDup = NULL;
	SqlPtr sqlPtr = NULL;
	char std_release_date[11]={0};
	char SapChangeNo[13]={0};

	printf("\nchange no create");
	//hRfc = BapiLogon();
	printf("setSize(Dmlso):%d",setSize(Dmlso));
	if(setSize(Dmlso)<=0)
	{
		if(dstat = ExpandObject5("CmRslts",VCObj,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION ,&taskObjs,&mfail)) goto CLEANUP;
		if(dstat = objGetAttribute(setGet(taskObjs,0),"WbsID",&taskId))goto CLEANUP;
		if(!nlsIsStrNull(taskId))
		{
			taskIdDup = nlsStrDup(taskId);
		}
		if(dstat = oiSqlCreateSelect(&sqlPtr) | oiSqlWhereBegParen(sqlPtr) | oiSqlWhereEQ(sqlPtr,"WbsID",taskIdDup) | oiSqlWhereEndParen(sqlPtr))goto CLEANUP;
		if(dstat = QueryWhere3("CmTaskIt", sqlPtr, 1, SC_SCOPE_OF_SESSION, &taskRevObjs, &mfail))goto CLEANUP;
		if (setSize(taskRevObjs)==0)
		{
			printf("\nTask Not Found Can not create change no");
			fprintf(fsuccess,"\nTask Not Found Can not create change no");
			goto CLEANUP;
		}
		//printf("\n...1");
		fflush(stdout);
		if(dstat= ExpandObject5("CmPlRvRv",setGet(taskRevObjs,0),"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&DmlObjs,&mfail)) goto CLEANUP;
		if(setSize(DmlObjs)==0)
		{
			printf("\nNot Attached to any DML Can not create change no");
			fprintf(fsuccess,"\nNot Attached to any DML Can not create change no");
			goto CLEANUP;
		}
		//printf("\n...2");
		fflush(stdout);
	}
	else
	{
		DmlObjs = setCreate(setSize(Dmlso));
		setCopy(DmlObjs,Dmlso);
	}

	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsID",&SapDmlNo))goto CLEANUP;
	if(!nlsIsStrNull(SapDmlNo))
	{
		SapDmlNoDup = nlsStrDup(SapDmlNo);
		nlsStrCpy(SapChangeNo,SapDmlNoDup);
		nlsStrCat(SapChangeNo,"EE");
	}
	//printf("\n...3");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsDescription",&SapDescription))goto CLEANUP;
	if(!nlsIsStrNull(SapDescription))
	{
		SapDescriptionDup = nlsStrDup(SapDescription);
	}
	//printf("\n...4");
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0), "ClosureTimeStamp", &date_updated))goto CLEANUP;
	if(!nlsIsStrNull(date_updated))
	{
		date_updatedDup = nlsStrDup(date_updated);
	}
	//printf("\n...5:%s",date_updatedDup);
	fflush(stdout);
	std_release_date[0]=*(date_updatedDup+8);
	std_release_date[1]=*(date_updatedDup+9);
	std_release_date[2]='.';
	std_release_date[3]=*(date_updatedDup+5);
	std_release_date[4]=*(date_updatedDup+6);
	std_release_date[5]='.';
	std_release_date[6]=*(date_updatedDup+0);
	std_release_date[7]=*(date_updatedDup+1);
	std_release_date[8]=*(date_updatedDup+2);
	std_release_date[9]=*(date_updatedDup+3);
	std_release_date[10]='\0';
	
	SapDescriptionDup[39] = '\0';
	//printf("\n...");
	fflush(stdout);
	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);
	fflush(stdout);
	fprintf(fsuccess,"\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);


	printf("\nCalling json for change no ST"); fflush(stdout);
	char *out;



	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	AltDates_req = cJSON_CreateObject();
	AltDates_item_req = cJSON_CreateObject();
	ChangeHeader_req = cJSON_CreateObject();
	Effectivity_req = cJSON_CreateObject();
	Effectivity_item_req = cJSON_CreateObject();
	ObjectBom_req = cJSON_CreateObject();
	Object084_req = cJSON_CreateObject();
	ObjectBomCus_req = cJSON_CreateObject();
	ObjectBomDoc_req = cJSON_CreateObject();
	ObjectBomEqui_req = cJSON_CreateObject();
	ObjectBomLoc_req = cJSON_CreateObject();
	ObjectBomMat_req = cJSON_CreateObject();
	ObjectBomPsp_req = cJSON_CreateObject();
	ObjectBomStd_req = cJSON_CreateObject();
	ObjectChar_req = cJSON_CreateObject();
	ObjectCls_req = cJSON_CreateObject();
	ObjectClsMaint_req = cJSON_CreateObject();
	ObjectConfProf_req = cJSON_CreateObject();
	ObjectDep_req = cJSON_CreateObject();
	ObjectDoc_req = cJSON_CreateObject();
	ObjectHazmat_req = cJSON_CreateObject();
	ObjectMat_req = cJSON_CreateObject();
	ObjectO75_req = cJSON_CreateObject();
	ObjectO76_req = cJSON_CreateObject();
	ObjectO77_req = cJSON_CreateObject();
	ObjectO78_req = cJSON_CreateObject();
	ObjectO79_req = cJSON_CreateObject();
	ObjectO80_req = cJSON_CreateObject();
	ObjectO81_req = cJSON_CreateObject();
	ObjectO82_req = cJSON_CreateObject();
	ObjectO83_req = cJSON_CreateObject();
	ObjectO85_req = cJSON_CreateObject();
	ObjectO86_req = cJSON_CreateObject();
	ObjectO87_req = cJSON_CreateObject();
	ObjectO88_req = cJSON_CreateObject();
	ObjectO89_req = cJSON_CreateObject();
	ObjectO90_req = cJSON_CreateObject();
	ObjectO91_req = cJSON_CreateObject();
	ObjectO92_req = cJSON_CreateObject();
	ObjectO93_req = cJSON_CreateObject();
	ObjectO94_req = cJSON_CreateObject();
	ObjectO95_req = cJSON_CreateObject();
	ObjectO96_req = cJSON_CreateObject();
	ObjectO97_req = cJSON_CreateObject();
	ObjectO98_req = cJSON_CreateObject();
	ObjectO99_req = cJSON_CreateObject();
	ObjectPhrase_req = cJSON_CreateObject();
	ObjectPvs_req = cJSON_CreateObject();
	ObjectPvsAlt_req = cJSON_CreateObject();
	ObjectPvsRel_req = cJSON_CreateObject();
	ObjectPvsVar_req = cJSON_CreateObject();
	ObjectSubstance_req = cJSON_CreateObject();
	ObjectTlist_req = cJSON_CreateObject();
	ObjectTlistA_req = cJSON_CreateObject();
	ObjectTlistE_req = cJSON_CreateObject();
	ObjectTlistM_req = cJSON_CreateObject();
	ObjectTlistN_req = cJSON_CreateObject();
	ObjectTlistQ_req = cJSON_CreateObject();
	ObjectTlistR_req = cJSON_CreateObject();
	ObjectTlistS_req = cJSON_CreateObject();
	ObjectTlistT_req = cJSON_CreateObject();
	ObjectTlist_2_req = cJSON_CreateObject();
	ObjectValidMatvers_req = cJSON_CreateObject();
	ObjectVarTab_req = cJSON_CreateObject();

	Objmgrec_req = cJSON_CreateObject();
	Objmgrec_item_req = cJSON_CreateObject();

	Textheader_req = cJSON_CreateObject();
	Textheader_item_req = cJSON_CreateObject();

	Textlines_req = cJSON_CreateObject();
	Textlines_item_req = cJSON_CreateObject();

	ValueAssign_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "CcapEcnCreate", exp_imp_tab_req);

	/*cJSON_AddItemToObject(exp_imp_tab_req, "AltDates", AltDates_req);
		cJSON_AddItemToObject(AltDates_req, "item", AltDates_item_req);
			cJSON_AddItemToObject(AltDates_item_req, "AltDate", cJSON_CreateString(erc_release_date));//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "ValidFrom", cJSON_CreateString(erc_release_date));//07.02.2025//erc_release_date
			cJSON_AddItemToObject(AltDates_item_req, "FlDelete", cJSON_CreateString(""));*/

	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);


	cJSON_AddItemToObject(exp_imp_tab_req, "ChangeHeader", ChangeHeader_req);
		cJSON_AddItemToObject(ChangeHeader_req, "ChangeNo", cJSON_CreateString(SapChangeNo));//dml_numER//"CORRCT070225"
		cJSON_AddItemToObject(ChangeHeader_req, "Status", cJSON_CreateString("01"));
		cJSON_AddItemToObject(ChangeHeader_req, "AuthGroup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "ValidFrom", cJSON_CreateString(std_release_date));//07022025//erc_release_date
		//cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(DMLDescription));//DMLDescription//"DBK TEST REST API POC"
		cJSON_AddItemToObject(ChangeHeader_req, "Descript", cJSON_CreateString(SapDescriptionDup));
		cJSON_AddItemToObject(ChangeHeader_req, "ReasonChg", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "DeletionMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "IndateRule", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OutdateRule", cJSON_CreateString(""));

		cJSON_AddItemToObject(ChangeHeader_req, "Function", cJSON_CreateString("1"));//Disable for with release key
		cJSON_AddItemToObject(ChangeHeader_req, "ReleaseKey", cJSON_CreateString("00"));//Disable for with release key

		cJSON_AddItemToObject(ChangeHeader_req, "ChangeLeader", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "EffectivityType", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "OverridingMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "Rank", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "StatusProfile", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "TechRel", cJSON_CreateString(""));
		cJSON_AddItemToObject(ChangeHeader_req, "BasicChange", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Effectivity", Effectivity_req);
		cJSON_AddItemToObject(Effectivity_req, "item", Effectivity_item_req);
			cJSON_AddItemToObject(Effectivity_item_req, "ValidFrom", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "ValidTo", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "DateMark", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Material", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrLow", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SerialnrHigh", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Product", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Class", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Classty", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Startup", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "Locno", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "SernrOi", cJSON_CreateString(""));
			cJSON_AddItemToObject(Effectivity_item_req, "FlDelete", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "FlAle", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlCommitAndWait", cJSON_CreateString("X"));
	cJSON_AddItemToObject(exp_imp_tab_req, "FlNoCommitWork", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "IvAccessUseCase", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBom", ObjectBom_req);
		cJSON_AddItemToObject(ObjectBom_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBom_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomCus", ObjectBomCus_req);
		cJSON_AddItemToObject(ObjectBomCus_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomCus_req, "GenDialog", cJSON_CreateString(""));


		cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomDoc", ObjectBomDoc_req);
		cJSON_AddItemToObject(ObjectBomDoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomDoc_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomEqui", ObjectBomEqui_req);
		cJSON_AddItemToObject(ObjectBomEqui_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomEqui_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomLoc", ObjectBomLoc_req);
		cJSON_AddItemToObject(ObjectBomLoc_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomLoc_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomMat", ObjectBomMat_req);
		cJSON_AddItemToObject(ObjectBomMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectBomMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectBomMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomMat_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomPsp", ObjectBomPsp_req);
		cJSON_AddItemToObject(ObjectBomPsp_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomPsp_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectBomStd", ObjectBomStd_req);
		cJSON_AddItemToObject(ObjectBomStd_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectBomStd_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectChar", ObjectChar_req);
		cJSON_AddItemToObject(ObjectChar_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectChar_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectCls", ObjectCls_req);
		cJSON_AddItemToObject(ObjectCls_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectCls_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectClsMaint", ObjectClsMaint_req);
		cJSON_AddItemToObject(ObjectClsMaint_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectClsMaint_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectConfProf", ObjectConfProf_req);
		cJSON_AddItemToObject(ObjectConfProf_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectConfProf_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDep", ObjectDep_req);
		cJSON_AddItemToObject(ObjectDep_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDep_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectDoc", ObjectDoc_req);
		cJSON_AddItemToObject(ObjectDoc_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectDoc_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectDoc_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectDoc_req, "GenDialog", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectHazmat", ObjectHazmat_req);
		cJSON_AddItemToObject(ObjectHazmat_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectHazmat_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectMat", ObjectMat_req);
		cJSON_AddItemToObject(ObjectMat_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectMat_req, "MgtrecGen", cJSON_CreateString("X"));/*X*/
		cJSON_AddItemToObject(ObjectMat_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectMat_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO75", ObjectO75_req);
		cJSON_AddItemToObject(ObjectO75_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO75_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO76", ObjectO76_req);
		cJSON_AddItemToObject(ObjectO76_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO76_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO77", ObjectO77_req);
		cJSON_AddItemToObject(ObjectO77_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO77_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO78", ObjectO78_req);
		cJSON_AddItemToObject(ObjectO78_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO78_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO79", ObjectO79_req);
		cJSON_AddItemToObject(ObjectO79_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO79_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO80", ObjectO80_req);
		cJSON_AddItemToObject(ObjectO80_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO80_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO81", ObjectO81_req);
		cJSON_AddItemToObject(ObjectO81_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO81_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO82", ObjectO82_req);
		cJSON_AddItemToObject(ObjectO82_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO82_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO83", ObjectO83_req);
		cJSON_AddItemToObject(ObjectO83_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO83_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Object084", Object084_req);
		cJSON_AddItemToObject(Object084_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(Object084_req, "GenDialog", cJSON_CreateString(""));




	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO85", ObjectO85_req);
		cJSON_AddItemToObject(ObjectO85_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO85_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO86", ObjectO86_req);
		cJSON_AddItemToObject(ObjectO86_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO86_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO87", ObjectO87_req);
		cJSON_AddItemToObject(ObjectO87_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO87_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO88", ObjectO88_req);
		cJSON_AddItemToObject(ObjectO88_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO88_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO89", ObjectO89_req);
		cJSON_AddItemToObject(ObjectO89_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO89_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO90", ObjectO90_req);
		cJSON_AddItemToObject(ObjectO90_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO90_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO91", ObjectO91_req);
		cJSON_AddItemToObject(ObjectO91_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO91_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO92", ObjectO92_req);
		cJSON_AddItemToObject(ObjectO92_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO92_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO93", ObjectO93_req);
		cJSON_AddItemToObject(ObjectO93_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO93_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO94", ObjectO94_req);
		cJSON_AddItemToObject(ObjectO94_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO94_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO95", ObjectO95_req);
		cJSON_AddItemToObject(ObjectO95_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO95_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO96", ObjectO96_req);
		cJSON_AddItemToObject(ObjectO96_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO96_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO97", ObjectO97_req);
		cJSON_AddItemToObject(ObjectO97_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO97_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO98", ObjectO98_req);
		cJSON_AddItemToObject(ObjectO98_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO98_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectO99", ObjectO99_req);
		cJSON_AddItemToObject(ObjectO99_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectO99_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPhrase", ObjectPhrase_req);
		cJSON_AddItemToObject(ObjectPhrase_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPhrase_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvs", ObjectPvs_req);
		cJSON_AddItemToObject(ObjectPvs_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvs_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsAlt", ObjectPvsAlt_req);
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsAlt_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsRel", ObjectPvsRel_req);
		cJSON_AddItemToObject(ObjectPvsRel_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsRel_req, "GenDialog", cJSON_CreateString(""));*/


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectPvsVar", ObjectPvsVar_req);
		cJSON_AddItemToObject(ObjectPvsVar_req, "Active", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "ObjRequ", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "MgtrecGen", cJSON_CreateString("X"));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectPvsVar_req, "GenDialog", cJSON_CreateString(""));


	/*cJSON_AddItemToObject(exp_imp_tab_req, "ObjectSubstance", ObjectSubstance_req);
		cJSON_AddItemToObject(ObjectSubstance_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectSubstance_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist", ObjectTlist_req);
		cJSON_AddItemToObject(ObjectTlist_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistA", ObjectTlistA_req);
		cJSON_AddItemToObject(ObjectTlistA_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistA_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistE", ObjectTlistE_req);
		cJSON_AddItemToObject(ObjectTlistE_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistE_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistM", ObjectTlistM_req);
		cJSON_AddItemToObject(ObjectTlistM_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistM_req, "GenDialog", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistN", ObjectTlistN_req);
		cJSON_AddItemToObject(ObjectTlistN_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistN_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistQ", ObjectTlistQ_req);
		cJSON_AddItemToObject(ObjectTlistQ_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistQ_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistR", ObjectTlistR_req);
		cJSON_AddItemToObject(ObjectTlistR_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistR_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistS", ObjectTlistS_req);
		cJSON_AddItemToObject(ObjectTlistS_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistS_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlistT", ObjectTlistT_req);
		cJSON_AddItemToObject(ObjectTlistT_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlistT_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectTlist_2", ObjectTlist_2_req);
		cJSON_AddItemToObject(ObjectTlist_2_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectTlist_2_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectValidMatvers", ObjectValidMatvers_req);
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectValidMatvers_req, "GenDialog", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ObjectVarTab", ObjectVarTab_req);
		cJSON_AddItemToObject(ObjectVarTab_req, "Active", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "Locked", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "ObjRequ", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "MgtrecGen", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenNew", cJSON_CreateString(""));
		cJSON_AddItemToObject(ObjectVarTab_req, "GenDialog", cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "Objmgrec", Objmgrec_req);
		cJSON_AddItemToObject(Objmgrec_req, "item", Objmgrec_item_req);
			cJSON_AddItemToObject(Objmgrec_item_req, "AltDate", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ChgObjtyp", cJSON_CreateString(""));//"4"
			cJSON_AddItemToObject(Objmgrec_item_req, "BomCat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomStdObject", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "BomUsage", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Chgtypeobj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DescrObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocVers", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "DocPart", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Equipment", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FuncLoc", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Material", cJSON_CreateString(""));/*PartNumC*/
			cJSON_AddItemToObject(Objmgrec_item_req, "Plant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PspElement", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsGuid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsNode", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassNumber", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsClassType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "PvsVariant", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrder", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "SdOrderI", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistType", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "TlistGrp", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "ObjChglock", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "StatusProfObj", cJSON_CreateString(""));
			cJSON_AddItemToObject(Objmgrec_item_req, "FlDelete", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "Textheader", Textheader_req);
		cJSON_AddItemToObject(Textheader_req, "item", Textheader_item_req);
			cJSON_AddItemToObject(Textheader_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdname", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdid", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textheader_item_req, "Tdspras", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "Textlines", Textlines_req);
		cJSON_AddItemToObject(Textlines_req, "item", Textlines_item_req);
			cJSON_AddItemToObject(Textlines_item_req, "Textkey", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdformat", cJSON_CreateString(""));
			cJSON_AddItemToObject(Textlines_item_req, "Tdline", cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "ValueAssign", ValueAssign_req);
		cJSON_AddItemToObject(ValueAssign_req, "ValidFrom", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "ValidTo", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "DateMark", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Material", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrLow", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SerialnrHigh", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Product", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Class", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Classty", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Startup", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Plant", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "Locno", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "SernrOi", cJSON_CreateString(""));
		cJSON_AddItemToObject(ValueAssign_req, "FlDelete", cJSON_CreateString(""));*/

	out = cJSON_Print(rfc_root);
	//printf("%s\n", out);

	strcpy(json_req_objST,out);

	free(out);
	cJSON_Delete(rfc_root);
	printf("\nend json for change no : [%zu]",strlen(json_req_objST)); fflush(stdout);
	CLEANUP:
	return 0;
}
int cll_ccap_ecn_createST(SetOfObjects Dmlso,ObjectPtr VCObj)
{
	char *json_req_objST = NULL;
	json_req_objST = malloc(34000);
	change_no_json_crST ( Dmlso, VCObj, json_req_objST );
	//printf("%s\n", json_req_objST);

	create_change_no_in_sapST ( json_req_objST ) ;

	free(json_req_objST);
	return 0;
}
/*
void cll_ccap_ecn_createST(SetOfObjects Dmlso,ObjectPtr VCObj)
{
	static RFC_RC RfcRc;
	RFC_HANDLE hRfc;
	char SapChangeNo[13]={0};
	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];
	SetOfObjects taskObjs = NULL;
	SetOfObjects taskRevObjs = NULL;
	SetOfObjects DmlObjs = NULL;
	integer mfail = OKAY;
	status dstat = OKAY;
	string taskId = NULL;
	string taskIdDup = NULL;
	string SapDmlNo = NULL;
	string SapDmlNoDup = NULL;
	string SapDescription = NULL;
	string SapDescriptionDup = NULL;
	string date_updated = NULL;
	string date_updatedDup = NULL;
	SqlPtr sqlPtr = NULL;
	char std_release_date[11]={0};

	printf("\nchange no create");
	hRfc = BapiLogon();
	printf("setSize(Dmlso):%d",setSize(Dmlso));
	if(setSize(Dmlso)<=0)
	{
		if(dstat = ExpandObject5("CmRslts",VCObj,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION ,&taskObjs,&mfail)) goto CLEANUP;
		if(dstat = objGetAttribute(setGet(taskObjs,0),"WbsID",&taskId))goto CLEANUP;
		if(!nlsIsStrNull(taskId))
		{
			taskIdDup = nlsStrDup(taskId);
		}
		if(dstat = oiSqlCreateSelect(&sqlPtr) | oiSqlWhereBegParen(sqlPtr) | oiSqlWhereEQ(sqlPtr,"WbsID",taskIdDup) | oiSqlWhereEndParen(sqlPtr))goto CLEANUP;
		if(dstat = QueryWhere3("CmTaskIt", sqlPtr, 1, SC_SCOPE_OF_SESSION, &taskRevObjs, &mfail))goto CLEANUP;
		if (setSize(taskRevObjs)==0)
		{
			printf("\nTask Not Found Can not create change no");
			fprintf(fsuccess,"\nTask Not Found Can not create change no");
			goto CLEANUP;
		}
		if(dstat= ExpandObject5("CmPlRvRv",setGet(taskRevObjs,0),"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&DmlObjs,&mfail)) goto CLEANUP;
		if(setSize(DmlObjs)==0)
		{
			printf("\nNot Attached to any DML Can not create change no");
			fprintf(fsuccess,"\nNot Attached to any DML Can not create change no");
			goto CLEANUP;
		}
	}
	else
	{
		DmlObjs = setCreate(setSize(Dmlso));
		setCopy(DmlObjs,Dmlso);
	}

	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsID",&SapDmlNo))goto CLEANUP;
	if(!nlsIsStrNull(SapDmlNo))
	{
		SapDmlNoDup = nlsStrDup(SapDmlNo);
		nlsStrCpy(SapChangeNo,SapDmlNoDup);
		nlsStrCat(SapChangeNo,"EE");
	}
	fflush(stdout);
	if(dstat = objGetAttribute(setGet(DmlObjs,0),"WbsDescription",&SapDescription))goto CLEANUP;
	if(!nlsIsStrNull(SapDescription))
	{
		SapDescriptionDup = nlsStrDup(SapDescription);
	}
	//objDump(setGet(DmlObjs,0));
	if(dstat = objGetAttribute(setGet(DmlObjs,0), "ClosureTimeStamp", &date_updated))goto CLEANUP;
	if(!nlsIsStrNull(date_updated))
	{
		date_updatedDup = nlsStrDup(date_updated);
	}
	std_release_date[0]=*(date_updatedDup+8);
	std_release_date[1]=*(date_updatedDup+9);
	std_release_date[2]='.';
	std_release_date[3]=*(date_updatedDup+5);
	std_release_date[4]=*(date_updatedDup+6);
	std_release_date[5]='.';
	std_release_date[6]=*(date_updatedDup+0);
	std_release_date[7]=*(date_updatedDup+1);
	std_release_date[8]=*(date_updatedDup+2);
	std_release_date[9]=*(date_updatedDup+3);
	std_release_date[10]='\0';

	printf("\n...");
	fflush(stdout);
	printf("\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);
	fflush(stdout);
	fprintf(fsuccess,"\n[%s:%s]\tDescription:[%s]\tDate:[%s]",SapDmlNoDup,SapChangeNo,SapDescriptionDup,std_release_date);



	SETCHAR(eChangeHeader.ChangeNo,SapChangeNo);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");
	SETCHAR(eChangeHeader.ValidFrom,std_release_date);
	SETCHAR(eChangeHeader.Descript,SapDescriptionDup);

	//Disable for with release key
	//SETCHAR(eChangeHeader.Function,"");
	//SETNUM(eChangeHeader.ReleaseKey,"");

	//Enable for with release key
	SETCHAR(eChangeHeader.Function,"1");
	SETNUM(eChangeHeader.ReleaseKey,"00");


	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"X");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"X");
	SETCHAR(eObjectPvsVar.MgtrecGen,"X");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");
	if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	 }
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");


	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
			{
			case RFC_OK:
				printf("\necn create: %u",RFC_OK);
				fprintf(fsuccess,"\necn create: %d",RFC_OK);
		    	break;
			case RFC_EXCEPTION:
				printf("\nRFC Exception: %s",xException);
				break;
            default: ;
			}
	RfcClose(hRfc);
	CLEANUP:
		printf("\nChangeNumberCreation");
		fprintf(fsuccess,"\nChangeNumberCreation");
}
*/

int tm_curl_CAD_CREATE_BOM_WITH_SUB_ITEMS ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;


	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_CAD_CREATE_BOM_WITH_SUB_ITEMS_CV");//bom create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )//ecc QA  //S/4 HANA
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_CAD_CREATE_BOM_WITH_SUB_ITEMS_CV_QA");//bom create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_CAD_CREATE_BOM_WITH_SUB_ITEMS_CV");//bom create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\nsSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");

	printf("\nFile request content as below "); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object BOM_CREATE"); fflush(stdout);

	parse_json_object(chunk.response, "BOM_CREATE");

	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

	printf("\nfree"); fflush(stdout);

	curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int displayCreate(struct node *head,string assy_noDup, char *json_bom_create_in_plant_req_obj)
{
	struct node *p = NULL;
	char sap_qty[18];
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *BOM_ITEM_req;
	cJSON *BOM_ITEM_item_req;

	cJSON *BOM_SUB_ITEM_req;
	cJSON *BOM_SUB_ITEM_item_req;

	cJSON *DMS_CLASS_DATA_req;
	cJSON *DMS_CLASS_DATA_item_req;

	cJSON *I_BOM_HEADER_req;


	cJSON *SAP_FIELD_DATA_req;
	cJSON *SAP_FIELD_DATA_item_req;


	char *out;


	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	//BOM_ITEM_req = cJSON_CreateObject();
	//BOM_ITEM_item_req = cJSON_CreateObject();

	BOM_SUB_ITEM_req = cJSON_CreateObject();
	BOM_SUB_ITEM_item_req = cJSON_CreateObject();

	DMS_CLASS_DATA_req = cJSON_CreateObject();
	DMS_CLASS_DATA_item_req = cJSON_CreateObject();

	I_BOM_HEADER_req = cJSON_CreateObject();


	SAP_FIELD_DATA_req = cJSON_CreateObject();
	SAP_FIELD_DATA_item_req = cJSON_CreateObject();
	//tBomItem

	cJSON_AddItemToObject(rfc_root, "CAD_CREATE_BOM_WITH_SUB_ITEMS", exp_imp_tab_req);



	BOM_ITEM_req = cJSON_CreateObject();
	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_ITEM", BOM_ITEM_req);

	//for(p = head; p != NULL; p = p -> next)
	//{
	for(p = head; p != NULL; p = p -> next)
	{

		sprintf(sap_qty,"%7.3f", p->qty);

		BOM_ITEM_item_req = cJSON_CreateObject();
		cJSON_AddItemToObject(BOM_ITEM_req, "item", BOM_ITEM_item_req);

		//sprintf(sap_qty,"%7.3f", p->qty);
		nlsStrTrimTrailWhiteSpace(sap_qty);
		nlsStrTrimLeadWhiteSpace(sap_qty);
		printf("\n\t sap_qty [%s]",sap_qty);
		//printf("\n\t %s %-15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);
		//fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel);

			cJSON_AddItemToObject(BOM_ITEM_item_req, "UPSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPOS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSCH", cJSON_CreateString("0.00"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AVOAU", cJSON_CreateString("0.00"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "BEIKZ", cJSON_CreateString(p->mat_prov_ind));//p->mat_prov_ind//L//mat_prov_ind
			cJSON_AddItemToObject(BOM_ITEM_item_req, "CADPO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EKGRP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ERSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "FMENG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "IDNRK", cJSON_CreateString(p->part));//part
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFNR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFZT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MATKL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MEINS", cJSON_CreateString(p->uq));

			if ( *assy_noDup =='G' )
			{
				cJSON_AddItemToObject(BOM_ITEM_item_req, "MENGE", cJSON_CreateString("0000000001"));//1.000
			}
			else
			{
				cJSON_AddItemToObject(BOM_ITEM_item_req, "MENGE", cJSON_CreateString(sap_qty));//1.000
			}
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NETAU", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFMAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PEINH", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POSNR", cJSON_CreateString(p->sr_no));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POSTP", cJSON_CreateString("L"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PREIS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX1", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX2", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PSWRK", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "REKRS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RFORM", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROANZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROKME", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEI", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEN", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS1", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS2", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS3", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RVREL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SAKTO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANFE", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANIN", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKA", cJSON_CreateString(p->tempcsrel));//p->tempcsrel//1//tempcsrel
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANVS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SCHGT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELAL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELID", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELPO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELSB", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SORTF", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STKKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STKTX", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STLAL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STLKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "VERTI", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "WEBAZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "WAERS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKAR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKNR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKVR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKTL", cJSON_CreateString(""));

			cJSON_AddItemToObject(BOM_ITEM_item_req, "EKORG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LGORT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "CLASS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KLART", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTPR", cJSON_CreateString(""));




			if(*assy_noDup=='G')
			{
				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPGR", cJSON_CreateString("a1"));
				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPRF", cJSON_CreateString("1"));

				//if(nlsStrCmp(p->sr_no,"0001")==0)
				//{
				//	cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString("100"));
				//}
				//else
				//{
				cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString("000"));
				//}

				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPST", cJSON_CreateString(""));

			}
			else
			{
				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPGR", cJSON_CreateString(""));
				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPRF", cJSON_CreateString(""));
				cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString(""));
				cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPST", cJSON_CreateString(""));

			}
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DSPST", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PRVBE", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFEAG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFGRP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KZKUP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "INTRM", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KZCLB", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZV", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFMV", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RFPNT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MATNR_LONG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ITSOB", cJSON_CreateString(""));
	}

	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_SUB_ITEM", BOM_SUB_ITEM_req);
		cJSON_AddItemToObject(BOM_SUB_ITEM_req, "item", BOM_SUB_ITEM_item_req);
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "POSID", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "EBORT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPMNG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPOSZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPTXT", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "DMS_CLASS_DATA", DMS_CLASS_DATA_req);
		cJSON_AddItemToObject(DMS_CLASS_DATA_req, "item", DMS_CLASS_DATA_item_req);
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATNAM", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATBEZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATWRT", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "DINKB", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "UNIT", cJSON_CreateString(""));

	//eIAutoPosnr
	//eIBomHeader

	cJSON_AddItemToObject(exp_imp_tab_req, "I_AUTO_POSNR", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "I_BOM_HEADER", I_BOM_HEADER_req);
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STYPE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TCODE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "AENNR", cJSON_CreateString(EEDmlNumberST));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMEIN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "CADKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUB", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EQUNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EXSTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LABOR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOEKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSBS", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSVN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR", cJSON_CreateString(assy_noDup));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SELAL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SERGE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STKTX", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAL", cJSON_CreateString("01"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAN", cJSON_CreateString("1"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLBE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLST", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VMTNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "WERKS", cJSON_CreateString("1005"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "ZTEXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "REVLV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TPLNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBELN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBPOS", cJSON_CreateString("000000"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STOBJ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VEQNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VTPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "PSPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "OITXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR_LONG", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "SAP_FIELD_DATA", SAP_FIELD_DATA_req);
		cJSON_AddItemToObject(SAP_FIELD_DATA_req, "item", SAP_FIELD_DATA_item_req);
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDMULTI", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDNAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDVALUE", cJSON_CreateString(""));

	out = cJSON_Print(rfc_root);
	printf("in function SapBomCreate:[%s]", out);
	strcpy ( json_bom_create_in_plant_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	printf("\n end json for SapBomCreate : [%zu]",strlen(json_bom_create_in_plant_req_obj)); fflush(stdout);
	return 0;
}
/*void displayCreate(struct node *head,string assy_noDup)
{
	struct node *p=NULL;
	char sap_qty[18];
	int crow;
	char comp_sap[15];
	char xException[256];
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	char MessageRet[80];
	CAD_BICSK eIBomHeader;
	DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				printf("\nItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			printf("\nItFreeBOM_ITEM");
	}

	printf("\nAssembly: %s -> 1005 %s",assy_noDup,EEDmlNumberST);
	fprintf(fsuccess,"\nAssembly: %s -> 1005 %s",assy_noDup,EEDmlNumberST);


	SETCHAR(eIAutoPosnr,"");
	SETCHAR(eIBomHeader.Matnr,assy_noDup);
	SETCHAR(eIBomHeader.Werks,"1005");
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	SETCHAR(eIBomHeader.Aennr,EEDmlNumberST);
	SETCHAR(eIBomHeader.Datuv,"");
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Datub,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");



	for(p = head; p != NULL; p = p -> next)
	{


		sprintf(sap_qty,"%7.3f", p->qty);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
				printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Menge,"0000000001");
		}
		else
		{
			SETCHAR(tBomItem->Menge,sap_qty);
		}
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);

		if(nlsStrNCmp(assy_noDup,"G",1)==0)
		{
			SETCHAR(tBomItem->Alpgr,"a1");

			SETNUM(tBomItem->Alprf,"1");
			SETCHAR(tBomItem->Ewahr,"000");
			SETCHAR(tBomItem->Alpst,"1");
		}
		else
		{
			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");
		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		SETCHAR(tBomItem->Schgt,"");
		SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"0.00");
		SETCHAR(tBomItem->Avoau,"0.00");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");
	}

	RfcRc = cad_create_bom_with_sub_items(hRfc,&eIAutoPosnr,&eIBomHeader,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,xException);

	 switch (RfcRc)
	  {
	     case RFC_OK :
			for (crow = 1;crow <= ItFill(thBomItem); crow++)
			{
			    tBomItem = ItGetLine(thBomItem,crow);
			    if (tBomItem == NULL)
					printf("ItGetLineBOM_ITEM");
				strcpy(comp_sap,"");
				GETCHAR(tBomItem->Idnrk,comp_sap);
			    printf("\n%04d %15s",crow,comp_sap);
			    fflush(stdout);
			    fprintf(fsuccess,"\n%04d %15s",crow,comp_sap);
			}
			GETCHAR(iEMessage,MessageRet);
			printf("\nMessage FOR BOM [%s] CREATE:%80s",assy_noDup,MessageRet);
			fflush(stdout);
			fprintf(fsuccess,"\nMessage FOR BOM [%s] CREATE:%80s",assy_noDup,MessageRet);

		break;
	     case RFC_EXCEPTION :
			printf("\nexception");
			fprintf(fsuccess,"\nexception");
		break;
	     case RFC_SYS_EXCEPTION :
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
	     case RFC_FAILURE :
			printf("\nfailure");
			fprintf(fsuccess,"\nfailure");
		break;
	     default :
			printf("\nother failure");
			fprintf(fsuccess,"\nother failure");
		break;
	   }
	 if (ItDelete(thBomItem) != 0)
	   printf("\nItDelete BOM_ITEM");
	 RfcClose(hRfc);

}
*/

int tm_curl_ZCAD_CHANGE_BOM_WITH_SUB_ITEMS ( char *data )
{
	struct memory chunk = {0};
//	 char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;


	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZCAD_CHANGE_BOM_WITH_SUB_ITEMS_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZCAD_CHANGE_BOM_WITH_SUB_ITEMS_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZCAD_CHANGE_BOM_WITH_SUB_ITEMS_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");

	printf("\nFile request content as below "); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object BOM_CHANGE"); fflush(stdout);

	parse_json_object(chunk.response, "BOM_CHANGE");

	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

	printf("\nfree"); fflush(stdout);

	curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int displayChange(struct node *head,string assy_noDup, char* json_bom_change_in_plant_req_obj)
{
	struct node *p=NULL;
	char sap_qty[18];
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *BOM_ITEM_req;
	cJSON *BOM_ITEM_item_req;

	cJSON *BOM_SUB_ITEM_req;
	cJSON *BOM_SUB_ITEM_item_req;

	cJSON *DMS_CLASS_DATA_req;
	cJSON *DMS_CLASS_DATA_item_req;

	cJSON *I_BOM_HEADER_req;


	cJSON *SAP_FIELD_DATA_req;
	cJSON *SAP_FIELD_DATA_item_req;

	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	BOM_ITEM_req = cJSON_CreateObject();
	//BOM_ITEM_item_req = cJSON_CreateObject();

	BOM_SUB_ITEM_req = cJSON_CreateObject();
	BOM_SUB_ITEM_item_req = cJSON_CreateObject();

	DMS_CLASS_DATA_req = cJSON_CreateObject();
	DMS_CLASS_DATA_item_req = cJSON_CreateObject();

	I_BOM_HEADER_req = cJSON_CreateObject();


	SAP_FIELD_DATA_req = cJSON_CreateObject();
	SAP_FIELD_DATA_item_req = cJSON_CreateObject();


	cJSON_AddItemToObject(rfc_root, "ZCAD_CHANGE_BOM_WITH_SUB_ITEMS", exp_imp_tab_req);

	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_ITEM", BOM_ITEM_req);
	for(p = head; p != NULL; p = p -> next)
	{

		BOM_ITEM_item_req = cJSON_CreateObject();
		cJSON_AddItemToObject(BOM_ITEM_req, "item", BOM_ITEM_item_req);


		sprintf(sap_qty,"%7.3f", p->qty);
		nlsStrTrimTrailWhiteSpace(sap_qty);
		nlsStrTrimLeadWhiteSpace(sap_qty);

		cJSON_AddItemToObject(BOM_ITEM_item_req, "UPSKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPOS", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSCH", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "AVOAU", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "BEIKZ", cJSON_CreateString(p->mat_prov_ind));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "CADPO", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "EKGRP", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ERSKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "FMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "IDNRK", cJSON_CreateString(p->part));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFZT", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "MATKL", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "MEINS", cJSON_CreateString(p->uq));

		if(*assy_noDup=='G')
		{
			//SETCHAR(tBomItem->Menge,"0000000001");//Code has been modifed as per DENIS on 02.07.2011
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MENGE", cJSON_CreateString("0000000001"));
		}
		else
		{
			//SETCHAR(tBomItem->Menge,sap_qty);
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MENGE", cJSON_CreateString(sap_qty));
		}


		cJSON_AddItemToObject(BOM_ITEM_item_req, "NETAU", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NFMAT", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZT", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "PEINH", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "POSNR", cJSON_CreateString(p->sr_no));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "POSTP", cJSON_CreateString("L"));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "PREIS", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX1", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX2", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "PSWRK", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "REKRS", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "RFORM", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROANZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROAME", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROKME", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEI", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEN", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS1", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS2", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS3", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "RVREL", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SAKTO", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SANFE", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SANIN", cJSON_CreateString(""));

		cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKO", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SANVS", cJSON_CreateString(""));

		if (nlsStrCmp(sap_qty,"99") != 0)
		{
			//SETCHAR(tBomItem->Schgt,"");//blk_ind
			;
		}
		else
		{
			nlsStrCpy(p->tempcsrel,"1");
			//SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SCHGT", cJSON_CreateString(""));


		cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKA", cJSON_CreateString(p->tempcsrel));

		cJSON_AddItemToObject(BOM_ITEM_item_req, "SELAL", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SELID", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SELPO", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SELSB", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "SORTF", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "STKKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "STKTX", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "STLAL", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "STLKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "VERTI", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "WEBAZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "WAERS", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "EKORG", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "LGORT", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "CLASS", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "KLART", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "POTPR", cJSON_CreateString(""));
		if(*assy_noDup=='G')
		{
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPGR", cJSON_CreateString("a1"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPRF", cJSON_CreateString("1"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPST", cJSON_CreateString("1"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString(""));

		}
		else
		{

			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPGR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPRF", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPST", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString(""));
		}


		cJSON_AddItemToObject(BOM_ITEM_item_req, "DSPST", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "PRVBE", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NFEAG", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NFGRP", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "KZKUP", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "INTRM", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "KZCLB", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZV", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFMV", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "RFPNT", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "MATNR_LONG", cJSON_CreateString(""));
		cJSON_AddItemToObject(BOM_ITEM_item_req, "ITSOB", cJSON_CreateString(""));

	}

	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_SUB_ITEM", BOM_SUB_ITEM_req);
		cJSON_AddItemToObject(BOM_SUB_ITEM_req, "item", BOM_SUB_ITEM_item_req);
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "POSID", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "EBORT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPMNG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPOSZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPTXT", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "DMS_CLASS_DATA", DMS_CLASS_DATA_req);
		cJSON_AddItemToObject(DMS_CLASS_DATA_req, "item", DMS_CLASS_DATA_item_req);
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATNAM", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATBEZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATWRT", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "DINKB", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "UNIT", cJSON_CreateString(""));

	//cJSON_AddItemToObject(exp_imp_tab_req, "I_AUTO_POSNR", cJSON_CreateString(""));

	//eIBomHeader
	cJSON_AddItemToObject(exp_imp_tab_req, "I_BOM_HEADER", I_BOM_HEADER_req);
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STYPE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TCODE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "AENNR", cJSON_CreateString(EEDmlNumberST));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMEIN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "CADKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUB", cJSON_CreateString("31.12.9999"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EQUNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EXSTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LABOR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOEKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSBS", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSVN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR", cJSON_CreateString(assy_noDup));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SELAL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SERGE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STKTX", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAL", cJSON_CreateString("01"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAN", cJSON_CreateString("1"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLBE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLST", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VMTNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "WERKS", cJSON_CreateString("1005"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "ZTEXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "REVLV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TPLNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBELN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBPOS", cJSON_CreateString("000000"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STOBJ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VEQNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VTPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "PSPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "OITXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR_LONG", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "SAP_FIELD_DATA", SAP_FIELD_DATA_req);
		cJSON_AddItemToObject(SAP_FIELD_DATA_req, "item", SAP_FIELD_DATA_item_req);
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDMULTI", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDNAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDVALUE", cJSON_CreateString(""));


	out = cJSON_Print(rfc_root);
	printf("in function SapBomChange:[%s]", out);
	strcpy ( json_bom_change_in_plant_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	printf("\n end json for SapBomChange : [%zu]",strlen(json_bom_change_in_plant_req_obj)); fflush(stdout);
	return 0;
}
/*
void displayChange(struct node *head,string assy_noDup)
{
	struct node *p=NULL;
	char sap_qty[18];


	int crow;
	char xException[256];
	char MessageRet[80];
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	char comp_sap[15];
	CAD_BICSK eIBomHeader;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;



	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				printf("\nItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			printf("\nItFreeBOM_ITEM");
	}
	printf("\nAssembly: %s :%s:-> 1005",assy_noDup,EEDmlNumberST);
	fprintf(fsuccess,"\nAssembly: %s :%s:-> 1005",assy_noDup,EEDmlNumberST);

	SETCHAR(eIBomHeader.Matnr,assy_noDup);
	SETCHAR(eIBomHeader.Werks,"1005");
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	SETCHAR(eIBomHeader.Aennr,EEDmlNumberST);
	SETCHAR(eIBomHeader.Datuv,"");
	SETCHAR(eIBomHeader.Datub,"31.12.9999");
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");






	for(p = head; p != NULL; p = p -> next)
	{


		sprintf(sap_qty,"%7.3f", p->qty);

		tBomItem = ItAppLine(thBomItem);
		if (tBomItem == NULL)
		  printf("ItAppLineBOM_ITEM");

		SETCHAR(tBomItem->Idnrk,p->part);
		if(*assy_noDup=='G')
		{
			SETCHAR(tBomItem->Menge,"0000000001");//Code has been modifed as per DENIS on 02.07.2011
		}
		else
		{
			SETCHAR(tBomItem->Menge,sap_qty);
		}
		SETCHAR(tBomItem->Postp,"L");
		SETCHAR(tBomItem->Posnr,p->sr_no);

		if(nlsStrNCmp(assy_noDup,"G",1)==0)
		{
			SETCHAR(tBomItem->Alpgr,"a1");
			SETNUM(tBomItem->Alprf,"1");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"1");

		}
		else
		{
			SETCHAR(tBomItem->Alpgr,"");
			SETNUM(tBomItem->Alprf,"");
			SETCHAR(tBomItem->Ewahr,"");
			SETCHAR(tBomItem->Alpst,"");

		}
		SETCHAR(tBomItem->Verti,"");
		SETCHAR(tBomItem->Beikz,p->mat_prov_ind);
		SETCHAR(tBomItem->Selsb,"");
		if (nlsStrCmp(sap_qty,"99") != 0)
		{
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		else
		{
			nlsStrCpy(p->tempcsrel,"1");
			SETCHAR(tBomItem->Schgt,"");//blk_ind
		}
		SETCHAR(tBomItem->Sanka,p->tempcsrel);
		SETCHAR(tBomItem->Schgt,"");
			SETCHAR(tBomItem->Meins,p->uq);
		SETCHAR(tBomItem->Potx1,"");	//bomtxt
		SETCHAR(tBomItem->Sanfe,"");
		SETCHAR(tBomItem->Dspst,"");
		SETCHAR(tBomItem->Upskz,"");
		SETCHAR(tBomItem->Auskz,"");
		SETCHAR(tBomItem->Alpos,"");
		SETCHAR(tBomItem->Ausch,"");
		SETCHAR(tBomItem->Avoau,"");
		SETCHAR(tBomItem->Cadpo,"");
		SETCHAR(tBomItem->Ekgrp,"");
		SETCHAR(tBomItem->Erskz,"");
		SETCHAR(tBomItem->Fmeng,"");
		SETCHAR(tBomItem->Lifnr,"");
		SETCHAR(tBomItem->Lifzt,"");
		SETCHAR(tBomItem->Matkl,"");
		SETCHAR(tBomItem->Netau,"");
		SETCHAR(tBomItem->Nfmat,"");
		SETCHAR(tBomItem->Nlfzt,"");
		SETCHAR(tBomItem->Peinh,"");
		SETCHAR(tBomItem->Preis,"");
		SETCHAR(tBomItem->Potx2,"");
		SETCHAR(tBomItem->Pswrk,"");
		SETCHAR(tBomItem->Rekrs,"");
		SETCHAR(tBomItem->Rform,"");
		SETCHAR(tBomItem->Roanz,"");
		SETCHAR(tBomItem->Roame,"");
		SETCHAR(tBomItem->Rokme,"");
		SETCHAR(tBomItem->Romei,"");
		SETCHAR(tBomItem->Romen,"");
		SETCHAR(tBomItem->Roms1,"");
		SETCHAR(tBomItem->Roms2,"");
		SETCHAR(tBomItem->Roms3,"");
		SETCHAR(tBomItem->Rvrel,"");
		SETCHAR(tBomItem->Sakto,"");
		SETCHAR(tBomItem->Sanin,"");
		SETCHAR(tBomItem->Sanko,"");
		SETCHAR(tBomItem->Sanvs,"");
		SETCHAR(tBomItem->Selal,"");
		SETCHAR(tBomItem->Selid,"");
		SETCHAR(tBomItem->Selpo,"");
		SETCHAR(tBomItem->Sortf,"");
		SETCHAR(tBomItem->Stkkz,"");
		SETCHAR(tBomItem->Stktx,"");
		SETCHAR(tBomItem->Stlal,"");
		SETCHAR(tBomItem->Stlkz,"");
		SETCHAR(tBomItem->Webaz,"");
		SETCHAR(tBomItem->Waers,"");
		SETCHAR(tBomItem->Dokar,"");
		SETCHAR(tBomItem->Doknr,"");
		SETCHAR(tBomItem->Dokvr,"");
		SETCHAR(tBomItem->Doktl,"");
		SETCHAR(tBomItem->Ekorg,"");
		SETCHAR(tBomItem->Lgort,"");
		SETCHAR(tBomItem->Class,"");
		SETCHAR(tBomItem->Klart,"");
		SETCHAR(tBomItem->Potpr,"");
		SETCHAR(tBomItem->Prvbe,"");
		SETCHAR(tBomItem->Nfeag,"");
		SETCHAR(tBomItem->Nfgrp,"");
		SETCHAR(tBomItem->Kzkup,"");
		SETCHAR(tBomItem->Intrm,"");
		SETCHAR(tBomItem->Kzclb,"");
		SETCHAR(tBomItem->Nlfzv,"");
		SETCHAR(tBomItem->Nlfmv,"");
		SETCHAR(tBomItem->Rfpnt,"");
		SETCHAR(tBomItem->MatnrLong,"");


	}

	RfcRc = zcad_change_bom_with_sub_items(hRfc,&eIBomHeader,&iEReturn,&iEMessage,&iEMessageLen,&iEBomHeader,thBomItem,xException);
	switch (RfcRc)
	{
		case RFC_OK :
			for (crow = 1;crow <= ItFill(thBomItem); crow++)
			{
			    tBomItem = ItGetLine(thBomItem,crow);
			    if (tBomItem == NULL)
					printf("ItGetLineBOM_ITEM");
				strcpy(comp_sap,"");
				GETCHAR(tBomItem->Idnrk,comp_sap);
			    printf("\n%04d %15s",crow,comp_sap);
			    fflush(stdout);
			    fprintf(fsuccess,"\n%04d %15s",crow,comp_sap);
			}
			GETCHAR(iEMessage,MessageRet);
			printf("\nMessage FOR BOM [%s] Change:%80s",assy_noDup,MessageRet);
			fflush(stdout);
			fprintf(fsuccess,"\nMessage FOR BOM [%s] Change:%80s",assy_noDup,MessageRet);

		break;

		case RFC_EXCEPTION :
			 printf("EXCEPTION");
		break;
		case RFC_SYS_EXCEPTION :
			printf("\nSYSTEM EXCEPTION RAISED");
		break;
		case RFC_FAILURE :
			printf("\nfailure");
		break;
		default :
			printf("\nother failure");
		break;
	}
	if (ItDelete(thBomItem) != 0)
		printf("\nItDelete BOM_ITEM");
	RfcClose(hRfc);


}
*/
struct node* createnode ( char sr_no[5], string part, float qty, char uq[4], char tempcsrel[2], char mat_prov_ind[2] )
{
	struct node* p=NULL;

	p = (struct node*) malloc ( sizeof ( struct node ) ) ;
	p->part = part ;
	strcpy ( p->sr_no, sr_no ) ;
	strcpy ( p->uq, uq ) ;
	strcpy ( p->mat_prov_ind, mat_prov_ind ) ;
	strcpy ( p->tempcsrel, tempcsrel ) ;
	p->qty = qty ;
	p->next = NULL ;
	return p ;
}

int search(struct node* start,string part,float qty)
{
	struct node* p ;
	int found = 1 ;

	p = start;
	while ( p != NULL )
	{
			if ( strcmp ( p -> part, part ) == 0 )
			{
					//found ;
					p -> qty = p -> qty + qty ;
					found = 0 ;
					break ;
			}
			else
			{
				p = p -> next ;
				found = 1 ;
			}

		}
	return found ;
}
/*
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc, BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2	*eBapiret2,ITAB_H       thBapi_Makt,ITAB_H       thBapi_Marm,ITAB_H       thBapi_Marmx,char *xException)
{

 RFC_PARAMETER Exporting[9];
 RFC_PARAMETER Importing[2];
 RFC_TABLE Tables[4];
 RFC_RC RfcRc;
 char *RfcException = NULL;

 		 Exporting[0].name = "HEADDATA";
		 Exporting[0].nlen = 8;
		 Exporting[0].type = handleOfBAPIMATHEAD;
		 Exporting[0].leng = sizeof(BAPIMATHEAD);
		 Exporting[0].addr = eBapiMatHead;

		 Exporting[1].name = "CLIENTDATA";
		 Exporting[1].nlen = 10;
		 Exporting[1].type = handleOfBAPI_MARA;
		 Exporting[1].leng = sizeof(BAPI_MARA);
		 Exporting[1].addr = eBasicView;

		 Exporting[2].name = "CLIENTDATAX";
		 Exporting[2].nlen = 11;
		 Exporting[2].type = handleOfBAPI_MARAX;
		 Exporting[2].leng = sizeof(BAPI_MARAX);
		 Exporting[2].addr = eBasicViewx;

		 Exporting[3].name = "PLANTDATA";
		 Exporting[3].nlen = 9;
		 Exporting[3].type = handleOfBAPI_MARC;
		 Exporting[3].leng = sizeof(BAPI_MARC);
		 Exporting[3].addr = eMrpView;

		 Exporting[4].name = "PLANTDATAX";
		 Exporting[4].nlen = 10;
		 Exporting[4].type = handleOfBAPI_MARCX;
		 Exporting[4].leng = sizeof(BAPI_MARCX);
		 Exporting[4].addr = eMrpViewx;



		 Exporting[5].name = "STORAGELOCATIONDATA";
		 Exporting[5].nlen = 19;
		 Exporting[5].type = handleOfBAPI_MARD;
		 Exporting[5].leng = sizeof(BAPI_MARD);
		 Exporting[5].addr = eBapi_Mard;

		 Exporting[6].name = "STORAGELOCATIONDATAX";
		 Exporting[6].nlen = 20;
		 Exporting[6].type = handleOfBAPI_MARDX;
		 Exporting[6].leng = sizeof(BAPI_MARDX);
		 Exporting[6].addr = eBapi_Mardx;



		 Exporting[7].name = "CHANGE_NUMBER";
		 Exporting[7].nlen = 13;
		 Exporting[7].type = handleOfRMMG1_AENNR;
		 Exporting[7].leng = sizeof(RMMG1_AENNR);
		 Exporting[7].addr = eRmmg1_Aennr;

		 Exporting[8].name = NULL;

		Tables[0].name     = "MATERIALDESCRIPTION";
		Tables[0].nlen     = 19;
		Tables[0].type     = handleOfBAPI_MAKT;
		Tables[0].ithandle = thBapi_Makt;

		Tables[1].name     = "UNITSOFMEASURE";
		Tables[1].nlen     = 14;
		Tables[1].type     = handleOfBAPI_MARM;
		Tables[1].ithandle = thBapi_Marm;

		Tables[2].name     = "UNITSOFMEASUREX";
		Tables[2].nlen     = 15;
		Tables[2].type     = handleOfBAPI_MARMX;
		Tables[2].ithandle = thBapi_Marmx;

		Tables[3].name = NULL;

		RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

		switch (RfcRc)
		{

		case RFC_OK :
			 Importing[0].name = "RETURN";
			 Importing[0].nlen = 6;
			 Importing[0].type = TYPC;
			 Importing[0].leng = sizeof(BAPIRET2);
			 Importing[0].addr = eBapiret2;

			 Importing[1].name = NULL;
			 RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			 switch (RfcRc)
			 {
				case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION :
					strcpy(xException,RfcException);
				break;

				default: ;
			 }
			break;
		default :
			printf("\nNOT RFC OK");
		}
  return RfcRc;
}
*/
void BomChange(ObjectPtr PartOPtr,char EEDmlNumber[])
{
	printf("\nBomChange");
}
int RefPartBomCreate(string AssyPartNumberDup,string ChildPartNumberDup,char EEDmlNumber[12], char *json_ref_bom_create_in_plant_req_obj)
{
	int mfail = OKAY;
	SqlPtr sql = NULL;
	status dstat = OKAY;
	SetOfObjects partObjs = NULL;
	string ComponentMakeBuyInd = NULL;
	string ComponentMakeBuyIndDup = NULL;
	string RefPartclass = NULL;
	string RefPartclassDup = NULL;
	char MatProvInd[2]={0};
	char TempCsRel[2]={0};
//	int crow;
//	char comp_sap[15];
//	char xException[256];
//	static RFC_HANDLE hRfc;
//	static RFC_RC RfcRc;
//	char MessageRet[80];
//	CAD_BICSK eIBomHeader;
//	DRAW_LOEDK eIAutoPosnr;
//	CAD_BICSK iEBomHeader;
//	MESSAGE_MSGTX iEMessage;
//	CAD_RETURN_MESSAGE_LEN iEMessageLen;
//	CAD_RETURN_VALUE iEReturn;
//	ITAB_H thBomItem = ITAB_NULL;
//	CAD_BOM_ITEM *tBomItem;
	char EEPartThreeDigit[4]={0};

	if (
		(dstat = oiSqlCreateSelect(&sql)) ||
		(dstat = oiSqlWhereEQ(sql,"PartNumber",ChildPartNumberDup)) ||
		(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereBegParen(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsErcRlzd")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAPLWrkg")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAplRlzd")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDAthrig")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDWrkg")) ||
		(dstat = oiSqlWhereOR(sql))||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDRlzd")) ||
		(dstat = oiSqlWhereEndParen(sql)) ||
		(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereEQ(sql,"OwnerName","Release Vault")) ||
		(dstat = oiSqlDescOrder(sql,"CreationDate")) ||
		(dstat = QueryWhere("Part",sql,&partObjs,&mfail))
	)
	goto CLEANUP;


	if(setSize(partObjs) == 0)
	{
		printf("\naNo Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
		fprintf(fsuccess,"\n\naMSG RCVD:No Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
		goto CLEANUP;
	}
	if(setSize(partObjs)>0)
	{
		if(dstat = objGetClass(setGet(partObjs,0), &RefPartclass)) goto CLEANUP;
		if(!nlsIsStrNull(RefPartclass))
		{
			RefPartclassDup = nlsStrDup(RefPartclass);
		}
		if(nlsStrCmp(RefPartclassDup,"t5EeAsm")!=0)
		{
			printf("\nrefpart class is not t5EeAsm hence exit");
			fprintf(fsuccess,"\nrefpart class is not t5EeAsm hence exit");
			goto CLEANUP;
		}
		nlsStrCpy(EEPartThreeDigit,"");
		EEPartThreeDigit[0]= *(ChildPartNumberDup+0);
		EEPartThreeDigit[1]= *(ChildPartNumberDup+1);
		EEPartThreeDigit[2]= *(ChildPartNumberDup+2);
		EEPartThreeDigit[3]= '\0';
		printf("\n%s",EEPartThreeDigit);
		if(nlsStrNCmp(ChildPartNumberDup,EEPartThreeDigit,3)==0)
		{
			printf("\nvalid part found");
		}
		else
		{
			printf("\ninvalid part found hence check next part");
			goto CLEANUP;
		}

	}
	if(dstat = objGetAttribute(setGet(partObjs,0), "t5PunMakeBuyIndicator", &ComponentMakeBuyInd)) goto CLEANUP;

	nlsStrCpy(MatProvInd,"");
	nlsStrCpy(TempCsRel,"X");


	if(!nlsIsStrNull(ComponentMakeBuyInd))
	{
		ComponentMakeBuyIndDup = nlsStrDup(ComponentMakeBuyInd);
		if(nlsStrCmp(ComponentMakeBuyIndDup, "F") == 0)
		{
			nlsStrCpy(MatProvInd,"L");
			nlsStrCpy(TempCsRel,"1");
		}
		else
		{
			nlsStrCpy(MatProvInd,"");
			nlsStrCpy(TempCsRel,"X");
		}
	}
	else
	{
		printf("\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
		fprintf(fsuccess,"\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
		goto CLEANUP;
	}

	if(nlsIsStrNull(ComponentMakeBuyInd)&&(*ChildPartNumberDup !='G'))
	{
		goto CLEANUP;
	}


	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *BOM_ITEM_req;
	cJSON *BOM_ITEM_item_req;

	cJSON *BOM_SUB_ITEM_req;
	cJSON *BOM_SUB_ITEM_item_req;

	cJSON *DMS_CLASS_DATA_req;
	cJSON *DMS_CLASS_DATA_item_req;

	cJSON *I_BOM_HEADER_req;


	cJSON *SAP_FIELD_DATA_req;
	cJSON *SAP_FIELD_DATA_item_req;


	char *out;


	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	//BOM_ITEM_req = cJSON_CreateObject();
	//BOM_ITEM_item_req = cJSON_CreateObject();

	BOM_SUB_ITEM_req = cJSON_CreateObject();
	BOM_SUB_ITEM_item_req = cJSON_CreateObject();

	DMS_CLASS_DATA_req = cJSON_CreateObject();
	DMS_CLASS_DATA_item_req = cJSON_CreateObject();

	I_BOM_HEADER_req = cJSON_CreateObject();


	SAP_FIELD_DATA_req = cJSON_CreateObject();
	SAP_FIELD_DATA_item_req = cJSON_CreateObject();
	//tBomItem

	cJSON_AddItemToObject(rfc_root, "CAD_CREATE_BOM_WITH_SUB_ITEMS", exp_imp_tab_req);



	BOM_ITEM_req = cJSON_CreateObject();
	cJSON_AddItemToObject(exp_imp_tab_req, "BOM_ITEM", BOM_ITEM_req);

		BOM_ITEM_item_req = cJSON_CreateObject();
		cJSON_AddItemToObject(BOM_ITEM_req, "item", BOM_ITEM_item_req);

			cJSON_AddItemToObject(BOM_ITEM_item_req, "UPSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPOS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AUSCH", cJSON_CreateString("0.00"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "AVOAU", cJSON_CreateString("0.00"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "BEIKZ", cJSON_CreateString(MatProvInd));//p->mat_prov_ind//L
			cJSON_AddItemToObject(BOM_ITEM_item_req, "CADPO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EKGRP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ERSKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "FMENG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "IDNRK", cJSON_CreateString(ChildPartNumberDup));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFNR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LIFZT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MATKL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MEINS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MENGE", cJSON_CreateString("1"));//1.000
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NETAU", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFMAT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PEINH", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POSNR", cJSON_CreateString("0001"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POSTP", cJSON_CreateString("L"));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PREIS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX1", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTX2", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PSWRK", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "REKRS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RFORM", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROANZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROKME", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEI", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMEN", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS1", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS2", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ROMS3", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RVREL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SAKTO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANFE", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANIN", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKA", cJSON_CreateString(TempCsRel));//p->tempcsrel//1
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANKO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SANVS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SCHGT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELAL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELID", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELPO", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SELSB", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "SORTF", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STKKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STKTX", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STLAL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "STLKZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "VERTI", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "WEBAZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "WAERS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKAR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKNR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKVR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "DOKTL", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EKORG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "LGORT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "CLASS", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KLART", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "POTPR", cJSON_CreateString(""));

			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPGR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPRF", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "EWAHR", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ALPST", cJSON_CreateString(""));

			cJSON_AddItemToObject(BOM_ITEM_item_req, "DSPST", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "PRVBE", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFEAG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NFGRP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KZKUP", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "INTRM", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "KZCLB", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFZV", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "NLFMV", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "RFPNT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "MATNR_LONG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_ITEM_item_req, "ITSOB", cJSON_CreateString(""));

			//--
			cJSON_AddItemToObject(exp_imp_tab_req, "BOM_SUB_ITEM", BOM_SUB_ITEM_req);
		cJSON_AddItemToObject(BOM_SUB_ITEM_req, "item", BOM_SUB_ITEM_item_req);
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "POSID", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "EBORT", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPMNG", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPOSZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(BOM_SUB_ITEM_item_req, "UPTXT", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "DMS_CLASS_DATA", DMS_CLASS_DATA_req);
		cJSON_AddItemToObject(DMS_CLASS_DATA_req, "item", DMS_CLASS_DATA_item_req);
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATNAM", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATBEZ", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "ATWRT", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "DINKB", cJSON_CreateString(""));
			cJSON_AddItemToObject(DMS_CLASS_DATA_item_req, "UNIT", cJSON_CreateString(""));

	//eIAutoPosnr
	//eIBomHeader
	cJSON_AddItemToObject(exp_imp_tab_req, "I_AUTO_POSNR", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "I_BOM_HEADER", I_BOM_HEADER_req);
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STYPE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TCODE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "AENNR", cJSON_CreateString(EEDmlNumberST));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMEIN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "BMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "CADKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUB", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DATUV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EMENG", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EQUNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "EXSTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LABOR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOEKZ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSBS", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "LOSVN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR", cJSON_CreateString(AssyPartNumberDup));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SELAL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "SERGE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STKTX", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAL", cJSON_CreateString("01"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLAN", cJSON_CreateString("1"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLBE", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STLST", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VMTNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "WERKS", cJSON_CreateString("1005"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "ZTEXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "REVLV", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "TPLNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "DOKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBELN", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VBPOS", cJSON_CreateString("000000"));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "STOBJ", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKAR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKTL", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VDKVR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VEQNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "VTPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "PSPNR", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "OITXT", cJSON_CreateString(""));
		cJSON_AddItemToObject(I_BOM_HEADER_req, "MATNR_LONG", cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "SAP_FIELD_DATA", SAP_FIELD_DATA_req);
		cJSON_AddItemToObject(SAP_FIELD_DATA_req, "item", SAP_FIELD_DATA_item_req);
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDMULTI", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDNAME", cJSON_CreateString(""));
			cJSON_AddItemToObject(SAP_FIELD_DATA_item_req, "FIELDVALUE", cJSON_CreateString(""));

	out = cJSON_Print(rfc_root);
	printf("in function SapBomCreate:[%s]", out);
	strcpy ( json_ref_bom_create_in_plant_req_obj, out ) ;
	free(out);
	cJSON_Delete(rfc_root);
	printf("\nend json for SapBomCreate : [%zu]",strlen(json_ref_bom_create_in_plant_req_obj)); fflush(stdout);


CLEANUP:
	return 0;
}
/*
void RefPartBomCreate(string AssyPartNumberDup,string ChildPartNumberDup,char EEDmlNumber[])
{
	int mfail = OKAY;
	SqlPtr sql = NULL;
	status dstat = OKAY;
	SetOfObjects partObjs = NULL;
	string ComponentMakeBuyInd = NULL;
	string ComponentMakeBuyIndDup = NULL;
	string RefPartclass = NULL;
	string RefPartclassDup = NULL;
	char MatProvInd[2]={0};
	char TempCsRel[2]={0};
	int crow;
	char comp_sap[15];
	char xException[256];
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;
	char MessageRet[80];
	CAD_BICSK eIBomHeader;
	DRAW_LOEDK eIAutoPosnr;
	CAD_BICSK iEBomHeader;
	MESSAGE_MSGTX iEMessage;
	CAD_RETURN_MESSAGE_LEN iEMessageLen;
	CAD_RETURN_VALUE iEReturn;
	ITAB_H thBomItem = ITAB_NULL;
	CAD_BOM_ITEM *tBomItem;
	char EEPartThreeDigit[4]={0};

	if (
		(dstat = oiSqlCreateSelect(&sql)) ||
		(dstat = oiSqlWhereEQ(sql,"PartNumber",ChildPartNumberDup)) ||
		(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereBegParen(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsErcRlzd")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAPLWrkg")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAplRlzd")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDAthrig")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDWrkg")) ||
		(dstat = oiSqlWhereOR(sql))||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDRlzd")) ||
		(dstat = oiSqlWhereEndParen(sql)) ||
		(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereEQ(sql,"OwnerName","Release Vault")) ||
		(dstat = oiSqlDescOrder(sql,"CreationDate")) ||
		(dstat = QueryWhere("Part",sql,&partObjs,&mfail))
	)
	goto CLEANUP;


	if(setSize(partObjs) == 0)
	{
		printf("\naNo Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
		fprintf(fsuccess,"\n\naMSG RCVD:No Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
		goto CLEANUP;
	}
	if(setSize(partObjs)>0)
	{
		if(dstat = objGetClass(setGet(partObjs,0), &RefPartclass)) goto CLEANUP;
		if(!nlsIsStrNull(RefPartclass))
		{
			RefPartclassDup = nlsStrDup(RefPartclass);
		}
		if(nlsStrCmp(RefPartclassDup,"t5EeAsm")!=0)
		{
			printf("\nrefpart class is not t5EeAsm hence exit");
			fprintf(fsuccess,"\nrefpart class is not t5EeAsm hence exit");
			goto CLEANUP;
		}
		nlsStrCpy(EEPartThreeDigit,"");
		EEPartThreeDigit[0]= *(ChildPartNumberDup+0);
		EEPartThreeDigit[1]= *(ChildPartNumberDup+1);
		EEPartThreeDigit[2]= *(ChildPartNumberDup+2);
		EEPartThreeDigit[3]= '\0';
		printf("\n%s",EEPartThreeDigit);
		if(nlsStrNCmp(ChildPartNumberDup,EEPartThreeDigit,3)==0)
		{
			printf("\nvalid part found");
		}
		else
		{
			printf("\ninvalid part found hence check next part");
			goto CLEANUP;
		}

	}
	if(dstat = objGetAttribute(setGet(partObjs,0), "t5PunMakeBuyIndicator", &ComponentMakeBuyInd)) goto CLEANUP;

	nlsStrCpy(MatProvInd,"");
	nlsStrCpy(TempCsRel,"X");


	if(!nlsIsStrNull(ComponentMakeBuyInd))
	{
		ComponentMakeBuyIndDup = nlsStrDup(ComponentMakeBuyInd);
		if(nlsStrCmp(ComponentMakeBuyIndDup, "F") == 0)
		{
			nlsStrCpy(MatProvInd,"L");
			nlsStrCpy(TempCsRel,"1");
		}
		else
		{
			nlsStrCpy(MatProvInd,"");
			nlsStrCpy(TempCsRel,"X");
		}
	}
	else
	{
		printf("\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
		fprintf(fsuccess,"\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
		goto CLEANUP;
	}

	if(nlsIsStrNull(ComponentMakeBuyInd)&&(*ChildPartNumberDup !='G'))
	{
		goto CLEANUP;
	}

	hRfc = BapiLogon();
	thBomItem = ITAB_NULL;
	if (thBomItem==ITAB_NULL)
	{
		thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
		if (thBomItem==ITAB_NULL)
				printf("\nItCreateBOM_ITEM");
	}
	else
	{
		if (ItFree(thBomItem) != 0)
			printf("\nItFreeBOM_ITEM");
	}


	printf("\nAssembly: %s -> 1005 %s",AssyPartNumberDup,EEDmlNumberST);
	fprintf(fsuccess,"\nAssembly: %s -> 1005 %s",AssyPartNumberDup,EEDmlNumberST);


	SETCHAR(eIAutoPosnr,"");
	SETCHAR(eIBomHeader.Matnr,AssyPartNumberDup);
	SETCHAR(eIBomHeader.Werks,"1005");
	SETCHAR(eIBomHeader.Stlan,"1");
	SETCHAR(eIBomHeader.Stlal,"01");
	SETCHAR(eIBomHeader.Aennr,EEDmlNumberST);
	SETCHAR(eIBomHeader.Datuv,"");
	SETCHAR(eIBomHeader.Stype,"");
	SETCHAR(eIBomHeader.Tcode,"");
	SETCHAR(eIBomHeader.Bmein,"");
	SETCHAR(eIBomHeader.Bmeng,"");
	SETCHAR(eIBomHeader.Cadkz,"");
	SETCHAR(eIBomHeader.Datub,"");
	SETCHAR(eIBomHeader.Emeng,"");
	SETCHAR(eIBomHeader.Equnr,"");
	SETCHAR(eIBomHeader.Exstl,"");
	SETCHAR(eIBomHeader.Labor,"");
	SETCHAR(eIBomHeader.Loekz,"");
	SETCHAR(eIBomHeader.Losbs,"");
	SETCHAR(eIBomHeader.Losvn,"");
	SETCHAR(eIBomHeader.Selal,"");
	SETCHAR(eIBomHeader.Serge,"");
	SETCHAR(eIBomHeader.Stktx,"");
	SETCHAR(eIBomHeader.Stlbe,"");
	SETCHAR(eIBomHeader.Stlst,"");
	SETCHAR(eIBomHeader.Vmtnr,"");
	SETCHAR(eIBomHeader.Ztext,"");
	SETCHAR(eIBomHeader.Revlv,"");
	SETCHAR(eIBomHeader.Tplnr,"");
	SETCHAR(eIBomHeader.Dokar,"");
	SETCHAR(eIBomHeader.Doknr,"");
	SETCHAR(eIBomHeader.Doktl,"");
	SETCHAR(eIBomHeader.Dokvr,"");
	SETCHAR(eIBomHeader.Vbeln,"");
	SETNUM(eIBomHeader.Vbpos,"000000");
	SETCHAR(eIBomHeader.Stobj,"");
	SETCHAR(eIBomHeader.Vdknr,"");
	SETCHAR(eIBomHeader.Vdkar,"");
	SETCHAR(eIBomHeader.Vdktl,"");
	SETCHAR(eIBomHeader.Vdkvr,"");
	SETCHAR(eIBomHeader.Veqnr,"");
	SETCHAR(eIBomHeader.Vtpnr,"");
	SETCHAR(eIBomHeader.Pspnr,"");
	SETCHAR(eIBomHeader.Oitxt,"");
	SETCHAR(eIBomHeader.MatnrLong,"");

	tBomItem = ItAppLine(thBomItem);
	if (tBomItem == NULL)
			printf("ItAppLineBOM_ITEM");

	SETCHAR(tBomItem->Idnrk,ChildPartNumberDup);
	SETCHAR(tBomItem->Menge,"1");
	SETCHAR(tBomItem->Postp,"L");
	SETCHAR(tBomItem->Posnr,"0001");
	SETCHAR(tBomItem->Alpgr,"");
	SETNUM(tBomItem->Alprf,"");
	SETCHAR(tBomItem->Ewahr,"");
	SETCHAR(tBomItem->Alpst,"");
	SETCHAR(tBomItem->Verti,"");
	SETCHAR(tBomItem->Sanka,TempCsRel);
	SETCHAR(tBomItem->Sanfe,"");
	SETCHAR(tBomItem->Beikz,MatProvInd);
	SETCHAR(tBomItem->Selsb,"");
	SETCHAR(tBomItem->Schgt,"");
	SETCHAR(tBomItem->Meins,"");
	SETCHAR(tBomItem->Potx1,"");
	SETCHAR(tBomItem->Dspst,"");
	SETCHAR(tBomItem->Lgort,"");
	SETCHAR(tBomItem->Sortf,"");
	SETCHAR(tBomItem->Potx2,"");
	SETCHAR(tBomItem->Upskz,"");
	SETCHAR(tBomItem->Auskz,"");
	SETCHAR(tBomItem->Alpos,"");
	SETCHAR(tBomItem->Ausch,"0.00");
	SETCHAR(tBomItem->Avoau,"0.00");
	SETCHAR(tBomItem->Cadpo,"");
	SETCHAR(tBomItem->Ekgrp,"");
	SETCHAR(tBomItem->Erskz,"");
	SETCHAR(tBomItem->Fmeng,"");
	SETCHAR(tBomItem->Lifnr,"");
	SETCHAR(tBomItem->Lifzt,"");
	SETCHAR(tBomItem->Matkl,"");
	SETCHAR(tBomItem->Netau,"");
	SETCHAR(tBomItem->Nfmat,"");
	SETCHAR(tBomItem->Nlfzt,"");
	SETCHAR(tBomItem->Peinh,"");
	SETCHAR(tBomItem->Preis,"");
	SETCHAR(tBomItem->Pswrk,"");
	SETCHAR(tBomItem->Rekrs,"");
	SETCHAR(tBomItem->Rform,"");
	SETCHAR(tBomItem->Roanz,"");
	SETCHAR(tBomItem->Roame,"");
	SETCHAR(tBomItem->Rokme,"");
	SETCHAR(tBomItem->Romei,"");
	SETCHAR(tBomItem->Romen,"");
	SETCHAR(tBomItem->Roms1,"");
	SETCHAR(tBomItem->Roms2,"");
	SETCHAR(tBomItem->Roms3,"");
	SETCHAR(tBomItem->Rvrel,"");
	SETCHAR(tBomItem->Sakto,"");
	SETCHAR(tBomItem->Sanin,"");
	SETCHAR(tBomItem->Sanko,"");
	SETCHAR(tBomItem->Sanvs,"");
	SETCHAR(tBomItem->Selal,"");
	SETCHAR(tBomItem->Selid,"");
	SETCHAR(tBomItem->Selpo,"");
	SETCHAR(tBomItem->Stkkz,"");
	SETCHAR(tBomItem->Stktx,"");
	SETCHAR(tBomItem->Stlal,"");
	SETCHAR(tBomItem->Stlkz,"");
	SETCHAR(tBomItem->Webaz,"");
	SETCHAR(tBomItem->Waers,"");
	SETCHAR(tBomItem->Dokar,"");
	SETCHAR(tBomItem->Doknr,"");
	SETCHAR(tBomItem->Dokvr,"");
	SETCHAR(tBomItem->Doktl,"");
	SETCHAR(tBomItem->Ekorg,"");
	SETCHAR(tBomItem->Class,"");
	SETCHAR(tBomItem->Klart,"");
	SETCHAR(tBomItem->Potpr,"");
	SETCHAR(tBomItem->Prvbe,"");
	SETCHAR(tBomItem->Nfeag,"");
	SETCHAR(tBomItem->Nfgrp,"");
	SETCHAR(tBomItem->Kzkup,"");
	SETCHAR(tBomItem->Intrm,"");
	SETCHAR(tBomItem->Kzclb,"");
	SETCHAR(tBomItem->Nlfzv,"");
	SETCHAR(tBomItem->Nlfmv,"");
	SETCHAR(tBomItem->Rfpnt,"");
	SETCHAR(tBomItem->MatnrLong,"");

	RfcRc = cad_create_bom_with_sub_items(hRfc,&eIAutoPosnr,&eIBomHeader,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,xException);

	 switch (RfcRc)
	  {
	     case RFC_OK :
			for (crow = 1;crow <= ItFill(thBomItem); crow++)
			{
			    tBomItem = ItGetLine(thBomItem,crow);
			    if (tBomItem == NULL)
					printf("ItGetLineBOM_ITEM");
				strcpy(comp_sap,"");
				GETCHAR(tBomItem->Idnrk,comp_sap);
			    printf("\n%04d %15s",crow,comp_sap);
			    fflush(stdout);
			    fprintf(fsuccess,"\n%04d %15s",crow,comp_sap);
			}
			GETCHAR(iEMessage,MessageRet);
			printf("\nMessage FOR BOM [%s] CREATE:%80s",AssyPartNumberDup,MessageRet);
			fflush(stdout);
			fprintf(fsuccess,"\nMessage FOR BOM [%s] CREATE:%80s",AssyPartNumberDup,MessageRet);

		break;
	     case RFC_EXCEPTION :
			printf("\nexception");
			fprintf(fsuccess,"\nexception");
		break;
	     case RFC_SYS_EXCEPTION :
			printf("\nsystem exception raised");
			fprintf(fsuccess,"\nsystem exception raised");
		break;
	     case RFC_FAILURE :
			printf("\nfailure");
			fprintf(fsuccess,"\nfailure");
		break;
	     default :
			printf("\nother failure");
			fprintf(fsuccess,"\nother failure");
		break;
	   }
	 if (ItDelete(thBomItem) != 0)
	   printf("\nItDelete BOM_ITEM");

CLEANUP:
 RfcClose(hRfc);
}
*/
void BomCreate(ObjectPtr PartOPtr,char EEDmlNumber[])
{
	int mfail = OKAY;
	status dstat = OKAY;
	int noOfChilds = 0;
	string DisplayedName = NULL;
	string DisplayedNameDup = NULL;
	string AssemblyNumber = NULL;
	string AssemblyNumberDup = NULL;
	string mPartClass = NULL;
	string mPartClassDup = NULL;
	string ComponentPartNumber = NULL;
	string ComponentPartNumberDup = NULL;
	string ComponentPartType = NULL;
	string ComponentPartTypeDup = NULL;
	string ComponentMakeBuyInd = NULL;
	string ComponentMakeBuyIndDup = NULL;
	string ComponentUnitOfMeasure = NULL;
	string ComponentUnitOfMeasureDup = NULL;
	string ComponentSapUq = NULL;
	string ComponentQuantity = NULL;
	string ComponentQuantityDup = NULL;
	string ComponentQuantityRound = NULL;
	string ComponentQuantityReqInfo = NULL;
	string ComponentQuantityReqInfoDup = NULL;
	char MatProvInd[2]={0};
	char TempCsRel[2]={0};
	ObjectPtr ChildOPtr = NULL;
	SetOfObjects childObjs = NULL;
	SetOfObjects childRelObjs = NULL;
	char sr_no[5];
	int ret;
	static int sr_no1 = 0;
	struct node *start = NULL;
	struct node *p = NULL;
	struct node *q = NULL;

	ComponentSapUq = nlsStrAlloc(3);

	if (dstat = objGetAttribute(PartOPtr, "DisplayedName", &DisplayedName)) goto CLEANUP;
	if(!nlsIsStrNull(DisplayedName))
	{
		DisplayedNameDup = nlsStrDup(DisplayedName);
	}

	if(dstat = objGetAttribute(PartOPtr, "PartNumber", &AssemblyNumber)) goto CLEANUP;
	if(!nlsIsStrNull(AssemblyNumber))
	{
			AssemblyNumberDup = nlsStrDup(AssemblyNumber);
	}
	printf("\nAssembly Number:[%s]", DisplayedNameDup);
	fprintf(fsuccess,"\nAssembly Number:[%s]", DisplayedNameDup);

	if(dstat = objGetClass(PartOPtr,&mPartClass)) goto CLEANUP;
	if(!nlsIsStrNull(PartClass))
	{
		mPartClassDup = nlsStrDup(mPartClass);
	}
	printf("\nclass name of the part being passed is %s",mPartClassDup);
	fprintf(fsuccess,"\nclass name of the part being passed is %s",mPartClassDup);


	if(!nlsStrCmp(mPartClassDup,"Assembly") || !nlsStrCmp(mPartClassDup,"t5GrpID") || !nlsStrCmp(mPartClassDup,"t5EeAsm"))
	{

			if(dstat = ExpandObject2("AsRevRev",PartOPtr,"PartsInAssembly",SC_SCOPE_OF_SESSION,&childObjs,&childRelObjs,&mfail));

			if (setSize(childRelObjs)>0)
			{
				for(noOfChilds=0;noOfChilds<setSize(childObjs);noOfChilds++)
				{

					ChildOPtr = setGet(childObjs,noOfChilds);

					if(dstat =objGetAttribute(ChildOPtr, "PartNumber", &ComponentPartNumber)) goto CLEANUP;
					if(!nlsIsStrNull(ComponentPartNumber))
					{
						ComponentPartNumberDup = nlsStrDup(ComponentPartNumber);
					}
					printf("\nComponentPartNo:[%18s]",ComponentPartNumberDup);
					fprintf(fsuccess,"\nComponentPartNo:[%18s]",ComponentPartNumberDup);
					if(dstat = objGetAttribute(ChildOPtr,"t5EePartType",&ComponentPartType)) goto CLEANUP;
					if(!nlsIsStrNull(ComponentPartType))
					{
						ComponentPartTypeDup = nlsStrDup(ComponentPartType);
					}

					if (ComponentMakeBuyInd)
					{
						nlsStrFree(ComponentMakeBuyInd);
					}
					ComponentMakeBuyInd = NULL;
					if (ComponentMakeBuyIndDup)
					{
						nlsStrFree(ComponentMakeBuyIndDup);
					}
					ComponentMakeBuyIndDup = NULL;

					if(dstat = objGetAttribute(ChildOPtr, "t5PunMakeBuyIndicator", &ComponentMakeBuyInd)) goto CLEANUP;

					nlsStrCpy(MatProvInd,"");
					nlsStrCpy(TempCsRel,"X");


					if(!nlsIsStrNull(ComponentMakeBuyInd))
					{
						ComponentMakeBuyIndDup = nlsStrDup(ComponentMakeBuyInd);
						if(nlsStrCmp(ComponentMakeBuyIndDup, "F") == 0)
						{
							nlsStrCpy(MatProvInd,"L");
							nlsStrCpy(TempCsRel,"1");
						}
						else
						{
							nlsStrCpy(MatProvInd,"");
							nlsStrCpy(TempCsRel,"X");
						}
					}
					else
					{
						printf("\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
						fprintf(fsuccess,"\tMake and Buy Indicator: [%s] skipping ",ComponentMakeBuyIndDup);
						continue;
					}

					if(nlsIsStrNull(ComponentMakeBuyInd)&&(*ComponentPartNumberDup !='G'))
					{
						continue;
					}

					if(nlsStrCmp(ComponentMakeBuyIndDup,"NA")==0)
					{
						printf("\nComponent Part %s MakeBuyInd is NA hence skip",ComponentPartNumberDup);
						fprintf(fsuccess,"\nComponent Part %s MakeBuyInd is NA hence skip",ComponentPartNumberDup);
						continue;
					}


					printf("\tPune Make/Buy Indicator: %s", ComponentMakeBuyIndDup);
					printf("\tCosting Relevancy Indicator: %s", TempCsRel);
					printf("\tMaterial Provision Indicator: %s", MatProvInd);


					if(dstat = objGetAttribute(ChildOPtr, "t5UQdup", &ComponentUnitOfMeasure)) goto CLEANUP;
					printf("\t%s",ComponentUnitOfMeasure);
					if(!nlsIsStrNull(ComponentUnitOfMeasure))
					{
						ComponentUnitOfMeasureDup=nlsStrDup(ComponentUnitOfMeasure);
					}
					else
					{
						printf("\tUq for part is null hence aborting");
						fprintf(fsuccess,"\tUq for part is null hence aborting");
						goto CLEANUP;
					}

					if (nlsStrCmp(ComponentUnitOfMeasureDup,"1")==0)
					{
						nlsStrCpy(ComponentSapUq, "M");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"2")==0)
					{
						nlsStrCpy(ComponentSapUq, "KG");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"3")==0)
					{
						nlsStrCpy(ComponentSapUq, "L");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"4")==0)
					{
						nlsStrCpy(ComponentSapUq, "EA");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"5")==0)
					{
						nlsStrCpy(ComponentSapUq, "M2");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"6")==0)
					{
						nlsStrCpy(ComponentSapUq, "EA");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"7")==0)
					{
						nlsStrCpy(ComponentSapUq, "TD");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"8")==0)
					{
						nlsStrCpy(ComponentSapUq, "M3");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"9")==0)
					{
						nlsStrCpy(ComponentSapUq, "TS");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"PAC")==0)
					{
						nlsStrCpy(ComponentSapUq, "PAC");
					}
					else if (nlsStrCmp(ComponentUnitOfMeasureDup,"Pac")==0)
					{
						nlsStrCpy(ComponentSapUq, "Pac");
					}
					else
					{
						nlsStrCpy(ComponentUnitOfMeasureDup, "EA");
						nlsStrCpy(ComponentSapUq, "EA");
					}

					printf("\tUq:[%s,%s]",ComponentUnitOfMeasureDup, ComponentSapUq);
					fprintf(fsuccess,"\tUq:[%s,%s]",ComponentUnitOfMeasureDup, ComponentSapUq);
					if(dstat = objGetAttribute(setGet(childRelObjs,noOfChilds),"Quantity",&ComponentQuantity)) goto CLEANUP;
					if(!nlsIsStrNull(ComponentQuantity))
					{
						ComponentQuantityDup = nlsStrDup(ComponentQuantity);
					}

					if(dstat=objGetAttribute(setGet(childRelObjs,noOfChilds),"t5QtyReqInfo",&ComponentQuantityReqInfo)) goto CLEANUP;
					if(!nlsIsStrNull(ComponentQuantityReqInfo))
					{
						ComponentQuantityReqInfoDup = nlsStrDup(ComponentQuantityReqInfo);
					}

					if(!nlsStrCmp(ComponentQuantityDup,"0") && (!nlsStrCmp(ComponentQuantityReqInfoDup,"NA") || !nlsStrCmp(ComponentQuantityReqInfoDup,"+")))
					{
						printf("\tSkipping this Part as quantity is %s and Quantity Required information  is %s",ComponentQuantityDup,ComponentQuantityReqInfoDup);
						fprintf(fsuccess,"\tSkipping this Part as quantity is %s and Quantity Required information  is %s",ComponentQuantityDup,ComponentQuantityReqInfoDup);
						continue;
					}
					if(!nlsStrCmp(ComponentQuantityDup,"1") && (!nlsStrCmp(ComponentQuantityReqInfoDup,"+")))
					{
						printf("\tSkipping this Part as quantity is %s and Quantity Required information  is %s",ComponentQuantityDup,ComponentQuantityReqInfoDup);
						fprintf(fsuccess,"\tSkipping this Part as quantity is %s and Quantity Required information  is %s",ComponentQuantityDup,ComponentQuantityReqInfoDup);
						continue;
					}
					if (!nlsStrCmp(ComponentQuantityDup,"0") && !nlsStrCmp(ComponentQuantityReqInfoDup,"AR"))
					{
						ComponentQuantityDup = "1";
						printf("\tquantity after AR logic %s",ComponentQuantityDup);
						fprintf(fsuccess,"\tquantity after AR logic %s",ComponentQuantityDup);
					}

					if(!nlsStrCmp(ComponentPartTypeDup,"D")&& (*ComponentPartNumberDup!='G'))
					{
						printf("\tAs Part is Dummy skip part ");
						fprintf(fsuccess,"\tAs Part is Dummy skip part ");
						continue;
					}

					if(!nlsIsStrNull(nlsStrStr(ComponentPartNumberDup,"_")))
					{
						printf("\tAs ComponentPartNumberDup number contains underscore char hence skip part ");
						fprintf(fsuccess,"\tAs ComponentPartNumberDup number contains underscore char hence skip part ");
						continue;
					}



					ComponentQuantityRound = nlsStrAlloc(17);
					sprintf(ComponentQuantityRound,"%7.3f",atof(ComponentQuantityDup));
					nlsStrTrimTrailWhiteSpace(ComponentQuantityRound);
					nlsStrTrimLeadWhiteSpace(ComponentQuantityRound);
					printf("\t[%s]",ComponentQuantityRound);
					fprintf(fsuccess,"\t[%s]",ComponentQuantityRound);
					if(nlsStrCmp(ComponentQuantityRound,"0.000")==0)
					{
						printf("\tquantity is 0.000 hence skipping");
						fprintf(fsuccess,"\tquantity is 0.000 hence skipping");
						continue;
					}
					if(p==NULL)
					{
						sr_no1 = 1 ;
						sprintf(sr_no,"%04d",sr_no1);

						p = createnode(sr_no,ComponentPartNumberDup,atof(ComponentQuantityRound),ComponentSapUq,TempCsRel,MatProvInd);
						start = p;
					}
					else
					{
						 ret = search(start,ComponentPartNumberDup,atof(ComponentQuantityRound));
						 if(ret==1)
							{
								 q=start;
								 while(q->next!=NULL)
								 {
									 q=q->next;
								 }
								 sr_no1 = sr_no1 + 1 ;
								 sprintf(sr_no,"%04d",sr_no1);
								 q->next = createnode(sr_no,ComponentPartNumberDup,atof(ComponentQuantityRound),ComponentSapUq,TempCsRel,MatProvInd);

							}

					}

				}
			}
			else
			{
				printf("\nNO BOM found for %s assembly in PLM",DisplayedNameDup);
				fprintf(fsuccess,"\nNO BOM found for %s assembly in PLM",DisplayedNameDup);
				goto CLEANUP;
			}
	}
	//------------------------------------
	char *json_bom_create_in_plant_req_obj = NULL ;
	json_bom_create_in_plant_req_obj = malloc ( 990000 ) ;

	int RFCRet=0;
	RFCRet = displayCreate( start, AssemblyNumberDup, json_bom_create_in_plant_req_obj );

	printf("\nRetuned Str : %s\n", json_bom_create_in_plant_req_obj);

	tm_curl_CAD_CREATE_BOM_WITH_SUB_ITEMS ( json_bom_create_in_plant_req_obj );
	free(json_bom_create_in_plant_req_obj);
	//------------------------------------
	//displayCreate(start,AssemblyNumberDup);


	//------------------------------------
	char *json_bom_change_in_plant_req_obj = NULL;
	json_bom_change_in_plant_req_obj = malloc(990000);

	int BOMChangeRet=0;
	BOMChangeRet = displayChange( start, AssemblyNumberDup, json_bom_change_in_plant_req_obj );
	//display1(start,assy_noDup);

	//printf("\n Retuned Json Str for BOM Chnage : [%s]", json_bom_change_in_plant_req_obj);
	tm_curl_ZCAD_CHANGE_BOM_WITH_SUB_ITEMS ( json_bom_change_in_plant_req_obj );
	free(json_bom_change_in_plant_req_obj);

	//displayChange(start,AssemblyNumberDup);
	//------------------------------------
	my_free(start);
	CLEANUP:
		printf("\nBOM create");
		fprintf(fsuccess,"\nBOM create");
}

status t5GetDocumentTypes(SetOfObjects docObjs, SetOfStrings* docTypes, integer* mfail)
{
	status dstat = OKAY;
   	char *mod_name = "t5GetDocumentTypes";
	string gclassname = NULL;
	string classname = NULL;
	SetOfStrings tempTypes = NULL;
	int count = 0;
   	*mfail = USC_OKAY;

	printf("\nIn t5GetDocumentTypes");
	fflush(stdout);

	if(setSize(docObjs) == 0)
	{
		goto CLEANUP;
	}
	else
	{
		tempTypes = setCreate(1);
	}

	for(count=0; count<setSize(docObjs); count++)
	{
		if( dstat = objGetClass(setGet(docObjs, count), &gclassname) ) goto CLEANUP;
		classname = nlsStrDup(gclassname);
		low_set_add_str_unique(tempTypes, classname);
	}

	if(*docTypes)
	{
		setDestroy(*docTypes);
	}
	*docTypes = NULL;
	*docTypes = tempTypes;

CLEANUP:


	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}


status t5GetTypeDocuments(SetOfObjects docObjs,SetOfObjects docRelObjs,string docType,SetOfObjects* docTypeObjs,SetOfObjects* docTypeRelObjs,integer* mfail)
{
	status dstat = OKAY;
   	char *mod_name 	= "t5GetTypeDocuments";
	string gclassname = NULL;
	string classname = NULL;
	ObjectPtr docObj = NULL;
	ObjectPtr docRelObj = NULL;
	SetOfObjects tempDocObjs = NULL;
	SetOfObjects tempDocRelObs = NULL;
	int count = 0;
   			*mfail 		= USC_OKAY;

	if(setSize(docObjs) == 0)
	{
		goto CLEANUP;
	}

	for(count=0; count<setSize(docObjs); count++)
	{
		docObj = setGet(docObjs, count);
		docRelObj = setGet(docRelObjs, count);

		if( dstat = objGetClass(docObj, &gclassname) )		goto CLEANUP;
		classname = nlsStrDup(gclassname);

		if( strcmp(classname, docType) == 0 )
		{
			if(dstat = ulyCopyObjectToSet(docObj, &tempDocObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(docRelObj, &tempDocRelObs)) goto CLEANUP;
		}
	}


	*docTypeObjs = tempDocObjs;
	*docTypeRelObjs = tempDocRelObs;

CLEANUP:

	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}


status t5GetLatestDocumnets(SetOfObjects docObjs,SetOfObjects docRelObjs,SetOfObjects* latestDocs,SetOfObjects* latestRelDocs,integer* mfail)
{
	status	dstat		= OKAY;
   	char	*mod_name 	= "t5GetLatestDocumnets";
	SetOfStrings	docTypes	= NULL;
	string	docType		= NULL;
	SetOfObjects	docTypeObjs	= NULL;
	SetOfObjects	docTypeRelObjs	= NULL;
	ObjectPtr		latestDoc	= NULL;
	ObjectPtr		latestRelDoc	= NULL;
	int		count		= 0;
   			*mfail 		= USC_OKAY;

	printf("\nIn t5GetLatestDocumnets");
	fflush(stdout);
	if( dstat = t5GetDocumentTypes(docObjs, &docTypes, mfail) ) goto CLEANUP;
	if(*mfail) goto CLEANUP;


	if(docTypeObjs)
	{
		objDisposeAll(docTypeObjs);
	}
	docTypeObjs = NULL;
	if(docTypeRelObjs)
	{
		objDisposeAll(docTypeRelObjs);
	}
	docTypeRelObjs = NULL;

	for(count=0; count<setSize(docTypes); count++)
	{
		docType = setGetStr(docTypes, count);

		if( dstat = t5GetTypeDocuments(docObjs, docRelObjs, docType, &docTypeObjs, &docTypeRelObjs, mfail) ) goto CLEANUP;
		if(*mfail) goto CLEANUP;


		if(dstat = t0LatestBI(docTypeObjs, docTypeRelObjs, &latestDoc, &latestRelDoc, mfail)) goto CLEANUP;
		if(*mfail) goto CLEANUP;

		if(dstat = ulyCopyObjectToSet(latestDoc, latestDocs)) goto CLEANUP;
		if(dstat = ulyCopyObjectToSet(latestRelDoc, latestRelDocs)) goto CLEANUP;
	}

CLEANUP:


	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}


status t5GetDistinctAttributeValues(SetOfObjects objs,string attrName,SetOfStrings* distValues,integer* mfail)
{
	string	gattrValue	= NULL;
	string	attrValue	= NULL;
	SetOfStrings	tempValues	= NULL;
	int		count		= 0;
	t5MethodInit("t5GetDistinctAttributeValues");

	if(setSize(objs) == 0)
	{
		goto CLEANUP;
	}
	else
	{
		tempValues = setCreate(1);
	}

	for(count=0; count<setSize(objs); count++)
	{
		if(dstat = objGetAttribute(setGet(objs, count), attrName, &gattrValue) ) goto CLEANUP;
		attrValue = nlsStrDup(gattrValue);
		low_set_add_str_unique(tempValues, attrValue);
	}

	if(*distValues)
	{
		setDestroy(*distValues);
	}
	*distValues = NULL;
	*distValues = tempValues;

CLEANUP:

	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
return( dstat );
}


status t0LatestBI(SetOfObjects itemObj,SetOfObjects itemRel,ObjectPtr *returnedObj,ObjectPtr *returnedRel,integer *mfail)
{
        char *mod_name =   "t0LatestBI";
        status dstat =   OKAY;

	integer count =	0;

	SetOfObjects successorObjSet = NULL;
	SetOfObjects successorObjRelSet = NULL;
	ObjectPtr tmpItemObj = NULL;
   	ObjectPtr tmpRelObj = NULL;
   	ObjectPtr tmpObjSuccessor = NULL;
	int setFinder = 0;
	printf("\nIn t0LatestBI");

	for(count=0; count<setSize(itemObj); count++)
	{
		tmpItemObj = setGet(itemObj,count);
		tmpRelObj = setGet(itemRel,count);

		if (dstat = ExpandObject2(SuccessrClass,tmpItemObj,"SuccessorOfItem",SC_SCOPE_OF_SESSION,&successorObjSet,&successorObjRelSet,mfail) ) goto CLEANUP;
		if(*mfail) goto CLEANUP;

		if (setSize(successorObjSet)>0)
		{
			tmpObjSuccessor = setGet(successorObjSet,0);

			if(dstat = ulyFindObjectInSet(tmpObjSuccessor,itemObj,OBIDAttr,0,&setFinder)) goto CLEANUP;

			if(setFinder>=0)
			{
				continue;
			}
			else
			{
				if(dstat = objCopy(returnedObj, tmpItemObj)) goto CLEANUP;
				if(dstat = objCopy(returnedRel, tmpRelObj)) goto CLEANUP;

				break;
			}
		}
		else
		{
			if(dstat = objCopy(returnedObj, tmpItemObj)) goto CLEANUP;
			if(dstat = objCopy(returnedRel, tmpRelObj)) goto CLEANUP;

			break;
		}
	}

CLEANUP:


if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
return( dstat );
}

int tm_curl_BAPI_create_change_mat ( char *data )
{
	struct memory chunk = {0};
	//char* response;
	CURLcode res;
	CURL *curl = curl_easy_init();
	if (!curl) {
        printf("\nFailed to initialize CURL");
        return 0;
    }

	struct curl_slist *list = NULL;


	if ( nlsStrCmp ( sSAPServer, "CVD" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmdev.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create dev
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVQ" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srmqa.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV_QA");//mat get all create qa
		curl_easy_setopt(curl, CURLOPT_USERPWD, "DEV_External:TmlB2B@1234");//with credential
	}
	else if ( nlsStrCmp ( sSAPServer, "CVP" ) ==  0 )
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://srm.inservices.tatamotors.com/RESTAdapter/PLM_ZBAPI_MATERIAL_SAVEDATA_CV");//mat get all create prod
		curl_easy_setopt(curl, CURLOPT_USERPWD, "PRD_External:TmlB2B@1234");//with credential
	}
	else
	{
		printf("\n sSAPServer is Blank..!!");fflush(stdout);
	}

	list = curl_slist_append(list, "Content-Type: application/json");

	printf("\nFile request content as below "); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

	printf("\ncurl_easy_setopt CURLOPT_WRITEFUNCTION"); fflush(stdout);

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);

	printf("\ncurl_easy_setopt"); fflush(stdout);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);

	printf("\ncurl_easy_setopt CURLOPT_WRITEDATA"); fflush(stdout);


	res = curl_easy_perform(curl);

	printf("\ncurl_easy_perform");fflush(stdout);
	printf("\nprint_json_object"); fflush(stdout);

	parse_json_object(chunk.response, "MAT_CREATE_CHANGE");

	printf("\nparse_json_object"); fflush(stdout);
	free(chunk.response);

	printf("\nfree"); fflush(stdout);

	curl_easy_cleanup(curl);

	printf("\ncurl_easy_cleanup"); fflush(stdout);
	return 0;
}
int call_BAPI_change_mat_view (
					string PartNumberDup,
					string MaterialGroupDup,
					string MatType,
					string MeasureUnit,
					string PartDescriptionDup,
					char proc_type[2],
					char spl_proc_key[3],
					char EEDmlNumber[11],
					char *json_change_mat_view_req_obj
				)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;
	
	
	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;
	
	cJSON *HEADDATA_req;
	
	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;
	
	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;
	
	
	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;
	
	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;
	
	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;
	
	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;
	
	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;
	
	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;
	
	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;
		
	
	
	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();
	
	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();
	
	HEADDATA_req = cJSON_CreateObject();
	
	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();
	
	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();
	
	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();
	
	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();
	
	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();
	
	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();
	
	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();
	
	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();
	
	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();
	
	
	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();
	
	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();
	
	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();
	
	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();
	
	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();
	
	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();
	
	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();
	
	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();
	
	
		
	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(EEDmlNumber));
		
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));//MaterialGroupDup
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));//drg_std_no
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));//drg_std_ind
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));//sheet_status
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));//PageFormat
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));//SheetNumberDup
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));//sheet_size
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString("NORM"));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(PartNumberDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(MatType));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));
	
	
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(PartDescriptionDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));
	
	
	
	/*cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));*/
	
	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(""));//mrp_type
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(""));//avail_chk
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(""));//profit_centre
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));//plan_calendar
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));
	
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));
	
	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	
	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));
	
	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));
	
			
	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	strcpy(json_change_mat_view_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;

}
int call_BAPI_extend_mat_view (
					string PartNumberDup,
					string MaterialGroupDup,
					string MatType,
					string MeasureUnit,
					string PartDescriptionDup,
					char proc_type[2],
					char spl_proc_key[3],
					char mrp_type[3],
					char avail_chk[3],
					char profit_centre[11],
					char EEDmlNumber[11],
					char *json_extend_mat_view_req_obj
				)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;


	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;

	cJSON *HEADDATA_req;

	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;

	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;


	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;

	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;

	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;

	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;

	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;

	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;

	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;



	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();

	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();

	HEADDATA_req = cJSON_CreateObject();

	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();

	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();

	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();

	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();

	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();

	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();

	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();

	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();

	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();


	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();

	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();

	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();

	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();

	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();

	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();

	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();

	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();



	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(EEDmlNumber));

	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(MaterialGroupDup));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(""));//drg_std_no
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(""));//drg_std_ind
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(""));//sheet_status
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(""));//PageFormat
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(""));//SheetNumberDup
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(""));//sheet_size
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString("NORM"));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(PartNumberDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(MatType));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));




	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(PartDescriptionDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));



	/*cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(mrp_type));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(avail_chk));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(profit_centre));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));//plan_calendar
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));



	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));



	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));


	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	strcpy(json_extend_mat_view_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;

}
int call_BAPI_create_mat_all_view (
					string PartNumberDup,
					string MaterialGroupDup,
					string MatType,
					string MeasureUnit,
					string PartDescriptionDup,
					string SheetNumberDup,
					string PageFormat,
					char drg_std_ind[4],
					char drg_std_no[15],
					char sheet_status[3],
					char sheet_size[3],
					char basic_division[3],
					char proc_type[2],
					char spl_proc_key[3],
					char mrp_type[3],
					char avail_chk[3],
					char profit_centre[11],
					char EEDmlNumber[11],
					char *json_create_mat_all_view_req_obj
				)
{
	cJSON *rfc_root;
	cJSON *exp_imp_tab_req;
	cJSON *CLIENTDATA_req;
	cJSON *CLIENTDATAX_req;
	cJSON *EXTENSIONIN_req;
	cJSON *EXTENSIONINX_req;
	cJSON *item1_req;
	cJSON *item2_req;


	cJSON *FORECASTPARAMETERS_req;
	cJSON *FORECASTPARAMETERSX_req;

	cJSON *HEADDATA_req;

	cJSON *INTERNATIONALARTNOS_req;
	cJSON *item3_req;

	cJSON *MATERIALDESCRIPTION_req;
	cJSON *item4_req;


	cJSON *MATERIALLONGTEXT_req;
	cJSON *item5_req;

	cJSON *PLANNINGDATA_req;
	cJSON *PLANNINGDATAX_req;

	cJSON *PLANTDATA_req;
	cJSON *PLANTDATAX_req;

	cJSON *PRTDATA_req;
	cJSON *item6_req;

	cJSON *PRTDATAX_req;
	cJSON *item7_req;

	cJSON *RETURNMESSAGES_req;
	cJSON *item8_req;

	cJSON *SALESDATA_req;
	cJSON *SALESDATAX_req;

	cJSON *STORAGELOCATIONDATA_req;
	cJSON *STORAGELOCATIONDATAX_req;

	cJSON *STORAGETYPEDATA_req;
	cJSON *STORAGETYPEDATAX_req;

	cJSON *TAXCLASSIFICATIONS_req;
	cJSON *item9_req;

	cJSON *UNITSOFMEASURE_req;
	cJSON *item10_req;

	cJSON *UNITSOFMEASUREX_req;
	cJSON *item11_req;

	cJSON *VALUATIONDATA_req;
	cJSON *VALUATIONDATAX_req;

	cJSON *WAREHOUSENUMBERDATA_req;
	cJSON *WAREHOUSENUMBERDATAX_req;



	char *out;
	rfc_root = cJSON_CreateObject();
	exp_imp_tab_req = cJSON_CreateObject();
	CLIENTDATA_req = cJSON_CreateObject();
	CLIENTDATAX_req = cJSON_CreateObject();

	EXTENSIONIN_req = cJSON_CreateObject();
	EXTENSIONINX_req = cJSON_CreateObject();
	item1_req = cJSON_CreateObject();
	item2_req = cJSON_CreateObject();

	HEADDATA_req = cJSON_CreateObject();

	FORECASTPARAMETERS_req = cJSON_CreateObject();
	FORECASTPARAMETERSX_req = cJSON_CreateObject();

	INTERNATIONALARTNOS_req = cJSON_CreateObject();
	item3_req = cJSON_CreateObject();

	MATERIALDESCRIPTION_req = cJSON_CreateObject();
	item4_req = cJSON_CreateObject();

	MATERIALLONGTEXT_req = cJSON_CreateObject();
	item5_req = cJSON_CreateObject();

	PLANNINGDATA_req = cJSON_CreateObject();
	PLANNINGDATAX_req = cJSON_CreateObject();

	PLANTDATA_req = cJSON_CreateObject();
	PLANTDATAX_req = cJSON_CreateObject();

	PRTDATA_req = cJSON_CreateObject();
	item6_req = cJSON_CreateObject();

	PRTDATAX_req = cJSON_CreateObject();
	item7_req = cJSON_CreateObject();

	RETURNMESSAGES_req = cJSON_CreateObject();
	item8_req = cJSON_CreateObject();


	SALESDATA_req = cJSON_CreateObject();
	SALESDATAX_req = cJSON_CreateObject();

	STORAGELOCATIONDATA_req = cJSON_CreateObject();
	STORAGELOCATIONDATAX_req = cJSON_CreateObject();

	STORAGETYPEDATA_req = cJSON_CreateObject();
	STORAGETYPEDATAX_req = cJSON_CreateObject();

	TAXCLASSIFICATIONS_req = cJSON_CreateObject();
	item9_req = cJSON_CreateObject();

	UNITSOFMEASURE_req = cJSON_CreateObject();
	item10_req = cJSON_CreateObject();

	UNITSOFMEASUREX_req = cJSON_CreateObject();
	item11_req = cJSON_CreateObject();

	VALUATIONDATA_req = cJSON_CreateObject();
	VALUATIONDATAX_req = cJSON_CreateObject();

	WAREHOUSENUMBERDATA_req = cJSON_CreateObject();
	WAREHOUSENUMBERDATAX_req = cJSON_CreateObject();



	cJSON_AddItemToObject(rfc_root, "ZBAPI_MATERIAL_SAVEDATA", exp_imp_tab_req);
	cJSON_AddItemToObject(exp_imp_tab_req, "CHANGE_NUMBER", cJSON_CreateString(EEDmlNumber));

	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATA", CLIENTDATA_req);
	cJSON_AddItemToObject(CLIENTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(MaterialGroupDup));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATA_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATA_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASE_UOM_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOCUMENT" , cJSON_CreateString(drg_std_no));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_TYPE" , cJSON_CreateString(drg_std_ind));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_VERS" , cJSON_CreateString(sheet_status));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_FORMAT" , cJSON_CreateString(PageFormat));
	cJSON_AddItemToObject(CLIENTDATA_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NO_SHEETS" , cJSON_CreateString(SheetNumberDup));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SIZE_DIM" , cJSON_CreateString(sheet_size));
	cJSON_AddItemToObject(CLIENTDATA_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DIVISION" , cJSON_CreateString(basic_division));
	cJSON_AddItemToObject(CLIENTDATA_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ITEM_CAT" , cJSON_CreateString("NORM"));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATA_req, "ANP" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "CLIENTDATAX", CLIENTDATAX_req);
	cJSON_AddItemToObject(CLIENTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	if(!nlsIsStrNull(MaterialGroupDup))
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString("X"));
	}
	else
	{
		cJSON_AddItemToObject(CLIENTDATAX_req, "MATL_GROUP" , cJSON_CreateString(""));
	}
	cJSON_AddItemToObject(CLIENTDATAX_req, "OLD_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASE_UOM_ISO" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PO_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOCUMENT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_VERS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_FORMAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DOC_CHG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGE_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NO_SHEETS" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_MEMO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAGEFORMAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SIZE_DIM" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BASIC_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_DESCR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DSN_OFFICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_VALKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NET_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CONTAINER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TEMP_CONDS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "TRANS_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DIVISION" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COMPETITOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QTY_GR_GI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROC_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEASON" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LABEL_FORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_HIER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CAD_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLOWED_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_WT_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ALLWD_VOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACK_VO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WT_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VOL_TOL_LT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VAR_ORD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SH_MAT_TYP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "FILL_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STACK_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAT_GRP_SM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "AUTHORITYGROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QM_PROCMNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CATPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MINREMLIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SHELF_LIFE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STOR_PCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SAL_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ENVT_RLVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_ALLOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUAL_DIK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANU_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MFR_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MANUF_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZMATPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HIGH_VISC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "LOOSEORLIQ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CLOSED_BOX" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "APPD_B_REC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATCMPLLVL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PAR_EFF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ROUND_UP_RULE_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PERIOD_IND_EXPIRATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PROD_COMPOSITION_ON_PACKAGING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ITEM_CAT" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "INV_MAT_NO_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATERIAL_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "CM_RELEVANCE_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SLED_BBD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIALIZATION_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EXTMATLGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "UOMUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "GDS_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PL_REF_MAT_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WE_ORIGIN_ACCEPTANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "STD_HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PILFERABLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_STORAGE_CONDITION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "WHSE_MATERIAL_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HANDLING_INDICATOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HAZ_MAT_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "HU_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "VARIABLE_TARE_WEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_CAPACITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "OVERCAPACITY_TOLERANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_ALLOWED_HEIGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MAX_DIMENSION_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUARANTINE_PERIOD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "QUALITY_INSP_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SERIAL_NUMBER_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_TOLERANCE_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "EWM_CW_INPUT_CONTROL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PCKGING_SMARTFORM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PACOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "DG_PCKGING_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ADJUST_PROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "IPMIPPRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "MEDIUM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "NSNID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "PHYSICAL_COMMODITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "SEGMENTATION_RELEVANCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(CLIENTDATAX_req, "ANP" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_CAD_CALL", cJSON_CreateString(""));
	cJSON_AddItemToObject(exp_imp_tab_req, "FLAG_ONLINE", cJSON_CreateString(""));

	/*cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONIN", EXTENSIONIN_req);
	cJSON_AddItemToObject(EXTENSIONIN_req, "item" , item1_req);
	cJSON_AddItemToObject(item1_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item1_req, "VALUEPART4" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "EXTENSIONINX", EXTENSIONINX_req);
	cJSON_AddItemToObject(EXTENSIONINX_req, "item" , item2_req);
	cJSON_AddItemToObject(item2_req, "STRUCTURE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item2_req, "VALUEPART4" , cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "HEADDATA", HEADDATA_req);
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL" , cJSON_CreateString(PartNumberDup));
	cJSON_AddItemToObject(HEADDATA_req, "IND_SECTOR" , cJSON_CreateString("M"));
	cJSON_AddItemToObject(HEADDATA_req, "MATL_TYPE" , cJSON_CreateString(MatType));
	cJSON_AddItemToObject(HEADDATA_req, "BASIC_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "SALES_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PURCHASE_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "MRP_VIEW" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(HEADDATA_req, "FORECAST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WORK_SCHED_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "PRT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "STORAGE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "WAREHOUSE_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "QUALITY_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "ACCOUNT_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "COST_VIEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "INP_FLD_CHECK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(HEADDATA_req, "MATERIAL_VERSION" , cJSON_CreateString(""));




	cJSON_AddItemToObject(exp_imp_tab_req, "MATERIALDESCRIPTION", MATERIALDESCRIPTION_req);
	cJSON_AddItemToObject(MATERIALDESCRIPTION_req, "item" , item4_req);
	cJSON_AddItemToObject(item4_req, "LANGU" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "LANGU_ISO" , cJSON_CreateString("E"));
	cJSON_AddItemToObject(item4_req, "MATL_DESC" , cJSON_CreateString(PartDescriptionDup));
	cJSON_AddItemToObject(item4_req, "DEL_FLAG" , cJSON_CreateString(""));



	/*cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATA", PLANNINGDATA_req);
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATA_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANNINGDATAX", PLANNINGDATAX_req);
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_PLANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "CONVFACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANNINGDATAX_req, "PLNG_MATL_VERSION" , cJSON_CreateString(""));*/

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATA", PLANTDATA_req);
	cJSON_AddItemToObject(PLANTDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_TYPE" , cJSON_CreateString(mrp_type));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TYPE" , cJSON_CreateString(proc_type));
	cJSON_AddItemToObject(PLANTDATA_req, "SPPROCTYPE" , cJSON_CreateString(spl_proc_key));
	cJSON_AddItemToObject(PLANTDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAILCHECK" , cJSON_CreateString(avail_chk));
	cJSON_AddItemToObject(PLANTDATA_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROFIT_CTR" , cJSON_CreateString(profit_centre));
	cJSON_AddItemToObject(PLANTDATA_req, "PPC_PL_CAL" , cJSON_CreateString(""));//plan_calendar
	cJSON_AddItemToObject(PLANTDATA_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATA_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "PLANTDATAX", PLANTDATAX_req);
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ABC_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CRIT_PART" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISSUE_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRPPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_CTRLER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLND_DELRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GR_PR_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ASSY_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOTSIZEKEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPPROCTYPE" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MINLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAXLOTSIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIXED_LOT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_VAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORD_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEP_REQ_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOR_COSTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALT_BOM_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCONTINU" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EFF_O_DAY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "GRP_REQMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIXED_MRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SM_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BACKFLUSH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODUCTION_SCHEDULER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUPTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INTEROP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INHSEPRODT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGEPERIOD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STGE_PD_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNLIMITED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNDER_TOL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLENTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPLACE_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IND_POST_TO_INSP_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DOC_REQD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOADINGGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCH_MGMT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QUOTAUSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERV_LEVEL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPLIT_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAILCHECK" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "FY_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CORR_FACT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SETUP_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BASE_QTY_PLAN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SHIP_PROC_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUP_SOURCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_P_ORD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SOURCELIST" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COUNTRYORI_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REGIONORIG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMM_CO_UN_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EXPIMPGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROFIT_CTR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(PLANTDATAX_req, "PPC_PL_CAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REP_MANUF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PL_TI_FNCE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMMODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FWD_CONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ALTERNATIVE_BOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BOM_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLANLISTCNT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SPECPROCTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_UNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ISS_ST_LOC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COMP_SCRAP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CERT_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CYCLE_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "COVPROFILE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_PH_INV" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "VARIANCE_KEY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SERNO_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REPMANPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NEG_STOCKS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_RGMTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLNG_CYCLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROUND_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "D_TO_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MULT_REF_M" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AUTO_RESET" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_NO_NEW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EX_CERT_DT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MILIT_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "INSP_INT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CO_PRODUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLAN_STRGP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SLOC_EXPRC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BULK_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CC_FIXED" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DETERM_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "QM_AUTHGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "TASK_LIST_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUR_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODPROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFTY_T_ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SAFETYTIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PLORD_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "BATCHENTRY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PVALIDFROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MATFRGTGRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODVERSCS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_CFOP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_LIST_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "EU_MAT_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CAS_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PRODCOM_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CTRL_CODE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "JIT_RELVT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAT_GRP_TRANS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "HANDLG_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SUPPLY_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FAIR_SHARE_RULE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PUSH_DISTRIB" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEPLOY_HORIZ" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MAX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FIX_LOT_SIZE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "LOT_INCREMENT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PROD_CONV_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISTR_PROF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "PERIOD_PROFILE_SAFETY_TIME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FXD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "AVAIL_CHECK_ALL_PROJ_SEGMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "OVERALLPRF" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MRP_RELEVANCY_DEP_REQUIREMENTS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "MIN_SAFETY_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "NO_COSTING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UNIT_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "FOLLOW_UP_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_EXTERNAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_GUID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "REFMATCONS_VERSION" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ROTATION_DATE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_E" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_V" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "ORIGINAL_BATCH_REF_MATERIAL_G" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_RELEVANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "IUID_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "UID_IEA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STRATEGY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "SEGMENTATION_STATUS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "CONSUMPTION_PRIORITY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DISCRETE_BATCH_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "STOCK_PROTECTION_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(PLANTDATAX_req, "DEFAULT_STOCK_SEGMENT" , cJSON_CreateString(""));



	cJSON_AddItemToObject(exp_imp_tab_req, "RETURNMESSAGES", RETURNMESSAGES_req);
	cJSON_AddItemToObject(RETURNMESSAGES_req, "item", item8_req);
	cJSON_AddItemToObject(item8_req, "TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ID" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "NUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "LOG_MSG_NO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "MESSAGE_V4" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "PARAMETER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "ROW" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "FIELD" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item8_req, "SYSTEM" , cJSON_CreateString(""));



	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATA" , STORAGELOCATIONDATA_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATA_req, "INV_CORR_FAC" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "STORAGELOCATIONDATAX" , STORAGELOCATIONDATAX_req);
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PLANT" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_LOC" , cJSON_CreateString("ED03"));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "MRP_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "SPEC_PROC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REORDER_PT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "REPL_QTY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "STGE_BIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "PICKG_AREA" , cJSON_CreateString(""));
	cJSON_AddItemToObject(STORAGELOCATIONDATAX_req, "INV_CORR_FAC" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASURE" , UNITSOFMEASURE_req);
	cJSON_AddItemToObject(UNITSOFMEASURE_req, "item" , item10_req);
	cJSON_AddItemToObject(item10_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item10_req, "NUMERATOR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "DENOMINATR" , cJSON_CreateString("1"));
	cJSON_AddItemToObject(item10_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item10_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));


	cJSON_AddItemToObject(exp_imp_tab_req, "UNITSOFMEASUREX" , UNITSOFMEASUREX_req);
	cJSON_AddItemToObject(UNITSOFMEASUREX_req, "item" , item11_req);
	cJSON_AddItemToObject(item11_req, "ALT_UNIT" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "ALT_UNIT_ISO" , cJSON_CreateString(MeasureUnit));
	cJSON_AddItemToObject(item11_req, "NUMERATOR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "DENOMINATR" , cJSON_CreateString("X"));
	cJSON_AddItemToObject(item11_req, "EAN_UPC" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EAN_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "LENGTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "WIDTH" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "HEIGHT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_DIM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUME" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "VOLUMEUNIT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GROSS_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "UNIT_OF_WT_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "SUB_UOM_ISO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "GTIN_VARIANT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "NESTING_FACTOR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "MAXIMUM_STACKING" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "CAPACITY_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(item11_req, "EWM_CW_UOM_TYPE" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATA" , VALUATIONDATA_req);
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATA_req, "TAX_CML_UN" , cJSON_CreateString(""));

	cJSON_AddItemToObject(exp_imp_tab_req, "VALUATIONDATAX" , VALUATIONDATAX_req);
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_AREA" , cJSON_CreateString("1005"));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_TYPE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEL_FLAG" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_CTRL" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOVING_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PRICE_UNIT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CLASS" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_CTRL_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MOV_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "STD_PR_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VCLASS_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PR_UNIT_PY" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VAL_CAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "FUTURE_PR" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VALID_FROM" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLND_PRICE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRICE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE1" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "PLNDPRDATE3" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "LIFO_FIFO" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "POOLNUMBER" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAXPRICE_2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "COMMPRICE2" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "DEVAL_IND" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_GROUP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "OVERHEAD_GRP" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "QTY_STRUCT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_ACTIVE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ML_SETTLE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "ORIG_MAT" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_SO_STK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "VM_P_STOCK" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MATL_USAGE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "MAT_ORIGIN" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "IN_HOUSE" , cJSON_CreateString(""));
	cJSON_AddItemToObject(VALUATIONDATAX_req, "TAX_CML_UN" , cJSON_CreateString(""));


	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	strcpy(json_create_mat_all_view_req_obj,out);
	free(out);
	cJSON_Delete(rfc_root);
	return 0;

}

int DZ_ckd_bapi_mat(ObjectPtr PartOPtr,string MatPartNumber,char EEDmlNumber[11],char shop_store)
{

	char drg_std_ind[4]={0};
	char drg_std_no[15]={0};
	char sheet_status[3]={0};
//	char schas_type_no[15];
	char sheet_size[3]={0};
	char acr_ind[3]={0};
	int cs_logic();
	int mat_create();
//	char net_wt[18]= {0};
//	char gros_wt[18]= {0};
//	char volume[18]= {0};
	char basic_division[3]= {0};
	char proc_type[2] = {0};
	char spl_proc_key[3]= {0};

	char mrp_type[3]= {0};

//	char plan_calendar[4]= {0};

	char avail_chk[3]= {0};

	char profit_centre[11];

	int go_for_rfc = 0;

	int flag = 0;
//	static RFC_RC RfcRc;
//	static RFC_HANDLE hRfc;
//	BAPIMATHEAD eBapiMatHead;
//	BAPI_MARA eBasicView;
//	BAPI_MARAX eBasicViewx;
//	BAPI_MARC eMrpView;
//	BAPI_MARCX eMrpViewx;
//	BAPI_MPGD eBapi_Mpgd;
//	BAPI_MPGDX eBapi_Mpgdx;
//	BAPI_MARD eBapi_Mard;
//	BAPI_MARDX eBapi_Mardx;
//	BAPI_MBEW eAccView;
//	BAPI_MBEWX eAccViewx;
//	RMMG1_AENNR eRmmg1_Aennr;
//	BAPIRET2 eBapiret2;
//	ITAB_H thBapi_Makt = ITAB_NULL;
//	ITAB_H thBapi_Marm = ITAB_NULL;
//	ITAB_H thBapi_Marmx = ITAB_NULL;
//	char xException[256];
//	BAPI_MAKT *tBapi_Makt;
//	BAPI_MARM *tBapi_Marm;
//	BAPI_MARMX *tBapi_Marmx;


	status dstat = OKAY;
	int mfail = OKAY;
	string myzeroDup1 = NULL;
	string myzeroDup2 = NULL;
	string myzeroDup3 = NULL;
	string myzeroDup4 = NULL;


	int result = 0;
	int t = 0;
	string PartNumber = NULL;
	string PartNumberDup = NULL;
	string MaterialGroup = NULL;
	string MaterialGroupDup = NULL;
	string PartDescription = NULL;
	string PartDescriptionDup = NULL;
	string UnitOfMeasure = NULL;
	string UnitOfMeasureDup = NULL;
	string MeasureUnit = NULL;
	string MakeBuyInd = NULL;
	string MakeBuyIndDup = NULL;
	string PartType = NULL;
	string PartTypeDup = NULL;
	string MatType = NULL;
	string DrawingInd = NULL;
	string DrawingIndDup = NULL;
	int noOfDocs = 0;
	int TabSize = 0;
	string DocClass = NULL;
	string DocNumber = NULL;
	string DocNumberDup = NULL;
	string DrawingType = NULL;
	string DrawingTypeDup = NULL;
	string DrawingRevision = NULL;
	string DrawingRevisionDup = NULL;
	string Size = NULL;
	string SizeDup = NULL;
	string SheetNumber = NULL;
	string SheetNumberDup = NULL;
	string PageFormat = NULL;
	string PartRevision = NULL;
	string PartRevisionDup = NULL;
	SetOfObjects docObjs = NULL;
	SetOfObjects docRelObjs = NULL;
	SetOfObjects latestDocs = NULL;
	SetOfObjects latestRelDocs = NULL;
	SetOfObjects docRefObjs = NULL;
	SetOfObjects docRelRefObjs = NULL;
	SetOfObjects latestRefDocs = NULL;
	SetOfObjects latestRelRefDocs = NULL;
	SetOfObjects lRefdocs = NULL;
	ObjectPtr docOPtr = NULL;
	ObjectPtr lRefdocOPtr = NULL;
	ObjectPtr InfoDialogObj = NULL;
	SqlPtr sqlDoc = NULL;
	string sPartClass = NULL;
	string prjcode = NULL;
	string prjcodeDup = NULL;


	myzeroDup1 = nlsStrAlloc(2);
	myzeroDup2 = nlsStrAlloc(7);
	myzeroDup3 = nlsStrAlloc(7);
	myzeroDup4 = nlsStrAlloc(12);
	MeasureUnit = nlsStrAlloc(4);



	nlsStrCpy(myzeroDup1,"0.0");
	nlsStrCpy(myzeroDup2,"0.00");
	nlsStrCpy(myzeroDup3,"0.000");
	nlsStrCpy(myzeroDup4,"0.0000");

	strcpy(proc_type,"");
	strcpy(spl_proc_key,"");



	if(dstat = objGetAttribute(PartOPtr, "PartNumber", &PartNumber)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "Revision", &PartRevision)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "Nomenclature", &PartDescription)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "t5UQdup", &UnitOfMeasure)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr,"t5PunMakeBuyIndicator",&MakeBuyInd)) goto CLEANUP;

	if(dstat = objGetClass(PartOPtr,&sPartClass)) goto CLEANUP;
	if(nlsStrCmp(sPartClass,"t5EeAsm")==0)
	{
		if(dstat = objGetAttribute(PartOPtr, "t5EePartType", &PartType)) goto CLEANUP;
		if(dstat = objGetAttribute(PartOPtr, "t5EEMaterialClass", &MaterialGroup)) goto CLEANUP;
		if(!nlsIsStrNull(MaterialGroup))
		{
			MaterialGroupDup = nlsStrDup(MaterialGroup);
		}
	}
	else
	{
		if(dstat = objGetAttribute(PartOPtr, "PartType", &PartType)) goto CLEANUP;
		if(dstat = objGetAttribute(PartOPtr, "ProjectName", &prjcode)) goto CLEANUP;
		if(!nlsIsStrNull(prjcode))
		{
			prjcodeDup = nlsStrDup(prjcode);
		}
		if(nlsStrCmp(prjcodeDup,"1111")==0)
		{
			if(dstat = objGetAttribute(PartOPtr, "t5MatlClass", &MaterialGroup)) goto CLEANUP;
			if(!nlsIsStrNull(MaterialGroup))
			{
				MaterialGroupDup = nlsStrDup(MaterialGroup);
			}
			else
			{
				MaterialGroupDup = nlsStrDup("");
			}
		}
		if(nlsStrCmp(prjcodeDup,"1111")!=0)
		{
			MaterialGroupDup = nlsStrDup("ZZZZZZ");
		}

	}

	if(dstat = objGetAttribute (PartOPtr, "t5DrawingInd", &DrawingInd)) goto CLEANUP;





	if(!nlsIsStrNull(PartNumber))
	{
		PartNumberDup = nlsStrDup(PartNumber);
	}
	if(!nlsIsStrNull(PartRevision))
	{
		PartRevisionDup = nlsStrDup(PartRevision);
	}
	if(!nlsIsStrNull(PartDescription))
	{
		PartDescriptionDup = nlsStrDup(PartDescription);
	}

	if(!nlsIsStrNull(UnitOfMeasure))
	{
		UnitOfMeasureDup = nlsStrDup(UnitOfMeasure);
	}
	else
	{
		printf("\nPart UnitOfMeasure is null");
	}
	if(ercDmlflag == 1)
	{
		MakeBuyInd = nlsStrDup("E");
		MakeBuyIndDup = nlsStrDup("E");
	}
	if(!nlsIsStrNull(MakeBuyInd))
	{
		MakeBuyIndDup = nlsStrDup(MakeBuyInd);
		nlsStrCpy(proc_type,subString(MakeBuyIndDup, 0, 1));
		printf("\nProcurement Type: %s", proc_type);
		fprintf(fsuccess,"\nProcurement Type: %s", proc_type);
		nlsStrCpy(spl_proc_key, subString(MakeBuyIndDup, 1, 2));
		printf("\nSpecial Procurement Key: %s", spl_proc_key);
		fprintf(fsuccess,"\nSpecial Procurement Key: %s", spl_proc_key);

		//09 March 2016
		//Rajendra:6072-Allow material creation for �F18� E1 parts as �F� in SAP-1005

		if((nlsStrCmp(spl_proc_key,"18")==0) && (nlsStrCmp(proc_type,"F")==0))
		{
			nlsStrCpy(spl_proc_key,"");

			printf("\nProcurement Type1: %s", proc_type);
			printf("\nSpecial Procurement Key1: %s\n", spl_proc_key);
		}


	}
	else
	{
		printf("\nPart MakeBuyInd is null");
		fprintf(fsuccess,"\nPart MakeBuyInd is null");
	}
	if(nlsStrCmp(MakeBuyIndDup,"NA")==0)
	{
		printf("\nPart MakeBuyInd is NA hence exit from material create");
		fprintf(fsuccess,"\nPart MakeBuyInd is NA hence exit from material create");
		return 1;
	}

	if(strcmp(proc_type,"")==0)
	{
		printf("\nPart %s MakeBuyInd is NULL hence exit from material create",PartNumberDup);
		fprintf(fsuccess,"\nPart %s MakeBuyInd is NULL hence exit from material create",PartNumberDup);
		return 1;
	}


	if(!nlsIsStrNull(PartType))
	{
		PartTypeDup = nlsStrDup(PartType);
	}
	else
	{
		printf("\nPart t5EEPartType is null");
		printf("\nMessage Material creation [%s] Part t5EEPartType is null",PartNumberDup);
		fprintf(fsuccess,"\nMessage Material creation [%s] Part t5EEPartType is null",PartNumberDup);
		goto CLEANUP;
	}
	printf("PartType:[%s]",PartTypeDup);
	fprintf(fsuccess,"PartType:[%s]",PartTypeDup);
	MatType = nlsStrAlloc(10);
	if (nlsStrCmp(PartTypeDup, "C") == 0)
	{
		nlsStrCpy(MatType,"HALB");
	}
	else if (nlsStrCmp(PartTypeDup, "A") == 0)
	{
		nlsStrCpy(MatType,"HALB");
	}

	printf("\nMatType:[%s]",MatType);
	if (nlsStrCmp(UnitOfMeasureDup,"1") == 0)
	{
		nlsStrCpy(MeasureUnit,"M");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"2") == 0)
	{
		nlsStrCpy(MeasureUnit,"KG");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"3") == 0)
	{
		nlsStrCpy(MeasureUnit,"L");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"4") == 0)
	{
		nlsStrCpy(MeasureUnit,"EA");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"5") == 0)
	{
		nlsStrCpy(MeasureUnit,"M2");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"6") == 0)
	{
		nlsStrCpy(MeasureUnit,"EA");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"7") == 0)
	{
		nlsStrCpy(MeasureUnit,"TD");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"8") == 0)
	{
		nlsStrCpy(MeasureUnit,"M3");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"9") == 0)
	{
		nlsStrCpy(MeasureUnit,"TS");
	}

	printf("\nMeasureUnit:[%s]",MeasureUnit);
	if(!nlsIsStrNull(DrawingInd))
	{
		DrawingIndDup = nlsStrDup(DrawingInd);
		printf("\nDrawing Indicator: %s", DrawingIndDup);
		fflush(stdout);
		fprintf(fsuccess,"\nDrawing Indicator: %s", DrawingIndDup);
	}
	else
	{
		printf("\nDrawing Indicator is NULL");
		fprintf(fsuccess,"\nDrawing Indicator is NULL");
		fflush(stdout);
	}
	strcpy(basic_division,"01");
	printf("\nbasic_division:[%s]",basic_division);
	fflush(stdout);

	strcpy(mrp_type,"ND");
	printf("\nmrp_type:[%s]",mrp_type);
	fflush(stdout);
	strcpy(avail_chk,"02");
	printf("\navail_chk:[%s]",avail_chk);
	fflush(stdout);
	//strcpy(profit_centre,"0001111060");
	strcpy(profit_centre,"0000705000");
	printf("\nprofit_centre:[%s]",profit_centre);
	fflush(stdout);





	SheetNumberDup = nlsStrDup("02");
	printf("\nSheetNumberDup:[%s]",SheetNumberDup);
	fflush(stdout);

	PageFormat = nlsStrDup("a4");
	printf("\nPageFormat:[%s]",PageFormat);
	fflush(stdout);
	if((nlsStrCmp(PartTypeDup,"D") != 0))
	{
		printf("\nPart is not dummy hence checking Drawing indicator");
		fflush(stdout);
		if(nlsStrCmp(DrawingIndDup,"D")==0)
		{
			printf("\nDrawing indicator is D for part");
			fflush(stdout);
			if(dstat = ExpandObject2("PartDoc",PartOPtr,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,&mfail)) goto CLEANUP;
			printf("\nsetSize(docObjs):[%d]",setSize(docObjs));
			fflush(stdout);
			if(setSize(docObjs)<=0)
			{

				if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,&mfail)) goto CLEANUP;
				printf("\nsetSize(latestDocs):[%d]",setSize(latestDocs));
				fflush(stdout);
				if (setSize(latestDocs)>0)
				{
					printf("\nIn 'Is Described By' drawing documents loop");
					fprintf(fsuccess,"\nIn 'Is Described By' drawing documents loop");
					fflush(stdout);
					for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
					{
						docOPtr = setGet(latestDocs, noOfDocs);
						DocClass = low_getspace(20);
						if(dstat = objGetClass(docOPtr, &DocClass)) goto CLEANUP;
						if((nlsStrCmp(DocClass,"t5DrwDoc") == 0))
						{
							result = 1;
							printf("\n<Drawing Documents Found!>");
							fprintf(fsuccess,"\n<Drawing Documents Found!>");
							fflush(stdout);

							if(dstat = objGetAttribute (docOPtr, "DocumentName", &DocNumber)) goto CLEANUP;
							DocNumberDup = nlsStrDup(DocNumber);
							nlsStrCpy(drg_std_no,DocNumberDup);
							printf("\nDocument Number: %s", DocNumberDup);
							fprintf(fsuccess,"\nDocument Number: %s", DocNumberDup);
							fflush(stdout);

							if(dstat = objGetAttribute(docOPtr, "t5DrawingType", &DrawingType)) goto CLEANUP;
							if(!nlsIsStrNull(DrawingType))
							{
								DrawingTypeDup = nlsStrDup(DrawingType);
								nlsStrCpy(drg_std_ind,DrawingTypeDup);
								printf("\nDocument Type: %s", DrawingTypeDup);
								fprintf(fsuccess,"\nDocument Type: %s", DrawingTypeDup);
								fflush(stdout);
							}
							else
							{
								printf("\nDocument Type is NULL!");
								fprintf(fsuccess,"\nDocument Type is NULL!");
								fflush(stdout);

							}
							if(dstat = objGetAttribute (docOPtr, "Revision", &DrawingRevision)) goto CLEANUP;
							if(!nlsIsStrNull(DrawingRevision))
							{
								DrawingRevisionDup = nlsStrDup(DrawingRevision);
								nlsStrCpy(sheet_status,DrawingRevisionDup);
								printf("\nDocument Version: %s", DrawingRevisionDup);
								fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								fflush(stdout);
							}
							else
							{
								DrawingRevisionDup = nlsStrDup("NR");
								nlsStrCpy(sheet_status,DrawingRevisionDup);
								printf("\nDocument Version: %s", DrawingRevisionDup);
								fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								fflush(stdout);

							}

							if(dstat = objGetAttribute (docOPtr, "t5SheetSize", &Size)) goto CLEANUP;
							if(!nlsIsStrNull(Size))
							{
								SizeDup = nlsStrDup(Size);
								printf("\nSheet Size: %s", SizeDup);
								fprintf(fsuccess,"\nSheet Size: %s", SizeDup);
								fflush(stdout);
							}
							else
							{
								printf("\nSheet Size is NULL!");
								fprintf(fsuccess,"\nSheet Size is NULL!");
								fflush(stdout);

							}

							TabSize=0;
							if(dstat = objGetTableSize(docOPtr,"t5SheetDetails",&TabSize)) goto CLEANUP;
							printf("\nGetlRefTableSize:[%d]",TabSize);fflush(stdout);
							fflush(stdout);

							if(TabSize==0)
							{
								SheetNumberDup = nlsStrDup("1");
							}

							for(t=0;t<TabSize;t++)
							{
								SheetNumber = NULL;
								SheetNumberDup = NULL;
								if(dstat = GetInfoItem(docOPtr,&InfoDialogObj,&mfail)) goto CLEANUP;
								if(dstat = objGetTableAttribute(InfoDialogObj,"t5SheetDetails",t,"t5SheetNo",&SheetNumber)) goto CLEANUP;
								if(!nlsIsStrNull(SheetNumber))
								{
									SheetNumberDup = nlsStrDup(SheetNumber);
								}
							}
						}
					}
					if (result == 0)
					{
						printf("\n<No 'IsDescribedBy' Drawing Documents found for Part %s %d>\n", PartNumberDup,setSize(latestRefDocs));
						fprintf(fsuccess,"\n<No 'IsDescribedBy' Drawing Documents found for Part %s %d>\n", PartNumberDup,setSize(latestRefDocs));
						fflush(stdout);
					}
				}
			}
			else
			{
				printf("\nNo drawing doc attached");
				fprintf(fsuccess,"\nNo drawing doc attached");
				fflush(stdout);
			}

			printf("\nGoing for ref drg doc");
			fflush(stdout);
			if(dstat = ExpandObject2("InfoDwg",PartOPtr,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docRefObjs,&docRelRefObjs,&mfail)) goto CLEANUP;
			if(setSize(docRefObjs)<=0)
			{


				if(dstat = t5GetLatestDocumnets(docRefObjs,docRelRefObjs,&latestRefDocs,&latestRelRefDocs,&mfail)) goto CLEANUP;

				if (setSize(latestRefDocs)>0)
				{
					printf("\nIn 'Is Referenced By' drawing documents loop");
					fprintf(fsuccess,"\nIn 'Is Referenced By' drawing documents loop");
					for(noOfDocs = 0; noOfDocs<setSize(latestRefDocs); noOfDocs++)
					{
						docOPtr = setGet(latestRefDocs, noOfDocs);
						DocClass = low_getspace(20);

						if(dstat = objGetClass(docOPtr, &DocClass)) goto CLEANUP;
						if((nlsStrCmp(DocClass,"t5DrwDoc") == 0))
						{
							result = 2;
							printf("\n<Drawing Documents Found!>");
							fprintf(fsuccess,"\n<Drawing Documents Found!>");

							if(dstat = objGetAttribute (docOPtr, "DocumentName", &DocNumber)) goto CLEANUP;
								DocNumberDup = nlsStrDup(DocNumber);
							nlsStrCpy(drg_std_no,DocNumberDup);
							printf("\nDocument Number: %s", DocNumberDup);
							fprintf(fsuccess,"\nDocument Number: %s", DocNumberDup);

							if
							(
								(dstat = oiSqlCreateSelect(&sqlDoc)) ||
								(dstat = oiSqlWhereBegParen(sqlDoc)) ||
								(dstat = oiSqlWhereEQ(sqlDoc,"DocumentName",DocNumberDup)) ||
								(dstat = oiSqlWhereAND(sqlDoc))||
								(dstat = oiSqlWhereEQ(sqlDoc,"Superseded","-")) ||
								(dstat = oiSqlWhereEndParen(sqlDoc)) ||
								(dstat = QueryWhere("t5DrwDoc",sqlDoc,&lRefdocs,&mfail))
							)
							goto CLEANUP;

							if(setSize(lRefdocs)> 0)
							{
								lRefdocOPtr = setGet(lRefdocs,0);

								if(dstat = objGetAttribute (lRefdocOPtr, "t5DrawingType", &DrawingType)) goto CLEANUP;
								if(!nlsIsStrNull(DrawingType))
								{
									DrawingTypeDup = nlsStrDup(DrawingType);
									nlsStrCpy(drg_std_ind,DrawingTypeDup);
									printf("\nDocument Type: %s", DrawingTypeDup);
									fprintf(fsuccess,"\nDocument Type: %s", DrawingTypeDup);
								}
								else
								{
									printf("\nDocument Type is NULL!");
									fprintf(fsuccess,"\nDocument Type is NULL!");
								 }


								if(dstat = objGetAttribute (lRefdocOPtr, "Revision", &DrawingRevision)) goto CLEANUP;
								if(!nlsIsStrNull(DrawingRevision))
								{
									DrawingRevisionDup = nlsStrDup(DrawingRevision);
									nlsStrCpy(sheet_status,DrawingRevisionDup);
									printf("\nDocument Version: %s", DrawingRevisionDup);
									fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								}
								else
								{
									printf("\nDocument Version is NULL!");
									fprintf(fsuccess,"\nDocument Version is NULL!");
								}


								printf("\nbefore getting the details of ref drawing");
								fprintf(fsuccess,"\nbefore getting the details of ref drawing");
								TabSize=0;

								if(dstat = objGetTableSize(lRefdocOPtr,"t5SheetDetails",&TabSize)) goto CLEANUP;
								printf("\nGetlRefTableSize:[%d]",TabSize);fflush(stdout);

								SizeDup=NULL;
								if(TabSize==0)
								{
									SizeDup = nlsStrDup("1");
									fprintf(fsuccess,"\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
								}
								for(t=0;t<TabSize;t++)
								{
									if(!nlsIsStrNull(Size))
									{
										nlsStrFree(Size);
										Size = NULL;
									}
									if(!nlsIsStrNull(SizeDup))
									{
										nlsStrFree(SizeDup);
										SizeDup = NULL;
									}

									if(dstat = GetInfoItem(docOPtr,&InfoDialogObj,&mfail)) goto CLEANUP;
									if(dstat = objGetTableAttribute(InfoDialogObj,"t5SheetDetails",t,"t5SheetNo",&Size)) goto CLEANUP;
									if(!nlsIsStrNull(Size))
									{
										SizeDup = nlsStrDup(Size);
									}
									else
									{
										SizeDup = nlsStrDup("zero");
									}
								}
								printf("\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
								fprintf(fsuccess,"\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
							}
						}
					}

					if (result == 0)
					{
						printf("\n<No 'IsReferencedBy' Drawing Documents found for Part %s>\n", PartNumberDup);
						fprintf(fsuccess,"\n<No 'IsReferencedBy' Drawing Documents found for Part %s>\n", PartNumberDup);
					}
				}
				else
				{
					printf("\n<No Documents found for Part %s>", PartNumberDup);
					fprintf(fsuccess,"\n<No Documents found for Part %s>", PartNumberDup);
				}
			}
			else
			{
				printf("\nNo ref drawing doc attached hence return");
				fprintf(fsuccess,"\nNo ref drawing doc attached hence return");
			}
		}
		else
		{
			printf("\nGetting NR revision here");
			fprintf(fsuccess,"\nGetting NR revision here");
			DrawingRevisionDup = nlsStrDup("");
			nlsStrCpy(sheet_status,"");
			SizeDup = nlsStrDup("");
			SheetNumberDup = nlsStrDup("");
			PageFormat = nlsStrDup("");
			nlsStrCpy(drg_std_no,"DRG NOT REQUIRED");

		}
	}

	pstat='0';
	pstat_mrp='0';
	pstat_acc='0';


	GetCSPstat ( PartNumberDup ) ;
	pstat_basicFun ( ) ;


	if((strcmp(acr_ind,"D") != 0))
	{


		if(flag == 0 )
		{


			printf("\nmat_part:[%s]",PartNumberDup);
			printf("\nmat_type:[%s]",MatType);
			printf("\nPlant:[1005]");
			printf("\nuq:[%s]",MeasureUnit);
			printf("\ndescription:[%s]",PartDescriptionDup);
			printf("\ndrg_std_no:[%s]",drg_std_no);
			printf("\ndrg_std_ind:[%s]",drg_std_ind);
			printf("\nsheet_status:[%s]",sheet_status);
			printf("\nSheetNumber:[%s]",SheetNumberDup);
			printf("\nbasic_division:[%s]",basic_division);
			printf("\nPageFormat:[%s]",PageFormat);
			printf("\nprofit_centre:[%s]",profit_centre);
			printf("\nmrp_type:[%s]",mrp_type);
			printf("\nmaterial_group:[%s]",MaterialGroupDup);
			printf("\nDml:[%s]",EEDmlNumber);

			fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
			fprintf(fsuccess,"\nmat_type:[%s]",MatType);
			fprintf(fsuccess,"\nM");
			fprintf(fsuccess,"\nPlant:[1005]");
			fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
			fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
			fprintf(fsuccess,"\ndrg_std_no:[%s]",drg_std_no);
			fprintf(fsuccess,"\ndrg_std_ind:[%s]",drg_std_ind);
			fprintf(fsuccess,"\nsheet_status:[%s]",sheet_status);
			fprintf(fsuccess,"\nSheetNumber:[%s]",SheetNumberDup);
			fprintf(fsuccess,"\nbasic_division:[%s]",basic_division);
			fprintf(fsuccess,"\nPageFormat:[%s]",PageFormat);
			fprintf(fsuccess,"\nprofit_centre:[%s]",profit_centre);
			fprintf(fsuccess,"\nmrp_type:[%s]",mrp_type);
			fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
			fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




			pstat='0';
			pstat_mrp='0';
			pstat_acc='0';


			GetCSPstat(PartNumberDup);
			pstat_basicFun();


			printf("\nPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
			fprintf(fsuccess,"\nPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

			if ((pstat_mrp == 'D')&&(pstat=='K'))
			{
				printf("\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);
				fprintf(fsuccess,"\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);

				if(nlsStrCmp(PartRevisionDup,"NR")!=0)
				{
					flag = 1;
				}
			}
			else
			{
				if(ercDmlflag==1)
				{
					if(pstat!='K')
					{
						printf("ERC dml part [%s] do not have BASIC view hence skipping from material extend to 1005",PartNumberDup);
						return 1;
					}
				}

				if((pstat!='K')&&(pstat_mrp != 'D'))//basic and mrp view not present create all view
				{
					go_for_rfc = 0;

					//int create_mat_all_view()
					//{
						char *json_create_mat_all_view_req_obj = NULL;
						json_create_mat_all_view_req_obj = malloc(234000);
						call_BAPI_create_mat_all_view(PartNumberDup, MaterialGroupDup, MatType, MeasureUnit, PartDescriptionDup, SheetNumberDup, PageFormat, drg_std_ind, drg_std_no, sheet_status, sheet_size, basic_division, proc_type, spl_proc_key, mrp_type, avail_chk, profit_centre, EEDmlNumber, json_create_mat_all_view_req_obj );
						//printf("\nRetuned Str : %s\n", json_create_mat_all_view_req_obj);
						tm_curl_BAPI_create_change_mat ( json_create_mat_all_view_req_obj );
						free(json_create_mat_all_view_req_obj);

					//	return 0;
					//}
					
					if(!nlsIsStrNull(sheet_status))
					{
						BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
					}
					go_for_rfc = 1;
				}
				else if((pstat=='K')&&(pstat_mrp != 'D'))//basic present and mrp view not present extend other view
				{


					printf("\nMaterial Extend");
					printf("\nmat_part:[%s]",PartNumberDup);
					printf("\nmat_type:[%s]",MatType);
					printf("\nPlant:[1005]");
					printf("\nuq:[%s]",MeasureUnit);
					printf("\ndescription:[%s]",PartDescriptionDup);
					printf("\nmaterial_group:[%s]",MaterialGroupDup);
					printf("\nproc_type:[%s]",proc_type);
					printf("\nspl_proc_type:[%s]",spl_proc_key);
					printf("\nDml:[%s]",EEDmlNumber);

					fprintf(fsuccess,"\nMaterial Extend");
					fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
					fprintf(fsuccess,"\nmat_type:[%s]",MatType);
					fprintf(fsuccess,"\nM");
					fprintf(fsuccess,"\nPlant:[1005]");
					fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
					fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
					fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
					fprintf(fsuccess,"\nproc_type:[%s]",proc_type);
					fprintf(fsuccess,"\nspl_proc_type:[%s]",spl_proc_key);
					fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




					pstat='0';
					pstat_mrp='0';
					pstat_acc='0';


					GetCSPstat(PartNumberDup);
					pstat_basicFun();



					printf("\naPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
					fprintf(fsuccess,"\naPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

					if (pstat_mrp == 'D')
					{
						printf("\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);
						fprintf(fsuccess,"\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);


					}
					else
					{


						go_for_rfc = 0;
						
						char *json_extend_mat_view_req_obj = NULL;
						json_extend_mat_view_req_obj = malloc(234000);
						call_BAPI_extend_mat_view ( PartNumberDup, MaterialGroupDup, MatType, MeasureUnit, PartDescriptionDup, proc_type, spl_proc_key, mrp_type, avail_chk, profit_centre, EEDmlNumber, json_extend_mat_view_req_obj );
						//printf("\nRetuned Str : %s\n", json_extend_mat_view_req_obj);
						tm_curl_BAPI_create_change_mat ( json_extend_mat_view_req_obj );
						free(json_extend_mat_view_req_obj);

						if(!nlsIsStrNull(sheet_status))
						{
							BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
						}
						go_for_rfc = 1;
						
						
						
				

					}


				}

			}
		}
		if((flag == 1 ))
		{

			printf("\nMaterial Change");
			printf("\nmat_part:[%s]",PartNumberDup);
			printf("\nmat_type:[%s]",MatType);
			printf("\nPlant:[1005]");
			printf("\nuq:[%s]",MeasureUnit);
			printf("\ndescription:[%s]",PartDescriptionDup);
			printf("\nmaterial_group:[%s]",MaterialGroupDup);
			printf("\nproc_type:[%s]",proc_type);
			printf("\nspl_proc_type:[%s]",spl_proc_key);
			printf("\nDml:[%s]",EEDmlNumber);

			fprintf(fsuccess,"\nMaterial Change");
			fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
			fprintf(fsuccess,"\nmat_type:[%s]",MatType);
			fprintf(fsuccess,"\nM");
			fprintf(fsuccess,"\nPlant:[1005]");
			fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
			fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
			fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
			fprintf(fsuccess,"\nproc_type:[%s]",proc_type);
			fprintf(fsuccess,"\nspl_proc_type:[%s]",spl_proc_key);
			fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




			pstat='0';
			pstat_mrp='0';
			pstat_acc='0';

			GetCSPstat ( PartNumberDup ) ;
			pstat_basicFun ( ) ;


			printf("\nbPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
			fprintf(fsuccess,"\nbPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

			if ( pstat_mrp == 'D' )
			{
				if ( ercDmlflag == 1 )
				{
					if(pstat!='K')
					{
						printf("ERC dml part [%s] do not have BASIC view hence skipping from material extend to 1005",PartNumberDup);
						return 1;
					}
				}

				go_for_rfc = 0;
				
				char *json_change_mat_view_req_obj = NULL;
				json_change_mat_view_req_obj = malloc(234000);
				call_BAPI_change_mat_view ( PartNumberDup, MaterialGroupDup, MatType, MeasureUnit, PartDescriptionDup, proc_type, spl_proc_key, EEDmlNumber, json_change_mat_view_req_obj ) ;
				//printf("\nRetuned Str : %s\n", json_change_mat_view_req_obj);
				tm_curl_BAPI_create_change_mat ( json_change_mat_view_req_obj );
				free(json_change_mat_view_req_obj);


				

				if(!nlsIsStrNull(sheet_status))
				{
					BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
				}
				go_for_rfc = 1;


			}
			else
			{
				printf("\nMessage for Material Create:Material %s need to create in plant 1005\n",PartNumberDup);
				fprintf(fsuccess,"\nMessage for Material Create:Material %s need to create in plant 1005\n",PartNumberDup);
			}

		}

	}
	CLEANUP:
		if(latestDocs)
		{
			objDisposeAll(latestDocs);
		}
		latestDocs = NULL;
		if(latestRelDocs)
		{
			objDisposeAll(latestRelDocs);
		}
		latestRelDocs = NULL;

		if(latestRefDocs)
		{
			objDisposeAll(latestRefDocs);
		}
		latestRefDocs = NULL;
		if(latestRelRefDocs)
		{
			objDisposeAll(latestRelRefDocs);
		}
		latestRelRefDocs = NULL;
		return 0;
}

/*
int DZ_ckd_bapi_mat(ObjectPtr PartOPtr,string MatPartNumber,char EEDmlNumber[11],char shop_store)
{


	char drg_std_ind[4]={0};
	char drg_std_no[15]={0};
	char sheet_status[3]={0};
	char schas_type_no[15];
	char sheet_size[3]={0};
	char acr_ind[3]={0};
	int cs_logic();
	int mat_create();
	char net_wt[18]= {0};
	char gros_wt[18]= {0};
	char volume[18]= {0};
	char basic_division[3]= {0};
	char proc_type[2] = {0};
	char spl_proc_key[3]= {0};

	char mrp_type[3]= {0};

	char plan_calendar[4]= {0};

	char avail_chk[3]= {0};

	char profit_centre[11];

	int go_for_rfc = 0;

	int flag = 0;
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA eBasicView;
	BAPI_MARAX eBasicViewx;
	BAPI_MARC eMrpView;
	BAPI_MARCX eMrpViewx;
	BAPI_MPGD eBapi_Mpgd;
	BAPI_MPGDX eBapi_Mpgdx;
	BAPI_MARD eBapi_Mard;
	BAPI_MARDX eBapi_Mardx;
	BAPI_MBEW eAccView;
	BAPI_MBEWX eAccViewx;
	RMMG1_AENNR eRmmg1_Aennr;
	BAPIRET2 eBapiret2;
	ITAB_H thBapi_Makt = ITAB_NULL;
	ITAB_H thBapi_Marm = ITAB_NULL;
	ITAB_H thBapi_Marmx = ITAB_NULL;
	char xException[256];
	BAPI_MAKT *tBapi_Makt;
	BAPI_MARM *tBapi_Marm;
	BAPI_MARMX *tBapi_Marmx;


	status dstat = OKAY;
	int mfail = OKAY;
	string myzeroDup1 = NULL;
	string myzeroDup2 = NULL;
	string myzeroDup3 = NULL;
	string myzeroDup4 = NULL;


	int result = 0;
	int t = 0;
	string PartNumber = NULL;
	string PartNumberDup = NULL;
	string MaterialGroup = NULL;
	string MaterialGroupDup = NULL;
	string PartDescription = NULL;
	string PartDescriptionDup = NULL;
	string UnitOfMeasure = NULL;
	string UnitOfMeasureDup = NULL;
	string MeasureUnit = NULL;
	string MakeBuyInd = NULL;
	string MakeBuyIndDup = NULL;
	string PartType = NULL;
	string PartTypeDup = NULL;
	string MatType = NULL;
	string DrawingInd = NULL;
	string DrawingIndDup = NULL;
	int noOfDocs = 0;
	int TabSize = 0;
	string DocClass = NULL;
	string DocNumber = NULL;
	string DocNumberDup = NULL;
	string DrawingType = NULL;
	string DrawingTypeDup = NULL;
	string DrawingRevision = NULL;
	string DrawingRevisionDup = NULL;
	string Size = NULL;
	string SizeDup = NULL;
	string SheetNumber = NULL;
	string SheetNumberDup = NULL;
	string PageFormat = NULL;
	string PartRevision = NULL;
	string PartRevisionDup = NULL;
	SetOfObjects docObjs = NULL;
	SetOfObjects docRelObjs = NULL;
	SetOfObjects latestDocs = NULL;
	SetOfObjects latestRelDocs = NULL;
	SetOfObjects docRefObjs = NULL;
	SetOfObjects docRelRefObjs = NULL;
	SetOfObjects latestRefDocs = NULL;
	SetOfObjects latestRelRefDocs = NULL;
	SetOfObjects lRefdocs = NULL;
	ObjectPtr docOPtr = NULL;
	ObjectPtr lRefdocOPtr = NULL;
	ObjectPtr InfoDialogObj = NULL;
	SqlPtr sqlDoc = NULL;
	string sPartClass = NULL;
	string prjcode = NULL;
	string prjcodeDup = NULL;


	myzeroDup1 = nlsStrAlloc(2);
	myzeroDup2 = nlsStrAlloc(7);
	myzeroDup3 = nlsStrAlloc(7);
	myzeroDup4 = nlsStrAlloc(12);
	MeasureUnit = nlsStrAlloc(4);



	nlsStrCpy(myzeroDup1,"0.0");
	nlsStrCpy(myzeroDup2,"0.00");
	nlsStrCpy(myzeroDup3,"0.000");
	nlsStrCpy(myzeroDup4,"0.0000");

	strcpy(proc_type,"");
	strcpy(spl_proc_key,"");



	if(dstat = objGetAttribute(PartOPtr, "PartNumber", &PartNumber)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "Revision", &PartRevision)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "Nomenclature", &PartDescription)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr, "t5UQdup", &UnitOfMeasure)) goto CLEANUP;
	if(dstat = objGetAttribute(PartOPtr,"t5PunMakeBuyIndicator",&MakeBuyInd)) goto CLEANUP;

	if(dstat = objGetClass(PartOPtr,&sPartClass)) goto CLEANUP;
	if(nlsStrCmp(sPartClass,"t5EeAsm")==0)
	{
		if(dstat = objGetAttribute(PartOPtr, "t5EePartType", &PartType)) goto CLEANUP;
		if(dstat = objGetAttribute(PartOPtr, "t5EEMaterialClass", &MaterialGroup)) goto CLEANUP;
		if(!nlsIsStrNull(MaterialGroup))
		{
			MaterialGroupDup = nlsStrDup(MaterialGroup);
		}
	}
	else
	{
		if(dstat = objGetAttribute(PartOPtr, "PartType", &PartType)) goto CLEANUP;
		if(dstat = objGetAttribute(PartOPtr, "ProjectName", &prjcode)) goto CLEANUP;
		if(!nlsIsStrNull(prjcode))
		{
			prjcodeDup = nlsStrDup(prjcode);
		}
		if(nlsStrCmp(prjcodeDup,"1111")==0)
		{
			if(dstat = objGetAttribute(PartOPtr, "t5MatlClass", &MaterialGroup)) goto CLEANUP;
			if(!nlsIsStrNull(MaterialGroup))
			{
				MaterialGroupDup = nlsStrDup(MaterialGroup);
			}
			else
			{
				MaterialGroupDup = nlsStrDup("");
			}
		}
		if(nlsStrCmp(prjcodeDup,"1111")!=0)
		{
			MaterialGroupDup = nlsStrDup("ZZZZZZ");
		}

	}

	if(dstat = objGetAttribute (PartOPtr, "t5DrawingInd", &DrawingInd)) goto CLEANUP;





	if(!nlsIsStrNull(PartNumber))
	{
		PartNumberDup = nlsStrDup(PartNumber);
	}
	if(!nlsIsStrNull(PartRevision))
	{
		PartRevisionDup = nlsStrDup(PartRevision);
	}
	if(!nlsIsStrNull(PartDescription))
	{
		PartDescriptionDup = nlsStrDup(PartDescription);
	}

	if(!nlsIsStrNull(UnitOfMeasure))
	{
		UnitOfMeasureDup = nlsStrDup(UnitOfMeasure);
	}
	else
	{
		printf("\nPart UnitOfMeasure is null");
	}
	if(ercDmlflag == 1)
	{
	MakeBuyInd = nlsStrDup("E");
	MakeBuyIndDup = nlsStrDup("E");
	}
	if(!nlsIsStrNull(MakeBuyInd))
	{
		MakeBuyIndDup = nlsStrDup(MakeBuyInd);
		nlsStrCpy(proc_type,subString(MakeBuyIndDup, 0, 1));
		printf("\nProcurement Type: %s", proc_type);
		fprintf(fsuccess,"\nProcurement Type: %s", proc_type);
		nlsStrCpy(spl_proc_key, subString(MakeBuyIndDup, 1, 2));
		printf("\nSpecial Procurement Key: %s", spl_proc_key);
		fprintf(fsuccess,"\nSpecial Procurement Key: %s", spl_proc_key);

		//09 March 2016
		//Rajendra:6072-Allow material creation for �F18� E1 parts as �F� in SAP-1005

		if((nlsStrCmp(spl_proc_key,"18")==0) && (nlsStrCmp(proc_type,"F")==0))
		{
			nlsStrCpy(spl_proc_key,"");

			printf("\nProcurement Type1: %s", proc_type);
			printf("\nSpecial Procurement Key1: %s\n", spl_proc_key);
		}


	}
	else
	{
		printf("\nPart MakeBuyInd is null");
		fprintf(fsuccess,"\nPart MakeBuyInd is null");
	}
	if(nlsStrCmp(MakeBuyIndDup,"NA")==0)
	{
		printf("\nPart MakeBuyInd is NA hence exit from material create");
		fprintf(fsuccess,"\nPart MakeBuyInd is NA hence exit from material create");
		return 1;
	}

	if(strcmp(proc_type,"")==0)
	{
		printf("\nPart %s MakeBuyInd is NULL hence exit from material create",PartNumberDup);
		fprintf(fsuccess,"\nPart %s MakeBuyInd is NULL hence exit from material create",PartNumberDup);
		return 1;
	}


	if(!nlsIsStrNull(PartType))
	{
		PartTypeDup = nlsStrDup(PartType);
	}
	else
	{
		printf("\nPart t5EEPartType is null");
		printf("\nMessage Material creation [%s] Part t5EEPartType is null",PartNumberDup);
		fprintf(fsuccess,"\nMessage Material creation [%s] Part t5EEPartType is null",PartNumberDup);
		goto CLEANUP;
	}
	printf("PartType:[%s]",PartTypeDup);
	fprintf(fsuccess,"PartType:[%s]",PartTypeDup);
	MatType = nlsStrAlloc(10);
	if (nlsStrCmp(PartTypeDup, "C") == 0)
	{
		nlsStrCpy(MatType,"HALB");
	}
	else if (nlsStrCmp(PartTypeDup, "A") == 0)
	{
		nlsStrCpy(MatType,"HALB");
	}

	printf("\nMatType:[%s]",MatType);
	if (nlsStrCmp(UnitOfMeasureDup,"1") == 0)
	{
		nlsStrCpy(MeasureUnit,"M");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"2") == 0)
	{
		nlsStrCpy(MeasureUnit,"KG");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"3") == 0)
	{
		nlsStrCpy(MeasureUnit,"L");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"4") == 0)
	{
		nlsStrCpy(MeasureUnit,"EA");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"5") == 0)
	{
		nlsStrCpy(MeasureUnit,"M2");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"6") == 0)
	{
		nlsStrCpy(MeasureUnit,"EA");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"7") == 0)
	{
		nlsStrCpy(MeasureUnit,"TD");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"8") == 0)
	{
		nlsStrCpy(MeasureUnit,"M3");
	}
	else if (nlsStrCmp(UnitOfMeasureDup,"9") == 0)
	{
		nlsStrCpy(MeasureUnit,"TS");
	}

	printf("\nMeasureUnit:[%s]",MeasureUnit);
	if(!nlsIsStrNull(DrawingInd))
	{
		DrawingIndDup = nlsStrDup(DrawingInd);
		printf("\nDrawing Indicator: %s", DrawingIndDup);
		fflush(stdout);
		fprintf(fsuccess,"\nDrawing Indicator: %s", DrawingIndDup);
	}
	else
	{
		printf("\nDrawing Indicator is NULL");
		fprintf(fsuccess,"\nDrawing Indicator is NULL");
		fflush(stdout);
	}
	strcpy(basic_division,"01");
	printf("\nbasic_division:[%s]",basic_division);
	fflush(stdout);

	strcpy(mrp_type,"ND");
	printf("\nmrp_type:[%s]",mrp_type);
	fflush(stdout);
	strcpy(avail_chk,"02");
	printf("\navail_chk:[%s]",avail_chk);
	fflush(stdout);
	strcpy(profit_centre,"0001111060");
	printf("\nprofit_centre:[%s]",profit_centre);
	fflush(stdout);





	SheetNumberDup = nlsStrDup("02");
	printf("\nSheetNumberDup:[%s]",SheetNumberDup);
	fflush(stdout);

	PageFormat = nlsStrDup("a4");
	printf("\nPageFormat:[%s]",PageFormat);
	fflush(stdout);
	if((nlsStrCmp(PartTypeDup,"D") != 0))
	{
		printf("\nPart is not dummy hence checking Drawing indicator");
		fflush(stdout);
		if(nlsStrCmp(DrawingIndDup,"D")==0)
		{
			printf("\nDrawing indicator is D for part");
			fflush(stdout);
			if(dstat = ExpandObject2("PartDoc",PartOPtr,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,&mfail)) goto CLEANUP;
			printf("\nsetSize(docObjs):[%d]",setSize(docObjs));
			fflush(stdout);
			if(setSize(docObjs)<=0)
			{

				if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,&mfail)) goto CLEANUP;
				printf("\nsetSize(latestDocs):[%d]",setSize(latestDocs));
				fflush(stdout);
				if (setSize(latestDocs)>0)
				{
					printf("\nIn 'Is Described By' drawing documents loop");
					fprintf(fsuccess,"\nIn 'Is Described By' drawing documents loop");
					fflush(stdout);
					for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
					{
						docOPtr = setGet(latestDocs, noOfDocs);
						DocClass = low_getspace(20);
						if(dstat = objGetClass(docOPtr, &DocClass)) goto CLEANUP;
						if((nlsStrCmp(DocClass,"t5DrwDoc") == 0))
						{
							result = 1;
							printf("\n<Drawing Documents Found!>");
							fprintf(fsuccess,"\n<Drawing Documents Found!>");
							fflush(stdout);

							if(dstat = objGetAttribute (docOPtr, "DocumentName", &DocNumber)) goto CLEANUP;
							DocNumberDup = nlsStrDup(DocNumber);
							nlsStrCpy(drg_std_no,DocNumberDup);
							printf("\nDocument Number: %s", DocNumberDup);
							fprintf(fsuccess,"\nDocument Number: %s", DocNumberDup);
							fflush(stdout);

							if(dstat = objGetAttribute(docOPtr, "t5DrawingType", &DrawingType)) goto CLEANUP;
							if(!nlsIsStrNull(DrawingType))
							{
								DrawingTypeDup = nlsStrDup(DrawingType);
								nlsStrCpy(drg_std_ind,DrawingTypeDup);
								printf("\nDocument Type: %s", DrawingTypeDup);
								fprintf(fsuccess,"\nDocument Type: %s", DrawingTypeDup);
								fflush(stdout);
							}
							else
							{
								printf("\nDocument Type is NULL!");
								fprintf(fsuccess,"\nDocument Type is NULL!");
								fflush(stdout);

							}
							if(dstat = objGetAttribute (docOPtr, "Revision", &DrawingRevision)) goto CLEANUP;
							if(!nlsIsStrNull(DrawingRevision))
							{
								DrawingRevisionDup = nlsStrDup(DrawingRevision);
								nlsStrCpy(sheet_status,DrawingRevisionDup);
								printf("\nDocument Version: %s", DrawingRevisionDup);
								fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								fflush(stdout);
							}
							else
							{
								DrawingRevisionDup = nlsStrDup("NR");
								nlsStrCpy(sheet_status,DrawingRevisionDup);
								printf("\nDocument Version: %s", DrawingRevisionDup);
								fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								fflush(stdout);

							}

							if(dstat = objGetAttribute (docOPtr, "t5SheetSize", &Size)) goto CLEANUP;
							if(!nlsIsStrNull(Size))
							{
								SizeDup = nlsStrDup(Size);
								printf("\nSheet Size: %s", SizeDup);
								fprintf(fsuccess,"\nSheet Size: %s", SizeDup);
								fflush(stdout);
							}
							else
							{
								printf("\nSheet Size is NULL!");
								fprintf(fsuccess,"\nSheet Size is NULL!");
								fflush(stdout);

							}

							TabSize=0;
							if(dstat = objGetTableSize(docOPtr,"t5SheetDetails",&TabSize)) goto CLEANUP;
							printf("\nGetlRefTableSize:[%d]",TabSize);fflush(stdout);
							fflush(stdout);

							if(TabSize==0)
							{
								SheetNumberDup = nlsStrDup("1");
							}

							for(t=0;t<TabSize;t++)
							{
								SheetNumber = NULL;
								SheetNumberDup = NULL;
								if(dstat = GetInfoItem(docOPtr,&InfoDialogObj,&mfail)) goto CLEANUP;
								if(dstat = objGetTableAttribute(InfoDialogObj,"t5SheetDetails",t,"t5SheetNo",&SheetNumber)) goto CLEANUP;
								if(!nlsIsStrNull(SheetNumber))
								{
									SheetNumberDup = nlsStrDup(SheetNumber);
								}
							}
						}
					}
					if (result == 0)
					{
						printf("\n<No 'IsDescribedBy' Drawing Documents found for Part %s %d>\n", PartNumberDup,setSize(latestRefDocs));
						fprintf(fsuccess,"\n<No 'IsDescribedBy' Drawing Documents found for Part %s %d>\n", PartNumberDup,setSize(latestRefDocs));
						fflush(stdout);
					}
				}
			}
			else
			{
				printf("\nNo drawing doc attached");
				fprintf(fsuccess,"\nNo drawing doc attached");
				fflush(stdout);
			}

			printf("\nGoing for ref drg doc");
			fflush(stdout);
			if(dstat = ExpandObject2("InfoDwg",PartOPtr,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docRefObjs,&docRelRefObjs,&mfail)) goto CLEANUP;
			if(setSize(docRefObjs)<=0)
			{


				if(dstat = t5GetLatestDocumnets(docRefObjs,docRelRefObjs,&latestRefDocs,&latestRelRefDocs,&mfail)) goto CLEANUP;

				if (setSize(latestRefDocs)>0)
				{
					printf("\nIn 'Is Referenced By' drawing documents loop");
					fprintf(fsuccess,"\nIn 'Is Referenced By' drawing documents loop");
					for(noOfDocs = 0; noOfDocs<setSize(latestRefDocs); noOfDocs++)
					{
						docOPtr = setGet(latestRefDocs, noOfDocs);
						DocClass = low_getspace(20);

						if(dstat = objGetClass(docOPtr, &DocClass)) goto CLEANUP;
						if((nlsStrCmp(DocClass,"t5DrwDoc") == 0))
						{
							result = 2;
							printf("\n<Drawing Documents Found!>");
							fprintf(fsuccess,"\n<Drawing Documents Found!>");

							if(dstat = objGetAttribute (docOPtr, "DocumentName", &DocNumber)) goto CLEANUP;
								DocNumberDup = nlsStrDup(DocNumber);
							nlsStrCpy(drg_std_no,DocNumberDup);
							printf("\nDocument Number: %s", DocNumberDup);
							fprintf(fsuccess,"\nDocument Number: %s", DocNumberDup);

							if
							(
								(dstat = oiSqlCreateSelect(&sqlDoc)) ||
								(dstat = oiSqlWhereBegParen(sqlDoc)) ||
								(dstat = oiSqlWhereEQ(sqlDoc,"DocumentName",DocNumberDup)) ||
								(dstat = oiSqlWhereAND(sqlDoc))||
								(dstat = oiSqlWhereEQ(sqlDoc,"Superseded","-")) ||
								(dstat = oiSqlWhereEndParen(sqlDoc)) ||
								(dstat = QueryWhere("t5DrwDoc",sqlDoc,&lRefdocs,&mfail))
							)
							goto CLEANUP;

							if(setSize(lRefdocs)> 0)
							{
								lRefdocOPtr = setGet(lRefdocs,0);

								if(dstat = objGetAttribute (lRefdocOPtr, "t5DrawingType", &DrawingType)) goto CLEANUP;
								if(!nlsIsStrNull(DrawingType))
								{
									DrawingTypeDup = nlsStrDup(DrawingType);
									nlsStrCpy(drg_std_ind,DrawingTypeDup);
									printf("\nDocument Type: %s", DrawingTypeDup);
									fprintf(fsuccess,"\nDocument Type: %s", DrawingTypeDup);
								}
								else
								{
									printf("\nDocument Type is NULL!");
									fprintf(fsuccess,"\nDocument Type is NULL!");
								 }


								if(dstat = objGetAttribute (lRefdocOPtr, "Revision", &DrawingRevision)) goto CLEANUP;
								if(!nlsIsStrNull(DrawingRevision))
								{
									DrawingRevisionDup = nlsStrDup(DrawingRevision);
									nlsStrCpy(sheet_status,DrawingRevisionDup);
									printf("\nDocument Version: %s", DrawingRevisionDup);
									fprintf(fsuccess,"\nDocument Version: %s", DrawingRevisionDup);
								}
								else
								{
									printf("\nDocument Version is NULL!");
									fprintf(fsuccess,"\nDocument Version is NULL!");
								}


								printf("\nbefore getting the details of ref drawing");
								fprintf(fsuccess,"\nbefore getting the details of ref drawing");
								TabSize=0;

								if(dstat = objGetTableSize(lRefdocOPtr,"t5SheetDetails",&TabSize)) goto CLEANUP;
								printf("\nGetlRefTableSize:[%d]",TabSize);fflush(stdout);

								SizeDup=NULL;
								if(TabSize==0)
								{
									SizeDup = nlsStrDup("1");
									fprintf(fsuccess,"\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
								}
								for(t=0;t<TabSize;t++)
								{
									if(!nlsIsStrNull(Size))
									{
										nlsStrFree(Size);
										Size = NULL;
									}
									if(!nlsIsStrNull(SizeDup))
									{
										nlsStrFree(SizeDup);
										SizeDup = NULL;
									}

									if(dstat = GetInfoItem(docOPtr,&InfoDialogObj,&mfail)) goto CLEANUP;
									if(dstat = objGetTableAttribute(InfoDialogObj,"t5SheetDetails",t,"t5SheetNo",&Size)) goto CLEANUP;
									if(!nlsIsStrNull(Size))
									{
										SizeDup = nlsStrDup(Size);
									}
									else
									{
										SizeDup = nlsStrDup("zero");
									}
								}
								printf("\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
								fprintf(fsuccess,"\nNumber of Sheets refer:%s\t%s",SizeDup,PartNumberDup);
							}
						}
					}

					if (result == 0)
					{
						printf("\n<No 'IsReferencedBy' Drawing Documents found for Part %s>\n", PartNumberDup);
						fprintf(fsuccess,"\n<No 'IsReferencedBy' Drawing Documents found for Part %s>\n", PartNumberDup);
					}
				}
				else
				{
					printf("\n<No Documents found for Part %s>", PartNumberDup);
					fprintf(fsuccess,"\n<No Documents found for Part %s>", PartNumberDup);
				}
			}
			else
			{
				printf("\nNo ref drawing doc attached hence return");
				fprintf(fsuccess,"\nNo ref drawing doc attached hence return");
			}
		}
		else
		{
			printf("Getting NR revision here");
			fprintf(fsuccess,"Getting NR revision here");
			DrawingRevisionDup = nlsStrDup("");
			nlsStrCpy(sheet_status,"");
			SizeDup = nlsStrDup("");
			SheetNumberDup = nlsStrDup("");
			PageFormat = nlsStrDup("");
			nlsStrCpy(drg_std_no,"DRG NOT REQUIRED");

		}
	}

	pstat='0';
	pstat_mrp='0';
	pstat_acc='0';


	GetCSPstat ( PartNumberDup ) ;
	pstat_basicFun ( ) ;


	if((strcmp(acr_ind,"D") != 0))
	{


		if(flag == 0 )
		{

			printf("\nmat_part:[%s]",PartNumberDup);
			printf("\nmat_type:[%s]",MatType);
			printf("\nPlant:[1005]");
			printf("\nuq:[%s]",MeasureUnit);
			printf("\ndescription:[%s]",PartDescriptionDup);
			printf("\ndrg_std_no:[%s]",drg_std_no);
			printf("\ndrg_std_ind:[%s]",drg_std_ind);
			printf("\nsheet_status:[%s]",sheet_status);
			printf("\nSheetNumber:[%s]",SheetNumberDup);
			printf("\nbasic_division:[%s]",basic_division);
			printf("\nPageFormat:[%s]",PageFormat);
			printf("\nprofit_centre:[%s]",profit_centre);
			printf("\nmrp_type:[%s]",mrp_type);
			printf("\nmaterial_group:[%s]",MaterialGroupDup);
			printf("\nDml:[%s]",EEDmlNumber);

			fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
			fprintf(fsuccess,"\nmat_type:[%s]",MatType);
			fprintf(fsuccess,"\nM");
			fprintf(fsuccess,"\nPlant:[1005]");
			fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
			fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
			fprintf(fsuccess,"\ndrg_std_no:[%s]",drg_std_no);
			fprintf(fsuccess,"\ndrg_std_ind:[%s]",drg_std_ind);
			fprintf(fsuccess,"\nsheet_status:[%s]",sheet_status);
			fprintf(fsuccess,"\nSheetNumber:[%s]",SheetNumberDup);
			fprintf(fsuccess,"\nbasic_division:[%s]",basic_division);
			fprintf(fsuccess,"\nPageFormat:[%s]",PageFormat);
			fprintf(fsuccess,"\nprofit_centre:[%s]",profit_centre);
			fprintf(fsuccess,"\nmrp_type:[%s]",mrp_type);
			fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
			fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




			pstat='0';
			pstat_mrp='0';
			pstat_acc='0';


			GetCSPstat(PartNumberDup);
			pstat_basicFun();


			printf("\nPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
			fprintf(fsuccess,"\nPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

			if ((pstat_mrp == 'D')&&(pstat=='K'))
			{
				printf("\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);
				fprintf(fsuccess,"\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);

				if(nlsStrCmp(PartRevisionDup,"NR")!=0)
				{
					flag = 1;
				}
			}
			else
			{
				if(ercDmlflag==1)
				{
					if(pstat!='K')
					{
						printf("ERC dml part [%s] do not have BASIC view hence skipping from material extend to 1005",PartNumberDup);
						return 1;
					}
				}

				if((pstat!='K')&&(pstat_mrp != 'D'))//basic and mrp view not present create all view
				{
					go_for_rfc = 0;
					hRfc = BapiLogon();

					thBapi_Makt = ITAB_NULL;
					thBapi_Marm = ITAB_NULL;
					thBapi_Marmx = ITAB_NULL;


					if (thBapi_Makt==ITAB_NULL)
					{
						thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
						if (thBapi_Makt==ITAB_NULL)
							printf("\nItCreate MATERIALDESCRIPTION");
					}
					else
					{
						if (ItFree(thBapi_Makt) != 0)
							printf("\nItFree MATERIALDESCRIPTION");
					}

					if (thBapi_Marm==ITAB_NULL)
					{
						 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
						 if (thBapi_Marm==ITAB_NULL)
							printf("\nItCreate UNITSOFMEASURE");
					}
					else
					{
						if (ItFree(thBapi_Marm)!= 0)
							printf("\nItFree UNITSOFMEASURE");
					}

					if (thBapi_Marmx==ITAB_NULL)
					{
						 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
						if (thBapi_Marmx==ITAB_NULL)
							printf("\nItCreate UNITSOFMEASUREX");
					}
					else
					{
						if (ItFree(thBapi_Marmx)!= 0)
							printf("\nItFree UNITSOFMEASUREX");
					}

					tBapi_Makt = ItAppLine (thBapi_Makt) ;
					tBapi_Marm  = ItAppLine (thBapi_Marm) ;
					tBapi_Marmx = ItAppLine (thBapi_Marmx) ;

					if (tBapi_Makt == NULL)
						printf("\nItAppLine BAPI_MAKT");
					if (tBapi_Marm == NULL)
						printf("\nItAppLine BAPI_MARM second table");
					if (tBapi_Marmx == NULL)
						printf("\nItAppLine BAPI_MARMX");




					SETCHAR(eBapiMatHead.Material,PartNumberDup);
					SETCHAR(eBapiMatHead.Matl_Type,MatType);
					SETCHAR(eBapiMatHead.Ind_Sector,"M");
					SETCHAR(eBapiMatHead.Basic_View,"X");
					SETCHAR(eBasicView.Base_Uom,MeasureUnit);
					SETCHAR(eBasicView.Base_Uom_Iso,MeasureUnit);
					SETCHAR(eBasicViewx.Base_Uom,"X");
					SETCHAR(eBasicViewx.Base_Uom_Iso,"X");

					SETCHAR(tBapi_Marm->Alt_Unit,MeasureUnit);
					SETCHAR(tBapi_Marm->Alt_Unit_Iso,MeasureUnit);
					SETCHAR(tBapi_Marmx->Alt_Unit,MeasureUnit);
					SETCHAR(tBapi_Marmx->Alt_Unit_Iso,MeasureUnit);
					SETCHAR(tBapi_Makt->Matl_Desc,PartDescriptionDup);

					SETCHAR(eBasicView.Document,drg_std_no);



					if(strcmp(drg_std_no,"")!=0)
					{
						SETCHAR(eBasicViewx.Document,"X");
					}
					else
					{
						SETCHAR(eBasicViewx.Document,"");
					}
					SETCHAR(eBasicView.Doc_Type,drg_std_ind);
					if(strcmp(drg_std_ind,"")!=0)
					{
						SETCHAR(eBasicViewx.Doc_Type,"X");
					}
					else
					{
						SETCHAR(eBasicViewx.Doc_Type,"");
					}

					SETCHAR(eBasicView.Doc_Vers,sheet_status);
					if(strcmp(sheet_status,"")!=0)
					{

						SETCHAR(eBasicViewx.Doc_Vers,"X");
					}
					else
					{
						SETCHAR(eBasicViewx.Doc_Vers,"");
					}
					SETNUM(eBasicView.No_Sheets,SheetNumberDup);
					SETCHAR(eBasicViewx.No_Sheets,"X");

					SETCHAR(eBasicView.Doc_Format,PageFormat);
					SETCHAR(eBasicViewx.Doc_Format,"X");


					SETCHAR(eBasicView.Pageformat,"");
					SETCHAR(eBasicViewx.Pageformat,"");

					SETCHAR(eBasicView.Old_Mat_No,schas_type_no);
					SETCHAR(eBasicViewx.Old_Mat_No,"");

					SETBCD(eBasicView.Net_Weight,net_wt,3);
					SETCHAR(eBasicViewx.Net_Weight,"");
					SETBCD(tBapi_Marm->Gross_Wt,gros_wt,3);
					SETCHAR(tBapi_Marmx->Gross_Wt,"");
					SETCHAR(eBasicView.Unit_Of_Wt,"");
					SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
					SETCHAR(eBasicViewx.Unit_Of_Wt,"");
					SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
					SETCHAR(tBapi_Marm->Unit_Of_Wt,"");
					SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,"");
					SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
					SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");
					SETBCD(tBapi_Marm->Volume,volume,3);
					SETCHAR(tBapi_Marm->VolumeUnit,"");
					SETCHAR(tBapi_Marm->VolumeUnit_Iso,"");
					SETCHAR(tBapi_Marmx->Volume,"");
					SETCHAR(tBapi_Marmx->VolumeUnit,"");
					SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");

					SETCHAR(eBasicView.Size_Dim,sheet_size);
					SETCHAR(eBasicViewx.Size_Dim,"X");

					if(!nlsIsStrNull(MaterialGroupDup))
					{
						SETCHAR(eBasicView.Matl_Group,MaterialGroupDup);
						SETCHAR(eBasicViewx.Matl_Group,"X");
					}
					else
					{
						SETCHAR(eBasicView.Matl_Group,"");
						SETCHAR(eBasicViewx.Matl_Group,"");
					}

					SETCHAR(eBasicView.Division,basic_division);
					SETCHAR(eBasicViewx.Division,"X");
					SETCHAR(eBasicView.Item_Cat,"NORM");
					SETCHAR(eBasicViewx.Item_Cat,"X");
					SETCHAR(eBapiMatHead.Mrp_View,"X");
					SETCHAR(eBapiMatHead.Purchase_View,"X");
					SETCHAR(eMrpView.Mrp_Group,"");
					SETCHAR(eMrpViewx.Mrp_Group,"");
					SETCHAR(eMrpView.Abc_Id,"");
					SETCHAR(eMrpViewx.Abc_Id,"");
					SETCHAR(eMrpView.Pur_Status,"");
					SETCHAR(eMrpViewx.Pur_Status,"");
					SETCHAR(eMrpView.Mrp_Type,mrp_type);
					SETCHAR(eMrpViewx.Mrp_Type,"X");
					SETBCD(eMrpView.Reorder_Pt,"",3);
					SETCHAR(eMrpViewx.Reorder_Pt,"");
					SETCHAR(eMrpView.Quotausage,"");
					SETCHAR(eMrpViewx.Quotausage,"");
					SETCHAR(eMrpView.Mrp_Ctrler,"");
					SETCHAR(eMrpViewx.Mrp_Ctrler,"");
					SETCHAR(eMrpView.Lotsizekey,"");
					SETCHAR(eMrpViewx.Lotsizekey,"");
					SETBCD(eMrpView.Fixed_Lot,"",3);
					SETCHAR(eMrpViewx.Fixed_Lot,"");
					SETBCD(eMrpView.Max_Stock,"",3);
					SETCHAR(eMrpViewx.Max_Stock,"");
					SETCHAR(eMrpView.Proc_Type,proc_type);
					SETCHAR(eMrpViewx.Proc_Type,"X");
					SETCHAR(eMrpView.Spproctype,spl_proc_key);
					SETCHAR(eMrpViewx.Spproctype,"X");
					SETCHAR(eMrpView.Bulk_Mat,"");
					SETCHAR(eMrpViewx.Bulk_Mat,"");
					SETCHAR(eMrpView.Sm_Key,"");
					SETCHAR(eMrpViewx.Sm_Key,"");
					SETCHAR(eMrpView.Ppc_Pl_Cal,plan_calendar);
					SETCHAR(eMrpViewx.Ppc_Pl_Cal,"");
					SETCHAR(eMrpView.Grp_Reqmts,"");
					SETCHAR(eMrpViewx.Grp_Reqmts,"");
					SETCHAR(eMrpView.Period_Ind,"");
					SETCHAR(eMrpViewx.Period_Ind,"");
					SETCHAR(eMrpView.Mixed_Mrp,"");
					SETCHAR(eMrpViewx.Mixed_Mrp,"");
					SETCHAR(eMrpView.Availcheck,avail_chk);
					SETCHAR(eMrpViewx.Availcheck,"X");
					SETCHAR(eBapi_Mpgd.Plng_Matl,"");
					SETCHAR(eBapi_Mpgdx.Plng_Matl,"");
					SETCHAR(eBapi_Mpgd.Plng_Plant,"");
					SETCHAR(eBapi_Mpgdx.Plng_Plant,"");
					SETCHAR(eBapi_Mpgd.Convfactor,"");
					SETCHAR(eBapi_Mpgdx.Convfactor,"");
					SETCHAR(eMrpView.Alternative_Bom,"");
					SETCHAR(eMrpViewx.Alternative_Bom,"");
					SETCHAR(eMrpView.Dep_Req_Id,"");

					SETCHAR(eMrpViewx.Dep_Req_Id,"");
					SETCHAR(eMrpView.Rep_Manuf,"");
					SETCHAR(eMrpViewx.Rep_Manuf,"");
					SETCHAR(eMrpView.Repmanprof,"");
					SETCHAR(eMrpViewx.Repmanprof,"");
					SETCHAR(eMrpView.Determ_Grp,"");
					SETCHAR(eMrpViewx.Determ_Grp,"");
					SETCHAR(eBapiMatHead.Storage_View,"");
					SETCHAR(eMrpView.Issue_Unit,"");
					SETCHAR(eMrpView.Issue_Unit_Iso,"");
					SETCHAR(eMrpViewx.Issue_Unit,"");
					SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
					SETCHAR(eMrpView.Profit_Ctr,profit_centre);
					SETCHAR(eMrpViewx.Profit_Ctr,"X");
					if(strcmp(MatType,"FERT") != 0)
					{
						SETCHAR(eBapiMatHead.Quality_View,"");
						SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
						SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
						SETCHAR(eMrpView.Doc_Reqd,"");
						SETCHAR(eMrpViewx.Doc_Reqd,"");
						SETBCD(eMrpView.Gr_Pr_Time,"",0);
						SETCHAR(eMrpViewx.Gr_Pr_Time,"");
						SETCHAR(eBasicView.Catprofile,"");
						SETCHAR(eBasicViewx.Catprofile,"");
						SETCHAR(eBasicView.Qm_Procmnt,"");
						SETCHAR(eBasicViewx.Qm_Procmnt,"");
						SETCHAR(eMrpView.Ctrl_Key,"");
						SETCHAR(eMrpViewx.Ctrl_Key,"");
						SETCHAR(eMrpView.Cert_Type,"");
						SETCHAR(eMrpViewx.Cert_Type,"");
					}
					else
					{
						SETCHAR(eBapiMatHead.Quality_View,"");
						SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
						SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
						SETCHAR(eMrpView.Doc_Reqd,"");
						SETCHAR(eMrpViewx.Doc_Reqd,"");
						SETBCD(eMrpView.Gr_Pr_Time,"",0);
						SETCHAR(eMrpViewx.Gr_Pr_Time,"");
						SETCHAR(eBasicView.Catprofile,"");
						SETCHAR(eBasicViewx.Catprofile,"");
						SETCHAR(eBasicView.Qm_Procmnt,"");
						SETCHAR(eBasicViewx.Qm_Procmnt,"");
						SETCHAR(eMrpView.Ctrl_Key,"");
						SETCHAR(eMrpViewx.Ctrl_Key,"");
						SETCHAR(eMrpView.Cert_Type,"");
						SETCHAR(eMrpViewx.Cert_Type,"");
					}

					SETCHAR(eBapiMatHead.Account_View,"");
					SETCHAR(eAccView.Val_Cat,"");
					SETCHAR(eAccViewx.Val_Cat,"");
					SETCHAR(eAccView.Val_Class,"");
					SETCHAR(eAccViewx.Val_Class,"");
					SETCHAR(eAccView.Price_Ctrl,"");
					SETCHAR(eAccViewx.Price_Ctrl,"");
					SETBCD(eAccView.Std_Price,"",4);
					SETCHAR(eAccViewx.Std_Price,"");
					SETBCD(eAccView.Moving_Pr,"",4);
					SETCHAR(eAccViewx.Moving_Pr,"");
					SETCHAR(eBapiMatHead.Cost_View,"");
					SETCHAR(eAccView.Mat_Origin,"");
					SETCHAR(eAccViewx.Mat_Origin,"");
					SETCHAR(eAccView.Orig_Group,"");
					SETCHAR(eAccViewx.Orig_Group,"");
					SETBCD(eMrpView.Lot_Size,"",3);
					SETCHAR(eMrpViewx.Lot_Size,"");
					SETCHAR(eAccView.Overhead_Grp,"");
					SETCHAR(eAccViewx.Overhead_Grp,"");
					SETCHAR(eMrpView.Variance_Key,"");
					SETCHAR(eMrpViewx.Variance_Key,"");
					SETCHAR(eAccView.Qty_Struct,"");
					SETCHAR(eAccViewx.Qty_Struct,"");
					SETCHAR(eMrpView.Split_Ind,"");
					SETCHAR(eMrpViewx.Split_Ind,"");

					SETCHAR(eRmmg1_Aennr.Aennr,EEDmlNumber);

					SETCHAR(eBapiMatHead.Sales_View,"");
					SETCHAR(eBapiMatHead.Forecast_View,"");
					SETCHAR(eBapiMatHead.Work_Sched_View,"");
					SETCHAR(eBapiMatHead.Prt_View,"");
					SETCHAR(eBapiMatHead.Warehouse_View,"");

					SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
					SETCHAR(eBapiMatHead.Material_External,"");
					SETCHAR(eBapiMatHead.MateriaL_Guid,"");
					SETCHAR(eBapiMatHead.Material_Version,"");
					SETCHAR(eBasicView.Del_Flag,"");
					SETCHAR(eBasicView.Po_Unit,"");
					SETCHAR(eBasicView.Po_Unit_Iso,"");

					SETCHAR(eBasicView.Doc_Chg_No,"");
					SETCHAR(eBasicView.Page_No,"");

					SETCHAR(eBasicView.Prod_Memo,"");
					SETCHAR(eBasicView.Basic_Matl,"");
					SETCHAR(eBasicView.Std_Descr,"");
					SETCHAR(eBasicView.Dsn_Office,"");
					SETCHAR(eBasicView.Pur_Valkey,"");
					SETCHAR(eBasicView.Container,"");
					SETCHAR(eBasicView.Stor_Conds,"");
					SETCHAR(eBasicView.Temp_Conds,"");
					SETCHAR(eBasicView.Trans_Grp,"");
					SETCHAR(eBasicView.Haz_Mat_No,"");

					SETCHAR(eBasicView.Competitor,"");

					SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);

					SETCHAR(eBasicView.Proc_Rule,"");
					SETCHAR(eBasicView.Sup_Source,"");
					SETCHAR(eBasicView.Season,"");
					SETCHAR(eBasicView.Label_Type,"");
					SETCHAR(eBasicView.Label_Form,"");
					SETCHAR(eBasicView.Prod_Hier,"");

					SETCHAR(eBasicView.Cad_Id,"");

					SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
					SETCHAR(eBasicView.Pack_Wt_Un,"");
					SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
					SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
					SETCHAR(eBasicView.Pack_Vo_Un,"");
					SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
					SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
					SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
					SETCHAR(eBasicView.Var_Ord_Un,"");
					SETCHAR(eBasicView.Batch_Mgmt,"");
					SETCHAR(eBasicView.Sh_Mat_Typ,"");
					SETBCD(eBasicView.Fill_Level,"0",0);
					SETINT2(&eBasicView.Stack_Fact,"0");
					SETCHAR(eBasicView.Mat_Grp_Sm,"");
					SETCHAR(eBasicView.Authoritygroup,"");
					SETBCD(eBasicView.Minremlife,"0",0);
					SETBCD(eBasicView.Shelf_Life,"0",0);
					SETBCD(eBasicView.Stor_Pct,"0",0);
					SETCHAR(eBasicView.Pur_Status,"");
					SETCHAR(eBasicView.Sal_Status,"");
					SETDATE(eBasicView.Pvalidfrom,"");
					SETDATE(eBasicView.Svalidfrom,"");
					SETCHAR(eBasicView.Envt_Rlvt,"");
					SETCHAR(eBasicView.Prod_Alloc,"");
					SETCHAR(eBasicView.Qual_Dik,"");
					SETCHAR(eBasicView.Manu_Mat,"");
					SETCHAR(eBasicView.Mfr_No,"");
					SETCHAR(eBasicView.Inv_Mat_No,"");
					SETCHAR(eBasicView.Manuf_Prof,"");
					SETCHAR(eBasicView.Hazmatprof,"");
					SETCHAR(eBasicView.High_Visc,"");
					SETCHAR(eBasicView.Looseorliq,"");
					SETCHAR(eBasicView.Closed_Box,"");
					SETCHAR(eBasicView.Appd_B_Rec,"");
					SETNUM(eBasicView.Matcmpllvl,"00");
					SETCHAR(eBasicView.Par_Eff,"");
					SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
					SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
					SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
					SETCHAR(eBasicView.Haz_Mat_No_External,"");
					SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
					SETCHAR(eBasicView.Haz_Mat_No_Version,"");
					SETCHAR(eBasicView.Inv_Mat_No_External,"");
					SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
					SETCHAR(eBasicView.Inv_Mat_No_Version,"");
					SETCHAR(eBasicView.Material_Fixed,"");
					SETCHAR(eBasicView.Cm_Relevance_Flag,"");
					SETCHAR(eBasicView.Sled_Bbd,"");
					SETCHAR(eBasicView.Gtin_Variant,"");
					SETCHAR(eBasicView.Serialization_Level,"");
					SETCHAR(eBasicView.Pl_Ref_Mat,"");
					SETCHAR(eBasicView.Extmatlgrp,"");
					SETCHAR(eBasicView.Uomusage,"");
					SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
					SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
					SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
					SETCHAR(eBasicViewx.Del_Flag,"");
					SETCHAR(eBasicViewx.Po_Unit,"");
					SETCHAR(eBasicViewx.Po_Unit_Iso,"");

					SETCHAR(eBasicViewx.Doc_Chg_No,"");
					SETCHAR(eBasicViewx.Page_No,"");
					SETCHAR(eBasicViewx.Prod_Memo,"");

					SETCHAR(eBasicViewx.Basic_Matl,"");
					SETCHAR(eBasicViewx.Std_Descr,"");
					SETCHAR(eBasicViewx.Dsn_Office,"");
					SETCHAR(eBasicViewx.Pur_Valkey,"");
					SETCHAR(eBasicViewx.Container,"");
					SETCHAR(eBasicViewx.Stor_Conds,"");
					SETCHAR(eBasicViewx.Temp_Conds,"");
					SETCHAR(eBasicViewx.Trans_Grp,"");
					SETCHAR(eBasicViewx.Haz_Mat_No,"");
					SETCHAR(eBasicViewx.Competitor,"");
					SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
					SETCHAR(eBasicViewx.Proc_Rule,"");
					SETCHAR(eBasicViewx.Sup_Source,"");
					SETCHAR(eBasicViewx.Season,"");
					SETCHAR(eBasicViewx.Label_Type,"");
					SETCHAR(eBasicViewx.Label_Form,"");
					SETCHAR(eBasicViewx.Prod_Hier,"");
					SETCHAR(eBasicViewx.Cad_Id,"");
					SETCHAR(eBasicViewx.Allowed_Wt,"");
					SETCHAR(eBasicViewx.Pack_Wt_Un,"");
					SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
					SETCHAR(eBasicViewx.Allwd_Vol,"");
					SETCHAR(eBasicViewx.Pack_Vo_Un,"");
					SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
					SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
					SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
					SETCHAR(eBasicViewx.Var_Ord_Un,"");
					SETCHAR(eBasicViewx.Batch_Mgmt,"");
					SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
					SETCHAR(eBasicViewx.Fill_Level,"");
					SETCHAR(eBasicViewx.Stack_Fact,"");
					SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
					SETCHAR(eBasicViewx.Authoritygroup,"");
					SETCHAR(eBasicViewx.Minremlife,"");
					SETCHAR(eBasicViewx.Shelf_Life,"");
					SETCHAR(eBasicViewx.Stor_Pct,"");
					SETCHAR(eBasicViewx.Pur_Status,"");
					SETCHAR(eBasicViewx.Sal_Status,"");
					SETCHAR(eBasicViewx.Pvalidfrom,"");
					SETCHAR(eBasicViewx.Svalidfrom,"");
					SETCHAR(eBasicViewx.Envt_Rlvt,"");
					SETCHAR(eBasicViewx.Prod_Alloc,"");
					SETCHAR(eBasicViewx.Qual_Dik,"");
					SETCHAR(eBasicViewx.Manu_Mat,"");
					SETCHAR(eBasicViewx.Mfr_No,"");
					SETCHAR(eBasicViewx.Inv_Mat_No,"");
					SETCHAR(eBasicViewx.Manuf_Prof,"");
					SETCHAR(eBasicViewx.Hazmatprof,"");
					SETCHAR(eBasicViewx.High_Visc,"");
					SETCHAR(eBasicViewx.Looseorliq,"");
					SETCHAR(eBasicViewx.Closed_Box,"");
					SETCHAR(eBasicViewx.Appd_B_Rec,"");
					SETCHAR(eBasicViewx.Matcmpllvl,"");
					SETCHAR(eBasicViewx.Par_Eff,"");
					SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
					SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
					SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
					SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
					SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
					SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
					SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
					SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
					SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
					SETCHAR(eBasicViewx.Material_Fixed,"");
					SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
					SETCHAR(eBasicViewx.Sled_Bbd,"");
					SETCHAR(eBasicViewx.Gtin_Variant,"");
					SETCHAR(eBasicViewx.Serialization_Level,"");
					SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
					SETCHAR(eBasicViewx.Extmatlgrp,"");
					SETCHAR(eBasicViewx.Uomusage,"");
					SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
					SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
					SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
					SETCHAR(eMrpView.Plant,"1005");
					SETCHAR(eMrpView.Del_Flag,"");
					SETCHAR(eMrpView.Crit_Part,"");
					SETCHAR(eMrpView.Pur_Group,"");
					SETCHAR(eMrpView.Mrpprofile,"");
					SETCHAR(eMrpView.Plnd_Delry,"0");
					SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
					SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
					SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
					SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
					SETBCD(eMrpView.Round_Val,myzeroDup3,3);
					SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
					SETCHAR(eMrpView.Stor_Costs,"");
					SETCHAR(eMrpView.Alt_Bom_Id,"");
					SETCHAR(eMrpView.Discontinu,"");
					SETCHAR(eMrpView.Eff_O_Day,"");
					SETCHAR(eMrpView.Follow_Up,"");
					SETCHAR(eMrpView.Backflush,"");
					SETCHAR(eMrpView.Production_Scheduler,"");
					SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
					SETBCD(eMrpView.Setuptime,myzeroDup2,2);
					SETBCD(eMrpView.Interop,myzeroDup2,2);
					SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
					SETBCD(eMrpView.Inhseprodt,"0",0);
					SETBCD(eMrpView.Stgeperiod,"0",0);
					SETCHAR(eMrpView.Stge_Pd_Un,"");
					SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
					SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
					SETCHAR(eMrpView.Unlimited,"");
					SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
					SETBCD(eMrpView.Replentime,"0",0);
					SETCHAR(eMrpView.Replace_Pt,"");
					SETCHAR(eMrpView.Loadinggrp,"");
					SETCHAR(eMrpView.Batch_Mgmt,"");
					SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
					SETCHAR(eMrpView.Fy_Variant,"");
					SETCHAR(eMrpView.Corr_Fact,"");
					SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
					SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
					SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
					SETCHAR(eMrpView.Sup_Source,"");
					SETCHAR(eMrpView.Auto_P_Ord,"");
					SETCHAR(eMrpView.Sourcelist,"");
					SETCHAR(eMrpView.Comm_Code,"");
					SETCHAR(eMrpView.Countryori,"");
					SETCHAR(eMrpView.Countryori_Iso,"");
					SETCHAR(eMrpView.Regionorig,"");
					SETCHAR(eMrpView.Comm_Co_Un,"");
					SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
					SETCHAR(eMrpView.Expimpgrp,"");
					SETNUM(eMrpView.Pl_Ti_Fnce,"000");
					SETCHAR(eMrpView.Consummode,"");
					SETNUM(eMrpView.Bwd_Cons,"000");
					SETNUM(eMrpView.Fwd_Cons,"000");
					SETCHAR(eMrpView.Bom_Usage,"");
					SETCHAR(eMrpView.Planlistgrp,"");
					SETCHAR(eMrpView.Planlistcnt,"");
					SETCHAR(eMrpView.Specprocty,"");
					SETCHAR(eMrpView.Prod_Unit,"");
					SETCHAR(eMrpView.Prod_Unit_Iso,"");
					SETCHAR(eMrpView.Iss_St_Loc,"");
					SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
					SETBCD(eMrpView.Cycle_Time,"0",0);
					SETCHAR(eMrpView.Covprofile,"");
					SETCHAR(eMrpView.Cc_Ph_Inv,"");
					SETCHAR(eMrpView.Serno_Prof,"");
					SETCHAR(eMrpView.Neg_Stocks,"");
					SETCHAR(eMrpView.Qm_Rgmts,"");
					SETCHAR(eMrpView.Plng_Cycle,"");
					SETCHAR(eMrpView.Round_Prof,"");
					SETCHAR(eMrpView.Refmatcons,"");
					SETCHAR(eMrpView.D_To_Ref_M,"");
					SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
					SETCHAR(eMrpView.Auto_Reset,"");
					SETCHAR(eMrpView.Ex_Cert_Id,"");
					SETCHAR(eMrpView.Ex_Cert_No_New,"");
					SETCHAR(eMrpView.Ex_Cert_Dt,"");
					SETCHAR(eMrpView.Milit_Id,"");
					SETBCD(eMrpView.Insp_Int,"0",0);
					SETCHAR(eMrpView.Co_Product,"");
					SETCHAR(eMrpView.Plan_Strgp,"");
					SETCHAR(eMrpView.Sloc_Exprc,"");
					SETCHAR(eMrpView.Cc_Fixed,"");
					SETCHAR(eMrpView.Qm_Authgrp,"");
					SETCHAR(eMrpView.Task_List_Type,"");
					SETCHAR(eMrpView.Prodprof,"");
					SETCHAR(eMrpView.Safty_T_Id,"");
					SETNUM(eMrpView.Safetytime,"00");
					SETCHAR(eMrpView.Plord_Ctrl,"");
					SETCHAR(eMrpView.Batchentry,"");
					SETDATE(eMrpView.Pvalidfrom,"");
					SETCHAR(eMrpView.Matfrgtgrp,"");
					SETCHAR(eMrpView.Prodverscs,"");
					SETCHAR(eMrpView.Mat_Cfop,"");
					SETCHAR(eMrpView.Eu_List_No,"");
					SETCHAR(eMrpView.Eu_Mat_Grp,"");
					SETCHAR(eMrpView.Cas_No,"");
					SETCHAR(eMrpView.Prodcom_No,"");
					SETCHAR(eMrpView.Ctrl_Code,"");
					SETCHAR(eMrpView.Jit_Relvt,"");
					SETCHAR(eMrpView.Mat_Grp_Trans,"");
					SETCHAR(eMrpView.Handlg_Grp,"");
					SETCHAR(eMrpView.Supply_Area,"");
					SETCHAR(eMrpView.Fair_Share_Rule,"");
					SETCHAR(eMrpView.Push_Distrib,"");
					SETBCD(eMrpView.Deploy_Horiz,"0",0);
					SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
					SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
					SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
					SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
					SETCHAR(eMrpView.Prod_Conv_Type,"");
					SETCHAR(eMrpView.Distr_Prof,"");
					SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
					SETCHAR(eMrpView.Fxd_Price,"");
					SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
					SETCHAR(eMrpView.Overallprf,"");
					SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
					SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
					SETCHAR(eMrpView.No_Costing,"");
					SETCHAR(eMrpView.Unit_Group,"");
					SETCHAR(eMrpView.Follow_Up_External,"");
					SETCHAR(eMrpView.Follow_Up_Guid,"");
					SETCHAR(eMrpView.Follow_Up_Version,"");
					SETCHAR(eMrpView.Refmatcons_External,"");
					SETCHAR(eMrpView.Refmatcons_Guid,"");
					SETCHAR(eMrpView.Refmatcons_Version,"");
					SETCHAR(eMrpView.Rotation_Date,"");
					SETCHAR(eMrpView.Original_Batch_Flag,"");
					SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
					SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
					SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
					SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
					SETCHAR(eMrpViewx.Plant,"1005");
					SETCHAR(eMrpViewx.Del_Flag,"");
					SETCHAR(eMrpViewx.Crit_Part,"");
					SETCHAR(eMrpViewx.Pur_Group,"");
					SETCHAR(eMrpViewx.Mrpprofile,"");
					SETCHAR(eMrpViewx.Plnd_Delry,"");
					SETCHAR(eMrpViewx.Assy_Scrap,"");
					SETCHAR(eMrpViewx.Safety_Stk,"");
					SETCHAR(eMrpViewx.Minlotsize,"");
					SETCHAR(eMrpViewx.Maxlotsize,"");
					SETCHAR(eMrpViewx.Round_Val,"");
					SETCHAR(eMrpViewx.Ord_Costs,"");
					SETCHAR(eMrpViewx.Stor_Costs,"");
					SETCHAR(eMrpViewx.Alt_Bom_Id,"");
					SETCHAR(eMrpViewx.Discontinu,"");
					SETCHAR(eMrpViewx.Eff_O_Day,"");
					SETCHAR(eMrpViewx.Follow_Up,"");
					SETCHAR(eMrpViewx.Backflush,"");
					SETCHAR(eMrpViewx.Production_Scheduler,"");
					SETCHAR(eMrpViewx.Proc_Time,"");
					SETCHAR(eMrpViewx.Setuptime,"");
					SETCHAR(eMrpViewx.Interop,"");
					SETCHAR(eMrpViewx.Base_Qty,"");
					SETCHAR(eMrpViewx.Inhseprodt,"");
					SETCHAR(eMrpViewx.Stgeperiod,"");
					SETCHAR(eMrpViewx.Stge_Pd_Un,"");
					SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
					SETCHAR(eMrpViewx.Over_Tol,"");
					SETCHAR(eMrpViewx.Unlimited,"");
					SETCHAR(eMrpViewx.Under_Tol,"");
					SETCHAR(eMrpViewx.Replentime,"");
					SETCHAR(eMrpViewx.Replace_Pt,"");
					SETCHAR(eMrpViewx.Loadinggrp,"");
					SETCHAR(eMrpViewx.Batch_Mgmt,"");
					SETCHAR(eMrpViewx.Serv_Level,"");
					SETCHAR(eMrpViewx.Fy_Variant,"");
					SETCHAR(eMrpViewx.Corr_Fact,"");
					SETCHAR(eMrpViewx.Setup_Time,"");
					SETCHAR(eMrpViewx.Base_Qty_Plan,"");
					SETCHAR(eMrpViewx.Ship_Proc_Time,"");
					SETCHAR(eMrpViewx.Sup_Source,"");
					SETCHAR(eMrpViewx.Auto_P_Ord,"");
					SETCHAR(eMrpViewx.Sourcelist,"");
					SETCHAR(eMrpViewx.Comm_Code,"");
					SETCHAR(eMrpViewx.Countryori,"");
					SETCHAR(eMrpViewx.Countryori_Iso,"");
					SETCHAR(eMrpViewx.Regionorig,"");
					SETCHAR(eMrpViewx.Comm_Co_Un,"");
					SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
					SETCHAR(eMrpViewx.Expimpgrp,"");
					SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
					SETCHAR(eMrpViewx.Consummode,"");
					SETCHAR(eMrpViewx.Bwd_Cons,"");
					SETCHAR(eMrpViewx.Fwd_Cons,"");
					SETCHAR(eMrpViewx.Bom_Usage,"");
					SETCHAR(eMrpViewx.Planlistgrp,"");
					SETCHAR(eMrpViewx.Planlistcnt,"");
					SETCHAR(eMrpViewx.Specprocty,"");
					SETCHAR(eMrpViewx.Prod_Unit,"");
					SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
					SETCHAR(eMrpViewx.Iss_St_Loc,"");
					SETCHAR(eMrpViewx.Comp_Scrap,"");
					SETCHAR(eMrpViewx.Cycle_Time,"");
					SETCHAR(eMrpViewx.Covprofile,"");
					SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
					SETCHAR(eMrpViewx.Serno_Prof,"");
					SETCHAR(eMrpViewx.Neg_Stocks,"");
					SETCHAR(eMrpViewx.Qm_Rgmts,"");
					SETCHAR(eMrpViewx.Plng_Cycle,"");
					SETCHAR(eMrpViewx.Round_Prof,"");
					SETCHAR(eMrpViewx.Refmatcons,"");
					SETCHAR(eMrpViewx.D_To_Ref_M,"");
					SETCHAR(eMrpViewx.Mult_Ref_M,"");
					SETCHAR(eMrpViewx.Auto_Reset,"");
					SETCHAR(eMrpViewx.Ex_Cert_Id,"");
					SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
					SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
					SETCHAR(eMrpViewx.Milit_Id,"");
					SETCHAR(eMrpViewx.Insp_Int,"");
					SETCHAR(eMrpViewx.Co_Product,"");
					SETCHAR(eMrpViewx.Plan_Strgp,"");
					SETCHAR(eMrpViewx.Sloc_Exprc,"");
					SETCHAR(eMrpViewx.Cc_Fixed,"");
					SETCHAR(eMrpViewx.Qm_Authgrp,"");
					SETCHAR(eMrpViewx.Task_List_Type,"");
					SETCHAR(eMrpViewx.Prodprof,"");
					SETCHAR(eMrpViewx.Safty_T_Id,"");
					SETCHAR(eMrpViewx.Safetytime,"");
					SETCHAR(eMrpViewx.Plord_Ctrl,"");
					SETCHAR(eMrpViewx.Batchentry,"");
					SETCHAR(eMrpViewx.Pvalidfrom,"");
					SETCHAR(eMrpViewx.Matfrgtgrp,"");
					SETCHAR(eMrpViewx.Prodverscs,"");
					SETCHAR(eMrpViewx.Mat_Cfop,"");
					SETCHAR(eMrpViewx.Eu_List_No,"");
					SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
					SETCHAR(eMrpViewx.Cas_No,"");
					SETCHAR(eMrpViewx.Prodcom_No,"");
					SETCHAR(eMrpViewx.Ctrl_Code,"");
					SETCHAR(eMrpViewx.Jit_Relvt,"");
					SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
					SETCHAR(eMrpViewx.Handlg_Grp,"");
					SETCHAR(eMrpViewx.Supply_Area,"");
					SETCHAR(eMrpViewx.Fair_Share_Rule,"");
					SETCHAR(eMrpViewx.Push_Distrib,"");
					SETCHAR(eMrpViewx.Deploy_Horiz,"");
					SETCHAR(eMrpViewx.Min_Lot_Size,"");
					SETCHAR(eMrpViewx.Max_Lot_Size,"");
					SETCHAR(eMrpViewx.Fix_Lot_Size,"");
					SETCHAR(eMrpViewx.Lot_Increment,"");
					SETCHAR(eMrpViewx.Prod_Conv_Type,"");
					SETCHAR(eMrpViewx.Distr_Prof,"");
					SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
					SETCHAR(eMrpViewx.Fxd_Price,"");
					SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
					SETCHAR(eMrpViewx.Overallprf,"");
					SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
					SETCHAR(eMrpViewx.Min_Safety_Stk,"");
					SETCHAR(eMrpViewx.No_Costing,"");
					SETCHAR(eMrpViewx.Unit_Group,"");
					SETCHAR(eMrpViewx.Follow_Up_External,"");
					SETCHAR(eMrpViewx.Follow_Up_Guid,"");
					SETCHAR(eMrpViewx.Follow_Up_Version,"");
					SETCHAR(eMrpViewx.Refmatcons_External,"");
					SETCHAR(eMrpViewx.Refmatcons_Guid,"");
					SETCHAR(eMrpViewx.Refmatcons_Version,"");
					SETCHAR(eMrpViewx.Rotation_Date,"");
					SETCHAR(eMrpViewx.Original_Batch_Flag,"");
					SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
					SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
					SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
					SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");


					SETCHAR(eBapi_Mpgd.Plant,"1005");
					SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
					SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
					SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
					SETCHAR(eBapi_Mpgdx.Plant,"1005");
					SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
					SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
					SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");

					SETCHAR(eBapi_Mard.Plant,"1005");
					SETCHAR(eBapi_Mard.Stge_Loc,"ED03");
					SETCHAR(eBapi_Mard.Del_Flag,"");
					SETCHAR(eBapi_Mard.Mrp_Ind,"");
					SETCHAR(eBapi_Mard.Spec_Proc,"");
					SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
					SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
					SETCHAR(eBapi_Mard.Stge_Bin,"");
					SETCHAR(eBapi_Mard.Pickg_Area,"");
					SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
					SETCHAR(eBapi_Mardx.Plant,"1005");
					SETCHAR(eBapi_Mardx.Stge_Loc,"ED03");
					SETCHAR(eBapi_Mardx.Del_Flag,"");
					SETCHAR(eBapi_Mardx.Mrp_Ind,"");
					SETCHAR(eBapi_Mardx.Spec_Proc,"");
					SETCHAR(eBapi_Mardx.Reorder_Pt,"");
					SETCHAR(eBapi_Mardx.Repl_Qty,"");
					SETCHAR(eBapi_Mardx.Stge_Bin,"");
					SETCHAR(eBapi_Mardx.Pickg_Area,"");
					SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");

					SETCHAR(eAccView.Val_Area,"1005");
					SETCHAR(eAccView.Val_Type,"");
					SETCHAR(eAccView.Del_Flag,"");
					SETBCD(eAccView.Price_Unit,"",0);
					SETCHAR(eAccView.Pr_Ctrl_Pp,"");
					SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
					SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
					SETBCD(eAccView.Pr_Unit_Pp,"0",1);
					SETCHAR(eAccView.Vclass_Pp,"");
					SETCHAR(eAccView.Pr_Ctrl_Py,"");
					SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
					SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
					SETCHAR(eAccView.Vclass_Py,"");
					SETBCD(eAccView.Pr_Unit_Py,"0",0);
					SETBCD(eAccView.Future_Pr,myzeroDup4,4);
					SETDATE(eAccView.Valid_From,"");

					SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
					SETBCD(eAccView.Commprice1,myzeroDup4,4);
					SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
					SETBCD(eAccView.Commprice3,myzeroDup4,4);
					SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
					SETBCD(eAccView.Plndprice1,myzeroDup4,4);
					SETBCD(eAccView.Plndprice2,myzeroDup4,4);
					SETBCD(eAccView.Plndprice3,myzeroDup4,4);
					SETDATE(eAccView.Plndprdate1,"");
					SETDATE(eAccView.Plndprdate2,"");
					SETDATE(eAccView.Plndprdate3,"");
					SETCHAR(eAccView.Lifo_Fifo,"");
					SETCHAR(eAccView.Poolnumber,"");
					SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
					SETBCD(eAccView.Commprice2,myzeroDup4,4);
					SETNUM(eAccView.Deval_Ind,"00");
					SETCHAR(eAccView.Ml_Active,"");
					SETCHAR(eAccView.Ml_Settle,"");
					SETCHAR(eAccView.Orig_Mat,"");
					SETCHAR(eAccView.Vm_So_Stk,"");
					SETCHAR(eAccView.Vm_P_Stock,"");
					SETCHAR(eAccView.Matl_Usage,"");
					SETCHAR(eAccView.In_House,"");
					SETBCD(eAccView.Tax_Cml_Un,"0",0);
					SETCHAR(eAccViewx.Val_Area,"1005");
					SETCHAR(eAccViewx.Val_Type,"");
					SETCHAR(eAccViewx.Del_Flag,"");
					SETCHAR(eAccViewx.Price_Unit,"");
					SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
					SETCHAR(eAccViewx.Mov_Pr_Pp,"");
					SETCHAR(eAccViewx.Std_Pr_Pp,"");
					SETCHAR(eAccViewx.Pr_Unit_Pp,"");
					SETCHAR(eAccViewx.Vclass_Pp,"");
					SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
					SETCHAR(eAccViewx.Mov_Pr_Py,"");
					SETCHAR(eAccViewx.Std_Pr_Py,"");
					SETCHAR(eAccViewx.Vclass_Py,"");
					SETCHAR(eAccViewx.Pr_Unit_Py,"");
					SETCHAR(eAccViewx.Future_Pr,"");
					SETCHAR(eAccViewx.Valid_From,"");
					SETCHAR(eAccViewx.Taxprice_1,"");
					SETCHAR(eAccViewx.Commprice1,"");
					SETCHAR(eAccViewx.Taxprice_3,"");
					SETCHAR(eAccViewx.Commprice3,"");
					SETCHAR(eAccViewx.Plnd_Price,"");
					SETCHAR(eAccViewx.Plndprice1,"");
					SETCHAR(eAccViewx.Plndprice2,"");
					SETCHAR(eAccViewx.Plndprice3,"");
					SETCHAR(eAccViewx.Plndprdate1,"");
					SETCHAR(eAccViewx.Plndprdate2,"");
					SETCHAR(eAccViewx.Plndprdate3,"");
					SETCHAR(eAccViewx.Lifo_Fifo,"");
					SETCHAR(eAccViewx.Poolnumber,"");
					SETCHAR(eAccViewx.Taxprice_2,"");
					SETCHAR(eAccViewx.Commprice2,"");
					SETCHAR(eAccViewx.Deval_Ind,"");
					SETCHAR(eAccViewx.Ml_Active,"");
					SETCHAR(eAccViewx.Ml_Settle,"");
					SETCHAR(eAccViewx.Orig_Mat,"");
					SETCHAR(eAccViewx.Vm_So_Stk,"");
					SETCHAR(eAccViewx.Vm_P_Stock,"");
					SETCHAR(eAccViewx.Matl_Usage,"");
					SETCHAR(eAccViewx.In_House,"");
					SETCHAR(eAccViewx.Tax_Cml_Un,"");

					SETCHAR(tBapi_Makt->Langu,"EN");
					SETCHAR(tBapi_Makt->Langu_Iso,"EN");
					SETCHAR(tBapi_Makt->Del_Flag,"");
					SETBCD(tBapi_Marm->Numerator,"1",0);
					SETBCD(tBapi_Marm->Denominatr,"1",0);
					SETCHAR(tBapi_Marm->Ean_Upc,"");
					SETCHAR(tBapi_Marm->Ean_Cat,"");
					SETCHAR(tBapi_Marm->Length,"");
					SETCHAR(tBapi_Marm->Width,"");
					SETCHAR(tBapi_Marm->Height,"");
					SETCHAR(tBapi_Marm->Unit_Dim,"");
					SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
					SETCHAR(tBapi_Marm->Del_Flag,"");
					SETCHAR(tBapi_Marm->Sub_Uom,"");
					SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
					SETCHAR(tBapi_Marm->Gtin_Variant,"");
					SETCHAR(tBapi_Marmx->Numerator,"X");
					SETCHAR(tBapi_Marmx->Denominatr,"X");
					SETCHAR(tBapi_Marmx->Ean_Upc,"");
					SETCHAR(tBapi_Marmx->Ean_Cat,"");
					SETCHAR(tBapi_Marmx->Length,"");
					SETCHAR(tBapi_Marmx->Width,"");
					SETCHAR(tBapi_Marmx->Height,"");
					SETCHAR(tBapi_Marmx->Unit_Dim,"");
					SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
					SETCHAR(tBapi_Marmx->Sub_Uom,"");
					SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
					SETCHAR(tBapi_Marmx->Gtin_Variant,"");


					RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,xException);

					switch (RfcRc)
					{
						case RFC_OK :
							printf("\nMessage Material creation [%s]:[%s]",PartNumberDup,eBapiret2.Message);
							fprintf(fsuccess,"\nMessage Material creation [%s]:[%s]",PartNumberDup,eBapiret2.Message);
						break;
						case RFC_EXCEPTION :
							printf("\nRFC EXCEPTION:-%s",xException);
						break;
						case RFC_SYS_EXCEPTION :
							printf("\nSYSTEM EXCEPTION RAISED");
						break;
						case RFC_FAILURE :
							printf("\nFAILURE");
						break;
						default :
							printf("\nOTHER FAILURE");
					}
					if (ItDelete(thBapi_Makt) != 0)
						printf("\nItDelete thBapi_Makt");
					if (ItDelete(thBapi_Marm) != 0)
						printf("\nItDelete tBapi_Marm");
					if (ItDelete(thBapi_Marmx) != 0)
						printf("\nItDelete thBapi_Marmx");
					RfcClose(hRfc);


					if(!nlsIsStrNull(sheet_status))
					{
						BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
					}
					go_for_rfc = 1;
				}
				else if((pstat=='K')&&(pstat_mrp != 'D'))//basic present and mrp view not present extend other view
				{


					printf("\nMaterial Extend");
					printf("\nmat_part:[%s]",PartNumberDup);
					printf("\nmat_type:[%s]",MatType);
					printf("\nPlant:[1005]");
					printf("\nuq:[%s]",MeasureUnit);
					printf("\ndescription:[%s]",PartDescriptionDup);
					printf("\nmaterial_group:[%s]",MaterialGroupDup);
					printf("\nproc_type:[%s]",proc_type);
					printf("\nspl_proc_type:[%s]",spl_proc_key);
					printf("\nDml:[%s]",EEDmlNumber);

					fprintf(fsuccess,"\nMaterial Extend");
					fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
					fprintf(fsuccess,"\nmat_type:[%s]",MatType);
					fprintf(fsuccess,"\nM");
					fprintf(fsuccess,"\nPlant:[1005]");
					fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
					fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
					fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
					fprintf(fsuccess,"\nproc_type:[%s]",proc_type);
					fprintf(fsuccess,"\nspl_proc_type:[%s]",spl_proc_key);
					fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




					pstat='0';
					pstat_mrp='0';
					pstat_acc='0';


					GetCSPstat(PartNumberDup);
					pstat_basicFun();



					printf("\naPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
					fprintf(fsuccess,"\naPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

					if (pstat_mrp == 'D')
					{
						printf("\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);
						fprintf(fsuccess,"\nMessage for Material Create:Material %s already exist for plant 1005\n",PartNumberDup);


					}
					else
					{


						go_for_rfc = 0;

						hRfc = BapiLogon();


						thBapi_Makt = ITAB_NULL;
						thBapi_Marm = ITAB_NULL;
						thBapi_Marmx = ITAB_NULL;


						if (thBapi_Makt==ITAB_NULL)
						{
							thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
							if (thBapi_Makt==ITAB_NULL)
								printf("\nItCreate MATERIALDESCRIPTION");
						}
						else
						{
							if (ItFree(thBapi_Makt) != 0)
								printf("\nItFree MATERIALDESCRIPTION");
						}

						if (thBapi_Marm==ITAB_NULL)
						{
							 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
							 if (thBapi_Marm==ITAB_NULL)
								printf("\nItCreate UNITSOFMEASURE");
						}
						else
						{
							if (ItFree(thBapi_Marm)!= 0)
								printf("\nItFree UNITSOFMEASURE");
						}

						if (thBapi_Marmx==ITAB_NULL)
						{
							 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
							if (thBapi_Marmx==ITAB_NULL)
								printf("\nItCreate UNITSOFMEASUREX");
						}
						else
						{
							if (ItFree(thBapi_Marmx)!= 0)
								printf("\nItFree UNITSOFMEASUREX");
						}

						tBapi_Makt = ItAppLine (thBapi_Makt) ;
						tBapi_Marm  = ItAppLine (thBapi_Marm) ;
						tBapi_Marmx = ItAppLine (thBapi_Marmx) ;

						if (tBapi_Makt == NULL)
							printf("\nItAppLine BAPI_MAKT");
						if (tBapi_Marm == NULL)
							printf("\nItAppLine BAPI_MARM second table");
						if (tBapi_Marmx == NULL)
							printf("\nItAppLine BAPI_MARMX");




						SETCHAR(eBapiMatHead.Material,PartNumberDup);
						SETCHAR(eBapiMatHead.Matl_Type,MatType);
						SETCHAR(eBapiMatHead.Ind_Sector,"M");
						SETCHAR(eBapiMatHead.Basic_View,"");
						SETCHAR(eBasicView.Base_Uom,MeasureUnit);
						SETCHAR(eBasicView.Base_Uom_Iso,MeasureUnit);
						SETCHAR(eBasicViewx.Base_Uom,"X");
						SETCHAR(eBasicViewx.Base_Uom_Iso,"X");

						SETCHAR(tBapi_Marm->Alt_Unit,MeasureUnit);
						SETCHAR(tBapi_Marm->Alt_Unit_Iso,MeasureUnit);
						SETCHAR(tBapi_Marmx->Alt_Unit,MeasureUnit);
						SETCHAR(tBapi_Marmx->Alt_Unit_Iso,MeasureUnit);
						SETCHAR(tBapi_Makt->Matl_Desc,PartDescriptionDup);

						SETCHAR(eBasicView.Document,drg_std_no);



						if(strcmp(drg_std_no,"")!=0)
						{
							SETCHAR(eBasicViewx.Document,"");
						}
						else
						{
							SETCHAR(eBasicViewx.Document,"");
						}
						SETCHAR(eBasicView.Doc_Type,drg_std_ind);
						if(strcmp(drg_std_ind,"")!=0)
						{
							SETCHAR(eBasicViewx.Doc_Type,"");
						}
						else
						{
							SETCHAR(eBasicViewx.Doc_Type,"");
						}

						SETCHAR(eBasicView.Doc_Vers,sheet_status);
						if(strcmp(sheet_status,"")!=0)
						{

							SETCHAR(eBasicViewx.Doc_Vers,"");
						}
						else
						{
							SETCHAR(eBasicViewx.Doc_Vers,"");
						}
						SETNUM(eBasicView.No_Sheets,SheetNumberDup);
						SETCHAR(eBasicViewx.No_Sheets,"");

						SETCHAR(eBasicView.Doc_Format,PageFormat);
						SETCHAR(eBasicViewx.Doc_Format,"");


						SETCHAR(eBasicView.Pageformat,"");
						SETCHAR(eBasicViewx.Pageformat,"");

						SETCHAR(eBasicView.Old_Mat_No,schas_type_no);
						SETCHAR(eBasicViewx.Old_Mat_No,"");

						SETBCD(eBasicView.Net_Weight,net_wt,3);
						SETCHAR(eBasicViewx.Net_Weight,"");
						SETBCD(tBapi_Marm->Gross_Wt,gros_wt,3);
						SETCHAR(tBapi_Marmx->Gross_Wt,"");
						SETCHAR(eBasicView.Unit_Of_Wt,"");
						SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
						SETCHAR(eBasicViewx.Unit_Of_Wt,"");
						SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
						SETCHAR(tBapi_Marm->Unit_Of_Wt,"");
						SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,"");
						SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
						SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");
						SETBCD(tBapi_Marm->Volume,volume,3);
						SETCHAR(tBapi_Marm->VolumeUnit,"");
						SETCHAR(tBapi_Marm->VolumeUnit_Iso,"");
						SETCHAR(tBapi_Marmx->Volume,"");
						SETCHAR(tBapi_Marmx->VolumeUnit,"");
						SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");

						SETCHAR(eBasicView.Size_Dim,sheet_size);
						SETCHAR(eBasicViewx.Size_Dim,"");

						if(!nlsIsStrNull(MaterialGroupDup))
						{
							SETCHAR(eBasicView.Matl_Group,MaterialGroupDup);
							if(ercDmlflag!=1)
							{
								SETCHAR(eBasicViewx.Matl_Group,"");
							}
							else if(ercDmlflag==1)  //ERC dml part hence do not update basic view
							{
								SETCHAR(eBasicViewx.Matl_Group,"");
							}
						}
						else
						{
							SETCHAR(eBasicView.Matl_Group,"");
							SETCHAR(eBasicViewx.Matl_Group,"");
						}

						SETCHAR(eBasicView.Division,basic_division);
						SETCHAR(eBasicViewx.Division,"");
						SETCHAR(eBasicView.Item_Cat,"NORM");
						SETCHAR(eBasicViewx.Item_Cat,"");
						SETCHAR(eBapiMatHead.Mrp_View,"X");
						SETCHAR(eBapiMatHead.Purchase_View,"");
						SETCHAR(eMrpView.Mrp_Group,"");
						SETCHAR(eMrpViewx.Mrp_Group,"");
						SETCHAR(eMrpView.Abc_Id,"");
						SETCHAR(eMrpViewx.Abc_Id,"");
						SETCHAR(eMrpView.Pur_Status,"");
						SETCHAR(eMrpViewx.Pur_Status,"");
						SETCHAR(eMrpView.Mrp_Type,mrp_type);
						SETCHAR(eMrpViewx.Mrp_Type,"X");
						SETBCD(eMrpView.Reorder_Pt,"",3);
						SETCHAR(eMrpViewx.Reorder_Pt,"");
						SETCHAR(eMrpView.Quotausage,"");
						SETCHAR(eMrpViewx.Quotausage,"");
						SETCHAR(eMrpView.Mrp_Ctrler,"");
						SETCHAR(eMrpViewx.Mrp_Ctrler,"");
						SETCHAR(eMrpView.Lotsizekey,"");
						SETCHAR(eMrpViewx.Lotsizekey,"");
						SETBCD(eMrpView.Fixed_Lot,"",3);
						SETCHAR(eMrpViewx.Fixed_Lot,"");
						SETBCD(eMrpView.Max_Stock,"",3);
						SETCHAR(eMrpViewx.Max_Stock,"");
						SETCHAR(eMrpView.Proc_Type,proc_type);
						SETCHAR(eMrpViewx.Proc_Type,"X");
						SETCHAR(eMrpView.Spproctype,spl_proc_key);
						SETCHAR(eMrpViewx.Spproctype,"X");
						SETCHAR(eMrpView.Bulk_Mat,"");
						SETCHAR(eMrpViewx.Bulk_Mat,"");
						SETCHAR(eMrpView.Sm_Key,"");
						SETCHAR(eMrpViewx.Sm_Key,"");
						SETCHAR(eMrpView.Ppc_Pl_Cal,plan_calendar);
						SETCHAR(eMrpViewx.Ppc_Pl_Cal,"");
						SETCHAR(eMrpView.Grp_Reqmts,"");
						SETCHAR(eMrpViewx.Grp_Reqmts,"");
						SETCHAR(eMrpView.Period_Ind,"");
						SETCHAR(eMrpViewx.Period_Ind,"");
						SETCHAR(eMrpView.Mixed_Mrp,"");
						SETCHAR(eMrpViewx.Mixed_Mrp,"");
						SETCHAR(eMrpView.Availcheck,avail_chk);
						SETCHAR(eMrpViewx.Availcheck,"");
						SETCHAR(eBapi_Mpgd.Plng_Matl,"");
						SETCHAR(eBapi_Mpgdx.Plng_Matl,"");
						SETCHAR(eBapi_Mpgd.Plng_Plant,"");
						SETCHAR(eBapi_Mpgdx.Plng_Plant,"");
						SETCHAR(eBapi_Mpgd.Convfactor,"");
						SETCHAR(eBapi_Mpgdx.Convfactor,"");
						SETCHAR(eMrpView.Alternative_Bom,"");
						SETCHAR(eMrpViewx.Alternative_Bom,"");
						SETCHAR(eMrpView.Dep_Req_Id,"");

						SETCHAR(eMrpViewx.Dep_Req_Id,"");
						SETCHAR(eMrpView.Rep_Manuf,"");
						SETCHAR(eMrpViewx.Rep_Manuf,"");
						SETCHAR(eMrpView.Repmanprof,"");
						SETCHAR(eMrpViewx.Repmanprof,"");
						SETCHAR(eMrpView.Determ_Grp,"");
						SETCHAR(eMrpViewx.Determ_Grp,"");
						SETCHAR(eBapiMatHead.Storage_View,"");
						SETCHAR(eMrpView.Issue_Unit,"");
						SETCHAR(eMrpView.Issue_Unit_Iso,"");
						SETCHAR(eMrpViewx.Issue_Unit,"");
						SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
						SETCHAR(eMrpView.Profit_Ctr,profit_centre);
						SETCHAR(eMrpViewx.Profit_Ctr,"");
						if(strcmp(MatType,"FERT") != 0)
						{
							SETCHAR(eBapiMatHead.Quality_View,"");
							SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
							SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
							SETCHAR(eMrpView.Doc_Reqd,"");
							SETCHAR(eMrpViewx.Doc_Reqd,"");
							SETBCD(eMrpView.Gr_Pr_Time,"",0);
							SETCHAR(eMrpViewx.Gr_Pr_Time,"");
							SETCHAR(eBasicView.Catprofile,"");
							SETCHAR(eBasicViewx.Catprofile,"");
							SETCHAR(eBasicView.Qm_Procmnt,"");
							SETCHAR(eBasicViewx.Qm_Procmnt,"");
							SETCHAR(eMrpView.Ctrl_Key,"");
							SETCHAR(eMrpViewx.Ctrl_Key,"");
							SETCHAR(eMrpView.Cert_Type,"");
							SETCHAR(eMrpViewx.Cert_Type,"");
						}
						else
						{
							SETCHAR(eBapiMatHead.Quality_View,"");
							SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
							SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
							SETCHAR(eMrpView.Doc_Reqd,"");
							SETCHAR(eMrpViewx.Doc_Reqd,"");
							SETBCD(eMrpView.Gr_Pr_Time,"",0);
							SETCHAR(eMrpViewx.Gr_Pr_Time,"");
							SETCHAR(eBasicView.Catprofile,"");
							SETCHAR(eBasicViewx.Catprofile,"");
							SETCHAR(eBasicView.Qm_Procmnt,"");
							SETCHAR(eBasicViewx.Qm_Procmnt,"");
							SETCHAR(eMrpView.Ctrl_Key,"");
							SETCHAR(eMrpViewx.Ctrl_Key,"");
							SETCHAR(eMrpView.Cert_Type,"");
							SETCHAR(eMrpViewx.Cert_Type,"");
						}

						SETCHAR(eBapiMatHead.Account_View,"");
						SETCHAR(eAccView.Val_Cat,"");
						SETCHAR(eAccViewx.Val_Cat,"");
						SETCHAR(eAccView.Val_Class,"");
						SETCHAR(eAccViewx.Val_Class,"");
						SETCHAR(eAccView.Price_Ctrl,"");
						SETCHAR(eAccViewx.Price_Ctrl,"");
						SETBCD(eAccView.Std_Price,"",4);
						SETCHAR(eAccViewx.Std_Price,"");
						SETBCD(eAccView.Moving_Pr,"",4);
						SETCHAR(eAccViewx.Moving_Pr,"");
						SETCHAR(eBapiMatHead.Cost_View,"");
						SETCHAR(eAccView.Mat_Origin,"");
						SETCHAR(eAccViewx.Mat_Origin,"");
						SETCHAR(eAccView.Orig_Group,"");
						SETCHAR(eAccViewx.Orig_Group,"");
						SETBCD(eMrpView.Lot_Size,"",3);
						SETCHAR(eMrpViewx.Lot_Size,"");
						SETCHAR(eAccView.Overhead_Grp,"");
						SETCHAR(eAccViewx.Overhead_Grp,"");
						SETCHAR(eMrpView.Variance_Key,"");
						SETCHAR(eMrpViewx.Variance_Key,"");
						SETCHAR(eAccView.Qty_Struct,"");
						SETCHAR(eAccViewx.Qty_Struct,"");
						SETCHAR(eMrpView.Split_Ind,"");
						SETCHAR(eMrpViewx.Split_Ind,"");

						SETCHAR(eRmmg1_Aennr.Aennr,EEDmlNumber);

						SETCHAR(eBapiMatHead.Sales_View,"");
						SETCHAR(eBapiMatHead.Forecast_View,"");
						SETCHAR(eBapiMatHead.Work_Sched_View,"");
						SETCHAR(eBapiMatHead.Prt_View,"");
						SETCHAR(eBapiMatHead.Warehouse_View,"");

						SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
						SETCHAR(eBapiMatHead.Material_External,"");
						SETCHAR(eBapiMatHead.MateriaL_Guid,"");
						SETCHAR(eBapiMatHead.Material_Version,"");
						SETCHAR(eBasicView.Del_Flag,"");
						SETCHAR(eBasicView.Po_Unit,"");
						SETCHAR(eBasicView.Po_Unit_Iso,"");

						SETCHAR(eBasicView.Doc_Chg_No,"");
						SETCHAR(eBasicView.Page_No,"");

						SETCHAR(eBasicView.Prod_Memo,"");
						SETCHAR(eBasicView.Basic_Matl,"");
						SETCHAR(eBasicView.Std_Descr,"");
						SETCHAR(eBasicView.Dsn_Office,"");
						SETCHAR(eBasicView.Pur_Valkey,"");
						SETCHAR(eBasicView.Container,"");
						SETCHAR(eBasicView.Stor_Conds,"");
						SETCHAR(eBasicView.Temp_Conds,"");
						SETCHAR(eBasicView.Trans_Grp,"");
						SETCHAR(eBasicView.Haz_Mat_No,"");

						SETCHAR(eBasicView.Competitor,"");

						SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);

						SETCHAR(eBasicView.Proc_Rule,"");
						SETCHAR(eBasicView.Sup_Source,"");
						SETCHAR(eBasicView.Season,"");
						SETCHAR(eBasicView.Label_Type,"");
						SETCHAR(eBasicView.Label_Form,"");
						SETCHAR(eBasicView.Prod_Hier,"");

						SETCHAR(eBasicView.Cad_Id,"");

						SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
						SETCHAR(eBasicView.Pack_Wt_Un,"");
						SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
						SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
						SETCHAR(eBasicView.Pack_Vo_Un,"");
						SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
						SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
						SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
						SETCHAR(eBasicView.Var_Ord_Un,"");
						SETCHAR(eBasicView.Batch_Mgmt,"");
						SETCHAR(eBasicView.Sh_Mat_Typ,"");
						SETBCD(eBasicView.Fill_Level,"0",0);
						SETINT2(&eBasicView.Stack_Fact,"0");
						SETCHAR(eBasicView.Mat_Grp_Sm,"");
						SETCHAR(eBasicView.Authoritygroup,"");
						SETBCD(eBasicView.Minremlife,"0",0);
						SETBCD(eBasicView.Shelf_Life,"0",0);
						SETBCD(eBasicView.Stor_Pct,"0",0);
						SETCHAR(eBasicView.Pur_Status,"");
						SETCHAR(eBasicView.Sal_Status,"");
						SETDATE(eBasicView.Pvalidfrom,"");
						SETDATE(eBasicView.Svalidfrom,"");
						SETCHAR(eBasicView.Envt_Rlvt,"");
						SETCHAR(eBasicView.Prod_Alloc,"");
						SETCHAR(eBasicView.Qual_Dik,"");
						SETCHAR(eBasicView.Manu_Mat,"");
						SETCHAR(eBasicView.Mfr_No,"");
						SETCHAR(eBasicView.Inv_Mat_No,"");
						SETCHAR(eBasicView.Manuf_Prof,"");
						SETCHAR(eBasicView.Hazmatprof,"");
						SETCHAR(eBasicView.High_Visc,"");
						SETCHAR(eBasicView.Looseorliq,"");
						SETCHAR(eBasicView.Closed_Box,"");
						SETCHAR(eBasicView.Appd_B_Rec,"");
						SETNUM(eBasicView.Matcmpllvl,"00");
						SETCHAR(eBasicView.Par_Eff,"");
						SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
						SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
						SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
						SETCHAR(eBasicView.Haz_Mat_No_External,"");
						SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
						SETCHAR(eBasicView.Haz_Mat_No_Version,"");
						SETCHAR(eBasicView.Inv_Mat_No_External,"");
						SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
						SETCHAR(eBasicView.Inv_Mat_No_Version,"");
						SETCHAR(eBasicView.Material_Fixed,"");
						SETCHAR(eBasicView.Cm_Relevance_Flag,"");
						SETCHAR(eBasicView.Sled_Bbd,"");
						SETCHAR(eBasicView.Gtin_Variant,"");
						SETCHAR(eBasicView.Serialization_Level,"");
						SETCHAR(eBasicView.Pl_Ref_Mat,"");
						SETCHAR(eBasicView.Extmatlgrp,"");
						SETCHAR(eBasicView.Uomusage,"");
						SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
						SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
						SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
						SETCHAR(eBasicViewx.Del_Flag,"");
						SETCHAR(eBasicViewx.Po_Unit,"");
						SETCHAR(eBasicViewx.Po_Unit_Iso,"");

						SETCHAR(eBasicViewx.Doc_Chg_No,"");
						SETCHAR(eBasicViewx.Page_No,"");
						SETCHAR(eBasicViewx.Prod_Memo,"");

						SETCHAR(eBasicViewx.Basic_Matl,"");
						SETCHAR(eBasicViewx.Std_Descr,"");
						SETCHAR(eBasicViewx.Dsn_Office,"");
						SETCHAR(eBasicViewx.Pur_Valkey,"");
						SETCHAR(eBasicViewx.Container,"");
						SETCHAR(eBasicViewx.Stor_Conds,"");
						SETCHAR(eBasicViewx.Temp_Conds,"");
						SETCHAR(eBasicViewx.Trans_Grp,"");
						SETCHAR(eBasicViewx.Haz_Mat_No,"");
						SETCHAR(eBasicViewx.Competitor,"");
						SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
						SETCHAR(eBasicViewx.Proc_Rule,"");
						SETCHAR(eBasicViewx.Sup_Source,"");
						SETCHAR(eBasicViewx.Season,"");
						SETCHAR(eBasicViewx.Label_Type,"");
						SETCHAR(eBasicViewx.Label_Form,"");
						SETCHAR(eBasicViewx.Prod_Hier,"");
						SETCHAR(eBasicViewx.Cad_Id,"");
						SETCHAR(eBasicViewx.Allowed_Wt,"");
						SETCHAR(eBasicViewx.Pack_Wt_Un,"");
						SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
						SETCHAR(eBasicViewx.Allwd_Vol,"");
						SETCHAR(eBasicViewx.Pack_Vo_Un,"");
						SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
						SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
						SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
						SETCHAR(eBasicViewx.Var_Ord_Un,"");
						SETCHAR(eBasicViewx.Batch_Mgmt,"");
						SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
						SETCHAR(eBasicViewx.Fill_Level,"");
						SETCHAR(eBasicViewx.Stack_Fact,"");
						SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
						SETCHAR(eBasicViewx.Authoritygroup,"");
						SETCHAR(eBasicViewx.Minremlife,"");
						SETCHAR(eBasicViewx.Shelf_Life,"");
						SETCHAR(eBasicViewx.Stor_Pct,"");
						SETCHAR(eBasicViewx.Pur_Status,"");
						SETCHAR(eBasicViewx.Sal_Status,"");
						SETCHAR(eBasicViewx.Pvalidfrom,"");
						SETCHAR(eBasicViewx.Svalidfrom,"");
						SETCHAR(eBasicViewx.Envt_Rlvt,"");
						SETCHAR(eBasicViewx.Prod_Alloc,"");
						SETCHAR(eBasicViewx.Qual_Dik,"");
						SETCHAR(eBasicViewx.Manu_Mat,"");
						SETCHAR(eBasicViewx.Mfr_No,"");
						SETCHAR(eBasicViewx.Inv_Mat_No,"");
						SETCHAR(eBasicViewx.Manuf_Prof,"");
						SETCHAR(eBasicViewx.Hazmatprof,"");
						SETCHAR(eBasicViewx.High_Visc,"");
						SETCHAR(eBasicViewx.Looseorliq,"");
						SETCHAR(eBasicViewx.Closed_Box,"");
						SETCHAR(eBasicViewx.Appd_B_Rec,"");
						SETCHAR(eBasicViewx.Matcmpllvl,"");
						SETCHAR(eBasicViewx.Par_Eff,"");
						SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
						SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
						SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
						SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
						SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
						SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
						SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
						SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
						SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
						SETCHAR(eBasicViewx.Material_Fixed,"");
						SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
						SETCHAR(eBasicViewx.Sled_Bbd,"");
						SETCHAR(eBasicViewx.Gtin_Variant,"");
						SETCHAR(eBasicViewx.Serialization_Level,"");
						SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
						SETCHAR(eBasicViewx.Extmatlgrp,"");
						SETCHAR(eBasicViewx.Uomusage,"");
						SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
						SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
						SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
						SETCHAR(eMrpView.Plant,"1005");
						SETCHAR(eMrpView.Del_Flag,"");
						SETCHAR(eMrpView.Crit_Part,"");
						SETCHAR(eMrpView.Pur_Group,"");
						SETCHAR(eMrpView.Mrpprofile,"");
						SETCHAR(eMrpView.Plnd_Delry,"0");
						SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
						SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
						SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
						SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
						SETBCD(eMrpView.Round_Val,myzeroDup3,3);
						SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
						SETCHAR(eMrpView.Stor_Costs,"");
						SETCHAR(eMrpView.Alt_Bom_Id,"");
						SETCHAR(eMrpView.Discontinu,"");
						SETCHAR(eMrpView.Eff_O_Day,"");
						SETCHAR(eMrpView.Follow_Up,"");
						SETCHAR(eMrpView.Backflush,"");
						SETCHAR(eMrpView.Production_Scheduler,"");
						SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
						SETBCD(eMrpView.Setuptime,myzeroDup2,2);
						SETBCD(eMrpView.Interop,myzeroDup2,2);
						SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
						SETBCD(eMrpView.Inhseprodt,"0",0);
						SETBCD(eMrpView.Stgeperiod,"0",0);
						SETCHAR(eMrpView.Stge_Pd_Un,"");
						SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
						SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
						SETCHAR(eMrpView.Unlimited,"");
						SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
						SETBCD(eMrpView.Replentime,"0",0);
						SETCHAR(eMrpView.Replace_Pt,"");
						SETCHAR(eMrpView.Loadinggrp,"");
						SETCHAR(eMrpView.Batch_Mgmt,"");
						SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
						SETCHAR(eMrpView.Fy_Variant,"");
						SETCHAR(eMrpView.Corr_Fact,"");
						SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
						SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
						SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
						SETCHAR(eMrpView.Sup_Source,"");
						SETCHAR(eMrpView.Auto_P_Ord,"");
						SETCHAR(eMrpView.Sourcelist,"");
						SETCHAR(eMrpView.Comm_Code,"");
						SETCHAR(eMrpView.Countryori,"");
						SETCHAR(eMrpView.Countryori_Iso,"");
						SETCHAR(eMrpView.Regionorig,"");
						SETCHAR(eMrpView.Comm_Co_Un,"");
						SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
						SETCHAR(eMrpView.Expimpgrp,"");
						SETNUM(eMrpView.Pl_Ti_Fnce,"000");
						SETCHAR(eMrpView.Consummode,"");
						SETNUM(eMrpView.Bwd_Cons,"000");
						SETNUM(eMrpView.Fwd_Cons,"000");
						SETCHAR(eMrpView.Bom_Usage,"");
						SETCHAR(eMrpView.Planlistgrp,"");
						SETCHAR(eMrpView.Planlistcnt,"");
						SETCHAR(eMrpView.Specprocty,"");
						SETCHAR(eMrpView.Prod_Unit,"");
						SETCHAR(eMrpView.Prod_Unit_Iso,"");
						SETCHAR(eMrpView.Iss_St_Loc,"");
						SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
						SETBCD(eMrpView.Cycle_Time,"0",0);
						SETCHAR(eMrpView.Covprofile,"");
						SETCHAR(eMrpView.Cc_Ph_Inv,"");
						SETCHAR(eMrpView.Serno_Prof,"");
						SETCHAR(eMrpView.Neg_Stocks,"");
						SETCHAR(eMrpView.Qm_Rgmts,"");
						SETCHAR(eMrpView.Plng_Cycle,"");
						SETCHAR(eMrpView.Round_Prof,"");
						SETCHAR(eMrpView.Refmatcons,"");
						SETCHAR(eMrpView.D_To_Ref_M,"");
						SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
						SETCHAR(eMrpView.Auto_Reset,"");
						SETCHAR(eMrpView.Ex_Cert_Id,"");
						SETCHAR(eMrpView.Ex_Cert_No_New,"");
						SETCHAR(eMrpView.Ex_Cert_Dt,"");
						SETCHAR(eMrpView.Milit_Id,"");
						SETBCD(eMrpView.Insp_Int,"0",0);
						SETCHAR(eMrpView.Co_Product,"");
						SETCHAR(eMrpView.Plan_Strgp,"");
						SETCHAR(eMrpView.Sloc_Exprc,"");
						SETCHAR(eMrpView.Cc_Fixed,"");
						SETCHAR(eMrpView.Qm_Authgrp,"");
						SETCHAR(eMrpView.Task_List_Type,"");
						SETCHAR(eMrpView.Prodprof,"");
						SETCHAR(eMrpView.Safty_T_Id,"");
						SETNUM(eMrpView.Safetytime,"00");
						SETCHAR(eMrpView.Plord_Ctrl,"");
						SETCHAR(eMrpView.Batchentry,"");
						SETDATE(eMrpView.Pvalidfrom,"");
						SETCHAR(eMrpView.Matfrgtgrp,"");
						SETCHAR(eMrpView.Prodverscs,"");
						SETCHAR(eMrpView.Mat_Cfop,"");
						SETCHAR(eMrpView.Eu_List_No,"");
						SETCHAR(eMrpView.Eu_Mat_Grp,"");
						SETCHAR(eMrpView.Cas_No,"");
						SETCHAR(eMrpView.Prodcom_No,"");
						SETCHAR(eMrpView.Ctrl_Code,"");
						SETCHAR(eMrpView.Jit_Relvt,"");
						SETCHAR(eMrpView.Mat_Grp_Trans,"");
						SETCHAR(eMrpView.Handlg_Grp,"");
						SETCHAR(eMrpView.Supply_Area,"");
						SETCHAR(eMrpView.Fair_Share_Rule,"");
						SETCHAR(eMrpView.Push_Distrib,"");
						SETBCD(eMrpView.Deploy_Horiz,"0",0);
						SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
						SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
						SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
						SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
						SETCHAR(eMrpView.Prod_Conv_Type,"");
						SETCHAR(eMrpView.Distr_Prof,"");
						SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
						SETCHAR(eMrpView.Fxd_Price,"");
						SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
						SETCHAR(eMrpView.Overallprf,"");
						SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
						SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
						SETCHAR(eMrpView.No_Costing,"");
						SETCHAR(eMrpView.Unit_Group,"");
						SETCHAR(eMrpView.Follow_Up_External,"");
						SETCHAR(eMrpView.Follow_Up_Guid,"");
						SETCHAR(eMrpView.Follow_Up_Version,"");
						SETCHAR(eMrpView.Refmatcons_External,"");
						SETCHAR(eMrpView.Refmatcons_Guid,"");
						SETCHAR(eMrpView.Refmatcons_Version,"");
						SETCHAR(eMrpView.Rotation_Date,"");
						SETCHAR(eMrpView.Original_Batch_Flag,"");
						SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
						SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
						SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
						SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
						SETCHAR(eMrpViewx.Plant,"1005");
						SETCHAR(eMrpViewx.Del_Flag,"");
						SETCHAR(eMrpViewx.Crit_Part,"");
						SETCHAR(eMrpViewx.Pur_Group,"");
						SETCHAR(eMrpViewx.Mrpprofile,"");
						SETCHAR(eMrpViewx.Plnd_Delry,"");
						SETCHAR(eMrpViewx.Assy_Scrap,"");
						SETCHAR(eMrpViewx.Safety_Stk,"");
						SETCHAR(eMrpViewx.Minlotsize,"");
						SETCHAR(eMrpViewx.Maxlotsize,"");
						SETCHAR(eMrpViewx.Round_Val,"");
						SETCHAR(eMrpViewx.Ord_Costs,"");
						SETCHAR(eMrpViewx.Stor_Costs,"");
						SETCHAR(eMrpViewx.Alt_Bom_Id,"");
						SETCHAR(eMrpViewx.Discontinu,"");
						SETCHAR(eMrpViewx.Eff_O_Day,"");
						SETCHAR(eMrpViewx.Follow_Up,"");
						SETCHAR(eMrpViewx.Backflush,"");
						SETCHAR(eMrpViewx.Production_Scheduler,"");
						SETCHAR(eMrpViewx.Proc_Time,"");
						SETCHAR(eMrpViewx.Setuptime,"");
						SETCHAR(eMrpViewx.Interop,"");
						SETCHAR(eMrpViewx.Base_Qty,"");
						SETCHAR(eMrpViewx.Inhseprodt,"");
						SETCHAR(eMrpViewx.Stgeperiod,"");
						SETCHAR(eMrpViewx.Stge_Pd_Un,"");
						SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
						SETCHAR(eMrpViewx.Over_Tol,"");
						SETCHAR(eMrpViewx.Unlimited,"");
						SETCHAR(eMrpViewx.Under_Tol,"");
						SETCHAR(eMrpViewx.Replentime,"");
						SETCHAR(eMrpViewx.Replace_Pt,"");
						SETCHAR(eMrpViewx.Loadinggrp,"");
						SETCHAR(eMrpViewx.Batch_Mgmt,"");
						SETCHAR(eMrpViewx.Serv_Level,"");
						SETCHAR(eMrpViewx.Fy_Variant,"");
						SETCHAR(eMrpViewx.Corr_Fact,"");
						SETCHAR(eMrpViewx.Setup_Time,"");
						SETCHAR(eMrpViewx.Base_Qty_Plan,"");
						SETCHAR(eMrpViewx.Ship_Proc_Time,"");
						SETCHAR(eMrpViewx.Sup_Source,"");
						SETCHAR(eMrpViewx.Auto_P_Ord,"");
						SETCHAR(eMrpViewx.Sourcelist,"");
						SETCHAR(eMrpViewx.Comm_Code,"");
						SETCHAR(eMrpViewx.Countryori,"");
						SETCHAR(eMrpViewx.Countryori_Iso,"");
						SETCHAR(eMrpViewx.Regionorig,"");
						SETCHAR(eMrpViewx.Comm_Co_Un,"");
						SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
						SETCHAR(eMrpViewx.Expimpgrp,"");
						SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
						SETCHAR(eMrpViewx.Consummode,"");
						SETCHAR(eMrpViewx.Bwd_Cons,"");
						SETCHAR(eMrpViewx.Fwd_Cons,"");
						SETCHAR(eMrpViewx.Bom_Usage,"");
						SETCHAR(eMrpViewx.Planlistgrp,"");
						SETCHAR(eMrpViewx.Planlistcnt,"");
						SETCHAR(eMrpViewx.Specprocty,"");
						SETCHAR(eMrpViewx.Prod_Unit,"");
						SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
						SETCHAR(eMrpViewx.Iss_St_Loc,"");
						SETCHAR(eMrpViewx.Comp_Scrap,"");
						SETCHAR(eMrpViewx.Cycle_Time,"");
						SETCHAR(eMrpViewx.Covprofile,"");
						SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
						SETCHAR(eMrpViewx.Serno_Prof,"");
						SETCHAR(eMrpViewx.Neg_Stocks,"");
						SETCHAR(eMrpViewx.Qm_Rgmts,"");
						SETCHAR(eMrpViewx.Plng_Cycle,"");
						SETCHAR(eMrpViewx.Round_Prof,"");
						SETCHAR(eMrpViewx.Refmatcons,"");
						SETCHAR(eMrpViewx.D_To_Ref_M,"");
						SETCHAR(eMrpViewx.Mult_Ref_M,"");
						SETCHAR(eMrpViewx.Auto_Reset,"");
						SETCHAR(eMrpViewx.Ex_Cert_Id,"");
						SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
						SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
						SETCHAR(eMrpViewx.Milit_Id,"");
						SETCHAR(eMrpViewx.Insp_Int,"");
						SETCHAR(eMrpViewx.Co_Product,"");
						SETCHAR(eMrpViewx.Plan_Strgp,"");
						SETCHAR(eMrpViewx.Sloc_Exprc,"");
						SETCHAR(eMrpViewx.Cc_Fixed,"");
						SETCHAR(eMrpViewx.Qm_Authgrp,"");
						SETCHAR(eMrpViewx.Task_List_Type,"");
						SETCHAR(eMrpViewx.Prodprof,"");
						SETCHAR(eMrpViewx.Safty_T_Id,"");
						SETCHAR(eMrpViewx.Safetytime,"");
						SETCHAR(eMrpViewx.Plord_Ctrl,"");
						SETCHAR(eMrpViewx.Batchentry,"");
						SETCHAR(eMrpViewx.Pvalidfrom,"");
						SETCHAR(eMrpViewx.Matfrgtgrp,"");
						SETCHAR(eMrpViewx.Prodverscs,"");
						SETCHAR(eMrpViewx.Mat_Cfop,"");
						SETCHAR(eMrpViewx.Eu_List_No,"");
						SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
						SETCHAR(eMrpViewx.Cas_No,"");
						SETCHAR(eMrpViewx.Prodcom_No,"");
						SETCHAR(eMrpViewx.Ctrl_Code,"");
						SETCHAR(eMrpViewx.Jit_Relvt,"");
						SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
						SETCHAR(eMrpViewx.Handlg_Grp,"");
						SETCHAR(eMrpViewx.Supply_Area,"");
						SETCHAR(eMrpViewx.Fair_Share_Rule,"");
						SETCHAR(eMrpViewx.Push_Distrib,"");
						SETCHAR(eMrpViewx.Deploy_Horiz,"");
						SETCHAR(eMrpViewx.Min_Lot_Size,"");
						SETCHAR(eMrpViewx.Max_Lot_Size,"");
						SETCHAR(eMrpViewx.Fix_Lot_Size,"");
						SETCHAR(eMrpViewx.Lot_Increment,"");
						SETCHAR(eMrpViewx.Prod_Conv_Type,"");
						SETCHAR(eMrpViewx.Distr_Prof,"");
						SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
						SETCHAR(eMrpViewx.Fxd_Price,"");
						SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
						SETCHAR(eMrpViewx.Overallprf,"");
						SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
						SETCHAR(eMrpViewx.Min_Safety_Stk,"");
						SETCHAR(eMrpViewx.No_Costing,"");
						SETCHAR(eMrpViewx.Unit_Group,"");
						SETCHAR(eMrpViewx.Follow_Up_External,"");
						SETCHAR(eMrpViewx.Follow_Up_Guid,"");
						SETCHAR(eMrpViewx.Follow_Up_Version,"");
						SETCHAR(eMrpViewx.Refmatcons_External,"");
						SETCHAR(eMrpViewx.Refmatcons_Guid,"");
						SETCHAR(eMrpViewx.Refmatcons_Version,"");
						SETCHAR(eMrpViewx.Rotation_Date,"");
						SETCHAR(eMrpViewx.Original_Batch_Flag,"");
						SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
						SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
						SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
						SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");


						SETCHAR(eBapi_Mpgd.Plant,"1005");
						SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
						SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
						SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
						SETCHAR(eBapi_Mpgdx.Plant,"1005");
						SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
						SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
						SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");

						SETCHAR(eBapi_Mard.Plant,"1005");
						SETCHAR(eBapi_Mard.Stge_Loc,"ED03");
						SETCHAR(eBapi_Mard.Del_Flag,"");
						SETCHAR(eBapi_Mard.Mrp_Ind,"");
						SETCHAR(eBapi_Mard.Spec_Proc,"");
						SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
						SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
						SETCHAR(eBapi_Mard.Stge_Bin,"");
						SETCHAR(eBapi_Mard.Pickg_Area,"");
						SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
						SETCHAR(eBapi_Mardx.Plant,"1005");
						SETCHAR(eBapi_Mardx.Stge_Loc,"ED03");
						SETCHAR(eBapi_Mardx.Del_Flag,"");
						SETCHAR(eBapi_Mardx.Mrp_Ind,"");
						SETCHAR(eBapi_Mardx.Spec_Proc,"");
						SETCHAR(eBapi_Mardx.Reorder_Pt,"");
						SETCHAR(eBapi_Mardx.Repl_Qty,"");
						SETCHAR(eBapi_Mardx.Stge_Bin,"");
						SETCHAR(eBapi_Mardx.Pickg_Area,"");
						SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");

						SETCHAR(eAccView.Val_Area,"1005");
						SETCHAR(eAccView.Val_Type,"");
						SETCHAR(eAccView.Del_Flag,"");
						SETBCD(eAccView.Price_Unit,"",0);
						SETCHAR(eAccView.Pr_Ctrl_Pp,"");
						SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
						SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
						SETBCD(eAccView.Pr_Unit_Pp,"0",1);
						SETCHAR(eAccView.Vclass_Pp,"");
						SETCHAR(eAccView.Pr_Ctrl_Py,"");
						SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
						SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
						SETCHAR(eAccView.Vclass_Py,"");
						SETBCD(eAccView.Pr_Unit_Py,"0",0);
						SETBCD(eAccView.Future_Pr,myzeroDup4,4);
						SETDATE(eAccView.Valid_From,"");

						SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
						SETBCD(eAccView.Commprice1,myzeroDup4,4);
						SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
						SETBCD(eAccView.Commprice3,myzeroDup4,4);
						SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
						SETBCD(eAccView.Plndprice1,myzeroDup4,4);
						SETBCD(eAccView.Plndprice2,myzeroDup4,4);
						SETBCD(eAccView.Plndprice3,myzeroDup4,4);
						SETDATE(eAccView.Plndprdate1,"");
						SETDATE(eAccView.Plndprdate2,"");
						SETDATE(eAccView.Plndprdate3,"");
						SETCHAR(eAccView.Lifo_Fifo,"");
						SETCHAR(eAccView.Poolnumber,"");
						SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
						SETBCD(eAccView.Commprice2,myzeroDup4,4);
						SETNUM(eAccView.Deval_Ind,"00");
						SETCHAR(eAccView.Ml_Active,"");
						SETCHAR(eAccView.Ml_Settle,"");
						SETCHAR(eAccView.Orig_Mat,"");
						SETCHAR(eAccView.Vm_So_Stk,"");
						SETCHAR(eAccView.Vm_P_Stock,"");
						SETCHAR(eAccView.Matl_Usage,"");
						SETCHAR(eAccView.In_House,"");
						SETBCD(eAccView.Tax_Cml_Un,"0",0);
						SETCHAR(eAccViewx.Val_Area,"1005");
						SETCHAR(eAccViewx.Val_Type,"");
						SETCHAR(eAccViewx.Del_Flag,"");
						SETCHAR(eAccViewx.Price_Unit,"");
						SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
						SETCHAR(eAccViewx.Mov_Pr_Pp,"");
						SETCHAR(eAccViewx.Std_Pr_Pp,"");
						SETCHAR(eAccViewx.Pr_Unit_Pp,"");
						SETCHAR(eAccViewx.Vclass_Pp,"");
						SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
						SETCHAR(eAccViewx.Mov_Pr_Py,"");
						SETCHAR(eAccViewx.Std_Pr_Py,"");
						SETCHAR(eAccViewx.Vclass_Py,"");
						SETCHAR(eAccViewx.Pr_Unit_Py,"");
						SETCHAR(eAccViewx.Future_Pr,"");
						SETCHAR(eAccViewx.Valid_From,"");
						SETCHAR(eAccViewx.Taxprice_1,"");
						SETCHAR(eAccViewx.Commprice1,"");
						SETCHAR(eAccViewx.Taxprice_3,"");
						SETCHAR(eAccViewx.Commprice3,"");
						SETCHAR(eAccViewx.Plnd_Price,"");
						SETCHAR(eAccViewx.Plndprice1,"");
						SETCHAR(eAccViewx.Plndprice2,"");
						SETCHAR(eAccViewx.Plndprice3,"");
						SETCHAR(eAccViewx.Plndprdate1,"");
						SETCHAR(eAccViewx.Plndprdate2,"");
						SETCHAR(eAccViewx.Plndprdate3,"");
						SETCHAR(eAccViewx.Lifo_Fifo,"");
						SETCHAR(eAccViewx.Poolnumber,"");
						SETCHAR(eAccViewx.Taxprice_2,"");
						SETCHAR(eAccViewx.Commprice2,"");
						SETCHAR(eAccViewx.Deval_Ind,"");
						SETCHAR(eAccViewx.Ml_Active,"");
						SETCHAR(eAccViewx.Ml_Settle,"");
						SETCHAR(eAccViewx.Orig_Mat,"");
						SETCHAR(eAccViewx.Vm_So_Stk,"");
						SETCHAR(eAccViewx.Vm_P_Stock,"");
						SETCHAR(eAccViewx.Matl_Usage,"");
						SETCHAR(eAccViewx.In_House,"");
						SETCHAR(eAccViewx.Tax_Cml_Un,"");

						SETCHAR(tBapi_Makt->Langu,"EN");
						SETCHAR(tBapi_Makt->Langu_Iso,"EN");
						SETCHAR(tBapi_Makt->Del_Flag,"");
						SETBCD(tBapi_Marm->Numerator,"1",0);
						SETBCD(tBapi_Marm->Denominatr,"1",0);
						SETCHAR(tBapi_Marm->Ean_Upc,"");
						SETCHAR(tBapi_Marm->Ean_Cat,"");
						SETCHAR(tBapi_Marm->Length,"");
						SETCHAR(tBapi_Marm->Width,"");
						SETCHAR(tBapi_Marm->Height,"");
						SETCHAR(tBapi_Marm->Unit_Dim,"");
						SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
						SETCHAR(tBapi_Marm->Del_Flag,"");
						SETCHAR(tBapi_Marm->Sub_Uom,"");
						SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
						SETCHAR(tBapi_Marm->Gtin_Variant,"");
						SETCHAR(tBapi_Marmx->Numerator,"");
						SETCHAR(tBapi_Marmx->Denominatr,"");
						SETCHAR(tBapi_Marmx->Ean_Upc,"");
						SETCHAR(tBapi_Marmx->Ean_Cat,"");
						SETCHAR(tBapi_Marmx->Length,"");
						SETCHAR(tBapi_Marmx->Width,"");
						SETCHAR(tBapi_Marmx->Height,"");
						SETCHAR(tBapi_Marmx->Unit_Dim,"");
						SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
						SETCHAR(tBapi_Marmx->Sub_Uom,"");
						SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
						SETCHAR(tBapi_Marmx->Gtin_Variant,"");


						RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,xException);

						switch (RfcRc)
						{
							case RFC_OK :
								printf("\nMessage Material Change [%s]:[%s]",PartNumberDup,eBapiret2.Message);
								fprintf(fsuccess,"\nMessage Material Change [%s]:[%s]",PartNumberDup,eBapiret2.Message);
							break;
							case RFC_EXCEPTION :
								printf("\nRFC EXCEPTION:-%s",xException);
							break;
							case RFC_SYS_EXCEPTION :
								printf("\nSYSTEM EXCEPTION RAISED");
							break;
							case RFC_FAILURE :
								printf("\nFAILURE");
							break;
							default :
								printf("\nOTHER FAILURE");
						}
						if (ItDelete(thBapi_Makt) != 0)
							printf("\nItDelete thBapi_Makt");
						if (ItDelete(thBapi_Marm) != 0)
							printf("\nItDelete tBapi_Marm");
						if (ItDelete(thBapi_Marmx) != 0)
							printf("\nItDelete thBapi_Marmx");
						RfcClose(hRfc);

						if(!nlsIsStrNull(sheet_status))
						{
							BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
						}
						go_for_rfc = 1;


					}


				}

			}
		}
		if((flag == 1 ))
		{

			printf("\nMaterial Change");
			printf("\nmat_part:[%s]",PartNumberDup);
			printf("\nmat_type:[%s]",MatType);
			printf("\nPlant:[1005]");
			printf("\nuq:[%s]",MeasureUnit);
			printf("\ndescription:[%s]",PartDescriptionDup);
			printf("\nmaterial_group:[%s]",MaterialGroupDup);
			printf("\nproc_type:[%s]",proc_type);
			printf("\nspl_proc_type:[%s]",spl_proc_key);
			printf("\nDml:[%s]",EEDmlNumber);

			fprintf(fsuccess,"\nMaterial Change");
			fprintf(fsuccess,"\nmat_part:[%s]",PartNumberDup);
			fprintf(fsuccess,"\nmat_type:[%s]",MatType);
			fprintf(fsuccess,"\nM");
			fprintf(fsuccess,"\nPlant:[1005]");
			fprintf(fsuccess,"\nuq:[%s]",MeasureUnit);
			fprintf(fsuccess,"\ndescription:[%s]",PartDescriptionDup);
			fprintf(fsuccess,"\nmaterial_group:[%s]",MaterialGroupDup);
			fprintf(fsuccess,"\nproc_type:[%s]",proc_type);
			fprintf(fsuccess,"\nspl_proc_type:[%s]",spl_proc_key);
			fprintf(fsuccess,"\nDml:[%s]",EEDmlNumber);




			pstat='0';
			pstat_mrp='0';
			pstat_acc='0';

			GetCSPstat ( PartNumberDup ) ;
			pstat_basicFun ( ) ;


			printf("\nbPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);
			fprintf(fsuccess,"\nbPStat for Basic View: [%c] MRP View: [%c] Accounting View: [%c]",pstat,pstat_mrp,pstat_acc);

			if ( pstat_mrp == 'D' )
			{
				if ( ercDmlflag == 1 )
				{
					if(pstat!='K')
					{
						printf("ERC dml part [%s] do not have BASIC view hence skipping from material extend to 1005",PartNumberDup);
						return 1;
					}
				}

				go_for_rfc = 0;

				hRfc = BapiLogon();


				thBapi_Makt = ITAB_NULL;
				thBapi_Marm = ITAB_NULL;
				thBapi_Marmx = ITAB_NULL;


				if (thBapi_Makt==ITAB_NULL)
				{
					thBapi_Makt = ItCreate("MATERIALDESCRIPTION",sizeof(BAPI_MAKT),0,0);
					if (thBapi_Makt==ITAB_NULL)
						printf("\nItCreate MATERIALDESCRIPTION");
				}
				else
				{
					if (ItFree(thBapi_Makt) != 0)
						printf("\nItFree MATERIALDESCRIPTION");
				}

				if (thBapi_Marm==ITAB_NULL)
				{
					 thBapi_Marm = ItCreate("UNITSOFMEASURE",sizeof(BAPI_MARM),0,0);
					 if (thBapi_Marm==ITAB_NULL)
						printf("\nItCreate UNITSOFMEASURE");
				}
				else
				{
					if (ItFree(thBapi_Marm)!= 0)
						printf("\nItFree UNITSOFMEASURE");
				}

				if (thBapi_Marmx==ITAB_NULL)
				{
					 thBapi_Marmx = ItCreate("UNITSOFMEASUREX",sizeof(BAPI_MARMX),0,0);
					if (thBapi_Marmx==ITAB_NULL)
						printf("\nItCreate UNITSOFMEASUREX");
				}
				else
				{
					if (ItFree(thBapi_Marmx)!= 0)
						printf("\nItFree UNITSOFMEASUREX");
				}

				tBapi_Makt = ItAppLine (thBapi_Makt) ;
				tBapi_Marm  = ItAppLine (thBapi_Marm) ;
				tBapi_Marmx = ItAppLine (thBapi_Marmx) ;

				if (tBapi_Makt == NULL)
					printf("\nItAppLine BAPI_MAKT");
				if (tBapi_Marm == NULL)
					printf("\nItAppLine BAPI_MARM second table");
				if (tBapi_Marmx == NULL)
					printf("\nItAppLine BAPI_MARMX");




				SETCHAR(eBapiMatHead.Material,PartNumberDup);
				SETCHAR(eBapiMatHead.Matl_Type,MatType);
				SETCHAR(eBapiMatHead.Ind_Sector,"M");
				SETCHAR(eBapiMatHead.Basic_View,"X");
				SETCHAR(eBasicView.Base_Uom,MeasureUnit);
				SETCHAR(eBasicView.Base_Uom_Iso,MeasureUnit);
				SETCHAR(eBasicViewx.Base_Uom,"X");
				SETCHAR(eBasicViewx.Base_Uom_Iso,"X");

				SETCHAR(tBapi_Marm->Alt_Unit,MeasureUnit);
				SETCHAR(tBapi_Marm->Alt_Unit_Iso,MeasureUnit);
				SETCHAR(tBapi_Marmx->Alt_Unit,MeasureUnit);
				SETCHAR(tBapi_Marmx->Alt_Unit_Iso,MeasureUnit);
				SETCHAR(tBapi_Makt->Matl_Desc,PartDescriptionDup);

				SETCHAR(eBasicView.Document,drg_std_no);



				if(strcmp(drg_std_no,"")!=0)
				{
					SETCHAR(eBasicViewx.Document,"");
				}
				else
				{
					SETCHAR(eBasicViewx.Document,"");
				}
				SETCHAR(eBasicView.Doc_Type,drg_std_ind);
				if(strcmp(drg_std_ind,"")!=0)
				{
					SETCHAR(eBasicViewx.Doc_Type,"");
				}
				else
				{
					SETCHAR(eBasicViewx.Doc_Type,"");
				}

				SETCHAR(eBasicView.Doc_Vers,sheet_status);
				if(strcmp(sheet_status,"")!=0)
				{

					SETCHAR(eBasicViewx.Doc_Vers,"");
				}
				else
				{
					SETCHAR(eBasicViewx.Doc_Vers,"");
				}
				SETNUM(eBasicView.No_Sheets,SheetNumberDup);
				SETCHAR(eBasicViewx.No_Sheets,"");

				SETCHAR(eBasicView.Doc_Format,PageFormat);
				SETCHAR(eBasicViewx.Doc_Format,"");


				SETCHAR(eBasicView.Pageformat,"");
				SETCHAR(eBasicViewx.Pageformat,"");

				SETCHAR(eBasicView.Old_Mat_No,schas_type_no);
				SETCHAR(eBasicViewx.Old_Mat_No,"");

				SETBCD(eBasicView.Net_Weight,net_wt,3);
				SETCHAR(eBasicViewx.Net_Weight,"");
				SETBCD(tBapi_Marm->Gross_Wt,gros_wt,3);
				SETCHAR(tBapi_Marmx->Gross_Wt,"");
				SETCHAR(eBasicView.Unit_Of_Wt,"");
				SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
				SETCHAR(eBasicViewx.Unit_Of_Wt,"");
				SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");
				SETCHAR(tBapi_Marm->Unit_Of_Wt,"");
				SETCHAR(tBapi_Marm->Unit_Of_Wt_Iso,"");
				SETCHAR(tBapi_Marmx->Unit_Of_Wt,"");
				SETCHAR(tBapi_Marmx->Unit_Of_Wt_Iso,"");
				SETBCD(tBapi_Marm->Volume,volume,3);
				SETCHAR(tBapi_Marm->VolumeUnit,"");
				SETCHAR(tBapi_Marm->VolumeUnit_Iso,"");
				SETCHAR(tBapi_Marmx->Volume,"");
				SETCHAR(tBapi_Marmx->VolumeUnit,"");
				SETCHAR(tBapi_Marmx->VolumeUnit_Iso,"");

				SETCHAR(eBasicView.Size_Dim,sheet_size);
				SETCHAR(eBasicViewx.Size_Dim,"");

				if(!nlsIsStrNull(MaterialGroupDup))
				{
					SETCHAR(eBasicView.Matl_Group,MaterialGroupDup);
					if(ercDmlflag!=1)
					{
						SETCHAR(eBasicViewx.Matl_Group,"");
					}
					else if(ercDmlflag == 1)  //ERC dml part hence do not update basic view
					{
						SETCHAR(eBasicViewx.Matl_Group,"");
					}
				}
				else
				{
					SETCHAR(eBasicView.Matl_Group,"");
					SETCHAR(eBasicViewx.Matl_Group,"");
				}

				SETCHAR(eBasicView.Division,basic_division);
				SETCHAR(eBasicViewx.Division,"");
				SETCHAR(eBasicView.Item_Cat,"NORM");
				SETCHAR(eBasicViewx.Item_Cat,"");
				SETCHAR(eBapiMatHead.Mrp_View,"X");
				SETCHAR(eBapiMatHead.Purchase_View,"");
				SETCHAR(eMrpView.Mrp_Group,"");
				SETCHAR(eMrpViewx.Mrp_Group,"");
				SETCHAR(eMrpView.Abc_Id,"");
				SETCHAR(eMrpViewx.Abc_Id,"");
				SETCHAR(eMrpView.Pur_Status,"");
				SETCHAR(eMrpViewx.Pur_Status,"");
				SETCHAR(eMrpView.Mrp_Type,mrp_type);
				SETCHAR(eMrpViewx.Mrp_Type,"");
				SETBCD(eMrpView.Reorder_Pt,"",3);
				SETCHAR(eMrpViewx.Reorder_Pt,"");
				SETCHAR(eMrpView.Quotausage,"");
				SETCHAR(eMrpViewx.Quotausage,"");
				SETCHAR(eMrpView.Mrp_Ctrler,"");
				SETCHAR(eMrpViewx.Mrp_Ctrler,"");
				SETCHAR(eMrpView.Lotsizekey,"");
				SETCHAR(eMrpViewx.Lotsizekey,"");
				SETBCD(eMrpView.Fixed_Lot,"",3);
				SETCHAR(eMrpViewx.Fixed_Lot,"");
				SETBCD(eMrpView.Max_Stock,"",3);
				SETCHAR(eMrpViewx.Max_Stock,"");
				SETCHAR(eMrpView.Proc_Type,proc_type);
				SETCHAR(eMrpViewx.Proc_Type,"X");
				SETCHAR(eMrpView.Spproctype,spl_proc_key);
				SETCHAR(eMrpViewx.Spproctype,"X");
				SETCHAR(eMrpView.Bulk_Mat,"");
				SETCHAR(eMrpViewx.Bulk_Mat,"");
				SETCHAR(eMrpView.Sm_Key,"");
				SETCHAR(eMrpViewx.Sm_Key,"");
				SETCHAR(eMrpView.Ppc_Pl_Cal,plan_calendar);
				SETCHAR(eMrpViewx.Ppc_Pl_Cal,"");
				SETCHAR(eMrpView.Grp_Reqmts,"");
				SETCHAR(eMrpViewx.Grp_Reqmts,"");
				SETCHAR(eMrpView.Period_Ind,"");
				SETCHAR(eMrpViewx.Period_Ind,"");
				SETCHAR(eMrpView.Mixed_Mrp,"");
				SETCHAR(eMrpViewx.Mixed_Mrp,"");
				SETCHAR(eMrpView.Availcheck,avail_chk);
				SETCHAR(eMrpViewx.Availcheck,"");
				SETCHAR(eBapi_Mpgd.Plng_Matl,"");
				SETCHAR(eBapi_Mpgdx.Plng_Matl,"");
				SETCHAR(eBapi_Mpgd.Plng_Plant,"");
				SETCHAR(eBapi_Mpgdx.Plng_Plant,"");
				SETCHAR(eBapi_Mpgd.Convfactor,"");
				SETCHAR(eBapi_Mpgdx.Convfactor,"");
				SETCHAR(eMrpView.Alternative_Bom,"");
				SETCHAR(eMrpViewx.Alternative_Bom,"");
				SETCHAR(eMrpView.Dep_Req_Id,"");

				SETCHAR(eMrpViewx.Dep_Req_Id,"");
				SETCHAR(eMrpView.Rep_Manuf,"");
				SETCHAR(eMrpViewx.Rep_Manuf,"");
				SETCHAR(eMrpView.Repmanprof,"");
				SETCHAR(eMrpViewx.Repmanprof,"");
				SETCHAR(eMrpView.Determ_Grp,"");
				SETCHAR(eMrpViewx.Determ_Grp,"");
				SETCHAR(eBapiMatHead.Storage_View,"");
				SETCHAR(eMrpView.Issue_Unit,"");
				SETCHAR(eMrpView.Issue_Unit_Iso,"");
				SETCHAR(eMrpViewx.Issue_Unit,"");
				SETCHAR(eMrpViewx.Issue_Unit_Iso,"");
				SETCHAR(eMrpView.Profit_Ctr,profit_centre);
				SETCHAR(eMrpViewx.Profit_Ctr,"");
				if(strcmp(MatType,"FERT") != 0)
				{
					SETCHAR(eBapiMatHead.Quality_View,"");
					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
					SETCHAR(eMrpView.Doc_Reqd,"");
					SETCHAR(eMrpViewx.Doc_Reqd,"");
					SETBCD(eMrpView.Gr_Pr_Time,"",0);
					SETCHAR(eMrpViewx.Gr_Pr_Time,"");
					SETCHAR(eBasicView.Catprofile,"");
					SETCHAR(eBasicViewx.Catprofile,"");
					SETCHAR(eBasicView.Qm_Procmnt,"");
					SETCHAR(eBasicViewx.Qm_Procmnt,"");
					SETCHAR(eMrpView.Ctrl_Key,"");
					SETCHAR(eMrpViewx.Ctrl_Key,"");
					SETCHAR(eMrpView.Cert_Type,"");
					SETCHAR(eMrpViewx.Cert_Type,"");
				}
				else
				{
					SETCHAR(eBapiMatHead.Quality_View,"");
					SETCHAR(eMrpView.Ind_Post_To_Insp_Stock,"");
					SETCHAR(eMrpViewx.Ind_Post_To_Insp_Stock,"");
					SETCHAR(eMrpView.Doc_Reqd,"");
					SETCHAR(eMrpViewx.Doc_Reqd,"");
					SETBCD(eMrpView.Gr_Pr_Time,"",0);
					SETCHAR(eMrpViewx.Gr_Pr_Time,"");
					SETCHAR(eBasicView.Catprofile,"");
					SETCHAR(eBasicViewx.Catprofile,"");
					SETCHAR(eBasicView.Qm_Procmnt,"");
					SETCHAR(eBasicViewx.Qm_Procmnt,"");
					SETCHAR(eMrpView.Ctrl_Key,"");
					SETCHAR(eMrpViewx.Ctrl_Key,"");
					SETCHAR(eMrpView.Cert_Type,"");
					SETCHAR(eMrpViewx.Cert_Type,"");
				}

				SETCHAR(eBapiMatHead.Account_View,"");
				SETCHAR(eAccView.Val_Cat,"");
				SETCHAR(eAccViewx.Val_Cat,"");
				SETCHAR(eAccView.Val_Class,"");
				SETCHAR(eAccViewx.Val_Class,"");
				SETCHAR(eAccView.Price_Ctrl,"");
				SETCHAR(eAccViewx.Price_Ctrl,"");
				SETBCD(eAccView.Std_Price,"",4);
				SETCHAR(eAccViewx.Std_Price,"");
				SETBCD(eAccView.Moving_Pr,"",4);
				SETCHAR(eAccViewx.Moving_Pr,"");
				SETCHAR(eBapiMatHead.Cost_View,"");
				SETCHAR(eAccView.Mat_Origin,"");
				SETCHAR(eAccViewx.Mat_Origin,"");
				SETCHAR(eAccView.Orig_Group,"");
				SETCHAR(eAccViewx.Orig_Group,"");
				SETBCD(eMrpView.Lot_Size,"",3);
				SETCHAR(eMrpViewx.Lot_Size,"");
				SETCHAR(eAccView.Overhead_Grp,"");
				SETCHAR(eAccViewx.Overhead_Grp,"");
				SETCHAR(eMrpView.Variance_Key,"");
				SETCHAR(eMrpViewx.Variance_Key,"");
				SETCHAR(eAccView.Qty_Struct,"");
				SETCHAR(eAccViewx.Qty_Struct,"");
				SETCHAR(eMrpView.Split_Ind,"");
				SETCHAR(eMrpViewx.Split_Ind,"");

				SETCHAR(eRmmg1_Aennr.Aennr,EEDmlNumber);

				SETCHAR(eBapiMatHead.Sales_View,"");
				SETCHAR(eBapiMatHead.Forecast_View,"");
				SETCHAR(eBapiMatHead.Work_Sched_View,"");
				SETCHAR(eBapiMatHead.Prt_View,"");
				SETCHAR(eBapiMatHead.Warehouse_View,"");

				SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
				SETCHAR(eBapiMatHead.Material_External,"");
				SETCHAR(eBapiMatHead.MateriaL_Guid,"");
				SETCHAR(eBapiMatHead.Material_Version,"");
				SETCHAR(eBasicView.Del_Flag,"");
				SETCHAR(eBasicView.Po_Unit,"");
				SETCHAR(eBasicView.Po_Unit_Iso,"");

				SETCHAR(eBasicView.Doc_Chg_No,"");
				SETCHAR(eBasicView.Page_No,"");

				SETCHAR(eBasicView.Prod_Memo,"");
				SETCHAR(eBasicView.Basic_Matl,"");
				SETCHAR(eBasicView.Std_Descr,"");
				SETCHAR(eBasicView.Dsn_Office,"");
				SETCHAR(eBasicView.Pur_Valkey,"");
				SETCHAR(eBasicView.Container,"");
				SETCHAR(eBasicView.Stor_Conds,"");
				SETCHAR(eBasicView.Temp_Conds,"");
				SETCHAR(eBasicView.Trans_Grp,"");
				SETCHAR(eBasicView.Haz_Mat_No,"");

				SETCHAR(eBasicView.Competitor,"");

				SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);

				SETCHAR(eBasicView.Proc_Rule,"");
				SETCHAR(eBasicView.Sup_Source,"");
				SETCHAR(eBasicView.Season,"");
				SETCHAR(eBasicView.Label_Type,"");
				SETCHAR(eBasicView.Label_Form,"");
				SETCHAR(eBasicView.Prod_Hier,"");

				SETCHAR(eBasicView.Cad_Id,"");

				SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
				SETCHAR(eBasicView.Pack_Wt_Un,"");
				SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
				SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
				SETCHAR(eBasicView.Pack_Vo_Un,"");
				SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
				SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
				SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
				SETCHAR(eBasicView.Var_Ord_Un,"");
				SETCHAR(eBasicView.Batch_Mgmt,"");
				SETCHAR(eBasicView.Sh_Mat_Typ,"");
				SETBCD(eBasicView.Fill_Level,"0",0);
				SETINT2(&eBasicView.Stack_Fact,"0");
				SETCHAR(eBasicView.Mat_Grp_Sm,"");
				SETCHAR(eBasicView.Authoritygroup,"");
				SETBCD(eBasicView.Minremlife,"0",0);
				SETBCD(eBasicView.Shelf_Life,"0",0);
				SETBCD(eBasicView.Stor_Pct,"0",0);
				SETCHAR(eBasicView.Pur_Status,"");
				SETCHAR(eBasicView.Sal_Status,"");
				SETDATE(eBasicView.Pvalidfrom,"");
				SETDATE(eBasicView.Svalidfrom,"");
				SETCHAR(eBasicView.Envt_Rlvt,"");
				SETCHAR(eBasicView.Prod_Alloc,"");
				SETCHAR(eBasicView.Qual_Dik,"");
				SETCHAR(eBasicView.Manu_Mat,"");
				SETCHAR(eBasicView.Mfr_No,"");
				SETCHAR(eBasicView.Inv_Mat_No,"");
				SETCHAR(eBasicView.Manuf_Prof,"");
				SETCHAR(eBasicView.Hazmatprof,"");
				SETCHAR(eBasicView.High_Visc,"");
				SETCHAR(eBasicView.Looseorliq,"");
				SETCHAR(eBasicView.Closed_Box,"");
				SETCHAR(eBasicView.Appd_B_Rec,"");
				SETNUM(eBasicView.Matcmpllvl,"00");
				SETCHAR(eBasicView.Par_Eff,"");
				SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
				SETCHAR(eBasicView.Period_Ind_Expiration_Date,"D");
				SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
				SETCHAR(eBasicView.Haz_Mat_No_External,"");
				SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
				SETCHAR(eBasicView.Haz_Mat_No_Version,"");
				SETCHAR(eBasicView.Inv_Mat_No_External,"");
				SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
				SETCHAR(eBasicView.Inv_Mat_No_Version,"");
				SETCHAR(eBasicView.Material_Fixed,"");
				SETCHAR(eBasicView.Cm_Relevance_Flag,"");
				SETCHAR(eBasicView.Sled_Bbd,"");
				SETCHAR(eBasicView.Gtin_Variant,"");
				SETCHAR(eBasicView.Serialization_Level,"");
				SETCHAR(eBasicView.Pl_Ref_Mat,"");
				SETCHAR(eBasicView.Extmatlgrp,"");
				SETCHAR(eBasicView.Uomusage,"");
				SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
				SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
				SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
				SETCHAR(eBasicViewx.Del_Flag,"");
				SETCHAR(eBasicViewx.Po_Unit,"");
				SETCHAR(eBasicViewx.Po_Unit_Iso,"");

				SETCHAR(eBasicViewx.Doc_Chg_No,"");
				SETCHAR(eBasicViewx.Page_No,"");
				SETCHAR(eBasicViewx.Prod_Memo,"");

				SETCHAR(eBasicViewx.Basic_Matl,"");
				SETCHAR(eBasicViewx.Std_Descr,"");
				SETCHAR(eBasicViewx.Dsn_Office,"");
				SETCHAR(eBasicViewx.Pur_Valkey,"");
				SETCHAR(eBasicViewx.Container,"");
				SETCHAR(eBasicViewx.Stor_Conds,"");
				SETCHAR(eBasicViewx.Temp_Conds,"");
				SETCHAR(eBasicViewx.Trans_Grp,"");
				SETCHAR(eBasicViewx.Haz_Mat_No,"");
				SETCHAR(eBasicViewx.Competitor,"");
				SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
				SETCHAR(eBasicViewx.Proc_Rule,"");
				SETCHAR(eBasicViewx.Sup_Source,"");
				SETCHAR(eBasicViewx.Season,"");
				SETCHAR(eBasicViewx.Label_Type,"");
				SETCHAR(eBasicViewx.Label_Form,"");
				SETCHAR(eBasicViewx.Prod_Hier,"");
				SETCHAR(eBasicViewx.Cad_Id,"");
				SETCHAR(eBasicViewx.Allowed_Wt,"");
				SETCHAR(eBasicViewx.Pack_Wt_Un,"");
				SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
				SETCHAR(eBasicViewx.Allwd_Vol,"");
				SETCHAR(eBasicViewx.Pack_Vo_Un,"");
				SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
				SETCHAR(eBasicViewx.Wt_Tol_Lt,"");
				SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
				SETCHAR(eBasicViewx.Var_Ord_Un,"");
				SETCHAR(eBasicViewx.Batch_Mgmt,"");
				SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
				SETCHAR(eBasicViewx.Fill_Level,"");
				SETCHAR(eBasicViewx.Stack_Fact,"");
				SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
				SETCHAR(eBasicViewx.Authoritygroup,"");
				SETCHAR(eBasicViewx.Minremlife,"");
				SETCHAR(eBasicViewx.Shelf_Life,"");
				SETCHAR(eBasicViewx.Stor_Pct,"");
				SETCHAR(eBasicViewx.Pur_Status,"");
				SETCHAR(eBasicViewx.Sal_Status,"");
				SETCHAR(eBasicViewx.Pvalidfrom,"");
				SETCHAR(eBasicViewx.Svalidfrom,"");
				SETCHAR(eBasicViewx.Envt_Rlvt,"");
				SETCHAR(eBasicViewx.Prod_Alloc,"");
				SETCHAR(eBasicViewx.Qual_Dik,"");
				SETCHAR(eBasicViewx.Manu_Mat,"");
				SETCHAR(eBasicViewx.Mfr_No,"");
				SETCHAR(eBasicViewx.Inv_Mat_No,"");
				SETCHAR(eBasicViewx.Manuf_Prof,"");
				SETCHAR(eBasicViewx.Hazmatprof,"");
				SETCHAR(eBasicViewx.High_Visc,"");
				SETCHAR(eBasicViewx.Looseorliq,"");
				SETCHAR(eBasicViewx.Closed_Box,"");
				SETCHAR(eBasicViewx.Appd_B_Rec,"");
				SETCHAR(eBasicViewx.Matcmpllvl,"");
				SETCHAR(eBasicViewx.Par_Eff,"");
				SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
				SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
				SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
				SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
				SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
				SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
				SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
				SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
				SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
				SETCHAR(eBasicViewx.Material_Fixed,"");
				SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
				SETCHAR(eBasicViewx.Sled_Bbd,"");
				SETCHAR(eBasicViewx.Gtin_Variant,"");
				SETCHAR(eBasicViewx.Serialization_Level,"");
				SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
				SETCHAR(eBasicViewx.Extmatlgrp,"");
				SETCHAR(eBasicViewx.Uomusage,"");
				SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
				SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
				SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
				SETCHAR(eMrpView.Plant,"1005");
				SETCHAR(eMrpView.Del_Flag,"");
				SETCHAR(eMrpView.Crit_Part,"");
				SETCHAR(eMrpView.Pur_Group,"");
				SETCHAR(eMrpView.Mrpprofile,"");
				SETCHAR(eMrpView.Plnd_Delry,"0");
				SETBCD(eMrpView.Assy_Scrap,myzeroDup2,2);
				SETBCD(eMrpView.Safety_Stk,myzeroDup3,3);
				SETBCD(eMrpView.Minlotsize,myzeroDup3,3);
				SETBCD(eMrpView.Maxlotsize,myzeroDup3,3);
				SETBCD(eMrpView.Round_Val,myzeroDup3,3);
				SETBCD(eMrpView.Ord_Costs,myzeroDup4,4);
				SETCHAR(eMrpView.Stor_Costs,"");
				SETCHAR(eMrpView.Alt_Bom_Id,"");
				SETCHAR(eMrpView.Discontinu,"");
				SETCHAR(eMrpView.Eff_O_Day,"");
				SETCHAR(eMrpView.Follow_Up,"");
				SETCHAR(eMrpView.Backflush,"");
				SETCHAR(eMrpView.Production_Scheduler,"");
				SETBCD(eMrpView.Proc_Time,myzeroDup2,2);
				SETBCD(eMrpView.Setuptime,myzeroDup2,2);
				SETBCD(eMrpView.Interop,myzeroDup2,2);
				SETBCD(eMrpView.Base_Qty,myzeroDup3,3);
				SETBCD(eMrpView.Inhseprodt,"0",0);
				SETBCD(eMrpView.Stgeperiod,"0",0);
				SETCHAR(eMrpView.Stge_Pd_Un,"");
				SETCHAR(eMrpView.Stge_Pd_Un_Iso,"");
				SETBCD(eMrpView.Over_Tol,myzeroDup1,1);
				SETCHAR(eMrpView.Unlimited,"");
				SETBCD(eMrpView.Under_Tol,myzeroDup1,1);
				SETBCD(eMrpView.Replentime,"0",0);
				SETCHAR(eMrpView.Replace_Pt,"");
				SETCHAR(eMrpView.Loadinggrp,"");
				SETCHAR(eMrpView.Batch_Mgmt,"");
				SETBCD(eMrpView.Serv_Level,myzeroDup1,1);
				SETCHAR(eMrpView.Fy_Variant,"");
				SETCHAR(eMrpView.Corr_Fact,"");
				SETBCD(eMrpView.Setup_Time,myzeroDup2,2);
				SETBCD(eMrpView.Base_Qty_Plan,myzeroDup3,3);
				SETBCD(eMrpView.Ship_Proc_Time,myzeroDup2,2);
				SETCHAR(eMrpView.Sup_Source,"");
				SETCHAR(eMrpView.Auto_P_Ord,"");
				SETCHAR(eMrpView.Sourcelist,"");
				SETCHAR(eMrpView.Comm_Code,"");
				SETCHAR(eMrpView.Countryori,"");
				SETCHAR(eMrpView.Countryori_Iso,"");
				SETCHAR(eMrpView.Regionorig,"");
				SETCHAR(eMrpView.Comm_Co_Un,"");
				SETCHAR(eMrpView.Comm_Co_Un_Iso,"");
				SETCHAR(eMrpView.Expimpgrp,"");
				SETNUM(eMrpView.Pl_Ti_Fnce,"000");
				SETCHAR(eMrpView.Consummode,"");
				SETNUM(eMrpView.Bwd_Cons,"000");
				SETNUM(eMrpView.Fwd_Cons,"000");
				SETCHAR(eMrpView.Bom_Usage,"");
				SETCHAR(eMrpView.Planlistgrp,"");
				SETCHAR(eMrpView.Planlistcnt,"");
				SETCHAR(eMrpView.Specprocty,"");
				SETCHAR(eMrpView.Prod_Unit,"");
				SETCHAR(eMrpView.Prod_Unit_Iso,"");
				SETCHAR(eMrpView.Iss_St_Loc,"");
				SETBCD(eMrpView.Comp_Scrap,myzeroDup2,2);
				SETBCD(eMrpView.Cycle_Time,"0",0);
				SETCHAR(eMrpView.Covprofile,"");
				SETCHAR(eMrpView.Cc_Ph_Inv,"");
				SETCHAR(eMrpView.Serno_Prof,"");
				SETCHAR(eMrpView.Neg_Stocks,"");
				SETCHAR(eMrpView.Qm_Rgmts,"");
				SETCHAR(eMrpView.Plng_Cycle,"");
				SETCHAR(eMrpView.Round_Prof,"");
				SETCHAR(eMrpView.Refmatcons,"");
				SETCHAR(eMrpView.D_To_Ref_M,"");
				SETBCD(eMrpView.Mult_Ref_M,myzeroDup2,2);
				SETCHAR(eMrpView.Auto_Reset,"");
				SETCHAR(eMrpView.Ex_Cert_Id,"");
				SETCHAR(eMrpView.Ex_Cert_No_New,"");
				SETCHAR(eMrpView.Ex_Cert_Dt,"");
				SETCHAR(eMrpView.Milit_Id,"");
				SETBCD(eMrpView.Insp_Int,"0",0);
				SETCHAR(eMrpView.Co_Product,"");
				SETCHAR(eMrpView.Plan_Strgp,"");
				SETCHAR(eMrpView.Sloc_Exprc,"");
				SETCHAR(eMrpView.Cc_Fixed,"");
				SETCHAR(eMrpView.Qm_Authgrp,"");
				SETCHAR(eMrpView.Task_List_Type,"");
				SETCHAR(eMrpView.Prodprof,"");
				SETCHAR(eMrpView.Safty_T_Id,"");
				SETNUM(eMrpView.Safetytime,"00");
				SETCHAR(eMrpView.Plord_Ctrl,"");
				SETCHAR(eMrpView.Batchentry,"");
				SETDATE(eMrpView.Pvalidfrom,"");
				SETCHAR(eMrpView.Matfrgtgrp,"");
				SETCHAR(eMrpView.Prodverscs,"");
				SETCHAR(eMrpView.Mat_Cfop,"");
				SETCHAR(eMrpView.Eu_List_No,"");
				SETCHAR(eMrpView.Eu_Mat_Grp,"");
				SETCHAR(eMrpView.Cas_No,"");
				SETCHAR(eMrpView.Prodcom_No,"");
				SETCHAR(eMrpView.Ctrl_Code,"");
				SETCHAR(eMrpView.Jit_Relvt,"");
				SETCHAR(eMrpView.Mat_Grp_Trans,"");
				SETCHAR(eMrpView.Handlg_Grp,"");
				SETCHAR(eMrpView.Supply_Area,"");
				SETCHAR(eMrpView.Fair_Share_Rule,"");
				SETCHAR(eMrpView.Push_Distrib,"");
				SETBCD(eMrpView.Deploy_Horiz,"0",0);
				SETBCD(eMrpView.Min_Lot_Size,myzeroDup3,3);
				SETBCD(eMrpView.Max_Lot_Size,myzeroDup3,3);
				SETBCD(eMrpView.Fix_Lot_Size,myzeroDup3,3);
				SETBCD(eMrpView.Lot_Increment,myzeroDup3,3);
				SETCHAR(eMrpView.Prod_Conv_Type,"");
				SETCHAR(eMrpView.Distr_Prof,"");
				SETCHAR(eMrpView.Period_Profile_Safety_Time,"");
				SETCHAR(eMrpView.Fxd_Price,"");
				SETCHAR(eMrpView.Avail_Check_All_Proj_Segments,"");
				SETCHAR(eMrpView.Overallprf,"");
				SETCHAR(eMrpView.Mrp_Relevancy_Dep_Requirements,"");
				SETBCD(eMrpView.Min_Safety_Stk,myzeroDup2,2);
				SETCHAR(eMrpView.No_Costing,"");
				SETCHAR(eMrpView.Unit_Group,"");
				SETCHAR(eMrpView.Follow_Up_External,"");
				SETCHAR(eMrpView.Follow_Up_Guid,"");
				SETCHAR(eMrpView.Follow_Up_Version,"");
				SETCHAR(eMrpView.Refmatcons_External,"");
				SETCHAR(eMrpView.Refmatcons_Guid,"");
				SETCHAR(eMrpView.Refmatcons_Version,"");
				SETCHAR(eMrpView.Rotation_Date,"");
				SETCHAR(eMrpView.Original_Batch_Flag,"");
				SETCHAR(eMrpView.Original_Batch_Ref_Material,"");
				SETCHAR(eMrpView.Original_Batch_Ref_Material_E,"");
				SETCHAR(eMrpView.Original_Batch_Ref_Material_V,"");
				SETCHAR(eMrpView.Original_Batch_Ref_Material_G,"");
				SETCHAR(eMrpViewx.Plant,"1005");
				SETCHAR(eMrpViewx.Del_Flag,"");
				SETCHAR(eMrpViewx.Crit_Part,"");
				SETCHAR(eMrpViewx.Pur_Group,"");
				SETCHAR(eMrpViewx.Mrpprofile,"");
				SETCHAR(eMrpViewx.Plnd_Delry,"");
				SETCHAR(eMrpViewx.Assy_Scrap,"");
				SETCHAR(eMrpViewx.Safety_Stk,"");
				SETCHAR(eMrpViewx.Minlotsize,"");
				SETCHAR(eMrpViewx.Maxlotsize,"");
				SETCHAR(eMrpViewx.Round_Val,"");
				SETCHAR(eMrpViewx.Ord_Costs,"");
				SETCHAR(eMrpViewx.Stor_Costs,"");
				SETCHAR(eMrpViewx.Alt_Bom_Id,"");
				SETCHAR(eMrpViewx.Discontinu,"");
				SETCHAR(eMrpViewx.Eff_O_Day,"");
				SETCHAR(eMrpViewx.Follow_Up,"");
				SETCHAR(eMrpViewx.Backflush,"");
				SETCHAR(eMrpViewx.Production_Scheduler,"");
				SETCHAR(eMrpViewx.Proc_Time,"");
				SETCHAR(eMrpViewx.Setuptime,"");
				SETCHAR(eMrpViewx.Interop,"");
				SETCHAR(eMrpViewx.Base_Qty,"");
				SETCHAR(eMrpViewx.Inhseprodt,"");
				SETCHAR(eMrpViewx.Stgeperiod,"");
				SETCHAR(eMrpViewx.Stge_Pd_Un,"");
				SETCHAR(eMrpViewx.Stge_Pd_Un_Iso,"");
				SETCHAR(eMrpViewx.Over_Tol,"");
				SETCHAR(eMrpViewx.Unlimited,"");
				SETCHAR(eMrpViewx.Under_Tol,"");
				SETCHAR(eMrpViewx.Replentime,"");
				SETCHAR(eMrpViewx.Replace_Pt,"");
				SETCHAR(eMrpViewx.Loadinggrp,"");
				SETCHAR(eMrpViewx.Batch_Mgmt,"");
				SETCHAR(eMrpViewx.Serv_Level,"");
				SETCHAR(eMrpViewx.Fy_Variant,"");
				SETCHAR(eMrpViewx.Corr_Fact,"");
				SETCHAR(eMrpViewx.Setup_Time,"");
				SETCHAR(eMrpViewx.Base_Qty_Plan,"");
				SETCHAR(eMrpViewx.Ship_Proc_Time,"");
				SETCHAR(eMrpViewx.Sup_Source,"");
				SETCHAR(eMrpViewx.Auto_P_Ord,"");
				SETCHAR(eMrpViewx.Sourcelist,"");
				SETCHAR(eMrpViewx.Comm_Code,"");
				SETCHAR(eMrpViewx.Countryori,"");
				SETCHAR(eMrpViewx.Countryori_Iso,"");
				SETCHAR(eMrpViewx.Regionorig,"");
				SETCHAR(eMrpViewx.Comm_Co_Un,"");
				SETCHAR(eMrpViewx.Comm_Co_Un_Iso,"");
				SETCHAR(eMrpViewx.Expimpgrp,"");
				SETCHAR(eMrpViewx.Pl_Ti_Fncve,"");
				SETCHAR(eMrpViewx.Consummode,"");
				SETCHAR(eMrpViewx.Bwd_Cons,"");
				SETCHAR(eMrpViewx.Fwd_Cons,"");
				SETCHAR(eMrpViewx.Bom_Usage,"");
				SETCHAR(eMrpViewx.Planlistgrp,"");
				SETCHAR(eMrpViewx.Planlistcnt,"");
				SETCHAR(eMrpViewx.Specprocty,"");
				SETCHAR(eMrpViewx.Prod_Unit,"");
				SETCHAR(eMrpViewx.Prod_Unit_Iso,"");
				SETCHAR(eMrpViewx.Iss_St_Loc,"");
				SETCHAR(eMrpViewx.Comp_Scrap,"");
				SETCHAR(eMrpViewx.Cycle_Time,"");
				SETCHAR(eMrpViewx.Covprofile,"");
				SETCHAR(eMrpViewx.Cc_Ph_Inv,"");
				SETCHAR(eMrpViewx.Serno_Prof,"");
				SETCHAR(eMrpViewx.Neg_Stocks,"");
				SETCHAR(eMrpViewx.Qm_Rgmts,"");
				SETCHAR(eMrpViewx.Plng_Cycle,"");
				SETCHAR(eMrpViewx.Round_Prof,"");
				SETCHAR(eMrpViewx.Refmatcons,"");
				SETCHAR(eMrpViewx.D_To_Ref_M,"");
				SETCHAR(eMrpViewx.Mult_Ref_M,"");
				SETCHAR(eMrpViewx.Auto_Reset,"");
				SETCHAR(eMrpViewx.Ex_Cert_Id,"");
				SETCHAR(eMrpViewx.Ex_Cert_No_New,"");
				SETCHAR(eMrpViewx.Ex_Cert_Dt,"");
				SETCHAR(eMrpViewx.Milit_Id,"");
				SETCHAR(eMrpViewx.Insp_Int,"");
				SETCHAR(eMrpViewx.Co_Product,"");
				SETCHAR(eMrpViewx.Plan_Strgp,"");
				SETCHAR(eMrpViewx.Sloc_Exprc,"");
				SETCHAR(eMrpViewx.Cc_Fixed,"");
				SETCHAR(eMrpViewx.Qm_Authgrp,"");
				SETCHAR(eMrpViewx.Task_List_Type,"");
				SETCHAR(eMrpViewx.Prodprof,"");
				SETCHAR(eMrpViewx.Safty_T_Id,"");
				SETCHAR(eMrpViewx.Safetytime,"");
				SETCHAR(eMrpViewx.Plord_Ctrl,"");
				SETCHAR(eMrpViewx.Batchentry,"");
				SETCHAR(eMrpViewx.Pvalidfrom,"");
				SETCHAR(eMrpViewx.Matfrgtgrp,"");
				SETCHAR(eMrpViewx.Prodverscs,"");
				SETCHAR(eMrpViewx.Mat_Cfop,"");
				SETCHAR(eMrpViewx.Eu_List_No,"");
				SETCHAR(eMrpViewx.Eu_Mat_Grp,"");
				SETCHAR(eMrpViewx.Cas_No,"");
				SETCHAR(eMrpViewx.Prodcom_No,"");
				SETCHAR(eMrpViewx.Ctrl_Code,"");
				SETCHAR(eMrpViewx.Jit_Relvt,"");
				SETCHAR(eMrpViewx.Mat_Grp_Trans,"");
				SETCHAR(eMrpViewx.Handlg_Grp,"");
				SETCHAR(eMrpViewx.Supply_Area,"");
				SETCHAR(eMrpViewx.Fair_Share_Rule,"");
				SETCHAR(eMrpViewx.Push_Distrib,"");
				SETCHAR(eMrpViewx.Deploy_Horiz,"");
				SETCHAR(eMrpViewx.Min_Lot_Size,"");
				SETCHAR(eMrpViewx.Max_Lot_Size,"");
				SETCHAR(eMrpViewx.Fix_Lot_Size,"");
				SETCHAR(eMrpViewx.Lot_Increment,"");
				SETCHAR(eMrpViewx.Prod_Conv_Type,"");
				SETCHAR(eMrpViewx.Distr_Prof,"");
				SETCHAR(eMrpViewx.Period_Profile_Safety_Time,"");
				SETCHAR(eMrpViewx.Fxd_Price,"");
				SETCHAR(eMrpViewx.Avail_Check_All_Proj_Segments,"");
				SETCHAR(eMrpViewx.Overallprf,"");
				SETCHAR(eMrpViewx.Mrp_Relevancy_Dep_Requirements,"");
				SETCHAR(eMrpViewx.Min_Safety_Stk,"");
				SETCHAR(eMrpViewx.No_Costing,"");
				SETCHAR(eMrpViewx.Unit_Group,"");
				SETCHAR(eMrpViewx.Follow_Up_External,"");
				SETCHAR(eMrpViewx.Follow_Up_Guid,"");
				SETCHAR(eMrpViewx.Follow_Up_Version,"");
				SETCHAR(eMrpViewx.Refmatcons_External,"");
				SETCHAR(eMrpViewx.Refmatcons_Guid,"");
				SETCHAR(eMrpViewx.Refmatcons_Version,"");
				SETCHAR(eMrpViewx.Rotation_Date,"");
				SETCHAR(eMrpViewx.Original_Batch_Flag,"");
				SETCHAR(eMrpViewx.Original_Batch_Ref_Material,"");
				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_E,"");
				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_V,"");
				SETCHAR(eMrpViewx.Original_Batch_Ref_Material_G,"");


				SETCHAR(eBapi_Mpgd.Plant,"1005");
				SETCHAR(eBapi_Mpgd.Plng_Matl_External,"");
				SETCHAR(eBapi_Mpgd.Plng_Matl_Guid,"");
				SETCHAR(eBapi_Mpgd.Plng_Matl_Version,"");
				SETCHAR(eBapi_Mpgdx.Plant,"1005");
				SETCHAR(eBapi_Mpgdx.Plng_Matl_External,"");
				SETCHAR(eBapi_Mpgdx.Plng_Matl_Guid,"");
				SETCHAR(eBapi_Mpgdx.Plng_Matl_Version,"");

				SETCHAR(eBapi_Mard.Plant,"1005");
				SETCHAR(eBapi_Mard.Stge_Loc,"ED03");
				SETCHAR(eBapi_Mard.Del_Flag,"");
				SETCHAR(eBapi_Mard.Mrp_Ind,"");
				SETCHAR(eBapi_Mard.Spec_Proc,"");
				SETBCD(eBapi_Mard.Reorder_Pt,myzeroDup3,3);
				SETBCD(eBapi_Mard.Repl_Qty,myzeroDup3,3);
				SETCHAR(eBapi_Mard.Stge_Bin,"");
				SETCHAR(eBapi_Mard.Pickg_Area,"");
				SETFLOAT(&eBapi_Mard.Inv_Corr_Fac,"");
				SETCHAR(eBapi_Mardx.Plant,"1005");
				SETCHAR(eBapi_Mardx.Stge_Loc,"ED03");
				SETCHAR(eBapi_Mardx.Del_Flag,"");
				SETCHAR(eBapi_Mardx.Mrp_Ind,"");
				SETCHAR(eBapi_Mardx.Spec_Proc,"");
				SETCHAR(eBapi_Mardx.Reorder_Pt,"");
				SETCHAR(eBapi_Mardx.Repl_Qty,"");
				SETCHAR(eBapi_Mardx.Stge_Bin,"");
				SETCHAR(eBapi_Mardx.Pickg_Area,"");
				SETCHAR(eBapi_Mardx.Inv_Corr_Fac,"");

				SETCHAR(eAccView.Val_Area,"1005");
				SETCHAR(eAccView.Val_Type,"");
				SETCHAR(eAccView.Del_Flag,"");
				SETBCD(eAccView.Price_Unit,"",0);
				SETCHAR(eAccView.Pr_Ctrl_Pp,"");
				SETBCD(eAccView.Mov_Pr_Pp,myzeroDup4,4);
				SETBCD(eAccView.Std_Pr_Pp,myzeroDup4,4);
				SETBCD(eAccView.Pr_Unit_Pp,"0",1);
				SETCHAR(eAccView.Vclass_Pp,"");
				SETCHAR(eAccView.Pr_Ctrl_Py,"");
				SETBCD(eAccView.Mov_Pr_Py,myzeroDup4,4);
				SETBCD(eAccView.Std_Pr_Py,myzeroDup4,4);
				SETCHAR(eAccView.Vclass_Py,"");
				SETBCD(eAccView.Pr_Unit_Py,"0",0);
				SETBCD(eAccView.Future_Pr,myzeroDup4,4);
				SETDATE(eAccView.Valid_From,"");

				SETBCD(eAccView.Taxprice_1,myzeroDup4,4);
				SETBCD(eAccView.Commprice1,myzeroDup4,4);
				SETBCD(eAccView.Taxprice_3,myzeroDup4,4);
				SETBCD(eAccView.Commprice3,myzeroDup4,4);
				SETBCD(eAccView.Plnd_Price,myzeroDup4,4);
				SETBCD(eAccView.Plndprice1,myzeroDup4,4);
				SETBCD(eAccView.Plndprice2,myzeroDup4,4);
				SETBCD(eAccView.Plndprice3,myzeroDup4,4);
				SETDATE(eAccView.Plndprdate1,"");
				SETDATE(eAccView.Plndprdate2,"");
				SETDATE(eAccView.Plndprdate3,"");
				SETCHAR(eAccView.Lifo_Fifo,"");
				SETCHAR(eAccView.Poolnumber,"");
				SETBCD(eAccView.Taxprice_2,myzeroDup4,4);
				SETBCD(eAccView.Commprice2,myzeroDup4,4);
				SETNUM(eAccView.Deval_Ind,"00");
				SETCHAR(eAccView.Ml_Active,"");
				SETCHAR(eAccView.Ml_Settle,"");
				SETCHAR(eAccView.Orig_Mat,"");
				SETCHAR(eAccView.Vm_So_Stk,"");
				SETCHAR(eAccView.Vm_P_Stock,"");
				SETCHAR(eAccView.Matl_Usage,"");
				SETCHAR(eAccView.In_House,"");
				SETBCD(eAccView.Tax_Cml_Un,"0",0);
				SETCHAR(eAccViewx.Val_Area,"1005");
				SETCHAR(eAccViewx.Val_Type,"");
				SETCHAR(eAccViewx.Del_Flag,"");
				SETCHAR(eAccViewx.Price_Unit,"");
				SETCHAR(eAccViewx.Pr_Ctrl_Pp,"");
				SETCHAR(eAccViewx.Mov_Pr_Pp,"");
				SETCHAR(eAccViewx.Std_Pr_Pp,"");
				SETCHAR(eAccViewx.Pr_Unit_Pp,"");
				SETCHAR(eAccViewx.Vclass_Pp,"");
				SETCHAR(eAccViewx.Pr_Ctrl_Py,"");
				SETCHAR(eAccViewx.Mov_Pr_Py,"");
				SETCHAR(eAccViewx.Std_Pr_Py,"");
				SETCHAR(eAccViewx.Vclass_Py,"");
				SETCHAR(eAccViewx.Pr_Unit_Py,"");
				SETCHAR(eAccViewx.Future_Pr,"");
				SETCHAR(eAccViewx.Valid_From,"");
				SETCHAR(eAccViewx.Taxprice_1,"");
				SETCHAR(eAccViewx.Commprice1,"");
				SETCHAR(eAccViewx.Taxprice_3,"");
				SETCHAR(eAccViewx.Commprice3,"");
				SETCHAR(eAccViewx.Plnd_Price,"");
				SETCHAR(eAccViewx.Plndprice1,"");
				SETCHAR(eAccViewx.Plndprice2,"");
				SETCHAR(eAccViewx.Plndprice3,"");
				SETCHAR(eAccViewx.Plndprdate1,"");
				SETCHAR(eAccViewx.Plndprdate2,"");
				SETCHAR(eAccViewx.Plndprdate3,"");
				SETCHAR(eAccViewx.Lifo_Fifo,"");
				SETCHAR(eAccViewx.Poolnumber,"");
				SETCHAR(eAccViewx.Taxprice_2,"");
				SETCHAR(eAccViewx.Commprice2,"");
				SETCHAR(eAccViewx.Deval_Ind,"");
				SETCHAR(eAccViewx.Ml_Active,"");
				SETCHAR(eAccViewx.Ml_Settle,"");
				SETCHAR(eAccViewx.Orig_Mat,"");
				SETCHAR(eAccViewx.Vm_So_Stk,"");
				SETCHAR(eAccViewx.Vm_P_Stock,"");
				SETCHAR(eAccViewx.Matl_Usage,"");
				SETCHAR(eAccViewx.In_House,"");
				SETCHAR(eAccViewx.Tax_Cml_Un,"");

				SETCHAR(tBapi_Makt->Langu,"EN");
				SETCHAR(tBapi_Makt->Langu_Iso,"EN");
				SETCHAR(tBapi_Makt->Del_Flag,"");
				SETBCD(tBapi_Marm->Numerator,"1",0);
				SETBCD(tBapi_Marm->Denominatr,"1",0);
				SETCHAR(tBapi_Marm->Ean_Upc,"");
				SETCHAR(tBapi_Marm->Ean_Cat,"");
				SETCHAR(tBapi_Marm->Length,"");
				SETCHAR(tBapi_Marm->Width,"");
				SETCHAR(tBapi_Marm->Height,"");
				SETCHAR(tBapi_Marm->Unit_Dim,"");
				SETCHAR(tBapi_Marm->Unit_Dim_Iso,"");
				SETCHAR(tBapi_Marm->Del_Flag,"");
				SETCHAR(tBapi_Marm->Sub_Uom,"");
				SETCHAR(tBapi_Marm->Sub_Uom_Iso,"");
				SETCHAR(tBapi_Marm->Gtin_Variant,"");
				SETCHAR(tBapi_Marmx->Numerator,"");
				SETCHAR(tBapi_Marmx->Denominatr,"");
				SETCHAR(tBapi_Marmx->Ean_Upc,"");
				SETCHAR(tBapi_Marmx->Ean_Cat,"");
				SETCHAR(tBapi_Marmx->Length,"");
				SETCHAR(tBapi_Marmx->Width,"");
				SETCHAR(tBapi_Marmx->Height,"");
				SETCHAR(tBapi_Marmx->Unit_Dim,"");
				SETCHAR(tBapi_Marmx->Unit_Dim_Iso,"");
				SETCHAR(tBapi_Marmx->Sub_Uom,"");
				SETCHAR(tBapi_Marmx->Sub_Uom_Iso,"");
				SETCHAR(tBapi_Marmx->Gtin_Variant,"");


				RfcRc = zbapi_material_savedata_mrp(hRfc,&eBapiMatHead,&eBasicView,&eBasicViewx,&eMrpView,&eMrpViewx,&eBapi_Mpgd,&eBapi_Mpgdx,&eBapi_Mard,&eBapi_Mardx,&eAccView,&eAccViewx,&eRmmg1_Aennr,&eBapiret2,thBapi_Makt,thBapi_Marm,thBapi_Marmx,xException);

				switch (RfcRc)
				{
					case RFC_OK :
						printf("\nMessage Material Change [%s]:[%s]",PartNumberDup,eBapiret2.Message);
						fprintf(fsuccess,"\nMessage Material Change [%s]:[%s]",PartNumberDup,eBapiret2.Message);
					break;
					case RFC_EXCEPTION :
						printf("\nRFC EXCEPTION:-%s",xException);
					break;
					case RFC_SYS_EXCEPTION :
						printf("\nSYSTEM EXCEPTION RAISED");
					break;
					case RFC_FAILURE :
						printf("\nFAILURE");
					break;
					default :
						printf("\nOTHER FAILURE");
				}
				if (ItDelete(thBapi_Makt) != 0)
					printf("\nItDelete thBapi_Makt");
				if (ItDelete(thBapi_Marm) != 0)
					printf("\nItDelete tBapi_Marm");
				if (ItDelete(thBapi_Marmx) != 0)
					printf("\nItDelete thBapi_Marmx");
				RfcClose(hRfc);

				if(!nlsIsStrNull(sheet_status))
				{
					BapiRevcr(EEDmlNumber,PartNumberDup,sheet_status);
				}
				go_for_rfc = 1;


			}
			else
			{
				printf("\nMessage for Material Create:Material %s need to create in plant 1005\n",PartNumberDup);
				fprintf(fsuccess,"\nMessage for Material Create:Material %s need to create in plant 1005\n",PartNumberDup);
			}

		}

	}
	CLEANUP:
		if(latestDocs)
		{
			objDisposeAll(latestDocs);
		}
		latestDocs = NULL;
		if(latestRelDocs)
		{
			objDisposeAll(latestRelDocs);
		}
		latestRelDocs = NULL;

		if(latestRefDocs)
		{
			objDisposeAll(latestRefDocs);
		}
		latestRefDocs = NULL;
		if(latestRelRefDocs)
		{
			objDisposeAll(latestRelRefDocs);
		}
		latestRelRefDocs = NULL;
		return 0;
}

*/


int main(int argc, char *argv[])
{
	status dstat = OKAY;
	int stat = 0;
	int mfail = OKAY;

	SetOfObjects DmlObjs = NULL;
	SetOfObjects taskObjs = NULL;
	SetOfObjects taskRevObjs = NULL;
	SetOfObjects PartObjs = NULL;
	SetOfObjects TmpPartObjs = NULL;
	SqlPtr sql = NULL;
	SqlPtr sqlPtr = NULL;
	SqlPtr sql1 = NULL;
	string taskId = NULL;
	string taskIdDup = NULL;
	string PartNumber = NULL;
	string PartNumberDup = NULL;
	string returnLotNo = NULL;
	string VehiclePartNumber = NULL;
	string BaseVcDescription = NULL;
	string schas_type_no = NULL;
	SetOfStrings StoreShopValuesMat = NULL;
	ObjectPtr AssemblyPtr = NULL;
	ObjectPtr genContextObjOP = NULL;
	ObjectPtr contextObjOP = NULL;
	SetOfObjects soChildParts = NULL;
	SetOfObjects soChildPartsRels = NULL;
	SetOfObjects rpartObjs = NULL;
	ObjectPtr ObjChildPart = NULL;
	ObjectPtr ObjChildRelPart = NULL;
	string ChildPartNumber = NULL;
	string ChildPartNumberDup = NULL;
	int noOfChildParts = 0;
	int noOfTasks = 0;
	int noOfParts = 0;
	string StoreShopAssy = NULL;
		string Quantity = NULL;
	string QuantityDup = NULL;
	string QuantityReqInfo = NULL;
	string QuantityReqInfoDup = NULL;
	string MakeBuyIndicator = NULL;
	string ChildProjectCode = NULL;
	string ChildProjectCodeDup = NULL;
	string MakeBuyInd = NULL;
	string MakeBuyIndDup = NULL;
	string AssyPartNumber = NULL;
	string AssyPartNumberDup = NULL;
	int nCount = 0;
	int partflag = 0;
	string RefPartclass = NULL;
	string RefPartclassDup = NULL;
	char EEPartThreeDigit[4]={0};
	sSAPServer = nlsStrAlloc(10);


	if (dstat = clInitMB2 (argc, &argv, NULL))goto EXIT;
	if (dstat = clTestNetwork ())goto EXIT;
	if (dstat = clInitialize2 (FALSE))goto EXIT;
	if (dstat = clLogin2 ("Loader", "123loader", &stat)) goto EXIT;
	if (dstat = OpenStartupPrefs("StuPref",&mfail));

	nlsStrCpy(InputDmlOrPart,argv[1]);
	nlsStrCpy(sSAPServer,argv[2]);

	returnLotNo = nlsStrAlloc(7);
	VehiclePartNumber = nlsStrAlloc(18);
	StoreShopAssy = nlsStrAlloc(18);
	BaseVcDescription = nlsStrAlloc(41);
	schas_type_no = nlsStrAlloc(18);
	StoreShopValuesMat = low_set_create_str(500);
	MakeBuyIndicator = nlsStrAlloc(4);

	nlsStrCpy(MakeBuyIndicator,"t5PunMakeBuyIndicator");

		nlsStrCpy(returnLotNo,"");
	nlsStrCpy(VehiclePartNumber,"");
	nlsStrCpy(schas_type_no,"");
	sprintf(fgen_filename,"%s/PLMSAP/EEDMLLOGDIR/EEDml_%s_%s.log",getenv("ONLREP"),InputDmlOrPart,sSAPServer);
	//sprintf(fgen_filename,"EEDml_%s.log",InputDmlOrPart);

	if(argc!=3)
	{
		printf("\nEnter Dml Number");
		fprintf(fsuccess,"\nEnter Dml Number");
		exit(0);
	}



	if(
		(dstat = oiSqlCreateSelect(&sql)) ||
		(dstat = oiSqlWhereEQ(sql,"WbsID",InputDmlOrPart))||
		/*(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereBegParen(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDResc")) ||
		(dstat = oiSqlWhereOR(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDRlzd")) ||
		(dstat = oiSqlWhereEndParen(sql)) ||
		(dstat = oiSqlWhereAND(sql))||
		(dstat = oiSqlWhereEQ(sql,"OwnerName","Release Vault")) ||*/
		/*(dstat = QueryWhere("CmChNtIt",sql,&DmlObjs,&mfail))*/
		(dstat = QueryWhere("t5EeECN",sql,&DmlObjs,&mfail))
	)goto CLEANUP;
	if(setSize(DmlObjs) > 0)
	{
		/*E1 dml flag*/
		ercDmlflag = 0;
	}

if(setSize(DmlObjs) <= 0)
	{
		if(
			(dstat = oiSqlCreateSelect(&sql)) ||
			(dstat = oiSqlWhereEQ(sql,"WbsID",InputDmlOrPart))||
			(dstat = oiSqlWhereAND(sql))||
			(dstat = oiSqlWhereBegParen(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","TPL")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","ECU")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","TK")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","PR")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","CQ")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","PPR")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","BEC")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","D")) ||
			(dstat = oiSqlWhereOR(sql))||
			(dstat = oiSqlWhereEQ(sql,"t5DmlType","K")) || //as per discussion with Renuka Kit and spare part release dml handled on 26-apr-2019
			(dstat = oiSqlWhereEndParen(sql)) ||
			(dstat = oiSqlWhereAND(sql))||
			(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsErcRlzd")) ||
			(dstat = oiSqlWhereAND(sql))||
			(dstat = oiSqlWhereEQ(sql,"OwnerName","Release Vault")) ||
			(dstat = QueryWhere("CmChRqIt",sql,&DmlObjs,&mfail))
		)goto CLEANUP;
		if(setSize(DmlObjs) > 0)
		{
			ercDmlflag = 1;
		}

	}

	printf("\nEEDmlNumber:[%s]",InputDmlOrPart);
	fsuccess = fopen(fgen_filename,"a");
	printf("\nDmlObject Found:[%d]",setSize(DmlObjs));
	fprintf(fsuccess,"\nDmlObject Found:[%d]",setSize(DmlObjs));
	if(setSize(DmlObjs)>0)
	{
		printf("\nchange no create");
		TmpPartObjs = set_create(1);
		cll_ccap_ecn_create(DmlObjs,NULL);
		cll_ccap_ecn_createST(DmlObjs,NULL);
	}

	if(setSize(DmlObjs) == 0)
	{
		printf("\nNo DML Found in DataBase");
		fprintf(fsuccess,"\nNo DML Found in DataBase");

		if (PartObjs)
		{
			objDisposeAll(PartObjs);
			PartObjs  = NULL;
		}
		PartObjs = set_create(2);

		if (
				(dstat = oiSqlCreateSelect(&sql)) ||
				(dstat = oiSqlWhereBegParen(sql)) ||
				(dstat = oiSqlWhereEQ(sql,"PartNumber",InputDmlOrPart)) ||

			    (dstat = oiSqlWhereAND(sql))||
				(dstat = oiSqlWhereBegParen(sql))||
				(dstat = oiSqlWhereEQ(sql,"t5DesignGroup","54")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"t5DesignGroup","80")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"t5DesignGroup","15")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"t5DesignGroup","16")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"t5DesignGroup","82")) ||
			    (dstat = oiSqlWhereEndParen(sql)) ||
				(dstat = oiSqlWhereAND(sql))||
				(dstat = oiSqlWhereBegParen(sql)) ||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsErcRlzd")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAPLWrkg")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsAplRlzd")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDAthrig")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDWrkg")) ||
				(dstat = oiSqlWhereOR(sql))||
				(dstat = oiSqlWhereEQ(sql,"LifeCycleState","LcsSTDRlzd")) ||
				(dstat = oiSqlWhereEndParen(sql)) ||
				(dstat = oiSqlWhereAND(sql))||
				(dstat = oiSqlWhereEQ(sql,"OwnerName","Release Vault")) ||
				(dstat = oiSqlDescOrder(sql,"CreationDate")) ||
				(dstat = oiSqlWhereEndParen(sql)) ||
				(dstat = QueryWhere("Part",sql,&PartObjs,&mfail))
			)
		goto CLEANUP;

	}
	else
	{
		strcpy(EEDmlNumber,InputDmlOrPart);
		strcat(EEDmlNumber,"EE");
		strcpy(EEDmlNumberST,InputDmlOrPart);
		strcat(EEDmlNumberST,"EE");
	}
	if(setSize(PartObjs)>0)
	{
		partflag = 1;
		cll_ccap_ecn_create(NULL,setGet(PartObjs,0));
		cll_ccap_ecn_createST(NULL,setGet(PartObjs,0));

	}

	if(setSize(DmlObjs) != 0)
	{
		if(dstat = ExpandObject5("CmPlStrc",setGet(DmlObjs,0),"CMPlanBreaksDownInTo",SC_SCOPE_OF_SESSION,&taskObjs,&mfail)) goto CLEANUP;
		printf("\nTaskObject Found:[%d]",setSize(taskObjs));
		fprintf(fsuccess,"\nTaskObject Found:[%d]",setSize(taskObjs));
		if(setSize(taskObjs) == 0)
		{
			printf("\nNo TASK Found in DataBase");
			fprintf(fsuccess,"\nNo TASK Found in DataBase");
			goto CLEANUP;
		}
		for(noOfTasks = 0; noOfTasks < setSize(taskObjs); noOfTasks++)
		{
			if(dstat = objGetAttribute(setGet(taskObjs,noOfTasks),"WbsID",&taskId)) goto CLEANUP;
			if(!nlsIsStrNull(taskId))
			{
				taskIdDup = nlsStrDup(taskId);
			}

			if((!nlsIsStrNull(nlsStrStr(taskIdDup,"APLPUNE")))|| (!nlsIsStrNull(nlsStrStr(taskIdDup,"STD1")))|| (!nlsIsStrNull(nlsStrStr(taskIdDup,"STD"))) || (!nlsIsStrNull(nlsStrStr(taskIdDup,"APLSGR"))) || (!nlsIsStrNull(nlsStrStr(taskIdDup,"APL"))) || (!nlsIsStrNull(nlsStrStr(taskIdDup,"APL1"))))
			{
				printf("\nAPLPUNE APLSGR STD STD1 APL APL1 Hence task skip %s.......",taskIdDup);
				fprintf(fsuccess,"\nAPLPUNE APLSGR STD STD1 APL APL1  Hence task skip %s.......",taskIdDup);
				continue;
			}

			if
			(
				(dstat = oiSqlCreateSelect(&sqlPtr))||
				(dstat = oiSqlWhereBegParen(sqlPtr))||
				(dstat = oiSqlWhereEQ(sqlPtr,"WbsID",taskIdDup))||
				(dstat = oiSqlWhereEndParen(sqlPtr))
			) goto CLEANUP;

			if(dstat = QueryWhere3("CmTaskIt",sqlPtr,1,SC_SCOPE_OF_SESSION,&taskRevObjs,&mfail)) goto CLEANUP;
			printf("\nTaskRevObject Found:[%d]",setSize(taskRevObjs));
			fprintf(fsuccess,"\nTaskRevObject Found:[%d]",setSize(taskRevObjs));
			if(setSize(taskRevObjs)==0)
			{
				printf("\nTaskRev Not Found");
				fprintf(fsuccess,"\nTaskRev Not Found");
				goto CLEANUP;
			}
			if(dstat = ExpandObject5("CmRslts",setGet(taskRevObjs,0),"CMPrdPlnResultsInBusItem",SC_SCOPE_OF_SESSION,&TmpPartObjs,&mfail))goto CLEANUP;
			printf("\nPartObject Found:[%d]",setSize(TmpPartObjs));
			fprintf(fsuccess,"\nPartObject Found:[%d]",setSize(TmpPartObjs));
			for(nCount = 0;nCount < setSize(TmpPartObjs);nCount++)
			{
				if(dstat = objGetAttribute(setGet(TmpPartObjs,nCount),"PartNumber",&PartNumber)) goto CLEANUP;
				if(!nlsIsStrNull(PartNumber))
				{
					PartNumberDup = nlsStrDup(PartNumber);
				}
				printf("\nPartno :[%s] added in set",PartNumberDup);
				fprintf(fsuccess,"\nPartno :[%s] added in set",PartNumberDup);
				ulyCopyObjectToSet(setGet(TmpPartObjs,nCount),&PartObjs);
			}
		}

	}
	printf("\nsetSize(PartObjs):[%d]",setSize(PartObjs));
	fprintf(fsuccess,"\nsetSize(PartObjs):[%d]",setSize(PartObjs));

	for(noOfParts = 0; noOfParts < setSize(PartObjs); noOfParts++)
	{

		AssemblyPtr = setGet(PartObjs,noOfParts);


		if(ercDmlflag == 1)//ERC dml bom with party partno
		{
			printf("\nLogic for ERC dml bom create in plant 1005");
			fflush(stdout);
			if(dstat = objGetAttribute(AssemblyPtr,"t5RefPartNumber",&ChildPartNumber)) goto CLEANUP;
			if(!nlsIsStrNull(ChildPartNumber))
			{
				ChildPartNumberDup = nlsStrDup(ChildPartNumber);
			}
			else
			{
				ChildPartNumberDup = nlsStrDup("");
				printf("\nref part no is null hence skip this assembly for bom creation");
				continue;
			}
			printf("\nRefPartno:[%s] now querying...",ChildPartNumberDup);
			fflush(stdout);
			if (
				(dstat = oiSqlCreateSelect(&sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"PartNumber",ChildPartNumberDup)) ||
				(dstat = oiSqlWhereAND(sql1))||
				(dstat = oiSqlWhereBegParen(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsErcRlzd")) ||
				(dstat = oiSqlWhereOR(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsAPLWrkg")) ||
				(dstat = oiSqlWhereOR(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsAplRlzd")) ||
				(dstat = oiSqlWhereOR(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsSTDAthrig")) ||
				(dstat = oiSqlWhereOR(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsSTDWrkg")) ||
				(dstat = oiSqlWhereOR(sql1))||
				(dstat = oiSqlWhereEQ(sql1,"LifeCycleState","LcsSTDRlzd")) ||
				(dstat = oiSqlWhereEndParen(sql1)) ||
				(dstat = oiSqlWhereAND(sql1))||
				(dstat = oiSqlWhereEQ(sql1,"OwnerName","Release Vault")) ||
				(dstat = oiSqlDescOrder(sql1,"CreationDate")) ||
				(dstat = QueryWhere("Part",sql1,&rpartObjs,&mfail))
			)goto CLEANUP;
			if(dstat = oiSqlPrint(sql1)) goto CLEANUP;


			if(setSize(rpartObjs) == 0)
			{
				printf("\nbNo Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
				fprintf(fsuccess,"\n\nbMSG RCVD:No Revisions of referance Part %s found in Release Vault with Life Cycle State as ERC Released",ChildPartNumberDup);
				continue;
			}
			if(setSize(rpartObjs)>0)
			{
				if(dstat = objGetClass(setGet(rpartObjs,0), &RefPartclass)) goto CLEANUP;
				if(!nlsIsStrNull(RefPartclass))
				{
					RefPartclassDup = nlsStrDup(RefPartclass);
				}
				if(nlsStrCmp(RefPartclassDup,"t5EeAsm")!=0)
				{
					printf("\nrefpart class is not t5EeAsm hence exit");
					fprintf(fsuccess,"\nrefpart class is not t5EeAsm hence exit");
					continue;
				}
					nlsStrCpy(EEPartThreeDigit,"");
				EEPartThreeDigit[0]= *(ChildPartNumberDup+0);
				EEPartThreeDigit[1]= *(ChildPartNumberDup+1);
				EEPartThreeDigit[2]= *(ChildPartNumberDup+2);
				EEPartThreeDigit[3]= '\0';
				printf("\n%s",EEPartThreeDigit);
				if(nlsStrNCmp(ChildPartNumberDup,EEPartThreeDigit,3)==0)
				{
					printf("\nvalid part found [%s]",ChildPartNumberDup);
					DZ_ckd_bapi_mat(AssemblyPtr,PartNumberDup,EEDmlNumber,'0');
				}
				else
				{
					printf("\ninvalid part found hence check next part [%s]",ChildPartNumberDup);
					continue;
				}


			}
		}
		else	//E1 dml bom
		{
			if(dstat = objGetAttribute(AssemblyPtr,"PartNumber",&PartNumber)) goto CLEANUP;
			if(!nlsIsStrNull(PartNumber))
			{
				PartNumberDup = nlsStrDup(PartNumber);
			}
			printf("\nAssemblyMatCreation:[%s]",PartNumberDup);
			fprintf(fsuccess,"\nAssemblyMatCreation:[%s]",PartNumberDup);

			DZ_ckd_bapi_mat(AssemblyPtr,PartNumberDup,EEDmlNumber,'0');

			if(dstat = SetUpContext(objClass(AssemblyPtr),AssemblyPtr,&genContextObjOP,&mfail)) goto CLEANUP;
			if(dstat = GetCfgCtxtObjFromCtxt("DSesGnC",genContextObjOP,&contextObjOP,&mfail)) goto CLEANUP;
			if(dstat = objSetAttribute(contextObjOP,"ExpandOnRevision","PscLastRev")) goto CLEANUP;
			if(dstat = objSetAttribute(contextObjOP,"NavigateViewBitPos","0")) goto CLEANUP;
			if(dstat = objSetAttribute(contextObjOP,"CfgItemId","GlobalCtxt")) goto CLEANUP;
			if(dstat = objSetAttribute(contextObjOP,"NavigateViewNetwork","EAS")) goto CLEANUP;
			if(dstat = objSetAttribute(contextObjOP,"NavigateViewName","STD")) goto CLEANUP;
			if(dstat = SetNavigateViewPref(contextObjOP,TRUE,"EAS","STD",&mfail)) goto CLEANUP;

			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsSTDRlzd","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsSTDWrkg","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsAplRlzd","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsAPLWrkg","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsErcRlzd","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsReview","+")) goto CLEANUP;
			if(dstat = objNameValueSet(contextObjOP,"LCStateList","LcsWorking","+")) goto CLEANUP;
			if(dstat = objSetObject(genContextObjOP,"ConfigCtxtBlob",contextObjOP)) goto CLEANUP;



			if(dstat = objSetObject(genContextObjOP,ConfigCtxtBlobAttr,contextObjOP)) goto CLEANUP;
			printf("\nContext Set Successfully");fflush(stdout);
			fprintf(fsuccess,"\nContext Set Successfully");fflush(stdout);



			if(dstat = ExpandRelationWithCtxt("AsRevRev",AssemblyPtr,"PartsInAssembly",genContextObjOP,SC_SCOPE_OF_SESSION ,NULL, &soChildParts, &soChildPartsRels,&mfail))goto CLEANUP;


			printf("\nsetSize(soChildParts):[%d]",setSize(soChildParts));fflush(stdout);
			fprintf(fsuccess,"\nsetSize(soChildParts):[%d]",setSize(soChildParts));
			printf("\nsetSize(soChildPartsRels):[%d]",setSize(soChildPartsRels));
			fprintf(fsuccess,"\nsetSize(soChildPartsRels):[%d]",setSize(soChildPartsRels));
			for(noOfChildParts = 0; noOfChildParts < setSize(soChildParts); noOfChildParts++)
			{
				ObjChildPart = setGet(soChildParts,noOfChildParts);
				ObjChildRelPart = setGet(soChildPartsRels,noOfChildParts);
				if(dstat = objGetAttribute(ObjChildPart,"PartNumber",&ChildPartNumber)) goto CLEANUP;
				if(!nlsIsStrNull(ChildPartNumber))
				{
					ChildPartNumberDup = nlsStrDup(ChildPartNumber);
				}
				if(dstat = objGetAttribute(ObjChildRelPart,"Quantity",&Quantity)) goto CLEANUP;
				if(!nlsIsStrNull(Quantity))
				{
					QuantityDup = nlsStrDup(Quantity);
				}

				if(dstat=objGetAttribute(ObjChildRelPart,"t5QtyReqInfo",&QuantityReqInfo)) goto CLEANUP;
				if(!nlsIsStrNull(QuantityReqInfo))
				{
					QuantityReqInfoDup = nlsStrDup(QuantityReqInfo);
				}

				if(!nlsStrCmp(QuantityDup,"0") && (!nlsStrCmp(QuantityReqInfoDup,"NA") || !nlsStrCmp(QuantityReqInfoDup,"+")))
				{
					printf("\nSkipping this Part as quantity is %s and Quantity Required information  is %s",QuantityDup,QuantityReqInfoDup);
					continue;
				}
				if(!nlsStrCmp(QuantityDup,"1") && (!nlsStrCmp(QuantityReqInfoDup,"+")))
				{
					printf("\nSkipping this Part as quantity is %s and Quantity Required information  is %s",QuantityDup,QuantityReqInfoDup);
					continue;
				}
				printf("\n[%18s, %18s, %10s, %4s]",PartNumberDup,ChildPartNumberDup,QuantityDup,QuantityReqInfoDup);
				fprintf(fsuccess,"\n[%18s, %18s, %10s, %4s]",PartNumberDup,ChildPartNumberDup,QuantityDup,QuantityReqInfoDup);
				printf("\nChildPartMatCreation:[%s]",ChildPartNumberDup);
				fprintf(fsuccess,"\nChildPartMatCreation:[%s]",ChildPartNumberDup);

				if(dstat = objGetAttribute(ObjChildPart,"ProjectName",&ChildProjectCode)) goto CLEANUP;
				if(!nlsIsStrNull(ChildProjectCode))
				{
					ChildProjectCodeDup = nlsStrDup(ChildProjectCode);
				}
				printf("\n[%s]ChildProjectCode:[%s]",ChildPartNumberDup,ChildProjectCodeDup);
				fprintf(fsuccess,"\n[%s]ChildProjectCode:[%s]",ChildPartNumberDup,ChildProjectCodeDup);


				if(dstat = objGetAttribute(ObjChildPart,"t5PunMakeBuyIndicator",&MakeBuyInd)) goto CLEANUP;

				if(!nlsIsStrNull(MakeBuyInd))
				{
					MakeBuyIndDup = nlsStrDup(MakeBuyInd);
				}
				if(nlsIsStrNull(MakeBuyInd))

				{
					printf("\nPart MakeBuyInd is null");
					fprintf(fsuccess,"\nPart MakeBuyInd is null");
					continue;
				}
				if(nlsStrCmp(MakeBuyIndDup,"NA")==0)
				{
					printf("\nPart MakeBuyInd is NA hence exit from material create");
					fprintf(fsuccess,"\nPart MakeBuyInd is NA hence exit from material create");
					continue;
				}
				DZ_ckd_bapi_mat(ObjChildPart,ChildPartNumberDup,EEDmlNumber,'0');
			}
			if(partflag == 1)
			{
				printf("will process only input part");
				break;
			}
		}
	}

	/*******************E1 BOM creation Loop start********************/
	if(ercDmlflag != 1)
	{
		for(noOfParts = 0; noOfParts < setSize(PartObjs); noOfParts++)
		{

			BomCreate(setGet(PartObjs,noOfParts),EEDmlNumber);
			printf("\nCreating Changing BOM");
			fprintf(fsuccess,"\nCreating Changing BOM");
			if(partflag == 1)
			{
				printf("will process only input part");
				goto CLEANUP;
			}
		}
	}
	else if(ercDmlflag == 1) /*******************ERC BOM creation Loop start********************/
	{
		printf("\nERC 54 group bom create");
		for(noOfParts = 0; noOfParts < setSize(PartObjs); noOfParts++)
		{
			if(dstat = objGetAttribute(setGet(PartObjs,noOfParts),"PartNumber",&AssyPartNumber)) goto CLEANUP;
			if(!nlsIsStrNull(AssyPartNumber))
			{
				AssyPartNumberDup = nlsStrDup(AssyPartNumber);
			}
			else
			{
				AssyPartNumberDup = nlsStrDup("");
				continue;
			}


			if(dstat = objGetAttribute(setGet(PartObjs,noOfParts),"t5RefPartNumber",&ChildPartNumber)) goto CLEANUP;
			if(!nlsIsStrNull(ChildPartNumber))
			{
				ChildPartNumberDup = nlsStrDup(ChildPartNumber);
			}
			else
			{
				ChildPartNumber = nlsStrDup("");
				ChildPartNumberDup = nlsStrDup("");
			}

			printf("\nAssyPartNumberDup[%s]ChildPartNumberDup[%s]\n",AssyPartNumberDup,ChildPartNumberDup);
			//----------------------------------------
			char *json_ref_bom_create_in_plant_req_obj = NULL ;
			json_ref_bom_create_in_plant_req_obj = malloc ( 990000 ) ;

			int RFCRet=0;
			RFCRet = RefPartBomCreate( AssyPartNumberDup,ChildPartNumberDup,EEDmlNumber,json_ref_bom_create_in_plant_req_obj );

			printf("\nRetuned Str : %s\n", json_ref_bom_create_in_plant_req_obj);

			tm_curl_CAD_CREATE_BOM_WITH_SUB_ITEMS ( json_ref_bom_create_in_plant_req_obj );
			free(json_ref_bom_create_in_plant_req_obj);
			//RefPartBomCreate(AssyPartNumberDup,ChildPartNumberDup,EEDmlNumber);
			//----------------------------------------

		}
		printf("\nWrite here bom creation logic");
	}

CLEANUP:
		printf("\nCleaning up the memory...");
	fprintf(fsuccess,"\nCleaning up the memory...");
	clLogout();
	clTerminate();

EXIT:
	printf("\nExiting...");
	fprintf(fsuccess,"\nExiting...");
	printf("\n");
	fprintf(fsuccess,"\n");fflush(stdout);
	if (fsuccess)
	{
		fclose(fsuccess);
	}
	fsuccess = NULL;
	return 0;
}

