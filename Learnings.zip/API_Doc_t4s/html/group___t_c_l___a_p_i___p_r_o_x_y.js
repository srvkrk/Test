var group___t_c_l___a_p_i___p_r_o_x_y =
[
    [ "createClient", "group___t_c_l___a_p_i___p_r_o_x_y.html#gaf31ea95655cec685c32aebba281bf211", null ],
    [ "createClientA", "group___t_c_l___a_p_i___p_r_o_x_y.html#gac8b3208ff6f520e51f812acac4fe11d7", null ],
    [ "createServer", "group___t_c_l___a_p_i___p_r_o_x_y.html#gaf9ab3c1cc0fc1eb8b4f3066887552b90", null ],
    [ "typeDef", "group___t_c_l___a_p_i___p_r_o_x_y.html#gaabd168b25fd1098eeb9acaedb42871b1", null ]
];