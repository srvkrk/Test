var namespace_t_c =
[
    [ "SCHMGR", "namespace_t_c_1_1_s_c_h_m_g_r.html", null ]
];