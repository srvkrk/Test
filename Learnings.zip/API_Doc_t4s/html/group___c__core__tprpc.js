var group___c__core__tprpc =
[
    [ "tpco_closeSrvSession", "group___c__core__tprpc.html#gac37a46f024df20f9994f3cd5f6ba2768", null ],
    [ "tpco_openSrvSession", "group___c__core__tprpc.html#ga90cdd897a18637a94ff8aa54513ca470", null ],
    [ "tpco_openSrvSession2", "group___c__core__tprpc.html#ga5439d9baedf48e3eced9223a7bcf6422", null ],
    [ "tpco_openSrvSession3", "group___c__core__tprpc.html#gaa248e34aed4fa004a7765327f5ff30dd", null ],
    [ "tpco_sendSrvCMD", "group___c__core__tprpc.html#ga6f564b529e6d07b5214d9663c35f4128", null ]
];