var namespace_t4_s =
[
    [ "CONNECTION2SAP", "namespace_t4_s_1_1_c_o_n_n_e_c_t_i_o_n2_s_a_p.html", null ],
    [ "TC", "namespace_t4_s_1_1_t_c.html", "namespace_t4_s_1_1_t_c" ],
    [ "TRANSLOG", "namespace_t4_s_1_1_t_r_a_n_s_l_o_g.html", null ]
];