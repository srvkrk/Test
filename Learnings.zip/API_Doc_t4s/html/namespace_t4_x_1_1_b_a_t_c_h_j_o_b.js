var namespace_t4_x_1_1_b_a_t_c_h_j_o_b =
[
    [ "DEPENDENCIES", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_d_e_p_e_n_d_e_n_c_i_e_s.html", null ],
    [ "EXPORT", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_e_x_p_o_r_t.html", null ],
    [ "IMPORT", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_i_m_p_o_r_t.html", null ],
    [ "TOOLBOX", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_t_o_o_l_b_o_x.html", null ]
];