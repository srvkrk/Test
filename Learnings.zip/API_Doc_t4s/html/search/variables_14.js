var searchData=
[
  ['zero',['ZERO',['../namespace_t4_x_1_1_o_b_j_e_c_t_s.html#ab284bdf3b32e4fc5d5db7feb9fcfb8f0',1,'T4X::OBJECTS']]]
];
