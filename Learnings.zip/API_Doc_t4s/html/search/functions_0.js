var searchData=
[
  ['_5fdeleteperspectives',['_DeletePerspectives',['../namespace_shared_mem.html#a7cd82e212531feb32e405e376080383e',1,'SharedMem']]],
  ['_5fletperspective',['_LetPerspective',['../namespace_shared_mem.html#a858ea5437b0c65cecca8a13c113bad0d',1,'SharedMem']]],
  ['_5fsetperspective',['_SetPerspective',['../namespace_shared_mem.html#ad4001368ae5197030eba9c9bd0339e2a',1,'SharedMem']]]
];
