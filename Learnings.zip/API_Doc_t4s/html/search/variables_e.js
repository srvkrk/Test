var searchData=
[
  ['required_5fjars',['REQUIRED_JARS',['../namespace_t4_x_1_1_j_a_v_a_s_e_r_v_e_r.html#a566a6ca5a2072a115803ec5945794d87',1,'T4X::JAVASERVER']]],
  ['required_5fplugins',['REQUIRED_PLUGINS',['../namespace_t4_x_1_1_j_a_v_a_s_e_r_v_e_r.html#a5a827c85b8335ea6ea5fb2b3bb6cf047',1,'T4X::JAVASERVER']]],
  ['rfcattributes',['RfcAttributes',['../namespace_t_p_s_a_p.html#a0bc3010a7075730118ebf114f6f1f15e',1,'TPSAP']]]
];
