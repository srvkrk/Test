var searchData=
[
  ['pipe_20client_2fserver_20handling',['PIPE client/server handling',['../group___c__core__pipe.html',1,'']]]
];
