var searchData=
[
  ['batchjobdefaults',['BatchjobDefaults',['../namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_e_x_p_o_r_t.html#a3436e2800ddb6e5434c7862f23ff7107',1,'T4X::BATCHJOB::EXPORT::BatchjobDefaults()'],['../namespace_t4_x_1_1_b_a_t_c_h_j_o_b_1_1_i_m_p_o_r_t.html#a3436e2800ddb6e5434c7862f23ff7107',1,'T4X::BATCHJOB::IMPORT::BatchjobDefaults()'],['../namespace_t4_x_1_1_t_e_s_t_1_1_w_o_r_k_f_l_o_w.html#a3436e2800ddb6e5434c7862f23ff7107',1,'T4X::TEST::WORKFLOW::BatchjobDefaults()']]]
];
