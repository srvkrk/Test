var searchData=
[
  ['core_20tcl_20enhancements_20in_20the_20t4x_20kernel',['CORE tcl enhancements in the T4x kernel',['../group___c__core__functions.html',1,'']]],
  ['create_20client_2fserver_20functions',['create CLIENT/SERVER functions',['../group___t_c_l___a_p_i___p_r_o_x_y.html',1,'']]]
];
