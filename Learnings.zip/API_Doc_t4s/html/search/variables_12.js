var searchData=
[
  ['waittime4translogfile',['WaitTime4TransLogFile',['../namespace_t4_x_1_1_t_r_a_n_s_l_o_g.html#ae4d037a20bda2d339e54328f0076b52c',1,'T4X::TRANSLOG']]]
];
