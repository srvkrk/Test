var searchData=
[
  ['teamcenter_20data_20handling',['TEAMCENTER DATA handling',['../group___c__core__tcd.html',1,'']]],
  ['tprpc_20client_20functions',['TPRPC client functions',['../group___c__core__tprpc.html',1,'']]]
];
