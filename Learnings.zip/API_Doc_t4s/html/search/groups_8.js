var searchData=
[
  ['zip_20data_20handling',['ZIP data handling',['../group___c__core__zip.html',1,'']]]
];
