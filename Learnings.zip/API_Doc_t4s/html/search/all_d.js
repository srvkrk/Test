var searchData=
[
  ['name',['name',['../namespace_t4_x_1_1_testing_support_1_1_demo_case.html#ab74e6bf80237ddc4109968cedc58c151',1,'T4X::TestingSupport::DemoCase']]],
  ['nsdelimiter',['nsDelimiter',['../namespace_t4_x_1_1_testing_support.html#ad97227dd726dbd679eb26dde52ccd4e6',1,'T4X::TestingSupport']]]
];
