var searchData=
[
  ['use_5fxsi_5ftypes',['USE_XSI_TYPES',['../namespace_t4_x_1_1_p_r_o_p_1_1_m_a_p_p_i_n_g.html#a3e784e84748a03c379bdb64d1537b4ed',1,'T4X::PROP::MAPPING']]],
  ['usejco',['UseJCO',['../namespace_t_p_s_a_p_1_1_m_m.html#a46911ed2ddc2326285fb0f22786a8fa2',1,'TPSAP::MM']]],
  ['users_5fkey_5fprefix',['USERS_KEY_PREFIX',['../namespace_shared_mem.html#a7745eeba903342a603e67ef62454ba41',1,'SharedMem']]]
];
