var searchData=
[
  ['xsi_5ftypes',['XSI_TYPES',['../namespace_t4_x_1_1_p_r_o_p_1_1_m_a_p_p_i_n_g.html#a87d64250bf7c421d0d2c77eaaf145602',1,'T4X::PROP::MAPPING']]]
];
