var searchData=
[
  ['path',['path',['../namespace_t4_x_1_1_testing_support_1_1_demo_suite.html#aa28dc103258589d9cb421197fe2de90b',1,'T4X::TestingSupport::DemoSuite']]],
  ['path_5fvar_5fseparator',['PATH_VAR_SEPARATOR',['../namespace_t4_x_1_1_j_a_v_a_s_e_r_v_e_r.html#a81742a819b2998f9a861480d648f8229',1,'T4X::JAVASERVER']]],
  ['perspectives_5fkey_5fprefix',['PERSPECTIVES_KEY_PREFIX',['../namespace_shared_mem.html#a735ef435cf6e803e2ad671d82dcb0f07',1,'SharedMem']]]
];
