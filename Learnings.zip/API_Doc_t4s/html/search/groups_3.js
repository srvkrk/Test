var searchData=
[
  ['logging_20client_20functions',['LOGGING client functions',['../group___c__core__logc.html',1,'']]],
  ['log_20file_20handling',['LOG file handling',['../group___t_c_l___a_p_i___l_o_g.html',1,'']]]
];
