var searchData=
[
  ['false',['FALSE',['../namespace_t4_x_1_1_o_b_j_e_c_t_s.html#a409147574fa4c0c4213d56284830ae2e',1,'T4X::OBJECTS']]]
];
