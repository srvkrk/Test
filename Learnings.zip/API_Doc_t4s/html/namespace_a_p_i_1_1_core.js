var namespace_a_p_i_1_1_core =
[
    [ "Batch", "namespace_a_p_i_1_1_core_1_1_batch.html", null ],
    [ "Sql", "namespace_a_p_i_1_1_core_1_1_sql.html", null ]
];