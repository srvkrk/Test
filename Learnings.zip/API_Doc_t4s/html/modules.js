var modules =
[
    [ "BASE64 file handling", "group___c__core__base64.html", "group___c__core__base64" ],
    [ "BASIC system function", "group___t_c_l___a_p_i___b_a_s_e.html", "group___t_c_l___a_p_i___b_a_s_e" ],
    [ "BATCH pool and job handling", "group___t_c_l___a_p_i___batch.html", "group___t_c_l___a_p_i___batch" ],
    [ "CORE tcl enhancements in the T4x kernel", "group___c__core__functions.html", "group___c__core__functions" ],
    [ "HEX16 encoding/decoding", "group___c__core__h16.html", "group___c__core__h16" ],
    [ "HTML and XML utility functions", "group___t_c_l___a_p_i___h_t_t_p_u_t.html", "group___t_c_l___a_p_i___h_t_t_p_u_t" ],
    [ "LOG file handling", "group___t_c_l___a_p_i___l_o_g.html", "group___t_c_l___a_p_i___l_o_g" ],
    [ "LOGGING client functions", "group___c__core__logc.html", "group___c__core__logc" ],
    [ "PIPE client/server handling", "group___c__core__pipe.html", "group___c__core__pipe" ],
    [ "SMTP handling", "group___t_c_l___a_p_i___s_m_t_p.html", "group___t_c_l___a_p_i___s_m_t_p" ],
    [ "SOAP client", "group___t_c_l___a_p_i___s_o_a_p_c.html", null ],
    [ "SQL interface to the internal T4x database", "group___t_c_l___a_p_i___s_q_l.html", null ],
    [ "SYSTEM utility functions", "group___t_c_l___a_p_i___s_u_t_i_l_s.html", "group___t_c_l___a_p_i___s_u_t_i_l_s" ],
    [ "TEAMCENTER DATA handling", "group___c__core__tcd.html", "group___c__core__tcd" ],
    [ "TPRPC client functions", "group___c__core__tprpc.html", "group___c__core__tprpc" ],
    [ "WEBSOCKET functions", "group___c__core__wsock.html", "group___c__core__wsock" ],
    [ "ZIP data handling", "group___c__core__zip.html", "group___c__core__zip" ],
    [ "create CLIENT/SERVER functions", "group___t_c_l___a_p_i___p_r_o_x_y.html", "group___t_c_l___a_p_i___p_r_o_x_y" ],
    [ "handling SHARED MEMORY keys", "group___c__core__shm.html", "group___c__core__shm" ],
    [ "handling of LOG file ATTACHMENTS", "group___c__core__attachment.html", "group___c__core__attachment" ],
    [ "simple CRYPTING functions", "group___c__core__crypt.html", "group___c__core__crypt" ]
];