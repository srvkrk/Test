var namespaces =
[
    [ "AdminGui", "namespace_admin_gui.html", "namespace_admin_gui" ],
    [ "API", "namespace_a_p_i.html", "namespace_a_p_i" ],
    [ "EMail", "namespace_e_mail.html", "namespace_e_mail" ],
    [ "ITK", "namespace_i_t_k.html", "namespace_i_t_k" ],
    [ "JSONScope", "namespace_j_s_o_n_scope.html", null ],
    [ "LogTools", "namespace_log_tools.html", null ],
    [ "ProxyGen", "namespace_proxy_gen.html", null ],
    [ "SharedMem", "namespace_shared_mem.html", null ],
    [ "Soap2C", "namespace_soap2_c.html", null ],
    [ "SQLite", "namespace_s_q_lite.html", null ],
    [ "SYSBase", "namespace_s_y_s_base.html", null ],
    [ "SYSUtils", "namespace_s_y_s_utils.html", null ],
    [ "T4S", "namespace_t4_s.html", "namespace_t4_s" ],
    [ "T4SSoap2", "namespace_t4_s_soap2.html", null ],
    [ "T4X", "namespace_t4_x.html", "namespace_t4_x" ],
    [ "TC", "namespace_t_c.html", "namespace_t_c" ],
    [ "TPHAP", "namespace_t_p_h_a_p.html", null ],
    [ "TPSAP", "namespace_t_p_s_a_p.html", "namespace_t_p_s_a_p" ]
];