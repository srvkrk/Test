var namespace_t4_x =
[
    [ "BATCHJOB", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b.html", "namespace_t4_x_1_1_b_a_t_c_h_j_o_b" ],
    [ "CORE", "namespace_t4_x_1_1_c_o_r_e.html", null ],
    [ "CUSTOM", "namespace_t4_x_1_1_c_u_s_t_o_m.html", "namespace_t4_x_1_1_c_u_s_t_o_m" ],
    [ "JAVASERVER", "namespace_t4_x_1_1_j_a_v_a_s_e_r_v_e_r.html", null ],
    [ "OBJECTS", "namespace_t4_x_1_1_o_b_j_e_c_t_s.html", null ],
    [ "PROP", "namespace_t4_x_1_1_p_r_o_p.html", "namespace_t4_x_1_1_p_r_o_p" ],
    [ "QUERY", "namespace_t4_x_1_1_q_u_e_r_y.html", null ],
    [ "SOA", "namespace_t4_x_1_1_s_o_a.html", null ],
    [ "TC", "namespace_t4_x_1_1_t_c.html", "namespace_t4_x_1_1_t_c" ],
    [ "TEST", "namespace_t4_x_1_1_t_e_s_t.html", "namespace_t4_x_1_1_t_e_s_t" ],
    [ "TestingSupport", "namespace_t4_x_1_1_testing_support.html", "namespace_t4_x_1_1_testing_support" ],
    [ "TRANSLOG", "namespace_t4_x_1_1_t_r_a_n_s_l_o_g.html", null ]
];