var namespace_admin_gui =
[
    [ "Mapping", "namespace_admin_gui_1_1_mapping.html", null ],
    [ "Script", "namespace_admin_gui_1_1_script.html", null ],
    [ "SysInfo", "namespace_admin_gui_1_1_sys_info.html", null ]
];