var namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m =
[
    [ "BADI", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_b_a_d_i.html", null ],
    [ "CADKZ", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_c_a_d_k_z.html", null ],
    [ "CM_OBJECT_LINK", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_c_m___o_b_j_e_c_t___l_i_n_k.html", null ],
    [ "MISC", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_m_i_s_c.html", null ],
    [ "MM_ATTACHMENTS", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_m_m___a_t_t_a_c_h_m_e_n_t_s.html", null ],
    [ "MM_OBJECT_LINK", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_m_m___o_b_j_e_c_t___l_i_n_k.html", null ],
    [ "OBJECT_LINK", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_o_b_j_e_c_t___l_i_n_k.html", null ],
    [ "UOM", "namespace_t_p_s_a_p_1_1_t_e_s_i_s_p_l_m_1_1_u_o_m.html", null ]
];