var group___c__core__logc =
[
    [ "tpco_getdefaultlogchannel", "group___c__core__logc.html#gaf284efa84c09136fe164ed88c2a85819", null ],
    [ "tpco_setdlogchannel", "group___c__core__logc.html#ga60885e12bb3f01c818a95fa00bbccb84", null ],
    [ "tpco_udpDumpLogFile", "group___c__core__logc.html#gab81a0f7ccef0d90049fc953da374910f", null ],
    [ "tpwrite", "group___c__core__logc.html#ga0fcad3a1609877505a9cbd2352d4f72a", null ]
];