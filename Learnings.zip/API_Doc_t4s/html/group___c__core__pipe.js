var group___c__core__pipe =
[
    [ "tpco_closeAllECMD", "group___c__core__pipe.html#gaa3b53b83184850ec2a6f4bd5d69ff9b7", null ],
    [ "tpco_closeECMD", "group___c__core__pipe.html#gaf394a231061ca48e781fac73dd16e296", null ],
    [ "tpco_getECMDState", "group___c__core__pipe.html#ga9609e23a95141c7f0c8db8389a6f40e0", null ],
    [ "tpco_openECMD", "group___c__core__pipe.html#gadacc49abb796da0388ba1d87abc5fe9b", null ],
    [ "tpco_receiveECMD", "group___c__core__pipe.html#ga22fac9cede143979d726c4ea56bfa6da", null ],
    [ "tpco_registerECMD", "group___c__core__pipe.html#ga1750f22ae1f41b0a52a9b9bb1ff077ed", null ],
    [ "tpco_sendECMD", "group___c__core__pipe.html#gafde35224aae81123f8f04dfb55fb3c0c", null ],
    [ "tpco_sendECMD2", "group___c__core__pipe.html#ga5fe0cf0f90577e7aaf1efc0178806d73", null ]
];