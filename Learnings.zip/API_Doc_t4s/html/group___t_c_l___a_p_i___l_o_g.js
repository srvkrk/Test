var group___t_c_l___a_p_i___l_o_g =
[
    [ "getBinLogFile", "group___t_c_l___a_p_i___l_o_g.html#gae6029f3091aefb7d109d0970eb68cf36", null ],
    [ "storeBinLogFile", "group___t_c_l___a_p_i___l_o_g.html#gaee981d179a61496401c8c51647d3f90c", null ],
    [ "testLogPattern", "group___t_c_l___a_p_i___l_o_g.html#ga94cb2a5a37d9277dd15cecd0922c094f", null ]
];