var group___c__core__h16 =
[
    [ "tpco_formatHEX16", "group___c__core__h16.html#ga2fcd44592b9c94f02f1e35280aa38cea", null ],
    [ "tpco_scanHEX16", "group___c__core__h16.html#ga3be2f6636a0f4f3f49d94b93f39552f5", null ]
];