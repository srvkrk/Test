#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <bom/bom_attr.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
//#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>
#include <bom/bom_attr.h>
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);
void childfun(tag_t,int);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);
int bpart=0;
int tbcnt=0;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();
char *inputfile=NULL;
	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sOpt  = ITK_ask_cli_argument("-i=");
	inputfile = ITK_ask_cli_argument("-ip=");
	//sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);


char	*FileName = NULL;

FileName =(char *) MEM_alloc(150);
FILE *fptr;

printf("\n Input TPL Is : [%s]\n",inputfile);

  
	
	tc_strcpy(FileName,"/user/cvprod/Akshay/TPLLoading/BOM/");
	tc_strcat(FileName,sOpt);
	tc_strcat(FileName,"_BOM");
	tc_strcat(FileName,".csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		//exit(1);
	}
	else
	{
		printf("\nlog File opening!!!");  fflush(stdout);
	}

//////////////////
FILE* fp=NULL;
FILE* fperror=NULL;
     char* inputline=NULL;
     char* level=NULL;
     char* item_id=NULL;
     char* item_revision_id=NULL;
     char* item_sequence_id=NULL;
     
	 int line=0;
	 int mline=0;
	

fp=fopen(inputfile,"r");
		fperror=fopen("error.log","a");
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(1000);
				while(fgets(inputline,1000,fp)!=NULL)
				{
                    line++;  

					if (line>2)
					{
						mline++;
					
					    									
						//fputs(inputline,stdout);
						level=strtok(inputline,"^");  //1
						item_id=strtok(NULL,"^"); //2
						item_revision_id=strtok(NULL,"^"); //3
						item_sequence_id=strtok(NULL,"^"); //4



						

						printf("\nL:[%s],I:[%s],R:[%s],S:[%s]...%d\n",level,item_id,item_revision_id,item_sequence_id,mline);
					}


						

						
				}
				


	    }
		

printf("\n Total parts in TCE %d \n",mline);





///////////////////////////////////////////

           tag_t rel_type2=NULLTAG;
			tag_t modulelatestrev=NULLTAG;
			tag_t* moduleno=NULLTAG;
			int modulecnt=0;
			char* modulenoname=NULL;
			char* modulerevseq=NULL;
		

					int moduleallrevcount=0;
					tag_t *modul_rev_list = NULLTAG;
					tag_t tplrevtag = NULLTAG;
					
					char* moduleid =NULL;
					char* modidrev =NULL;
					int mi=0;
					char *modrevrelstus = NULL;

					char *tpl = NULL;
					char *tplrev = NULL;
					char *revseq = NULL;
					 tpl =(char *) MEM_alloc(150);
					 revseq =(char *) MEM_alloc(150);
                    tag_t tpltag = NULLTAG;

						   tpl=subString(sOpt, 0, 11);

	   printf("\n  tpl  %s \n ", tpl);fflush(stdout);

	   revseq=subString(sOpt, 12, 14);

	   printf("\n revseq   %s \n ", revseq);fflush(stdout);
	    ITK_CALL(STRNG_replace_str(revseq,"_",";",&tplrev));
		printf("\n tpl rev   %s \n ", tplrev);fflush(stdout);




			 ITK_CALL(ITEM_find_item(tpl,&tpltag));
			   if (tpltag)
			   {
				   ITK_CALL(ITEM_find_revision(tpltag,tplrev,&tplrevtag)); 
					   

					
					if (tplrevtag)
					{
					

							 ITK_CALL(AOM_ask_value_string(tplrevtag,"item_id",&moduleid));
							 ITK_CALL(AOM_ask_value_string(tplrevtag,"item_revision_id",&modidrev));
							 printf("\n moduleid %s \n ", moduleid);fflush(stdout);
							 printf("\n modidrev %s \n ", modidrev);fflush(stdout);

					
																	
								
								tag_t	bomline		=	NULLTAG;
								tag_t	*child		=	NULLTAG;
								tag_t	window		=	NULLTAG;
								tag_t	t_revrule	=	NULLTAG;
								tag_t	itemtag;

								int		bcount		=	0;
								int		ib			=	0;
								char		*child_id		=	NULL;
								char		*child_revid	=	NULL;
								char		*child_level						= NULL;
								char		*swparttype						= NULL;
								

								 if(BOM_create_window(&window));
								  {
									if(CFM_find("", &t_revrule));
									if(BOM_set_window_config_rule( window, t_revrule ));
								//	if(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
									if(BOM_set_window_pack_all(window, true));
									if(BOM_set_window_top_line(window,NULLTAG,tplrevtag,NULLTAG,&bomline));
									 {
										if(BOM_line_ask_all_child_lines(bomline,&bcount,&child));
										 {
											if(bcount > 0)
											{
												for(ib = 0 ; ib < bcount ; ib++)
												{
												//	if(AOM_ask_value_string(child[ib],"bl_item_item_id", &child_id));
												//	if(AOM_ask_value_string(child[ib],"bl_rev_item_revision_id", &child_revid));
												//	if(AOM_UIF_ask_value(child[ib],"bl_level_starting_0", &child_level));
																																						

													//	fprintf(fptr,"\n%s,%s,%s",child_level,child_id,child_revid); fflush(stdout);


														  bpart++ ;
														   
															
													childfun(child[ib],&cnt);
												
											       


											    }
											}
											else
											{
												printf("No child part is present for %s",moduleid); fflush(stdout);
											}
										}
									}
									BOM_close_window(window);
								}





						
				  }
             }



					  




printf("\n Total parts in TCUA %d \n",tbcnt);


  ////////////////////////////////////////      


	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

/*	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}



void childfun(tag_t child,int* cnt)
{
	int		count1		=	0;
	int		j		=	0;

	tag_t	*child1		=	NULLTAG;

	char		*child_id1	=	NULL;
	char		*child_revid1	=	NULL;
	char		*subchild_id1	=	NULL;
	char		*subchild_qty	=	NULL;
	char		*swparttype1	=	NULL;

	
	tag_t	rel_type1 = NULLTAG;
	tag_t	itemtag = NULLTAG;
	tag_t	atPrt = NULLTAG;
	tag_t	refrel = NULLTAG;
	tag_t	refrelobjt = NULLTAG;
	tag_t*	refrelobjts = NULLTAG;
	tag_t*	allrevlist = NULLTAG;
	int		solnobjcnt = 0;
	int		refrelcnt = 0;
	int		iref = 0;
	int		k = 0;
	int		revcnt = 0;
	int		at = 0;




	if(BOM_line_ask_all_child_lines(child,&count1,&child1));
	{
	
		for(j = 0 ; j < count1 ; j++)
		{
			if(AOM_ask_value_string(child1[j],"bl_item_item_id", &child_id1));
			if(AOM_ask_value_string(child1[j],"bl_rev_item_revision_id", &child_revid1));
			if(AOM_UIF_ask_value(child1[j],"bl_level_starting_0", &subchild_id1));

               bpart++;
			//	fprintf(fptr,"\n%s,%s,%s",subchild_id1,child_id1,child_revid1); fflush(stdout);
													



            childfun(child1[j],cnt);
			 
              
		
		}
		
	}

		
}


