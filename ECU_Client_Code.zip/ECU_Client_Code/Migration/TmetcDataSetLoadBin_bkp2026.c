
/***********************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                               :   Kalpesh Gondhali
*  Module                               :   TCUA DataSet Uploader
*  Code                                 :   DataSetLoad.c
*  Created on                   :   March 25th, 2015
*
*
* Modification History :
* S.No          Date                                    CR No           Modified By                             Modification Notes
        1               11_oct2019                              -                       Kalpesh Gondhali                Binary file migration
***********************************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <ss/ss_const.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/datasettype.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <sa/tcfile.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define SS_BINARY   020000
#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                                   \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }                                                                               \

//#define TCTYPE_name_size_c 100

extern int ITK_user_main (int argc, char **argv)
{
        int                                             status;
        int                                             result                                                  = 0;
        int                                             count                                                   = 0;
        int                                             iCounter1                                               = 0;
        int                                             i                                                               = 0;
        char                                    *value                                                  = NULL;
        char                                    *argstring1                                             = NULL;
        char                                    *argstring2                                             = NULL;
        char                                    *argstring3                                             = NULL;

        char                                    *user                                                   = NULL;
        char                                    *pass                                                   = NULL;
        char                                    *group                                                  = NULL;
        //char                                  *RefNo                                                  = NULL;

        char                                    *itemId                                                 = NULL;
        //char                                  *BomType                                                = NULL;
        char                                    *revisionID                                             = NULL;
        char                                    *SeqID                                                  = NULL;

        char                                    *BinFileSeq                                             = NULL;
        char                                    *fullPath                                               = NULL;

        char                                    *Status                                                 = NULL;
        char                                    *relation_input                             = NULL;
        char                                    *file_type                                              = NULL;

        FILE                                    *input                                                  = NULL;
        char                                    *object_type                                    = NULL;
        tag_t                                   t_item                                                  = NULLTAG;
        tag_t                                   revision                                                = NULLTAG;
        int                                             ref_count;
        tag_t                                   datasettype                                             = NULLTAG;
        tag_t                                   Newdataset                                              = NULLTAG;
        tag_t                                   tool                                                    = NULLTAG;
        tag_t                                   filetag                                                 = NULLTAG;
        char                                    **ref_list;

        IMF_file_t                              fileDescriptor;
        AE_reference_type_t             tagRefType                                              = 1;
        AE_reference_type_t             tagRefType_new                                  = 1;

        //char                                  *ref_name = NULL;
        char                                    ref_name[AE_reference_size_c + 1];
        //char                                  ref_name_new[AE_reference_size_c + 1];

        int                                             sep_count                                               = 0;
        int                                             iCountSecondary                                 = 0;
        tag_t                                   *secondaryObjects                               = NULL;

        char                                    *Binname                                                = "";
        char                                    **cp_bname                                              = NULL;
        char                                    *itemId1                                                = NULL;
        char                                    *itemId2                                                = NULL;
        char                                    *itemId3                                                = NULL;
        char                                    *aDatasetId                                             = NULL;
        char                                    *parent_name                                    = NULL;
        char                                    *dataset_name;

        int ii,itemcount,j=0;
        int sPartNumberTokint=0;
        int c,t=0;
        tag_t item=NULLTAG;
        tag_t *rev_list=NULL;
        char *format=NULL;
        char *StrWeightArrayMain1=NULL;
        tag_t   relation_type   = NULLTAG;
        tag_t   relation                = NULLTAG;
        //char *ID = "Item ID";
        //char *Rev = "Revision";
        char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
        char **values = (char **) MEM_alloc(2 * sizeof(char *));

        char    **qry_entries   = (char **) MEM_alloc(20 * sizeof(char *));
        char    **qry_values    = (char **) MEM_alloc(20 * sizeof(char *));

        qry_entries[0]  = (char *) MEM_alloc(20 * sizeof(char));
        qry_entries[1]  = (char *) MEM_alloc(20 * sizeof(char));

        qry_values[0]   = (char *) MEM_alloc(20 * sizeof(char));
        qry_values[1]   = (char *) MEM_alloc(20 * sizeof(char));

        tc_strcpy(qry_entries[0], "");
        tc_strcpy(qry_entries[0], "Item ID");
        tc_strcpy(qry_entries[1], "");
        tc_strcpy(qry_entries[1], "Revision");

        tag_t  reln_type = NULLTAG;
        int    n_attches = 0;
        int    Flag_1 =0;
        GRM_relation_t *rellist;
        tag_t  *secondary_objects,primary,objTypeTag,refobject = NULLTAG;
		//tag_t primary=NULLTAG;
        tag_t Fndrelation = NULLTAG;
        int nameRef_cnt;
        tag_t *namRefObject = NULL;
        int  * nFound;
        int   nlFound;
        int   ds;
        int   ass = 0;
        int   cnt = 0;
        tag_t **  datasets;
        int ref_count_d=0;
        int n_prop=0;
        int p=0;

        int n_tags_found = 0;
        tag_t query = NULLTAG;
        tag_t   master          =       NULLTAG;
        tag_t *cntr_objects = NULL;
        tag_t   *t_item1                =       NULLTAG;
        tag_t   latestrev       =       NULLTAG;
        //int n_entries = 2;
        int n_found = 1;
        int dd = 0;
        int org_seq_id_int=0;
        char *inputfile=NULL;
        tag_t *tags_found = NULL;
        char* inputline=NULL;
        tag_t   queryTag        = NULLTAG;
        int resultCount=0;
        tag_t rev_tag = NULLTAG;
		tag_t Dataset_tag=NULLTAG;
        char *itemRevSeq = NULL;
        char **props = NULL;

        char *drawingnumber;
        FILE* fp=NULL;
        char *drawingtype;
        char *relationstr;
        char *user_data_1;
        //char *type_name;
      //  char  type_name[TCTYPE_name_size_c+1];
		char *type_name = NULL;
        char object_name[TCTYPE_name_size_c+1] ;
        tag_t *namRefObject_d = NULL;
		 char DatasetArray[10][50];

        char *DataSetNm2 = NULL;
        char *DataSetNm = NULL;
		char* NR_Filename=NULL;
		int found=0;

        inputfile = ITK_ask_cli_argument("-i=");

        ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
        printf("\nAuto login");fflush(stdout);
        ITK_CALL(ITK_auto_login( ));
        ITK_CALL(ITK_set_journalling( TRUE ));

        fp=fopen(inputfile,"r");
        if(fp!=NULL)
        {
                inputline=(char *) MEM_alloc(500);
                while(fgets(inputline,500,fp)!=NULL)
                {
                        fputs(inputline,stdout);
                        //BomType=strtok(inputline,"^");  //1
                        itemId=strtok(inputline,"^");  //2
                        revisionID=strtok(NULL,"^"); //3
                        SeqID=strtok(NULL,"^"); //4
                        Binname=strtok(NULL,"^"); //5
                        fullPath=strtok(NULL,"^"); //6
                        BinFileSeq=strtok(NULL,"^"); //7
                        //RefNo=strtok(NULL,"^"); //8

                        printf("Item Id is:%s\n",itemId);
                        printf("RevisionID is:%s\n",revisionID);
                        printf("Seq is:%s\n",SeqID);
                        printf("Name of Binary file is:%s\n",Binname);
                        printf("FullPath is:%s\n",fullPath);
                        printf("Bin Sequence is:%s\n",BinFileSeq);
                        //printf("Ref No--->%s\n",RefNo);
                        itemId3 = NULL;
                        itemId3=(char *) MEM_alloc(200);

                        if(QRY_find2("Item Revision...", &queryTag));
                        if (queryTag)
                        {
                                printf("Query Found...!!\n");fflush(stdout);
                        }
                        else
                        {
                                printf("Query not found...!!\n");fflush(stdout);
                        }

                        itemRevSeq = NULL;
                        itemRevSeq=(char *) MEM_alloc(10);

                        strcpy(itemRevSeq,revisionID);
                        strcat(itemRevSeq,"*");
                        strcat(itemRevSeq,SeqID);
                        //strcat(itemRevSeq,"\0");
                        printf("ItemRevSeq is:%s\n",itemRevSeq);

                        tc_strcpy(qry_values[0], "");
                        tc_strcpy(qry_values[0], itemId);
                        tc_strcpy(qry_values[1], "");
                        tc_strcpy(qry_values[1], itemRevSeq);

                        printf("2.parent->item_id[%s]\n",itemId);fflush(stdout);
                        printf("2.parent->item_revision_id[%s]\n", itemRevSeq);fflush(stdout);

                        if(QRY_execute(queryTag, 2, qry_entries, qry_values, &resultCount, &rev_list));
                        printf("Revision Count:%d\n\n", resultCount); fflush(stdout);

                        if(resultCount == 1)
                        {
                                rev_tag = rev_list[0];

                                ITK_CALL(GRM_find_relation_type("IMAN_specification", &reln_type));
                                if(reln_type)
                                printf("\nRelation type found...!!\n");
                                ITK_CALL(GRM_list_secondary_objects(rev_tag, reln_type, &n_attches, &rellist));
                                printf("Total n_attches:%d\n", n_attches);

                                for(i=0;i<n_attches;i++)
                                {
                                        printf("\nInside loop of dataset\n");fflush(stdout);
                                      
                                        primary=rellist[i].secondary;
                                        ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                        ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
                                        printf("Type Name:%s\n",type_name);fflush(stdout);
                                        ITK_CALL(AOM_UIF_ask_value(primary,"object_name",&parent_name));
                                        printf("parent_name:%s\n",parent_name);fflush(stdout);
                                        
								         tc_strcpy(DatasetArray[i],parent_name);
								}
                                ITK_CALL(EPM__parse_string(Binname, ".", &sep_count, &cp_bname));
								
                                printf("\nValue:[%s]\n", cp_bname[sep_count-1]);
                                ITK_CALL(IMF_import_file(fullPath, NULL, SS_BINARY, &filetag, &fileDescriptor));
								ITK_CALL(AOM_save_without_extensions(filetag));
								
                                found=0;
								
								 for(ii=0;ii<n_attches;ii++)
								 {
							    
								     if(tc_strstr(DatasetArray[ii],Binname) != NULL)
                                          {
									         printf("\n at line 318\n");fflush(stdout);
											 found = 1;
											  printf("\nDataset is already attached\n");fflush(stdout);
											  break;
									      }
										  
 								 }
								
								
								
									  if(found==1)
                                        {
									        printf("\n at line 329\n");fflush(stdout);
									            AE_find_dataset2(Binname,&primary);
									
                                                ITK_CALL(AE_ask_dataset_named_refs(primary, &ref_count_d, &namRefObject_d));
											
                                            if(ref_count_d==0)
										    {
											  if(tc_strstr(Binname,".abm")!= NULL || tc_strstr(Binname,".Abm")!= NULL)
                                                {
											            
                                                        tc_strcpy(ref_name,"T5_abm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 abm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".bin")!= NULL || tc_strstr(Binname,".Bin")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bin");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 bin--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".crc")!= NULL || tc_strstr(Binname,".Crc")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_crc");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 crc--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecs")!= NULL || tc_strstr(Binname,".Ecs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 ecs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecu")!= NULL || tc_strstr(Binname,".Ecu")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecu");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 ecu--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hex")!= NULL || tc_strstr(Binname,".Hex")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hex");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 hex--->%d",result);fflush(stdout);
                                                        ITK_CALL(AE_save_myself(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hxk")!= NULL || tc_strstr(Binname,".Hxk")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hxk");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 hxk--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".idx")!= NULL || tc_strstr(Binname,".Idx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_idx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 idx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".iso")!= NULL || tc_strstr(Binname,".Iso")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_iso");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 iso--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".mhx")!= NULL || tc_strstr(Binname,".Mhx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_mhx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 mhx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".n07")!= NULL || tc_strstr(Binname,".N07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_n07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 n07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".par")!= NULL || tc_strstr(Binname,".Par")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_par");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 par--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".prm")!= NULL || tc_strstr(Binname,".Prm")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_prm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 prm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".rec")!= NULL || tc_strstr(Binname,".Rec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_rec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 rec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".srec")!= NULL || tc_strstr(Binname,".Srec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_srec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 srec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s07")!= NULL || tc_strstr(Binname,".S07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_s07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 s07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s19") != 0 || tc_strstr(Binname,".S19") != 0)
                                                {
                                                        tc_strcpy(ref_name,"T5_s19");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 s19--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sal")!= NULL || tc_strstr(Binname,".Sal")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sal");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 sal--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sol")!= NULL || tc_strstr(Binname,".Sol")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sol");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 sol--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".swl")!= NULL || tc_strstr(Binname,".Swl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_swl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 swl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ulp")!= NULL || tc_strstr(Binname,".Ulp")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ulp");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 ulp--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".txt")!= NULL || tc_strstr(Binname,".Txt")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_txt");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 txt--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strcmp(cp_bname[sep_count-1],"s") == 0 || tc_strcmp(cp_bname[sep_count-1],"S") == 0)
                                                {
                                                        tc_strcpy(ref_name,"T5_s");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 s--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".bsl")!= NULL || tc_strstr(Binname,".Bsl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bsl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 bsl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".img")!= NULL || tc_strstr(Binname,".Img")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_img");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 img--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".zip")!= NULL || tc_strstr(Binname,".Zip")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_zip");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 zip--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".sqfs")!= NULL || tc_strstr(Binname,".sqfs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sqfs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 sqfs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												

                                                

                                                
                                        }
							           else
								        {
											for (i=0;i<ref_count_d;i++)
										   {
												AOM_UIF_ask_value(namRefObject_d[i], "original_file_name",&NR_Filename);
												 printf("\nFile name--->%s\n",NR_Filename);fflush(stdout);
												 if(tc_strcmp(Binname,NR_Filename)!=0)
													 
										    { if(tc_strstr(Binname,".abm")!= NULL || tc_strstr(Binname,".Abm")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_abm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 abm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".bin")!= NULL || tc_strstr(Binname,".Bin")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bin");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 bin--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".crc")!= NULL || tc_strstr(Binname,".Crc")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_crc");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 crc--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecs")!= NULL || tc_strstr(Binname,".Ecs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ecs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecu")!= NULL || tc_strstr(Binname,".Ecu")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecu");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ecu--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hex")!= NULL || tc_strstr(Binname,".Hex")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hex");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 hex--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hxk")!= NULL || tc_strstr(Binname,".Hxk")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hxk");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 hxk--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".idx")!= NULL || tc_strstr(Binname,".Idx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_idx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 idx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".iso")!= NULL || tc_strstr(Binname,".Iso")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_iso");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 iso--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".mhx")!= NULL || tc_strstr(Binname,".Mhx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_mhx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 mhx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".n07")!= NULL || tc_strstr(Binname,".N07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_n07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 n07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".par")!= NULL || tc_strstr(Binname,".Par")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_par");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 par--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".prm")!= NULL || tc_strstr(Binname,".Prm")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_prm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 prm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".rec")!= NULL || tc_strstr(Binname,".Rec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_rec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 rec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".srec")!= NULL || tc_strstr(Binname,".Srec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_srec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 srec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s07")!= NULL || tc_strstr(Binname,".S07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_s07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s19")!= NULL || tc_strstr(Binname,".S19")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_s19");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s19--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sal")!= NULL || tc_strstr(Binname,".Sal")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sal");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 sal--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sol")!= NULL || tc_strstr(Binname,".Sol")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sol");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 sol--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".swl")!= NULL || tc_strstr(Binname,".Swl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_swl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 swl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ulp")!= NULL || tc_strstr(Binname,".Ulp")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ulp");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ulp--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".txt")!= NULL || tc_strstr(Binname,".Txt")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_txt");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 txt--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strcmp(cp_bname[sep_count-1],"s") == 0 || tc_strcmp(cp_bname[sep_count-1],"S") == 0)
                                                {
                                                        tc_strcpy(ref_name,"T5_s");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".bsl")!= NULL || tc_strstr(Binname,".Bsl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bsl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 bsl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".img")!= NULL || tc_strstr(Binname,".Img")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_img");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 img--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".zip")!= NULL || tc_strstr(Binname,".Zip")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_zip");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 zip--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".sqfs")!= NULL || tc_strstr(Binname,".sqfs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sqfs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 sqfs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }

											        
										    }
												
										}
                                
                                
								}
							}
								
								
                                
								
                                if(n_attches==0 ||found==0)
                                {
							
							            result=AE_find_dataset2(Binname,&Dataset_tag);
										printf("\nDataset is alredy there but not attached to part");fflush(stdout);fflush(stdout);
										result = GRM_find_relation_type("IMAN_specification", &relation_type);
                                         printf("\nGRM_find_relation_type:%d\n",result);fflush(stdout);
										if(Dataset_tag)
										{
                                                result = GRM_create_relation(rev_tag, Dataset_tag, relation_type, NULLTAG, &relation);
                                                printf("GRM_create_relation:%d\n",result);fflush(stdout);
                                                result = GRM_save_relation(relation);
                                                printf("GRM_save_relation:%d\n",result);fflush(stdout);
									     
									    
										}
										
								    else{
                                        
										if(tc_strstr(Binname,".txt")!= NULL)
										{result = AE_find_datasettype2("Text", &datasettype);}
									else{result = AE_find_datasettype2("T5_IndepBin", &datasettype);}
                                        printf("\nDataset Type found:->%d", result);fflush(stdout);

                                        result = AE_create_dataset_with_id(datasettype,Binname,"", NULL, NULL, &primary);
                                        printf("\nDataset created:->%s", Binname);fflush(stdout);

                                        result = AE_set_dataset_format2(primary, "BINARY_REF");
                                        printf("\nDataset format set:->%d", result);fflush(stdout);

                                        result = AE_set_dataset_tool(primary,tool);
                                        printf("\nTool set:->%d", result);fflush(stdout);fflush(stdout);
                                                
                                               ITK_CALL(IMF_import_file(fullPath, NULL, SS_BINARY, &filetag, &fileDescriptor));
											   printf("File Imported:->%d\n",result);fflush(stdout);

                                                result = AOM_save_without_extensions(filetag);
                                                printf("File saved:->%d\n",result);fflush(stdout);

                                                if(tc_strstr(Binname,".abm")!= NULL || tc_strstr(Binname,".Abm")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_abm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 abm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".bin")!= NULL || tc_strstr(Binname,".Bin")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bin");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 bin--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".crc")!= NULL || tc_strstr(Binname,".Crc")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_crc");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 crc--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecs")!= NULL || tc_strstr(Binname,".Ecs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ecs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ecu")!= NULL || tc_strstr(Binname,".Ecu")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ecu");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ecu--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hex")!= NULL || tc_strstr(Binname,".Hex")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hex");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 hex--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".hxk")!= NULL || tc_strstr(Binname,".Hxk")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_hxk");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 hxk--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".idx")!= NULL || tc_strstr(Binname,".Idx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_idx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 idx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".iso")!= NULL || tc_strstr(Binname,".Iso")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_iso");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 iso--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".mhx")!= NULL || tc_strstr(Binname,".Mhx")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_mhx");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 mhx--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".n07")!= NULL || tc_strstr(Binname,".N07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_n07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 n07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".par")!= NULL || tc_strstr(Binname,".Par")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_par");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 par--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".prm")!= NULL || tc_strstr(Binname,".Prm")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_prm");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 prm--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".rec")!= NULL || tc_strstr(Binname,".Rec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_rec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 rec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".srec")!= NULL || tc_strstr(Binname,".Srec")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_srec");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 srec--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s07")!= NULL || tc_strstr(Binname,".S07")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_s07");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s07--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".s19")!= NULL || tc_strstr(Binname,".S19")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_s19");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s19--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sal")!= NULL || tc_strstr(Binname,".Sal")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sal");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 sal--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".sol")!= NULL || tc_strstr(Binname,".Sol")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sol");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 sol--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".swl")!= NULL || tc_strstr(Binname,".Swl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_swl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 swl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strstr(Binname,".ulp")!= NULL || tc_strstr(Binname,".Ulp")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_ulp");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 ulp--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".txt")!= NULL || tc_strstr(Binname,".Txt")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_txt");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 txt--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
                                                else if(tc_strcmp(cp_bname[sep_count-1],"s") == 0 || tc_strcmp(cp_bname[sep_count-1],"S") == 0)
                                                {
                                                        tc_strcpy(ref_name,"T5_s");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 s--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".bsl")!= NULL || tc_strstr(Binname,".Bsl")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_bsl");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 bsl--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".img")!= NULL || tc_strstr(Binname,".Img")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_img");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 img--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".zip")!= NULL || tc_strstr(Binname,".Zip")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_zip");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        result = AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag);
                                                        printf("\nAE_add_dataset_named_ref2 zip--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }
												else if(tc_strstr(Binname,".sqfs")!= NULL || tc_strstr(Binname,".sqfs")!= NULL)
                                                {
                                                        tc_strcpy(ref_name,"T5_sqfs");
                                                        printf("\nrefname:%s\n", ref_name);fflush(stdout);
                                                        ITK_CALL(AOM_refresh(primary,1));
                                                        ITK_CALL(AE_add_dataset_named_ref2(primary,ref_name,tagRefType,filetag));
                                                        printf("\nAE_add_dataset_named_ref2 sqfs--->%d",result);fflush(stdout);
                                                        ITK_CALL(AOM_save_without_extensions(primary));
                                                        ITK_CALL(AOM_refresh(primary,0));
                                                }

                                                
                                                result = GRM_create_relation(rev_tag, primary, relation_type, NULLTAG, &relation);
                                                printf("GRM_create_relation:%d\n",result);fflush(stdout);
                                                result = GRM_save_relation(relation);
                                                printf("GRM_save_relation:%d\n",result);fflush(stdout);
												AE_set_dataset_tool(primary,tool);
                                                printf("Tool set:->%d\n",result);fflush(stdout);fflush(stdout);
                                                result = AOM_save_without_extensions(primary);

                                       
									  }
								    
									}
						          
								
					    }
                }
        }
        ITK_CALL(POM_logout(false));
        return status;
}
