/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                             :   Raghavendra B T
*  Module                           :   TCUA Desing Rev Uploader
*  Code                                 :   createRevForProe.c
*  Created on     :   March 25, 2015
*
*
* Modification History :
*  S.No        Date                  CR No             Modified By              Modification Notes
   01          02-11-2017            NA                Shivkumar Birnale        L248 t5_PartType=TPL added, ITK_CALL function changed, APIs updated in CreateEffctivity()
   02          13-06-2018            NA                Shivkumar Birnale        DR Status values now taken from the file instead of 'NA'
*****************************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <time.h>
#include <stdio.h>
#include <errno.h>
#include <time.h>
//#include <itk/mem.h>
#include <tccore/releasestatus.h>
#include <tccore/project.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_date.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>


#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCREVIEW        "T5_LcsReview"
#define ERCWORKING   "T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
                if (return_code != ITK_ok)
                {
                                int                                                           index = 0;
                                int                                                           n_ifails = 0;
                                const int*                            severities = 0;
                                const int*                            ifails = 0;
                                const char**      texts = NULL;

                                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                                printf("%3d error(s)\n", n_ifails);
                                for( index=0; index<n_ifails; index++)
                                {
                                                printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                                                TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                                }
                                EMH_clear_errors();
                                
    }
                return return_code;
}

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

int T5_set_value_logical(tag_t* rev, char* prop_name, char* prop_value)
{
                logical propModifiable;
                printf("%s value = '%s' \n",prop_name,prop_value);

                ITK_CALL(AOM_is_modifiable(*rev,prop_name,&propModifiable));
                if(propModifiable)
                {
                                //printf("Inside propModifiable\n");
                                if(tc_strcmp(prop_value,"+")==0||tc_strcasecmp(prop_value,"Y")==0||tc_strcasecmp(prop_value,"true")==0)                                                                //True = +
                                {
											ITK_CALL(AOM_set_value_logical(*rev,prop_name,true));
											//printf("Inside true\n");
                                }
                                else if(tc_strcmp(prop_value,"-")==0||tc_strcasecmp(prop_value,"N")==0||tc_strcasecmp(prop_value,"false")==0)                                        //False = -
                                {
											ITK_CALL(AOM_set_value_logical(*rev,prop_name,false));
											//printf("Inside false\n");
                                }
                                else
                                {
											printf("Incorrect property value \"%s\" passed to the function 'T5_set_value_logical()'. Cannot populate value of %s\n",prop_value,prop_name);
								}
                }
                else
                {
                                printf("%s is not modifiable\n",prop_name);
                }
                return ITK_ok;

}

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,&year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}

int setAttributesOnDesignRev(tag_t* rev,char* projectcode,char *desc,char* designgroup,int sequence_id,char* mod_desc,char* DrawingNoS,char* DrawingIndS,char* Materialclass,char* MaterialInDrwS,char* MaterialThickNessS,char* DeignOwnUnitS,char* ModelIndS,char* ColourIndS,char* WeightS,char* atype,char * t5SpareIndS,char * t5SpareCriteriaS,char * t5ReliabilityS,char * t5RefPartNumberS,char * t5RecyclabilityS,char * t5RecoverableS,char * t5PunMakeBuyIndS,char * t5PunIntialAgS,char * t5PrtCatCodeS,char * t5ProductS,char * t5PkgStdS,char * t5PartStatusS,char * t5PartPropertyS,char * t5PartCodeS,char * t5NcPartNoS,char * t5ListRecSparess,char * t5HomologationReqdS,char * t5HazardousContS,char * t5EnvelopeDimenS,char * t5DismantableS,char * t5ConfigIDS,char * t5ColourIDS,char * t5ClassificationHazS,char * t5CMVRCertificationS,char * t5SurfPrtStdS,char * t5SamplesToApprS,char * t5AsmDisposalS,char * t5FinDisposalInstrS,char * t5RPDisposalInstrS,char * t5SPDisposalInstrS,char * t5WIPDisposalInstrS,char * t5LastModByS,char * t5VerCreatorS,char * t5CAEDocES,char * t5CoatedS,char * t5ConvDocS,char * t5AplCopyOfErcRevS,char * t5AppCodeS,char * t5RqstNumS,char * t5RsnCodeS,char * t5SurfaceAreaS,char * t5VolumeS,char * t5CarIntialAgencyS,char * t5CarMakeBuyIndiS,char * t5ErcIndNameS,char * t5PostRelReqS,char * t5ItmCategoryS,char * t5CopReqS,char * t5AplInvalidateS,char * t5PrtValiStatusS,char * t5DRSubStateS,char * t5KnxtDocIndS,char * t5SimValS,char * t5PerYieldS,char * t5PunStoreLocationS,char * t5AltPartNoS,char * t5RolledupWtS,char * t5PFDModReqdS,char * t5ToolIndentReqdS,char * CategoryNameS,char * t5DsgnDeptS,char* t5AplCopyOfErcSeqS, char* t5_EcuType, char* t5_SwPartType, char* t5_AppForEOL, char* t5_EE_PartType, char* t5_EPReadable)
{
			printf("\n i am in setAttributesOnDesignRev \n");
		double dweight=0;
		tag_t  projobj=NULLTAG;
		tag_t user_tag=NULLTAG;
		char* username=NULL;
		 tag_t class_id1=NULLTAG;
		 char *class_name1;

		//printf("\n keyword Desc ---->%s\n",CategoryNameS);fflush(stdout);
		//printf("\n Party Part Number ---->%s\n",t5RefPartNumberS);fflush(stdout);
		//printf("\n designgroup---->%s\n",designgroup);fflush(stdout);
		
ITK_CALL(AOM_lock(*rev));

if((strcmp(projectcode," ")!=0) && (tc_strstr(projectcode,"NULL")==NULL))
  {
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ProjectCode",projectcode));
  }

ITK_CALL ( AOM_set_value_int(*rev,"sequence_id",sequence_id));


if((strcmp(designgroup," ")!=0) && (tc_strstr(designgroup,"NULL")==NULL))
  {
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DesignGrp",designgroup));
  }


if((strcmp(desc," ")!=0) && (tc_strstr(desc,"NULL")==NULL))
	  {
	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",desc));
	  }

if((strcmp(mod_desc," ")!=0) && (tc_strstr(mod_desc,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));
	}

if((strcmp(DrawingNoS," ")!=0) && (tc_strstr(DrawingNoS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS));
	}

if((strcmp(DrawingIndS," ")!=0)  && (tc_strstr(DrawingIndS,"NULL")==NULL))

	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS));
	}
// Added by Raghavendra B T for more attributes

if((strcmp(t5RefPartNumberS," ")!=0) && (tc_strstr(t5RefPartNumberS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RefPartNumber",t5RefPartNumberS));
	}

if((strcmp(t5PunMakeBuyIndS," ")!=0) && (tc_strstr(t5PunMakeBuyIndS,"NULL")==NULL))
	{

	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS));//Change PNR make buy
	}

if((strcmp(t5PunIntialAgS," ")!=0) && (tc_strstr(t5PunIntialAgS,"NULL")==NULL))
	{

	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunIntialAgency",t5PunIntialAgS));//change PNR Initial Agency
	}

if((strcmp(t5PrtCatCodeS," ")!=0) && (tc_strstr(t5PrtCatCodeS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS));
	}

if((strcmp(t5ProductS," ")!=0) && (tc_strstr(t5ProductS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_Product",t5ProductS));
	}

if((strcmp(t5PkgStdS," ")!=0) && (tc_strstr(t5PkgStdS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PkgStd",t5PkgStdS));
	}

if((strcmp(t5PartStatusS," ")!=0) && (tc_strstr(t5PartStatusS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS));//Create it
	}

if((strcmp(t5PartPropertyS," ")!=0) && (tc_strstr(t5PartPropertyS,"NULL")==NULL))
	{

	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartProperty",t5PartPropertyS));
	}

if((strcmp(t5PartCodeS," ")!=0) && (tc_strstr(t5PartCodeS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS));
	}

if((strcmp(t5NcPartNoS," ")!=0) && (tc_strstr(t5NcPartNoS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_NcPartNo",t5NcPartNoS));
	}

if((strcmp(t5HomologationReqdS," ")!=0) && (tc_strstr(t5HomologationReqdS,"NULL")==NULL))
	{

	ITK_CALL ( AOM_set_value_string(*rev,"t5_HomologationReqd",t5HomologationReqdS));
	}

if((strcmp(t5EnvelopeDimenS," ")!=0) && (tc_strstr(t5EnvelopeDimenS,"NULL")==NULL))
	{

	ITK_CALL ( AOM_set_value_string(*rev,"t5_EnvelopeDimensions",t5EnvelopeDimenS));
	}

if((strcmp(t5ConfigIDS," ")!=0) && (tc_strstr(t5ConfigIDS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ConfigID",t5ConfigIDS));//change its name right now it is ConfigID
	}

if((strcmp(t5ColourIDS," ")!=0) && (tc_strstr(t5ColourIDS,"NULL")==NULL))

	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS));
	}

if((strcmp(t5SurfPrtStdS," ")!=0) && (tc_strstr(t5SurfPrtStdS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SurfPrtStd",t5SurfPrtStdS));
	}

if((strcmp(t5AsmDisposalS," ")!=0) && (tc_strstr(t5AsmDisposalS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AsmDisposalInstr",t5AsmDisposalS));
	}

if((strcmp(t5FinDisposalInstrS," ")!=0) && (tc_strstr(t5FinDisposalInstrS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_FinDisposalInstr",t5FinDisposalInstrS));
	}

if((strcmp(t5RPDisposalInstrS," ")!=0) && (tc_strstr(t5RPDisposalInstrS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RPDisposalInstr",t5RPDisposalInstrS));
	}

if((strcmp(t5SPDisposalInstrS," ")!=0) && (tc_strstr(t5SPDisposalInstrS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SPDisposalInstr",t5SPDisposalInstrS));
	}

if((strcmp(t5WIPDisposalInstrS," ")!=0) && (tc_strstr(t5WIPDisposalInstrS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_WIPDisposalInstr",t5WIPDisposalInstrS));
	}

if((strcmp(t5VerCreatorS," ")!=0) && (tc_strstr(t5VerCreatorS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_VerCreator",t5VerCreatorS));//Create it
	}

if((strcmp(t5CoatedS," ")!=0) && (tc_strstr(t5CoatedS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_Coated",t5CoatedS));
	}

if((strcmp(t5AplCopyOfErcRevS," ")!=0) && (tc_strstr(t5AplCopyOfErcRevS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AplCopyOfErcRev",t5AplCopyOfErcRevS));
	}

if((strcmp(t5AppCodeS," ")==0) && (tc_strstr(t5AppCodeS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AppCode","NA"));
	}

if((strcmp(t5RqstNumS," ")!=0) && (tc_strstr(t5RqstNumS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RqstNum",t5RqstNumS));
	}

if((strcmp(t5RsnCodeS," ")!=0) && (tc_strstr(t5RsnCodeS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RsnCode",t5RsnCodeS));

	}
if((strcmp(t5CarIntialAgencyS," ")!=0) && (tc_strstr(t5CarIntialAgencyS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_CarIntialAgency",t5CarIntialAgencyS));
	}
 
if((strcmp(t5CarMakeBuyIndiS," ")!=0) && (tc_strstr(t5CarMakeBuyIndiS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_CarMakeBuyIndicator",t5CarMakeBuyIndiS));
	}

if((strcmp(t5ErcIndNameS," ")!=0) && (tc_strstr(t5ErcIndNameS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ErcIndName",t5ErcIndNameS));
	}

if((strcmp(t5ItmCategoryS," ")!=0) && (tc_strstr(t5ItmCategoryS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ItmCategory",t5ItmCategoryS));
	}

if((strcmp(t5AplInvalidateS," ")!=0) && (tc_strstr(t5AplInvalidateS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AplInvalidate",t5AplInvalidateS));//create it
	}

if((strcmp(t5PrtValiStatusS," ")!=0) && (tc_strstr(t5PrtValiStatusS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PrtValiStatus",t5PrtValiStatusS));//create it
	}

if((strcmp(t5DRSubStateS," ")!=0) && (tc_strstr(t5DRSubStateS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DRSubState",t5DRSubStateS));//create it
	}

if((strcmp(t5KnxtDocIndS," ")!=0) && (tc_strstr(t5KnxtDocIndS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_KnxtDocInd",t5KnxtDocIndS));//create it
	}

if((strcmp(t5SimValS," ")!=0) && (tc_strstr(t5SimValS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SimVal",t5SimValS));//create it
	}

if((strcmp(t5PerYieldS," ")!=0) && (tc_strstr(t5PerYieldS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PerYield",t5PerYieldS));//create it
	}

if((strcmp(t5PunStoreLocationS," ")!=0) && (tc_strstr(t5PunStoreLocationS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunStoreLocation",t5PunStoreLocationS));//create it
	}

if((strcmp(t5AltPartNoS," ")!=0) && (tc_strstr(t5AltPartNoS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AltPartNo",t5AltPartNoS));//create it
	}

if((strcmp(t5RolledupWtS," ")!=0) && (tc_strstr(t5RolledupWtS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RolledupWt",t5RolledupWtS));//create it
	}

if((strcmp(t5RolledupWtS," ")!=0) && (tc_strstr(t5RolledupWtS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_EstSheetReqd",t5RolledupWtS));//create it
	}

if((strcmp(t5PFDModReqdS," ")!=0) && (tc_strstr(t5PFDModReqdS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PFDModReqd",t5PFDModReqdS));//create it
	}

if((strcmp(t5ToolIndentReqdS," ")!=0) && (tc_strstr(t5ToolIndentReqdS,"NULL")==NULL))
	{
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ToolIndentReqd",t5ToolIndentReqdS));//create it
	}


//Logical Properties are being populated below

if((strcmp(t5CAEDocES," ")!=0) && (tc_strstr(t5CAEDocES,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_CAEDocE",t5CAEDocES);
	}

if((strcmp(t5CMVRCertificationS," ")!=0) && (tc_strstr(t5CMVRCertificationS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_CMVRCertificationReqd",t5CMVRCertificationS);
	}

if((strcmp(t5ConvDocS," ")!=0) && (tc_strstr(t5ConvDocS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_ConvDoc",t5ConvDocS);
	}

if((strcmp(t5CopReqS," ")!=0) && (tc_strstr(t5CopReqS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_CopReq",t5CopReqS);
	}

if((strcmp(t5DismantableS," ")!=0) && (tc_strstr(t5DismantableS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_Dismantable",t5DismantableS);
	}

if((strcmp(t5HazardousContS," ")!=0) && (tc_strstr(t5HazardousContS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_HazardousContents",t5HazardousContS);
	}

if((strcmp(t5ListRecSparess," ")!=0) && (tc_strstr(t5ListRecSparess,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_ListRecSpares",t5ListRecSparess);
	}

if((strcmp(t5PostRelReqS," ")!=0) && (tc_strstr(t5PostRelReqS,"NULL")==NULL))

	{
	T5_set_value_logical(rev,"t5_PostRelReq",t5PostRelReqS);
	}

if((strcmp(t5RecoverableS," ")!=0) && (tc_strstr(t5RecoverableS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_Recoverable",t5RecoverableS);
	}

if((strcmp(t5RecyclabilityS," ")!=0) && (tc_strstr(t5RecyclabilityS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_Recyclability",t5RecyclabilityS);
	}

if((strcmp(t5SamplesToApprS," ")!=0) && (tc_strstr(t5SamplesToApprS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_SamplesToAppr",t5SamplesToApprS);
	}


if((strcmp(t5SpareIndS," ")!=0) && (tc_strstr(t5SpareIndS,"NULL")==NULL))
	{
	T5_set_value_logical(rev,"t5_SpareInd",t5SpareIndS);
	}


//Added by Kalpesh(EE_Part)

			ITK_CALL(POM_class_of_instance(*rev,&class_id1));
			ITK_CALL(POM_name_of_class(class_id1,&class_name1));

			printf("\n\n\t\t class_name found1 :%s",class_name1);

			if (tc_strcmp(class_name1,"T5_EE_PartRevision")==0)
			{
					

				if((strcmp(t5_EcuType," ")!=0) && (tc_strstr(t5_EcuType,"null")==NULL))
					{
					printf("\n\n\t\t t5_EcuType found1 :%s",t5_EcuType);
					ITK_CALL(AOM_set_value_string(*rev, "t5_EcuType", t5_EcuType));
					}

				if((strcmp(t5_SwPartType," ")!=0) && (tc_strstr(t5_SwPartType,"null")==NULL))
					{
					printf("\n\n\t\t t5_SwPartType found1 :%s",t5_SwPartType);
					ITK_CALL(AOM_set_value_string(*rev, "t5_SwPartType", t5_SwPartType));
					}
					
				if((strcmp(t5_AppForEOL," ")!=0) && (tc_strstr(t5_AppForEOL,"null")==NULL))
					{
					printf("\n\n\t\t t5_AppForEOL found1 :%s",t5_AppForEOL);
					ITK_CALL(AOM_set_value_string(*rev, "t5_AppForEOL", t5_AppForEOL));
					}

				if((strcmp(t5_EE_PartType," ")!=0) && (tc_strstr(t5_EE_PartType,"null")==NULL))
					{
					printf("\n\n\t\t t5_EE_PartType found1 :%s",t5_EE_PartType);
					ITK_CALL(AOM_set_value_string(*rev, "t5_EE_PartType", t5_EE_PartType));
					}

				if((strcmp(t5_EPReadable," ")!=0) && (tc_strstr(t5_EPReadable,"null")==NULL))
					{
					printf("\n\n\t\t t5_EPReadable found1 :%s",t5_EPReadable);
					ITK_CALL(AOM_set_value_string(*rev, "t5_EPReadable", t5_EPReadable));
					}
			}
		//End(EE_Part)
		
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_last_mod_user",t5LastModByS));
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_SpareCriteria",t5SpareCriteriaS)); // Create it
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_Reliability",t5ReliabilityS));
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_SurfaceArea",t5SurfaceAreaS));
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_Volume",t5VolumeS));       
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_CopReq",t5CopReqS));
		//ITK_CALL ( AOM_set_value_string(*rev,"t5_ClassificationHazardous",t5ClassificationHazS));
		//

		// Ended by Raghavendra B T for more attributes

		if (strstr(atype,"D")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","D"));
		}
		if (strstr(atype,"A")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","A"));
		}
		if (strstr(atype,"C")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","C"));
		}
		if (strstr(atype,"VC")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VC"));
		}
		if (strstr(atype,"V")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","V"));
		}
		if (strstr(atype,"T")!=NULL)
		{
						ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","T"));
		}
		ITK_CALL(AOM_save_without_extensions(*rev));
		ITK_CALL(AOM_lock(*rev));


		if((strcmp(CategoryNameS," ")!=0) && (tc_strstr(CategoryNameS,"NULL")==NULL))
		{
			
		ITK_CALL ( AOM_set_value_string(*rev,"t5_CategoryName",CategoryNameS));//create it
		}

		//printf("\n t5_MatlClass ---->%s\n",Materialclass);fflush(stdout);
		//printf("\n DeignOwnUnitS ---->%s\n",DeignOwnUnitS);fflush(stdout);

		//ITK_CALL ( AOM_set_value_string(*rev,"t5_MatlClass",Materialclass));

		if((strcmp(MaterialInDrwS," ")!=0) && (tc_strstr(MaterialInDrwS,"NULL")==NULL))
		{		
			ITK_CALL ( AOM_set_value_string(*rev,"t5_Material",MaterialInDrwS));
		}

		if((strcmp(MaterialThickNessS," ")!=0) && (tc_strstr(MaterialThickNessS,"NULL")==NULL))
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_MThickness",MaterialThickNessS));
		}

		if((DeignOwnUnitS!=NULL) && (strcmp(DeignOwnUnitS," ")!=0) && (tc_strstr(DeignOwnUnitS,"NULL")==NULL))
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS));
		}              

		if((strcmp(ColourIndS," ")!=0) && (tc_strstr(ColourIndS,"NULL")==NULL))
		{
			 ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS));
		}

		//printf("\n In function Weight is --->%s\n",WeightS);

		if(WeightS!=NULL)
		{
						dweight=atof(WeightS);
		}
		//printf("\n In function dweight is --->%f\n",dweight);

		ITK_CALL ( AOM_set_value_double(*rev,"t5_Weight",dweight));
		ITK_CALL(AOM_save_without_extensions(*rev));
		ITK_CALL(AOM_unlock(*rev));

		return ITK_ok;
}


int setAttributesOnDesign(tag_t* item,char * desc,char* UnitOfMeasureS,char* LeftRhS)
{
                
		char* ent_uom=NULL;
		tag_t unit_of_measure=NULLTAG;

		ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

		ITK_CALL(AOM_lock(*item));

		if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
		else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
		else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
		else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
		else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
		else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
		else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
		else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
		else {strcpy(ent_uom,"-");}

		printf("\n LeftRhS ... [%s]",LeftRhS);

		printf("\n ent_uom ... [%s]",ent_uom);
		ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
		//ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
		ITK_CALL ( AOM_set_value_string(*item,"t5_LeftRh",LeftRhS));

		ITK_CALL ( AOM_set_value_string(*item,"object_desc",desc));
		ITK_CALL(AOM_save_without_extensions(*item));
		ITK_CALL(AOM_unlock(*item));
		return ITK_ok;
		//ITK_CALL ( AOM_set_value_string(*item,"uom_tag",UnitOfMeasureS));

}

int setLifeCycle(tag_t* itemRev,char* lifeCycleS)
{
		int status;
		tag_t   status2=NULLTAG;
		logical retain=false;
		char* lcsToset=NULL;

		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCWORKING);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,APLWORKING);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,APLRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,STDWORKING);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
						printf("\n This is std rel...");
						strcpy(lcsToset,STDRELEASED);
		}

	//	ITK_CALL(CR_create_release_status(lcsToset,&status2));
		ITK_CALL(RELSTAT_create_release_status(lcsToset,&status2));
		//ITK_CALL(EPM_add_release_status(status2,1,itemRev,retain));
		ITK_CALL(RELSTAT_add_release_status(status2,1,itemRev,retain));

		return ITK_ok;

		//ITK_CALL(AOM_save_without_extensions(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
}

void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
		  {
						tc_strcpy(cMonth,"Jan");
		  }
		  else if(m==2)
		  {
						tc_strcpy(cMonth,"Feb");
		  }
		  else if(m==3)
		  {
						tc_strcpy(cMonth,"Mar");
		  }
		  else if(m==4)
		  {
						tc_strcpy(cMonth,"Apr");
		  }
		  else if(m==5)
		  {
						tc_strcpy(cMonth,"May");
		  }
		  else if(m==6)
		  {
						tc_strcpy(cMonth,"Jun");
		  }
		  else if(m==7)
		  {
						tc_strcpy(cMonth,"Jul");
		  }
		  else if(m==8)
		  {
						tc_strcpy(cMonth,"Aug");
		  }
		  else if(m==9)
		  {
						tc_strcpy(cMonth,"Sep");
		  }
		  else if(m==10)
		  {
						tc_strcpy(cMonth,"Oct");
		  }
		  else if(m==11)
		  {
						tc_strcpy(cMonth,"Nov");
		  }
		  else if(m==12)
		  {
						tc_strcpy(cMonth,"Dec");
		  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
		int day, month, year, nd, nm, ny, ndays;
		int                           ch1;
		int                           Monthas;
		int                           ch;
		time_t  temp;
		date_t DayTommorow ;
		struct tm *timeptr;
		struct tm *timeptr1;
		char pAccessDate[20];
		char pAccessDate1[20];

		char*     strDay;
		char*     strMon;
		char*     strYear;
		char       DateS[20];
		char* cMonth ;
		char CCMonth[30];
		temp = time(NULL);
		tc_strcpy(pAccessDate,"");
		//            timeptr = (struct tm *)localtime(&temp);
		//            ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
		
		//            day=timeptr->tm_mday;
		//            month=(timeptr->tm_mon)+1;
		//            year=(timeptr->tm_year+1900);

		strYear =  strtok(DatetoConvert,"/"); //1
		cMonth  =  strtok(NULL,"'/'"); //2
		strDay  =  strtok(NULL,"'/'"); //3
		Monthas =  atoi(cMonth);
		getMonth(Monthas,CCMonth);

		//printf("\n strYear:%s\n",strYear);
		//printf("\n CCMonth:%s\n",CCMonth);
		//printf("\n strDay:%s\n",strDay);

		tc_strcpy(cnextAccessDate,strDay);
		tc_strcat(cnextAccessDate,"-");
		tc_strcat(cnextAccessDate,CCMonth);
		tc_strcat(cnextAccessDate,"-");
		tc_strcat(cnextAccessDate,strYear);
		tc_strcat(cnextAccessDate," ");
		tc_strcat(cnextAccessDate,"00:00");
		//printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


int days( int m, int y )
{
                if ( m < 1 || m > 12 ) return 0;
                switch ( m ) 
                {
                                case 1: return 31;
                                case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
                }
                return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}


int AssignProject(tag_t  itemRev,char* projectcode)
{ 
		tag_t  projobj=NULLTAG;
		char* username=NULL;
		tag_t user_tag=NULLTAG;

		// ITK_CALL(AOM_lock(itemRev));
		printf("Projectcode [%s]\n",projectcode);
		ITK_CALL (PROJ_find(projectcode,&projobj));
		//printf("\n Assigned to Project\n");fflush(stdout);

		if(projobj !=NULLTAG)
		{
			//POM_get_user(&username,&user_tag);
			//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
			ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
			printf("Assigned to Project\n");fflush(stdout);
		}
		else
		{
			printf("\n Project not found\n");fflush(stdout);
		}
		//   ITK_CALL(AOM_save_without_extensions(itemRev));
		//  ITK_CALL(AOM_unlock(itemRev));
		return ITK_ok;
}


int setEffectivity(tag_t* itemRev,char* date)
{          
	logical   date_is_valid   = FALSE;
	tag_t       st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t    st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;


	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
		//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
						//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
						//WSOM_status_ask_effectivitie
						//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
					//	ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,date,&eff_t));
						ITK_CALL(WSOM_eff_create_with_unit_text(status_list[0],NULLTAG,date,&eff_t));
						ITK_CALL(AOM_save_without_extensions(status_list[0]));
						ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
						printf("\n Cannot load this......");
		}
		//ITK_CALL(AOM_save_without_extensions(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}
	return ITK_ok;
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{

	tag_t   release_status =NULLTAG;
	char   *ReleaseStatus=NULL;
	logical  retain_released_date =false;
	logical  is_v7  ;
	char FrmNextDate[20]={0};
	char ToNextDate[20]={0};
	date_t test_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	int                           ifail         =0;
	char* lcsToset=NULL;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;

	int              status_count=0;
	int              ss=0;
	int              StatusFlg=0;
	tag_t* status_list = NULLTAG;
	
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	//printf("\n lifeCycleS: [%s]\n",lifeCycleS);fflush(stdout);

	if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
	{
		printf("This is Std Release\n");
		strcpy(lcsToset,ERCRELEASED);
	}

	if((strcmp(lcsToset,"T5_LcsErcRlzd")==0))
	{
			ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
			printf("Existing Status_count: %d\n",status_count);
			if (status_count == 0) /* No Status, so the Item is not yet Released */
			{
				printf("No Existing Status, so the Item is not yet Released \n");
			}
			else
			{
					for(ss=0; ss<status_count ; ss++)
					{
							ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
							printf("\n Existing Status : %s\n",class_name);
							if(strcmp(class_name,lcsToset)==0)
							{
								StatusFlg ++;
							}
					}
			}
			if(StatusFlg != 0) return ITK_ok;

			printf("Stamping Releasing Item\n");
			ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status));
			ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,false));

			printf("FromDate : [%s]\n",FromDate);
			printf("ToDate : [%s]\n",ToDate);
			if((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0))  return 0;

			ITK_CALL(WSOM_ask_effectivity_mode(&is_v7));                                             
			printf("v7 Effectivity is:%d\n",is_v7);

			getNextDate(FromDate,FrmNextDate);
			getNextDate(ToDate,ToNextDate);
			printf("FrmNextDate:%s\n",FrmNextDate);
			printf("ToNextDate:%s\n",ToNextDate);

			if(ITK_ok != (ifail = ITK_string_to_date(FrmNextDate, &test_date_1 )))
			{
							return ifail;
			}
			if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
			{
							return ifail;
			}
			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);


				start_end_date[0] = test_date_1;
				start_end_date[1] = test_date_2;

				ITK_CALL(WSOM_status_clear_effectivities ( release_status));
				ITK_CALL(WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
				ITK_CALL(AOM_save_without_extensions(eff_d));
				ITK_CALL(AOM_save_without_extensions(release_status));
				ITK_CALL(AOM_refresh( release_status, 0 ));
				printf("Effectivity Stamping Completed : %s\n",FrmNextDate);

	}
	else
	{
			ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
			printf("Existing status_count: %d\n",status_count);
			if(status_count>0)
			{
				for(ss=0; ss<status_count ; ss++)
				{
					ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
					printf("Existing Status: %s\n",class_name);
					if(strcmp(class_name,lcsToset)==0)
					{
						StatusFlg ++;
						printf("INFO : %d Status already exists. Skipping status addition\n",lcsToset);
					}
				}
			}
			if(StatusFlg == 0)
			{
				printf("Adding Release status to Item Revision\n");
				ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status));
				ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,false));
				printf("Release status addition completed\n");
			}
	}
  return ITK_ok;
}

//====================================================================================

int t5removeAllReleaseStatus (tag_t rev)
{
                
		int                                           status_count;
		tag_t*                   status_list;
		int                                           st_relList_count                = 0; 
		int                                           Rel_cnt                                                                 = 0; 
		tag_t*                   relstatus_list                                      = NULLTAG;
		char                       *WSO_Name_RelVal                      = NULL ; 
		tag_t                     tReleaseStatusList                           = NULLTAG; 
		int                                           n_values                                                              = 0; 
		int                                           cunt1                                                                     = 0; 
		tag_t*                   attr_tags                                                              = NULLTAG; 
		logical                    *is_it_null                                                           = NULL; 
		logical                    *is_it_empty                                     = NULL;
		tag_t                     class_id                                                = NULLTAG;
		char                       *class_name                                                      = NULL;
		logical                    log1;
		int                                           ifail = 0;

                
		ITK_CALL(WSOM_ask_release_status_list(rev,&status_count,&status_list));

		printf("No of Status == %d\n",status_count);
		if(status_count>0) 
		{
				ITK_CALL(POM_class_of_instance(rev,&class_id));
				ITK_CALL(POM_name_of_class(class_id,&class_name));
				ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));
				ITK_CALL(POM_unload_instances (1,&rev));
				ITK_CALL(POM_load_instances(1,&rev,class_id,1));
				ITK_CALL(POM_is_loaded(rev,&log1));
				if(log1 == 1)
				{
						printf("Load Success\n" );
				}
				else
				printf("Load Failure\n");

				ITK_CALL( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
				if(n_values>0)
				{
						ITK_CALL( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
						for (cunt1 =  0; cunt1 <n_values; cunt1++)
						{
								printf("Status removal started\n");
								ITK_CALL(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
								ITK_CALL(POM_save_instances(1,&rev,1));
								ITK_CALL(POM_refresh_instances(1,&rev,class_id,2));
								ifail=ITK_CALL(AOM_lock(rev));
								if(ifail!=ITK_ok)
								{
										printf("The Item Revision cannot be locked. Status Removal failed\n");
										break;
								}
								ITK_CALL(AOM_save_without_extensions(rev));
								ITK_CALL(AOM_refresh(rev,1));
								printf("Status removal completed\n");

								ITK_CALL(POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
								printf("Updated Status Count is :%d\n",n_values);
								ITK_CALL( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
								cunt1=cunt1-1;
						}
						ITK_CALL(AOM_unlock(rev));
				}
				printf("All Statuses removed\n");;fflush(stdout);

		}
		return ITK_ok;   
}
//====================================================================================


extern int ITK_user_main (int argc, char ** argv)
{
	int status;
     int org_seq_id_int=0;
     int j=0;
     int i=0;
     int n_strings = 1;
     int l_strings = 80;          // Arbitrary values - Please verify proper lengths for your application!
     int tempStrLength = 80;
     int index;
     int item_revision_id_int;
     logical isCheckOut=false;
     FILE* fp=NULL;

     char* inputline=NULL;
     char* level=NULL;
     char* item_id=NULL;
     char* item_name=NULL;
     char* item_revision_id=NULL;
     char* item_sequence_id=NULL;
     char* desc=NULL;
     char* qty=NULL;
     char* dtype=NULL;
     char* atype="L";
     char *unit_of_measure="-";

     char* ModDescriptionDupS=NULL;
     char* mod_desc=NULL;
     char* DrawingNoDupS=NULL;
     char* Materialclass=NULL;
     char* DrawingIndDupS=NULL;
     char* DrawingIndS=NULL;
     char* MaterialDupS=NULL;
     char* MaterialS=NULL;
     char* MaterialInDrwDupS=NULL;
     char* MaterialInDrwS=NULL;
     char* LeftRhDupS=NULL;
     char* LeftRhS=NULL;
     char* DeignOwnUnitDupS=NULL;
     char* DeignOwnUnitS=NULL;
     char* ModelIndDupS=NULL;
     char* ModelIndS=NULL;
     char* UnitOfMeasureDupS=NULL;
     char* UnitOfMeasureS=NULL;
     char* ColourIndDupS=NULL;
     char* ColourIndS=NULL;
     char* WeightDupS=NULL;
     char* WeightS=NULL;
     char* MaterialThickNessS=NULL;
     char* DrawingNoS=NULL;
     char* projectcode=NULL;
     char* designgroup=NULL;
     char * rel_list=NULL;
     char * lifecycleS=NULL;

     // Added By Raghavendra B T

     char * t5SpareIndS=NULL;
     char * t5SpareCriteriaS=NULL;
     char * t5ReliabilityS=NULL;
     char * t5RefPartNumberS=NULL;
     char * t5RecyclabilityS=NULL;
     char * t5RecoverableS=NULL;
     char * t5PunMakeBuyIndS=NULL;
     char * t5PunIntialAgS=NULL;
     char * t5PrtCatCodeS=NULL;
     char * t5ProductS=NULL;
     char * t5PkgStdS=NULL;
     char * t5PartStatusS=NULL;
     char * t5PartPropertyS=NULL;
     char * t5PartCodeS=NULL;
     char * t5NcPartNoS=NULL;
     char * t5ListRecSparess=NULL;
     char * t5HomologationReqdS=NULL;
     char * t5HazardousContS=NULL;
     char * t5EnvelopeDimenS=NULL;
     char * t5DismantableS=NULL;
     char * t5ConfigIDS=NULL;
     char * t5ColourIDS=NULL;
     char * t5ClassificationHazS=NULL;
     char * t5CMVRCertificationS=NULL;
     char * t5SurfPrtStdS=NULL;
     char * t5SamplesToApprS=NULL;
     char * t5AsmDisposalS=NULL;
     char * t5FinDisposalInstrS=NULL;
     char * t5RPDisposalInstrS=NULL;
     char * t5SPDisposalInstrS=NULL;
     char * t5WIPDisposalInstrS=NULL;
     char * t5LastModByS=NULL;
     char * t5VerCreatorS=NULL;
     char * t5CAEDocES=NULL;
     char * t5CoatedS=NULL;
     char * t5ConvDocS=NULL;
     char * t5AplCopyOfErcRevS=NULL;
     char * t5AppCodeS=NULL;
     char * t5RqstNumS=NULL;
     char * t5RsnCodeS=NULL;
     char * t5SurfaceAreaS=NULL;
     char * t5VolumeS=NULL;
     char * t5CarIntialAgencyS=NULL;
     char * t5CarMakeBuyIndiS=NULL;
     char * t5ErcIndNameS=NULL;
     char * t5PostRelReqS=NULL;
     char * t5ItmCategoryS=NULL;
     char * t5CopReqS=NULL;
     char * t5AplInvalidateS=NULL;
     char * t5PrtValiStatusS=NULL;
     char * t5DRSubStateS=NULL;
     char * t5KnxtDocIndS=NULL;
     char * t5SimValS=NULL;
     char * t5PerYieldS=NULL;
     char * t5PunStoreLocationS=NULL;
     char * t5AltPartNoS=NULL;
     char * t5RolledupWtS=NULL;
     char * t5PFDModReqdS=NULL;
     char * t5ToolIndentReqdS=NULL;
     char * CategoryNameS=NULL;
     char * t5DsgnDeptS=NULL;
     char * t5AplCopyOfErcSeqS=NULL;
     char *FromDate;
     char *ToDate;
     int si;
     int lat_seq_id_int;
     int lat_seq_id_int_1;
     char *itemRevSeq = NULL;

     // Ended By Raghavendra B T

     char**  stringArray = NULL;
     tag_t newItemTag=NULLTAG;
     tag_t itemRevCreInTag=NULLTAG;
     tag_t itemRevTypeTag=NULLTAG;
     tag_t item=NULLTAG;
     tag_t rev=NULLTAG;
     tag_t *tags_found = NULL;
     char *inputfile=NULL;
     int n_tags_found= 0;
     char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
     char **values = (char **) MEM_alloc(1 * sizeof(char *));

     int stat_count=0;
     int stat_count2=0;
     tag_t relPropTag=NULLTAG ;
     tag_t relPropTag2=NULLTAG ;
     tag_t status2=NULLTAG ;
     tag_t reln_type=NULLTAG ;
     tag_t reln_type2=NULLTAG ;
     tag_t *secondary_objects=NULLTAG ;
     tag_t *secondary_objects2=NULLTAG ;
     tag_t *status1=NULL;
     tag_t  attr_name_id   = NULLTAG;
     tag_t  primary=NULLTAG,objTypeTag=NULLTAG;
     tag_t  primary2=NULLTAG,objTypeTag2=NULLTAG;
     char   *value         = NULL;
     char   *eff_date         = NULL;
                tag_t class_id = NULLTAG;
                char szClassName[100 + 1] = "";
     logical is_it_empty = FALSE;
     logical is_it_null  = FALSE;
     logical is_loaded   = FALSE;
	char   type_name[100+1];
	char   type_name2[100+1];
	int release_status   = 0;
	FILE* fperror=NULL;
	
	//Added by Kalpesh(T5_EE_PartRevision)
	
	char	*t5PnrIntialAgencyS				= NULL;
	char	*t5PnrMakeBuyIndiS				= NULL;
	char	*t5PnrStoreLocS					= NULL;
	char	*t5JsrIntialAgencyS				= NULL;
	char	*t5JsrMakeBuyIndiS				= NULL;
	char	*t5JsrStoreLocS					= NULL;
	char	*t5LkoIntialAgencyS				= NULL;
	char	*t5LkoMakeBuyIndiS				= NULL;
	char	*t5LkoStoreLocS					= NULL;
	char	*t5AhdIntialAgencyS				= NULL;
	char	*t5AhdMakeBuyIndiS				= NULL;
	char	*t5AhdStoreLocS					= NULL;
	char	*t5DwdIntialAgencyS				= NULL;
	char	*t5DwdMakeBuyIndiS				= NULL;
	char	*t5DwdStoreLocS					= NULL;
	char	*t5PunPCBUIntialAgencyS			= NULL;
	char	*t5PunPCBUMakeBuyIndiS			= NULL;
	char	*t5PunPCBUStoreLocS				= NULL;
	char	*t5SgrIntialAgencyS				= NULL;
	char	*t5SgrMakeBuyIndiS				= NULL;
	char	*t5SgrStoreLocS					= NULL;
	char	*t5JdlIntialAgencyS				= NULL;
	char	*t5JdlMakeBuyIndiS				= NULL;
	char	*t5JdlStoreLocS					= NULL;
	char	*PartCreDateS					= NULL;
	char	*PartModDateS					= NULL;
	char	*PartCreator					= NULL;

	char	*t5_EcuType						= NULL;
	char	*t5_SwPartType					= NULL;
	char	*t5_AppForEOL					= NULL;
	char	*t5_EE_PartType					= NULL;
	char	*t5_EPReadable					= NULL;
	//End(T5_EE_PartRevision)

	char *szbom_revision_status = NULL;
	tag_t   window, window2, rule, item_tag = null_tag, top_line;

	inputfile = ITK_ask_cli_argument("-i=");

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
                printf("\n Auto login ");fflush(stdout);
                ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
                printf("\n Auto login .......\n");fflush(stdout);

    //printf("\n Item:[%s]\nRev:[%s]\nSeq[%s]",req_item,req_rev,req_seq);fflush(stdout);

    //ITK_CALL(ITEM_find_item(req_item, &item ));

		fp=fopen(inputfile,"r");
		fperror=fopen("error.log","a");
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(1000);
				while(fgets(inputline,1000,fp)!=NULL)
				{
						//fputs(inputline,stdout);
						level=strtok(inputline,"^");  //1
						item_id=strtok(NULL,"^"); //2
						item_revision_id=strtok(NULL,"^"); //3
						item_sequence_id=strtok(NULL,"^"); //4
						desc=strtok(NULL,"^"); //5
						qty=strtok(NULL,"^"); //6
						dtype=strtok(NULL,"^"); //7
						atype=strtok(NULL,"^"); //8

						projectcode=strtok(NULL,"^"); //9
						designgroup=strtok(NULL,"^"); //10
						mod_desc=strtok(NULL,"^");//11
						DrawingNoS=strtok(NULL,"^");//12
						DrawingIndS=strtok(NULL,"^");//13
						Materialclass=strtok(NULL,"^");//14
						MaterialInDrwS=strtok(NULL,"^");//15
						MaterialThickNessS=strtok(NULL,"^");//16
						LeftRhS=strtok(NULL,"^");//17
						DeignOwnUnitS=strtok(NULL,"^");//18
						ModelIndS=strtok(NULL,"^");//19
						UnitOfMeasureS=strtok(NULL,"^");//20
						ColourIndS=strtok(NULL,"^");//21
						lifecycleS=strtok(NULL,"^");//22
						//eff_date=strtok(NULL,"^");
						WeightS=strtok(NULL,"^");//23
						//Added By Raghavendra B T for more attributes
						t5CMVRCertificationS=strtok(NULL,"^");//24
						t5ClassificationHazS=strtok(NULL,"^");//25
						t5ColourIDS=strtok(NULL,"^");//26
						t5ConfigIDS=strtok(NULL,"^");//27
						t5DismantableS=strtok(NULL,"^");//28
						t5DsgnDeptS=strtok(NULL,"^");//29
						t5EnvelopeDimenS=strtok(NULL,"^");//30
						t5HazardousContS=strtok(NULL,"^");//31
						t5HomologationReqdS=strtok(NULL,"^");//32
						t5ListRecSparess=strtok(NULL,"^");//33
						t5NcPartNoS=strtok(NULL,"^");//34
						t5PartCodeS=strtok(NULL,"^");//35
						t5PartPropertyS=strtok(NULL,"^");//36
						t5PartStatusS=strtok(NULL,"^");//37
						t5PkgStdS=strtok(NULL,"^");//38
						t5ProductS=strtok(NULL,"^");//39
						t5PrtCatCodeS=strtok(NULL,"^");//40
						t5PunIntialAgS=strtok(NULL,"^");//41
						t5PunMakeBuyIndS=strtok(NULL,"^");//42
						t5RecoverableS=strtok(NULL,"^");//43
						t5RecyclabilityS=strtok(NULL,"^");//44
						t5RefPartNumberS=strtok(NULL,"^");//45
						t5ReliabilityS=strtok(NULL,"^");//46
						t5SpareCriteriaS=strtok(NULL,"^");//47
						t5SpareIndS=strtok(NULL,"^");//48
						t5SurfPrtStdS=strtok(NULL,"^");//49
						t5SamplesToApprS=strtok(NULL,"^");//50
						t5AsmDisposalS=strtok(NULL,"^");//51
						t5FinDisposalInstrS=strtok(NULL,"^");//52
						t5RPDisposalInstrS=strtok(NULL,"^");//53
						t5SPDisposalInstrS=strtok(NULL,"^");//54
						t5WIPDisposalInstrS=strtok(NULL,"^");//55
						t5LastModByS=strtok(NULL,"^");//56
						t5VerCreatorS=strtok(NULL,"^");//57
						t5CAEDocES=strtok(NULL,"^");//58
						t5CoatedS=strtok(NULL,"^");//59
						t5ConvDocS=strtok(NULL,"^");//60
						t5AplCopyOfErcRevS=strtok(NULL,"^");//61
						t5AplCopyOfErcSeqS=strtok(NULL,"^");//62
						t5AppCodeS=strtok(NULL,"^");//63
						t5RqstNumS=strtok(NULL,"^");//64
						t5RsnCodeS=strtok(NULL,"^");//65
						t5SurfaceAreaS=strtok(NULL,"^");//66
						t5VolumeS=strtok(NULL,"^");//67
						t5CarIntialAgencyS=strtok(NULL,"^");//68
						t5CarMakeBuyIndiS=strtok(NULL,"^");//69
						t5ErcIndNameS=strtok(NULL,"^");//70
						t5PostRelReqS=strtok(NULL,"^");//71
						t5ItmCategoryS=strtok(NULL,"^");//72
						t5CopReqS=strtok(NULL,"^");//73
						t5AplInvalidateS=strtok(NULL,"^");//74
						t5PrtValiStatusS=strtok(NULL,"^");//75
						t5DRSubStateS=strtok(NULL,"^");//76
						t5KnxtDocIndS=strtok(NULL,"^");//77
						t5SimValS=strtok(NULL,"^");//78
						t5PerYieldS=strtok(NULL,"^");//79
						t5PunStoreLocationS=strtok(NULL,"^");//80
						t5AltPartNoS=strtok(NULL,"^");//81
						t5RolledupWtS=strtok(NULL,"^");//82
						t5PFDModReqdS=strtok(NULL,"^");//83
						t5ToolIndentReqdS=strtok(NULL,"^");//84
						CategoryNameS=strtok(NULL,"^");//85
						FromDate=strtok(NULL,"^");//86
						ToDate=strtok(NULL,"^");//87
						
						//T5_EE_PartRevision
						t5PnrIntialAgencyS		=strtok(NULL,"^");
						t5PnrMakeBuyIndiS		=strtok(NULL,"^");
						t5PnrStoreLocS			=strtok(NULL,"^");
						t5JsrIntialAgencyS		=strtok(NULL,"^");
						t5JsrMakeBuyIndiS		=strtok(NULL,"^");
						t5JsrStoreLocS			=strtok(NULL,"^");
						t5LkoIntialAgencyS		=strtok(NULL,"^");
						t5LkoMakeBuyIndiS		=strtok(NULL,"^");
						t5LkoStoreLocS			=strtok(NULL,"^");
						t5AhdIntialAgencyS		=strtok(NULL,"^");
						t5AhdMakeBuyIndiS		=strtok(NULL,"^");
						t5AhdStoreLocS			=strtok(NULL,"^");
						t5DwdIntialAgencyS		=strtok(NULL,"^");
						t5DwdMakeBuyIndiS		=strtok(NULL,"^");
						t5DwdStoreLocS			=strtok(NULL,"^");
						t5PunPCBUIntialAgencyS	=strtok(NULL,"^");
						t5PunPCBUMakeBuyIndiS	=strtok(NULL,"^");
						t5PunPCBUStoreLocS		=strtok(NULL,"^");
						t5SgrIntialAgencyS		=strtok(NULL,"^");
						t5SgrMakeBuyIndiS		=strtok(NULL,"^");
						t5SgrStoreLocS			=strtok(NULL,"^");
						t5JdlIntialAgencyS		=strtok(NULL,"^");
						t5JdlMakeBuyIndiS		=strtok(NULL,"^");
						t5JdlStoreLocS			=strtok(NULL,"^");
						PartCreDateS			=strtok(NULL,"^");
						PartModDateS			=strtok(NULL,"^");
						PartCreator				=strtok(NULL,"^");

						t5_EcuType				=strtok(NULL,"^");
						t5_SwPartType			=strtok(NULL,"^");
						t5_AppForEOL			=strtok(NULL,"^");
						t5_EE_PartType			=strtok(NULL,"^");
						t5_EPReadable			=strtok(NULL,"^");
						//End (T5_EE_PartRevision)


						printf("\nlifecycleS [%s]\n",lifecycleS);
						printf("mod_desc [%s]\n",mod_desc);
						printf("t5DsgnDeptS [%s]\n",t5DsgnDeptS);
						printf("t5PartCodeS [%s]\n",t5PartCodeS);
						printf("t5VerCreatorS [%s]\n",t5VerCreatorS);
						printf("t5CarIntialAgencyS [%s]\n",t5CarIntialAgencyS);
						printf("t5CarMakeBuyIndiS [%s]\n",t5CarMakeBuyIndiS);
						printf("CategoryNameS [%s]\n",CategoryNameS);
						printf("FromDate [%s]\n",FromDate);
						printf("ToDate [%s]\n",ToDate);
						printf("t5AppCodeS [%s]\n",t5AppCodeS);
						printf("PartCreator [%s]\n",PartCreator);
						printf("t5_EcuType [%s]\n",t5_EcuType);
						printf("t5_SwPartType [%s]\n",t5_SwPartType);
						printf("t5_AppForEOL [%s]\n",t5_AppForEOL);
						printf("t5_EE_PartType [%s]\n",t5_EE_PartType);
						printf("t5_EPReadable [%s]\n",t5_EPReadable);

						//Ended By Raghavendra B T for more attributes

						printf("\nL:[%s],I:[%s],R:[%s],S:[%s],D:[%s],Q:[%s],DType:[%s],AType:[%s]\n",level,item_id,item_revision_id,item_sequence_id,desc,qty,dtype,atype);
						item_revision_id_int=atoi(item_sequence_id);
						attrs[0] ="item_id";
						values[0] = (char *)item_id;
						//Querying with item id
						ITK_CALL(ITEM_find_item(item_id,&item));

						if(item == NULLTAG)
						{
							printf("Creating new Item\n");

							printf("\n WeightS is ---->%s\n",WeightS);
							printf("\n Design Dept is ---->%s\n",t5DsgnDeptS);
							printf("\n Last Modified is ---->%s\n",t5LastModByS);
							printf("\n Item Category is ---->%s\n",t5ItmCategoryS);
							printf("\n yield is ---->%s\n",t5PerYieldS);

							itemRevSeq = NULL;
							itemRevSeq=(char *) MEM_alloc(32);
							strcpy(itemRevSeq,item_revision_id);
							strcat(itemRevSeq,";");

							strcat(itemRevSeq,item_sequence_id);

							printf("\n Category Name is ---->%s\n",CategoryNameS);
							ITK_CALL(ITEM_create_item(item_id,item_id,"T5_EE_Part",default_empty_to_A(itemRevSeq),&item,&rev));
							setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS, CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS, t5_EcuType, t5_SwPartType, t5_AppForEOL, t5_EE_PartType, t5_EPReadable);
							setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);																																																																																																																																																																																																																																																																															
																																																																																																																																																																																																																																																																																																				
							t5removeAllReleaseStatus (rev);																																																																																																																																																																																																																																																																																						
							ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));																																																																																																																																																																																																																																																																															
							ITK_CALL(AssignProject(rev,projectcode));

							//ITK_CALL(AOM_save_without_extensions(item));
							//ITK_CALL(AOM_unlock(item));
						}else
						{
							printf("Item already exists\n");
							itemRevSeq = NULL;
							itemRevSeq=(char *) MEM_alloc(32);
							strcpy(itemRevSeq,item_revision_id);
							strcat(itemRevSeq,";");
							strcat(itemRevSeq,item_sequence_id);

							//printf("itemRevSeq [%s]\n",itemRevSeq);

							ITK_CALL(ITEM_find_revision(item,itemRevSeq,&rev));
							if(rev != NULLTAG)
							{
								ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
								if(isCheckOut)
								{
									ITK_CALL(AssignProject(rev,projectcode));
									fprintf(fperror,"part number is Checked Out:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
								}
								else
								{

									//////////
									tag_t latest_rev_id=NULLTAG;
									char *latestrev_relstus = NULL;
									char *latestrevi = NULL;

									ITK_CALL(ITEM_ask_latest_rev(item,&latest_rev_id));
									ITK_CALL(AOM_UIF_ask_value(latest_rev_id,"release_status_list",&latestrev_relstus));
									printf("\n latest revision Release_status : [%s]", latestrev_relstus );fflush(stdout);

									 ITK_CALL(AOM_ask_value_string(latest_rev_id,"item_revision_id",&latestrevi));
									 printf("\n latest revision id : [%s]", latestrevi);fflush(stdout);

									if(tc_strcmp(itemRevSeq,latestrevi)==0)
									{
										if(tc_strcmp(latestrev_relstus,"ERC Review")==0)
										{

											//////////
										
												 char *relstus = NULL;
												
											 
													 ITK_CALL(AOM_UIF_ask_value(rev,"release_status_list",&relstus));
													 
													 printf("\n   Release_status : [%s]", relstus );fflush(stdout);

															
													 if (( tc_strcmp(relstus,"ERC Review")==0) && (tc_strcmp(lifecycleS,"LcsReview")!=0))
													  {
														 printf("Item Revision has Review in TCUA and Release in TCE\n");

														setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS, t5_EcuType, t5_SwPartType, t5_AppForEOL, t5_EE_PartType, t5_EPReadable);		
											          //uncommented
													
													  //   t5removeAllReleaseStatus(rev);																																																																																																																																																																																																																																																																																				  	
													   ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));		//uncommented	
													   ITK_CALL(AssignProject(rev,projectcode));
																												
													  }
															

											/////////////

										}

									}
									

									/////////////
								
																																																																																																																																																																																																																																																																																	  	
								}
							}
							else
							{
									printf("Item Revision not found\n");

									itemRevSeq = NULL;
									itemRevSeq=(char *) MEM_alloc(32);
									strcpy(itemRevSeq,item_revision_id);
									strcat(itemRevSeq,";");
									strcat(itemRevSeq,item_sequence_id);
									ITK_CALL(ITEM_create_rev(item,default_empty_to_A(itemRevSeq),&rev));
									ITK_CALL(AOM_save_without_extensions(rev));
									ITK_CALL(AOM_unlock(rev));

									setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS,t5_EcuType, t5_SwPartType, t5_AppForEOL, t5_EE_PartType, t5_EPReadable);
									setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);																																																																																																																																																																																																																																																																													  
									t5removeAllReleaseStatus ( rev);																																																																																																																																																																																																																																																																																			  
									ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));																																																																																																																																																																																																																																																																													  	
									ITK_CALL(AssignProject(rev,projectcode));																																																																																																																																																																																																																																																																																	  
									printf("Item Revision Created\n");
							}
						}
						wait ();
						sleep(1);
				printf("===============================================================================================\n");
				}
				return ITK_ok;
		}

		ITK_CALL(POM_logout(false));
		if(fperror)fclose(fperror);fperror=NULL;
		return ITK_ok;
}
