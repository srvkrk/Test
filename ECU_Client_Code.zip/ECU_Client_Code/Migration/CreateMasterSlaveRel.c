	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;
#define STRSIZE 200
#define NUMWORDS 11


int read_value_from_file(char*,int);
int createMasterSlaveRel(char*);
int createContainerHasParaRel(char*);
char* removeUnwantedChar(char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 						= NULL;
	char			* password						= NULL;
	char			* group							= NULL;
	char			* tpl							= NULL;
	char			Data[100]						= "";
	char			outputFile[200]					= "";
	char			* inputFile						= "";
	char			* inputFileHasPara				= "";

	int				MasterSlave						= 0;
	int				ContPara						= 1;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	tpl 			= ITK_ask_cli_argument("-tpl=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(tpl)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\n\t Login Successfull.....!!\n");
			printf("\n\t Welcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\n\tUser is not Privileged Admin User \n\n");
		return -1;
	}	
		

		inputFile = (char *)MEM_alloc(200);
		tc_strcpy(inputFile,"");
		tc_strcat(inputFile,tpl);
		tc_strcat(inputFile,"_MasterSlave.txt");

		inputFileHasPara = (char *)MEM_alloc(200);
		tc_strcpy(inputFileHasPara,"");
		tc_strcat(inputFileHasPara,tpl);
		tc_strcat(inputFileHasPara,"_ContHasPara.txt");

	
		ifail = read_value_from_file(inputFile,MasterSlave);
		CHECK_FAIL;

		ifail = read_value_from_file(inputFileHasPara,ContPara);
		CHECK_FAIL;
		
	printf("\n\t End of program.....!!\n");
	printf("\n\t *********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename, int IsMasterOrContPara)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, " ");

				printf("\nInput IsMasterOrContPara :%d",IsMasterOrContPara);

				if(IsMasterOrContPara == 0)
				{
					ifail = createMasterSlaveRel(item_id);
				}
				else if(IsMasterOrContPara == 1)
				{
					ifail = createContainerHasParaRel(item_id);
				}
				
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
		return ifail;
	}
	fclose(fp);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int createMasterSlaveRel(char* item_id)
{
	int status =ITK_ok;
	char* ErrorText = NULL;

	printf("\n\t I am in createMasterSlaveRel :: Input Item ID is: %s\n\t",item_id);

//	//char* MasterContID = NULL;
//	char* MasterConRev = NULL;
//	char* MasterConSeq = NULL;
//
//	char* SlaveContID = NULL;
//	char* SlaveConRev = NULL;
//	char* SlaveConSeq = NULL;

	tag_t MstrSlvrelation_type  = NULLTAG;
	tag_t MasterRevTag			= NULLTAG;
	tag_t SlaveRevTag			= NULLTAG;
	tag_t relationTag			= NULLTAG;
	tag_t newRelation			= NULLTAG;
	tag_t MasterContItem		= NULLTAG;
	tag_t SlaveContItem		= NULLTAG;

	char *MasterContID		= (char *) MEM_alloc( 20 * sizeof(char) );
	char *MasterConRev		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *MasterConSeq		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *SlaveContID		= (char *) MEM_alloc( 20 * sizeof(char) );
	char *SlaveConRev		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *SlaveConSeq		= (char *) MEM_alloc( 5 * sizeof(char) );

	char* MasterConObjStr	= NULL;
	char* SlaveConObjStr	= NULL;

	char* temMasterRevSeq	=  (char *) MEM_alloc( 20 * sizeof(char) );
	char* temSlveRevSeq		=  (char *) MEM_alloc( 20 * sizeof(char) );
	

	char *token		  = NULL;
	char data[NUMWORDS][STRSIZE];
	char *buffer;
    int i;

	buffer = strtok(item_id, ",");
	i = 0;
	 while (buffer != NULL) {
        strcpy(data[i], buffer);

        //printf("data[%i] = %s\n\t", i+1, data[i]);
        buffer = strtok(NULL, ",");
        i++;
    }

	tc_strcpy(MasterContID, data[0]);
	tc_strcpy(MasterConRev, data[1]);
	tc_strcpy(MasterConSeq, data[2]);
	tc_strcpy(SlaveContID, data[3]);
	tc_strcpy(SlaveConRev, data[4]);
	tc_strcpy(SlaveConSeq, data[5]);



	ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvrelation_type); 
	printf("\n\t after finding T5_ContHasSlave \n");fflush(stdout);

	ITKCALL(ITEM_find_item(MasterContID,&MasterContItem));

	if(MasterContItem)
	{
		ITKCALL(ITEM_find_item(SlaveContID,&SlaveContItem));

		if(SlaveContItem)
		{

			tc_strcpy(temMasterRevSeq,"");
			tc_strcpy(temMasterRevSeq,MasterConRev);
			tc_strcat(temMasterRevSeq,";");
			tc_strcat(temMasterRevSeq,MasterConSeq);

			printf("\n\t After strcpy & strcat temMasterRevSeq : %s\n\t",temMasterRevSeq);

			tc_strcpy(temSlveRevSeq,"");
			tc_strcpy(temSlveRevSeq,SlaveConRev);
			tc_strcat(temSlveRevSeq,";");
			tc_strcat(temSlveRevSeq,SlaveConSeq);

			printf("\n\t After strcpy & strcat temSlveRevSeq : %s\n\t",temSlveRevSeq);

			status	=	ITEM_find_revision(MasterContItem,temMasterRevSeq,&MasterRevTag);
			if(status != ITK_ok)
			{
				EMH_ask_error_text(status,&ErrorText);
				printf("\n\t ErrorText: %s\n\t",ErrorText);

			}
			

			if(MasterRevTag)
			{
				status	=	ITEM_find_revision(SlaveContItem,temSlveRevSeq,&SlaveRevTag);
				if(status != ITK_ok)
				{
					EMH_ask_error_text(status,&ErrorText);
					printf("\n\t ErrorText: %s\n\t",ErrorText);

				}

				if(SlaveRevTag)
				{
					ITKCALL(AOM_ask_value_string(MasterRevTag,"object_string",&MasterConObjStr));
					ITKCALL(AOM_ask_value_string(SlaveRevTag,"object_string",&SlaveConObjStr));

					printf("\n\t MasterContID Obj Str is : %s\n\t",MasterConObjStr);
					printf("\n\t SlaveContID Obj Str is : %s\n\t",SlaveConObjStr);


					GRM_find_relation(MasterRevTag, SlaveRevTag, MstrSlvrelation_type, &relationTag);
					CHECK_FAIL;
					 if(relationTag)
					 {
						printf("\n\t ******* Relation is already available. ******\n");fflush(stdout);

					 }
					 else
					 {
							 ITK_CALL(AOM_refresh(MasterRevTag,1));
							 ITK_CALL(GRM_create_relation(MasterRevTag, SlaveRevTag, MstrSlvrelation_type, NULLTAG,&newRelation));
							 ITK_CALL(GRM_save_relation(newRelation));
							 ITK_CALL(AOM_save_without_extensions(MasterRevTag));
							 ITK_CALL(AOM_refresh(MasterRevTag,0));
							 printf("\n\t ****Relation is created with Master and  slave revision.*****\n");fflush(stdout);
					 }

				}

			}

		}// if for slave container item

	
	} // if for master container item
	
	return status;
	
}
int createContainerHasParaRel(char* item_id)
{
	int status =ITK_ok;
	char* ErrorText = NULL;

	printf("\n\t I am in  createContainerHasParaRel::  Input Item ID is: %s\n\t",item_id);

//	//char* MasterContID = NULL;
//	char* MasterConRev = NULL;
//	char* MasterConSeq = NULL;
//
//	char* SlaveContID = NULL;
//	char* SlaveConRev = NULL;
//	char* SlaveConSeq = NULL;

	tag_t ContHasParaRel_type  = NULLTAG;
	tag_t MasterRevTag			= NULLTAG;
	tag_t SlaveRevTag			= NULLTAG;
	tag_t relationTag			= NULLTAG;
	tag_t newRelation			= NULLTAG;
	tag_t MasterContItem		= NULLTAG;
	tag_t SlaveContItem		= NULLTAG;

	char *MasterContID		= (char *) MEM_alloc( 20 * sizeof(char) );
	char *MasterConRev		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *MasterConSeq		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *SlaveContID		= (char *) MEM_alloc( 20 * sizeof(char) );
	char *SlaveConRev		= (char *) MEM_alloc( 5 * sizeof(char) );
	char *SlaveConSeq		= (char *) MEM_alloc( 5 * sizeof(char) );

	char* MasterConObjStr	= NULL;
	char* SlaveConObjStr	= NULL;

	char* temMasterRevSeq	=  (char *) MEM_alloc( 20 * sizeof(char) );
	char* temSlveRevSeq		=  (char *) MEM_alloc( 20 * sizeof(char) );
	

	char *token		  = NULL;
	char data[NUMWORDS][STRSIZE];
	char *buffer;
    int i;

	buffer = strtok(item_id, ",");
	i = 0;
	 while (buffer != NULL) {
        strcpy(data[i], buffer);

        //printf("data[%i] = %s\n\t", i+1, data[i]);
        buffer = strtok(NULL, ",");
        i++;
    }

	tc_strcpy(MasterContID, data[0]);
	tc_strcpy(MasterConRev, data[1]);
	tc_strcpy(MasterConSeq, data[2]);
	tc_strcpy(SlaveContID, data[3]);
	tc_strcpy(SlaveConRev, data[4]);
	tc_strcpy(SlaveConSeq, data[5]);



	ifail = GRM_find_relation_type("T5_ContHasPara",&ContHasParaRel_type); 
	printf("\n\t after finding T5_ContHasPara \n");fflush(stdout);

	ITKCALL(ITEM_find_item(MasterContID,&MasterContItem));

	if(MasterContItem)
	{
		ITKCALL(ITEM_find_item(SlaveContID,&SlaveContItem));

		if(SlaveContItem)
		{

			tc_strcpy(temMasterRevSeq,"");
			tc_strcpy(temMasterRevSeq,MasterConRev);
			tc_strcat(temMasterRevSeq,";");
			tc_strcat(temMasterRevSeq,MasterConSeq);

			printf("\n\t After strcpy & strcat temMasterRevSeq : %s\n\t",temMasterRevSeq);

			tc_strcpy(temSlveRevSeq,"");
			tc_strcpy(temSlveRevSeq,SlaveConRev);
			tc_strcat(temSlveRevSeq,";");
			tc_strcat(temSlveRevSeq,SlaveConSeq);

			printf("\n\t After strcpy & strcat temSlveRevSeq : %s\n\t",temSlveRevSeq);

			status	=	ITEM_find_revision(MasterContItem,temMasterRevSeq,&MasterRevTag);
			if(status != ITK_ok)
			{
				EMH_ask_error_text(status,&ErrorText);
				printf("\n\t ErrorText: %s\n\t",ErrorText);

			}
			

			if(MasterRevTag)
			{
				status	=	ITEM_find_revision(SlaveContItem,temSlveRevSeq,&SlaveRevTag);
				if(status != ITK_ok)
				{
					EMH_ask_error_text(status,&ErrorText);
					printf("\n\t ErrorText: %s\n\t",ErrorText);

				}

				if(SlaveRevTag)
				{
					ITKCALL(AOM_ask_value_string(MasterRevTag,"object_string",&MasterConObjStr));
					ITKCALL(AOM_ask_value_string(SlaveRevTag,"object_string",&SlaveConObjStr));

					printf("\n\t Container ID Obj Str is : %s\n\t",MasterConObjStr);
					printf("\n\t Parameter ID Obj Str is : %s\n\t",SlaveConObjStr);


					GRM_find_relation(MasterRevTag, SlaveRevTag, ContHasParaRel_type, &relationTag);
					CHECK_FAIL;
					 if(relationTag)
					 {
						printf("\n\t ******* Relation is already available. ******\n");fflush(stdout);

					 }
					 else
					 {
							 ITK_CALL(AOM_refresh(MasterRevTag,1));
							 ITK_CALL(GRM_create_relation(MasterRevTag, SlaveRevTag, ContHasParaRel_type, NULLTAG,&newRelation));
							 ITK_CALL(GRM_save_relation(newRelation));
							 ITK_CALL(AOM_save_without_extensions(MasterRevTag));
							 ITK_CALL(AOM_refresh(MasterRevTag,0));
							 printf("\n\t ****Relation is created with Container and  Parameter revision.*****\n");fflush(stdout);
					 }

				}
				else
				{
					printf("\n\t Slave Cont Rev Not Found \n");fflush(stdout);
				}

			}
			else
			{
				printf("\n\t Master Cont Rev Not Found \n");fflush(stdout);
			}

		}// if for slave container item
		else
		{
			printf("\n\t SlaveContItem Not Found \n");fflush(stdout);
		}

	
	} // if for master container item
	else
	{
		printf("\n\t MasterContItem Not Found \n");fflush(stdout);
	}
	
	return status;
	
}