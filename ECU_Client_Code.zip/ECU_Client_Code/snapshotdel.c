	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int tm_ECUNewSnapshot(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = tm_ECUNewSnapshot(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int tm_ECUNewSnapshot(char* dmlNo)
{
	int ifail = ITK_ok;
	tag_t priObjTag			= NULLTAG;
	tag_t priObjTypeTag		= NULLTAG;
	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t user_tag			= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	char *CurrentTask		= NULL;
	char * parent_name		= NULL;
	char *username			= NULL;
	char *taskTempLT		= NULL;
	char *dmlTaskNo			= NULL;
	char *type_name1        = NULL;
	char* Rel_type			= NULL;
//	char *DMLNo				= NULL;
	tag_t DML_tag			= NULLTAG;
	tag_t *Pendingtasks		= NULLTAG;
	int   noAttachment      = 0;
	int   Pncount			= 0;

	char	 *DML_item				 = NULL;
	char	 *PartNo				 = NULL;
	char	 *RevIDNo				 = NULL;
	char	 *Mod_no				 = NULL;
	char	 *ModRevNo				 = NULL;
	char	 *ModNo1				 = NULL;
	char	 *ModNo2				 = NULL;
	char	 *CCIDNo1				 = NULL;
	char	 *CCIDNo2				 = NULL;
	char*	 jobName= NULL;;
	char*	 CCIDNo= NULL;;
	char*	 PartNumber= NULL;;
	char*	 MPartNumber= NULL;;
	char*	 NewModule= NULL;;
	char*	 SnapshotNo= NULL;;
	char*	 NewCCID= NULL;;
	char*	 ModTok= NULL;;
	char*	 ModNo= NULL;;

	tag_t	 snapshot			  = NULLTAG;
	tag_t	 SnapshotRelationType = NULLTAG;
	//tag_t	 HasRefCCIDRelType    = NULLTAG;
	tag_t	 HasNewCCIDRelTypeX   = NULLTAG;
	tag_t	 IsMemberOfCCID   = NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t	 CCVCHasECUModuleTag  = NULLTAG;
	tag_t	 HasNewCCIDRelType    = NULLTAG;
	tag_t	 Rel_task			  = NULLTAG;

	tag_t *VCObjSO				 = NULLTAG;

	char *DMLprojcode				 = NULL;
	tag_t	ProQryContObj			 = NULLTAG;
	char	*info1					 = NULL;
	char	*info2					 = NULL;
	char	*info3					 = NULL;
	char	*info4					 = NULL;
	char	*info5					 = NULL;
	char	*info6					 = NULL;
	char	*info7					 = NULL;
	char	*info8					 = NULL;
	char	*info9					 = NULL;
	char	*info10					 = NULL;

	tag_t *ProjCnObj				 = NULL;
	int		n_Input					 = 2;
	int    ProjCount				 = 0;
	int    CheckFlag				 = 0;
	char	*qry_Input[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_ProjVal[2] = {"CCID", "PROJCT"};

	//int		ifail;
	int		status;
	int		cnt;
	tag_t    DesignrevTag		  = NULLTAG;
	//tag_t    FinalModuleTag		  = NULLTAG;
	//tag_t    Latestrev			  = NULLTAG;
	tag_t	 top_line;
	tag_t	*children;
	tag_t	 window;

	char	**SSDetails	         = NULL;

	int   n_tags_found	  = 0;
	int   n_rev			  = 0;
	char*  partno         = NULL;
	char*  partno1        = NULL;
	char*  PartType       = NULL;
	char*  MPartType      = NULL;
	char*  MPartNo        = NULL;
	//char*  MPartNumber        = NULL;
	char*  SSRead         = NULL;
	char*  MRevIDNo       = NULL;
	char*  NewMRevIDNo    = NULL;
	char*  ModuleNo       = NULL;
	tag_t DMLToTaskRel    = NULLTAG;
	tag_t *PartsTag		  = NULLTAG;
	int   tsk_cnt		  = 0;
	int   p				  = 0;
	int   t				  = 0;
	int   ss			  = 0;
	int   sr			  = 0;
	int   partcnt		  = 0;
	int   *levels		  = 0;
	int   SSDetRead		  = 0;
	int   CCIDcnt		  = 0;
	int   cc			  = 0;
	int   vc			  = 0;
	int   VCCnt			  = 0;

	tag_t *Tsk_objects    = NULLTAG;
	char* Taskobject_type = NULL;
	char* ReleaseType	  = NULL;
	char* MReleaseType	  = NULL;
	char* NewModuleNum	  = NULL;
	char* NewModulerev	  = NULL;
	char*	CCIDPartNo	  = NULL;
	char*	Cciditem_rev  = NULL;
	//char*	CcidSeq		  = NULL; removed
	char*	NewCCIDNum	  = NULL;
	char*	NewCCIDRem	  = NULL;
	char*	VCnum		  = NULL;
	char* ModPartType     = NULL; //Adi latest 99

	tag_t 	part_tsk_rel  = NULLTAG;
	tag_t 	ModuleTag	  = NULLTAG;
	tag_t 	CCIDRevTag	  = NULLTAG;
	tag_t 	VCTag		  = NULLTAG;
	tag_t 	RevRuleTag	  = NULLTAG;

	int     iWrite		  = 0;
	int		n_parents     = 0;
	tag_t   *parents		= NULL;
	tag_t   CcidMstr		= NULLTAG;
	tag_t   Cciditem		= NULLTAG;
	tag_t   CCIDRefRel_task = NULLTAG;

	tag_t  *CCIDattachments	= NULLTAG;
	tag_t   object_create_input_tag		= NULLTAG;
	tag_t   CCIDdata_type_tag			= NULLTAG;
	tag_t	CCIDItemtag		= NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	NewModuleTag	= NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t	Mod_tag			= NULLTAG;
	//int		n_tags_found	= 0;
	tag_t	*tags_found		= NULL;

	int		id_count	= 0;
	int		icnt	= 0;
	char	**rev_seq	= NULL;

	tag_t	IsMemberOfCCIDx			 = NULLTAG;
	tag_t	ReferencesCCVTag		 = NULLTAG;
	tag_t	IsMemberOfCCID_Rel		 = NULLTAG;
	tag_t	ReferencesCCV_Rel		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t*	attccidTagMem		 = NULLTAG;


	tag_t 	CCIDMastRevTag	  = NULLTAG; //new Adi
	int		CcidSeq     = 0; //new Adi
	int		attccidcnt     = 0; //new Adi
	int		attccidcntMem     = 0; //new Adi
	char cidsequence[10]; //new Adi
	//char cidsequence[10]; //new Adi

	tag_t	sn_rule		 = NULLTAG; //NEW 9 JULY

	SSDetails = (char**)MEM_alloc( 1 * sizeof *SSDetails );

	char cCurrentAccessDate[20]={0};

	/**********JULY 30************/
	tag_t	*snapObj		  = NULLTAG;
	int		SnapshotCount     = 0;
	//char	*qry_Input1[1]	  = {"object_name"}; //Adi AUGUST
	char	*qry_Input1[1]	  = {"Name"};  //Adi AUGUST
	char	*values1[1];
	int		n_Input1					 = 1;
	tag_t	ProQrySSObj			= NULLTAG;
	/**********JULY 30************/

		
			int		count1			=0;
			tag_t	item_tag1		= NULLTAG;
			tag_t	*rev_list		= NULL;

	
		ITK_CALL(POM_get_user_id (&username));//JULY 28
		printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);//JULY 28

		//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
		//printf("\n tm_ECUNewSnapshot...");fflush(stdout);

		//CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
		//printf("\n tm_ECUNewSnapshot CurrentTask: %s",CurrentTask);fflush(stdout);

		//CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		//printf("\n tm_ECUNewSnapshot Parent Name: %s",parent_name);fflush(stdout);

		getCurrentDateTime(cCurrentAccessDate);
		printf("\n tm_ECUNewSnapshot cCurrentAccessDate : %s",cCurrentAccessDate);fflush(stdout);

		//if(strcmp(parent_name,"ECU_SnapShot")==0)
		//if(strcmp(parent_name,"ERC Task Workflow")==0)
		//(strcmp(parent_name,"VI Review(DMU & BOM Analyst Review)")==0)
		// {
		//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
		//printf("\n tm_ECUNewSnapshot Target Attachment:%d",noAttachment);fflush(stdout);

		ifail = ITEM_find_item (dmlNo, &item_tag1);
		CHECK_FAIL;
		ifail = ITEM_list_all_revs (item_tag1, &count1, &rev_list);
		CHECK_FAIL;

		if(count1 > 0)
		{
			DMLTaskTag = rev_list[0];

			if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
			printf("\n tm_ECUNewSnapshot dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout); //getting dml number here

			//if (tc_strstr(dmlTaskNo,"_") != NULL)
			//{
			//	DMLNo=strtok(dmlTaskNo,"_");
			//	printf("\n tm_ECUNewSnapshot DMLNo =====> [%s]", DMLNo);fflush(stdout);
			//}
			//if(ITEM_find_item(DMLNo, &DML_tag)!=ITK_ok)PrintErrorStack();
			if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

			if (DML_tag != NULLTAG)
			{
				if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
				printf(" tm_ECUNewSnapshot DML Rel_type: [%s]", Rel_type);fflush(stdout);

				if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
				{
					if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLprojcode)==ITK_ok) PrintErrorStack();
					if(tc_strlen(DMLprojcode)>0)
					{
						printf("\nRevision Project Code [%s]",DMLprojcode);fflush(stdout);

						if(QRY_find2("ControlObjQry", &ProQryContObj));
						if(ProQryContObj)
						{
							if(QRY_execute(ProQryContObj, n_Input, qry_Input, qry_ProjVal, &ProjCount, &ProjCnObj));
							printf("\n CONT Objects for CCID == %d", ProjCount);fflush(stdout);
						}
						else
						{
							printf("\n ContrlObj not found for CCID");fflush(stdout);
						}

						if(ProjCount >0)
						{
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo3",&info3)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo4",&info4)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo5",&info5)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo6",&info6)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo7",&info7)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo8",&info8)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo9",&info9)!=ITK_ok) PrintErrorStack();
							if (AOM_ask_value_string(ProjCnObj[0],"t5_userinfo10",&info10)!=ITK_ok) PrintErrorStack();

							printf("\n CCID Project Codes List [%s]",info1); fflush(stdout);

							if(tc_strstr(info1,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info2,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info3,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info4,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info5,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info6,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info7,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info8,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info9,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
							if(tc_strstr(info10,DMLprojcode)!=NULL)
							{
								printf("\n CCID Project matches\n"); fflush(stdout);
								CheckFlag=1;
							}
						}
					}
					if(CheckFlag==1)
					{
						//ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
						//ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));

						//printf("\n  Task count is : %d",tsk_cnt);fflush(stdout);
						//if (tsk_cnt>0)
						//{
						//for (t=0;t<tsk_cnt ;t++ )
						//{
						//ITK_CALL(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type));
						////printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
						//if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
						//{
						////printf("\n inside T5_ChangeTaskRevision :\n");fflush(stdout);
						//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
						//if (part_tsk_rel!=NULLTAG)
						//{
						//}
						//}
						//}
						//}
						//////start
						ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&HasNewCCIDRelTypeX));
						printf("\n after finding HasNewCCIDRelTypeX \n");fflush(stdout);

						ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, HasNewCCIDRelTypeX, &attccidcnt, &attccidTag));
						printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);

						for (icnt=0;icnt<attccidcnt;icnt++)
						{
							latest_Cciditem=attccidTag[icnt];

							if(latest_Cciditem)
							{
								tag_t*	snapshottags		 = NULLTAG;
									int snapshotcnt=0;
									int snc=0;
									tag_t HasSnapshotType1=NULLTAG;
									
									tag_t snpashotRel_tag=NULLTAG;

									if(AOM_ask_value_string(latest_Cciditem,"item_id",&CCIDNo)==ITK_ok);
								printf("\n  CCIDNo.:%s\n",CCIDNo);fflush(stdout);
									 
									ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType1));
									ITK_CALL(GRM_list_secondary_objects_only(latest_Cciditem, HasSnapshotType1,&snapshotcnt,&snapshottags));
									printf("\n  snapshotcnt.:%d\n",snapshotcnt);fflush(stdout);
									
									if(snapshotcnt > 1)
									{
										printf("\n  multiple snapshot  availbale\n");fflush(stdout);
										ITK_CALL(GRM_find_relation(latest_Cciditem, snapshottags[0], HasSnapshotType1, &snpashotRel_tag));
										if(snpashotRel_tag)
										{
										 ITK_CALL(GRM_delete_relation(snpashotRel_tag));
											
																		
									/*	 ITK_CALL(AOM_refresh(snpashotRel_tag, TRUE)) ;
										 ITK_CALL(AOM_save_without_extensions(snpashotRel_tag));
										 ITK_CALL(AOM_refresh(snpashotRel_tag,FALSE)) ;*/

										  ITK_CALL(GRM_delete_relation(snpashotRel_tag));
                                          ITK_CALL(GRM_save_relation(snpashotRel_tag));
											
										printf("\n  snpashot deleted for vcid :%s\n",CCIDNo);fflush(stdout);
										}
									}

		
							}
						}

					}
					else
					{
						printf ("\n tm_ECUNewSnapshot project not present in control object \n"); fflush(stdout);
					}

				}
				else
				{
					printf ("\n tm_ECUNewSnapshot Rel type is not ECU PARTS REL \n"); fflush(stdout);
				}
			}
		}

	return ifail;
}
