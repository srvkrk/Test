#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 100
#define NUMWORDS 5

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
        if (return_code != ITK_ok)
        {
                int                             index = 0;
                int                             n_ifails = 0;
                const int*              severities = 0;
                const int*              ifails = 0;
                const char**    texts = NULL;

                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                printf("%3d error(s)\n", n_ifails);
                for( index=0; index<n_ifails; index++)
                {
                        printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                        //TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                        //TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                }
                EMH_clear_errors();

        }
        return return_code;
}


FILE            *output                         = NULL;

char            *sep                            = "^";
int                     ifail                           = ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
        printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
                                        It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;


        char                    * file                                          = NULL;
        char                    Data[100]                                       = "";
        char                    outputFile[200]                         = "";

        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");
        file                    = ITK_ask_cli_argument("-file=");


        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);
        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");
                CHECK_FAIL;
                return ifail;
        }
        else
                {
                        printf("\nLogin Successfull.....!!\n");
                        printf("\nWelcome to Teamcenter.....!!\n");
                }
        ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");
                return -1;
        }

        ifail = read_value_from_file(file);
        CHECK_FAIL;

        printf("\nEnd of program.....!!\n");
        printf("\n*********************\n");
        ifail = ITK_exit_module(true);
        return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
        int                             count                                   = 0;

        char                    *item_id                                = NULL;
        char                    *rev_id                                 = NULL;
        char                    *attr_value                             = NULL;
        char                    temp[240];

        FILE* fp = NULL;
        fp = fopen(Filename, "r");

        if (fp != NULL)
        {
                while (fgets(temp, 240, fp)!= NULL)
                {
                        tc_strcpy(temp,stripBlanks(temp));

                        if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
                        {
                                //item_id = strtok(temp, ",");
                                item_id = strtok(temp, "#");
                                //printf("\nInput Item_id:%s",item_id);

                                ifail = check_rel_status(item_id);
                        }
                        tc_strcpy(temp, "");
                }
        }
        else
        {
                printf("*****File Unable to Open...!!*********");
        }
        fclose(fp);
        //fclose(output);
        return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:
********************************************************************************************/
int check_rel_status(char* item_id)
{
	tag_t item_type_tag                             = NULLTAG;
	tag_t item_create_input_tag             = NULLTAG;
	tag_t cfg_item_create_input_tag = NULLTAG;
	tag_t object                                    = NULLTAG;
	tag_t objectBOMView                             = NULLTAG;
	tag_t bomViewRevion                             = NULLTAG;
	tag_t cfg_object                                = NULLTAG;
	tag_t cfg_item_type_tag                 = NULLTAG;
	tag_t relation_type                             = NULLTAG;
	tag_t new_relation                              = NULLTAG;
	char* error_str                                 = NULL;
	tag_t cc_item_tag    = NULLTAG;;
	tag_t cc_item_Rev_tag = NULLTAG;;

	int             count                   =0;
	tag_t   item_tag                = NULLTAG;
	tag_t   *rev_list               = NULL;


	char *sysCD = (char *) MEM_alloc( 1000 * sizeof(char) );
	char *subSysCD = (char *) MEM_alloc( 1000 * sizeof(char) );
	char *userInfo1 = (char *) MEM_alloc( 1000 * sizeof(char) );
	char *userInfo2 = (char *) MEM_alloc( 1000 * sizeof(char) );
	char *userInfo3 = (char *) MEM_alloc( 1000 * sizeof(char) );
	char *userInfo4 = (char *) MEM_alloc( 1000 * sizeof(char) );


	char *token               = NULL;
	char data[NUMWORDS][STRSIZE];
	char *buffer;
    int i;
	//boolean ccValue = true;

	char *cc_id =  (char *) MEM_alloc( 2000 * sizeof(char) );;
	char *temp      =  (char *) MEM_alloc( 2000 * sizeof(char) );;


	printf("\n\tInput Item ID is: %s\n\t",item_id);

	buffer = strtok(item_id, ";");
	i = 0;
	while (buffer != NULL) 
	{
		strcpy(data[i], buffer);
		//printf("data[%i] = %s\n\t", i+1, data[i]);
		buffer = strtok(NULL, ";");
		i++;
	}

	tc_strcpy(sysCD, data[0]);
	tc_strcpy(subSysCD, data[1]);
	tc_strcpy(userInfo1, data[2]);
	tc_strcpy(userInfo2, data[3]);
	tc_strcpy(userInfo3, data[4]);
	tc_strcpy(userInfo4, data[5]);

    printf("\n\t sysCD :%s", sysCD);
    printf("\n\t subSysCD :%s", subSysCD);
    printf("\n\t userInfo1 :%s", userInfo1);
    printf("\n\t userInfo2 :%s", userInfo2);
	printf("\n\t userInfo3 :%s", userInfo3);
	printf("\n\t userInfo4 :%s", userInfo4);

	    char	*qry_CInput[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_CVal[2] = {sysCD, subSysCD};
	int		n_InputX		= 2;
	int     CountC			= 0;
	tag_t	*CnObjC		    = NULLTAG;
	tag_t	ProQryContObj		    = NULLTAG;

	
//	ITK_CALL(QRY_find2("ControlObjQry", &ProQryContObj));
//	if(ProQryContObj)
//	{
	//  ITK_CALL(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
	//  printf("\n Number of Control Object found  == %d\n", CountC);fflush(stdout);
	//  if(CountC >0)
	//  {
	//     printf("\n Control Object Already Available\n");

	 /*   ITK_CALL(AOM_refresh(CnObjC[0],1));
	    ITK_CALL(AOM_set_value_string(CnObjC[0], "t5_Userinfo1", userInfo1));
		ITK_CALL(AOM_set_value_string(CnObjC[0], "t5_Userinfo2", userInfo2));
		ITK_CALL(AOM_set_value_string(CnObjC[0], "t5_Userinfo3", userInfo3));
		ITK_CALL(AOM_set_value_string(CnObjC[0], "t5_Userinfo4", userInfo4));
		ITK_CALL(AOM_save_without_extensions(CnObjC[0]));
		ITK_CALL(AOM_refresh(CnObjC[0],0));*/

	//  }
	//  else
	//  {
	

		printf("\n\t *****Creating the Control Object*********");
		ITK_CALL(TCTYPE_find_type("T5_ControlObject", "WorkspaceObject", &item_type_tag));
		ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));

		ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", sysCD));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_Syscd", sysCD));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_SubSyscd", subSysCD));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_Userinfo1", userInfo1));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_Userinfo2", userInfo2));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_Userinfo3", userInfo3));
		ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_Userinfo4", userInfo4));
		ITK_CALL(TCTYPE_create_object(item_create_input_tag, &object));
		ITK_CALL(AOM_save_without_extensions(object));
		printf("\n\t *****Control Object Created*********");

	//	}


//	}

    return ifail;
}
