/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*,char*);
int correction(char*,char*,char*,char*,char*,char*);
int tm_PartReplace(char*,tag_t);
int tm_VCIDUpdate(char*,tag_t);



void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
//	ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*partadd					= NULL;
	char 			*revad					= NULL;
	char 			*partrmv					= NULL;
	char 			*revrmv					= NULL;
	char 			*Nextrev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);

				rev_id = strtok(NULL, ",");
				printf("\nrev_id:%s",rev_id);

				partadd = strtok(NULL, ",");
				printf("\n partadd:%s",partadd);

				revad = strtok(NULL, ",");
				printf("\n revad:%s",revad);

				partrmv = strtok(NULL, ",");
				printf("\n partrmv:%s",partrmv);

				revrmv = strtok(NULL, ",");
				printf("\n revrmv:%s",revrmv);



				
		
				ifail = correction(item_id,rev_id,partadd,revad,partrmv,revrmv);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


int correction(char* CCIDNo,char* rev_id,char* partadd,char* revad,char* partrmv,char* revrmv)
{
    tag_t	item_tagc		= NULLTAG;  
    tag_t	itemrev_tagc		= NULLTAG;  
    tag_t	itemrev_tagLatest		= NULLTAG;  
	  int n_references = 0;
	 int *levels1 = NULL;
    tag_t *reference_tags = NULLTAG;
    char **relation_type_name = NULL;
	int ii=0;
	int ifail=0;
	int status;
	char* dmlnumber = NULL;
	char* dmlrevid = NULL;
	char* dmlnumberupdate = NULL;
	char* DMLRevisionid = NULL;
	char* DMLseqid = NULL;
	char	*Rel_type   = NULL;
	char	*Rel_typeupdate   = NULL;
	
	tag_t			tsk_dml_rel_type			= NULLTAG;
	int dmlcount=0;
	tag_t			*DMLRevision				= NULLTAG;
	tag_t			DMLRevTag				= NULLTAG;
	tag_t			additmtag				= NULLTAG;
	tag_t			additmrevtag				= NULLTAG;
	tag_t			partrmvtag				= NULLTAG;
	tag_t			partrmvrevtag				= NULLTAG;
	logical is_latest;
	char	*one   = NULL;
	char	*two   = NULL;
	char	*latestitemrevid   = NULL;
	char* ErrorText =NULL;

    logical lispartfoundlatest =false;
    logical lispartfound =false;
    logical available =false;
   
	

	ifail = ITEM_find_item (CCIDNo, &item_tagc);
	CHECK_FAIL;

	if (item_tagc)
	{
		 
		ifail = ITEM_find_revision(item_tagc,rev_id, &itemrev_tagc);  
		CHECK_FAIL;

	   if (itemrev_tagc)
		{

			ifail = ITEM_find_item (partadd, &additmtag);
			CHECK_FAIL;

				if (additmtag)
				{
				 
				ifail = ITEM_find_revision(additmtag,revad, &additmrevtag);  

					if (additmrevtag)
					{

					ifail = ITEM_find_item (partrmv, &partrmvtag);
					CHECK_FAIL;

						if (partrmvtag)
						{
						 
						ifail = ITEM_find_revision(partrmvtag,revrmv, &partrmvrevtag); 
						CHECK_FAIL;
						  if (partrmvrevtag)
							{
	                     //////////////////

						 		char* datetime = NULL;
								char buffer[80];			
								datetime =(char *) MEM_alloc(sizeof(char)* 50); 
								time_t t = time(NULL);
								struct tm* timeinfo;   
								time(&t);
								timeinfo = localtime(&t);
								strftime(buffer,80,"_%Y-%m-%d-%H-%M-%S",timeinfo);
								printf("\n current date & time : %s \n",buffer);fflush(stdout);

								 char	*selecVCID = NULL;
								char	*selecVCIDrev = NULL;
								char	*tempRev_ID = NULL;
								char	*childrev = NULL;
								char	*childid = NULL;
								fflush(NULL);
								char	*FileName = NULL;
								//char     *f        =   NULL;
								FileName =(char *) MEM_alloc(150);
								FILE *fptr;

								  ifail=AOM_ask_value_string(itemrev_tagc,"item_id",&selecVCID);
								  ifail=AOM_ask_value_string(itemrev_tagc,"item_revision_id",&selecVCIDrev);
								  
								tc_strcpy(FileName,"/user/uaprodtrl/Akshay/ECU_Client_code/correctionlog/");
								tc_strcat(FileName,selecVCID);
								tc_strcat(FileName,"_");
								 ITK_CALL(STRNG_replace_str(selecVCIDrev,";","_",&tempRev_ID));
								printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);
								tc_strcat(FileName,tempRev_ID);
								tc_strcat(FileName,buffer);
								tc_strcat(FileName,"revert.csv");

								printf("kk.log file name is : [%s]\n",FileName);

								fptr = fopen(FileName,"w");

								if(fptr==NULL)
								{
									printf("Error! in log File opening!!!");  fflush(stdout);
									//exit(1);
								}
								else
								{
									printf("\nlog File opening!!!");  fflush(stdout);
								}
							//	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
								 fprintf(fptr,"%s,%s,%s,%s","VCID Number","part added","part removed","Latest VCID");fflush(fptr);



								/////////////////////
								 char	*AddPartnumber = NULL;
								 char	*AddPartnumberrev = NULL;
								 char	*rmvPartnumber = NULL;
								 char	*rmvPartnumberrev = NULL;
								 tag_t			HasSnapshotType				= NULLTAG;
								 tag_t			SnChild				= NULLTAG;
								 tag_t*			ccidTagrf				= NULLTAG;
								 tag_t*	 snapchild				= NULL;
								 tag_t*	 snapchildlatest				= NULL;
								 tag_t*	 snpapshotlatest				= NULL;
								int		CCID 	        = 0;
								int		CCIDlatest 	        = 0;
								int		snapcount 	        = 0;
								int		snapcountlatest 	        = 0;
								int		sn 	        = 0;


								   if( AOM_ask_value_string(additmrevtag,"item_id",&AddPartnumber)!=ITK_ok);
									printf("\n AddPartnumber [%s]  \n",AddPartnumber); fflush(stdout);

									if(AOM_ask_value_string(additmrevtag,"item_revision_id",&AddPartnumberrev)!=ITK_ok);//JULY 28
									printf("\n AddPartnumberrev -------> %s \n", AddPartnumberrev);fflush(stdout);//JULY 28

									if( AOM_ask_value_string(partrmvrevtag,"item_id",&rmvPartnumber)!=ITK_ok);
									printf("\n rmvPartnumber [%s]  \n",rmvPartnumber); fflush(stdout);

									if(AOM_ask_value_string(partrmvrevtag,"item_revision_id",&rmvPartnumberrev)!=ITK_ok);//JULY 28
									printf("\n rmvPartnumberrev -------> %s \n", rmvPartnumberrev);fflush(stdout);//JULY 28

									ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide 
									 printf("\n PartReplace_DML after finding HasSnapshotType \n");fflush(stdout);

									 ITK_CALL(GRM_list_secondary_objects_only(itemrev_tagc, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
									 printf("\n PartReplace_DML -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
									
									 if(CCID >0 )
									 {
											 ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
											 printf("\n  PartReplace_DML -snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

											

											 if(snapcount >0)
											 {

												lispartfound=true;

												ITK_CALL(AOM_lock(ccidTagrf[0]));
												ITK_CALL(FL_remove(ccidTagrf[0],partrmvrevtag));
												printf("\n PartReplace_DML- after fl remove AA1 \n");fflush(stdout);

												ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
												ITK_CALL(AOM_refresh(ccidTagrf[0],0));
												 ITK_CALL(AOM_unlock(ccidTagrf[0]));

												printf("\n  PartReplace_DML Relation OF part deleted in Snapshot %s/%s\n",rmvPartnumber,rmvPartnumberrev);fflush(stdout);

												 
											 }

											   if(lispartfound==true)
												 {

													 ITK_CALL(AOM_lock(ccidTagrf[0]));
													
															
													ifail = FL_insert(ccidTagrf[0],additmrevtag,999);
													if(ifail != ITK_ok)
													{
														EMH_ask_error_text(ifail,&ErrorText);
														printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
													}

													printf("\n PartReplace_DML  Part addition code having sequence - %s/%s \n",AddPartnumber,AddPartnumberrev);fflush(stdout);
								
													ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
												
													ITK_CALL(AOM_refresh(ccidTagrf[0],0));

													ITK_CALL(AOM_unlock(ccidTagrf[0]));

													printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);

													 fprintf(fptr,"\n%s/%s,%s/%s,%s/%s,%s",selecVCID,selecVCIDrev,AddPartnumber,AddPartnumberrev,rmvPartnumber,rmvPartnumberrev,"");fflush(fptr);


													 /////////////// for latest rev
														/*	 ifail = ITEM_ask_latest_rev(item_tagc, &itemrev_tagLatest);
															 CHECK_FAIL;

															 ifail=AOM_ask_value_string(itemrev_tagLatest,"item_revision_id",&latestitemrevid);
															   printf("\n rev_id: %s",rev_id); fflush(stdout);
															   printf("\n latestitemrevid: %s",latestitemrevid); fflush(stdout);

															  ITK_CALL(GRM_list_secondary_objects_only(itemrev_tagLatest, HasSnapshotType, &CCIDlatest, &snpapshotlatest));//3 sept
															 printf("\n PartReplace_DML -Find the SNAPSHOT for CCID2 ---.:%d \n",CCIDlatest);fflush(stdout);
															
															 if(CCIDlatest >0 )
															 {
																	 ITK_CALL(AOM_ask_value_tags(snpapshotlatest[0],"contents",&snapcountlatest,&snapchildlatest));//added
																	 printf("\n  PartReplace_DML -snapcount  contents2 -------> [%d] \n",snapcount);fflush(stdout);


																 if(snapcountlatest >0)
																 {
																 
															 
																  if (tc_strcmp(rev_id,latestitemrevid)!=0)
																  {
																	   printf("\n latest vcid found: %s/%s",selecVCID,latestitemrevid); fflush(stdout);
		 
																	lispartfoundlatest=true;

																	ITK_CALL(AOM_lock(snpapshotlatest[0]));
																	ITK_CALL(FL_remove(snpapshotlatest[0],partrmvrevtag));
																	printf("\n PartReplace_DML- after fl remove AA2 \n");fflush(stdout);

																	ITK_CALL(AOM_save_without_extensions(snpapshotlatest[0]));
																	ITK_CALL(AOM_refresh(snpapshotlatest[0],0));
																	 ITK_CALL(AOM_unlock(snpapshotlatest[0]));

																	printf("\n  PartReplace_DML Relation OF part deleted in latest Snapshot2 %s/%s\n",rmvPartnumber,rmvPartnumberrev);fflush(stdout);

																	
																	   if(lispartfoundlatest==true)
																		 {

																			 ITK_CALL(AOM_lock(snpapshotlatest[0]));
																			
																					
																			ifail = FL_insert(snpapshotlatest[0],additmrevtag,999);
																			if(ifail != ITK_ok)
																			{
																				EMH_ask_error_text(ifail,&ErrorText);
																				printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
																			}

																			printf("\n PartReplace_DML  Part addition code having sequence2 - %s/%s\n",AddPartnumber,AddPartnumberrev );fflush(stdout);
														
																			ITK_CALL(AOM_save_without_extensions(snpapshotlatest[0]));
																		
																			ITK_CALL(AOM_refresh(snpapshotlatest[0],0));

																			ITK_CALL(AOM_unlock(snpapshotlatest[0]));

																			printf("\n  PartReplace_DML Relation OF nr part added in Snapshot2\n");fflush(stdout);

																			fprintf(fptr,"\n%s/%s,%s/%s,%s/%s,%s",selecVCID,latestitemrevid,AddPartnumber,AddPartnumberrev,rmvPartnumber,rmvPartnumberrev,"Latest vcid found");fflush(fptr);

																		 }
																  }
															   }
															}*/





													 ////////////

												 }//lispartfound
									 }// if(CCID >0 )
					   
														   
							 }//if (partrmvrevtag)
                              

						   
				       }

				   }
				

				 }

			}

	}


	return ifail;
}

