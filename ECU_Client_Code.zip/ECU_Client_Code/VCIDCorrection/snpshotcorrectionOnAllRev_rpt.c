/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*,char*);
int correction(char*,char*);
int tm_PartReplace(char*,tag_t);
int tm_VCIDUpdate(char*,tag_t);



void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
//	ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*Nextrev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);

				rev_id = strtok(NULL, ",");
				printf("\nrev_id:%s",rev_id);

			//	Nextrev_id = strtok(NULL, ",");
			//	printf("\nNextrev_id:%s",Nextrev_id);

				
			//	ifail = check_rel_status(item_id,rev_id); //to copy content
				ifail = correction(item_id,rev_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* CCIDNo,char* rev_id)
{
	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;
		
	char		   *firsttok      =NULL;
	char		   *secondtok	  =NULL;
	char		   *thirdtok	  =NULL;
	char		   *forthtok	  =NULL;
	char		   *tempforthtok	  =NULL;
	//char          tempChar       =NULL;
	//char         tempChar1       =NULL;

	char          tempChar       ='\0';
	char         tempChar1       ='\0';
	
	tag_t    Cciditemrev   = NULLTAG;
	
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;
	char*  SnapshotId		= NULL; 

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t	 HasRefCCIDRelTypen		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t  *SnapTag		      = NULLTAG;
	tag_t	ProQrySSObj			= NULLTAG;
	tag_t	*snapObj		  = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t	 SnChild			  = NULLTAG;
	
	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;
	int     sn		       = 0;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	char  *AddPartnumber       = NULL;
	char *  PartItemIdSn      =NULL;
	 char *  PartItemRevIdSn =NULL;

	char*	 OldSnapshotNo				 = NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;
	int		attccidcnt     = 0;
	int SnapCnt =0;
	int		icnt     = 0;
	int		iy     = 0;
	//char*	 CCIDNo= NULL;
	char*	 CCIDNoRev= NULL;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int SnpshotSeq = 0;
	int UpdatedSeq =0;
	char	NewSnapshotSeq[20];
	char	*qry_Input1[1]	  = {"Name"};
	char	*values1[1];
	int		n_Input1 = 1;
	int		SnapshotCount     = 0;
	
	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;


//*************
tag_t	itemrev_tag		= NULLTAG;
	
	ifail = ITEM_find_item (CCIDNo, &item_tag);
	CHECK_FAIL;
	 
    ifail = ITEM_find_revision(item_tag,rev_id, &itemrev_tag);
	CHECK_FAIL;

	if (itemrev_tag)
	{
	 ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide 
	 printf("\n  DataSnap -now get CCID has  HasSnapshotType \n");fflush(stdout);

	 ifail = GRM_list_secondary_objects_only(itemrev_tag,HasSnapshotType,&SnapCnt,&SnapTag);
	 printf("\n  DataSnap -Check how many Snapshot in Refrences Relationship =============>>> %d  \n",SnapCnt);fflush(stdout);

		if(SnapCnt>0)		 				
		{
			for (iy=0;iy<SnapCnt;iy++)
			{
				
					ITK_CALL(AOM_ask_value_string(SnapTag[iy],"current_name",&SnapshotId));

					printf("\n  DataSnap -Snapshot object name-- [%s] \n", SnapshotId);fflush(stdout);

						firsttok = strtok( SnapshotId, "_" );
						secondtok	  = strtok ( NULL, "_" );
						thirdtok	  = strtok ( NULL, "_" );
						forthtok	  = strtok ( NULL, "_" );
						printf("\n\n\t\t  DataSnap -forthtok is :%s",forthtok); fflush(stdout);

						SnpshotSeq=atoi(forthtok);

						printf("\n final snapshot sequence is  =%d \n",SnpshotSeq); fflush(stdout);

						UpdatedSeq=SnpshotSeq -1;
						printf("\n UpdatedSeq snapshot sequence is  =%d \n",UpdatedSeq); fflush(stdout);

						
						 OldSnapshotNo	=NULL; 
						 OldSnapshotNo=(char *) MEM_alloc(30);

						 tempforthtok = NULL;
						 tempforthtok =(char *) MEM_alloc(30);

						 if(UpdatedSeq == 0)
						 {
								printf("\n UpdatedSeq is 0\n"); fflush(stdout);
								printf("\n thirdtok is =%s \n",thirdtok); fflush(stdout);
								printf("\n forthtok is =%s\n",forthtok); fflush(stdout);
								
								//tc_strcpy(tempChar,thirdtok[0]);
								tempChar = thirdtok[0];
								tempChar1 = tempChar -1;

								tc_strcpy(tempforthtok,"");

								tempforthtok[0] = tempChar1;
								//tc_strcpy(tempforthtok,thirdtok - 1);
								//tempforthtok = thirdtok - 1;

								tc_strcpy(forthtok,"");
								tc_strcpy(forthtok,"9");
								
								tc_strcpy(OldSnapshotNo,CCIDNo);   
								tc_strcat(OldSnapshotNo,"_");
								tc_strcat(OldSnapshotNo,tempforthtok);  
								tc_strcat(OldSnapshotNo,"_");
								tc_strcat(OldSnapshotNo,forthtok); 

								printf("\n DataSanp OldSnapshotNo, when UpdatedSeq is 0 --------->[%s]\n",OldSnapshotNo);fflush(stdout);
						 }
						 else 
						 {		
								 sprintf(NewSnapshotSeq,"%d",UpdatedSeq);
								 printf("\n Converted string old snapshot sequence is  =%s \n",NewSnapshotSeq); fflush(stdout);
								 tc_strcpy(OldSnapshotNo,CCIDNo);   
								 tc_strcat(OldSnapshotNo,"_");
								 tc_strcat(OldSnapshotNo,thirdtok);  
								 tc_strcat(OldSnapshotNo,"_");
								 tc_strcat(OldSnapshotNo,NewSnapshotSeq); 
								 printf("\n  DataSnap  OldSnapshotNo is ------->[%s]\n",OldSnapshotNo);fflush(stdout);
						 }

						 if(OldSnapshotNo)
						 {
							values1[0] = OldSnapshotNo;
							if(QRY_find2("SnapShot", &ProQrySSObj));//PRODUCTION
							if(ProQrySSObj)
							{
								if(QRY_execute(ProQrySSObj, n_Input1, qry_Input1, values1, &SnapshotCount, &snapObj));
								printf("\n  DataSnap -qUERY for SnapshotCount count== %d", SnapshotCount);fflush(stdout);
									if (SnapshotCount == 1)
									{
										 printf ("\n For  DataSnap OldSnapshotNoCount  hence creating snapshot %s\n", OldSnapshotNo); fflush(stdout);						
										 ITK_CALL(AOM_ask_value_tags(snapObj[0],"contents",&snapcount,&snapchild));//added
										 printf("\n   DataSnap snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);
										 printf("\n  DataSnap- CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);
										 if(snapcount >0)
										 {
											  for (sn=0;sn<snapcount;sn++)
											  {
													SnChild=snapchild[sn];

													if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
													printf("\n  DataSnap- Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout); 

													if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
													printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28

													ITK_CALL(AOM_lock(SnapTag[iy]));
										
													ITK_CALL(FL_insert(SnapTag[iy],SnChild,999));//new added
													printf("\n   DataSnap -Part addition code- after fl add AA \n");fflush(stdout);
								
													ITK_CALL(AOM_save_without_extensions(SnapTag[iy]));
												
													ITK_CALL(AOM_refresh(SnapTag[iy],0));

													ITK_CALL(AOM_unlock(SnapTag[iy]));

													printf("\n For DataSnap Relation OF nr part added in Snapshot\n");fflush(stdout);
											  }// for snapcount

										 }//snapcount
									}//SnapshotCount
							}// ProQrySSObj
							
						 }// if for OldSnapshotNo
			}// for loop SnapCnt ends
		}// if for SnapCnt

	  



	}


	return ifail;
}




int correction(char* CCIDNo,char* rev_id)
{
    tag_t	item_tagc		= NULLTAG;  
    tag_t	itemrev_tagc		= NULLTAG;  
    tag_t	itemrev_tagLatest		= NULLTAG;  
	  int n_references = 0;
	 int *levels1 = NULL;
    tag_t *reference_tags = NULLTAG;
    char **relation_type_name = NULL;
	int ii=0;
	int ifail=0;
	
	char* dmlnumber = NULL;
	char* dmlrevid = NULL;
	char* dmlnumberupdate = NULL;
	char* DMLRevisionid = NULL;
	char* DMLseqid = NULL;
	char	*Rel_type   = NULL;
	char	*Rel_typeupdate   = NULL;
	
	tag_t			tsk_dml_rel_type			= NULLTAG;
	int dmlcount=0;
	tag_t			*DMLRevision				= NULLTAG;
	tag_t			DMLRevTag				= NULLTAG;
	logical is_latest;
	char	*one   = NULL;
	char	*two   = NULL;
	char	*latestitemrevid   = NULL;

	ifail = ITEM_find_item (CCIDNo, &item_tagc);
	CHECK_FAIL;
	 
    ifail = ITEM_find_revision(item_tagc,rev_id, &itemrev_tagc);  
	CHECK_FAIL;
	  
	 ifail = ITEM_ask_latest_rev(item_tagc, &itemrev_tagLatest);
     CHECK_FAIL;

	if (itemrev_tagc)
	{

	ifail=WSOM_where_referenced2((const tag_t)itemrev_tagc, 1, &n_references, &levels1,&reference_tags, &relation_type_name);
	 for (ii = 0; ii < n_references; ii++)
		{ 

		 	char*  type_name1 = NULL;

																
			ifail=WSOM_ask_object_type2(reference_tags[ii], &type_name1);

			printf("\n type_name1 --->[%s]\n", type_name1); fflush(stdout);
			printf("\n relation_type_name[ii] --->[%s]\n", relation_type_name[ii]); fflush(stdout);
		 if((tc_strcmp(type_name1,"ChangeRequestRevision")==0) && (tc_strcmp(relation_type_name[ii],"T5_HasNewCCID")==0))
		 {
		   printf("\n DML Found \n"); fflush(stdout);

		   
		   

		   if(AOM_ask_value_string(reference_tags[ii],"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
			  printf("\n for DataSnap_DML DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);

			  if((tc_strcmp(Rel_type,"Backward Compatible VCID Release")==0)||(tc_strcmp(Rel_type,"BKC")==0))
			 {
				  ifail=AOM_ask_value_string(reference_tags[ii],"item_id",&dmlnumber);
		          ifail=AOM_ask_value_string(reference_tags[ii],"item_revision_id",&dmlrevid);
				 printf("\n ***************************BKC dml found [%s/%s]*****************************",dmlnumber,dmlrevid); fflush(stdout);
					  ifail = tm_PartReplace(dmlnumber,itemrev_tagc);

					  ifail=AOM_ask_value_string(itemrev_tagLatest,"item_revision_id",&latestitemrevid);
					   printf("\n rev_id: %s",rev_id); fflush(stdout);
					   printf("\n latestitemrevid: %s",latestitemrevid); fflush(stdout);

				/*	  if (tc_strcmp(rev_id,latestitemrevid)!=0)
					  {
						   ifail = tm_PartReplace(dmlnumber,itemrev_tagLatest);
					  }*/
					

			 }

	
		 }

		 if((tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0) && (tc_strcmp(relation_type_name[ii],"CMHasSolutionItem")==0))
		 {
		   printf("\n DML Found \n"); fflush(stdout);

		   ifail=AOM_ask_value_string(reference_tags[ii],"item_id",&dmlnumberupdate);
		   printf("\ndmlnumber: %s",dmlnumberupdate); fflush(stdout);


		   ifail = GRM_find_relation_type("T5_DMLTaskRelation",&tsk_dml_rel_type);
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ifail = GRM_list_primary_objects_only(reference_tags[ii],tsk_dml_rel_type,&dmlcount,&DMLRevision);
				printf("\n\n\t\t ***********DML Revision from Task **********: %d",dmlcount);fflush(stdout);

				ifail=AOM_ask_value_string(DMLRevision[0],"item_id",&one);
				ifail=AOM_ask_value_string(DMLRevision[1],"item_id",&two);

                printf("\n one: [%s]", one);fflush(stdout);
                printf("\n two: [%s]", two);fflush(stdout);


				ifail = ITEM_rev_sequence_is_latest(DMLRevision[0],&is_latest);
					printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
				//	if(is_latest != true)
				//	{
					//	printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);

			//		} else
			//		{
						DMLRevTag = DMLRevision[0];
					



					 if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_typeupdate)!=ITK_ok)PrintErrorStack();
					 
					  printf("\n for DataSnap_DML DMLworkflow  DML Rel_type: [%s]", Rel_typeupdate);fflush(stdout);

					 if((tc_strcmp(Rel_typeupdate,"VCID Update")==0)||(tc_strcmp(Rel_typeupdate,"CCU")==0))
						{
						 if(AOM_ask_value_string(DMLRevTag,"item_id",&DMLRevisionid)!=ITK_ok)PrintErrorStack();
						 if(AOM_ask_value_string(DMLRevTag,"item_revision_id",&DMLseqid)!=ITK_ok)PrintErrorStack();

						  printf("\n *******************************VCID Update dml found[%s/%s]******************************",DMLRevisionid,DMLseqid); fflush(stdout);
						 // ifail = tm_VCIDUpdate(DMLRevisionid,itemrev_tagc);

						}
				//	}
				
			}

	
		 }

		 




		}

	

	}


	return ifail;
}

int tm_PartReplace(char* item_id,tag_t itemrev_tagc)
{


	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;
		
	char		   *firsttok      =NULL;
	 char		   *secondtok	  =NULL;
	 char		   *thirdtok	  =NULL;
	 char		   *forthtok	  =NULL;
	
	tag_t    Cciditemrev   = NULLTAG;
	
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;
	char*  SnapshotId		= NULL; 

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t	 HasRefCCIDRelTypen		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t  *SnapTag		      = NULLTAG;
	tag_t	ProQrySSObj			= NULLTAG;
	tag_t	*snapObj		  = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	
	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;
	int     sn		       = 0;

	char* username				= NULL;
	char* parent_name			= NULL;
	char* dmlTaskNo			= NULL;
	char* AddPartnumber       = NULL;
	char* PartItemIdSn       =NULL;
	 char* PartItemRevIdSn   =NULL;

	char*	 OldSnapshotNo				 = NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;
	int		attccidcnt     = 0;
	int SnapCnt =0;
	int		icnt     = 0;
	int		iy     = 0;
	char*	 CCIDNo= NULL;
	char*	 CCIDNoRev= NULL;
	char   *PartRevID =NULL;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int SnpshotSeq = 0;
	int UpdatedSeq =0;
	char	NewSnapshotSeq[20];
	char	*qry_Input1[1]	  = {"Name"};
 	char	*values1[1];
	char*	 Cciditem_rev			 = NULL;
	int		n_Input1					 = 1;
	int		SnapshotCount     = 0;
	int		in     = 0;
	int		zr     = 0;
	int		partaddcnt	= 0;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t *ccidTagrf=NULLTAG;

	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;
	char* ErrorText =NULL;
	logical lispartfound;

	/////////////////////
	/*	time_t temp;
	 
		struct tm *timeptr;
	 
		char pAccessDate[30];
	 
		char *sCurrentDate = NULL;
	 
		char *sCurrentDateDup = NULL;
	 
		char *strToBereplaceddate;
	 
		char *strToBeUsedInsteaddate;
		sCurrentDate =(char *) MEM_alloc(30);
	 
		sCurrentDateDup =(char *) MEM_alloc(30);
	 
		strToBereplaceddate = (char*)malloc(5);
	 
		strToBeUsedInsteaddate = (char*)malloc(5);
		
		time(&temp);
	 
		timeptr = localtime(&temp );
	 
		tc_strcpy(pAccessDate,"");
	 
		strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
	 
		tc_strcpy(sCurrentDate,pAccessDate);
	 
		tc_strcpy(strToBereplaceddate,"/");
	 
		tc_strcpy(strToBeUsedInsteaddate,"-");

		ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);*/


		char* datetime = NULL;
		char buffer[80];			
		datetime =(char *) MEM_alloc(sizeof(char)* 50); 
		time_t t = time(NULL);
		struct tm* timeinfo;   
		time(&t);
		timeinfo = localtime(&t);
		strftime(buffer,80,"_%Y-%m-%d-%H-%M-%S",timeinfo);
		printf("\n current date & time : %s \n",buffer);fflush(stdout);











	///////////////

	//////////////////
char	*selecVCID = NULL;
char	*selecVCIDrev = NULL;
char	*tempRev_ID = NULL;
fflush(NULL);



char	*FileName = NULL;
//char     *f        =   NULL;
FileName =(char *) MEM_alloc(150);
FILE *fptr;

	  ifail=AOM_ask_value_string(itemrev_tagc,"item_id",&selecVCID);
	  ifail=AOM_ask_value_string(itemrev_tagc,"item_revision_id",&selecVCIDrev);
	  
	tc_strcpy(FileName,"/user/uaprodtrl/Akshay/ECU_Client_code/correctionlog/");
	tc_strcat(FileName,selecVCID);
	tc_strcat(FileName,"_");
	 ITK_CALL(STRNG_replace_str(selecVCIDrev,";","_",&tempRev_ID));
	printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);
    tc_strcat(FileName,tempRev_ID);
	tc_strcat(FileName,"_");
    tc_strcat(FileName,item_id);
	tc_strcat(FileName,"_");
    tc_strcat(FileName,buffer);
	tc_strcat(FileName,".csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		//exit(1);
	}
	else
	{
		printf("\nlog File opening!!!");  fflush(stdout);
	}
//	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
     fprintf(fptr,"%s,%s,%s,%s","VCID Number","part Removed","part Added","DML Number");fflush(fptr);



	/////////////////////

	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;	

	if(count>0)
	{
		printf("\n Inside for --PartReplace_DML DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
		DMLTaskTag = rev_list[0];
		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout); 
		if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();
		if (MdmDML_tag != NULLTAG)
		{
			printf("\n DML tag is not null for PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);
			if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

			if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
			printf("\n for PartReplace_DML DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
			printf("\n PartReplace_DML DML number for :%s \n",dmlNo);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
			ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

			printf("\n Finding the PartReplace_DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);
			if (Mdmtsk_cnt>0)
			{
				printf("\n Inside task count for PartReplace_DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);
				 for (in=0;in<Mdmtsk_cnt ;in++ )
				 {
						 printf("\n Now inside the task find as Task count is for PartReplace_DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
						 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[in],"object_type",&Taskobj_type));
						 printf("\n Now PartReplace_DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);
						 
						 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[in],"item_id",&TskNmMdm));
						 printf("\n Now PartReplace_DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

						 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Part_tobeAdd));

						 ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));
						 printf("\n  No of part attached to task in  PartReplace_DML -: %d \n",partaddcnt);fflush(stdout);
						 if (partaddcnt>0)
						 {
							  printf("\n Inside part found in PartReplace_DML attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);
							  for (zr=0;zr<partaddcnt;zr++)
							  {
									CcidADDTag=addPartsTag[zr];
									AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
									if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
									printf("\n PartReplace_DML CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

									if(AOM_ask_value_string(CcidADDTag,"item_revision_id",&PartRevID)!=ITK_ok);//JULY 28
									printf("\n PartReplace_DML  Revision of part -------> %s \n", PartRevID);fflush(stdout);//JULY 28

//									ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &part_tsk_relc));
//									printf("\n PartReplace_DML -Expanding T5_HasNewCCID  expanded \n"); fflush(stdout);
//									if (part_tsk_relc!=NULLTAG)
//									{
//										 printf("\n for PartReplace_DML Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);
//										 ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag, part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
//										 printf("\n for PartReplace_DML Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);
//										 if (partcntrf>0)
//										 {
//											 for (pr=0;pr<partcntrf;pr++)
//											 {
//												 printf("\n Inside Dataset found for PartReplace_DML \n"); fflush(stdout);
//												 DesignrevTagR=PartsTagrf[pr];
//
//												 if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
//												 printf("\n PartReplace_DML -In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);
//
//											     if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
//												 printf("\n PartReplace_DML-  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

												 ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide 
												 printf("\n PartReplace_DML after finding HasSnapshotType \n");fflush(stdout);

												 ITK_CALL(GRM_list_secondary_objects_only(itemrev_tagc, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
												 printf("\n PartReplace_DML -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
												
												 if(CCID >0 )
												 {
														 ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
														 printf("\n  PartReplace_DML -snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

														 printf("\n PartReplace_DML- CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

														 if(snapcount >0)
														 {
															 
															 lispartfound=false;
																 for (sn=0;sn<snapcount;sn++)
																 {
																	     
																		 SnChild=snapchild[sn];

																		if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
																		printf("\n PartReplace_DML -Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout); 

																		if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
																		printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28
																		
																		printf("\n Part number attached to task -> %s \n", AddPartnumber);fflush(stdout);//JULY 28

																		if(tc_strcmp(AddPartnumber,PartItemIdSn)==0)
																		{
																			printf("\n ######  As name is same  in PartReplace_DML------->  \n");fflush(stdout);
																			printf("\n  snapshot part number revision id - %s ------->  \n",PartItemRevIdSn );fflush(stdout);
																			printf("\n  task  part number revision id- %s ------->  \n",PartRevID );fflush(stdout);

																			if(tc_strcmp(PartItemRevIdSn,PartRevID)!=0)
																			{
																				printf("\n Revision is not same snapshot part rev id -%s and task part id -%s  \n",PartItemRevIdSn , PartRevID );fflush(stdout);
																				lispartfound=true;
																		/*		ITK_CALL(AOM_lock(ccidTagrf[0]));
																				ITK_CALL(FL_remove(ccidTagrf[0],SnChild));
																				printf("\n PartReplace_DML- after fl remove AA \n");fflush(stdout);
															
																				ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
																			
																				ITK_CALL(AOM_refresh(ccidTagrf[0],0));
				
																				ITK_CALL(AOM_unlock(ccidTagrf[0]));
				
																				printf("\n  PartReplace_DML Relation OF part-%s deleted in Snapshot\n",PartItemIdSn);fflush(stdout);*///rpt

																				//////////


																				fprintf(fptr,"\n%s/%s,%s/%s,%s/%s,%s-%s",selecVCID,selecVCIDrev,PartItemIdSn,PartItemRevIdSn,AddPartnumber,PartRevID,item_id,"BKC");fflush(fptr);





																			}


																		}

																 }
																 
															/*	 if(lispartfound==true)
																 {

																	 ITK_CALL(AOM_lock(ccidTagrf[0]));
																	
																			
																	ifail = FL_insert(ccidTagrf[0],CcidADDTag,999);
																	if(ifail != ITK_ok)
																	{
																		EMH_ask_error_text(ifail,&ErrorText);
																		printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
																	}

																	printf("\n PartReplace_DML  Part addition code-%s having sequence - %s \n",AddPartnumber,PartRevID );fflush(stdout);
												
																	ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
																
																	ITK_CALL(AOM_refresh(ccidTagrf[0],0));

																	ITK_CALL(AOM_unlock(ccidTagrf[0]));

																	printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);

																 }*///rpt
																 
																 
																 
																 // for loop for snapcount ends

															 }// snapcount ends 
												 } // if CCID is not having snapshot ::
											

										//	 }// for for partcntrf ends

										// }// if partcntrf ends 

								//	}// if for part_tsk_relc ends

							  }// for loop for partaddcnt ends

						 }// if for partaddcnt

				 }// for loop for Mdmtsk_cnt ends

			}// if for Mdmtsk_cnt ends

		}// if ends for MdmDML_tag

	}// if ends for count 

	return ifail;
}




int tm_VCIDUpdate(char* item_id,tag_t DesignrevTagR)
{

		tag_t *attachments	   = NULLTAG;
		tag_t DMLTaskTag	   = NULLTAG;
		tag_t rootTask		   = NULLTAG;
		char *CurrentTask		= NULL;
		char *BusUnitDV			= NULL;
		char *DMLDRdvp			= NULL;
		char *dmlNo             =NULL;
		char* DMLtype		    = NULL;
		char* Taskobj_type	    = NULL;
		char *TskNmMdm			=  NULL;
		char  *Partnumber       = NULL;
		char   *Prt_object_type =NULL;
		char *DatasetName	    = NULL;
		char  *mdmclass_name;

		tag_t    Cciditemrev   = NULLTAG;

		char    *str		    = NULL;
		tag_t	*DMLObj		    = NULLTAG;
		int ifail;
		int status;
		int iStatus			=0;
		char	*Rel_type   = NULL;

		tag_t	MdmDMLRevTag		= NULLTAG;
		tag_t	ProQryObj			= NULLTAG;
		tag_t	ProQryContObj		= NULLTAG;
		tag_t   MdmDMLToTaskRel	    = NULLTAG;
		tag_t	MdmDML_tag			= NULLTAG;
		tag_t   class_id            =NULLTAG;
		tag_t  *MdmTsk_objects	    = NULLTAG;
		tag_t  *MdmPartsTag          =NULLTAG;
		tag_t	Mdm_tsk_rel		    = NULLTAG;
		tag_t	DesignrMdmTag		= NULLTAG;
		tag_t	part_tsk_relc		    = NULLTAG;

		int     noAttachment      = 0;
		int     Mdmtsk_cnt		  = 0;
		int     tt		          = 0;
		int     partcnt		       = 0;

		char * username				= NULL;
		char * parent_name			= NULL;
		char * dmlTaskNo			= NULL;
		int		newccidcnt			= 0;
		int		AttachmentCount	    = 0;
		int		partcntrf	        = 0;
		int		pr					= 0;

		int	n_entriesMdm = 2;
		int n_foundMdm = 0;
		int p = 0;
		char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
		char *qry_valuesMdm[2]  = {"CCU", "DML"};
		tag_t   *MdmCtrObj      = NULLTAG;
		tag_t   *PartsTagrf       = NULLTAG;
		tag_t  TagMdmControl     = NULLTAG;
//		tag_t	DesignrevTagR	 = NULLTAG;
		tag_t  reln_typeMdm       = NULLTAG;
		tag_t  Mdmrelation        =NULLTAG;

		//

		char*	Cciditem_rev  = NULL;
		char *  PartItemRevIdSn =NULL;
		tag_t	 HasSnapshotType	  = NULLTAG;
		tag_t*	 snapchild				= NULL;
		tag_t  *addPartsTag          =NULLTAG;
		tag_t	 SnChild			  = NULLTAG;
		tag_t	 Part_tobeAdd	    = NULLTAG;
		tag_t	CcidADDTag		= NULLTAG;
		int		CCID 	        = 0;
		int		snapcount 	        = 0;
		int		sn 	        = 0;

		int		partaddcnt				= 0;
		int		z				= 0;
			tag_t *ccidTagrf=NULLTAG;
				char *  PartItemIdSn      =NULL;
		char  *AddPartnumber       = NULL;
		char  *AddPartnumberrevid       = NULL;
	
			char  *ErrorText       = NULL;

			////////////////////////


char	*selecVCID = NULL;
char	*selecVCIDrev = NULL;
char	*tempRev_ID = NULL;
fflush(NULL);




char	*FileName = NULL;
//char     *f        =   NULL;
FileName =(char *) MEM_alloc(150);
FILE *fptr;

	  ifail=AOM_ask_value_string(DesignrevTagR,"item_id",&selecVCID);
	  ifail=AOM_ask_value_string(DesignrevTagR,"item_revision_id",&selecVCIDrev);
	  
	tc_strcpy(FileName,"/user/uaprodtrl/Akshay/ECU_Client_code/correctionlog/");
	tc_strcat(FileName,selecVCID);
	tc_strcat(FileName,"_");
	 ITK_CALL(STRNG_replace_str(selecVCIDrev,";","_",&tempRev_ID));
	printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);
    tc_strcat(FileName,tempRev_ID);
	tc_strcat(FileName,".csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		//exit(1);
	}
	else
	{
		printf("\nlog File opening!!!");  fflush(stdout);
	}
//	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
     fprintf(fptr,"%s,%s,%s,%s","VCID Number","part Removed","part Added","DML Number");fflush(fptr);





			/////////////


		ITK_CALL(POM_get_user_id (&username));
		printf("\n Inside the CCU_DML DMLworkflow Session User is : %s \n",username); fflush(stdout);

		//if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		//{
			//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			//printf("\n Inside the CCU_DML DMLworkflow  ...\n");fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			//printf("\n CCU_DML DMLworkflow - CurrentTask: %s \n",CurrentTask);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			//printf("\n CCU_DML DMLworkflow - Parent Name: %s \n",parent_name);fflush(stdout);

			//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			//printf("\n CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);

			int		count			=0;
			tag_t	item_tag		= NULLTAG;
			tag_t	*rev_list		= NULL;

			ifail = ITEM_find_item (item_id, &item_tag);
			CHECK_FAIL;
			
			ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
			CHECK_FAIL;	

		   if(count > 0)
			{
				printf("\n Inside for --CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
				DMLTaskTag = rev_list[0];

				if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
				printf("\n CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

				if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();

				if (MdmDML_tag != NULLTAG)
				{
				  printf("\n DML tag is not null for CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

				  if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

				  if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
				  printf("\n for CCU DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);
	//
	//			   ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
	//			   printf("\n CCU DML business unit for :%s \n",BusUnitDV);fflush(stdout);
	//
	//				ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_PlntToPlnt",&DMLDRdvp));
	//				printf("\n CCU Plant to plant  :%s \n",DMLDRdvp);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
					printf("\n CCU DML number for DVP :%s \n",dmlNo);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&DMLtype));
					printf("\n CCU DML Release type for DVP :%s \n",DMLtype);fflush(stdout);

					printf("\n  Inside the CCU DML - \n");fflush(stdout);

					if(QRY_find2("ControlObjQry", &TagMdmControl));

					if(QRY_execute(TagMdmControl, n_entriesMdm, qry_entriesMdm, qry_valuesMdm, &n_foundMdm, &MdmCtrObj));
					printf("\n Control Object found for CCU DML == %d \n", n_foundMdm);fflush(stdout);

					if(n_foundMdm==1)
					{
						printf("\n As Control Object found for CCU DML == %d  \n", n_foundMdm);fflush(stdout);

					  ITK_CALL(POM_class_of_instance(MdmDMLRevTag,&class_id));
					  ITK_CALL(POM_name_of_class(class_id,&mdmclass_name));
					  printf("\n Inside the CCU DML class_name of Task :%s \n",mdmclass_name);fflush(stdout);

					  ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
					  ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

					  printf("\n Finding the CCU DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);

					   if (Mdmtsk_cnt>0)
					  {
						  printf("\n Inside task count for CCU DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);

						 for (tt=0;tt<Mdmtsk_cnt ;tt++ )
						{
							 printf("\n Now inside the task find as Task count is for CCU DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
							 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[tt],"object_type",&Taskobj_type));
							 printf("\n Now CCU DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

							 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[tt],"item_id",&TskNmMdm));
							 printf("\n Now CCU DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

							// part remmoval

														 //ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &Mdm_tsk_rel));
							 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Mdm_tsk_rel));


							 if (Mdm_tsk_rel!=NULLTAG)
							 {
							   printf("\n Has solution item relationship found \n");fflush(stdout);
							   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Mdm_tsk_rel, &partcnt, &MdmPartsTag));
							   printf("\n  No of part attached to task in ccu DML -: %d \n",partcnt);fflush(stdout);

								if (partcnt>0)
								{
								   printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partcnt);fflush(stdout);
								   for (p=0;p<partcnt;p++)
								   {
										DesignrMdmTag=MdmPartsTag[p];
										Partnumber =(char *) MEM_alloc(20 * sizeof(char *));
										if( AOM_ask_value_string(DesignrMdmTag,"item_id",&Partnumber)!=ITK_ok);

										printf("\n Part attached to task Revision Number- [%s]  \n",Partnumber); fflush(stdout);

	
										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_relc));
										printf("\n Forccu -Expanding CMHasSolutionItem  expanded \n"); fflush(stdout);

									//	 if (part_tsk_relc!=NULLTAG)
									//	 {
									//	   printf("\n Forccu Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

									//	   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
									//	   printf("\n Forccu Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

										  // if (partcntrf>0)
											// {
											 //  for (pr=0;pr<partcntrf;pr++)
											//	 {
													printf("\n Inside Dataset found forccu  \n"); fflush(stdout);
												//	DesignrevTagR=PartsTagrf[pr];

													if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
													printf("\n In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

													if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
													printf("\n  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

													ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
													printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

													 ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
													 printf("\n Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
													
													if(CCID > 0)
													{
															 ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
														printf("\n  snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

														printf("\n 444  CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

														if(snapcount >0)
														{
															 for (sn=0;sn<snapcount;sn++)
															 {
																SnChild=snapchild[sn];

																	if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
																	printf("\n Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout);

																	if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
																	printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28

																	printf("\n Part number attached to task -> %s \n", Partnumber);fflush(stdout);//JULY 28

																	if(tc_strcmp(PartItemIdSn,Partnumber)==0)
																	{
																		printf("\n  As name is same  ------->  \n");fflush(stdout);


																		ITK_CALL(AOM_lock(ccidTagrf[0]));
																		ITK_CALL(FL_remove(ccidTagrf[0],SnChild));
																		printf("\n  after fl remove AA \n");fflush(stdout);

																		ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));

																		ITK_CALL(AOM_refresh(ccidTagrf[0],0));

																		ITK_CALL(AOM_unlock(ccidTagrf[0]));

																		printf("\n  Relation OF nr part deleted in Snapshot\n");fflush(stdout);

																		fprintf(fptr,"\n%s/%s,%s/%s,%s %s,%s-%s",selecVCID,selecVCIDrev,PartItemIdSn,PartItemRevIdSn," "," ",item_id,"VCID Update");fflush(fptr);
																		break;

																	}

															 }

														}
													}
													else 
													{
														printf("\n  No snapshot Found...\n");fflush(stdout);
													}
													
												// }
											/* }
											 else
											 {
												 printf("\n Else no  Dataset attached to refrence folder in MDM .:%d \n",partcntrf);fflush(stdout);
											 }*/

										// }
									}

								 }
								 else
								 {
									printf("\n Else No part found inccu  attached to task -: %d \n",partcnt);fflush(stdout);
								 }

							 }



							 //part addition


							 ITK_CALL(GRM_find_relation_type("EC_reference_item_rel", &Part_tobeAdd));

							   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));
							   printf("\n  No of part attached to task in  CCU DML  -: %d \n",partaddcnt);fflush(stdout);

								if (partaddcnt>0)
								{
								   printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);
								   for (z=0;z<partaddcnt;z++)
								   {
										CcidADDTag=addPartsTag[z];
										AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
										if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
										if( AOM_ask_value_string(CcidADDTag,"item_revision_id",&AddPartnumberrevid)!=ITK_ok);

										printf("\n CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

										//ITK_CALL(GRM_find_relation_type("IMAN_reference", &part_tsk_relc));
										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_relc));
										printf("\n Part addition code-Expanding CMHasSolutionItem expanded \n"); fflush(stdout);

									//	 if (part_tsk_relc!=NULLTAG)
									//	 {
									//	   printf("\n Part addition code Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

										//   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
										//   printf("\n Part addition code Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

										//   if (partcntrf>0)
										//	 {
										//	   for (pr=0;pr<partcntrf;pr++)
										//		 {
													printf("\n Part addition code -Inside Dataset found for MDM DML  \n"); fflush(stdout);
												//	DesignrevTagR=PartsTagrf[pr];

													if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
													printf("\n Part addition code In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

													if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
													printf("\n  Part addition code ccid  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

									////////////////////////////



										ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
										printf("\n Part addition code - finding HasSnapshotType \n");fflush(stdout);

										 ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
										 printf("\n Part addition code -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
										
										if(CCID > 0)
										{
											ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
											printf("\n Part addition code- snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

										 if(snapcount > 0)
										 {


											printf("\n 444  CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);



											ITK_CALL(AOM_lock(ccidTagrf[0]));

											//ITK_CALL(FL_insert(ccidTagrf[0],CcidADDTag,999));//new added
											ifail = FL_insert(ccidTagrf[0],CcidADDTag,999);
											if(ifail != ITK_ok)
                                            {
												ITK_CALL(AOM_unlock(ccidTagrf[0]));
												EMH_ask_error_text(ifail,&ErrorText);
											}
											else
											{
												printf("\n  Part addition code- after fl add AA \n %d",ifail);fflush(stdout);

												ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));

												ITK_CALL(AOM_refresh(ccidTagrf[0],0));

												ITK_CALL(AOM_unlock(ccidTagrf[0]));

												printf("\n  Relation OF nr part added in Snapshot\n");fflush(stdout);
												fprintf(fptr,"\n%s/%s,%s %s,%s/%s,%s-%s",selecVCID,selecVCIDrev," "," ",AddPartnumber,AddPartnumberrevid,item_id,"VCID Update");fflush(fptr);
											}
										 }
										}
										else 
										{
											printf("\n  No snapshot found\n");fflush(stdout);
										}
										 

							//	}

							// }

						//   }
						 }

					  }



						}

					  }

					}
					else
					{
						printf("\n Else no  Control Object Not found for CCU DML == %d  \n", n_foundMdm);fflush(stdout);
					}

				}
		   }
	//	}

	return ITK_ok;
}

