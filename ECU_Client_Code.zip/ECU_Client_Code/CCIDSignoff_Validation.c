	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int CCIDSignoff_Validation(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}
int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;

	//tmp = sizeof(*strset);

	for(j=0;j<*count;j++)
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;

	}
	return -1;
 }
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = CCIDSignoff_Validation(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int CCIDSignoff_Validation(char* dmlNo)
{
	int ifail = ITK_ok;

	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;

	char *CurrentTask		= NULL;
	char * parent_name		= NULL;
	char *username			= NULL;
//	char *DMLNo				= NULL;
	tag_t DML_tag			= NULLTAG;
	tag_t *Pendingtasks		= NULLTAG;
	int   noAttachment      = 0;

	//int ifail;
	int status;
	int iStatus=0;
	int t=0;
	int i=0;
	int p=0;
	int partcnt=0;
	int ecuRlzStatusCnt =0;

	tag_t	*DMLObj					= NULLTAG;
	tag_t   *ecu_Rlz_St_list        = NULL;

	char	*Rel_type               = NULL;
	char    *ecuPrtLatestRlzSt      = NULL;
	char    *RevIDNo_Org            = NULL;
	char    *LatestVC               = NULL;
	char    *VCnumberDup            = NULL;
	char    *VCnumber               = NULL;
	char    *PartType               = NULL;
	tag_t	DesignrevTag			= NULLTAG;
	tag_t	latest_Cciditem			= NULLTAG;

	logical * 	deprecated_staus;
	char* attributeValue=NULL;
	tag_t Design_rev_cls_tag        = NULLTAG;

	tag_t	 HasNewCCIDRelTypeX   = NULLTAG;
	tag_t	 HasRefCCIDRelType    = NULLTAG;
	tag_t *RefRelTag	          = NULLTAG;
	tag_t *attccidTag	          = NULLTAG;
	tag_t DMLToTaskRel	          = NULLTAG;

	tag_t	*CCIDObj			= NULL;

	int		attccidcnt     = 0;
	int		RefRelcnt      = 0;
	int		www            = 0;
	int     iCCID		   = 0;
	int     icnt		   = 0;
	int     ccflag		   = 0;
	int     tsk_cnt		   = 0;
	int     bl			   = 0;
	int     tt			   = 0;
	int     NRflag		   = 0;
	int     Countflag	   = 0;
	int     DMLCount	   = 0;
	int		n_Input	       = 2;

	char*  CCIDObjNameX			= NULL;
	char*  CCIDObjNameXdup		= NULL;

	char *CCIDObjNameXduptok =NULL;
	char *CCIDNoduptok =NULL;
	char *CCIDNo =NULL;
	char *PartNo =NULL;

	//EPM_decision_t decision;

	char	**CCDetails		  =	NULL;
	CCDetails = (char**)MEM_alloc( 1 * sizeof *CCDetails );

	char	* req_item			=   NULL;
	char	* CCIDNodup			=   NULL;

	tag_t	 HasSolution		= NULLTAG;

	tag_t *Tsk_objects			= NULLTAG;
	char* Taskobject_type		= NULL;
	tag_t part_tsk_rel			= NULLTAG;
	tag_t *PartsTag			 = NULLTAG;

	int   membercnt					 = 0;

	tag_t	 IsMemberOfCCID			 = NULLTAG;
	tag_t   *memberTag				 = NULL;

	char	*BlItemID				 = NULL;
	char	*BlItemIDdup			 = NULL;
	char	*BlItemIDduptok			 = NULL;
	char	*dmlTaskNo			     = NULL;
	char	*RevIDNo			     = NULL;
	char	*RevIDNodup			     = NULL;
	char	*RevIDNoduptok			 = NULL;

	tag_t 	BLrevTag				 = NULLTAG;
	//decision = EPM_go;

	//added by ajinkya for control object on rejection on 3 march//
	int	n_entriesdmu = 2;
	int n_founddmu = 0;
	char *qry_entriesdmu[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesdmu[2] = {"DMU", "ECU"};
	tag_t   *dvpCtrObjdmu     = NULLTAG;
	tag_t TagdmuControl = NULLTAG;


	ITK_CALL(POM_get_user_id (&username));
	printf("\n\n CCIDSignoff_Validation Session login User1 : %s\n",username); fflush(stdout);

	//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	//printf("\n CCIDSignoff_Validation...");fflush(stdout);
	//CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	//printf("\n CCIDSignoff_Validation CurrentTask: %s",CurrentTask);fflush(stdout);
	//CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	//printf("\n CCIDSignoff_Validation Parent Name: %s",parent_name);fflush(stdout);
	//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	//printf("\n CCIDSignoff_Validation Target Attachment:%d",noAttachment);fflush(stdout);


	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	ifail = ITEM_find_item (dmlNo, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_list_all_revs (item_tag, &count1, &rev_list);
	CHECK_FAIL;

	if(count1 > 0)
	{
		DMLTaskTag = rev_list[0];

		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n CCIDSignoff_Validation dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout); //getting dml number here

		if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();
		if (DML_tag != NULLTAG)
		{

			 if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
			 if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
			 printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);
			 if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
		     {

				    ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&HasNewCCIDRelTypeX));
					printf("\n after finding HasNewCCIDRelTypeX \n");fflush(stdout);

					ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, HasNewCCIDRelTypeX, &attccidcnt, &attccidTag));
					printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);

					ITK_CALL(GRM_find_relation_type("T5_HasReferenceCCID",&HasRefCCIDRelType));
					printf("\n after finding HasRefCCIDRelType \n");fflush(stdout);

					ifail = GRM_list_secondary_objects_only(DMLRevTag,HasRefCCIDRelType,&RefRelcnt,&RefRelTag);
					printf("\n CCIDSignoff_Validation RefRelcnt =============>>> %d  \n",RefRelcnt);fflush(stdout);

					if(attccidcnt>0)
					{
						    for(icnt=0;icnt<attccidcnt;icnt++)
							{
							    latest_Cciditem=attccidTag[icnt];

								if(latest_Cciditem)
								{
									//printf("\n tm_ECUNewSnapshot CCID after GRM_save_relation--------->\n");fflush(stdout);

									if(AOM_ask_value_string(latest_Cciditem,"item_id",&CCIDNo)==ITK_ok);
									printf("\n  CCIDNo.:%s\n",CCIDNo);fflush(stdout);

									tc_strdup(CCIDNo,&CCIDNodup);

									CCIDNoduptok = tc_strtok (CCIDNodup,"_");
									printf("\n  CCIDNduptok  is----> [%s]\n",CCIDNoduptok);

									setAddStr(&iCCID,&CCDetails,CCIDNoduptok);
								}
							}

							if(RefRelcnt>0)
							{
								for (www=0;www<RefRelcnt;www++)
								  {
										ITK_CALL(AOM_ask_value_string(RefRelTag[www],"item_id",&CCIDObjNameX));

										printf("\n CCIDObjNameX [%s] \n", CCIDObjNameX);fflush(stdout);

										tc_strdup(CCIDObjNameX,&CCIDObjNameXdup);

										CCIDObjNameXduptok = tc_strtok (CCIDObjNameXdup,"_");
										printf("\n  CCIDObjNameXduptok  is----> [%s]\n",CCIDObjNameXduptok);

										//setAddStr(&iCCID,&CCDetails,CCIDObjNameXduptok);


										if(setFindStr1(&iCCID,&CCDetails,CCIDObjNameXduptok)==-1)//if not available
										 {
											printf("\n AAAAAAAAAAAAAAAAAAAAAAAAAAAAA CCID [%s] not found in new ccid \n",CCIDObjNameXduptok);fflush(stdout);
											ccflag=1;
											break;

										 }
										 else
										 {
											printf("\n  CCIDObjNameXduptok found ----> [%s]\n",CCIDObjNameXduptok);
										 }
								 }
							}

							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
							ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));

							printf("\n  tm_ECURefSnapshot Task count is \n: %d",tsk_cnt);fflush(stdout);

							if (tsk_cnt>0)
						    {
								 for (tt=0;tt<tsk_cnt ;tt++ )
								 {
									  ITK_CALL(AOM_ask_value_string(Tsk_objects[tt],"object_type",&Taskobject_type));
									  printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);

									   if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
									   {
										   printf("\n tm_ECURefSnapshot inside T5_ChangeTaskRevision :\n");fflush(stdout);
										   ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
										    if (part_tsk_rel!=NULLTAG)
											{
												 ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[tt], part_tsk_rel, &partcnt, &PartsTag));//Adi AUGUST
												 printf("\n  partcnt.:%d\n",partcnt);fflush(stdout);

												  if (partcnt>0)
												  {
														for (p=0;p<partcnt;p++)
														{
																DesignrevTag=PartsTag[p];

																if(AOM_ask_value_string(DesignrevTag,"item_id",&PartNo)==ITK_ok);
																printf("\n CCIDSignoff_Validation PartNo is  = [%s]\n", PartNo);fflush(stdout);

																if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok);
																printf("\n CCIDSignoff_Validation PartType is  = [%s]\n", PartType);fflush(stdout);//ECU Module or EM

																if ((tc_strcmp(PartType,"EM")==0)||(tc_strcmp(PartType,"ECU Module")==0))
																{
																	if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo)==ITK_ok);
																	printf("\n CCIDSignoff_Validation RevIDNo is  = [%s]\n", RevIDNo);fflush(stdout);

																	tc_strdup(RevIDNo,&RevIDNodup);

																	RevIDNoduptok = tc_strtok (RevIDNodup,";");
																	printf("\n  RevIDNoduptok  is----> [%s]\n",RevIDNoduptok);fflush(stdout);

																	if (tc_strcmp(RevIDNoduptok,"NR")==0)
																	{
																		ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&IsMemberOfCCID));
																		printf("\n  after finding IsMemberOfCCID \n");fflush(stdout);

																		ifail = GRM_list_secondary_objects_only(DesignrevTag,IsMemberOfCCID,&membercnt,&memberTag);
																		printf("\n  CCIDSignoff_Validation membercnt IS =============>>> %d  \n",membercnt); fflush(stdout);
																		if(membercnt==0)
																		{
																			printf("\n count = 0\n"); fflush(stdout);
																			Countflag=1;
																		}
																		else if(membercnt>0)
																		{
																			for (bl=0;bl<membercnt;bl++)
																			{
																					BLrevTag=memberTag[bl];

																					if(AOM_ask_value_string(BLrevTag,"item_id",&BlItemID)==ITK_ok);
																					printf("\n BlItemID is  = [%s]\n", BlItemID);fflush(stdout);

																					tc_strdup(BlItemID,&BlItemIDdup);

																					BlItemIDduptok = tc_strtok (BlItemIDdup,"_");
																					printf("\n  BlItemIDduptok  is----> [%s]\n",BlItemIDduptok);

																					if(setFindStr1(&iCCID,&CCDetails,BlItemIDduptok)==-1)//if not available
																					 {
																						printf("\n NR CCID [%s] not found in new ccid \n",BlItemIDduptok);fflush(stdout);
																						NRflag=1;
																						break;

																					 }
																					 else
																					 {
																						printf("\n  BlItemIDduptok found ----> [%s]\n",BlItemIDduptok);
																					 }
																			 }
																		}

																	}

																}


														}
												  }
											}
									   }
								 }
							}


					}
					else /******Adi AUGUST***********/
					{
							printf("\n Check control object for DMU rejection in ECU DML work flow \n");fflush(stdout);
							if(QRY_find2("ControlObjQry", &TagdmuControl));
							if (TagdmuControl != NULLTAG)
							{
								if(QRY_execute(TagdmuControl, n_entriesdmu, qry_entriesdmu, qry_valuesdmu, &n_founddmu, &dvpCtrObjdmu));
							}
							printf("\n Control Object found for DMU rejection  == %d \n", n_founddmu);fflush(stdout);

							if(n_founddmu==1)
							{
								printf("\n MISMATCH ERROR -NO CCID's found  IN NEW CCID \n");fflush(stdout);
								printf("\n None of the required CCID's are found in 'Has New CCID' relation.Please use Revise or Create option on CCID's available in Has Ref CCID relation \n For NR Revision of Module, select Module and use Create-New CCID Option");
								//EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,ITK_err, "None of the required CCID's are found in 'Has New CCID' relation.Please use Revise or Create option on CCID's available in Has Ref CCID relation \n For NR Revision of Module, select Module and use Create-New CCID Option");
								//decision = EPM_nogo;
								return ifail;

							}
							else
							{
								printf("\n In else No Control Object found for DMU rejection  == %d \n", n_founddmu);fflush(stdout);
							}
					}

					if(ccflag==1)
					{
						printf("\n MISMATCH ERROR -ALL REFERENCE CCID ARE NOT PRESENT IN NEW CCID \n");fflush(stdout);
						printf("\n All of the required CCID's are not available in 'Has New CCID' relation.Please use Revise or Create option on CCID's available in Has Ref CCID relation");
						//EMH_clear_errors();
						//EMH_store_error_s1(EMH_severity_error,ITK_err, "All of the required CCID's are not available in 'Has New CCID' relation.Please use Revise or Create option on CCID's available in Has Ref CCID relation");
						//decision = EPM_nogo;
						return ifail;
					}
					else
					{
						printf("\n ALL REF OBJECTS FOUND IN NEWW CCID   \n",CCIDNoduptok);fflush(stdout);
					}

					if(NRflag==1)
					{
						printf("\n MISMATCH ERROR -NR NOT PRESENT IN NEW CCID \n");fflush(stdout);

						printf("\n Required Baselines are not attached to DML.CCID's for Modules having NR Rev which are available in solution items of this DML need to be present in Has New CCID relation");

						//EMH_clear_errors();
						//EMH_store_error_s1(EMH_severity_error,ITK_err, "Required Baselines are not attached to DML.CCID's for Modules having NR Rev which are available in solution items of this DML need to be present in Has New CCID relation");
						//decision = EPM_nogo;
						return ifail;
					}
					else
					{
						printf("\n ALL  NR OBJECTS FOUND IN NEWW CCID   \n",CCIDNoduptok);fflush(stdout);
					}

					if(Countflag==1)
					{
						printf("\n NO CCID FOUND FOR NR MODULE \n");fflush(stdout);

						printf("\n Please Create CCID's for Modules having NR Rev which are available in solution items of this DML");

						//EMH_clear_errors();
						//EMH_store_error_s1(EMH_severity_error,ITK_err, "Please Create CCID's for Modules having NR Rev which are available in solution items of this DML");
						//decision = EPM_nogo;
						return ifail;
					}

			 }
		}

	}

	return ifail;
}
