/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: Clr_SVRGenTPL.c
**
** Functions:-    This utility applies SVR, Revision Rule and clouser Rule on input Platform to create it BOM structure which is furter use to create ColourSVRGenTPL Report.
**
**           Date                                                                                                      Author                               
**           16-July-2019																							 Rohit Bhosale                            
**
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

void childfun(tag_t child,char*);
FILE *fptr ;

char *replaceWord(const char *s, const char *oldW, const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

		char c[] = ",";
	    char d[] = ";";


//Allproperties defined

		char	*Description = NULL;
		char	*Modification_Description = NULL;
		char	*AddOn_Description = NULL;
		char	*Keyword_Description = NULL;
		char	*Platform = NULL;
		char	*Module_Address		 = NULL;
		char	*Module_Name		 = NULL;
		char	*Track_and_Trace		 = NULL;
		char	*CTECTS			 = NULL;
		char	*Project_Code		 = NULL;
		char	*Design_Group		 = NULL;
		char	*Owner_Design_Unit	 = NULL;
		char	*Part_Type		 = NULL;
		char	*Part_Code		 = NULL;
		char	*Drawing_Indicator	 = NULL;
		char	*Drawing_No		 = NULL;
		char	*Part_Material		 = NULL;
		char	*Weight			 = NULL;
		char	*Rolled_Up_Weight	 = NULL;
		char	*Material_Thickness	 = NULL;
		char	*Material_Class		 = NULL;
		char	*Surface_Protection	 = NULL;
		char	*Coated			 = NULL;
		char	*Colour_Indicator	 = NULL;
		char	*Comp_Code		 = NULL;
		char	*Envelope_Dimensions	 = NULL;
		char	*Application_Owner = NULL;
		char	*Samples_to_be_Approved	 = NULL;
		char	*Validation_Status	 = NULL;
		char	*Spare_Part		 = NULL;
		char	*Spare_Indicator		 = NULL;
		char	*Homologation_Reqd	 = NULL;
		char	*Unit			 = NULL;
		char	*Owner			 = NULL;
		char	*Creation_Date		 = NULL;
		char	*Last_Modifying_User	 = NULL;
		char	*Last_Modified_Date	 = NULL;
		char	*Release_Status		 = NULL;

		char	*Descriptionc = NULL;
		char	*Modification_Descriptionc = NULL;
		char	*AddOn_Descriptionc = NULL;
		char	*Keyword_Descriptionc = NULL;
		char	*Platformc = NULL;
		char	*Module_Addressc		 = NULL;
		char	*Module_Namec		 = NULL;
		char	*Track_and_Tracec		 = NULL;
		char	*CTECTSc			 = NULL;
		char	*Project_Codec		 = NULL;
		char	*Design_Groupc		 = NULL;
		char	*Owner_Design_Unitc	 = NULL;
		char	*Part_Typec		 = NULL;
		char	*Part_Codec		 = NULL;
		char	*Drawing_Indicatorc	 = NULL;
		char	*Drawing_Noc		 = NULL;
		char	*Part_Materialc		 = NULL;
		char	*Weightc			 = NULL;
		char	*Rolled_Up_Weightc	 = NULL;
		char	*Material_Thicknessc	 = NULL;
		char	*Material_Classc		 = NULL;
		char	*Surface_Protectionc	 = NULL;
		char	*Coatedc			 = NULL;
		char	*Colour_Indicatorc	 = NULL;
		char	*Comp_Codec		 = NULL;
		char	*Envelope_Dimensionsc	 = NULL;
		char	*Application_Ownerc = NULL;
		char	*Samples_to_be_Approvedc	 = NULL;
		char	*Validation_Statusc	 = NULL;
		char	*Spare_Partc		 = NULL;
		char	*Spare_Indicatorc		 = NULL;
		char	*Homologation_Reqdc	 = NULL;
		char	*Unitc			 = NULL;
		char	*Ownerc			 = NULL;
		char	*Creation_Datec		 = NULL;
		char	*Last_Modifying_Userc	 = NULL;
		char	*Last_Modified_Datec	 = NULL;
		char	*Release_Statusc		 = NULL;

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
                                
    }
                return return_code;
}

int ITK_user_main(int argc, char* argv[])
{
	
	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;

	tag_t    Cciditemrev   = NULLTAG;

	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;
	char	*swprttpe   = NULL;

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;

	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;

	int	n_entriesMdm = 2;
	int n_foundMdm = 0;
	int p = 0;
	int i=0;
	int z = 0;
	char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesMdm[2]  = {"MDM", "EECreateRel"};
	tag_t   *MdmCtrObj      = NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t  TagMdmControl     = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t  reln_typeMdm       = NULLTAG;
	tag_t  Mdmrelation        =NULLTAG;
	tag_t  DML_tag        =NULLTAG;
    dmlTaskNo 		= ITK_ask_cli_argument("-i=");

	 z = ITK_auto_login();
		if(z == ITK_ok)
		{
		    printf("\n\n\t Login Successful for [%s]\n",dmlTaskNo); fflush(stdout);

			//FILE *fptr ;
			fptr	=	fopen("output.csv", "w");

			if (fptr == NULL)
			{
			    printf("Could not open file");	fflush(stdout);
			    return 0;
			}

			ITK_CALL(POM_get_user_id (&username));
			printf("\n Inside the tm_MDMCreateEERelation Session User is : %s \n",username); fflush(stdout);

			ITK_CALL(ITEM_find_item(dmlTaskNo,&DML_tag));

			printf("\n MDM ECU Report DML No: found [%s] \n", dmlTaskNo);fflush(stdout);
		    if (DML_tag != NULLTAG)
		     {
			  printf("\n inside  DML_tag \n");fflush(stdout);
			  ITK_CALL(ITEM_ask_latest_rev(DML_tag,&MdmDMLRevTag));	
			  
			   if(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlTaskNo)!=ITK_ok);

			    printf("\n tm_MDMCreateEERelation - DML No: [%s] \n", dmlTaskNo);fflush(stdout);
				ITK_CALL(POM_class_of_instance(MdmDMLRevTag,&class_id));
			   ITK_CALL(POM_name_of_class(class_id,&mdmclass_name));
			   printf("\n Inside the tm_MDMCreateEERelation DML class_name of Task :%s \n",mdmclass_name);fflush(stdout);

				   if(strcmp(mdmclass_name,"ChangeRequestRevision")==0)
					{
						printf("\n Inside for --tm_MDMCreateEERelation- Target Attachment:%d \n",noAttachment);fflush(stdout);

						if (MdmDMLRevTag != NULLTAG)
						{

							  ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&MdmDMLToTaskRel));
							  ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

							  printf("\n Finding the tm_MDMCreateEERelation Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);

							   if (Mdmtsk_cnt>0)
							  {
								  printf("\n Inside task count for tm_MDMCreateEERelation --- %d \n" ,Mdmtsk_cnt); fflush(stdout);

								 for (tt=0;tt<Mdmtsk_cnt ;tt++ )
								{
									 printf("\n Now inside the task find as Task count is for tm_MDMCreateEERelation-- %d \n",Mdmtsk_cnt);fflush(stdout);
									 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[tt],"object_type",&Taskobj_type));
									 printf("\n Now tm_MDMCreateEERelation -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

									 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[tt],"item_id",&TskNmMdm));
									 printf("\n Now tm_MDMCreateEERelation -Task name  is :%s \n",TskNmMdm);fflush(stdout);

									 ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&Mdm_tsk_rel));

									 if (Mdm_tsk_rel!=NULLTAG)
									 {
									   printf("\n Has solution item relationship found \n");fflush(stdout);
									   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Mdm_tsk_rel,&partcnt,&MdmPartsTag));
									   printf("\n  No of part attached to task in tm_MDMCreateEERelation -: %d \n",partcnt);fflush(stdout);

										if (partcnt>0)
										{
										   printf("\n Inside part found in tm_MDMCreateEERelation  attached to task in tm_MDMCreateEERelation -: %d \n",partcnt);fflush(stdout);
										   for (p=0;p<partcnt;p++)
										   {
												DesignrMdmTag=MdmPartsTag[p];
												Partnumber =(char *) MEM_alloc(20 * sizeof(char *));
												if( AOM_ask_value_string(DesignrMdmTag,"item_id",&Partnumber)!=ITK_ok);
												if( AOM_ask_value_string(DesignrMdmTag,"t5_SwPartType",&swprttpe)!=ITK_ok);

												if(tc_strstr(swprttpe,"CON")!=NULL)
												{
												

												printf("\n  For tm_MDMCreateEERelation Design Revision Number- [%s]  \n",Partnumber); fflush(stdout);

												ITK_CALL(GRM_find_relation_type("IMAN_reference",&part_tsk_relc));
												printf("\n For tm_MDMCreateEERelation -Expanding IMAN_reference expanded \n"); fflush(stdout);

												 if (part_tsk_relc!=NULLTAG)
												 {
												   printf("\n For tm_MDMCreateEERelation Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

												   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc,&partcntrf,&PartsTagrf));//3 sept
												   printf("\n For tm_MDMCreateEERelation Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

												   if (partcntrf>0)
													 {
													   for (pr=0;pr<partcntrf;pr++)
														 {
															printf("\n Inside Dataset found for tm_MDMCreateEERelation  \n"); fflush(stdout);
															DesignrevTagR=PartsTagrf[pr];

															if(AOM_ask_value_string(DesignrevTagR,"t5_SwPartType",&Prt_object_type)!=ITK_ok);
															printf("\n In tm_MDMCreateEERelation for Dataset, t5_SwPartType is :%s \n",Prt_object_type);fflush(stdout);

														//	DatasetName	= strtok( Prt_object_type, "_" );
														//	printf("\n tm_MDMCreateEERelation-  DatasetName: %s \n",DatasetName);fflush(stdout);

															if(tc_strcmp(Prt_object_type,"CON")==0)
															{
																printf("\n As DatasetName -%s and  Part Number %s are same so create relationship in tm_MDMCreateEERelation \n",DatasetName,Partnumber);fflush(stdout);

															  ITK_CALL(GRM_find_relation_type("T5_ContHasSlave",&reln_typeMdm));
															  printf("\n\n In tm_MDMCreateEERelation T5_ContHasSlave.........\n");fflush(stdout);

																if(reln_typeMdm != NULLTAG)
															   {
																	printf("\n\n  for tm_MDMCreateEERelation DML T5_ContHasSlave. relationship found. \n");fflush(stdout);

																	ITK_CALL(GRM_create_relation(DesignrMdmTag,DesignrevTagR, reln_typeMdm, NULLTAG,&Mdmrelation));
																	printf("\n for tm_MDMCreateEERelation DML GRM_create_relation ---->[%s] [%s]",Prt_object_type,Partnumber);fflush(stdout);
																	ITK_CALL(GRM_save_relation(Mdmrelation));
																	printf("\n for tm_MDMCreateEERelation DML GRM_save_relation ---->[%s] [%s]",Prt_object_type,Partnumber);fflush(stdout);

															   }

															 }
															
															else if(tc_strcmp(Prt_object_type,"PRM")==0)
															{
																printf("\n As DatasetName -%s and  Part Number %s are same so create relationship in tm_MDMCreateEERelation \n",DatasetName,Partnumber);fflush(stdout);

															  ITK_CALL(GRM_find_relation_type("T5_ContHasPara",&reln_typeMdm));
															  printf("\n\n In tm_MDMCreateEERelation T5_ContHasPara.........\n");fflush(stdout);

																if(reln_typeMdm != NULLTAG)
															   {
																	printf("\n\n  for tm_MDMCreateEERelation DML T5_ContHasPara. relationship found. \n");fflush(stdout);

																	ITK_CALL(GRM_create_relation(DesignrMdmTag,DesignrevTagR, reln_typeMdm, NULLTAG,&Mdmrelation));
																	printf("\n for tm_MDMCreateEERelation DML GRM_create_relation ---->[%s] [%s]",Prt_object_type,Partnumber);fflush(stdout);
																	ITK_CALL(GRM_save_relation(Mdmrelation));
																	printf("\n for tm_MDMCreateEERelation DML GRM_save_relation ---->[%s] [%s]",Prt_object_type,Partnumber);fflush(stdout);

															   }

															 }

														 }
													 }
													 else
													 {
														 printf("\n Else no  Container attached to refrence folder in tm_MDMCreateEERelation .:%d \n",partcntrf);fflush(stdout);
													 }

												 }
											  }//s/w part type
											}

										 }
										 else
										 {
											printf("\n Else No part found in Solution folder tm_MDMCreateEERelation -: %d \n",partcnt);fflush(stdout);
										 }

									 }
								}

							  }



						}
				   }
				
				

				printf ("\n--------------tm_MDMCreateEERelation=Completed--------------------\n");fflush(stdout);

		    }
}
	return 0;

}

