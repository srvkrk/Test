	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int correctVCIDSnap(char*,char*,char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* pn						= NULL;
	char			* rev						= NULL;
	char			* seq						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	pn 				= ITK_ask_cli_argument("-pn=");
	rev 			= ITK_ask_cli_argument("-r=");
	seq 			= ITK_ask_cli_argument("-s=");
	file 			= ITK_ask_cli_argument("-file=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(pn)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = correctVCIDSnap(pn,rev,seq,file);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int correctVCIDSnap(char* partNo,char* Rev,char* Seq,char* File)
{
	int status =0;
	int ifail		= ITK_ok;
	char 			temp[200];
	char* snapShot	= NULL;
	int i =0;
	int sn =0;
	char* Stritem_id	= NULL;
	tag_t partTag		= NULLTAG;
	tag_t partRev_Tag	= NULLTAG;
	char* objstr = NULL;
	char* tempRevSeq	= NULL;
	tempRevSeq =(char *) MEM_alloc(10 * sizeof(char *));

	tc_strcpy(tempRevSeq,"");
	tc_strcat(tempRevSeq,Rev);
	tc_strcat(tempRevSeq,";");
	tc_strcat(tempRevSeq,Seq);
	
	printf("\nInput partNo:%s",partNo);
	printf("\nInput Rev:%s",Rev);
	printf("\nInput Seq:%s",Seq);

	printf("\ntempRevSeq\n : [%s]", tempRevSeq);fflush(stdout);
	
	int snapshotChildCont = 0;
	tag_t*	 snapchild				= NULL;
	//Getting the tag of Platform
	int		No_of_Entry = 1 ;
	char    *Q_Entry[1]  = {"Name"};
	char	**Q_Value = (char **) MEM_alloc(5 * sizeof(char *));
	int snapshotCount = 0;
	tag_t   Qry_tag     = NULLTAG;
	tag_t *SnapshotTag = NULLTAG;

	tag_t	 HasContents			  = NULLTAG;
	ITK_CALL(GRM_find_relation_type("contents",&HasContents));

	if(QRY_find2("SnapShot", &Qry_tag));

	ITK_CALL(ITEM_find_item(partNo,&partTag));
	ITK_CALL(ITEM_find_rev(partNo,tempRevSeq,&partRev_Tag));
	if(AOM_ask_value_string(partRev_Tag,"object_string",&objstr)!=ITK_ok);
	printf("\nObjstr part rev: [%s]", objstr);fflush(stdout);



	FILE* fp = NULL;
	fp = fopen(File, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				snapShot = strtok(temp, " ");
				//item_id = strtok(temp, "#");
				printf("\n*****************Input snapShot******************:%s",snapShot);
				printf("\nCorrecting VCID SnapShot Now");

				if (Qry_tag)
				{
					printf("\n General Query Found \n");fflush(stdout);
					Q_Value[0]=snapShot;

					if(QRY_execute(Qry_tag, No_of_Entry, Q_Entry, Q_Value, &snapshotCount, &SnapshotTag));
					printf("\n No of snapshotCount Found = %d\n",snapshotCount);fflush(stdout);
					
					for(i =0 ;i < snapshotCount ;i++)
					{
						ITK_CALL(AOM_ask_value_tags(SnapshotTag[i],"contents",&snapshotChildCont,&snapchild));//added
						printf("\nSnapcount  contents -------> [%d] \n",snapshotChildCont);fflush(stdout);

						if(snapshotChildCont > 0)
						{
							for (sn=0;sn<snapshotChildCont;sn++)
							{
								if(AOM_ask_value_string(snapchild[sn],"item_id",&Stritem_id)!=ITK_ok);
								printf("\nStritem_id : [%s]", Stritem_id);fflush(stdout);
								if(tc_strstr(Stritem_id,partNo)!=NULL)
								{
									printf("\n Now need to remove part");fflush(stdout);

									ITK_CALL(AOM_lock(SnapshotTag[i]));
									ITK_CALL(FL_remove(SnapshotTag[i],snapchild[sn]));
									ITK_CALL(AOM_save_without_extensions(SnapshotTag[i]));
									ITK_CALL(AOM_refresh(SnapshotTag[i],0));
									ITK_CALL(AOM_unlock(SnapshotTag[i]));

									// need to add input part revision seq to snapshot
									printf("\n Now adding given input part to snapshot...");fflush(stdout);
									ITK_CALL(AOM_lock(SnapshotTag[i]));
									ITK_CALL(FL_insert(SnapshotTag[i],partRev_Tag,999));//new added
									ITK_CALL(AOM_save_without_extensions(SnapshotTag[i]));
									ITK_CALL(AOM_unlock(SnapshotTag[i]));
									ITK_CALL(AOM_refresh(SnapshotTag[i],0));

								}

							}
							
						}


					}
			
				}

				
			}		
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("*****File Unable to Open...!!*********");
	}
	fclose(fp);

	return ifail;
}
