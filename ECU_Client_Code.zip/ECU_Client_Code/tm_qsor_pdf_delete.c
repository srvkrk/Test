#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/grm_msg.h>
#include <time.h>
#include <ae/dataset_msg.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PLM_error (EMH_USER_error_base + 325)

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

int tm_check_info_control_object_gen ( char *syscd, char *subsyscd, char *info1, char *info2 )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	char *l_info1 = NULL ;
	char *l_info2 = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
		tc_strcpy( info1, l_info1 );
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
		tc_strcpy( info2, l_info2 );

		TC_write_syslog ( "\ninfo1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	}

	return n_found ;
}



extern DLLAPI int QSOR_pdf_delete_method_pre ( METHOD_message_t *m, va_list args )
{
	tag_t datasetTag = va_arg(args, tag_t);
	char dataset_name[WSO_name_size_c+1] ;
	tag_t dataset_obj_Type_Tag = NULLTAG;
	tag_t primary_obj_Type_Tag = NULLTAG;
	char *dataset_type_name = NULL;
	char *primary_type_name = NULL;
	int Primary_obj_count = 0 ;
	tag_t *Primary_objs = NULLTAG;
	int i = 0;
	tag_t relation_type = NULLTAG;
	
	ITK_CALL(WSOM_ask_name(datasetTag, dataset_name));
	
	ITK_CALL ( TCTYPE_ask_object_type ( datasetTag, &dataset_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( dataset_obj_Type_Tag, &dataset_type_name ) );
	
    TC_write_syslog("\nQSOR_pdf_delete_method_pre dataset : [%s]\n", dataset_name);
    TC_write_syslog("\nQSOR_pdf_delete_method_pre dataset dataset_type_name : [%s]\n", dataset_type_name);
	
	
    //ITK_CALL(GRM_find_relation_type("IMAN_specification", &relation_type));
    
	
	//ITK_CALL ( GRM_list_primary_objects_only ( datasetTag, dml_tsk_rel_type, &Tskcount, &Primary_objs ) ) ;//task to dml traversal
	ITK_CALL ( GRM_list_primary_objects_only ( datasetTag, relation_type, &Primary_obj_count, &Primary_objs ) ) ;//task to dml traversal
	TC_write_syslog("\nQSOR_pdf_delete_method_pre dataset Primary_obj_count : [%d]\n", Primary_obj_count);
	if ( Primary_obj_count > 0 )
	{
		for ( i = 0 ; i < Primary_obj_count ; i++ )
		{
			ITK_CALL ( TCTYPE_ask_object_type ( Primary_objs[i], &primary_obj_Type_Tag ) ) ;
			ITK_CALL ( TCTYPE_ask_name2 ( primary_obj_Type_Tag, &primary_type_name ) );
			TC_write_syslog("\nQSOR_pdf_delete_method_pre obj primary_type_name : [%s]\n", primary_type_name);
		}
	}
	
	//EMH_store_error_s1 ( EMH_severity_error, PLM_error,"Can not delete dataset" ) ;
	//TC_write_syslog ( "\n: Can not delete dataset " ) ;
	//return PLM_error;
	
	return ITK_ok;
}
extern DLLAPI int tm_delete_rel_dataset_method_1(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
    //ResultStatus rstat;
	int pi = 0 ;
	int si = 0 ;
    va_list largs;
    va_copy( largs, args );
    tag_t relation  = va_arg(largs, tag_t);
    va_end( largs );
	
	tag_t primary_object = NULLTAG;
	tag_t secondary_object = NULLTAG;
	tag_t primary_obj_Type_Tag = NULLTAG;
	tag_t secondary_Type_Tag = NULLTAG;
	char *relation_type_name = NULL;
	char *primary_type_name = NULL;
	char *secondary_type_name = NULL;
	char *Release_status_SOR = NULL;
	char *error_msg_1 = NULL;
	int n_found_ctrl_obj = 0;
	
	error_msg_1 = ( char * ) MEM_alloc ( 150 * sizeof( char )) ;
	
	tag_t relation_type = NULLTAG;
    ITK_CALL(GRM_ask_relation_type(relation , &relation_type));
	//ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( relation_type, &relation_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj relation_type_name : [%s]\n", relation_type_name);
		   
	ITK_CALL( GRM_ask_primary (relation , &primary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &primary_obj_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( primary_obj_Type_Tag, &primary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj primary_type_name : [%s]\n", primary_type_name);
			
	ITK_CALL ( GRM_ask_secondary(relation , &secondary_object) );
	ITK_CALL ( TCTYPE_ask_object_type ( secondary_object, &secondary_Type_Tag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( secondary_Type_Tag, &secondary_type_name ) );
	TC_write_syslog("\nQSOR_pdf_delete_rel_method_pre obj secondary_type_name : [%s]\n", secondary_type_name);
	
	
	n_found_ctrl_obj = tm_check_info_control_object_gen ( "CTRL_DEL_REL",relation_type_name , primary_type_name, secondary_type_name );
	printf ( "\nn_found_ctrl_obj : [%d]", n_found_ctrl_obj ) ;
	TC_write_syslog ( "\nn_found_ctrl_obj : [%d]", n_found_ctrl_obj ) ;
		
	if ( n_found_ctrl_obj > 0 )
	{
		//TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
		//return 0;
	//}
	
	//if ( ( tc_strcmp (primary_type_name,"T5_quicksorRevision") == 0 ) && ( tc_strcmp (secondary_type_name,"PDF") == 0 ) )
	//{
		Release_status_SOR = NULL;
		ITK_CALL(AOM_UIF_ask_value(primary_object,"release_status_list",&Release_status_SOR));
		TC_write_syslog ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ;
		
		if ( tc_strstr( Release_status_SOR, "ERC Released" ) != NULL )
		{
			sprintf ( error_msg_1, "Can not delete relation between [%s] and [%s] as primary object is ERC Released" ,primary_type_name ,secondary_type_name ) ;
			EMH_store_error_s1 ( EMH_severity_error, PLM_error, error_msg_1 ) ;
			TC_write_syslog ( "\nError MSG : [%s]", error_msg_1 ) ;
			return PLM_error;
		}
		else
		{
			TC_write_syslog ( "\nRelease_status_SOR : [%s] hence allowed to cut (break relation)", Release_status_SOR ) ;
		}
	}
    return ifail;
}

extern int tm_qsor_pdf_delete_CUST_register_method(int *decision, va_list args)
{

	METHOD_id_t  method_delete_pre_act_qsor_pdf;
	 METHOD_id_t  method_delete_rel;

	
	ITK_CALL ( METHOD_find_method ( "Dataset", AE_delete_dataset_msg, &method_delete_pre_act_qsor_pdf  ) );
	if ( method_delete_pre_act_qsor_pdf.id != NULLTAG )
	{
		ITK_CALL ( METHOD_add_action ( method_delete_pre_act_qsor_pdf, METHOD_pre_action_type, (METHOD_function_t) QSOR_pdf_delete_method_pre, NULL ) ) ;
		TC_write_syslog("\nmethod_delete_pre_act_qsor_pdf\n");fflush(stdout);
    }
	
	ITK_CALL(METHOD_find_method("ImanRelation", "IMAN_delete", &method_delete_rel));
    if (method_delete_rel.id != NULLTAG)
    {
        ITK_CALL( METHOD_add_action(method_delete_rel, METHOD_pre_action_type, (METHOD_function_t) tm_delete_rel_dataset_method_1, NULL));
        TC_write_syslog("Registered tm_delete_dataset_method_1 as Pre-Action for delete relation of dataset\n");
    }
    else
        TC_write_syslog("Method not found!\n");
	
	return ITK_ok;
}
DLLAPI int tm_qsor_pdf_delete_register_callbacks ()
{
	int ifail=0;
	printf("\nregister_callback for tm_qsor_pdf_delete\n");fflush(stdout);
	TC_write_syslog("\nregister_callback for tm_qsor_pdf_delete\n");fflush(stdout);
	ITK_CALL ( CUSTOM_register_exit ( "tm_qsor_pdf_delete", "USER_init_module", (CUSTOM_EXIT_ftn_t)  tm_qsor_pdf_delete_CUST_register_method ) ) ;
	TC_write_syslog("\nafter register_callback for tm_qsor_pdf_delete\n");fflush(stdout);

	return ITK_ok;
}