/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;



int tm_OTAPartRelMailNotification(char* );
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlTaskNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlTaskNo 			= ITK_ask_cli_argument("-i=");
		
	time_t 	now;
	struct 	tm when;

	int status;
	char* error;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlTaskNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
/*	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/
	
		ifail = tm_OTAPartRelMailNotification(dmlTaskNo);
		if(ifail != ITK_ok)	
		{
			EMH_ask_error_text(ifail,&error);
			printf("Error:: %s",error);
		}
		//ITK_CALL(read_value_from_file(file));
		//CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

int tm_OTAPartRelMailNotification(char* dmlTaskNo)
{

    tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char    *info1         = NULL;
	char    *info2         = NULL;
	char    *info3         = NULL;
	char    *info4         = NULL;
	char    *info5         = NULL;
	char    *info6         = NULL;
	char    *info7         = NULL;
	int     OTACheckFlag	= 0;
//	char    *str		    = NULL;
	char	*qry_CInput[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_CVal[2] = {"ECU", "OTAModify"};
	int		n_InputX		= 2;
	int     CountC			= 0;
	tag_t	*CnObjC		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	int		AttachmentCount	    = 0;
	int length=0;
	tag_t	DMLRevTag			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t	DML_tag				= NULLTAG;
	tag_t   *newccidTag         = NULLTAG;

	char * username				= NULL;
	char * parent_name			= NULL;
	//char * dmlTaskNo			= NULL;
	char	*Rel_type   = NULL;
	char	*Projcode   = NULL;
	char	*objname   = NULL;
    char *DMLNo		= NULL; 
    char* eMailCC	= NULL;
    char* eMailTo	= NULL;
    char* envSub	= NULL;
    char  *envDesc	= NULL;
    char* buff		= NULL;
    char* Sevice	= NULL;   
    char* DID		= NULL;   
    char* DTC		= NULL;   
    char* Taskobject_type		= NULL; 
    char* partobjtype		= NULL; 
    char* swparttype		= NULL; 
    char* ecutype		= NULL; 
    char* OTACapable		= NULL;
    char* partid		= NULL;
    char* fotadesc		= NULL;
    char* clsname		= NULL;
    char* EPDidValue		= NULL;
    char* relBitValue		= NULL;

	eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
	eMailCC=(char *) MEM_alloc(1000 * sizeof(char *));
	DMLNo=(char *) MEM_alloc(1000 * sizeof(char *));
	buff=(char *) MEM_alloc(10000 * sizeof(char *));
	int		attccidcnt     = 0;	
	int     icnt		   = 0;
	int     tsk_cnt		   = 0;
	int     t		   = 0;
	int     p		   = 0;
	int     partcnt		   = 0;
	int     clscnt		   = 0;
	int     c		   = 0;
	
	tag_t *attccidTag	          = NULLTAG;
	tag_t	 HasToolChange   = NULLTAG;
	tag_t	latest_Cciditem			= NULLTAG;
	tag_t	DMLToTaskRel			= NULLTAG;
	tag_t	part_tsk_rel			= NULLTAG;
	tag_t	parttag			= NULLTAG;
	tag_t	objTypeTag			= NULLTAG;
	tag_t	prmrelation_type			= NULLTAG;
	tag_t*	Tsk_objects			= NULLTAG;
	tag_t*	PartsTag			= NULLTAG;
	tag_t*	clauses			= NULLTAG;
	tag_t	clause			= NULLTAG;
	tag_t realRelationTag  = NULLTAG;

	char* swpartlist =NULL;
	char* prmlist =NULL;
   swpartlist = (char *)MEM_alloc(5000);
   prmlist = (char *)MEM_alloc(5000);
   tc_strcpy(swpartlist,"");
   tc_strcpy(prmlist,"");
   char str[20];
   char str2[20];
   tc_strcpy(eMailTo,"");
   

	TC_write_syslog("\n Start:tm_OTAPartRelease.");
	ITK_CALL(POM_get_user_id (&username));
	printf("\n tm_OTAPartRelease Session User is : %s\n",username); fflush(stdout);

	// if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
	// {
	  if(QRY_find2("ControlObjQry", &ProQryContObj));
	  if(ProQryContObj)
	  {
		  if(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
		  printf("\n CONT Objects for tm_OTAPartRelease  == %d\n", CountC);fflush(stdout);
		  if(CountC >0)
		  {

		//   ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

		//   ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
		//   printf("\n tm_OTAPartRelease Parent Name: %s",parent_name);fflush(stdout);

		//   ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
		//   printf("\n tm_OTAPartRelease Target Attachment:%d",AttachmentCount);fflush(stdout);

		     //   if(AttachmentCount > 0)
			//	{
				//	DMLTaskTag = attachments[0];

				//	if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
					printf("\n tm_OTAPartRelease dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);



					if(tc_strstr(dmlTaskNo,"_") != NULL)
					 {
						DMLNo=strtok(dmlTaskNo,"_");
						printf("\n DMLNo =====> [%s]", DMLNo);fflush(stdout); //getting dml number here
					 }
					 else
					  {
						 tc_strcpy(DMLNo,dmlTaskNo);
						 printf("\n DMLNo 2=====> [%s]", DMLNo);fflush(stdout);
					  }

					tag_t *tags_found = NULL;
					int n_tags_found= 0;
					int n_rev= 0;

					const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
					const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

					attrs[0] ="item_id";
					values[0] = (char *) DMLNo;

					ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
					MEM_free(attrs);
					MEM_free(values);
					CHECK_FAIL;

					if (n_tags_found == 0)
					{
						printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", DMLNo); fflush(stdout);
						exit (0);
					}

					DML_tag = tags_found[0];

					ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));

					MEM_free(tags_found);
					printf("\n test 123456789 \n");fflush(stdout);

					if (DMLRevTag != NULLTAG)
					{
					  if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
					  if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&Projcode)!=ITK_ok)PrintErrorStack();
					  if(AOM_ask_value_string(DMLRevTag,"object_name",&objname)!=ITK_ok)PrintErrorStack();
					  printf("\n tm_OTAPartRelease DML Rel_type: [%s]", Rel_type);fflush(stdout);
					  printf("\n tm_OTAPartRelease DML Projcode: [%s]", Projcode);fflush(stdout);
					  printf("\n tm_OTAPartRelease DML objname: [%s]", objname);fflush(stdout);

					  if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
						{



///////////////////////////////
								if (GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel)) PrintErrorStack() ;
								if (GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects))  PrintErrorStack();
								printf("\n  tm_OTAPartRelease Task count is : %d",tsk_cnt);fflush(stdout);
								
								if (tsk_cnt>0)
								{
									 for (t=0;t<tsk_cnt ;t++ )
									 {
										 if(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type)!=ITK_ok)  PrintErrorStack();
										 printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);

										 if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
										 {
											
											 if(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel))  PrintErrorStack();

											  if (part_tsk_rel!=NULLTAG)
											  {  if(GRM_list_secondary_objects_only(Tsk_objects[t], part_tsk_rel, &partcnt, &PartsTag))  PrintErrorStack();
												   printf("\n  partcnt.:%d\n",partcnt);fflush(stdout);

													if (partcnt>0)
													{
													
													  	int     n	= 0;
													  	int     pr	= 0;

													    for (p=0;p<partcnt;p++)
														{     parttag=PartsTag[p];

														  

															if(TCTYPE_ask_object_type(parttag,&objTypeTag));
												            if(TCTYPE_ask_name2(objTypeTag,&partobjtype));
												            printf("\n\n\t\t part object Type := %s \n", partobjtype);fflush(stdout);

												            if(strcmp(partobjtype,"T5_EE_PartRevision")==0)
												            {
																if(AOM_ask_value_string(parttag,"t5_SwPartType",&swparttype)!=ITK_ok)  PrintErrorStack();
																if(AOM_ask_value_string(parttag,"t5_EcuType",&ecutype)!=ITK_ok)  PrintErrorStack();
																if(AOM_ask_value_string(parttag,"t5_FotaModificationDesc",&fotadesc)!=ITK_ok)  PrintErrorStack();
																if(AOM_ask_value_string(parttag,"item_id",&partid)!=ITK_ok)  PrintErrorStack();
																  printf("\n\n\t\t swparttype := %s \n", swparttype);fflush(stdout);
																  printf("\n\n\t\t ecutype := %s \n", ecutype);fflush(stdout);
																  printf("\n\n\t\t fotadesc := %s \n", fotadesc);fflush(stdout);
																  printf("\n\n\t\t partid := %s \n", partid);fflush(stdout);

																if ((tc_strcmp(swparttype,"CAL")==0) || (tc_strcmp(swparttype,"CFG")==0) || (tc_strcmp(swparttype,"APP")==0) || (tc_strcmp(swparttype,"BAS")==0) || (tc_strcmp(swparttype,"HCL")==0) || (tc_strcmp(swparttype,"PBL")==0) || (tc_strcmp(swparttype,"SBL")==0))
																{
																	

																	if(AOM_ask_value_string(parttag,"OTACapable",&OTACapable)!=ITK_ok)  PrintErrorStack();
																	 printf("\n\n\t\t OTACapable := %s \n", OTACapable);fflush(stdout);

																//	if(tc_strcmp(OTACapable,"Yes")==0)
																//	{
																		n++;
																		OTACheckFlag=1;
																		printf("\nOTACheckFlag is one\n");
																		
																		sprintf(str, "%d", n);

																		tc_strcat(swpartlist,"<br>");
																		tc_strcat(swpartlist,str);	
																		tc_strcat(swpartlist,") ");	
																		tc_strcat(swpartlist,partid);										    
																		tc_strcat(swpartlist,"/");										    
																		tc_strcat(swpartlist,ecutype);	
																		tc_strcat(swpartlist,"/");
																		tc_strcat(swpartlist,swparttype);
																		tc_strcat(swpartlist,"<br>Fota modification description:");
																		//tc_strcat(swpartlist,fotadesc);
																		tc_strcat(swpartlist,partid);
																		tc_strcat(swpartlist,"<br>");
																//	} 
																	
																}
																if (tc_strcmp(swparttype,"PRM")==0)
																{
																	   pr++;
																	   
																		   sprintf(str2, "%d", pr);

																	    tc_strcat(prmlist,"<br>");
																		tc_strcat(prmlist,str2);	
																		tc_strcat(prmlist,") ");	
																		tc_strcat(prmlist,partid);										    
																		tc_strcat(prmlist,"/");										    
																		tc_strcat(prmlist,ecutype);	
																		tc_strcat(prmlist,"/");
																		tc_strcat(prmlist,swparttype);
																		tc_strcat(prmlist,"<br>");
																		 
																		



																		GRM_find_relation_type ("T5_EEPrm", &prmrelation_type);
				                                                        GRM_list_secondary_objects_only(parttag,prmrelation_type, &clscnt, &clauses);
																		int     d	= 0;
																		for (c=0;c<clscnt;c++ )
																		 {
																			
																			clause=clauses[c];

																			AOM_ask_value_string(clause, "object_name", &clsname);
																			AOM_ask_value_string(clause, "t5_EPDidValue", &EPDidValue);

																			 ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo7",&info7));
																			 if ( tc_strstr(info7,EPDidValue) != NULL )
																				{
																				 d++;

																					printf("\n clsname: %s ",clsname);fflush(stdout);
																					printf("\n EPDidValue: %s ",EPDidValue);fflush(stdout);

																					GRM_find_relation(parttag,clause,prmrelation_type,&realRelationTag);
																					if(realRelationTag != NULLTAG)
																					{
																						AOM_ask_value_string(realRelationTag,"t5_BitValue",&relBitValue);
																						printf("\n relBitValue: %s ",relBitValue);fflush(stdout);

																						if (d==1)
																						{
																							tc_strcat(prmlist,"DID:  ");
																						}
																						else
																						{
																							tc_strcat(prmlist,"      ");
																						}
																																										   
																						tc_strcat(prmlist,EPDidValue);
																						tc_strcat(prmlist,":");
																						tc_strcat(prmlist,relBitValue);
																						tc_strcat(prmlist,"<br>");
																					}
																					else
																					{
																						printf("\n ************ realRelationTag == NULLTAG ************ ");fflush(stdout);
																					}
																					
																				}

																         }
												 
															
															     }//PRM
															 
															 
														}//T5_EE_PartRevision
													}


											  }
										}
									  }
									 }
								}








						  //////////////////////////


//t5_FotaModificationDesc
							if(OTACheckFlag==1)
							{
							/*
								   ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo1",&info1));

									printf("\n tm_OTAPartRelease INFO 1 ----- [%s]",info1); fflush(stdout);
									tc_strcpy(eMailTo,info1);


									 ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo2",&info2));
									 printf("\n tm_OTAPartRelease INFO 2 ----- [%s]",info2); fflush(stdout);
									 tc_strcpy(eMailCC,info2);*/


									 ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo1",&info1));
								    ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo2",&info2));
									 ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo3",&info3));
									  ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo4",&info4));
									  ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo5",&info5));

									  
										  tc_strcat(eMailTo,info1);
										  tc_strcat(eMailTo,",");
										  tc_strcat(eMailTo,info2);
										  tc_strcat(eMailTo,",");
										  tc_strcat(eMailTo,info3);
										  tc_strcat(eMailTo,",");
										  tc_strcat(eMailTo,info4);
										  tc_strcat(eMailTo,",");
										  tc_strcat(eMailTo,info5);
										  



									printf("\n tm_OTAPartmodifyMailNotification eMailTo ----- [%s]",eMailTo); fflush(stdout);
								//	tc_strcpy(eMailTo,info1);


									 ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo6",&info6));
									 printf("\n tm_OTAPartmodifyMailNotification INFO 6 ----- [%s]",info6); fflush(stdout);
									  tc_strcpy(eMailCC,info6);


                                    envSub = (char *) MEM_alloc( 1000 * sizeof(char) );
									envDesc = (char *) MEM_alloc( 5000 * sizeof(char) );
									char* objValue=NULL;
									tc_strcpy(envSub,"OTA part release/Modified");
								
									tc_strcpy(envDesc,"Dear Sir/Madam,<br><br>");
								//	tc_strcat(envDesc,"\n");
									tc_strcat(envDesc,"\nPart number with 'OTA capable' as 'Yes' has been created/Released<br> ");
									tc_strcat(envDesc,"DML number -");
									tc_strcat(envDesc,DMLNo);
									tc_strcat(envDesc,"<br>Project code -");									
									tc_strcat(envDesc,Projcode);
									tc_strcat(envDesc,"<br>Synopsis �");
									tc_strcat(envDesc,objname);
								//	tc_strcat(envDesc,"\n");
									tc_strcat(envDesc,"<br><br>Software Part number ;");
									tc_strcat(envDesc,swpartlist);
								//	tc_strcat(envDesc,"\n");
									tc_strcat(envDesc,"<br><br>Parameter part number details:<br>");
									tc_strcat(envDesc,prmlist);

								
									length = tc_strlen(eMailTo);
									 printf("\n eMailTo Length == %d\n", length);fflush(stdout);

									if (length>0)
									{

									 printf("\n\nMAIL_initialize\n\n");
									 sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -c \"%s\"  \"%s\" ",envDesc,envSub,eMailCC,eMailTo);								
									 printf("\n BUFF--- is :: %s ..\n",buff);fflush(stdout);

									 system(buff);

									}
									
							}

					  }
					  else
					  {
						  printf("\n  not ECU Parts Release DML hence tm_OTAPartRelease not allowed \n");fflush(stdout);
					  }
				  }
			 //  }Attchment
		  }
		  else
		  {
		  printf("\n ContrlObj count not found for tm_OTAPartRelease As it is applicable Only for PVBU");fflush(stdout);
		  }


	  }
	  else
	  {
		printf("\n Query not found for tm_OTAPartRelease");fflush(stdout);
	  }

	printf ("\n--------------tm_OTAPartRelease=Completed--------------------\n");fflush(stdout);
	TC_write_syslog("\n End:tm_OTAPartRelease.");
	
	return 0;
}
