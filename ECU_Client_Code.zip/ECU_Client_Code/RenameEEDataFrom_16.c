
/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File                  :   Cntrlobj.c
*  Author                :   Sudhir
*  Module                :   Control Object create in TCUA
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X)                                                     \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("%3d error(s) with #X\n", n_ifails);                                             \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
        ;

int ITK_user_main(int argc,char* argv[])
{
        int z;
        int status;


        FILE* fptr = NULL;
        FILE* wfptr = NULL;

        char *inputline = NULL;


        char *MasterItemidDup=NULL;
        char *MasterItemid1Dup=NULL;
        char *MasterItemid=NULL;
        char *MasterItemTypeDup=NULL;
        char *MasterItemType=NULL;
        char *updated_id=NULL;
        char *master_id=NULL;
        char *Tempupdate_id=NULL;
        char *master_type=NULL;
        char *updated_revid=NULL;

        const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;



        char    *f      =NULL;
        char    result1 [ 100000 ] ;
        char    result2 [ 100000 ] ;

         int
        //error_code = ITK_ok,
        n_entries = 2,
        n_found = 0,
        ii,cnt = 0;
                int i,TotalRevs,revcnt = 0;

        tag_t   query                           = NULLTAG;
        tag_t   criteria_object         = NULLTAG;
        tag_t   *criteria_objects       = NULLTAG;
        tag_t   updateitemid    = NULLTAG;
        tag_t   latrevcriteria_object   = NULLTAG;
        tag_t   updaterevitemid = NULLTAG;
        tag_t   *DesignRev_objects      = NULLTAG;


        char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]  = {"*","*"};


        ITK_CALL(ITK_set_journalling( TRUE ));
        ITK_CALL(ITK_initialize_text_services (0));
        printf("\n\n\t Attempting Logging\n ");

        z=ITK_CALL(ITK_auto_login());
        if(z!=ITK_ok)
        {
                printf("\n\n\t OMG Login Not Successfull\n ");
        }
        else
        {
          printf("\n\n\t Login Successfull\n ");
        }

        u = ITK_ask_cli_argument( "-u=");
        p = ITK_ask_cli_argument( "-pf=");
        g = ITK_ask_cli_argument( "-g=");


        if (ITK_init_module(u,p,g) == ITK_ok )
        {
        fptr=fopen("MasterList.txt","r");
        wfptr=fopen("RenameMasterList.txt","w");
        //fptr=fopen("/user/bsd05818/sudhir/RenameMasterData/MasterList.txt","r");
        printf("\n file read .......");fflush(stdout);
        if(fptr!=NULL)
        {
                inputline=(char *) MEM_alloc(50000);
                Tempupdate_id=(char *) MEM_alloc(20);

                while(fgets(inputline,50000,fptr)!=NULL)
                {
                        for (i = 0; i < strlen(inputline); i++)
                        {
                                if ( inputline[i] == '\n' || inputline[i] == '\r' )
                                        inputline[i] = '\0';
                        }
                        while(1)
                        {
                                f = strstr(inputline,",,");
                                if(f==NULL)
                                {
                                        break;
                                }

                                strcpy(result2,f+1);
                                *(f+1)=' ';
                                *(f+2)='\0';
                                strcat(f,result2);
                         }
                         strcpy(result1,inputline);
                        printf("\n inputline .......%s\n",result1);fflush(stdout);
                        fputs(result1,stdout);

                        MasterItemidDup=tc_strtok(result1,"~");
                        printf("\n MasterItemidDup [%s]",MasterItemidDup);fflush(stdout);
                        MasterItemTypeDup=tc_strtok(NULL,"~");
                        printf("\n MasterItemTypeDup [%s]",MasterItemTypeDup);fflush(stdout);



                        if(MasterItemidDup)MasterItemid = strdup(MasterItemidDup);
                        if(MasterItemTypeDup)MasterItemType = strdup(MasterItemTypeDup);


                        printf("\n MasterItemid .......%s",MasterItemid);fflush(stdout);
                        printf("\n MasterItemType .......%s",MasterItemType);fflush(stdout);




                        qry_values[0] = MasterItemid;
                        qry_values[1] = "Design";
                        //qry_values[1] = "Criteria MasterData";

                        ITK_CALL(QRY_find2("Item...", &query));
                        ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &criteria_objects));
                        printf("\n n_found=====>%d", n_found);fflush(stdout);
                        if(n_found>0)
                        {
                                for(cnt=0;cnt<n_found;cnt++)
                                {
                                        criteria_object = criteria_objects[cnt];

                                        AOM_ask_value_string(criteria_object,"item_id",&master_id);
                                        printf("\n master_id %s",master_id);fflush(stdout);
                                        //MasterItemid1Dup=tc_strtok(master_id,"_CORRUPT");

                                        AOM_ask_value_string(criteria_object,"object_type",&master_type);
                                        printf("\n master_type %s",master_type);fflush(stdout);

                                        //if(tc_strcmp(master_type,"T5masterdata")==0)
                                        if(tc_strcmp(master_type,"Design")==0)
                                        {
                                                tc_strcpy(Tempupdate_id,"5706H1A1616064");
                                              //  tc_strcat(Tempupdate_id,"_16");
                                                //tc_strcat(Tempupdate_id,"_CORRUPT");
                                                printf("\n Tempupdate_id [%s]",Tempupdate_id);fflush(stdout);

                                                AOM_refresh( criteria_object, POM_modify_lock);
                                                //POM_attr_id_of_attr("item_id", "T5masterdata", &updateitemid);
                                                POM_attr_id_of_attr("item_id", "Item", &updateitemid);
                                                POM_set_attr_string(1, &criteria_object, updateitemid, Tempupdate_id);
                                                POM_save_instances(1, &criteria_object, false);
                                                printf("\n Completed::POM_save_instances");fflush(stdout);
                                                AOM_refresh(criteria_object, POM_no_lock);
                                                AOM_ask_value_string(criteria_object,"item_id",&updated_id);
                                                printf("\n updated_id %s",updated_id);fflush(stdout);
                                                fprintf(wfptr,"\n");
                                                fprintf(wfptr,"%s~",updated_id);

                                                //ITEM_ask_latest_rev(criteria_object,&latrevcriteria_object);
                                                ITEM_list_all_revs(criteria_object,&TotalRevs,&DesignRev_objects);
                                                if(DesignRev_objects!=NULLTAG)
                                                {
                                                        for(revcnt;revcnt<TotalRevs;revcnt++)
                                                        {
                                                                latrevcriteria_object = DesignRev_objects[revcnt];
                                                                AOM_refresh( latrevcriteria_object, POM_modify_lock);
                                                                //ITEM_set_rev_id(latrevcriteria_object,Tempupdate_id);
                                                                //ITEM_save_rev(latrevcriteria_object);
                                                                //POM_attr_id_of_attr("item_id", "T5masterdataRevision", &updaterevitemid);
                                                                POM_attr_id_of_attr("item_id", "ItemRevision", &updaterevitemid);
                                                                POM_set_attr_string(1, &latrevcriteria_object, updaterevitemid, Tempupdate_id);
                                                                //POM_modify_string(1, &latrevcriteria_object, updateitemid, Tempupdate_id);
                                                                POM_save_instances(1, &latrevcriteria_object, false);
                                                                AOM_refresh(latrevcriteria_object, POM_no_lock);
                                                                AOM_ask_value_string(latrevcriteria_object,"item_id",&updated_revid);
                                                                printf("\n updated_revid %s",updated_revid);fflush(stdout);
                                                        }

                                                }
                                        }



                                }
                        }
                }
                MEM_free(criteria_objects);
                MEM_free(DesignRev_objects);
        }
        }

         fclose(fptr);
         fclose(wfptr);
         return ITK_ok;
}
