/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: Clr_SVRGenTPL.c
**
** Functions:-    This utility applies SVR, Revision Rule and clouser Rule on input Platform to create it BOM structure which is furter use to create ColourSVRGenTPL Report.
**
**           Date                                                                                                      Author                               
**           16-July-2019																							 Rohit Bhosale                            
**
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
//#include <bom/bom.h>
#include <bom/bom_attr.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>


#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


int create_para_relation(char*, char*, tag_t, char*, char*);
FILE *fptr ;

char *replaceWord(const char *s, const char *oldW, const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

		char c[] = ",";
	    char d[] = ";";


//Allproperties defined

		char	*Description = NULL;
		char	*Modification_Description = NULL;
		char	*AddOn_Description = NULL;
		char	*Keyword_Description = NULL;
		char	*Platform = NULL;
		char	*Module_Address		 = NULL;
		char	*Module_Name		 = NULL;
		char	*Track_and_Trace		 = NULL;
		char	*CTECTS			 = NULL;
		char	*Project_Code		 = NULL;
		char	*Design_Group		 = NULL;
		char	*Owner_Design_Unit	 = NULL;
		char	*Part_Type		 = NULL;
		char	*Part_Code		 = NULL;
		char	*Drawing_Indicator	 = NULL;
		char	*Drawing_No		 = NULL;
		char	*Part_Material		 = NULL;
		char	*Weight			 = NULL;
		char	*Rolled_Up_Weight	 = NULL;
		char	*Material_Thickness	 = NULL;
		char	*Material_Class		 = NULL;
		char	*Surface_Protection	 = NULL;
		char	*Coated			 = NULL;
		char	*Colour_Indicator	 = NULL;
		char	*Comp_Code		 = NULL;
		char	*Envelope_Dimensions	 = NULL;
		char	*Application_Owner = NULL;
		char	*Samples_to_be_Approved	 = NULL;
		char	*Validation_Status	 = NULL;
		char	*Spare_Part		 = NULL;
		char	*Spare_Indicator		 = NULL;
		char	*Homologation_Reqd	 = NULL;
		char	*Unit			 = NULL;
		char	*Owner			 = NULL;
		char	*Creation_Date		 = NULL;
		char	*Last_Modifying_User	 = NULL;
		char	*Last_Modified_Date	 = NULL;
		char	*Release_Status		 = NULL;

		char	*Descriptionc = NULL;
		char	*Modification_Descriptionc = NULL;
		char	*AddOn_Descriptionc = NULL;
		char	*Keyword_Descriptionc = NULL;
		char	*Platformc = NULL;
		char	*Module_Addressc		 = NULL;
		char	*Module_Namec		 = NULL;
		char	*Track_and_Tracec		 = NULL;
		char	*CTECTSc			 = NULL;
		char	*Project_Codec		 = NULL;
		char	*Design_Groupc		 = NULL;
		char	*Owner_Design_Unitc	 = NULL;
		char	*Part_Typec		 = NULL;
		char	*Part_Codec		 = NULL;
		char	*Drawing_Indicatorc	 = NULL;
		char	*Drawing_Noc		 = NULL;
		char	*Part_Materialc		 = NULL;
		char	*Weightc			 = NULL;
		char	*Rolled_Up_Weightc	 = NULL;
		char	*Material_Thicknessc	 = NULL;
		char	*Material_Classc		 = NULL;
		char	*Surface_Protectionc	 = NULL;
		char	*Coatedc			 = NULL;
		char	*Colour_Indicatorc	 = NULL;
		char	*Comp_Codec		 = NULL;
		char	*Envelope_Dimensionsc	 = NULL;
		char	*Application_Ownerc = NULL;
		char	*Samples_to_be_Approvedc	 = NULL;
		char	*Validation_Statusc	 = NULL;
		char	*Spare_Partc		 = NULL;
		char	*Spare_Indicatorc		 = NULL;
		char	*Homologation_Reqdc	 = NULL;
		char	*Unitc			 = NULL;
		char	*Ownerc			 = NULL;
		char	*Creation_Datec		 = NULL;
		char	*Last_Modifying_Userc	 = NULL;
		char	*Last_Modified_Datec	 = NULL;
		char	*Release_Statusc		 = NULL;

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

      //  EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
                                
    }
                return return_code;
}

int ITK_user_main(int argc, char* argv[])
{
	int z = 0;
	
		char		*sItemId 		= NULL;
		 char		*revid 		= NULL;
		 char		*sItemId2 		= NULL;
        char		*revid2 		= NULL;
       
        
        

		sItemId 	= ITK_ask_cli_argument("-i=");
		revid 		= ITK_ask_cli_argument("-r=");
		sItemId2 	= ITK_ask_cli_argument("-i2=");
		revid2 		= ITK_ask_cli_argument("-r2=");
	

z = ITK_auto_login();
	if(z == ITK_ok)
	{
		printf("\n\n\t Login Successful\n"); fflush(stdout);


			int ifail =ITK_ok;
			int vcattr =0;
			int sec_result_count =0;
			tag_t *statustags = NULLTAG;
			tag_t itemrevtag2 = NULLTAG;
			tag_t Latestrev_Tag = NULLTAG;
			tag_t tRelationExist = NULLTAG;
			tag_t designtag = NULLTAG;
			tag_t tRelationFind = NULLTAG;
			tag_t itemrevtag = NULLTAG;
			tag_t itemtag = NULLTAG;
			tag_t Relationtag = NULLTAG;
			

		//	 char		*sItemId 		= NULL;
			 char		*itemName 		= NULL;
			 char		*Releasestatuspt 		= NULL;
			 char		*releasedate 		= NULL;
			 char		*statusname 		= NULL;
		//	 char		*revid 		= NULL;
			 
		//	 USERARG_get_string_argument(&sItemId);
		//	 USERARG_get_string_argument(&revid);

			
			 printf("\n selected Item revision %s\n",sItemId);
			 printf("\n selected Revision Sequenec %s\n",revid);	
			// ITEM_find_item(sItemId, &designtag);
			// ITEM_find_revision(designtag,revid,&Latestrev_Tag);





			 /////////////////////////////////////////
		//	 char		*sItemId2 		= NULL;
		//	 char		*revid2 		= NULL;

		//	 USERARG_get_string_argument(&sItemId2);
		//	 USERARG_get_string_argument(&revid2);

			  printf("\n Item 2 %s\n",sItemId2);
			   printf("\n Item revision 2 %s\n",revid2);

			 tag_t relation_type = NULLTAG;
			 tag_t itemtag2 = NULLTAG;
			// tag_t itemrevtag2 = NULLTAG;
			 tag_t sec_tag_para = NULLTAG;
			 tag_t realRelationTag = NULLTAG;
			 
			 tag_t *rellist = NULLTAG;
			 char		*BitValue 		= NULL;
			 char		*Swtype 		= NULL;
			 char		*Swtype2 		= NULL;
			 char		*type_name				= NULL;
			 char		*type_name2				= NULL;
			 tag_t objTypeTag = NULLTAG;
			 tag_t objTypeTag2 = NULLTAG;

			 int count=0;
			 int i=0;

			  ITK_CALL(ITEM_find_item(sItemId,&itemtag));
			   if (itemtag)
			   {
				ITK_CALL(ITEM_find_revision(itemtag,revid, &itemrevtag));

				ITK_CALL(AOM_ask_value_string(itemrevtag,"t5_SwPartType",&Swtype));
			    printf("\n --Swtype= %s  ",Swtype);fflush(stdout);

				ITK_CALL(TCTYPE_ask_object_type(itemrevtag,&objTypeTag));
		        ITK_CALL(TCTYPE_ask_name2(objTypeTag, &type_name));
		        printf("\n --object_type:%s ", type_name);

		        if((tc_strcmp(type_name, "T5_EE_PartRevision") == 0) && (tc_strcmp(Swtype,"PRM")==0))
				  {

					   ITK_CALL(ITEM_find_item(sItemId2,&itemtag2));
					   if (itemtag2)
					   {
						ITK_CALL(ITEM_find_revision(itemtag2,revid2, &itemrevtag2));

						ITK_CALL(AOM_ask_value_string(itemrevtag2,"t5_SwPartType",&Swtype2));
						printf("\n --Swtype2= %s  ",Swtype2);fflush(stdout);

						ITK_CALL(TCTYPE_ask_object_type(itemrevtag2,&objTypeTag2));
						ITK_CALL(TCTYPE_ask_name2(objTypeTag2, &type_name2));
						printf("\n --object_type2:%s ", type_name2);

						  if((tc_strcmp(type_name2, "T5_EE_PartRevision") == 0) && (tc_strcmp(Swtype2,"PRM")==0))
						 {


							GRM_find_relation_type ("T5_EEPrm", &relation_type);
							GRM_list_secondary_objects_only(itemrevtag,relation_type, &count, &rellist);
							printf("\n --parameter count on selected part= %d  ",count);fflush(stdout);

							for (i=0;i<count;i++ )
							{

							   sec_tag_para=rellist[i];

								GRM_find_relation(itemrevtag,sec_tag_para,relation_type,&realRelationTag);
								if(realRelationTag != NULLTAG)
								{
									AOM_ask_value_string(realRelationTag,"t5_BitValue",&BitValue);
									printf("\n user entered value is:%s ", BitValue);



								   ITK_CALL(create_para_relation(sItemId2, revid2, sec_tag_para, BitValue, BitValue));


								}
								else
								{
									printf("\n ************ realRelationTag == NULLTAG ************ ");fflush(stdout);
								}

							}
						 }
					   }
					   else
						 {
							printf("\n part2 not found:%s ", sItemId2);

						 }
				  }
			  }
			  else
			  {
			  printf("\n part not found:%s ", sItemId);
			  }


    }
	else
	{
		printf("\n\n\t Login Not Successful\n"); fflush(stdout);
	}
	return 0;
}

int create_para_relation(char* part_no, char* rev_id, tag_t object, char* BitValue, char* ParamValue)
{
	int ifail =ITK_ok;
        int                             i                                                       = 0;
        int                             count                                           = 0;

        char                    *obj_string                                     = NULL;

        tag_t                   *sec_tag                                        = NULL;

        tag_t                   ee_part_rev_tag                         = NULLTAG;
        tag_t                   relation_type                           = NULLTAG;
        tag_t                   new_relation                            = NULLTAG;
        tag_t                   rel_exist                                       = NULLTAG;


                int     number_of_types2;

                tag_t *         type_tag3_R;

                tag_t   object_create_input_tag3_R                  = NULLTAG;



        printf("\nGoing to create relation between EE Part and ECU Parameter Master...!!\n");
        ITK_CALL(ITEM_find_rev (part_no, rev_id, &ee_part_rev_tag));
        printf("\npart:%s and rev:%s\n", part_no, rev_id);
        if(ee_part_rev_tag != NULLTAG)
        {
                printf("\nEE part revision found...!!\n");
                ITK_CALL(GRM_find_relation_type ("T5_EEPrm", &relation_type));

                if(relation_type != NULLTAG)
                {

                     /*   ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
                        ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));*/

                        printf("\nRelation type found...!!\n");
		//////////////////////////////////
						tag_t relation_type=NULLTAG;
						tag_t reltag=NULLTAG;
						tag_t rel2=NULLTAG;
						tag_t *rellist2=NULLTAG;
						int cnt =0;
						char* paraobjname=NULL;
						char* curruntname=NULL;
						int found=0;

					   GRM_find_relation_type ("T5_EEPrm", &relation_type);
					   GRM_list_secondary_objects_only(ee_part_rev_tag,relation_type, &cnt, &rellist2);
					   
					   AOM_ask_value_string(object, "object_name", &curruntname);
					   printf("\n Current Clause name: %s ",curruntname);fflush(stdout);

					   for (int r=0;r<cnt;r++)
					   {
						rel2  = rellist2[r];

						AOM_ask_value_string(rel2, "object_name", &paraobjname);

						printf("\n Clause object name: %s ",paraobjname);fflush(stdout);
						if (tc_strcmp(curruntname,paraobjname)==0)
						{
							found=1;
						}

					   }

					   if (found==1)
					   {
						 
						 printf("\n Clause alraedy available: %s ",curruntname);fflush(stdout);

						/*   GRM_find_relation(ee_part_rev_tag,object,relation_type,&reltag);
						   if (reltag!=NULLTAG)
						   {
							   printf("\n IUpdating User entered value");fflush(stdout);
							   ITK_CALL(AOM_refresh(reltag,1));
							   ITK_CALL(AOM_UIF_set_value(reltag,"t5_BitValue",BitValue));
							    ITK_CALL(AOM_save_without_extensions(reltag));
							   ITK_CALL(AOM_refresh(reltag,0));
							   ITK_CALL(AOM_unlock(reltag));
						   }*/
						   
					   }
					   else
						{
						   printf("\n Clause not available so creating Relation: %s ",curruntname);fflush(stdout);
						ITK_CALL(TCTYPE_find_types_for_class("T5_EEPrm",&number_of_types2,&type_tag3_R));
                        ITK_CALL(TCTYPE_construct_create_input(type_tag3_R[0], &object_create_input_tag3_R));

                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"primary_object",ee_part_rev_tag));
                        ITK_CALL(AOM_set_value_tag(object_create_input_tag3_R,"secondary_object",object));
                        ITK_CALL(AOM_UIF_set_value(object_create_input_tag3_R,"t5_BitValue",BitValue));
                        ITK_CALL(TCTYPE_create_object(object_create_input_tag3_R, &new_relation));
						ITK_CALL(AOM_save_without_extensions(new_relation));
                        ITK_CALL(AOM_refresh(new_relation,0));
                        ITK_CALL(AOM_unlock(new_relation));

						}

///////////////////////////////////



                }
        }
        return ifail;
}

