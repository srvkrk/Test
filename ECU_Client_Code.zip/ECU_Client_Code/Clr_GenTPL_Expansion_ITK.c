/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: Clr_SVRGenTPL.c
**
** Functions:-    This utility applies SVR, Revision Rule and clouser Rule on input Platform to create it BOM structure which is furter use to create ColourSVRGenTPL Report.
**
**           Date                                                                                                      Author                               
**           16-July-2019																							 Rohit Bhosale                            
**
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

void childfun(tag_t child);
FILE *fptr ;

char *replaceWord(const char *s, const char *oldW, const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

		char c[] = ",";
	    char d[] = ";";


//Allproperties defined

		char	*Description = NULL;
		char	*Modification_Description = NULL;
		char	*AddOn_Description = NULL;
		char	*Keyword_Description = NULL;
		char	*Platform = NULL;
		char	*Module_Address		 = NULL;
		char	*Module_Name		 = NULL;
		char	*Track_and_Trace		 = NULL;
		char	*CTECTS			 = NULL;
		char	*Project_Code		 = NULL;
		char	*Design_Group		 = NULL;
		char	*Owner_Design_Unit	 = NULL;
		char	*Part_Type		 = NULL;
		char	*Part_Code		 = NULL;
		char	*Drawing_Indicator	 = NULL;
		char	*Drawing_No		 = NULL;
		char	*Part_Material		 = NULL;
		char	*Weight			 = NULL;
		char	*Rolled_Up_Weight	 = NULL;
		char	*Material_Thickness	 = NULL;
		char	*Material_Class		 = NULL;
		char	*Surface_Protection	 = NULL;
		char	*Coated			 = NULL;
		char	*Colour_Indicator	 = NULL;
		char	*Comp_Code		 = NULL;
		char	*Envelope_Dimensions	 = NULL;
		char	*Application_Owner = NULL;
		char	*Samples_to_be_Approved	 = NULL;
		char	*Validation_Status	 = NULL;
		char	*Spare_Part		 = NULL;
		char	*Spare_Indicator		 = NULL;
		char	*Homologation_Reqd	 = NULL;
		char	*Unit			 = NULL;
		char	*Owner			 = NULL;
		char	*Creation_Date		 = NULL;
		char	*Last_Modifying_User	 = NULL;
		char	*Last_Modified_Date	 = NULL;
		char	*Release_Status		 = NULL;

		char	*Descriptionc = NULL;
		char	*Modification_Descriptionc = NULL;
		char	*AddOn_Descriptionc = NULL;
		char	*Keyword_Descriptionc = NULL;
		char	*Platformc = NULL;
		char	*Module_Addressc		 = NULL;
		char	*Module_Namec		 = NULL;
		char	*Track_and_Tracec		 = NULL;
		char	*CTECTSc			 = NULL;
		char	*Project_Codec		 = NULL;
		char	*Design_Groupc		 = NULL;
		char	*Owner_Design_Unitc	 = NULL;
		char	*Part_Typec		 = NULL;
		char	*Part_Codec		 = NULL;
		char	*Drawing_Indicatorc	 = NULL;
		char	*Drawing_Noc		 = NULL;
		char	*Part_Materialc		 = NULL;
		char	*Weightc			 = NULL;
		char	*Rolled_Up_Weightc	 = NULL;
		char	*Material_Thicknessc	 = NULL;
		char	*Material_Classc		 = NULL;
		char	*Surface_Protectionc	 = NULL;
		char	*Coatedc			 = NULL;
		char	*Colour_Indicatorc	 = NULL;
		char	*Comp_Codec		 = NULL;
		char	*Envelope_Dimensionsc	 = NULL;
		char	*Application_Ownerc = NULL;
		char	*Samples_to_be_Approvedc	 = NULL;
		char	*Validation_Statusc	 = NULL;
		char	*Spare_Partc		 = NULL;
		char	*Spare_Indicatorc		 = NULL;
		char	*Homologation_Reqdc	 = NULL;
		char	*Unitc			 = NULL;
		char	*Ownerc			 = NULL;
		char	*Creation_Datec		 = NULL;
		char	*Last_Modifying_Userc	 = NULL;
		char	*Last_Modified_Datec	 = NULL;
		char	*Release_Statusc		 = NULL;

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
                                
    }
                return return_code;
}

int ITK_user_main(int argc, char* argv[])
{
		int z = 0;
		char			* Item_ID						= NULL;
		char			* RevisionRule						= NULL;
		char			* rev_id						= NULL;
		char			* itemid						= NULL;
		char			* child_level						= NULL;
		char			* child_qty						= NULL;

		Item_ID 		= ITK_ask_cli_argument("-Item_ID=");
		RevisionRule 	= ITK_ask_cli_argument("-RevisionRule=");


		tag_t	item		=	NULLTAG;
		tag_t	rev			=	NULLTAG;
		tag_t	bomline		=	NULLTAG;
		tag_t	*child		=	NULLTAG;
		tag_t	window		=	NULLTAG;
		tag_t	t_revrule	=	NULLTAG;
		tag_t	*closurerule	=	NULLTAG;
		tag_t	close_tag;

		char		*child_id		=	NULL;
		char		*child_revid	=	NULL;
		char		**rulename		=	NULL;
		char		**rulevalue		=	 NULL;



		int		count		=	0;
		int		i			=	0;
		int		rulefound	=	0;

		z = ITK_auto_login();
		if(z == ITK_ok)
		{
		    printf("\n\n\t Login Successful for [%s]\n",Item_ID); fflush(stdout);

			//FILE *fptr ;
			fptr	=	fopen("output.csv", "w");

			if (fptr == NULL)
			{
			    printf("Could not open file");	fflush(stdout);
			    return 0;
			}

			fprintf(fptr,"\nLevel,Item ID,Revision,Quantity,Description, Modification_Description, AddOn_Description, Keyword_Description, Platform, Module_Name, Track_and_Trace, CTECTS, Project_Code, Design_Group, Owner_Design_Unit, Part_Type, Part_Code, Drawing_Indicator, Drawing_No, Part_Material, Weight, Rolled_Up_Weight, Material_Thickness, Material_Class, Surface_Protection, Coated, Colour_Indicator, Comp_Code, Envelope_Dimensions, Application_Owner, Samples_to_be_Approved, Validation_Status, Spare_Part, Spare_Indicator, Homologation_Reqd, Unit, Owner, Creation_Date, Last_Modifying_User, Last_Modified_Date, Release_Status");
			fprintf(fptr,"\n0,%s",Item_ID);

			if(ITEM_find_item(Item_ID,&item));
			if(ITEM_ask_latest_rev(item,&rev));

			if(AOM_ask_value_string(rev,"item_revision_id",&rev_id));
			if(AOM_ask_value_string(rev,"item_id",&itemid));
			printf("\nItem and its revision for which we are generating report is [%s/%s]\n",itemid,rev_id);

			if(PIE_find_closure_rules( "BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule ));
			//if(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
			if (rulefound > 0)
			{
						close_tag = closurerule[0];
						printf ("closure rule found \n");fflush(stdout);
					   // MEM_free(tags_found);
			}

			if(BOM_create_window(&window));
			{
				if(CFM_find(RevisionRule, &t_revrule));
				if(BOM_set_window_config_rule( window, t_revrule ));
				if(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
				if(BOM_set_window_pack_all(window, true));
				if(BOM_set_window_top_line(window,item,rev,NULLTAG,&bomline));
				{
					if(BOM_line_ask_all_child_lines(bomline,&count,&child));
					{
						if(count > 0)
						{
							for(i = 0 ; i < count ; i++)
							{
								if(AOM_ask_value_string(child[i],"bl_item_item_id", &child_id));
								if(AOM_ask_value_string(child[i],"bl_rev_item_revision_id", &child_revid));
								if(AOM_UIF_ask_value(child[i],"bl_level_starting_0", &child_level));
								if(AOM_UIF_ask_value(child[i],"bl_rorev_object_desc", &Description));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DocRemarks", &Modification_Description));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SimVal,", &AddOn_Description));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_CategoryName", &Keyword_Description));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Platform", &Platform));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ModuleAddress", &Module_Address));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ModuleNam", &Module_Name));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_TrackTrace", &Track_and_Trace));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_CTECTS", &CTECTS));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ProjectCode", &Project_Code));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DesignGrp", &Design_Group));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DsgnOwn", &Owner_Design_Unit));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartType", &Part_Type));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartCode", &Part_Code));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DrawingInd", &Drawing_Indicator));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_DrawingNo", &Drawing_No));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Material", &Part_Material));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Weight", &Weight));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_RolledupWt", &Rolled_Up_Weight));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_MThickness", &Material_Thickness));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_MatlClass", &Material_Class));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SurfPrtStd", &Surface_Protection));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_Coated", &Coated));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ColourInd", &Colour_Indicator));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PrtCatCode", &Comp_Code));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_EnvelopeDimensions", &Envelope_Dimensions));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_ApplicationOwner", &Application_Owner));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SamplesToAppr", &Samples_to_be_Approved));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PrtValiStatus", &Validation_Status));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SPDisposalInstr", &Spare_Part));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_SpareInd", &Spare_Indicator));
								if(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_HomologationReqd", &Homologation_Reqd));
								if(AOM_UIF_ask_value(child[i],"bl_uom", &Unit));
								if(AOM_UIF_ask_value(child[i],"bl_rorev_owning_user", &Owner));
								if(AOM_UIF_ask_value(child[i],"bl_rorev_creation_date", &Creation_Date));
								if(AOM_UIF_ask_value(child[i],"awb0RevisionLastModifiedUser", &Last_Modifying_User));
								if(AOM_UIF_ask_value(child[i],"awb0RevisionLastModifiedDate", &Last_Modified_Date));
								if(AOM_UIF_ask_value(child[i],"awb0RevisionRelStatusList", &Release_Status));

								char *new_Description = replaceWord(Description, c, d);
								char *new_Modification_Description = replaceWord(Modification_Description, c, d);
								char *new_AddOn_Description = replaceWord(AddOn_Description, c, d);
								char *new_Keyword_Description = replaceWord(Keyword_Description, c, d);
								char *new_Release_Status = replaceWord(Release_Status, c, d);
								
								if(AOM_UIF_ask_value(child[i],"bl_quantity", &child_qty));
								if(tc_strcmp(child_qty, "0") != 0 )
								{
									//printf("\nChild is [%s,%s]",child_id,child_level); fflush(stdout);
									printf("\nChild is [%s,%s/%s,%s]",child_level,child_id,child_revid,child_qty); fflush(stdout);
									fprintf(fptr,"\n%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s",child_level,child_id,child_revid,child_qty,new_Description, new_Modification_Description, new_AddOn_Description, new_Keyword_Description, Platform, Module_Name, Track_and_Trace, CTECTS, Project_Code, Design_Group, Owner_Design_Unit, Part_Type, Part_Code, Drawing_Indicator, Drawing_No, Part_Material, Weight, Rolled_Up_Weight, Material_Thickness, Material_Class, Surface_Protection, Coated, Colour_Indicator, Comp_Code, Envelope_Dimensions, Application_Owner, Samples_to_be_Approved, Validation_Status, Spare_Part, Spare_Indicator, Homologation_Reqd, Unit, Owner, Creation_Date, Last_Modifying_User, Last_Modified_Date, new_Release_Status); fflush(stdout);

									childfun(child[i]);
								}
							}
						}
						else
						{
							printf("No child part is present for %s",Item_ID); fflush(stdout);
						}
					}
				}
				BOM_close_window(window);
			}
		}
		else
		{
			printf("\n\n\t Login Not Successful\n"); fflush(stdout);
		}
	return 0;
}

void childfun(tag_t child)
{
	int		count1		=	0;
	int		j		=	0;

	tag_t	*child1		=	NULLTAG;

	char		*child_id1	=	NULL;
	char		*child_revid1	=	NULL;
	char		*subchild_id1	=	NULL;
	char		*subchild_qty	=	NULL;

	if(BOM_line_ask_all_child_lines(child,&count1,&child1));
	{
		for(j = 0 ; j < count1 ; j++)
		{
			if(AOM_ask_value_string(child1[j],"bl_item_item_id", &child_id1));
			if(AOM_ask_value_string(child1[j],"bl_rev_item_revision_id", &child_revid1));
			if(AOM_UIF_ask_value(child1[j],"bl_level_starting_0", &subchild_id1));
			if(AOM_UIF_ask_value(child1[j],"bl_quantity", &subchild_qty));

			if(AOM_UIF_ask_value(child1[j],"bl_rorev_object_desc", &Descriptionc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_DocRemarks", &Modification_Descriptionc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_SimVal,", &AddOn_Descriptionc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_CategoryName", &Keyword_Descriptionc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_Platform", &Platformc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_ModuleAddress", &Module_Addressc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_ModuleName", &Module_Namec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_TrackTrace", &Track_and_Tracec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_CTECTS", &CTECTSc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_ProjectCode", &Project_Codec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_DesignGrp", &Design_Groupc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_DsgnOwn", &Owner_Design_Unitc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_PartType", &Part_Typec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_PartCode", &Part_Codec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_DrawingInd", &Drawing_Indicatorc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_DrawingNo", &Drawing_Noc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_Material", &Part_Materialc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_Weight", &Weightc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_RolledupWt", &Rolled_Up_Weightc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_MThickness", &Material_Thicknessc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_MatlClass", &Material_Classc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_SurfPrtStd", &Surface_Protectionc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_Coated", &Coatedc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_ColourInd", &Colour_Indicatorc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_PrtCatCode", &Comp_Codec));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_EnvelopeDimensions", &Envelope_Dimensionsc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_ApplicationOwner", &Application_Ownerc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_SamplesToAppr", &Samples_to_be_Approvedc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_PrtValiStatus", &Validation_Statusc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_SPDisposalInstr", &Spare_Partc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_SpareInd", &Spare_Indicatorc));
			if(AOM_UIF_ask_value(child1[j],"bl_Design Revision_t5_HomologationReqd", &Homologation_Reqdc));
			if(AOM_UIF_ask_value(child1[j],"bl_uom", &Unitc));
			if(AOM_UIF_ask_value(child1[j],"bl_rorev_owning_user", &Ownerc));
			if(AOM_UIF_ask_value(child1[j],"bl_rorev_creation_date", &Creation_Datec));
			if(AOM_UIF_ask_value(child1[j],"awb0RevisionLastModifiedUser", &Last_Modifying_Userc));
			if(AOM_UIF_ask_value(child1[j],"awb0RevisionLastModifiedDate", &Last_Modified_Datec));
			if(AOM_UIF_ask_value(child1[j],"awb0RevisionRelStatusList", &Release_Statusc));

			char *new_Descriptionc = replaceWord(Descriptionc, c, d);
			char *new_Modification_Descriptionc = replaceWord(Modification_Descriptionc, c, d);
			char *new_AddOn_Descriptionc = replaceWord(AddOn_Descriptionc, c, d);
			char *new_Keyword_Descriptionc = replaceWord(Keyword_Descriptionc, c, d);
			char *new_Release_Statusc = replaceWord(Release_Statusc, c, d);

			if(tc_strcmp(subchild_qty, "0") != 0 )
			{
				//printf("\nSub-Child is [%s,%s]",child_id1,subchild_id1); fflush(stdout);
				printf("\nSub-Child is [%s,%s/%s,%s]",subchild_id1,child_id1,child_revid1,subchild_qty); fflush(stdout);
				fprintf(fptr,"\n%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s,%-20s",subchild_id1,child_id1,child_revid1,subchild_qty,new_Descriptionc, new_Modification_Descriptionc, new_AddOn_Descriptionc, new_Keyword_Descriptionc, Platformc, Module_Namec, Track_and_Tracec, CTECTSc, Project_Codec, Design_Groupc, Owner_Design_Unitc, Part_Typec, Part_Codec, Drawing_Indicatorc, Drawing_Noc, Part_Materialc, Weightc, Rolled_Up_Weightc, Material_Thicknessc, Material_Classc, Surface_Protectionc, Coatedc, Colour_Indicatorc, Comp_Codec, Envelope_Dimensionsc, Application_Ownerc, Samples_to_be_Approvedc, Validation_Statusc, Spare_Partc, Spare_Indicatorc, Homologation_Reqdc, Unitc, Ownerc, Creation_Datec, Last_Modifying_Userc, Last_Modified_Datec, new_Release_Statusc); fflush(stdout);
				childfun(child1[j]);
			}
		}
		
	}
}
