#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sPart			=   NULL;
char	* sRevSeq		=   NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

int IsVCIDRevLatest(char *sVCIDNumber,char *sVCIDRevSeq,logical *lIsVCIDLatest)
{
	int status;
	char *sLtstVCIDNum = NULL;
	char *sLtstVCIDRevSeq = NULL;
	tag_t tDesgVCID = NULLTAG;
	tag_t tVCIDLtstRev = NULLTAG;

	ITK_CALL(ITEM_find_item(sVCIDNumber,&tDesgVCID));
	ITK_CALL(ITEM_ask_latest_rev(tDesgVCID,&tVCIDLtstRev));
	if(tVCIDLtstRev != NULLTAG)
	{
		if(AOM_ask_value_string(tVCIDLtstRev,"item_id",&sLtstVCIDNum)!=ITK_ok);
		if(AOM_ask_value_string(tVCIDLtstRev,"item_revision_id",&sLtstVCIDRevSeq)!=ITK_ok);
		printf("\nkk.Latest VCID is [%s,%s]",sLtstVCIDNum,sLtstVCIDRevSeq);fflush(stdout);
		if(tc_strcmp(sVCIDNumber,sLtstVCIDNum)==0 && tc_strcmp(sVCIDRevSeq,sLtstVCIDRevSeq)==0)
		{
			printf("\nkk.Latest VCID Found.");fflush(stdout);
			*lIsVCIDLatest = true;
		}
	}
	return 0;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sPart  = ITK_ask_cli_argument("-i=");
	sRevSeq = ITK_ask_cli_argument("-r=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input [Part,RevSeq] [%s,%s]",sPart,sRevSeq); fflush(stdout);

	char	*sFrmRpl;
	char	*sToRpl;

	int		n_Input = 2;
	int		nPrtCnt = 0;
	char	*values[2];
	char	*qry_Input[2] = {"Item ID", "Revision"};
	tag_t	QryPrt = NULLTAG;
	tag_t	tPrt = NULLTAG;
	tag_t	*tpPrtObj = NULL;

	int iSCnt = 0;
	int iVCIDCnt = 0;
	char	*sSnapName = NULL;
	char	*sObjtype = NULL;
	char	*sClassName = NULL;
	char	**VCIDList = NULL;
	tag_t	tObj = NULLTAG;
	tag_t	HasContents = NULLTAG;
	tag_t	tSnapObj = NULLTAG;
	tag_t	tClassId = NULLTAG;
	tag_t	tCCIDHsSnap = NULLTAG;
	tag_t	tRefCCVTag = NULLTAG;

	int nRef = 0;
	int *levels = 0;
	char **relationsRef = NULL;
	tag_t	*tpRef = NULL;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	VCIDList = (char**)MEM_alloc(1 * sizeof *VCIDList);
	
	tc_strcpy(sFrmRpl,";");
	tc_strcpy(sToRpl,"*");
	ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRevSeq); 

	printf("\nkk.Querying.. [%s,%s]",sPart,sRevSeq); fflush(stdout);

	values[0] = sPart;
	//values[1] = "EE Part Revision";
	//values[1] = "Design Revision";
	values[1] = sRevSeq;

	if(QRY_find2("Item Revision...", &QryPrt));
	if(QryPrt)
	{
		if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObj));
		printf("\nkk.Part count is [%d]\n", nPrtCnt);fflush(stdout);

		if(nPrtCnt>0)
		{
			tPrt = tpPrtObj[0];
			ITKCALL(WSOM_where_referenced(tPrt,1,&nRef,&levels,&tpRef,&relationsRef));
			if(nRef>0)
			{
				ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&tCCIDHsSnap));
				ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&tRefCCVTag));
				for(iSCnt=0; iSCnt<nRef; ++iSCnt)
				{
					tSnapObj = tpRef[iSCnt];
					//printf("\nkk.[%d,%s]\n",iSCnt,relationsRef[iSCnt]);fflush(stdout);
					POM_class_of_instance(tSnapObj,&tClassId);
					POM_name_of_class(tClassId,&sClassName);
					printf("\nkk.Cass name[%s]\n",sClassName);fflush(stdout);
					if(tc_strstr(sClassName,"Snapshot") != NULL)
					{
						if(AOM_ask_value_string(tSnapObj,"object_name",&sSnapName)!=ITK_ok);
						setAddStr(&iVCIDCnt,&VCIDList,sSnapName);
					}
				}
				printf("\nkk.Snapshots affecting part number %s is:%d\n",sPart,iVCIDCnt);fflush(stdout);
				for(iSCnt=0; iSCnt<iVCIDCnt; ++iSCnt)
				{
					printf("%s\n",VCIDList[iSCnt]);fflush(stdout);
				}
			}
		}
	}

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}
}

