	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ECUCount_Validation(char*);
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int ,int ,tag_t , int *);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = ECUCount_Validation(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int ECUCount_Validation(char* dmlNo)
{
	int ifail = ITK_ok;
	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	//int  	options;
	int  	n_shared_sites;
	int  	ic = 0;
	int		xc = 0;
	char	** shared_sites ;
	char* attributeValue		= NULL;
	char* attributeValue1		= NULL;
	tag_t Design_rev_cls_tag    = NULLTAG;

	//27-07-2023 : Way of reading Tech Spec Value changed.
	int theAttributeCount =0;
	int *theAttributeIds ;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char***       theAttributeValues = NULL;
	char***       theAttributeOptimizedUnits = NULL;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	//int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;

	//EPM_decision_t decision;

	int status;
	int iStatus	=0;
	int DMLCount=0;
	int tsk_cnt	=0;
	int t		=0;
	int i		=0;
	int p		=0;
	int partcnt =0;
	int ecuRlzStatusCnt =0;

	int level 			       =    0;
	int con				       =    0;
	int containerCount         =    0;


	tag_t	*DMLObj					= NULLTAG;
	tag_t	*Tsk_objects			= NULLTAG;
	tag_t	*PartsTag				= NULLTAG;
	tag_t   *ecu_Rlz_St_list        = NULL;

	char	*DMLprojcode            = NULL;
	char	*Rel_type               = NULL;
	char	*Taskobject_type        = NULL;
	char    *RevIDNo_Org            = NULL;
	char    *VCnumberDup            = NULL;
	char    *VCnumber               = NULL;
	char    *PartNo                 = NULL;
	char    *PartType               = NULL;
	char    *PartType1              = NULL;
	char    *req_item               = NULL;
	char    *t5NoEcuDup             = NULL;
	char Container_count_string[50];

	tag_t	DMLRevTag				= NULLTAG;
	tag_t	DMLToTaskRel		    = NULLTAG;
	tag_t	part_tsk_rel		    = NULLTAG;
	tag_t	ProQryDMLObj			= NULLTAG;
	tag_t	DesignrevTag			= NULLTAG;
	tag_t	LatestVC				= NULLTAG;
	tag_t	CCVCrelation_type		= NULLTAG;
	tag_t	LatestModRevTag			= NULLTAG;
	tag_t	sn_rule					= NULLTAG;
	tag_t	sn_rule1				= NULLTAG;

	int		n_Input	       = 2;
	int		t5NoEcuDupint  = 0;
	int		Modcnt	       = 0;

	tag_t	window 	        = NULLTAG;
	tag_t	window1	        = NULLTAG;
	tag_t	*Modattachments	= NULLTAG;
	tag_t   Mod_rev_tag     = NULLTAG;
	tag_t   DML_tag			= NULLTAG;
	tag_t	top_line	    = NULLTAG;
	tag_t	top_line1	    = NULLTAG;
	tag_t	DesignMasterTag	= NULLTAG;

	char * username			= NULL;
	char * parent_name		= NULL;
	char * dmlTaskNo		= NULL;
	char * ModulNo			= NULL;
	char * ECUCountErr		= NULL;

	int AttachmentCount		= 0;

	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t rootTask			= NULLTAG;

	tag_t   Mod_rev_tag_mstr = NULLTAG; //3 sept
	char*   ModulRevid     =NULL;      //3 sept

	//decision = EPM_go;// 9 SEPT

	//Added by ajinkya for DVP in VC//
	tag_t	CCVCrelation_typeDv		= NULLTAG;
	tag_t	*ModattachmentsDv		= NULLTAG;
	tag_t   Mod_rev_tag_mstrDv      = NULLTAG;
	tag_t   Mod_rev_tagDv			= NULLTAG;
	tag_t   class_id                =NULLTAG;
	tag_t   *DMLRevision			= NULLTAG;
	tag_t	NewDMLRevTag			= NULLTAG;
	tag_t  *children				= NULLTAG;
	tag_t  *children1				= NULLTAG;
	tag_t	bl_Child_dv				= NULLTAG;
	tag_t   tsk_dml_rel_type;
	char * ModulNoDv			    = NULL;
	char*   ModulRevidDv            =NULL;
	char 	*BusUnitDV				= NULL;
	char	*DMLDRdvp				= NULL;
	char*	partNumber 				= NULL;
	char*	ModPartType				= NULL;
	char	*LatChildName			=	NULL;
	char   *class_name;
	int		ModcntDv                = 0;
	int     jdv 	                =0;
	int     jt  	                =0;
	int		n_Cnt					=0;
	int		n_Cnt1					=0;
	int     jcnt					=0;
	logical is_latest;
//	char  type_name[TCTYPE_name_size_c+1];
    char*	type_name				= NULL;
	tag_t objTypeTagdv  = NULLTAG;
	tag_t reln_typeDvp  = NULLTAG;
	tag_t SolnItemTag   = NULLTAG;
	tag_t EE_tag		= NULLTAG;
	tag_t EEparent_rev   = NULLTAG;
	int n_attchs_dvp     = 0;
	int  dvp             = 0;
	int  ddi             = 0;
	char    * dataset_name1 = NULL;
	char    * Item_id_EE = NULL;
	GRM_relation_t *secondary_dvp;
	tag_t	new_Child_tg			= NULLTAG;
	tag_t  *childrenee	= NULLTAG;

	int	n_entriesWe = 2;
	int n_foundWe = 0;
	char *qry_entriesWe[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesWe[2] = {"VC", "DVP"};
	tag_t   *dvpCtrObj      = NULLTAG;
	tag_t TagWeControl = NULLTAG;

	int  dvpflag = 0;
//END for DVP//

//Added by Ajinkya for Module and VC DR check on 13 march//
	int	n_entriesDR = 2;
	int n_foundDR = 0;
	char *qry_entriesDR[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesDR[2] = {"DR", "MODULE"};
	tag_t   *DRCtrObj      = NULLTAG;
	tag_t TagDRControl = NULLTAG;

	tag_t	CCVCrelation_typeDR	= NULLTAG;
	tag_t	*ModattachmentsDR		= NULLTAG;
	tag_t   Mod_rev_tag_mstrDR      = NULLTAG;
	tag_t   Mod_rev_tagDR			= NULLTAG;
	char*   VCdrStatus              =NULL;
	char*   ModulNoDR			    = NULL;
	char*   ModulRevidDR            =NULL;
	char*   ModuleDrStatus            =NULL;
	char*   ModDR            =NULL;
	char*   VcDR            =NULL;

	int		ModcntDR               = 0;
	int     ModDRNo  =0;
	int     VcDRNo  =0;

	//end for Module and VC DR check //
	ITK_CALL(POM_get_user_id (&username));
	printf("\n ECUCount_Validation Session User is : %s\n",username); fflush(stdout);

   // ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

   // ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
    //printf("\n ECUCount_Validation Parent Name: %s",parent_name);fflush(stdout);

    //ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
    //printf("\n ECUCount_Validation Target Attachment:%d",AttachmentCount);fflush(stdout);

	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	ifail = ITEM_find_item (dmlNo, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_list_all_revs (item_tag, &count1, &rev_list);
	CHECK_FAIL;

    if(count1 > 0)
	{
		DMLTaskTag = rev_list[0];
		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n ECUCount_Validation dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);

		// if(ITEM_find_item(dmlTaskNo, &DML_tag)!=ITK_ok)PrintErrorStack();

		
		tag_t *tags_found = NULL;
		int n_tags_found= 0;
		int n_rev= 0;

		const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
		const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

		attrs[0] ="item_id";
		values[0] = (char *) dmlTaskNo;

		ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
		MEM_free(attrs);
		MEM_free(values);
		CHECK_FAIL;

		if (n_tags_found == 0)
		{
			printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", dmlTaskNo); fflush(stdout);
			exit (0);
		}

		DML_tag = tags_found[0];
		printf("\n after  DML_tag XXXXXXXXXX :\n");fflush(stdout);

		ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));

		 ITK_CALL(AOM_ask_value_string(DMLTaskTag,"object_type",&Taskobject_type));//3 sept
		 printf("\n  VC validation Taskobject_type is :[%s]\n",Taskobject_type);fflush(stdout);
		 if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
		 {
			   printf("\n tm_ECURefSnapshot inside T5_ChangeTaskRevision :\n");fflush(stdout);
			   ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));

			     if (part_tsk_rel!=NULLTAG)
				 {
					 ITK_CALL(GRM_list_secondary_objects_only(DMLTaskTag, part_tsk_rel, &partcnt, &PartsTag));//3 sept
					 printf("\n  VC validation partcnt.:%d\n",partcnt);fflush(stdout);
					 if (partcnt>0)
					 {
						 for (p=0;p<partcnt;p++)
						 {
								DesignrevTag=PartsTag[p];

								ITEM_ask_item_of_rev(DesignrevTag,&DesignMasterTag); //find master here

								//ITK_CALL(ITEM_ask_latest_rev(DesignrevTag,&LatestVC));
								if( AOM_ask_value_string(DesignrevTag,"item_id",&VCnumber)!=ITK_ok);
								//tc_strcpy(VCnumberDup,VCnumber);
								printf("\n VCnumber is [%s]  \n",VCnumber); fflush(stdout);


								if(AOM_ask_value_string(DesignrevTag,"item_id",&PartNo)==ITK_ok);
								printf("\n  VC validation PartNo is  = [%s]\n", PartNo);fflush(stdout);

								if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo_Org)==ITK_ok);
								printf("\n  VC validation RevIDNo is  = [%s]\n", RevIDNo_Org);fflush(stdout);

								if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok);
								printf("\n  VC validation PartType is  = [%s]\n", PartType);fflush(stdout);

								//added by ajinkya on 13 march for DR validation on VC and Module//
								printf("\n  for DR validation on VC and Module started now \n");fflush(stdout);
								if(QRY_find2("ControlObjQry", &TagDRControl));
								if (TagDRControl != NULLTAG)
								{
								if(QRY_execute(TagDRControl, n_entriesDR, qry_entriesDR, qry_valuesDR, &n_foundDR, &DRCtrObj));
								}
								printf("\n Control Object found for VC and Module  == %d\n", n_foundDR);fflush(stdout);

								if(n_foundDR==1)
								{
									printf("\n Inside Control Object found for VC and Module = [%d] and Part Type  == [%s] \n", n_foundDR,PartType);fflush(stdout);
									if ((tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"Vehicle Combination")==0))
									{
										//code for Module expand//
										printf("\nSetting VC into Structure manager and checking Vehicle present or not \n");fflush(stdout);
										ITK_CALL(BOM_create_window (&window1)); //3 sept
										ITK_CALL(BOM_set_window_pack_all (window1, true));//3 sept
										ITK_CALL(CFM_find("ERC Review And Above", &sn_rule1 ));
										ITK_CALL(BOM_set_window_config_rule( window1, sn_rule1 ));

										ITK_CALL(BOM_set_window_top_line (window1, null_tag,DesignrevTag,null_tag, &top_line1));
										ITK_CALL(BOM_window_show_suppressed (window1));

										printf("\n -------------------VC to Vehicle Expansion----- \n");fflush(stdout);

										ITK_CALL(AOM_ask_value_string(top_line1,"bl_item_item_id",&partNumber));// 3 sept
										printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);

										ITK_CALL(BOM_line_ask_child_lines (top_line1, &n_Cnt1, &children1)); //3 sept
										printf("\n\n\t\t **** VC contains child objects are :: %d \n", n_Cnt1);fflush(stdout);

										if (n_Cnt1>0)
										{
											printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt1);fflush(stdout);
											for (jcnt=0;jcnt<n_Cnt1;jcnt++)
											{
												printf("\n\n\t\t Inside for loop \n");fflush(stdout);

												bl_Child_dv=children1[jcnt];

												ITK_CALL(AOM_ask_value_string( bl_Child_dv,"bl_item_item_id",&LatChildName));
												printf("\n DVP-VC LatChildName Parts Id : [%s] \n",LatChildName);

												ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_PartType",&PartType1));
												printf("\nChildName Parts Type 11 : [%s] \n",PartType1);
												if((tc_strcmp(PartType1,"V")==0) || (tc_strcmp(PartType1,"Vehicle")==0))
												{
													DesignrevTag = bl_Child_dv;
													printf("\nCopying Vehicle Object from VC Object\n");fflush(stdout);
													break;
												}
											}
										}
									}
									//	n_Cnt	=	0;
									printf("\n Outside  main loop  -PartType1 if vehicle found ---> [%s] \n",PartType1);fflush(stdout);

									//if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok);
									  printf("\n  VC validation PartType is  = [%s]\n", PartType);fflush(stdout);
									   if ((tc_strcmp(PartType,"CCVC")==0)||(tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"Configurable VC")==0) || (tc_strcmp(PartType,"Vehicle")==0) ||  (tc_strcmp(PartType1,"V")==0) ||  (tc_strcmp(PartType1,"Vehicle")==0))
									   {
													printf("\n As Part TYPE Inside VC and Module Check ============= [%s]  \n",PartType); fflush(stdout);

													if(AOM_ask_value_string(DesignrevTag,"t5_PartStatus",&VCdrStatus)==ITK_ok);
													printf("\n  VC- (%s) has DR status as   = [%s]\n",PartNo, VCdrStatus);fflush(stdout);

													ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDR));
													printf("\n For VC and Module Check CCVC has ECU module REL FOUND \n");fflush(stdout);

													ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_typeDR,&ModcntDR,&ModattachmentsDR));
													printf("\n VC and Module ModcntDR ============= [%d]  \n",ModcntDR); fflush(stdout);

													
													if (ModcntDR > 0)
													{
														printf("\n Inside VC and Module ModcntDR ============= [%d]  \n",ModcntDR); fflush(stdout);
														Mod_rev_tag_mstrDR = ModattachmentsDR[0];

														ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstrDR,&Mod_rev_tagDR));

														if(AOM_ask_value_string(Mod_rev_tagDR,"item_id",&ModulNoDR)==ITK_ok);
														printf("\n  VC and Module validation ModulNoDR is  = [%s] \n", ModulNoDR);fflush(stdout);

														if(AOM_ask_value_string(Mod_rev_tagDR,"item_revision_id",&ModulRevidDR)==ITK_ok);
														printf("\n VC and Module validation ModulRevidDR is  = [%s] \n", ModulRevidDR);fflush(stdout);

														if(AOM_ask_value_string(Mod_rev_tagDR,"t5_PartStatus",&ModuleDrStatus)==ITK_ok);
														printf("\n VC and Module validation ModuleDrStatus is  = [%s] \n", ModuleDrStatus);fflush(stdout);

														ModDR=subString(ModuleDrStatus, 2, 1);
														printf( "\n Substring Module DR ----<%s>  ***\n",ModDR );fflush(stdout);

														ModDRNo=atoi(ModDR);
														printf("\n Module DR status after conversion -----------  [%d]\n",ModDRNo); fflush(stdout);


														printf("\n Add again- VC- (%s) has DR status as   = [%s]\n",PartNo, VCdrStatus);fflush(stdout);

														VcDR=subString(VCdrStatus, 2, 1);
														printf( "\n Subsstring VC Dr  ----<%s>  ***\n",VcDR );fflush(stdout);

														VcDRNo=atoi(VcDR);
														printf("\n VC DR status after conversion -----------  [%d]\n",VcDRNo); fflush(stdout);


														//if(tc_strcmp(ModuleDrStatus,VCdrStatus)==0)
														if (ModDRNo >= VcDRNo)
														{
														  printf("\n For VC -(%s) and Module- (%s) DR status match \n",VCdrStatus, ModuleDrStatus);fflush(stdout);
														  printf("\n For VC -(%d) and Module- (%d) DR status match \n",VcDRNo, ModDRNo);fflush(stdout);

														}
														else
														{
															printf("\n  Error pop up now. As VC -(%s) and Module- (%s) DR status not matched \n",VCdrStatus, ModuleDrStatus);fflush(stdout);

															//EMH_clear_errors();
															//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "DR Status of VC or CCVC is Not Matching with Module.Please Correct the DR Status of Module Same as VC or CCVC" );
															//decision = EPM_nogo;
															//printf("\n  Error pop up now. As VC -(%s) and Module- (%s) DR status not matched \n",VCdrStatus, ModuleDrStatus);fflush(stdout);
															return ifail;

														}

														printf("\n OUTSIDE Module and VC DR status check  \n"); fflush(stdout);
													}
									   }
									  else
									  {
										printf("\n Else As Part TYPE Inside VC and Module Check is  ============= [%s]  \n",PartType); fflush(stdout);

									  }
								}
								else
								 {
									printf("\n  Else No Control Object found for VC and Module  == %d  \n", n_foundDR);fflush(stdout);
								 }
								 //end on 13 march//
									printf("\n Code started for ECU Count ,check Part Type as-- [%s]  \n",PartType); fflush(stdout);
									printf("\n Also check PartType1 -- [%s]  \n",PartType1); fflush(stdout);

								//	if((tc_strcmp(PartType,"Configurable VC")==0)||(tc_strcmp(PartType,"CCVC")==0))
								//	if((tc_strcmp(PartType,"Configurable VC")==0)||(tc_strcmp(PartType,"CCVC")==0))
										if ((tc_strcmp(PartType,"CCVC")==0)||(tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"Configurable VC")==0) || (tc_strcmp(PartType,"Vehicle")==0) ||  (tc_strcmp(PartType1,"V")==0) ||  (tc_strcmp(PartType1,"Vehicle")==0))
										{
											printf("\n Inside the Also check PartType1-(%d) and PartType -- [%s]  \n",PartType1,PartType); fflush(stdout);
											(ICS_ask_classification_object(DesignMasterTag,&Design_rev_cls_tag));
											if(Design_rev_cls_tag)
											{
													ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
													if(theAttributeCount>0)
													{
														for(ic=0;ic<theAttributeCount;ic++)
														{
															sprintf(attrId,"%d",theAttributeIds[ic]);

															tc_strcpy(attributeNameDup,"");
															tc_strcpy(attributeNameDup,theAttributeNames[ic]);

															//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,ic);fflush(stdout);

															if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
															{
																tc_strcpy(attributeValueDup,"");
																for(xc=0;xc<theAttributeValCounts[ic];xc++)
																{
																	//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
																	tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
																	//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
																}

																printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
																printf("\n attrId:[%s]",attrId);fflush(stdout);
																printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

																t5NoEcuDupint=atoi(attributeValueDup);
																printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10

															}

														}

												   }
											}
											else
											{
												printf("\n Design_rev_cls_tag Not Found..."); fflush(stdout);//10
											}
										
											//											ITK_CALL(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
//											printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
//
//											for(ic=0;ic<n_lov_entries;ic++)
//											{
//												printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
//												(ICS_ask_classification_object(DesignMasterTag,&Design_rev_cls_tag));
//
//												(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));
//
//												printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
//
//												if(tc_strcmp(attributeValue,lov_keys[ic])==0)
//												{
//													printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);
//
//													t5NoEcuDup		   =(char *) MEM_alloc(20);
//													tc_strcpy(t5NoEcuDup,lov_values[ic]);
//
//													printf("\n ECU COUNT IS  =%s",t5NoEcuDup); fflush(stdout);//10
//
//													t5NoEcuDupint=atoi(t5NoEcuDup);
//
//													printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10
//
//												}
//			
												ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_type));
												printf("\n   CCVC has ECU module REL FOUND \n");fflush(stdout);

												ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_type,&Modcnt,&Modattachments));
												printf("\n Modcnt ============= [%d]  \n",Modcnt); fflush(stdout);
												if (Modcnt > 0)
												{
													//Mod_rev_tag = Modattachments[0];
													Mod_rev_tag_mstr = Modattachments[0]; // 3 sept

													ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstr,&Mod_rev_tag));// 3 sept

													if(AOM_ask_value_string(Mod_rev_tag,"item_id",&ModulNo)==ITK_ok);
													printf("\n  VC validation ModulNo is  = [%s]\n", ModulNo);fflush(stdout);

													if(AOM_ask_value_string(Mod_rev_tag,"item_revision_id",&ModulRevid)==ITK_ok); //3 sept
													printf("\n  VC validation ModulRevid is  = [%s]\n", ModulRevid);fflush(stdout);//3 sept

													printf("\n Mod_rev_tagP \n"); fflush(stdout);
													//VC_Multi_Get_Part_BOM_Lvl_Col_1(window,99,level,LatestModRevTag,containerCount);
													VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,Mod_rev_tag,&containerCount);
												}
												printf("\n final count of containers  is [%d] \n",containerCount);fflush(stdout);
												if(containerCount==t5NoEcuDupint)
												{
													printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
												}
												else
												{
													printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
													sprintf(Container_count_string,"%d", containerCount);
													if (tc_strcmp(ECUCountErr,"NULL") !=0) MEM_free(ECUCountErr);
													ECUCountErr=(char *)MEM_alloc(600);
													tc_strcpy(ECUCountErr,"VC Attribute with Name 'Total number of ECUs' attribute value in Tech Spec Header of Vehicle/CCV ");
													tc_strcat(ECUCountErr,VCnumber);
													tc_strcat(ECUCountErr," is ");
													tc_strcat(ECUCountErr,attributeValueDup);
													tc_strcat(ECUCountErr,"\nNo. of Containers in ECU Module " );
													tc_strcat(ECUCountErr,ModulNo);
													tc_strcat(ECUCountErr," for vehicle/ccv ");
													tc_strcat(ECUCountErr,VCnumber);
													tc_strcat(ECUCountErr," is ");
													tc_strcat(ECUCountErr,Container_count_string);

													printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);

													//EMH_clear_errors();
													//EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErr);
													//decision = EPM_nogo;

													//printf("\n ECUCountErr :: %s",ECUCountErr);

													return ifail;
												}

											containerCount = 0;
											t5NoEcuDupint = 0;

										}
										//Code added by ajinkya for DVP Report validation on 10 sep ............ //
										printf("\n  DVP-VC validation for VC started now \n");fflush(stdout);
										if(QRY_find2("ControlObjQry", &TagWeControl));

										if(QRY_execute(TagWeControl, n_entriesWe, qry_entriesWe, qry_valuesWe, &n_foundWe, &dvpCtrObj));
										printf("\n Control Object found for WE parts == %d\n", n_foundWe);fflush(stdout);
										if(n_foundWe==1)
										{
											printf("\n  Control Object found for DVP == %d  \n", n_foundWe);fflush(stdout);
											if (DMLRevTag != NULLTAG)
											{
												printf("\n As DMLRevTag not null \n");fflush(stdout);

												ITK_CALL(POM_class_of_instance(DMLRevTag,&class_id));
												ITK_CALL(POM_name_of_class(class_id,&class_name));
												printf("\n\n DVP-VC  class_name of Task :%s \n",class_name);fflush(stdout);

												if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
												{
													printf("\n\n Task class_name find ---:%s \n",class_name);fflush(stdout);
													ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
													if (tsk_dml_rel_type!=NULLTAG)
													{
														printf("\n\n Relationship tag class_name find  \n");fflush(stdout);
														ITK_CALL(GRM_list_primary_objects_only(DMLRevTag,tsk_dml_rel_type,&jdv,&DMLRevision));
														printf("\n\n\t\t DML Revision from Task : %d \n",jdv);fflush(stdout);

														for (jt=0;jt<jdv ;jt++ )
														{
															printf("\n\n Inside for DML Latest revision  ---:%d \n",jdv);fflush(stdout);
															ITK_CALL(ITEM_rev_sequence_is_latest(DMLRevision[jt],&is_latest));
															printf("\n\n\t\t is_latest : %d \n",is_latest);fflush(stdout);

															if(is_latest != true)
															{
																printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);
															}else
															{
																printf("\n\n INSIDE DML FIND  code \n");fflush(stdout);
																NewDMLRevTag = DMLRevision[jt];

																ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
																printf("\n IN VC DML business unit for DVP :%s \n",BusUnitDV);fflush(stdout);

																ITK_CALL(AOM_ask_value_string(NewDMLRevTag,"t5_cDRstatus",&DMLDRdvp));
																printf("\n IN VC DML DR status  for DVP :%s \n",DMLDRdvp);fflush(stdout);
															}
														}
													}
												}

												printf("\n IN VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);

												if(((strcmp(BusUnitDV,"PVBU")==0)||(strcmp(BusUnitDV,"CVBU")==0)||(strcmp(BusUnitDV,"PV-PSE")==0)||(strcmp(BusUnitDV,"CV-PSE")==0)||(strcmp(BusUnitDV,"PV-Transmission")==0)||(strcmp(BusUnitDV,"CV-Transmission")==0))&& (strcmp(DMLDRdvp,"DR4")==0))										
												{
												printf("\n  DVP-VC validation PartType is  = [%s] \n", PartType);fflush(stdout);
												if ((tc_strcmp(PartType,"CCVC")==0)||(tc_strcmp(PartType,"V")==0))
												{
												printf("\n Part TYPE Inside DVP-VC ============= [%s]  \n",PartType); fflush(stdout);
												ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDv));
												printf("\n  DVP-VC CCVC has ECU module REL FOUND \n");fflush(stdout);

												ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag,CCVCrelation_typeDv,&ModcntDv,&ModattachmentsDv));
												printf("\n DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);

												if (ModcntDv > 0)
												{
												printf("\n Inside DVP-VC ModcntDv ============= [%d]  \n",ModcntDv); fflush(stdout);
												Mod_rev_tag_mstrDv = ModattachmentsDv[0];

												ITK_CALL(ITEM_ask_latest_rev(Mod_rev_tag_mstrDv,&Mod_rev_tagDv));

												if(AOM_ask_value_string(Mod_rev_tagDv,"item_id",&ModulNoDv)==ITK_ok);
												printf("\n  DVP-VC validation ModulNoDv is  = [%s] \n", ModulNoDv);fflush(stdout);

												if(AOM_ask_value_string(Mod_rev_tagDv,"item_revision_id",&ModulRevidDv)==ITK_ok); //3 sept
												printf("\n DVP-VC validation ModulRevidDv is  = [%s] \n", ModulRevidDv);fflush(stdout);//3 sept

												printf("\n Mod_rev_tagP \n"); fflush(stdout);

												//code for Module expand//
												ITK_CALL(BOM_create_window (&window)); //3 sept
												ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept
												ITK_CALL(CFM_find("ERC Released and Above", &sn_rule ));
												ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

												ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tagDv,null_tag, &top_line));

												ITK_CALL(BOM_window_show_suppressed (window));

												printf("\n DVP-VC after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

												ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
												printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);

												ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
												printf("\n\n\t\t **** DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);

												if (n_Cnt>0)
												{
												printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);
												for (jcnt=0;jcnt<n_Cnt;jcnt++)
												{
												printf("\n\n\t\t Inside for loop \n");fflush(stdout);

												bl_Child_dv=children[jcnt];

												ITK_CALL(AOM_ask_value_string( bl_Child_dv,"bl_item_item_id",&LatChildName));
												printf("\n DVP-VC LatChildName Parts Id : [%s] \n",LatChildName);

												if( AOM_ask_value_string(bl_Child_dv,"bl_T5_EE_PartRevision_t5_SwPartType",&ModPartType)!=ITK_ok);
												printf("\n DVP-VC t_ChildItemRev tag found ===>%s \n",ModPartType);fflush(stdout);

												//check for dvp report //
												if(strcmp(ModPartType,"CON")==0)
												{
												printf("\n Inside container part found ===>%s \n",ModPartType);fflush(stdout);
												//ITK_CALL(ITEM_find_item(LatChildName,&EE_tag));
												//printf("\n Function called FOR EE_tag \n");fflush(stdout);

												//if( AOM_ask_value_string(EE_tag,"item_id",&Item_id_EE)!=ITK_ok);

												//printf("\n  DVP-VC Item ID is  ---->%s \n",Item_id_EE); fflush(stdout);

												//ITK_CALL(ITEM_ask_latest_rev(EE_tag,&EEparent_rev));

												if(TCTYPE_ask_object_type(bl_Child_dv,&objTypeTagdv));
												if(TCTYPE_ask_name2(objTypeTagdv,&type_name));
												printf("\n\n\t\t DVP-VC EEparent_rev type_name := %s \n", type_name);fflush(stdout);

												if(strcmp(type_name,"T5_EE_PartRevision")==0)
												{
												printf("\n\n\t\t For DVP-VC part type is  %s \n", type_name);fflush(stdout);

												ITK_CALL(GRM_find_relation_type("IMAN_specification",&reln_typeDvp));
												printf("\n\n\t\t DVP for IMAN_specification......... \n");fflush(stdout);

												if(reln_typeDvp != NULLTAG)
												{
												printf("\n\n\t\t DVP-VC relation_type   is not null........ \n");fflush(stdout);

												ITK_CALL(GRM_list_secondary_objects(bl_Child_dv,reln_typeDvp,&n_attchs_dvp,&secondary_dvp));

												printf("\n\n\t\t DVP-VC After GRM_list_secondary_objects count : %d \n",n_attchs_dvp);fflush(stdout);


												if(n_attchs_dvp>0)
												{
												for(ddi=0;ddi<n_attchs_dvp;ddi++)
												{
												dvpflag=0;
												printf("\n\n\t\t DVP-VC Inside data set for DVP-VC found ........ \n");fflush(stdout);

												SolnItemTag = secondary_dvp[ddi].secondary;

												ITK_CALL(AOM_ask_value_string(SolnItemTag,"object_name",&dataset_name1));
												printf("\n\n\t\t DVP-VC Data set name for DVP----%s ........ \n",dataset_name1 );fflush(stdout);

												if(strstr(dataset_name1,"DVP") != NULL)
												{
												printf("\n\n\t\t DVP-VC Inside Flag set as Data set name for DVP----%s ........\n",dataset_name1 );fflush(stdout);

												dvpflag=1;
												break;
												}
												}
												printf("\n DVP-VC OUTSIDE for loop dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
												if (dvpflag==1)
												{
												printf("\n DVP-VC Inside dvpflag  flag for dvp find ----- :%d  \n",dvpflag);fflush(stdout);
												}
												else
												{
												printf("\n\n DVP-VC Inside else as DVP report NOT found attached Container as flag value  %d \n" ,dvpflag );fflush(stdout);

												//EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Please Attach DVP Validation Report to Container Part in Specification \n Give Report Name which Start with DVP Word" );
												//decision = EPM_nogo;
												return ifail;

												}

												}
												else
												{
												printf("\n\n DVP-VC As no data set found, GIVE THE ERROR Please attach DVP validation report to Container.. (%d) \n",n_attchs_dvp );fflush(stdout);
												//EMH_clear_errors();
												////EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "No Dataset Found for Container Part.Please Attach DVP Validation Report to Container in Specification \n Give Report Name which Start with DVP Word" );
												//decision = EPM_nogo;
												return ifail;
												}

												}

												}
												else
												{
												printf("\n\n\t\t DVP-VC Else part type EEparent_rev type_name := %s \n", type_name);fflush(stdout);
												}

												}
												else
												{
												printf("\n DVP-VC Else container part Not found ===>%s \n",ModPartType);fflush(stdout);
												}

												}
												}

												//end
												}

												}
												else
												{
												printf("\n Else Part TYPE  DVP-VC  ============= [%s]  \n",PartType); fflush(stdout);
												}

												}
												else
												{
												printf("\n Else VC DML DR status--(%s) and Bussiness Unit  for DVP :(%s) \n",BusUnitDV, DMLDRdvp);fflush(stdout);

												}

										   }

										}
										else
										 {
											printf("\n Else Control Object Not found for DVP not FOUND == %d  \n", n_foundWe);fflush(stdout);
										 }
										 printf("\n Outside fot DVP report check on VC code \n");fflush(stdout);
						 }
					 }
				 }

		 }

	}

	if(theAttributeNames !=NULL)
		MEM_free(theAttributeNames);

	if(theAttributeValues !=NULL)
		MEM_free(theAttributeValues);

	if(theAttributeOptimizedUnits !=NULL)
		MEM_free(theAttributeOptimizedUnits);

	if(attributeNameDup !=NULL)
		MEM_free(attributeNameDup);

	if(attributeValueDup !=NULL)
		MEM_free(attributeValueDup);


	return ifail;
}
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int reqLevel,int level,tag_t Mod_rev_tag, int *containerCount)
{
	int ifail;
	int status = 0;
	int iChildItemTag=0;
	char * ItemName;
	int k		    =0;
	int n_Cnt	    =0;
	int assbvr	    =0;
	int flagBVR	    =0;
	int n_values_bvr=0;

	tag_t   t_ChildItemRev;
	//tag_t	window 	    = NULLTAG;

	tag_t	top_line    = NULLTAG;
	int bvrfound		= 0;
	tag_t  *children	= NULLTAG;
	char* partNumber 	= NULL;
	char* PartType      = NULL;
	char* LatChildName      = NULL;
	char* ObjType       = NULL;
	char* BLObjType     = NULL;
	tag_t	sn_rule		= NULLTAG;
	tag_t	window		= NULLTAG;


	printf("\n INSIDE MULTI LEVEL EXP FUNCTION \n");fflush(stdout);

	if(level == reqLevel) goto CLEANUP;
	ITK_CALL(BOM_create_window (&window)); //3 sept

	ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept

	ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));

	ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

	ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tag,null_tag, &top_line));

	ITK_CALL(BOM_window_show_suppressed (window));

	printf("\n after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
	printf("\n\n\t\t **** No of child objects are n level :: %d :: %d\n",level, n_Cnt);fflush(stdout);

	if(n_Cnt == 0) goto CLEANUP;
	for (k = 0; k < n_Cnt; k++)
	  {
		BOM_line_unpack (children[k]);
		//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
		//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);

		if( AOM_ask_value_tag(children[k],"bl_line_object",&t_ChildItemRev)!=ITK_ok);

		if(t_ChildItemRev!=NULLTAG)
		{
			//if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			printf("\n t_ChildItemRev Part type  ===>%s\n",PartType);fflush(stdout);

			if( AOM_ask_value_string(children[k],"bl_item_item_id",&LatChildName)!=ITK_ok);
			printf("\n  LatChildName Parts Id : [%s] \n",LatChildName);

			//char   dRftSpectype_name[TCTYPE_name_size_c+1];
			char   *dRftSpectype_name=NULL;
			tag_t  DrftSpecTypeTag = NULLTAG;

			if(TCTYPE_ask_object_type(t_ChildItemRev,&DrftSpecTypeTag));
			if(TCTYPE_ask_name2(DrftSpecTypeTag,&dRftSpectype_name));

			printf("\n t_ChildItemRev tag found ===>%s\n",dRftSpectype_name);fflush(stdout);


			if(tc_strcmp(PartType,"CON")==0)
			{
				*containerCount=*containerCount+1;
				printf("\n count after is [%d] -- %s for part number -%s\n",*containerCount, PartType,LatChildName);fflush(stdout);
			}

			VC_Multi_Get_Part_BOM_Lvl_Col_SW(reqLevel,level,t_ChildItemRev,containerCount); //3 sept
		 }
	  }
	level = level + 1;

	window = NULLTAG;

	CLEANUP:
		printf("\n Inside VC_Multi_Get_Part_BOM_Lvl_1 function CLEANUP\n");fflush(stdout);

	return 0;
}