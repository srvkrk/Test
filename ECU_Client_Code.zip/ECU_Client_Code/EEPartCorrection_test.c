
/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File                  :   EEPartCorrection.c
*  Author                :   Sudhir
*  Module                :   Control Object create in TCUA
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/aom_prop.h>
#include <cfm/cfm.h>
#include <tccore/project.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100

#define CONST_MAX_YEAR                   2100
#define CONST_MIN_YEAR                   1975
#define CONST_MAX_MONTH                  11
#define CONST_MIN_MONTH                  0
#define CONST_MIN_DAY                    1
#define CONST_MAX_DAY                    31
#define CONST_MIN_HOUR                   00
#define CONST_MAX_HOUR               23
#define CONST_MIN_MINUTE                 00
#define CONST_MAX_MINUTE                 59
#define CONST_MIN_SECOND                 00
#define CONST_MAX_SECOND                 59
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

tag_t* childLines               = NULLTAG;
int childPartcount=0;
static void handle_ifail(char *file, int line);
void setAddTAG(int *count,tag_t **objlist,tag_t obj );
void setAddStr(int *count,char ***strset,char* str);
void setFindStr(char **str_list,int count,char *str,int *found);
static logical is_descendant_of_folder(tag_t object_tag);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X)                                                     \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("%3d error(s) with #X\n", n_ifails);                                             \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
        ;

		static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}


struct func
{
         char SrNo[100];
         char Module_Number[100];
         char Module_Revision[500];
         char Module_Seqence[500];
         char Module_Description[1000];
         char Module_ProjectCode[1000];
         char Module_DrStatus[1000];
         char Module_PartType[1000];
         char Module_Creator[1000];
         char Module_Plateform[1000];
         char Module_AggregateGroup[1000];
         char Module_Aggregates[1000];
         char Module_ModuleName[1000];
         char Module_SubModule[1000];
         char Module_SubModuleAdress[1000];
         char Module_SubModuleDesignGrp[1000];
         char Module_CreationDate[40];
         char Module_ReleaseStatus[40];
         char Module_PrtAddonDesc[200];
         char Module_PrtLstUpd[40];
         char Module_DML[40];

} moduleobjupload[800000];

logical IsValideDate(date_t *date)
{
        logical isFlag          = false;
        date_t  localdate  = NULLDATE;

        localdate = *date;

        //Check if date is null
        if(DATE_IS_NULL(localdate) != 1)
        {
                if(date->year < CONST_MIN_YEAR)
                        date->year = CONST_MIN_YEAR;

                if (date->year > CONST_MAX_YEAR)
                        date->year = CONST_MAX_YEAR;

                if(date->month < CONST_MIN_MONTH)
                        date->month = CONST_MIN_MONTH;

                if(date->month > CONST_MAX_MONTH)
                        date->month = CONST_MAX_MONTH;

                if(date->day < CONST_MIN_DAY)
                        date->day = CONST_MIN_DAY;

                if(date->day > CONST_MAX_DAY)
                        date->day = CONST_MAX_DAY;

                if(date->hour < CONST_MIN_HOUR)
                        date->hour = CONST_MIN_HOUR;

                if(date->hour > CONST_MAX_HOUR)
                        date->hour = CONST_MAX_HOUR;

                if(date->minute < CONST_MIN_MINUTE)
                        date->minute = CONST_MIN_MINUTE;

                if(date->minute > CONST_MAX_MINUTE)
                        date->minute = CONST_MAX_MINUTE;

                if(date->second < CONST_MIN_SECOND)
                        date->second = CONST_MIN_SECOND;

                if(date->second > CONST_MAX_SECOND)
                        date->second = CONST_MAX_SECOND;

                //For the months of April, June, September and November, check the date to be less than or equal to 30
                if (date->month == 3 || date->month == 5 || date->month == 8 || date->month == 10)
                {
                        if (date->day > 30)
                                date->day = 30;
                }

                //For the month of February,
                /////If the year is a leap year, then check the date to be less than or equal to 29
                /////Else, check the date to be less than or equal to 28
                if (date->month == 1)
                {
                        if((date->year % 4 == 0 && date->year % 100 != 0) || date->year % 400 == 0)
                        {
                                if (date->day > 29)
                                        date->day = 29;
                        }
                        else
                        {
                                if (date->day > 28)
                                        date->day = 28;
                        }
                }

                //Set the Flag true
                isFlag = true;
        }

        return isFlag;
}

int TML_Change_Creation_Date(tag_t revTag,date_t creation_date,date_t release_date)
{
        int             iCnt            = 0;
        int             ifail           = 0;
        tag_t   Module_CreationDate = NULLTAG;
        tag_t   Module_ReleseDate = NULLTAG;

        if(DATE_IS_NULL(creation_date) == 0)
        {
                ifail = AOM_refresh(revTag,true);

                printf("\n Debugging ==> 003 \n");fflush(stdout);

                //ifail = POM_set_creation_date(revTag,creation_date);
                POM_attr_id_of_attr("t5_smTceCreDate", "T5_MODULEMIGTRK", &Module_CreationDate);
                POM_set_attr_date(1, &revTag, Module_CreationDate, creation_date);

                printf("\n Debugging ==> 004 \n");fflush(stdout);

                //ifail = AOM_save_without_extensions(revTag);



                POM_save_instances(1, &revTag, false);


                ifail = AOM_refresh(revTag,false);

        }
        if(DATE_IS_NULL(release_date) == 0)
        {
                ifail = AOM_refresh(revTag,true);

                printf("\n Debugging ==> 003 \n");fflush(stdout);

                //ifail = POM_set_creation_date(revTag,release_date);
                POM_attr_id_of_attr("t5_smTceRelDate", "T5_MODULEMIGTRK", &Module_ReleseDate);
                POM_set_attr_date(1, &revTag, Module_ReleseDate, release_date);

                POM_attr_id_of_attr("t5_smTceDmlRelDate", "T5_MODULEMIGTRK", &Module_ReleseDate);
                POM_set_attr_date(1, &revTag, Module_ReleseDate, release_date);

                printf("\n Debugging ==> 004 \n");fflush(stdout);

                //ifail = AOM_save_without_extensions(revTag);



                POM_save_instances(1, &revTag, false);


                ifail = AOM_refresh(revTag,false);

        }

        return ITK_ok;
}

static date_t TML_token_to_date(char *str )
{
        date_t   date             = NULLDATE;

        int      month      = 0;          /* Month */
        int      day        = 0;          /* Day */
        int      year       = 0;          /* Year */
        int      hour       = 0;          /* Hour */
        int      minute     = 0;          /* Minutes */
        int      second     = 0;          /* Seconds */

        int ifail=0;

        //printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

        printf("\n Debugging ==>%s 000899999 \n",str);fflush(stdout);

        if(tc_strlen(str)>0)
        {
                printf("\n Debugging ==> 0008999 \n");fflush(stdout);
                sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
                month--;

                date.month = month;
                date.day   = day;
                date.year  = year;
                date.hour  = hour;
                date.minute= minute;
                date.second= second;
                printf("\n month ==> %d \n",month);fflush(stdout);
                printf("\n day ==> %d \n",day);fflush(stdout);
                printf("\n year ==> %d \n",year);fflush(stdout);
                printf("\n hour ==> %d \n",hour);fflush(stdout);
                printf("\n minute ==> %d \n",minute);fflush(stdout);
                printf("\n second ==> %d \n",second);fflush(stdout);

        }
        printf("\n date ==> %d \n",date);fflush(stdout);
        return date;
}

/* Function to add Tag into a set of Tag */
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

        *count=*count+1;
        if(*count==1)
        {
                //printf("\n ****setAddTAG1");fflush(stdout);
                (*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

        }
        else
        {
                //printf("\n ****setAddTAG2");fflush(stdout);
                (*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
        }

        (*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


/* Function to add string into a set of string */
void setAddStr(int *count,char ***strset,char* str)
{

        *count=*count+1;
        //printf("\n setAddStr %d",*count);fflush(stdout);
        if(*count==1)
        {
                (*strset) = (char **)malloc((*count ) * sizeof(char *));
        }
        else
        {
                (*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
        }
        (*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
         tc_strcpy((*strset)[*count-1],str);
         //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void setFindStr(char **str_list,int count,char *str,int *found)
{

        int k=0;
        //*found=0;
        *found=-1;
        char *TempModuleprt             = NULL;
        for(k=0;k<count-1;k++)
        {

                //printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
                if(tc_strlen(str_list[k])>0)tc_strdup(str_list[k],&TempModuleprt);
                //printf("\n[%d]tc_strcmp(%s,%s)",k,TempModuleprt,str);fflush(stdout);
                if(tc_strcmp(TempModuleprt,str)==0)
                {
                        *found=k;
                        break;
                }

        }
}
int setFindStr1(int *count,char ***strset,char* str)
 {
        int j   =0;

        //tmp = sizeof(*strset);

        for(j=0;j<*count;j++)
        {
                //printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
                //printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
                //printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

                //if(tc_strcmp((*strset)[*count-1],str)==0) //check this
                if(tc_strcmp((*strset)[j],str)==0) //check this
                //if(tc_strcmp(*strset[j],str)==0)

                return j;

        }
        return -1;
 }

void setFindTag(tag_t *objlist,int count,tag_t obj,int *found)
{
        int k=0;
        *found=-1;

        for(k=0;k<count;k++)
        {


                if(objlist[k]==obj)
                {
                        *found=k;
                        break;
                }
        }
}
void setFindTag1(tag_t *objlist,int count,tag_t obj,int *found)
{
        int k=0;
        *found=-1;
        char *uidtofind;
        ITK__convert_tag_to_uid(obj,&uidtofind);
        for(k=0;k<count;k++)
        {
                char *uidbefind;
                ITK__convert_tag_to_uid(objlist[k],&uidbefind);
                //printf("\n uidbefind-->[%s]\n",uidbefind);fflush(stdout);
                //printf("\n uidtofind-->[%s]\n",uidtofind);fflush(stdout);
                if(tc_strcmp(uidbefind,uidtofind)==0)
                {
                        *found=k;
                        break;
                }
        }
}
/*calling BOM Window Child Part Line Count for tags and calling recursive function as well*/

int findChildTag(tag_t tagBOMline,int* StrctInt)
{
        int ifail =0;
        int status;
        int                     count2                                                                  = 0;
        int                     childCountCfgTopBomLine1                                = 0;
        int                     childCountCfgTopBomLine2                                = 0;
        tag_t                   *childTagCfgTopBomLine1                                 = NULLTAG;
        tag_t                   *childTagCfgTopBomLine2                                 = NULLTAG;
        tag_t   projobj                                 = NULLTAG;

        char*   partNumber = NULL;
        char*   partRevNumber = NULL;
        char*   partSeqNumber = NULL;
        char *  item_level= NULL;
        char *  quantity = NULL;
        char *  PuneCS= NULL;
        char* Weight= NULL;
        char* PartProjCode1 = NULLTAG;
        char* CS= NULLTAG;
        char* PartProjCode = NULLTAG;
        char* PartType = NULLTAG;
        char* Material = NULLTAG;
        char* Description = NULLTAG;
        char*   SurfaceArea =NULL;
        char*   Volume =NULL;
        char*   Thicknes =NULL;
        char*   EnvelopeDimensions =NULL;
        char    *ModItem_Rev                    =       NULL;
        char    *ModItem_Seq                    =       NULL;
        char    *ChildGroup                     =       NULL;

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_level_starting_0",&item_level);
        printf("Part Level number===>%s\n",item_level);fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_item_item_id",&partNumber);
        printf("Part number===>%s\n",partNumber);fflush(stdout);

    ifail=AOM_ask_value_string(tagBOMline,"bl_rev_item_revision_id",&partRevNumber);
        printf("Part Rev number===>%s\n",partRevNumber);fflush(stdout);

        ModItem_Rev =  tc_strtok(partRevNumber,";");
        printf("Item_Rev --> : %s\n",ModItem_Rev); fflush(stdout);

        ModItem_Seq = tc_strtok(NULL,";");
        printf("Item_Seq --> : %s\n",ModItem_Seq); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Weight",&Weight);
        printf("Part Weight: [%s]\n", Weight); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_SurfaceArea",&SurfaceArea);
        printf("SurfaceArea : [%s]\n", SurfaceArea); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Volume",&Volume);
        printf("Volume : [%s]\n", Volume); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_PunMakeBuyIndicator",&PuneCS);
        printf("Part CS number===>%s\n",PuneCS);fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_Material",&Material);
        printf("Material: [%s]\n", Material); fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_rev_object_desc",&Description);
        printf("object_description: [%s]\n", Description); fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_ProjectCode",&PartProjCode);
        printf("Part ProjCode: [%s]\n", PartProjCode); fflush(stdout);

         ITKCALL (PROJ_find(PartProjCode,&projobj));
         if(projobj !=NULLTAG)
        {
                AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);
                printf("Part Project Description: %s", PartProjCode1); fflush(stdout);
        }
        else
        {       printf("Project not Resister for Item\n");fflush(stdout); }

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions);
        printf("EnvelopeDimensions : [%s]\n", EnvelopeDimensions); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_MThickness",&Thicknes);
        printf("Thicknes : [%s]\n", Thicknes); fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PartType",&PartType);
        printf("PartType: [%s]\n", PartType); fflush(stdout);

        ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_DesignGrp",&ChildGroup);
        printf("ChildGroup: [%s]\n", ChildGroup); fflush(stdout);

        ifail=AOM_UIF_ask_value(tagBOMline,"bl_quantity",&quantity);
        printf("Part Quantity number==>%s\n\n",quantity);fflush(stdout);

        *StrctInt       =       *StrctInt+1;

        ITK_CALL(BOM_line_ask_child_lines(tagBOMline, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1));

        printf("*********Number of Child Lines & its ChildTag*********** %d \n",childCountCfgTopBomLine1);fflush(stdout);

        for (count2 = 0;count2 < childCountCfgTopBomLine1;count2++)
        {
                ITK_CALL(findChildTag(childTagCfgTopBomLine1[count2],StrctInt));
                setAddTAG(&childPartcount,&childLines,childTagCfgTopBomLine1[count2]);
        }
        printf("\n findChildTag: Total Number of Child Parts Found--->[%d] \n",childPartcount);fflush(stdout);
        return 0;
}


static logical is_descendant_of_folder(tag_t object_tag)
{
    int status;
        tag_t parent_class = NULLTAG;
    ITK_CALL(POM_class_id_of_class("Folder", &parent_class));

    tag_t class_tag = NULLTAG;
    ITK_CALL(POM_class_of_instance(object_tag, &class_tag));

    logical verdict = FALSE;
    ITK_CALL(POM_is_descendant(parent_class, class_tag, &verdict));

    return verdict;
}

int ITK_user_main(int argc,char* argv[])
{
        int z;
        int status;


        tag_t   query                                   = NULLTAG;
        tag_t   query3                                  = NULLTAG;
        tag_t   query2                                  = NULLTAG;
        tag_t   *Design_objects                 = NULLTAG;
        tag_t   *DesignRev_objects              = NULLTAG;
        tag_t   DesignRev_object                = NULLTAG;
        tag_t   Design_object                   = NULLTAG;
        tag_t   reln_type                               = NULLTAG;
        tag_t   primary                                 = NULLTAG;
        tag_t   objTypeTag                              = NULLTAG;
        tag_t   tagBOMwindow                    = NULLTAG;
        tag_t   tagBOMwindow1                   = NULLTAG;
        tag_t   tagRule                                 = NULLTAG;
        tag_t   tagRule1                                = NULLTAG;
        tag_t   tagBOMline                              = NULLTAG;
        tag_t   tagParentBOMline                = NULLTAG;
        tag_t   *childTagCfgTopBomLine1 = NULLTAG;
        tag_t   *Design_objects2                = NULLTAG;
        tag_t   *parents                                = NULLTAG;
        tag_t   *childTagTopBomLine             = NULLTAG;
        tag_t   *EE_objects                             = NULLTAG;
        tag_t   *t_EERevObjs                    = NULLTAG;
        GRM_relation_t *related_object_list;
   //     char  type_name[TCTYPE_name_size_c+1];

		char *type_name                       = NULL;





        FILE* fptr = NULL;


        const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;
    const char* arg1 = NULL;


        char *Pno                       = NULL;
        char *EEPno                     = NULL;
        char *PartNumber        = NULL;
        char *DesignGrp         = NULL;
        char *ParentNumber      = NULL;
        char *ParentDsgGrp      = NULL;
        char *ParentRev         = NULL;
        char **ChildPrtNumber= NULL;
        char *tag_blitemId      = NULL;
        char **ChildQty          = NULL;
        char **ChildRev          = NULL;
        char **AtMatrix          = NULL;
        char **RtMatrix          = NULL;
        char *Part_Revision     = NULL;
        char *DesRevSeq     = NULL;
        char *eeRevSeq     = NULL;
		char* ErrorText;
		int ifail=0;

        int StrctInt   =0;
        int  n_entries1=2;
        int  n_entries3=2;
        int  n_found1,dsgrevcnt,rel=0;
        int  dsgcnt,TotalRevs,n_attchs=0;
        int  childCountCfgTopBomLine1=0;
        int  childCountTopBomLine=0;
        int  n_entries2=1;
        int  n_found2=0;
		int r;

        int n_parents,n_found3 = 0;
    int *levels = 0;
        int bl_item_id   = 0;
        int bl_quantity  = 0;
        int bl_rev_item_revision_id      = 0;
        int bl_plmxml_abs_xform  = 0;
        int bl_plmxml_occ_xform  = 0;
        int ii,jj,EE_tags_found = 0;
		tag_t slave_relationType=NULLTAG;
		tag_t DesrelationType=NULLTAG;
		int mstrcnt=0;
		tag_t* mstrobj=NULLTAG;
		tag_t Slave_relation_tag=NULLTAG;
		tag_t param_relationType=NULLTAG;
		int paramcnt=0;
		tag_t* prmobj=NULLTAG;
		tag_t Param_relation_tag=NULLTAG;
		tag_t eerevseqtag =NULLTAG;
		tag_t eerelation_tag =NULLTAG;
		tag_t reltyptag =NULLTAG;
		tag_t* list_of_references=NULLTAG;
		int ITK_OK = 0;
		tag_t des_rel_typ =NULLTAG;
		tag_t des_rel_tag  =NULLTAG;



        int n_references = 0;
	 int *levels1 = NULL;
    tag_t *reference_tags = NULLTAG;
    char **relation_type_name = NULL;
	int num_of_references=0;

	int  strct1=0;
	int  strct2=0;
	int  strct3=0;
	int  strct4=0;
	int  strct5=0;

        char
        *qry_entries1[2] = {"Item ID","Type"},
        *qry_values1[2] = {"*","*"};

        char
        *qry_entries3[2] = {"Item ID","Type"},
        *qry_values3[2] = {"*","*"};

        char
        *qry_entries2[2] = {"BOM_Child_ItemID"},
        *qry_values2[2] = {"*"};

        const char
        *attrs1[2] = {"item_id","object_type"},
        *values1[2]     = {"*","*"};


        printf("\n\n\t Attempting Logging\n ");fflush(stdout);
        u = ITK_ask_cli_argument( "-u=");
        p = ITK_ask_cli_argument( "-pf=");
        g = ITK_ask_cli_argument( "-g=");
        arg1 = ITK_ask_cli_argument( "-i=");

        //ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
        //ITK_auto_login();
        //ITK_set_bypass(true);

        printf("\n\n\t Attempting Logging with User [%s], Passwd[%s], Group[%s]\n ",u,p,g);fflush(stdout);

        z=ITK_CALL(ITK_auto_login());
       if(z!=ITK_ok)
        {
                //printf("\n\n\t OMG Login Not Successfull\n ");fflush(stdout);
        }
        else
        {
        printf("\n\n\t Login Successfull\n ");fflush(stdout);
                //ITK_set_journalling( TRUE );
        }

        //u = ITK_ask_cli_argument( "-u=loader");
        //p = ITK_ask_cli_argument( "-p=loader123");
        //g = ITK_ask_cli_argument( "-g=dba");
   //     if (ITK_init_module(u,p,g) == ITK_ok )
   //     {
                printf("\n\n\t Login Successfull\n ");fflush(stdout);
                ITK_set_bypass(true);
                Pno=(char *)MEM_alloc(30);
                EEPno=(char *)MEM_alloc(30);
                tc_strcpy(Pno,arg1);
                tc_strcpy(EEPno,arg1);
                tc_strcat(Pno,"_16");
                printf("\n Input part Number is=>[%s]",Pno);fflush(stdout);
                printf("\n Input EE part Number is=>[%s]",EEPno);fflush(stdout);
                qry_values1[0] = Pno;
                qry_values1[1] = "Design";

                ITK_CALL(QRY_find2("Item...", &query));
                ITK_CALL(QRY_find2("IsUsedByAssembly", &query2));
                ITK_CALL(QRY_find2("Item...", &query3));

                if(query!=NULLTAG)
                {
                        printf("\n1Query Found...");fflush(stdout);
                        ITK_CALL(QRY_execute(query, n_entries1, qry_entries1, qry_values1, &n_found1, &Design_objects));
                }
                if(query3!=NULLTAG)
                {
                        printf("\n2Query Found...");fflush(stdout);
                        qry_values3[0] = EEPno;
                        qry_values3[1] = "EE Part";
                        ITK_CALL(QRY_execute(query3, n_entries3, qry_entries3, qry_values3, &n_found3, &EE_objects));
                }
                printf("\n Total Number of Designobjects=>[%d]",n_found1);fflush(stdout);
                printf("\n Total Number of EEobjects=>[%d]",n_found3);fflush(stdout);
                if(n_found1>0)
                {
                        for(dsgcnt=0;dsgcnt<n_found1;dsgcnt++)
                        {
                                Design_object = Design_objects[dsgcnt];
                                AOM_ask_value_string(Design_object,"item_id",&PartNumber);
                                printf("\n PartNumber=>[%s]",PartNumber);fflush(stdout);
                                ITK_CALL(ITEM_list_all_revs(Design_object,&TotalRevs,&DesignRev_objects));
                                printf("\n Total Number of DesignRevobjects=>[%d]",TotalRevs);fflush(stdout);
                                if(TotalRevs>0)
                                {
                                        for(dsgrevcnt=0;dsgrevcnt<TotalRevs;dsgrevcnt++)
                                        {
                                                DesignRev_object = DesignRev_objects[dsgrevcnt];
                                                AOM_ask_value_string(DesignRev_object,"t5_DesignGrp",&DesignGrp);
                                                printf("\n DesignGrp=>[%s]",DesignGrp);fflush(stdout);
                                                //if((tc_strcmp(DesignGrp,"16")==0) && (tc_strlen(PartNumber)==12))
                                                //if((tc_strcmp(DesignGrp,"16")==0))
                                                //{ 
											
                                                        ITK_CALL(GRM_list_secondary_objects(DesignRev_object,reln_type,&n_attchs,&related_object_list));
                                                        printf("\n Total Number of n_attchs=>[%d]",n_attchs);fflush(stdout);
                                                        if(n_attchs>0)
                                                        {
                                                                for(rel=0;rel<n_attchs;rel++)
                                                                {
                                                                        primary=related_object_list[rel].secondary;
                                                                        ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
                                                                        ITK_CALL(TCTYPE_ask_name2(objTypeTag,&type_name));
																		
																		
                                                                        printf("\n Type Name:%s ..............",type_name);fflush(stdout);
                                                                }
                                                        }
                                                        // BOM Expansion...
                                                        /*
                                                        ITK_CALL(BOM_create_window(&tagBOMwindow));
                                                        ITK_CALL(BOM_set_window_pack_all(tagBOMwindow, true));
                                                        ITK_CALL(CFM_find("Latest Working", &tagRule));
                                                        ITK_CALL(BOM_set_window_config_rule( tagBOMwindow,tagRule));
                                                        ITKCALL(BOM_save_window(tagBOMwindow));
                                                        ITKCALL(BOM_set_window_top_line(tagBOMwindow, NULLTAG, DesignRev_object, NULLTAG, &tagBOMline));
                                                        ITK_CALL(BOM_line_ask_child_lines(tagBOMline, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1));
                                                        printf("\n Total Parts Found from BOM Line childPartcount --->[%d]\n", childCountCfgTopBomLine1); fflush(stdout);
                                                        */

                                                        //childPartcount = 0;
                                                        //if(childLines!=NULLTAG)MEM_free(childLines);
                                                        //ITKCALL(findChildTag(tagBOMline,&StrctInt));

            
														AOM_ask_value_string(DesignRev_object,"item_revision_id",&DesRevSeq);
														printf("\n Design revision --->[%s]\n", DesRevSeq); fflush(stdout);
                                                  
														 ITK_CALL(WSOM_where_referenced2((const tag_t)DesignRev_object, 1, &n_references, &levels1,&reference_tags, &relation_type_name));
														printf("\n references --->[%d]\n", n_references); fflush(stdout);
														for (ii = 0; ii < n_references; ii++)
                                                        {       
                                                                //char  type_name1[WSO_name_size_c + 1] = "";
																char*  type_name1 = NULL;

																
                                                                ITK_CALL(WSOM_ask_object_type2(reference_tags[ii], &type_name1));

                                                                printf("\n type_name1 --->[%s]\n", type_name1); fflush(stdout);
                                                                printf("\n relation_type_name[ii] --->[%s]\n", relation_type_name[ii]); fflush(stdout);
                                                            
															if((strlen(relation_type_name[ii]) > 0) && (tc_strcmp(relation_type_name[ii],"T5ERCDtl")==1))//indent                
															{
																printf("\n relation is exist"); fflush(stdout);
                                                                 ITEM_find_rev(arg1,DesRevSeq,&eerevseqtag);
                                                                 AOM_ask_value_string(eerevseqtag,"item_revision_id",&eeRevSeq);
																 printf("\n EE Revision --->[%s]\n", eeRevSeq); fflush(stdout);

																 if(GRM_find_relation_type(relation_type_name[ii],&reltyptag)!=ITK_OK)PrintErrorStack();
																 ITK_CALL(AOM_lock(reference_tags[ii]));
	 
																 if(GRM_create_relation(reference_tags[ii],eerevseqtag,reltyptag,NULLTAG,&eerelation_tag)!=ITK_OK)PrintErrorStack();
																 if(GRM_save_relation(eerelation_tag)!=ITK_OK)PrintErrorStack();


                                                                 GRM_find_relation_type(relation_type_name[ii],&des_rel_typ);
																 GRM_find_relation(reference_tags[ii],DesignRev_object,des_rel_typ,&des_rel_tag);
                                                                 ITK_CALL(GRM_delete_relation(des_rel_tag));											                                                          
											                     GRM_save_relation(des_rel_tag);


                                                                   
                                                                 
															}
															else
															{
                                                               //(tc_strcmp(type_name1,"VisStructureContext")==0) 
															 if((tc_strcmp(type_name1,"Snapshot")==0) || (tc_strcmp(type_name1,"Envelope")==0) ||(tc_strcmp(type_name1,"T5_APLTaskRevision")==0) ||(tc_strcmp(type_name1,"T5_ChangeTaskRevision")==0))
															 {
															   printf("\n i am in snapshot \n"); fflush(stdout);

															   ITEM_find_rev(arg1,DesRevSeq,&eerevseqtag);
															   AOM_ask_value_string(eerevseqtag,"item_revision_id",&eeRevSeq);
															   printf("\n EE Revision --->[%s]\n", eeRevSeq); fflush(stdout);
																 
															   ITK_CALL(AOM_lock(reference_tags[ii]));
															   if(FL_insert(reference_tags[ii],eerevseqtag,999)!=ITK_OK)PrintErrorStack();

															   if(ifail != ITK_ok)
																{
																	EMH_ask_error_text(ifail,&ErrorText);
																	printf("\n relation not created \n",ErrorText);fflush(stdout);
																}
																else
																{
																printf("\n  Relation OF EE part added in Snapshot\n");fflush(stdout);
																if(FL_remove(reference_tags[ii],DesignRev_object)!=ITK_OK)PrintErrorStack();

															   ITK_CALL(AOM_save_without_extensions(reference_tags[ii]));

															   ITK_CALL(AOM_refresh(reference_tags[ii],0));

															   ITK_CALL(AOM_unlock(reference_tags[ii]));

																}
																 
															   

			
																
															 }
														   }
																
                                                               
                                                        }
                                                        ITK_CALL(PS_where_used_all(DesignRev_object, 1, &n_parents, &levels, &parents));
                                                        //ITK_CALL(PS_where_used_configured(Design_object, tagRule, 1, &n_parents, &levels, &parents));
                                                        printf("\n Total n_parents --->[%d]\n", n_parents); fflush(stdout);
                                                        if(n_parents>0)
                                                        {
                                                                for(ii= 0;ii< n_parents;ii++)
                                                                {
                                                                        tag_t parent_tag = NULLTAG;
                                                                        tag_t relation_tag = NULLTAG;
                                                                        tag_t relation_type_tag = NULLTAG;
                                                                        parent_tag = parents[ii];
                                                                        AOM_ask_value_string(parent_tag,"item_id",&ParentNumber);
                                                                        AOM_ask_value_string(parent_tag,"item_revision_id",&ParentRev);
                                                                        AOM_ask_value_string(parent_tag,"t5_DesignGrp",&ParentDsgGrp);
                                                                        printf("\n ParentNumber --->[%s]-->ParentRev-->[%s]-->ParentDsgGrp-->[%s]\n", ParentNumber,ParentRev,ParentDsgGrp); fflush(stdout);
                                                                        // BOM Expansion...
                                                                        ITK_CALL(BOM_create_window(&tagBOMwindow1));
                                                                        ITK_CALL(BOM_set_window_pack_all(tagBOMwindow1, true));
                                                                        ITK_CALL(CFM_find("Latest Working", &tagRule1));
                                                                        ITK_CALL(BOM_set_window_config_rule( tagBOMwindow1,tagRule1));
                                                                        ITKCALL(BOM_save_window(tagBOMwindow1));
                                                                        ITKCALL(BOM_set_window_top_line(tagBOMwindow1, NULLTAG, parent_tag, NULLTAG, &tagParentBOMline));
                                                                        ITK_CALL(BOM_line_ask_child_lines(tagParentBOMline, &childCountTopBomLine, &childTagTopBomLine));
                                                                        printf("\n Total childCountTopBomLine --->[%d]\n", childCountTopBomLine); fflush(stdout);
                                                                 if(childCountTopBomLine>0)
                                                                {
                                                                                for(jj= 0;jj< childCountTopBomLine;jj++)
                                                                                {
                                                                                        tag_t child_tag = NULLTAG;
                                                                                        child_tag = childTagTopBomLine[jj];
																					 //   BOM_line_look_up_attribute("bl_item_item_id", &bl_item_id);
                                                                                      //  BOM_line_ask_attribute_string(child_tag,bl_item_id,&ChildPrtNumber);
                                                                                        //  AOM_ask_value_tag(child_tag,"bl_item_item_id",&ChildPrtNumber);
																						  AOM_ask_displayable_values(child_tag,"bl_item_item_id",&strct1,&ChildPrtNumber);


                                                                                        printf("\n ChildPrtNumber [%s]\n",ChildPrtNumber[0]); fflush(stdout);
                                                                                        if(tc_strcmp(ChildPrtNumber[0],PartNumber)==0)
                                                                                        {
                                                                                                printf("\n DELETE BOM RELATION\n"); fflush(stdout);
                                                                                               // BOM_line_look_up_attribute("bl_quantity", &bl_quantity);
                                                                                               // BOM_line_ask_attribute_string(child_tag,bl_quantity,&ChildQty);
                                                                                                //  AOM_ask_value_tag(child_tag,"bl_quantity",&ChildQty);
																								AOM_ask_displayable_values(child_tag,"bl_quantity",&strct2,&ChildQty);


                                                                                                printf("\n ChildQty [%s]\n",ChildQty[0]); fflush(stdout);
                                                                                                double d;
                                                                                                sscanf(ChildQty[0], "%lf", &d);
                                                                                                printf("ChildQty----->%lf", d);fflush(stdout);
                                                                                                //printf("ChildQty----->%f\n", atof(ChildQty));

                                                                                            //  BOM_line_look_up_attribute("bl_rev_item_revision_id", &bl_rev_item_revision_id);
                                                                                            //  BOM_line_ask_attribute_string(child_tag,bl_rev_item_revision_id,&ChildRev);
                                                                                            //    AOM_ask_value_tag(child_tag,"bl_rev_item_revision_id",&ChildRev);
                                                                                                AOM_ask_displayable_values(child_tag,"bl_rev_item_revision_id",&strct3,&ChildRev);

																								printf("\n ChildRev [%s]\n",ChildRev[0]); fflush(stdout);
                                                                                                Part_Revision = tc_strtok(ChildRev[0],";");
                                                                                                printf("\n Part_Revision [%s]\n",Part_Revision); fflush(stdout);

                                                                                            //  BOM_line_look_up_attribute("bl_plmxml_abs_xform", &bl_plmxml_abs_xform);
                                                                                            //  BOM_line_ask_attribute_string(child_tag,bl_plmxml_abs_xform,&AtMatrix);
                                                                                              //  AOM_ask_value_tag(child_tag,"bl_plmxml_abs_xform",&AtMatrix);
                                                                                                AOM_ask_displayable_values(child_tag,"bl_plmxml_abs_xform",&strct4,&AtMatrix);

																								printf("\n AtMatrix [%s]\n",AtMatrix[0]); fflush(stdout);

                                                                                             //   BOM_line_look_up_attribute("bl_plmxml_occ_xform", &bl_plmxml_occ_xform);
                                                                                            //    BOM_line_ask_attribute_string(child_tag,bl_plmxml_occ_xform,&RtMatrix);
                                                                                               // AOM_ask_value_tag(child_tag,"bl_plmxml_occ_xform",&RtMatrix);
                                                                                               AOM_ask_displayable_values(child_tag,"bl_plmxml_occ_xform",&strct5,&RtMatrix);

																								printf("\n RtMatrix [%s]\n",RtMatrix[0]); fflush(stdout);
                                                                                                printf("\n EEPno [%s]\n",EEPno); fflush(stdout);


                                                                                                values1[0] = EEPno;
                                                                                                values1[1] = "T5_EEPartRevision";
                                                                                                ITEM_find_item_revs_by_key_attributes(2,attrs1, values1,ChildRev[0],&EE_tags_found, &t_EERevObjs);
                                                                                                printf("\n EE_tags_found [%d]\n",EE_tags_found); fflush(stdout);
                                                                                                if(n_found3>0)
                                                                                                {
																							
																							
																							
																							
                                                                                                        tag_t EEPart_rev=NULLTAG;
                                                                                                        ITK_CALL(ITEM_ask_latest_rev(EE_objects[0],&EEPart_rev));
                                                                                                        int bvr_count = 0;
                                                                                                        tag_t *bvrs=NULLTAG;
                                                                                                        ITK_CALL(BOM_line_cut(child_tag));
                                                                                                        ITKCALL(ITEM_rev_list_bom_view_revs(parent_tag,&bvr_count, &bvrs));
                                                                                                        if (bvr_count>0)
                                                                                                        {
                                                                                                                tag_t bvr=NULLTAG;
                                                                                                                bvr = bvrs[0];
                                                                                                                MEM_free(bvrs);
                                                                                                                tag_t   *occs2          =       NULLTAG;
                                                                                                                ITKCALL(PS_create_occurrences(bvr, EEPart_rev, NULLTAG,1, &occs2 ));
                                                                                                                ITKCALL(PS_set_occurrence_qty(bvr,occs2[0],d));
                                                                                                                ITKCALL(AOM_save_without_extensions(bvr));
                                                                                                                ITKCALL(AOM_refresh(bvr,0));
                                                                                                                ITKCALL(AOM_unlock(bvr));
                                                                                                        }
                                                                                                }
                                                                                                break;
                                                                                        }
                                                                                }
                                                                                BOM_save_window (tagBOMwindow1);
                                                                                BOM_close_window(tagBOMwindow1);
                                                                        }
                                                                        /*
                                                                        ITK_CALL(GRM_find_relation_type("BOMView Revision",&relation_type_tag));
                                                                        if(relation_type_tag!=NULLTAG)
                                                                        {
                                                                                ITK_CALL(GRM_find_relation(parent_tag, DesignRev_object,relation_type_tag, &relation_tag));
                                                                                if(relation_tag!=NULLTAG)
                                                                                {
                                                                                        printf("\n DELETE RELATION\n"); fflush(stdout);
                                                                                        //ITK_CALL(GRM_delete_relation(relation_tag ));
                                                                                }
                                                                        }
                                                                        */

                                                                }
                                                        }
														
														
														if(n_found3>0)
                                                                                        {
																							
																							
																							
																							
                                                                                                        tag_t EEPart_rev=NULLTAG;
                                                                                                        ITK_CALL(ITEM_ask_latest_rev(EE_objects[0],&EEPart_rev));
																										
											                                                           GRM_find_relation_type("T5_ContHasSlave",&slave_relationType);
											                                                           GRM_list_primary_objects_only(DesignRev_object,slave_relationType,&mstrcnt,&mstrobj);
																									   GRM_find_relation_type("T5_EEPrm",&param_relationType);
											                                                           GRM_list_primary_objects_only(DesignRev_object,param_relationType,&paramcnt,&prmobj);
											                                                           printf("\n Master obj --->[%d]\n", mstrcnt); fflush(stdout);
											                                                              if(mstrcnt>0)
																										  {
																										  for(ii=0;ii<mstrcnt;ii++)
                                                                                                             {
											                                                             AOM_ask_value_string(mstrobj[0],"item_id",&PartNumber);
                                                                                                         printf("\n Master obj --->[%s]\n", PartNumber); fflush(stdout);
											                                                             GRM_find_relation(mstrobj[ii],DesignRev_object,slave_relationType,&Slave_relation_tag);
                                                                                                           ITK_CALL(GRM_delete_relation(Slave_relation_tag ));
											                                                              GRM_create_relation(mstrobj[ii],EEPart_rev,slave_relationType,NULLTAG,&Slave_relation_tag);
											                                                              GRM_save_relation(Slave_relation_tag);
                                                                                                             }
																										  }
																											 
																											 if(paramcnt>0)
																											  {
																											  for(ii=0;ii<paramcnt;ii++)
                                                                                                            {
																											  AOM_ask_value_string(prmobj[0],"item_id",&PartNumber);
                                                                                                              printf("\n Master obj --->[%s]\n", PartNumber); fflush(stdout);
																											  GRM_find_relation(prmobj[ii],DesignRev_object,param_relationType,&Param_relation_tag);
                                                                                                              ITK_CALL(GRM_delete_relation(Param_relation_tag ));
																											   GRM_create_relation(prmobj[ii],EEPart_rev,param_relationType,NULLTAG,&Param_relation_tag);
																											   GRM_save_relation(Param_relation_tag);
                                                                                                            }
																											  }
																						}
                                                        /*

                                                        if(query2!=NULLTAG)
                                                        {
                                                                qry_values2[0] = PartNumber;
                                                                ITK_CALL(QRY_execute(query2, n_entries2, qry_entries2, qry_values2, &n_found2, &Design_objects2));
                                                                printf("\n Total Parents Parts Found from BOM Line --->[%d]\n", n_found2); fflush(stdout);
                                                        }
                                                        ITK_CALL(WSOM_where_referenced(Design_object, 1, &n_references, &levels1,&reference_tags, &relation_type_name));
                                                        printf("\n Total n_references --->[%d]\n", n_references); fflush(stdout);
                                                        for (ii = 0; ii < n_references; ii++)
                                                        {
                                                              //  char  type_name1[WSO_name_size_c + 1] = "";
																char  type_name1 = NULL;
                                                                ITK_CALL(WSOM_ask_object_type2(reference_tags[ii], &type_name1));
                                                                printf("\n type_name1 --->[%s]\n", type_name1); fflush(stdout);
                                                                printf("\n relation_type_name[ii] --->[%s]\n", relation_type_name[ii]); fflush(stdout);
                                                                if (is_descendant_of_folder(reference_tags[ii]))
                                                                {
                                                                        tag_t folder = reference_tags[ii];
                                                                        ITK_CALL(AOM_refresh(folder, TRUE));
                                                                        ITK_CALL(FL_remove(folder, Design_object));
                                                                        ITK_CALL(AOM_save_without_extensions(folder));
                                                                        ITK_CALL(AOM_refresh(folder, FALSE));
                                                                        printf("\n FOLDER --->\n"); fflush(stdout);
                                                                }
                                                                else if((relation_type_name[ii] != NULL) && (strlen(relation_type_name[ii]) > 0) && tc_strcmp(relation_type_name[ii],"gk_occ_pseudo_reln")!=0)
                                                                {
                                                                        tag_t relation_type_tag = NULLTAG;
                                                                        ITK_CALL(GRM_find_relation_type(relation_type_name[ii],&relation_type_tag));

                                                                        // GRM_delete_relation requires the relation object which we don't have
                                                                        tag_t relation_tag = NULLTAG;

                                                                        // First try relation using the reference as a primary object
                                                                        tag_t primary_object = reference_tags[ii];
                                                                        tag_t second_object = Design_object;
                                                                        ITK_CALL(GRM_find_relation(primary_object, second_object,relation_type_tag, &relation_tag));

                                                                        // If no relation is found try the reference as a secondary object
                                                                        if (relation_tag == NULLTAG)
                                                                        {
                                                                                primary_object = Design_object;
                                                                                second_object = reference_tags[ii];
                                                                                ITK_CALL(GRM_find_relation(primary_object, second_object,relation_type_tag, &relation_tag));
                                                                        }
                                                                        //ITK_CALL(GRM_delete_relation(relation_tag ));
                                                                }
                                                        }
                                                        */
                                                //}
                                        }
                                }
                                //MEM_free(childLines);
                        }
                }
                MEM_free(Design_objects);
                MEM_free(DesignRev_objects);
  //      }// login

        return ITK_ok;
}
