	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
//#include <itk/mem.h>
#include <string.h>


#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
/*	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}*/
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ECUCount_Validation(char*,char*);


void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			* rev						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
	rev 			= ITK_ask_cli_argument("-rev=");

		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = ECUCount_Validation(dmlNo,rev);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int ECUCount_Validation(char* dmlNo,char* rev)
{
	int ifail = ITK_ok;
				//Akshay


	tag_t dataset_rel_type=NULLTAG;			
	int DsCnt=0;
	tag_t* datasetobj1=NULLTAG;
	tag_t Datasetobj3=NULLTAG;
	tag_t part=NULLTAG;
	tag_t objTag=NULLTAG;
	char* Dataset_name=NULL;
	int NR_count=0;
	tag_t* Named_ref=NULLTAG;
	int i=0;
	int k=0;
	int j=0;
	tag_t Named_ref_obj=NULLTAG;
	char* NR_Filename=NULL;
	

	char		*errordataset				= NULL;
char	**values[2];

	errordataset	=(char* )malloc( 500 * sizeof (char));

printf("\n dmlNo : %s \n",dmlNo);fflush(stdout);
printf("\n rev : %s \n",rev);fflush(stdout);
		//ITK_CALL(ITEM_find_item(dmlNo,&part));
		

//		ITK_CALL(ITEM_find_revision(part,rev,&objTag));
tag_t ItemQry     = NULLTAG;

int ConCount=0;
int Entry_count=2;
tag_t *objTags=NULL;


char *Entries[2] = {"Item ID","Revision"};
//char **Values = (char **) MEM_alloc(50 * sizeof(char *));



Values[0] = dmlNo;
Values[1] = rev;
char* objectname=NULL;
int iPCnt =0;


 ifail=QRY_find2("Item Revision...", &ItemQry);

	    
		if (ItemQry)
		{ 
	     QRY_execute(ItemQry, Entry_count, Entries, Values, &ConCount, &objTags);
		 
		        printf("\nContainer Object Found : %d", ConCount);fflush(stdout);
				
		}	


if (ConCount>0)
{
	for(iPCnt=0; iPCnt<ConCount; ++iPCnt)
	{
			
           objTag=objTags[iPCnt];
           ITK_CALL(AOM_ask_value_string(objTag,"object_name",&objectname));
		   printf("\n objectname  : %s", objectname);fflush(stdout);  		
			 ITK_CALL(GRM_find_relation_type("IMAN_specification", &dataset_rel_type));
          ITK_CALL(GRM_list_secondary_objects_only(objTag,dataset_rel_type,&DsCnt,&datasetobj1));
		  printf("\n sec Object Found : %d", DsCnt);fflush(stdout);
		if(DsCnt>0)
		{
		  for( i=0; i<1; i++)
          {
			 printf("\n checking dataset");fflush(stdout);
			 Datasetobj3=datasetobj1[i];
			 Dataset_name=(char *) MEM_alloc(100);
			 ITK_CALL(AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name));
		      
		     printf("\n dataset name : %s", Dataset_name);fflush(stdout);  		
	         printf("\nchecking for Named ref file");fflush(stdout);
		     ITK_CALL(AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref));
			   
	         printf("\n named ref found :%d=",NR_count);fflush(stdout); 
			 
		     if(NR_count>0)
		      { 

				 printf("\n checking named references\n======================\n");fflush(stdout);
				 j=0;
  		         while(j<NR_count)
                 { 
				     printf("\n+++++++++++++++++\nloop start:%d NR_count:%d\n",j);fflush(stdout);   
					 tag_t Named_ref_obj=NULLTAG;  
 				//	 char   NR_Filename[IMF_filename_size_c + 1]; 
					 AE_reference_type_t     reftype2; 
 					 char *file_type = NULL;
					 char* NR_Filename=NULL; 
 					 ITK_CALL(AE_find_dataset_named_ref2(Datasetobj3,j,&file_type,&reftype2,&Named_ref_obj));
					 ITK_CALL(IMF_ask_original_file_name2(Named_ref_obj,&NR_Filename)); 
					 printf("\n checking file:%s type:%s",NR_Filename,file_type);fflush(stdout);  
					 

					 int length = strlen(NR_Filename);
					 printf("\n file length : %d \n",length);fflush(stdout);
					  if(length > 100)
					  {

							printf("\n At. Inside dataset length validation : %s",NR_Filename);fflush(stdout);
						/*	EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"dataset length should be less than 100 character");
							return ITK_err;*/
						
					  }
					
				
					 if (strchr(NR_Filename,' ')) 
					 { 
						 printf("\n file name Contains space :%s", NR_Filename);fflush(stdout); 
						 printf("\n At. Inside dataset length validation : %s",NR_Filename);fflush(stdout);
					/*	EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"While creating file name (dataset) there should be no space in it");
						return ITK_err;*/
						 
						
 					 }
					 
					 printf("\n loop end +++++++++++++++++");fflush(stdout);   
				 }
			
        }


		}
	}
}

}





	return ifail;
}
