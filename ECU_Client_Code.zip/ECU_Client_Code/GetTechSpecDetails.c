#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//s#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

int status;

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);
int vcidcreation(tag_t,tag_t);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
//char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char *inputfile=NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
 
{
 
		int ifail;
	 
	//	int status;
	 
		int iStatus=0;

		(void)argc;
	 
		(void)argv;

		initialise();

		sUsr  = ITK_ask_cli_argument("-u=");
	 
		spass  = ITK_ask_cli_argument("-pf=");
	 
		sDB  = ITK_ask_cli_argument("-g=");
		inputfile = ITK_ask_cli_argument("-i=");
	 
		iStatus = ITK_auto_login();	 
		if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	 
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	 
		ITK_CALL(ITK_set_journalling( TRUE ));



	/////////////////


		logical lIsQtyModified = false;

		time_t temp;
	 
		struct tm *timeptr;
	 
		char pAccessDate[30];
	 
		char *sCurrentDate = NULL;
	 
		char *sCurrentDateDup = NULL;
	 
		char *strToBereplaceddate;
	 
		char *strToBeUsedInsteaddate;
		char	*vehid = NULL;
	 
		char	*sPrtRev = NULL;
		char	*FileName = NULL;

		FILE *fptr;

	 
		FileName =(char *) MEM_alloc(150);
	 
		sCurrentDate =(char *) MEM_alloc(30);
	 
		sCurrentDateDup =(char *) MEM_alloc(30);
	 
		strToBereplaceddate = (char*)malloc(5);
	 
		strToBeUsedInsteaddate = (char*)malloc(5);
		
		time(&temp);
	 
		timeptr = localtime(&temp );
	 
		tc_strcpy(pAccessDate,"");
	 
		strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
	 
		tc_strcpy(sCurrentDate,pAccessDate);
	 
		tc_strcpy(strToBereplaceddate,"/");
	 
		tc_strcpy(strToBeUsedInsteaddate,"-");

		ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);
	 
		//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
	 
		printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

		tc_strcpy(FileName,"TechspecDetails_");
	 
		tc_strcat(FileName,sCurrentDateDup);
	 
		tc_strcat(FileName,"_log.csv");

		printf("kk.log file name is : [%s]\n",FileName);

		fptr = fopen(FileName,"w");

		if(fptr==NULL)
	 
		{
	 
			printf("Error! in log File opening!!!");  fflush(stdout);
	 
			exit(1);
	 
		}



fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s","Input Vehicle Number","Revision Sequence","fuelType","majorModel","EngineModel","TransmissionType","Veh Not Found","Veh Not Release");fflush(fptr);







	 FILE* fp=NULL;
	 FILE* fperror=NULL;
	 char* vehnumber=NULL;
	  char* inputline=NULL;

			fp=fopen(inputfile,"r");
		fperror=fopen("error.log","a");
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(1000);
				while(fgets(inputline,1000,fp)!=NULL)
				{

					vehnumber=strtok(inputline,"^");  //1
					printf("\nInput veh is [%s]\n",vehnumber);
				



	//////////////


																int		i = 0;
															 
																int		n_Input = 1;
															 
																int		nPrtCnt = 0;
															 
																int		n_Cnt = 0;
															 
																int		iPCnt = 0;
															 
																int		bl_qty_form = 0;

																int     vcidcnt   = 0;

																int  crevcidcnt   = 0;
															 
																int        v=0;
																int    CheckFlag				 = 0;

																
															 
																char	*values[1];
															 
										
															 
																char	*qry_Input[1] = {"Item ID"};
															 
																tag_t	QryPrt = NULLTAG;
															 
																tag_t	vprt = NULLTAG;
															 
																tag_t	*tpPrtObjs = NULL;

																tag_t   rel_type3 = NULLTAG;

																tag_t vehlatestrevtag = NULLTAG;
															 
																tag_t*   vcidno   = NULLTAG;

																tag_t*   crevcidno   = NULLTAG;

															 
																tag_t   item_tag   = NULLTAG;
															//	tag_t   vcidtag   = NULLTAG;
															//	tag_t   vcidtestrevtag   = NULLTAG;
																
																	


															 
																char	*sPrtTyp = NULL;
															 
																char	*sCPartNum = NULL;
															 
																char	*sCPartRvSq = NULL;
															 
																char	*sCPartQty = NULL;
															 																
																char *vehrevid = NULL;
																char *projcode = NULL;
															 
																char *vcidname     = NULL;
															 
																char *VcidLatestRevseq   = NULL;
																int moduleallrevcount =0;
																int mi=0;
																tag_t *modul_rev_list = NULLTAG;
																
																

															 
																values[0] = "*K2A01*";

															 
																	printf("\nkk.veh Number is [%s]\n", vehnumber);fflush(stdout);

		
																	ITK_CALL(ITEM_find_item(vehnumber,&vprt));
																	if(vprt == NULLTAG)
																	{
																		printf("\nItem not found:%s\n",vehnumber);
																		fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s,%s",vehnumber,"","","","","",vehnumber,"");fflush(fptr);
																	}
																	else
					                                                {
															 
																	
															 
																			ITKCALL(AOM_ask_value_string(vprt,"item_id",&vehid));

																			///////////////////
																		ITK_CALL(ITEM_list_all_revs(vprt,&moduleallrevcount,&modul_rev_list));
																		printf("\n moduleallrevcount=%d \n",moduleallrevcount);fflush(stdout);
																		
																		if (moduleallrevcount>0)
																		{
																		
																		 for(mi=moduleallrevcount-1;mi>-1;mi--)
																		  {
																			  printf("\n inside for loop \n ");fflush(stdout);
																			  vehlatestrevtag=modul_rev_list[mi];






																			//////////////
															 
																		
															 
																		//   ITK_CALL(ITEM_ask_latest_rev(vprt,&vehlatestrevtag));
															 
																		   ITK_CALL(AOM_ask_value_string(vehlatestrevtag,"item_revision_id",&vehrevid));
																		   ITK_CALL(AOM_ask_value_string(vehlatestrevtag,"t5_ProjectCode",&projcode));
															 
																		   printf("\n modulenoname latest rev seq [%s/%s] \n ", vehid,vehrevid);fflush(stdout);
																		   printf("\n projcode [%s] \n ", projcode);fflush(stdout);

																	/*	   if ( tc_strstr( projcode,"5445") == 0 )

																		   {
																			  tc_strcpy(vehnumberpunch,"")
																		      vehnumberpunch=subString(vehnumber,0,8);																		   
																			   
																			   tc_strcat(vehnumberpunch,"000R")

																		   }*/


																		  int length = strlen(vehid);
															 
																		  printf("\n module length : %d \n",length);fflush(stdout);


																		  		char *modrevrelstus = NULL;
																			 ITK_CALL(AOM_UIF_ask_value(vehlatestrevtag,"release_status_list",&modrevrelstus));
																			 TC_write_syslog ( "\n veh Release_status : [%s]", modrevrelstus ) ;
																			 printf("\n  veh Release_status : [%s]", modrevrelstus );fflush(stdout);

																			 /////////////

																			 if ( tc_strstr( modrevrelstus,"ERC Released") != NULL )
																			  {
																			   printf("\n latest release found ----- [%s/%s]",vehid,vehrevid); fflush(stdout);																	


																			 /////////////

																					
																					  if (( tc_strstr( modrevrelstus,"ERC Released") == NULL ) && ( tc_strstr( vehrevid,"NR") != NULL ))
																					   {
																						
																						fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s,%s",vehnumber,vehrevid,"","","","","",vehnumber);fflush(fptr);
																						}
																					  else
																					  {

																						
																						if((tc_strstr(vehid,"R")!=NULL) || (tc_strstr(vehid,"L")!=NULL))
																		 
																						 {

																							ITKCALL(AOM_ask_value_string(vehlatestrevtag,"t5_PartType",&sPrtTyp));
																		 
																							 printf("\n module part type= [%s/%s =%s]\n",vehid,vehrevid,sPrtTyp);fflush(stdout);

																							 if((tc_strcmp(sPrtTyp,"V")==0) || (tc_strcmp(sPrtTyp,"VCCR")==0))

																							  {
																								  ////////////////////////
																								  tag_t	VCVehicalDesignMasterTag	= NULLTAG;
																								  tag_t Design_rev_cls_tag    = NULLTAG;
																								  int theAttributeCount =0;
																									int *theAttributeIds;
																									char **theAttributeNames = NULL;
																									int *theAttributeValCounts=0;
																									char***       theAttributeValues = NULL;
																									char***       theAttributeOptimizedUnits = NULL;
																									char* 	attrId 					= NULL;
																									attrId = (char *) MEM_alloc( 50 * sizeof(char) );
																									char 	*attributeNameDup 			= NULL;
																									char 	*attributeValueDup 			= NULL;
																									char 	*fueltype 			= NULL;
																									char 	*majormodel 			= NULL;
																									
																									attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
																									attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
																									fueltype = (char *) MEM_alloc( 5000 * sizeof(char) );
																									majormodel = (char *) MEM_alloc( 5000 * sizeof(char) );
																									int ic=0;
																									int xc=0;
																									int		t5NoEcuDupint  = 0;


																									char 	*EngineModel 			= NULL;
																									char 	*TranssmissionType 			= NULL;
																									EngineModel = (char *) MEM_alloc( 5000 * sizeof(char) );
																									TranssmissionType = (char *) MEM_alloc( 5000 * sizeof(char) );
																								  tc_strcpy(EngineModel,"");
																								  tc_strcpy(TranssmissionType,"");
																								  tc_strcpy(fueltype,"");
																								  tc_strcpy(majormodel,"");


																								ITEM_ask_item_of_rev(vehlatestrevtag,&VCVehicalDesignMasterTag);
																								(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
																								if(Design_rev_cls_tag)
																								{
																									ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
																									if(theAttributeCount>0)
																									{
																										for(ic=0;ic<theAttributeCount;ic++)
																										{
																											sprintf(attrId,"%d",theAttributeIds[ic]);

																											tc_strcpy(attributeNameDup,"");
																											tc_strcpy(attributeNameDup,theAttributeNames[ic]);

																											

																											if(tc_strcmp(attributeNameDup,"[VC]FUEL(FUEL)")==0)
																											{

																												
																												for(xc=0;xc<theAttributeValCounts[ic];xc++)
																												{
																													
																													tc_strcat(fueltype,theAttributeValues[ic][xc]);
																												
																												}

																												printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
																												printf("\n attrId:[%s]",attrId);fflush(stdout);
																												printf("\n FUEL value:[%s] ",fueltype);fflush(stdout);

																											

																											}
																											if(tc_strcmp(attributeNameDup,"[VC]MAJORMODEL")==0)
																											{   
																												for(xc=0;xc<theAttributeValCounts[ic];xc++)
																												{
																													
																													tc_strcat(majormodel,theAttributeValues[ic][xc]);
																													
																												}

																												printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
																												printf("\n attrId:[%s]",attrId);fflush(stdout);
																												printf("\n MAJORMODEL value:[%s] ",majormodel);fflush(stdout);

																											

																											}
																											

																										}
																										//fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s",vehnumber,vehrevid,fueltype,majormodel,"","","");fflush(fptr);
																									}
																								}
																								else
																								{
																									printf("\n Design_rev_cls_tag NOT Found...");fflush(stdout);
																								
																								}
																			 //////////////////////////////////////////

																									tag_t	bomline		=	NULLTAG;
																									tag_t	*child		=	NULLTAG;
																									tag_t	window		=	NULLTAG;
																									tag_t	t_revrule	=	NULLTAG;
																									tag_t	solitemtag	=	NULLTAG;


																									int		bcount		=	0;
																									int		ib			=	0;
																									char		*child_id		=	NULL;
																									char		*child_revid	=	NULL;
																									char		*child_level						= NULL;
																									char		*swparttype						= NULL;
																									char		*moduleAddress						= NULL;

																									 if(BOM_create_window(&window));
																									  {
																										if(CFM_find("ERC release and above", &t_revrule));
																										if(BOM_set_window_config_rule( window, t_revrule ));
																									//	if(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
																										if(BOM_set_window_pack_all(window, true));
																										if(BOM_set_window_top_line(window,NULLTAG,vehlatestrevtag,NULLTAG,&bomline));
																										 {
																											if(BOM_line_ask_all_child_lines(bomline,&bcount,&child));
																											 {
																												if(bcount > 0)
																												{
																													for(ib = 0 ; ib < bcount ; ib++)
																													{

																														if(AOM_ask_value_string(child[ib],"bl_item_item_id", &child_id));
																														if(AOM_ask_value_string(child[ib],"bl_rev_item_revision_id", &child_revid));
																														if(AOM_UIF_ask_value(child[ib],"bl_level_starting_0", &child_level));
																														if(AOM_UIF_ask_value(child[ib],"bl_T5_EE_PartRevision_t5_SwPartType", &swparttype));												
																														if(AOM_UIF_ask_value(child[ib],"bl_Design Revision_t5_ModuleAddress", &moduleAddress));												
																													

																														if((tc_strcmp(moduleAddress,"MP1A01")==0) || (tc_strcmp(moduleAddress,"MP3A01")==0) || (tc_strcmp(moduleAddress,"MP3B01")==0))
																														{
																															printf("\n Container Number:[%s]\n",child_id);fflush(stdout);
																																 ITK_CALL(ITEM_find_item(child_id,&solitemtag));
																																  if (solitemtag)
																																   {

																																	
																																	  tag_t module_cls_tag    = NULLTAG;
																																	  int theAttributeCountmodule =0;
																																		int *theAttributeIdsmodule;
																																		char **theAttributeNamesmodule = NULL;
																																		int *theAttributeValCountsModule=0;
																																		char***       theAttributeValuesModule = NULL;
																																		char***       theAttributeOptimizedUnitsMod = NULL;
																																		char* 	attrIdmod 					= NULL;
																																		attrIdmod = (char *) MEM_alloc( 50 * sizeof(char) );
																																		char 	*attributeNameDupMod 			= NULL;
																																		char 	*attributeValueDupMod 			= NULL;
																																		
																																		attributeNameDupMod = (char *) MEM_alloc( 5000 * sizeof(char) );
																																		attributeValueDupMod = (char *) MEM_alloc( 5000 * sizeof(char) );
																																		
																																		int icm=0;
																																		int xcm=0;
																															
																															


																																//	ITEM_ask_item_of_rev(vehlatestrevtag,&VCVehicalDesignMasterTag);
																																	(ICS_ask_classification_object(solitemtag,&module_cls_tag));
																																	if(module_cls_tag)
																																	{
																																		ITK_CALL( ICS_ico_ask_attributes_optimized(module_cls_tag,&theAttributeCountmodule,&theAttributeIdsmodule,&theAttributeNamesmodule,&theAttributeValCountsModule,&theAttributeValuesModule,&theAttributeOptimizedUnitsMod));
																																		if(theAttributeCountmodule>0)
																																		{
																																			for(icm=0;icm<theAttributeCountmodule;icm++)
																																			{
																																				sprintf(attrIdmod,"%d",theAttributeIdsmodule[icm]);

																																				tc_strcpy(attributeNameDupMod,"");
																																				tc_strcpy(attributeNameDupMod,theAttributeNamesmodule[icm]);

																																			 if(tc_strcmp(moduleAddress,"MP1A01")==0) 
																																				{
																																					if(tc_strcmp(attributeNameDupMod,"[VC]Engine Model")==0)
																																					{

																																						
																																						for(xcm=0;xcm<theAttributeValCountsModule[icm];xcm++)
																																						{
																																							
																																							tc_strcat(EngineModel,theAttributeValuesModule[icm][xcm]);
																																							
																																						}

																																						printf("\n theAttribute Name :[%s]",attributeNameDupMod,icm);fflush(stdout);
																																						printf("\n attrIdmod:[%s]",attrIdmod);fflush(stdout);
																																						printf("\n Engine Model Value:[%s] ",EngineModel);fflush(stdout);

																																					

																																					}
																																				}
																																				if((tc_strcmp(moduleAddress,"MP3A01")==0) || (tc_strcmp(moduleAddress,"MP3B01")==0))
																																				{
																																					if(tc_strcmp(attributeNameDupMod,"TRANSMISSION TYPE")==0)
																																					{
																																						
																																						for(xcm=0;xcm<theAttributeValCountsModule[icm];xcm++)
																																						{
																																							
																																							tc_strcat(TranssmissionType,theAttributeValuesModule[icm][xcm]);
																																							
																																						}

																																						printf("\n theAttribute Name :[%s]",attributeNameDupMod,icm);fflush(stdout);
																																						printf("\n attrIdmod:[%s]",attrIdmod);fflush(stdout);
																																						printf("\n TranssmissionType value:[%s] ",TranssmissionType);fflush(stdout);

																																					

																																					}
																																				}
																																				

																																			}
																																		//	fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s",vehnumber,vehrevid,EngineModel,TranssmissionType,"","","");fflush(fptr);
																																		}
																																	}
																																	else
																																	{
																																		printf("\n module_cls_tag NOT Found...");fflush(stdout);
																																	
																																	}

																																  }

																														}//P1A01
																													

																													}


																												}
																												else
																												{
																													printf("No child part is present for %s",vehid); fflush(stdout);
																												}
																											}
																										}
																										BOM_close_window(window);
																									}
																				 //////////////////////////

																							  fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s,%s",vehnumber,vehrevid,fueltype,majormodel,EngineModel,TranssmissionType,"","");fflush(fptr);

																							   }																				   
																		 
																						 }

																					  }//else veh no release
																		      break;
																			 }//if release
																		    }//for all rev
																		  }

																		    
				                                                        }
															 
																	
															 

															printf("\n===============================================================================================\n");
				}
		}

	ITK_exit_module(true);

	return status;
	 
	}

	static void initialise (void)
	 
	{
	 
		int ifail;

		/* <kc> pr#397778 July2595 exit if autologin() fail */
	 
		if ((ifail = ITK_auto_login()) != ITK_ok)
	 
		   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	 
		CHECK_FAIL;

		/* these tokens come from bom_attr.h */
	 
		initialise_attribute (bomAttr_lineName, &name_attribute);
	 
		initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	 

	 
		CHECK_FAIL;
	 
	}

	static void initialise_attribute (char *name,  int *attribute)
	 
	{
	 	int ifail, mode;
	 
		CHECK_FAIL;
	
	 
	}


	int vcidcreation(tag_t vprt,tag_t modulelatestrevtag)
	 
	{
	 
	  printf("\n INSIDE VCID Creation \n ");fflush(stdout);

	  char *modulenoname = NULL;
	 
	  char *parttype     = NULL;
	 
	  char *firsttep     = NULL;
	 
	  char *ObjCCidName  = NULL;
	 
	  char *Secondtep  = NULL;
	 
	  //tag_t modulelatestrevtag = NULLTAG;
	 
	  char *vehlatestrevtag  = NULL;
	  char *modulelDRstatus  = NULL;

	  tag_t itemtag = NULLTAG;

	  tag_t itemrevtag = NULLTAG;

	  int    CheckFlag				 = 0;
	 
	  ITK_CALL(AOM_ask_value_string(vprt,"item_id",&modulenoname));
	 
	  

	  //  ITK_CALL(ITEM_ask_latest_rev(vprt,&modulelatestrevtag));
	 
	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"item_revision_id",&vehlatestrevtag));
	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"t5_PartStatus",&modulelDRstatus));

	  printf("\n Vcid Creation on latest revision [%s/%s] \n ",modulenoname,vehlatestrevtag);fflush(stdout);
	 


	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"t5_PartType",&parttype));
	 
	  printf("\n part type %s \n ", parttype);fflush(stdout);

	  // int len = strlen(modulenoname);
	 
	   //printf("\n modulenoname number length : %d \n",len);fflush(stdout);
	 
	 
	  printf("\n 16 found in modulenoname %s \n ", modulenoname);fflush(stdout);

	 
	 
	 /*  firsttep=subString(modulenoname, 0, 9);

	   printf("\n  firsttep  %s \n ", firsttep);fflush(stdout);

	   Secondtep=subString(modulenoname, 11, 14);

	   printf("\n Secondtep   %s \n ", Secondtep);fflush(stdout);*/



	   ObjCCidName = (char *) MEM_alloc(5000 * sizeof(char *));

	   tc_strcat(ObjCCidName,modulenoname);

	 //  tc_strcat(ObjCCidName,Secondtep);

	   tc_strcat(ObjCCidName,"_R1");

	   printf("\n Main CCID NUMBER for Module------>  %s \n ", ObjCCidName);fflush(stdout);

	  ITK_CALL(ITEM_find_item(ObjCCidName,&itemtag));

		if(itemtag)
		{

		printf("\n VCID Object already available------>  %s \n ", ObjCCidName);fflush(stdout);

		}
		 
		else
		{	 
		  CheckFlag				 = 1;
	//    ITK_CALL(ITEM_ask_latest_rev(itemtag,&itemrevtag));

		   tag_t object1                = NULLTAG;

		   tag_t item_type_tag1         = NULLTAG;

		   tag_t item_create_input_tag1  = NULLTAG;

		   tag_t VcidLatestRev           = NULLTAG;

		   tag_t vcidrel               = NULLTAG;

		   tag_t vcidreltyp              = NULLTAG;

		   char *ObjCCidrev           =NULL;

			ITK_CALL(TCTYPE_find_type("T5_CCID", "Item", &item_type_tag1));         

			ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));

			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",ObjCCidName));

			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",ObjCCidName));

			ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));

			ITK_CALL(AOM_save_without_extensions(object1));

			ITK_CALL(AOM_refresh(object1,0));

			if(object1)

				{

					ITK_CALL(AOM_unlock(object1));

					printf("\n vcid Object is created.\n"); fflush(stdout);

					ITK_CALL(ITEM_ask_latest_rev(object1,&VcidLatestRev));

					ITK_CALL(AOM_set_value_string(VcidLatestRev,"item_revision_id","A;1"));
				//	ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDApplicability","BothES"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDApplicability","Service"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDDRStatus",modulelDRstatus));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"object_desc","Initial Revision"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"object_name","Initial Revision"));


					ITK_CALL(AOM_save_without_extensions(VcidLatestRev));

					ITK_CALL(AOM_refresh(VcidLatestRev,0));

				

					

					  printf("\n vcid relation creation with module.....\n"); fflush(stdout);

					  ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&vcidreltyp));

					  printf("\n module relation creation \n"); fflush(stdout);

					  ITK_CALL(GRM_create_relation(modulelatestrevtag,VcidLatestRev,vcidreltyp,NULLTAG,&vcidrel));				

					  ITK_CALL(AOM_unlock(vcidrel));

					  GRM_save_relation(vcidrel);

					  ITK_CALL(AOM_lock(vcidrel));

					  printf("\n RELATIONSHIP CREATED  \n");fflush(stdout);

					//  fprintf(fptr,"\n%s,%s/%s,%s/%s,%s/%s",vehid,vehicleno,vehrevseq,modulenoname,vehrevid,ObjCCidName,ObjCCidrev);fflush(fptr);

					

				}

				else

				{

					printf("\n vcid Object is not created.\n"); fflush(stdout);

				}
	 
		}

return CheckFlag;
 
}