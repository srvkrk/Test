
#include <stdio.h>
//#include <tc/tc.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
//#include <itk/mem.h>
#include <string.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int read_value_from_file(char*);
int Get_Qry_Execute(char*, char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Part_no					= NULL;
	//char			* filename1					= NULL;
    char *Folder_name=NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Part_no		    = ITK_ask_cli_argument("-i=");
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = read_value_from_file(Part_no);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_value_from_file(char* Part_no)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
    
	
	char *Part_RevSeq	= NULL;
	char* Rem_part=NULL;
	
	int row=0;
	
	char 			temp[500];

//Part_no=(char *) MEM_alloc(100);
Part_RevSeq=(char *) MEM_alloc(100);
char* Filename_1=NULL;
Filename_1=(char *) MEM_alloc(100);
tc_strcpy(Filename_1,"");
tc_strcpy(Filename_1,Part_no);
tc_strcat(Filename_1,"_Rlz.txt");

printf("\nFilename1: %s", Filename_1);
	
	FILE* fp = NULL;
	fp = fopen(Filename_1, "r");
	
	if (fp != NULL)
	{

		while (fgets(temp, 500, fp)!= NULL)
		{
	
	       row ++;
			if(row==1)
			continue;
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				
                Part_no =strtok(temp,"^");
				printf("\nPart_no:%s",Part_no);

				Part_RevSeq = strtok(NULL,"^");
				printf("\nPart_RevSeq:%s",Part_RevSeq);
				
				Rem_part = strtok(NULL,",");
				printf("\nRemaining_part:%s",Rem_part);
				
				ifail = Get_Qry_Execute(Part_no,Part_RevSeq);
              
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	

	      
			 fclose(fp);
	return ifail;
}

int Get_Qry_Execute(char* Part_no,char* Part_RevSeq)
{
int ifail           = ITK_ok;
tag_t ItemQry     = NULLTAG;
tag_t* ContainerTag   = NULLTAG;
tag_t* PartTag   = NULLTAG;
tag_t* PartTag1   = NULLTAG;
tag_t dataset_rel_type2=NULLTAG;
tag_t datasettype=NULLTAG;
tag_t* datasetobj2=NULLTAG;
tag_t Datasetobj4=NULLTAG;
tag_t DVPrelation=NULLTAG;
tag_t revtag=NULLTAG;
tag_t* Named_ref=NULLTAG;
tag_t Named_ref_obj=NULLTAG;
char* class =NULL;
char* NR_Filename=NULL;
char* Dataset_name=NULL;
int ConCount=0;
int Entry_count=2;
int iii=0;
int j=0;
int PartCount=0;
int PartCount1=0;
int DsCnt=0;
int DsCnt1=0;
int DsCnt3=0;
char* errormsg=NULL;
char * Part_no1=NULL;
Part_no1=(char *) MEM_alloc(300);
	
tag_t dataset_rel_type=NULLTAG;
tag_t Relation_type_tag=NULLTAG;
tag_t* datasetobj1=NULLTAG;
tag_t* datasetobj3=NULLTAG;
tag_t Relation=NULLTAG;
tag_t Datasetobj3=NULLTAG;
tag_t Datasetobj5=NULLTAG;
char* Dataset_RevSeq=NULL;
char* Relation_type=NULL;
tag_t relation_new=NULLTAG;
tag_t relation_new1=NULLTAG;
tag_t relation_new2=NULLTAG;
tag_t spec_rel_type =NULLTAG;
tag_t rend_rel_type =NULLTAG;
tag_t struct_rel_type =NULLTAG;
char* refname=NULL;
char* reftype=NULL;
char *Exfile=NULL;

tag_t class_id=NULLTAG;
char* class_name=NULL;

char *Entries[2] = {"Item ID","Revision"};
char **Values = (char **) MEM_alloc(50 * sizeof(char *));
char **Values1 = (char **) MEM_alloc(50 * sizeof(char *));

char               *tempRev_ID	          =NULL;
ITK_CALL(STRNG_replace_str(Part_RevSeq,";","*",&tempRev_ID));
Values[0] = Part_no;
//Values[1] = Part_RevSeq;
Values[1] = tempRev_ID;


tc_strcpy(Part_no1,Part_no);
 tc_strcat(Part_no1,"_16");
Values1[0] = Part_no1;
//Values1[1] = Part_RevSeq;
Values1[1] = tempRev_ID;
               // printf("\nvalue_0:%s",Values[0]);
                //printf("\nvalue_1:%s",Values[1]);

        ifail=QRY_find2("Item Revision...", &ItemQry);

	    
		if (ItemQry)
		{ 
	     QRY_execute(ItemQry, Entry_count, Entries, Values, &PartCount, &PartTag);
		 QRY_execute(ItemQry, Entry_count, Entries, Values1, &PartCount1, &PartTag1);
		        printf("\nContainer Object Found : %d", PartCount);fflush(stdout);
				
				ITK_CALL(GRM_find_relation_type("IMAN_specification",&spec_rel_type));
				ITK_CALL(GRM_list_secondary_objects_only(PartTag1[0],spec_rel_type,&DsCnt,&datasetobj1));
				   
				 
		  printf("\nDsCnt=%d\n",DsCnt);
		if(DsCnt>0)
		{
		  for( iii=0; iii<DsCnt; iii++)
            {
				
				Datasetobj3=datasetobj1[iii];
				ITK_CALL(POM_class_of_instance(Datasetobj3,&class_id));
                      printf("\t   "); fflush(stdout);
                  ITK_CALL(POM_name_of_class(class_id,&class_name));
                 printf("\t   class_name is :%s\n\t   ",class_name);fflush(stdout);
				if(tc_strcmp(class_name,"Dataset")==0)
				{
			
			
			ITK_CALL(GRM_create_relation(PartTag[0],Datasetobj3,spec_rel_type,NULLTAG,&relation_new));
			ITK_CALL(GRM_save_relation(relation_new));
			
	                
							 
				} 
		                   
		            	
		              
		               
		            
						
			}
			
        }
		
		  ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&rend_rel_type));
				   ITK_CALL(GRM_list_secondary_objects_only(PartTag1[0],rend_rel_type,&DsCnt1,&datasetobj2));
		  printf("\nDsCnt1=%d\n",DsCnt1);
		if(DsCnt1>0)
		{
		  for( j=0; j<DsCnt1; j++)
            {
				
				Datasetobj4=datasetobj2[j];
				ITK_CALL(POM_class_of_instance(Datasetobj4,&class_id));
                      printf("\t   "); fflush(stdout);
                  ITK_CALL(POM_name_of_class(class_id,&class_name));
                 printf("\t   class_name is :%s\n\t   ",class_name);fflush(stdout);
				if(tc_strcmp(class_name,"Dataset")==0)
				{
				ITK_CALL(GRM_create_relation(PartTag[0],Datasetobj4,rend_rel_type,NULLTAG,&relation_new1));
			    ITK_CALL(GRM_save_relation(relation_new1));
				} 
		   
		
				
				
				
		    }  
	    }
			
		
		
		}

  

return ifail;
}

