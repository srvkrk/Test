/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{


	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;
		
	char		   *firsttok      =NULL;
	 char		   *secondtok	  =NULL;
	 char		   *thirdtok	  =NULL;
	 char		   *forthtok	  =NULL;
	
	tag_t    Cciditemrev   = NULLTAG;
	
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;
	char*  SnapshotId		= NULL; 

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t	 HasRefCCIDRelTypen		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t  *SnapTag		      = NULLTAG;
	tag_t	ProQrySSObj			= NULLTAG;
	tag_t	*snapObj		  = NULLTAG;
	tag_t*	 snapchild				= NULLTAG;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	
	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;
	int     sn		       = 0;

	char* username				= NULL;
	char* parent_name			= NULL;
	char* dmlTaskNo			= NULL;
	char* AddPartnumber       = NULL;
	char* PartItemIdSn       =NULL;
	 char* PartItemRevIdSn   =NULL;

	char*	 OldSnapshotNo				 = NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;
	int		attccidcnt     = 0;
	int SnapCnt =0;
	int		icnt     = 0;
	int		iy     = 0;
	char*	 CCIDNo= NULL;
	char*	 CCIDNoRev= NULL;
	char   *PartRevID =NULL;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int SnpshotSeq = 0;
	int UpdatedSeq =0;
	char	NewSnapshotSeq[20];
	char	*qry_Input1[1]	  = {"Name"};
 	char	*values1[1];
	char*	 Cciditem_rev			 = NULL;
	int		n_Input1					 = 1;
	int		SnapshotCount     = 0;
	int		in     = 0;
	int		zr     = 0;
	int		partaddcnt	= 0;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t *ccidTagrf=NULLTAG;

	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;
	char* ErrorText =NULL;
	logical lispartfound;
   char	*snpashotobjtype			 = NULL;
   char	*snpashotobjtname			 = NULL;
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;	

	if(count>0)
	{
		printf("\n Inside for --PartReplace_DML DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
		DMLTaskTag = rev_list[0];
		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout); 
		if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();
		if (MdmDML_tag != NULLTAG)
		{
			printf("\n DML tag is not null for PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);
			if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

			if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
			printf("\n for PartReplace_DML DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
			printf("\n PartReplace_DML DML number for :%s \n",dmlNo);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
			ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

			printf("\n Finding the PartReplace_DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);
			if (Mdmtsk_cnt>0)
			{
				printf("\n Inside task count for PartReplace_DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);
				 for (in=0;in<Mdmtsk_cnt ;in++ )
				 {
						 printf("\n Now inside the task find as Task count is for PartReplace_DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
						 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[in],"object_type",&Taskobj_type));
						 printf("\n Now PartReplace_DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);
						 
						 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[in],"item_id",&TskNmMdm));
						 printf("\n Now PartReplace_DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

						 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Part_tobeAdd));

						// ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));//commented
						 ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[in], Part_tobeAdd, &partaddcnt, &addPartsTag));
						 printf("\n  No of part attached to task in  PartReplace_DML -: %d \n",partaddcnt);fflush(stdout);
						 if (partaddcnt>0)
						 {
							  printf("\n Inside part found in PartReplace_DML attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);
							  for (zr=0;zr<partaddcnt;zr++)
							  {
									CcidADDTag=addPartsTag[zr];
									AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
									if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
									printf("\n PartReplace_DML CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

									if(AOM_ask_value_string(CcidADDTag,"item_revision_id",&PartRevID)!=ITK_ok);//JULY 28
									printf("\n PartReplace_DML  Revision of part -------> %s \n", PartRevID);fflush(stdout);//JULY 28

									ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &part_tsk_relc));
									printf("\n PartReplace_DML -Expanding T5_HasNewCCID  expanded \n"); fflush(stdout);
									if (part_tsk_relc!=NULLTAG)
									{
										 printf("\n for PartReplace_DML Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);
										 ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag, part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
										 printf("\n for PartReplace_DML Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);
										 if (partcntrf>0)
										 {
											 for (pr=0;pr<partcntrf;pr++)
											 {
												 printf("\n Inside Dataset found for PartReplace_DML \n"); fflush(stdout);
												 DesignrevTagR=PartsTagrf[pr];

												 if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
												 printf("\n PartReplace_DML -In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

											     if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
												 printf("\n PartReplace_DML-  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

												 ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide 
												 printf("\n PartReplace_DML after finding HasSnapshotType \n");fflush(stdout);

												 ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
												 printf("\n PartReplace_DML -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
												
												 if(CCID >0 )
												 {
													 ITK_CALL(AOM_ask_value_string(ccidTagrf[0],"object_type",&snpashotobjtype));
													 ITK_CALL(AOM_ask_value_string(ccidTagrf[0],"object_name",&snpashotobjtname));
													  printf("\n PartReplace_DML After snpashotobjtype :%s \n",snpashotobjtype);fflush(stdout);
													  printf("\n PartReplace_DML After snpashotobjtname :%s \n",snpashotobjtname);fflush(stdout);

													 
													 //   AOM_refresh(ccidTagrf[0],0);
													    ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
													//	ITK_CALL(FL_ask_references(ccidTagrf[0],FL_fsc_by_date_modified ,&snapcount,&snapchild));
														 printf("\n  PartReplace_DML -snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

														 printf("\n PartReplace_DML- CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

														 if(snapcount >0)
														 {
															lispartfound=false;
															 
																 for (sn=0;sn<snapcount;sn++)
																 {
																	     
																		 SnChild=snapchild[sn];

																		if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
																		printf("\n PartReplace_DML -Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout); 

																		if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
																		printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28
																		
																		printf("\n Part number attached to task -> %s \n", AddPartnumber);fflush(stdout);//JULY 28

																		if(tc_strcmp(AddPartnumber,PartItemIdSn)==0)
																		{
																			printf("\n ######  As name is same  in PartReplace_DML------->  \n");fflush(stdout);
																			printf("\n  snapshot part number revision id - %s ------->  \n",PartItemRevIdSn );fflush(stdout);
																			printf("\n  task  part number revision id- %s ------->  \n",PartRevID );fflush(stdout);

																			if(tc_strcmp(PartItemRevIdSn,PartRevID)!=0)
																			{
																				printf("\n Revision is not same snapshot part rev id -%s and task part id -%s  \n",PartItemRevIdSn , PartRevID );fflush(stdout);
																				lispartfound=true;
																				ITK_CALL(AOM_lock(ccidTagrf[0]));
																				ITK_CALL(FL_remove(ccidTagrf[0],SnChild));
																				printf("\n PartReplace_DML- after fl remove AA \n");fflush(stdout);
															
																				ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
																			
																				ITK_CALL(AOM_refresh(ccidTagrf[0],0));
				
																				ITK_CALL(AOM_unlock(ccidTagrf[0]));
				
																				printf("\n  PartReplace_DML Relation OF part-%s deleted in Snapshot\n",PartItemIdSn);fflush(stdout);


																			/*	ITK_CALL(AOM_lock(ccidTagrf[0]));
																	
																			
																				ifail = FL_insert(ccidTagrf[0],CcidADDTag,999);
																				if(ifail != ITK_ok)
																				{
																					EMH_ask_error_text(ifail,&ErrorText);
																					printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
																				}

																				printf("\n PartReplace_DML  Part addition code-%s having sequence - %s \n",AddPartnumber,PartRevID );fflush(stdout);
															
																				ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
																			
																				ITK_CALL(AOM_refresh(ccidTagrf[0],0));

																				ITK_CALL(AOM_unlock(ccidTagrf[0]));

																				printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);*/

																			}
																		/*	else
																			{
																			
																			lispartfound=true;
																			break;
																			
																			
																			}*/


																			//(tc_strcmp(PartItemRevIdSn,PartRevID)!=0)

																		}// (tc_strcmp(AddPartnumber,PartItemIdSn)==0) ends 

																 }
																 
																 if(lispartfound==true)
																 {

																	 ITK_CALL(AOM_lock(ccidTagrf[0]));
																	
																			
																	ifail = FL_insert(ccidTagrf[0],CcidADDTag,999);
																	if(ifail != ITK_ok)
																	{
																		EMH_ask_error_text(ifail,&ErrorText);
																		printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);
																	}

																	printf("\n PartReplace_DML  Part addition code-%s having sequence - %s \n",AddPartnumber,PartRevID );fflush(stdout);
												
																	ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));
																
																	ITK_CALL(AOM_refresh(ccidTagrf[0],0));

																	ITK_CALL(AOM_unlock(ccidTagrf[0]));

																	printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);

																 }
																 
																 
																 
																 // for loop for snapcount ends

															 }// snapcount ends 
												 } // if CCID is not having snapshot ::
											

											 }// for for partcntrf ends

										 }// if partcntrf ends 

									}// if for part_tsk_relc ends

							  }// for loop for partaddcnt ends

						 }// if for partaddcnt

				 }// for loop for Mdmtsk_cnt ends

			}// if for Mdmtsk_cnt ends

		}// if ends for MdmDML_tag

	}// if ends for count 

	return ifail;
}
