#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//s#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

int status;

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);
int vcidcreation(tag_t,tag_t);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
//char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char *inputfile=NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
 
{
 
		int ifail;
	 
	//	int status;
	 
		int iStatus=0;

		(void)argc;
	 
		(void)argv;

		initialise();

		sUsr  = ITK_ask_cli_argument("-u=");
	 
		spass  = ITK_ask_cli_argument("-pf=");
	 
		sDB  = ITK_ask_cli_argument("-g=");
		inputfile = ITK_ask_cli_argument("-i=");
	 
	//	sOpt  = ITK_ask_cli_argument("-i=");
	 
		//sRevSeq = ITK_ask_cli_argument("-r=");
	 
		//sAttrName = ITK_ask_cli_argument("-n=");
	 
		//sAttrVal = ITK_ask_cli_argument("-v=");

		iStatus = ITK_auto_login();

		//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	 
		if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	 
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	 
		ITK_CALL(ITK_set_journalling( TRUE ));

	//	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);



	/////////////////


		logical lIsQtyModified = false;

		time_t temp;
	 
		struct tm *timeptr;
	 
		char pAccessDate[30];
	 
		char *sCurrentDate = NULL;
	 
		char *sCurrentDateDup = NULL;
	 
		char *strToBereplaceddate;
	 
		char *strToBeUsedInsteaddate;
		char	*sPrtVal = NULL;
	 
		char	*sPrtRev = NULL;
		char	*FileName = NULL;

		FILE *fptr;

	 
		FileName =(char *) MEM_alloc(150);
	 
		sCurrentDate =(char *) MEM_alloc(30);
	 
		sCurrentDateDup =(char *) MEM_alloc(30);
	 
		strToBereplaceddate = (char*)malloc(5);
	 
		strToBeUsedInsteaddate = (char*)malloc(5);
		
		time(&temp);
	 
		timeptr = localtime(&temp );
	 
		tc_strcpy(pAccessDate,"");
	 
		strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
	 
		tc_strcpy(sCurrentDate,pAccessDate);
	 
		tc_strcpy(strToBereplaceddate,"/");
	 
		tc_strcpy(strToBeUsedInsteaddate,"-");

		ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);
	 
		//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
	 
		printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

		tc_strcpy(FileName,"TPLVCID_");
	 
		tc_strcat(FileName,sCurrentDateDup);
	 
		tc_strcat(FileName,"_log.csv");

		printf("kk.log file name is : [%s]\n",FileName);

		fptr = fopen(FileName,"w");

		if(fptr==NULL)
	 
		{
	 
			printf("Error! in log File opening!!!");  fflush(stdout);
	 
			exit(1);
	 
		}



fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s","Input TPL Number","Revision Sequence","Available VCID","VCID Created","VCID creation pending","VCID Available on previous Revision","TPL Not Found");fflush(fptr);







	 FILE* fp=NULL;
	 FILE* fperror=NULL;
	 char* tplnumber=NULL;
	  char* inputline=NULL;

			fp=fopen(inputfile,"r");
		fperror=fopen("error.log","a");
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(1000);
				while(fgets(inputline,1000,fp)!=NULL)
				{

					tplnumber=strtok(inputline,"^");  //1
					printf("\nInput Tpl is [%s]\n",tplnumber);
				



	//////////////

															//	char	*sFrmRpl;
															 
														//		char	*sToRpl;
													         //	FileName =(char *) MEM_alloc(150);

																int		i = 0;
															 
																int		n_Input = 1;
															 
																int		nPrtCnt = 0;
															 
																int		n_Cnt = 0;
															 
																int		iPCnt = 0;
															 
																int		bl_qty_form = 0;

																int     vcidcnt   = 0;

																int  crevcidcnt   = 0;
															 
																int        v=0;
																int    CheckFlag				 = 0;

																//char	*values[3];
															 
																char	*values[1];
															 
																//char	*qry_Input[3] = {"Item ID", "Type", "Revision"};
															 
																char	*qry_Input[1] = {"Item ID"};
															 
																tag_t	QryPrt = NULLTAG;
															 
																tag_t	tPrt = NULLTAG;
															 
																tag_t	*tpPrtObjs = NULL;

																tag_t   rel_type3 = NULLTAG;

																tag_t modulelatestrev = NULLTAG;
															 
																tag_t*   vcidno   = NULLTAG;

																tag_t*   crevcidno   = NULLTAG;

															 
																tag_t   item_tag   = NULLTAG;
															//	tag_t   vcidtag   = NULLTAG;
															//	tag_t   vcidtestrevtag   = NULLTAG;
																
																	


															 
																char	*sPrtTyp = NULL;
															 
																char	*sCPartNum = NULL;
															 
																char	*sCPartRvSq = NULL;
															 
																char	*sCPartQty = NULL;
															 																
																char *modulerevseq = NULL;
															 
																char *vcidname     = NULL;
															 
																char *VcidLatestRevseq   = NULL;
																
															//	char *VcidLatestRev   = NULL;



													/*			logical lIsQtyModified = false;

																time_t temp;
															 
																struct tm *timeptr;
															 
																char pAccessDate[30];
															 
																char *sCurrentDate = NULL;
															 
																char *sCurrentDateDup = NULL;
															 
																char *strToBereplaceddate;
															 
																char *strToBeUsedInsteaddate;

																FILE *fptr;

																sFrmRpl = (char*)malloc(5);
															 
																sToRpl = (char*)malloc(5);
															 
																FileName =(char *) MEM_alloc(150);
															 
																sCurrentDate =(char *) MEM_alloc(30);
															 
																sCurrentDateDup =(char *) MEM_alloc(30);
															 
																strToBereplaceddate = (char*)malloc(5);
															 
																strToBeUsedInsteaddate = (char*)malloc(5);*/
																


																printf("\nkk.Querying all ECU Modules\n"); fflush(stdout);

																//values[0] = sPart;
															 
																//values[1] = "EE Part Revision";
															 
																//values[2] = sRevSeq;
															 
																values[0] = "*K2A01*";

														/*		time(&temp);
															 
																timeptr = localtime(&temp );
															 
																tc_strcpy(pAccessDate,"");
															 
																strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
															 
																tc_strcpy(sCurrentDate,pAccessDate);
															 
																tc_strcpy(strToBereplaceddate,"/");
															 
																tc_strcpy(strToBeUsedInsteaddate,"-");

																ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);
															 
																//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
															 
																printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

																tc_strcpy(FileName,"ECUVcidUpdate_");
															 
																tc_strcat(FileName,sCurrentDateDup);
															 
																tc_strcat(FileName,"_log.csv");

																printf("kk.log file name is : [%s]\n",FileName);

																fptr = fopen(FileName,"w");

																if(fptr==NULL)
															 
																{
															 
																	printf("Error! in log File opening!!!");  fflush(stdout);
															 
																	exit(1);
															 
																}*/
															 
															//	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
															 
															//	fprintf(fptr,"%s,%s,%s,%s,%s,%s","Module Number","Revision Sequence","Available VCID","VCID Created","VCID creation pending","VCID Available on previous Revision");fflush(fptr);

															//	if(QRY_find2("Item...", &QryPrt));
															 
															//	if(QryPrt)
															 
															//	{
															 
															//		if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObjs));
															 
																	printf("\nkk.TPL Number is [%s]\n", tplnumber);fflush(stdout);

																//	if(nPrtCnt>0)
															 
																//	{	
															 
																	//	for(iPCnt=0; iPCnt<nPrtCnt; ++iPCnt)
															 
																	//	{
															 
																	//		lIsQtyModified = false;
																	ITK_CALL(ITEM_find_item(tplnumber,&tPrt));
																	if(tPrt == NULLTAG)
																	{
																		printf("\nItem not found:%s\n",tplnumber);
																		fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s",tplnumber,"","","","","",tplnumber);fflush(fptr);
																	}
																	else
					                                                {
															 
																	//		tPrt = tpPrtObjs[iPCnt];
															 
																			ITKCALL(AOM_ask_value_string(tPrt,"item_id",&sPrtVal));
															 
																		//	ITKCALL(AOM_ask_value_string(tPrt,"item_revision_id",&sPrtRev));
															 
																	   //     printf("\n modulenoname current rev seq [%s/%s] \n ", sPrtVal,sPrtRev);fflush(stdout);

															 
																		//	ITK_CALL(ITEM_find_item(sPrtVal,&item_tag));
															 
																		   ITK_CALL(ITEM_ask_latest_rev(tPrt,&modulelatestrev));
															 
																		   ITK_CALL(AOM_ask_value_string(modulelatestrev,"item_revision_id",&modulerevseq));
															 
																		   printf("\n modulenoname latest rev seq [%s/%s] \n ", sPrtVal,modulerevseq);fflush(stdout);


																		  int length = strlen(sPrtVal);
															 
																		  printf("\n module length : %d \n",length);fflush(stdout);

																			// if((tc_strstr(sPrtVal,"16R")!=NULL) && (length == 11))
																			if((tc_strstr(sPrtVal,"16R")!=NULL) || (tc_strstr(sPrtVal,"16L")!=NULL))
															 
																			 {

																				ITKCALL(AOM_ask_value_string(modulelatestrev,"t5_PartType",&sPrtTyp));
															 
																				 printf("\n module part type= [%s/%s =%s]\n",sPrtVal,modulerevseq,sPrtTyp);fflush(stdout);

																				 if(tc_strcmp(sPrtTyp,"T")==0)

																				  {

																					  ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&rel_type3));

																					  ITK_CALL(GRM_list_secondary_objects_only(modulelatestrev,rel_type3,&vcidcnt,&vcidno));

																					  printf("\n VCID Count on [%s/%s]= %d \n",sPrtVal,modulerevseq,vcidcnt);fflush(stdout);

																					  if(vcidcnt>0)	

																					  {

																						 printf("\n VCID is available \n");fflush(stdout);

																						for(v=0; v<vcidcnt; ++v)

																						  {

															 

																							ITK_CALL(AOM_ask_value_string(vcidno[v],"item_id",&vcidname));

																							ITK_CALL(AOM_ask_value_string(vcidno[v],"item_revision_id",&VcidLatestRevseq));

																							printf("\n vcid is available [%s/%s] \n ", vcidname,VcidLatestRevseq);fflush(stdout);



																						//	ITK_CALL(ITEM_find_item(vcidname,&vcidtag));

																						//	ITK_CALL(ITEM_ask_latest_rev(vcidtag,&vcidtestrevtag));
																						//	ITK_CALL(AOM_ask_value_string(vcidtestrevtag,"item_revision_id",&VcidLatestRev));



																							fprintf(fptr,"\n%s,%s,%s/%s",sPrtVal,modulerevseq,vcidname,VcidLatestRevseq);fflush(fptr);
																						//    fprintf(fptr,"\n%s,%s,%s/%s",sPrtVal,modulerevseq,vcidname,VcidLatestRev);fflush(fptr);

																						  }
																						  MEM_free(vcidno);

																					  }

																					  else

																						{

																							  printf("\n i am in else of vcid creation \n");fflush(stdout);

																							  CheckFlag=vcidcreation(tPrt,modulelatestrev);

																							  printf("\n i am in else of after vcid creation \n");fflush(stdout);
																							 

																						   if(CheckFlag==1)
																						   {
																							//  ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&rel_type3));

																							  ITK_CALL(GRM_list_secondary_objects_only(modulelatestrev,rel_type3,&crevcidcnt,&crevcidno));

																							  printf("\n vcidcnt count after vcid creation : %d \n",crevcidcnt);fflush(stdout);


																								if(crevcidcnt>0)

																								{

																								  ITK_CALL(AOM_ask_value_string(crevcidno[0],"item_id",&vcidname));

																								  ITK_CALL(AOM_ask_value_string(crevcidno[0],"item_revision_id",&VcidLatestRevseq));

																								  printf("\n vcid after cretion [%s/%s] \n ", vcidname,VcidLatestRevseq);fflush(stdout);

															 

																								  fprintf(fptr,"\n%s,%s,%s,%s/%s",sPrtVal,modulerevseq,"",vcidname,VcidLatestRevseq);fflush(fptr);

																								}

																								else

																								{  

																									printf("\n VCID Not get created on latest revision of module [%s/%s] \n ", sPrtVal,modulerevseq);fflush(stdout);

																									fprintf(fptr,"\n%s,%s,%s,%s,%s",sPrtVal,modulerevseq,"","","VCID Not created on letest Revision");fflush(fptr);

																								}	
																							//	MEM_free(crevcidno);

																							}
																							else
																							{
																							 printf("\n VCID is Already available on previous Revision \n ");fflush(stdout);
																							 fprintf(fptr,"\n%s,%s,%s,%s,%s,%s",sPrtVal,modulerevseq,"","","","VCID is Available on Previous Revision");fflush(fptr);
																							}

																						}
																					//	MEM_free(vcidno);

																				   }
																				   
															 
																			 }
				                                                          }
															 
																	//	} 
																		MEM_free(tpPrtObjs);
																		MEM_free(crevcidno);
															 
																//	}
																	
															 
															//	}
															printf("===============================================================================================\n");
				}
		}

	ITK_exit_module(true);

	return status;
	 
	}

	static void initialise (void)
	 
	{
	 
		int ifail;

		/* <kc> pr#397778 July2595 exit if autologin() fail */
	 
		if ((ifail = ITK_auto_login()) != ITK_ok)
	 
		   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	 
		CHECK_FAIL;

		/* these tokens come from bom_attr.h */
	 
		initialise_attribute (bomAttr_lineName, &name_attribute);
	 
		initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	 
		//ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	 
	//	CHECK_FAIL;
	 
		//ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	 
		CHECK_FAIL;
	 
	}

	static void initialise_attribute (char *name,  int *attribute)
	 
	{
	 
		int ifail, mode;

	//	ifail = BOM_line_look_up_attribute (name, attribute);
	 
	//	CHECK_FAIL;
	 
	//	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	 
		CHECK_FAIL;
	 
	/*	if (mode != BOM_attribute_mode_string)
	 
		{
	 
			printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
	 
			exit(0);
	 
		}*/
	 
	}


	int vcidcreation(tag_t tPrt,tag_t modulelatestrevtag)
	 
	{
	 
	  printf("\n INSIDE VCID Creation \n ");fflush(stdout);

	  char *modulenoname = NULL;
	 
	  char *parttype     = NULL;
	 
	  char *firsttep     = NULL;
	 
	  char *ObjCCidName  = NULL;
	 
	  char *Secondtep  = NULL;
	 
	  //tag_t modulelatestrevtag = NULLTAG;
	 
	  char *modulelatestrev  = NULL;
	  char *modulelDRstatus  = NULL;

	  tag_t itemtag = NULLTAG;

	  tag_t itemrevtag = NULLTAG;

	  int    CheckFlag				 = 0;
	 
	  ITK_CALL(AOM_ask_value_string(tPrt,"item_id",&modulenoname));
	 
	  

	  //  ITK_CALL(ITEM_ask_latest_rev(tPrt,&modulelatestrevtag));
	 
	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"item_revision_id",&modulelatestrev));
	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"t5_PartStatus",&modulelDRstatus));

	  printf("\n Vcid Creation on latest revision [%s/%s] \n ",modulenoname,modulelatestrev);fflush(stdout);
	 


	  ITK_CALL(AOM_ask_value_string(modulelatestrevtag,"t5_PartType",&parttype));
	 
	  printf("\n part type %s \n ", parttype);fflush(stdout);

	  // int len = strlen(modulenoname);
	 
	   //printf("\n modulenoname number length : %d \n",len);fflush(stdout);
	 
	 
	  printf("\n 16 found in modulenoname %s \n ", modulenoname);fflush(stdout);

	 
	 
	 /*  firsttep=subString(modulenoname, 0, 9);

	   printf("\n  firsttep  %s \n ", firsttep);fflush(stdout);

	   Secondtep=subString(modulenoname, 11, 14);

	   printf("\n Secondtep   %s \n ", Secondtep);fflush(stdout);*/



	   ObjCCidName = (char *) MEM_alloc(5000 * sizeof(char *));

	   tc_strcat(ObjCCidName,modulenoname);

	 //  tc_strcat(ObjCCidName,Secondtep);

	   tc_strcat(ObjCCidName,"_R1");

	   printf("\n Main CCID NUMBER for Module------>  %s \n ", ObjCCidName);fflush(stdout);

	  ITK_CALL(ITEM_find_item(ObjCCidName,&itemtag));

		if(itemtag)
		{

		printf("\n VCID Object already available------>  %s \n ", ObjCCidName);fflush(stdout);

		}
		 
		else
		{	 
		  CheckFlag				 = 1;
	//    ITK_CALL(ITEM_ask_latest_rev(itemtag,&itemrevtag));

		   tag_t object1                = NULLTAG;

		   tag_t item_type_tag1         = NULLTAG;

		   tag_t item_create_input_tag1  = NULLTAG;

		   tag_t VcidLatestRev           = NULLTAG;

		   tag_t vcidrel               = NULLTAG;

		   tag_t vcidreltyp              = NULLTAG;

		   char *ObjCCidrev           =NULL;

			ITK_CALL(TCTYPE_find_type("T5_CCID", "Item", &item_type_tag1));         

			ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));

			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",ObjCCidName));

			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",ObjCCidName));

			ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));

			ITK_CALL(AOM_save_without_extensions(object1));

			ITK_CALL(AOM_refresh(object1,0));

			if(object1)

				{

					ITK_CALL(AOM_unlock(object1));

					printf("\n vcid Object is created.\n"); fflush(stdout);

					ITK_CALL(ITEM_ask_latest_rev(object1,&VcidLatestRev));

					ITK_CALL(AOM_set_value_string(VcidLatestRev,"item_revision_id","A;1"));
				//	ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDApplicability","BothES"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDApplicability","Service"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"t5_CCIDDRStatus",modulelDRstatus));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"object_desc","Initial Revision"));
					ITK_CALL(AOM_set_value_string(VcidLatestRev,"object_name","Initial Revision"));


					ITK_CALL(AOM_save_without_extensions(VcidLatestRev));

					ITK_CALL(AOM_refresh(VcidLatestRev,0));

				

					

					  printf("\n vcid relation creation with module.....\n"); fflush(stdout);

					  ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&vcidreltyp));

					  printf("\n module relation creation \n"); fflush(stdout);

					  ITK_CALL(GRM_create_relation(modulelatestrevtag,VcidLatestRev,vcidreltyp,NULLTAG,&vcidrel));				

					  ITK_CALL(AOM_unlock(vcidrel));

					  GRM_save_relation(vcidrel);

					  ITK_CALL(AOM_lock(vcidrel));

					  printf("\n RELATIONSHIP CREATED  \n");fflush(stdout);

					//  fprintf(fptr,"\n%s,%s/%s,%s/%s,%s/%s",sPrtVal,vehicleno,vehrevseq,modulenoname,modulerevseq,ObjCCidName,ObjCCidrev);fflush(fptr);

					

				}

				else

				{

					printf("\n vcid Object is not created.\n"); fflush(stdout);

				}
	 
		}

return CheckFlag;
 
}