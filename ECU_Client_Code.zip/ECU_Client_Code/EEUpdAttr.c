#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)                                                                                                             \
        if(Debug)                                                                                                                       \
        {                                                                                                                                       \
                printf(#X);                                                                                                             \
        }                                                                                                                                       \
        fflush(NULL);                                                                                                           \
        status=X;                                                                                                                       \
        if (status != ITK_ok )                                                                                          \
        {                                                                                                                                       \
                int                             index = 0;                                                                              \
                int                             n_ifails = 0;                                                                   \
                const int*              severities = 0;                                                                 \
                const int*              ifails = 0;                                                                             \
                const char**    texts = NULL;                                                                   \
                                                                                                                                                \
                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                printf("\t%3d error(s)\n", n_ifails);                                                   \
                for( index=0; index<n_ifails; index++)                                                  \
                {                                                                                                                               \
                        printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                }                                                                                                                               \
                return status;                                                                                                  \
        }                                                                                                                                       \
        else                                                                                                                            \
        {                                                                                                                                       \
                if(Debug)                                                                                                               \
                printf("\tSUCCESS\n");                                                                                  \
        }                                                                                                                                       \

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char    * sPart                 =   NULL;
char    * sRevSeq               =   NULL;
char    * sAttrName             =   NULL;
char    * sAttrVal              =   NULL;

void setAddStr(int *count,char ***strset,char* str)
{
        *count=*count+1;
        //printf("\n setAddStr %d",*count);fflush(stdout);
        if(*count==1)
        {
                (*strset) = (char **)malloc((*count ) * sizeof(char *));
        }
        else
        {
                (*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
        }
        (*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
         tc_strcpy((*strset)[*count-1],str);
         printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
        int j   =0;
        for(j=0;j<*count;j++)
        {
                printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
                printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
                if(tc_strcmp((*strset)[j],str)==0) //check this
                return j;
        }
        return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
        int ifail;
        int status;
        int iStatus=0;

        (void)argc;
        (void)argv;

        initialise();

        sPart  = ITK_ask_cli_argument("-i=");
        sRevSeq = ITK_ask_cli_argument("-r=");
        

        iStatus = ITK_auto_login();

        if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
        ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
        ITK_CALL(ITK_set_journalling( TRUE ));

        printf("\nkk.Input [Part,RevSeq,Attr Name,Attr Val] [%s,%s,%s,%s]",sPart,sRevSeq,sAttrName,sAttrVal); fflush(stdout);

        char    *sFrmRpl;
        char    *sToRpl;

        int             n_Input = 3;
        int             nPrtCnt = 0;
        int             nPrtCnt_1 = 0;
        char    *values[3];
		char    *values_1[3];
        char    *qry_Input[3] = {"Item ID", "Type", "Revision"};
        tag_t   QryPrt = NULLTAG;
        tag_t   tPrt = NULLTAG;
        tag_t   tPrt_1 = NULLTAG;
        tag_t   *tpPrtObj = NULL;
        tag_t   *tpPrtObj_1 = NULL;

        char    *sObjVal = NULL;
char* part_status=NULL;
		char* App_owner=NULL;
		char* Barcode=NULL;
		//logical car_ind=false;
		char* Key_descp=NULL;
		char* Material_class=NULL;
		char* MOd_descp=NULL;
		char* Dsg_own=NULL;
		char* Own_Project=NULL;
		char* Spare_criteria=NULL;
		char* Project=NULL;
		char* Roll_Weight=NULL;
		char* weight=NULL;
		char* UOM=NULL;
		char* T_T=NULL;
		char* CMVR=NULL;
		char* cabinkit_app=NULL;
		char* Owning_user=NULL;
		char* Aggregate=NULL;
		char* Aggregate_group=NULL;
		char* Mod_ind=NULL;

        /*int nCCIDCnt = 0;
        int iSCnt = 0;
        int iVCIDCnt = 0;
        int nVCCnt = 0;
        char    *sObjtype = NULL;
        char    *sClassName = NULL;
        char    *sVCIDNum = NULL;
        char    *sVCIDRev = NULL;
        char    *sVCIDTyp = NULL;
        char    **VCIDList = NULL;
        char    *sVCIDObjStr = NULL;
        tag_t   tObj = NULLTAG;
        tag_t   HasContents = NULLTAG;
        tag_t   *tpAllObjs = NULL;
        tag_t   *tpVCatch = NULL;
        tag_t   tSnapObj = NULLTAG;
        tag_t   tClassId = NULLTAG;
        tag_t   tCCIDHsSnap = NULLTAG;
        tag_t   tVCID = NULLTAG;
        tag_t   tRefCCVTag = NULLTAG;
        logical lIsVCIDLatest = false;
		
		
						

        int nRef = 0;
        int *levels = 0;
        char **relationsRef = NULL;
        tag_t   *tpRef = NULL;*/

        sFrmRpl = (char*)malloc(5);
        sToRpl = (char*)malloc(5);
        //sVCIDObjStr = (char*)malloc(50);
        //VCIDList = (char**)MEM_alloc(1 * sizeof *VCIDList);

        tc_strcpy(sFrmRpl,";");
        tc_strcpy(sToRpl,"*");
        ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRevSeq);

        printf("\nkk.Querying.. [%s,%s]",sPart,sRevSeq); fflush(stdout);

        values[0] = sPart;
        values[1] = "EE Part Revision";
        values[2] = sRevSeq;
		
		
		char * Part_no1=NULL;
Part_no1=(char *) MEM_alloc(300);
tc_strcpy(Part_no1,sPart);
 tc_strcat(Part_no1,"_16");

		values_1[0] = Part_no1;
        values_1[1] = "Design Revision";
        values_1[2] = sRevSeq;

        if(QRY_find2("Item Revision...", &QryPrt));
        if(QryPrt)
        {
                if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObj));
                if(QRY_execute(QryPrt, n_Input, qry_Input, values_1, &nPrtCnt_1, &tpPrtObj_1));
				
                printf("\nkk.Part count is [%d]\n", nPrtCnt);fflush(stdout);
				printf("\nkk.Part count is [%d]\n", nPrtCnt_1);fflush(stdout);

                if(nPrtCnt_1>0)
                {
                        tPrt_1 = tpPrtObj_1[0];
						
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_PartStatus",&part_status));
						printf("\nkk.part_status [%s]\n", part_status);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_ApplicationOwner",&App_owner));
						printf("\nkk.App_owner [%s]\n", App_owner);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_Barcode",&Barcode));
						printf("\nkk.Barcode [%s]\n", Barcode);fflush(stdout);
                        //ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_CarMakeBuyIndicator",&car_ind));
						//printf("\nkk.car_ind [%s]\n", car_ind);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_CategoryName",&Key_descp));
						printf("\nkk.Key_descp [%s]\n", Key_descp);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_MatlClass",&Material_class));
						printf("\nkk.Material_class [%s]\n", Material_class);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_DocRemarks",&MOd_descp));
						printf("\nkk.MOd_descp [%s]\n", MOd_descp);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_DsgnOwn",&Dsg_own));
						printf("\nkk.Dsg_own [%s]\n", Dsg_own);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"owning_project",&Own_Project));
						printf("\nkk.Own_Project [%s]\n", Own_Project);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_SpareCriteria",&Spare_criteria));
						printf("\nkk.Spare_criteria [%s]\n", Spare_criteria);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_ProjectCode",&Project));
						printf("\nkk.Project [%s]\n", Project);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_RolledupWt",&Roll_Weight));
						printf("\nkk.Roll_Weight [%s]\n", Roll_Weight);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_Weight",&weight));
						printf("\nkk.weight [%s]\n", weight);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_uom",&UOM));
						printf("\nkk.UOM [%s]\n", UOM);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_TrackTrace",&T_T));
						printf("\nkk.T_T [%s]\n", T_T);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_CMVRCertificationReqd",&CMVR));
						printf("\nkk.CMVR [%s]\n", CMVR);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_cabkitapp",&cabinkit_app));
						printf("\nkk.cabinkit_app [%s]\n", cabinkit_app);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"owning_user",&Owning_user));
						printf("\nkk.Owning_user [%s]\n", Owning_user);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_Aggregate",&Aggregate));
						printf("\nkk.Aggregate [%s]\n", Aggregate);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_AggregateGroup",&Aggregate_group));
						printf("\nkk.Aggregate_group [%s]\n", Aggregate_group);fflush(stdout);
                        ITKCALL(AOM_UIF_ask_value(tPrt_1,"t5_ModelIndicator",&Mod_ind));
						printf("\nkk.Mod_ind [%s]\n", Mod_ind);fflush(stdout);
						
                    }
					
					if(nPrtCnt>0)
                        {
						
						tPrt = tpPrtObj[0];
                        ITK_CALL(AOM_refresh(tPrt,1));
						
						if(part_status!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_PartStatus",part_status));}
                        if(App_owner!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_ApplicationOwner",App_owner));}
                        if(Barcode!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_Barcode",Barcode));}
                       // if(car_ind!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_CarMakeBuyIndicator",car_ind));}
                        if(Key_descp!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_CategoryName",Key_descp));}
                        if(Material_class!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_MatlClass",Material_class));}
                        if(MOd_descp!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_DocRemarks",MOd_descp));}
                        if(Dsg_own!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_DsgnOwn",Dsg_own));}
                        //if(Own_Project!=NULL){ITKCALL(PROP_UIF_set_value(tPrt,"owning_project",Own_Project));}
                        if(Spare_criteria!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_SpareCriteria",Spare_criteria));}
                        if(Project!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_ProjectCode",Project));}
                        if(Roll_Weight!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_RolledupWt",Roll_Weight));}
                        if(weight!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_Weight",weight));}
                        if(UOM!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_uom",UOM));}
                        if(T_T!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_TrackTrace",T_T));}
                        if(CMVR!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_CMVRCertificationReqd",CMVR));}
                        if(cabinkit_app!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_cabkitapp",cabinkit_app));}
                       // if(Owning_user!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"owning_user",Owning_user));}
                        if(Aggregate!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_Aggregate",Aggregate));}
                        if(Aggregate_group!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_AggregateGroup",Aggregate_group));}
                       //if(Mod_ind!=NULL){ITKCALL(AOM_UIF_set_value(tPrt,"t5_ModelIndicator",Mod_ind));}
                                ITK_CALL( AOM_save_without_extensions(tPrt));
                                ITK_CALL(AOM_refresh(tPrt,0));
                                printf("\nkk.Value Updated.\n");fflush(stdout);
                        }
                
        }

        ITK_exit_module(true);

        return status;
}

static void initialise (void)
{
        int ifail;

        /* <kc> pr#397778 July2595 exit if autologin() fail */
        if ((ifail = ITK_auto_login()) != ITK_ok)
           printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
        CHECK_FAIL;

        /* these tokens come from bom_attr.h */
        initialise_attribute (bomAttr_lineName, &name_attribute);
        initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
    //    ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
        CHECK_FAIL;
   //     ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
        CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
        int ifail, mode;

     /*   ifail = BOM_line_look_up_attribute (name, attribute);
        CHECK_FAIL;
        ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
        CHECK_FAIL;
        if (mode != BOM_attribute_mode_string)
        {
                printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
                exit(0);
        }*/
}


