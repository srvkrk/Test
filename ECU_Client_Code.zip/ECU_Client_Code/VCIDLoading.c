/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*,char*);
int correction(char*,char*);
int tm_PartReplace(char*,tag_t);
int tm_VCIDUpdate(char*,tag_t);

int vcidloading(char* ,char* ,tag_t,char* ,char*);



void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*partnumber				= NULL;
	char 			*rev_id					= NULL;
	char 			*Nextrev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");

					//////////////////
					char 			*VCIDNumber					= NULL;
					char 			*vcidrevseq					= NULL;
					char 			*vcidrev					= NULL;
					char 			*vcidseq					= NULL;
					char 			*VCIDNumber1					= NULL;
					char 			*VCIDNumber2					= NULL;
					char 			*extension					= NULL;
					char 			*tempextenstion					= NULL;

					tag_t VCIDNumberitem_tag	   = NULLTAG;
					tag_t vcidrevseq_tag	   = NULLTAG;

					vcidrevseq =(char *) MEM_alloc(150);
					VCIDNumber =(char *) MEM_alloc(150);

printf("\nInput Filename befor is :%s",Filename);
 ifail=STRNG_replace_str(Filename,".","_",&tempextenstion);
 printf("\nInput Filename tempextenstion :%s",tempextenstion);

	VCIDNumber1 = strtok(tempextenstion, "_");
	printf("\nInput VCIDNumber1:%s",VCIDNumber1);

	VCIDNumber2 = strtok(NULL, "_");
	printf("\nInput VCIDNumber2:%s",VCIDNumber2);

	vcidrev = strtok(NULL, "_");
	printf("\nInput vcidrev:%s",vcidrev);

	vcidseq = strtok(NULL, "_");
	printf("\nInput vcidseq:%s",vcidseq);

	extension = strtok(NULL, "_");
	printf("\nInput extension:%s",extension);



	tc_strcpy(VCIDNumber,"");	
	tc_strcat(VCIDNumber,VCIDNumber1);
	tc_strcat(VCIDNumber,"_");
	tc_strcat(VCIDNumber,VCIDNumber2);

	tc_strcpy(vcidrevseq,"");	
	tc_strcat(vcidrevseq,vcidrev);
	tc_strcat(vcidrevseq,";");
	tc_strcat(vcidrevseq,vcidseq);

     printf("\nInput VCID:%s/%s",VCIDNumber,vcidrevseq);


	 int ifail;
	tag_t	item_tag		= NULLTAG;
	tag_t	itemrev_tag		= NULLTAG;

	tag_t	*ccidTagrf		= NULLTAG;
	tag_t	*snapchild		= NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	int SnapCnt=0;
	int snapcount=0;
	char* ErrorText =NULL;
	fflush(NULL);


	char	*FName = NULL;
	FName =(char *) MEM_alloc(150);
	FILE *fptr;
	tc_strcpy(FName,"/user/cvprod/Akshay/TPLLoading/VCIDLoading/VCIDLOADINGLOG/");
	tc_strcat(FName,VCIDNumber);
	tc_strcat(FName,"_");
	tc_strcat(FName,vcidrev);
	tc_strcat(FName,"_");
	tc_strcat(FName,vcidseq);
	tc_strcat(FName,".csv");

     fptr = fopen(FName,"w");
	 
	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		//exit(1);
	}
	else
	{
		printf("\nlog File opening!!!");  fflush(stdout);
	}

     fprintf(fptr,"%s,%s,%s","VCID Number","part Added","part Not Added");fflush(fptr);



	///////////////////////////
	
	
	//	ifail =ITEM_create_item(VCIDNumber,VCIDNumber,"T5_CCID",vcidrevseq,&VCIDNumberitem_tag,&vcidrevseq_tag);
	

	////////////////////


	ifail = ITEM_find_item (VCIDNumber, &VCIDNumberitem_tag);
	if (VCIDNumberitem_tag)
	{
	
	                 
	 
      ifail = ITEM_find_revision(VCIDNumberitem_tag,vcidrevseq, &vcidrevseq_tag);

					 

		   rev_id =(char *) MEM_alloc(150);
		   char	*rev = NULL;
		   char	*id = NULL;





	
		if (fp != NULL)
		{
			while (fgets(temp, 200, fp)!= NULL)
			{
				tc_strcpy(temp,stripBlanks(temp));

				if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
				{
					partnumber = strtok(temp, "^");
					printf("\nInput partnumber:%s",partnumber);

					rev = strtok(NULL, "^");
					printf("\nInput rev:%s",rev);

					id = strtok(NULL, "^");
					printf("\nInput id:%s",id);


					tc_strcpy(rev_id,"");	
					tc_strcat(rev_id,rev);
					tc_strcat(rev_id,";");
					tc_strcat(rev_id,id);



				//	rev_id = strtok(NULL, "^");
					printf("\nrev_id:%s",rev_id);



					
			 //		ifail = vcidloading(partnumber,rev_id,vcidrevseq_tag,VCIDNumber,vcidrevseq); //to copy content

			//////////////


						ifail = ITEM_find_item (partnumber, &item_tag);
						CHECK_FAIL;
						 
						ifail = ITEM_find_revision(item_tag,rev_id, &itemrev_tag);
						CHECK_FAIL;

						if (itemrev_tag)
						{
							 ifail=GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType);// new relation created in bmide 
							 printf("\n  DataSnap -now get CCID has  HasSnapshotType \n");fflush(stdout);

							 ifail = GRM_list_secondary_objects_only(vcidrevseq_tag,HasSnapshotType,&SnapCnt,&ccidTagrf);
							 printf("\n  DataSnap -Check how many Snapshot in Refrences Relationship =============>>> %d  \n",SnapCnt);fflush(stdout);


							 ifail=AOM_lock(ccidTagrf[0]);
																							
																									
							ifail = FL_insert(ccidTagrf[0],itemrev_tag,999);
							if(ifail != ITK_ok)
							{
								EMH_ask_error_text(ifail,&ErrorText);
								printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);

								fprintf(fptr,"\n%s/%s,%s,%s/%s",VCIDNumber,vcidrevseq," ",partnumber,rev_id);fflush(fptr);
							}

							printf("\n PartReplace_DML  Part addition code-%s having sequence - %s \n",partnumber,rev_id );fflush(stdout);

							ifail=AOM_save_without_extensions(ccidTagrf[0]);

							ifail=AOM_refresh(ccidTagrf[0],0);

							ifail=AOM_unlock(ccidTagrf[0]);

							printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);

							fprintf(fptr,"\n%s/%s,%s/%s,%s",VCIDNumber,vcidrevseq,partnumber,rev_id," ");fflush(fptr);

			
						}


			////////////
					

				}			
				tc_strcpy(temp, "");
			}
		}
		else 
		{
			printf("File Unable to Open...!!");
		}
}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/

/*int vcidloading(char* partnumber,char* rev_id,tag_t vcidrevseq_tag,char* VCIDNumber,char* vcidrevseq)
{





return ifail;
}*/




