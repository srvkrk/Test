#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
#include <tc/tc_startup.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <tccore/item_msg.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <fnd0booleansolve/booleansolve.h>
#define ITK_err 919002
#define GMD_err (EMH_USER_error_base +26)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error (EMH_USER_error_base+25)
#define PLM_error1 (EMH_USER_error_base+26)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PLM_error2 (EMH_USER_error_base+26)
#define PLM_error3 (EMH_USER_error_base+26)
#define PLM_error4 (EMH_USER_error_base+26)
#define PLM_error5 (EMH_USER_error_base+26)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -p=<project name> (required)\n"
        );	
}
int VCID_UV_Transfer(char*);
int part_replace(char*);

int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Dmlid					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Dmlid 			= ITK_ask_cli_argument("-i=");

	int			ifail 				= ITK_ok;
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Dmlid)) == 0)
	{
		print_requirement();
		return -1;
	}
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ifail = ITK_auto_login();

	ITK_CALL(ITK_set_journalling( TRUE ));

	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	ifail = VCID_UV_Transfer(Dmlid);
	
		
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


int VCID_UV_Transfer(char* Dmlid)
{

	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t	MdmDMLRevTag		= NULLTAG;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcntrf		          = 0;
	int     pr		          = 0;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	char   *Prt_object_type =NULL;
	char   *Prt_object_typerev =NULL;
	char    *NewCCIDRevDup = NULL;
	char    *str		    = NULL;
	char    *info3		    = NULL;
	char    *info4		    = NULL;
	char    *Rel_type		    = NULL;
	char	*qry_CInput[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_CVal[2] = {"VCID", "autotransfer"};
	int		n_InputX		= 2;
	int     CountC			= 0;
	tag_t	*CnObjC		    = NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
    NewCCIDRevDup		=(char *) MEM_alloc(10);
	str = malloc(1500);
	int ifail=ITK_ok;
													
	

if(QRY_find2("ControlObjQry", &ProQryContObj));
if(ProQryContObj)
{
	if(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
	printf("\n CONT Objects for CCID transfer LIVE  == %d\n", CountC);fflush(stdout);

 if(CountC >0)
 {
	if(ITEM_find_item(Dmlid, &MdmDML_tag)!=ITK_ok)PrintErrorStack();

			if (MdmDML_tag != NULLTAG)
			{
				  printf("\n DML tag is not null for DML No: [%s] \n", Dmlid);fflush(stdout);

				  if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

				  if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
					  printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);

				  if((tc_strcmp(Rel_type,"VCID Update")==0)||(tc_strcmp(Rel_type,"CCU")==0))
					{
					  printf("\n VCID Update\n");fflush(stdout);

						ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
						ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));
						printf("\n Finding the CCU DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);
						if (Mdmtsk_cnt>0)
						  {
							for (tt=0;tt<Mdmtsk_cnt ;tt++ )
								{

								 printf("\n Now inside the task find as Task count is for CCU DML-- %d \n",Mdmtsk_cnt);fflush(stdout);

								 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[tt],"object_type",&Taskobj_type));
								 printf("\n Now CCU DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

								 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[tt],"item_id",&TskNmMdm));
								 printf("\n Now CCU DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

								 ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_relc));
								 if (part_tsk_relc!=NULLTAG)
									{
									  ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc, &partcntrf, &PartsTagrf));

									  if (partcntrf>0)
										{
											
											for (pr=0;pr<partcntrf;pr++)
											{
												DesignrevTagR=PartsTagrf[pr];
												if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
												if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Prt_object_typerev)!=ITK_ok);

												printf("\n VCID Number is : %s/%s \n",Prt_object_type,Prt_object_typerev);fflush(stdout);

												  
													tc_strcpy(NewCCIDRevDup,Prt_object_typerev);
													printf("\n  NewCCIDRevDup is:[%s]\n",NewCCIDRevDup);fflush(stdout);

												/*	if(QRY_find2("ControlObjQry", &ProQryContObj));
													if(ProQryContObj)
													{
														if(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
														printf("\n CONT Objects for CCID transfer LIVE  == %d\n", CountC);fflush(stdout);

														if(CountC >0)
														 {*/
															ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo3",&info3));

															printf("\n CCID INFO 3 ----- [%s]",info3); fflush(stdout);

															
															tc_strcpy(str,"");														
															tc_strcat(str,info3);//user/uaprodtrl/ECU_Code/5442/Client_Code/BL_UA_UV_Transfer.sh					
															tc_strcat(str," ");
															tc_strcat(str,Prt_object_type);
															tc_strcat(str," ");
															tc_strcat(str,"'");
															tc_strcat(str,NewCCIDRevDup);   //BBL_UA_UV_Transfer.sh CCIDNo 'CCIDRev'
															tc_strcat(str,"'");


															printf("\n Cammand To Run ------------------:[%s]\n",str);fflush(stdout);

														//	system(str);

															printf("\n AFTER CCID SHELL str DownloadPath DIR :[%s]\n",str);fflush(stdout);
														
													/*	}
													}
													else
													{
														printf("\n ContrlObj not found for CCID Transfer live ");fflush(stdout);
													}*/
					

											}
										}
										else
										{
											printf("\n VCIDs NOT Found \n");fflush(stdout);
										}


									}


								}


						  }
						  else
							{
							 printf("\n T5_DMLTaskRelation NOT Found \n");fflush(stdout);
							}



					}

					//***************
					
				//	if((tc_strcmp(Rel_type,"Backward Compatible VCID Release")==0)||(tc_strcmp(Rel_type,"BKC")==0))

					if((tc_strcmp(Rel_type,"ECU Parts Release")==0) || (tc_strcmp(Rel_type,"EP")==0) || (tc_strcmp(Rel_type,"Backward Compatible VCID Release")==0)||(tc_strcmp(Rel_type,"BKC")==0))
					{
						
						

					   ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &part_tsk_relc));
					

						if (part_tsk_relc!=NULLTAG)
						{
						   printf("\n Relation T5_HasNewCCID expanded \n"); fflush(stdout);

						   ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag, part_tsk_relc, &partcntrf, &PartsTagrf));
						   
								
								if (partcntrf>0)
								{
									
									for (pr=0;pr<partcntrf;pr++)
									{ 
										DesignrevTagR=PartsTagrf[pr];

										if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
										if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Prt_object_typerev)!=ITK_ok);

										printf("\n VCID Number is : %s/%s \n",Prt_object_type,Prt_object_typerev);fflush(stdout);

									   
										
										tc_strcpy(NewCCIDRevDup,Prt_object_typerev);
										printf("\n  NewCCIDRevDup is:[%s]\n",NewCCIDRevDup);fflush(stdout);
										ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo4",&info4));

										printf("\n CCID INFO 4 ----- [%s]",info4); fflush(stdout);

										
										tc_strcpy(str,"");														
										tc_strcat(str,info4);//user/uaprodtrl/ECU_Code/5442/Client_Code/BL_UA_UV_Transfer.sh					
										tc_strcat(str," ");
										tc_strcat(str,Prt_object_type);
										tc_strcat(str," ");
										tc_strcat(str,"'");
										tc_strcat(str,NewCCIDRevDup);   //BBL_UA_UV_Transfer.sh CCIDNo 'CCIDRev'
										tc_strcat(str,"'");


										printf("\n Cammand To Run ------------------:[%s]\n",str);fflush(stdout);

										system(str);

										printf("\n AFTER CCID SHELL str DownloadPath DIR :[%s]\n",str);fflush(stdout);
									}
								}
						}


					}



			}
			else
			{
			 printf("\n DML Not found NOT Found \n");fflush(stdout);
			}
	}
}
else
{
	printf("\n ContrlObj not found for CCID Transfer live ");fflush(stdout);
}

  return ITK_ok;
}

