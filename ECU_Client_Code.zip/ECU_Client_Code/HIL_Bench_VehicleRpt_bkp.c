/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: Clr_SVRGenTPL.c
**
** Functions:-    This utility applies SVR, Revision Rule and clouser Rule on input Platform to create it BOM structure which is furter use to create ColourSVRGenTPL Report.
**
**           Date                                                                                                      Author                               
**           16-July-2019																							 Rohit Bhosale                            
**
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

void childfun(tag_t child,char*);
FILE *fptr ;

char *replaceWord(const char *s, const char *oldW, const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

		char c[] = ",";
	    char d[] = ";";


//Allproperties defined

		char	*Description = NULL;
		char	*Modification_Description = NULL;
		char	*AddOn_Description = NULL;
		char	*Keyword_Description = NULL;
		char	*Platform = NULL;
		char	*Module_Address		 = NULL;
		char	*Module_Name		 = NULL;
		char	*Track_and_Trace		 = NULL;
		char	*CTECTS			 = NULL;
		char	*Project_Code		 = NULL;
		char	*Design_Group		 = NULL;
		char	*Owner_Design_Unit	 = NULL;
		char	*Part_Type		 = NULL;
		char	*Part_Code		 = NULL;
		char	*Drawing_Indicator	 = NULL;
		char	*Drawing_No		 = NULL;
		char	*Part_Material		 = NULL;
		char	*Weight			 = NULL;
		char	*Rolled_Up_Weight	 = NULL;
		char	*Material_Thickness	 = NULL;
		char	*Material_Class		 = NULL;
		char	*Surface_Protection	 = NULL;
		char	*Coated			 = NULL;
		char	*Colour_Indicator	 = NULL;
		char	*Comp_Code		 = NULL;
		char	*Envelope_Dimensions	 = NULL;
		char	*Application_Owner = NULL;
		char	*Samples_to_be_Approved	 = NULL;
		char	*Validation_Status	 = NULL;
		char	*Spare_Part		 = NULL;
		char	*Spare_Indicator		 = NULL;
		char	*Homologation_Reqd	 = NULL;
		char	*Unit			 = NULL;
		char	*Owner			 = NULL;
		char	*Creation_Date		 = NULL;
		char	*Last_Modifying_User	 = NULL;
		char	*Last_Modified_Date	 = NULL;
		char	*Release_Status		 = NULL;

		char	*Descriptionc = NULL;
		char	*Modification_Descriptionc = NULL;
		char	*AddOn_Descriptionc = NULL;
		char	*Keyword_Descriptionc = NULL;
		char	*Platformc = NULL;
		char	*Module_Addressc		 = NULL;
		char	*Module_Namec		 = NULL;
		char	*Track_and_Tracec		 = NULL;
		char	*CTECTSc			 = NULL;
		char	*Project_Codec		 = NULL;
		char	*Design_Groupc		 = NULL;
		char	*Owner_Design_Unitc	 = NULL;
		char	*Part_Typec		 = NULL;
		char	*Part_Codec		 = NULL;
		char	*Drawing_Indicatorc	 = NULL;
		char	*Drawing_Noc		 = NULL;
		char	*Part_Materialc		 = NULL;
		char	*Weightc			 = NULL;
		char	*Rolled_Up_Weightc	 = NULL;
		char	*Material_Thicknessc	 = NULL;
		char	*Material_Classc		 = NULL;
		char	*Surface_Protectionc	 = NULL;
		char	*Coatedc			 = NULL;
		char	*Colour_Indicatorc	 = NULL;
		char	*Comp_Codec		 = NULL;
		char	*Envelope_Dimensionsc	 = NULL;
		char	*Application_Ownerc = NULL;
		char	*Samples_to_be_Approvedc	 = NULL;
		char	*Validation_Statusc	 = NULL;
		char	*Spare_Partc		 = NULL;
		char	*Spare_Indicatorc		 = NULL;
		char	*Homologation_Reqdc	 = NULL;
		char	*Unitc			 = NULL;
		char	*Ownerc			 = NULL;
		char	*Creation_Datec		 = NULL;
		char	*Last_Modifying_Userc	 = NULL;
		char	*Last_Modified_Datec	 = NULL;
		char	*Release_Statusc		 = NULL;

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
                                
    }
                return return_code;
}

int ITK_user_main(int argc, char* argv[])
{
	int z = 0;
	/*	char			* Item_ID						= NULL;
		char			* RevisionRule						= NULL;
		char			* rev_id						= NULL;
		char			* itemid						= NULL;
		char			* child_level						= NULL;
		char			* child_qty						= NULL;
		char			* swparttype						= NULL;*/
		char	*dmlTaskNo	    = NULL;

		dmlTaskNo 		= ITK_ask_cli_argument("-i=");
	//	RevisionRule 	= ITK_ask_cli_argument("-RevisionRule=");

	z = ITK_auto_login();
		if(z == ITK_ok)
		{
		    printf("\n\n\t Login Successful for [%s]\n",dmlTaskNo); fflush(stdout);

			//FILE *fptr ;
			fptr	=	fopen("output.csv", "w");

			if (fptr == NULL)
			{
			    printf("Could not open file");	fflush(stdout);
			    return 0;
			}


		 tag_t rootTask			= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t *attachments		= NULLTAG;
	tag_t DML_tag			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	tag_t	 DMLTaskRelation  = NULLTAG;
	tag_t *attccidTag	    = NULLTAG;
	tag_t	taskobj	= NULLTAG;
	tag_t	ProQryContObj	= NULLTAG;

    char * parent_name		= NULL;
	char *username			= NULL;
    char* Taskobject_type   = NULL;   
    char* Taskobject_name	= NULL;   
//	char	*dmlTaskNo	    = NULL;
	char *DMLNo				= NULL; 
    char	*Rel_type       = NULL;
    char *CurrentTask		= NULL;
	char	*info1			= NULL;
	char	*info2			= NULL;
	char	*info3			= NULL;
	char* Sevice		    = NULL;   
	char* DID		        = NULL;   
	char* DTC		        = NULL; 
	DMLNo=(char *) MEM_alloc(1000 * sizeof(char *));

    int		attccidcnt     = 0;		
	int     icnt		   = 0;
    int   noAttachment      = 0;
    int CCICheckFlag =0;
    int ChkTdsDoc =0;
	int ifail;
    int CCICheckTDS =0;
   


	EPM_decision_t decision;
	decision = EPM_go;

    char	*qry_CInput[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_CVal[2] = {"HILBenchVehicleRpt", "Live"};
	int		n_InputX		= 2;
	int     CountC			= 0;
	tag_t	*CnObjC		    = NULLTAG;

	TC_write_syslog("\n Start:HIL_Bench_VehicleRpt.");
	if(QRY_find2("ControlObjQry", &ProQryContObj));
	if(ProQryContObj)
	{
	  if(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
	  printf("\n Control Object found for HIL_Bench_VehicleRpt LIVE  == %d\n", CountC);fflush(stdout);
	  if(CountC >0)
	  {
		ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo1",&info1));
		ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo2",&info2));
		ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo3",&info3));

		printf("\n HILBenchVehicleRpt INFO 1 ----- [%s]",info1); fflush(stdout);
		printf("\n HILBenchVehicleRpt INFO 2 ----- [%s]",info2); fflush(stdout);
		printf("\n HILBenchVehicleRpt INFO 3 ----- [%s]",info3); fflush(stdout);
	  
			
			char* message =NULL;
			char* message2 =NULL;
			char* pdfdocname =NULL;
			char* taskobjid =NULL;
			char* solupart =NULL;
			char* solrevisionid =NULL;
			char* SwPartType =NULL;
			char* soluobjtp =NULL;
			char* rptname =NULL;
			char* HILdocname =NULL;
			char* BenchReport =NULL;
			char* VehicleReport =NULL;
			char* containerlist =NULL;
			char* drstatus =NULL;

			tag_t	rel_type1 = NULLTAG;
			tag_t	refrel = NULLTAG;
			int		solnobjcnt = 0;
			int		refrelcnt = 0;
			int		iref = 0;
			int		k = 0;
			int		revcnt = 0;
			int		at = 0;

			tag_t*	solnobjs = NULLTAG;
			tag_t*	refrelobjts = NULLTAG;
			tag_t*	allrevlist = NULLTAG;
			tag_t	solnobj = NULLTAG;
			tag_t	refrelobjt = NULLTAG;
			tag_t	atPrt = NULLTAG;
			tag_t	solitemtag = NULLTAG;

			

			message = (char *)MEM_alloc(500);
			message2 = (char *)MEM_alloc(500);
			pdfdocname = (char *)MEM_alloc(500);
			HILdocname = (char *)MEM_alloc(500);
			BenchReport = (char *)MEM_alloc(500);
			VehicleReport = (char *)MEM_alloc(500);
			containerlist = (char *)MEM_alloc(5000);

			tc_strcpy(message,"");
			tc_strcpy(message2,"");

			tc_strcpy(containerlist,"");

			tc_strcpy(message,"Please attach below reports to container reference folder (Container number__HIL_Report,Container number_Bench_Report,Container number_Vehicle_Report)");
		//	tc_strcpy(message2,"(Query document format 'PA20-F439' in PLM)");



			ITK_CALL(POM_get_user_id (&username));
			printf("\n\n TDS Session login User1 : %s\n",username); fflush(stdout);

		//	if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		//	{

			//	CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			//	printf("\n TDS...");fflush(stdout);

			//	CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			//	printf("\n TDS CurrentTask: %s",CurrentTask);fflush(stdout);

			//	CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			//	printf("\n TDS Parent Name: %s",parent_name);fflush(stdout);



			//	CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			//	printf("\n TDS Target Attachment:%d",noAttachment);fflush(stdout);

			//	if(noAttachment > 0)
				//   {

				//	DMLTaskTag = attachments[0];

				//	if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok);
					printf("\n  dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout);



					 if(tc_strstr(dmlTaskNo,"_") != NULL)
					 {
						DMLNo=strtok(dmlTaskNo,"_");
						printf("\n DMLNo =====> [%s]", DMLNo);fflush(stdout); //getting dml number here
					 }
					 else
					  {
						 tc_strcpy(DMLNo,dmlTaskNo);
						 printf("\n DMLNo 2=====> [%s]", DMLNo);fflush(stdout);
					  }

					if(ITEM_find_item(DMLNo,&DML_tag)!=ITK_ok);

						if (DML_tag != NULLTAG)
						{
						  if(ITEM_ask_latest_rev(DML_tag,&DMLRevTag)!=ITK_ok);

						  if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok);
						  printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);

							if(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&drstatus)!=ITK_ok);
						  printf("\n CCIDSignoff_Validationt DML drstatus: [%s]", drstatus);fflush(stdout);

						  if(((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0)) && (tc_strcmp(info1,"EP")==0))
						    {
								 if((tc_strcmp(drstatus,"DR3")==0)||(tc_strcmp(drstatus,"AR3")==0))
								 {

								    ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&DMLTaskRelation));
									printf("\n after finding DMLTaskRelation \n");fflush(stdout);

									ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, DMLTaskRelation,&attccidcnt,&attccidTag));
									printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);
							 
									if(attccidcnt>0)
									 {
										for(icnt=0;icnt<attccidcnt;icnt++)
										 {
										    taskobj=attccidTag[icnt];

											if(taskobj)
											{
												ITK_CALL(AOM_ask_value_string(taskobj,"item_id",&taskobjid));
												printf("\n taskobjid is :%s\n",taskobjid);fflush(stdout);

												ITK_CALL(AOM_ask_value_string(taskobj,"object_type",&Taskobject_type));
												 printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
												  if(tc_strstr(taskobjid,"_16")!=NULL)					
												   {															  
													  ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&rel_type1));

													  ITK_CALL(GRM_list_secondary_objects_only(taskobj,rel_type1,&solnobjcnt,&solnobjs));

													  printf("\n solnobjcnt : %d \n", solnobjcnt);fflush(stdout);


                                                        if (solnobjcnt > 0)
                                                        {
                                                        
														  for(k=0;k<solnobjcnt;k++)
														   {
															  solnobj =solnobjs[k];

															  int ChkHillRept =0;
															  int ChkBenchRpt =0;
															  int ChkVehicleRpt =0;

															//tc_strcpy(pdfdocname,"");
															  tc_strcpy(HILdocname,"");
															  tc_strcpy(BenchReport,"");
															  tc_strcpy(VehicleReport,"");
														 
															  ITK_CALL(AOM_ask_value_string(solnobj,"item_id",&solupart));
															  ITK_CALL(AOM_ask_value_string(solnobj,"item_revision_id",&solrevisionid));															 
															  ITK_CALL(AOM_ask_value_string(solnobj,"object_type",&soluobjtp));
															   printf("\n item_id is :%s\n",solupart);fflush(stdout);
															   printf("\n item_revision_id is :%s\n",solrevisionid);fflush(stdout);
															   printf("\n soluobjtp is :%s\n",soluobjtp);fflush(stdout);

															  if(tc_strcmp(soluobjtp,"T5_EE_PartRevision")==0)
															   {
																   ITK_CALL(AOM_ask_value_string(solnobj,"t5_SwPartType",&SwPartType));
																   printf("\n SwPartType is :%s\n",SwPartType);fflush(stdout);

																   if((tc_strcmp(SwPartType,"Container")==0) || (tc_strcmp(SwPartType,"CON")==0))
																   {

																	  ITK_CALL(GRM_find_relation_type("IMAN_reference",&refrel));

																	  ITK_CALL(GRM_list_secondary_objects_only(solnobj,refrel,&refrelcnt,&refrelobjts));

																	  printf("\n refrelcnt : %d \n", refrelcnt);fflush(stdout);

																	  if (refrelcnt>0)
																	  {																		  																		  

																		  for(iref=0;iref<refrelcnt;iref++)
																			{
																			   refrelobjt=refrelobjts[iref];																			

																				ITK_CALL(AOM_ask_value_string(refrelobjt,"object_name",&rptname));
																				printf("\n Report name is :%s\n",rptname);fflush(stdout);
																				
																				tc_strcpy(HILdocname,solupart);										    
																				tc_strcat(HILdocname,"_HIL_Report");	

																				tc_strcpy(BenchReport,solupart);										    
																				tc_strcat(BenchReport,"_Bench_Report");	

																				tc_strcpy(VehicleReport,solupart);										    
																				tc_strcat(VehicleReport,"_Vehicle_Report");	

																				  if(strstr(rptname,HILdocname) != NULL)
																				   {
																					   ChkHillRept=1;
																				   }

																				   if(strstr(rptname,BenchReport) != NULL)
																					{
																					   ChkBenchRpt=1;

																					}

																					if(strstr(rptname,VehicleReport) != NULL)
																					{
																					   ChkVehicleRpt=1;

																					}																																																														
																				
																			}

																			if ((ChkHillRept==0) || (ChkBenchRpt==0) || (ChkVehicleRpt==0))
																			{

																			 
																				if (tc_strstr(containerlist,solupart)!=NULL)
																				{
																					printf("\n data is already in list:[%s]\n",solupart);fflush(stdout);

																				}
																				else
																				{
																				  
																				  tc_strcat(containerlist,solupart);										    
																				  tc_strcat(containerlist," ");	
																				  
																				  
																				}

																			}

																	   }
																	   else
																		{
																		 if (tc_strstr(containerlist,solupart)!=NULL)
																			{
																				printf("\n data is already in list2:[%s]\n",solupart);fflush(stdout);

																			}
																			else
																			{
																			  
																			  tc_strcat(containerlist,solupart);										    
																			  tc_strcat(containerlist," ");	
																			  
																			  
																			}																
																		}



																			
																   }
															   }


														   }//for loop for solution objects	
														}

													printf("\n containerlist:[%s]\n",containerlist);fflush(stdout);
															   																   
													int len = strlen(containerlist);

													printf("\n containerlist length : %d \n",len);fflush(stdout);

													   if (len > 10)
													   {
														tc_strcat(message2,"Container number:");
														tc_strcat(message2,containerlist);

														 printf("\n Report not Found  \n");fflush(stdout);
														  printf("\n %s %s\n",message,message2);fflush(stdout);
													//	EMH_clear_errors();
													//	EMH_store_error_s1(EMH_severity_error,ITK_err, message);			
													//	EMH_store_error_s2(EMH_severity_information,ITK_err,message, message2);						  
													//   decision = EPM_nogo;
													//   return decision;

													   }



											    	}
																									
											}								
											else
											{
												  printf("\nDML Task Not Found \n"); fflush(stdout);

											}

										 }
										
									 }
								}//DR
							
							 }
//*********************************************************************************************************
                           else if(((tc_strcmp(Rel_type,"Gate Maturation")==0)||(tc_strcmp(Rel_type,"TODR")==0)) && (tc_strcmp(info2,"TODR")==0))
						    {
								 if((tc_strcmp(drstatus,"DR3")==0)||(tc_strcmp(drstatus,"AR3")==0))
								 {
									ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&DMLTaskRelation));
									printf("\n after finding DMLTaskRelation \n");fflush(stdout);

									ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, DMLTaskRelation,&attccidcnt,&attccidTag));
									printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);
							 

									if(attccidcnt>0)
									   {
										 for(icnt=0;icnt<attccidcnt;icnt++)
											{
											   taskobj=attccidTag[icnt];

												if(taskobj)
												{
													ITK_CALL(AOM_ask_value_string(taskobj,"item_id",&taskobjid));
													printf("\n taskobjid is :%s\n",taskobjid);fflush(stdout);

													ITK_CALL(AOM_ask_value_string(taskobj,"object_type",&Taskobject_type));
													 printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
													  if(tc_strstr(taskobjid,"_16")!=NULL)					
													   {

														  
														  ITK_CALL(GRM_find_relation_type("CMReferences",&rel_type1));

														  ITK_CALL(GRM_list_secondary_objects_only(taskobj,rel_type1,&solnobjcnt,&solnobjs));

														  printf("\n solnobjcnt : %d \n", solnobjcnt);fflush(stdout);

														 if (solnobjcnt > 0)
														 {
														  


														  for(k=0;k<solnobjcnt;k++)
														   {
															  solnobj =solnobjs[k];
															  int ChkHillRept =0;
															  int ChkBenchRpt =0;
															  int ChkVehicleRpt =0;

															  tc_strcpy(HILdocname,"");
															  tc_strcpy(BenchReport,"");
															  tc_strcpy(VehicleReport,"");
															  

														 														  
															  ITK_CALL(AOM_ask_value_string(solnobj,"object_type",&soluobjtp));
															  														   
															   printf("\n soluobjtp is :%s\n",soluobjtp);fflush(stdout);

															   if(tc_strcmp(soluobjtp,"T5_EE_PartRevision")==0)
															    {
																   ITK_CALL(AOM_ask_value_string(solnobj,"item_id",&solupart));
															       ITK_CALL(AOM_ask_value_string(solnobj,"item_revision_id",&solrevisionid));	
																   ITK_CALL(AOM_ask_value_string(solnobj,"t5_SwPartType",&SwPartType));

																   printf("\n item_id is :%s\n",solupart);fflush(stdout);
															       printf("\n item_revision_id is :%s\n",solrevisionid);fflush(stdout);	
																   printf("\n SwPartType is :%s\n",SwPartType);fflush(stdout);

																   if((tc_strcmp(SwPartType,"Container")==0) || (tc_strcmp(SwPartType,"CON")==0))																		      
																   {

																	ITK_CALL(ITEM_find_item(solupart,&solitemtag));
																	if (solitemtag)
																	{
																	

															        ITK_CALL(ITEM_list_all_revs(solitemtag,&revcnt,&allrevlist));

															        printf("\n revcnt : %d \n", revcnt);fflush(stdout);

															          if (revcnt >0)
															          {
															   							
																	     for(at=0; at<revcnt; ++at)
																	      {
																		
																		     atPrt = allrevlist[at];

																		     //   if((tc_strcmp(SwPartType,"Container")==0) || (tc_strcmp(SwPartType,"CON")==0))
																		      //   {

																					  ITK_CALL(GRM_find_relation_type("IMAN_reference",&refrel));

																					  ITK_CALL(GRM_list_secondary_objects_only(atPrt,refrel,&refrelcnt,&refrelobjts));

																					  printf("\n refrelcnt : %d \n", refrelcnt);fflush(stdout);

																					  if (refrelcnt>0)
																					  {																		  																		  

																						 for(iref=0;iref<refrelcnt;iref++)
																						  {
																							refrelobjt=refrelobjts[iref];																					

																							ITK_CALL(AOM_ask_value_string(refrelobjt,"object_name",&rptname));
																							printf("\n Report name is :%s\n",rptname);fflush(stdout);
																							
																							tc_strcpy(HILdocname,solupart);										    
																							tc_strcat(HILdocname,"_HIL_Report");	

																							tc_strcpy(BenchReport,solupart);										    
																							tc_strcat(BenchReport,"_Bench_Report");	

																							tc_strcpy(VehicleReport,solupart);										    
																							tc_strcat(VehicleReport,"_Vehicle_Report");	

																							  if(strstr(rptname,HILdocname) != NULL)
																							   {
																								   ChkHillRept=1;
																							   }

																							   if(strstr(rptname,BenchReport) != NULL)
																								{
																								   ChkBenchRpt=1;

																								}

																								if(strstr(rptname,VehicleReport) != NULL)
																								{
																								   ChkVehicleRpt=1;

																								}																								
																																														
																								
																							}

																							

																					   }
																					//else
																					//{
																					// tc_strcat(containerlist,solupart);										    
																					// tc_strcat(containerlist,",");																			
																					//}
																					
																		       // }
																		 
																	      }
															         }
														       

																    if ((ChkHillRept==0) || (ChkBenchRpt==0) || (ChkVehicleRpt==0))
																	{
																	 
																	   if (tc_strstr(containerlist,solupart)!=NULL)
																		{
																			printf("\n data is already in list:[%s]\n",solupart);fflush(stdout);

																		}
																		else
																		{
																		  
																		  tc_strcat(containerlist,solupart);										    
																		  tc_strcat(containerlist," ");	
																		  
																		  
																		}

																	}
																   }//if solitemtag
																  }//con

																}//ee

																/////////////////////////////////folder

																if(tc_strcmp(soluobjtp,"Folder")==0)
															    {
																	int FldrObjCount =0;
																	tag_t  *FlderObjs_tag	= NULLTAG;
																	tag_t  FlderObj_tag	= NULLTAG;
																	int fd=0;
																	char* FlderObjtype =NULL;
																	char* FlderObjtypeID =NULL;
																	char* FlderObjrev =NULL;
																	char* FlderObjtSwPartType =NULL;
																   printf("\n Inside Parts For Gate Maturation \n");fflush(stdout);

																   if(FL_ask_references(solnobj,FL_fsc_by_date_modified ,&FldrObjCount,&FlderObjs_tag));
																//    ITK_CALL(AOM_ask_value_tags(solnobj,"contents",&FldrObjCount,&FlderObjs_tag));
																	 printf("\n FldrObjCount : %d \n", FldrObjCount);fflush(stdout);

																   if (FldrObjCount>0)
																   {
																	   for (fd=0;fd<FldrObjCount;fd++)
											                           {

																		 int ChkHillRept =0;
																		 int ChkBenchRpt =0;
																		 int ChkVehicleRpt =0;

																		  tc_strcpy(HILdocname,"");
																		  tc_strcpy(BenchReport,"");
																		  tc_strcpy(VehicleReport,"");

																	    FlderObj_tag = FlderObjs_tag[fd];

																		ITK_CALL(AOM_ask_value_string(FlderObj_tag,"object_type",&FlderObjtype));
															  														   
															            printf("\n FlderObjtype is :%s\n",FlderObjtype);fflush(stdout);

																		if(tc_strcmp(FlderObjtype,"T5_EE_PartRevision")==0)
															            {

																		  ITK_CALL(AOM_ask_value_string(FlderObj_tag,"item_id",&FlderObjtypeID));
																		   ITK_CALL(AOM_ask_value_string(FlderObj_tag,"item_revision_id",&FlderObjrev));	
																		   ITK_CALL(AOM_ask_value_string(FlderObj_tag,"t5_SwPartType",&FlderObjtSwPartType));

																		   printf("\n FlderObjtypeID is :%s\n",FlderObjtypeID);fflush(stdout);
																		   printf("\n FlderObjrev is :%s\n",FlderObjrev);fflush(stdout);	
																		   printf("\n FlderObjtSwPartType is :%s\n",FlderObjtSwPartType);fflush(stdout);



																		   
																		   if((tc_strcmp(FlderObjtSwPartType,"Container")==0) || (tc_strcmp(FlderObjtSwPartType,"CON")==0))																		      
																		   {

																			ITK_CALL(ITEM_find_item(FlderObjtypeID,&solitemtag));
																			if (solitemtag)
																			{
																			

																			ITK_CALL(ITEM_list_all_revs(solitemtag,&revcnt,&allrevlist));

																			printf("\n revcnt : %d \n", revcnt);fflush(stdout);

																			  if (revcnt >0)
																			  {
																								
																				 for(at=0; at<revcnt; ++at)
																				  {
																				
																					 atPrt = allrevlist[at];

																					 //   if((tc_strcmp(SwPartType,"Container")==0) || (tc_strcmp(SwPartType,"CON")==0))
																					  //   {

																							  ITK_CALL(GRM_find_relation_type("IMAN_reference",&refrel));

																							  ITK_CALL(GRM_list_secondary_objects_only(atPrt,refrel,&refrelcnt,&refrelobjts));

																							  printf("\n refrelcnt : %d \n", refrelcnt);fflush(stdout);

																							  if (refrelcnt>0)
																							  {																		  																		  

																								 for(iref=0;iref<refrelcnt;iref++)
																								  {
																									refrelobjt=refrelobjts[iref];																					

																									ITK_CALL(AOM_ask_value_string(refrelobjt,"object_name",&rptname));
																									printf("\n Report name is :%s\n",rptname);fflush(stdout);
																									
																									tc_strcpy(HILdocname,FlderObjtypeID);										    
																									tc_strcat(HILdocname,"_HIL_Report");	

																									tc_strcpy(BenchReport,FlderObjtypeID);										    
																									tc_strcat(BenchReport,"_Bench_Report");	

																									tc_strcpy(VehicleReport,FlderObjtypeID);										    
																									tc_strcat(VehicleReport,"_Vehicle_Report");	

																									  if(strstr(rptname,HILdocname) != NULL)
																									   {
																										   ChkHillRept=1;
																									   }

																									   if(strstr(rptname,BenchReport) != NULL)
																										{
																										   ChkBenchRpt=1;

																										}

																										if(strstr(rptname,VehicleReport) != NULL)
																										{
																										   ChkVehicleRpt=1;

																										}																								
																																																
																										
																									}

																									

																							   }
																							//else
																							//{
																							// tc_strcat(containerlist,solupart);										    
																							// tc_strcat(containerlist,",");																			
																							//}
																							
																					   // }
																				 
																				  }
																			 }

																			
																			 
																	   

																			if ((ChkHillRept==0) || (ChkBenchRpt==0) || (ChkVehicleRpt==0))
																			{
																			 
																			   if (tc_strstr(containerlist,FlderObjtypeID)!=NULL)
																				{
																					printf("\n data is already in list:[%s]\n",FlderObjtypeID);fflush(stdout);

																				}
																				else
																				{
																				  
																				  tc_strcat(containerlist,FlderObjtypeID);										    
																				  tc_strcat(containerlist," ");	
																				  
																				  
																				}

																			}
																		   }//if solitemtag
																		  }//con




																		}



																	   }

																   }

																   


																}//folder


																///////////////////////////////////////////////folder



														   }//for loop for solution objects	
													   }
														   
												       printf("\n containerlist:[%s]\n",containerlist);fflush(stdout);

														int len = strlen(containerlist);

														printf("\n containerlist length : %d \n",len);fflush(stdout);

														if (len > 10)
														   {
															tc_strcat(message2,"Container number:");
															tc_strcat(message2,containerlist);

															 printf("\n Report not Found  \n");fflush(stdout);
															 printf("\n %s %s\n",message,message2);fflush(stdout);
														//	 EMH_clear_errors();
														//	 EMH_store_error_s1(EMH_severity_error,ITK_err, message);			
														//	 EMH_store_error_s2(EMH_severity_information,ITK_err,message, message2);						  
														//	 decision = EPM_nogo;
														//	 return decision;

														   }



													   }
																								
												}								
												else
												{
													  printf("\nDML Task Not Found \n"); fflush(stdout);

												}

											}
									
									  }
								}//DR
							
							 }


//*********************************************************************************************************

                          else if(((tc_strcmp(Rel_type,"Vehicle Release")==0)||(tc_strcmp(Rel_type,"Veh")==0)) && (tc_strcmp(info3,"veh")==0))
						    {
								 if(tc_strcmp(drstatus,"DR3")==0)
								 {

									ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&DMLTaskRelation));
									printf("\n after finding DMLTaskRelation \n");fflush(stdout);

									ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, DMLTaskRelation,&attccidcnt,&attccidTag));
									printf("\n  attccidcnt.:%d\n",attccidcnt);fflush(stdout);							 

									if(attccidcnt>0)
									 {
									   for(icnt=0;icnt<attccidcnt;icnt++)
										{
										   taskobj=attccidTag[icnt];

											if(taskobj)
											{
												ITK_CALL(AOM_ask_value_string(taskobj,"item_id",&taskobjid));
												printf("\n taskobjid is :%s\n",taskobjid);fflush(stdout);

												ITK_CALL(AOM_ask_value_string(taskobj,"object_type",&Taskobject_type));
												printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
												  if(tc_strstr(taskobjid,"_00")!=NULL)					
												   {
													  
													  ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&rel_type1));

													  ITK_CALL(GRM_list_secondary_objects_only(taskobj,rel_type1,&solnobjcnt,&solnobjs));

													  printf("\n solnobjcnt : %d \n", solnobjcnt);fflush(stdout);

													  for(k=0;k<solnobjcnt;k++)
													   {
														  int ChkHillRept =0;
														  int ChkBenchRpt =0;
														  int ChkVehicleRpt =0;


														  solnobj =solnobjs[k];

														  ITK_CALL(AOM_ask_value_string(solnobj,"item_id",&solupart));
														  ITK_CALL(AOM_ask_value_string(solnobj,"item_revision_id",&solrevisionid));																
														  ITK_CALL(AOM_ask_value_string(solnobj,"object_type",&soluobjtp));

														   printf("\n item_id is :%s\n",solupart);fflush(stdout);
														   printf("\n item_revision_id is :%s\n",solrevisionid);fflush(stdout);
														   printf("\n soluobjtp is :%s\n",soluobjtp);fflush(stdout);



														//************************************************
															tag_t rel_type2=NULLTAG;
															tag_t modulelatestrev=NULLTAG;
															tag_t* moduleno=NULLTAG;
															int modulecnt=0;
															char* modulenoname=NULL;
															char* modulerevseq=NULL;
														
															 ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&rel_type2));

															  ITK_CALL(GRM_list_secondary_objects_only(solnobj,rel_type2,&modulecnt,&moduleno));
															  
																if(modulecnt>0)	
																{																																			   														  																 

																	int moduleallrevcount=0;
																	tag_t *modul_rev_list = NULLTAG;
																	tag_t modrev = NULLTAG;
																	char* moduleid =NULL;
																	char* modidrev =NULL;
																	int mi=0;
																	char *modrevrelstus = NULL;


																	ITK_CALL(ITEM_list_all_revs(moduleno[0],&moduleallrevcount,&modul_rev_list));
																	printf("\n moduleallrevcount=%d \n",moduleallrevcount);fflush(stdout);

																	
																	if (moduleallrevcount>0)
																	{
																	

																		 for(mi=moduleallrevcount-1;mi>-1;mi--)
																		  {
																				
																			 printf("\n inside for loop \n ");fflush(stdout);

																			 modrev=modul_rev_list[mi];

																			 ITK_CALL(AOM_ask_value_string(modrev,"item_id",&moduleid));
																			 ITK_CALL(AOM_ask_value_string(modrev,"item_revision_id",&modidrev));
																			 printf("\n moduleid %s \n ", moduleid);fflush(stdout);
																			 printf("\n modidrev %s \n ", modidrev);fflush(stdout);

																	
																			 modrevrelstus = NULL;
																			 ITK_CALL(AOM_UIF_ask_value(modrev,"release_status_list",&modrevrelstus));
																			 TC_write_syslog ( "\n module Release_status : [%s]", modrevrelstus ) ;
																			 printf("\n  module Release_status : [%s]", modrevrelstus );fflush(stdout);

																					
																			 if ( tc_strstr( modrevrelstus,"ERC Released") != NULL )
																			  {
																			   printf("\n latest release found ----- [%s/%s]",moduleid,modidrev); fflush(stdout);																	
																				
																				tag_t	bomline		=	NULLTAG;
																				tag_t	*child		=	NULLTAG;
																				tag_t	window		=	NULLTAG;
																				tag_t	t_revrule	=	NULLTAG;
																				tag_t	itemtag;

																				int		bcount		=	0;
																				int		ib			=	0;
																				char		*child_id		=	NULL;
																				char		*child_revid	=	NULL;
																				char		*child_level						= NULL;
																				char		*swparttype						= NULL;

																				 if(BOM_create_window(&window));
																				  {
																					if(CFM_find("ERC release and above", &t_revrule));
																					if(BOM_set_window_config_rule( window, t_revrule ));
																				//	if(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
																					if(BOM_set_window_pack_all(window, true));
																					if(BOM_set_window_top_line(window,NULLTAG,modrev,NULLTAG,&bomline));
																					 {
																						if(BOM_line_ask_all_child_lines(bomline,&bcount,&child));
																						 {
																							if(bcount > 0)
																							{
																								for(ib = 0 ; ib < bcount ; ib++)
																								{
																									if(AOM_ask_value_string(child[ib],"bl_item_item_id", &child_id));
																									if(AOM_ask_value_string(child[ib],"bl_rev_item_revision_id", &child_revid));
																									if(AOM_UIF_ask_value(child[ib],"bl_level_starting_0", &child_level));
																									if(AOM_UIF_ask_value(child[ib],"bl_T5_EE_PartRevision_t5_SwPartType", &swparttype));												
																								

																									if((tc_strcmp(swparttype,"Container")==0) || (tc_strcmp(swparttype,"CON")==0))
																									{
																										
																										printf("\n Container found :%s,%s/%s",swparttype,child_id,child_revid); fflush(stdout);
																									//	fprintf(fptr,"\n%s,%s,%s",child_level,child_id,child_revid); fflush(stdout);

																										 tc_strcpy(HILdocname,"");
																										 tc_strcpy(BenchReport,"");
																										 tc_strcpy(VehicleReport,"");
																														
																										  int ChkHillRept =0;
																										  int ChkBenchRpt =0;
																										  int ChkVehicleRpt =0;

																										   ITK_CALL(ITEM_find_item(child_id,&itemtag));
																										   if (itemtag)
																										   {
																										   


																											ITK_CALL(ITEM_list_all_revs(itemtag,&revcnt,&allrevlist));

																											printf("\n revcnt : %d \n", revcnt);fflush(stdout);//pending

																												
																											 if (revcnt>0)
																											 {
																												

																												for(at=0; at<revcnt; ++at)
																												{
																													
																													  atPrt = allrevlist[at];

																													  ITK_CALL(GRM_find_relation_type("IMAN_reference",&refrel));

																													  ITK_CALL(GRM_list_secondary_objects_only(atPrt,refrel,&refrelcnt,&refrelobjts));

																													  printf("\n refrelcnt : %d \n", refrelcnt);fflush(stdout);

																													  if (refrelcnt>0)
																													  {																		  																		  

																														  for(iref=0;iref<refrelcnt;iref++)
																															{
																															   refrelobjt=refrelobjts[iref];
																															   ITK_CALL(AOM_ask_value_string(refrelobjt,"object_name",&rptname));
																																printf("\n Report name is :%s\n",rptname);fflush(stdout);
																																
																																tc_strcpy(HILdocname,child_id);										    
																																tc_strcat(HILdocname,"_HIL_Report");	

																																tc_strcpy(BenchReport,child_id);										    
																																tc_strcat(BenchReport,"_Bench_Report");	

																																tc_strcpy(VehicleReport,child_id);										    
																																tc_strcat(VehicleReport,"_Vehicle_Report");	

																																  if(strstr(rptname,HILdocname) != NULL)
																																   {
																																	   ChkHillRept=1;
																																   }

																																   if(strstr(rptname,BenchReport) != NULL)
																																	{
																																	   ChkBenchRpt=1;

																																	}

																																	if(strstr(rptname,VehicleReport) != NULL)
																																	{
																																	   ChkVehicleRpt=1;

																																	}

																														
																															  }
																															

																															

																													   }
																													  
																												  }
																												} 
																									        }
																										   if ((ChkHillRept==0) || (ChkBenchRpt==0) || (ChkVehicleRpt==0))
																											{

																											 

																											   if (tc_strstr(containerlist,child_id)!=NULL)
																												{
																													printf("\n data is already in list:[%s]\n",child_id);fflush(stdout);

																												}
																												else
																												{
																												  
																												  tc_strcat(containerlist,child_id);										    
																											      tc_strcat(containerlist," ");	
																												  
																												  
																												}
																																																															
																											

																											}
																											else
																											{
																												printf("\n Report found on :%s\n",child_id);fflush(stdout);																											}
																	

																									          }
																									childfun(child[ib],containerlist);
																								
																								}


																							}
																							else
																							{
																								printf("No child part is present for %s",moduleid); fflush(stdout);
																							}
																						}
																					}
																					BOM_close_window(window);
																				}

																		//////////////////////////////////////////////////////////////////////cc end
																							
																			  break;
																			 }



																		}
																  }



																	  
																}	
																																								

													   }//for loop for solution objects	
													   
														printf("\n containerlist:[%s]\n",containerlist);fflush(stdout);
														int len = strlen(containerlist);

														printf("\n containerlist length : %d \n",len);fflush(stdout);

														if (len > 10)
														   {
															 tc_strcat(message2,"Container number:");
														     tc_strcat(message2,containerlist);


															  printf("\n Report not Found  \n");fflush(stdout);
															  printf("\n %s %s\n",message,message2);fflush(stdout);
															//  EMH_clear_errors();
															 //EMH_store_error_s1(EMH_severity_error,ITK_err, message);			
															//  EMH_store_error_s2(EMH_severity_information,ITK_err,message, message2);						  
														   //   decision = EPM_nogo;
														   //   return decision;

														   }



												   }
																							
											}								
											else
											{
												  printf("\nDML Task Not Found \n"); fflush(stdout);

											}

										}
										
									}
								}//DR
							
							 }



//*********************************************************************************************************

						}
				 //  }attach
			//}loader bypass
	  }
	}

	printf ("\n--------------HIL_Bench_VehicleRpt Completed--------------------\n");fflush(stdout);
	TC_write_syslog("\n End:ECU HIL_Bench_VehicleRpt.");
//	return decision;

  }
	else
	{
		printf("\n\n\t Login Not Successful\n"); fflush(stdout);
	}
	return 0;
}

void childfun(tag_t child,char* containerlist)
{
	int		count1		=	0;
	int		j		=	0;

	tag_t	*child1		=	NULLTAG;

	char		*child_id1	=	NULL;
	char		*child_revid1	=	NULL;
	char		*subchild_id1	=	NULL;
	char		*subchild_qty	=	NULL;
	char		*swparttype1	=	NULL;

 //    char* message =NULL;
//	 message = (char *)MEM_alloc(500);
//	 tc_strcpy(message,"");
//	 tc_strcpy(message,"Please attach below reports to containers reference folder (Container number__HIL_Report,Container number_Bench_Report,Container number_Vehicle_Report)");
		
//	char* containerlist2 =NULL;
//	containerlist2 = (char *)MEM_alloc(500);
//	tc_strcpy(containerlist2,"");
	
	tag_t	rel_type1 = NULLTAG;
	tag_t	itemtag = NULLTAG;
	tag_t	atPrt = NULLTAG;
	tag_t	refrel = NULLTAG;
	tag_t	refrelobjt = NULLTAG;
	tag_t*	refrelobjts = NULLTAG;
	tag_t*	allrevlist = NULLTAG;
	int		solnobjcnt = 0;
	int		refrelcnt = 0;
	int		iref = 0;
	int		k = 0;
	int		revcnt = 0;
	int		at = 0;

	char* rptname =NULL;
	char* HILdocname =NULL;
	char* BenchReport =NULL;
	char* VehicleReport =NULL;
		
	HILdocname = (char *)MEM_alloc(500);
	BenchReport = (char *)MEM_alloc(500);
	VehicleReport = (char *)MEM_alloc(500);

	if(BOM_line_ask_all_child_lines(child,&count1,&child1));
	{
	
		for(j = 0 ; j < count1 ; j++)
		{
			if(AOM_ask_value_string(child1[j],"bl_item_item_id", &child_id1));
			if(AOM_ask_value_string(child1[j],"bl_rev_item_revision_id", &child_revid1));
			if(AOM_UIF_ask_value(child1[j],"bl_level_starting_0", &subchild_id1));
			if(AOM_UIF_ask_value(child1[j],"bl_quantity", &subchild_qty));
			if(AOM_UIF_ask_value(child1[j],"bl_T5_EE_PartRevision_t5_SwPartType", &swparttype1));
			
			if((tc_strcmp(swparttype1,"Container")==0) || (tc_strcmp(swparttype1,"CON")==0))
			{
				printf("\n Container found2 :%s,%s/%s",swparttype1,child_id1,child_revid1); fflush(stdout);
				fprintf(fptr,"\n%s,%s,%s",subchild_id1,child_id1,child_revid1); fflush(stdout);
													
					tc_strcpy(HILdocname,"");
					tc_strcpy(BenchReport,"");
					tc_strcpy(VehicleReport,"");
						
					int ChkHillRept =0;
					int ChkBenchRpt =0;
					int ChkVehicleRpt =0;

					ITK_CALL(ITEM_find_item(child_id1,&itemtag));

					ITK_CALL(ITEM_list_all_revs(itemtag,&revcnt,&allrevlist));
					for(at=0; at<revcnt; ++at)
					{
						
						atPrt = allrevlist[at];
						

					  ITK_CALL(GRM_find_relation_type("IMAN_reference",&refrel));

					  ITK_CALL(GRM_list_secondary_objects_only(atPrt,refrel,&refrelcnt,&refrelobjts));

					  printf("\n refrelcnt : %d \n", refrelcnt);fflush(stdout);

					  if (refrelcnt>0)
					  {																		  																		  

						  for(iref=0;iref<refrelcnt;iref++)
							{
							    refrelobjt=refrelobjts[iref];
							
								ITK_CALL(AOM_ask_value_string(refrelobjt,"object_name",&rptname));
								printf("\n Report name is :%s\n",rptname);fflush(stdout);
								
								tc_strcpy(HILdocname,child_id1);										    
								tc_strcat(HILdocname,"_HIL_Report");	

								tc_strcpy(BenchReport,child_id1);										    
								tc_strcat(BenchReport,"_Bench_Report");	

								tc_strcpy(VehicleReport,child_id1);										    
								tc_strcat(VehicleReport,"_Vehicle_Report");	

								  if(strstr(rptname,HILdocname) != NULL)
								   {
									   ChkHillRept=1;
								   }

								   if(strstr(rptname,BenchReport) != NULL)
									{
									   ChkBenchRpt=1;

									}

									if(strstr(rptname,VehicleReport) != NULL)
									{
									   ChkVehicleRpt=1;

									}										
																																				
							}
						
					   }
					
			       }

				   if ((ChkHillRept==0) || (ChkBenchRpt==0) || (ChkVehicleRpt==0))
					{
					   					 
					
					   if (tc_strstr(containerlist,child_id1)!=NULL)
						{
							printf("\n data is already in list3:[%s]\n",child_id1);fflush(stdout);

						}
						else
						{
						  
						  tc_strcat(containerlist,child_id1);										    
						  tc_strcat(containerlist," ");	
						  
						  
						}

					}
					else
					{
						printf("\n Report found on :%s\n",child_id1);fflush(stdout);
					}
																				

			}
			

            childfun(child1[j],containerlist);

		
		}
		
	}

		/*   tc_strcat(message,"    Container number:");
			tc_strcat(message,containerlist2);

			int len = strlen(containerlist2);

			printf("\n containerlist2 length : %d \n",len);fflush(stdout);
			


			if (len > 10)
			   {


				 printf("\n Report not Found  \n");fflush(stdout);
				 printf("\n %s \n",message);fflush(stdout);
			//	EMH_clear_errors();
			//	EMH_store_error_s1(EMH_severity_error,ITK_err, message);			
				//EMH_store_error_s2(EMH_severity_information,ITK_err,"Please create a'TDS Tool change form' by selecting the DML.This action will trigger notifications to the tool designer and the customer support team if at least one attribute value is 'Yes'.", message);						  
			//   decision = EPM_nogo;
			//   return decision;

			   }*/


}
