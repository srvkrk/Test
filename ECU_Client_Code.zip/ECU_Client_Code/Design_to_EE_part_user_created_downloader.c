#include <string.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <string.h>
#include <unidefs.h>
#include <stdlib.h>

int                     ifail                           = ITK_ok;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}



int Get_part_Attribute(char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Part_no					= NULL;
	
	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Part_no		    = ITK_ask_cli_argument("-i=");
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = Get_part_Attribute(Part_no);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int Get_part_Attribute(char* Part_no)
{
	
	char* refname=NULL;
char* reftype=NULL;
char *Exfile=NULL;
char *Dataset_name=NULL;

    char *ECU_type= NULL;
	char *SW_part_type= NULL;
	char *Read_write=NULL;
	char*App_EOL_Service = NULL;
	char*Part_Type = NULL;
	char *Part_Status=NULL;
    char *CMVRCert=NULL;
    char *CabitkitApp=NULL;
    char *Obj_Descp=NULL;
    char *Design_group=NULL;
    char *Category_Name=NULL;
    char *LHRH_ind=NULL;
    char *Material_class=NULL;
    char *Model_ind=NULL;
    char *Spare_ind=NULL;
    char *Proj_code=NULL;
	tag_t* Release_status_list=NULL;
	tag_t Release_status=NULL;
    char *UOM=NULL;
	char *class=NULL;
	char *class_name=NULL;
	char *EE_Part_Type=NULL;
	char* status_name=NULL;
	char*errortext=NULL;
	char temp[500];
	int ifail = ITK_ok;
	tag_t Qry_tag = NULLTAG;
	tag_t* Obj_tag = NULLTAG;
	tag_t* datasetobj2 = NULLTAG;
	tag_t* datasetobj1 = NULLTAG;
	tag_t item=NULLTAG;
	tag_t revtag=NULLTAG;
	tag_t type_tag=NULLTAG;
	tag_t create_input_tag=NULLTAG;
	tag_t EE_part_tag=NULLTAG;
	tag_t spec_rel_type =NULLTAG;
	tag_t rend_rel_type =NULLTAG;
	tag_t Datasetobj3=NULLTAG;
	tag_t Datasetobj4=NULLTAG;
	tag_t class_id=NULLTAG;
	tag_t Named_ref_obj=NULLTAG;
	int	count=0;
	int i=0;
	int ii=0;
	int iii=0;
	int j=0;
	int DsCnt=0;
	int DsCnt1=0;
	char* creation_date=NULL;
	int status_count=0;
	char* Eff_dates=NULL;
	char* Rlz_date=NULL;
	char* revseq=NULL;
	char* Filename_2=NULL;
	Filename_2=(char *) MEM_alloc(100);
	tc_strcpy(Filename_2,"");
	tc_strcpy(Filename_2,Part_no);
	tc_strcat(Filename_2,"_Rlz.txt");
	
	
	char* Filename_1=NULL;
Filename_1=(char *) MEM_alloc(100);
tc_strcpy(Filename_1,"");
tc_strcpy(Filename_1,Part_no);
tc_strcat(Filename_1,"_input.txt");
     printf("\nFilename1: %s", Filename_1);
	 printf("\nFilename2: %s", Filename_2);

char* startDate;
char* End_date;
char* Date_1=NULL;
char* Date_2=NULL;
char* Date_A=NULL;
char* Date_B=NULL;
char* D1=NULL;
char* M1=NULL;
char* Y1=NULL;
char* Y11=NULL;
char* Y12=NULL;

char* D2=NULL;
char* M2=NULL;
char* Y2=NULL;
char* cMonth1=NULL;
char* cMonth2=NULL;
char* NR_Filename=NULL;

FILE* fp = NULL;
FILE* fp1 = NULL;
//tag_t rev_object_creation_date=NULL;

logical is_it_null=false;
logical is_it_empty=false;

	
cMonth1=(char *) MEM_alloc(50);
                   cMonth2=(char *) MEM_alloc(50);
                   startDate =(char *) MEM_alloc(50);
                   End_date=(char *) MEM_alloc(50);
                   Date_1=(char *) MEM_alloc(50);
                   Date_2=(char *) MEM_alloc(50);


	fp = fopen(Filename_2,"w");
	fp1 = fopen(Filename_1,"w");
	fprintf(fp,"Part_no,revseq,status_name,Eff_dates,Rlz_date\n");
				ITK_CALL(ITEM_find_item(Part_no,&item));
		        ITK_CALL(ITEM_list_all_revs(item,&count,&Obj_tag));
		         printf("\nObject Found : %d", count);
				 if(count>0)
			        {
				 for(i=0;i<count;i++)
				 {
			        
				       revtag=Obj_tag[i];
				       ifail = AOM_ask_value_string(revtag,"item_revision_id",&revseq);
				       printf("\nRev Seq of revision :%s",revseq);
					   ifail = WSOM_ask_release_status_list	(revtag,&status_count,&Release_status_list);
					   printf("\nstatus count:%d",status_count);
					   if(status_count>0)
					   {
					   for(ii=0;ii<status_count;ii++)
					   {
				   
				   
				   Release_status=Release_status_list[ii];
				   ITK_CALL(RELSTAT_ask_release_status_type(Release_status,&status_name));
				   printf("\nRelease Status:%s",status_name);
				   
				   
				   
				   AOM_UIF_ask_value(Release_status,"effectivity_text",&Eff_dates);
				   AOM_UIF_ask_value(Release_status,"date_released",&Rlz_date);
				   printf("\nEff_dates:%s",Eff_dates);
				   
				   AOM_UIF_ask_value(revtag,"creation_date",&creation_date);
				    printf("\ncreation_date:%s",creation_date);
				   
				    Date_1 = strtok(Eff_dates," ");
				    Date_A = strtok(NULL," ");
				    Date_B = strtok(NULL," ");
				    Date_2 = strtok(NULL," ");
				printf("\nDate_1 :%s Date_2 :[%s]",Date_1,Date_2);
				  
				  D1=strtok(Date_1,"-");
				  M1=strtok(NULL,"-");
				  Y1=strtok(NULL,"-");
				  
				  Y11=strtok(Y1," ");
				  Y12=strtok(Y2," ");
				  
				   printf("\nDate:%s Month:%s Year:%s",D1,M1,Y11);
				 if(tc_strcmp(M1,"Jan")==0) {tc_strcpy(cMonth1,"1");}
                  else if(tc_strcmp(M1,"Feb")==0) {tc_strcpy(cMonth1,"2");}
                  else if(tc_strcmp(M1,"Mar")==0) {tc_strcpy(cMonth1,"3");}
                  else if(tc_strcmp(M1,"Apr")==0) {tc_strcpy(cMonth1,"4");}
                  else if(tc_strcmp(M1,"May")==0) {tc_strcpy(cMonth1,"5");}
                  else if(tc_strcmp(M1,"Jun")==0) {tc_strcpy(cMonth1,"6");}
                  else if(tc_strcmp(M1,"Jul")==0) {tc_strcpy(cMonth1,"7");}
                  else if(tc_strcmp(M1,"Aug")==0) {tc_strcpy(cMonth1,"8");}
                  else if(tc_strcmp(M1,"Sep")==0) {tc_strcpy(cMonth1,"9");}
                  else if(tc_strcmp(M1,"Oct")==0) {tc_strcpy(cMonth1,"10");}
                  else if(tc_strcmp(M1,"Nov")==0) {tc_strcpy(cMonth1,"11");}
                  else if(tc_strcmp(M1,"Dec")==0) {tc_strcpy(cMonth1,"12");}
				  startDate=tc_strcpy(startDate,Y11);
				  startDate=tc_strcat(startDate,"/");
				  startDate=tc_strcat(startDate,cMonth1);
				  startDate=tc_strcat(startDate,"/");
				  startDate=tc_strcat(startDate,D1);
				printf("\nStart Date:%s",startDate);
				
				  if(tc_strcmp(Date_2,"UP")!=0)
				  {
				  D2=strtok(Date_2,"-");
				  M2=strtok(NULL,"-");
				  Y2=strtok(NULL,"-");
				 printf("\nDate:%s Month:%s Year:%s",D2,M2,Y2);
				 
				  if(tc_strcmp(M2,"Jan")==0) {tc_strcpy(cMonth2,"1");}
                  else if(tc_strcmp(M2,"Feb")==0) {tc_strcpy(cMonth2,"2");}
                  else if(tc_strcmp(M2,"Mar")==0) {tc_strcpy(cMonth2,"3");}
                  else if(tc_strcmp(M2,"Apr")==0) {tc_strcpy(cMonth2,"4");}
                  else if(tc_strcmp(M2,"May")==0) {tc_strcpy(cMonth2,"5");}
                  else if(tc_strcmp(M2,"Jun")==0) {tc_strcpy(cMonth2,"6");}
                  else if(tc_strcmp(M2,"Jul")==0) {tc_strcpy(cMonth2,"7");}
                  else if(tc_strcmp(M2,"Aug")==0) {tc_strcpy(cMonth2,"8");}
                  else if(tc_strcmp(M2,"Sep")==0) {tc_strcpy(cMonth2,"9");}
                  else if(tc_strcmp(M2,"Oct")==0) {tc_strcpy(cMonth2,"10");}
                  else if(tc_strcmp(M2,"Nov")==0) {tc_strcpy(cMonth2,"11");}
                  else if(tc_strcmp(M2,"Dec")==0) {tc_strcpy(cMonth2,"12");}
				  End_date=tc_strcpy(End_date,Y2);
				  End_date=tc_strcat(End_date,"/");
				  End_date=tc_strcat(End_date,cMonth2);
				  End_date=tc_strcat(End_date,"/");
				 End_date=tc_strcat(End_date,D2);
				  
				 printf("\nEnd Date:%s",End_date);
				  }
				  else
				  {
					  End_date=strcpy(End_date,"9999/12/31");
					  }
				  
			
				   
				   fprintf(fp,"%s^%s^%s^%s^%s^%s^%s^\n",Part_no,revseq,status_name,startDate,End_date,Rlz_date,creation_date);
				   fprintf(fp1,"%s^%s^\n",Part_no,revseq);
				   
				}
		     }
				 
			        }
					
			}
				    else
				    {
				    printf("\nObject not found :%d",Part_no);
				   	}
		        
			fclose(fp1);
			fclose(fp);
	    
			  

	
	return ifail;
}

