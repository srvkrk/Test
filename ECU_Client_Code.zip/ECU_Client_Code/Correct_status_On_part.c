
/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Prasad Sagare
*  Module                :   TCUA DML Released having Stamp other than ERC Released should be removed.
*  Code                  :   FindFolder.c
*  Created on			 :   23th Oct 2023
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include  <time.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

FILE		*fp 			= NULL;
FILE		*fpC 			= NULL;

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
	

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dml						= NULL;
	char			* latest_rev_Rel_Stus1					= NULL;
	char			* Part					= NULL;
	char			* Rev					= NULL;
	char			* Seq					= NULL;
	char			* RevSeqCat1					= NULL;
	char			* IteamNumberone					= NULL;
	tag_t		* relStatus_list					= NULL;
	tag_t		item						=	NULLTAG;
	//tag_t		item						=	NULLTAG;
	tag_t		AssemoneQuery			= NULLTAG;
	tag_t		IteamprintTag			= NULLTAG;
	tag_t*		t_allrevdocs			= NULLTAG;
	tag_t attRelStatus = NULLTAG;
	char *qry_entries[2] = {"Item ID","Revision"};
	char **valuesone             = NULL;
	int	n_rev_entries = 2;
	int n_tags_found1 =0;
	int It =0;
	int k1 =0;
	int status_count =0;
	char *Liststamp =NULL;
	tag_t status_review = NULLTAG;

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Part		= ITK_ask_cli_argument("-Part=");
	Rev		= ITK_ask_cli_argument("-Rev=");
	Seq		= ITK_ask_cli_argument("-Seq=");
	//dml				= ITK_ask_cli_argument("-i=");

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	//printf("\nBefor CorrectpartLRlzst call Filename[%s] \n\n",Filename);

	//FindFolder(dml);
	//ifail = CorrectDMLRlzst(Filename);
	printf("\nBefor GetLastSevDayRelDML call \n\n");
	RevSeqCat1 = (char *)MEM_alloc(50);
	tc_strcpy(RevSeqCat1, Rev);
	tc_strcat(RevSeqCat1, "*");
	tc_strcat(RevSeqCat1, Seq);
	valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
	valuesone[0] = (char *)MEM_alloc( strlen( Part ) + 1);
	tc_strcpy(valuesone[0], Part);
	ITK_CALL(ITEM_find_item(Part,&item));
	valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
	tc_strcpy(valuesone[1], RevSeqCat1);
	QRY_find2("Item Revision...", &AssemoneQuery);
	printf("\nafter Iteam revision\n");fflush(stdout);
	if (AssemoneQuery!=NULLTAG)
		{
		printf("\nInside first part tag\n");fflush(stdout);
		QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs);
		if (n_tags_found1>0)
		{
			for (It=0;It<n_tags_found1 ;It++)
				{

					IteamprintTag=t_allrevdocs[0];
					//t5RefPartNumberS = "";
					ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_string",&IteamNumberone));
					printf("\n first part of module is %s\n",IteamNumberone);fflush(stdout);
					if (IteamprintTag!=NULLTAG)
					{
						ifail = WSOM_ask_release_status_list(IteamprintTag, &status_count, &relStatus_list);
						printf("\n\t WSOM_ask_release_status_list count is :: %d\n",status_count);fflush(stdout);
						if (status_count > 1)
						{
							for (k1=0;k1 < status_count; k1++)
								{
									ifail = AOM_UIF_ask_value(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus1);
									printf("\n\t %d. Release status is : %s>>>>>>>>>\n",k1,latest_rev_Rel_Stus1);fflush(stdout);
									if ((tc_strcmp(latest_rev_Rel_Stus1,"ERC Review")==0) || (tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsReview")==0) || (tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsReview")==0))
									{
										printf("\n\t ERC working status found for the part : %s\n",IteamNumberone);fflush(stdout);
										(AOM_refresh(IteamprintTag,1));
										CHECK_FAIL(ITK_set_bypass(true));
										CHECK_FAIL(POM_attr_id_of_attr("release_status_list","ChangeRequestRevision",&attRelStatus));
										CHECK_FAIL(POM_refresh_instances_any_class(1,&IteamprintTag, POM_modify_lock));
										CHECK_FAIL(POM_clear_attr(1,&IteamprintTag,attRelStatus));
										CHECK_FAIL(POM_save_instances(1,&IteamprintTag,true));
										CHECK_FAIL(POM_refresh_instances_any_class(1,relStatus_list,POM_delete_lock));
										CHECK_FAIL(POM_delete_instances(1,relStatus_list));
										(AOM_refresh(IteamprintTag,0));
										break;
									}
								}
							
						}
					}
			   }

		   }
		}
	return 0;
}
