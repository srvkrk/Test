/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);
int IsCCIDLatest(char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//ifail = ITK_init_module(userid, password, group);
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput Item_id:%s",item_id);
				
				ifail = check_rel_status(item_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id)
{

		tag_t *attachments	   = NULLTAG;
		tag_t DMLTaskTag	   = NULLTAG;
		tag_t rootTask		   = NULLTAG;
		char *CurrentTask		= NULL;
		char *BusUnitDV			= NULL;
		char *DMLDRdvp			= NULL;
		char *dmlNo             =NULL;
		char* DMLtype		    = NULL;
		char* Taskobj_type	    = NULL;
		char *TskNmMdm			=  NULL;
		char  *Partnumber       = NULL;
		char   *Prt_object_type =NULL;
		char *DatasetName	    = NULL;
		char  *mdmclass_name;

		tag_t    Cciditemrev   = NULLTAG;

		char    *str		    = NULL;
		tag_t	*DMLObj		    = NULLTAG;
		int ifail;
		int status;
		int iStatus			=0;
		char	*Rel_type   = NULL;

		tag_t	MdmDMLRevTag		= NULLTAG;
		tag_t	ProQryObj			= NULLTAG;
		tag_t	ProQryContObj		= NULLTAG;
		tag_t   MdmDMLToTaskRel	    = NULLTAG;
		tag_t	MdmDML_tag			= NULLTAG;
		tag_t   class_id            =NULLTAG;
		tag_t  *MdmTsk_objects	    = NULLTAG;
		tag_t  *MdmPartsTag          =NULLTAG;
		tag_t	Mdm_tsk_rel		    = NULLTAG;
		tag_t	DesignrMdmTag		= NULLTAG;
		tag_t	part_tsk_relc		    = NULLTAG;

		int     noAttachment      = 0;
		int     Mdmtsk_cnt		  = 0;
		int     tt		          = 0;
		int     partcnt		       = 0;

		char * username				= NULL;
		char * parent_name			= NULL;
		char * dmlTaskNo			= NULL;
		int		newccidcnt			= 0;
		int		AttachmentCount	    = 0;
		int		partcntrf	        = 0;
		int		pr					= 0;

		int	n_entriesMdm = 2;
		int n_foundMdm = 0;
		int p = 0;
		char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
		char *qry_valuesMdm[2]  = {"CCU", "DML"};
		tag_t   *MdmCtrObj      = NULLTAG;
		tag_t   *PartsTagrf       = NULLTAG;
		tag_t  TagMdmControl     = NULLTAG;
		tag_t	DesignrevTagR	 = NULLTAG;
		tag_t  reln_typeMdm       = NULLTAG;
		tag_t  Mdmrelation        =NULLTAG;

		//

		char*	Cciditem_rev  = NULL;
		char *  PartItemRevIdSn =NULL;
		tag_t	 HasSnapshotType	  = NULLTAG;
		tag_t*	 snapchild				= NULL;
		tag_t  *addPartsTag          =NULLTAG;
		tag_t	 SnChild			  = NULLTAG;
		tag_t	 Part_tobeAdd	    = NULLTAG;
		tag_t	CcidADDTag		= NULLTAG;
		int		CCID 	        = 0;
		int		snapcount 	        = 0;
		int		sn 	        = 0;

		int		partaddcnt				= 0;
		int		z				= 0;
			tag_t *ccidTagrf=NULLTAG;
				char *  PartItemIdSn      =NULL;
		char  *AddPartnumber       = NULL;
			char  *ErrorText       = NULL;


		ITK_CALL(POM_get_user_id (&username));
		printf("\n Inside the CCU_DML DMLworkflow Session User is : %s \n",username); fflush(stdout);

		//if((tc_strcmp(username,"infodba") !=0) && (tc_strcmp(username,"loader") !=0))
		//{
			//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			//printf("\n Inside the CCU_DML DMLworkflow  ...\n");fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
			//printf("\n CCU_DML DMLworkflow - CurrentTask: %s \n",CurrentTask);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
			//printf("\n CCU_DML DMLworkflow - Parent Name: %s \n",parent_name);fflush(stdout);

			//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
			//printf("\n CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);

			int		count			=0;
			tag_t	item_tag		= NULLTAG;
			tag_t	*rev_list		= NULL;

			ifail = ITEM_find_item (item_id, &item_tag);
			CHECK_FAIL;
			
			ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
			CHECK_FAIL;	

		   if(count > 0)
			{
				printf("\n Inside for --CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
				DMLTaskTag = rev_list[0];

				if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
				printf("\n CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

				if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();

				if (MdmDML_tag != NULLTAG)
				{
				  printf("\n DML tag is not null for CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

				  if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

				  if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
				  printf("\n for CCU DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);
	//
	//			   ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
	//			   printf("\n CCU DML business unit for :%s \n",BusUnitDV);fflush(stdout);
	//
	//				ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_PlntToPlnt",&DMLDRdvp));
	//				printf("\n CCU Plant to plant  :%s \n",DMLDRdvp);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
					printf("\n CCU DML number for DVP :%s \n",dmlNo);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&DMLtype));
					printf("\n CCU DML Release type for DVP :%s \n",DMLtype);fflush(stdout);

					printf("\n  Inside the CCU DML - \n");fflush(stdout);

					if(QRY_find2("ControlObjQry", &TagMdmControl));

					if(QRY_execute(TagMdmControl, n_entriesMdm, qry_entriesMdm, qry_valuesMdm, &n_foundMdm, &MdmCtrObj));
					printf("\n Control Object found for CCU DML == %d \n", n_foundMdm);fflush(stdout);

					if(n_foundMdm==1)
					{
						printf("\n As Control Object found for CCU DML == %d  \n", n_foundMdm);fflush(stdout);

					  ITK_CALL(POM_class_of_instance(MdmDMLRevTag,&class_id));
					  ITK_CALL(POM_name_of_class(class_id,&mdmclass_name));
					  printf("\n Inside the CCU DML class_name of Task :%s \n",mdmclass_name);fflush(stdout);

					  ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
					  ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

					  printf("\n Finding the CCU DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);

					   if (Mdmtsk_cnt>0)
					  {
						  printf("\n Inside task count for CCU DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);

						 for (tt=0;tt<Mdmtsk_cnt ;tt++ )
						{
							 printf("\n Now inside the task find as Task count is for CCU DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
							 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[tt],"object_type",&Taskobj_type));
							 printf("\n Now CCU DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

							 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[tt],"item_id",&TskNmMdm));
							 printf("\n Now CCU DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);

							// part remmoval

														 //ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &Mdm_tsk_rel));
							 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Mdm_tsk_rel));


							 if (Mdm_tsk_rel!=NULLTAG)
							 {
							   printf("\n Has solution item relationship found \n");fflush(stdout);
							   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Mdm_tsk_rel, &partcnt, &MdmPartsTag));
							   printf("\n  No of part attached to task in ccu DML -: %d \n",partcnt);fflush(stdout);

								if (partcnt>0)
								{
								   printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partcnt);fflush(stdout);
								   for (p=0;p<partcnt;p++)
								   {
										DesignrMdmTag=MdmPartsTag[p];
										Partnumber =(char *) MEM_alloc(20 * sizeof(char *));
										if( AOM_ask_value_string(DesignrMdmTag,"item_id",&Partnumber)!=ITK_ok);

										printf("\n Part attached to task Revision Number- [%s]  \n",Partnumber); fflush(stdout);

										//ITK_CALL(GRM_find_relation_type("CMReferences", &part_tsk_relc));
										//ITK_CALL(GRM_find_relation_type("IMAN_reference", &part_tsk_relc));
										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_relc));
										printf("\n Forccu -Expanding CMHasSolutionItem  expanded \n"); fflush(stdout);

										 if (part_tsk_relc!=NULLTAG)
										 {
										   printf("\n Forccu Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

										   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
										   printf("\n Forccu Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

										   if (partcntrf>0)
											 {
											   for (pr=0;pr<partcntrf;pr++)
												 {
													printf("\n Inside Dataset found forccu  \n"); fflush(stdout);
													DesignrevTagR=PartsTagrf[pr];

													if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
													printf("\n In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

													if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
													printf("\n  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

													ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
													printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

													 ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
													 printf("\n Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
													
													if(CCID > 0)
													{
															 ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
														printf("\n  snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

														printf("\n 444  CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

														if(snapcount >0)
														{
															 for (sn=0;sn<snapcount;sn++)
															 {
																SnChild=snapchild[sn];

																	if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
																	printf("\n Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout);

																	if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);//JULY 28
																	printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);//JULY 28

																	printf("\n Part number attached to task -> %s \n", Partnumber);fflush(stdout);//JULY 28

																	if(tc_strcmp(PartItemIdSn,Partnumber)==0)
																	{
																		printf("\n  As name is same  ------->  \n");fflush(stdout);


																		ITK_CALL(AOM_lock(ccidTagrf[0]));
																		ITK_CALL(FL_remove(ccidTagrf[0],SnChild));
																		printf("\n  after fl remove AA \n");fflush(stdout);

																		ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));

																		ITK_CALL(AOM_refresh(ccidTagrf[0],0));

																		ITK_CALL(AOM_unlock(ccidTagrf[0]));

																		printf("\n  Relation OF nr part deleted in Snapshot\n");fflush(stdout);
																		break;

																	}

															 }

														}
													}
													else 
													{
														printf("\n  No snapshot Found...\n");fflush(stdout);
													}
													
												 }
											 }
											 else
											 {
												 printf("\n Else no  Dataset attached to refrence folder in MDM .:%d \n",partcntrf);fflush(stdout);
											 }

										 }
									}

								 }
								 else
								 {
									printf("\n Else No part found inccu  attached to task -: %d \n",partcnt);fflush(stdout);
								 }

							 }



							 //part addition


							 ITK_CALL(GRM_find_relation_type("EC_reference_item_rel", &Part_tobeAdd));

							   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));
							   printf("\n  No of part attached to task in  CCU DML  -: %d \n",partaddcnt);fflush(stdout);

								if (partaddcnt>0)
								{
								   printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);
								   for (z=0;z<partaddcnt;z++)
								   {
										CcidADDTag=addPartsTag[z];
										AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
										if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);

										printf("\n CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

										//ITK_CALL(GRM_find_relation_type("IMAN_reference", &part_tsk_relc));
										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_relc));
										printf("\n Part addition code-Expanding CMHasSolutionItem expanded \n"); fflush(stdout);

										 if (part_tsk_relc!=NULLTAG)
										 {
										   printf("\n Part addition code Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

										   ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
										   printf("\n Part addition code Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

										   if (partcntrf>0)
											 {
											   for (pr=0;pr<partcntrf;pr++)
												 {
													printf("\n Part addition code -Inside Dataset found for MDM DML  \n"); fflush(stdout);
													DesignrevTagR=PartsTagrf[pr];

													if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
													printf("\n Part addition code In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

													if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
													printf("\n  Part addition code ccid  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

									////////////////////////////



										ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
										printf("\n Part addition code - finding HasSnapshotType \n");fflush(stdout);

										 ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
										 printf("\n Part addition code -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);
										
										if(CCID > 0)
										{
											ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
											printf("\n Part addition code- snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

											printf("\n 444  CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);



											ITK_CALL(AOM_lock(ccidTagrf[0]));

											//ITK_CALL(FL_insert(ccidTagrf[0],CcidADDTag,999));//new added
											ifail = FL_insert(ccidTagrf[0],CcidADDTag,999);
											if(ifail != ITK_ok)
                                            {
												ITK_CALL(AOM_unlock(ccidTagrf[0]));
												EMH_ask_error_text(ifail,&ErrorText);
											}
											else
											{
												printf("\n  Part addition code- after fl add AA \n %d",ifail);fflush(stdout);

												ITK_CALL(AOM_save_without_extensions(ccidTagrf[0]));

												ITK_CALL(AOM_refresh(ccidTagrf[0],0));

												ITK_CALL(AOM_unlock(ccidTagrf[0]));

												printf("\n  Relation OF nr part added in Snapshot\n");fflush(stdout);
											}
										}
										else 
										{
											printf("\n  No snapshot found\n");fflush(stdout);
										}
										 

								}

							 }

						   }
						 }

					  }



						}

					  }

					}
					else
					{
						printf("\n Else no  Control Object Not found for CCU DML == %d  \n", n_foundMdm);fflush(stdout);
					}

				}
		   }
	//	}

	return ITK_ok;
}
