	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int tm_ECURefSnapshot(char*);
int Getcontrolobjinfo(tag_t*,char*,int);
void FindLatestVCID(tag_t*,int , tag_t*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}
int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;

	//tmp = sizeof(*strset);

	for(j=0;j<*count;j++)
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;

	}
	return -1;
 }
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = tm_ECURefSnapshot(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int tm_ECURefSnapshot(char* dml_No)
{
	int ifail = ITK_ok;

	//tag_t priObjTag		= NULLTAG;
	//tag_t priObjTypeTag	= NULLTAG;
	tag_t *attachments		= NULLTAG;
	tag_t DMLTaskTag		= NULLTAG;
	tag_t user_tag			= NULLTAG;
	tag_t rootTask			= NULLTAG;
	tag_t DMLRevTag			= NULLTAG;
	char *CurrentTask		= NULL;
	char * parent_name		= NULL;
	char *username			= NULL;
	char *taskTempLT		= NULL;
	char *dmlTaskNo			= NULL;
	char *type_name1        = NULL;
	char* Rel_type			= NULL;
	char *DMLNo				= NULL;
	tag_t DML_tag			= NULLTAG;
	//tag_t *Pendingtasks	= NULLTAG;
	int   noAttachment      = 0;

	char	 *DML_item				 = NULL;
	char	 *PartNo				 = NULL;
	char	 *RevIDNo				 = NULL;
	char	 *Mod_no				 = NULL;
	char	 *ModRevNo				 = NULL;

	char*    partno					 = NULL;
	char*    partno1				 = NULL;
	char*    PartType				 = NULL;
	char*    MPartType				 = NULL;
	char*    MPartNo				 = NULL;
	char*    SSRead					 = NULL;
	char*    MRevIDNo				 = NULL;
	char*    ModuleNo				 = NULL;
	char*	 Cciditem_rev			 = NULL;
	char*	 CcidSeq				 = NULL;
	//char	 jobName[30];
	char*	 CCIDNo					 = NULL;
	char*	 PartNumber				 = NULL;
	char*	 MPartNumber			 = NULL;
	char*	 NewModule				 = NULL;
	char*	 SnapshotNo				 = NULL;

	tag_t	 snapshot				 = NULLTAG;
	//tag_t	 SnapshotRelationType	 = NULLTAG;
	tag_t	 HasRefCCIDRelType		 = NULLTAG;
	tag_t	 HasSnapshotType		 = NULLTAG;
	tag_t	 HasNewCCIDRelType		 = NULLTAG;
	tag_t	 Rel_task				 = NULLTAG;
	tag_t	 IsMemberOfCCID			 = NULLTAG;
	tag_t	 IsMemberOfCCIDx		 = NULLTAG;
	tag_t	 IsMemberOfCCID_Rel		 = NULLTAG;

	tag_t    DesignrevTag			 = NULLTAG;
	//tag_t    FinalModuleTag		 = NULLTAG;
	//tag_t    Latestrev			 = NULLTAG;
	tag_t	 top_line;
	tag_t	*children;
	tag_t	 window;

	char	**SSDetails				 = NULL;

	int   n_tags_found				 = 0;
	int   n_tags_found1				 = 0;
	int   membercnt					 = 0;
	int   membercnt0				 = 0;
	int   n_rev						 = 0;
	int	  status;
	int	  cnt;
	int   tsk_cnt					 = 0;
	int   p							 = 0;
	int   t							 = 0;
	int   ss						 = 0;
	int   sr						 = 0;
	int   partcnt					 = 0;
	int   *levels					 = 0;
	int   SSDetRead					 = 0;
	int   CCIDcnt					 = 0;
	int   cc						 = 0;
	int   iWrite					 = 0;
	int	  n_parents				     = 0;

	tag_t DMLToTaskRel				 = NULLTAG;
	tag_t *PartsTag					 = NULLTAG;

	tag_t *Tsk_objects				 = NULLTAG;
	char* Taskobject_type			 = NULL;
	char* ReleaseType				 = NULL;
	char* MReleaseType				 = NULL;
	char* NewModuleNum				 = NULL;
	char* NewModulerev				 = NULL;
	char* NewModulerev1				 = NULL;
	char*	NewCCID					 = NULL;

	char *DMLprojcode				 = NULL;
	tag_t	ProQryContObj			 = NULLTAG;
	char	*info1					 = NULL;
	char	*BlItemIDNew			 = NULL;
	char	*BlItemID				 = NULL;
	char	*BlRevID				 = NULL;
	char	*BlItemIDNum			 = NULL;
	char	*BlItemIDseq			 = NULL;
	char	*BlLatestItemID			 = NULL;

	tag_t *ProjCnObj				 = NULLTAG;
	int		n_Input					 = 2;
	int    ProjCount				 = 0;
	int    CheckFlag				 = 0;
	int    bl						 = 0;
	int	  iBlItemIDseq				 = 0;
	char	*qry_Input[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_ProjVal[2] = {"CCID", "PROJCT"};

	tag_t 	part_tsk_rel			 = NULLTAG;
	tag_t 	ModuleTag				 = NULLTAG;
	tag_t 	BLrevTag				 = NULLTAG;
	tag_t 	BLrevTagLatest			 = NULLTAG;
	tag_t 	RevRuleTag				 = NULLTAG;

	tag_t   *parents				 = NULL;
	tag_t   *memberTag				 = NULL;
	//tag_t   CcidMstr				 = NULLTAG;
	tag_t   Cciditem				 = NULLTAG;
	tag_t   CCIDRefRel_task		     = NULLTAG;
	tag_t	t_previousRevision		 = NULLTAG;

	tag_t  *CCIDattachments			 = NULLTAG;
	tag_t  *memberattachments		 = NULLTAG;
	tag_t  *memberattachments0		 = NULLTAG;
	tag_t   object_create_input_tag	 = NULLTAG;
	tag_t   CCIDdata_type_tag		 = NULLTAG;
	tag_t	CCIDItemtag				 = NULLTAG;
	tag_t	latest_Cciditem			 = NULLTAG;
	tag_t	NewModuleTag			 = NULLTAG;
	//tag_t	item_tag				 = NULLTAG;
	tag_t	Mod_tag					 = NULLTAG;
	tag_t	Mod_tag1				 = NULLTAG;
	tag_t	BLTagLatest				 = NULLTAG;
	tag_t	*tags_found				 = NULL;
	tag_t	*tags_found1			 = NULL;
	tag_t LatestblRev				 = NULLTAG;

	tag_t 	BLMstTag				 = NULLTAG;//NEW

	//added on 19 may
	tag_t	CCVCrelation_typeN	= NULLTAG;
	tag_t	*ModattachmentsN		= NULLTAG;
	int		ModcntN               = 0;

	//end

	SSDetails = (char**)MEM_alloc( 1 * sizeof *SSDetails );

//	char cCurrentAccessDate[20]={0};
//
//	tag_t object = va_arg(args, tag_t);// object of handler task
//
//	if (GRM_ask_primary (object,&priObjTag)!=ITK_ok);
//	if (TCTYPE_ask_object_type(priObjTag,&priObjTypeTag)!=ITK_ok);
//	if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
//	printf("\n tm_ECURefSnapshot::pri_type_name :%s\n", type_name1);fflush(stdout);

	//POM_get_user(&username,&user_tag); JULY 28
	//printf("\n tm_ECURefSnapshot :%s....\n",username);fflush(stdout);JULY 28

	ITK_CALL(POM_get_user_id (&username));//JULY28
	printf("\n\n  Session login User1 : %s\n",username); fflush(stdout);//JULY 28
	
	//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	//printf("\n tm_ECURefSnapshot...");fflush(stdout);

	
	//CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	//printf("\n tm_ECURefSnapshot CurrentTask: %s",CurrentTask);fflush(stdout);

	//CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	//printf("\n tm_ECURefSnapshot Parent Name: %s",parent_name);fflush(stdout);

	//	getCurrentDateTime(cCurrentAccessDate);
	//	printf("\n tm_ECURefSnapshot cCurrentAccessDate : %s",cCurrentAccessDate);fflush(stdout);

//    if(strcmp(parent_name,"Change Request Life Cycle")==0)
//	  if(strcmp(parent_name,"Add solution items")==0)
//	  if(strcmp(parent_name,"ERC Task Workflow")==0)
//    if(strcmp(parent_name,"ECU_SnapShot")==0)
//      {
//		CALLAPI(EPM_ask_tasks(rootTask,EPM_pending ,&Pncount,&Pendingtasks));
//
//		CALLAPI(AOM_UIF_ask_value(Pendingtasks[0],"fnd0ActuatedInteractiveTsks",&taskTempLT));
//
//		printf("\n tm_ECURefSnapshot primary taskTempLT is : %s\n",taskTempLT);fflush(stdout);
//
//		if(strcmp(taskTempLT,"Add solution items")==0)
//		{

	// CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	 //printf("\n tm_ECURefSnapshot Target Attachment:%d",noAttachment);fflush(stdout);
	

	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	ifail = ITEM_find_item (dml_No, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_list_all_revs (item_tag, &count1, &rev_list);
	CHECK_FAIL;


	 if(count1 > 0)
	 {
		 DMLTaskTag = rev_list[0];

		 if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		 printf("\n tm_ECURefSnapshot dmlTaskNo: [%s]", dmlTaskNo);fflush(stdout);

		 if (tc_strstr(dmlTaskNo,"_") != NULL)
		 {
			DMLNo=strtok(dmlTaskNo,"_");
			printf("\n DMLNo =====> [%s]", DMLNo);fflush(stdout);
		 }

		  if(ITEM_find_item(DMLNo, &DML_tag)!=ITK_ok)PrintErrorStack();
		  if (DML_tag != NULLTAG)
		  {
			    if(ITEM_ask_latest_rev(DML_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
			    printf(" tm_ECURefSnapshot DML Rel_type: [%s]", Rel_type);fflush(stdout);

				if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
				{
					if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLprojcode)==ITK_ok) PrintErrorStack();

					if(tc_strlen(DMLprojcode)>0)
					{
						printf("\nRevision Project Code [%s]\n",DMLprojcode);fflush(stdout);

						if(QRY_find2("ControlObjQry", &ProQryContObj));
						if(ProQryContObj)
						{
							 if(QRY_execute(ProQryContObj, n_Input, qry_Input, qry_ProjVal, &ProjCount, &ProjCnObj));
							 printf("\n CONT Objects for CCID == %d\n", ProjCount);fflush(stdout);
						}
						else
						{
							printf("\n ContrlObj not found for CCID");fflush(stdout);
						}

						if(ProjCount >0)
						{

							CheckFlag=Getcontrolobjinfo(ProjCnObj,DMLprojcode,ProjCount);

						    printf("flag value is : %d",CheckFlag);

							/*	if (AOM_ask_value_string(ProjCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();

								printf("\n CCID Project Codes List [%s]",info1); fflush(stdout);


								if(tc_strstr(info1,DMLprojcode)!=NULL)
								{
									printf("\n CCID Project matches\n"); fflush(stdout);
									CheckFlag=1;
								}*/
						}
					}
					if(CheckFlag==1)
					{
						ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
					    ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));
						printf("\n  tm_ECURefSnapshot Task count is : %d",tsk_cnt);fflush(stdout);
						if (tsk_cnt>0)
						{
							 for (t=0;t<tsk_cnt ;t++ )
 							 {
								 ITK_CALL(AOM_ask_value_string(Tsk_objects[t],"object_type",&Taskobject_type));
								 printf("\n Taskobject_type is :%s\n",Taskobject_type);fflush(stdout);
								 if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
								 {
									 printf("\n tm_ECURefSnapshot inside T5_ChangeTaskRevision :\n");fflush(stdout);
									 ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));

									  if (part_tsk_rel!=NULLTAG)
									  {
										   ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[t], part_tsk_rel, &partcnt, &PartsTag));
										   printf("\n  partcnt.:%d\n",partcnt);fflush(stdout);
										    if (partcnt>0)
											{
												for (p=0;p<partcnt;p++ )
												{
														PartNumber=NULL;
														PartNumber=(char *) MEM_alloc(25);

														int ecuRlzStatusCnt =0;
														int ss2 =0;
														tag_t* ecu_Rlz_St_list=NULL;
														char * ecuPrtLatestRlzSt =NULL;
														char * RevIDNo_Org =NULL;

														DesignrevTag=PartsTag[p];

														//if(AOM_ask_value_string(DesignrevTag,"release_status_list",&ReleaseType)==ITK_ok);
														//printf("\n tm_ECURefSnapshot ReleaseType is  = [%s]\n", ReleaseType);fflush(stdout);
														if(WSOM_ask_release_status_list(DesignrevTag, &ecuRlzStatusCnt, &ecu_Rlz_St_list)!=ITK_ok)PrintErrorStack();
														printf("\t ecuRlzStatusCnt: %d",ecuRlzStatusCnt);	fflush(stdout);

														if(AOM_ask_value_string(DesignrevTag,"item_id",&PartNo)==ITK_ok);
														printf("\n tm_ECURefSnapshot PartNo is  = [%s]\n", PartNo);fflush(stdout);

														if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo_Org)==ITK_ok);
														printf("\n tm_ECURefSnapshot RevIDNo is  = [%s]\n", RevIDNo_Org);fflush(stdout);

														int ECURlzRevFlag=0;
														/*if (ecuRlzStatusCnt > 0)
														{
															for(ss2=0; ss2<ecuRlzStatusCnt ; ss2++)
															{
																if(AOM_ask_value_string(ecu_Rlz_St_list[ss2],"object_name",&ecuPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();

																printf("\t ecuPrtLatestRlzSt 11111: %s ",ecuPrtLatestRlzSt);fflush(stdout);
																//if((tc_strcmp(ecuPrtLatestRlzSt,"ERC Review")==0) || (tc_strcmp(ecuPrtLatestRlzSt,"T5_LcsReview")==0))
																//{
																	printf("\t ecuPrtLatestRlzSt: %s ",ecuPrtLatestRlzSt);fflush(stdout);
																	ECURlzRevFlag=1;
																	break;
																//}
															}
														}*/
														if ( (tc_strstr(RevIDNo_Org,"NR")==NULL))	//not NR
														{
																tm_find_Prev_Official_Rev(PartNo,DesignrevTag, &t_previousRevision);
																DesignrevTag=t_previousRevision;
																printf("\t Inside ECU t_previousRevision :");fflush(stdout);
														}
														else
														 {
																printf("\t Inside continue");fflush(stdout);
																continue;
														 }

														 if(AOM_ask_value_string(DesignrevTag,"item_revision_id",&RevIDNo)==ITK_ok);
														printf("\n tm_ECURefSnapshot RevIDNo22222is  = [%s]\n", RevIDNo);fflush(stdout);

														if(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType)==ITK_ok);
														printf("\n tm_ECURefSnapshot PartType is  = [%s]\n", PartType);fflush(stdout);

															tc_strcpy(PartNumber,PartNo);
															printf("\n PartNumber going to add -------------> [%s]\n",PartNumber);


														//tc_strcat(PartNumber,"/");//sks
														//tc_strcat(PartNumber,RevIDNo);//sks

														//if(tc_strcmp(PartType,"EM")==0)
														if((tc_strcmp(PartType,"EM")==0)||(tc_strcmp(PartType,"T")==0)) // ADI LATEST 99
														 {

															if ((tc_strstr(RevIDNo_Org,"NR")==NULL))
															{
																if(setFindStr1(&iWrite,&SSDetails,PartNumber)==-1)
																//if(setFindStr1(&iWrite,&SSDetails,PartNo)==0)
																 {
																	setAddStr(&iWrite,&SSDetails,PartNumber);
																	printf("\n AAAAAAAAAAAAAAAAAAAAAAAAAAAAA tm_ECURefSnapshot module [%s] added directly \n",PartNumber);fflush(stdout);
																 }
																else
																 {
																	printf("\n module [%s] already exists in set \n",PartNumber);fflush(stdout);

																 }
															}
														}
														else
														{
																printf("\n tm_ECURefSnapshot PartType is not module hence imploding \n");fflush(stdout);
																ITKCALL(CFM_find("ERC release and above", &RevRuleTag ));
																//ITKCALL(PS_where_used_all(DesignrevTag,1,&n_parents,&levels,&parents));
																ITKCALL(PS_where_used_configured(DesignrevTag,RevRuleTag,3,&n_parents,&levels,&parents));
																printf("\n  tm_ECURefSnapshot containers where_used count of objects are : %d",n_parents); fflush(stdout);
																if(n_parents>0)
																{
																	for (ss=0;ss<n_parents;ss++ )
																	{
																			MPartNumber=NULL;
																			MPartNumber=(char *) MEM_alloc(25);

																			ModuleTag=parents[ss];

																			if(AOM_ask_value_string(ModuleTag,"item_id",&MPartNo)==ITK_ok);
																			printf("\n tm_ECURefSnapshot Module PartNo is  = [%s]\n", MPartNo);fflush(stdout);

																			if(AOM_ask_value_string(ModuleTag,"item_revision_id",&MRevIDNo)==ITK_ok);
																			printf("\n tm_ECURefSnapshot MODULE RevIDNo is  = [%s]\n", MRevIDNo);fflush(stdout);

																			if(AOM_ask_value_string(ModuleTag,"t5_PartType",&MPartType)==ITK_ok);
																			printf("\n tm_ECURefSnapshot MPartType is  = [%s]\n", MPartType);fflush(stdout);

																			if(AOM_ask_value_string(ModuleTag,"release_status_list",&MReleaseType)==ITK_ok);
																			printf("\n tm_ECURefSnapshot MReleaseType is  = [%s]\n", MReleaseType);fflush(stdout);

																			tc_strcpy(MPartNumber,MPartNo);
																			//tc_strcat(MPartNumber,"/");
																			//tc_strcat(MPartNumber,MRevIDNo);

																			printf("\n MPartNumber is -------------> [%s]\n",MPartNumber);

																			//code added by ajinkya on 19 may//
																			if(tc_strcmp(MPartType,"T")==0)
																			{
																				  printf("\n Inside the condition as Part type is----> [%s]\n",MPartNumber);

																					ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeN));
																					printf("\n  For TPL check - CCVC has ECU module REL FOUND \n");fflush(stdout);

																					ITK_CALL(GRM_list_secondary_objects_only(ModuleTag,CCVCrelation_typeN,&ModcntN,&ModattachmentsN));
																					printf("\n for tpl check - ModcntN ============= [%d]  \n",ModcntN); fflush(stdout);

																					 if (ModcntN>0)
																					{
																						 printf("\n Inside For TPL count  ============= [%d]  \n",ModcntN); fflush(stdout);
																						 printf("\n So Skipping TPL as Module created ============= \n"); fflush(stdout);

																						continue;
																					}
																					else
																					{
																						 printf("\n Else  For TPL count  ============= [%d]  \n",ModcntN); fflush(stdout);
																					}

																			}

																			//if(tc_strcmp(MPartType,"EM")==0)
																			if((tc_strcmp(MPartType,"EM")==0)||(tc_strcmp(MPartType,"T")==0)) // ADI LATEST 99
																			 {
																					if(setFindStr1(&iWrite,&SSDetails,MPartNumber)==-1)
																					 {
																						setAddStr(&iWrite,&SSDetails,MPartNumber);
																						printf("\n BBBBBBBBBBBBBBBBBBBBBBBBBBBB  tm_ECURefSnapshot module [%s] added after implosion \n",MPartNumber);fflush(stdout);
																					 }
																					 else
																					 {
																						printf("\n module [%s] already exists in set  after implosion\n",MPartNumber);fflush(stdout);
																					 }
																			 }
																	}// for loop ss complete
																}// n_parents if complete

														}

												} //partcnt for ends

												SSDetRead = sizeof(SSDetails);


												///////////////////////////NEW 9 JULY 2020///////////////////////////////////////////
												int	   RefRelcnt	        = 0;
												int	   ix					= 0;
												tag_t  RefRelTagX		    = NULLTAG;
												char*  CCIDObjNameX			= NULL;
												tag_t *RefRelTag	        = NULLTAG;

												ITK_CALL(GRM_find_relation_type("T5_HasReferenceCCID",&HasRefCCIDRelType));
												printf("\n after finding HasRefCCIDRelType \n");fflush(stdout);

												ifail = GRM_list_secondary_objects_only(DMLRevTag,HasRefCCIDRelType,&RefRelcnt,&RefRelTag);
												printf("\n tm_ECURefSnapshot RefRelcnt =============>>> %d  \n",RefRelcnt);fflush(stdout);

												if(RefRelcnt>0)
												{
													for (ix=0;ix<RefRelcnt;ix++)
													{
														ITK_CALL( GRM_find_relation(DMLRevTag, RefRelTag[ix], HasRefCCIDRelType, &RefRelTagX));

														ITK_CALL(AOM_ask_value_string(RefRelTag[ix],"object_name",&CCIDObjNameX));

														printf("\n CCIDObjNameX [%s] \n", CCIDObjNameX);fflush(stdout);

														if (RefRelTagX != NULLTAG)
														{
															ITK_CALL(GRM_delete_relation(RefRelTagX));

															printf("\n reference relation of [%s] deleted \n",CCIDObjNameX); fflush(stdout);
														}
													}
												}

												/////////////////////////////////NEW 9 JULY 2020/////////////////////////////////////////////

												if(iWrite>0)
												{
													for(sr=0;sr<iWrite;sr++)
													{
															NewModule=NULL;
															NewModule=(char *) MEM_alloc(25);

															tag_t ECU_tag_1 =NULLTAG;
															tag_t ECU_RevTag_1 =NULLTAG;
															tag_t t_previousRevision_1 =NULLTAG;
															int ECU_RlzStatusCnt_1 =0;
															int ss3 =0;
															tag_t * ECU_Rlz_St_list_1=NULL;
															char * ECUPrtLatestRlzSt_1=NULL;

															SSRead = SSDetails[sr];
															printf("\n tm_ECURefSnapshot Part numbers in set ----[%d] \n",iWrite);fflush(stdout);
															printf("\n SSRead in set ----[%s] \n",SSRead);fflush(stdout); // 5445T3A1168001/NR;1

															tc_strcpy(NewModule,SSRead);

															//NewModuleNum=tc_strtok(NewModule,"/");//SKS

															//NewModulerev =tc_strtok(NULL,"");//SKS

															if(ITEM_find_item(NewModule, &ECU_tag_1)!=ITK_ok)PrintErrorStack();

															if (ECU_tag_1 != NULLTAG)
															 {
																	if(ITEM_ask_latest_rev(ECU_tag_1, &ECU_RevTag_1)!=ITK_ok)PrintErrorStack();

																	if(WSOM_ask_release_status_list(ECU_RevTag_1, &ECU_RlzStatusCnt_1, &ECU_Rlz_St_list_1)!=ITK_ok)PrintErrorStack();
																	printf("\t ECU_RlzStatusCnt_1: %d",ECU_RlzStatusCnt_1);	fflush(stdout);

																	int ECURlzRevFlag_1=0;
																	if (ECU_RlzStatusCnt_1 > 0)
																	{
																		for(ss3=0; ss3<ECU_RlzStatusCnt_1 ; ss3++)
																		{
																			if(AOM_ask_value_string(ECU_Rlz_St_list_1[ss3],"object_name",&ECUPrtLatestRlzSt_1)!=ITK_ok)PrintErrorStack();
																			if((tc_strcmp(ECUPrtLatestRlzSt_1,"ERC Released")==0) || (tc_strcmp(ECUPrtLatestRlzSt_1,"T5_LcsErcRlzd")==0))
																			{
																				printf("\t ECUPrtLatestRlzSt_1: %s ",ECUPrtLatestRlzSt_1);fflush(stdout);
																				ECURlzRevFlag_1=1;
																				break;
																			}
																		}

																		 if (ECURlzRevFlag_1)
																		 {
																			t_previousRevision_1=ECU_RevTag_1;// latest released EM or TPL
																		 }
																		 else
																		{
																			 tm_find_Prev_Official_Rev(NewModule,ECU_RevTag_1, &t_previousRevision_1);
																			 //NOT Released find previous offical release
																		}

																	}

															 }

															 //printf("\n rev is NR \n");fflush(stdout);
															//const char **attrs = (const char **) MEM_alloc(1  * sizeof(char *));
															//const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

															//attrs[0] ="item_id";
															//values[0] = (char *) NewModuleNum;

															//ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,attrs,values,NewModulerev,&n_tags_found,&tags_found));

															//MEM_free(attrs);
															//MEM_free(values);
				//											////CHECK_FAIL;
				//
				//											if (n_tags_found == 0)
				//											{
				//												printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", NewModuleNum); fflush(stdout);
				//												exit (0);
				//											}
				//
				//											Mod_tag = tags_found[0];
				//											char* ModPartType=NULL;
				//											if(AOM_ask_value_string(Mod_tag,"t5_PartType",&ModPartType)==ITK_ok);
				//											printf("\n Mod_tag MPartType is  = [%s]\n", ModPartType);fflush(stdout);

				//
				//
				//											if(tc_strstr(NewModulerev,"NR")!=NULL)
				//											 {
				//												printf("\n revision NR hence not creating any snapshot in reference CCID \n");fflush(stdout);
				//											 }
				//											 else
															if (t_previousRevision_1)
															{
																printf("\n tm_ECURefSnapshot not NR REV so check if MODULE is member of CCID \n");fflush(stdout);

																				//if (tc_strcmp(ModPartType,"EM")==0)
				//												{
				//
				//													tm_find_Prev_Official_Rev(NewModuleNum,Mod_tag, &t_previousRevision);
				//												}
				//												else if (tc_strcmp(ModPartType,"T")==0)
				//												{
				//													t_previousRevision=Mod_tag;
				//												}
																if(t_previousRevision_1!=NULLTAG)
																{
																	printf("\n t_previousRevision found \n");fflush(stdout);
																		NewModulerev1	=	NULL;
																		ITKCALL(AOM_ask_value_string(t_previousRevision_1,"item_revision_id",&NewModulerev1));
																		printf("\n tm_ECURefSnapshot NewModulerev1: %s\n",NewModulerev1);fflush(stdout);

																		//const char **attrs1 = (const char **) MEM_alloc(1 * sizeof(char *));
																		//const char **values1 = (const char **) MEM_alloc(1 * sizeof(char *));

																		//attrs1[0] ="item_id";
																		//values1[0] = (char *) NewModuleNum;

																		//ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,attrs1,values1,NewModulerev1,&n_tags_found1,&tags_found1));

																		//MEM_free(attrs1);
																		//MEM_free(values1);

																		//if (n_tags_found1 == 0)
																		//{
																			//printf ("\n ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", NewModuleNum); fflush(stdout);
																			//exit (0);
																		//}

																		//Mod_tag1 = t_previousRevision_1;
																		ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&IsMemberOfCCID));
																		printf("\n tm_ECURefSnapshot after finding IsMemberOfCCID \n");fflush(stdout);

																		ifail = GRM_list_secondary_objects_only(t_previousRevision_1,IsMemberOfCCID,&membercnt,&memberTag);
																		printf("\n tm_ECURefSnapshot membercnt =============>>> %d  \n",membercnt); fflush(stdout);
																		if (membercnt > 0)
																		{
																			 int iFinalSeq=0;
																			 for (bl=0;bl<membercnt;bl++)
																			 {
																					iBlItemIDseq=0;
																					BlItemIDNew=NULL;
																					BlItemIDNew=(char *) MEM_alloc(25);

																					BLrevTag=memberTag[bl];// NEW Aditya Ambardekar
																					//BLMstTag=memberTag[bl]; //NEW
																					//ITK_CALL(ITEM_ask_latest_rev(BLMstTag,&BLrevTag)); //newly added

																					if(AOM_ask_value_string(BLrevTag,"item_id",&BlItemID)==ITK_ok);//5445E4Z01008_01
																					printf("\n BlItemID is  = [%s]\n", BlItemID);fflush(stdout);

																					if(AOM_ask_value_string(BLrevTag,"item_revision_id",&BlRevID)==ITK_ok);//A;1
																					printf("\n BlRevID is  = [%s]\n", BlRevID);fflush(stdout);

																					tc_strcpy(BlItemIDNew,BlItemID);//5445E4Z01008_01

																					if (tc_strstr(BlItemID,"_R1")!=NULL)
																					{
																						BLrevTagLatest=memberTag[bl];

																					}

																					else
																				    {

																						//////////
																						char * tempvcid=NULL;
																						char * VCIDNumAst=NULL;
																						tag_t tempvcid_tag =NULLTAG;
																						tag_t ProQryCCIDObj =NULLTAG;
																						tag_t* tpVCIDObj =NULLTAG;
																						tag_t	VCID_Obj = NULLTAG;
																						char	*qry_Input_VCID[2] = {"Item ID", "Type"};
																						int n_Input_VCID = 2;
																						int nVCIDCnt = 2;
																						char	*values1[2];

																						 if(tc_strstr(BlItemID,"_") != NULL)
																						 {
																							tempvcid=strtok(BlItemID,"_");
																							printf("\n tempvcid =====> [%s]", tempvcid);fflush(stdout); 
																						 }
																						 else
																						  {
																							 tc_strcpy(tempvcid,BlItemID);
																							 printf("\n tempvcid 2=====> [%s]", tempvcid);fflush(stdout);
																						  }


																							VCIDNumAst=(char *) MEM_alloc(30);
																							tc_strcpy(VCIDNumAst,tempvcid);
																							tc_strcat(VCIDNumAst,"_*");
																							printf("\nkk.VCID to search [%s]",VCIDNumAst); fflush(stdout);

																							values1[0] = VCIDNumAst;
																							values1[1] = "VCID";

																							if(QRY_find2("Item...",&ProQryCCIDObj));
																							if(ProQryCCIDObj)
																							{
																								if(QRY_execute(ProQryCCIDObj, n_Input_VCID, qry_Input_VCID, values1,&nVCIDCnt,&tpVCIDObj));
																								printf("\nkk.VCID count is %d.", nVCIDCnt);fflush(stdout);

																								if(nVCIDCnt>0)
																								{
																									FindLatestVCID(tpVCIDObj,nVCIDCnt,&VCID_Obj);
																									if(VCID_Obj)
																									{
																										ITK_CALL(ITEM_ask_latest_rev(VCID_Obj,&BLrevTagLatest));
																										
																									}
																								}
																							}



																						///////////
																					/*	BlItemIDNum=tc_strtok(BlItemIDNew,"_");// 5445T3A1168001
																						printf("\n BlItemIDNum is  = [%s]\n", BlItemIDNum);fflush(stdout);

																						BlItemIDseq =tc_strtok(NULL,"");//01
																						printf("\n BlItemIDseq is  = [%s]\n", BlItemIDseq);fflush(stdout);

																						if (BlItemIDseq)
																						{
																							iBlItemIDseq= atoi(BlItemIDseq);
																							if(iBlItemIDseq > iFinalSeq)
																							{
																								iFinalSeq = iBlItemIDseq;
																								//pLtstBsl = setGet(soBsls,iBlCnt);
																								BLrevTagLatest=memberTag[bl];//5445E4Z01008_03
																							}
																						}*/
																				   }
																			 }
																			 if(AOM_ask_value_string(BLrevTagLatest,"item_id",&BlLatestItemID)==ITK_ok);//5445E4Z01008_04
																				printf("\n BlLatestItemID is  = [%s]\n", BlLatestItemID);fflush(stdout);

																				// write logic to find LATEST CCID HERE AND attach the latest ccid in references CCID relation

																				//sks need to review
																				tag_t *Bltags_found = NULL;
																				int n_tags_foundbl= 0;
																				//int n_rev= 0;
																				const char **attrs33 = (const char **) MEM_alloc(1 * sizeof(char *));
																				const char **values33 = (const char **) MEM_alloc(1 * sizeof(char *));


																				attrs33[0] ="item_id";
																				values33[0] = (char *) BlLatestItemID;

																				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs33, values33, &n_tags_foundbl, &Bltags_found));
																				MEM_free(attrs33);
																				MEM_free(values33);


																				if (n_tags_foundbl == 0)
																				{
																					printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", BlLatestItemID); fflush(stdout);
																					exit (0);
																				}//sks need to review

																				BLTagLatest = Bltags_found[0];

																				ITK_CALL(ITEM_ask_latest_rev(BLTagLatest,&LatestblRev));//5445E4Z01008_04,C;2

																				//MEM_free(Bltags_found);

																				printf("\n latest reference CCID found \n");fflush(stdout);

																				//ITK_CALL(GRM_find_relation_type("T5_HasReferenceCCID",&HasRefCCIDRelType));
																				//printf("\n after finding HasRefCCIDRelType \n");fflush(stdout);

																				ITK_CALL(GRM_create_relation(DMLRevTag,LatestblRev,HasRefCCIDRelType,NULLTAG,&CCIDRefRel_task));
																				ITK_CALL(GRM_save_relation(CCIDRefRel_task));
																				ITK_CALL(AOM_refresh(DMLRevTag,1));
																				ITK_CALL(AOM_save_without_extensions(DMLRevTag));
																				ITK_CALL(AOM_refresh(DMLRevTag,0));

																		}
																		//else
					//													{
					//														printf("\n Reference CCIDs are not present for Modules. Please create Reference CCID for latest released version of Modules \n");fflush(stdout);
					//														EMH_clear_errors();
					//														EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"Reference CCIDs are not present for Modules. Please create Reference CCID for latest released version of Modules");
					//														return ITK_errStore1;
					//													}


																}

															}

													}
												}
												else
											   {
												  printf("\n  tm_ECURefSnapshot NO MODULE FOUND ATTACHED \n");fflush(stdout);
											   }

												
											}
									  }
								 }


							 }
						}
					}
					else
					{
						printf ("\n  project not present in control object 111 \n"); fflush(stdout);
					}
				}
				 else
				 {
					printf ("\n NOT ECU PARTS RELEASE DML \n"); fflush(stdout);
				 }

		  }
	 }
	EMH_clear_errors();

	printf ("\n--------------tm_ECURefSnapshot=Completed--------------------\n");fflush(stdout);

	return ifail;
}


//	Akshay Toke info reading
int Getcontrolobjinfo(tag_t* ProjCnObj,char* DMLprojcode,int ProjCount)
{
	char *info1CCID			 = NULL;
	char *info2CCID			 = NULL;
	char *info3CCID			 = NULL;
	char *info4CCID			 = NULL;
	char *info5CCID			 = NULL;
	char *info6CCID			 = NULL;
	char *info7CCID			 = NULL;
	char *info8CCID			 = NULL;
	char *info9CCID			 = NULL;
	char *info10CCID			 = NULL;
	char* finalInfoCCID       = NULL;
	int CheckFlag =0;
    int i=0;

	finalInfoCCID = (char *) MEM_alloc(10000 * sizeof(char *));
	TC_write_syslog("\n start:Getcontrolobjinfo.");
    for(i =0;i < ProjCount;i++)
	{
		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo1",&info1CCID);
		printf("\n info1CCID Project Codes List [%s]",info1CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo2",&info2CCID);
		printf("\n info2CCID Project Codes List [%s]",info2CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo3",&info3CCID);
		printf("\n info3CCID Project Codes List [%s]",info3CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo4",&info4CCID);
		printf("\n info4CCID Project Codes List [%s]",info4CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo5",&info5CCID);
		printf("\n info5CCID Project Codes List [%s]",info5CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo6",&info6CCID);
		printf("\n info6CCID Project Codes List [%s]",info6CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo7",&info7CCID);
		printf("\n info7CCID Project Codes List [%s]",info7CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo8",&info8CCID);
		printf("\n info8CCID Project Codes List [%s]",info8CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_Userinfo9",&info9CCID);
		printf("\n info9CCID Project Codes List [%s]",info9CCID); fflush(stdout);

		AOM_ask_value_string(ProjCnObj[i],"t5_userinfo10",&info10CCID);
		printf("\n info10CCID Project Codes List [%s]",info10CCID); fflush(stdout);


		if(info1CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info1CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info2CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info2CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info3CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info3CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info4CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info4CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info5CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info5CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info6CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info6CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info7CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info7CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info8CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info8CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info9CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info9CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info10CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info10CCID);
			tc_strcat(finalInfoCCID,",");
		}

	}


	printf("\n CCID Project Codes List [%s]",finalInfoCCID); fflush(stdout);


	if(tc_strstr(finalInfoCCID,DMLprojcode)!=NULL)
	{
		printf("\n CCID Project matches\n"); fflush(stdout);
		CheckFlag=1;
	}

	TC_write_syslog("\n End:Getcontrolobjinfo.");
  return CheckFlag;
}

void FindLatestVCID(tag_t* tpVCIDList,int nVCnt, tag_t* VCIDObj)
{
	int iVCnt = 0;
	int iMaxSq = 0;
	int nVcidSeq = 0;
	char* sVCIDNum = NULL;
	char* vcid_id = NULL;
	char* vcid_seq = NULL;
	TC_write_syslog("\n Start:FindLatestVCID.");
	for(iVCnt=0; iVCnt<nVCnt; ++iVCnt)
	{
		if (AOM_ask_value_string(tpVCIDList[iVCnt],"item_id",&sVCIDNum)!=ITK_ok);
		printf("\nkk.VCID number is [%s]",sVCIDNum); fflush(stdout);

		vcid_id = tc_strtok(sVCIDNum,"_");
		vcid_seq = tc_strtok(NULL,"_");
		nVcidSeq = atoi(vcid_seq);
		if(nVcidSeq>iMaxSq)
		{
			iMaxSq=nVcidSeq;
			VCIDObj[0]=tpVCIDList[iVCnt];
		}
	}
	printf("\nkk.Max sequence is [%d]",iMaxSq); fflush(stdout);
	TC_write_syslog("\n End:FindLatestVCID.");
}

//5533734916R/E;2