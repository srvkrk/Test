	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int CCID_TransferToUV(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = CCID_TransferToUV(dmlNo);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int CCID_TransferToUV(char* dmlNo)
{
	int ifail = ITK_ok;

	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char    *req_item      = NULL;
	char    *info1         = NULL;
	char    *NewCCIDNo     = NULL;
	char    *NewCCIDRev    = NULL;
	char    *NewCCIDRevDup = NULL;
	char    *NewCCIDRevDupS= NULL;
	char    *NewCCIDSeq    = NULL;
	char    *FinalCCIDRev  = NULL;
	char    *CCIDenvName   = NULL;
	tag_t    Cciditemrev   = NULLTAG;

	int     CCICheckFlag	= 0;
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int      cc             = 0;

	char	*qry_CInput[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_CVal[2] = {"CCID", "LIVE"};
	int		n_InputX		= 2;
	int     CountC			= 0;
	tag_t	*CnObjC		    = NULLTAG;

	//int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;

	tag_t	DMLRevTag			= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t	NewCCIDRelType		= NULLTAG;
	tag_t	DML_tag				= NULLTAG;
	tag_t   *newccidTag         = NULLTAG;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;

	ITK_CALL(POM_get_user_id (&username));
	printf("\n ECUCount_Validation Session User is : %s\n",username); fflush(stdout);

	//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));

    //ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
   // printf("\n ECUCount_Validation Parent Name: %s",parent_name);fflush(stdout);

   // ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&AttachmentCount,&attachments));
   // printf("\n ECUCount_Validation Target Attachment:%d",AttachmentCount);fflush(stdout);

   	int		count1			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;

	ifail = ITEM_find_item (dmlNo, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_list_all_revs (item_tag, &count1, &rev_list);
	CHECK_FAIL;

	if(count1 > 0)
	{
		DMLTaskTag = rev_list[0];

		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n ECUCount_Validation dmlTaskNo: [%s]",dmlTaskNo);fflush(stdout);

		tag_t *tags_found = NULL;
			int n_tags_found= 0;
			int n_rev= 0;

			const char **attrs = (const char **) MEM_alloc(1 * sizeof(char *));
			const char **values = (const char **) MEM_alloc(1 * sizeof(char *));

			attrs[0] ="item_id";
			values[0] = (char *) dmlTaskNo;

			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
			MEM_free(attrs);
			MEM_free(values);
			CHECK_FAIL;

			if (n_tags_found == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", dmlTaskNo); fflush(stdout);
				exit (0);
			}

			DML_tag = tags_found[0];

			ITK_CALL(ITEM_ask_latest_rev(DML_tag,&DMLRevTag));

			MEM_free(tags_found);
			printf("\n test 123456789 \n");fflush(stdout);
			if (DMLRevTag != NULLTAG)
			{
				 if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
				 printf("\n CCIDSignoff_Validationt DML Rel_type: [%s]", Rel_type);fflush(stdout);
				  if((tc_strcmp(Rel_type,"ECU Parts Release")==0)||(tc_strcmp(Rel_type,"EP")==0))
				  {
					    if(QRY_find2("ControlObjQry", &ProQryContObj));
						if(ProQryContObj)
						{
							if(QRY_execute(ProQryContObj, n_InputX, qry_CInput, qry_CVal, &CountC, &CnObjC));
							printf("\n CONT Objects for CCID transfer LIVE  == %d\n", CountC);fflush(stdout);

							if(CountC >0)
							 {
								ITK_CALL(AOM_ask_value_string(CnObjC[0],"t5_Userinfo1",&info1));

								printf("\n CCID INFO 1 ----- [%s]",info1); fflush(stdout);

								if(tc_strcmp(info1,"CCIDLIVE")==0)
								{
									printf("\n CCID Transfer Live \n"); fflush(stdout);
									CCICheckFlag=1;
								}
							}
						}
						else
						{
							printf("\n ContrlObj not found for CCID tRANSFER live ");fflush(stdout);
						}

						 if(CCICheckFlag==1)
						 {
							   ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&NewCCIDRelType));
							   printf("\n after finding NewCCIDRelType \n");fflush(stdout);

							   ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, NewCCIDRelType, &newccidcnt, &newccidTag));
							   printf("\n  newccidcnt is------------[%d]\n",newccidcnt);fflush(stdout);

							   ITK_CALL(PREF_ask_char_value("CCID_TRANSFERPATH", 0 , &CCIDenvName ));
						       printf("\n CCID_TRANSFERPATH issss  %s\n",CCIDenvName);fflush(stdout); // /user/uaprod/shells/ECU_TCUA/
							   if(!CCIDenvName)
								{
									printf("\n CCIDenvName envname not found \n");fflush(stdout);
									//EMH_store_error_s1(EMH_severity_error,ITK_err,"Preference not found. Please check the preference CCID_TRANSFERPATH");
									return ifail;
								}
								else
								{
									 printf("\n CCIDenvName preference found so continue  \n");fflush(stdout);
									 if(newccidcnt>0)
									 {
										 for (cc=0;cc<newccidcnt;cc++)
										 {
											  Cciditemrev=newccidTag[cc];
											   if(Cciditemrev)
											   {
														if(AOM_ask_value_string(Cciditemrev,"item_id",&NewCCIDNo)==ITK_ok);
														printf("\n  NewCCIDNo.:[%s]\n",NewCCIDNo);fflush(stdout);

														if(AOM_ask_value_string(Cciditemrev,"item_revision_id",&NewCCIDRev)==ITK_ok);
														printf("\n  NewCCIDRev is:[%s]\n",NewCCIDRev);fflush(stdout);

														NewCCIDRevDup		=(char *) MEM_alloc(10);
														//FinalCCIDRev		=(char *) MEM_alloc(25);

														tc_strcpy(NewCCIDRevDup,NewCCIDRev);//A;1
														printf("\n  NewCCIDRevDup is:[%s]\n",NewCCIDRevDup);fflush(stdout);

														str = malloc(1500);

														tc_strcpy(str,"");
														tc_strcat(str,CCIDenvName);
														//tc_strcat(str,"/user/uaprod/shells/ECU_TCUA");
														//tc_strcat(str,"/user/bsd05818/Adi");
														tc_strcat(str,"/");
														tc_strcat(str,"BSL_UA_UV_Transfer.sh");
														//tc_strcat(str,"BL_UA_UV_Transfer.sh");
														tc_strcat(str," ");
														tc_strcat(str,NewCCIDNo);
														tc_strcat(str," ");
														tc_strcat(str,"'");
														tc_strcat(str,NewCCIDRevDup);   //BSL_UA_UV_Transfer.sh  NewCCIDNo  NewCCIDRev
														tc_strcat(str,"'");


														printf("\n CCID str DIR ------------------:[%s]\n",str);fflush(stdout);

														//system(str);

														printf("\n AFTER CCID SHELL str DownloadPath DIR :[%s]\n",str);fflush(stdout);
											   }

										 }
									 }
									 else
									 {
										 printf("\n  CCID's count ==[%d]. Nothing found to transfer to UV \n",newccidcnt);fflush(stdout);
									 }

								}
						 }
						 else
					     {
							 printf("\n  control object not found  \n");fflush(stdout);
						 }
				  }
				  else
			      {
					   printf("\n  not ECU DML hence data transfer to UV not allowed \n");fflush(stdout);
				  }
			}


	}
	printf ("\n--------------CCID_TransferToUV=Completed--------------------\n");fflush(stdout);

	return ifail;
}
