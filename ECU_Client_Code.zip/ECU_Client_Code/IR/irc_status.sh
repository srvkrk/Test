echo "i am in testcmi"
cd /user/testcmi/Dev/devgroups/Akshay/IR/checkin/
./IR_checklist -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file=$OUTPUT_FILE
