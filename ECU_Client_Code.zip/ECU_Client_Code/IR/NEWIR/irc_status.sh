cd /user/testcmi/Dev/devgroups/Akshay/IR
./IR_checklist -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file=2829F9Y0131010_Input.txt




