
#include <stdio.h>
#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
#include <itk/mem.h>
#include <string.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int read_value_from_file(char*,char*);
int Get_Qry_Execute(char*, char*, char*, char*, char*, char*,char*,char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			* filename1					= NULL;
    char *Folder_name=NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-f=");
	Folder_name   = ITK_ask_cli_argument("-fp=");
  // Folder_name=(char *) MEM_alloc(100);
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = read_value_from_file(Filename,Folder_name);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_value_from_file(char* Filename,char* Folder_name)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
    char *Container_no	= NULL;
	char *Container_Rev	= NULL;
	char *Container_Seq	= NULL;
	char *Dataset_no	= NULL;
	char *Dataset_Rev	= NULL;
	char *Dataset_Seq	= NULL;
	char *ImanFile_Name=NULL;
	char *FullPath=NULL;
	
	
	char 			temp[500];

Container_no=(char *) MEM_alloc(100);
Container_Rev=(char *) MEM_alloc(100);
Container_Seq=(char *) MEM_alloc(100);
Dataset_no	=(char *) MEM_alloc(100);
Dataset_Rev	=(char *) MEM_alloc(100);
Dataset_Seq	=(char *) MEM_alloc(100);
ImanFile_Name=(char *) MEM_alloc(1000);
	FullPath=(char *) MEM_alloc(1000);
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 500, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				
                Container_no =strtok(temp,",");
				printf("\nContainer_no:%s",Container_no);

				Container_Rev = strtok(NULL,",");
				printf("\nContainer_Rev:%s",Container_Rev);

                Container_Seq = strtok(NULL,",");
				printf("\nContainer_Seq:%s",Container_Seq);
				
				Dataset_no =strtok(NULL,",");
				printf("\nDataset_no:%s",Dataset_no);

				Dataset_Rev = strtok(NULL,",");
				printf("\nDataset_Rev:%s",Dataset_Rev);

                Dataset_Seq = strtok(NULL,",");
				printf("\nDataset_Seq:%s",Dataset_Seq);

                ImanFile_Name = strtok(NULL,",");
				printf("\nImanFile_Name:%s",ImanFile_Name);

                FullPath = strcpy(FullPath,"/user/cvprod/EE_loading/");
				FullPath=strcat(FullPath,Folder_name);
				FullPath=strcat(FullPath,"/DVP_PDF/");
				FullPath=strcat(FullPath,ImanFile_Name);
				
				printf("\nFull_Path:%s",FullPath);
								
				ifail = Get_Qry_Execute(Container_no,Container_Rev,Container_Seq,Dataset_no,Dataset_Rev,Dataset_Seq,ImanFile_Name,FullPath);
              
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	

	      
			 fclose(fp);
	return ifail;
}

int Get_Qry_Execute(char* Container_no,char* Container_Rev,char* Container_Seq,char* Dataset_no,char* Dataset_Rev,char* Dataset_Seq,char* ImanFile_Name,char* FullPath)
{
int ifail           = ITK_ok;
tag_t ItemQry     = NULLTAG;
tag_t* ContainerTag   = NULLTAG;
tag_t dataset_rel_type=NULLTAG;
tag_t dataset_rel_type2=NULLTAG;
tag_t datasettype=NULLTAG;
tag_t* datasetobj1=NULLTAG;
tag_t datasetobj2=NULLTAG;
tag_t Datasetobj3=NULLTAG;
tag_t Datasetobj4=NULLTAG;
tag_t DVPrelation=NULLTAG;
tag_t revtag=NULLTAG;
tag_t* Named_ref=NULLTAG;
tag_t Named_ref_obj=NULLTAG;
char* class =NULL;
char* NR_Filename=NULL;
char* Container_RevSeq=NULL;
char* Dataset_name=NULL;
char* Dataset_RevSeq=NULL;
int ConCount=0;
int Entry_count=2;
int i=0;
int NR_count=0;
int NRflag=0;
int DsCnt=0;
char* errormsg=NULL;
	if (tc_strcmp(Dataset_no, "NA") != 0)
{
char *Entries[2] = {"Name","Type"};
char **Values = (char **) MEM_alloc(50 * sizeof(char *));
Container_RevSeq=MEM_alloc(100);
tc_strcpy(Container_RevSeq,"");
		        tc_strcat(Container_RevSeq,Container_Rev);
		        tc_strcat(Container_RevSeq,";");
		        tc_strcat(Container_RevSeq,Container_Seq);

Dataset_RevSeq=MEM_alloc(100);
tc_strcpy(Dataset_RevSeq,"");
		        tc_strcat(Dataset_RevSeq,Dataset_Rev);
		        tc_strcat(Dataset_RevSeq,";");
tc_strcat(Dataset_RevSeq,Dataset_Seq);

Values[0] = Container_no;
Values[1] = Interface Rule Revision;

               // printf("\nvalue_0:%s",Values[0]);
                //printf("\nvalue_1:%s",Values[1]);

        ifail=QRY_find("General...", &ItemQry);

	    
		if (ItemQry)
		{ 
	     QRY_execute(ItemQry, Entry_count, Entries, Values, &ConCount, &ContainerTag);
		 
		        printf("\nContainer Object Found : %d", ConCount);fflush(stdout);
				
		}	
   if (ConCount>0)
	{
		  revtag=ContainerTag[0];
		  class=(char *) MEM_alloc(100);
		 ifail = AOM_ask_value_string(revtag,"object_name",&class);
		 // printf("\nContainer Object class FoundBB : %s", class);fflush(stdout);
		  ifail=GRM_find_relation_type("IMAN_specification", &dataset_rel_type);
          ifail=GRM_list_secondary_objects_only(revtag,dataset_rel_type,&DsCnt,&datasetobj1);
		if(DsCnt>0)
		{
		  for( i=0; i<DsCnt; i++)
            {
				
				Datasetobj3=datasetobj1[i];
				ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
		            if(tc_strcmp(Dataset_name,Dataset_no)==0)
		            {
		            		
	                    printf("\nDataset found checking for Named ref file");fflush(stdout);
		            	ifail=AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref);
	                  
		              if(NR_count>0)
		              {
		                   for( i=0; i<NR_count; i++)
                            {
		            	     Named_ref_obj=Named_ref[i];
		            	     ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
		            	     
		            	     if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
		            	    { 
		            	    	printf("\nNamed refrenced file is alredy exists in dataset attached to container");fflush(stdout);
		            	    	NRflag=1;
		            	    }
		                    
		                   }
		            	
		              }
		               if(NRflag==0||NR_count==0)
		            	{
		                    printf("\nAdding Named refrenced file in existing dataset attached to container");fflush(stdout);
		            		ifail=AOM_refresh(Datasetobj3,1);
		                    ifail=AE_import_named_ref(Datasetobj3,"PDF_Reference",FullPath,NULL,SS_BINARY);
		                    ifail=AOM_save(Datasetobj3);
		                    ifail=AOM_refresh(Datasetobj3,0);
		            		
		            	}
		            		
		            }
					else 
			        {
		               printf("\nDataset not matched with DVP creating both dataset and Named ref file");fflush(stdout);
			           ifail= AE_find_datasettype2("PDF",&datasettype);
			           ifail=AE_create_dataset_with_id(datasettype,Dataset_no,Dataset_no,Dataset_no,Dataset_RevSeq,&Datasetobj4);
		               ifail=AOM_save(Datasetobj4);
			           ifail=AE_find_dataset2(Dataset_no,&datasetobj2);
		               ifail=AOM_refresh(datasetobj2,1);
		               ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		               ifail=AOM_save(datasetobj2);
		               ifail=AOM_refresh(datasetobj2,0);
			           ifail=GRM_create_relation(revtag,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	                   ifail=GRM_save_relation(dataset_rel_type2);      
		               
			        }
						
			}
			
        }
		else
		{	
			
		  ifail=AE_find_dataset2(Dataset_no,&datasetobj2);
		  
		 if (datasetobj2)
		  {
	        printf("\nDataset found. Creating relation with container");fflush(stdout);
	        ifail=GRM_create_relation(revtag,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	        ifail=GRM_save_relation(dataset_rel_type2);      
			ifail=AE_ask_dataset_named_refs(datasetobj2,&NR_count,&Named_ref);
	      
		  if(NR_count>0)
		  {
		   for( i=0; i<NR_count; i++)
            {
			 Named_ref_obj=Named_ref[i];
			 ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
			 
			 if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
			{ 
				printf("\nNamed refrenced file is alredy exists in dataset");fflush(stdout);
				NRflag=1;
			}
		    
		   }
			
		  }
		   else if(NRflag==0||NR_count==0)
			{
		        printf("\nAdding Named refrenced file in existing dataset");fflush(stdout);
				ifail=AOM_refresh(datasetobj2,1);
		        ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		        ifail=AOM_save(datasetobj2);
		        ifail=AOM_refresh(datasetobj2,0);
				
			}
		  
		  }
		  
		  else 
			{
		       printf("\nDataset not found creating both dataset and Named ref file");fflush(stdout);
			   ifail= AE_find_datasettype2("PDF",&datasettype);
			   ifail=AE_create_dataset_with_id(datasettype,Dataset_no,Dataset_no,Dataset_no,Dataset_RevSeq,&Datasetobj4);
		       ifail=AOM_save(Datasetobj4);
			   ifail=AE_find_dataset2(Dataset_no,&datasetobj2);
		       ifail=AOM_refresh(datasetobj2,1);
		       ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		       ifail=AOM_save(datasetobj2);
		       ifail=AOM_refresh(datasetobj2,0);
			   ifail=GRM_create_relation(revtag,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	           ifail=GRM_save_relation(dataset_rel_type2);      
		       
			}
		}
    }
 else
    {
                
 		 printf("\n Container not found with given input\n");fflush(stdout);
 		 
    }

}
			
              return ifail;
			  
}

