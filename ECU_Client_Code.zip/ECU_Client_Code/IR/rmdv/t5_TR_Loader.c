/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                             :   Raghavendra B T
*  Module                           :   TCUA Desing Rev Uploader
*  Code                                 :   createRevForProe.c
*  Created on     :   March 25, 2015
*
*
* Modification History :
*  S.No        Date                  CR No             Modified By              Modification Notes
   01          02-11-2017            NA                Shivkumar Birnale        L248 t5_PartType=TPL added, ITK_CALL function changed, APIs updated in CreateEffctivity()
   02          13-06-2018            NA                Shivkumar Birnale        DR Status values now taken from the file instead of 'NA'
*****************************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <time.h>

#include <epm/epm.h>



#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>



#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCREVIEW        "T5_LcsReview"
#define ERCWORKING   "T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

static int report_error( char *file, int line, char *function, int return_code)
{
                if (return_code != ITK_ok)
                {
                                int                                                           index = 0;
                                int                                                           n_ifails = 0;
                                const int*                            severities = 0;
                                const int*                            ifails = 0;
                                const char**      texts = NULL;

                                EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
                                printf("%3d error(s)\n", n_ifails);
                                for( index=0; index<n_ifails; index++)
                                {
                                                printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
                                                printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
                                                TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
                                }
                                EMH_clear_errors();
                                
    }
                return return_code;
}


//char*  excelfile( char* TR_No, char* TR_NO_LAT_str);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}


static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*)malloc(toCharf+2);
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}

char *remove_white_spaces(char *str)
{
	int i = 0, j = 0;
	while (str[i])
	{
		if (str[i] != ' ')
          str[j++] = str[i];
		i++;
	}
	str[j] = '\0';
	return str;
}


void setAddStr(int *count,char ***strset,char* str)
{

*count=*count+1;
//printf("\n setAddStr %d",*count);fflush(stdout);
if(*count==1)
{
	(*strset) = (char **)malloc((*count ) * sizeof(char *));
}
else
{
	(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
}
(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
 tc_strcpy((*strset)[*count-1],str);
 printf("\n Adi setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int setFindStr1(int *count,char ***strset,char* str)
 {
	int j   =0;

	//tmp = sizeof(*strset); 

	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;

	}
	return -1;
 }


int T5_set_value_logical(tag_t* rev, char* prop_name, char* prop_value)
{
                logical propModifiable;
                printf("%s value = '%s' \n",prop_name,prop_value);

                ITK_CALL(AOM_is_modifiable(*rev,prop_name,&propModifiable));
                if(propModifiable)
                {
                                //printf("Inside propModifiable\n");
                                if(tc_strcmp(prop_value,"+")==0||tc_strcasecmp(prop_value,"Y")==0||tc_strcasecmp(prop_value,"true")==0)                                                                //True = +
                                {
											ITK_CALL(AOM_set_value_logical(*rev,prop_name,true));
											//printf("Inside true\n");
                                }
                                else if(tc_strcmp(prop_value,"-")==0||tc_strcasecmp(prop_value,"N")==0||tc_strcasecmp(prop_value,"false")==0)                                        //False = -
                                {
											ITK_CALL(AOM_set_value_logical(*rev,prop_name,false));
											//printf("Inside false\n");
                                }
                                else
                                {
											printf("Incorrect property value \"%s\" passed to the function 'T5_set_value_logical()'. Cannot populate value of %s\n",prop_value,prop_name);
								}
                }
                else
                {
                                printf("%s is not modifiable\n",prop_name);
                }
                return ITK_ok;

}

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,&year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}





void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
		  {
						tc_strcpy(cMonth,"Jan");
		  }
		  else if(m==2)
		  {
						tc_strcpy(cMonth,"Feb");
		  }
		  else if(m==3)
		  {
						tc_strcpy(cMonth,"Mar");
		  }
		  else if(m==4)
		  {
						tc_strcpy(cMonth,"Apr");
		  }
		  else if(m==5)
		  {
						tc_strcpy(cMonth,"May");
		  }
		  else if(m==6)
		  {
						tc_strcpy(cMonth,"Jun");
		  }
		  else if(m==7)
		  {
						tc_strcpy(cMonth,"Jul");
		  }
		  else if(m==8)
		  {
						tc_strcpy(cMonth,"Aug");
		  }
		  else if(m==9)
		  {
						tc_strcpy(cMonth,"Sep");
		  }
		  else if(m==10)
		  {
						tc_strcpy(cMonth,"Oct");
		  }
		  else if(m==11)
		  {
						tc_strcpy(cMonth,"Nov");
		  }
		  else if(m==12)
		  {
						tc_strcpy(cMonth,"Dec");
		  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
		int day, month, year, nd, nm, ny, ndays;
		int                           ch1;
		int                           Monthas;
		int                           ch;
		time_t  temp;
		date_t DayTommorow ;
		struct tm *timeptr;
		struct tm *timeptr1;
		char pAccessDate[20];
		char pAccessDate1[20];

		char*     strDay;
		char*     strMon;
		char*     strYear;
		char       DateS[20];
		char* cMonth ;
		char CCMonth[30];
		temp = time(NULL);
		tc_strcpy(pAccessDate,"");
		//            timeptr = (struct tm *)localtime(&temp);
		//            ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
		
		//            day=timeptr->tm_mday;
		//            month=(timeptr->tm_mon)+1;
		//            year=(timeptr->tm_year+1900);

		strYear =  strtok(DatetoConvert,"/"); //1
		cMonth  =  strtok(NULL,"'/'"); //2
		strDay  =  strtok(NULL,"'/'"); //3
		Monthas =  atoi(cMonth);
		getMonth(Monthas,CCMonth);

		//printf("\n strYear:%s\n",strYear);
		//printf("\n CCMonth:%s\n",CCMonth);
		//printf("\n strDay:%s\n",strDay);

		tc_strcpy(cnextAccessDate,strDay);
		tc_strcat(cnextAccessDate,"-");
		tc_strcat(cnextAccessDate,CCMonth);
		tc_strcat(cnextAccessDate,"-");
		tc_strcat(cnextAccessDate,strYear);
		tc_strcat(cnextAccessDate," ");
		tc_strcat(cnextAccessDate,"00:00");
		//printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


int days( int m, int y )
{
                if ( m < 1 || m > 12 ) return 0;
                switch ( m ) 
                {
                                case 1: return 31;
                                case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
                }
                return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}


int AssignProject(tag_t  itemRev,char* projectcode)
{ 
		tag_t  projobj=NULLTAG;
		char* username=NULL;
		tag_t user_tag=NULLTAG;

		// ITK_CALL(AOM_lock(itemRev));
		printf("Projectcode [%s]\n",projectcode);
		ITK_CALL (PROJ_find(projectcode,&projobj));
		//printf("\n Assigned to Project\n");fflush(stdout);

		if(projobj !=NULLTAG)
		{
			//POM_get_user(&username,&user_tag);
			//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
			ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
			printf("Assigned to Project\n");fflush(stdout);
		}
		else
		{
			printf("\n Project not found\n");fflush(stdout);
		}
		   ITK_CALL(AOM_save(itemRev));
		  ITK_CALL(AOM_unlock(itemRev));
		return ITK_ok;
}




int setEffectivity(tag_t* itemRev,char* date)
{          
	logical   date_is_valid   = FALSE;
	tag_t       st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t    st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;


	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
		//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
						//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
						//WSOM_status_ask_effectivitie
						//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
						ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,date,&eff_t));
						ITK_CALL(AOM_save(status_list[0]));
						ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
						printf("\n Cannot load this......");
		}
		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}
	return ITK_ok;
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{

	tag_t   release_status =NULLTAG;
	char   *ReleaseStatus=NULL;
	logical  retain_released_date =false;
	logical  is_v7  ;
	char FrmNextDate[20]={0};
	char ToNextDate[20]={0};
	date_t test_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	int                           ifail         =0;
	char* lcsToset=NULL;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;

	int              status_count=0;
	int              ss=0;
	int              StatusFlg=0;
	tag_t* status_list = NULLTAG;
	
	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	//printf("\n lifeCycleS: [%s]\n",lifeCycleS);fflush(stdout);

	if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
	{
		printf("This is Std Release\n");
		strcpy(lcsToset,ERCRELEASED);
	}

	if((strcmp(lcsToset,"T5_LcsErcRlzd")==0))
	{
			ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
			printf("Existing Status_count: %d\n",status_count);
			if (status_count == 0) /* No Status, so the Item is not yet Released */
			{
				printf("No Existing Status, so the Item is not yet Released \n");
			}
			else
			{
					for(ss=0; ss<status_count ; ss++)
					{
							ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
							printf("\n Existing Status : %s\n",class_name);
							if(strcmp(class_name,lcsToset)==0)
							{
								StatusFlg ++;
							}
					}
			}
			if(StatusFlg != 0) return ITK_ok;

			printf("Stamping Releasing Item\n");
			ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status));
			ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,false));

			printf("FromDate : [%s]\n",FromDate);
			printf("ToDate : [%s]\n",ToDate);
			if((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0))  return 0;

			ITK_CALL(WSOM_ask_effectivity_mode(&is_v7));                                             
			printf("v7 Effectivity is:%d\n",is_v7);

			getNextDate(FromDate,FrmNextDate);
			getNextDate(ToDate,ToNextDate);
			printf("FrmNextDate:%s\n",FrmNextDate);
			printf("ToNextDate:%s\n",ToNextDate);

			if(ITK_ok != (ifail = ITK_string_to_date(FrmNextDate, &test_date_1 )))
			{
							return ifail;
			}
			if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
			{
							return ifail;
			}
			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);


				start_end_date[0] = test_date_1;
				start_end_date[1] = test_date_2;

				ITK_CALL(WSOM_status_clear_effectivities ( release_status));
				ITK_CALL(WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
				ITK_CALL(AOM_save(eff_d));
				ITK_CALL(AOM_save(release_status));
				ITK_CALL(AOM_refresh( release_status, 0 ));
				printf("Effectivity Stamping Completed : %s\n",FrmNextDate);

	}
	else
	{
			ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
			printf("Existing status_count: %d\n",status_count);
			if(status_count>0)
			{
				for(ss=0; ss<status_count ; ss++)
				{
					ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
					printf("Existing Status: %s\n",class_name);
					if(strcmp(class_name,lcsToset)==0)
					{
						StatusFlg ++;
						printf("INFO : %d Status already exists. Skipping status addition\n",lcsToset);
					}
				}
			}
			if(StatusFlg == 0)
			{
				printf("Adding Release status to Item Revision\n");
				ITK_CALL(RELSTAT_create_release_status(lcsToset,&release_status));
				ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,false));
				printf("Release status addition completed\n");
			}
	}
  return ITK_ok;
}

//====================================================================================

int t5removeAllReleaseStatus (tag_t rev)
{
                
		int                                           status_count;
		tag_t*                   status_list;
		int                                           st_relList_count                = 0; 
		int                                           Rel_cnt                                                                 = 0; 
		tag_t*                   relstatus_list                                      = NULLTAG;
		char                       *WSO_Name_RelVal                      = NULL ; 
		tag_t                     tReleaseStatusList                           = NULLTAG; 
		int                                           n_values                                                              = 0; 
		int                                           cunt1                                                                     = 0; 
		tag_t*                   attr_tags                                                              = NULLTAG; 
		logical                    *is_it_null                                                           = NULL; 
		logical                    *is_it_empty                                     = NULL;
		tag_t                     class_id                                                = NULLTAG;
		char                       *class_name                                                      = NULL;
		logical                    log1;
		int                                           ifail = 0;

                
		ITK_CALL(WSOM_ask_release_status_list(rev,&status_count,&status_list));

		printf("No of Status == %d\n",status_count);
		if(status_count>0) 
		{
				ITK_CALL(POM_class_of_instance(rev,&class_id));
				ITK_CALL(POM_name_of_class(class_id,&class_name));
				ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));
				ITK_CALL(POM_unload_instances (1,&rev));
				ITK_CALL(POM_load_instances(1,&rev,class_id,1));
				ITK_CALL(POM_is_loaded(rev,&log1));
				if(log1 == 1)
				{
						printf("Load Success\n" );
				}
				else
				printf("Load Failure\n");

				ITK_CALL( POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
				if(n_values>0)
				{
						ITK_CALL( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
						for (cunt1 =  0; cunt1 <n_values; cunt1++)
						{
								printf("Status removal started\n");
								ITK_CALL(POM_remove_from_attr(1,&rev,tReleaseStatusList,0,1));
								ITK_CALL(POM_save_instances(1,&rev,1));
								ITK_CALL(POM_refresh_instances(1,&rev,class_id,2));
								ifail=ITK_CALL(AOM_lock(rev));
								if(ifail!=ITK_ok)
								{
										printf("The Item Revision cannot be locked. Status Removal failed\n");
										break;
								}
								ITK_CALL(AOM_save(rev));
								ITK_CALL(AOM_refresh(rev,1));
								printf("Status removal completed\n");

								ITK_CALL(POM_length_of_attr(rev, tReleaseStatusList, &n_values) );
								printf("Updated Status Count is :%d\n",n_values);
								ITK_CALL( POM_ask_attr_tags(rev, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
								cunt1=cunt1-1;
						}
						ITK_CALL(AOM_unlock(rev));
				}
				printf("All Statuses removed\n");;fflush(stdout);

		}
		return ITK_ok;   
}
//====================================================================================

tag_t Qry_PartM(char* Part)
{
		tag_t tags_found4=NULLTAG;
		
			
		ITEM_find_item(Part,&tags_found4);

			return tags_found4;
		

}

char* GetDomain(char* TR_RqDomain)
{
	char* RqDomain=NULL;
	if (tc_strstr(TR_RqDomain,"IDT"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"AETM"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"AETE"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"AETL"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"BRK"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"BSR"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"CHA"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"EXHT"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"FUEL"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"ILAB"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"STRG"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"SUSP"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"TRN"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Transmission");//changed
	}
	else if (tc_strstr(TR_RqDomain,"CAB"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"TSJ"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Transmission");//changed
	}
	else if (tc_strstr(TR_RqDomain,"VT"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Indoor");
	}
	else if (tc_strstr(TR_RqDomain,"POLY"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Metallurgy");//changed
	}
	else if (tc_strstr(TR_RqDomain,"METPS") || tc_strstr(TR_RqDomain,"METCS") || tc_strstr(TR_RqDomain,"METBT")|| tc_strstr(TR_RqDomain,"METSEC"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Metallurgy");//changed
	}
	else if (tc_strstr(TR_RqDomain,"Testing-Crash"))
	{
		RqDomain=(char *) MEM_alloc(30);
		tc_strcpy(RqDomain,"Testing-Crash");//changed
	}

	return RqDomain;
}


char* GetProjCode(char* TR_RqProj)
{
	char* RqProj=NULL;
	if (tc_strstr(TR_RqProj,"5442"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5442");
	}
	else if (tc_strstr(TR_RqProj,"5445"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5445");
	}
	else if (tc_strstr(TR_RqProj,"5457"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5457");
	}
	else if (tc_strstr(TR_RqProj,"5447"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5447");
	}
	else if (tc_strstr(TR_RqProj,"5464"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5464");
	}
	else if (tc_strstr(TR_RqProj,"5465"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5465");
	}
	else if (tc_strstr(TR_RqProj,"5467"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5467");
	}
	else if (tc_strstr(TR_RqProj,"5123"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5123");
	}
	else if (tc_strstr(TR_RqProj,"5458"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5458");
	}
	else if (tc_strstr(TR_RqProj,"5466"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5466");
	}
	else if (tc_strstr(TR_RqProj,"5468"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5468");
	}
	else if (tc_strstr(TR_RqProj,"5474"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"5474");
	}

	return RqProj;
}
char* GetProgram(char* TR_RqProj) //changed
{
	char* RqProj=NULL;
	if (tc_strstr(TR_RqProj,"5442"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X4");
	}
	else if (tc_strstr(TR_RqProj,"5445"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"Hornbill");
	}
	else if (tc_strstr(TR_RqProj,"5457"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X4");
	}
	else if (tc_strstr(TR_RqProj,"5447"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X4");
	}
	else if (tc_strstr(TR_RqProj,"5464"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X104");
	}
	else if (tc_strstr(TR_RqProj,"5465"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"UV");
	}
	else if (tc_strstr(TR_RqProj,"5467"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X0");
	}
	else if (tc_strstr(TR_RqProj,"5123"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X104_EV");
	}
	else if (tc_strstr(TR_RqProj,"5458"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X451_EV");
	}
	else if (tc_strstr(TR_RqProj,"5466"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"UV");
	}
	else if (tc_strstr(TR_RqProj,"5468"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"Hornbill");
	}
	else if (tc_strstr(TR_RqProj,"5474"))
	{
		RqProj=(char *) MEM_alloc(30);
		tc_strcpy(RqProj,"X104_EV");
	}
	//ADD HERE 
	return RqProj;
}
char* GetBuisnessUnit(char* TR_RqProj) //changed
{
	char* RqBU=NULL;
	if (tc_strstr(TR_RqProj,"5442"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5445"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5457"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5447"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5464"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5465"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5467"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5123"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5458"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5466"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5468"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	else if (tc_strstr(TR_RqProj,"5474"))
	{
		RqBU=(char *) MEM_alloc(30);
		tc_strcpy(RqBU,"PVBU");
	}
	//ADD HERE 
	return RqBU;
}
char* GetBoolean(char* TR_Rqbool)
{
	char* RqBool=NULL;
	if (tc_strstr(TR_Rqbool,"Yes"))
	{
		RqBool=(char *) MEM_alloc(30);
		tc_strcpy(RqBool,"YES");
	}
	else 
	{
		RqBool=(char *) MEM_alloc(30);
		tc_strcpy(RqBool,"NO");
	}
	return RqBool;
}
char* GetReasonCode(char* TR_Reason)
{
	char* RqReason=NULL;
	if (tc_strcmp(TR_Reason,"First source development")==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"First Source Development");
	}
	else if (tc_strcmp(TR_Reason,"Alternate source development") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Alternate Development");
	}
	else if (tc_strcmp(TR_Reason,"Regulatory Test") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Regulatory Requirement");
	}
	else if (tc_strcmp(TR_Reason,"Cost Reduction") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Cost-Weight Reduction/Commonisation");
	}
	else if (tc_strcmp(TR_Reason,"Weight Reduction") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Cost-Weight Reduction/Commonisation");
	}
	else if (tc_strcmp(TR_Reason,"Data generation Test") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Data Generation");
	}
	else if (tc_strcmp(TR_Reason,"New Development") ==0)
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"New Development");
	}
	else
	{
		RqReason=(char *) MEM_alloc(200);
		tc_strcpy(RqReason,"Test Failure");
	}
	return RqReason;
}



//AETM-Auto-Electrical - Mechatronics
//AETE-Auto-Electrical - Electro-Mechanical
//AETL-Auto-Electrical - Lighting
//BRK-Brakes System
//BSR-BSR testing
//CHA-Chassis System
//EXHT-Exhaust System
//FUEL-Fuel System
//ILAB-Instrumentation and RLDA
//STRG-Steering System
//SUSP-Suspension System
//TRN-Transmission System
//CAB-CAB SYSTEM
//TSJ-Transmission Sys JSR
//VT-Virtual Testing
//POLY-Polymer System
//METCS-Metallics Chassis and Suspension
//METBT-Metallics BIW
//METPT-Metallics Powertrain


char* GetSubDomain(char* TR_RqDomain)
{
	char* SubRqDomain=NULL;
	if (tc_strstr(TR_RqDomain,"AETM"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"AETM-Auto-Electrical - Mechatronics");
	}
	else if (tc_strstr(TR_RqDomain,"AETE"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"AETE-Auto-Electrical - Electro-Mechanical");
	}
	else if (tc_strstr(TR_RqDomain,"AETL"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"AETL-Auto-Electrical - Lighting");
	}
	else if (tc_strstr(TR_RqDomain,"BRK"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"BRK-Brakes System");
	}
	else if (tc_strstr(TR_RqDomain,"BSR"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"BSR-BSR testing");
	}
	else if (tc_strstr(TR_RqDomain,"CHA"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"CHA-Chassis System");
	}
	else if (tc_strstr(TR_RqDomain,"EXHT"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"EXHT-Exhaust System");
	}
	else if (tc_strstr(TR_RqDomain,"FUEL"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"FUEL-Fuel System");
	}
	else if (tc_strstr(TR_RqDomain,"ILAB"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"ILAB-Instrumentation and RLDA");
	}
	else if (tc_strstr(TR_RqDomain,"STRG-"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"STRG-Steering System");
	}
	else if (tc_strstr(TR_RqDomain,"SUSP"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"SUSP-Suspension System");
	}
	else if (tc_strstr(TR_RqDomain,"TRN"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"TRN-Transmission System");
	}
	else if (tc_strstr(TR_RqDomain,"CAB"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"CAB-CAB SYSTEM");
	}
	else if (tc_strstr(TR_RqDomain,"TSJ"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"TSJ-Transmission Sys JSR");
	}
	else if (tc_strstr(TR_RqDomain,"VT"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"VT-Virtual Testing");
	}
	else if (tc_strstr(TR_RqDomain,"POLY"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"POLY-Polymer System");
	}
	else if (tc_strstr(TR_RqDomain,"METCS"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"METCS-Metallics Chassis and Suspension");
	}
	else if (tc_strstr(TR_RqDomain,"METBT"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"METBT-Metallics BIW");
	}
	else if (tc_strstr(TR_RqDomain,"METPT"))
	{
		SubRqDomain=(char *) MEM_alloc(100);
		tc_strcpy(SubRqDomain,"METPT-Metallics Powertrain");
	}
	return SubRqDomain;
}





TCrashInitiateAndAssign(char* RevObjName, tag_t itemRev_t, char* TR_No, char* TR_NO_LAT_str, tag_t boTag)
{

   tag_t template_tag2 = NULLTAG; //ADI AUTO SUBMIT CODE ----
   tag_t test_job_a2 = NULLTAG;
   int attachment_types2 = 1;
   int i = 0;


			printf("\n auto submit Test Request Template \n");fflush(stdout);
			ITK_CALL(EPM_find_template2("Test Request Template For Testing-Crash",0,&template_tag2));
			
			if (template_tag2!=NULLTAG)
			{
				printf("\n Submit RMDV to workflow\n");fflush(stdout);
				//ITK_CALL(EPM_create_process("IDT and TMT Process","",template_tag,1, &itemRev_t,&attachment_types2,&test_job_a2));
				ITK_CALL(EPM_create_process(RevObjName,"Testing Crash Workflow",template_tag2,1, &itemRev_t,&attachment_types2,&test_job_a2));
				
				printf("\n Submit RMDV to Crash workflow process complete\n");fflush(stdout);
			}
			else
			{
				printf("\n RMDV Crash WORKFLOW PROCESS  Not Found \n");fflush(stdout);
			}



			char *TaskAssignment = NULL;


			tag_t job_Tag2    =     NULLTAG;
			tag_t jobtype_Tag2 =    NULLTAG;
			tag_t rootTask2    =    NULLTAG;
			tag_t* subtask   =      NULLTAG;
         //	tag_t* taskAttachments=NULLTAG;
         //	tag_t* reviewSubTasks=NULLTAG;
			char dRftSpectype_name[TCTYPE_name_size_c+1];
			char	*EIDLinfo2		=  NULL;
			char	*parent_name2		=  NULL;
			int tskcount2=0;

			char	*subtask0		=  NULL;
			char	*subtask1		=  NULL;
			char	*subtask2		=  NULL;
			char	*subtask3		=  NULL;
			char	*subtask4		=  NULL;
			char	*subtask5		=  NULL;
			char	*subtask6		=  NULL;
			char	*subtask7		=  NULL;

			tag_t    *signoffs      =  NULLTAG;
			tag_t    *childtask6    =  NULLTAG;
			char    *task_type6     =  NULL;

			int v=0;
			int tskcount6 = 0;
			int signoffCount = 0;

			ITK_CALL(EPM_get_current_job(itemRev_t,&job_Tag2,&jobtype_Tag2));
			ITK_CALL(TCTYPE_ask_name(jobtype_Tag2,dRftSpectype_name));
			ITK_CALL(AOM_ask_value_string(job_Tag2,"object_name",&EIDLinfo2)) ;
			printf("\n Inside [%s] [%s] \n",dRftSpectype_name,EIDLinfo2);fflush(stdout);



			ITK_CALL(EPM_ask_root_task(job_Tag2,&rootTask2));               					    
			ITK_CALL(EPM_ask_sub_tasks(rootTask2,&tskcount2,&subtask));                           
			ITK_CALL(AOM_ask_value_string(rootTask2,"object_name",&parent_name2));
			printf("\n Parent Name: %s",parent_name2);fflush(stdout);
			printf("No of subtasks = %d\n",tskcount2);fflush(stdout);



//			 ITK_CALL(EPM_promote_task(subtask[0],"Promote for RMDV"));
//			 ITK_CALL(AOM_ask_value_string(subtask[0],"object_name",&subtask0));
//			 printf("\n subtask0 is: %s",subtask0);fflush(stdout);	
//			 ITK_CALL(EPM_promote_task(subtask[1],"Promote for RMDV"));
//			 ITK_CALL(AOM_ask_value_string(subtask[1],"object_name",&subtask1));
//			 printf("\n subtask1 is: %s",subtask1);fflush(stdout);
//			 ITK_CALL(EPM_promote_task(subtask[2],"Promote for RMDV"));
//			 ITK_CALL(AOM_ask_value_string(subtask[2],"object_name",&subtask2));
//			 printf("\n subtask2 is: %s",subtask2);fflush(stdout);
//			 ITK_CALL(EPM_promote_task(subtask[3],"Promote for RMDV"));
//			 ITK_CALL(AOM_ask_value_string(subtask[3],"object_name",&subtask3));
//			 printf("\n subtask3 is: %s",subtask3);fflush(stdout);
			 ITK_CALL(EPM_promote_task(subtask[4],"Promote for RMDV"));
			 ITK_CALL(AOM_ask_value_string(subtask[4],"object_name",&subtask4));
			 printf("\n subtask4 is: %s",subtask4);fflush(stdout);
			 ITK_CALL(EPM_promote_task(subtask[5],"Promote for RMDV"));
			 ITK_CALL(AOM_ask_value_string(subtask[5],"object_name",&subtask5));
			 printf("\n subtask5 is: %s",subtask5);fflush(stdout);
//			 ITK_CALL(EPM_promote_task(subtask[6],"Promote for RMDV"));
//			 ITK_CALL(AOM_ask_value_string(subtask[6],"object_name",&subtask6));
//			 printf("\n subtask6 is: %s",subtask6);fflush(stdout);

			 
			 							tag_t	objTag		  =  NULLTAG;
										tag_t	objTypTag	  =  NULLTAG;
										tag_t	ObjTypTR	  =  NULLTAG;
										tag_t	*attachments1 =  NULLTAG;
										tag_t	*tags_found	  =  NULLTAG;
										tag_t	*TR_Particpant =  NULLTAG;
										tag_t	*TR_Reviewr		=  NULLTAG;
										tag_t    rootTask       =  NULLTAG;
										int count3=0;
										int l=0,j=0,PrtCount=0,n_tags_found=0;
										logical is_latest;
										char *TestReqNos=NULL;
										char *dmlrelease_type=NULL;
										char *TR_Project=NULL;
										char *TR_Project_Program=NULL;
										char   ObjTyp[TCTYPE_name_size_c+1];
										char   type_name7[TCTYPE_name_size_c+1];
										tag_t TR_Particpant_rel_type =NULLTAG;
										int iii=0;
										ITK_CALL(EPM_ask_root_task(subtask[6],&rootTask2));
										
										ITK_CALL(EPM_ask_attachments (rootTask2,EPM_target_attachment,&count3,&attachments1));
										printf("\nSVR Release No of attachments1:%d",count3);	
										
										if(count3>0)
	                                    {
											for(l=0;l<count3;l++)
											{
												objTag=attachments1[l];
												if(TCTYPE_ask_object_type(objTag,&objTypTag));
												if(TCTYPE_ask_name(objTypTag,ObjTyp));
												printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

												if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
												printf("\n TR:DML/Task Number: [%s].", TestReqNos);fflush(stdout);
												
												if(GRM_find_relation_type("HasParticipant", &TR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
												if(tc_strcmp(ObjTyp,"T5_TestRqRevision")==0)
												{
													
													printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
													if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
													printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
													int jk=0;
													for (jk=0;jk<PrtCount ;jk++ )
													{
														tag_t TR_PartTag = TR_Particpant[jk];
														if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
														if(TCTYPE_ask_name(ObjTypTR,type_name7));
														printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

														///Removal of VATS Review 1

														if ( tc_strcmp(type_name7,"T5_TR_GrpHd")==0 )  //tc_strcmp(type_name7,"T5_TR_VatsRev")==0  || &  || tc_strcmp(type_name7,"T5_TR_ClstrHd")==0 
														{
															if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
															printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
															AOM_lock(objTag);
															ITEM_rev_remove_participant (objTag,TR_PartTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_save(objTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_unlock(objTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_refresh (objTag,TRUE);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
														}
													}


													
														

													/// Addition of GroupHead Reviewer

													//printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);

													
													char	*groupName			=  NULL;
													char	*roleName_GH			=  NULL;
													char	*TR_SubGrp_Tok			=  NULL;
													char	*TR_SubGrp			=  NULL;
													char	*TR_Domain			=  NULL;
													char	*TR_BU			=  NULL;
													tag_t	groupName_tag		=  NULLTAG;		
													tag_t	roleName_GH_tag		=  NULLTAG;	
													tag_t	TR_GH_Party			=  NULLTAG;
													tag_t	TR_GH_Patri_Type	=  NULLTAG;												
													tag_t	*GH_Tags            =  NULLTAG;
													int No_GH  =  0;
												
													

													if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy")|| tc_strstr(TestReqNos,"CAE-") || tc_strstr(TestReqNos,"Testing-Outdoor") || tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-Climate")|| tc_strstr(TestReqNos,"Testing-NVH"))
													{
														if(AOM_ask_value_string(objTag,"t5_TestSubGrp",&TR_SubGrp)!=ITK_ok)PrintErrorStack();
														printf("\n TR:TestReqNos: [%s] TR_SubGrp: [%s]", TestReqNos,TR_SubGrp);fflush(stdout);

														if(AOM_ask_value_string(objTag,"t5_RqDomain",&TR_Domain)!=ITK_ok)PrintErrorStack();
														printf("\n TR:TestReqNos: [%s] TR_Domain: [%s]", TestReqNos,TR_Domain);fflush(stdout);
									 
														groupName = (char	*)MEM_alloc(100);
														
														//roleName_CH = (char	*)MEM_alloc(100);
														roleName_GH = (char	*)MEM_alloc(100);

														tc_strcpy(roleName_GH,"Group_Head");

														//if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy"))
														//{
														//
														//	TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
														//	printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);
														//
														//	tc_strcpy(groupName,TR_SubGrp_Tok);
														//	tc_strcat(groupName,".");
														//	tc_strcat(groupName,TR_Domain);
														//	//tc_strcpy(roleName_CH,"Cluster_Head");  
														//}
														//else if (tc_strstr(TestReqNos,"CAE-"))
														//{
														//	tc_strcpy(groupName,TR_Domain);
														//	//tc_strcpy(roleName_CH,"Department_Head");  //Department_Head
														//}
														if (tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-NVH") || tc_strstr(TestReqNos,"Testing-Climate"))
														{
															tc_strcpy(groupName,TR_Domain);   
															//tc_strcpy(groupName,"Testing-Crash");   
														}
														//else if (tc_strstr(TestReqNos,"Testing-Outdoor"))
														//{
														//	//groupName_CH = (char	*)MEM_alloc(100);
														//	if(AOM_ask_value_string(objTag,"t5_BU",&TR_BU)!=ITK_ok)PrintErrorStack();
														//	printf("\n TR:TestReqNos: [%s] TR_BU: [%s]", TestReqNos,TR_BU);fflush(stdout);
														//
														//	TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
														//	printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);
														//
														//	tc_strcpy(groupName,TR_SubGrp_Tok);
														//	tc_strcat(groupName,".");
														//	tc_strcat(groupName,TR_Domain);
														//	tc_strcat(groupName,"_");
														//	tc_strcat(groupName,TR_BU);
														//	//tc_strcpy(roleName_CH,"Project_Head");  //Project_Head
														//
														//
		//												//			tc_strcpy(groupName_CH,TR_Domain);
		//												//			tc_strcat(groupName_CH,"_");
		//												//			tc_strcat(groupName_CH,TR_BU);
														//
														//	printf("\n groupName => %s ",groupName);fflush(stdout);
														//	//printf("\n groupName_CH => %s",groupName_CH );fflush(stdout);
														//}
														

														printf("\n TR:groupName  1111: [%s] roleName_GH: [%s]  ", groupName,roleName_GH);fflush(stdout);
														//printf("\n TR:roleName_CH: [%s]", roleName_CH);fflush(stdout);


														printf("\n TR: Setting  GH...");fflush(stdout);
														if(SA_find_group(groupName,&groupName_tag)!=ITK_ok)PrintErrorStack();
			//														if (groupName_CH)
			//														{
			//															if(SA_find_group(groupName_CH,&groupName_tag_CH)!=ITK_ok)PrintErrorStack();
			//														}

														if(SA_find_role2(roleName_GH,&roleName_GH_tag)!=ITK_ok)PrintErrorStack();
														//if(SA_find_role2(roleName_CH,&roleName_CH_tag)!=ITK_ok)PrintErrorStack();

														if(SA_find_groupmember_by_role(roleName_GH_tag,groupName_tag,&No_GH,&GH_Tags)!=ITK_ok)PrintErrorStack();
														printf("\n TR: No_GH :[%d]",No_GH);  fflush(stdout);
														if(No_GH>0)
														{
	                                                        ITK_CALL(EPM_ask_sub_tasks(subtask[6],&tskcount6,&childtask6));
											                printf("\n tskcount6  is: %d",tskcount6);fflush(stdout);
															
															for(iii=0;iii<No_GH;iii++)
															{	
																printf("\n TR: GH Reviewer no [%d]",iii);fflush(stdout);
																//if(TCTYPE_find_type("T5_TR_GrpHd","T5_TR_GrpHd",&TR_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_get_participanttype ("T5_TR_GrpHd",&TR_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_create_participant(GH_Tags[iii],TR_GH_Patri_Type,&TR_GH_Party)!=ITK_ok)PrintErrorStack();
																AOM_lock(objTag);			
																if(ITEM_rev_add_participant(objTag,TR_GH_Party)!=ITK_ok)PrintErrorStack();
																AOM_save(objTag);
																AOM_unlock(objTag);
																if(GH_Tags[iii] == NULLTAG)
															   {
																	printf("\n GH_Tags %d  is null",iii);fflush(stdout);
															   }
															   else
															   { 
																	printf("\n GH_Tags %d  is not null",iii);fflush(stdout); 
															   }
															   for( v=0; v<tskcount6; v++)
															   {
																   printf("\n ...........For loop Started ............");fflush(stdout);
																   ITK_CALL(AOM_ask_value_string(childtask6[v],"task_type",&task_type6));
																  
																   printf("\n task_type6 is: %s",task_type6);fflush(stdout);
																  
																   if(tc_strcmp(task_type6,"EPMSelectSignoffTask")==0)
																   {
																 	   printf("\n <<<<<<<<Current task is SST of Group Head task>>>>>>>>>");fflush(stdout);
																  
																 	   ITK_CALL(EPM_create_adhoc_signoff(childtask6[v], GH_Tags[iii], &signoffCount, &signoffs));
																  
																 	   printf("\n signoffCount is: %d",signoffCount);fflush(stdout);
																  
																 	   ITK_CALL(EPM_set_adhoc_signoff_selection_done(childtask6[v], true));
																  
																 	   ITK_CALL(AOM_lock(childtask6[v]));
																  
																 	   ITK_CALL(AOM_set_value_int(childtask6[v],"signoff_quorum", signoffCount));
																  
																 	   ITK_CALL(AOM_save(childtask6[v]));
																  
																 	   ITK_CALL(AOM_unlock(childtask6[v]));  
																   }
															   
															    }

															}
															  
															 
														}
														else 
													    {
														  printf("\n >>>>>>>>>>>>>>>>GH PARTICIPANTS NOT MAPPED <<<<<<<<<<<<<<");  fflush(stdout);
													    }
												
														AOM_refresh ( objTag,TRUE);
														MEM_free(GH_Tags);
														


													

												}
											}

										}
                                       
									}

		if(itemRev_t != NULLTAG)
		{
			createpdf(itemRev_t);
		} 
		else
		{
		    printf("\n Item rev not found 404040\n");fflush(stdout);
		}


        excelfile(TR_No,TR_NO_LAT_str, boTag);      //TR_No,TR_NO_LAT_str
            

}


int createpdf(tag_t itemRev_t)
{


	            char			*TestRqObjNm					= NULL;
				char			*output						= NULL;
				char			*FileStr						= NULL;
				char			*ExePath						= NULL;
				ExePath =(char *) MEM_alloc(sizeof(char)* 300);
				
				char mainFile[300];
				char command[1000];
				char docFile[300];
				char **values = (char **) MEM_alloc(1 * sizeof(char *));
				FileStr = MEM_alloc(1000);
				tag_t *transfermodes=NULLTAG;
				int transfermodeCnt=0;
				tag_t PLMSession=NULLTAG;
				char* TestRqObjNm1=NULL;
				char* TestRqObjNm2=NULL;

				tag_t objTypeTag = NULLTAG;
				char  	TestRqType[TCTYPE_name_size_c+1];





				printf("\n inside createpdf function");fflush(stdout);



				if (itemRev_t)
				{
					

					ITK_CALL(TCTYPE_ask_object_type (itemRev_t, &objTypeTag));
					ITK_CALL(TCTYPE_ask_name( objTypeTag, TestRqType));
					printf("\n\n\t\t type_name ==> %s\n", TestRqType);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(itemRev_t,"item_id",&TestRqObjNm));
					if (itemRev_t!=NULLTAG)
					{
						
						STRNG_replace_str(TestRqObjNm,"/","_",&TestRqObjNm1);
						STRNG_replace_str(TestRqObjNm1,"(","_",&TestRqObjNm2);
						STRNG_replace_str(TestRqObjNm2,")","_",&FileStr);
						printf("\n TDM_ReportFun1 function %s",FileStr);fflush(stdout);
						
						tc_strcpy(mainFile,"");
						tc_strcat(mainFile,"/tmp/");
						tc_strcat(mainFile,FileStr);
						tc_strcat(mainFile,".xml");
						TC_write_syslog("Main File = %s\n",mainFile);

						tc_strcpy(docFile,"");
						tc_strcat(docFile,"/tmp/");
						tc_strcat(docFile,FileStr);
						tc_strcat(docFile,".pdf");
						TC_write_syslog("Doc File = %s\n",docFile);

						printf("\n TDM_ReportFun function <%s> <%s>",mainFile,docFile);fflush(stdout);



						

						ITK_CALL(PIE_create_session(&PLMSession));
						ITK_CALL(PIE_session_set_file(PLMSession,mainFile));
						if (tc_strcmp(TestRqType,"T5_TestRqRevision")==0)
						{
							ITK_CALL(PIE_find_transfer_mode2("tm_TestRequest_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
						}

						
						ITK_CALL(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
						ITK_CALL(PIE_session_export_objects(PLMSession,1,&itemRev_t));

						
                            tc_strcpy(ExePath,"/user/uaprodtrl/sks08539/TDM/Report/TDM_Pdf.sh");       
                           
							printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);

							sprintf(command,"%s %s %s %s %s",ExePath,mainFile,docFile,TestRqType,FileStr);
							printf("\n Command to be run  == <%s>", command);fflush(stdout);
							system(command);

							if(access(docFile,F_OK)!=-1)
							{
								tag_t specRelationType_t=NULLTAG;
								tag_t PdfType=NULLTAG;
								tag_t PdfDataset=NULLTAG;
								tag_t PdfLatestDat_t=NULLTAG;
								tag_t specificationRel_t=NULLTAG;
								tag_t *DATASET=NULL;
								char* PdfObjdesc=NULL;
								char* PdfObjName=NULL;
								int DsCnt=0;

								printf("Doc file created successfully\n");fflush(stdout);
								ITK_CALL(AE_find_datasettype2("PDF",&PdfType));
								if(PdfType == NULLTAG)
								{
									printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
									
								}
								int Icnt=0;
								tag_t RelationDS=NULLTAG;
								
								ITK_CALL(GRM_find_relation_type("TC_Attaches",&specRelationType_t));

								ITK_CALL(GRM_list_secondary_objects_only(itemRev_t,specRelationType_t,&DsCnt,&DATASET));
								printf("\n TR DsCnt: %d",DsCnt);fflush(stdout);
								printf("\n 1st line");fflush(stdout);
								for (Icnt=0;Icnt<DsCnt ;Icnt++ )
								{
									ITK_CALL(AOM_ask_value_string(DATASET[Icnt],"object_desc",&PdfObjdesc));
									ITK_CALL(AOM_ask_value_string(DATASET[Icnt],"object_name",&PdfObjName));

									printf("\n TR DsCnt: <%s>   <%s>",PdfObjName,PdfObjdesc);fflush(stdout);
									printf("\n 2nd line");fflush(stdout);
									if ((tc_strcmp(PdfObjdesc,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName,FileStr)==0))
									{
										ITK_CALL(GRM_find_relation(itemRev_t,DATASET[Icnt],specRelationType_t,&RelationDS));
										if (RelationDS)
										{
											ITK_CALL(GRM_delete_relation(RelationDS));
										}
									}
								}

								ITK_CALL(AE_create_dataset_with_id(PdfType,FileStr,"TDM Pdf Report","","",&PdfDataset));
								ITK_CALL(AE_save_myself(PdfDataset));
								ITK_CALL(GRM_create_relation(itemRev_t,PdfDataset,specRelationType_t,NULLTAG,&specificationRel_t));
								ITK_CALL(AOM_load(specificationRel_t));
								ITK_CALL(GRM_save_relation(specificationRel_t));
								ITK_CALL(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
								ITK_CALL(AOM_refresh(PdfLatestDat_t,TRUE));
								ITK_CALL(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
								//CALLAPI(AE_save_myself(PdfLatestDat_t));

								AOM_save(PdfLatestDat_t);
								AOM_refresh(PdfLatestDat_t, FALSE);
								AOM_unload(PdfLatestDat_t);
								remove(docFile);
								output = "Report Generated Successfully and attached to revision in Attaches relationship";
								printf("\n Report Generated Successfully and attached to revision in Attaches relationship");fflush(stdout);
							}			
							else
							{
								  printf("\n file object not found \n");fflush(stdout);
								  output = "Report not generated. Please contact PLM support team";
							}



						printf("\n End of program.....!!\n\n");fflush(stdout);

					}
					else
					{
						  printf("\n Item revision not not found \n");fflush(stdout);
						  output = "Report not generated. Please contact PLM support team";
					}
				}
				else
				{
					  printf("\n Item not found \n");fflush(stdout);
					  output = "Report not generated. Please contact PLM support team";
				}

}

int excelfile( char* TR_No, char* TR_NO_LAT_str, tag_t boTag)
{

				FILE* fptr;
				char* TR_status="CREATED";
				char* Cre_date = NULL;
				char* filename = NULL;
				char* datetime = NULL;
				char buffer[80];
				filename =(char *) MEM_alloc(sizeof(char)* 300);
				datetime =(char *) MEM_alloc(sizeof(char)* 50);

				time_t t = time(NULL);
				struct tm* timeinfo;   
				time(&t);
				timeinfo = localtime(&t);
				strftime(buffer,80,"%Y-%m-%d-%H:%M:%S",timeinfo);
				printf("\n current date & time : %s \n",buffer);fflush(stdout);

				tc_strncpy(datetime,buffer,13);
				printf("\n changed current date & time : %s \n",datetime);fflush(stdout);
			 
				ITK_CALL(AOM_UIF_ask_value(boTag,"creation_date",&Cre_date));
				printf("\n creation date : %s \n",Cre_date);fflush(stdout);



				tc_strcpy(filename,"/user/uaprodtrl/shells/RMDV/TestRequestCreationforTCUA_");       
				tc_strcat(filename,datetime);
				tc_strcat(filename,".csv");

				printf("\n filename : %s \n",filename);fflush(stdout);

				if(tc_strstr(Cre_date,"15:")!=NULL)                               //First run of Cronjob
				{
					fptr=fopen(filename,"a");

					if(fptr==NULL)
					{
					   printf("\n File is not opened \n");fflush(stdout);
					}
					else
					{
						printf("\n File is opened \n");fflush(stdout);
							
						if(boTag != NULLTAG)
						{
						   fprintf(fptr,"%s, %s, %s, %s\n",TR_No,TR_NO_LAT_str,TR_status,buffer);fflush(stdout);
						}
					}

					if(fptr)
					{
						fclose(fptr);
						fptr=NULL;
					}
				}

				if(tc_strstr(Cre_date,"21:")!=NULL)                               //Second run of Cronjob
				{
					fptr=fopen(filename,"a");

					if(fptr==NULL)
					{
					   printf("\n File is not opened \n");fflush(stdout);
					}
					else
					{
						printf("\n File is opened \n");fflush(stdout);
							
						if(boTag != NULLTAG)
						{
						    fprintf(fptr,"%s, %s, %s, %s\n",TR_No,TR_NO_LAT_str,TR_status,buffer);fflush(stdout);
						}
					}

					if(fptr)
					{
						fclose(fptr);
						fptr=NULL;
					}
				}
  
				


}



TR_Create(char* TR_RqDomain,
		  char* TR_RqProjCode,
		  char* TR_RqProjDes,
		  char* TR_BU,
		  char* TR_WBS,
		  char* TR_WbsDesc,
		  char* TR_TestSubGrp,
		  char* TR_RqAggregate,
		  char* TR_RqProgram,
		  char* TR_RqDesStatus,
		  char* TR_No,
		  char* TR_RqRefDVP,
		  char* TR_RqReqDep,
		  char* TR_RqVehStage,
		  char* TR_RqSupplier,
		  char* TR_RqInvType,
		  char* TR_DescComp,
		  char* TR_RqTestDetails,
		  char* TR_RqBGHistory,
		  char* TR_RqChkMetRep,
		  char* TR_RqMetRepNo,
		  char* TR_RqChkQaRep,
		  char* TR_RqQaRepNo,
		  char* TR_RqChkPartyRep,
		  char* TR_RqPartyRepNo,
		  char* TR_SamplPeriGvn,
		  char* TR_RqSmplNo,
		  char* TR_RqGIN,
		  char* TestEngineer,
		  char* Owner,
		  char* Part_Number)
{

	

	char* TR_ProjCode;
	char* TR__BU;
	char* TR_SubGrp;
	char* TR_Domain;
	char* TR_Reason;
	char* TR_Program;
	int status=0;
	int ifail=0;

			tag_t rev_tag=NULLTAG;

		tag_t boTag= NULLTAG;
			tag_t item_t= NULLTAG;
	tag_t itemRev_t = NULLTAG;
	char *LatRev_ObjectType;
	char *PartObjectType;


		
	char *buff;
	char *buff11;
	char *logFile;
	char *part,*revv,*seq,*revSeq;

	int i=0,j=0;

			
	tag_t creInputTag_r= NULLTAG;
	tag_t creInputTag= NULLTAG;
	tag_t boTypeTag= NULLTAG;
	tag_t boTypeTag_r= NULLTAG;
	tag_t* foundItemsMtag;
	tag_t* TR_Tags;
	tag_t rev;
	tag_t Rel_dcr_part;
	tag_t relation_type1;
	tag_t user_tag;
	tag_t group;

					tag_t template_tag = NULLTAG; //ADI AUTO SUBMIT CODE ----
					tag_t test_job_a = NULLTAG;
					int attachment_types = 1;

						char*    Prt			= NULL;				//NEW							
						char*    Part_NumberDup = NULL;				//NEW	
						char*    Part_NumberX	= NULL;				//NEW	
						Part_NumberDup=(char *) MEM_alloc(2000);
						char*    Prt1			= NULL;				//NEW
						char**   PartSet		= NULL;				//NEW						
						char*   reid			= NULL;				//NEW	
						char*   reidDup			= NULL;				//NEW	
						char	*nwRev			= NULL;
						char	*Rev			= NULL;
						char	*Seq			= NULL;
						PartSet = (char**)MEM_alloc( 10 * sizeof *PartSet );
						int     iWrite			= 0;
						tag_t tags_found4		= NULLTAG;
						tag_t tags_found4_Rev	= NULLTAG;
						int		n_tags_found6	= 0;
						tag_t  *tags_found6		= NULL;
						tag_t   ItemRevTag		= NULLTAG;
						char * itemid			= NULL;
						char * itemrevid	    = NULL;



	tag_t *TRObjectTags = NULL;
	tag_t qryTag = NULLTAG;
	char* SerialNos=NULL;
	char* TR_NO_LAT=NULL;
	int SerialNosInt=0;
	char	strTemp[6];
	char* TR_NO_LAT_str = NULL;
	char* TR_obj_Name;
	char* TR_RqDomain_STR;
	TR_NO_LAT_str=(char *) MEM_alloc(30);


	TR_ProjCode=GetProjCode(TR_RqProjCode);
	TR__BU=GetBuisnessUnit(TR_RqProjCode);
	TR_SubGrp=GetSubDomain(TR_TestSubGrp);
	TR_Domain=GetDomain(TR_RqDomain);
	TR_Reason=GetReasonCode(TR_RqInvType);

	TR_Program=GetProgram(TR_RqProjCode);//new adi

	printf("\n TR_Domain. %s \n",TR_Domain);fflush(stdout);
	printf("\n TR_BU. %s \n",TR__BU);fflush(stdout);
	printf("\n TR_SubGrp. %s \n",TR_SubGrp);fflush(stdout);
	printf("\n TR_Domain. %s \n",TR_Domain);fflush(stdout);
	printf("\n TR_Reason. %s \n",TR_Reason);fflush(stdout);
	printf("\n TR_ProjCode. %s \n",TR_ProjCode);fflush(stdout);
	printf("\n TR_Program. %s \n",TR_Program);fflush(stdout);


	 printf("\n TR_RqProjCode== ============ %s\n", TR_ProjCode);fflush(stdout);
	int		n_Input1						= 1;
	int		ProjCount					= 0;
	tag_t	*ProjObj					= NULL;
	char	*qry_Input1[1]				= {"Name"};
	char	*values1[1];
	tag_t	 Qry_Proj					= NULLTAG;
	tag_t	 Pcode					= NULLTAG;
	char *	 projdes					= NULL;


	values1[0] = TR_ProjCode;
	if(QRY_find2("QryProj", &Qry_Proj));
	if(Qry_Proj)
	{
		 if(QRY_execute(Qry_Proj, n_Input1, qry_Input1, values1, &ProjCount, &ProjObj));
		 printf("\n QUERY for ProjCount count== %d", ProjCount);fflush(stdout);

		 if(ProjCount>0)
		 {
			Pcode =ProjObj[0];

			if(AOM_ask_value_string(Pcode,"project_desc",&projdes)==ITK_ok) PrintErrorStack();
			printf("\n projdes== %s", projdes);fflush(stdout);
				//object_desc   project_desc
		 }
	}

	//return 0;

	//t5_TstReqRef

  // Adi dont allow multiple requests to get created on same ref number

	printf("\nTR_No ---------------- %s \n",TR_No);fflush(stdout);

	int		n_Input					= 1;
	int		TRCount					= 0;
	tag_t	*TRObj					= NULL;
	char	*qry_Input[1]			= {"Test Request Reference No"};
	char	*values[1];
	tag_t	ProQryTRObj			= NULLTAG;
    char *RevObjName=NULL;
	values[0] = TR_No;

	if(QRY_find2("Test Request Query", &ProQryTRObj));
	if(ProQryTRObj)
	{
		 if(QRY_execute(ProQryTRObj, n_Input, qry_Input, values, &TRCount, &TRObj));
		 printf("\n QUERY for TR_No count== %d", TRCount);fflush(stdout);
	}

	if (TRCount == 0)
	{
		printf ("\n TR  not found in TCUA \n"); fflush(stdout);

	int STrLProj=tc_strlen(TR_RqProjDes);
	printf("\n TR_RqProjDes length is :%d",STrLProj);fflush(stdout);

	

	TCTYPE_find_type("T5_TestRq", NULL, &boTypeTag);
	TCTYPE_find_type("T5_TestRqRevision", NULL, &boTypeTag_r);
	if(boTypeTag != NULLTAG) 
		printf("\n T5_TestRq Type Tag Found. \n");fflush(stdout);

	if(boTypeTag_r != NULLTAG) 
		printf("\n T5_TestRqRevision Revision Type Tag Found. \n");fflush(stdout);
	
	TCTYPE_construct_create_input (boTypeTag, &creInputTag);
	if(creInputTag != NULLTAG) 
		printf("\nInput Tag Created for item id. \n");fflush(stdout);
	boTypeTag = NULLTAG;

	TCTYPE_construct_create_input (boTypeTag_r, &creInputTag_r);
	if(creInputTag_r != NULLTAG) 
		printf("\nInput Tag Created for item id Revision. \n");fflush(stdout);
	boTypeTag_r = NULLTAG;


	AOM_set_value_string(creInputTag_r, "t5_RqDomain", TR_Domain);
	printf("\n t5_RqDomain attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqProjCode", TR_ProjCode);
	printf("\n t5_RqProjCode attributes SET !!!!");fflush(stdout);
	//if(STrLProj>0)
	//	{
			  ITK_CALL(AOM_set_value_string(creInputTag_r, "t5_RqProjDes", projdes));
	//	}
	//	else
	//	{
	//		AOM_set_value_string(creInputTag_r, "t5_RqProjDes", "NA");
	//	}
	AOM_set_value_string(creInputTag_r, "t5_BU", TR__BU);
	printf("\n t5_BU attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_WBS", TR_WBS);
	printf("\n t5_WBS attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_WbsDesc", TR_WbsDesc);
	AOM_set_value_string(creInputTag_r, "t5_TestSubGrp", TR_SubGrp);
	printf("\n t5_TestSubGrp attributes SET !!!!");fflush(stdout);
	//AOM_set_value_string(creInputTag_r, "t5_RqAggregate", TR_RqAggregate);

	//AOM_set_value_string(creInputTag_r, "t5_RqProgram", GetProgram(TR_RqProjCode)); 
	//ITK_CALL(AOM_set_value_string(creInputTag_r, "t5_RqProgram", TR_Program)); //Adi changed
	//ITK_CALL(AOM_UIF_set_value(creInputTag_r,"t5_RqProgram",TR_Program)); //Adi changed
	printf("\n t5_RqProgram attributes SET [%s]!!!!\n",TR_Program);fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqDesStatus", "DR3");
	AOM_set_value_string(creInputTag_r, "t5_TstReqRef", TR_No);
	//AOM_set_value_string(creInputTag_r, "t5_RqRefDVP", TR_RqRefDVP);
	//AOM_set_value_string(creInputTag_r, "t5_RqReqDep", TR_RqReqDep);
	AOM_set_value_string(creInputTag_r, "t5_RqVehStage", "Beta");

	AOM_set_value_string(creInputTag_r, "t5_RqSupplier", TR_RqSupplier);
	printf("\n t5_RqSupplier attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqInvType", TR_Reason);
	printf("\n t5_RqInvType attributes SET !!!!");fflush(stdout);

	if (tc_strlen(TR_DescComp)<249)
	{
		AOM_set_value_string(creInputTag_r, "t5_DescComp", TR_DescComp);
        printf("\n Desc Comp leass than 249--------------");fflush(stdout);
	}
	else
	{
		printf("\n subString(TR_DescComp,0,248) : %s",subString(TR_DescComp,0,248));fflush(stdout);
		printf("\n TR_DescComp : %s",TR_DescComp);fflush(stdout);
		AOM_set_value_string(creInputTag_r, "t5_DescComp", subString(TR_DescComp,0,248));
		AOM_set_value_string(creInputTag_r, "t5_RqTestDetails", TR_DescComp);
	}
	printf("\n t5_DescComp attributes SET !!!!");fflush(stdout);
	
	 //Remark
	AOM_set_value_string(creInputTag_r, "t5_RqBGHistory", TR_RqAggregate);
	printf("\n TR_RqAggregate attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqChkMetRep", GetBoolean(TR_RqChkMetRep));
	printf("\n t5_RqChkMetRep attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqChkQaRep", GetBoolean(TR_RqChkQaRep));
	printf("\n t5_RqChkQaRep attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_RqChkPartyRep", GetBoolean(TR_RqChkPartyRep));
	printf("\n t5_RqChkPartyRep attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "t5_SamplPeriGvn", GetBoolean(TR_SamplPeriGvn));
	
	//AOM_set_value_string(creInputTag_r, "t5_RqGIN", TR_RqGIN);
	//AOM_set_value_string(creInputTag_r, "t5_PrtFIREng",TestEngineer);
	//AOM_set_value_string(creInputTag_r, "t5_PrtFIRChfEng",Owner);
	AOM_set_value_string(creInputTag_r, "t5_RqMetRepNo", TR_RqMetRepNo);
	AOM_set_value_string(creInputTag_r, "t5_RqQaRepNo", TR_RqQaRepNo);
	AOM_set_value_string(creInputTag_r, "t5_RqPartyRepNo", TR_RqPartyRepNo);
	AOM_set_value_string(creInputTag_r, "t5_RqSmplNo", TR_RqSmplNo);
	printf("\n Report nos attributes SET !!!!");fflush(stdout);
	AOM_set_value_string(creInputTag_r, "item_revision_id", "A;1");
	


	printf("\n Revision attributes SET !!!!");fflush(stdout);
	

	AOM_set_value_tag(creInputTag, "revision",creInputTag_r);



		QRY_ignore_case_on_search(TRUE);
		QRY_find2("tm_TstRq", &qryTag);
		//ifail=QRY_find2("General...", &qryTag);


		if (qryTag)
		{
			printf("\n Eff:Found Query tm_TstRq111111 \n");fflush(stdout);
		}
		else
		{
			printf("\n Eff:Not Found Query tm_TstRq11 \n");fflush(stdout);
			return 0;
		}
		TR_RqDomain_STR=(char *) MEM_alloc(30);
		tc_strcpy(TR_RqDomain_STR,"");
		tc_strcat(TR_RqDomain_STR,TR_Domain);
		tc_strcat(TR_RqDomain_STR,"-UA/*");

		printf("\n serch string <%s> \n",TR_RqDomain_STR);fflush(stdout);
		
		char   *qry_entry[1]  = {"ID"};
		char   **qry_values     =  (char **) MEM_alloc(10 * sizeof(char *));
		int n_entry    = 1,rsltCount=0;
		qry_values[0] = TR_RqDomain_STR;

		char *keys[1] = {"creation_date"};
		int  orders[1]  ={2};


		QRY_execute_with_sort(qryTag,n_entry,qry_entry,qry_values,1,keys,orders,&rsltCount,&TRObjectTags);
		//ifail=QRY_execute(qryTag, n_entry, qry_entry, qry_values, &rsltCount, &TRObjectTags);
		printf(" \n TRObjectTags :%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{
			CALLAPI(AOM_ask_value_string(TRObjectTags[0],"item_id",&TR_NO_LAT));
			printf("\nTR_NO_LAT is  = [%s]\n", TR_NO_LAT);fflush(stdout);

			strtok( TR_NO_LAT, "/" );
			SerialNos	  = strtok ( NULL, "/" );

			printf("\nTR_NO_LAT SerialNos is  = [%s]\n", SerialNos);fflush(stdout);

			SerialNosInt=atoi(SerialNos);
			SerialNosInt++;
			//SerialNosInt=50;

			sprintf(strTemp,"%05d",SerialNosInt);

			printf("\nTR_NO_LAT strTemp is  = [%s]\n", strTemp);fflush(stdout);

		}
        tc_strcpy(TR_NO_LAT_str,"");
		tc_strcpy(TR_NO_LAT_str,TR_Domain);
		tc_strcat(TR_NO_LAT_str,"-UA/");
		tc_strcat(TR_NO_LAT_str,strTemp);
		
		


		printf("\n TR_NO_LAT_str : %s \t \n",TR_NO_LAT_str);fflush(stdout);
		//return 0;

		
		if(TR_NO_LAT_str)
		{
			status = AOM_set_value_string(creInputTag, "item_id", TR_NO_LAT_str);
				printf("\n TR is manadatory attribute. 1");fflush(stdout);


			status = AOM_set_value_string(creInputTag, "object_name", TR_No);
			printf("\n TR is manadatory attribute. 2");fflush(stdout);
			status = AOM_set_value_string(creInputTag, "object_desc", "RMDV");

			printf("\n TR is manadatory attribute. 3");fflush(stdout);


			//Creating Object
			printf("\n Creating TR Object ......................... \n");fflush(stdout);
			status = TCTYPE_create_object (creInputTag, &boTag) ;

			//if(creInputTag != NULLTAG) MEM_free(&creInputTag);
			creInputTag = NULLTAG;
			if(boTag != NULLTAG) 
			{
				printf("\n TR Object Created. \n");fflush(stdout);
			}
			else
			{
				printf("\n TR Object not Created 1. \n");fflush(stdout);
				

			}
			ITK_CALL(AOM_save(boTag));
			ITK_CALL(AOM_refresh(boTag,0));
			ITK_CALL(AOM_unlock(boTag));

			if (ifail != ITK_ok )
			{
				printf("\n TR Object not Created. \n");fflush(stdout);
				
			}
			//boTag = NULLTAG;


					



			ITEM_ask_latest_rev(boTag,&itemRev_t);
			printf("\n Option Value is created......\n");fflush(stdout);
			AOM_UIF_ask_value(itemRev_t,"object_string",&RevObjName); 
			printf("\n rev name:%s",RevObjName);fflush(stdout);
			ITK_CALL(AOM_save(itemRev_t));
			ITK_CALL(AOM_unlock(itemRev_t));
		}
			/*ITK_CALL(SA_find_user2(Owner, &user_tag));
			if (user_tag)
			{
				printf("\nproperty Value set  11...!!\n");fflush(stdout);
				ITK_CALL(SA_find_group("POLY.Testing-Metallurgy", &group));
			
				if (group)
				{
						ITK_CALL(AOM_set_ownership(boTag,user_tag ,group));
						ITK_CALL(AOM_set_ownership(itemRev_t,user_tag ,group));
						printf("\nproperty Value set...!!\n");fflush(stdout);
						ifail=AOM_save(boTag);
						ifail=AOM_save(itemRev_t);
						printf("\nproperty11 Value set...!!\n");fflush(stdout);
						
				}*/
			//}




				printf("Created TEST REQUEST NUMBER IS :%s",TR_NO_LAT_str);fflush(stdout);

			//ITEM_find_item(TR_NO_LAT_str,&item_t);
			if(itemRev_t)
			{
				tag_t relation_type1=NULLTAG;
				printf("\n TR FOUND");fflush(stdout);
				//ITEM_ask_latest_rev(item_t,&itemRev_t);
				AOM_UIF_ask_value(itemRev_t,"object_type",&LatRev_ObjectType);
				printf("\n Object Type of Latest Revision is :%s",LatRev_ObjectType);fflush(stdout);

				CALLAPI(GRM_find_relation_type("T5_TR_DesRev_Rel",&relation_type1));
				
				//Prt = (char *)MEM_alloc(100 * sizeof(char));

				
				
				
				//tc_strcpy(Prt,"");
				printf("\n Part_Number is :%s",Part_Number);fflush(stdout);								//NEW
				remove_white_spaces(Part_Number);														//NEW
				printf("\n Part_Number AFTER removing white space IS :%s",Part_Number);fflush(stdout);  //NEW

				if(Part_Number != NULL)
				{
					//					int iii=0;
					//					int STrL=tc_strlen(Part_Number);
					//					printf("\n Part_Number length is :%d",STrL);fflush(stdout);
					//
					//					if (STrL>0)
					//					{
					//						for (iii=0;iii<STrL-11;iii++)
					//						{
					//							char*    Prt = NULL;
					//							//Prt="";
					//							tag_t tags_found4=NULLTAG;
					//							tag_t tags_found4_Rev=NULLTAG;
					//							Prt=subString(Part_Number,iii,12);
					//
					//							printf("\n Part going to be serched is :%s",Prt);fflush(stdout);
					//
					//							
					//							ITEM_find_item(Prt,&tags_found4);
					//
					//							if (tags_found4)
					//							{
					//								printf("\n Part found \n :%s",Prt);fflush(stdout);
					//								ITEM_ask_latest_rev(tags_found4,&tags_found4_Rev);
					//
					//								if (tags_found4_Rev)
					//								{
					//									CALLAPI(GRM_create_relation(itemRev_t,tags_found4_Rev,relation_type1,NULLTAG,&Rel_dcr_part));
					//									ITK_CALL(GRM_save_relation(Rel_dcr_part));
					//								}
					//							}
					//						}
					//					}

							
						/**************************NEW below*******************/



					int iii=0;
					int STrL=tc_strlen(Part_Number);
					printf("\n Part_Number length is :%d",STrL);fflush(stdout);
					if (STrL>0)
					  {
	

						//tc_strdup(Part_Number,&Part_NumberDup);
						tc_strcpy(Part_NumberDup,Part_Number);

						Part_NumberX	  =tc_strtok(Part_NumberDup,",");	    //NEW  

						printf("\n Part Part_NumberX [%s]\n",Part_NumberX);fflush(stdout);
						iWrite=0;
						//while(Part_NumberX != NULL)								 
						while(Part_NumberX)								 
						{	
							printf("\n iWrite 0000000000 -------------> [%d]\n",iWrite);fflush(stdout);
							if(iWrite == 0)
							{
								setAddStr(&iWrite,&PartSet,Part_NumberX);
								//iWrite=iWrite+1;
								printf("\n iWrite 111111111 -------------> [%d]\n",iWrite);fflush(stdout);
							}
							else
							{
								printf("\n Part going to be serched is :[%s]",Part_NumberX);fflush(stdout);   
								if(setFindStr1(&iWrite,&PartSet,Part_NumberX)==-1)
								{
									setAddStr(&iWrite,&PartSet,Part_NumberX);
									//iWrite++;

									printf("\n iWrite 222222222 -------------> [%d]\n",iWrite);fflush(stdout);
								}
								else
								{
									printf("\n Part already added\n",Part_NumberX);fflush(stdout); 
								}	
							}
							
							Part_NumberX	  =tc_strtok(NULL,",");	
							
						}
						
						printf("\n iWrite 3333333333 -------------> [%d]\n",iWrite);fflush(stdout);
						for (iii=0;iii<iWrite;iii++)					//NEW
						{

							printf("\n in Iwrite  ---------------------->:%s",PartSet[iii]);fflush(stdout);
							Prt1=tc_strtok(PartSet[iii],"/");		//123456/NR;1			 
							printf("\n Prt1 ----------------> \n :%s",Prt1);fflush(stdout);
							reid=tc_strtok(NULL,"/");
							printf("\n reid ----------------> \n :%s",reid);fflush(stdout);//NR;1

							reidDup=(char *) MEM_alloc(20);               //Adi for specific rev seq
							nwRev		=(char *) MEM_alloc(10);
							tc_strcpy(reidDup,reid);//NR;1
							Rev=tc_strtok(reidDup,";");//NR
							Seq=tc_strtok(NULL,"");//1

							tc_strcpy(nwRev,"");
							tc_strcat(nwRev,Rev);
							tc_strcat(nwRev,"*");
							tc_strcat(nwRev,Seq);
							printf("\nAAAAAAAAA  nwRev:::::::: = %s\n", nwRev);fflush(stdout);

							
			
							ITEM_find_item(Prt1,&tags_found4);


							if (tags_found4)
							{
								printf("\n Part found \n :%s",Prt1);fflush(stdout);
								ITEM_ask_latest_rev(tags_found4,&tags_found4_Rev); 

									const char **attrs6  = (const char **) MEM_alloc(2 * sizeof(char *));
									const char **values6 = (const char **) MEM_alloc(2 * sizeof(char *));
									attrs6[0]	   = "item_id";
									values6[0]     = (char *)Prt1;
									ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,attrs6, values6,nwRev, &n_tags_found6, &tags_found6));
									
									MEM_free(attrs6);
									MEM_free(values6);

									if (n_tags_found6>0)
									{
									   ItemRevTag= tags_found6[0];

									   	AOM_UIF_ask_value(ItemRevTag,"object_type",&PartObjectType);
										printf("\n PartObjectType is :[%s]",PartObjectType);fflush(stdout);

									    if( AOM_ask_value_string(ItemRevTag,"item_id",&itemid)!=ITK_ok);
										printf("\n itemid  is----> [%s]\n",itemid);

										if( AOM_ask_value_string(ItemRevTag,"item_revision_id",&itemrevid)!=ITK_ok);//A;1
										printf("\n item_revision_id  is----> [%s]\n",itemrevid);
									}

								//return 0;

								//if (tags_found4_Rev)
								if (ItemRevTag)
								{
									//CALLAPI(GRM_create_relation(itemRev_t,tags_found4_Rev,relation_type1,NULLTAG,&Rel_dcr_part));
									CALLAPI(GRM_create_relation(itemRev_t,ItemRevTag,relation_type1,NULLTAG,&Rel_dcr_part));
									ITK_CALL(GRM_save_relation(Rel_dcr_part));
									printf("\n After grm save---> \n");
								}
							}
						}					  
					}

						/**************************NEW*******************/

					printf("\n ATTENTION ATTENTION !!!!!! \n");fflush(stdout);
					ITK_CALL(AOM_lock(itemRev_t));
					ITK_CALL(AOM_set_value_string(itemRev_t, "t5_RqProgram", TR_Program));
					ITK_CALL(AOM_set_value_string(itemRev_t, "t5_CtrDrwNo", itemid));
					ITK_CALL(AOM_save(itemRev_t));
					printf("\n\t after setting value of Program AOM_save itemRev_t"); fflush(stdout);

					if(tc_strcmp(TR_Domain,"Testing-Crash")==0)
					{
					   TCrashInitiateAndAssign(RevObjName, itemRev_t,TR_No,TR_NO_LAT_str, boTag);

				       printf("\n\t after TCrashInitiateAndAssign function 7777777"); fflush(stdout);
					   return 0;
					}
				

					printf("\n auto submit Test Request Template \n");fflush(stdout);
					ITK_CALL(EPM_find_template2("Test Request Template For IDT and TMT",0,&template_tag));
					///ITK_CALL(EPM_find_template2("Testing_TestRequest",0,&template_tag));
					if (template_tag!=NULLTAG)
					{
						printf("\n Submit RMDV to workflow\n");fflush(stdout);
						//ITK_CALL(EPM_create_process("IDT and TMT Process","",template_tag,1, &itemRev_t,&attachment_types,&test_job_a));
						ITK_CALL(EPM_create_process(RevObjName,"IDT TMT Workflow",template_tag,1, &itemRev_t,&attachment_types,&test_job_a));
						///ITK_CALL(EPM_create_process(RevObjName,"Testing Test Request Workflow",template_tag,1, &itemRev_t,&attachment_types,&test_job_a));
						printf("\n Submit RMDV in to workflow process complete\n");fflush(stdout);
					}
					else
					{
						printf("\n RMDV WORKFLOW PROCESS  Not Found \n");fflush(stdout);
					}



					char *TaskAssignment = NULL;


					tag_t job_Tag=NULLTAG;
					tag_t jobtype_Tag=NULLTAG;
					tag_t rootTask=NULLTAG;
					tag_t* subtask=NULLTAG;
					tag_t* taskAttachments=NULLTAG;
					tag_t* reviewSubTasks=NULLTAG;
					char dRftSpectype_name[TCTYPE_name_size_c+1];
					char	*EIDLinfo1		=  NULL;
					char	*parent_name		=  NULL;
					int tskcount=0;
					//int count=0;
					

					ITK_CALL(AOM_UIF_ask_value(itemRev_t,"fnd0ActuatedInteractiveTsks",&TaskAssignment));
					printf("\n DM:primary TaskAssignment is .. [%s]\n",TaskAssignment);fflush(stdout);

					if(tc_strcmp(TaskAssignment,"Assign Manager and Chief Engineer")==0)
					{


						ITK_CALL(EPM_get_current_job(itemRev_t,&job_Tag,&jobtype_Tag));
						ITK_CALL(TCTYPE_ask_name(jobtype_Tag,dRftSpectype_name));
						ITK_CALL(AOM_ask_value_string(job_Tag,"object_name",&EIDLinfo1)) ;
						printf("\n Inside [%s] [%s] \n",dRftSpectype_name,EIDLinfo1);fflush(stdout);



						ITK_CALL(EPM_ask_root_task(job_Tag,&rootTask));               					    
						ITK_CALL(EPM_ask_sub_tasks(rootTask,&tskcount,&subtask));                           
						ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
						printf("\n Parent Name: %s",parent_name);fflush(stdout);
						printf("No of subtasks = %d\n",tskcount);fflush(stdout);


						//printf("\n PROMOTING 1 \n");fflush(stdout);
                    
					    //printf("\n PROMOTING 2 \n");fflush(stdout);
                        

                                        

										int v=0;
										int tskcount13 = 0;
										int tskcount14 = 0;                     
										//int tskcount9 = 0;
										int signoffCount = 0;
										
										tag_t    *signoffs      =  NULLTAG;
										tag_t    *childtask13      =  NULLTAG;
										tag_t    *childtask14      =  NULLTAG;
										//tag_t    *childtask9      =  NULLTAG;

										char	*subtask0		=  NULL;
										char	*subtask1		=  NULL;
										char	*subtask2		=  NULL;
										char	*subtask3		=  NULL;
										char	*subtask4		=  NULL;
										char	*subtask5		=  NULL;
										char	*subtask6		=  NULL;
										char	*subtask7		=  NULL;
										char	*subtask8		=  NULL;
										char	*subtask9		=  NULL;
										char	*subtask10		=  NULL;
										char	*subtask11		=  NULL;
									    char	*subtask12		=  NULL;
										char	*subtask13		=  NULL;
										char	*subtask14		=  NULL;
										char	*subtask15		=  NULL;
										

                                      char    *task_type13     =  NULL;
                                      char    *task_type14    =  NULL;
                                      //char    *task_type9     =  NULL;

										    
                                            
//								 ITK_CALL(EPM_promote_task(subtask[1],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[1],"object_name",&subtask1));
//								 printf("\n subtask1 is: %s",subtask1);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[2],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[2],"object_name",&subtask2));
//								 printf("\n subtask2 is: %s",subtask2);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[3],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[3],"object_name",&subtask3));
//								 printf("\n subtask3 is: %s",subtask3);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[5],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[5],"object_name",&subtask5));
//								 printf("\n subtask5 is: %s",subtask5);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[6],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[6],"object_name",&subtask6));
//								 printf("\n subtask6 is: %s",subtask6);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[7],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[7],"object_name",&subtask7));
//								 printf("\n subtask7 is: %s",subtask7);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[8],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[8],"object_name",&subtask8));
//								 printf("\n subtask8 is: %s",subtask8);fflush(stdout);


											ITK_CALL(EPM_promote_task(subtask[15],"Promote for RMDV"));
											ITK_CALL(AOM_ask_value_string(subtask[15],"object_name",&subtask15));
											printf("\n subtask15 is: %s",subtask15);fflush(stdout);
											ITK_CALL(EPM_promote_task(subtask[4],"Promote for RMDV"));
											ITK_CALL(AOM_ask_value_string(subtask[4],"object_name",&subtask4));
											printf("\n subtask4 is: %s",subtask4);fflush(stdout);
											ITK_CALL(EPM_promote_task(subtask[0],"Promote for RMDV"));
											ITK_CALL(AOM_ask_value_string(subtask[0],"object_name",&subtask0));
											printf("\n subtask0 is: %s",subtask0);fflush(stdout);

//								 ITK_CALL(EPM_promote_task(subtask[9],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[9],"object_name",&subtask9));
//								 printf("\n subtask9 is: %s",subtask9);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[10],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[10],"object_name",&subtask10));
//								 printf("\n subtask10 is: %s",subtask10);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[11],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[11],"object_name",&subtask11));
//								 printf("\n subtask11 is: %s",subtask11);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[12],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[12],"object_name",&subtask12));
//								 printf("\n subtask12 is: %s",subtask12);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[13],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[13],"object_name",&subtask13));
//								 printf("\n subtask13 is: %s",subtask13);fflush(stdout);
//								 ITK_CALL(EPM_promote_task(subtask[14],"Promote for RMDV"));
//								 ITK_CALL(AOM_ask_value_string(subtask[14],"object_name",&subtask14));
//								 printf("\n subtask14 is: %s",subtask14);fflush(stdout);



											

											
											


										tag_t	objTag			=NULLTAG;
										tag_t	objTypTag			=NULLTAG;
										tag_t	ObjTypTR			=NULLTAG;
										tag_t	*attachments1		=NULLTAG;
										tag_t	*tags_found		=NULLTAG;
										tag_t	*TR_Particpant		=NULLTAG;
										tag_t	*TR_Reviewr		=NULLTAG;
										int count3=0;
										int l=0,j=0,PrtCount=0,n_tags_found=0;
										logical is_latest;
										char *TestReqNos=NULL;
										char *dmlrelease_type=NULL;
										char *TR_Project=NULL;
										char *TR_Project_Program=NULL;
										char   ObjTyp[TCTYPE_name_size_c+1];
										char   type_name7[TCTYPE_name_size_c+1];
										tag_t TR_Particpant_rel_type;
										int iii=0;
										CALLAPI(EPM_ask_root_task(subtask[14],&rootTask));
										
										CALLAPI(EPM_ask_attachments (rootTask,EPM_target_attachment,&count3,&attachments1));
										printf("\nSVR Release No of attachments1:%d",count3);	
										
										if(count3>0)
	                                    {
											for(l=0;l<count3;l++)
											{
												objTag=attachments1[l];
												if(TCTYPE_ask_object_type(objTag,&objTypTag));
												if(TCTYPE_ask_name(objTypTag,ObjTyp));
												printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

												if(AOM_ask_value_string(objTag,"item_id",&TestReqNos)!=ITK_ok)PrintErrorStack();
												printf("\n TR:DML/Task Number: [%s].", TestReqNos);fflush(stdout);
												
												if(GRM_find_relation_type("HasParticipant", &TR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();
												if(tc_strcmp(ObjTyp,"T5_TestRqRevision")==0)
												{
													
													printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
													if(GRM_list_secondary_objects_only(objTag,TR_Particpant_rel_type,&PrtCount,&TR_Particpant)!=ITK_ok)PrintErrorStack();
													printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
													int jk=0;
													for (jk=0;jk<PrtCount ;jk++ )
													{
														tag_t TR_PartTag = TR_Particpant[jk];
														if(TCTYPE_ask_object_type(TR_PartTag,&ObjTypTR));
														if(TCTYPE_ask_name(ObjTypTR,type_name7));
														printf("\n TR:DML:2 Participants Name: %s", type_name7);fflush(stdout);

														///Removal of VATS Review 1

														if (tc_strcmp(type_name7,"T5_TR_VatsRev")==0  || tc_strcmp(type_name7,"T5_TR_GrpHd")==0  || tc_strcmp(type_name7,"T5_TR_ClstrHd")==0 )
														{
															if(AOM_UIF_ask_value(TR_PartTag,"fnd0AssigneeUser",&TR_Reviewr)!=ITK_ok)PrintErrorStack();
															printf("\n TR:Removing GH or CH Reviewer: [%s] ",TR_Reviewr);fflush(stdout);
															AOM_lock(objTag);
															ITEM_rev_remove_participant (objTag,TR_PartTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_save(objTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_unlock(objTag);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
															AOM_refresh (objTag,TRUE);
															printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
														}
													}


													/// Addition of VATS Review 1

													if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy"))
													{

														printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);
														if(AOM_ask_value_string(objTag,"t5_RqProgram",&TR_Project_Program)!=ITK_ok)PrintErrorStack();
														printf("\n TR:TestReqNos: [%s] TR_Program: [%s]", TestReqNos,TR_Project_Program);fflush(stdout);
														
														char	*groupName_VATS			=  NULL;
														char	*roleName_VATS			=  NULL;
														tag_t	groupName_VATS_tag		=  NULLTAG;
														tag_t	roleName_VATS_tag			=  NULLTAG;
														tag_t	TR_VATS_Party			=  NULLTAG;
														tag_t	TR_VATS_Patri_Type			=  NULLTAG;
														tag_t	*VATS_Tags			=  NULLTAG;
														int No_VATS=0;
														

											
														
														printf("\n TR:TR_Project_Program: [%s] ", TR_Project_Program);fflush(stdout);
														groupName_VATS = (char	*)MEM_alloc(100);
														tc_strcpy(groupName_VATS,"VATS_Group");

														roleName_VATS = (char	*)MEM_alloc(100);
														tc_strcpy(roleName_VATS,TR_Project_Program);
														tc_strcat(roleName_VATS,"_Reviewer");

														printf("\n TR:groupName_VATS  1111: [%s] roleName_VATS: [%s]", groupName_VATS,roleName_VATS);fflush(stdout);


														printf("\n TR: Setting  VATS...");fflush(stdout);
														if(SA_find_group(groupName_VATS,&groupName_VATS_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_role2(roleName_VATS,&roleName_VATS_tag)!=ITK_ok)PrintErrorStack();
														if(SA_find_groupmember_by_role(roleName_VATS_tag,groupName_VATS_tag,&No_VATS,&VATS_Tags)!=ITK_ok)PrintErrorStack();
														printf("\n TR: No_VATS :[%d]",No_VATS);  fflush(stdout);
														if(No_VATS>0)
														{
															ITK_CALL(EPM_ask_sub_tasks(subtask[14],&tskcount14,&childtask14));
											                printf("\n tskcount14  is: %d",tskcount14);fflush(stdout);

															for(iii=0;iii<No_VATS;iii++)
															{	
																printf("\n TR:PCBU: VATS Reviewer no [%d]",iii);fflush(stdout);
																if(EPM_get_participanttype ("T5_TR_VatsRev",&TR_VATS_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_create_participant(VATS_Tags[iii],TR_VATS_Patri_Type,&TR_VATS_Party)!=ITK_ok)PrintErrorStack();
																AOM_lock(objTag);			
																if(ITEM_rev_add_participant(objTag,TR_VATS_Party)!=ITK_ok)PrintErrorStack();
																AOM_save(objTag);
																AOM_unlock(objTag);
															   if(VATS_Tags[iii] == NULLTAG)
															   {
																	printf("\n VATS_Tags %d  is null",iii);fflush(stdout);
															   }
															   else
															   { 
																	printf("\n VATS_Tags %d  is not null",iii);fflush(stdout); 
															   }
															   for( v=0; v<tskcount14; v++)
															   {
																   printf("\n ...........For loop Started ............");fflush(stdout);
																   ITK_CALL(AOM_ask_value_string(childtask14[v],"task_type",&task_type14));
					
																   printf("\n task_type14 is: %s",task_type14);fflush(stdout);

																   if(tc_strcmp(task_type14,"EPMSelectSignoffTask")==0)
																   {
																	   printf("\n <<<<<<<<Current task is SST of VATS task>>>>>>>>>");fflush(stdout);
					
																	   ITK_CALL(EPM_create_adhoc_signoff(childtask14[v], VATS_Tags[iii], &signoffCount, &signoffs));

																	   printf("\n signoffCount is: %d",signoffCount);fflush(stdout);

																	   ITK_CALL(EPM_set_adhoc_signoff_selection_done(childtask14[v], true));

																	   ITK_CALL(AOM_lock(childtask14[v]));

																	   ITK_CALL(AOM_set_value_int(childtask14[v],"signoff_quorum", signoffCount));

																	   ITK_CALL(AOM_save(childtask14[v]));

																	   ITK_CALL(AOM_unlock(childtask14[v]));  
																   }
																	 
															   }
																
															}

															  ITK_CALL(EPM_promote_task(childtask14[0],"Promote for RMDV"));
															
														}
														else 
													    {
														printf("\n >>>>>>>>>>>>>>>>VATS PARTICIPANTS NOT MAPPED <<<<<<<<<<<<<<");  fflush(stdout);
													    }

														AOM_refresh ( objTag,TRUE);
														MEM_free(VATS_Tags);
													}
														

													/// Addition of GroupHead Reviewer

													//printf("\n TR:ADD PARTICIPALNTS START.. \n");fflush(stdout);

													
													char	*groupName			=  NULL;
													//char	*groupName_CH			=  NULL;
													char	*roleName_GH			=  NULL;
													//char	*roleName_CH			=  NULL;
													char	*TR_SubGrp_Tok			=  NULL;
													char	*TR_SubGrp			=  NULL;
													char	*TR_Domain			=  NULL;
													char	*TR_BU			=  NULL;
													tag_t	groupName_tag		=  NULLTAG;
													//tag_t	groupName_tag_CH		=  NULLTAG;
													tag_t	roleName_GH_tag			=  NULLTAG;
													//tag_t	roleName_CH_tag			=  NULLTAG;
													tag_t	TR_GH_Party			=  NULLTAG;
													//tag_t	TR_CH_Party			=  NULLTAG;
													tag_t	TR_GH_Patri_Type			=  NULLTAG;
													//tag_t	TR_CH_Patri_Type			=  NULLTAG;
													tag_t	*GH_Tags			=  NULLTAG;
													//tag_t	*CH_Tags			=  NULLTAG;
													int No_GH=0;
													//int No_CH=0;
													

													if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy")|| tc_strstr(TestReqNos,"CAE-") || tc_strstr(TestReqNos,"Testing-Outdoor") || tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-Climate")|| tc_strstr(TestReqNos,"Testing-NVH")|| tc_strstr(TestReqNos,"Testing-Transmission"))
													{
														if(AOM_ask_value_string(objTag,"t5_TestSubGrp",&TR_SubGrp)!=ITK_ok)PrintErrorStack();
														printf("\n TR:TestReqNos: [%s] TR_SubGrp: [%s]", TestReqNos,TR_SubGrp);fflush(stdout);

														if(AOM_ask_value_string(objTag,"t5_RqDomain",&TR_Domain)!=ITK_ok)PrintErrorStack();
														printf("\n TR:TestReqNos: [%s] TR_Domain: [%s]", TestReqNos,TR_Domain);fflush(stdout);
									 
														groupName = (char	*)MEM_alloc(100);
														
														//roleName_CH = (char	*)MEM_alloc(100);
														roleName_GH = (char	*)MEM_alloc(100);

														tc_strcpy(roleName_GH,"Group_Head");

														if (tc_strstr(TestReqNos,"Testing-Indoor") || tc_strstr(TestReqNos,"Testing-Metallurgy")|| tc_strstr(TestReqNos,"Testing-Transmission"))
														{

															TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
															printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);

															tc_strcpy(groupName,TR_SubGrp_Tok);
															tc_strcat(groupName,".");
															tc_strcat(groupName,TR_Domain);
															//tc_strcpy(roleName_CH,"Cluster_Head");  
														}
														else if (tc_strstr(TestReqNos,"CAE-"))
														{
															tc_strcpy(groupName,TR_Domain);
															//tc_strcpy(roleName_CH,"Department_Head");  //Department_Head
														}
														else if (tc_strstr(TestReqNos,"Testing-Crash"))  //|| tc_strstr(TestReqNos,"Testing-NVH") || tc_strstr(TestReqNos,"Testing-Climate")
														{
															tc_strcpy(groupName,TR_Domain);   
														}
														else if (tc_strstr(TestReqNos,"Testing-Outdoor"))
														{
															//groupName_CH = (char	*)MEM_alloc(100);
															if(AOM_ask_value_string(objTag,"t5_BU",&TR_BU)!=ITK_ok)PrintErrorStack();
															printf("\n TR:TestReqNos: [%s] TR_BU: [%s]", TestReqNos,TR_BU);fflush(stdout);

															TR_SubGrp_Tok=tc_strtok(TR_SubGrp,"-");
															printf("\n TR_SubGrp_Tok => %s ",TR_SubGrp_Tok );fflush(stdout);

															tc_strcpy(groupName,TR_SubGrp_Tok);
															tc_strcat(groupName,".");
															tc_strcat(groupName,TR_Domain);
															tc_strcat(groupName,"_");
															tc_strcat(groupName,TR_BU);
															//tc_strcpy(roleName_CH,"Project_Head");  //Project_Head


		//															tc_strcpy(groupName_CH,TR_Domain);
		//															tc_strcat(groupName_CH,"_");
		//															tc_strcat(groupName_CH,TR_BU);

															printf("\n groupName => %s ",groupName);fflush(stdout);
															//printf("\n groupName_CH => %s",groupName_CH );fflush(stdout);
														}
														

														printf("\n TR:groupName  1111: [%s] roleName_GH: [%s]  ", groupName,roleName_GH);fflush(stdout);
														//printf("\n TR:roleName_CH: [%s]", roleName_CH);fflush(stdout);


														printf("\n TR: Setting  GH...");fflush(stdout);
														if(SA_find_group(groupName,&groupName_tag)!=ITK_ok)PrintErrorStack();
			//														if (groupName_CH)
			//														{
			//															if(SA_find_group(groupName_CH,&groupName_tag_CH)!=ITK_ok)PrintErrorStack();
			//														}
														
														if(SA_find_role2(roleName_GH,&roleName_GH_tag)!=ITK_ok)PrintErrorStack();
														//if(SA_find_role2(roleName_CH,&roleName_CH_tag)!=ITK_ok)PrintErrorStack();

														if(SA_find_groupmember_by_role(roleName_GH_tag,groupName_tag,&No_GH,&GH_Tags)!=ITK_ok)PrintErrorStack();
														printf("\n TR: No_GH :[%d]",No_GH);  fflush(stdout);
														if(No_GH>0)
														{
	                                                        ITK_CALL(EPM_ask_sub_tasks(subtask[13],&tskcount13,&childtask13));
											                printf("\n tskcount13  is: %d",tskcount13);fflush(stdout);
															
															for(iii=0;iii<No_GH;iii++)
															{	
																printf("\n TR: GH Reviewer no [%d]",iii);fflush(stdout);
																if(EPM_get_participanttype ("T5_TR_GrpHd",&TR_GH_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_create_participant(GH_Tags[iii],TR_GH_Patri_Type,&TR_GH_Party)!=ITK_ok)PrintErrorStack();
																AOM_lock(objTag);			
																if(ITEM_rev_add_participant(objTag,TR_GH_Party)!=ITK_ok)PrintErrorStack();
																AOM_save(objTag);
																AOM_unlock(objTag);
																if(GH_Tags[iii] == NULLTAG)
															   {
																	printf("\n GH_Tags %d  is null",iii);fflush(stdout);
															   }
															   else
															   { 
																	printf("\n GH_Tags %d  is not null",iii);fflush(stdout); 
															   }
															   for( v=0; v<tskcount13; v++)
															   {
																   printf("\n ...........For loop Started ............");fflush(stdout);
																   ITK_CALL(AOM_ask_value_string(childtask13[v],"task_type",&task_type13));
					
																   printf("\n task_type13 is: %s",task_type13);fflush(stdout);

																   if(tc_strcmp(task_type13,"EPMSelectSignoffTask")==0)
																   {
																	   printf("\n <<<<<<<<Current task is SST of Group Head task>>>>>>>>>");fflush(stdout);
					
																	   ITK_CALL(EPM_create_adhoc_signoff(childtask13[v], GH_Tags[iii], &signoffCount, &signoffs));

																	   printf("\n signoffCount is: %d",signoffCount);fflush(stdout);

																	   ITK_CALL(EPM_set_adhoc_signoff_selection_done(childtask13[v], true));

																	   ITK_CALL(AOM_lock(childtask13[v]));

																	   ITK_CALL(AOM_set_value_int(childtask13[v],"signoff_quorum", signoffCount));

																	   ITK_CALL(AOM_save(childtask13[v]));

																	   ITK_CALL(AOM_unlock(childtask13[v]));  
																   }

															    }
															}
															 
														}
														else 
													    {
														printf("\n >>>>>>>>>>>>>>>>GH PARTICIPANTS NOT MAPPED <<<<<<<<<<<<<<");  fflush(stdout);
													    }
												
														AOM_refresh ( objTag,TRUE);
														MEM_free(GH_Tags);
														

														/// Addition of ClusterHead Reviewer

				//														if (tc_strstr(TestReqNos,"Testing-Outdoor"))
				//														{
				//															if(SA_find_groupmember_by_role(roleName_CH_tag,groupName_tag_CH,&No_CH,&CH_Tags)!=ITK_ok)PrintErrorStack();
				//														}
				//														else if (tc_strstr(TestReqNos,"Testing-Crash") || tc_strstr(TestReqNos,"Testing-NVH") || tc_strstr(TestReqNos,"Testing-Climate"))
				//														{
				//															printf("\n TR:Skipping for Testing Crash/NAV/Climate \n");  fflush(stdout);
				//														}
				//														else
				//														{
				//															if(SA_find_groupmember_by_role(roleName_CH_tag,groupName_tag,&No_CH,&CH_Tags)!=ITK_ok)PrintErrorStack();
				//														}
				//
				//													
				//														printf("\n TR: No_CH :[%d]",No_CH);  fflush(stdout);
				//														if(No_CH>0)
				//														{
				//															ITK_CALL(EPM_ask_sub_tasks(subtask[9],&tskcount9,&childtask9));
				//											                printf("\n tskcount9  is: %d",tskcount9);fflush(stdout);
				//															
				//															for(iii=0;iii<No_CH;iii++)
				//															{	
				//																printf("\n TR: CH Reviewer no [%d]",iii);fflush(stdout);
				//																if(EPM_get_participanttype ("T5_TR_ClstrHd",&TR_CH_Patri_Type)!=ITK_ok)PrintErrorStack();
				//																if(EPM_create_participant(CH_Tags[iii],TR_CH_Patri_Type,&TR_CH_Party)!=ITK_ok)PrintErrorStack();
				//																AOM_lock(objTag);			
				//																if(ITEM_rev_add_participant(objTag,TR_CH_Party)!=ITK_ok)PrintErrorStack();
				//																AOM_save(objTag);
				//																AOM_unlock(objTag);
				//																if(CH_Tags[iii] == NULLTAG)
				//															   {
				//																	printf("\n CH_Tags %d  is null",iii);fflush(stdout);
				//															   }
				//															   else
				//															   { 
				//																	printf("\n CH_Tags %d  is not null",iii);fflush(stdout); 
				//															   }
				//															   for( v=0; v<tskcount9; v++)
				//															   {
				//																   printf("\n ...........For loop Started ............");fflush(stdout);
				//																   ITK_CALL(AOM_ask_value_string(childtask9[v],"task_type",&task_type9));
				//					
				//																   printf("\n task_type9 is: %s",task_type9);fflush(stdout);
				//
				//																   if(tc_strcmp(task_type9,"EPMSelectSignoffTask")==0)
				//																   {
				//																	   printf("\n <<<<<<<<Current task is SST of Cluster Head task>>>>>>>>>");fflush(stdout);
				//					
				//																	   ITK_CALL(EPM_create_adhoc_signoff(childtask9[v], CH_Tags[iii], &signoffCount, &signoffs));
				//
				//																	   printf("\n signoffCount is: %d",signoffCount);fflush(stdout);
				//
				//																	   ITK_CALL(EPM_set_adhoc_signoff_selection_done(childtask9[v], true));
				//
				//																	   ITK_CALL(AOM_lock(childtask9[v]));
				//
				//																	   ITK_CALL(AOM_set_value_int(childtask9[v],"signoff_quorum", signoffCount));
				//
				//																	   ITK_CALL(AOM_save(childtask9[v]));
				//
				//																	   ITK_CALL(AOM_unlock(childtask9[v]));  
				//																   }
				//															}
				//															AOM_refresh ( objTag,TRUE);
				//															MEM_free(CH_Tags);
				//														}
				//
				//													}
													

												}
											}

										}
                                       
									}     
											
										
								           
						                    //return ITK_ok;                                      
					}					
				}		
			}



//				char			*TestRqObjNm					= NULL;
//				char			*output						= NULL;
//				char			*FileStr						= NULL;
//				char			*ExePath						= NULL;
//				ExePath =(char *) MEM_alloc(sizeof(char)* 300);
//				
//				char mainFile[300];
//				char command[1000];
//				char docFile[300];
//				char **values = (char **) MEM_alloc(1 * sizeof(char *));
//				FileStr=MEM_alloc(1000);
//				tag_t *transfermodes=NULLTAG;
//				int transfermodeCnt=0;
//				tag_t PLMSession=NULLTAG;
//				char* TestRqObjNm1=NULL;
//				char* TestRqObjNm2=NULL;
//
//				tag_t objTypeTag = NULLTAG;
//				char  	TestRqType[TCTYPE_name_size_c+1];
//
//
//
//
//
//				printf("\n in TDM_ReportITK function3 change1");fflush(stdout);
//
//
//
//				if (itemRev_t)
//				{
//					
//
//					CALLAPI(TCTYPE_ask_object_type (itemRev_t, &objTypeTag));
//					CALLAPI(TCTYPE_ask_name( objTypeTag, TestRqType));
//					printf("\n\n\t\t type_name ==> %s\n", TestRqType);fflush(stdout);
//
//					CALLAPI(AOM_ask_value_string(itemRev_t,"item_id",&TestRqObjNm));
//					if (itemRev_t!=NULLTAG)
//					{
//						
//						STRNG_replace_str(TestRqObjNm,"/","_",&TestRqObjNm1);
//						STRNG_replace_str(TestRqObjNm1,"(","_",&TestRqObjNm2);
//						STRNG_replace_str(TestRqObjNm2,")","_",&FileStr);
//						printf("\n TDM_ReportFun1 function %s",FileStr);fflush(stdout);
//						
//						tc_strcpy(mainFile,"");
//						tc_strcat(mainFile,"/tmp/");
//						tc_strcat(mainFile,FileStr);
//						tc_strcat(mainFile,".xml");
//						TC_write_syslog("Main File = %s\n",mainFile);
//
//						tc_strcpy(docFile,"");
//						tc_strcat(docFile,"/tmp/");
//						tc_strcat(docFile,FileStr);
//						tc_strcat(docFile,".pdf");
//						TC_write_syslog("Doc File = %s\n",docFile);
//
//						printf("\n TDM_ReportFun function <%s> <%s>",mainFile,docFile);fflush(stdout);
//
//
//
//						
//
//						CALLAPI(PIE_create_session(&PLMSession));
//						CALLAPI(PIE_session_set_file(PLMSession,mainFile));
//						if (tc_strcmp(TestRqType,"T5_TestRqRevision")==0)
//						{
//							CALLAPI(PIE_find_transfer_mode2("tm_TestRequest_IDT","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
//						}
//
//						
//						CALLAPI(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
//						CALLAPI(PIE_session_export_objects(PLMSession,1,&itemRev_t));
//
//						
//                            tc_strcpy(ExePath,"/user/uaprodtrl/sks08539/TDM/Report/TDM_Pdf.sh");       
//                           
//							printf("\n Information 1 Value == [%s]", ExePath);fflush(stdout);
//
//							sprintf(command,"%s %s %s %s %s",ExePath,mainFile,docFile,TestRqType,FileStr);
//							printf("\n Command to be run  == <%s>", command);fflush(stdout);
//							system(command);
//
//							if(access(docFile,F_OK)!=-1)
//							{
//								tag_t specRelationType_t=NULLTAG;
//								tag_t PdfType=NULLTAG;
//								tag_t PdfDataset=NULLTAG;
//								tag_t PdfLatestDat_t=NULLTAG;
//								tag_t specificationRel_t=NULLTAG;
//								tag_t *DATASET=NULL;
//								char* PdfObjdesc=NULL;
//								char* PdfObjName=NULL;
//								int DsCnt=0;
//
//								printf("Doc file created successfully\n");fflush(stdout);
//								CALLAPI(AE_find_datasettype2("PDF",&PdfType));
//								if(PdfType == NULLTAG)
//								{
//									printf("Could not find Dataset Type PDF. Please check data model\n");fflush(stdout);
//									
//								}
//								int Icnt=0;
//								tag_t RelationDS=NULLTAG;
//								
//								CALLAPI(GRM_find_relation_type("TC_Attaches",&specRelationType_t));
//
//								CALLAPI(GRM_list_secondary_objects_only(itemRev_t,specRelationType_t,&DsCnt,&DATASET));
//								printf("\n TR DsCnt: %d",DsCnt);fflush(stdout);
//								printf("\n 1st line");fflush(stdout);
//								for (Icnt=0;Icnt<DsCnt ;Icnt++ )
//								{
//									CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_desc",&PdfObjdesc));
//									CALLAPI(AOM_ask_value_string(DATASET[Icnt],"object_name",&PdfObjName));
//
//									printf("\n TR DsCnt: <%s>   <%s>",PdfObjName,PdfObjdesc);fflush(stdout);
//									printf("\n 2nd line");fflush(stdout);
//									if ((tc_strcmp(PdfObjdesc,"TDM Pdf Report")==0) && (tc_strcmp(PdfObjName,FileStr)==0))
//									{
//										CALLAPI(GRM_find_relation(itemRev_t,DATASET[Icnt],specRelationType_t,&RelationDS));
//										if (RelationDS)
//										{
//											CALLAPI(GRM_delete_relation(RelationDS));
//										}
//									}
//								}
//
//								CALLAPI(AE_create_dataset_with_id(PdfType,FileStr,"TDM Pdf Report","","",&PdfDataset));
//								CALLAPI(AE_save_myself(PdfDataset));
//								CALLAPI(GRM_create_relation(itemRev_t,PdfDataset,specRelationType_t,NULLTAG,&specificationRel_t));
//								CALLAPI(AOM_load(specificationRel_t));
//								CALLAPI(GRM_save_relation(specificationRel_t));
//								CALLAPI(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
//								CALLAPI(AOM_refresh(PdfLatestDat_t,TRUE));
//								CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
//								//CALLAPI(AE_save_myself(PdfLatestDat_t));
//
//								AOM_save(PdfLatestDat_t);
//								AOM_refresh(PdfLatestDat_t, FALSE);
//								AOM_unload(PdfLatestDat_t);
//								remove(docFile);
//								output = "Report Generated Successfully and attached to revision in Attaches relationship";
//								printf("\n Report Generated Successfully and attached to revision in Attaches relationship");fflush(stdout);
//							}			
//							else
//							{
//								  printf("\n file object not found \n");fflush(stdout);
//								  output = "Report not generated. Please contact PLM support team";
//							}
//
//
//
//						printf("\n End of program.....!!\n\n");fflush(stdout);
//
//					}
//					else
//					{
//						  printf("\n Item revision not not found \n");fflush(stdout);
//						  output = "Report not generated. Please contact PLM support team";
//					}
//				}
//				else
//				{
//					  printf("\n Item not found \n");fflush(stdout);
//					  output = "Report not generated. Please contact PLM support team";
//				}



				if(itemRev_t != NULLTAG)
				{
						 createpdf(itemRev_t);

				}
				else
				{
				  printf("\n Item rev not found 20202020\n");fflush(stdout);
				}

				 excelfile(TR_No,TR_NO_LAT_str,boTag); 

	}
	else
	{
		printf("\n TR Already available in tcua \n");fflush(stdout);
	}
			
}

extern int ITK_user_main (int argc, char ** argv)
{
	int status;
	int ifail =0;

    
     FILE* fp=NULL;

	 char *inputfile=NULL;
     
	 //char*  user=NULL;
     //char* passwordfile;
     char* inputline=NULL;
     


     char* Filename_SS=NULL;





		char* TR_RqDomain=NULL;
		char* TR_RqProjCode=NULL;
		char* TR_RqProjDes=NULL;
		char* TR_BU=NULL;
		char* TR_WBS=NULL;
		char* TR_WbsDesc=NULL;
		char* TR_TestSubGrp=NULL;
		char* TR_RqAggregate=NULL;
		char* TR_RqProgram=NULL;
		char* TR_RqDesStatus=NULL;
		char* TR_No=NULL;
		char* TR_RqRefDVP=NULL;
		char* TR_RqReqDep=NULL;
		char* TR_RqVehStage=NULL;
		char* TR_RqSupplier=NULL;
		char* TR_RqInvType=NULL;
		char* TR_DescComp=NULL;
		char* TR_RqTestDetails=NULL;
		char* TR_RqBGHistory=NULL;
		char* TR_RqChkMetRep=NULL;
		char* TR_RqMetRepNo=NULL;
		char* TR_RqChkQaRep=NULL;
		char* TR_RqQaRepNo=NULL;
		char* TR_RqChkPartyRep=NULL;
		char* TR_RqPartyRepNo=NULL;
		char* TR_SamplPeriGvn=NULL;
		char* TR_RqSmplNo=NULL;
		char* TR_RqGIN=NULL;
		char* TestEngineer=NULL;
		char* Owner=NULL;
		char* Part_Number=NULL;
		char* TR_TstReqRef=NULL;
		tag_t rev_tag=NULLTAG;

		tag_t boTag= NULLTAG;
			tag_t item_t= NULLTAG;
	tag_t itemRev_t = NULLTAG;
	char *LatRev_ObjectType;



	char *part,*revv,*seq,*revSeq;

			tag_t creInputTag= NULLTAG;
	tag_t creInputTag_r= NULLTAG;
	tag_t boTypeTag= NULLTAG;
	tag_t boTypeTag_r= NULLTAG;
	tag_t* foundItemsMtag;
	tag_t* TR_Tags;
	tag_t rev;
	tag_t Rel_dcr_part;
	tag_t relation_type1;
	tag_t user_tag;
	tag_t group;


	inputfile = ITK_ask_cli_argument("-i=");
	

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
                printf("\n Auto login ");fflush(stdout);
                ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
                printf("\n Auto login .......\n");fflush(stdout);

    //printf("\n Item:[%s]\nRev:[%s]\nSeq[%s]",req_item,req_rev,req_seq);fflush(stdout);

    //ITK_CALL(ITEM_find_item(req_item, &item ));
	//TR_No,TR_RqDomain,TR_RqProjCode,TR_RqProjDes,TR_BU,TR_WBS,TR_WbsDesc,TR_TestSubGrp,TR_RqAggregate,TR_RqProgram,TR_RqDesStatus,TR_TstReqRef,
	//TR_RqRefDVP,TR_RqReqDep,TR_RqVehStage,TR_RqSupplier,TR_RqInvType,TR_DescComp,TR_RqTestDetails,TR_RqBGHistory,TR_RqChkMetRep,
	//TR_RqMetRepNo,TR_RqChkQaRep,TR_RqQaRepNo,TR_RqChkPartyRep,TR_RqPartyRepNo,TR_SamplPeriGvn,TR_RqSmplNo,TR_RqGIN,Part_Number,Owner,TestEngineer);


//TR_No,TR_RqDomain,TR_RqProjCode,TR_RqProjDes,TR_BU,TR_WBS,TR_WbsDesc,TR_TestSubGrp,TR_RqAggregate,TR_RqProgram,TR_RqDesStatus,TR_TstReqRef,TR_RqRefDVP,
//TR_RqReqDep,TR_RqVehStage,TR_RqSupplier,TR_RqInvType,TR_DescComp,TR_RqTestDetails,TR_RqBGHistory,TR_RqChkMetRep,TR_RqMetRepNo,TR_RqChkQaRep,TR_RqQaRepNo
//TR_RqChkPartyRep,TR_RqPartyRepNo,TR_SamplPeriGvn,TR_RqSmplNo,TR_RqGIN,Part_Number,Owner,TestEngineer);
	
	

		fp=fopen(inputfile,"r");
		
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(3000);
				while(fgets(inputline,3000,fp)!=NULL)
				{
					printf("\nproperty1234 Value set...!!\n");fflush(stdout);
			
						//fputs(inputline,stdout);
					TR_No				=strsep(&inputline,"^");
					TR_RqDomain				=strsep(&inputline,"^");
					TR_RqProjCode				=strsep(&inputline,"^");
					TR_RqProjDes				=strsep(&inputline,"^");
					TR_BU				=strsep(&inputline,"^");
					TR_WBS				=strsep(&inputline,"^");
					TR_WbsDesc				=strsep(&inputline,"^");
					TR_TestSubGrp				=strsep(&inputline,"^");
					TR_RqAggregate				=strsep(&inputline,"^");
					TR_RqProgram				=strsep(&inputline,"^");
					TR_RqDesStatus				=strsep(&inputline,"^");
					TR_TstReqRef				=strsep(&inputline,"^");
					TR_RqRefDVP				=strsep(&inputline,"^");
					TR_RqReqDep				=strsep(&inputline,"^");
					TR_RqVehStage				=strsep(&inputline,"^");
					TR_RqSupplier				=strsep(&inputline,"^");     
					TR_RqInvType				=strsep(&inputline,"^");
					TR_DescComp				=strsep(&inputline,"^");
					TR_RqTestDetails				=strsep(&inputline,"^");
					TR_RqBGHistory				=strsep(&inputline,"^");
					TR_RqChkMetRep				=strsep(&inputline,"^");
					TR_RqMetRepNo				=strsep(&inputline,"^");
					TR_RqChkQaRep				=strsep(&inputline,"^");
					TR_RqQaRepNo				=strsep(&inputline,"^");
					TR_RqChkPartyRep				=strsep(&inputline,"^");
					TR_RqPartyRepNo				=strsep(&inputline,"^");
					TR_SamplPeriGvn				=strsep(&inputline,"^");
					TR_RqSmplNo				=strsep(&inputline,"^");
					TR_RqGIN				=strsep(&inputline,"^");         
					Part_Number				=strsep(&inputline,"^");
					Owner				=strsep(&inputline,"^");
					TestEngineer				=strsep(&inputline,"^");
					
					

					printf("\nInput TR_RqDomain     :%s",TR_RqDomain);fflush(stdout);
					printf("\nInput TR_RqProjCode   :%s",TR_RqProjCode);fflush(stdout);
					printf("\nInput TR_RqProjDes    :%s",TR_RqProjDes);fflush(stdout);
					printf("\nInput TR_BU           :%s",TR_BU);fflush(stdout);
					printf("\nInput TR_WBS          :%s",TR_WBS);fflush(stdout);
					printf("\nInput TR_WbsDesc      :%s",TR_WbsDesc);fflush(stdout);
					printf("\nInput TR_TestSubGrp   :%s",TR_TestSubGrp);fflush(stdout);
					printf("\nInput TR_RqAggregate  :%s",TR_RqAggregate);fflush(stdout);
					printf("\nInput TR_RqProgram    :%s",TR_RqProgram);fflush(stdout);
					printf("\nInput TR_RqDesStatus  :%s",TR_RqDesStatus);fflush(stdout);
					printf("\nInput TR_No           :%s",TR_No);fflush(stdout);
					printf("\nInput TR_RqRefDVP     :%s",TR_RqRefDVP);fflush(stdout);
					printf("\nInput TR_RqReqDep     :%s",TR_RqReqDep);fflush(stdout);
					printf("\nInput TR_RqVehStage   :%s",TR_RqVehStage);fflush(stdout);
					printf("\nInput TR_RqSupplier   :%s",TR_RqSupplier);fflush(stdout);
					printf("\nInput TR_RqInvType    :%s",TR_RqInvType);fflush(stdout);
					printf("\nInput TR_DescComp     :%s",TR_DescComp);fflush(stdout);
					printf("\nInput TR_RqTestDetails:%s",TR_RqTestDetails);fflush(stdout);
					printf("\nInput TR_RqBGHistory  :%s",TR_RqBGHistory);fflush(stdout);
					printf("\nInput TR_RqChkMetRep  :%s",TR_RqChkMetRep);fflush(stdout);
					printf("\nInput TR_RqMetRepNo   :%s",TR_RqMetRepNo);fflush(stdout);
					printf("\nInput TR_RqChkQaRep   :%s",TR_RqChkQaRep);fflush(stdout);
					printf("\nInput TR_RqQaRepNo    :%s",TR_RqQaRepNo);fflush(stdout);
					printf("\nInput TR_RqChkPartyRep:%s",TR_RqChkPartyRep);fflush(stdout);
					printf("\nInput TR_RqPartyRepNo :%s",TR_RqPartyRepNo);fflush(stdout);
					printf("\nInput TR_SamplPeriGvn :%s",TR_SamplPeriGvn);fflush(stdout);
					printf("\nInput TR_RqSmplNo     :%s",TR_RqSmplNo);fflush(stdout);
					printf("\nInput TR_RqGIN        :%s",TR_RqGIN);fflush(stdout);
					printf("\nInput TestEngineer    :%s",TestEngineer);fflush(stdout);
					printf("\nInput Owner           :%s",Owner);fflush(stdout);
					printf("\nInput Part_Number     :%s",Part_Number);fflush(stdout);

					TR_Create(TR_RqDomain,
							  TR_RqProjCode,
							  TR_RqProjDes,
							  TR_BU,
							  TR_WBS,
							  TR_WbsDesc,
							  TR_TestSubGrp,
							  TR_RqAggregate,
							  TR_RqProgram,
							  TR_RqDesStatus,
							  TR_No,
							  TR_RqRefDVP,
							  TR_RqReqDep,
							  TR_RqVehStage,
							  TR_RqSupplier,
							  TR_RqInvType,
							  TR_DescComp,
							  TR_RqTestDetails,
							  TR_RqBGHistory,
							  TR_RqChkMetRep,
							  TR_RqMetRepNo,
							  TR_RqChkQaRep,
							  TR_RqQaRepNo,
							  TR_RqChkPartyRep,
							  TR_RqPartyRepNo,
							  TR_SamplPeriGvn,
							  TR_RqSmplNo,
							  TR_RqGIN,
							  TestEngineer,
							  Owner,
							  Part_Number);

				printf("\n\n\n\n===============================================================================================\n\n\n\n\n");


				}
				//return ITK_ok;
		}

		//ITK_CALL(POM_logout(false));
		if(fp){fclose(fp);fp=NULL;}
		return ITK_ok;
}




										




















//   ./t5_TR_Loader -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="120036_RMDV_Input.txt"
//   ./t5_TR_Loader -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="119305_RMDV_Input.txt"
