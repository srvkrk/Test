//gsoap ns service name:				 Cre_TR_RMDV
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:Cre_TR_RMDV
//gsoap ns service location:			 http://172.22.97.12:9080/cgi/Cre_TR_RMDV.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:Cre_TR_RMDV
//gsoap ns service method-documentation: Module name web service


int ns__Cre_TR_RMDV( char *TR_No, char *TR_RqDomain, char *TR_RqProjCode, char *TR_RqProjDes,char *TR_BU, char *TR_WBS,char *TR_WbsDesc,char* TR_TestSubGrp,char *TR_RqAggregate,char *TR_RqProgram, 
	char *TR_RqDesStatus,char *TR_TstReqRef, char *TR_RqRefDVP,char *TR_RqReqDep,char *TR_RqVehStage,char *TR_RqSupplier, char *TR_RqInvType,char *TR_DescComp, char *TR_RqTestDetails,char *TR_RqBGHistory,char *TR_RqChkMetRep,
	char* TR_RqMetRepNo,char *TR_RqChkQaRep, char *TR_RqQaRepNo, char *TR_RqChkPartyRep, char *TR_RqPartyRepNo, char *TR_SamplPeriGvn, char *TR_RqSmplNo, char *TR_RqGIN, char *Part_Number,char *Owner,char *TestEngineer,char **return_);
