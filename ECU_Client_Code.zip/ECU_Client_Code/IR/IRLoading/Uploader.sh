/home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable IR_Loading
while read line
do

#NewMCTDNo=`echo $line`
echo "$line"
#NewMCTDNo=`echo "$line" | sed 's/\//_/g'`

./IR_Loading -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file=$line.csv

echo "$updated"
done <List.txt


