#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <unistd.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

int ParticipntAssinmt(tag_t);

ParticipntAssinmt(tag_t partrevtag)
{

  //char* ObjTyp = NULL;
  char   ObjTyp[TCTYPE_name_size_c+1];
char   IRtype_name[TCTYPE_name_size_c+1];

  int PrtCount = 0;
  int jk=0;
  int iii=0;

  tag_t objTypTag = NULLTAG;
  tag_t ObjTypIR  = NULLTAG;
  tag_t *IR_Particpant = NULLTAG;
  tag_t IR_PartTag     = NULLTAG;
  tag_t IR_Particpant_rel_type = NULLTAG;


  char* IR_Reviewr =NULL;
 // char* IRtype_name =NULL;


	
	if(GRM_find_relation_type("HasParticipant", &IR_Particpant_rel_type)!=ITK_ok)PrintErrorStack();

	if(TCTYPE_ask_object_type(partrevtag,&objTypTag));

	if(TCTYPE_ask_name(objTypTag,ObjTyp));
	printf("\n Object Type: [%s]\n", ObjTyp);fflush(stdout);
  
	if(tc_strcmp(ObjTyp,"T5_IR_CLIST_DATARevision")==0)
	{
			
		printf("\n TR:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);

		if(GRM_list_secondary_objects_only(partrevtag,IR_Particpant_rel_type,&PrtCount,&IR_Particpant)!=ITK_ok)PrintErrorStack();

		printf("\n TR: PrtCount count: %d",PrtCount);fflush(stdout);	
		
		for (jk=0;jk<PrtCount ;jk++ )
		{
			 
			 IR_PartTag = IR_Particpant[jk];
			if(TCTYPE_ask_object_type(IR_PartTag,&ObjTypIR));
			if(TCTYPE_ask_name(ObjTypIR,IRtype_name));
			printf("\n IR: Participants Name: %s", IRtype_name);fflush(stdout);

			///Removal of CCID Reviewer 

			if (tc_strcmp(IRtype_name,"T5_COChead")==0)
			{
				if(AOM_UIF_ask_value(IR_PartTag,"fnd0AssigneeUser",&IR_Reviewr)!=ITK_ok)PrintErrorStack();
				printf("\n TR:Removing CCID Reviewer: [%s] ",IR_Reviewr);fflush(stdout);
				AOM_lock(partrevtag);
				ITEM_rev_remove_participant (partrevtag,IR_PartTag);
				printf("\n TR:REMOVE PARTICIPALNTS END. \n");fflush(stdout);
				AOM_save(partrevtag);
				printf("\n TR:REMOVE PARTICIPALNTS END.. \n");fflush(stdout);
				AOM_unlock(partrevtag);
				printf("\n TR:REMOVE PARTICIPALNTS END... \n");fflush(stdout);
				AOM_refresh (partrevtag,TRUE);
				printf("\n TR:REMOVE PARTICIPALNTS END.... \n");fflush(stdout);
			}
		}

				 /// Addition of COC Reviewer
		
			 char	*groupName			=  NULL;
			 char	*roleName			=  NULL;
			 char	*aggregate			=  NULL;

			 tag_t	group_tag		=  NULLTAG;
			 tag_t	role_tag			=  NULLTAG;
			 tag_t	CCID_Party			=  NULLTAG;
			 tag_t	CCID_Patri_Type			=  NULLTAG;
			 tag_t  *CCID_Tags			=  NULL;

			 int    No_CCID=0;
			
		


			if(AOM_ask_value_string(partrevtag,"t5_Aggregate",&aggregate)!=ITK_ok)PrintErrorStack();
		
			printf("\n IR:aggregate: [%s] ", aggregate);fflush(stdout);

			groupName = (char	*)MEM_alloc(100);
			roleName = (char	*)MEM_alloc(100);

			if(tc_strstr(aggregate,"APPLICATIONS")!=NULL)
			{
			  tc_strcpy(groupName,"APPLICATIONS");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"EXTERIOR")!=NULL)
			{
			  tc_strcpy(groupName,"EXTERIOR");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"INTERIOR")!=NULL)
			{
			  tc_strcpy(groupName,"INTERIOR");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL)
			{
			  tc_strcpy(groupName,"CHASSIS_INTEGRATION_AGGREGATES");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL)
			{
			  tc_strcpy(groupName,"DRIVELINE_INTEGRATION_AGGREGATES");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL)
			{
			  tc_strcpy(groupName,"ENGINE_INTEGRATION_AGGREGATES");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"SUSPENSION")!=NULL)
			{
			  tc_strcpy(groupName,"SUSPENSION");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL)
			{
			  tc_strcpy(groupName,"BRAKES_AND_WHEELS");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL)
			{
			  tc_strcpy(groupName,"POWER_AND_DISTRIBUTION");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"ENGINEBASE ENGINEERING")!=NULL)
			{
			  tc_strcpy(groupName,"ENGINE_BASE_ENGINEERING");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL)
			{
			  tc_strcpy(groupName,"TRANSMISSION");
			  tc_strcat(groupName,".InterfaceRule");
			}
			else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL)
			{
			  tc_strcpy(groupName,"POWERTRAIN");
			  tc_strcat(groupName,".InterfaceRule");
			}
			


			

			tc_strcpy(roleName,"COC_Head");

			printf("\n IR:groupName: [%s]   roleName: [%s]", groupName,roleName);fflush(stdout);


			printf("\n TR: Setting  CCID...");fflush(stdout);
			if(SA_find_group(groupName,&group_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_role2(roleName,&role_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_groupmember_by_role(role_tag,group_tag,&No_CCID,&CCID_Tags)!=ITK_ok)PrintErrorStack();
			printf("\n IR: No_CCID :[%d]",No_CCID);fflush(stdout);

		
			if(No_CCID>0)
			{
				
				for(iii=0;iii<No_CCID;iii++)
				{	
					printf("\n IR:CVBU: COCHead Reviewer no [%d]",iii);fflush(stdout);

					if(EPM_get_participanttype ("T5_COChead",&CCID_Patri_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(CCID_Tags[iii],CCID_Patri_Type,&CCID_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(partrevtag);			
					if(ITEM_rev_add_participant(partrevtag,CCID_Party)!=ITK_ok)PrintErrorStack();
					AOM_save(partrevtag);
					AOM_unlock(partrevtag);
				}
			
				AOM_refresh (partrevtag,TRUE);
				MEM_free(CCID_Tags);

			}

			
	}

}


extern int ITK_user_main (int argc, char ** argv)
{
	int status;
	int ifail =0;

	char *userid		=   NULL;
	char *password		=   NULL;
	char *group         =   NULL;
	char *partrevid         =   NULL;
	char* chklistdataNo         =   NULL;
	char* Revseq         =   NULL;
	char* sessionUsr         =   NULL;
	char* Rev							=NULL;
	char* rev1							=NULL;		 
	char* seq							=NULL;	
	char* TokCcidNum							=NULL;

	tag_t parttag      =   NULLTAG;
	tag_t partrevtag      =   NULLTAG;
	tag_t revtag      =   NULLTAG;


	chklistdataNo = ITK_ask_cli_argument("-s=");
	Revseq = ITK_ask_cli_argument("-r=");
	sessionUsr = ITK_ask_cli_argument("-su=");


   Rev=(char *)MEM_alloc(60);
   TokCcidNum=(char *)MEM_alloc(60);
	

	tc_strcpy (TokCcidNum,"" );
	tc_strcat (TokCcidNum,Revseq);

	rev1 = tc_strtok(TokCcidNum,"_");
	seq	 = tc_strtok(NULL,"_");

	printf("\n chklistdataNo   ==%s\n",chklistdataNo);fflush(stdout);
	printf("\n Aftertok rev   ==%s\n",rev1);fflush(stdout);
	printf("\n Aftertok seq   ==%s\n",seq);fflush(stdout);

	tc_strcpy(Rev,rev1);
	tc_strcat(Rev,";");
	tc_strcat(Rev,seq);

	printf("\n final Rev   ==%s\n",Rev);fflush(stdout);



    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

    printf("\n Auto login ");fflush(stdout);

    ITK_CALL(ITK_auto_login( ));

	printf("\n Auto login .......\n");fflush(stdout);

	ITK_CALL(ITK_set_journalling( TRUE ));


	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);




	printf("\n Part no : %s \n", chklistdataNo);

	ifail = ITEM_find_item(chklistdataNo,&parttag);

	if (parttag !=NULLTAG)
	{
		
	printf("\n Part tag found\n");
	

	ifail = ITEM_find_revision(parttag,Rev,&revtag);
	

		if (revtag!= NULLTAG)
		{
			printf("\n Part Rev tag found\n");

			  tag_t	chklistreltyp = NULLTAG;
			  tag_t* chkliststag = NULLTAG;
			  tag_t chklisttag = NULLTAG;
			  tag_t	chklistobjTypTag		= NULLTAG;
			  tag_t	chklistdatareltyp = NULLTAG;
			  tag_t* chklistdatastag = NULLTAG;
			  tag_t	chklistdatatag = NULLTAG;

			  int chklistcnt =0;
			  int chklistdatacnt=0;
			  int aa = 0;
			  int bb = 0;
			  

			  char   chklistObjTyp[TCTYPE_name_size_c+1];

			  char	*err		=  NULL;
			  char	*Ruleid		=  NULL;
			  char	*status		=  NULL;
			  char	*chklistdataid	=  NULL;
			  char	*Objtyp	=  NULL;
			  char	*RevObjName	=  NULL;
			  char	*Fname	=  NULL;
			  char	*chkprocess	=  NULL;
			  char	*Relstatus	=  NULL;
			  char	*err2	=  NULL;

              ParticipntAssinmt(revtag);
/*
			 ITK_CALL(GRM_find_relation_type("IMAN_reference",&chklistreltyp));
			 ITK_CALL(GRM_list_secondary_objects_only(revtag,chklistreltyp,&chklistcnt,&chkliststag));
			 printf("\n Ref Relation count : %d \n",chklistcnt);fflush(stdout);
			 if (chklistcnt>0)
			 {
				 for(bb=0;bb<chklistcnt;bb++)
				   {
					  chklisttag =chkliststag[bb];
					  if(TCTYPE_ask_object_type(chklisttag,&chklistobjTypTag)!=ITK_ok);
						if(TCTYPE_ask_name(chklistobjTypTag,chklistObjTyp)!=ITK_ok);
						printf("\n Object Type: [%s]\n", chklistObjTyp);fflush(stdout);



						if(tc_strcmp(chklistObjTyp,"T5_IR_CHECKLISTRevision") == 0)
						{
							
							printf("\n checklist Object Type is: [%s]\n", chklistObjTyp);fflush(stdout);
							ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&chklistdatareltyp));
							ITK_CALL(GRM_list_secondary_objects_only(chklisttag,chklistdatareltyp,&chklistdatacnt,&chklistdatastag));							
							
							for(aa=0;aa<chklistdatacnt;aa++)
							{
							 chklistdatatag =chklistdatastag[aa];

							   ParticipntAssinmt(chklistdatatag);

								printf("\n **************************** \n");fflush(stdout);
							}

						
						}
				   
		 
				   }
			 }*/

		
		}
		else 
		{
			printf("\n Part Rev tag not found\n");
		}
   }
   else
   {
	printf("\n Part tag not found\n");
   }
		
  printf("\n\n\n\n===============================================================================================\n\n\n\n\n");


return ITK_ok;
}