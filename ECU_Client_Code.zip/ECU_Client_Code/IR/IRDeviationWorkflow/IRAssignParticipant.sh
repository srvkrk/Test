echo "IR Deviation Workflow participant assignment Script Called"
cd /user/testcmi/Dev/devgroups/Akshay/IR/IRDeviationWorkflow/
#/home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable IR_AssignParticipants
/user/testcmi/Dev/devgroups/Akshay/IR/IRDeviationWorkflow/IR_AssignParticipants -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -s="$1" -r="$2" -su="$3"

echo "IR Deviation Workflow participant assignment completed"


