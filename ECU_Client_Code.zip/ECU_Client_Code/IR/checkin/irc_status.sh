echo "i am in testcmi"
echo "${1}_IR_STS.txt"
cd /user/testcmi/Dev/devgroups/Akshay/IR/checkin/
./IR_checklist -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file="${1}_IR_STS.txt"


