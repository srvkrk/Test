#!/bin/ksh
#. /user/omfprod/.bash_profile

#FileLocation=/user/omf9dev/devgroups/Aditya/RMDV_Shell  
#FileLocation=/user/omfprod/shells/RMDV  
FileLocation=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input  
echo "Checking data on $FileLocation"
cd /user/testcmi/Dev/devgroups/Akshay/IR/IR_Input
rm -f Confirmation.txt
ls *Input* > Confirmation.txt


#mail -s "RMDV PART LIST" adityaa.ttl@tatamotors.com -a /user/omfprod/shells/RMDV/Confirmation.txt

echo "Ashvin, Prashant -
We have recieved the attached Part Number Task Input files on Teamcenter Unified Server.
The attached data, is the data recieved till the time of sending this mail
Please connect with Rahul Shinde if you need any information

Regards
PLM Team" | mail -s "DATA RCVD FROM CAD" -r "at924736.ttl@tatamotors.com" -a /user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/Confirmation.txt at924736.ttl@tatamotors.com
