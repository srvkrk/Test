#!/bin/ksh
#. /user/uaprodtrl/.bash_profile

FileLocation=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input
echo "$FileLocation"

CopyFilesToLocation=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell
echo "$CopyFilesToLocation"

MoveFilesToLocation=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/Moved_Files/
echo "$MoveFilesToLocation"

MoveFilesToLocationOrig=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/Moved_Files/Moved_Files_Orig
echo "$MoveFilesToLocationOrig"

MoveCsvFilesToLocation=/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/Moved_CsvFiles

echo "Begin Data Upload shell UA"

cd /user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell
rm -f *.txt
rm -f *.txt.1
rm -f Final.txt
rm -f Fina1l.txt


echo "$i start copying files"
cp "$FileLocation"/*Input.txt $CopyFilesToLocation/

echo "Files copied to UA Shells folder"

#cd /user/uaprod/shells/RMDV

ls *Input* > Final1.txt
while read line
do
partno=`echo $line | cut -f1 -d','`
echo "$partno"

cat $partno | tr -d "\n" > $partno."1"
done </user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/Final1.txt

ls *Input*1 > Final.txt
echo "Calling exe..."

while read j
do
echo $j
#${CopyFilesToLocation}/IR_checklist -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$j"
/user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/IR_checklist -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file="$j"
done < /user/testcmi/Dev/devgroups/Akshay/IR/IR_Input/shell/Final.txt
#mv $FileLocation/*_Input.txt $MoveFilesToLocation
mv $CopyFilesToLocation/*_Input.txt* $MoveFilesToLocation
mv $FileLocation/*_Input.txt $MoveFilesToLocationOrig
#mv $CopyFilesToLocation/*.csv $MoveCsvFilesToLocation

