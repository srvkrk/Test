#!/bin/ksh
. /user/uaprodtrl/.bash_profile

#BASE_PATH=/user/uaprod/Adi/RMDV
BASE_PATH=/user/uaprodtrl/shells/RMDV
cd $BASE_PATH
echo "Begin RDMV Data Upload shell UA"

#dt=$(date --date yesterday "+ %Y/%m/%d")
#echo $dt

#date "+ %Y/%m/%d" | read dt1
#dt1=$(date "+ %Y/%m/%d" )
#echo ${dt1}

dt=$(date --date yesterday "+ %d-%b-%Y")
echo $dt

dt1=$(date --date tomorrow "+ %d-%b-%Y" )
echo ${dt1}

echo "Executing Exe for UA RMDV Consume"
/user/uaprodtrl/shells/RMDV/FirGrnRep -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -d1="$dt" -d2="$dt1"
#/user/uaprod/shells/RMDV/FirGrnRep -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba


echo "Executing Exe for UA RMDV Consume Completed"

echo "SHELL COMPLETE"

