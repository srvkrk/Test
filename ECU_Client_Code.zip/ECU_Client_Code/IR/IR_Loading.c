/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: IR_checklist.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** IR_checklist -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int IR(char*,char*,char*,char*,char*,char*,char*,char*,char*,char*);

//int createCheckListRowData(tag_t,char*,char*,char*,tag_t,char*,char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char            *Folder_name                =NULL;
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
//	Folder_name   = ITK_ask_cli_argument("-fp=");
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
/*	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	*/
		ifail = read_value_from_file(file);
//		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int		count	 				= 0;
	
	char	*item_id							= NULL;
	char	*IR_no					= NULL;
	char	*rev_id						= NULL;
	char	*Aggregates					= NULL;
	char	*agg_grp					= NULL;
	char	*module					= NULL;
	char	*submodule					= NULL;
	char	*applicable_modules					= NULL;
	char	*rule_desc					= NULL;
	char* irchecklist                           =NULL;
	char* irchecklistobj                        =NULL;
//	char 	*rev_id					= NULL;
	char 	 temp[2000];
//    char	*SrNo					= NULL;
   
	char *ImanFile_Name=NULL;
	char *FullPath=NULL;
	//*********************
  IR_no=(char *) MEM_alloc(100);
  rev_id=(char *) MEM_alloc(100);
  rule_desc=(char *) MEM_alloc(100);
  applicable_modules	=(char *) MEM_alloc(100);
  agg_grp	=(char *) MEM_alloc(100);
  Aggregates	=(char *) MEM_alloc(100);
  module=(char *) MEM_alloc(1000);
  submodule=(char *) MEM_alloc(1000);
  ImanFile_Name=(char *) MEM_alloc(1000);
  FullPath=(char *) MEM_alloc(1000);


	//******************
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 2000, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{


				IR_no = strtok(temp, "~");
				printf("\n IR_no:%s",IR_no);


				rev_id = strtok(NULL, "~");
				printf("\nrev_id:%s",rev_id);

				rule_desc = strtok(NULL, "~");
				printf("\nrule desc:%s",rule_desc);

				applicable_modules = strtok(NULL, "~");
				printf("\napplicable modules:%s",applicable_modules);

				agg_grp = strtok(NULL, "~");
				printf("\nagg grp:%s",agg_grp);

				Aggregates = strtok(NULL, "~");
				printf("\nAggregates:%s",Aggregates);
			

				module = strtok(NULL, "~");
				printf("\nmodule:%s",module);

				submodule = strtok(NULL, "~");
				printf("\nsubmodule:%s",submodule);

				ImanFile_Name = strtok(NULL,"~");
				printf("\nImanFile_Name:%s",ImanFile_Name);


              

          //      FullPath = strcpy(FullPath,"/user/cvprod/EE_loading/");
		        FullPath = strcpy(FullPath,"/user/cvprod/Akshay/IR/IR_Migration/");
			//	FullPath=strcat(FullPath,Folder_name);
		//		FullPath=strcat(FullPath,"/DVP_PDF/");
				FullPath=strcat(FullPath,ImanFile_Name);
				
				printf("\nFull_Path:%s",FullPath);

								
			
				ifail = IR(IR_no,rev_id,rule_desc,applicable_modules,agg_grp,Aggregates,module,submodule,ImanFile_Name,FullPath);

           //    ifail = Get_Qry_Execute(IR_no,rev_id,Container_Seq,Dataset_no,Dataset_Rev,Dataset_Seq,ImanFile_Name,FullPath);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
//	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       IR
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int IR(char* IR_no,char* rev_id,char* rule_desc,char* applicable_modules,char* agg_grp,char* Aggregates,char* module,char* submodule,char* ImanFile_Name,char* FullPath)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;

	//int PorjectCode = atoi(Project);
	
	tag_t			module_tag			= NULLTAG;	
	tag_t			moduleRev_tag			= NULL;
	tag_t           item_type_tag1           = NULLTAG;

	tag_t           item_create_input_tag1   = NULLTAG;
	
	tag_t            object1                = NULLTAG;
	
	tag_t            ChecklistRev            = NULLTAG;
	
    int                 n_items                = 0;
	int                n_items1                = 0;
	int                n_items2                = 0;
	tag_t               item_tag             = NULL;
	tag_t                module_rev         = NULLTAG;
	char               *tempRev_ID	          =NULL;
	tag_t                item_tag1           = NULL;
	tag_t                IR_Rev         = NULLTAG;
	
    tag_t relation_type;
	tag_t relation = NULLTAG;
	char* irchecklist=	NULL;
	
	 tag_t            tempChecklistRev            = NULLTAG;
    tag_t relation_type1;
	tag_t relation1 = NULLTAG;
	tag_t latest_rev_id         = NULLTAG;
	
   
	


	

	ITK_CALL(ITEM_find_item(IR_no,&item_tag1));
	printf("\niten find");

	

	if(item_tag1)
	{
			
			printf("\n IR Object is already Available.....updating\n"); fflush(stdout);
			ITK_CALL(ITEM_ask_latest_rev(item_tag1,&IR_Rev));
/*
if(tc_strcmp("NA",ImanFile_Name)!=0)
{
printf("\nDataset available for this object...adding dataset");fflush(stdout);
tag_t ItemQry     = NULLTAG;
tag_t* ContainerTag   = NULLTAG;
tag_t dataset_rel_type=NULLTAG;
tag_t dataset_rel_type2=NULLTAG;
tag_t datasettype=NULLTAG;
tag_t* datasetobj1=NULLTAG;
tag_t datasetobj2=NULLTAG;
tag_t Datasetobj3=NULLTAG;
tag_t Datasetobj4=NULLTAG;
tag_t DVPrelation=NULLTAG;
tag_t revtag=NULLTAG;
tag_t* Named_ref=NULLTAG;
tag_t Named_ref_obj=NULLTAG;
char* class =NULL;
char* NR_Filename=NULL;
char* Container_RevSeq=NULL;
char* Dataset_name=NULL;
char* Dataset_RevSeq=NULL;
int ConCount=0;
int Entry_count=2;
int i=0;
int NR_count=0;
int NRflag=0;
int DsCnt=0;

		//  IR_Rev=ContainerTag[0];
		  class=(char *) MEM_alloc(100);
		 ifail = AOM_ask_value_string(IR_Rev,"object_name",&class);
		
		  ifail=GRM_find_relation_type("IMAN_reference", &dataset_rel_type);
          ifail=GRM_list_secondary_objects_only(IR_Rev,dataset_rel_type,&DsCnt,&datasetobj1);
		if(DsCnt>0)
		{
		  for( i=0; i<DsCnt; i++)
            {
				
				Datasetobj3=datasetobj1[i];
				ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
		            if(tc_strcmp(Dataset_name,IR_no)==0)
		            {
		            		
	                    printf("\nDataset found checking for Named ref file");fflush(stdout);
		            	ifail=AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref);
	                  
		              if(NR_count>0)
		              {
		                   for( i=0; i<NR_count; i++)
                            {
		            	     Named_ref_obj=Named_ref[i];
		            	     ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
		            	     
		            	     if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
		            	    { 
		            	    	printf("\nNamed refrenced file is alredy exists in dataset attached to container");fflush(stdout);
		            	    	NRflag=1;
		            	    }
		                    
		                   }
		            	
		              }
		               if(NRflag==0||NR_count==0)
		            	{
		                    printf("\nAdding Named refrenced file in existing dataset attached to container");fflush(stdout);
		            		ifail=AOM_refresh(Datasetobj3,1);
		                    ifail=AE_import_named_ref(Datasetobj3,"PDF_Reference",FullPath,NULL,SS_BINARY);
		                    ifail=AOM_save(Datasetobj3);
		                    ifail=AOM_refresh(Datasetobj3,0);
		            		
		            	}
		            		
		            }
					else 
			        {
		               printf("\nDataset not matched with DVP creating both dataset and Named ref file");fflush(stdout);
			           ifail= AE_find_datasettype2("PDF",&datasettype);
			           ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
		               ifail=AOM_save(Datasetobj4);
			           ifail=AE_find_dataset2(IR_no,&datasetobj2);
		               ifail=AOM_refresh(datasetobj2,1);
		               ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		               ifail=AOM_save(datasetobj2);
		               ifail=AOM_refresh(datasetobj2,0);
			           ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	                   ifail=GRM_save_relation(dataset_rel_type2);      
		               
			        }
						
			}
			
        }
		else
		{	
			
		  ifail=AE_find_dataset2(IR_no,&datasetobj2);
		  
		 if (datasetobj2)
		  {
	        printf("\nDataset found. Creating relation with container");fflush(stdout);
	        ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	        ifail=GRM_save_relation(dataset_rel_type2);      
			ifail=AE_ask_dataset_named_refs(datasetobj2,&NR_count,&Named_ref);
	      
		  if(NR_count>0)
		  {
		   for( i=0; i<NR_count; i++)
            {
			 Named_ref_obj=Named_ref[i];
			 ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
			 
			 if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
			{ 
				printf("\nNamed refrenced file is alredy exists in dataset");fflush(stdout);
				NRflag=1;
			}
		    
		   }
			
		  }
		   else if(NRflag==0||NR_count==0)
			{
		        printf("\nAdding Named refrenced file in existing dataset");fflush(stdout);
				ifail=AOM_refresh(datasetobj2,1);
		        ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		        ifail=AOM_save(datasetobj2);
		        ifail=AOM_refresh(datasetobj2,0);
				
			}
		  
		  }
		  
		  else 
			{
		       printf("\nDataset not found creating both dataset and Named ref file");fflush(stdout);
			   ifail= AE_find_datasettype2("PDF",&datasettype);
			   ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
		       ifail=AOM_save(Datasetobj4);
			   ifail=AE_find_dataset2(IR_no,&datasetobj2);
		       ifail=AOM_refresh(datasetobj2,1);
		       ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		       ifail=AOM_save(datasetobj2);
		       ifail=AOM_refresh(datasetobj2,0);
			   ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	           ifail=GRM_save_relation(dataset_rel_type2);      
		       printf("\nDataset is attached to IR");fflush(stdout);
			}
		}
    


}
else
{
printf("\nDataset not available for this object");fflush(stdout);
}
	*/	
	       
	}
	else
	{
		printf("\n IR object not found so creatiing check list object\n"); fflush(stdout);
			//Check list object not found so creatiing check list object.

			ITK_CALL(TCTYPE_find_type("T5_InterfaceRule","Seg0IntfSpec", &item_type_tag1));         
			ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));
			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",IR_no));
			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",IR_no));
			ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));

				if(object1)
				{
					ifail = AOM_save(object1);
					ifail = AOM_refresh(object1,0);
					ifail = AOM_unlock(object1);
					printf("\nadding properties.\n"); fflush(stdout);
					ITK_CALL(ITEM_ask_latest_rev(object1,&IR_Rev));
					// function create CheckList Row Data()
				ITK_CALL(AOM_refresh(IR_Rev,1));
				ITK_CALL(AOM_set_value_string(IR_Rev,"item_revision_id",rev_id));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggregate",Aggregates));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRAggrGrp",agg_grp));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRModule",module));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRSubModule",submodule));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_ApplicableModules",applicable_modules));
				ITK_CALL(AOM_set_value_string(IR_Rev,"t5_IRRuleDesc",rule_desc));

				ITK_CALL(AOM_save(IR_Rev));
				ITK_CALL(AOM_refresh(IR_Rev,0));
				
			     printf("\n checklist is created\n"); fflush(stdout);
				}

//**************************************
if(tc_strcmp("NA",ImanFile_Name)!=0)
{
printf("\nDataset available for this object...adding dataset");fflush(stdout);
tag_t ItemQry     = NULLTAG;
tag_t* ContainerTag   = NULLTAG;
tag_t dataset_rel_type=NULLTAG;
tag_t dataset_rel_type2=NULLTAG;
tag_t datasettype=NULLTAG;
tag_t* datasetobj1=NULLTAG;
tag_t datasetobj2=NULLTAG;
tag_t Datasetobj3=NULLTAG;
tag_t Datasetobj4=NULLTAG;
tag_t DVPrelation=NULLTAG;
tag_t revtag=NULLTAG;
tag_t* Named_ref=NULLTAG;
tag_t Named_ref_obj=NULLTAG;
char* class =NULL;
char* NR_Filename=NULL;
char* Container_RevSeq=NULL;
char* Dataset_name=NULL;
char* Dataset_RevSeq=NULL;
int ConCount=0;
int Entry_count=2;
int i=0;
int NR_count=0;
int NRflag=0;
int DsCnt=0;

		//  IR_Rev=ContainerTag[0];
		  class=(char *) MEM_alloc(100);
		 ifail = AOM_ask_value_string(IR_Rev,"object_name",&class);
		
		  ifail=GRM_find_relation_type("IMAN_reference", &dataset_rel_type);
          ifail=GRM_list_secondary_objects_only(IR_Rev,dataset_rel_type,&DsCnt,&datasetobj1);
		if(DsCnt>0)
		{
		  for( i=0; i<DsCnt; i++)
            {
				
				Datasetobj3=datasetobj1[i];
				ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
		            if(tc_strcmp(Dataset_name,IR_no)==0)
		            {
		            		
	                    printf("\nDataset found checking for Named ref file");fflush(stdout);
		            	ifail=AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref);
	                  
		              if(NR_count>0)
		              {
		                   for( i=0; i<NR_count; i++)
                            {
		            	     Named_ref_obj=Named_ref[i];
		            	     ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
		            	     
		            	     if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
		            	    { 
		            	    	printf("\nNamed refrenced file is alredy exists in dataset attached to container");fflush(stdout);
		            	    	NRflag=1;
		            	    }
		                    
		                   }
		            	
		              }
		               if(NRflag==0||NR_count==0)
		            	{
		                    printf("\nAdding Named refrenced file in existing dataset attached to container");fflush(stdout);
		            		ifail=AOM_refresh(Datasetobj3,1);
		                    ifail=AE_import_named_ref(Datasetobj3,"PDF_Reference",FullPath,NULL,SS_BINARY);
		                    ifail=AOM_save(Datasetobj3);
		                    ifail=AOM_refresh(Datasetobj3,0);
		            		
		            	}
		            		
		            }
					else 
			        {
		               printf("\nDataset not matched with DVP creating both dataset and Named ref file");fflush(stdout);
			           ifail= AE_find_datasettype2("PDF",&datasettype);
			           ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
		               ifail=AOM_save(Datasetobj4);
			           ifail=AE_find_dataset2(IR_no,&datasetobj2);
		               ifail=AOM_refresh(datasetobj2,1);
		               ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		               ifail=AOM_save(datasetobj2);
		               ifail=AOM_refresh(datasetobj2,0);
			           ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	                   ifail=GRM_save_relation(dataset_rel_type2);      
		               
			        }
						
			}
			
        }
		else
		{	
			
		  ifail=AE_find_dataset2(IR_no,&datasetobj2);
		  
		 if (datasetobj2)
		  {
	        printf("\nDataset found. Creating relation with container");fflush(stdout);
	        ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	        ifail=GRM_save_relation(dataset_rel_type2);      
			ifail=AE_ask_dataset_named_refs(datasetobj2,&NR_count,&Named_ref);
	      
		  if(NR_count>0)
		  {
		   for( i=0; i<NR_count; i++)
            {
			 Named_ref_obj=Named_ref[i];
			 ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
			 
			 if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
			{ 
				printf("\nNamed refrenced file is alredy exists in dataset");fflush(stdout);
				NRflag=1;
			}
		    
		   }
			
		  }
		   else if(NRflag==0||NR_count==0)
			{
		        printf("\nAdding Named refrenced file in existing dataset");fflush(stdout);
				ifail=AOM_refresh(datasetobj2,1);
		        ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		        ifail=AOM_save(datasetobj2);
		        ifail=AOM_refresh(datasetobj2,0);
				
			}
		  
		  }
		  
		  else 
			{
		       printf("\nDataset not found creating both dataset and Named ref file");fflush(stdout);
			   ifail= AE_find_datasettype2("PDF",&datasettype);
			   ifail=AE_create_dataset_with_id(datasettype,IR_no,IR_no,IR_no,IR_no,&Datasetobj4);
		       ifail=AOM_save(Datasetobj4);
			   ifail=AE_find_dataset2(IR_no,&datasetobj2);
		       ifail=AOM_refresh(datasetobj2,1);
		       ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		       ifail=AOM_save(datasetobj2);
		       ifail=AOM_refresh(datasetobj2,0);
			   ifail=GRM_create_relation(IR_Rev,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
	           ifail=GRM_save_relation(dataset_rel_type2);      
		       printf("\nDataset is attached to IR");fflush(stdout);
			}
		}
    


}
else
{
printf("\nDataset not available for this object");fflush(stdout);
}

//**********************************
	}


	return 0;
}

