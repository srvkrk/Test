. /user/testcmi/.bash_profile
cd /user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/
echo "Sendmail Script Called"
echo "file path $1"
echo "From $2"
echo "To $3"
#cat 14_Mar_2022_19_17_16_output.txt
#chmod 777 *
#cp $1 output.txt
cat $1 | /usr/sbin/sendmail -f "$2" -t "$3"
#rm -f /user/testcmi/devgroups/Kirtikumar/mail_notification_cr/
#rm -f $1
