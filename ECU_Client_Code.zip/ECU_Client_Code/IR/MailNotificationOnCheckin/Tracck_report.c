/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Chetan Borse
*  Module		 :   MBOM DML Status Report through CC
*  Code			 :   Tracck_report.c
*  Created on	 :   Oct 28,2023
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/


#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define MAX_LINE_LENGTH 100
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>


#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		/*else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\ */

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
///////////////////////////////////////////////////////////////////////////////////////////////////
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
void MBOMstrcat(char **src,char* dest)
{
	//printf("\n Inside Function MBOMstrcat\n");fflush(stdout);

	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";

	//printf("\n autoresizestrcat src len==%d",strlen(*src));
	//printf("\n autoresizestrcat desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	 //src = MEM_realloc(src, size_ab);

	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}
void ReverseStr(char str[])
{
    int i,j;
    char temp[100];
    for(i=strlen(str)-1,j=0; i+1!=0; --i,++j)
    {
        temp[j]=str[i];
    }
    temp[j]='\0';
    strcpy(str,temp);
}
/////////////////////////////////////////////////////////////////////////////////////////////////
 char* remove_specialCharDesc(char *in)
{
	printf("\n Test Inside Function remove_specialCharDesc \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
	   // if (in[j] != '\x01' && in[j] != '\x02')
		  if (in[j] != '\n' && in[j] != '\r'  && in[j] != ',' )
	  //  if (in[j] != ',')
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';


return tmp;
}


int ITK_user_main(int argc, char* argv[])
{
		FILE *fp1;
        int status=0;
        int i=0;
		int j=0;
		int count0=0;
		int count1=0;
		int count_status=0;
		int rev_count=0;
        tag_t query0=NULLTAG;
        tag_t query1=NULLTAG;
        tag_t* result0=NULLTAG;
        tag_t* result1=NULLTAG;
		tag_t	*status_lst				= NULLTAG;
		FILE *file;
    char line[MAX_LINE_LENGTH];




		char *DMLno=NULL;
		char *ERCDML=NULL;
		char *ERCDMLTASK=NULL;
		char *Dgrp=NULL;
		char *Designgrp=NULL;
		char *Desc=NULL;
		char *projcode=NULL;
		char *ReleaseType=NULL;
		char *ReleaseStatus=NULL;
		char *date_released=NULL;
		tag_t dmlitem=NULLTAG;
		tag_t* rev_list=NULLTAG;
	//	tag_t rev_list=NULLTAG;


		char *release_status=NULL;
		char *status_name=NULL;
		char *Assign_User=NULL;
		char *WfStatus=NULL;
		char *WfErrormsg=NULL;
		char *WFstate=NULL;
		char *WFname=NULL;
		char *Rstatus=NULL;
		char *WfErrormsg1=NULL;
		int val_count=0;
		tag_t *attachments=NULLTAG;
		int k=0;
		int z=0;
		int t=0;
		int count=0;
		int Sr_No=1;
		int MBOMCOUNT=0;
		int MBOMCOUNT0=0;
        int TaskCnt=0;
		char *output					= NULL;
		output = (char *) MEM_alloc( 10 * sizeof(char) );
        tag_t qryTagCntrlobj    =NULL;
		tag_t qryTagCntrlobj2    =NULL;
		tag_t qryTagDataset    =NULL;
		int n_entryCntrlobj     =2;
		int n_entryCntrlobj2     =2;
		int n_entryDatasetobj     =2;
		int controlObjfound =0;
		int controlObjfound2 =0;
		int DatasetObjfound =0;
		tag_t *list_of_cntrl_tags=NULLTAG;
		tag_t *list_of_cntrl_tags2=NULLTAG;
		tag_t *list_of_Dataset_tags=NULLTAG;
		char *info1 			=NULL;
		char *info2 			=NULL;
		int ii=0;
		int iii=0;
		char *qry_entryCntrlformat[2]  = {"Name","SUBSYSCD"};
		char *qry_entryDatasetformat[2]  = {"Name","Dataset Type"};
		char *qry_entryCntrlformat2[2]  = {"Name","SUBSYSCD"};
		//char	**qry_valuesDatasetformat= (char **) MEM_alloc(5 * sizeof(char *));
		char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
		char	**qry_valuesCntrlformat2= (char **) MEM_alloc(5 * sizeof(char *));
		char	**qry_valuesDatasetformat= (char **) MEM_alloc(5 * sizeof(char *));
		tag_t	relation_type,relation	,propTag	= NULLTAG;
		int COUNT= 0;
		int COUNT1= 0;
		tag_t*			TaskRevision		= NULLTAG;
		tag_t*			TaskRevision1		= NULLTAG;
		tag_t DMLITEM=NULLTAG;
		tag_t			TaskRevTag			= NULLTAG;
		char*			object_type			= NULL;
		char*			objTYPE			= NULL;
		char*			Datatyp			= NULL;
		char*			Txtfile			= NULL;
	//	char			Txtfile[200]				= "";

		int result=0;
		char*	D_grp = NULL;
		tag_t envelope	= NULLTAG;
		char env_body[300]= {'\0'};
		char env_subject[300] = {'\0'};
		int countenvelop = 0;
		tag_t* recievers = NULLTAG;


		// Structure Declaration
        typedef enum MAIL_to_or_cc_e
        {
	       MAIL_send_to,
	       MAIL_send_cc
        }MAIL_to_or_cc_t;



	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char * From_Date				= NULL;
	char * To_Date				    = NULL;
	tag_t DMLTag = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *startdate=NULL;
	char *enddate=NULL;
	char *ERCDMLITEM=NULL;
	char *Tempvalue1=NULL;
	char *tempDescMBOM=NULL;


	 userid			= ITK_ask_cli_argument("-u=");
	 password 		= ITK_ask_cli_argument("-p=");
  // group 			= ITK_ask_cli_argument("-g=");
	 From_Date	    = ITK_ask_cli_argument("-fd=");
	 To_Date	    = ITK_ask_cli_argument("-td=");

	//-u=cb923330 -p=XYT1ESA -g=APLPNR -fd=12-Jun-2023 -td=05-Sep-2023

	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	qry_entries[0] = "Type";
//	qry_entries[1] =	"Release Status";
	qry_entries[1] = "Created After";
	qry_entries[2] = "Created Before";

	qry_values[0] = "ERC DML Revision";
//	qry_values[1] = "ERC Released";
	qry_values[1] = From_Date;
    qry_values[2] = To_Date;


		char			Data[100]					= "";
		char			outputFile[200]				= "";

		time_t 	now;
		struct 	tm when;

		time(&now);
		when = *localtime(&now);

		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
		sprintf(outputFile,"MBOM_DML_Status_Report_%s.csv",Data);

		 fp1 = fopen(outputFile, "a+");

        char *s= NULL;
		char *fnd0InProcess=NULL;

		ITK_CALL( ITK_init_module(userid,password,group));
//		ITK_CALL(ITL_auto_login());
        ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
        ITK_set_bypass(true);
        ITK_CALL(ITK_set_journalling(TRUE));

        if (status == 0 )
        {
		   printf("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> APLPLANNER login successful<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");fflush(stdout);
        }
        else
        {
          printf("\n Error code:%d",status);fflush(stdout);
          ITK_CALL(EMH_ask_error_text(status,&s));
          printf("\n Error message:%s",s);fflush(stdout);
        }

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	ITK_CALL(QRY_find("General...",&query0));
    printf("\n ---------------------------------------------------Query Found Successfully---------------------------------------------------------");fflush(stdout);
    ITK_CALL(QRY_execute(query0,3,qry_entries,qry_values,&count0,&result0));
	printf("\n ---------------------------------------------------Result found by query---:-%d --------------------------------------------------------",count0);fflush(stdout);
//	fprintf(fp1,"=============================================================== Report START=============================================================================================\n");fflush(fp1);
	fprintf(fp1,"Sr_No,ERCDML NO,Description,Project Code,Design Grp,Release Type,ERC Released Date,MBOM DML Required,Already Created/Not\n");fflush(fp1);

      for(t=0,Sr_No=1;t<count0;t++,Sr_No++)
	     {
		         fprintf(fp1,"%d,",Sr_No);fflush(fp1);

				 ITK_CALL(AOM_ask_value_string(result0[t],"item_id",&ERCDML))
                 printf("\t\t \t\t ERCDML =%s \n",ERCDML);fflush(stdout);

		         ITK_CALL(AOM_ask_value_string(result0[t],"current_desc",&Desc))
                 printf("\t\t \t\t Desc =%s \n",Desc);fflush(stdout);
				 tempDescMBOM=NULL;
                 tempDescMBOM = remove_specialCharDesc(Desc);

				 ITK_CALL(AOM_ask_value_string(result0[t],"t5_cprojectcode",&projcode))
                 printf("\t\t \t projcode =%s \n",projcode);fflush(stdout);

		         ITK_CALL(AOM_UIF_ask_value(result0[t],"t5_crdesigngroup",&Designgrp))
		         printf("\t \t\t Designgrp =%s \n",Designgrp);fflush(stdout);

                   Tempvalue1=(char *)MEM_alloc(80);
                   tc_strcpy(Tempvalue1,"'");
			       STRNG_replace_str(Designgrp,",","/",&Tempvalue1);
	 		       printf("\t \t Tempvalue1 =%s \n\n",Tempvalue1);fflush(stdout);

					ITKCALL(QRY_find("Control Objects...", &qryTagCntrlobj));
			        if (qryTagCntrlobj != NULLTAG)
				     {
					   printf("\n Control Object Query Found \n");fflush(stdout);
				       qry_valuesCntrlformat[0]="MBOM_Track";
				       qry_valuesCntrlformat[1]="MBOM_Track_rpt";
				 //    qry_valuesCntrlformat[2]="0";

				       ITKCALL(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
				       printf("\n Number of control Obj Found is: %d",controlObjfound);fflush(stdout);
				     }
					 if (controlObjfound>0)
				       {
						      ITKCALL(AOM_ask_value_string( list_of_cntrl_tags[ii], "t5_Userinfo1", &info1));
			                  printf("\n Information1 is: %s\n",info1);fflush(stdout);

			                  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags[ii], "t5_Userinfo2", &info2));
	                          printf("\n Information2 is: %s\n",info2);fflush(stdout);
					   }

				   GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
			       ITKCALL(GRM_list_secondary_objects_only(result0[t],relation_type,&COUNT1,&TaskRevision1));
			       printf("\n DML Task Relation : %d\n",COUNT1);fflush(stdout);
					   for(z=0;z<COUNT1;z++)
				        {
				              ITK_CALL(AOM_UIF_ask_value(TaskRevision1[z],"item_id",&ERCDMLTASK))
		                      printf("\t \t\tERCDMLTASK  =%s \n",ERCDMLTASK);fflush(stdout);
				              ITK_CALL(AOM_UIF_ask_value(TaskRevision1[z],"object_type",&objTYPE))
		                      printf("\t\tobjTYPE  =%s \n",objTYPE);fflush(stdout);
			                       if(tc_strcmp(objTYPE,"ERC Task Revision")==0)
					                {
						                  D_grp=(char *)MEM_alloc(80);
						                  ReverseStr(ERCDMLTASK);
				                          D_grp= strtok(ERCDMLTASK, "_" );
						                  ReverseStr(D_grp);
						                  printf("\n D_grp= %s\n",D_grp);fflush(stdout);
					               if(tc_strstr(info2,D_grp)!=NULL)
						                {
						                	break;
						                }
					                }
					    }

		         ITK_CALL(AOM_ask_value_string(result0[t],"t5_rlstype",&ReleaseType))
		         printf("\t \t\t ReleaseType =%s \n",ReleaseType);fflush(stdout);

				 ITK_CALL(AOM_UIF_ask_value(result0[t],"release_status_list",&ReleaseStatus))
		         printf("\t \t ReleaseStatus =%s \n\n",ReleaseStatus);fflush(stdout);

				  ITK_CALL(AOM_UIF_ask_value(result0[t],"date_released",&date_released))
		         printf("\t \t ERC Release Date =%s \n\n",date_released);fflush(stdout);


			        if (controlObjfound>0)
				      {
						printf("\t \t\t D_grp =%s \n",D_grp);fflush(stdout);
						  if ((tc_strstr(info2,D_grp)!=NULL) && (tc_strstr(info1,ReleaseType)!=NULL))
				              {
								  printf("\t \t\t Designgrp =%s \n",Designgrp);fflush(stdout);
								  fprintf(fp1,"%s,",ERCDML);fflush(fp1);
								  fprintf(fp1,"%s,",tempDescMBOM);fflush(fp1);
								  fprintf(fp1,"%s,",projcode);fflush(fp1);
							      tc_strcat(Tempvalue1,"'");
								  fprintf(fp1,"%s,",Tempvalue1);fflush(fp1);
								  fprintf(fp1,"%s,",ReleaseType);fflush(fp1);
								  fprintf(fp1,"%s,",date_released);fflush(fp1);
								  fprintf(fp1,"YES,");fflush(fp1);

							       printf("\n MBOM DML CREATION=%s \n\n",ERCDML); fflush(stdout);
							       count++;

			                      	GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
			                       	ITKCALL(GRM_list_secondary_objects_only(result0[t],relation_type,&COUNT,&TaskRevision));

									for (TaskCnt=0;TaskCnt<COUNT ;TaskCnt++ )
								        {
				                           TaskRevTag = TaskRevision[TaskCnt];
				                           ITKCALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
									       printf("\n object_type= %s\n",object_type);fflush(stdout);

									       if(strcmp(object_type,"T5_MBOMDMLRevision")==0)
				                              {
										          MBOMCOUNT++;
										          printf("\n\t\tMbom DML found for ERCDML= %s\n",ERCDML);fflush(stdout);
											      printf("\t No.of count= %d\n",MBOMCOUNT);fflush(stdout);
											      fprintf(fp1,"Yes,");fflush(fp1);
											      break;
								              }
									       else
										      {
									                printf("\t\tERCDML= %s\n",ERCDML);fflush(stdout);
										        	fprintf(fp1,"No,");fflush(fp1);
											        break;
									          }
    						             }
						                      MBOMCOUNT0++;
										      if(COUNT==0)
										        {
											       fprintf(fp1,"Task Not Avilable");fflush(fp1);
										        }
										           fprintf(fp1,"\n");fflush(fp1);
										    //       break;
			                    }
							else
						       {
									fprintf(fp1,"%s,",ERCDML);fflush(fp1);
									fprintf(fp1,"%s,",tempDescMBOM);fflush(fp1);
								    fprintf(fp1,"%s,",projcode);fflush(fp1);
								    tc_strcat(Tempvalue1,"'");
								    fprintf(fp1,"%s,",Tempvalue1);fflush(fp1);
								    fprintf(fp1,"%s,",ReleaseType);fflush(fp1);
									fprintf(fp1,"%s,",date_released);fflush(fp1);
								    fprintf(fp1,"NO,");fflush(fp1);
								    fprintf(fp1,"--,");fflush(fp1);
								    fprintf(fp1,"\n");fflush(fp1);
								}
		                }
		     }

      fprintf(fp1,"\n=================== Report END======================");fflush(fp1);
      qry_entries[0] = "Person Name";
      qry_values[0] = "*";
      char *Status=NULL;
      char *DGroup=NULL;
	  char * command    = NULL;
      tag_t user=NULL;
     // char *person_name[SA_person_name_size_c+1];
      char *person_name=NULL;
      char *local_person_email=NULL;
      char *User_id=NULL;
	  tag_t person_tag = NULLTAG;
	  int m=0;
      char  *mailId = NULL;
	  char*			eMailCC		= NULL;
	  char*			eMailCC2		= NULL;
	  char*			mailcc		= NULL;
	  char*			eMailTo		= NULL;
	  char*			eMailTo2		= NULL;
	  char*			buff		= NULL;
	  char*			sender_email		= NULL;
	  char*			recipient_email		= NULL;
	  char*			cc_email		= NULL;
	  char*			subject		= NULL;
	  char*			body		= NULL;
	  char*			attachment_path		= NULL;
	  char*			mutt		= NULL;
	  char*			infocc1		= NULL;
	  char*			infocc2		= NULL;
	  char*			infocc3		= NULL;
	  char*			infocc4		= NULL;
	  char*			infocc5		= NULL;
	  char*			infocc6		= NULL;
	  char*			infocc7		= NULL;
	  char*			infocc8		= NULL;
	  char*			infocc9		= NULL;
	  char*			infocc10		= NULL;
	   

	  command = (char *)MEM_alloc(7000);
	  eMailCC=(char *) MEM_alloc(4000 * sizeof(char *));
	  eMailCC2=(char *) MEM_alloc(2000 * sizeof(char *));
	  eMailTo=(char *) MEM_alloc(2000 * sizeof(char *));
	  eMailTo2=(char *) MEM_alloc(100 * sizeof(char *));
     buff=(char *) MEM_alloc(1000 * sizeof(char *));
	  tc_strcpy(eMailCC,"");
	  tc_strcpy(eMailCC2,"");
	  tc_strcpy(eMailTo,"");
	  tc_strcpy(eMailTo2,"");



	  

     ITK_CALL(QRY_find("Admin - Employee Information",&query1));
     printf("\n ---------------------------------------------------Query Found Successfully---------------------------------------------------------");fflush(stdout);

     ITK_CALL(QRY_execute(query1,1,qry_entries,qry_values,&count1,&result1));
     printf("\n user count=%d",count1);fflush(stdout);

	for(m=0;m<count1;m++)
    {

		   ITK_CALL(AOM_UIF_ask_value(result1[m],"status",&Status))
           printf("\t\t \t\t Status =%s \n",Status);fflush(stdout);

		    ITK_CALL(AOM_UIF_ask_value(result1[m],"default_group",&DGroup))
            printf("\t\t \t\t DGroup =%s \n",DGroup);fflush(stdout);

		    ITK_CALL(AOM_UIF_ask_value(result1[m],"user_id",&User_id))
            printf("\t\t \t\t User_id =%s \n",User_id);fflush(stdout);

              if(tc_strcmp(Status,"0")==0 && tc_strcmp(DGroup,"MBOM")==0 )
	         	{
                   SA_find_user2(User_id, &user);
	               AOM_load(user);
	               SA_ask_user_person_name2(user, &person_name);
	               SA_find_person2 ( person_name, &person_tag);
	               SA_ask_person_email_address ( person_tag, &local_person_email );

	              printf("\nUser ID : [%s]",User_id);
	              printf("\nperson_name : [%s]",person_name);
	              printf("\nfun local_person_email : [%s]",local_person_email);

	                if(local_person_email != NULL)
						{
							if(tc_strstr(eMailTo, local_person_email)==NULL)
								{
								tc_strcat(eMailTo,local_person_email);
								tc_strcat(eMailTo,",");
								}
						}
		        }
        
    }

		ITKCALL(QRY_find("Control Objects...", &qryTagCntrlobj2));
			        if (qryTagCntrlobj2 != NULLTAG)
				     {
					   printf("\n Control Object Query Found \n");fflush(stdout);
				       qry_valuesCntrlformat2[0]="MBOM_CC_List";
				       qry_valuesCntrlformat2[1]="mbom_cc_list";
				 //    qry_valuesCntrlformat[2]="0";

				       ITKCALL(QRY_execute(qryTagCntrlobj2, n_entryCntrlobj2, qry_entryCntrlformat2, qry_valuesCntrlformat2, &controlObjfound2, &list_of_cntrl_tags2));
				       printf("\n Number of control Obj Found is: %d",controlObjfound2);fflush(stdout);
				     }
					 if (controlObjfound2>0)
				       {
						      ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo1", &infocc1));
			                  printf("\n Information1 is: %s\n",infocc1);fflush(stdout);

			                 ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo2", &infocc2));
	                          printf("\n Information2 is: %s\n",infocc2);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo3", &infocc3));
	                          printf("\n Information3 is: %s\n",infocc3);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo4", &infocc4));
	                          printf("\n Information4 is: %s\n",infocc4);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo5", &infocc5));
	                          printf("\n Information5 is: %s\n",infocc5);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo6", &infocc6));
	                          printf("\n Information6 is: %s\n",infocc6);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo7", &infocc7));
	                          printf("\n Information7 is: %s\n",infocc7);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo8", &infocc8));
	                          printf("\n Information8 is: %s\n",infocc8);fflush(stdout);

                              ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_Userinfo9", &infocc9));
	                          printf("\n Information9 is: %s\n",infocc9);fflush(stdout);

							  ITKCALL(AOM_ask_value_string( list_of_cntrl_tags2[iii], "t5_userinfo10", &infocc10));
	                          printf("\n Information10 is: %s\n",infocc10);fflush(stdout);
						

							 // tc_strcpy(eMailCC,"");
							  tc_strcat(eMailCC,infocc1);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc2);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc3);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc4);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc5);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc6);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc7);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc8);
							 // tc_strcat(eMailCC,",");
							 // tc_strcat(eMailCC,infocc9);
							  tc_strcat(eMailCC,",");
							  tc_strcat(eMailCC,infocc10);
							  printf("\n eMailCC is: %s\n",eMailCC);fflush(stdout);
					   }

    //    tc_strcat(eMailCC2,"ap922200.ttl@tatamotors.com");
    //    tc_strcat(eMailCC2,",");
    //    tc_strcat(eMailCC2,"pl922201.ttl@tatamotors.com");
    //    tc_strcat(eMailTo2,"cb923330.ttl@tatamotors.com");
    //    tc_strcat(eMailTo2,",");
    //    tc_strcat(eMailTo2,"aj928455.ttl@tatamotors.com");

    //    printf("\neMailCC2 : [%s]",eMailCC2);
	//    printf("\neMailTo2 : [%s]",eMailTo2);
        printf("\neMailCC : [%s]",eMailCC);
        printf("\neMailTo : [%s]",eMailTo);
        printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING START @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	
		       tc_strcat(command,infocc9);
			   tc_strcat(command," ");
			   tc_strcat(command,outputFile); // created csv file
			   tc_strcat(command," ");
			   tc_strcat(command,eMailTo); //to person mail
			   tc_strcat(command," ");
			   tc_strcat(command,eMailCC);  // cc person mail
			   printf("\n Mail Body String --------> %s\n",env_body);fflush(stdout);

               system(command);

			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@ EMAIL SENDING END @@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);

    result=(MBOMCOUNT0)-(MBOMCOUNT);
    printf("\n\n\t Total ERC DML=%d \n",count0); fflush(stdout);
	printf("\t Total MBOM DML Required=%d \n",count); fflush(stdout);
	printf("\t Already MBOM Created= %d\n",MBOMCOUNT);fflush(stdout);
	printf("\t Total pending of MBOM Creation= %d\n",result);fflush(stdout);
	fprintf(fp1,"\n=================== Report END======================");fflush(fp1);

    fclose(fp1);

    return 0;
}