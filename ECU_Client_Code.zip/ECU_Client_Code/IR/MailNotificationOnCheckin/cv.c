#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <sa/user.h>



#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define PROP_set_value_string_msg   "PROP_set_value_string"

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE            *output                         = NULL;
int                     ifail                           = ITK_ok;
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              printf ("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}
int Mail_Notification(char*);
int read_value_from_file(char*,char*);
void print_requirement()
{
        printf(
        "\nHELP:\n"
        "parameter_creation -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
        "-------------------------------------------------------------------------------------------\n\n"
        );
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
                                        It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;
        
		 char                    * Submodule                                      = NULL;


        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");
        
		Submodule               = ITK_ask_cli_argument("-SM=");

        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Submodule)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);
        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");
                return ifail;
        }
        else
                {
                        printf("\nLogin Successfull.....!!\n");
                        printf("\nWelcome to Teamcenter.....!!\n");
                }
        ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");
                return -1;
        }


        ifail=Mail_Notification(Submodule);
        


        printf("\nEnd of program.....!!\n");
        printf("\n*********************\n");
        ifail = ITK_exit_module(true);
        return ifail;
}

int Mail_Notification(char* Submodule)
{

    tag_t	qryTag			= NULLTAG;
	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entri[1]   = {"SYSCD"};
	int n_entries				= 1;
	int qrycount			= 0;
	tag_t *CntrlObjTag		= NULLTAG;
	char* FilePath          =NULL;
	char *InpFile=NULL;;
	char* error_text							=NULL;
//	FILE			*output 			= NULL;
    InpFile=(char *)MEM_alloc(100);

    tc_strcpy(InpFile,"");
    tc_strcpy(InpFile,"interfering_module.csv");
    printf("\n Input FILE NAME=> [%s] ",InpFile); fflush(stdout);


    /*        if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
			}
			qry_val[0] = "MailNotification";
			if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));
			printf("\n\t ****qrycount => %d*****\n",qrycount);fflush(stdout);

           if(qrycount>0)
			{*/

			//   if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo1",&FilePath))
			FilePath="/user/cvprod/Akshay/Mail_Notification/";
		       printf("\n Input File path is : [%s]\n", FilePath);fflush(stdout);

			    char *IpFile= NULL;
			    IpFile=(char *)MEM_alloc(100);
				 tc_strcpy(IpFile,"");
				 strcpy(IpFile,FilePath);
				
				 strcat(IpFile,InpFile);
				
				printf("\n CHECKLIST FILE PATH=> [%s] ",IpFile); fflush(stdout);

				 ifail = read_value_from_file(IpFile,Submodule);








		/*	}
			else
			{
				printf("\n Mail Notificatio is OFF  :: Mail_Notification !! \n");fflush(stdout);
				
			}*/

}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename,char*Submodule)
{
        char                    *DependentSubmodule                                        = NULL;
        char                    *chKOutSubmodule                                         = NULL;        
        char                    temp[10000];

        FILE            * fp                                    = NULL;
		int ifail=0;
		char* error_text							=NULL;
        FILE			*output 			= NULL;
		//********************				                        
		tag_t item_tag		= NULLTAG;
		tag_t latest_rev_id		= NULLTAG;
		char* object_name          =NULL;
		tag_t	object_owner						= NULLTAG;
		tag_t	object_owner_person					= NULLTAG;
		char *person_name							=NULL;
		char	*CC_MailList						= (char*)MEM_alloc(sizeof(char) * 2000);
		tc_strcpy(CC_MailList,"");
		tc_strcpy(CC_MailList,"ad928811.ttl@tatamotors.com");

		char			Data[100]					= "";
		char			outputFile[200]				= "";
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//	char command[512]							="";
		char command2[512]							="";
		char osUserName[SA_name_size_c+1];
		char*object_owner_email						= (char*)MEM_alloc(sizeof(char) * 2000);

   
        char                    *MailTo                                      = NULL;
		MailTo						= (char*)MEM_alloc(sizeof(char) * 2000);
		tc_strcpy(MailTo,"");
		tc_strcat(outputFile,"/user/cvprod/Akshay/Mail_Notification/");
		tc_strcat(outputFile,Data);
		tc_strcat(outputFile,"_output.txt");
			

		printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);


		output = fopen(outputFile, "a");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			printf("File opened successfully.\n");
			
		}
			

		ITK_CALL(ITEM_find_item(Submodule,&item_tag));
			
		if (item_tag)
		{
			  printf("\n  module found ");
		 

			ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));

			if (latest_rev_id)
			{
				printf("\n  module rev found");
			}
			else
			{
				printf("\n  module rev not found");
			}

			   ifail = AOM_ask_value_string(latest_rev_id,"object_string",&object_name);
				printf("\nObject Name :---%s\n", object_name);

				
				ifail = AOM_ask_owner(latest_rev_id,&object_owner);
				if(ifail ==ITK_ok){

				} else 
				{
					EMH_ask_error_text(ifail,&error_text);
					printf("\nError %s", error_text);
				}
				ifail = SA_ask_user_person(object_owner,&object_owner_person);
				if(ifail ==ITK_ok){

				} else 
				{
					EMH_ask_error_text(ifail,&error_text);
					printf("\nError %s", error_text);
				}


				ifail =SA_ask_person_name2(object_owner_person,&person_name);
				printf("\nPerson Name: %s",person_name);
				

			//	ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
			//	printf("\n Creator's e mail:-- %s",object_owner_email); 
			   object_owner_email="at924736.ttl@tatamotors.com";

	
				SA_ask_os_user_name	(object_owner,&osUserName);
				printf("\nuser Name %s",osUserName);
				
			/*	 tc_strcpy(object_owner_email,"");
				 tc_strcpy(object_owner_email,osUserName);
				 tc_strcat(object_owner_email,"@tatamotors.com");*/

				 printf("\nowninguser Mail id :---%s\n",object_owner_email);







				

		//*********************
      char command[512]							="";
        fp = fopen(Filename, "r");
        if (fp != NULL)
        {
                while (fgets(temp, 10000, fp)!= NULL)
                {
                        tc_strcpy(temp,stripBlanks(temp));

                        if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
                        {
                               DependentSubmodule = strtok(temp, "~");
                                printf("\nInput DependentSubmodule:%s",DependentSubmodule);

                                chKOutSubmodule = strtok(NULL, "~");
                                printf("\nInput chKOutSubmodule:%s",chKOutSubmodule);

								//************************************

								char                    *chkout1                                         = NULL;
								char                    *chkout2                                         = NULL;
								char                    *chkout3                                         = NULL;
								char                    *chkout4                                         = NULL;
								char                    *chkout5                                         = NULL;
								char                    *chkout6                                         = NULL;
								char                    *chkout7                                         = NULL;
								char                    *chkout8                                         = NULL;
								char                    *chkout9                                         = NULL;
								char                    *chkout10                                         = NULL;
								char                    *chkout11                                         = NULL;
								char                    *chkout12                                         = NULL;
								char                    *chkout13                                         = NULL;
								char                    *chkout14                                         = NULL;
								char                    *chkout15                                       = NULL;
								char                    *chkout16                                       = NULL;
								char                    *chkout17                                       = NULL;
								char                    *chkout18                                       = NULL;
								char                    *chkout19                                       = NULL;
								char                    *chkout20                                      = NULL;
								
								

								chkout1 = strtok(chKOutSubmodule, ";");
                                printf("\nchkout1:%s",chkout1);

                                chkout2 = strtok(NULL, ";");
                                printf("\nchkout2:%s",chkout2);

								chkout3 = strtok(NULL, ";");
                                printf("\n chkout3:%s",chkout3);

								chkout4 = strtok(NULL, ";");
                                printf("\n chkout4:%s",chkout4);

								chkout5 = strtok(NULL, ";");
                                printf("\n chkout5:%s",chkout5);

								chkout6 = strtok(NULL, ";");
                                printf("\n chkout6:%s",chkout6);

								chkout7 = strtok(NULL, ";");
                                printf("\n chkout7:%s",chkout7);

								chkout8 = strtok(NULL, ";");
                                printf("\n chkout8:%s",chkout8);

								chkout9 = strtok(NULL, ";");
                                printf("\n chkout9:%s",chkout9);

								chkout10 = strtok(NULL, ";");
                                printf("\n chkout10:%s",chkout10);

								chkout11 = strtok(NULL, ";");
                                printf("\n chkout11:%s",chkout11);

								chkout12 = strtok(NULL, ";");
                                printf("\n chkout12:%s",chkout12);

								chkout13 = strtok(NULL, ";");
                                printf("\n chkout13:%s",chkout13);

								chkout14 = strtok(NULL, ";");
                                printf("\n chkout14:%s",chkout14);

								chkout15 = strtok(NULL, ";");
                                printf("\n chkout15:%s",chkout15);

								chkout16 = strtok(NULL, ";");
                                printf("\n chkout16:%s",chkout16);

								chkout17 = strtok(NULL, ";");
                                printf("\n chkout17:%s",chkout17);

								chkout18 = strtok(NULL, ";");
                                printf("\n chkout18:%s",chkout18);

								chkout19 = strtok(NULL, ";");
                                printf("\n chkout19:%s",chkout19);

								chkout20 = strtok(NULL, ";");
                                printf("\n chkout20:%s",chkout20);

								




 
								if((tc_strstr(Submodule,chkout1)!=NULL) || (tc_strstr(Submodule,chkout2)!=NULL) || (tc_strstr(Submodule,chkout3)!=NULL) || (tc_strstr(Submodule,chkout4)!=NULL) || (tc_strstr(Submodule,chkout5)!=NULL) || (tc_strstr(Submodule,chkout6)!=NULL) || (tc_strstr(Submodule,chkout7)!=NULL) || (tc_strstr(Submodule,chkout8)!=NULL) || (tc_strstr(Submodule,chkout9)!=NULL) || (tc_strstr(Submodule,chkout10)!=NULL) || (tc_strstr(Submodule,chkout11)!=NULL) || (tc_strstr(Submodule,chkout12)!=NULL) ||(tc_strstr(Submodule,chkout13)!=NULL) || (tc_strstr(Submodule,chkout14)!=NULL) || (tc_strstr(Submodule,chkout15)!=NULL) || (tc_strstr(Submodule,chkout16)!=NULL) || (tc_strstr(Submodule,chkout17)!=NULL) || (tc_strstr(Submodule,chkout18)!=NULL) || (tc_strstr(Submodule,chkout19)!=NULL) || (tc_strstr(Submodule,chkout20)!=NULL))
							    {

                                       
//				                        tag_t item_tag		= NULLTAG;
//										tag_t latest_rev_id		= NULLTAG;
//										char* object_name          =NULL;
//										tag_t	object_owner						= NULLTAG;
//										tag_t	object_owner_person					= NULLTAG;
//										char *person_name							=NULL;
//										char	*CC_MailList						= (char*)MEM_alloc(sizeof(char) * 2000);
//										tc_strcpy(CC_MailList,"");
//										tc_strcpy(CC_MailList,"ad928811.ttl@tatamotors.com");
//
//										char			Data[100]					= "";
//										char			outputFile[200]				= "";
//										time_t 	now;
//										struct 	tm when;
//										time(&now);
//										when = *localtime(&now);
//										strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
//										char command[512]							="";
//										char command2[512]							="";
//										char osUserName[SA_name_size_c+1];
//										char*object_owner_email						= (char*)MEM_alloc(sizeof(char) * 2000);
//
//								   
//
//										tc_strcat(outputFile,"/user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/");
//										tc_strcat(outputFile,Data);
//										tc_strcat(outputFile,"_output.txt");
//											
//
//										printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);
//
//
//										output = fopen(outputFile, "a");
//										if (output == NULL)
//										{
//											printf("ERROR: Cannot open File\n");
//											return -1;
//										}
//										else
//										{
//											printf("File opened successfully.\n");
//											
//										}
//											
//
//										ITK_CALL(ITEM_find_item(Submodule,&item_tag));
//											
//										if (item_tag)
//										{
//											  printf("\n  module found ");
//										 
//
//											ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));
//
//											if (latest_rev_id)
//											{
//												printf("\n  module rev found");
//											}
//											else
//											{
//												printf("\n  module rev not found");
//											}
//
//											   ifail = AOM_ask_value_string(latest_rev_id,"object_string",&object_name);
//												printf("\nObject Name :---%s\n", object_name);

										
//
//												ifail = AOM_ask_owner(latest_rev_id,&object_owner);
//												if(ifail ==ITK_ok){
//
//												} else 
//												{
//													EMH_ask_error_text(ifail,&error_text);
//													printf("\nError %s", error_text);
//												}
//												ifail = SA_ask_user_person(object_owner,&object_owner_person);
//												if(ifail ==ITK_ok){
//
//												} else 
//												{
//													EMH_ask_error_text(ifail,&error_text);
//													printf("\nError %s", error_text);
//												}
//
//
//												ifail =SA_ask_person_name2(object_owner_person,&person_name);
//												printf("\nPerson Name: %s",person_name);
//												
//
//											//	ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
//											//	printf("\n Creator's e mail:-- %s",object_owner_email); 
//											//    object_owner_email="at924736.ttl@tatamotors.com";
//
//									
//												SA_ask_os_user_name	(object_owner,&osUserName);
//												printf("\nuser Name %s",osUserName);
//												
//												 tc_strcpy(object_owner_email,"");
//												 tc_strcpy(object_owner_email,osUserName);
//												 tc_strcat(object_owner_email,"@tatamotors.com");
//
//												 printf("\nowninguser Mail id :---%s\n",object_owner_email);

												  // Calling shell for send mail
												//sprintf(command,"/user/testcmi/devgroups/Kirtikumar/mail_notification_cr/testSendMail.sh %s %s %s > myoutput.txt &",outputFile,emailID_FIR_Analyst,TR_owner_email);

											//	fprintf(output,"To:%s\n",object_owner_email);
//											    fprintf(output,"To:%s\n","at924736.ttl@tatamotors.com");
//												fprintf(output,"CC:%s\n",CC_MailList);
//												fprintf(output,"Subject: Module is checkin:%s\n",object_name);
//												fprintf(output,"Hello,\n\n","");
//												fprintf(output,"Given Module has been modified in TCUA CV : %s\n\n\n",object_name);					
//												fprintf(output,"Thanks and Regards,\n","");
//												fprintf(output,"PLM Team ","");
//
//												fclose(output);
//
//												tc_strcat(command2,"chmod 777 /user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/*");
//												system(command2);
												
											
												tc_strcat(MailTo,object_owner_email);
												tc_strcat(MailTo,",");




											
													
												
									//	}
								}
								else
								{

									printf("\nchecking next\n");

								}




								//*******************************

                                

                            
                        }
                        printf("\n***************************************\n");
                         tc_strcpy(temp, "");
                }

                                              printf("\n\t Mail to :%s",MailTo);

												fprintf(output,"To:%s\n",MailTo);
												fprintf(output,"CC:%s\n",CC_MailList);
												fprintf(output,"Subject: Module is checkin:%s\n",object_name);
												fprintf(output,"Hello,\n\n","");
												fprintf(output,"Given Module has been modified in TCUA CV : %s\n\n\n",object_name);					
												fprintf(output,"Thanks and Regards,\n","");
												fprintf(output,"PLM Team ","");

												fclose(output);

												tc_strcat(command2,"chmod 777 /user/cvprod/Akshay/Mail_Notification/*");
												system(command2);

												tc_strcat(command,"/user/cvprod/Akshay/Mail_Notification/SendMail.sh");
												//tc_strcat(command,"");
												tc_strcat(command," ");
												tc_strcat(command,outputFile);
												tc_strcat(command," ");
												tc_strcat(command,"mam.ttl@tatamotors.com");
												tc_strcat(command," ");
												tc_strcat(command,MailTo);											   
												tc_strcat(command," > myoutput.txt &");

											 
												printf("\n\tCommand :%s",command);

											
												system(command);
												
												printf("\n*************************End of Handler*********************\n");
        }
        else
        {
                printf("File Unable to Open...!!");
        }
	
        fclose(fp);
        

	}
	return ifail;
}



































