
echo "IR mail notification Script Called"
cd /user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/
#/home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable ModuleCheckinNotification
/user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/ModuleCheckinNotification -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -SM="$1" -R="$2" -id="$3" &

