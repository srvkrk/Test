/* Program Name: preaction_on_checkin_using_custom_exits.c
/* Purpose : Call TCDC programs on checkin
/* Sharvari Karale
/* Devkant Kedar
*	28/04/2019		Ashwini Yedake	Migration from hexavalent Cr-coated fasteners to trivalent Cr-coated fasteners in line with the validation in TcE for PVBU
*	03/01/2020		Ashwini Yedake	776 - Extension of Fasteners related check for Nexon to TcUA
*	03/08/2023		Aadarsh Kumar	Drawing indicator=D to N not updating thro system, user interactive pop-up message is displayed.
*/
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE 1
#define _CRT_NONSTDC_NO_DEPRECATE 1
#define ITK_Prjerr (EMH_USER_error_base + 8)

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <bom/bom_tokens.h>
#include <pom/pom/pom.h>
#include <tccore/aom.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <ps/ps_errors.h>
#include <ps/vrule.h>
#include <tccore/grm.h>
#include <tc/emh_errors.h>
#include <tc/tc_errors.h>
#include <ss/ss_errors.h>
#include <fclasses/tc_string.h>
#include <property/prop.h>
#include <error.h>

#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define ITK_err (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errErr (EMH_USER_error_base + 99)

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}


#define MAX_LINE_LEN 1024
static const int    ECR_VERBOSE   = 1;
static const int    ECR_DEBUG     = 4;
static       int    log_threshold = 0;
static int	 LHRhFlag		= -1;

#define ECR_IS_VERBOSE   ( log_threshold >= ECR_VERBOSE )
#define ECR_IS_DEBUG     ( log_threshold >= ECR_DEBUG   )

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

static void FU_dumpItkErrors
(
	int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
	const char * prog_name,             /* <I> Name of the Module  */
	int lineNumber,                     /* <I> Line Number in which the error Occurred in the Program */
	const char * fileName               /* <I> Name of the File */
);
#define Debug TRUE

static void FU_dumpItkErrors
(
	int stat,                           /* <I> Checks the return code of the ITK Wrapper call */
	const char * prog_name,             /* <I> Name of the Module  */
	int line_number,                    /* <I> Line Number in which the error Occurred in the Program */
	const char * file_name              /* <I> Name of the File */
)
{
	int n_ifails=0;
	const int *severities=NULL;
	const int *ifails=NULL;
	const char **texts=NULL;
	char *errstring=NULL;
	char *err= NULL;
	err = ( char * ) MEM_alloc ( sizeof ( char ) * MAX_LINE_LEN );

	EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
	if ( n_ifails && texts != NULL )
	{
		if ( ifails[n_ifails-1] == stat )
		{
			//sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, texts[n_ifails-1] );
			//printf ( "%s ", err );
			printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, texts[n_ifails-1] );fflush(stdout);

		}
		else
		{
			EMH_ask_error_text (stat, &errstring );
			//sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
			//printf ( "%s", err );
			printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );fflush(stdout);

			if ( errstring != NULL )
				MEM_free( errstring );
		}
	}
	else
	{
		EMH_ask_error_text (stat, &errstring );
		//sprintf ( err,"\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );
		//printf ( " %s", err );
		printf("\n\n%s: Error %d: %s\n\n", prog_name, stat, errstring );fflush(stdout);
		if ( errstring != NULL )
		MEM_free( errstring );
	}

	//sprintf ( err,"\n\n%s: Error: Line %d in %s\n\n", prog_name, line_number, file_name );
	//printf ( "%s ", err);
	printf("\n\n%s: Error: Line %d in %s \n", prog_name, line_number, file_name );fflush(stdout);
}

#define ITK_CALL_OLD(x)                                                    \
{                                                                          \
	if ( ifail == ITK_ok )                                                 \
	{                                                                      \
		if ( (ifail = (x)) != ITK_ok )                                     \
		{                                                                  \
			FU_dumpItkErrors ( ifail, prog_name, __LINE__, __FILE__ );     \
		}                                                                  \
	}                                                                      \
}

static void print_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Item_idC,int qty,int TmpQty,FILE *fdf,FILE *fus);
static void get_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Env, char *EnvOrignal);
//int getTcPartDetails(tag_t* objTag,char* ptimestamp);
int getTcPartDetails(tag_t* objTag,char ptimestamp[20]);
char* subString (char* mainStringf ,int fromCharf,int toCharf);
//**************
int			ifail 				= ITK_ok;
 int read_value_from_file(char*);
 int IR_checklist(char*,char*,char*,char*);
 int createCheckListRowData(tag_t,char*,char*,char*,tag_t,char*,char*,char*);
//*********

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst = NULL;
	const int *pErrCdeLst = NULL;
	const char **pMsgLst = NULL;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	fprintf( stderr, "Error(PrintErrorStack):\n");
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		TC_write_syslog( "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}

	return ITK_ok;
}

static void report_object_description(tag_t object)
{
	WSO_description_t desc;
	//int sequence_id_c = 0;

	if (WSOM_describe(object, &desc) !=ITK_ok)   PrintErrorStack();
	//if (AOM_ask_value_int(object,"sequence_id",&sequence_id_c)!=ITK_ok)   PrintErrorStack();

	printf("\n report_object_description--TCDCObject Name: %s ", desc.object_name);
	printf("\n report_object_description--TCDCObject Type: %s ", desc.object_type);
	printf("\n report_object_description--TCDCRevision ID: %s ", desc.revision_id);
	//	printf("Sequence ID:		%d\n", sequence_id_c);
	//  printf("Owner's Name:    %s\n", desc.owners_name);
	//  printf("Owning Group:    %s\n", desc.owning_group_name);
	//  printf("Description:     %s\n", desc.description);
	//	printf("Date Created:    %s\n", desc.date_created);
	//  printf("Date Modified:   %s\n", desc.date_modified);
	//  printf("Application:     %s\n", desc.application);
	//  printf("Revision Limit:  %d\n", desc.revision_limit);
	//  printf("Last Modifier    %s\n", desc.last_modifying_user_name);
	//  printf("Is Frozen:       %d\n", desc.is_frozen);
	//  printf("Is Reserved:     %d\n", desc.is_reserved);
	//  printf("Owning Site:     %s\n", desc.owning_site_name);
}

//int getTcPartDetails(tag_t* objTag,char* ptimestamp)
int getTcPartDetails(tag_t* objTag,char ptimestamp[20])
{
	const char *prog_name="getTcPartDetails";
	char name[WSO_name_size_c +1];
	char description[WSO_desc_size_c +1];
	char* Item_id = NULL;
	char* sRevision = NULL;
	char* sSequence = NULL;
	char* sDescription = NULL;
	char* sPartType = NULL;
	char* sModelDescription = NULL;
	char* sKeywordDescription = NULL;
	char* sAddonDescription = NULL;
	char* sProjectCode = NULL;
	char* sDesignGroup = NULL;
	char* sMaterialInDrawing = NULL;
	char* sMaterialThickness = NULL;
	char* sMaterialClass = NULL;
	char* sYield = NULL;
	char* sEnteredWeight = NULL;
	char* sRollupWeight = NULL;
	char* sSurfaceArea = NULL;
	char* sVolume = NULL;
	char* sEnvelopeDimensions = NULL;
	char* sPartCategory = NULL;

	int iSequence = 0;
	double dEnteredWeight = 0.0;
	double dRollupWeight = 0.0;
	double dSurfaceArea = 0.0;
	double dVolume = 0.0;
	WSO_description_t desc;

	char *sStagingDir=NULL;
	char *TcDcEnvName=NULL;
	FILE* fpPLMProperties = NULL;
	char* sPLMProperties = NULL;
	int ifail = ITK_ok;
	struct stat info;
	char cDescRevision[WSO_name_size_c+1] = { "" };
	char *newPatRev = NULL;
	char *newPatSeq = NULL;
	char*  cRevSeq = NULL;
	/*************TZ 1.30*****************/
	char* ct5_DrawingInd = NULL;
	char* ct5_PartStatus = NULL;
	date_t dcreation_date;
	date_t dlast_mod_date;
	char* ccreation_date = NULL;
	char* clast_mod_date = NULL;
	char* ct5_SheetSize = NULL;
	char* ct5_ManCadInd = NULL;
	/*************TZ 1.30*****************/

	Item_id = malloc (50 * sizeof (char *) );
	sRevision = malloc(4 * sizeof (char *) );
	sSequence = malloc(4 * sizeof (char *) );
	sDescription = malloc(400 * sizeof (char *) );
	sPartType = malloc(25 * sizeof (char *) );
	sModelDescription = malloc(400 * sizeof (char *) );
	sKeywordDescription = malloc(400 * sizeof (char *) );
	sAddonDescription = malloc(400 * sizeof (char *) );
	sProjectCode = malloc(10 * sizeof (char *) );
	sDesignGroup = malloc(10 * sizeof (char *) );
	sMaterialInDrawing = malloc(50 * sizeof (char *) );
	sMaterialThickness = malloc(50 * sizeof (char *) );
	sMaterialClass = malloc(400 * sizeof (char *) );
	sYield = malloc(50 * sizeof (char *) );
	sEnteredWeight = malloc(50 * sizeof (char *) );
	sRollupWeight = malloc(50 * sizeof (char *) );
	sSurfaceArea = malloc(50 * sizeof (char *) );
	sVolume = malloc(50 * sizeof (char *) );
	sEnvelopeDimensions = malloc(50 * sizeof (char *) );
	sPartCategory = malloc(50 * sizeof (char *) );

	/*************TZ 1.30*****************/
	ct5_DrawingInd = malloc(3 * sizeof (char *) );
	ct5_PartStatus = malloc(50 * sizeof (char *) );
	ccreation_date = malloc(30 * sizeof (char *) );
	clast_mod_date = malloc(30 * sizeof (char *) );
	ct5_SheetSize = malloc(4 * sizeof (char *) );
	ct5_ManCadInd = malloc(3 * sizeof (char *) );
	/*************TZ 1.30*****************/

	sStagingDir = malloc(500* sizeof (char *) );
	//TcDcEnvName = malloc(250 * sizeof (char *) );
	sPLMProperties = malloc(750 * sizeof (char *) );

	ITK_CALL(AOM_ask_value_string(*objTag,"item_id",&Item_id));
	ITK_CALL(WSOM_describe(*objTag, &desc));
	ITK_CALL(AOM_ask_value_int(*objTag,"sequence_id",&iSequence));
	ITK_CALL(AOM_ask_value_string(*objTag,"object_desc",&sDescription));

	if(tc_strcmp(sDescription,"")==0)
	{
		tc_strcpy(sDescription,"NULL");
	}
	//ITK_CALL(AOM_ask_value_string(*objTag,"t5_PartType",&sPartType));
	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_PartType",&sPartType));
	if(tc_strcmp(sPartType,"")==0)
	{
		tc_strcpy(sPartType,"NULL");
	}

	//tc_strcpy ( cDescRevision, desc.revision_id );
	printf("\n getTcPartDetails--sPartType=%s ",sPartType);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(*objTag,"item_revision_id",&cRevSeq));
	printf("\n getTcPartDetails--TCDC in getTcPartDetails AOM_UIF_ask_value cRevSeq: %s ", cRevSeq);fflush(stdout);

	//tc_strcpy ( cDescRevision, desc.revision_id );
	//printf("\ncDescRevision:%s",cDescRevision);
	//newPatRev = strtok ( cDescRevision, ";" );
	newPatRev = strtok ( cRevSeq, ";" );
	//newPatRev = strtok ( cDescRevision, ";" );
	newPatSeq = strtok ( NULL, ";" );

	printf("\n getTcPartDetails--TCDCRevision=%s ",newPatRev);fflush(stdout);
	printf("\n getTcPartDetails--TCDCSequence=%s ",newPatSeq);fflush(stdout);

	//if( strcmp(desc.revision_id,"NR")!=0 )
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_DocRemarks",&sModelDescription));
	if( strcmp(newPatRev,"NR")!=0 )
	{
		if(tc_strcmp(sModelDescription,"")==0)
		{
			tc_strcpy(sModelDescription,"NULL");
		}
	}
	else
	{
		if(tc_strcmp(newPatSeq,"1")==0)
		{
			tc_strcpy(sModelDescription,"NULL");
		}
	}
	tc_strcpy(sKeywordDescription,"NULL");
	tc_strcpy(sAddonDescription,"NULL");
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_ProjectCode",&sProjectCode));
	if(tc_strcmp(sProjectCode,"")==0)
	{
		tc_strcpy(sProjectCode,"NULL");
	}
	//ITK_CALL(AOM_ask_value_string(*objTag,"t5_DesignGrp",&sDesignGroup));
	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_DesignGrp",&sDesignGroup));
	if(tc_strcmp(sDesignGroup,"")==0)
	{
		tc_strcpy(sDesignGroup,"NULL");
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_Material",&sMaterialInDrawing));
	if(tc_strcmp(sMaterialInDrawing,"")==0)
	{
		tc_strcpy(sMaterialInDrawing,"NULL");
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_MThickness",&sMaterialThickness));
	if(tc_strcmp(sMaterialThickness,"")==0)
	{
		tc_strcpy(sMaterialThickness,"NULL");
	}
	//tc_strcpy(sMaterialClass,"NULL");

	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_MatlClass",&sMaterialClass));
	if(tc_strcmp(sMaterialClass,"")==0)
	{
		tc_strcpy(sMaterialClass,"NULL");
	}

	tc_strcpy(sYield,"NULL");

	ITK_CALL(AOM_ask_value_double(*objTag,"t5_Weight",&dEnteredWeight));
	if(dEnteredWeight==0)
	{
		dEnteredWeight = 0;
	}
	ITK_CALL(AOM_ask_value_double(*objTag,"t5_SurfaceArea",&dSurfaceArea));
	if(dSurfaceArea==0)
	{
		dSurfaceArea = 0;
	}
	ITK_CALL(AOM_ask_value_double(*objTag,"t5_Volume",&dVolume));
	if(dVolume==0)
	{
		dVolume = 0;
	}
	ITK_CALL(AOM_ask_value_string(*objTag,"t5_EnvelopeDimensions",&sEnvelopeDimensions));
	if(tc_strcmp(sEnvelopeDimensions,"")==0)
	{
		tc_strcpy(sEnvelopeDimensions,"NULL");
	}
	tc_strcpy(sPartCategory,"NULL");

	/*************TZ 1.30*****************/
	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_DrawingInd",&ct5_DrawingInd));/*AOM_UIF_ask_value	AOM_ask_value_string*/
	if(tc_strcmp(ct5_DrawingInd,"")==0)
	{
		tc_strcpy(ct5_DrawingInd,"NULL");
	}

	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_PartStatus",&ct5_PartStatus));/*AOM_UIF_ask_value	AOM_ask_value_string*/
	if(tc_strcmp(ct5_PartStatus,"")==0)
	{
		tc_strcpy(ct5_PartStatus,"NULL");
	}

	ITK_CALL(AOM_ask_value_date(*objTag,"creation_date",&dcreation_date));
	ITK_date_to_string(dcreation_date, &ccreation_date);
	if(tc_strcmp(ccreation_date,"")==0)
	{
		tc_strcpy(ccreation_date,"NULL");
	}

	ITK_CALL(AOM_ask_value_date(*objTag,"last_mod_date",&dlast_mod_date));
	ITK_date_to_string(dlast_mod_date, &clast_mod_date);
	if(tc_strcmp(clast_mod_date,"")==0)
	{
		tc_strcpy(clast_mod_date,"NULL");
	}

	ITK_CALL(AOM_UIF_ask_value(*objTag,"t5_SheetSize",&ct5_SheetSize));/*OM_UIF_ask_value	AOM_ask_value_string*/
	if(tc_strcmp(ct5_SheetSize,"")==0)
	{
		tc_strcpy(ct5_SheetSize,"NULL");
	}

	ITK_CALL(AOM_ask_value_string(*objTag,"t5_ManCadInd",&ct5_ManCadInd));
	if(tc_strcmp(ct5_ManCadInd,"")==0)
	{
		tc_strcpy(ct5_ManCadInd,"NULL");
	}

	/*************TZ 1.30*****************/


	sprintf(sSequence,"%d",iSequence);

	printf("\n getTcPartDetails--TCDCPartNumber= [%s] ",Item_id);fflush(stdout);
	tc_strcpy(sRevision,desc.revision_id);fflush(stdout);
	//printf("\n getTcPartDetails--TCDCRevision= [%s] ",sRevision);fflush(stdout);
	printf("\n getTcPartDetails--TCDCRevision= [%s] ",newPatRev);fflush(stdout);
	//printf("\n getTcPartDetails--TCDCSequence= [%s] ",sSequence);fflush(stdout);
	printf("\n getTcPartDetails--TCDCSequence= [%s] ",newPatSeq);fflush(stdout);
	printf("\n getTcPartDetails--TCDCDescription= [%s] ",sDescription);fflush(stdout);
	printf("\n getTcPartDetails--TCDCPart Type= [%s] ",sPartType);fflush(stdout);
	printf("\n getTcPartDetails--TCDCModel Description= [%s] ",sModelDescription);fflush(stdout);
	printf("\n getTcPartDetails--TCDCKeyword Description= [%s] ",sKeywordDescription);fflush(stdout);	//?
	printf("\n getTcPartDetails--TCDCAddon Description= [%s] ",sAddonDescription);fflush(stdout);		//?
	printf("\n getTcPartDetails--TCDCProject Code= [%s] ",sProjectCode);fflush(stdout);
	printf("\n getTcPartDetails--TCDCDesign Group= [%s] ",sDesignGroup);fflush(stdout);
	printf("\n getTcPartDetails--TCDCMaterial In Drawing= [%s] ",sMaterialInDrawing);fflush(stdout);
	printf("\n getTcPartDetails--TCDCMaterial Thickness= [%s] ",sMaterialThickness);fflush(stdout);
	printf("\n getTcPartDetails--TCDCMaterial Class= [%s] ",sMaterialClass);fflush(stdout);			//?		t5_MatlClass
	printf("\n getTcPartDetails--TCDCYield= [%s] ",sYield);fflush(stdout);					//?
	printf("\n getTcPartDetails--TCDCEntered Weight=%.3f ",dEnteredWeight);fflush(stdout);
	printf("\n getTcPartDetails--TCDCRollup Weight=%.3f ",dRollupWeight);	fflush(stdout);		//?
	printf("\n getTcPartDetails--TCDCSurface Area=%.3f ",dSurfaceArea);fflush(stdout);
	printf("\n getTcPartDetails--TCDCVolume=%.3f ",dVolume);fflush(stdout);
	printf("\n getTcPartDetails--TCDCEnvelope Dimensions= [%s] ",sEnvelopeDimensions);fflush(stdout);
	printf("\n getTcPartDetails--TCDCPart Category= [%s] ",sPartCategory);fflush(stdout);			//?		t5_ItmCategory

	/*************TZ 1.30*****************/
	printf("\n getTcPartDetails--TCDCDrawingIndicator= [%s] ",ct5_DrawingInd);fflush(stdout);
	printf("\n getTcPartDetails--TCDCPartStatus= [%s] ",ct5_PartStatus);fflush(stdout);
	printf("\n getTcPartDetails--TCDCCreationDate= [%s] ",ccreation_date);fflush(stdout);
	printf("\n getTcPartDetails--TCDCLastModifiedDate= [%s] ",clast_mod_date);fflush(stdout);
	printf("\n getTcPartDetails--TCDCSheetSize= [%s] ",ct5_SheetSize);fflush(stdout);
	printf("\n getTcPartDetails--TCDCManualDrgIndicator= [%s] ",ct5_ManCadInd);fflush(stdout);
	/*************TZ 1.30*****************/

	/*TcDcEnvName = getenv("TCDC_LOGPATH");
	printf("\nTCDCTcDcEnvName:%s in getTcPartDetails",TcDcEnvName);fflush(stdout);
	if( stat( TcDcEnvName, &info ) != 0 )
	{
		printf("\nTCDCcannot access %s ", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
		return ITK_errStore;
	}
	else if( info.st_mode & S_IFDIR )
	{
		printf("\nTCDC%s is a directory ", TcDcEnvName );fflush(stdout);
	}
	else
	{
		printf("\nTCDC%s is not a directory ", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
		return ITK_errStore;
	}*/

	if(PREF_ask_char_value("TCDC_LOGPATH", 0 , &TcDcEnvName )!=ITK_ok)PrintErrorStack();
	printf ("\n getTcPartDetails--envName= [%s]", TcDcEnvName ) ;

	printf("\n getTcPartDetails--TCDCPlease check TCDC_LOGPATH  [%s] ",TcDcEnvName);fflush(stdout);

	if(!TcDcEnvName)
	{
		printf("\n getTcPartDetails--TCDCcannot access in getTcPartDetails envname: [%s] ", TcDcEnvName );fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!...");
		return ITK_errStore;
	}

	//sprintf(sStagingDir,"%s/%s_%s_%s_%s",TcDcEnvName,Item_id,sRevision,sSequence,ptimestamp);
	sprintf(sStagingDir,"%s/%s_%s_%s_%s",TcDcEnvName,Item_id,newPatRev,newPatSeq,ptimestamp);
	printf("\n getTcPartDetails--TCDCsStagingDir:%s in getTcPartDetails",sStagingDir);fflush(stdout);

	if(mkdir(sStagingDir,00777)==-1)
	{
		printf("\nTCDCerror creating directory inside staging directory ");fflush(stdout);

	}

	sprintf(sPLMProperties,"%s/PLMProperties.txt",sStagingDir);

	printf("\n getTcPartDetails--TCDCsStagingDir:%s",sStagingDir);fflush(stdout);
	printf("\n getTcPartDetails--TCDCtimestamp:%s",ptimestamp);fflush(stdout);
	printf("\n getTcPartDetails--TCDCsPLMProperties:%s",sPLMProperties);fflush(stdout);

	fpPLMProperties = fopen(sPLMProperties,"w");
	if(fpPLMProperties == NULL)
	{
		printf("\n getTcPartDetails--TCDCUnable to create PLMProperties.txt in staging directory ");fflush(stdout);
		return ITK_err;
	}


	fprintf(fpPLMProperties,"PartNumber=%s\n",Item_id);fflush(stdout);
	//fprintf(fpPLMProperties,"Revision=%s\n",sRevision);fflush(stdout);
	fprintf(fpPLMProperties,"Revision=%s\n",newPatRev);fflush(stdout);
	//fprintf(fpPLMProperties,"Sequence=%s\n",sSequence);fflush(stdout);
	fprintf(fpPLMProperties,"Sequence=%s\n",newPatSeq);fflush(stdout);
	fprintf(fpPLMProperties,"Description=%s\n",sDescription);fflush(stdout);
	fprintf(fpPLMProperties,"Part Type=%s\n",sPartType);fflush(stdout);
	fprintf(fpPLMProperties,"Model Description=%s\n",sModelDescription);fflush(stdout);
	fprintf(fpPLMProperties,"Keyword Description=%s\n",sKeywordDescription);fflush(stdout);	//?
	fprintf(fpPLMProperties,"Addon Description=%s\n",sAddonDescription);fflush(stdout);		//?
	fprintf(fpPLMProperties,"Project Code=%s\n",sProjectCode);fflush(stdout);
	fprintf(fpPLMProperties,"Design Group=%s\n",sDesignGroup);fflush(stdout);
	fprintf(fpPLMProperties,"Material In Drawing=%s\n",sMaterialInDrawing);fflush(stdout);
	fprintf(fpPLMProperties,"Material Thickness=%s\n",sMaterialThickness);fflush(stdout);
	fprintf(fpPLMProperties,"Material Class=%s\n",sMaterialClass);fflush(stdout);			//?		t5_MatlClass
	fprintf(fpPLMProperties,"Yield=%s\n",sYield);fflush(stdout);					//?
	fprintf(fpPLMProperties,"Entered Weight=%.3f\n",dEnteredWeight);fflush(stdout);
	fprintf(fpPLMProperties,"Rollup Weight=%.3f\n",dRollupWeight);fflush(stdout);			//?
	fprintf(fpPLMProperties,"Surface Area=%.3f\n",dSurfaceArea);fflush(stdout);
	fprintf(fpPLMProperties,"Volume=%.3f\n",dVolume);fflush(stdout);
	fprintf(fpPLMProperties,"Envelope Dimensions=%s\n",sEnvelopeDimensions);fflush(stdout);
	fprintf(fpPLMProperties,"Part Category=%s\n",sPartCategory);fflush(stdout);			//?		t5_ItmCategory

	/*************TZ 1.30*****************/
	fprintf(fpPLMProperties,"DrawingIndicator=%s\n",ct5_DrawingInd);fflush(stdout);
	fprintf(fpPLMProperties,"PartStatus=%s\n",ct5_PartStatus);fflush(stdout);
	fprintf(fpPLMProperties,"CreationDate=%s\n",ccreation_date);fflush(stdout);
	fprintf(fpPLMProperties,"LastModifiedDate=%s\n",clast_mod_date);fflush(stdout);
	fprintf(fpPLMProperties,"SheetSize=%s\n",ct5_SheetSize);fflush(stdout);
	fprintf(fpPLMProperties,"ManualDrgIndicator=%s\n",ct5_ManCadInd);fflush(stdout);
	/*************TZ 1.30*****************/

	fclose(fpPLMProperties);

	printf("\n getTcPartDetails--Completed processing of function.... ");fflush(stdout);

	return ITK_ok;
}
static void ask_property_value_by_name(tag_t object, char *prop_name,char **prop_value)
{
	tag_t prop_tag = NULLTAG;

	ITK_CALL(PROP_UIF_ask_property_by_name(object, prop_name, &prop_tag));
	ITK_CALL(PROP_UIF_ask_value(prop_tag, prop_value));
}
void GetDifromDesignRev(tag_t* item_rev_tags,char* envNameCpy)
{
	tag_t reln_type =NULLTAG;
	int n_attchs = 0;
	GRM_relation_t *rellist;
	int i = 0;
	int j = 0;
	tag_t primary = NULLTAG;
	int referencenumberfound = 0;
	char refname[AE_reference_size_c + 1];
	AE_reference_type_t reftype;
	tag_t refobject = NULLTAG;
	char orig_name[IMF_filename_size_c + 1];
	tag_t objTypeTag = NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	char *prefSupplierDataDir = NULL;
	char* DownloadPath = NULL;
	char* SupplierDataDir = NULL;
	char* SupplierDataLogPath = NULL;
	FILE* SupplierDatafp = NULL;
	char* DirectoryName = NULL;
	char* DownLoadType = NULL;
	tag_t prop_tag = NULLTAG;
	char *type = NULL;

	DirectoryName = (char *) MEM_alloc(250 * sizeof(char ));
	DownLoadType = (char *) MEM_alloc(50 * sizeof(char ));
	DownloadPath = (char *) MEM_alloc(250 * sizeof(char ));

	tc_strcpy(DownLoadType,"cad");
	printf("\nDownLoadType:%s",DownLoadType);
	printf("\nenvNameCpy:%s",envNameCpy);fflush(stdout);

	ITK_CALL(GRM_list_secondary_objects(*item_rev_tags,reln_type,&n_attchs,&rellist));
	printf("\nn_attchs:%d",n_attchs);fflush(stdout);
	for (i= 0; i < n_attchs; i++)
	{
		printf("\ni:%d",i);fflush(stdout);
		primary=rellist[i].secondary;

		ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
		ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
		printf("\tType Name:%s",type_name);fflush(stdout);

		if(tc_strcmp(type_name,"Design Revision Master")==0)
		{
			printf("\thence Skipping");fflush(stdout);
			continue;
		}
		else if(tc_strcmp(type_name,"Design Revision")==0)
		{
			printf("\thence Skipping");fflush(stdout);
			continue;
		}
		else if(tc_strcmp(type_name,"Design")==0)
		{
			printf("\thence Skipping");fflush(stdout);
			continue;
		}

		ITK_CALL(AE_ask_dataset_ref_count(primary,&referencenumberfound));
		printf("\nreferencenumberfound:%d",referencenumberfound);
		for(j = 0 ;j < referencenumberfound; j++)
		{
			printf("\nj:%d",j);fflush(stdout);
			ITK_CALL(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));
			ask_property_value_by_name(refobject, "Type", &type);
			printf("\treference type:%s",type);fflush(stdout);

			if(tc_strcmp(type,"CMI2BoundingBoxForm")==0)
			{
				printf("\nSkipping:%s",type);fflush(stdout);
				continue;
			}
			else if(tc_strcmp(type,"CMI2AuxFileInfoForm")==0)
			{
				printf("\nSkipping:%s",type);fflush(stdout);
				continue;
			}
			else if(tc_strcmp(type,"CMI2TypeForm")==0)
			{
				printf("\nSkipping:%s",type);fflush(stdout);
				continue;
			}
			ITK_CALL( IMF_ask_original_file_name(refobject,orig_name));
			printf("\nnSupplierData orig_name:%s",orig_name);fflush(stdout);

			if(tc_strcmp(type,"ImanFile")==0)
			{
				printf("\ttype_name:%s",type_name);fflush(stdout);
				if(tc_strstr(type_name,"CMI2")!=NULL)
				{
					tc_strcpy(DownloadPath,envNameCpy);
					tc_strcat(DownloadPath,"/");
					tc_strcat(DownloadPath,orig_name);
					printf("\nDownloadPath:%s",DownloadPath);fflush(stdout);
					IMF_export_file(refobject,DownloadPath);
				}
			}
		}
	}
	printf("\n GetDifromDesignRev--Completed processing of function.... ");fflush(stdout);
}

static tag_t ask_item_revision_from_bom_line(tag_t bom_line)
{
	tag_t item_revision = NULLTAG;
	char *item_id = NULL, *rev_id = NULL;

	ITK_CALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
	ITK_CALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
	ITK_CALL(ITEM_find_rev(item_id, rev_id, &item_revision));

	if (item_id) MEM_free(item_id);
	if (rev_id) MEM_free(rev_id);
	return item_revision;
}

//MBOM implementation for CV TZ-1.69  Start
void  get_CtrlVal_RelStateChkInfRev( char * Plt_Code ,char  RevwLC[40],char RevwLCActVal[40],char  WrkngLC[40],char  WrkngLCActVal[40],char RlzdLC[40],char  RlzdLCActVal[40],char  StdWrkLCActVal[60],char  StdRlzdLCActVal[60],char View[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevwVal 			= NULL;
	 char *WrkngVal			= NULL;
	 char *RlzdVal			= NULL;
	 char *BvrVal			= NULL;
	 char *RevwActVal		= NULL;
	 char *RlzdActVal		= NULL;
	 char *WrkngActVal		= NULL;
	 char *StdRlzdActVal	= NULL;
	 char *StdWrkActVal		= NULL;

	printf("\n Inside get_CtrlVal_RelStateChkInf Plt_Code: %s ------------",Plt_Code);fflush(stdout);

	if(QRY_find("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n get_CtrlVal_RelStateChkInfRev--Control Object Query Found ");fflush(stdout);

		qry_valuesCntrl1[0]="ReleaseStateInf";
		qry_valuesCntrl1[1]=Plt_Code;
		qry_valuesCntrl1[2]="0";

		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n get_CtrlVal_RelStateChkInfRev--Control Object Query not Found ");fflush(stdout);
	}

	printf("\n get_CtrlVal_RelStateChkInfRev--control_number_found1 is : %d ",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevwVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--RevwVal: [%s] ",RevwVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &WrkngVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--WrkngVal: [%s] ",WrkngVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &RlzdVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--RlzdVal: [%s] ",RlzdVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &BvrVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--BvrVal: [%s] ",BvrVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &RevwActVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--RevwActVal: [%s] ",RevwActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &WrkngActVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--WrkngActVal: [%s] ",WrkngActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &RlzdActVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--RlzdActVal: [%s] ",RlzdActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &StdWrkActVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--StdWrkActVal: [%s] ",StdWrkActVal);fflush(stdout);

		AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &StdRlzdActVal);
		printf("\n get_CtrlVal_RelStateChkInfRev--StdRlzdActVal: [%s] ",StdRlzdActVal);fflush(stdout);

		if(tc_strlen(RevwVal)>0)
		{
			tc_strcpy(RevwLC,RevwVal);
		}
		if(tc_strlen(WrkngVal)>0)
		{
			tc_strcpy(WrkngLC,WrkngVal);
		}
		if(tc_strlen(RlzdVal)>0)
		{
			tc_strcpy(RlzdLC,RlzdVal);
		}
		if(tc_strlen(BvrVal)>0)
		{
			tc_strcpy(View,BvrVal);
		}
		if(tc_strlen(RevwActVal)>0)
		{
			tc_strcpy(RevwLCActVal,RevwActVal);
		}
		if(tc_strlen(WrkngLCActVal)>0)
		{
			tc_strcpy(WrkngLCActVal,WrkngActVal);
		}
		if(tc_strlen(RlzdLCActVal)>0)
		{
			tc_strcpy(RlzdLCActVal,RlzdActVal);
		}
		if(tc_strlen(StdWrkLCActVal)>0)
		{
			tc_strcpy(StdWrkLCActVal,StdWrkActVal);
		}
		if(tc_strlen(StdRlzdLCActVal)>0)
		{
			tc_strcpy(StdRlzdLCActVal,StdRlzdActVal);
		}
	}
	printf("\n get_CtrlVal_RelStateChkInfRev--Completed processing of function.... ");fflush(stdout);
}
//MBOM implementation for CV TZ-1.69  End

//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPart(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 1;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	//char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	printf("\n In QueryObsPart function....."); fflush(stdout);
	printf("\n QueryObsPart--ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	//qry_values[1]="DELMAT";
	//qry_values[1]="";

	if(QRY_find("Cntrl_t5ObmPrt", &queryTag));
	if (queryTag)
	{
		printf("\n QueryObsPart--General Cntrl_t5ObmPrt... Found Query ControlObjects ");fflush(stdout);
	}
	else
	{
		printf("\n QueryObsPart--General Cntrl_t5ObmPrt...:Not Found Query ControlObjects ");
		//EMH_store_error_s1(EMH_severity_error,ITK_err,"Cntrl_t5ObmPrt Query Not found please contact to PLM Admin.");
		//return ITK_err;
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("\n QueryObsPart--11 Unique General... Query resultCount :%d: ", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		PrjCdObj = NewPartsSet[0];
		if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
		printf("\n QueryObsPart--In ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
		if(strcmp(ProjectCodeValS,"")!=0)
		{
			ProjectCodeValS1=ProjectCodeValS;
		}
		else
		{
			ProjectCodeValS1="PrtDelete";
		}
	}
	else
	{
		printf("\n QueryObsPart--In ELSE... ");fflush(stdout);
		ProjectCodeValS1 = "QryNotFound";
		printf("\n QueryObsPart--In ELSE ProjectCodeValS1 = %s... ",ProjectCodeValS1);fflush(stdout);
	}

	printf("\n QueryObsPart--In ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	printf("\n QueryObsPart--Completed processing of function.... ");fflush(stdout);

	return ProjectCodeValS1;
}

//Ashwini- to query Obsolete part from Table if exist
char* QueryObsPart_OSPREY(char* ProjctcdeS)
{
	tag_t queryTag		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;

	int n_entries = 2;
	int resultCount =0;

	char *ProjectCodeValS	= NULL;
	char *ProjectCodeValS1	= NULL;
	//char *qry_entries[2] = {"t5_Obspno","t5_AltPartInd"};
	char *qry_entries[2] = {"Obspno","Alt Part Ind"};
	//char *qry_entries[1] = {"Obspno"};
	char **qry_values = (char **) MEM_alloc(20 * sizeof(char *));

	printf("\nIn QueryObsPart"); fflush(stdout);
	printf("\nIn QueryObsPart ProjctcdeS = %s",ProjctcdeS); fflush(stdout);
	qry_values[0]=ProjctcdeS;
	qry_values[1]="OSPREY";
	//qry_values[1]="";

	//if(QRY_find("Cntrl_t5ObmPrt", &queryTag));
	if(QRY_find("Cntrl_t5ObmPrt_OSPRY", &queryTag));
	if (queryTag)
	{
		printf("\nGeneral Cntrl_t5ObmPrt... Found Query ControlObjects");fflush(stdout);
	}
	else
	{
		printf("\n General Cntrl_t5ObmPrt...:Not Found Query ControlObjects ");
		//EMH_store_error_s1(EMH_severity_error,ITK_err,"Cntrl_t5ObmPrt Query Not found please contact to PLM Admin.");
		//return ITK_err;
	}

	if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&NewPartsSet));
	printf("\n11 Unique General... Query resultCount :%d: ", resultCount); fflush(stdout);

	if (resultCount > 0)
	{
		ProjectCodeValS1="OSPREYPresnt";
	//		PrjCdObj = NewPartsSet[0];
	//		if(AOM_ask_value_string(PrjCdObj,"t5_Proalpno",&ProjectCodeValS) != ITK_ok);
	//		printf("\nIn ProjectCodeValS = %s",ProjectCodeValS); fflush(stdout);
	//		if(strcmp(ProjectCodeValS,"")!=0)
	//		{
	//			ProjectCodeValS1=ProjectCodeValS;
	//		}
	//		else
	//		{
	//			ProjectCodeValS1="PrtDelete";
	//		}
	}
	else
	{
		printf("\nIn ELSE... ");fflush(stdout);
		ProjectCodeValS1 = "OSPREYNTPresnt";
	}

	printf("\nIn ProjectCodeValS1 = %s",ProjectCodeValS1); fflush(stdout);
	printf("\n QueryObsPart_OSPREY--Completed processing of function.... ");fflush(stdout);

	return ProjectCodeValS1;
}

void GetAllChild(tag_t* item_rev_tags,char* envNameCpy)
{
	int n = 0;
	tag_t* children = NULLTAG;
	int k = 0;
	int Item_ID = 0;
	char *Item_ID_str = NULL;
	char *ParentPart = NULL;
	char *ParentPart1 = NULL;
	tag_t ChildItemRev = NULLTAG;
	int Item_ID1 = 0;
	char *Item_ID_str1 = NULL;

	tag_t window = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t rule = NULLTAG;

	printf("\n GetAllChild--envNameCpy: [%s]",envNameCpy);fflush(stdout);
	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(CFM_find( "Latest by Creation Date", &rule ));
	ITK_CALL(BOM_set_window_config_rule( window, rule ));
	ITK_CALL(BOM_set_window_pack_all (window, true));
	ITK_CALL(BOM_set_window_top_line (window,null_tag, *item_rev_tags, null_tag, &top_line));

	ITK_CALL( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	ITK_CALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));
	printf("\n GetAllChild--Item_ID_str1: [%s] ",Item_ID_str);fflush(stdout);

	ParentPart =(char *) MEM_alloc(100 * sizeof(char ));
	ParentPart1 =(char *) MEM_alloc(100 * sizeof(char ));

	tc_strcpy(ParentPart,Item_ID_str);
	tc_strcat(ParentPart,"_WE");


	tc_strcpy(ParentPart1,Item_ID_str);
	tc_strcat(ParentPart1,"_SE");

	ITK_CALL(BOM_line_ask_child_lines (top_line, &n, &children));

	for (k = 0; k < n; k++)
	{
		ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID1));
		ITK_CALL(BOM_line_ask_attribute_string(children[k], Item_ID1, &Item_ID_str1));
		printf("\n GetAllChild--Item_ID_str2: [%s] ",Item_ID_str1);fflush(stdout);
		printf("\n GetAllChild--ParentPart: [%s] ",ParentPart);fflush(stdout);
		printf("\n GetAllChild--ParentPart1: [%s] ",ParentPart1);fflush(stdout);
		if((tc_strcmp(Item_ID_str1,ParentPart)==0) || (tc_strcmp(Item_ID_str1,ParentPart1)==0))
		{
			printf("\n GetAllChild--WE/SE part found hence get cad and download to supplier directory ");fflush(stdout);
			ChildItemRev = ask_item_revision_from_bom_line(children[k]);
			GetDifromDesignRev(&ChildItemRev,envNameCpy);
		}
	}
	printf("\n GetAllChild--Completed processing of function.... ");fflush(stdout);
}


//Kalpesh(21_aug_19)-Mandatory attribute validation on check-in.
int checkin_attr_validation(METHOD_message_t *msg, va_list args)
{
	int			status					= ITK_ok;
	int			error_flag1				= 0;
	int			error_flag2				= 0;
	int			accessCount				= 0;
	int			Support_User_Flag		= 0;

	tag_t		objTag					= va_arg(args, tag_t);
	tag_t		*AccessGroups			= NULLTAG;
	tag_t		AccessGroupTag			= NULLTAG;

	char		*type_name				= NULL;
	char		*ee_weight				= NULL;
	char		*ee_desc				= NULL;
	char		*mod_desc				= NULL;
	char		*ee_keyword				= NULL;
	char		*ee_ecutype				= NULL;
	char		*ee_AppforEOL			= NULL;
	char		*ee_EPreadable			= NULL;
	char		*ee_PartType			= NULL;
	char		*ee_swPartType			= NULL;
	char		*username				= NULL;
	char		*error_msg1				= NULL;
	char		*error_msg2				= NULL;
	char		*error_msgP				= NULL;
	char		*AccessGroupName		= NULL;

	error_msgP	=(char* )malloc( 500 * sizeof (char));
	error_msg1	=(char* )malloc( 500 * sizeof (char));
	error_msg2	=(char* )malloc( 500 * sizeof (char));

	tc_strcpy(error_msg1, "Please find list of mandatory attributes while check-in:");
	tc_strcpy(error_msg2, "Please find list of mandatory attributes while check-in:");

	tag_t user_tag = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	int ac = 0;

	if(POM_get_user(&username,&user_tag)!=ITK_ok)PrintErrorStack();

	SA_find_groupmember_by_user(user_tag,&accessCount,&AccessGroups);

	printf("\n checkin_attr_validation--AccessCount: [%d]", accessCount);fflush(stdout);
	for(ac=0;ac<accessCount;ac++)
	{
		AccessGroupTag = AccessGroups[ac];
		AOM_ask_value_string(AccessGroupTag,"object_name",&AccessGroupName);
		printf("\n checkin_attr_validation--AccessGroupName : [%s]", AccessGroupName);fflush(stdout);

		if (tc_strstr(AccessGroupName,"PLM_Support_Group")!=NULL)
		{
			Support_User_Flag=1;
			break;
		}
	}
	printf("\n checkin_attr_validation--Support_User_Flag : [%d]", Support_User_Flag);fflush(stdout);

	//if(tc_strcmp(username,"loader") != 0 && tc_strcmp(username,"infodba") != 0 && tc_strcmp(username,"ercpsup") != 0)
	if(tc_strcmp(username,"loader") != 0 && tc_strcmp(username,"infodba") != 0 && Support_User_Flag == 0)
	{
		/****************************************Rohit Validation starts for SWP related check*********************************/

		tag_t	dataset_relation_typeP	=   NULLTAG;
		tag_t	*DatasetListP			=	NULLTAG;
		tag_t	datasetP				=	NULLTAG;
		tag_t	swp_CntrlOBJ			=	NULLTAG;
		tag_t	*CntrlObject_swp		=	NULLTAG;
		tag_t	objTypeTagP				=	NULLTAG;
		tag_t	objTypeTagR				= NULLTAG;

		char	*item_idR				=	NULL;
		char	*item_idRR				=	NULL;
		char	*item_dsggrp			=	NULL;
		char	*ctrlobj_dsggrp			=	NULL;
		char    *type_nameP				=	NULL;
		char	*object_nameP			=	NULL;
		char	*type_nameR				= NULL;

		char *qry_swp[1] = {"SYSCD"};
		char **qry_valuesswp = (char **) MEM_alloc(10 * sizeof(char *));
		qry_valuesswp[0] = "swpval";

		int		cntP		= 0;
		int		ip			= 0;
		int		swp_entries	= 1;
		int		swp_found	= 0;

		if(QRY_find("Control Objects...",&swp_CntrlOBJ));
		if(QRY_execute(swp_CntrlOBJ, swp_entries, qry_swp, qry_valuesswp, &swp_found, &CntrlObject_swp));
		printf("\n checkin_attr_validation--PRO SWP Control Object SYSCD :[ %d ] ",swp_found);	fflush(stdout);

		if(swp_found > 0)
		{
			printf("\n checkin_attr_validation--Inside Control Object for SWP validation "); fflush(stdout);
			if (TCTYPE_ask_object_type(objTag,&objTypeTagR)!=ITK_ok)PrintErrorStack();
			if (TCTYPE_ask_name2(objTypeTagR, &type_nameR)!=ITK_ok)PrintErrorStack();
			printf("\n checkin_attr_validation--object_type for SWP cehck: [%s] ", type_nameR);fflush(stdout);

			if(strcmp(type_nameR,"Design Revision")==0 ||strcmp(type_nameR,"ItemRevision")==0)
			{
				ITK_CALL(AOM_ask_value_string(objTag,"item_id",&item_idR));
				ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&item_idRR));
				ITK_CALL(AOM_ask_value_string(objTag,"t5_DesignGrp",&item_dsggrp));
				printf("\n checkin_attr_validation--Rohit part is : [%s] and [%s] and its design group is [%s] ",item_idR,item_idRR,item_dsggrp); fflush(stdout);

				ITK_CALL(AOM_ask_value_string(CntrlObject_swp[0],"t5_Userinfo1",&ctrlobj_dsggrp));
				printf("\n checkin_attr_validation--Design Groups present inside Control Object are : [%s] ",ctrlobj_dsggrp); fflush(stdout);

				//if(!(item_dsggrp >= "60" && item_dsggrp <= "99"))
				//if(item_dsggrp >= "60" && item_dsggrp <= "99")
				if (tc_strstr(ctrlobj_dsggrp,item_dsggrp) !=NULL)
				{
					printf("\n checkin_attr_validation--Design Group inside Loop is :[%s] ",item_dsggrp);fflush(stdout);
					ITK_CALL(GRM_find_relation_type("IMAN_specification",&dataset_relation_typeP));
					ITK_CALL(GRM_list_secondary_objects_only(objTag,dataset_relation_typeP,&cntP,&DatasetListP));
					printf("\n checkin_attr_validation--After GRM_list_secondary_objects_only count of sec objects is [%d] ",cntP);fflush(stdout);

					for ( ip = 0 ; ip < cntP ; ip++ )
					{
						//printf("\n checkin_attr_validation--Inside FOR loop ");	fflush(stdout);

						datasetP = DatasetListP[ip];

						ITK_CALL(TCTYPE_ask_object_type(datasetP,&objTypeTagP));
						ITK_CALL(TCTYPE_ask_name2(objTypeTagP,&type_nameP));
						ITK_CALL(AOM_ask_value_string(datasetP,"object_name",&object_nameP));

						printf("\n checkin_attr_validation--Dataset ObjectClassTypeP and object_nameP are :[%s] and [%s] ",type_nameP,object_nameP);fflush(stdout);

						if(strcmp(type_nameP,"ProPrt")==0 || strcmp(type_nameP,"ProAsm")==0)
						{
							//printf("\nInside name Loop ");

							if(strstr(object_nameP,"_swp")!=NULL) //Check case sensitive with Ninad
							{
								printf("\n checkin_attr_validation--Please cut CREO document as this is CATIA part and then try to check-in ");	fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Please cut CREO Dataset with _SWP present in its name and then try to check in as this is CATIA Part/Assembly.");
								return ITK_errStore;
							}
						}
					}
				}
				else
				{
					printf("\n checkin_attr_validation--This Check is bypassed for this part as it is not CATIA part "); fflush(stdout);
				}
			}
		}
		/****************************************Rohit Validation Ends for SWP related check*********************************/

		printf("\n checkin_attr_validation--Inside method checkin_attr_validation...!! ");
		if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
		if (TCTYPE_ask_name2(objTypeTag, &type_name)!=ITK_ok)PrintErrorStack();
		printf("\n checkin_attr_validation--object_type:%s ", type_name);

		if(tc_strcmp(type_name, "T5_EE_PartRevision") == 0)
		{
			if(AOM_UIF_ask_value(objTag, "t5_Weight", &ee_weight) != ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "object_desc", &ee_desc)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_DocRemarks", &mod_desc)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_CategoryName", &ee_keyword)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_EcuType", &ee_ecutype)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_AppForEOL", &ee_AppforEOL)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_EPReadable", &ee_EPreadable)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_EE_PartType", &ee_PartType)!= ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value(objTag, "t5_SwPartType", &ee_swPartType)!= ITK_ok)PrintErrorStack();
			printf("\n checkin_attr_validation--Weight:[%s]\nDesc:%s\nMod_desc:%s\nKeyword_desc:%s\nEcuType:%s\nAppForEOL:%s\nRead/Write:%s\nEE_PartType:%s\nSwPartType:%s ",ee_weight,ee_desc,mod_desc,ee_keyword,ee_ecutype,ee_AppforEOL,ee_EPreadable,ee_PartType,ee_swPartType);

			//weight, desc, mod_desc & keyword_desc
			if(tc_strlen(ee_weight) == 0)
			{
				error_flag1 = 1;
				tc_strcat(error_msg1, ",weight");
			}

			if(tc_strlen(ee_desc) == 0)
			{
				error_flag1 = 1;
				tc_strcat(error_msg1, ",object_desc");
			}

			if(tc_strlen(mod_desc) == 0)
			{
				error_flag1 = 1;
				tc_strcat(error_msg1, ",mod_desc");
			}

			if(tc_strlen(ee_keyword) == 0)
			{
				error_flag1 = 1;
				tc_strcat(error_msg1, ",ee_keyword_desc");
			}

			if(error_flag1 == 1)
			{
				printf("\n checkin_attr_validation--error_msg1=> [%s]  ",error_msg1);fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, error_msg1);
				return ITK_err;
			}

			if(tc_strcmp(ee_swPartType,"Others") != 0)
			{
				//ECU type, AppforEOL, read/write & EE Part type
				if(tc_strlen(ee_ecutype) == 0)
				{
					error_flag2 = 1;
					tc_strcat(error_msg2, ",ecutype");
				}

				if(tc_strlen(ee_AppforEOL) == 0)
				{
					error_flag2 = 1;
					tc_strcat(error_msg2, ",AppforEOL");
				}

				if(tc_strlen(ee_EPreadable) == 0)
				{
					error_flag2 = 1;
					tc_strcat(error_msg2, ",EPreadable");
				}

				if(tc_strlen(ee_PartType) == 0)
				{
					error_flag2 = 1;
					tc_strcat(error_msg2, ",EE_PartType");
				}

				if(error_flag2 == 1)
				{
					printf("\n checkin_attr_validation--error_msg2=> [%s] ", error_msg2);fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,error_msg2);
					return ITK_err;
				}
			}

			char* Swtype=NULL;
			char* EPUnit=NULL;
			char* EPLen=NULL;
			char* ECUType=NULL;
			char* EPDidValue=NULL;
			char* ECUVendor=NULL;
			char* ECUVersion=NULL;
			char* EP_ID=NULL;
			char* EPType=NULL;
			tag_t relation_type=NULLTAG;
			tag_t sec_tag_para=NULLTAG;
			int count=0;
			tag_t *rellist=NULL;
			int i=0,error_flagP=0;
			ITK_CALL(AOM_ask_value_string(objTag,"t5_SwPartType",&Swtype));
			printf("\n checkin_attr_validation--Swtype= %s  ",Swtype);fflush(stdout);

			if (tc_strcmp(Swtype,"PRM")==0)
			{
				tc_strcpy(error_msgP, " ");
				tc_strcat(error_msgP, "Please find list of mandatory attributes of Parameter ");

				tag_t TagQryContObj = NULLTAG,*cntr_objects = NULL;
				int	n_entries = 2;
				int n_found = 0;

				char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
				char *qry_values[2] = {"EE_ECUPara", "EE_ECUParaVal"};

				if(QRY_find2("ControlObjQry", &TagQryContObj));

				if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
				printf("\n checkin_attr_validation--Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

				GRM_find_relation_type ("T5_EEPrm", &relation_type);
				GRM_list_secondary_objects_only(objTag,relation_type, &count, &rellist);

				for (i=0;i<count ;i++ )
				{
					//error_msgP="";



					//EPUnit="";
					//EPLen="";

					//ECUType="";
					//EPDidValue="";


					//ECUVendor="";
					//ECUVersion="";
					//EP_ID="";



					sec_tag_para=rellist[i];
					//sec_tag_para_rel=rellist[i].the_relation;

					AOM_ask_value_string(sec_tag_para, "object_name", &EP_ID);//

					printf("\n checkin_attr_validation--EP_ID: %s ",EP_ID);fflush(stdout);


					tc_strcat(error_msgP, "=> ");

					AOM_ask_value_string(sec_tag_para, "t5_EPUnit", &EPUnit);//
					AOM_ask_value_string(sec_tag_para, "t5_EPLen", &EPLen);//
					AOM_ask_value_string(sec_tag_para, "t5_ECUType", &ECUType);//
					AOM_ask_value_string(sec_tag_para, "t5_EPDidValue", &EPDidValue);//
					AOM_ask_value_string(sec_tag_para, "t5_ECUVendor", &ECUVendor);//
					AOM_ask_value_string(sec_tag_para, "t5_ECUVersion", &ECUVersion);//

					printf ("\n checkin_attr_validation--%s======>>>>%s,%s,%s,%s,%s,%s, ",EP_ID,EPUnit,EPLen,ECUType,EPDidValue,ECUVendor,ECUVersion);fflush(stdout);
					if(tc_strlen(ECUType) == 0)
					{
						printf ("\n checkin_attr_validation--Inside ECUTYPE <%s>======",ECUType);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "ECU Type,");
					}

					if(tc_strlen(EPUnit) == 0)
					{
						printf ("\n checkin_attr_validation--Inside EPUnit <%s>======",EPUnit);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "Unit,");
					}

					if(tc_strlen(EPLen) == 0)
					{
						printf ("\n checkin_attr_validation--Inside EPLen <%s>======",EPLen);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "Length,");
					}

					if(tc_strlen(EPDidValue) == 0)
					{
						printf ("\n checkin_attr_validation--Inside EPDidValue <%s>======",EPDidValue);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "DID value,");
					}
					if(tc_strlen(ECUVendor) == 0)
					{
						printf ("\n checkin_attr_validation--Inside ECUVendor <%s>======",ECUVendor);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "Vendor,");
					}
					if(tc_strlen(ECUVersion) == 0)
					{
						printf ("\n checkin_attr_validation--Inside ECUVersion <%s>======",ECUVersion);fflush(stdout);
						error_flagP = 1;
						tc_strcat(error_msgP, "Version");
					}

					if(n_found>0)
					{
						if(error_flagP == 1)
						{
							tc_strcat(error_msgP, " for  ECU parameter =>> ");
							tc_strcat(error_msgP, EP_ID);

							printf("\n checkin_attr_validation--error_msgP= [%s] ",error_msgP);fflush(stdout);

							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err, error_msgP);
							return ITK_err;
						}
					}

					printf ("\n checkin_attr_validation--%s======>>>>%s,%s,%s,%s,%s,%s, ",EP_ID,EPUnit,EPLen,ECUType,EPDidValue,ECUVendor,ECUVersion);fflush(stdout);

					//AOM_ask_value_string(sec_tag_para, "object_name", &EP_ID);
					//AOM_ask_value_string(sec_tag_para, "t5_t5EPDesc", &EPDesc);
					//AOM_ask_value_string(sec_tag_para, "t5_EPValueList", &EPValueList);
					//AOM_ask_value_string(sec_tag_para, "t5_EPReadable", &EPReadable);
					//AOM_ask_value_string(sec_tag_para, "t5_EPApplicable", &EPApplicable);
					//AOM_ask_value_string(sec_tag_para_rel, "t5_BitValue", &ECUBitValue);
					//AOM_ask_value_string(sec_tag_para_rel, "t5_ParamValue", &ECUParamValue);
				}
			}
		}
	}
	printf("\n checkin_attr_validation--Completed processing of function.... ");fflush(stdout);

	return ITK_ok;
}
//End(kalpesh)

//Neha
int ENVErrorFn (char *ENVP_Diam)
{
	int Flag = 1;
	char *Tok1 = NULL;
	char *Tok2 = NULL;
	char *Tok3 = NULL;

	printf("\n\t ENVErrorFn--Env Dia is [%s]  ",ENVP_Diam);
	if (tc_strcmp(ENVP_Diam,"0X0X0")==0 || tc_strcmp(ENVP_Diam,"0x0x0")==0 )
	{
		Flag = 0;
	}

	if (tc_strstr(ENVP_Diam,"x")!=NULL)
	{
		Tok1=tc_strtok(ENVP_Diam,"x");
		Tok2=tc_strtok(NULL,"x");
		Tok3=tc_strtok(NULL,"x");
	}
	else
	{
		Tok1=tc_strtok(ENVP_Diam,"X");
		Tok2=tc_strtok(NULL,"X");
		Tok3=tc_strtok(NULL,"X");
	}

	if( tc_strcmp(Tok1,"")==0 || tc_strcmp(Tok2,"")==0 || tc_strcmp(Tok3,"")==0 || tc_strcmp(Tok1,NULL)==0 || tc_strcmp(Tok2,NULL)==0 || tc_strcmp(Tok3,NULL)==0 )
	{
		Flag = 0;
	}

	printf("\n ENVErrorFn--Completed processing of function.... ");fflush(stdout);

	return Flag;
}

int checkin_validation(tag_t objTag)
{
	printf("\n In checkin_validation Function  ");fflush(stdout);
	char *partCat = NULL;
	char *partCatDup = NULL;
	char *partType = NULL;
	logical	sprInd	= false;
	char *envDim = NULL;
	double wt = 0.0;
	char *matCls = NULL;
	char *weighttt = NULL;
	char *uom = NULL;
	char *qty = NULL;
	char *cmvrR = NULL;
	int count=0;
	int i=0;
	int len = 0;
	int after_decimal = 0;
	int total_Count = 0;
	int before_decimal = 0;
	int envErr = 0;

	ITK_CALL(AOM_ask_value_string(objTag,"t5_SpareCriteria",&partCat));
	ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&partType));
	ITK_CALL(AOM_ask_value_logical(objTag,"t5_SpareInd",&sprInd));
	ITK_CALL(AOM_UIF_ask_value(objTag,"t5_Weight",&weighttt));

	//code for counting digits after decimal
	before_decimal = atoi(weighttt);
	while(before_decimal!=0){
		before_decimal = before_decimal/10;
		count++;
	}
	len = strlen(weighttt);
	while(weighttt[i]!='.'){
	   i++;
	}
	after_decimal= len-i-1;
	printf("\n checkin_validation--Number of digits after decimal points are %d ",after_decimal);

	printf("\n checkin_validation--Part Type :: %s ",partType);fflush(stdout);
	partCatDup=subString(partCat,0,3);
	printf("\n checkin_validation--Part category :: %s ",partCatDup);fflush(stdout);

	//Actual logic
	// return 1- if condition true
	// return 2- if env is blank
	// return 3 - if wt is blank
	// return 4 - if matClass is blank
	// return 5 - if UOM is blank
	// return 6 - if env format is not ok
	// return 7 - if wt format is not ok

	if(tc_strcmp(partCatDup,"BTS")==0)
	{
		printf("\n checkin_validation--Inside BTS ");fflush(stdout);

		if(tc_strcmp(partType,"A")==0)
		{
			printf("\n checkin_validation--Inside Assembly ");fflush(stdout);
			envDim = NULL;
			wt = 0.0;
			uom = NULL;
			if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&envDim)==ITK_ok)
			{
				if(tc_strcmp(envDim,"")==0)
				{
					return 2;
				}
				else if(ENVErrorFn(envDim) == 0)
				{
					return 6;
				}

			}
			if(AOM_ask_value_double(objTag,"t5_Weight",&wt)==ITK_ok)
			{
				printf("\n checkin_validation--Entered Weight: [%f]",wt);fflush(stdout);
				if(wt==0.0)
				{
					return 3;
				}
				//else if (after_decimal>4)
				//{
				//	return 7;
				//}

			}

			//mat class not needed
		}
		else if(tc_strcmp(partType,"C")==0)
		{
			envDim = NULL;
			uom = NULL;
			printf("\n checkin_validation--Inside Component ");fflush(stdout);
			if(sprInd==1)
			{
				printf("\n checkin_validation--Inside Spare Indicator is True ");fflush(stdout);

				if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&envDim)==ITK_ok)
				{
					if(tc_strcmp(envDim,"")==0)
					{
						return 2;
					}
					else if(ENVErrorFn(envDim) == 0)
					{
						return 6;
					}
				}

				//wt not needed
				//mat class not needed
			}
			else
			{
				uom = NULL;
				printf("\n checkin_validation--Inside Spare Indicator is False ");fflush(stdout);
				//env dim not needed
				//wt not needed
				//mat class not needed
			}
		}
	}
	else if(tc_strcmp(partCatDup,"BTP")==0)
	{
		printf("\n checkin_validation--2.Inside else ");fflush(stdout);
		if(tc_strcmp(partType,"A")==0)
		{
			envDim = NULL;
			uom = NULL;
			printf("\n checkin_validation--2.Inside Assembly ");fflush(stdout);
			if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&envDim)==ITK_ok)
			{
				if(tc_strcmp(envDim,"")==0)
				{
					return 2;
				}
				else if(ENVErrorFn(envDim) == 0)
				{
					return 6;
				}
			}

			//wt not needed
			//mat class not needed
		}
		else if(tc_strcmp(partType,"C")==0)
		{
			envDim = NULL;
			matCls = NULL;
			wt = 0.0;
			uom = NULL;
			if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&envDim)==ITK_ok)
			{
				if(tc_strcmp(envDim,"")==0)
				{
					return 2;
				}
				else if(ENVErrorFn(envDim) == 0)
				{
					return 6;
				}
			}

			if(AOM_ask_value_double(objTag,"t5_Weight",&wt)==ITK_ok)
			{
				printf("\n checkin_validation--2.Entered Weight: [%f]",wt);fflush(stdout);
				if(wt==0.0 )
				{
					return 3;
				}
				//else if (after_decimal>4)
				//{
				//	return 7;
				//}
			}


			if( AOM_ask_value_string(objTag,"t5_MatlClass",&matCls)==ITK_ok)
			{
				if(tc_strcmp(matCls,"")==0)
				{
					return 4;
				}
			}

		}
	}
	if(AOM_UIF_ask_value(objTag,"t5_uom",&uom)==ITK_ok)
	{
		if(tc_strcmp(uom,"")==0)
		{
			return 5;
		}
	}

	printf("\n ENVErrorFn--Completed processing of function.... ");fflush(stdout);

	return 1;
}
//End code Neha

extern DLLAPI int checkin_method_1(METHOD_message_t *m, va_list args)
{
	int status = 0;

	const char *prog_name = "checkin_method_1";

	tag_t objTag = va_arg(args, tag_t);

	int n_attchs,nattchs,n_attchsd,n_attchs1,i=0,referencenumberfound=0, referencenumberfound1=0,j=0,TCDCControlFlag=0,errorflag=0,Comperrorflag=0;
	int sequence_id_c=0,Item_Type=0,j1=0,Item_RevisionW=0,Item_IDW=0,counter=0,counterPDF=0,CatPrtCN=0,ProPrtCN=0,CatPrdt=0,ProAsmCN=0;
	int CmiDrwCnt = 0;
	int i_ChildCount= 0,iChldPrts=0,iItemType=0,iItemRevId=0,iItemId=0,iChildItemTag=0,iChdItemTag=0;//Abhishek
	int ChildCount= 0;
	int ItemType=0;
	int kk=0;
	int i_ChildSeq= 0,ChldSeq= 0,iItemChkdOut=0;//Abhishek
	int iChildPartChkOutFlag=0;//Abhishek
	int *levels,p=0;
	int n = 0;

	char *ret_id = NULL, *ret_rev = NULL;
	char *objName = NULL, *Item_Revision_strW = NULL,  *Item_Type_str = NULL,  *Item_ID_strW = NULL;
	char *Item_id = NULL;
	char *RefItem_id = NULL;
	char *Item_idOwn = NULL;
	char *ModDes = NULL;
	char *projcode = NULL;
	char *projcodeS = NULL;
	char *desgrp = NULL;
	char *parttyp = NULL;
	char *PartType123 = NULL;
	char *PatSeq = NULL;
	char *TempTcPrtFile= NULL;
	char *drawingnum = NULL;

	AE_reference_type_t reftype;
	AE_reference_type_t reftype1;

	tag_t reln_type = NULLTAG;
	tag_t reln_type1 = NULLTAG;
	tag_t primarydProAsmDS = NULLTAG;

	tag_t *children1 = NULLTAG;
	tag_t *ChildRevobject = NULLTAG;
	tag_t *secondary_objects = NULLTAG,
		  *sec_objects = NULLTAG,
		  *secondary_objectsd = NULLTAG,
		  *secondary_objects1 = NULLTAG,
		  primary,primaryd = NULLTAG,
		  primary1,Childobject = NULLTAG,
		  refobject,refobject1 = NULLTAG,
		  objTypeTag = NULLTAG,
		  objTypeTagDi = NULLTAG,
		  objTypeTagDid = NULLTAG,
		  objTypeTag1 = NULLTAG,
		  ChildobjTypeTag1 = NULLTAG,
		  objTypeTagW = NULLTAG,
		  objTypeRefTag = NULLTAG;

	char refname[AE_reference_size_c + 1];
	char refname1[AE_reference_size_c + 1];
	char orig_name[IMF_filename_size_c + 1];
	char orig_nameW[IMF_filename_size_c + 1];
	char path_name[SS_MAXPATHLEN];
	char path_name2[SS_MAXPATHLEN];
	char ownFilenamePass[SS_MAXPATHLEN];
	//char ownFilenamePass[IMF_filename_size_c+1];
	char ownFilename[IMF_filename_size_c+1];
	char path_nameW[SS_MAXPATHLEN];
	char type_name[TCTYPE_name_size_c+1];
	char type_name2[TCTYPE_name_size_c+1];
	char type_name2d[TCTYPE_name_size_c+1];
	char type_name_ref[TCTYPE_name_size_c+1];
	char child_type_name[TCTYPE_name_size_c+1];
	char type_name1[TCTYPE_name_size_c+1];

	WSO_description_t desc;

	//char envName[500];
	//char TmpenvName[500];
	//char envName1[500];

	//FILE *fp = NULL;
	FILE *fp1 = NULL;
	//FILE *fp2 = NULL;
	FILE *fpSrc = NULL;
	FILE *fpDest = NULL;

	IMF_file_t ft;

	double dWeight=0;
	double dSurfArea=0;
	double dVol=0;

	char line1[20000];
	char *Finalline = NULL;
	char *Finalline1 = NULL;
	char *tmp1 = NULL;
	char *envName1 = NULL;
	char *Name = NULL;
	char *TmpenvName = NULL;
	char *envName = NULL;
	char *envNameCpy = NULL;
	char *ShellInpFilePath = NULL;
	char *envOrignal = NULL;
	char *FileName = NULL;
	char *ShellFileName = NULL;
	char *TempFile = NULL;
	char *sObjDesc = NULL;
	char *sMtrl = NULL;
	char *sSurfPrtStd = NULL;
	char *sMtrThiknes = NULL;
	char *sEnvDim = NULL;
	char *DrnInd = NULL;
	char *DrwNo = NULL;
	char *MdlInd = NULL;
	char buf[20000];
	char command[100];
	char *JTTransFileName = NULL;
	char *PDFTransFileName = NULL;
	char *cp_ItemType_str = NULL;//Abhishek
	char *ItemType_str = NULL;//Abhishek
	char *cp_ItemID_str = NULL;//Abhishek
	char *cp_ItemRev_str = NULL;//Abhishek
	char *cp_ChildSeq,*cp_ChildChkOutValue,*Desc_obj = NULL;//Abhishek

	tag_t window, window2, rule,rule1, item_tag = null_tag, top_line,top_line1=NULLTAG;
	tag_t t_BomLineWindow, t_Rule, t_ItemTag = null_tag, t_TopLine,t_Childobject=NULLTAG,t_ChildObjType=NULLTAG; //Abhishek
	tag_t t_Window, t_RRule, ItemTag = null_tag, t_TLine,t_ChldObj=NULLTAG,t_ChldObjType=NULLTAG; //Abhishek
	tag_t t_ChildItemRev=NULLTAG, t_ChildRev=NULLTAG, ItemMasterTag=NULLTAG;//Abhishek
	tag_t projobj=NULLTAG;
	tag_t objMasterTag=NULLTAG;
	tag_t user_tag=NULLTAG;
	tag_t owning_user = NULLTAG;
	tag_t Child_owning_user = NULLTAG;

	tag_t *t_PartChildren=NULLTAG;//Abhishek
	tag_t *t_PrtChldren=NULLTAG;//Abhishek
	tag_t *tags_found=NULLTAG, *referencers=NULLTAG, *Objects_Found = NULLTAG;

	logical	b_ChildChkOutValue ;//Abhishek
	logical	is_final=0 ;//Abhishek

	char ca_ChildType_Name[TCTYPE_name_size_c+1];//Abhishek
	char ChildType_Name[TCTYPE_name_size_c+1];//Abhishek

	int n_tags_found= 0,n_tags_found1=0,cnt,k=0,n_refs=0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	char **attrs1 = (char **) MEM_alloc(1 * sizeof(char *));
	char **values1 = (char **) MEM_alloc(1 * sizeof(char *));
	//	char relative_path[IMF_relative_path_size_c+1];
	char task_name[WSO_name_size_c+1];

	time_t now;
	struct tm *timeinfo;

	char timestamp[20] = { 0 };

	char* ptimestamp = NULL;
	char* username;
	char **relations = NULL;
	char *ObjProject = NULL;
	char* TcDcShellEnvName = NULL;
	char *CheckinItemId = NULL;
	char *datasetItemId = NULL;
	char *sDesignGroup = NULL;
	char *sPartType = NULL;
	char *sComponentType = NULL;
	char *sIsCatiaComp = NULL;
	char *newPatRev = NULL;
	char *RefPatRev = NULL;
	char *newPatSeq = NULL;
	char *RefPatSeq = NULL;
	char *cRevSeq = NULL;
	char *RefRevSeq = NULL;
	char *AttributeNullList = NULL ;
	char *CompAttributeNullList = NULL ;
	char *subclass_name_ObS = NULL;

	struct stat info;

	char cDescRevision[WSO_name_size_c+1] = { "" };
	char userid[SA_user_size_c+1];
	char childPartOwner[SA_user_size_c+1];
	tag_t *children=NULLTAG;
	//int ifail = ITK_ok;
	int   ifail				= 0;

	//char *tmpDrwNum = NULL;
	//char *tmpDrwNum1 = NULL;
	//char *tmpDrwNum2 = NULL;
	//char *tmpDrwNum3 = NULL;
	//char *tmpDrwNum4 = NULL;
	char *drwnum = NULL;
	char *oDrwNum = NULL;
	char *oDrwNum1 = NULL;
	char *oDrwNum2 = NULL;
	char *oDrwNum3 = NULL;

	//validation on check in
	char *Desc_obj2	= NULL;
	char *sObjTagMatDrw = NULL;
	char *sMatClass = NULL;
	char *sObjTagDrwInd = NULL;
	char *sPartStatus	  = NULL;
	char *sPartType1	  = NULL;
	char *sCatName	  = NULL;
	char *sDesignGrp	  = NULL;
	char *ItemDesc	  = NULL;
	logical	SpareInd1	= false;
	char *SpareCriteria1	 = NULL;
	char *RefPartNumber1	 = NULL;
	char *MThickness		 = NULL;
	char *TempVal			 = NULL;
	char *EnvelopeDim		 = NULL;
	char *ThirdBarrel		 = NULL;
	int y = 0;
	int counter1	= 0;
	int             ir,im =0;
	double objWeightVal ;
	char wgtstr[100];
	int left=0;
	int right=0;
	int Rolflag1=0;
	int Qtyflag1=0;

	//TZ 1.42
	char *DesgTypAPL	  = NULL;
	char *desidForAPL  = NULL;
	char *sFourFiveChar = NULL;
	char *sFrstFourChar = NULL;
	char *sNineTenChar   = NULL;
	char *sPartColIndAPL= NULL;
	char *sPrtCompCodeAPL= NULL;
	tag_t  CurrentRoleTag = NULLTAG;
	char roleName[SA_name_size_c+1];
	char* CheckedCompApl = NULL ;
	WSO_search_criteria_t      criteria_control;
	int        control_number_found;
	int        iCntl=0;
	tag_t *list_of_WSO_cntrl_tags    =    NULLTAG;
	WSO_search_criteria_t  	criteria_controlPrj;
	tag_t *list_of_WSO_cntrlPrj_tags=NULLTAG;
	tag_t *list_of_WSO_cntrlPrjA_tags=NULLTAG;


	char *qry_entryCntrl[4]  = {"Name","SUBSYSCD","Delete Indicator","Information-1"};
	char **qry_valuesCntrl= (char **) MEM_alloc(6 * sizeof(char *));
	char **qry_valuesCntrlA= (char **) MEM_alloc(6 * sizeof(char *));
	//TZ 1.42

	int control_number_foundPrj = 0;
	int control_number_foundPrjA = 0;
	int jPrj = 0;
	int FlagLivPrj = 0;
	int FlagLivUpd = 0;
	int n_entryCntrl    = 4;
	int PrtNumTplobo =0;
	int weChildChkOutFlag=0;

	//static int LHRhFlag = -1;

	char *subSyscdPrj = NULL;
	char *PlantNamePrj = NULL;
	char *PartConsumVal = NULL;
	char *username1 = NULL;
	char *userid1 = NULL;
	char *homeSite = NULL;
	char *siteName = NULL;
	char *hostName = NULL;
	char *sUsrInfo = NULL;
	char *sUsrInfo2 = NULL;
	char *sUsrInfo3 = NULL;

	tag_t qryTagCntrl = NULLTAG;
	tag_t user_tag1 = NULLTAG;

	//tmpDrwNum = (char *)malloc(500 * sizeof(char));
	//tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	//tmpDrwNum2 = (char *)malloc(500 * sizeof(char));
	//tmpDrwNum3 = (char *)malloc(500 * sizeof(char));
	//tmpDrwNum4 = (char *)malloc(500 * sizeof(char));

	sDesignGrp = malloc(10 * sizeof (char *) );
	sMatClass = malloc(400 * sizeof (char *) );
	TempVal=(char *) MEM_alloc(1000);
	CheckedCompApl = (char* ) malloc ( 2000 * sizeof ( char ) ) ;//TZ 1.42
	drwnum = (char *)malloc(500 * sizeof(char));
	oDrwNum = (char *)malloc(500 * sizeof(char));
	oDrwNum1 = (char *)malloc(500 * sizeof(char));
	oDrwNum2= (char *)malloc(500 * sizeof(char));
	oDrwNum3 = (char *)malloc(500 * sizeof(char));
	//validation on check in end

	//**************Akshay Toke***************
	printf("\n i am in Checklist creation "); fflush(stdout);

	char   *ModuleNumber   =NULL;
	
    ITK_CALL( AOM_UIF_ask_value(objTag,"t5_PartType",&parttyp));
    printf("\n part type=> [%s] ",parttyp); fflush(stdout);

	ITK_CALL(TCTYPE_ask_object_type(objTag,&objTypeTag));	 
	ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n object type name=> [%s] ",type_name); fflush(stdout);

	ITK_CALL( AOM_ask_value_string(objTag,"item_id",&ModuleNumber));
	 printf("\n module item id=> [%s] ",ModuleNumber); fflush(stdout);

  if(tc_strcmp(parttyp,"Module")==0 && tc_strcmp(type_name,"Design Revision")==0);
	{
	 printf("\n part type is module and it is design Revision "); fflush(stdout);
     char *InpFile;
     InpFile = (char *) malloc(sizeof (char) * 500 );
 //  strcpy(InpFile,"/user/testcmi/Dev/devgroups/Akshay/IR/");
     strcpy(InpFile,"/home/uadev/devgroups/Akshay/");

     strcat(InpFile,ModuleNumber);
     strcat(InpFile,"_Input.txt");
    printf("\n CHECKLIST FILE PATH=> [%s] ",InpFile); fflush(stdout);

	 ifail = read_value_from_file(InpFile);

	 printf("\n checklist creation scuessfully "); fflush(stdout);
	
	}




	//************************************

	//******************************************************* Added by Vinayak_B(Comp_code_validation) Start *******************************************************//

	char* Comp_code = NULL;
	char *revID_CCA	=	NULL;
	char *latest_rev_IDCCA = NULL;
	char *latest_item_IDCCA	= NULL;
	char *latest_rev_fastCCA = NULL;
	char *CCA_color_ind = NULL;
	char *CCA_color_id_str = NULL;
	char * SpareCriteria = NULL;  //Adi - PPart
	char * RefPartNumber = NULL;  //Adi - PPart

	int topline_CCA_count	=	0;
	int child_item_id_CCA =0;
	int Child_color_ind=0;
	int CCA_child=0;
	int CCA_flag=0;

	tag_t *CCA_childs =	NULLTAG;

	tag_t bom_CCA = NULLTAG;
	tag_t topline_CCA = NULLTAG;
	tag_t fastener_childtag = NULLTAG;
	tag_t CCA_rule = NULLTAG;
	tag_t latest_IDCCA = NULLTAG;
	tag_t latest_revCCA = NULLTAG;
	tag_t Childobject_CCA = NULLTAG;

	logical	SpareInd = false;

	/************** Adi CMI 1.26**************/
	char *catiasynch = NULL;
	char *qry_entries[1] = {"SYSCD"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *itemId = NULL;
	char cmi_name[TCTYPE_name_size_c+1];

	int n_entries = 1;
	int resultCount = 0;
	int ij=0, jj=0, flag = 0;

	tag_t cmiprimary = NULLTAG;
	tag_t cmiobjTypeTagDi = NULLTAG;
	tag_t queryTag = NULLTAG;

	tag_t *rev = NULLTAG;
	tag_t *CntrlObjectTag=NULLTAG;
	tag_t *cmi_objects = NULLTAG;
	/************* Adi CMI 1.26 *************/

	/************** Adi CMI 1.32 ***************/
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";
	char *DesignGrpProE = "00,01,02,03,04,05,00,07,08,09,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59";
	char *DesignGrpCat = NULL;
	/************** Adi CMI 1.32 ***************/

	/*********** Adi Alias 1.33*************/
	tag_t primaryd1;
	tag_t objTypeTagDid1;
	tag_t *secondary_objectsd1;
	int  k1 = 0;
	int  n_attchsd1 = 0;
	char *DatasetNameD = NULL;
	char *AlTransFileName= NULL;
	char type_name3d[TCTYPE_name_size_c+1];
	/***********Adi Alias 1.33*************/


	ITK_CALL(AOM_ask_value_string(objTag,"item_id",&revID_CCA));
	ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&latest_rev_IDCCA));
	printf("\n In checkin_method_1--revID_CCA [%s] and latest_rev_IDCCA: [%s]",revID_CCA,latest_rev_IDCCA); fflush(stdout);

	ITK_CALL(ITEM_find_item(revID_CCA,&latest_IDCCA));
	ITK_CALL(ITEM_ask_latest_rev(latest_IDCCA,&latest_revCCA));

	ITK_CALL(AOM_ask_value_string(latest_IDCCA,"item_id",&latest_item_IDCCA));
	ITK_CALL(AOM_ask_value_string(latest_revCCA,"item_revision_id",&latest_rev_fastCCA));
	printf("\n checkin_method_1--Item ID_CCA and Revision ID_CCA for rev is [%s] and [%s]",latest_item_IDCCA,latest_rev_fastCCA); fflush(stdout);

	ITK_CALL( AOM_ask_value_string(objTag,"t5_PrtCatCode",&Comp_code)!=ITK_ok);PrintErrorStack();
	printf("\n checkin_method_1--Comp_code is  [%s]",Comp_code); fflush(stdout);

	if(tc_strstr(Comp_code,"CCA") != NULL)
	{
		ITK_CALL(BOM_create_window(&bom_CCA)!=ITK_ok); PrintErrorStack();
		ITK_CALL(CFM_find("Latest Working", &CCA_rule)!=ITK_ok); PrintErrorStack();
		ITK_CALL(BOM_set_window_config_rule( bom_CCA, CCA_rule)!=ITK_ok); PrintErrorStack();
		ITK_CALL(BOM_set_window_pack_all(bom_CCA, true)!=ITK_ok); PrintErrorStack();
		ITK_CALL(BOM_set_window_top_line(bom_CCA,latest_IDCCA,latest_revCCA,NULLTAG,&topline_CCA)!=ITK_ok);	PrintErrorStack();

		printf("\n checkin_method_1--Window created AFTER "); fflush(stdout);
		ITK_CALL(BOM_line_ask_child_lines(topline_CCA,&topline_CCA_count,&CCA_childs)!=ITK_ok);	PrintErrorStack();
		printf("\n checkin_method_1--Child count related to CCA=> [%d] ",topline_CCA_count); fflush(stdout);

		if(topline_CCA_count>0)
		{
			printf("\t--BOM is present for  Comp_code_CCA  "); fflush(stdout);

			for (CCA_child = 0; CCA_child < topline_CCA_count; CCA_child++)
			{
				if(Childobject_CCA) Childobject_CCA=NULLTAG;
				Childobject_CCA=CCA_childs[CCA_child];

				//ITK_CALL(AOM_ask_value_string(Childobject_CCA, "bl_item_item_id", &child_item_id_CCA )!=ITK_ok);PrintErrorStack();
				ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&child_item_id_CCA)!=ITK_ok);PrintErrorStack();
				ITK_CALL(BOM_line_ask_attribute_string(Childobject_CCA, child_item_id_CCA, &CCA_color_id_str)!=ITK_ok);PrintErrorStack();

				ITK_CALL(BOM_line_look_up_attribute ("bl_T5_ClrPartRevision_t5_ColourInd",&Child_color_ind)!=ITK_ok);PrintErrorStack();
				ITK_CALL(BOM_line_ask_attribute_string(Childobject_CCA, Child_color_ind, &CCA_color_ind)!=ITK_ok);PrintErrorStack();

				printf("\n checkin_method_1--item_id and CCA_color_ind is==> %s and %s",CCA_color_id_str,CCA_color_ind); fflush(stdout);

				if(tc_strcmp(CCA_color_ind,"Y")==0)
				{
					printf("\n checkin_method_1--inside CCA_child_color_ind is Y "); fflush(stdout);
					CCA_flag=1;
					break;
				}
				else
				{
					printf("\n checkin_method_1--CCA_child must have color_ind Y "); fflush(stdout);
				}
			}
			if(CCA_flag==0)
			{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"If parent is having comp_code CCA,it should have atleast one child with color_ind Y");
					return ITK_errStore;
			}
		}
		else
		{
			EMH_clear_errors();
			EMH_store_error_s1(EMH_severity_error,ITK_errStore,"BOM must be present for the given comp_code_CCA");
			return ITK_errStore;;
			printf("\n checkin_method_1--BOM must be present for the given comp_code_CCA"); fflush(stdout);
		}
	}
	//******************************************************* Added by Vinayak_B(Comp_code_validation) End *******************************************************//

	/********************Alias assy management***********************/
	char *AliasenvNameCpy	   = NULL;
	char *str				   = NULL;
	char *strtxt			   = NULL;
	char *AliastxtNameCpy	   = NULL;
	char* AliasShellEnvName    = NULL;
	char* AliasItem_id		   = NULL;
	char* AliasItemRev_id	   = NULL;
	char* AliasRev			   = NULL;
	char* AliasSeq			   = NULL;
	char* Al_ChildChkOutValue  = NULL;
	char *DsetID			   = NULL;
	char *Alobject_type        = NULL;
	char *sRef_list            = NULL;
	char *AliasenvName		   = NULL;
	char *AliastxtName		   = NULL;
	char *reference_nameDS     = NULL;
	char* AliasDownloadPath	   = NULL;
	char* AliasTmpenvName	   = NULL;
	char *AliasFileName		   = NULL;
	char *Al_type 			   = NULL;
	char *AlTEXTFileName       = NULL;
	char *DatasetNameD1		   = NULL;

	tag_t reln_typeAl		   = NULLTAG;
	tag_t A_BomLineWindow	   = NULLTAG;
	tag_t A_Rule			   = NULLTAG;
	tag_t a_ItemTag			   = NULLTAG;
	tag_t a_TopLine			   = NULLTAG;
	tag_t datasettype		   = NULLTAG;
	tag_t filetag			   = NULLTAG;
	tag_t A_Childobject		   = NULLTAG;
	tag_t AlsecObjTypeTag      = NULLTAG;
	tag_t Alrefobject		   = NULLTAG;
	tag_t aNewDataset = NULLTAG;
	tag_t relation = NULLTAG;
	tag_t AliasobjTypeTag = NULLTAG;
	tag_t Relatn_type1 = NULLTAG;
	tag_t relation_fnd3 = NULLTAG;
	tag_t ChildItemRev = NULLTAG;
	tag_t file_tag = NULLTAG;

	tag_t *secondary_objectsAl = NULLTAG;
	tag_t *namedRef_tag = NULLTAG;
	tag_t *a_PartChildren = NULLTAG;

	IMF_file_t 	file_descriptor;
	IMF_file_t fileDescriptor;

	logical	checkout2;

	int Alias_attchs = 0;
	int AChldPrts = 0;
	int a_ChildCount = 0;
	int result = 0;
	int refnum = 0;
	int xx = 0;
	int n_attchsd2 = 0;
	int iItemChkdOutA = 0;

	char Alrefname[AE_reference_size_c + 1];
	char Alorig_name[IMF_filename_size_c + 1];
	char Altype_name2[TCTYPE_name_size_c+1];
	char a_typename[TCTYPE_name_size_c+1];
	//char Al_type[TCTYPE_name_size_c+1];
	char *sChildItemID = NULL;

	AE_reference_type_t Alreftype;
	reference_nameDS = (char *) MEM_alloc(10);
	AliasDownloadPath = (char *) MEM_alloc(250 * sizeof(char ));
	AE_reference_type_t tagRefType = 1;
	char  **ref_list;
	int	  ref_count = 0;
	int AliasFlag = 0;
	AE_reference_type_t tagRefTypeText	= 1;

	tag_t relation_typeAlias = NULLTAG;
	tag_t *data_objectsAl = NULLTAG;
	int at =0;
	/*******************Alias assy management ************************/

	char *Item_idDC  = NULL; //Adi 1.36
	char *bl_objectString = NULL;
	char *ref_objectString = NULL;
	int	BomViewCnt = 0;
	tag_t	*BomViewList = NULLTAG;
	tag_t	LatestRev = NULLTAG;
	tag_t	ref_item = NULLTAG;
	int partlength = 0;
	int item_seq = 0;

	tag_t itemrev1 = NULLTAG;

	//LH/RH Attribute declare
	char * ItemLhRhInd = NULL;
	char * DatasetName = NULL;
	int HasSymPrt=0;
	int filelinecount = 0;
	char* gov_classification = NULL;
	char *FirstEightDig = NULL;

	//ADDED by Ajinkya on 25 June//
	char   *sModuleName13  = NULL;
	char   *sModuleName14  = NULL;
	char *subpart5	   = NULL;
	char *subpart7	   = NULL;
	char *ChildCpy	   = NULL;
	char *t5_RhPart	   = NULL;

	tag_t chkout_childUsr = NULLTAG;
	tag_t chkout_childGrp = NULLTAG;
	tag_t chkout_PuserT = NULLTAG;
	tag_t chkout_PgrpT = NULLTAG;
	char *chkoutC_userid = NULL;
	char *chkoutP_userid = NULL;
	int		IsValidSite	=	0;

	static int          trans_sched_priority        = 0;
	static char        *trans_provider_name         = NULL;
	static char        *trans_service_name          = NULL;
	static char        *trans_type                  = NULL;
	static int          num_dataset_type_names      = 0;
	static char       **dataset_type_names          = NULL;
	static int          num_trans_args              = 0;
	static char       **trans_args                  = ( char ** )0;

	tag_t trans_rqst = NULLTAG;
	tag_t prop_tag = NULLTAG;
	char *prop_value = NULL;

	int iChPrts,QtyValue=0,ColIndValue=0;
	char	*QtyOccur_str	= NULL;
	char	*ColInd_str	= NULL;
	ChildCpy = malloc(250 * sizeof (char *) );

	char *info1	= NULL;
	char *info2	= NULL;
	tag_t TagQryContObjSite = NULLTAG, *BypCnObj = NULLTAG;
	int n_Input = 2,ByPasQCount = 0,CheckBypasFlag=0;
	char *qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_BypVal[2] = {"VALDBYPASS", "DSGPROJ"};

	//Ashwini
	char *projectcode = NULL;
	char *CprojcodeS = NULL;
	char *CDsgnGrpS = NULL;
	char *CItemNameS = NULL;
	char *AlternatePrtS	= NULL;
	char *CStrtngWth1	= NULL;
	char *ChildCpyAltS = NULL;
	char *ChildOSPRENTS = NULL;
	char *CPartQryLst = NULL;

	ChildCpy = malloc(1000 * sizeof(char *));

	tag_t queryTagObs		= NULLTAG;
	tag_t *NewPartsSet	= NULLTAG;
	tag_t PrjCdObj		= NULLTAG;
	tag_t *NewPartsSetObs	= NULLTAG;

	tag_t TagControlObs14 = NULLTAG,
	*cntr_objectsObs14 = NULL;
	int	n_entriesObs14 = 1;
	int n_foundObs14 = 0;
	char *qry_entriesObs14[1] = {"SYSCD"};
	char *qry_valuesObs14[1] = {"Obsolete_PrjCde_allow"};
	char *info3 = NULL;
	char *info4 = NULL;
	char *info5 = NULL;
	char *info6 = NULL;
	char *info7 = NULL;
	char *info8 = NULL;
	char *info9 = NULL;
	char *info10 = NULL;

	int n_entriesObs = 2;
	int resultCountObs =0;
	int CADDatasetExistflag=1;

	char *ProjectCodeValS = NULL;
	char *qry_entriesObs[2] = {"Name","Type"};
	char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n checkin_method_1--IN function QueryProject.. ");fflush(stdout);

	int altCount = 0;
	int OspryCount = 0;
	int QryFound = 0;
	int Cpartlength = 0;
	int CDsgnI,CPCdeI,CNameI;

	//added by ajinkya on 20 june//
	tag_t   qryCmiTag     = NULLTAG;
	char    **cmiCtrObjct     =  (char **) MEM_alloc(10 * sizeof(char *));
	int n_refcmi = 1;
	char    *qry_entry[1]  = {"SYSCD"};
	char    *cmi_qry_entry[1]  = {"SYSCD"};
	int rsltcmiCount = 0;
	tag_t   *cmiCntrlObjectTag      = NULLTAG;
	char	*cminfo1	= NULL;

	char *desgrpcmi = NULL;
	char  *Part_Desg	= NULL;
	char* sPartColInd = NULL;
	char* sPrtCompCode = NULL;

	int MessageFlagWE = 0;
	int MessageFlagAD = 0;
	int MessageFlagMB = 0;

	//end on 20 june//
	//added by ajinkya on 20/08/2019//
	char *parttypn = NULL;
	//end

	int			Key_entries			= 2;
	int			Key_found			= 0;
	int			key					= 0;
	int			prop				= 0;
	int			PropNum				= 0;
	int			Flag				= 0;
	int			CntlObjCount		= 0;
	int			Key_qry_entry		= 1;

	tag_t		queryKey			= NULLTAG;
	tag_t		*Keycntr_objects	= NULLTAG;
	tag_t		CntrlObjQry			= NULLTAG;
	tag_t		*CntObj_Tag			= NULLTAG;
	int n_parents=0;
	int *level = 0;
	int jd =0;
	tag_t *parents = NULLTAG;
	tag_t ArchAssyTag =NULLTAG;
	char* Arch_obj= NULL;
	tag_t ArchobjTypeTag=NULLTAG;
	char   Archtype_name[TCTYPE_name_size_c+1];
	char	*moduleNo	 = NULL;
	tag_t	queryTag1	= NULLTAG;
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries1[1] = {"ID"};
	int n_entries1 = 1;
	int resultCount1,Optcnt = 0;
	tag_t *Optfmly_Set=NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	char		*view_name				= NULL;
	char*			partTok					 = NULL;
	char*			viewTok					 = NULL;
	int flagBVR=0;

	int flagOptionFamily=0;
	int FlagFoundCol=0;
	int FlagFoundSCHEME=0;

	tag_t   window1=NULLTAG;
	tag_t   ruleM	=NULLTAG;
	tag_t   top_lineM=NULLTAG;
	tag_t *Nlines = NULLTAG;
	int n_count,p1 =0;
	tag_t        ReviseClrPrt           = NULLTAG;
	tag_t        ReviseClrPrtRev        = NULLTAG;
	tag_t   Childobject1=NULLTAG;
	char	*child_item_id	 = NULL;
	int Revformula;
	char *Item_ID_str= NULL;

	//mbb start
	int		QryEntryCnt			=	1;
	int		CntlObjCnt2			=	0;
	tag_t	*CntObj_Tag2		=	NULLTAG;
	tag_t	KeyCtrObjQry		=	NULLTAG;

	char	*QryEntry[1]		=	{"SYSCD"};
	char	**QryValue2			=	(char **) MEM_alloc(10 * sizeof(char *));
	//mbb stop

	//E-Cert Validations Start
	char *PartNum = NULL;
	char *PartNumDup = NULL;
	char *PartRev = NULL;
	char *PartRevDup = NULL;
	char *partType = NULL;
	char *partTypeDup = NULL;
	char *cmvrInd = NULL;
	char *cmvrIndDup = NULL;
	char *HlgInd = NULL;
	char *HlgIndDup = NULL;
	char *pObjType = NULL;
	char *pObjTypeDup = NULL;
	char *pcolInd = NULL;
	char *pcolIndDup = NULL;
	char *keywDesc = NULL;
	char *keywDescDup = NULL;
	char *pDesginGrp = NULL;
	char *pDesginGrpDup = NULL;
	char *sModuleInfo = NULL;
	char *tok_value1 = NULL;
	char *tok_value2 = NULL;
	char *tok_value3 = NULL;
	char *eCertNumInp = NULL;

	int one_entries = 1;
	int certCount = 0;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	int nTwo = 2;
	int modCount = 0;

	tag_t	ECertQry	= NULLTAG;
	tag_t	*opCertTags = NULLTAG;
	tag_t	KWDescQry = NULLTAG;
	tag_t	*moduleTags = NULLTAG;

	char *two_attr[2] = {"Name","ext_1"};
	char *ecert_entries[1] = {"Name"};
	char *keysAttr[1] = {"creation_date"};
	char **ecert_values = (char **) MEM_alloc(20 * sizeof(char *));
	char *eCertNumStr =(char *) MEM_alloc(20 * sizeof(char *));
	char **two_values = (char **) MEM_alloc(50 * sizeof(char *));
	//E-Cert Validation End

	//CompCode Update Validation
	int			CmpCdUpd				= 1;
	int			CmpCdUpdCnt				= 0;
	int			rev_cnt					= 0;
	int			iji						= 0;
	int			FlagKey					= 0;
	int			ClrPrtcnt				= 0;

	tag_t		Item_tagT				= NULLTAG;
	tag_t		LatestRev_tag			= NULLTAG;
	tag_t		Clr_Relation			= NULLTAG;
	tag_t		*CC_CtrlObjSet			= NULLTAG;
	tag_t		*rev_list_set			= NULLTAG;
	tag_t		*ClrPrtSet				= NULLTAG;
	tag_t		UseMaster				= NULLTAG;
	tag_t		Nrev					= NULLTAG;

	char		*Clr_Ind				= NULL;
	char		*RevisionString			= NULL;
	char		*NewRevisionString		= NULL;
	char		*CompCoDeStr			= NULL;
	char		*PreCompCoDeStr			= NULL;
	char		*item_IdStr				= NULL;
	char		*Rlstatus				= NULL;

	char		*CmpCdUpd_entry[1]		= {"SYSCD"};
	char		**CmpCdUpd_val			= (char **) MEM_alloc(10 * sizeof(char *));
	//CompCode Update Validation: End

	char *ColInd = NULL;
	char *MNumber = NULL;
	char *OptfmlyStr = NULL;
	char *MRevisionID = NULL;
	char *PartMType = NULL;
	char *KeyWordDesc = NULL;
	char *Key_PartType = NULL;
	char *Rev_idStr = NULL;
	char *DgnGrp = NULL;
	char *CmpCode = NULL;
	char *OppHandDrgLHRHPart = NULL;
	char **CmpCode_List = NULL;
	char *qryKey_entries[2] = {"Name","ext_1"};
	char *QryCntr_entry[1] = {"SYSCD"};
	char **QryCntr_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **Keyqry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *CompCodeCatList = NULL;
	char *DfmeaNumber1 = NULL;
	char *DfmeaNumber2 = NULL;
	char *s1  = NULL;
	char *s2  = NULL;
	char *s3  = NULL;
	char *s4  = NULL;
	char *s5  = NULL;
	char *s6  = NULL;
	char *s7  = NULL;
	char *s8  = NULL;
	char *s9  = NULL;
	char *ss1 = NULL;
	char *ss2 = NULL;
	char *ss3 = NULL;
	char *ss4 = NULL;
	char *ss5 = NULL;
	char *ss6 = NULL;
	char *ss7 = NULL;
	char *ss8 = NULL;
	char *ss9 = NULL;
	char *colInd = NULL;
	char *ColIndYPrt = NULL;

	char *strtxt1 = NULL;
	strtxt1 =(char *)MEM_alloc(100);
	char *strtxt2 = NULL;
	strtxt2 =(char *)MEM_alloc(100);
	FILE *fptr1;
	FILE *fptr2;
	FILE *fptrx;
	FILE *fptry;

	char *Logfname1 = NULL;
	Logfname1 =(char *)MEM_alloc(100);
	char *Logfname2 = NULL;
	Logfname2 =(char *)MEM_alloc(100);
	char *Logfnamex = NULL;
	Logfnamex =(char *)MEM_alloc(100);
	char *Logfnamey = NULL;
	Logfnamey =(char *)MEM_alloc(100);

	char *inputline1 = NULL;
	inputline1 =(char *)MEM_alloc(100);
	char *inputline2 = NULL;
	inputline2 =(char *)MEM_alloc(100);
	char *inputlinex = NULL;
	inputlinex =(char *)MEM_alloc(100);
	char *inputliney = NULL;
	inputliney =(char *)MEM_alloc(100);

	char *DfmeapathName		   = NULL;

	char   *PlantName = NULL;	//MBOM implementation for CV TZ-1.69
	char   *dsgModAddressVal = NULL;	//MBOM implementation for CV TZ-1.69
	char RvwLCVal[40];	//MBOM implementation for CV TZ-1.69
	char WrkngLCVal[40]; //MBOM implementation for CV TZ-1.69
	char WrkngActLCVal[40]; //MBOM implementation for CV TZ-1.69
	char RlzdLcVal[40];	//MBOM implementation for CV TZ-1.69
	char RlzdActLcVal[40];	//MBOM implementation for CV TZ-1.69
	char RvwLCActVal[40]; //MBOM implementation for CV TZ-1.69
	char View[40];//MBOM implementation for CV TZ-1.69
	char StdWrkLcVal[60];//MBOM implementation for CV TZ-1.69
	char StdRlzdLcVal[60];//MBOM implementation for CV TZ-1.69


	CompCodeCatList=(char *) MEM_alloc(1000);
	tc_strcpy(CompCodeCatList,"");

	AttributeNullList = (char* ) malloc ( 500 * sizeof ( char ) ) ;
	CompAttributeNullList = (char* ) malloc ( 500 * sizeof ( char ) ) ;

	tc_strcpy ( AttributeNullList, "Please find List of Mandatory Attributes :" );
	tc_strcpy ( CompAttributeNullList, "Please find List of Mandatory Attributes For Component:" );

	printf("\n checkin_method_1--for PRO-e ");fflush(stdout);

	if( AOM_ask_value_string(objTag,"gov_classification",&gov_classification)!=ITK_ok)PrintErrorStack();
	printf("\n checkin_method_1--gov_classification: [%s] ",gov_classification);fflush(stdout);

	if ( tc_strcmp(gov_classification, "Cancel_CheckOut" ) == 0)
	{
		return ITK_ok;
	}

	POM_get_user(&username,&user_tag);
	//Neha
	if((strcmp(username,"loader")==0) || strcmp(username,"infodba")==0)
	//if((strcmp(username,"loader")==0))
	{
		printf("\n checkin_method_1--This is loader/infodba login");fflush(stdout);
		goto BYPASSLOADER;
	}
	else
	{
		printf("\n checkin_method_1--not a loader loginnnnnnnn");fflush(stdout);
	}

	printf("\n checkin_method_1--Welcome :[%s]",username);fflush(stdout);
	time(&now);
	timeinfo = localtime(&now);
	//strftime(timestamp, 20, "%d%m%Y_%H%M%S", d);
	strftime(timestamp, 20, "%Y-%m-%d-%H_%M_%S", timeinfo);
	//sprintf(timestamp,"2015-06-05-02_46_01");
	printf("\n checkin_method_1--It's the time to stamp %s ", timestamp);fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok)PrintErrorStack();

	printf("\n checkin_method_1--Started for type_name allow only for selected class for Pro: [%s] ", type_name);fflush(stdout);

	//MBOM implementation for CV TZ-1.69 ,Start
	CALLAPI(SA_ask_current_role(&CurrentRoleTag));
	CALLAPI(SA_ask_role_name(CurrentRoleTag,roleName));
	printf("\n checkin_method_1--roleName : %s ",roleName); fflush(stdout);

	if( (tc_strstr(roleName,"APL")!=NULL) || (tc_strstr(roleName,"MBOM")!=NULL)) //MBOM implementation for CV TZ-1.69
	{
		printf("\n checkin_method_1--APL User Start \n");fflush(stdout);

		if(tc_strstr(roleName,"MBOM")!=NULL)	//MBOM implementation for CV TZ-1.69
		{
			dsgModAddressVal = strtok (roleName,"_");	//MBOM implementation for CV TZ-1.69
			PlantName = strtok (NULL,"_");
			printf( "dsgModAddressVal:%s\n", dsgModAddressVal); fflush(stdout);
			printf( "MBOM PlantName:%s\n", PlantName); fflush(stdout); //MBOM implementation for CV TZ-1.69
		}
		else
		{
			PlantName=subString(roleName,3,4);
		}
		printf("\n checkin_method_1--PlantName:%s", PlantName);fflush(stdout);

		get_CtrlVal_RelStateChkInfRev(PlantName,RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,StdWrkLcVal,StdRlzdLcVal,View);//MBOM implementation for CV TZ-1.69

		printf( "\n checkin_method_1--RvwLCVal:%s ,RvwLCActVal:%s ,WrkngLCVal :%s,WrkngActLCVal :%s,RlzdLcVal: %s,RlzdActLcVal :%s,StdWrkLcVal :%s,StdRlzdLcVal :%s, View:%s\n", RvwLCVal,RvwLCActVal,WrkngLCVal,WrkngActLCVal,RlzdLcVal,RlzdActLcVal,StdWrkLcVal,StdRlzdLcVal,View);fflush(stdout);//MBOM implementation for CV TZ-1.69
	}//MBOM implementation for CV TZ-1.69,End


	//if(strcmp(type_name,"ProPrt")!=0)
	if ( strstr ( type_name, "Pro" ) == NULL )
	{
		if ((strcmp(type_name,"T5_DummyPartRevision")==0) || (strcmp(type_name,"Design Revision")==0) || (strcmp(type_name,"ItemRevision")==0 )) //This condn is added in TZ 1.38 to skip 'BOMView Revision' class
		{
			sDesignGroup = malloc(10 * sizeof (char *) );
			sPartType = malloc(25 * sizeof (char *) );

			if( AOM_ask_value_string(objTag,"item_id",&CheckinItemId)!=ITK_ok)PrintErrorStack();

			ITK_CALL(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGroup));
			if(tc_strcmp(sDesignGroup,"")==0)
			{
				tc_strcpy(sDesignGroup,"NULL");
			}

			// UA1.53 bypass all check-in validations for design group AM and FD

			TC_write_syslog("\n checkin_method_1--UA1.53 bypass all check-in validations for design group AM and FD..  ");

			if((tc_strcmp(sDesignGroup,"AM")==0) || tc_strcmp(sDesignGroup,"FD")==0)
			{
				TC_write_syslog("\n checkin_method_1--Design Group is AM /FD..  ");
				goto BYPASSDesGrpAMFD;
			}
			else
			{
				TC_write_syslog("\n checkin_method_1--not a design group AM / FD..  ");
			}

			//ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&sPartType));
			ITK_CALL(AOM_UIF_ask_value(objTag,"t5_PartType",&sPartType));
			if(tc_strcmp(sPartType,"")==0)
			{
				tc_strcpy(sPartType,"NULL");
			}

			//ITK_CALL( AOM_ask_owner( objTag, &owning_user ));
			//ITK_CALL( SA_ask_user_identifier(owning_user,userid) );

			if(AOM_ask_last_modifier(objTag,&owning_user)!=ITK_ok)PrintErrorStack();
			if(SA_ask_user_identifier(owning_user,userid)!=ITK_ok)PrintErrorStack();
			printf("\n checkin_method_1--last_mod_user:%s",userid);fflush(stdout);

			if(AOM_ask_value_string(objTag,"t5_ColourInd",&sPartColInd)!=ITK_ok)PrintErrorStack();
			printf("\n checkin_method_1--color indicator : %s ",sPartColInd);fflush(stdout);

			if((tc_strcmp(sPartColInd,"Y")==0))
			{
				printf("\n checkin_method_1--color indicator of part is Y ");fflush(stdout);
				if(AOM_ask_value_string(objTag,"t5_PrtCatCode",&sPrtCompCode)!=ITK_ok)PrintErrorStack();

				if(tc_strcmp(sPrtCompCode,"")==0)
				{
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"For Color Indicator 'Y', COMP CODE should not be NULL.");
					return ITK_errStore;
				}

				if(AOM_ask_value_string(objTag,"t5_PartType",&PartMType)!=ITK_ok)PrintErrorStack();
				printf("\n checkin_method_1--PartMType: [%s]",PartMType);	fflush(stdout);

				if(tc_strcmp(PartMType,"M")==0)
				{
					/*****Added - Aadarsh ****/
					int		 n_entries1= 1;
					int		 n_found1	= 0;
					char*	 Uinfo	= NULL;
					tag_t	query1	= NULLTAG;
					tag_t   *CntrlObject_Tag1			= NULLTAG;
					char    *qry_entries1[1]	=	{"SYSCD"};
					char    **qry_values1    =  (char **) MEM_alloc(10 * sizeof(char *));

					QRY_find("Control Objects...",&query1);
					if (query1!=NULLTAG)
					{
						qry_values1[0] = "Colour_ind" ;
						QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &CntrlObject_Tag1);
					}
					printf("\n checkin_method_1--Control Object Colour_Ind_count count found : %d ",n_found1);
					if(n_found1>0)
					{
						AOM_ask_value_string(CntrlObject_Tag1[0],"t5_Userinfo1",&Uinfo);

						printf("\n checkin_method_1--Control Object value= [%s] ",Uinfo);
						if (tc_strcmp(Uinfo,"Colour_ind")==0)  //till here
						{
							if(AOM_ask_value_string(objTag,"item_id",&MNumber))PrintErrorStack();
							printf("\n\t  checkin_method_1--MNumber is :%s",MNumber);fflush(stdout);

							if(AOM_ask_value_string(objTag,"item_revision_id",&MRevisionID))PrintErrorStack();
							printf("\n\t  checkin_method_1--MRevisionID is :%s",MRevisionID);fflush(stdout);

							if(PS_where_used_all(objTag,1,&n_parents,&level,&parents))PrintErrorStack();
							printf("\n\t  checkin_method_1--Module attached to Count : %d",n_parents); fflush(stdout);

							if(n_parents>0)
							{
								for (jd=0;jd<n_parents;jd++ )
								{
									flagOptionFamily=0;
									FlagFoundCol=0;
									FlagFoundSCHEME=0;

									ArchAssyTag=parents[jd];

									if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
									printf("\n\t checkin_method_1--Architecture Object is :%s",Arch_obj);	fflush(stdout);

									if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
									if(TCTYPE_ask_name(ArchobjTypeTag,Archtype_name))PrintErrorStack();
									printf("\n\t checkin_method_1--Architecture Type Name is := %s", Archtype_name);fflush(stdout);

									if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
									{
										moduleNo = NULL;
										moduleNo=(char *) MEM_alloc(50);
										tc_strcpy(moduleNo,"*");
										tc_strcat(moduleNo,Arch_obj);
										tc_strcat(moduleNo,"*");
										printf("\n\t checkin_method_1--ArchModuleRevision=> %s ",moduleNo);fflush(stdout);

										//Query Option Family from Configuration ID
										if(QRY_find("Cfg0OptionFamiliesFromIDs", &queryTag1));
										printf("\n\t checkin_method_1--After Cfg0OptionFamiliesFromIDs : QRY_find");fflush(stdout);
										if (queryTag1)
										{
											printf("\n\t checkin_method_1--Found Query");fflush(stdout);

											qry_values1[0] = moduleNo;
											if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &Optfmly_Set));
										}
										else
										{
											printf("\n\t checkin_method_1--Not Found Query ");fflush(stdout);
										}
										printf("\n\t checkin_method_1--resultCount1: [%d]", resultCount1); fflush(stdout);

										if(resultCount1 > 0)
										{
											for (Optcnt=0;Optcnt<resultCount1;Optcnt++ )
											{
												Optfmly_tag = Optfmly_Set[Optcnt];
												ifail = AOM_ask_value_string(Optfmly_tag,"object_name",&OptfmlyStr);
												printf("\n\t checkin_method_1--OptfmlyStr: [%s] ",OptfmlyStr); fflush(stdout);

												if ((tc_strcmp(OptfmlyStr,"COLOUR-BOM")==0))
												{
													FlagFoundCol=1;
												}

												if ((tc_strcmp(OptfmlyStr,"SCHEME-NO")==0))
												{
													FlagFoundSCHEME=1;
												}
											}

											printf("\n\t checkin_method_1--FlagFoundCol= [%d] and FlagFoundSCHEME= [%d] ",FlagFoundCol,FlagFoundSCHEME); fflush(stdout);
											flagOptionFamily=1;
											if (FlagFoundCol==0 || FlagFoundSCHEME==0)
											{
													EMH_clear_errors();
													EMH_store_error_s2(EMH_severity_error,ITK_errStore,"The parent architecture node of this module does not have the colour-related options mapped to it. Please take up with the Master Data Management team to get these options populated; only then the change in colour indicator will be allowed to proceed.",Arch_obj);
													return ITK_errStore;
											}
											else
											{
												printf("\n\t checkin_method_1--Going to set flag values------- "); fflush(stdout);
												flagOptionFamily=1;
											}
										}

										printf("\n\t  checkin_method_1--flagOptionFamily------->%d ",flagOptionFamily); fflush(stdout);
										if(flagOptionFamily==1)
										{
											ifail = ITEM_find_item(Arch_obj,&ReviseClrPrt);
											ifail = ITEM_ask_latest_rev(ReviseClrPrt, &ReviseClrPrtRev);
											ifail = BOM_create_window (&window1);
											ifail = CFM_find("Latest Working", &ruleM);
											ifail = BOM_set_window_config_rule(window1, ruleM);
											ifail = BOM_set_window_pack_all(window1, true);
											ifail = BOM_set_window_top_line(window1, NULLTAG, ReviseClrPrtRev, NULLTAG, &top_lineM);
											if(top_lineM!=NULLTAG)
											{
												ifail = BOM_line_ask_child_lines(top_lineM, &n_count, &Nlines);
												printf("\n checkin_method_1--n_lines-----> %d ",n_count);

												if (n_count >0)
												{
													for (p1=0;p1<n_count ;p1++ )
													{
														if(Childobject1) Childobject1=NULLTAG;
														Childobject1=Nlines[p1];
														ifail = AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id );
														printf("\n checkin_method_1--child_item_id & Levels ==> %s=%s",child_item_id,MNumber);
														if(tc_strcmp(child_item_id,MNumber)==0)
														{
															Item_ID_str=NULL;
															ifail = BOM_line_look_up_attribute ("bl_formula",&Revformula);
															ifail = BOM_line_ask_attribute_string(Childobject1, Revformula, &Item_ID_str);
															printf("\n checkin_method_1--V_formula of Module=> %s ",Item_ID_str);fflush(stdout);
															if(Item_ID_str!=NULL)
															{
																if((tc_strstr(Item_ID_str,"COLOUR-BOM")!= NULL) && (tc_strstr(Item_ID_str,"SCHEME-NO")!= NULL))
																{
																	//if((tc_strstr(Item_ID_str,"[Teamcenter]COLOUR-BOM = N")!= NULL) && (tc_strstr(Item_ID_str,"[Teamcenter]COLOUR-BOM = Y")!= NULL))
																	if(tc_strstr(Item_ID_str,"[Teamcenter]COLOUR-BOM = N")!= NULL)
																	{
																		printf("\n checkin_method_1--Option Values [Teamcenter]COLOUR-BOM = N are Present in Variant Formula----------------"); fflush(stdout);
																	}
																	else
																	{
																		printf("\n checkin_method_1--Else-error-1-Colour-related Option Values [COLOUR-BOM = N] & [SCHEME-NO = NA] are mandatorily in Variant Formula  "); fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s2(EMH_severity_error,ITK_errStore,"Colour-related Option Values [COLOUR-BOM = N] & [SCHEME-NO = NA] are mandatorily in Variant Formula",MNumber);
																		return ITK_errStore;
																	}
																}
																else
																{
																	printf("\n checkin_method_1--Else-error-2-All applicable option values should be mandartory. Please apply verient formula then proceed to allow for check in activity. "); fflush(stdout);
																	EMH_clear_errors();
																	EMH_store_error_s2(EMH_severity_error,ITK_errStore,"All applicable option values should be mandartory.","Please apply verient formula then proceed to allow for check in activity.");
																	return ITK_errStore;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			printf("\n checkin_method_1--TCDCDesign Group not for PROE: %s Part Type: %s Owner:%s \t",sDesignGroup,sPartType,userid);fflush(stdout);
			// Start Check if this is Trilix Site and bypass for TCDC check as per mail by Mark.
			TC_write_syslog("\n checkin_method_1--Inside Preaction_on_checkin:checkin_method_1:calling IsThisTrilixSite function \t");
			IsValidSite = IsThisTrilixSite(objTag);
			TC_write_syslog("\n checkin_method_1--To bypass QCDC checks, IsValidSite: [%d]\t",IsValidSite);

			if(IsValidSite==1)
			{
				TC_write_syslog("\n checkin_method_1--bypass QCDC checks, for trilix Site: [%d]\t",IsValidSite);
				goto BYPASSTRILIXSITE;
			}
			else
			{
				TC_write_syslog("\n bypass QCDC checks, for trilix Site: [%d]\t",IsValidSite);
				printf("\n checkin_method_1--bypass QCDC checks, for trilix Site: [%d]\t",IsValidSite);fflush(stdout);
			}

			// End Check if this is Trilix site and bypass for TCDC check as per mail by Mark.


			// Added by Aashish_w Start

			char *sValOutput=NULL;
			int IsValidProjNType =0;

			printf("\n checkin_method_1--Calling Function t5_partcategory $Welcome$ to Check-In operation ****************  ");
			//Neha

			char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
			char *ctrlQryValues[2] = {"ChekInValWCQ", "ChekInValWCQ1"};
			tag_t TagCtrlQryContObj = NULLTAG,*ctrlCntrObjects = NULL;
			int nEntries = 2;
			int nFound = 0;

			if(QRY_find2("ControlObjQry", &TagCtrlQryContObj));

			if(QRY_execute(TagCtrlQryContObj, nEntries, ctrlQryEntries, ctrlQryValues, &nFound, &ctrlCntrObjects));
			printf("\n checkin_method_1--Objects for Query ControlObjQry from checkin validationnnn : %d", nFound);fflush(stdout);

			if(nFound>0)
			{
				printf("\n checkin_method_1--CRRRR1 ");fflush(stdout);
				int retVal = checkin_validation(objTag);
				printf("\n checkin_method_1--Return value : %d ",retVal);fflush(stdout);

				if (retVal == 1)
				{
					printf("\n checkin_method_1--Return value function : 1 ");fflush(stdout);
				}
				else if(retVal == 2)
				{
					printf("\n checkin_method_1--Return value function : 2 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Envelop dimension cannot be NULL");
					return ITK_errStore;
				}
				else if(retVal == 3)
				{
					printf("\n checkin_method_1--Return value function : 3 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight cannot be NULL");
					return ITK_errStore;
				}
				else if(retVal == 4)
				{
					printf("\n checkin_method_1--Return value function : 4 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Class cannot be NULL");
					return ITK_errStore;
				}
				else if(retVal == 5)
				{
					printf("\n checkin_method_1--Return value function : 5 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"UOM cannot be NULL");
					return ITK_errStore;
				}
				else if(retVal == 6)
				{
					printf("\n checkin_method_1--Return value function : 6 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Envelop dimension value is not in proper format of axbxc");
					return ITK_errStore;
				}
				else if(retVal == 7)
				{
					printf("\n checkin_method_1--Return value function : 7 ");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight value has too many digits after decimal");
					return ITK_errStore;
				}
			}
			else
			{
				printf("\n checkin_method_1--Inside else part of control object  ");fflush(stdout);
			}
			//End

			IsValidProjNType = t5_partcategory(objTag,&sValOutput);		//added by Aashish_w...

			if(IsValidProjNType==1)
			{
				printf("\n checkin_method_1--Part category is invalid...  ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput);
				return ITK_err;
			}
			else
			{
				printf("\n checkin_method_1--Part Category is Valid... Please proceed.  ");fflush(stdout);
			}

			printf("\n checkin_method_1--END of Function t5_partcategory to Check-In operation ****************  ");
			// Added by Aashish_w End

			// Added by Aashish_w Start
			char *sValOutput1=NULL;
			int IsValidProjNType1 =0;

			printf("\n checkin_method_1--Calling Function GroupIDCheck Welcome to Check-In operation ****************  ");

			IsValidProjNType1 = GroupIDCheck(objTag,&sValOutput1);		//added by Aashish_w...

			if(IsValidProjNType1==1)
			{
				printf("\n checkin_method_1--GroupIDCheck Fail....  ");fflush(stdout);
				EMH_clear_errors();
				EMH_store_error_s1(EMH_severity_error,ITK_err, sValOutput1);
				return ITK_err;
			}
			else
			{
				printf("\n checkin_method_1--GroupIDCheck is Valid... Please proceed.  ");fflush(stdout);
			}

			printf("\n checkin_method_1--END of Function GroupIDCheck to Check-In operation ****************  ");

			// Added by Aashish_w End

			if(strcmp(type_name,"T5_DummyPartRevision")==0)
			{
			if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();

			PatSeq = malloc(3);
			sprintf(PatSeq,"%d",sequence_id_c);

			if (WSOM_describe(objTag, &desc) !=ITK_ok)   PrintErrorStack();

			printf("\n checkin_method_1--a.TCDCItem_id: %s", Item_id);fflush(stdout);
			printf("\n checkin_method_1--a.TCDCObject Typee: %s", desc.object_type);fflush(stdout);
			printf("\n checkin_method_1--a.TCDCRevision IDD: %s", desc.revision_id);fflush(stdout);
			printf("\n checkin_method_1--a.TCDCSequence IDD(PatSeq): %s", PatSeq);fflush(stdout);

			tc_strcat(AttributeNullList,Item_id);
			tc_strcat(AttributeNullList,"/");
			tc_strcat(AttributeNullList,desc.revision_id);
			printf("\n  checkin_method_1--AttributeNullList : %s",AttributeNullList);

			ITK_CALL(AOM_UIF_ask_value(objTag,"item_revision_id",&cRevSeq));
			printf("\n  checkin_method_1--TCDCAOM_UIF_ask_value cRevSeq: [%s]", cRevSeq);fflush(stdout);

			//tc_strcpy ( cDescRevision, desc.revision_id );
			//printf("\ncDescRevision:%s",cDescRevision);
			//newPatRev = strtok ( cDescRevision, ";" );
			newPatRev = strtok ( cRevSeq, ";" );
			newPatSeq = strtok ( NULL, ";" );

			printf("\n checkin_method_1--newPatRev1: [%s]  newPatSeq1: [%s]",newPatRev,newPatSeq);fflush(stdout);

			ProAsmCN=0;
			primarydProAsmDS=NULLTAG;

			if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
			printf("\n checkin_method_1--TCDCNo of DI :%d",n_attchs);fflush(stdout);
			if(n_attchs>0)
			{
				for (i = 0; i < n_attchs; i++)
				{
					primary=secondary_objects[i];
					if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
					if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
					printf("\n checkin_method_1-c.i=[%d]-TCDCtype_name2: [%s] ",i,type_name2);fflush(stdout);
					if(tc_strcmp(type_name2,"CMI2Drawing")==0 || tc_strcmp(type_name2,"ProDrw")==0)
					{
						counter++;

						//Rajendra
						if( AOM_UIF_ask_value(primary,"object_name",&drawingnum)==ITK_ok)PrintErrorStack();
						printf("\n checkin_method_1--drawingnum: [%s]",drawingnum);fflush(stdout);

						if(tc_strcmp(type_name2,"CMI2Drawing")==0)
						{
							CmiDrwCnt++;
						}
					}
					else if((tc_strcmp(type_name2,"PDF")==0) && (counter==0)) //Aadarsh
					{
						counterPDF++;
						
						//Rajendra
						if( AOM_UIF_ask_value(primary,"object_name",&drawingnum)==ITK_ok)PrintErrorStack();
						printf("\n checkin_method_1--drawingnum: [%s]",drawingnum);fflush(stdout);
					}
					if(tc_strcmp(type_name2,"CMI2Part")==0 )
					{
						CatPrtCN++;
					}
					/*
					as per below mail request part type check is commented.. Now onward QCDC is on for all part type for cadtype CMI2Product
					trilix team was facing issue for checkin dummy part part and jt is not getting created
					due to part type check it is considering only catproduct and assembly for qcdc and cmi2part and cmi2drw for all part type
					mail subject:PLM error (check-out)
					mail date: 05-mar-2018

					if(tc_strcmp(type_name2,"CMI2Product")==0 && tc_strcmp(sPartType,"Assembly")==0 )	*/
					if(tc_strcmp(type_name2,"CMI2Product")==0)
					{
						CatPrdt++;
					}
					if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0))
					{
						ProPrtCN++;

						if (tc_strcmp(type_name2,"ProAsm")==0)	//Added in TZ 1.38
						{
						   ProAsmCN++;
						   primarydProAsmDS=secondary_objects[i];
						}
					}
				}
			}
			//CatPrtCN++;
			printf("\n checkin_method_1--TCDCcounter :%d ",counter);fflush(stdout);
			printf("\n checkin_method_1--TCDCCatPrtCN :%d ",CatPrtCN);fflush(stdout);
			printf("\n checkin_method_1--counterPDF:%d ",counterPDF);fflush(stdout);
			printf("\n checkin_method_1--TCDCCatPrdt :%d ",CatPrdt);fflush(stdout);
			printf("\n checkin_method_1--TCDCProPrtCN :%d ",ProPrtCN);fflush(stdout);
			printf("\n checkin_method_1--TCDCCmiDrwCnt :%d ",CmiDrwCnt);fflush(stdout);
			printf("\n checkin_method_1--drawingnum:%s ",drawingnum);fflush(stdout);
			printf("\n checkin_method_1--TCDCProAsmCN:::: %d ",ProAsmCN);fflush(stdout);
			}


			if(strcmp(type_name,"Design Revision")==0 ||strcmp(type_name,"ItemRevision")==0)
			{
				//ByPassing Mandetory Attribute Check Validations for APC Group Project Code 2956 and ST Design Group
				if(AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok) PrintErrorStack();
				if(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&desgrp)==ITK_ok) PrintErrorStack();

				if(strcmp(projcode,"")!=0 || strcmp(desgrp,"")!=0)
				{
					printf("\n checkin_method_1--Revision Project Code [%s] Design Group :[%s] checking in Bypass-controlObj...",projcode,desgrp);fflush(stdout);

					if(QRY_find2("ControlObjQry", &TagQryContObjSite));
					if(TagQryContObjSite)
					{
						if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_BypVal, &ByPasQCount, &BypCnObj));
						printf("\n checkin_method_1--Objects for Query VALDBYPASS == %d", ByPasQCount);fflush(stdout);
					}
					else
					{
						printf("\n checkin_method_1--ContrlObj not found for SYSCD=VALDBYPASS");fflush(stdout);
					}

					if(ByPasQCount >0)
					{
						if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
						if (AOM_ask_value_string(BypCnObj[0],"t5_Userinfo2",&info2)!=ITK_ok) PrintErrorStack();//Project Code

						printf("\n checkin_method_1--Bypass Project Codes List [%s]",info2); fflush(stdout);
						printf("\n checkin_method_1--Bypass Design  Group List [%s]",info1); fflush(stdout);

						if(tc_strstr(info2,projcode)!=NULL || tc_strstr(info1,desgrp)!=NULL)
						{
							CheckBypasFlag=1;	//If found in Control Object check-in validations will be bypassed
						}
					}
				}

				printf("\n checkin_method_1--CheckBypasFlag= [%d]",CheckBypasFlag); fflush(stdout);
				if(CheckBypasFlag==0)
				{
					if( AOM_ask_value_int(objTag,"sequence_id",&sequence_id_c)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();

					PatSeq=malloc(3);
					sprintf(PatSeq,"%d",sequence_id_c);

					if (WSOM_describe(objTag, &desc) !=ITK_ok)   PrintErrorStack();
					printf("\n checkin_method_1--b.TCDCItem_id: %s ", Item_id);fflush(stdout);
					printf("\n checkin_method_1--b.TCDCObject Type: %s ", desc.object_type);fflush(stdout);
					printf("\n checkin_method_1--b.TCDCRevision ID: %s ", desc.revision_id);fflush(stdout);
					printf("\n checkin_method_1--b.TCDCSequence ID(PatSeq): %s ", PatSeq);fflush(stdout);

					tc_strcat(AttributeNullList,Item_id);
					tc_strcat(AttributeNullList,"/");
					tc_strcat(AttributeNullList,desc.revision_id);
					printf("\n checkin_method_1--b.AttributeNullList : %s",AttributeNullList);

					ITK_CALL(AOM_UIF_ask_value(objTag,"item_revision_id",&cRevSeq));
					printf("\n checkin_method_1--b.TCDCAOM_UIF_ask_value cRevSeq: %s ", cRevSeq);fflush(stdout);

					//tc_strcpy ( cDescRevision, desc.revision_id );
					//printf("\ncDescRevision:%s",cDescRevision);
					//newPatRev = strtok ( cDescRevision, ";" );
					newPatRev = strtok ( cRevSeq, ";" );
					newPatSeq = strtok ( NULL, ";" );

					printf("\n checkin_method_1--b.TCDCnewPatRev3: %s TCDCnewPatSeq3: %s ", newPatRev, newPatSeq);fflush(stdout);

					//if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok)PrintErrorStack();
					if( AOM_UIF_ask_value(objTag,"t5_PartType",&parttyp)==ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--b.TCDCt5_PartType: %s ", parttyp);fflush(stdout);

					/************************Adi weldigo begins 1.36********************************/
					if( AOM_ask_value_string(objTag,"item_id",&Item_idDC)!=ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--b.Item_idDC ----------: %s ",Item_idDC);fflush(stdout);

					if(tc_strstr(Item_idDC,"_WE") != NULL)
					{
						printf("\n checkin_method_1--b.WELDIGO PART ");fflush(stdout);

						if(tc_strcmp(parttyp,"Dummy Component")==0)
						{
							printf("\n checkin_method_1--b.Part type is Dummy Component so continue   ");fflush(stdout);
						}
						else
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"For _WE parts , the part type can be Dummy Component only.");
							return ITK_errStore;
						}
					}
					else
					{
						printf("\n checkin_method_1--b.Not a weldigo part so continue   ");fflush(stdout);
					}
					/************************Adi weldigo ends 1.36********************************/

					/*********************************************************************************/

					//added by Hanuman
					if(AOM_ask_value_string(objTag,"object_string",&bl_objectString));
					printf("\n checkin_method_1--b.object_string => %s ",bl_objectString);fflush(stdout);

					if(ITEM_rev_list_bom_view_revs(objTag,&BomViewCnt,&BomViewList)!=ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--b.Count of BomView [%d] ",BomViewCnt);fflush(stdout);

					if(BomViewCnt>0)
					{
						printf("\n checkin_method_1--b.BVR found");fflush(stdout);
						if(AOM_ask_value_string(BomViewList[0],"object_name",&view_name));
						printf("\n checkin_method_1--b.view_name %s",view_name);fflush(stdout);

						partTok = strtok (view_name,"-");
						viewTok = strtok (NULL,"-");
						printf("\n checkin_method_1--b.viewTok: %s View: %s",viewTok,View);fflush(stdout);

						//if(tc_strcmp(viewTok,"APLC View")==0) View //MBOM implementation for CV TZ-1.69
						if(tc_strcmp(viewTok,View)==0)
						{
							flagBVR=1;
						}
						else
						{
							flagBVR=0;
						}
					}

					printf("\n checkin_method_1--b.flagBVR :: %d",flagBVR);fflush(stdout);
					if(flagBVR!=1)
					{
						/*Getting ChildParts through BOM LINE*/
						if(BOM_create_window (&t_Window) !=ITK_ok) PrintErrorStack();
						if(CFM_find( "Latest Working", &t_RRule )!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_config_rule( t_Window, t_RRule )!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_pack_all (t_Window, true)!=ITK_ok) PrintErrorStack();
						if(BOM_set_window_top_line (t_Window, ItemTag, objTag, null_tag, &t_TLine)!=ITK_ok) PrintErrorStack();
						if(BOM_line_ask_child_lines (t_TLine, &ChildCount, &t_PrtChldren)!=ITK_ok) PrintErrorStack();
						printf("\n checkin_method_1--b.[TZ 1.30]=> Child Parts Found in BomLine are :: [%d]",ChildCount);fflush(stdout);

						if((ChildCount > 0) && (tc_strcmp(parttyp,"Component")==0))
						{
							for (iChldPrts = 0; iChldPrts < ChildCount; iChldPrts++)
							{
							if(t_Childobject) t_Childobject=NULLTAG;
							t_Childobject=t_PrtChldren[iChldPrts];
							if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok)PrintErrorStack();
							if (TCTYPE_ask_name(t_ChildObjType,ca_ChildType_Name)!=ITK_ok)PrintErrorStack();
							printf("\n checkin_method_1--b.BOMline first level count :: [%d] ChildType is [%s] ",iChldPrts+1,ca_ChildType_Name);fflush(stdout);

							if(BOM_line_look_up_attribute ("bl_Design_t5_RevPartType",&iItemType));
							if(BOM_line_ask_attribute_string(t_Childobject, iItemType, &cp_ItemType_str));
							printf("\n checkin_method_1--b.BOMline part type [%d] Child ItemType is [%s] ",iChldPrts+1,cp_ItemType_str);

							if(tc_strcmp(cp_ItemType_str,"Dummy")!=0)
							{
								Rolflag1=1;
							}else
							{
								printf("\n checkin_method_1--b.All Child parts in BOMline are DUMMY... ");
							}
							}

							if(Rolflag1==1)
							{
								printf("\n checkin_method_1--b.Select revision having BVR");fflush(stdout);
								if(EMH_store_error_s3(EMH_severity_error,ITK_errStore,"\nNON-DUMMY parts in BOM are not allowed for parts having part type:Component.","",bl_objectString)!=ITK_ok)PrintErrorStack();
								return ITK_errStore;
							}
						}
						else
						{
							printf("\n checkin_method_1--b.Select revision is nither Cmponent nor having BVR");fflush(stdout);
						}
					}

					if(ChildCount > 0)
					{
						tc_strcpy(ChildCpy,"");
						//Ashwini ---> For obsolete Part at the time of check-in....
						//printf("\nAshwini ........ChildCount = %d ",ChildCount);fflush(stdout);
						printf("\n checkin_method_1--b.START Obsolete part checking Parent Project Code --  = %s ",projcode);fflush(stdout);

						if(QRY_find("General...", &queryTagObs));
						if (queryTagObs)
						{
						printf("\nGeneral... Found Query ControlObjects ");fflush(stdout);
						}
						else
						{
						printf("\n checkin_method_1--b.General...:Not Found Query ControlObjects  ");fflush(stdout);
						}
						qry_valuesObs[0] = projcode ;
						qry_valuesObs[1] = "Project" ;

						if(QRY_execute(queryTagObs,n_entriesObs,qry_entriesObs,qry_valuesObs,&resultCountObs,&NewPartsSetObs));
						printf("\n11 Unique General... Query resultCount :%d: ", resultCountObs); fflush(stdout);

						if (resultCountObs > 0)
						{
						PrjCdObj = NewPartsSetObs[0];
						if(AOM_ask_value_string(PrjCdObj,"t5_BussUnitType",&ProjectCodeValS) != ITK_ok);
						printf("\nBussiness unit of %s project code is %s ",projcode,ProjectCodeValS);fflush(stdout);
						}

						ChildCpyAltS=(char *) MEM_alloc(650);
						CPartQryLst=(char *) MEM_alloc(650);
						ChildOSPRENTS=(char *) MEM_alloc(950);

						printf("\nProject PCBU Obsolete Check-in.. ");fflush(stdout);
						tc_strcpy(ChildCpyAltS,"");
						strcat(ChildCpyAltS,"The following child part(s) under the checked IN assembly/module are hexavalent Cr-coated. You are advised to REPLACE them as indicated below ");

						tc_strcpy(CPartQryLst,"");
						strcat(CPartQryLst,"The following child part(s) under the checked IN assembly/module are hexavalent Cr-coated. You are advised to DELETE THEIR RELATIONSHIP before proceeding ");

						tc_strcpy(ChildOSPRENTS,"");
						strcat(ChildOSPRENTS,"Check-in unsuccessful:The assembly contains the following 11-digit fasteners, which are outside the list of fasteners to be used for Osprey project to refer the pre-defined list of fasteners for Osprey project, go to 'Query--->QueryObsPart_OSPREY---> Alt Part Ind = OSPREY and Obsolte Part =ChildPart Number'. Object in TCUA using general Query For any requirement beyond this list, a DCR needs to be raised. " );

						for (iChPrts = 0; iChPrts < ChildCount; iChPrts++)
						{
							if(t_Childobject) t_Childobject=NULLTAG;
							t_Childobject=t_PrtChldren[iChPrts];

							if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok)PrintErrorStack();
							if (TCTYPE_ask_name(t_ChildObjType,ca_ChildType_Name)!=ITK_ok)PrintErrorStack();
							printf("\n checkin_method_1--b.[TZ 1.39]=> ca_ChildType_Name :: [%s] ",ca_ChildType_Name);fflush(stdout);

							if(BOM_line_look_up_attribute ("bl_quantity",&QtyValue));
							if(BOM_line_ask_attribute_string(t_Childobject, QtyValue, &QtyOccur_str));
							printf("\n checkin_method_1--b.QtyOccur_str is----------------------------------> [%s] ",QtyOccur_str);

							//neha -- color Ind

							char *ctrlQryEntries[2] = {"SYSCD", "SUBSYSCD"};
							char *ctrlQryValues[2] = {"ColIndVal", "ColIndVal1"};
							tag_t TagCtrlQryObj = NULLTAG, *ctrlCntrObj = NULLTAG;
							int nEntr = 2;
							int nFnd = 0;


							if(QRY_find2("ControlObjQry", &TagCtrlQryObj));
							if (TagCtrlQryObj != NULLTAG)
							{
								if(QRY_execute(TagCtrlQryContObj, nEntr, ctrlQryEntries, ctrlQryValues, &nFnd, &ctrlCntrObj));
							}
							printf("\n checkin_method_1--b.Objects for Query ControlObjQry from checkin validation : %d", nFnd);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(objTag,"t5_ColourInd",&ColInd_str));
							printf("\n checkin_method_1--b.Color Indicator is----------------------------------> [%s] ",ColInd_str);


							if(BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
							if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
							printf("\n checkin_method_1--b.cp_ItemIDD_str is----------------------------------> [%s] ",cp_ItemID_str);


							ITK_CALL(ITEM_find_item(cp_ItemID_str,&UseMaster));

							if (UseMaster != NULLTAG)
							{
								printf("\n checkin_method_1--b.UseMaster found------>cp_ItemID_str: [%s]",cp_ItemID_str);
								ITK_CALL(ITEM_ask_latest_rev(UseMaster, &Nrev));
							}

							if(nFnd>0)
							{
								if(Nrev != NULLTAG)
								{
									if(AOM_UIF_ask_value(Nrev,"t5_ColourInd",&colInd)==ITK_ok)
									{
										printf("\n checkin_method_1--b.Inside Colour Ind : %s  ",colInd);fflush(stdout);
										if( tc_strcmp(ColInd_str,"N")==0 && tc_strcmp(colInd,"Y")==0)
										{
											ColIndYPrt=(char *)MEM_alloc(200);
											tc_strcpy(ColIndYPrt,"");
											tc_strcat(ColIndYPrt,cp_ItemID_str);

											EMH_clear_errors();
											EMH_store_error_s3(EMH_severity_error,ITK_Prjerr, "The child part : ",ColIndYPrt, " with colour indicator Y, cannot go below assembly with colour ind N. This is invalid combination of colour ind.");

											return ITK_errStore;
											printf("\nOne of the child part color indicator is Y ");fflush(stdout);

										}
									}
								}
								else
								{
									printf("\n checkin_method_1--b.Nrev tag not found...cp_ItemID_str: [%s] ",cp_ItemID_str);
								}
							}
							//end

							if(BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
							if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
							printf("\n checkin_method_1--b.cp_ItemID_str is----------------------------------> [%s] ",cp_ItemID_str);

							if(tc_strcmp(QtyOccur_str,"")==0)
							{
								tc_strcat(ChildCpy,cp_ItemID_str);
								tc_strcat(ChildCpy,",");
								printf("\n checkin_method_1--b.ChildCpy is----------------------------------> [%s] ",ChildCpy);
								Qtyflag1=1;
							}

							if(tc_strcmp(ProjectCodeValS,"PCBU") == 0)
							{
								if(BOM_line_look_up_attribute ("bl_Design Revision_t5_ProjectCode",&CPCdeI))PrintErrorStack();
								//if(BOM_line_look_up_attribute ("bl_T5_ClrPartRevision_t5_ProjectCode",&CPCdeI))PrintErrorStack();
								if(BOM_line_ask_attribute_string (t_Childobject, CPCdeI, &CprojcodeS))PrintErrorStack();

								//if(BOM_line_look_up_attribute ("bl_T5_ClrPartRevision_t5_DesignGrp",&CDsgnI))PrintErrorStack();
								if(BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&CDsgnI))PrintErrorStack();
								if(BOM_line_ask_attribute_string (t_Childobject, CDsgnI, &CDsgnGrpS))PrintErrorStack();

								CStrtngWth1=subString(cp_ItemID_str,0,1);
								Cpartlength = tc_strlen(cp_ItemID_str);
								printf("\n checkin_method_1--b.CprojcodeS is---> [%s] and CDsgnGrpS is---> [%s] Child Name Lenght=%d & Starts with =%s ",CprojcodeS,CDsgnGrpS,Cpartlength,CStrtngWth1);

								if(Cpartlength == 11 && tc_strcmp(CDsgnGrpS,"11")==0 && tc_strcmp(CprojcodeS,"1111")==0 && tc_strcmp(CStrtngWth1,"1")==0)
								//if(Cpartlength == 12 && tc_strcmp(CDsgnGrpS,"54")==0 && tc_strcmp(CprojcodeS,"5442")==0 && tc_strcmp(CStrtngWth1,"5")==0)
								{
									if(QRY_find2("ControlObjQry", &TagControlObs14));
									if(QRY_execute(TagControlObs14, n_entriesObs14, qry_entriesObs14, qry_valuesObs14, &n_foundObs14, &cntr_objectsObs14));
									printf("\nObsolete_PrjCde_allow Obsolete Project code Control Object == %d ", n_foundObs14);fflush(stdout);

									if(n_foundObs14==1)
									{
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo1",&info1)!=ITK_ok) PrintErrorStack();	//Design Group
										printf("\n checkin_method_1--b.Bypass Design  Group List [%s] and project code = %s",info1,projcode); fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info2 is.:[%s] and Project code = %s ", info2,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info3 is.:[%s] and project code = %s ", info3,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info4 is.:[%s] and Project code = %s ", info4,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo5",&info5)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info5 is.:[%s] and project code = %s ", info5,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo6",&info6)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info6 is.:[%s] and project code = %s ", info6,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo7",&info7)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info7 is.:[%s] and project code = %s ", info7,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo8",&info8)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info8 is.:[%s] and project code = %s ", info8,projcode);fflush(stdout);
										if (AOM_ask_value_string(cntr_objectsObs14[0],"t5_Userinfo9",&info9)!=ITK_ok)   PrintErrorStack();
										printf("\n checkin_method_1--b.info9 is.:[%s] and project code = %s ", info9,projcode);fflush(stdout);

										if((tc_strstr(info1,projcode)!=NULL) || (tc_strstr(info2,projcode)!=NULL) || (tc_strstr(info3,projcode)!=NULL) || (tc_strstr(info4,projcode)!=NULL) || (tc_strstr(info5,projcode)!=NULL) || (tc_strstr(info6,projcode)!=NULL) || (tc_strstr(info7,projcode)!=NULL) || (tc_strstr(info8,projcode)!=NULL) || (tc_strstr(info9,projcode)!=NULL))
										{
											printf("\n Extension of Fasteners related check for Nexon to TcUA - %s project CHCK-IN..... ",projcode);
											printf("\n checkin_method_1--b.CprojcodeS is---> [%s] and CDsgnGrpS is---> [%s] Child Name Lenght=%d & Starts with =%s ",CprojcodeS,CDsgnGrpS,Cpartlength,CStrtngWth1);
											AlternatePrtS=QueryObsPart_OSPREY(cp_ItemID_str); //OSPREY QueryObsPart_OSPREY OSPREYNTPresnt
											if(strcmp(AlternatePrtS,"OSPREYPresnt") == 0)
											{
												printf("\n checkin_method_1--b.OSPREY present in table allow Uses parts Creation.. ");fflush(stdout);
											}
											else
											{
												if(strcmp(AlternatePrtS,"OSPREYNTPresnt") == 0)
												{
													OspryCount = OspryCount+1;
													printf("\n checkin_method_1--b.a.[%d]..[%s] have Alternate Part QryNotFound: %s  ",OspryCount,cp_ItemID_str,AlternatePrtS);
													strcat(ChildOSPRENTS,cp_ItemID_str );
													strcat(ChildOSPRENTS,",");
												}
											}
										}
									}
									//else
									//{
									//if(Cpartlength == 12 && tc_strcmp(CDsgnGrpS,"42")==0 && tc_strcmp(CprojcodeS,"5442")==0)
									//if(Cpartlength >= 12  && tc_strcmp(CprojcodeS,"5442")==0)
									printf("\n checkin_method_1--b.Part is OBSOLETE Check AlterNate Part present or not. .. ");fflush(stdout);
									AlternatePrtS=QueryObsPart(cp_ItemID_str);
									printf("\n checkin_method_1--b.AlternatePrtS = %s ",AlternatePrtS);fflush(stdout);
									if(strcmp(AlternatePrtS,"PrtDelete")==0)
									{
										QryFound = QryFound+1;
										printf("\n checkin_method_1--b.%s have Alternate Part PrtDelete %s  ",cp_ItemID_str,AlternatePrtS);
										strcat(CPartQryLst,cp_ItemID_str);
										strcat(CPartQryLst,"," );
									}
									if(strcmp(AlternatePrtS,"PrtDelete") != 0)
									{
										if(strcmp(AlternatePrtS,"QryNotFound")!=0 && (tc_strlen(AlternatePrtS)!=0))
										{
											altCount = altCount+1;
											printf("\n checkin_method_1--b.b.[%d]..[%s] have Alternate Part QryNotFound%s ",altCount,cp_ItemID_str,AlternatePrtS);
											strcat(ChildCpyAltS,cp_ItemID_str );
											strcat(ChildCpyAltS,"--->" );
											strcat(ChildCpyAltS,AlternatePrtS);
											strcat(ChildCpyAltS,",");
										}
									}
								}
								else
								{
									printf("\n checkin_method_1--b.Part is Not Standard no need to check Obsolete/Alternate Part... ");fflush(stdout);
								}
								//}
							}
						}

						if(Qtyflag1==1)
						{
							printf("\n checkin_method_1--b.Select revision having BVR");fflush(stdout);
							if(EMH_store_error_s3(EMH_severity_error,ITK_errStore,ChildCpy,"\nChild part is having blank quantity","\nPls send assembly to structure manager and modify quantity and save and check-in")!=ITK_ok)PrintErrorStack();
							return ITK_errStore;
						}
						printf("\n checkin_method_1--b.altCount = %d and ChildCpyAltS = %s ",altCount,ChildCpyAltS);fflush(stdout);
						if (altCount > 0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,ChildCpyAltS);
							return ITK_err;
						}

						printf("\n checkin_method_1--b.QryFound = %d and CPartQryLst = %s ",QryFound,CPartQryLst);fflush(stdout);
						if(QryFound > 0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,CPartQryLst);
							return ITK_err;
						}
						printf("\n checkin_method_1--b.OspryCount = %d and ChildOSPRENTS = %s ",OspryCount,ChildOSPRENTS);fflush(stdout);
						if (OspryCount > 0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_err,ChildOSPRENTS);
							return ITK_err;
						}
					}
					printf("\n checkin_method_1--b.END Select revision is nither Cmponent nor having BVR");fflush(stdout);

					//ECU Module Check in Qty Validation Start
					if(strcmp(type_name,"Design Revision")==0)
					{
						if(ChildCount > 0)
						{
							char *Modparttyp=NULL;
							AOM_ask_value_string(objTag,"t5_PartType",&Modparttyp);
							printf("\n checkin_method_1--b.item_revision_id Modparttyp:     %s ", Modparttyp);fflush(stdout);

							if(strcmp(parttyp,"EM")==0 || strcmp(parttyp,"ECU Module")==0 )
							{
								tag_t   CntobjModCheckin		=	NULLTAG;

								char *qry_ModAdd_entry[3] = {"SYSCD","SUBSYSCD","Information-1"};
								char **qry_ModAdd_values = (char **) MEM_alloc(10 * sizeof(char *));

								int MOd_entry =	3;
								int ModChInCntlObj =	0;
								int QtyflagECUModCheckIn=0;

								tag_t *ModCheckInCntObj_Tag =	NULLTAG;

								char *ModPartName = NULL;
								char *prtModAdd = NULL;
								char *ECUChildCpy = NULL;

								ECUChildCpy = malloc(10000 * sizeof(char *));

								AOM_ask_value_string(objTag,"item_id",&ModPartName);
								printf("\n checkin_method_1--b.item_revision_id ModPartName: [%s]", ModPartName);fflush(stdout);

								AOM_ask_value_string(objTag,"t5_ModuleAddress",&prtModAdd);
								printf("\n checkin_method_1--b.prtModAdd : [%s]", prtModAdd);fflush(stdout);

								if(QRY_find("Control Objects...", &CntobjModCheckin));
								if (CntobjModCheckin)
								{
									printf("\n checkin_method_1--b.Found Query ControlObjects for Module Check-In  ");fflush(stdout);

									qry_ModAdd_values[0] = "SubModAddForCheckIn";
									qry_ModAdd_values[1] = "SubModAddForCheckIn";
									qry_ModAdd_values[2] =	 prtModAdd;

									if(QRY_execute(CntobjModCheckin, MOd_entry, qry_ModAdd_entry, qry_ModAdd_values, &ModChInCntlObj, &ModCheckInCntObj_Tag));
								}
								else
								{
									printf("\n checkin_method_1--b.Not Found Query ControlObjects for Module Check-In  ");fflush(stdout);
								}

								printf("\n checkin_method_1--b.Mod Checkin:ModChInCntlObj:[%d]",ModChInCntlObj); fflush(stdout);

								if(ModChInCntlObj>0)
								{
									QtyflagECUModCheckIn=0;
									tc_strcpy(ECUChildCpy,"");

									int ECUChInPrts=0;
									char	*ECUQtyOccur_str	= NULL;
									char *ECUcp_ItemID_str=NULL;
									char ECUM_ChildType_Name[TCTYPE_name_size_c+1];
									tag_t ECUt_ChildObjType=NULLTAG;
									int ECUQtyValue=0;
									int ECUiItemId=0;

									for (ECUChInPrts = 0; ECUChInPrts < ChildCount; ECUChInPrts++)
									{
										if(t_Childobject) t_Childobject=NULLTAG;
										t_Childobject=t_PrtChldren[ECUChInPrts];

										if (TCTYPE_ask_object_type(t_Childobject,&ECUt_ChildObjType)!=ITK_ok)PrintErrorStack();
										if (TCTYPE_ask_name(ECUt_ChildObjType,ECUM_ChildType_Name)!=ITK_ok)PrintErrorStack();
										printf("\n checkin_method_1--b.[TZ 1.39]=> ECUM_ChildType_Name :: [%s] ",ECUM_ChildType_Name);fflush(stdout);

										if(BOM_line_look_up_attribute ("bl_quantity",&ECUQtyValue));
										if(BOM_line_ask_attribute_string(t_Childobject, ECUQtyValue, &ECUQtyOccur_str));
										printf("\n checkin_method_1--b.ECUQtyOccur_str is111----------------------------------> [%s] ",ECUQtyOccur_str);fflush(stdout);

										if(BOM_line_look_up_attribute ("bl_item_item_id",&ECUiItemId));
										if(BOM_line_ask_attribute_string(t_Childobject, ECUiItemId, &ECUcp_ItemID_str));
										printf("\n checkin_method_1--b.ECUcp_ItemID_str is----------------------------------> [%s] ",ECUcp_ItemID_str);fflush(stdout);


										if(tc_strcmp(ECUQtyOccur_str,"")==0 || tc_strcmp(ECUQtyOccur_str,"0")!=0)
										{
											tc_strcat(ECUChildCpy,"'");
											tc_strcat(ECUChildCpy,ECUcp_ItemID_str);
											tc_strcat(ECUChildCpy,"'");
											tc_strcat(ECUChildCpy,",");

											printf("\n checkin_method_1--b.ECUChildCpy is----------------------------------> [%s] ",ECUChildCpy);fflush(stdout);
											QtyflagECUModCheckIn=1;
										}
									}
								}
								else
								{
									printf("\n checkin_method_1--b.Control object not found for SYSCD=SubModAddForCheckIn and SUBSYSCD =SubModAddForCheckIn and Information-1=[%s]  ",prtModAdd);fflush(stdout);
								}

								if(QtyflagECUModCheckIn==1)
								{
									char *ECUModCheckInError =NULL;
									if(ECUModCheckInError)MEM_free(ECUModCheckInError);
									ECUModCheckInError=(char *) MEM_alloc(15000);
									tc_strcpy (ECUModCheckInError,"");
									tc_strcat(ECUModCheckInError,"Please update quantity 0(zero) of ");
									tc_strcat(ECUModCheckInError,ECUChildCpy);
									tc_strcat(ECUModCheckInError,"parts under ECU Module '");
									tc_strcat(ECUModCheckInError,ModPartName);
									tc_strcat(ECUModCheckInError," '.");

									printf("\n checkin_method_1--b.Please update quantity 0(zero) of %s parts under ECU Module '%s' .",ECUChildCpy,ModPartName);fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,ECUModCheckInError);
									return ITK_err;
								}
							}
						}
					}
					//ECU Module Check in Qtt Validation END

					counter=0;
					CatPrtCN=0;
					counterPDF=0;
					CmiDrwCnt=0;
					ProAsmCN=0;
					primarydProAsmDS=NULLTAG;

					if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--c.TCDCNo of DI :%d ",n_attchs);fflush(stdout);
					if(n_attchs>0)
					{
						for (i= 0; i < n_attchs; i++)
						{
							primary=secondary_objects[i];
							if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
							if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
							printf("\n checkin_method_1--c.i=[%d] TCDCtype_name2 for the input is new: [%s] ",i,type_name2);fflush(stdout);

							if((tc_strcmp(type_name2,"CMI2Drawing")==0) || (tc_strcmp(type_name2,"ProDrw")==0))
							{
								counter++;
								//Rajendra
								if( AOM_UIF_ask_value(primary,"object_name",&drawingnum)==ITK_ok)PrintErrorStack();
								printf("\n checkin_method_1--c.drawingnum: [%s] ",drawingnum);fflush(stdout);

								if(tc_strcmp(type_name2,"CMI2Drawing")==0)
								{
									CmiDrwCnt++;
								}
							}
							else if((tc_strcmp(type_name2,"PDF")==0) && (counter==0)) // Aadarsh
							{
								counterPDF++;
								//Rajendra
								if( AOM_UIF_ask_value(primary,"object_name",&drawingnum)==ITK_ok)PrintErrorStack();
								printf("\n checkin_method_1--c.drawingnum: [%s] ",drawingnum);fflush(stdout);
							}

							if(tc_strcmp(type_name2,"CMI2Part")==0 )
							{
								CatPrtCN++;
							}

							/*
							as per below mail request part type check is commented.. Now onward QCDC is on for all part type for cadtype CMI2Product
							trilix team was facing issue for checkin dummy part part and jt is not getting created
							due to part type check it is considering only catproduct and assembly for qcdc and cmi2part and cmi2drw for all part type
							mail subject:PLM error (check-out)
							mail date: 05-mar-2018

							if(strcmp(type_name2,"CMI2Product")==0 && strcmp(sPartType,"Assembly")==0 )	*/
							if(tc_strcmp(type_name2,"CMI2Product")==0)
							{
								CatPrdt++;
							}
							if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0))
							{
								ProPrtCN++;

								if (tc_strcmp(type_name2,"ProAsm")==0)	//Added in TZ 1.38
								{
								   ProAsmCN++;
								   primarydProAsmDS=secondary_objects[i];
								}
							}
						}
					}
					//CatPrtCN++;
					printf("\n checkin_method_1--c.TCDCcounter :%d ",counter);fflush(stdout);
					printf("\n checkin_method_1--c.TCDCCatPrtCN :%d ",CatPrtCN);fflush(stdout);
					printf("\n checkin_method_1--c.counterPDF :%d ",counterPDF);fflush(stdout);
					printf("\n checkin_method_1--c.TCDCCatPrdt :%d ",CatPrdt);fflush(stdout);
					printf("\n checkin_method_1--c.TCDCProPrtCN :%d ",ProPrtCN);fflush(stdout);
					printf("\n checkin_method_1--c.CmiDrwCnt :%d ",CmiDrwCnt);fflush(stdout);
					printf("\n checkin_method_1--c.drawingnum:%s ",drawingnum);fflush(stdout);
					printf("\n checkin_method_1--c.TCDCProAsmCN: %d ",ProAsmCN);fflush(stdout);

					//Modification Description (t5_DocRemarks) cannot be null for revision other than "NR"
					//if( strcmp(desc.revision_id,"NR")!=0 )
					if((tc_strcmp(newPatRev,"NR")!=0) || ((tc_strcmp(newPatRev,"NR")==0) && (tc_strcmp(newPatSeq,"1")!=0)))
					{
						//printf("TCDCRevision ID for Mod Desc %s ", desc.revision_id);fflush(stdout);
						printf("\n checkin_method_1--c.TCDCRevision ID for Mod Desc %s ", newPatRev);fflush(stdout);

						if( AOM_ask_value_string(objTag,"t5_DocRemarks",&ModDes)!=ITK_ok)PrintErrorStack();
						printf("\n checkin_method_1--c.TCDCMod Desc %s ", ModDes);fflush(stdout);

						if( AOM_UIF_ask_value(objTag,"t5_PartType",&parttypn)==ITK_ok)
						printf("\n checkin_method_1--c.for modification description checking parttypn: [%s]  ModDes:[%s] ",parttypn,ModDes);fflush(stdout);
						//printf("\ntest to include part type Dummy for Modification Description validation ");fflush(stdout);

						if( strcmp(ModDes,"")==0 )
						{
							printf("\n checkin_method_1--c.TCDCMod modification Desc is null ");fflush(stdout);
							printf("\n checkin_method_1--c.modification Desc Part type for parttypn----------------->>> [%s] ",parttypn);fflush(stdout);
							if((tc_strcmp(parttypn,"Dummy")==0)||(tc_strcmp(parttypn,"Dummy Component")==0)||(tc_strcmp(parttypn,"Dummy Assembly")==0))
							{
								printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add Modification Description ");fflush(stdout);
							}
							else
							{
								tc_strcat ( AttributeNullList, "Modification Description" );
								errorflag=errorflag+1;
							}
							///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Modification Description");
							///return ITK_errStore;
						}

					}

					if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok)
					printf("\n checkin_method_1--c.TCDCProject from Object : %s ",projcode);fflush(stdout);

					if(strcmp(projcode,"")==0)
					{
						printf("\n checkin_method_1--c.TCDCBefore Project null error ");fflush(stdout);
						///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Project Code");
						///return ITK_errStore;
						tc_strcat ( AttributeNullList, ", Project Code" );
						errorflag=errorflag+1;
					}
					else
					{
						printf("\n checkin_method_1--c.TCDCProject from Object in else : %s ",projcode);fflush(stdout);

						if (PROJ_find(projcode,&projobj) !=ITK_ok)PrintErrorStack();

						if(projobj != NULLTAG)
						{
							printf("\n checkin_method_1--c.TCDCGetting Master Object for Project ");fflush(stdout);
							if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
							printf("\n checkin_method_1--c.TCDCAfter Master Object for Project ");fflush(stdout);
							if (PROJ_assign_objects(1 ,&projobj ,1 ,&objMasterTag )!=ITK_ok)PrintErrorStack();
							printf("\n checkin_method_1--c.TCDCAssigned to Project ");fflush(stdout);
						}
						else
						{
							printf("\n checkin_method_1--c.TCDCProject not found ");fflush(stdout);
						}
					}

					//if( AOM_ask_value_string(objTag,"t5_DesignGrp",&desgrp)==ITK_ok)
					if(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&desgrp)==ITK_ok)
					{
						printf("\n checkin_method_1--c.TCDCchecking t5_DesignGrp.........");fflush(stdout);
						if(tc_strcmp(desgrp,"")==0)
						{
							///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Design Group");
							///return ITK_errStore;
							tc_strcat ( AttributeNullList, ", Design Group" );
							errorflag=errorflag+1;
						}
					}

					//if( AOM_ask_value_string(objTag,"t5_PartType",&parttyp)==ITK_ok)
					if( AOM_UIF_ask_value(objTag,"t5_PartType",&parttyp)==ITK_ok)
					{
						printf("\n checkin_method_1--c.TCDCchecking my attribute %s........." ,parttyp);fflush(stdout);
						if(tc_strcmp(parttyp,"")==0)
						{
							///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Part Type");
							///return ITK_errStore;
							tc_strcat ( AttributeNullList, ", Part Type" );
							errorflag=errorflag+1;
						}
					}

					//Hrishikesh TZ 1.71
					char *Partnum = NULL;

					if( AOM_ask_value_string(objTag,"item_id",&Partnum)==ITK_ok)
					printf("\n checkin_method_1--c.TCDCPartnum from Object : %s ",Partnum);fflush(stdout);


					if( AOM_ask_value_double(objTag,"t5_Weight",&dWeight)==ITK_ok)
					{
						printf("\n checkin_method_1--c.Entered Weight: [%d] ",dWeight);fflush(stdout);
						if(dWeight==0)
						{
							//if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
							if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0) || ((tc_strcmp(parttyp,"Group Id")==0) && (tc_strstr(Partnum,"GCK")!=NULL)))
							{
								//printf("\n  part types Dummy / Dummy Component / Dummy Asm so do not add Part t5_Weight list ");fflush(stdout);
								printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm / GCK so do not add Part t5_Weight list ");fflush(stdout);//Added Hrishikesh TZ 1.71
							}
							else
							{
								///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight KG");
								///return ITK_errStore;
								if(tc_strcmp(parttyp,"Information Fitment Drawing")==0)
								{
									printf("\n checkin_method_1--c.Inside part types Infofitment Drawing !! ");fflush(stdout);
									if(AOM_lock(objTag))PrintErrorStack();
									if(AOM_set_value_double(objTag,"t5_Weight","0"))PrintErrorStack();
									if(AOM_save(objTag))PrintErrorStack();
									if(AOM_unlock(objTag))PrintErrorStack();
								}
								else
								{
									printf("\n checkin_method_1--c.Giving the error for Null weight for other part types ## ");fflush(stdout);
									tc_strcat ( AttributeNullList , ", Weight KG" );
									errorflag=errorflag+1;
								}
							}
						}
					}
					if(CatPrdt==0 && CatPrtCN!=0)
					{
						if( AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&sEnvDim)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Envelop Diamension: [%s] ",sEnvDim);fflush(stdout);
						if(tc_strcmp(sEnvDim,"")==0)
						{
						if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
						{
							printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add envelope dimensions in error list ");fflush(stdout);
						}
						else
						{
							tc_strcat ( AttributeNullList, ", Envelope Dimensions" );
							errorflag=errorflag+1;
						}
						}
						}

						if( AOM_ask_value_double(objTag,"t5_Volume",&dVol)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Entered Volume: [%d] ",dVol);fflush(stdout);

						if(dVol==0)
						{
						if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
						{
							printf("\n checkin_method_1--c.part types Dummy / Dummy Component/ Dummy Asm so do not add Volume in CuMtr in error list ");fflush(stdout);
						}
						else
						{
							tc_strcat ( AttributeNullList, ", Volume in CuMtr" );
							errorflag=errorflag+1;
						}
						}
						}

						if( AOM_ask_value_string(objTag,"t5_MThickness",&sMtrThiknes)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Entered Mtrl Thickness: [%s] ",sMtrThiknes);fflush(stdout);

						if(tc_strcmp(sMtrThiknes,"")==0)
						{
						if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
						{
							printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add Material Thickness in mm in error list ");fflush(stdout);
						}
						else
						{
							tc_strcat ( AttributeNullList, ", Material Thickness in mm" );
							errorflag=errorflag+1;
						}
						}
						}

						if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&sSurfPrtStd)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Entered SurfPrtStd: [%s] ",sSurfPrtStd);fflush(stdout);

						if(tc_strcmp(sSurfPrtStd,"")==0)
						{
						if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
						{
							printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add Surface Protection Stdin error list ");fflush(stdout);
						}
						else
						{
							tc_strcat ( AttributeNullList, ", Surface Protection Std" );
							errorflag=errorflag+1;
						}
						}
						}

						if( AOM_ask_value_double(objTag,"t5_SurfaceArea",&dSurfArea)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Entered SurfaceArea: [%d] ",dSurfArea);fflush(stdout);
						if(dSurfArea==0)
						{
						if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
						{
							printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add t5_SurfaceArea error list ");fflush(stdout);
						}
						else
						{
							tc_strcat ( AttributeNullList, ", Surface Area in SqMtr" );
							errorflag=errorflag+1;
						}
						}
						}

						if( AOM_ask_value_string(objTag,"t5_Material",&sMtrl)==ITK_ok)
						{
						printf("\n checkin_method_1--c.Entered Material: [%s] ",sMtrl);fflush(stdout);

						if(tc_strcmp(sMtrl,"")==0)
						{
							if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
							{
								printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add Part Materialerror list ");fflush(stdout);
							}
							else
							{
								tc_strcat ( AttributeNullList, ", Part Material" );
								errorflag=errorflag+1;
							}
						}
						}
					}

					if( AOM_ask_value_string(objTag,"object_desc",&sObjDesc)==ITK_ok)
					{
					printf("\n checkin_method_1--c.Entered Object Desc.:---> >>[%s] ",sObjDesc);fflush(stdout);

					if(tc_strcmp(sObjDesc,"")==0 )
					{
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Description");
					///return ITK_errStore;
					printf("\n checkin_method_1--c.Part type for parttyp----------------->>> [%s] ",parttyp);fflush(stdout);
					if((tc_strcmp(parttyp,"Dummy")==0)||(tc_strcmp(parttyp,"Dummy Component")==0)||(tc_strcmp(parttyp,"Dummy Assembly")==0))
					{
						printf("\n checkin_method_1--c.part types Dummy / Dummy Component / Dummy Asm so do not add Description ");fflush(stdout);
					}
					else
					{
					tc_strcat ( AttributeNullList, ", Description" );
					errorflag = errorflag + 1;
					}
					}
					}

					ITK_CALL(AOM_ask_value_string(objTag,"t5_LeftRh_Comp",&t5_RhPart));
					printf("\n checkin_method_1--c.LH/RH Indicator of t5_RhPart ::---> %s",t5_RhPart);fflush(stdout);

					//Add by Hanuman at TZ 1.54
					if(tc_strcmp(t5_RhPart,"LH CATIA")==0 || tc_strcmp(t5_RhPart,"LH PROE")==0 || tc_strcmp(t5_RhPart,"RH CATIA")==0 || tc_strcmp(t5_RhPart,"RH PROE")==0)
					{
						ITK_CALL(AOM_ask_value_string(objTag,"t5_OppHandDrg",&OppHandDrgLHRHPart));
						printf("\n checkin_method_1--c.OppHandDrg of LhRhPart is :: %s",OppHandDrgLHRHPart);fflush(stdout);

						if(tc_strcmp(OppHandDrgLHRHPart,"")==0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Opp Hand Drawingp Parameter can not be blank for LH/RH part. \nPlz Provide valid Opp Hand Drawing/Part Number");
							return ITK_errStore;
						}
						else
						{
							printf("\n checkin_method_1--c.Ok No Problem----------------------------> ::  ");fflush(stdout);
						}
					}
					else
					{
						printf("\n checkin_method_1--c.t5_LeftRh_Comp Vaues is NULL/NA of LH/RH Indicator----------> ");fflush(stdout);
					}

					printf("\n checkin_method_1--c.parttyp=[%s] ",parttyp);fflush(stdout);
					if((strcmp(t5_RhPart,"RH CATIA")!=0) && (strcmp(t5_RhPart,"RH PROE")!=0))
					{
						if ( errorflag > 0 )
						{
							printf("\n checkin_method_1--c.TCDC.NULL attributes : %s",AttributeNullList);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,AttributeNullList);
							return ITK_errStore;
						}
					}
					if(tc_strcmp(parttyp,"Module")==0 && tc_strcmp(type_name,"Design Revision")==0)
					{
						int	isNew = va_arg(args, int);
						char   *sModuleName	 =NULL;
						char   *sModuleDesc	 =NULL;
						char   *ErrorString	 =NULL;
						char   *Userinfo1Dup =NULL;
						char   *Userinfo1	 =NULL;
						char   *Userinfo2Dup =NULL;
						char   *Userinfo2    =NULL;
						char   *Module_ItemID_str    =NULL;
						char   *Module_ItemRev_str   =NULL;
						char   *Moddesgngrp   =NULL;
						char   *Modthirdbarrel   =NULL;
						char   *Modprojectcode   =NULL;
						char   *ModSubdesgngrp   =NULL;
						char   *SubModuleAdd   =NULL;
						char   *sModuleNumber   =NULL;
						char   *Userinfo3Dup   =NULL;
						char   *Userinfo3   =NULL;
						char   *Userinfo4Dup   =NULL;
						char   *Userinfo4   =NULL;
						char   *sModulePrj   =NULL;
						char   *sPrjName   =NULL;
						char   *sPrjBU   =NULL;

						tag_t	t_ModuleBomLineWindow	= NULLTAG;
						tag_t	t_ModuleRule			= NULLTAG;
						tag_t	t_ModuleItemTag			= NULLTAG;
						tag_t	t_ModuleTopLine			= NULLTAG;
						tag_t	*t_ModulePartChildren	= NULLTAG;
						tag_t	IFDqryTag				= NULLTAG;
						tag_t	*IFDCntrlObjectTag		= NULLTAG;
						tag_t	t_ModuleChildobject		= NULLTAG;
						tag_t	*prj_tagitems			= NULLTAG;

						int i_ModuleChildCount = 0;
						int n_IFDentries = 1;
						int IFDrsltCount = 0;
						int iModItemRevId = 0;
						int iModItemId = 0;
						int ModChilcnt = 0;
						int error_count = 0;
						int n_tags_found = 0;

						const char
							*attrs[2] = {"item_id","object_type"},
							*values[2]	= {"*","*"};

						char *IFDqry_entries[1] = {"SYSCD"};
						char *IFDqry_values[1] = {"*"};

						if(QRY_find("Control Objects...", &IFDqryTag));
						if(IFDqryTag!=NULLTAG)
						{
							IFDqry_values[0] = "IFD_CHECK";
							if(QRY_execute(IFDqryTag, n_IFDentries, IFDqry_entries, IFDqry_values, &IFDrsltCount, &IFDCntrlObjectTag));

							printf("\n checkin_method_1--c.IFDrsltCount [%d] ",IFDrsltCount);fflush(stdout);
							if(IFDrsltCount>0)
							{
								AOM_ask_value_string(IFDCntrlObjectTag[0],"t5_Userinfo1",&Userinfo1);
								tc_strdup(Userinfo1,&Userinfo1Dup);
								printf("\n checkin_method_1--c.Userinfo1 :[%s]:", Userinfo1Dup);fflush(stdout);
								AOM_ask_value_string(IFDCntrlObjectTag[0],"t5_Userinfo2",&Userinfo2);
								tc_strdup(Userinfo2,&Userinfo2Dup);
								printf("\n checkin_method_1--c.Userinfo2 :[%s]:", Userinfo2Dup);fflush(stdout);
								AOM_ask_value_string(IFDCntrlObjectTag[0],"t5_Userinfo3",&Userinfo3);
								tc_strdup(Userinfo3,&Userinfo3Dup);
								printf("\n checkin_method_1--c.Userinfo3 :[%s]:", Userinfo3Dup);fflush(stdout);
								AOM_ask_value_string(IFDCntrlObjectTag[0],"t5_Userinfo4",&Userinfo4);
								tc_strdup(Userinfo4,&Userinfo4Dup);
								printf("\n checkin_method_1--c.Userinfo4 :[%s]:", Userinfo4Dup);fflush(stdout);
								//if((tc_strstr(Userinfo1Dup, ReasonDup) != NULL || tc_strstr(Userinfo2Dup, ReasonDup) != NULL) && (tc_strstr(Userinfo3Dup, BusUnit) != NULL || tc_strstr(Userinfo4Dup, BusUnit) != NULL))
							}
						}

						if( AOM_ask_value_string(objTag,"t5_ModuleName",&sModuleName)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.After setting sModuleName[%s] ",sModuleName);fflush(stdout);
						if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.After setting sCatName[%s] ",sCatName);fflush(stdout);
						printf("\n checkin_method_1--c.After setting isNew[%d] ",isNew);fflush(stdout);
						if( AOM_ask_value_string(objTag,"item_id",&sModuleNumber)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.After setting sModuleNumber[%s] ",sModuleNumber);fflush(stdout);
						SubModuleAdd=subString(sModuleNumber,4,5);
						printf("\n checkin_method_1--c.After setting SubModuleAdd[%s] ",SubModuleAdd);fflush(stdout);
						if( AOM_ask_value_string(objTag,"t5_ProjectCode",&sModulePrj)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.After setting sModulePrj[%s] ",sModulePrj);fflush(stdout);

						values[0] = sModulePrj;
						values[1] = "T5_Project";
						ITEM_find_items_by_key_attributes(2, attrs, values, &n_tags_found, &prj_tagitems);
						printf("\n checkin_method_1--c.n_tags_found: [%d] ",n_tags_found);fflush(stdout);

						if(n_tags_found>0)
						{
							if( AOM_ask_value_string(prj_tagitems[0],"item_id",&sPrjName)!=ITK_ok);PrintErrorStack();
							printf("\n checkin_method_1--c.After setting sPrjName[%s] ",sPrjName);fflush(stdout);

							if( AOM_ask_value_string(prj_tagitems[0],"t5_BussUnitType",&sPrjBU)!=ITK_ok);PrintErrorStack();
							printf("\n checkin_method_1--c.After setting sPrjBU[%s] ",sPrjBU);fflush(stdout);
						}
						if(tc_strcmp(sCatName,sModuleName)==0)
						{
							printf("\n checkin_method_1--c.Keyword description Matching ");fflush(stdout);
						}
						else
						{
							printf("\n checkin_method_1--c.Keyword description Not Matching ");fflush(stdout);

							if(ErrorString)MEM_free(ErrorString);
							ErrorString=(char *) MEM_alloc(400);
							tc_strcpy (ErrorString, "Keyword Description [");
							tc_strcat(ErrorString,sCatName);
							tc_strcat(ErrorString,"]");
							tc_strcat(ErrorString," Module Name [");
							tc_strcat(ErrorString,sModuleName);
							tc_strcat(ErrorString,"]");
							tc_strcat(ErrorString," is not Matching, Please correct Keyword Description");

							printf("\n checkin_method_1--c.sPrjBU: [%s]  Userinfo4Dup: [%s] ",sPrjBU,Userinfo4Dup);fflush(stdout);
							if((tc_strcmp(sPrjBU,"CVBU")==0) || (tc_strstr(Userinfo4Dup,"CVBU")!= NULL))
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,ErrorString);
								return ITK_err;
							}
						}
						/*IFD CHECK VALIDATION FOR MODULE PART CHECK-IN ACTION----By SUDHIR*/
						if(tc_strstr(Userinfo1Dup,SubModuleAdd)!= NULL || tc_strstr(Userinfo2Dup,SubModuleAdd)!= NULL)
						{
							/*Getting ChildParts through BOM LINE*/
							if(BOM_create_window (&t_ModuleBomLineWindow) !=ITK_ok) PrintErrorStack();
							printf("\n checkin_method_1--c.Module 1111 ");fflush(stdout);
							if(CFM_find( "Latest Working", &t_ModuleRule )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_config_rule( t_ModuleBomLineWindow, t_ModuleRule )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_pack_all (t_ModuleBomLineWindow, true)!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_top_line (t_ModuleBomLineWindow, t_ModuleItemTag, objTag, null_tag, &t_ModuleTopLine)!=ITK_ok) PrintErrorStack();
							if(BOM_line_ask_child_lines (t_ModuleTopLine, &i_ModuleChildCount, &t_ModulePartChildren)!=ITK_ok) PrintErrorStack();
							printf("\n checkin_method_1--c.Module Child Parts Found in BomLine are [%d] ",i_ModuleChildCount);fflush(stdout);
							if(i_ModuleChildCount>0)
							{
								for(ModChilcnt=0;ModChilcnt<i_ModuleChildCount;ModChilcnt++)
								{
									t_ModuleChildobject = t_ModulePartChildren[ModChilcnt];
									if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iModItemRevId));
									if( BOM_line_look_up_attribute ("bl_item_item_id",&iModItemId));
									if(BOM_line_ask_attribute_string(t_ModuleChildobject, iModItemId, &Module_ItemID_str));
									if(BOM_line_ask_attribute_string(t_ModuleChildobject, iModItemRevId, &Module_ItemRev_str));
									printf("\n checkin_method_1--c.ModChilcnt[%d] ItemID is [%s] and ItemRevision is: [%s] ",ModChilcnt+1,Module_ItemID_str,Module_ItemRev_str);fflush(stdout);
									Modprojectcode=subString(Module_ItemID_str,0,4);
									Moddesgngrp=subString(Module_ItemID_str,4,2);
									ModSubdesgngrp=subString(Module_ItemID_str,6,2);
									Modthirdbarrel=subString(Module_ItemID_str,8,2);
									printf("\n checkin_method_1--c.Modprojectcode :[%s]:",Modprojectcode);fflush(stdout);
									printf("\n checkin_method_1--c.Moddesgngrp :[%s]:",Moddesgngrp);fflush(stdout);
									printf("\n checkin_method_1--c.ModSubdesgngrp :[%s]:",ModSubdesgngrp);fflush(stdout);
									printf("\n checkin_method_1--c.Modthirdbarrel :[%s]:",Modthirdbarrel);fflush(stdout);
									if(tc_strlen(Module_ItemID_str)==12 && tc_strcmp(Modthirdbarrel,"00")==0 && (tc_strcmp(sPrjBU,"CVBU")==0 || tc_strstr(Userinfo4Dup,"CVBU")!= NULL))
									{
										printf("\n checkin_method_1--c.IFD part number:[%s]: is alaviable in Module Part [%s]",Module_ItemID_str,sModuleNumber);fflush(stdout);
										error_count = 0;
										break;
									}
									else
									{
										error_count++;
									}
								}
							}
							printf("\n checkin_method_1--c.error_count :[%d]:",error_count);fflush(stdout);
							if(error_count>0)
							{
								printf("\n checkin_method_1--c.error-IFD missing,attach IFD before check-in of submodules... ");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"IFD missing,attach IFD before check-in of submodules");
								return ITK_err;
							}
						}


						/*IFD CHECK VALIDATION FOR MODULE PART CHECK-IN ACTION----By SUDHIR*/
					}

					if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok);PrintErrorStack();
					printf("\n checkin_method_1--c.Desc_obj2  = [%s] ", Desc_obj2);fflush(stdout);

					if(AOM_ask_value_string(objTag,"t5_DrawingInd",&sObjTagDrwInd)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_Material",&sObjTagMatDrw)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_PartStatus",&sPartStatus)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
					if(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGrp)!=ITK_ok);PrintErrorStack();
					if(AOM_UIF_ask_value(objTag,"t5_MatlClass",&sMatClass)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"object_desc",&ItemDesc)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_logical(objTag,"t5_SpareInd",&SpareInd1)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCriteria1)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber1)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_MThickness",&MThickness)!=ITK_ok);PrintErrorStack();
					if(AOM_ask_value_string(objTag,"t5_EnvelopeDimensions",&EnvelopeDim)!=ITK_ok);PrintErrorStack();

					printf("\n checkin_method_1--c.Drawing Indicator :%s \n Material In Drawing :%s \n Part Status :%s \n Part Type :%s  \n Design Group ",sObjTagDrwInd,sObjTagMatDrw,sPartStatus,sPartType1,sDesignGrp);fflush(stdout);

					//if((strcmp(sObjTagDrwInd,"A")==0) || (strcmp(sObjTagDrwInd,"D")==0) )
					//{
					//	if((tc_strcmp(sObjTagMatDrw,"")!=0))
					//	{
					//		printf("\n	Material name is present----->> :%s",sObjTagMatDrw);fflush(stdout);
					//	}
					//	else
					//	{
					//		EMH_store_error_s1(EMH_severity_error,ITK_errStore,"If Drawing Indicator is D/A then Material is Mandatory");
					//		return ITK_errStore;
					//	}
					//}
					if(strstr(Desc_obj2,"NR") != NULL)
					{
						if((strcmp(sPartStatus,"DR4")==0) || (strcmp(sPartStatus,"DR5")==0) ||(strcmp(sPartStatus,"AR4")==0) || (strcmp(sPartStatus,"AR5")==0) )
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,"NR revision part can not be created or updated with DR-status DR4/5 or AR4/5");
							return ITK_errStore;
						}
					}

					/*if( AOM_ask_value_string(objTag,"object_desc",&tempS)==ITK_ok)
					{
					if(tc_strcmp(tempS,"")==0 )
					{
					///EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Description");
					///return ITK_errStore;
					tc_strcat ( AttributeNullList, ", Description" );
					errorflag = errorflag + 1;
					}
					}*/

					if((strcmp(sPartType1,"C")==0))
					{
						tc_strcat(CompAttributeNullList,Item_id);
						tc_strcat(CompAttributeNullList,"/");
						tc_strcat(CompAttributeNullList,desc.revision_id);
						printf("\n checkin_method_1--c.CompAttributeNullList : %s",CompAttributeNullList);

						if((tc_strcmp(sObjTagMatDrw,"")!=0))
						{
							printf("\n checkin_method_1--c.Material while Part type comp :%s",sObjTagMatDrw);fflush(stdout);
						}
						else
						{
							//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Part Material can not be NULL for part type Component");
							//return ITK_errStore;
							tc_strcat (CompAttributeNullList, ", Part Material" );
							Comperrorflag = Comperrorflag + 1;
						}

						if((tc_strcmp(sMatClass,"")!=0))
						{
							printf("\n checkin_method_1--c.Material Class while Part type comp :%s",sMatClass);fflush(stdout);
						}
						else
						{
							//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"For Part Type Component Material Class can not be NULL.");
							//return ITK_errStore;

							tc_strcat (CompAttributeNullList, ", Material Class" );
							Comperrorflag = Comperrorflag + 1;
						}
					}
					/****************************************Rohit Validation Starts for Material Class and Material in Drawing*********************************/
					printf("\n checkin_method_1--c.Inside Checkin Validation Code\n "); fflush(stdout);

					char *Desc_obj2M	=	NULL;
					char *sPartType1M	=	NULL;
					char *SpareCriteria1M	=	NULL;
					char *sMatClassM	=	NULL;
					char *sObjTagMatDrwM	=	NULL;
					char *sObjTagMatDrwMnew = NULL;
					char *tmpUIsub = NULL;
					char *tmpCOsub = NULL;
					char *tmpUIsubtring = NULL;
					char *tmpCOsubtring = NULL;

					tag_t query1M = NULLTAG;
					tag_t query3M = NULLTAG;
					tag_t *CntrlObject_Tag1M = NULLTAG;
					tag_t *CntrlObject_Tag3M = NULLTAG;

					int n_found1M = 0;
					int n_found3M = 0;
					int n_entries1M = 1;
					int n_entries3M = 1;
					int z = 0;
					//int i = 0;
					char *info4M	=	NULL;
					char *info1M	=	NULL;
					char *info2M	=	NULL;
					char *info41M	=	NULL;
					char *info42M	=	NULL;
					char *tok_valueUI = NULL;
					char *tok_valueCO = NULL;
					char	*tok_valueM			= NULL;
					char *tmpchar1	=	NULL;
					char *TempValmtdr = NULL;
					tok_valueM=(char *) MEM_alloc(10000);
					tok_valueUI=(char *) MEM_alloc(1000);
					tok_valueCO=(char *) MEM_alloc(1000);
					tmpchar1=(char *) MEM_alloc(10000);
					TempValmtdr=(char *) MEM_alloc(10000);
					char	*ErrorMsgmatcls			= NULL;
					ErrorMsgmatcls = (char	*)MEM_alloc(500);

					int cLenMtdr = 0;
					int cLenMtdr1 = 0;
					int cLenU	= 0;
					int cLenCO  = 0;
					int sLenU  = 0;
					int sLenCO  = 0;
					int cLenUIS = 0;
					int cLenCOS = 0;

					tmpUIsubtring=(char *) MEM_alloc(10000);
					tmpCOsubtring=(char *) MEM_alloc(10000);

					z = AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2M);
					printf("\n checkin_method_1--c.Desc_obj2M MTDR  = [%s] ", Desc_obj2M);fflush(stdout);

					z = AOM_ask_value_string(objTag,"t5_PartType",&sPartType1M);
					printf("\n checkin_method_1--c.Part Type MTDR is  = [%s] ", sPartType1M);fflush(stdout);

					z = AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCriteria1M);
					printf("\n checkin_method_1--c.Part Category MTDR is  = [%s] ", SpareCriteria1M);fflush(stdout);

					z = AOM_UIF_ask_value(objTag,"t5_MatlClass",&sMatClassM);
					printf("\n checkin_method_1--c.Material Class MTDR is :%s",sMatClassM);fflush(stdout);

					z = AOM_UIF_ask_value(objTag,"t5_Material",&sObjTagMatDrwM);
					printf("\n checkin_method_1--c.Material Drawing MTDR is :%s",sObjTagMatDrwM);fflush(stdout);
					//ITK_CALL(AOM_ask_value_string(objTag,"t5_Material",&sObjTagMatDrwMnew));

					if((tc_strcmp(sPartType1M,"C")==0))
					{
						printf("\n checkin_method_1--c.EXE Working Condition");fflush(stdout);
						if(tc_strstr(Desc_obj2M,"NR") != NULL)
						{
							if((tc_strstr(SpareCriteria1M,"BTP") != NULL) || (tc_strstr(SpareCriteria1M,"BTW") != NULL))
							{
								int flag=0;
								z = QRY_find("Control Objects...",&query3M);
								printf("\n\nquery3..Control Objects... MATCLS Query Found\n ");	fflush(stdout);

								char *qry_entries3M[1] = {"SYSCD"};
								char **qry_values3M = (char **) MEM_alloc(10 * sizeof(char *));

								qry_values3M[0] = "MATCLSDRGCHECK";

								z = QRY_execute(query3M, n_entries3M, qry_entries3M, qry_values3M, &n_found3M, &CntrlObject_Tag3M);
								printf("\n\n  n_found3 SYSCD :%d ",n_found3M);	fflush(stdout);
								if(n_found3M>0)
								{
									AOM_ask_value_string(CntrlObject_Tag3M[0],"t5_Userinfo1",&info41M);
									printf("\n\nUser Information 41 is : %s and sObjTagMatDrwM :%s",info41M,sObjTagMatDrwM);	fflush(stdout);

									AOM_ask_value_string(CntrlObject_Tag3M[0],"t5_Userinfo2",&info42M);
									printf("\n\nUser Information 42 is : %s",info42M);	fflush(stdout);

									if(tc_strcmp(info41M,"MATCLSCHECK")==0)
									{
										int flag=0;

										z = QRY_find("Control Objects...",&query1M);
										printf("\nmmmm MATCLS Query Foundddddddddddddddddddddddddddddd ");	fflush(stdout);

										char *qry_entries1M[1] = {"SYSCD"};
										char **qry_values1M = (char **) MEM_alloc(10 * sizeof(char *));

										qry_values1M[0] = "MATCLS";
										z = QRY_execute(query1M, n_entries1M, qry_entries1M, qry_values1M, &n_found1M, &CntrlObject_Tag1M);

										printf("\n\ncccCount of control onjects is : %d",n_found1M);

										for(i = 0; i < n_found1M; i++)
										{
											z = AOM_ask_value_string(CntrlObject_Tag1M[i],"t5_Userinfo4",&info4M);
											printf("\n\nUser Information 4 is : %s",info4M);	fflush(stdout);

											if(tc_strstr(sMatClassM,info4M)!= NULL)
											{
												flag=1;
												printf("\n\nNo issue for Check-in");	fflush(stdout);
												break;
											}
										}
										if(flag==0)
										{
											printf("\n checkin_method_1--c.Material Class Value is not as per library. Kindly update valid value and try to check-in again.");
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Class Value is not as per library. Kindly update valid value and try to check-in again.");
											return ITK_errStore;;
										}
									}
									if(tc_strcmp(info42M,"DRGCHECK")==0)
									{
										tag_t query2M	=	NULLTAG;
										tag_t *CntrlObject_Tag2M	=	NULLTAG;
										int n_found2M = 0;
										int n_entries2M = 1;
										int j	=	0;

										z = QRY_find("Control Objects...",&query2M);
										printf("\n checkin_method_1--c.Control Objects...MTDR Query Found\n ");	fflush(stdout);

										int flag1 = 0;
										char *qry_entries2M[1] = {"SYSCD"};
										char **qry_values2M = (char **) MEM_alloc(10 * sizeof(char *));
										qry_values2M[0] = "MTDR" ;



										z	=	QRY_execute(query2M, n_entries2M, qry_entries2M, qry_values2M, &n_found2M, &CntrlObject_Tag2M);
										for(j = 0; j < n_found2M; j++)
										{
												flag1=0;
												z	=	AOM_ask_value_string(CntrlObject_Tag2M[j],"t5_Userinfo1",&info1M);
												printf("\n checkin_method_1--c.User Information 1 is : %s",info1M);	fflush(stdout);

												z	=	AOM_ask_value_string(CntrlObject_Tag2M[j],"t5_Userinfo2",&info2M);
												printf("\n checkin_method_1--c.User Information 2 is : %s",info2M);	fflush(stdout);

												if (tc_strstr(sObjTagMatDrwM,"mm Thk") == NULL)
												{
													printf("\n checkin_method_1--c.if--sMatClassM: [%s]   info1M: [%s]",sMatClassM,info1M); fflush(stdout);
													printf("\n checkin_method_1--c.iif--nfo2M: [%s]     sObjTagMatDrwM: [%s]",info2M,sObjTagMatDrwM);	 fflush(stdout);

													if(tc_strstr(info2M,sObjTagMatDrwM) != NULL)
													{
														printf("\n\n if--Material in Drawing validation 1");
														if(tc_strstr(sMatClassM,info1M) != NULL)
														{
															flag1=1; //flag1=0 change done
															printf("\n checkin_method_1--c.if--material class and info 1 are same");
															printf("\n checkin_method_1--c.if--Material Drawing value and Material Class value are as per Standards. Check-in Successfull");
															break;
														}
												}

												}
												else
												{
													if(tc_strstr(sMatClassM,info1M) != NULL)
													{
														printf("\n checkin_method_1--c.Control object and User input is  [%s] annnnnnnd [%s] ",info2M,sObjTagMatDrwM);

														if(tc_strstr(sObjTagMatDrwM,info2M) != NULL)
														{
															printf("\nCheck-in Successful before flag ");
															flag1=1;
															printf("\nCheck-in Successful ");
															break;
														}
													}

												}
													//{
													//	    flag1=1;
													//		cLenU=tc_strlen(sObjTagMatDrwM); //User given value for MTDR [1.5mm Thk - T SH HR-DD1079 TS23521][33]
													//		cLenCO=tc_strlen(info2M); //Calue of MTDR in control Object [xxxmm Thk - T SH HR-DD1079 TS23521][33]
													//		printf("\nValue given by user is [%s][%d] and Value present in Control Object is [%s][%d] ",sObjTagMatDrwM,cLenU,info2M,cLenCO);fflush(stdout);
													//
													//			if(tc_strstr(sMatClassM,info1M) != NULL)
													//			{
													//					if(tc_strlen(sObjTagMatDrwM) == tc_strlen(info2M))
													//					{
													//						printf("\nUser Input length matches with control object length "); fflush(stdout);
													//
													//						tmpUIsubtring = NULL;
													//						tmpCOsubtring = NULL;
													//
													//
													//						tmpUIsubtring=subString(sObjTagMatDrwM,5,(cLenU-5));
													//						tmpCOsubtring=subString(info2M,5,(cLenCO-5));
													//						printf("\nNormal print after getting substring "); fflush(stdout);
													//
													//
													//						printf("\nUser Input substring and Control Object substring is [%s][%s] ",tmpUIsubtring,tmpCOsubtring); fflush(stdout);
													//
													//						if(tc_strcmp(tmpUIsubtring,tmpCOsubtring)==0)
													//						{
													//							flag1=1;
													//							printf("\n checkin_method_1--c.No issue for Checkin"); fflush(stdout);
													//							break;
													//						}
													//
													//					}
													//			}
													//
													//}


										}
										printf ("\n flag1:== [%d]  ",flag1); fflush(stdout);
										if(flag1==0)
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material in Drawing Value and Material Class Value are not as per library. Kindly update valid value and try to check-in again.");
											return ITK_errStore;
											printf("\n\nMaterial in Drawing Value is not as per library. Kindly update valid value and try to check-in again.");
										}
									}
								}
							}
							else
							{
								printf("\n\nPart Category is not BTP or BTW\n\n");
							}
						}
						else
						{
							printf("\n\nRevision is not NR");
						}
					}
					else
					{
						printf("\n\nPart Type is not componenet");
					}

					/****************************************Rohit Validation Ends for Material Class and Material in Drawing*********************************/

					/****************************************Rohit Validation starts for Fastner related check*********************************/

					tag_t fast_CntrlOBJ	=	NULLTAG;
					int fast_entries = 1;
					int	fast_found	=	0;
					tag_t *CntrlObject_fast	=	NULLTAG;

					if(QRY_find("Control Objects...",&fast_CntrlOBJ));
					printf("\n\nFastCVBUCntrlObj Query Found\n\n");	fflush(stdout);

					char *qry_fastcntrl[1] = {"SYSCD"};

					char **qry_valuesfast = (char **) MEM_alloc(10 * sizeof(char *));

					qry_valuesfast[0] = "FastCVBUCntrlObj";

					if(QRY_execute(fast_CntrlOBJ, fast_entries, qry_fastcntrl, qry_valuesfast, &fast_found, &CntrlObject_fast));
					printf("\n\n  Fastener SYSCD :%d\n",fast_found);	fflush(stdout);
					if(fast_found>0)
					{
						printf("\n\nInside Fasteners Checkin Code ================> \n\n"); fflush(stdout);

						int count_OSPRY = 0;
						int zospry	=	0;
						int n_OSPRY_qry = 1;
						int IFA	=	0;
						int toplinefasteners_count = 0;
						int IFC	= 0	;
						int	childline_ID = 0;
						int childline_rev = 0;
						int childline_projcode = 0 ;
						int childline_designgrp	= 0 ;
						int child_cnt	= 0;
						int match_flag	= 0;
						int match_flag1	= 0;
						int match_flag2	= 0;

						tag_t OSPRY_qrytag = NULLTAG;
						tag_t *CntrlObject_OSPRY = NULLTAG;
						tag_t ALTPartIND_objs = NULLTAG;
						tag_t info_Obspno_childs = NULLTAG;
						tag_t bom_fasteners	= NULLTAG;
						tag_t topline_fasteners = NULLTAG;
						tag_t *fasteners_childs	= NULLTAG;
						tag_t latest_IDfast = NULLTAG;
						tag_t latest_revfast = NULLTAG;
						tag_t fastener_childtag	= NULLTAG;
						tag_t tfast_rule = NULLTAG;

						char *revID_Fasteners	=	NULL;
						char *partTypefasteners	=	NULL;
						char *info_Obspno_array	= NULL;
						char *ErrorMsgF = NULL;
						char *ErrorMsgFA = NULL;
						char *AhdMkByInd = NULL;
						char *CarMkByInd = NULL;
						char *DwdMkByInd = NULL;
						char *JsrMkByInd = NULL;
						char *JdlMkByInd = NULL;
						char *LkoMkByInd = NULL;
						char *PnrMkByInd = NULL;
						char *PCBUMkByInd = NULL;
						char *PuneMkByInd = NULL;
						char *PuneUVMkByInd = NULL;
						char *SrgMkByInd = NULL;
						char *revID_Fasteners_rev = NULL;
						char *info_ALTPartInd = NULL;
						char *info_Obspno = NULL;
						char *latest_item_ID = NULL;
						char *latest_rev_fast = NULL;
						char *fastener_ItemID_str = NULL;
						char *fasterner_ItemRev_str = NULL;
						char *fasterner_projcode_str = NULL   ;
						char *fasterner_designgrp_str = NULL   ;
						char *Fasteners_chld = NULL;
						char *Fasteners_chld_A = NULL;
						char *info_ALTPartNo = NULL;
						char *info_Obspno_child = NULL;

						ErrorMsgF = (char *)MEM_alloc(500);
						ErrorMsgFA = (char *)MEM_alloc(500);
						info_Obspno_array=(char *)MEM_alloc(1000);
						tc_strcpy(info_Obspno_array,"");

						if(AOM_ask_value_string(objTag,"item_id",&revID_Fasteners));
						if(AOM_ask_value_string(objTag,"item_revision_id",&revID_Fasteners_rev));

						//printf("\n checkin_method_1--c.Item ID and Rev ID is ======>  [%s] and [%s]\n", revID_Fasteners,revID_Fasteners_rev);fflush(stdout);

						if(AOM_ask_value_string(objTag,"t5_PartType",&partTypefasteners));
						printf("\n checkin_method_1--c.Part Type For Fastener Related is  = [%s]\n", partTypefasteners);fflush(stdout);

						if(ITEM_find_item(revID_Fasteners,&latest_IDfast));
						if(ITEM_ask_latest_rev(latest_IDfast,&latest_revfast));

						if(AOM_ask_value_string(latest_IDfast,"item_id",&latest_item_ID));
						if(AOM_ask_value_string(latest_revfast,"item_revision_id",&latest_rev_fast));
						printf("\nItem ID and Revision ID for rev is [%s] and [%s]",latest_item_ID,latest_rev_fast);	fflush(stdout);

						ITK_CALL(AOM_ask_value_string(objTag,"t5_AhdMakeBuyIndicator",&AhdMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_CarMakeBuyIndicator",&CarMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_DwdMakeBuyIndicator",&DwdMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_JsrMakeBuyIndicator",&JsrMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_JdlMakeBuyIndicator",&JdlMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_LkoMakeBuyIndicator",&LkoMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_PnrMakeBuyIndicator",&PnrMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_PunPCBUMakeBuyIndicator",&PCBUMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_PunMakeBuyIndicator",&PuneMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_PunUVMakeBuyIndicator",&PuneUVMkByInd));
						ITK_CALL(AOM_ask_value_string(objTag,"t5_SgrMakeBuyIndicator",&SrgMkByInd));

						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", AhdMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", CarMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", DwdMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", JsrMkByInd);fflush(stdout);    //E50,E99,E98
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", JdlMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", LkoMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", PnrMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", PCBUMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", PuneMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", PuneUVMkByInd);fflush(stdout);
						printf("\n checkin_method_1--c.Make Buy For Fastener Related is  = [%s]\n", SrgMkByInd);fflush(stdout);

						if((tc_strcmp(AhdMkByInd,"E50") == 0) || (tc_strcmp(AhdMkByInd,"E99") == 0) || (tc_strcmp(AhdMkByInd,"E98") == 0) || (tc_strcmp(CarMkByInd,"E50") == 0) || (tc_strcmp(CarMkByInd,"E99") == 0) || (tc_strcmp(CarMkByInd,"E98") == 0) || (tc_strcmp(DwdMkByInd,"E50") == 0) || (tc_strcmp(DwdMkByInd,"E99") == 0) || (tc_strcmp(DwdMkByInd,"E98") == 0) || (tc_strcmp(JsrMkByInd,"E50") == 0) || (tc_strcmp(JsrMkByInd,"E99") == 0) || (tc_strcmp(JsrMkByInd,"E98") == 0) || (tc_strcmp(JdlMkByInd,"E50") == 0) || (tc_strcmp(JdlMkByInd,"E99") == 0) || (tc_strcmp(JdlMkByInd,"E98") == 0) || (tc_strcmp(LkoMkByInd,"E50") == 0) || (tc_strcmp(LkoMkByInd,"E99") == 0) || (tc_strcmp(LkoMkByInd,"E98") == 0) || (tc_strcmp(PnrMkByInd,"E50") == 0) || (tc_strcmp(PnrMkByInd,"E99") == 0) || (tc_strcmp(PnrMkByInd,"E98") == 0) || (tc_strcmp(PCBUMkByInd,"E50") == 0) || (tc_strcmp(PCBUMkByInd,"E99") == 0) || (tc_strcmp(PCBUMkByInd,"E98") == 0) || (tc_strcmp(PuneMkByInd,"E50") == 0) || (tc_strcmp(PuneMkByInd,"E99") == 0) || (tc_strcmp(PuneMkByInd,"E98") == 0) || (tc_strcmp(PuneUVMkByInd,"E50") == 0) || (tc_strcmp(PuneUVMkByInd,"E99") == 0) || (tc_strcmp(PuneUVMkByInd,"E98") == 0) || (tc_strcmp(SrgMkByInd,"E50") == 0) || (tc_strcmp(SrgMkByInd,"E99") == 0) || (tc_strcmp(SrgMkByInd,"E98") == 0))
						{
							if(tc_strcmp(revID_Fasteners_rev,"NR") != 0)
							{
								if((tc_strcmp(partTypefasteners,"A")==0))
								{
									zospry	=	QRY_find("Cntrl_t5ObmPrt_OSPRY",&OSPRY_qrytag);
									char *OSPRY_entries[1] = {"Alt Part Ind"};
									char **OSPRY_values = (char **) MEM_alloc(10 * sizeof(char *));
									OSPRY_values[0] = "FastCVBU";
									zospry	=	QRY_execute(OSPRY_qrytag, n_OSPRY_qry, OSPRY_entries, OSPRY_values, &count_OSPRY, &CntrlObject_OSPRY);

									printf("\nBefore Window created\n"); fflush(stdout);
									if(BOM_create_window(&bom_fasteners)!=ITK_ok); PrintErrorStack();
									if(CFM_find("Latest Working", &tfast_rule)!=ITK_ok); PrintErrorStack();
									if(BOM_set_window_config_rule( bom_fasteners, tfast_rule)!=ITK_ok); PrintErrorStack();
									if(BOM_set_window_pack_all(bom_fasteners, true)!=ITK_ok); PrintErrorStack();
									if(BOM_set_window_top_line(bom_fasteners,latest_IDfast,latest_revfast,NULLTAG,&topline_fasteners)!=ITK_ok);	PrintErrorStack();
									printf("\nWindow created AFTER\n"); fflush(stdout);
									if(BOM_line_ask_child_lines(topline_fasteners,&toplinefasteners_count,&fasteners_childs)!=ITK_ok);	PrintErrorStack();
									printf("\nChild count related to FASTENERS is %d\n",toplinefasteners_count); fflush(stdout);

									if(count_OSPRY > 0)
									{
										for(IFA = 0 ; IFA < count_OSPRY ; IFA++)
										{
											ALTPartIND_objs = CntrlObject_OSPRY[IFA];

											if (AOM_ask_value_string(ALTPartIND_objs,"t5_AltPartInd",&info_ALTPartInd));
											if (AOM_ask_value_string(ALTPartIND_objs,"t5_Obspno",&info_Obspno));
											printf("\nAlt Part Indicator and Obspno is [%s] and [%s]\n\n",info_ALTPartInd,info_Obspno);fflush(stdout);

											if (AOM_ask_value_string(ALTPartIND_objs,"t5_Obspno",&info_Obspno));
											printf("\n checkin_method_1--c.info_Obspno [%s]\n",info_Obspno); fflush(stdout);

											tc_strcat(info_Obspno_array,info_Obspno);
											tc_strcat(info_Obspno_array,",");

											//info_Obspno_array = info_Obspno[IFA];
										}

										printf("\n checkin_method_1--c.info_Obspno_Array [%s]\n",info_Obspno_array); fflush(stdout);
										for(child_cnt = 0 ; child_cnt < toplinefasteners_count ; child_cnt++)
										{
											fastener_childtag = fasteners_childs[child_cnt];

											if( BOM_line_look_up_attribute ("bl_item_item_id",&childline_ID));
											if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&childline_rev));
											//if( BOM_line_look_up_attribute ("bl_rev_owning_project",&childline_projcode))	PrintErrorStack();
											if(BOM_line_look_up_attribute ("bl_Design Revision_t5_ProjectCode",&childline_projcode));
											if(BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&childline_designgrp))	;

											if(BOM_line_ask_attribute_string(fastener_childtag, childline_ID, &fastener_ItemID_str));
											if(BOM_line_ask_attribute_string(fastener_childtag, childline_rev, &fasterner_ItemRev_str));
											if(BOM_line_ask_attribute_string(fastener_childtag, childline_projcode, &fasterner_projcode_str))	PrintErrorStack();
											if(BOM_line_ask_attribute_string(fastener_childtag, childline_designgrp, &fasterner_designgrp_str));

											printf("\n checkin_method_1--c.Project Code is [%s] and Design group is: [%s]\n",fasterner_projcode_str,fasterner_designgrp_str);fflush(stdout);

											//if((tc_strcmp(fasterner_projcode_str,"1111") == 0) && (tc_strcmp(fasterner_designgrp_str,"11") == 0));
											if((tc_strcmp(fasterner_projcode_str,"1111")==0 && tc_strcmp(fasterner_designgrp_str,"11")==0))
											{
												printf("\n checkin_method_1--c.Parent[%d] ItemID is [%s] and ItemRevision is: [%s]\n",child_cnt+1,fastener_ItemID_str,fasterner_ItemRev_str);fflush(stdout);

												if(strstr(info_Obspno_array,fastener_ItemID_str) != NULL)
												{
													printf("\n checkin_method_1--c.fastener_ItemID_str & info_Obspno [%s=%s]\n",fastener_ItemID_str,info_Obspno); fflush(stdout);

													printf("\nMatch Flag if =========>>>>\n");
													if (AOM_ask_value_string(ALTPartIND_objs,"t5_Proalpno",&info_ALTPartNo));
													printf("\nAlternate Part Number is [%s]\n",info_ALTPartNo); fflush(stdout);

													if(tc_strcmp(info_ALTPartNo,"") != 0)
													{
														match_flag1 = 2;
														printf("\n checkin_method_1--c.match_flag1 Alternate Part Number is present = %d\n",match_flag1); fflush(stdout);
														Fasteners_chld_A=(char *)MEM_alloc(200);
														tc_strcpy(Fasteners_chld_A,"");
														tc_strcat(Fasteners_chld_A,info_ALTPartNo);
														printf("\n checkin_method_1--c.Alternate Part Number is present = %s\n",Fasteners_chld_A); fflush(stdout);
													}
												}
												else
												{
													match_flag2 = 1;
													printf("\n checkin_method_1--c.match_flag unable to check in Part Number = %d \n",match_flag2); fflush(stdout);
													Fasteners_chld=(char *)MEM_alloc(200);
													tc_strcpy(Fasteners_chld,"");
													tc_strcat(Fasteners_chld,fastener_ItemID_str);
													printf("\n checkin_method_1--c.unable to check in Part Number = %s \n",Fasteners_chld); fflush(stdout);
												}
											}
										}
										//Project Code and Design Group loop
									}

									printf("\nMatch Flag =========>>>> [%d = %d]\n",match_flag2,match_flag1);

									if (match_flag1 == 2)
									{
										tc_strcpy(ErrorMsgFA,"");
										tc_strcat(ErrorMsgFA,"Part Number [");
										tc_strcat(ErrorMsgFA,fastener_ItemID_str);
										tc_strcat(ErrorMsgFA,"] has an alternate Part Number.");
										tc_strcat(ErrorMsgFA,"Kindly use [");
										tc_strcat(ErrorMsgFA,info_ALTPartNo);
										tc_strcat(ErrorMsgFA,"] and check again.");

										printf("\n\t  [%s]",ErrorMsgFA);fflush(stdout);

										EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsgFA);
										return ITK_errStore;
									}
									if (match_flag2 == 1 )
									{
										tc_strcpy(ErrorMsgF,"");
										tc_strcat(ErrorMsgF,"Part Number [");
										tc_strcat(ErrorMsgF,Fasteners_chld);
										tc_strcat(ErrorMsgF,"] is not a STANDARD FASTENER.Check-In will not be successful");

										printf("\n\t  [%s]",ErrorMsgF);fflush(stdout);

										EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsgF);
										return ITK_errStore;
									}
								}//Part Type Assembly
							} //NR LOOP
						}//CS
					}//Main Control Object Loop
					/****************************************Rohit Validation ends for Fastner related check*********************************/

						/****************************************Rohit Validation starts for Platform Name attribute*********************************/

				tag_t platform_CntrlOBJ	=	NULLTAG;
				int platform_entries = 1;
				int	plat_found	=	0;
				tag_t *CntrlObject_plat	=	NULLTAG;

				if(QRY_find("Control Objects...",&platform_CntrlOBJ));
				printf("\n\nPlatform Query Found\n\n");	fflush(stdout);

				char *qry_platcntrl[1] = {"SYSCD"};

				char **qry_valuesplat = (char **) MEM_alloc(10 * sizeof(char *));

				qry_valuesplat[0] = "platform_checkin";

				if(QRY_execute(platform_CntrlOBJ, platform_entries, qry_platcntrl, qry_valuesplat, &plat_found, &CntrlObject_plat));
				printf("\n\n  Fastener SYSCD :%d\n",plat_found);	fflush(stdout);
				if(plat_found>0)
				{
					tag_t	user_tagPP		=	NULLTAG;
					tag_t	PP_CntrlOBJ		=	NULLTAG;
					tag_t	*CntrlObject_PP	=	NULLTAG;

					char		*useridPP		=	NULL;
					char		*usernamePP				=	NULL;
					char		*homeSitePP			=	NULL;
					char		*qry_PPcntrl[1]		= {"SYSCD"};
					char		**qry_valuesPP		= (char **) MEM_alloc(10 * sizeof(char *));
					qry_valuesPP[0]					= "PartPlatform";
					char		*pp_itemid			=	NULL;
					char		*pp_revisionid		=	NULL;
					char		*pp_parttype		=	NULL;
					char		*pp_PartPlatform	=	NULL;
					char		*info1PP			=	NULL;
					char		*info2PP			=	NULL;
					char		*pp_projectcode		=	NULL;

					int PP_entries			=	1;
					int	PP_found			=	0;
					int pp					=	0;

					POM_get_user(&usernamePP,&user_tagPP);
					SA_ask_user_identifier2 (user_tagPP,&useridPP);
					printf ("\n Logged in user for Platform attribute updation is :[%s] [%s] ",useridPP,usernamePP);fflush(stdout);
					AOM_UIF_ask_value(user_tagPP,"fnd0home_site",&homeSitePP);
					printf("\n Logged in fnd0home_site for Platform attribute updation is : [%s]",homeSitePP);fflush(stdout);

					if (strcmp(homeSitePP,"CV_Production")==0)
					{
						printf("Inside our home site - CVPROD"); fflush(stdout);

						if(AOM_ask_value_string(objTag,"item_id",&pp_itemid));
						if(AOM_ask_value_string(objTag,"item_revision_id",&pp_revisionid));
						if(AOM_ask_value_string(objTag,"t5_PartType",&pp_parttype));
						if(AOM_ask_value_string(objTag,"t5_Platform",&pp_PartPlatform));
						if(AOM_ask_value_string(objTag,"t5_ProjectCode",&pp_projectcode));

						if((tc_strcmp(pp_parttype,"V")==0))
						{
							printf("\nPart Type is Vehicle hence inside loop\n"); fflush(stdout);

							if(tc_strcmp(pp_PartPlatform,"")==0)
							{
								printf("\n\nPart Platform cannot be NULL/NA for vehicle. Kindly slect value from LOV only."); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Platform cannot be NULL/NA for vehicle. Kindly slect value from LOV only.");
								return ITK_errStore;

							}
							else
							{
								if(QRY_find("Control Objects...",&PP_CntrlOBJ));
								printf("\n\nPart Platform Query Found\n\n");	fflush(stdout);

								if(QRY_execute(PP_CntrlOBJ, PP_entries, qry_PPcntrl, qry_valuesPP, &PP_found, &CntrlObject_PP));
								printf("\n\n  Part Platfrom SYSCD :[%d]\n",PP_found);	fflush(stdout);

								for(pp = 0; pp < PP_found; pp++)
								{
									if(AOM_ask_value_string(CntrlObject_PP[pp],"t5_Userinfo1",&info1PP));
									if(AOM_ask_value_string(CntrlObject_PP[pp],"t5_Userinfo2",&info2PP));
									printf("\nFor Part platform Info 1 and and Info 2 values are [%s] and [%s]\n",info1PP,info2PP); fflush(stdout);

									if((tc_strcmp(info1PP,pp_PartPlatform)==0))
									{
										if(tc_strstr(info2PP,pp_projectcode) == NULL)
										{
											printf("\n\nPlatform and Project Code does not match."); fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Platform and Project Code does not match.");
											return ITK_errStore;
										}
										else
										{
											printf("Vehicle can be checked-in as Platform name and Project code matches"); fflush(stdout);
											break;
										}
									}
								}

							}
						}

					}
				}

	/****************************************Rohit Validation ends for Platform Name attribute*********************************/


					char* Item_id_Key=NULL;
					AOM_ask_value_string(objTag,"item_id",&Item_id_Key);
					printf("\n checkin_method_1--c.Item_id_Key   :<%s> <%d>",Item_id_Key,strlen(Item_id_Key));fflush(stdout);

					if (strlen(Item_id_Key)==12)
					{
						if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0))
						{
							printf("\n	Keyword description :%s",sCatName);fflush(stdout);
							if((tc_strcmp(sCatName,"")==0) || (strcmp(sCatName,"")==0) || (strlen(sCatName)<=0))
							{
								//Rohit

								tag_t	cab_CntrlOBJ			=	NULLTAG;
								tag_t	*CntrlObject_swp		=	NULLTAG;
								tag_t	*CntrlObject_cab		=	NULLTAG;
								tag_t	role_tag				=	NULLTAG;

								int		cab_entries				=		1;
								int		cab_found				=		1;

								char	*role_name				=	NULL;

								char *qry_cab[1] = {"SYSCD"};

								char **qry_valuescab = (char **) MEM_alloc(10 * sizeof(char *));
								qry_valuescab[0] = "CAB_val";

								if(QRY_find("Control Objects...",&cab_CntrlOBJ));
								if(QRY_execute(cab_CntrlOBJ, cab_entries, qry_cab, qry_valuescab, &cab_found, &CntrlObject_cab));
								printf("\n\n  CAB Control Object SYSCD :[ %d ]\n",cab_found);	fflush(stdout);

								if(cab_found > 0)
								{
									if(SA_ask_current_role(&role_tag));
									if(SA_ask_role_name2(role_tag,&role_name));
									printf("\n For CAB Role , user has set session to == [%s] ", role_name);

									if (tc_strstr(role_name,"CAB") == NULL )
									{
										printf("\n checkin_method_1--c.For  Part [%s]  Keyword description cannot be NULL: TSD\n",Item_id);fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description cannot be NULL for parttype Assembly and Component");
										return ITK_err;
									}
								}
							}
							else
							{
								printf("\n	Keyword description :%s, Design Group : %s",sCatName,sDesignGrp);fflush(stdout);
								char *qry_entries[2] = {"Name","ext_1"};
								int n_entries= 2,n_found;
								tag_t query = NULLTAG, *cntr_objects = NULL;
								char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

								qry_values[0] = sCatName ;
								qry_values[1] = sDesignGrp;
								QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query);
								QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects);
								printf("\nKeyword n_found:%d", n_found);fflush(stdout);
								if(n_found==0)
								{
									//mbb start

									if(QRY_find("ControlObjects", &KeyCtrObjQry));
									if (KeyCtrObjQry)
									{
										printf("\n checkin_method_1--c.KeyCtrObjQry query Found \n");fflush(stdout);

										QryValue2[0] = "KeyCtrNew" ;
										if(QRY_execute(KeyCtrObjQry, QryEntryCnt, QryEntry, QryValue2, &CntlObjCnt2, &CntObj_Tag2));
									}
									else
									{
										printf("\n checkin_method_1--c.KeyCtrObjQry query Not Found \n");fflush(stdout);
									}

									printf("\n checkin_method_1--c.KeyCtrNew count = [%d] = \n",CntlObjCnt2);fflush(stdout);

									if(CntlObjCnt2>0)
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description is not valid for Part No Design Group. Change the session Design Group as per Part No and then update the Keyword Description.");
										return ITK_err;
									}
									else
									{
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description for Design Revision is not matched as per given Design Group of Design Revision");
										return ITK_err;
									}
									//mbb stop
								}
							}
						}
					}

					char* sPartColInd=NULL;
					if( AOM_ask_value_string(objTag,"t5_ColourInd",&sPartColInd)!=ITK_ok);PrintErrorStack();
					printf("\n	color indicator :%s",sPartColInd);fflush(stdout);

					if((tc_strcmp(sPartColInd,"Y")==0))
					{
					printf("\n	color indicator of part is Y");fflush(stdout);
					char* sPrtCompCode=NULL;
					if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&sPrtCompCode)!=ITK_ok);PrintErrorStack();
					if(tc_strcmp(sPrtCompCode,"")==0)
					{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"For Color Indicator 'Y', COMP CODE should not be NULL");
					return ITK_err;
					}
					}
					if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0 || tc_strcmp(sPartType1,"D")==0) && strlen(Item_id)==12)
					{
					// If Design Revision Number - XXXX XX 16 XX XX
					ThirdBarrel = subString(Item_id,6,2);
					printf("\nPart [%s] ThirdBarrel [%s] SpareCriteria [%s]\n", Item_id,ThirdBarrel,SpareCriteria1);fflush(stdout);

					if(tc_strcmp(ThirdBarrel,"16")==0 && (tc_strcmp(SpareCriteria1,"TSD")!=0 || strlen(SpareCriteria1)==0))
					{
					//Hard Check To Select TSD
					printf("\nIf Part [%s] and ThirdBarrel [%s] Please select SpareCriteria Value : TSD\n",Item_id,ThirdBarrel);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Parts Numbers Third Barrel is 16, SpareCriteria Value Should be TSD : TML specification drawing");
					return ITK_err;
					}
					}

					/*** modification by Anand starts ***/

					//Material Thickness cannot be NULL for part type Component
					//Material thickness can be only Number or NA
					//DOT should not be more than one
					if((tc_strcmp(MThickness,"")==0))
					{
					printf("\n checkin_method_1--c.Material Thickness is NULL \n");fflush(stdout);

					if((strcmp(sPartType1,"C")==0))
					{
					//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness cannot be NULL for part type Component.");
					//return ITK_errStore;
					tc_strcat (CompAttributeNullList, ", Material Thickness" );
					Comperrorflag = Comperrorflag + 1;
					}

					}
					else
					{
					if(tc_strcmp(MThickness,"NA"))
					{
					TempVal =strcpy(TempVal,MThickness);

					for(y=0;y<tc_strlen(MThickness);y++)
					{
					if (TempVal[y] < 48 || TempVal[y] > 57)
					{	if (TempVal[y] == 46)
					{
						counter1++;
					}else
					{
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness need to have only numbers or it can be NA.");
						return ITK_errStore;
					}
					}
					}

					if (counter1>0 && counter1<2 && tc_strlen(MThickness)>0 && tc_strlen(MThickness)<2)
					{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Material Thickness need to have only numbers or it can be NA.");
					return ITK_errStore;
					}

					if(counter1 >1)
					{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"DOT should not be more than one for Material Thickness");
					return ITK_errStore;
					}

					}

					}


					if ( Comperrorflag > 0 )
					{
					printf("\n checkin_method_1--c.Component.NULL attributes : %s",CompAttributeNullList);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,CompAttributeNullList);
					return ITK_errStore;

					}



					//If Part Category is BTS and Spare Indicator is True, so Party Part number is mandatory
					//if((SpareInd1==1) && tc_strcmp(SpareCriteria1,"BTS")==0 )
					if( tc_strcmp(SpareCriteria1,"BTS")==0 )
					{
					printf("\n checkin_method_1--c.Spare Criteria is BTS\n");fflush(stdout);

					if(tc_strcmp(RefPartNumber1,"")==0)
					{
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Part Category is: BTS-Built To Specification, so Party Part number is mandatory");
					return ITK_err;
					}
					}
					//for spare indicator ='Y' envelope dimension should not be null
					if( SpareInd1==1 )
					{
					printf("\n checkin_method_1--c.Spare Indicator is True\n");fflush(stdout);

					if(tc_strcmp(EnvelopeDim,"")==0)
					{
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Envelope Dimensions cannot be null if Spare Indicator is True");
					return ITK_err;
					}
					}

					if(tc_strstr(ItemDesc,"\n"))
					{
					printf("\n checkin_method_1--c.Description of Design %s \n",ItemDesc);fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"New Line charecter is not allowed in Desc field.");
					return ITK_errStore;
					}
					//Ashish

					//Mohan start

					if((tc_strlen(ItemDesc)>40) )
					{
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Please Fill Only 40 Character In Description As Per SAP/Denis Standards.");
					return ITK_errStore;

					}
					//Mohan
					if( AOM_ask_value_double(objTag,"t5_Weight",&objWeightVal)==ITK_ok)
					{
						if (objWeightVal > 0.0)
						{
							sprintf(wgtstr,"%0.3f",objWeightVal);
							printf("\n checkin_method_1--c.wgtstr  = [%s]\n", wgtstr);fflush(stdout);
							sscanf(wgtstr, "%d.%d", &left, &right);
							printf("\n checkin_method_1--c.adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
							if(right>0)
							{
								while (right%10==0)
								{
									right=right/10;
								}
							}
							printf("\n checkin_method_1--c.adk left = [%d] adk right = [%d]", left,right);fflush(stdout);
							if(left > 99999 || right > 999)
							{
								printf("\nvalidation to weight\n");fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Weight Value should have a maximum of 5 Digits before the Decimal Point and maximum of 3 digits after the Decimal Point.");
								printf("\n checkin_method_1--c.after validation to weight\n");fflush(stdout);
								return ITK_errStore;
							}
						}
					}
					/****************************************Anand Kumar Validation*********************************/

					printf("\n checkin_method_1--c.PartType-------------- :%s\n",parttyp);fflush(stdout);
					printf("\n checkin_method_1--c.PartNumber-------------- :%s\n",Item_id);fflush(stdout);
					partlength = tc_strlen(Item_id);
					printf("\n checkin_method_1--c. partlength--------> %d\n",partlength);fflush(stdout);

					//Added by ajinkya on 25 JUNE//
					printf("\n checkin_method_1--c.Part Type object is :- %s\n", parttyp);fflush(stdout);

					if((strcmp(parttyp,"Module")==0))
					{
						char *sFunOutput=NULL;

						printf("\n\t inside the part type Module condition \n");fflush(stdout);

						if( AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sModuleName14)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.updated design grp value ---->> : %s\n",sModuleName14);fflush(stdout);

						if( AOM_UIF_ask_value(objTag,"t5_ProjectCode",&sModuleName13)!=ITK_ok);PrintErrorStack();
						printf("\n checkin_method_1--c.Updated value of project code  ---->> : %s\n",sModuleName13);fflush(stdout);

						TC_write_syslog("\n Inside preaction_on_checkin:checkin_method_1:Calling FunToCheckCharLength function: \n");

						int IsValidChar = FunToCheckCharLength(objTag,&sFunOutput);

						TC_write_syslog("\n Inside preaction_on_checkin:checkin_method_1:Closing FunToCheckCharLength function: \n");

						if(IsValidChar==1)
						{
							TC_write_syslog("\n  Inside error message of IsValidChar   %d\n",IsValidChar);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,sFunOutput);
							return ITK_err;
						}

						printf("\n checkin_method_1--c.Item ID value-------------- :%s\n",Item_id);fflush(stdout);
						subpart5=subString(Item_id,0,4);
						subpart7=subString(Item_id,9,2);
						printf("\n checkin_method_1--c.Project code after string tok --->> [%s] \n",subpart5);fflush(stdout);
						printf("\n checkin_method_1--c.Design Group after string tok --->> [%s] \n",subpart7);fflush(stdout);

						if(strstr(subpart5,sModuleName13)==NULL)
						{
							printf("\n checkin_method_1--c. Inside error message of Project code   %s\n",sModuleName13);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Do Not Modify Project code Value of Module");
							return ITK_err;
						}
						else
						{
							printf("\n checkin_method_1--c. Project code values are same  \n");fflush(stdout);
						}

						if(strstr(subpart7,sModuleName14)==NULL)
						{
							printf("\n checkin_method_1--c.Inside error message of Design group   %s\n",sModuleName14);fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Do Not Modify Design Group Value of Module");
							return ITK_err;
						}
						else
						{
							printf("\n checkin_method_1--c.Design Group values are same  \n");fflush(stdout);
						}
					}
					else
					{
						printf("\n checkin_method_1--c.Part Type object is NOT MODULE :- %s\n", parttyp);fflush(stdout);
					}
					//end on 25 June//

					//start TPL validation for having only numbers in first 8 Digits
					//if(tc_strcmp(parttyp,"T")==0 && partlength ==11)
					//{
					//	FirstEightDig=malloc(15);
					//	FirstEightDig=subString(Item_id,0,8);
					//	printf("\n checkin_method_1--c. Kumar Anand1--------> %s\n", FirstEightDig);fflush(stdout);
					//
					//	ir=tc_strlen(FirstEightDig);
					//	printf("\n checkin_method_1--c. Kumar Anand1--------> %d\n",ir);fflush(stdout);
					//
					//	for(im=0;im<ir;im++)
					//	{
					//		PrtNumTplobo = FirstEightDig[im];
					//		printf("\n checkin_method_1--c.Ascii Values of this string is-->%d\n",PrtNumTplobo);fflush(stdout);
					//
					//		if(PrtNumTplobo>=48 && PrtNumTplobo<=57)
					//		{
					//			printf("\n checkin_method_1--c. inside if loop-------->\n");fflush(stdout);
					//		}
					//		else
					//		{
					//			printf("\n checkin_method_1--c. inside else loop-------->\n");fflush(stdout);
					//			EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Creation of Assembly with Part Type 'TPL' should contain only Numbers in first 10 Digits.");
					//			return ITK_errStore;
					//		}
					//	}
					//}
					//Amol Kale
					//validations
					/*********************** Adi - Synch from Catia  *********************/
					qry_values[0] = itemId ;

					if(QRY_find("ControlObjects", &queryTag));
					if (queryTag)
					{
						printf("\n checkin_method_1--c.Found Query CMI \n");fflush(stdout);

						qry_values[0] = "IsCatSynch" ;
						ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &CntrlObjectTag));
					}
					else
					{
						printf("\n checkin_method_1--c.Not Found Query CMI \n");fflush(stdout);
					}

					printf(" \n resultCount :%d:", resultCount); fflush(stdout);
					if(resultCount>0)
					{
						printf("\n checkin_method_1--c.Adi Synch from Catia Validation-------------- \n");fflush(stdout);

						if(GRM_list_secondary_objects_only(objTag,reln_type,&jj,&cmi_objects)!=ITK_ok)PrintErrorStack();
						printf("\n checkin_method_1--c.cmi_objects :%d\n",jj);fflush(stdout);

						if(AOM_ask_value_string(objTag,"t5_DesignGrp",&DesignGrpCat));  //Adi 1.32
						printf("\n\t DesignGrpCat => %s\n",DesignGrpCat);fflush(stdout);//Adi 1.32
						printf("\n\t DesignGrp		 => %s\n",DesignGrp);fflush(stdout);//Adi 1.32


						if(jj>0)
						{
							for (ij= 0;ij< jj;ij++)
							{
								cmiprimary=cmi_objects[ij];

								if(TCTYPE_ask_object_type(cmiprimary,&cmiobjTypeTagDi))PrintErrorStack();
								if(TCTYPE_ask_name(cmiobjTypeTagDi,cmi_name))PrintErrorStack();

								printf("\n checkin_method_1--c.cmi_name for the input is new :%s\n",cmi_name);fflush(stdout);

								//if((tc_strcmp(cmi_name,"CMI2Product")==0)||(tc_strcmp(cmi_name,"CMI2Part")==0))
								if((strstr(DesignGrp,DesignGrpCat)!=NULL)&&((tc_strcmp(cmi_name,"CMI2Product")==0)||(tc_strcmp(cmi_name,"CMI2Part")==0))) //Adi 1.32
								{
									flag=1;
								}
							}
						}

						if(flag==1)
						{
							if( AOM_ask_value_string(objTag,"t5_IsCatSynch",&catiasynch)==ITK_ok)
							printf("\n checkin_method_1--c.catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

							if(tc_strcmp(catiasynch ,"Y")==0)
							{
								printf("\n checkin_method_1--c.part has been synched from catia--- so continue \n");fflush(stdout);
							}
							else
							{
								printf("\n checkin_method_1--c.Part has not been synchronised from Catia \n");fflush(stdout);
								//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Synchronize the part from CATIA and then try to check in");
								return ITK_errStore;
							}
						}
						else
						{
							printf("\n checkin_method_1--c.NOT A CATIA PART HENCE SKIPPING VALIDATION \n");fflush(stdout);
						}
					}
					else
					{
						printf("\n checkin_method_1--c.NO COntrol obj \n");fflush(stdout);
					}
					/************************* Adi - Synch from Catia  **************************/

					/****************************************Adi validation for party part*********************************/
					if( AOM_ask_value_logical(objTag,"t5_SpareInd",&SpareInd)==ITK_ok)
					printf("\n checkin_method_1--c.SpareInd d-------------- :%d\n",SpareInd);fflush(stdout);

					if( AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCriteria)==ITK_ok)
					printf("\n checkin_method_1--c.SpareCriteria -------------- :%s\n",SpareCriteria);fflush(stdout);

					if( AOM_ask_value_string(objTag,"t5_RefPartNumber",&RefPartNumber)==ITK_ok)
					printf("\n checkin_method_1--c.RefPartNumber -------------- :%s\n",RefPartNumber);fflush(stdout);

					if((SpareInd==1) && tc_strcmp(SpareCriteria,"BTS")==0 )
					{
						printf("\n checkin_method_1--c.222222222222222 \n");fflush(stdout);

						if(tc_strcmp(RefPartNumber,"")==0)
						{
							EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please enter a valid Party Part Number or make Spare Indicator as False");

							return ITK_errStore;
						}
					}
					/*****************************************Adi validation for party part ends*********************************/

					/*FOR PRASAD*/
					printf("\n checkin_method_1--c.before DFMEA check 222222 \n");fflush(stdout);
					if( AOM_ask_value_string(objTag,"t5_PartDFMEA",&DfmeaNumber1)==ITK_ok)
					{
						printf("\n checkin_method_1--c.in for loop for DFMEA check \n");fflush(stdout);
						//if(DfmeaNumber1)
						if(tc_strcmp(DfmeaNumber1,"")!=0)
						{
							s1 = tc_strtok(DfmeaNumber1, "//");
							s2 = tc_strtok(NULL, "/");
							s3 = tc_strtok(NULL, "/");
							s4 = tc_strtok(NULL, "/");
							s5 = tc_strtok(NULL, "/");
							s6 = tc_strtok(NULL, "/");
							s7 = tc_strtok(NULL, "/");
							s8 = tc_strtok(NULL, "/");
							s9 = tc_strtok(NULL, "/");

							printf("\n checkin_method_1--c.DFMEA ID :  %s\n",s8);fflush(stdout);

							ITK_CALL(PREF_ask_char_value("DFMEA_PATH", 0 , &DfmeapathName ));//ALIAS_TEXTPATH -name of preference  psasad = /tmp/
							printf("\n checkin_method_1--c.ALIAS_TEXTPATH issss %s\n",DfmeapathName);fflush(stdout);

							if(!DfmeapathName)
							{
								printf("\n checkin_method_1--c.ALIAS cannot access in DfmeapathName :%s\n", DfmeapathName );fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Directory not found. Please check ALIAS_TEXTPATH");
								return ITK_errStore;
							}
							printf("\n checkin_method_1--c.----------------- DFMEA check------------ \n");fflush(stdout);

							//strtxt = malloc(1500);

							printf("\n checkin_method_1--c.before shell exexute for DFMEA ------------ \n");fflush(stdout);

							tc_strcpy(strtxt1,"");
							tc_strcat(strtxt1,DfmeapathName);
							tc_strcat(strtxt1,"/");
							tc_strcat(strtxt1,"preaction_on_checkin.sh");
							tc_strcat(strtxt1," ");
							tc_strcat(strtxt1,s8);

							printf("\n checkin_method_1--c.strtxt DownloadPath DIR :%s",strtxt1);fflush(stdout);

							system(strtxt1);

							printf("\n checkin_method_1--c.after shell execute for DFMEA ------------ \n");fflush(stdout);

							//printf("\n checkin_method_1--c.ALIAS After excecuting shell : %s\n", AliasFileName);fflush(stdout);
							//: https://vzdfmeapoc02.tmindia.tatamotors.com:8092/QMS.WebContainer/module/Fmea/SystemElement/10621002/formsheet/10621002
							//tc_strcpy(Logfname1,"");
							//printf("\n checkin_method_1--c.before file read :  ------------ \n");fflush(stdout);

							tc_strcpy(Logfname1,"/tmp/svalues1.txt");
							tc_strcpy(Logfnamex,"/tmp/partlist1.txt");

							//printf("\n checkin_method_1--c.after file read :------------ \n");fflush(stdout);

							fptr1 = fopen(Logfname1,"r");
							fptrx = fopen(Logfnamex,"r");

							printf("\n checkin_method_1--c.file open :  ------------ \n");fflush(stdout);

							//while(fgets(inputline1,1500,fptr1)==NULL)
							//{
							//	printf("\n checkin_method_1--c.status found null \n");fflush(stdout);
							//	//fclose(fptr1);
							//	//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
							//	EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part has DFMEA not approved");
							//	return ITK_errStore;
							//}

							//fptr1 = fopen(Logfname1,"r");
							while(fgets(inputline1,1500,fptr1)!=NULL)
							{
								printf("\n checkin_method_1--c.inputline1234 : [%s] ------------ \n",inputline1);fflush(stdout);

								/*if (tc_strstr(inputline1,"Approved")!=NULL)
								{
								printf("\n checkin_method_1--c.DFMEA not approved \n");fflush(stdout);
								//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore, "DFMEA not approved");

								return ITK_errStore;
								}*/

								//if (tc_strstr(inputline1,"Approved")==NULL)
								if (tc_strcmp(inputline1,"PendingApproval||Approved")!=0)
								{
									printf("\n checkin_method_1--c.Part has DFMEA not approved \n");fflush(stdout);
									//fclose(fptr1);
									//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part has DFMEA not approved");
									return ITK_errStore;
									//return ITK_ok;
								}
								printf("\n checkin_method_1--c.DFMEA approved, closing the file \n");fflush(stdout);
								//fclose(fptr1);
								printf("\n checkin_method_1--c.DFMEA approved, file closed \n");fflush(stdout);
							}

							//int size1 = 0;
							//if (NULL != fptr1)
							//{
							//fseek (fptr1, 0, SEEK_END);
							//size1 = ftell(fptr1);
							//if (0 == size1)
							//{
							//printf("DFMEA not approved\n");fflush(stdout);
							//EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part Has DFMEA not approved");
							//	return ITK_errStore;
							//}
							//}
							//printf("\n checkin_method_1--c.opening file for part list \n");fflush(stdout);
							//
							//printf("\n checkin_method_1--c.file opened for part list \n");fflush(stdout);
							//
							//if (ftell(fptrx) == 0)
							//while(fgets(inputlinex,1500,fptrx)==NULL)
							//{
							//	printf("\n checkin_method_1--c.Part list is null \n");fflush(stdout);
							//	//fclose(fptrx);
							//	//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
							//	EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part not present in list, list is null");
							//	return ITK_errStore;
							//}
							//int size = 0;
							//if (NULL != fptrx)
							//	{
							//fseek (fptrx, 0, SEEK_END);
							//size = ftell(fptrx);
							//
							//if (0 == size)
							//	{
							//	printf("file is empty\n");fflush(stdout);
							//	EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part list is null");
							//		return ITK_errStore;
							//	}
							//	}
							//
							//printf("\n checkin_method_1--c.opening file for part list11 \n");fflush(stdout);
							////fptrx = fopen(Logfnamex,"r");
							//printf("\n checkin_method_1--c.file opened for part list11 \n");fflush(stdout);

							while(fgets(inputlinex,1500,fptrx)!=NULL)
							{
								printf("\n checkin_method_1--c.inputlinex1 : [%s] ------------ \n",inputlinex);fflush(stdout);

								//if (tc_strcmp(inputlinex,"PendingApproval||Approved")!=0)
								printf("\n checkin_method_1--c.Item_id...123 : [%s] ------------ \n",Item_id);fflush(stdout);


								//if(tc_strcmp(inputlinex,"") == 0)
								if(tc_strstr(inputlinex,Item_id) == NULL)
								{
									printf("\n checkin_method_1--c.Part not present in list \n");fflush(stdout);
									//fclose(fptrx);
									//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part not present in list");
									return ITK_errStore;
								}

								printf("\n checkin_method_1--c.closing file for part list11 \n");fflush(stdout);
								//fclose(fptrx);
								printf("\n checkin_method_1--c.file closed for part list11 \n");fflush(stdout);
							}
						}
					}
					//
					//}

					if( AOM_ask_value_string(objTag,"t5_PartRefDFMEA",&DfmeaNumber2)==ITK_ok)
					{
						//if(DfmeaNumber2)
						if(tc_strcmp(DfmeaNumber2,"")!=0)
						{
							ss1 = tc_strtok(DfmeaNumber2, "//");
							ss2 = tc_strtok(NULL, "/");
							ss3 = tc_strtok(NULL, "/");
							ss4 = tc_strtok(NULL, "/");
							ss5 = tc_strtok(NULL, "/");
							ss6 = tc_strtok(NULL, "/");
							ss7 = tc_strtok(NULL, "/");
							ss8 = tc_strtok(NULL, "/");
							ss9 = tc_strtok(NULL, "/");

							printf("\n checkin_method_1--c.DFMEA REF ID :  %s\n",ss8);fflush(stdout);

							ITK_CALL(PREF_ask_char_value("DFMEA_PATH", 0 , &DfmeapathName ));//ALIAS_TEXTPATH -name of preference  psasad = /tmp/
							printf("\n checkin_method_1--c.ALIAS_TEXTPATH issss %s\n",DfmeapathName);fflush(stdout);

							if(!DfmeapathName)
							{
								printf("\n checkin_method_1--c.ALIAS cannot access in DfmeapathName :%s\n", DfmeapathName );fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Directory not found. Please check ALIAS_TEXTPATH");
								return ITK_errStore;
							}

							//strtxt = malloc(1500);

							tc_strcpy(strtxt2,"");
							tc_strcat(strtxt2,DfmeapathName);
							tc_strcat(strtxt2,"/");
							tc_strcat(strtxt2,"preaction_on_checkin.sh");
							tc_strcat(strtxt2," ");
							tc_strcat(strtxt2,ss8);

							printf("\n checkin_method_1--c.strtxt DownloadPath DIR :%s",strtxt2);fflush(stdout);

							system(strtxt2);

							//printf("\n checkin_method_1--c.ALIAS After excecuting shell : %s\n", AliasFileName);fflush(stdout);
							//: https://vzdfmeapoc02.tmindia.tatamotors.com:8092/QMS.WebContainer/module/Fmea/SystemElement/10621002/formsheet/10621002
							//tc_strcpy(Logfname2,"");
							//tc_strcpy(Logfname2,"/tmp/svalues1.txt");
							//fptr2 = fopen(Logfname2,"r");

							printf("\n checkin_method_1--c.before file read :  ------------ \n");fflush(stdout);

							tc_strcpy(Logfname2,"/tmp/svalues1.txt");
							tc_strcpy(Logfnamey,"/tmp/partlist1.txt");

							printf("\n checkin_method_1--c.after file read :  ------------ \n");fflush(stdout);

							fptr2 = fopen(Logfname2,"r");
							fptry = fopen(Logfnamey,"r");


							printf("\n checkin_method_1--c.file open :  ------------ \n");fflush(stdout);

							while(fgets(inputline2,1500,fptr2)!=NULL)
							{
								printf("\n checkin_method_1--c.inputline5678 : [%s] ------------ \n",inputline2);fflush(stdout);

								//while(fgets(inputline2,1500,fptr2)!=NULL)
								//{
								if (tc_strcmp(inputline2,"PendingApproval||Approved")!=0)
								{
									printf("\n checkin_method_1--c.Part has reference DFMEA not approved \n");fflush(stdout);
									//	fclose(fptr2);
									//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part has reference DFMEA not approved");

									return ITK_errStore;
								}
								//fclose(fptr2);
							}

							while(fgets(inputliney,1500,fptry)!=NULL)
							{
								printf("\n checkin_method_1--c.inputliney1 : [%s] ------------ \n",inputliney);fflush(stdout);

								//if(tc_strstr(inputliney,".cgr") != NULL)
								printf("\n checkin_method_1--c.Item_id...456 : [%s] ------------ \n",Item_id);fflush(stdout);

								if(tc_strstr(inputliney,Item_id) == NULL)
								{
									printf("\n checkin_method_1--c.Part not present in list \n");fflush(stdout);
									//	fclose(fptry);
									//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
									EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Part not present in list");

									return ITK_errStore;
								}
								//fclose(fptry);
							}
						}
					}
					/*changed for eDFMEA, by Prasad*/

					if( AOM_ask_value_string(objTag,"t5_DrawingInd",&DrnInd)==ITK_ok);
					int lenStrInt = 0;
					//Yogendra
					//if drawing indicator is N and CATDrawing file is attached then it should not be allowd to check in.
					//If drawing indicator is D and CATDrawing file Is not attached then it should not allowd to check in.

					//if( strcmp(DrnInd,"")==0 )
					//{
					printf("\n checkin_method_1--c.TCDCTrying to set Drawing Ind since null ");fflush(stdout);
					printf("\n checkin_method_1--c.TCDCcounter :%d: ",counter);fflush(stdout);
					printf("\n checkin_method_1--c.counterPDF :%d: ",counterPDF);fflush(stdout);
					printf("\n checkin_method_1--c.DrnInd:%s: ",DrnInd);fflush(stdout);

					//Rajendra- Set drawing indicator & drawing number for part as per attached drawing/reference drawing.
					if((counter > 0) || (counterPDF > 0))
					{
						//if( strcmp(DrnInd,"")==0 || strcmp(DrnInd,"N")==0 || strcmp(DrnInd,"A")==0 )
						//{

						printf("\n checkin_method_1--c.TCDCDrnInd ");fflush(stdout);

						if(AOM_lock(objTag))PrintErrorStack();
						if(AOM_set_value_string(objTag,"t5_DrawingInd","D"))PrintErrorStack();
						if(AOM_save(objTag))PrintErrorStack();
						if(AOM_unlock(objTag))PrintErrorStack();
						//}

						printf("\n checkin_method_1--c.Item_id :%s: ",Item_id);fflush(stdout);
						printf("\n checkin_method_1--c.newPatRev1 :%s: ",newPatRev);fflush(stdout);
						printf("\n checkin_method_1--c.newPatSeq1 :%s: ",newPatSeq);fflush(stdout);
						printf("\n checkin_method_1--c.drawingnum :%s: ",drawingnum);fflush(stdout);
						printf("\n checkin_method_1--c.bl_objectString :%s: ",bl_objectString);fflush(stdout);
						if(drawingnum!=NULL)
						{
							if(tc_strstr(drawingnum,";")!=NULL)
							{
								oDrwNum=(char *) MEM_alloc(30);
								strcpy(oDrwNum,"");
								strcpy(oDrwNum,drawingnum);
								oDrwNum1=strtok(oDrwNum,"/");
								oDrwNum2=strtok(NULL,";");
								oDrwNum3=strtok(NULL,";");

								printf("\n checkin_method_1--c.oDrwNum: [%s] ",oDrwNum);fflush(stdout);
								printf("\n checkin_method_1--c.oDrwNum1:[%s] ",oDrwNum1);fflush(stdout);
								printf("\n checkin_method_1--c.oDrwNum3:[%s] ",oDrwNum2);fflush(stdout);
								printf("\n checkin_method_1--c.oDrwNum3:[%s] ",oDrwNum3);fflush(stdout);
							}
							else
							{
								oDrwNum1=(char *) MEM_alloc(30);
								strcpy(oDrwNum1,"");
								strcpy(oDrwNum1,drawingnum);
							}
						}
						else
						{
							oDrwNum1=(char *) MEM_alloc(30);
							strcpy(oDrwNum1,"");
						}
						printf("\n checkin_method_1--c.oDrwNum1:[%s] ",oDrwNum1);fflush(stdout);
						if(tc_strcmp(Item_id,oDrwNum1)==0)
						{
							printf("\n checkin_method_1--c.Drwaing num Same as Part Num [%s]=[%s] ",Item_id,oDrwNum1);fflush(stdout);

							//strcpy(tmpDrwNum,bl_objectString);
							//tmpDrwNum1=strtok(tmpDrwNum,"/");
							//tmpDrwNum2=strtok(NULL,";");
							//tmpDrwNum3=strtok(NULL,"(");
							//tmpDrwNum4=strtok(NULL,"(");
							//
							//printf("\ntmpDrwNum1:%s\n",tmpDrwNum1);fflush(stdout);
							//printf("\ntmpDrwNum2:%s\n",tmpDrwNum2);fflush(stdout);
							//printf("\ntmpDrwNum3:%s\n",tmpDrwNum3);fflush(stdout);
							//printf("\ntmpDrwNum4:%s\n",tmpDrwNum4);fflush(stdout);
							drwnum=(char *) MEM_alloc(30);
							strcpy(drwnum,"");
							strcpy(drwnum,Item_id);
							strcat(drwnum,"_");
							strcat(drwnum,newPatRev);
							strcat(drwnum,"_");
							strcat(drwnum,newPatSeq);
							lenStrInt=tc_strlen(Item_id)+tc_strlen(newPatRev)+tc_strlen(newPatSeq)+2;
							printf("\n checkin_method_1--cc.drwnum :%s: lenStrInt: [%d]",drwnum,lenStrInt);fflush(stdout);
						}
						else
						{
							printf("\n checkin_method_1--c.Ref Drwaing num ");fflush(stdout);
							if(oDrwNum1!=NULL)
							{
								ITK_CALL(ITEM_find_item(oDrwNum1,&ref_item));

								if(ref_item)
								{
									ITK_CALL(ITEM_ask_latest_rev(ref_item,&LatestRev));
									if(AOM_ask_value_string(LatestRev,"object_string",&ref_objectString));
									if( AOM_ask_value_string(LatestRev,"item_id",&RefItem_id)!=ITK_ok)PrintErrorStack();

									ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&RefRevSeq));

									printf("\n checkin_method_1--c.ref_objectString :%s: ", ref_objectString);fflush(stdout);
									printf("\n checkin_method_1--c.RefItem_id :%s: ", ref_objectString);fflush(stdout);
									printf("\n checkin_method_1--c.TCDCAOM_UIF_ask_value RefRevSeq :%s: ", RefRevSeq);fflush(stdout);

									//tc_strcpy ( cDescRevision, desc.revision_id );
									//printf("\ncDescRevision:%s",cDescRevision);
									//newPatRev = strtok ( cDescRevision, ";" );
									RefPatRev = strtok ( RefRevSeq, ";" );
									RefPatSeq = strtok ( NULL, ";" );

									printf("\n checkin_method_1--cd.RefPatRev: [%s] RefPatSeq: [%s]",RefPatRev ,RefPatSeq);fflush(stdout);

									//strcpy(tmpDrwNum,ref_objectString);
									//tmpDrwNum1=strtok(tmpDrwNum,"/");
									//tmpDrwNum2=strtok(NULL,";");
									//tmpDrwNum3=strtok(NULL,"(");
									//tmpDrwNum4=strtok(NULL,"(");
									//printf("\ntmpDrwNum1:%s\n",tmpDrwNum1);fflush(stdout);
									//printf("\ntmpDrwNum2:%s\n",tmpDrwNum2);fflush(stdout);
									//printf("\ntmpDrwNum3:%s\n",tmpDrwNum3);fflush(stdout);
									//printf("\ntmpDrwNum4:%s\n",tmpDrwNum4);fflush(stdout);
									drwnum=(char *) MEM_alloc(30);
									strcpy(drwnum,"");
									strcpy(drwnum,RefItem_id);
									strcat(drwnum,"_");
									strcat(drwnum,RefPatRev);
									strcat(drwnum,"_");
									strcat(drwnum,RefPatSeq);
									lenStrInt=tc_strlen(RefItem_id)+tc_strlen(RefPatRev)+tc_strlen(RefPatSeq)+2;
									printf("\n checkin_method_1--ce.drwnum: [%s] lenStrInt: [%d]",drwnum,lenStrInt);fflush(stdout);
								}
							}
							else
							{
								drwnum=(char *) MEM_alloc(30);
								strcpy(drwnum,"");
								printf("\n checkin_method_1--Value of oDrwNum1--A is NULL\n");fflush(stdout);
							}
						}
						if((tc_strlen(drwnum)>5) && (drwnum!=NULL))
						{
							printf("\n checkin_method_1--ce.drwnum: [%s] lenStrInt: [%d] -- Before Drawing No Set",drwnum,lenStrInt);fflush(stdout);
							if(AOM_lock(objTag))PrintErrorStack();
							if(AOM_set_value_string(objTag,"t5_DrawingNo",drwnum))PrintErrorStack();
							if(AOM_save(objTag))PrintErrorStack();
							if(AOM_unlock(objTag))PrintErrorStack();
							printf("\n checkin_method_1--ce.drwnum: [%s] lenStrInt: [%d] -- After Drawing No Set",drwnum,lenStrInt);fflush(stdout);
						}
					}
					else
					{
						if(tc_strcmp(DrnInd,"A")==0 )// Added by Rajendra TZ 1.28
						{
							printf("\n checkin_method_1--d.Item_id :%s: ",Item_id);fflush(stdout);
							printf("\n checkin_method_1--d.Item_id :%s: ",drawingnum);fflush(stdout);
							printf("\n checkin_method_1--d.newPatRev1:%s",newPatRev);fflush(stdout);
							printf("\n checkin_method_1--d.newPatSeq1:%s",newPatSeq);fflush(stdout);
							printf("\n checkin_method_1--d.bl_objectString :%s: ",bl_objectString);fflush(stdout);

							//strcpy(tmpDrwNum,bl_objectString);
							//tmpDrwNum1=strtok(tmpDrwNum,"/");
							//tmpDrwNum2=strtok(NULL,";");
							//tmpDrwNum3=strtok(NULL,"(");
							//tmpDrwNum4=strtok(NULL,"(");
							//
							//printf("\ntmpDrwNum1:%s ",tmpDrwNum1);fflush(stdout);
							//printf("\ntmpDrwNum2:%s ",tmpDrwNum2);fflush(stdout);
							//printf("\ntmpDrwNum3:%s ",tmpDrwNum3);fflush(stdout);
							//printf("\ntmpDrwNum4:%s ",tmpDrwNum4);fflush(stdout);
							drwnum=(char *) MEM_alloc(30);
							strcpy(drwnum,"");
							strcpy(drwnum,Item_id);
							strcat(drwnum,"_");
							strcat(drwnum,newPatRev);
							strcat(drwnum,"_");
							strcat(drwnum,newPatSeq);
							lenStrInt=tc_strlen(Item_id)+tc_strlen(newPatRev)+tc_strlen(newPatSeq)+2;
							printf("\n checkin_method_1--cc.drwnum :%s: lenStrInt: [%d]",drwnum,lenStrInt);fflush(stdout);

							printf("\n checkin_method_1--d.drwnum:%s: ",drwnum);fflush(stdout);
							printf("\n checkin_method_1--d.DrnInd :%s: ",DrnInd);fflush(stdout);
							if(AOM_lock(objTag))PrintErrorStack();
							if(AOM_set_value_string(objTag,"t5_DrawingInd","A"))PrintErrorStack();
							if(AOM_set_value_string(objTag,"t5_DrawingNo",drwnum))PrintErrorStack();
							if(AOM_save(objTag))PrintErrorStack();
							if(AOM_unlock(objTag))PrintErrorStack();
						}
						else
						{
							printf("\n checkin_method_1--e.DrnInd :%s: ",DrnInd);fflush(stdout);
							if(tc_strcmp(DrnInd,"D")==0)
							{
								// Below code is commented on 03/08/2023 by Aadarsh kumar, Requirment came from Subrata sir and user intractive pop up is added.
								if(AOM_lock(objTag))PrintErrorStack();
								//if(AOM_set_value_string(objTag,"t5_DrawingInd","N"))PrintErrorStack();
								if(AOM_set_value_string(objTag,"t5_DrawingNo",""))PrintErrorStack();
								if(AOM_save(objTag))PrintErrorStack();
								if(AOM_unlock(objTag))PrintErrorStack();

								printf("\n checkin_method_1--e.Error=Part has Drawing indicator D and Drawing is not attached to this part. if you want to continue please update Drawing indicator to N or attach Drawing Dataset. For Drawing indicator = N, SOR will not create or ask to create.\n\n");fflush(stdout);
								//printf("\n checkin_method_1--e.Error=Part has Drawing indicator D and Drawing is not attached to this part. if you want to continue please update Drawing indicator to N or attach Drawing Dataset. For Drawing indicator = N, SOR will not create or ask to create.\n\n");fflush(stdout);

								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_warning,ITK_err,"Part has Drawing indicator D and Drawing is not attached to this part. if you want to continue please update Drawing indicator to N or attach Drawing Dataset. For Drawing indicator = N, SOR will not create or ask to create.");
								return ITK_errStore;
							}
							else if(tc_strcmp(DrnInd,"N")==0)
							{
								if( AOM_ask_value_string(objTag,"t5_DrawingNo",&DrwNo)==ITK_ok)
								printf("\n checkin_method_1--e.DrwNo [%s] ",DrwNo);fflush(stdout);
								if (DrwNo != NULL)
								{
									if(AOM_lock(objTag))PrintErrorStack();
									printf("\t---setting Drawing number to NULL for DrwInd=N ....\n");fflush(stdout);
									if(AOM_set_value_string(objTag,"t5_DrawingNo",""))PrintErrorStack();
									if(AOM_save(objTag))PrintErrorStack();
									if(AOM_unlock(objTag))PrintErrorStack();
								}
							}
						}
						//		printf("\nTCDCThere is No CATDrawing. ");fflush(stdout);
						////	EMH_store_error_s1(EMH_severity_warning,ITK_err,"Drawing indicator updated to 'N' since no Drawing file attached.");
						////	errorflag=errorflag+1;
						//	}
						//
						//	if( strcmp(DrnInd,"D")==0 )
						//	{
						//		printf("\nTCDCThere is No CATDrawing. ");fflush(stdout);
						//		//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Drawing Indicator=D, You must attach drawing or update to 'N'");
						//		//return ITK_errStore;
						//		errorflag=errorflag+1;
						//	}
					}

					/*****Start code to update Colour Ind and Compcode for APL Part TZ 1.42*******/
					printf("\n checkin_method_1--c.PartType APL-------------- :%s ",parttyp);fflush(stdout);
					printf("\n checkin_method_1--c.PartNumber APL-------------- :%s ",Item_id);fflush(stdout);

					WSOM_clear_search_criteria(&criteria_control);
					strcpy(criteria_control.name,"CheckinAPL");
					strcpy(criteria_control.class_name,"T5_ControlObject");

					status = WSOM_search(criteria_control, &control_number_found, &list_of_WSO_cntrl_tags);
					printf("\n checkin_method_1--c.control_number_found->CheckinAPL : %d",control_number_found);fflush(stdout);

					if (control_number_found>0)
					{
						ITKCALL(SA_ask_current_role(&CurrentRoleTag));
						ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
						printf("\n checkin_method_1--c.roleNameAPL : %s ",roleName); fflush(stdout);

						tc_strcpy (CheckedCompApl, "Comp-code and Colour Indicator updated for APL Part(Stage-Assembly/Module) respectively...");

						if(strstr(roleName,"APLC") && strstr(roleName,"Planner"))
						{
							FlagLivPrj =0;
							if( AOM_ask_value_string(objTag,"item_id",&desidForAPL)!=ITK_ok);PrintErrorStack();
							printf("\n checkin_method_1--c.desidForAPL is  = [%s]\n", desidForAPL);fflush(stdout);

							if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypAPL)!=ITK_ok)   PrintErrorStack();
							printf("\n checkin_method_1--c.DesgTypAPL is  = [%s]\n", DesgTypAPL);fflush(stdout);

							if( AOM_ask_value_string(objTag,"t5_ColourInd",&sPartColIndAPL)!=ITK_ok);PrintErrorStack();
							printf("\n	sPartColIndAPL :%s\n",sPartColIndAPL);fflush(stdout);

							if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&sPrtCompCodeAPL)!=ITK_ok);PrintErrorStack();
							printf("\n	sPrtCompCodeAPL :%s\n",sPrtCompCodeAPL);fflush(stdout);

							sFrstFourChar=subString(desidForAPL,0,4);
							printf("\n checkin_method_1--c.sFrstFourChar == %s\n", sFrstFourChar);fflush(stdout);

							//added after

							control_number_foundPrj=0;
							list_of_WSO_cntrlPrj_tags=NULL;
							if(QRY_find("Control Objects...", &qryTagCntrl));
							if (qryTagCntrl)
							{
								qry_valuesCntrl[0]="PlantDML";
								qry_valuesCntrl[1]=sFrstFourChar;
								qry_valuesCntrl[2]="0";
								qry_valuesCntrl[3]="APLC";

								if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_foundPrj, &list_of_WSO_cntrlPrj_tags));

								printf("\n checkin_method_1--c.PlantDML=>control_number_foundPrj is : %d\n",control_number_foundPrj);fflush(stdout);
								if(control_number_foundPrj)
								{
									FlagLivPrj=1;
								}
								else
								{
									control_number_foundPrjA=0;
									list_of_WSO_cntrlPrjA_tags=NULL;

									qry_valuesCntrlA[0]="CompCodeAPLPrj";
									qry_valuesCntrlA[1]=sFrstFourChar;
									qry_valuesCntrlA[2]="0";
									qry_valuesCntrlA[3]="APLC";

									if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrlA, &control_number_foundPrjA, &list_of_WSO_cntrlPrjA_tags));
									printf("\n checkin_method_1--c.CompCodeAPLPrj=>control_number_foundPrjA is : %d\n",control_number_foundPrjA);fflush(stdout);
									if(control_number_foundPrjA)
									{
										FlagLivPrj=1;
									}
								}
							}
							else
							{
								printf("\n checkin_method_1--c.Control Object Query not Found \n");fflush(stdout);
							}

							printf("\n checkin_method_1--c.FlagLivPrj is : %d\n",FlagLivPrj);fflush(stdout);
							//added after
							if (FlagLivPrj==1)
							{
								if(tc_strcmp(DesgTypAPL,"M" )==0)
								{
									//5442B4Z0160001
									printf("\n checkin_method_1--c.Inside Module*****\n");fflush(stdout);
									sFourFiveChar=subString(desidForAPL,4,2);
									sNineTenChar=subString(desidForAPL,9,2);
									printf("\n checkin_method_1--c.sFourFiveChar == %s\n", sFourFiveChar);fflush(stdout);
									printf("\n checkin_method_1--c.sNineTenChar == %s\n", sNineTenChar);fflush(stdout);

									if((tc_strcmp(sFourFiveChar,"B4" )==0) && (tc_strcmp(sNineTenChar,"60" )==0))
									{
										printf("\n checkin_method_1--c.Going to Update Module*****\n");fflush(stdout);
										if((tc_strcmp(sPartColIndAPL,"Y")==0))
										{
											if(AOM_lock(objTag))PrintErrorStack();
											//if(AOM_set_value_string(objTag,"t5_PrtCatCode","CCA_X4_B4Z01"))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL"))PrintErrorStack();
											if(AOM_save(objTag))PrintErrorStack();
											if(AOM_unlock(objTag))PrintErrorStack();
											FlagLivUpd=1;
										}
										else
										{
											if(AOM_lock(objTag))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_ColourInd","Y"))PrintErrorStack();
											//if(AOM_set_value_string(objTag,"t5_PrtCatCode","CCA_X4_B4Z01"))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL"))PrintErrorStack();
											if(AOM_save(objTag))PrintErrorStack();
											if(AOM_unlock(objTag))PrintErrorStack();
											FlagLivUpd=1;
										}
									}
									else
									{
										printf("\n checkin_method_1--c.Not B4 for Module*****\n");fflush(stdout);
									}
								}

								if(tc_strcmp(DesgTypAPL,"SA" )==0)
								{
									//54426000PB1001
									printf("\n checkin_method_1--c.Inside Stage Assembly*****\n");fflush(stdout);
									sFourFiveChar=subString(desidForAPL,4,2);
									sNineTenChar=subString(desidForAPL,8,2);
									printf("\n checkin_method_1--c.sFourFiveChar == %s\n", sFourFiveChar);fflush(stdout);
									printf("\n checkin_method_1--c.sNineTenChar == %s\n", sNineTenChar);fflush(stdout);

									if((tc_strcmp(sFourFiveChar,"60" )==0) && (tc_strcmp(sNineTenChar,"PB" )==0))
									{
										printf("\n checkin_method_1--c.Going to Update SA*****\n");fflush(stdout);
										if((tc_strcmp(sPartColIndAPL,"Y")==0))
										{
											if(AOM_lock(objTag))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL"))PrintErrorStack();
											if(AOM_save(objTag))PrintErrorStack();
											if(AOM_unlock(objTag))PrintErrorStack();
											FlagLivUpd=1;
										}
										else
										{
											if(AOM_lock(objTag))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_ColourInd","Y"))PrintErrorStack();
											if(AOM_set_value_string(objTag,"t5_PrtCatCode","BODY_SHELL"))PrintErrorStack();
											if(AOM_save(objTag))PrintErrorStack();
											if(AOM_unlock(objTag))PrintErrorStack();
											FlagLivUpd=1;
										}
										//TZ 1.43

										if(control_number_foundPrjA>0)
										{
											ITKCALL(AOM_ask_value_string(objTag,"t5_MErcPartNo",&PartConsumVal));
											printf("\n checkin_method_1--c.PartConsumVal is :%s",PartConsumVal);fflush(stdout);

											if(strlen(PartConsumVal)>0)
											{
												if(strcmp(PartConsumVal,"FAIL")==0)
												{
													tc_strcat(CheckedCompApl,"\nPlease correct the GAP b/w EBOM-MBOM Module...");
												}
											}
											else
											{
												printf("\n checkin_method_1--c.Report not generated********");fflush(stdout);
												tc_strcat(CheckedCompApl,"\nHave you generated EBOM-MBOM Consumption Report? please generate the EBOM-MBOM Consumption Report...");
											}
										}
									}
									else
									{
										printf("\n checkin_method_1--c.***Not Desg-60 and PB for Stage assembly*****\n");fflush(stdout);
									}
								}
							}
							else
							{
								printf("\n checkin_method_1--c.Project is not Live*************\n");fflush(stdout);
							}
						}
						else
						{
							printf("\n checkin_method_1--c.Role is not APLC*************\n");fflush(stdout);
						}

						printf("\n checkin_method_1--c.FlagLivUpd is : %d\n",FlagLivUpd);fflush(stdout);
						if(FlagLivUpd==1)
						{
							printf("\n checkin_method_1--c.Inside Information message->APL 1.43*************\n");fflush(stdout);
							EMH_store_error_s2(EMH_severity_information, ITK_errStore, CheckedCompApl,CheckedCompApl);
							printf("\n checkin_method_1--c.Inside Information message->APL 1.43=>ITK_errStore*************[%d]\n",ITK_errStore);fflush(stdout);
							printf("\n checkin_method_1--c.Inside Information message->APL 1.43=>ITK_ok*************[%d]\n",ITK_ok);fflush(stdout);
							//return ITK_errStore;
						}
					}
					else
					{
						printf("\nCheckinAPL=>control_number_found Not Found: %d",control_number_found);fflush(stdout);
					}

					/*****Start code to update Colour Ind and Compcode for APL Part TZ 1.42*******/

					if( AOM_ask_value_string(objTag,"t5_ModelIndicator",&MdlInd)==ITK_ok)

					printf("\n checkin_method_1--d.TCDCTrying to set Model Ind since null ");fflush(stdout);
					printf("\n checkin_method_1--d.TCDCProPrtCN :%d ",ProPrtCN);fflush(stdout);
					printf("\n checkin_method_1--d.TCDCCatPrtCN :%d ",CatPrtCN);fflush(stdout);
					printf("\n checkin_method_1--d.TCDCCatPrdt :%d ",CatPrdt);fflush(stdout);
					printf("\n checkin_method_1--d.TCDCMdlInd :%s ",MdlInd);fflush(stdout);

					if( ProPrtCN > 0 ) //previously only for proasm or proprt modelind was set 15.04.2016
					//if ( ( ProPrtCN > 0 ) || ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) ) // Borkar is going to inform this discussed on 20.04.2016 in which condition he want to set model indicator
					{
						printf("\n checkin_method_1--d.TCDCProPrtCN : ");fflush(stdout);
						if ( ( strcmp(MdlInd,"")==0 )|| (strcmp(MdlInd,"N")==0 ) )
						{
							if(AOM_lock(objTag))PrintErrorStack();
							if(AOM_set_value_string(objTag,"t5_ModelIndicator","Y"))PrintErrorStack();
							if(AOM_save(objTag))PrintErrorStack();
							if(AOM_unlock(objTag))PrintErrorStack();
						}
					}
					else
					{
						printf("\ncheckin_method_1--d.TCDCelse of count of ProPrtCN : ");fflush(stdout);
						if(AOM_lock(objTag))PrintErrorStack();
						if(AOM_set_value_string(objTag,"t5_ModelIndicator","N"))PrintErrorStack();
						if(AOM_save(objTag))PrintErrorStack();
						if(AOM_unlock(objTag))PrintErrorStack();
					}
					//}

					/*printf("\nTCDC.....errorflag :: %d",errorflag);fflush(stdout);
					if ( errorflag > 0 )
					{
					printf("\nTCDC.....show error....");fflush(stdout);
					//if(EMH_store_error_s3(EMH_severity_error,ITK_errErr,Item_id,desc.revision_id,PatSeq)!=ITK_ok)PrintErrorStack();
					if(EMH_store_error_s3(EMH_severity_error,ITK_errErr,Item_id,newPatRev,newPatSeq)!=ITK_ok)PrintErrorStack();
					return ITK_errErr;
					}
					printf("\nTCDC.....no error");fflush(stdout);*/

					ITK_CALL(AOM_ask_value_string(objTag,"t5_LeftRh_Comp",&ItemLhRhInd));
					printf("\n checkin_method_1--c.LH/RH Indicator of Left Part is :: %s",ItemLhRhInd);fflush(stdout);

					if((strcmp(ItemLhRhInd,"RH CATIA")!=0) && (strcmp(ItemLhRhInd,"RH PROE")!=0))
					{
						/*************************************code to get PLMProperties.txt***********************************************/
						//ptimestamp = malloc(20);
						//ptimestamp = timestamp;
						//printf("\nTCDCtimestamp:%s",timestamp);
						//printf("\nTCDCptimestamp:%s",ptimestamp);
						printf("\n checkin_method_1--c.TCDC Test00:%s",Item_id);fflush(stdout);
						printf("\n checkin_method_1--c.TCDCItem_id:%s",Item_id);fflush(stdout);
						printf("\n checkin_method_1--c.TCDC Test01:[%s]",Item_id);fflush(stdout);
						if ( ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0) )
						{
							printf("\n checkin_method_1--c.TCDC started");
							if ( Item_id )
							{
								printf("\nTCDC Test1:%s",Item_id);fflush(stdout);

								//envName = (char *)malloc(250 * sizeof(char));
								envNameCpy = (char *)malloc(500 * sizeof(char));
								//envName = getenv("TCDC_LOGPATH");

								if(PREF_ask_char_value("TCDC_LOGPATH", 0 , &envName )!=ITK_ok)PrintErrorStack();
								printf ( "\n checkin_method_1--c.TCDCenvName:%s", envName ) ;fflush(stdout);

								if(!envName)
								{
									printf("\n checkin_method_1--c.Error-TCDCcannot access in checkin_method_1 envname:%s ", envName );fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!");
									return ITK_errStore;
								}

								/*if( stat( envName, &info ) != 0 )
								{
									printf("\nTCDCcannot access in checkin_method_1 envname:%s ", envName );fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!");
									return ITK_errStore;
								}
								else if( info.st_mode & S_IFDIR )
								{
									printf("\nTCDC%s is a directory ", envName );fflush(stdout);
								}
								else
								{
									printf("\nTCDC%s is no directory ", envName );fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH!!!!");
									return ITK_errStore;
								}*/
								//newPatRev = strtok ( desc.revision_id, ";" );
								//newPatSeq = strtok ( NULL, "_" );

								printf("\n checkin_method_1--d.newPatRev2:%s  newPatSeq2:%s",newPatRev,newPatSeq); fflush(stdout);

								strcpy(envNameCpy,envName);
								strcat(envNameCpy,"/");
								strcat(envNameCpy,Item_id);
								strcat(envNameCpy,"_");
								strcat(envNameCpy,newPatRev);
								strcat(envNameCpy,"_");
								strcat(envNameCpy, newPatSeq);
								strcat(envNameCpy,"_");
								strcat(envNameCpy,timestamp);
								printf("\n checkin_method_1--d.TCDCenvName before system is=> [%s] ", envNameCpy);fflush(stdout);
								TmpenvName = malloc(1500);
								strcpy(TmpenvName,envNameCpy);
								printf("\n checkin_method_1--d.TCDCTmpenvName=> [%s] ",envNameCpy);fflush(stdout);

								if(mkdir(envNameCpy,00777)==-1)
								{
									printf("\n checkin_method_1--d.TCDCerror in creating dir ??? \n");fflush(stdout);
								}
							}

							getTcPartDetails(&objTag,timestamp);
							/*************************************code to get PLMProperties.txt***********************************************/
							printf("\n checkin_method_1--d.TCDC FindMismatchInCATProduct.sh check file exist");fflush(stdout);
							//TcDcShellEnvName = malloc(250 * sizeof (char *) );
							//TcDcShellEnvName = getenv("TCDC_SHELL_PATH");
							//printf("\nTCDCTCDC_SHELL_PATH:%s",TcDcShellEnvName);fflush(stdout);


							if(PREF_ask_char_value("TCDC_SHELL_PATH", 0 , &TcDcShellEnvName )!=ITK_ok)PrintErrorStack();

							printf("\n checkin_method_1--d.TCDCPlease check TCDC_SHELL_PATH %s\n",TcDcShellEnvName);fflush(stdout);

							if(!TcDcShellEnvName)
							{
								printf("\n checkin_method_1--d.TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!! envname:%s\n", TcDcShellEnvName );fflush(stdout);

								EMH_store_error_s1(EMH_severity_error,ITK_errStore,"TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!!");

								return ITK_errStore;
							}

							ShellFileName = malloc(250 * sizeof (char *) );
							tc_strcpy(ShellFileName,TcDcShellEnvName);
							tc_strcat(ShellFileName,"/FindMismatchInCATProduct.sh");
							printf("\nTCDCShellFileNamePath:%s",ShellFileName);fflush(stdout);

							fpSrc = fopen(ShellFileName,"r");
							if(fpSrc)
							{
								TCDCControlFlag=1;
								printf("\n checkin_method_1--d.TCDCFindMismatchInCATProduct.sh exists.\n");fflush(stdout);
								fclose(fpSrc);
							}
							else
							{
								TCDCControlFlag=0;
								printf("\n checkin_method_1--d.TCDCError in opening the file fpSrc FindMismatchInCATProduct.sh-- DON't call TCDC programs.");fflush(stdout);
							}
							printf("\n checkin_method_1--d.TCDCTCDCControlFlagis :%d: ",TCDCControlFlag);fflush(stdout);

							if(TCDCControlFlag ==1)
							{
								if (GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)	PrintErrorStack();

								printf("\n checkin_method_1--d.TCDCIn method_1:  checking in n_attchs after GRM_list_secondary_objects_only = [%d]", n_attchs);fflush(stdout);
								if(n_attchs>0)
								{
									/*if (Item_id)
									{
										envName = malloc(1500);
										sprintf(envName,"%s",getenv("TCDC_LOGPATH"));///home/cmitest/plmdownload/CATProductMismatch


										printf("\nTCDCPlease check TCDC_LOGPATH %s\n",envName);fflush(stdout);

										if( stat( envName, &info ) != 0 )
										{
											printf("\nTCDCcannot access %s\n", envName );fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
											return ITK_errStore;
										}
										else if( info.st_mode & S_IFDIR )
										{
											printf("\nTCDC%s is a directory\n", envName );fflush(stdout);
										}
										else
										{
											printf("\nTCDC%s is no directory\n", envName );fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Staging directory not found. Please check TCDC_LOGPATH");
											return ITK_errStore;
										}

										strcat(envName,"/");
										strcat(envName,Item_id);
										strcat(envName,"_");
										strcat(envName,desc.revision_id);
										strcat(envName,"_");
										strcat(envName, PatSeq);
										strcat(envName,"_");
										strcat(envName,timestamp);
										printf("\nTCDCenvName before system is=>%s\n", envName);fflush(stdout);
										TmpenvName=malloc(1500);
										strcpy(TmpenvName,envName);
										printf("\nTCDCTmpenvName  is:%s\n",TmpenvName);fflush(stdout);

										if(mkdir(envName,00777)==-1)
										{
											printf("\nTCDCerror in creating dir\n");fflush(stdout);

										}
									}*/
									if(Item_id)
									{
										tag_t *tags_found = NULL;
										int n_tags_found= 0;

										attrs[0] ="item_id";
										values[0] = (char *)Item_id;
										printf("\n checkin_method_1--d.TCDCvalues[0] for parent is  :[%s]",values[0]);fflush(stdout);

										//if(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found) !=ITK_ok)PrintErrorStack();
										//MEM_free(attrs);
										//MEM_free(values);
										//if (n_tags_found == 0)
										//{
										//	printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", Item_id);
										//	exit (0);
										//}
										//else if (n_tags_found > 1)
										//{
										//	MEM_free(tags_found);
										//	EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
										//	printf ( "More than one items matched with id %s\n", Item_id);
										//	exit (0);
										//}
										//item_tag = tags_found[0];
										//MEM_free(tags_found);

										if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
										if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_top_line (window, null_tag,objTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();

										printf("\n checkin_method_1--d.TCDCbefore get_bom:%s and envName :%s and TmpenvName :%s ",values[0],envName,TmpenvName);fflush(stdout);
										envOrignal=malloc(1500);
										strcpy(envOrignal,envNameCpy);
										printf("\n checkin_method_1--d.TCDCbefore get_bom:envOrignal:%s ",envOrignal);fflush(stdout);
										get_bom (top_line,NULLTAG, 0,Item_id,envNameCpy,envOrignal);
										printf("\n checkin_method_1--d.TCDCafter get_bom :%s ",values[0]);fflush(stdout);

										//if(BOM_line_ask_child_lines (top_line, &k, &children1));
										//printf("\nTCDCNo of child objects are k %d ",k);
										//for (cnt = 0; cnt < k; cnt++)
										//{
										//	 if(Childobject) Childobject=NULLTAG;
										//	Childobject=children1[cnt];
										//
										//	if (TCTYPE_ask_object_type(Childobject,&ChildobjTypeTag1)!=ITK_ok)PrintErrorStack();
										//	if (TCTYPE_ask_name(ChildobjTypeTag1,child_type_name)!=ITK_ok)PrintErrorStack();
										//	 printf("\nTCDCchild_type_name %s ",child_type_name);
										//
										//	if( BOM_line_look_up_attribute ("bl_item_object_type",&Item_Type));
										//	if(BOM_line_ask_attribute_string(Childobject, Item_Type, &Item_Type_str));
										//
										//
										//	printf("\nTCDCItem_Type_str %s ",Item_Type_str);
										//
										//	if (strcmp(Item_Type_str,"Design")==0)
										//	{
										//		printf("\nTCDCinside weldspot %s ",Item_Type_str);
										//		if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_RevisionW));
										//		if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_IDW));
										//		if(BOM_line_ask_attribute_string(Childobject, Item_IDW, &Item_ID_strW));
										//		if(BOM_line_ask_attribute_string(Childobject, Item_RevisionW, &Item_Revision_strW));
										//		printf("\nTCDCItem_Revision_strW %s and Item_ID_strW :%s ",Item_Revision_strW,Item_ID_strW);
										//		if (GRM_list_secondary_objects_only(Childobject,reln_type1,&n_attchs1,&secondary_objects1)!=ITK_ok)
										//		PrintErrorStack();
										//		printf("\nTCDCn_attchs1 for T5_WeldSpot%d ",n_attchs1);
										//		for (n=0;n< n_attchs1;n++ )
										//		{
										//			if(primary1) primary1=NULLTAG;
										//			primary1=secondary_objects1[n];
										//			if (AE_ask_dataset_ref_count(primary1,&referencenumberfound1)!=ITK_ok)PrintErrorStack();
										//			printf("\nTCDCreferencenumberfound for T5_WeldSpot= %d ", referencenumberfound1);
										//			for(j1=0;j1<referencenumberfound1;j1++)
										//			{
										//					if (AE_find_dataset_named_ref(primary1,j1,refname1,&reftype1,&refobject1)!=ITK_ok)PrintErrorStack();
										//					//if(orig_name) orig_name=NULL;
										//					if ( IMF_ask_original_file_name(refobject1,orig_nameW)!=ITK_ok)PrintErrorStack();
										//					printf("\nTCDCorig_name as per referencenumberfound for T5_WeldSpot is :%s for j :%d ",orig_nameW,j1);
										//					//if(path_name) path_name=NULL;
										//					if(IMF_ask_file_pathname(refobject1,SS_UNIX_MACHINE,path_nameW)!=ITK_ok)PrintErrorStack();
										//					printf("\nTCDCpath_nameW T5_WeldSpot is :%s for j :%d ",path_nameW);
										//			   }
										//
										//		}
										//	}
										//   //print_bom (children1[k],line,depth,Item_idP,fdf,fus);
										//}
										//print_bom (children[k],line,depth,Item_idP,fdf,fus);
										//print_bom (top_line,NULLTAG, 0,Item_id,fp2,fp);
									}
									printf("\n checkin_method_1--c.n_attchs:%d",n_attchs);
									for (i= 0; i < n_attchs; i++)
									{
										if(envNameCpy)
										{
											printf("\n checkin_method_1--c.TCDCTmpenvName in is:%s for ",TmpenvName);fflush(stdout);
											envName=NULL;  envNameCpy=malloc(500);
											Name=NULL;  Name=malloc(1500);
											strcpy(envNameCpy,TmpenvName);
											printf("\n checkin_method_1--c.TCDCenvName got orignal in is:%s for i :%d ",envNameCpy,i);fflush(stdout);
										}
										if(primary) primary=NULLTAG;
										primary=secondary_objects[i];
										if (TCTYPE_ask_object_type(primary,&objTypeTag1)!=ITK_ok)PrintErrorStack();
										if (TCTYPE_ask_name(objTypeTag1,type_name1)!=ITK_ok)PrintErrorStack();
										printf("\n checkin_method_1--c.TCDCtype_name before strcmp is :%s for i :%d ",type_name1,i);fflush(stdout);
										//   if(strcmp(type_name,"CATProduct")==0 || strcmp(type_name,"t5Alias")==0 || strcmp(type_name,"CATPart")==0 || strcmp(type_name,"CATDrawing")==0 || strcmp(type_name,"Text")==0)
										// {
										  //if (AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev)!=ITK_ok)PrintErrorStack();
										if( tc_strstr(type_name1,"CMI2") == NULL) /*Skipping non CMIR2 object types*/
										{
											printf("\n checkin_method_1--c.TCDCSeconday object type not Valid for QCDC hence Skipping object type : %s, %s",type_name1,Item_id);
											continue;
										}
										if (AE_ask_dataset_ref_count(primary,&referencenumberfound)!=ITK_ok)PrintErrorStack();
										printf("\n checkin_method_1--c.TCDCIn method_1: referencenumberfound=%d ", referencenumberfound);fflush(stdout);
										for(j=0;j<referencenumberfound;j++)
										{
											if(envNameCpy)
											{
												printf("\n checkin_method_1--c.TCDCTmpenvName in is:%s for ",TmpenvName);fflush(stdout);
												envNameCpy=NULL; envNameCpy = malloc(500);
												Name=NULL; Name = malloc(1500);
												strcpy(envNameCpy,TmpenvName);
												printf("\n checkin_method_1--c.TCDCenvName got orignal in is:%s for i :%d ",envNameCpy,i);fflush(stdout);
											}
											if (AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject)!=ITK_ok)PrintErrorStack();
											ITK_CALL(PROP_UIF_ask_property_by_name(refobject, "Type", &prop_tag));
											ITK_CALL(PROP_UIF_ask_value(prop_tag, &prop_value));
											printf("\n checkin_method_1--c.File object type prop_value:%s",prop_value);
											if (tc_strcmp(prop_value, "ImanFile")!=0) /*allow only ImanFile type which can only download*/
											{
												printf("\n checkin_method_1--c.TCDC not valid part type %s hence skipping %s",prop_value,Item_id);fflush(stdout);
												continue;
											}

											if ( IMF_ask_original_file_name(refobject,orig_name)!=ITK_ok)PrintErrorStack();
											printf("\n checkin_method_1--c.TCDCorig_name as per referencenumberfound is :%s for j :%d ",orig_name,j);fflush(stdout);
											if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name)!=ITK_ok)PrintErrorStack();
											printf("\n checkin_method_1--c.TCDCpath_name as per referencenumberfound is :%s for j :%d and strstr(path_name,catpart) :%d ",path_name, j,strstr(path_name,"catpart"));fflush(stdout);
											//if(strlen(path_name) >0)
											if(strlen(orig_name) >0)
											{
												//if(( strstr(path_name,"catpart") != NULL ) || ( strstr(path_name,"CATDrawing")  != NULL ) ||  ( strstr(path_name,"catdrawing")  != NULL ) ||  ( strstr(path_name,"CATPart")  != NULL ) || ( strstr(path_name,"CATProduct") != NULL ) || ( strstr(path_name,"catproduct")  != NULL ) || ( strstr(path_name,"txt")  != NULL ) || ( strstr(path_name,"dat")  != NULL  ) )
												if(tc_strstr(orig_name,".cgr") != NULL) /*skip .cgr files*/
												{
													printf("\n checkin_method_1--c.TCDCskipping .cgr file:%s,%s",orig_name,Item_id);fflush(stdout);
													continue;
												}
												if(( strstr(orig_name,"catpart") != NULL ) || ( strstr(orig_name,"CATDrawing")  != NULL ) ||  ( strstr(orig_name,"catdrawing")  != NULL ) ||  ( strstr(orig_name,"CATPart")  != NULL ) || ( strstr(orig_name,"CATProduct") != NULL ) || ( strstr(orig_name,"catproduct")  != NULL ) || ( strstr(orig_name,"txt")  != NULL ) || ( strstr(orig_name,"dat")  != NULL  ) )
												{
													printf("\n checkin_method_1--c.ownFilename:%s",Item_id);fflush(stdout);

													Item_idOwn = malloc (50);
													tc_strcpy(Item_idOwn,Item_id);
													tc_strcat(Item_idOwn,".");
													printf("\n checkin_method_1--c.Item_idOwn:%s",Item_idOwn);fflush(stdout);

													if(strstr(orig_name,Item_idOwn)!= NULL)
													{
														if(IMF_ask_original_file_name( refobject, ownFilenamePass )!=ITK_ok)PrintErrorStack();
														//if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,ownFilenamePass)!=ITK_ok)PrintErrorStack();
														printf("\n checkin_method_1--c.ownFilenamePass:%s",ownFilenamePass);fflush(stdout);
													}

													//if(strstr(path_name,"bmp")==0 && strstr(path_name,"BMP")==0)
													if( ( strstr(path_name,"bmp")==NULL) && ( strstr(path_name,"BMP")== NULL))
													{

														printf("\n checkin_method_1--c.TCDCpath_name inside if condition :%s ",path_name);fflush(stdout);
														printf("\n checkin_method_1--c.TCDCenvName before cat is if condition :%s ",envNameCpy);fflush(stdout);
														//if(strstr(path_name,"CATProduct") || strstr(path_name,"catproduct"))
														//{
														//	strcat(envName,"/");
														//	strcat(envName,Item_id);
														//	strcat(envName,".CATProduct");
														//}
														//if(strstr(path_name,"catpart") || strstr(path_name,"CATPart"))
														//{
														//	strcat(envName,"/");
														//	strcat(envName,Item_id);
														//	strcat(envName,".CATPart");
														//}
														/*TempFile=malloc(1500);
														strcpy(TempFile,envName);
														strcat(TempFile,"/");
														strcat(TempFile,Item_id);
														strcat(TempFile,"-TCPartListTST.txt");
														printf("\nTCDCTempFile TCPartList:%s ",TempFile);

														fp=fopen(TempFile,"w");
														if(fp==NULL)
														{
															printf("\nTCDCError in opening the file fp TCPartList ");
														}
														fp2=fopen("Skktest1.txt","w");
														if(fp2==NULL)
														{
															printf("\nTCDCError in opening the file fp2 Skktest1.txt ");
														}*/


														Name=malloc(1500);
														strcpy(Name,envNameCpy);
														strcat(Name,"/");
														strcat(Name,orig_name);

														printf("\n checkin_method_1--c.TCDCpath_name before copy i am checking bmp: [%s] TCDCName: [%s] ",path_name,Name);fflush(stdout);

														sprintf(command,"cp  %s %s",path_name,Name);
														system(command);
														printf("\n checkin_method_1--c.TCDCDONE :%s ",Name);fflush(stdout);
														printf("\n checkin_method_1--c.TCDCName after  mkdir is=> %s ", Name);fflush(stdout);


														char *ctrlQryEntriesSite[2] = {"SYSCD", "SUBSYSCD"};
														char *ctrlQryValuesSite[2] = {"HOMESITES", "HOMESITES"};
														tag_t TagCtrlQryContObjSite = NULLTAG,*ctrlCntrObjectsSite = NULL;
														int nEntriesSite = 2;
														int nFoundSite = 0;

														if(QRY_find2("ControlObjQry", &TagCtrlQryContObjSite));
														if (TagCtrlQryContObjSite != NULLTAG)
														{
															if(QRY_execute(TagCtrlQryContObjSite, nEntriesSite, ctrlQryEntriesSite, ctrlQryValuesSite, &nFoundSite, &ctrlCntrObjectsSite));
														}

														printf("\n checkin_method_1--c.Objects for Query ControlObjQry from checkin validationnnn : %d", nFoundSite);fflush(stdout);

														if (nFoundSite>0)
														{
															POM_get_user(&username1,&user_tag1);
															SA_ask_user_identifier2	(user_tag1,&userid1);
															printf ("\n Logged in user:%s %s ",userid1,username1);fflush(stdout);
															AOM_UIF_ask_value(user_tag1,"fnd0home_site",&homeSite);
															printf("\n checkin_method_1--c.Logged in fnd0home_site: [%s]",homeSite);fflush(stdout);

															if (strcmp(homeSite,"Trilix-Production")==0)
															{
																if( AOM_ask_value_string(ctrlCntrObjectsSite[0],"t5_Userinfo3",&sUsrInfo3)!=ITK_ok);PrintErrorStack();
																char *siteName=tc_strtok(sUsrInfo3,",");
																char *hostName=tc_strtok(NULL,",");
																printf("\n checkin_method_1--c.TCDCsiteName and  hostName in controlobject sUsrInfo3   is :%s ,%s, ",siteName,hostName);fflush(stdout);
																tc_strcpy(path_name2,"");
																//strcat(path_name2,"trlcmifms@172.26.2.61:");
																strcat(path_name2,hostName);
																strcat(path_name2,path_name);
																printf("\n checkin_method_1--c.TCDCpath_name2 in getbom  is :%s ",path_name2);fflush(stdout);
																sprintf(command,"scp %s '%s'",path_name2,Name);
																system(command);
																printf("\n checkin_method_1--c.TCDCDONE :%s ",Name);fflush(stdout);
																printf("\n checkin_method_1--c.TCDCName after  mkdir is=> :%s ", Name);fflush(stdout);
															}
															else if (strcmp(homeSite,"TMETC-Production")==0)
															{
																if( AOM_ask_value_string(ctrlCntrObjectsSite[0],"t5_Userinfo2",&sUsrInfo2)!=ITK_ok);PrintErrorStack();
																tc_strcpy(path_name2,"");
																//strcat(path_name2,"trlcmifms@172.26.2.61:");
																strcat(path_name2,hostName);
																strcat(path_name2,path_name);
																printf("\n checkin_method_1--c.TCDCpath_name2 in getbom  is :%s ",path_name2);fflush(stdout);
																sprintf(command,"scp %s '%s'",path_name2,Name);
																system(command);
																printf("\n checkin_method_1--c.TCDCDONE :%s ",Name);fflush(stdout);
																printf("\n checkin_method_1--c.TCDCName after  mkdir is=>:%s ", Name);fflush(stdout);
															}
															else
															{
																sprintf(command,"cp %s '%s'",path_name,Name);
																system(command);
																printf("\n checkin_method_1--c.TCDCDONE :%s ",Name);fflush(stdout);
																printf("\n checkin_method_1--c.TCDCName after  mkdir is=> :%s ", Name);fflush(stdout);
															}

														}
														else
														{
														  sprintf(command,"cp %s '%s'",path_name,Name);
														  system(command);
														  printf("\n checkin_method_1--c.TCDCDONE :%s ",Name);fflush(stdout);
														  printf("\n checkin_method_1--c.TCDCName after  mkdir is=> :%s ", Name);fflush(stdout);
														}

														//---------------------------------------------------------------------------------------
														//previous code location
														//---------------------------------------------------------------------------------------
													}
													printf("\n checkin_method_1--c.TCDC..1");fflush(stdout);
												}
												printf("\n checkin_method_1--c.TCDC..2");fflush(stdout);

											}
											printf("\n checkin_method_1--c.TCDC..3");fflush(stdout);
										}
										printf("\n checkin_method_1--c.TCDC..4");fflush(stdout);
									}
									printf("\n checkin_method_1--c.TCDC..5");fflush(stdout);
									//-------------------------------19.09.2016--------------------------------------------------------
									printf("\n checkin_method_1--c.TCDC Item_id:%s *****************************",Item_id);fflush(stdout);
									n = 0;
									if(Item_id)
									{
										attrs[0] ="item_id";
										values[0] = (char *)Item_id;
										printf("\n checkin_method_1--c.TCDCvalues[0] :%s ",values[0]);fflush(stdout);

										if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
										if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
										if(BOM_set_window_top_line (window, null_tag,objTag , null_tag, &top_line)!=ITK_ok)PrintErrorStack();;

										if( BOM_line_ask_child_lines ( top_line, &n, &children ) );

										//print_bom (top_line,NULLTAG, 0,Item_id,Item_id,1,1,fp2,fp);
										//fclose(fp);
										//fclose(fp2);
									}
									sComponentType = malloc(5 * sizeof (char *) );
									sIsCatiaComp = malloc(5 * sizeof (char *) );
									if( n > 0 )
									{
										tc_strcpy(sComponentType,"ASM");
										tc_strcpy(sIsCatiaComp,"-");
									}
									else if( n <= 0 )
									{
										tc_strcpy(sComponentType,"PRT");
										tc_strcpy(sIsCatiaComp,"+");
									}

									//call shell here
									FileName = malloc(2000);
									//printf("\nTCDCItem_id:%s  and desc.revision_id :%s and PatSeq :%s and path_name :%s ",  Item_id ,desc.revision_id, PatSeq,path_name );fflush(stdout);
									printf("\n checkin_method_1--c.TCDCItem_id:%s  and newPatRev :%s and newPatSeq :%s and path_name :%s ",  Item_id ,newPatRev, newPatSeq,path_name );fflush(stdout);
									//TcDcShellEnvName = malloc(250 * sizeof (char *) );
									//TcDcShellEnvName = getenv("TCDC_SHELL_PATH");

									//**************************************************************************************
									//Devkant added on 03.08.2018 as per request from Sandip Borkar and Prashant Bahadure
									printf("\n checkin_method_1--c.DownLoading _WE file and _SE to directory");fflush(stdout);
									GetAllChild(&objTag,TmpenvName);
									printf("\n checkin_method_1--c.DownLoading completed _we file to directory ");fflush(stdout);
									//Devkant added on 03.08.2018 as per request from Sandip Borkar and Prashant Bahadure
									//**************************************************************************************

									getTcPartDetails(&objTag,timestamp);


									if(PREF_ask_char_value("TCDC_SHELL_PATH", 0 , &TcDcShellEnvName )!=ITK_ok)PrintErrorStack();

									printf("\n checkin_method_1--c.TCDCTCDC_SHELL_PATH %s ",TcDcShellEnvName);fflush(stdout);

									if(!TcDcShellEnvName)
									{
										printf("\n checkin_method_1--c.Error-TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!! envname:%s ", TcDcShellEnvName );fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_errStore,"TCDC Shell path not found. Please check TCDC_SHELL_PATH preference!!!...");
										return ITK_errStore;
									}

									if(envNameCpy)
									{
										printf("\n checkin_method_1--c.TCDCTmpenvName in is:%s for ",TmpenvName);fflush(stdout);
										envName=NULL;  envNameCpy=malloc(500);
										Name=NULL;  Name=malloc(1500);
										strcpy(envNameCpy,TmpenvName);
										printf("\n checkin_method_1--c.TCDCenvName got orignal in is:%s for i :%d ",envNameCpy,i);fflush(stdout);
									}

									printf("\n checkin_method_1--c.TCDC line 1557 path_name:%s",path_name);fflush(stdout);
									printf("\n checkin_method_1--c.TCDC line 1558 envNameCpy:%s",envNameCpy);fflush(stdout);

									ShellInpFilePath = malloc(600);
									tc_strcpy(ShellInpFilePath,"");

									sprintf(ShellInpFilePath,"%s/%s",envNameCpy,ownFilenamePass);
									printf("\n checkin_method_1--c.TCDCShellInpFilePath:%s ",ShellInpFilePath);fflush(stdout);

									if(ShellInpFilePath == NULL)
									{
										printf("\n checkin_method_1--c.TCDCShellInpFilePath is null hence mismatch shell failed ");fflush(stdout);
									}

									printf("\n checkin_method_1--c.path_name= [%s] ",path_name);fflush(stdout);

									strcpy(FileName,TcDcShellEnvName);
									strcat(FileName,"/FindMismatchInCATProduct.sh");
									strcat(FileName," ");
									strcat(FileName,Item_id);
									strcat(FileName," ");
									//strcat(FileName,desc.revision_id);
									strcat(FileName,newPatRev);
									strcat(FileName," ");
									//strcat(FileName,PatSeq);
									strcat(FileName,newPatSeq);
									strcat(FileName," ");
									//strcat(FileName,path_name);
									//strcat(FileName,ownFilenamePass);
									strcat(FileName,ShellInpFilePath);
									strcat(FileName," ");
									strcat(FileName,envNameCpy);
									strcat(FileName," ");
									strcat(FileName,sComponentType);
									strcat(FileName," ");
									strcat(FileName,sDesignGroup);
									strcat(FileName," ");
									strcat(FileName,sIsCatiaComp);
									strcat(FileName," ");
									strcat(FileName,sPartType);
									strcat(FileName," ");
									strcat(FileName,userid);

									printf("\n checkin_method_1--c.TCDCFileName before system calling shell from custom exit: %s ", FileName);fflush(stdout);
									system(FileName);
									printf("\n checkin_method_1--c.TCDCAfter excecuting shell from custom exit: %s ", FileName);fflush(stdout);

									envName1=malloc(1000);

									strcpy(envName1,envNameCpy);
									strcat(envName1,"/");
									strcat(envName1,Item_id);
									strcat(envName1,"_mismatch.txt");

									printf("\n checkin_method_1--c.TCDCenvName1 is:%s ",envName1);fflush(stdout);

									fp1 = fopen(envName1, "r");

									Finalline=malloc(2000);
									filelinecount = 0;

									if ( fp1 )
									{
										tc_strcpy(Finalline,"Error  ");
										printf("\n checkin_method_1--c.after Finalline copy : %s ", Finalline);fflush(stdout);
										while ( fgets (line1 , 200 , fp1) )
										{
											printf("\ncheckin_method_1--c.The data of the file is: %s ", line1);fflush(stdout);
											tc_strcat(Finalline,line1);
											filelinecount = filelinecount + 1;
											if ( filelinecount == 8 )
											{
												break;
											}
										}
										printf("\n checkin_method_1--c.TCDCstrlen(line1) :%d ",tc_strlen(line1));fflush(stdout);
										printf("\n checkin_method_1--c.TCDCstrlen(Finalline) :%d ",tc_strlen(Finalline));fflush(stdout);
										printf("\n checkin_method_1--c.TCDCAt end all after strcat: %s ", Finalline);fflush(stdout);
										if(tc_strlen(Finalline)>8)
										{
											if(tc_strlen(Finalline)>1650)
											{
												Finalline1=malloc(2050);
												Finalline1=subString(Finalline,0,2000);
												 printf("\n checkin_method_1--c.TCDCBefore print of the file is: %s ", Finalline1);fflush(stdout);
												//  printf("\n Before print StrCat(Finalline,line1): %s ", Finalline);
												 EMH_store_error_s1(EMH_severity_error,ITK_err,Finalline1);

												 return ITK_err;
											}
											else
											{
												 printf("\n checkin_method_1--c.TCDCless than 1650 no substring: %s ", Finalline);fflush(stdout);
												 EMH_store_error_s1(EMH_severity_error,ITK_err,Finalline);
												 return ITK_err;
											}
										}
									}
									else
									{
										printf("\n checkin_method_1--c.TCDCError: Log file can not be created.Program Aborting ");fflush(stdout);
									}
									//----------------------------------19.09.2016-----------------------------------------------------
								}
								else
								{
									printf("\n checkin_method_1--c.TCDCThere are no data items attached to part being checked in ");fflush(stdout);
								}
							}
						}

						//Added by Sharvari for handling removing relation of folder and Design revision during checkin on 8-10-2013(Requirement from MSDCAD for PRO-E)
						printf("\n checkin_method_1--c.TCDCProPrtCN is before folder check:%d ",ProPrtCN);fflush(stdout);

						//printf("\n checkin_method_1--c.UA1.53 - Removing TCDCProPrtCN handling code for relation of folder and DR  ");fflush(stdout);
						//if(ProPrtCN >0)
						//{
						//	if (ITEM_ask_item_of_rev( objTag,&ItemMasterTag)!=ITK_ok)PrintErrorStack();
						//	if (ItemMasterTag)
						//	{
						//		if(WSOM_where_referenced(ItemMasterTag, WSO_where_ref_any_depth,&n_refs,&levels,&referencers,&relations)!=ITK_ok)PrintErrorStack();
						//		 printf("\nTCDCn_refs  to item are:%d ",n_refs);fflush(stdout);
						//		 if (n_refs >0)
						//		 {
						//			for (cnt=0;cnt<n_refs ;cnt++ )
						//			{
						//				if(TCTYPE_ask_object_type(referencers[cnt],&objTypeRefTag))PrintErrorStack();
						//				if(TCTYPE_ask_name(objTypeRefTag,type_name_ref))PrintErrorStack();
						//				printf("\nTCDCtype_name_ref isss :%s ",type_name_ref);fflush(stdout);
						//				if (strcmp(type_name_ref,"Folder")==0)
						//				{
						//					if (WSOM_describe(referencers[cnt], &desc) !=ITK_ok)   PrintErrorStack();
						//					printf("Object Name:     %s ", desc.object_name);fflush(stdout);
						//					printf("Object Typeeee:     %s ", desc.object_type);fflush(stdout);
						//					if(strcmp(desc.object_name,"Home")!=0)
						//					{
						//					//			int TotalSize=0;
						//					//	    if(FL_ask_references(referencers[cnt],FL_fsc_by_date_modified ,&TotalSize,&Objects_Found)!=ITK_ok)PrintErrorStack();
						//					//	    printf("\nTCDCTotalSize:%d ",TotalSize); fflush(stdout);
						//					//	    for (p=0;p<TotalSize ;p++ )
						//					//		{
						//					//			if(WSOM_ask_name(Objects_Found[p],task_name)!=ITK_ok)PrintErrorStack();
						//					//			printf("\nTCDCtaskName isss :%s ",task_name);fflush(stdout);
						//					//		}
						//					if(AOM_lock(referencers[cnt])!=ITK_ok)PrintErrorStack();
						//					if(FL_remove(referencers[cnt],ItemMasterTag)!=ITK_ok)PrintErrorStack();
						//					//if(AOM_refresh(referencers[cnt],1)!=ITK_ok)PrintErrorStack();
						//					if(AOM_save(referencers[cnt])!=ITK_ok)PrintErrorStack();
						//					if(AOM_refresh(referencers[cnt],0)!=ITK_ok)PrintErrorStack();
						//					printf("\nTCDCrefreshed after save .. "); fflush(stdout);
						//					if(AOM_unlock(referencers[cnt])!=ITK_ok)PrintErrorStack();
						//					printf("\nTCDCremoved.. "); fflush(stdout);
						//					break;
						//					}
						//				}
						//			}
						//		 }
						//	}
						//}
						//printf("\n checkin_method_1--c.UA1.53 code remove copleted.. In file preaction_on_checkin code commented  ");fflush(stdout);

						printf("\n checkin_method_1--c.TCDCItemId:[%s] TCDCObjectType for Checkin=>[%s] TCDCRevision: [%s] TCDCSequence: [%s] ",Item_id,desc.object_type,newPatRev,PatSeq);fflush(stdout);

						if (GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)	PrintErrorStack();
						printf("\n checkin_method_1--c.TCDCTotal Secondary Objects Found for Part [%s] are [%d] ",Item_id,n_attchs);fflush(stdout);

						if (n_attchs > 0)
						{
							printf("\n checkin_method_1--c.TCDCThere are some Secondary Objects ... so proceed with checks ");fflush(stdout);
							/*Getting ChildParts through BOM LINE*/
							if(BOM_create_window (&t_BomLineWindow) !=ITK_ok) PrintErrorStack();
							printf("\n checkin_method_1--c.TCDCABHI 1111 ");fflush(stdout);
							if(CFM_find( "Latest Working", &t_Rule )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_config_rule( t_BomLineWindow, t_Rule )!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_pack_all (t_BomLineWindow, true)!=ITK_ok) PrintErrorStack();
							if(BOM_set_window_top_line (t_BomLineWindow, t_ItemTag, objTag, null_tag, &t_TopLine)!=ITK_ok) PrintErrorStack();
							if(BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren)!=ITK_ok) PrintErrorStack();
							printf("\n checkin_method_1--c.TCDCTotal Child Parts Found in BomLine are [%d] ",i_ChildCount);fflush(stdout);

							RES_who_checked_object_out(objTag,&chkout_PuserT,&chkout_PgrpT);
							SA_ask_user_identifier2(chkout_PuserT,&chkoutP_userid);

							printf("\n checkin_method_1--c.In file preaction on checkin:checkin_method_1: chkoutP_userid----  %s",chkoutP_userid);fflush(stdout);

							iChildPartChkOutFlag=0;
							weChildChkOutFlag=0;
							for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
							{
								if(t_Childobject) t_Childobject=NULLTAG;
								t_Childobject=t_PartChildren[iChldPrts];
								if (TCTYPE_ask_object_type(t_Childobject,&t_ChildObjType)!=ITK_ok)PrintErrorStack();
								if (TCTYPE_ask_name(t_ChildObjType,ca_ChildType_Name)!=ITK_ok)PrintErrorStack();
								printf("\n checkin_method_1--c.TCDC[%d] ChildType is [%s] ",iChldPrts+1,ca_ChildType_Name);fflush(stdout);

								if( BOM_line_look_up_attribute ("bl_item_object_type",&iItemType));
								if(BOM_line_ask_attribute_string(t_Childobject, iItemType, &cp_ItemType_str));
								printf("\n checkin_method_1--c.TCDC[%d] Child ItemType is [%s] ",iChldPrts+1,cp_ItemType_str);

								if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemRevId));
								if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));
								if(BOM_line_ask_attribute_string(t_Childobject, iItemId, &cp_ItemID_str));
								if(BOM_line_ask_attribute_string(t_Childobject, iItemRevId, &cp_ItemRev_str));
								printf("\n checkin_method_1--c.TCDC[%d] ItemRevision is [%s] and ItemID is: [%s] ",iChldPrts+1,cp_ItemRev_str,cp_ItemID_str);

								if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
								if(BOM_line_ask_attribute_tag(t_Childobject, iChildItemTag, &t_ChildItemRev));

								if(AOM_ask_value_int(t_ChildItemRev,"sequence_id",&i_ChildSeq));
								cp_ChildSeq = (char *) MEM_alloc( 5 * sizeof(char) );
								sprintf(cp_ChildSeq,"%d",i_ChildSeq);
								printf("\n checkin_method_1--c.TCDC[%d] ItemSequence is [%s] ",iChldPrts+1,cp_ChildSeq);fflush(stdout);

								if(BOM_line_look_up_attribute ("bl_rev_checked_out",&iItemChkdOut));
								if(BOM_line_ask_attribute_string (t_Childobject, iItemChkdOut, &cp_ChildChkOutValue));
								printf("\n checkin_method_1--c.TCDC[%d] CheckedOut is [%s] ",iChldPrts+1,cp_ChildChkOutValue);fflush(stdout);

								if (AOM_ask_value_string(t_ChildItemRev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
								printf("\n checkin_method_1--c.TCDC[%d] Description is [%s] ",iChldPrts+1,Desc_obj);fflush(stdout);

								RES_who_checked_object_out(t_ChildItemRev,&chkout_childUsr,&chkout_childGrp);
								SA_ask_user_identifier2(chkout_childUsr,&chkoutC_userid);

								printf("\n checkin_method_1--c.In file preaction on checkin:checkin_method_1: chkoutC_userid----  %s",chkoutC_userid);fflush(stdout);

								//Added by Ajinkya on 06 Oct 2018//
								if (tc_strcmp(cp_ChildChkOutValue,"Y")==0)
								{
									printf("\n checkin_method_1--c.Setting check out _WE/_AD/_MB part flag  ");fflush(stdout);

									//changes added on 2 July//

									if((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_WE")== NULL))
									{
										printf("\n checkin_method_1--c.Setting check out _WE part flag as _WE not found  ");fflush(stdout);
									}
									else if ((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_WE")!= NULL))
									{
										if(tc_strstr(cp_ItemID_str,Item_id)!=NULL)
										{
											printf("\n checkin_method_1--c.Auto check in of _WE part  ");fflush(stdout);
											if (RES_checkin(t_ChildItemRev)!=ITK_ok)   PrintErrorStack();
											printf("\n checkin_method_1--c.Done part _we is checked in   ");fflush(stdout);
											weChildChkOutFlag=0;
										}
										else
										{
											printf("\n checkin_method_1--c.Error-The partnumber of the Assembly being checked in its corresponding _WE part number do not match.Contact DPD-CMI team.... ");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"The partnumber of the Assembly being checked in its corresponding _WE part number do not match.Contact DPD-CMI team");
											return ITK_err;
										}
									}

									if((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_AD")== NULL))
									{
										printf("\n checkin_method_1--c.Setting check out _AD part flag as _AD not found  ");fflush(stdout);
									}
									else if((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_AD")!= NULL))
									{
										if(tc_strstr(cp_ItemID_str,Item_id)!=NULL)
										{
											printf("\n checkin_method_1--c.Auto check in of _AD part  ");fflush(stdout);
											if (RES_checkin(t_ChildItemRev)!=ITK_ok)   PrintErrorStack();
											printf("\n checkin_method_1--c.Done part _AD is checked in   ");fflush(stdout);
											weChildChkOutFlag=0;
										}
										else
										{
											printf("\n checkin_method_1--c.Error-The partnumber of the Assembly being checked in and its corresponding _AD part number do not match.Contact DPD-CMI team.... ");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"The partnumber of the Assembly being checked in and its corresponding _AD part number do not match.Contact DPD-CMI team");
											return ITK_err;
										}
									}

									if((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_MB")== NULL))
									{
										printf("\n checkin_method_1--c.Setting check out _AD part flag as _AD not found  ");fflush(stdout);
									}
									else if((tc_strcmp(cp_ChildChkOutValue,"Y")==0) && (tc_strstr(cp_ItemID_str,"_MB")!= NULL))
									{
										if(tc_strstr(cp_ItemID_str,Item_id)!=NULL)
										{
											printf("\n checkin_method_1--c.Auto check in of _MB part  ");fflush(stdout);
											if (RES_checkin(t_ChildItemRev)!=ITK_ok)   PrintErrorStack();
											printf("\n checkin_method_1--c.Done part _MB is checked in   ");fflush(stdout);
											weChildChkOutFlag=0;
										}
										else
										{
											printf("\n checkin_method_1--c.Error-The partnumber of the Assembly being checked in and its corresponding _MB part number do not match.Contact DPD-CMI team.... ");fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"The partnumber of the Assembly being checked in and its corresponding _MB part number do not match.Contact DPD-CMI team");
											return ITK_err;
										}
									}
									printf("\n checkin_method_1--c.FLAG VALUE IS  ------>[%d] ",weChildChkOutFlag);fflush(stdout);

									if(weChildChkOutFlag!=0)
									{
										printf("\n checkin_method_1--c.Check final falg value before set ---%d  ",weChildChkOutFlag);fflush(stdout);
										weChildChkOutFlag=1;
										break;
										printf("\n checkin_method_1--c.Done Setting part _we   ");fflush(stdout);
									}
									//end

									printf("\n checkin_method_1--c.Out side all condition for flag set ----(%d)  ",weChildChkOutFlag);fflush(stdout);
								}

								//end
								printf("\n checkin_method_1--c.Item id of uses PART is: [%s]  ", cp_ItemID_str);fflush(stdout);
								if((strcmp(cp_ChildChkOutValue,"Y")==0) && (strcmp(cp_ItemType_str,"WeldSpot")!=0) && (tc_strcmp(chkoutC_userid,chkoutP_userid)==0))
								{
									printf("\nTCDCChild Part is checkedout.. ");fflush(stdout);
									if(tc_strstr(cp_ItemID_str,"_WE")!= NULL)
									{
										printf("\n checkin_method_1--c.AS _WE  PART ItemID is: [%s]  found  ", cp_ItemID_str);fflush(stdout);
										iChildPartChkOutFlag=2;

									}
									if(tc_strstr(cp_ItemID_str,"_AD")!= NULL)
									{
										printf("\n checkin_method_1--c.AS _AD  PART ItemID is: [%s]  found  ", cp_ItemID_str);fflush(stdout);
										iChildPartChkOutFlag=2;
									}
									if(tc_strstr(cp_ItemID_str,"_MB")!= NULL)
									{
										printf("\n checkin_method_1--c.AS _MB PART ItemID is: [%s]  found  ", cp_ItemID_str);fflush(stdout);
										iChildPartChkOutFlag=2;
									}

									printf("\n checkin_method_1--c.out of loop iChildPartChkOutFlag as -%d  ",iChildPartChkOutFlag);fflush(stdout);
									if(iChildPartChkOutFlag!=2)
									{
										printf("\n checkin_method_1--c.i AM CHECKING INSIDE CONDITION value of iChildPartChkOutFlag as -%d  ",iChildPartChkOutFlag);fflush(stdout);
										iChildPartChkOutFlag=1;
										break;
										printf("\n checkin_method_1--c.work for Setting part iChildPartChkOutFlag as -%d    ",iChildPartChkOutFlag);fflush(stdout);
									}

									printf("\n checkin_method_1--c.Not seeting flag as _we or _AD or _MB part found %s ",cp_ItemID_str);fflush(stdout);
								}
								else if (strcmp(cp_ChildChkOutValue,"Y")==0 && strcmp(cp_ItemType_str,"WeldSpot")==0)
								{
									printf("\nTCDCThis is WeldSpot and is checked out... so auto checkin it ");fflush(stdout);
									if (RES_checkin(t_ChildItemRev)!=ITK_ok)   PrintErrorStack();
								}
							}
							printf("\n checkin_method_1--c.Flag value,iChildPartChkOutFlag - %d ",iChildPartChkOutFlag);fflush(stdout);

							printf("\n checkin_method_1--c.Flag value weChildChkOutFlag - %d  ",weChildChkOutFlag);fflush(stdout);

							if ((iChildPartChkOutFlag == 0) &&  (weChildChkOutFlag == 0))
							{
								printf("\n checkin_method_1--e.TCDCAll Child Part are checkedin ...so proceed ");fflush(stdout);
							}
							else
							{
								//if( strcmp(desc.revision_id,"NR")==0 )
								//if( strcmp(newPatRev,"NR")==0 ) // Allow child part check in validations for all revisions as mailed by Pallavi/Sandip
								//{
								//printf("\nTCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",desc.revision_id,Item_id);fflush(stdout);
								printf("\n checkin_method_1--e.TCDCbefore checkin message for child and parent");fflush(stdout);
								printf("\n checkin_method_1--e.TCDCCatPrtCN:%d",CatPrtCN);fflush(stdout);
								printf("\n checkin_method_1--e.TCDCCatPrdt:%d",CatPrdt);fflush(stdout);
								printf("\n checkin_method_1--e.TCDCCmiDrwCnt:%d",CmiDrwCnt);fflush(stdout);
								//TZ 1.30/136 proe/catia check in validation.. If checked out users are same then ask user to check in child part first.

								if (( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0))
								{
									if(tc_strcmp(chkoutC_userid,chkoutP_userid)==0)
									{
										printf("\n  checkin_method_1--e.In else condition Item id of uses PART is: [%s] \n", cp_ItemID_str);fflush(stdout);

										if(tc_strstr(cp_ItemID_str,"_WE")!= NULL)
										{
											printf("\n  checkin_method_1--e.For _WE check ---> [%s] \n", cp_ItemID_str);fflush(stdout);
											MessageFlagWE=1;
											MessageFlagAD=2;
											MessageFlagMB=2;
										}
										if (tc_strstr(cp_ItemID_str,"_AD")!= NULL )
										{
											printf("\n  checkin_method_1--e.For _AD check---> [%s] \n", cp_ItemID_str);fflush(stdout);
											MessageFlagWE=2;
											MessageFlagAD=1;
											MessageFlagMB=2;
										}
										if (tc_strstr(cp_ItemID_str,"_MB")!= NULL)
										{
											printf("\n  checkin_method_1--e.For _MB check---> [%s] \n", cp_ItemID_str);fflush(stdout);
											MessageFlagWE=2;
											MessageFlagAD=2;
											MessageFlagMB=1;
										}

										printf("\n  checkin_method_1--e.MessageFlagWE ----(%d) \n",MessageFlagWE);fflush(stdout);
										printf("\n  checkin_method_1--e.MessageFlagAD----(%d) \n",MessageFlagAD);fflush(stdout);
										printf("\n  checkin_method_1--e.MessageFlagMB----(%d) \n",MessageFlagMB);fflush(stdout);

										if (MessageFlagWE==0)
										{
											   printf("\n  checkin_method_1--e.WE TCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",newPatRev,Item_id);fflush(stdout);
											   EMH_store_error_s1(EMH_severity_error,ITK_err,"Dependent Child Parts are not Checked-In.. Checkin all Child Part first");
											   return ITK_err;
										}
										if (MessageFlagAD==0)
										{
											   printf("\n  checkin_method_1--e.AD TCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",newPatRev,Item_id);fflush(stdout);
											   EMH_store_error_s1(EMH_severity_error,ITK_err,"Dependent Child Parts are not Checked-In.. Checkin all Child Part first");
											   return ITK_err;
										}
										if (MessageFlagMB==0)
										{
											   printf("\n  checkin_method_1--e.MB TCDCSome Child Parts are checkedout.... So Ask user to checkin child Parts first Parent rev:%s itemid:%s...\n",newPatRev,Item_id);fflush(stdout);
											   EMH_store_error_s1(EMH_severity_error,ITK_err,"Dependent Child Parts are not Checked-In.. Checkin all Child Part first");
											   return ITK_err;
										}


										printf("\n  checkin_method_1--e.In else ## Not seeting flag as _we or _AD or _MB part found -%s\n",cp_ItemID_str);fflush(stdout);
									}
									else
									{
										printf("\n  checkin_method_1--e.Checked out user of parent and its childs are not same\n");fflush(stdout);
									}
								}
								else if(ProPrtCN>0)
								{
									if(tc_strcmp(chkoutC_userid,chkoutP_userid)==0 )
									{
										printf("\n  checkin_method_1--e.In file preaction on checkin:checkin_method_1: ProPrtCN is [%d]",ProPrtCN);fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Dependent Child Parts are not Checked-In.. Checkin all Child Part first");
										return ITK_err;
									}
									else
									{
										printf("\n  checkin_method_1--e.Checked out user of parent and its childs are not same\n");fflush(stdout);
									}
								}
								//}
							}
						}
						printf("\nTCDC1..");fflush(stdout);
					}
					else
					{
						printf("\n  checkin_method_1--e.QCDC Skiping for RH Parts--------> %s\n",ItemLhRhInd);fflush(stdout);
					}



					/******************************************************************************************
										LH/RH Checked-in start by Hanuman
					******************************************************************************************/
					HasSymPrt=0;
					int result,n_attch = 0;
					int count,k;
					int found =0;
					tag_t relation_type;
					tag_t relation_type3;
					tag_t  	master =	NULLTAG;
					tag_t  *master2 = NULLTAG;
					tag_t	latestrev	=	NULLTAG;
					tag_t objTypeTag2 = NULLTAG;
					logical	checkout = 0;
					logical	checkout1 = 0;

					ITK_CALL(RES_is_checked_out(objTag,&checkout1));
					printf("\n checkin_method_1--b.Checkedout Status is : [%d]\n",checkout1);fflush(stdout);

					if(checkout1)
					{
						ITK_CALL(AOM_ask_value_string(objTag,"t5_LeftRh_Comp",&ItemLhRhInd));
						printf("\n checkin_method_1--b.LH/RH Indicator of Left Part is :: %s",ItemLhRhInd);fflush(stdout);

						if(ItemLhRhInd==NULL || tc_strcmp(ItemLhRhInd,"NA")==0)
						{
							printf("\n checkin_method_1--b.inside NULL/NA of LH/RH Indicator values");fflush(stdout);
							HasSymPrt=0;
						}
						else
						{
							if(tc_strcmp(ItemLhRhInd,"LH CATIA")==0 || tc_strcmp(ItemLhRhInd,"LH PROE")==0)
							{
								printf("\n checkin_method_1--b.inside LH CATIA OR PROE");fflush(stdout);
								HasSymPrt=1;

								ITK_CALL(ITEM_ask_item_of_rev(objTag, &master));
								printf("\n checkin_method_1--b.ITEM_Found......");fflush(stdout);

								result = GRM_find_relation_type("T5_LRReln", &relation_type);
								printf("\n checkin_method_1--b.GRM_find_relation_type ---->%d",result);fflush(stdout);

								if (relation_type!=NULLTAG)
								{
									ITK_CALL(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
									printf("\n checkin_method_1--b.master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

									if(n_attch>0)
									{
										  ITK_CALL(ITEM_ask_latest_rev(master2[0],&latestrev));
										  if (latestrev!=NULLTAG)
										  {
											  printf("\n checkin_method_1--b.master2 latest revision found\n");fflush(stdout);
											  if (TCTYPE_ask_object_type(latestrev,&objTypeTag2)!=ITK_ok)PrintErrorStack();
											  if (TCTYPE_ask_name(objTypeTag2,type_name)!=ITK_ok)PrintErrorStack();
											  printf("\n checkin_method_1--b.type_name ==> %s\n", type_name);fflush(stdout);

											  if(tc_strcmp(type_name,"Design Revision")==0 || tc_strcmp(type_name,"ItemRevision")==0 )
											  {
												printf("\n checkin_method_1--b.Rh Part Revision is also of type [Design Revision/ItemRevision]");fflush(stdout);
												ITK_CALL(RES_is_checked_out(latestrev,&checkout));
												printf("\n checkin_method_1--b.Value of checkout Attribute in Checkin : [%d]\n",checkout);fflush(stdout);

												if(checkout==1)
												{
													LHRhFlag = 1;
													printf("\n checkin_method_1--b.LHRhFlag : %d",LHRhFlag);

													if(ITK_ok != (ifail = RES_checkin(latestrev)))
													{
														printf("\n checkin_method_1--b.RH Part ifail for Checked-in.............");fflush(stdout);
														return ifail;

													}else
													{
														printf("\n checkin_method_1--b.RH Part success for Checked-in.............");fflush(stdout);
														ITK_CALL(AOM_refresh(latestrev,0));
													}

													//ITK_CALL(RES_checkin(latestrev));
													//ITK_CALL(AOM_refresh(latestrev,0));
												}
											  }
										  }
									}
									else
									{
										printf("\n checkin_method_1--b.Error-Pls Confirm LH/RH Part Relationship,Select LH Part, Goto: Tool->Product Structure Classes->Create LH/RH Relation----\n",n_attch);fflush(stdout);
										EMH_store_error_s2(EMH_severity_error,ITK_errStore,"Pls Confirm LH/RH Part Relationship\n","Select LH Part, Goto: Tool->Product Structure Classes->Create LH/RH Relation");
										return ITK_errStore;
									}
								}
							}

							if(tc_strcmp(ItemLhRhInd,"RH CATIA")==0 || tc_strcmp(ItemLhRhInd,"RH PROE")==0)
							{
								ITK_CALL(ITEM_ask_item_of_rev(objTag, &master));
								printf("\n checkin_method_1--b.ITEM_Found......");fflush(stdout);

								result = GRM_find_relation_type("T5_LRReln", &relation_type);
								printf("\n checkin_method_1--b.GRM_find_relation_type ---->%d",result);fflush(stdout);

								if (relation_type!=NULLTAG)
								{
									ITK_CALL(GRM_list_secondary_objects_only(master,relation_type,&n_attch,&master2));
									printf("\n checkin_method_1--b.master2 from Design master1 :: %d\n",n_attch);fflush(stdout);

									if(n_attch>0)
									{
										printf("\n checkin_method_1--b.Else IF LHRhFlag : %d",LHRhFlag);
										if(LHRhFlag<1)
										{
											printf("\n checkin_method_1--b.inside RH CATIA OR PROE");fflush(stdout);
											EMH_store_error_s2(EMH_severity_error,ITK_errStore,"In-Valid to Check-in RH Part","Pls select LH Part and Check-in");
											return ITK_errStore;
										}else
										{
											printf("\n checkin_method_1--b.RH Part is checked-in........");fflush(stdout);
										}
									}else
									{
										EMH_store_error_s2(EMH_severity_error,ITK_errStore,"Pls Confirm LH/RH Part Relationship\n","Select LH Part, Goto: Tool->Product Structure Classes->Create LH/RH Relation");
										return ITK_errStore;
									}
								}
							}
						}
					}
					else
					{
						printf("\n checkin_method_1--b.Selected Part is already checked-in..........\n");fflush(stdout);
					}
				}//Check-In Validation Check CheckBypasFlag
				else
				{
					if( AOM_ask_value_string(objTag,"item_id",&Item_id)!=ITK_ok)PrintErrorStack();
					if (WSOM_describe(objTag, &desc) !=ITK_ok)   PrintErrorStack();
					printf("\n checkin_method_1--d.TCDCItem_id: %s", Item_id);fflush(stdout);
					printf("\n checkin_method_1--d.TCDCObject Type: %s", desc.object_type);fflush(stdout);
					printf("\n checkin_method_1--d.TCDCRevision ID: %s", desc.revision_id);fflush(stdout);

					if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--d.TCDCNo of DI :%d ",n_attchs);fflush(stdout);
					if(n_attchs>0)
					{
						for (i= 0; i < n_attchs; i++)
						{
							primary=secondary_objects[i];
							if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
							if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
							printf("\n checkin_method_1-c.i=[%d] d.TCDCtype_name2 for the input is new: [%s] ",i,type_name2);fflush(stdout);
							if((tc_strcmp(type_name2,"CMI2Drawing")==0) || (tc_strcmp(type_name2,"ProDrw")==0))
							{
								counter++;
								//Rajendra
								if( AOM_UIF_ask_value(primary,"object_name",&drawingnum)==ITK_ok)PrintErrorStack();
								printf("\n checkin_method_1--d.drawingnum: [%s]",drawingnum);fflush(stdout);

								if(tc_strcmp(type_name2,"CMI2Drawing")==0)
								{
									CmiDrwCnt++;
								}
							}
							if(tc_strcmp(type_name2,"CMI2Part")==0 )
							{
								CatPrtCN++;
							}
							/*
							as per below mail request part type check is commented.. Now onward QCDC is on for all part type for cadtype CMI2Product
							trilix team was facing issue for checkin dummy part part and jt is not getting created
							due to part type check it is considering only catproduct and assembly for qcdc and cmi2part and cmi2drw for all part type
							mail subject:PLM error (check-out)
							mail date: 05-mar-2018

							if(strcmp(type_name2,"CMI2Product")==0 && strcmp(sPartType,"Assembly")==0 )	*/
							if(tc_strcmp(type_name2,"CMI2Product")==0)
							{
								CatPrdt++;
							}
							if((tc_strcmp(type_name2,"ProPrt")==0) || (tc_strcmp(type_name2,"ProAsm")==0))
							{
								ProPrtCN++;
							}
						}
					}
				}

				/*********************************************************START************************************************************/
				/**************************************************ALIAS ASSY MANAGEMENT***************************************************/

				ITK_CALL(GRM_find_relation_type("IMAN_specification", &relation_typeAlias));

				if(GRM_list_secondary_objects_only(objTag,relation_typeAlias,&at,&data_objectsAl)!=ITK_ok)PrintErrorStack();
				printf("\n checkin_method_1--data_objectsAl :%d",at);fflush(stdout);

				//if (at>0)
				//{
				//	  for (xx=0; xx<at; xx++)
				//	   {
				//		  Al_type	=	NULL;
				//		  ask_property_value_by_name(data_objectsAl[xx], "Type", &Al_type);
				//
				//		  printf("\n Alias reference type:%s",Al_type);fflush(stdout);//WIRE
				//
				//		  if(tc_strcmp(Al_type,"WIRE")==0)
				//		   {
				//			  break;
				//		   }
				//	   }
				//	   if((tc_strcmp(desgrp,"ST")==0) && (tc_strcmp(Al_type,"WIRE")==0 ))
				//		{
				//
				//		}
				//}
				//else if (at==0)
				//if (at==0)
				//{
				//printf("\n no dataset attached to design rev \n");fflush(stdout);

				if((tc_strcmp(desgrp,"ST")==0) && (at==0))
				{
					printf("\n ST GROUP - ALIAS ASSEMBLY CHECKIN - no dataset attached to design rev \n");fflush(stdout);

					ITK_CALL(AOM_ask_value_string(objTag,"item_id",&AliasItem_id));
					printf("\n AliasItem_id  is    :%s\n",AliasItem_id);fflush(stdout);
					ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&AliasItemRev_id));

					AliasRev = strtok ( AliasItemRev_id, ";" );
					printf("\n AliasRev  is    :%s\n",AliasRev);fflush(stdout);
					AliasSeq = strtok ( NULL, ";" );
					printf("\n AliasSeq  is    :%s\n",AliasSeq);fflush(stdout);

					ITK_CALL(PREF_ask_char_value("ALIAS_DOWNLOADPATH", 0 , &AliasenvName ));
					printf("\n ALIAS_DOWNLOADPATH issss  %s\n",AliasenvName);fflush(stdout);

					if(!AliasenvName)
					{
					printf("\n ALIAS cannot access in getTcPartDetails envname:%s\n", AliasenvName );fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Directory not found. Please check ALIAS_DOWNLOADPATH");
					return ITK_errStore;
					}

					AliasenvNameCpy = malloc(1500);

					tc_strcpy(AliasenvNameCpy,AliasenvName);
					tc_strcat(AliasenvNameCpy,"/");
					tc_strcat(AliasenvNameCpy,AliasItem_id);
					tc_strcat(AliasenvNameCpy,"_");
					tc_strcat(AliasenvNameCpy,AliasRev);
					tc_strcat(AliasenvNameCpy,"_");
					tc_strcat(AliasenvNameCpy,AliasSeq);

					printf("\n ALIAS  AliasenvName before system is=>%s\n", AliasenvNameCpy);fflush(stdout);

					//if(mkdir(AliasenvNameCpy,00777)==-1)
					//{
					//	printf("\n ALIAS error in creating dir\n");fflush(stdout);
					//}

					printf("\n Alias bom window \n");fflush(stdout);
					ITK_CALL(BOM_create_window (&A_BomLineWindow));
					ITK_CALL(CFM_find("Latest Working",&A_Rule));
					ITK_CALL(BOM_set_window_config_rule(A_BomLineWindow, A_Rule));
					ITK_CALL(BOM_set_window_pack_all(A_BomLineWindow,FALSE));
					ITK_CALL(BOM_set_window_top_line(A_BomLineWindow,a_ItemTag,objTag,null_tag,&a_TopLine));

					//ITK_CALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_IDAsm));
					//ITK_CALL(BOM_line_ask_attribute_string(a_TopLine, Item_IDAsm, &Item_ID_str));
					//printf("\n Item_ID_str1:%s\n",Item_ID_str);fflush(stdout);

					ITK_CALL(BOM_line_ask_child_lines(a_TopLine,&a_ChildCount,&a_PartChildren));

					printf("\n Total Child Parts Found in ALIAS BomLine are [%d]\n",a_ChildCount);fflush(stdout);

					ITK_CALL(GRM_find_relation_type("IMAN_specification",&Relatn_type1));
					printf("\n Relatn_type1 found\n "); fflush(stdout);

					if(a_ChildCount>0)
					{
						printf("\n  a_ChildCount > 0  \n "); fflush(stdout);
						for (AChldPrts=0; AChldPrts<a_ChildCount; AChldPrts++)
						{
							printf("\n  AChldPrts test  \n "); fflush(stdout);
							if(A_Childobject) A_Childobject=NULLTAG;
							A_Childobject=a_PartChildren[AChldPrts];

							//ITK_CALL(TCTYPE_ask_object_type(A_Childobject,&AliasobjTypeTag));
							//ITK_CALL(TCTYPE_ask_name(AliasobjTypeTag,a_typename));
							//printf("\n Alias Type Name:%s\n",a_typename);fflush(stdout);

							ChildItemRev = ask_item_revision_from_bom_line(A_Childobject);

							ITK_CALL(AOM_ask_value_string(ChildItemRev,"item_id",&sChildItemID));
							printf("\n sChildItemID  is    :%s\n",sChildItemID);fflush(stdout);

							printf("\n AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA \n");fflush(stdout);

							ITK_CALL(GRM_list_secondary_objects_only(ChildItemRev,Relatn_type1,&Alias_attchs,&secondary_objectsAl));
							printf("\n after secondary_objectsAl  \n "); fflush(stdout);

							for (xx=0; xx<Alias_attchs; xx++)
							{
								Alrefobject=NULLTAG;

								ask_property_value_by_name(secondary_objectsAl[xx], "Type", &Al_type);
								//ask_property_value_by_name(secondary_objectsAl[xx], "Type", &Al_type);
								printf("\n Alias reference type:%s",Al_type);fflush(stdout);//WIRE

								//ITK_CALL(AE_ask_dataset_ref_count(secondary_objectsAl[xx],&referencenumberfound));
								//printf("\nreferencenumberfound =%d\n",referencenumberfound);
								//
								//for(j=0;j<referencenumberfound;j++)
								//{

								ITK_CALL(AE_find_dataset_named_ref(secondary_objectsAl[xx],0,Alrefname,&Alreftype,&Alrefobject));
								printf("\n after  AE_find_dataset_named_ref  \n "); fflush(stdout);

								ITK_CALL(BOM_line_look_up_attribute ("bl_rev_checked_out",&iItemChkdOutA));
								ITK_CALL(BOM_line_ask_attribute_string (A_Childobject, iItemChkdOutA, &Al_ChildChkOutValue));

								printf("\n [%d] CheckedOut value of alias part is [%s]\n",AChldPrts+1,Al_ChildChkOutValue);fflush(stdout);

								if(tc_strcmp(Al_ChildChkOutValue,"Y")==0)
								{
									printf("\n Error--Check-in all the dependent items, then check-in the main Alias Asm.....\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Check-in all the dependent items, then check-in the main Alias Asm");
									return ITK_err;
								}
								else
								{
									printf("\n Alias -- All dependent items are checked in so begin downloading the files \n");fflush(stdout);

									//if(Alorig_name)Alorig_name="";
									//printf("\n after Alorig_name null  \n "); fflush(stdout);

									ITK_CALL( IMF_ask_original_file_name(Alrefobject,Alorig_name));
									printf("\n  Alorig_name:%s",Alorig_name);fflush(stdout);

									//if((tc_strstr(Alorig_name,"WIRE")==0)||tc_strstr(Alorig_name,"wire")==0)
									if(tc_strcmp(Al_type,"WIRE")==0)
									{
										AliasTmpenvName = malloc(1500);
										tc_strcpy(AliasTmpenvName,AliasenvNameCpy);
										printf("\n ALIAS TmpenvName  is:%s\n",AliasTmpenvName);fflush(stdout);
										// call shells to create dir
										str = malloc(1500);

										tc_strcpy(str,"");
										tc_strcat(str,AliasenvName);
										tc_strcat(str,"/");
										tc_strcat(str,"ALIAS_DIR.sh ");
										tc_strcat(str,AliasTmpenvName);

										printf("\n str DownloadPath DIR :%s",str);fflush(stdout);

										system(str);

										printf("\n AFTER SHELL str DownloadPath DIR :%s",str);fflush(stdout);

										tc_strcpy(AliasDownloadPath,AliasTmpenvName);
										tc_strcat(AliasDownloadPath,"/");
										tc_strcat(AliasDownloadPath,Alorig_name);
										printf("\n Alias files DownloadPath:%s",AliasDownloadPath);fflush(stdout);
										IMF_export_file(Alrefobject,AliasDownloadPath);
										//IMF_export_file(Alorig_name,AliasDownloadPath);

										printf("\n after downloading ALIAS file \n");fflush(stdout);
									}
									else
									{
										printf("\n NOT WIRE TYPE \n");fflush(stdout);
									}
								}
							}
						}

						ITK_CALL(AE_find_datasettype("Text", &datasettype));
						tc_strcpy(reference_nameDS,"Text");

						DsetID = NULL;
						DsetID=(char *) MEM_alloc(32);
						tc_strcpy(DsetID,"");
						tc_strcat(DsetID,AliasItem_id);

						printf("\n\t ALIAS DsetID --  [%s]\n",DsetID); fflush(stdout);

						ITK_CALL(PREF_ask_char_value("ALIAS_TEXTPATH", 0 , &AliastxtName ));
						printf("\n ALIAS_TEXTPATH issss  %s\n",AliastxtName);fflush(stdout);

						if(!AliastxtName)
						{
						printf("\n ALIAS cannot access in AliastxtName :%s\n", AliastxtName );fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Directory not found. Please check ALIAS_TEXTPATH");
						return ITK_errStore;
						}

						AliastxtNameCpy = malloc(1500);

						tc_strcpy(AliastxtNameCpy,AliastxtName);
						tc_strcat(AliastxtNameCpy,"/");
						tc_strcat(AliastxtNameCpy,AliasItem_id);
						tc_strcat(AliasenvNameCpy,"_");
						tc_strcat(AliasenvNameCpy,AliasRev);
						tc_strcat(AliasenvNameCpy,"_");
						tc_strcat(AliasenvNameCpy,AliasSeq);
						tc_strcat(AliastxtNameCpy,".txt");

						printf("\n FULL PATH IS :%s\n", AliastxtNameCpy );fflush(stdout);

						strtxt = malloc(1500);

						tc_strcpy(strtxt,"");
						tc_strcat(strtxt,AliastxtName);
						tc_strcat(strtxt,"/");
						tc_strcat(strtxt,"ALIAS_TEXT.sh ");
						tc_strcat(strtxt,AliastxtNameCpy);

						printf("\n strtxt DownloadPath DIR :%s",strtxt);fflush(stdout);

						system(strtxt);

						//ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"Dataset Creation Tool",AliasItem_id,AliasItemRev_id,&aNewDataset));
						ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"Dataset Creation Tool","","",&aNewDataset));
						//ITK_CALL(AE_save_myself(aNewDataset));
						printf("\n\t after AE_save_myself--  \n"); fflush(stdout);

						//ITK_CALL(IMF_create_file(AliastxtNameCpy,SS_TEXT,&file_tag,&file_descriptor));	//not working
						//printf("\n\t after IMF_create_file--  \n"); fflush(stdout);


						ITK_CALL(IMF_import_file(AliastxtNameCpy,NULL, SS_TEXT, &file_tag, &file_descriptor));
						printf("\n\t after IMF_import_file \n"); fflush(stdout);

						//ITK_CALL(save_object(file_tag));
						//printf("\n\t save_object file_tag"); fflush(stdout);

						ITK_CALL(AOM_save(file_tag));

						ITK_CALL(AOM_lock(aNewDataset));
						printf("\n\t after AOM_save FIRST TIME -  \n"); fflush(stdout);

						//ITK_CALL(IMF_set_original_file_name(file_tag,AliasItem_id));
						//printf("\n\t File saved---> [%s]",AliasItem_id); fflush(stdout);

						//ITK_CALL(AE_add_dataset_named_ref2(aNewDataset,reference_nameDS,tagRefType,file_tag));
						ITK_CALL(AE_add_dataset_named_ref2(aNewDataset,reference_nameDS,tagRefTypeText,file_tag));

						printf("\n\t after named reference ALIAS \n"); fflush(stdout);

						ITK_CALL(AOM_save(aNewDataset));
						printf("\n\t AOM_save Dataset ALIAS \n"); fflush(stdout);
						ITK_CALL(AOM_unlock(aNewDataset));

						ITK_CALL(GRM_create_relation(objTag,aNewDataset,Relatn_type1,NULLTAG,&relation));
						printf("\n\t after creating relation between dataset and alias asm\n"); fflush(stdout);
						ITK_CALL(GRM_save_relation(relation));
						ITK_CALL(AOM_refresh(objTag,0));
						printf("\n\t after AOM_refresh 2ND TIME alias \n"); fflush(stdout);


						/*tc_strcpy(AliasFileName,AliasShellEnvName);
						tc_strcat(AliasFileName,"/Alias.sh");
						tc_strcat(AliasFileName," ");
						tc_strcat(AliasFileName,AliasItem_id);
						tc_strcat(AliasFileName," ");
						tc_strcat(AliasFileName,AliasRev);
						tc_strcat(AliasFileName," ");
						tc_strcat(AliasFileName,AliasSeq);
						tc_strcat(AliasFileName," ");
						printf("\n ALIAS FileName before system calling shell : %s\n", AliasFileName);fflush(stdout);

						system(AliasFileName);

						printf("\n ALIAS After excecuting shell : %s\n", AliasFileName);fflush(stdout);


						ITK_CALL(GRM_list_secondary_objects_only(objTag,reln_typeAl,&Alias_attchs,&secondary_objectsAl));

						printf("\n ALIAS Total Secondary Objects Found for ASM [%s] are [%d]\n",AliasItem_id,Alias_attchs);fflush(stdout);

						if(Alias_attchs>0)
						{
						for (revloop=0;revloop<Alias_attchs ; revloop++)
						{
						printf("\n\t "); fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(secondary_objectsAl[revloop],"object_type",&Alobject_type));
						if(TCTYPE_ask_object_type(secondary_objectsAl[revloop],&AlsecObjTypeTag));
						if(TCTYPE_ask_name(AlsecObjTypeTag,Altype_name2));
						printf("\n\t Alias Part type_name is  :%s ",Altype_name2); fflush(stdout);

						if((tc_strcmp(Altype_name2,"T5_Alias")==0) && (tc_strstr(AliasShellEnvName,".wire")!=NULL))
						{
						ITK_CALL(AOM_UIF_ask_value(secondary_objectsAl[revloop],"ref_list",&sRef_list));

						printf("\t Alobject_type=:%s is found in revision\n",Alobject_type);fflush(stdout);

						if (tc_strstr(AliasShellEnvName,".wire")!=NULL)
						{
						ITK_CALL(AE_find_datasettype("WIRE", &datasettype));
						tc_strcpy(reference_nameDS,"T5_Wire");

						ITK_CALL(AE_ask_dataset_named_refs(secondary_objectsAl[revloop],&refnum,&namedRef_tag));
						printf(" \n\t refnum: %d \n\t",refnum);fflush(stdout);
						if(refnum == 0)
						{
						ITK_CALL(AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list));
						printf("\n\t ref_count--->%d",ref_count); fflush(stdout);

						ITK_CALL(IMF_import_file(AliasShellEnvName,NULL, SS_BINARY, &filetag, &fileDescriptor));
						printf("\n\t After IMF_import_file"); fflush(stdout);

						ITK_CALL(AOM_save(filetag));
						printf("\n\t AOM_save filetag"); fflush(stdout);

						ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
						result = AOM_save(filetag);
						printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

						ITK_CALL(AOM_lock(secondary_objectsAl[revloop]));

						ITK_CALL(AE_add_dataset_named_ref2(secondary_objectsAl[revloop],reference_nameDS,tagRefType,filetag));

						ITK_CALL(AOM_save(secondary_objectsAl[revloop]));
						printf("\n\t AOM_save Dataset"); fflush(stdout);

						ITK_CALL(AOM_unlock(secondary_objectsAl[revloop]));
						}
						printf("\n\t Named reference found for DR %s",AliasItem_id); fflush(stdout);
						}
						}
						}
						}
						else
						{
						printf("\n\t Dataset NOT Found so creating Dataset \n");fflush(stdout);

						if (strstr(AliasShellEnvName,".wire")!=NULL)
						{
							ITK_CALL(AE_find_datasettype("WIRE", &datasettype));
							strcpy(reference_nameDS,"T5_Wire");
						}

						DsetID = NULL;
						DsetID=(char *) MEM_alloc(32);
						tc_strcpy(DsetID,"");
						tc_strcat(DsetID,AliasItem_id);

						printf("\n\t DsetID --  [%s]\n",DsetID); fflush(stdout);

						ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"Dataset Creation Tool",AliasItem_id,AliasItemRev_id,&aNewDataset));

						ITK_CALL(IMF_import_file(AliasShellEnvName,NULL, SS_BINARY, &filetag, &fileDescriptor));
						printf("\n\t After IMF_import_file"); fflush(stdout);

						ITK_CALL(AOM_save(filetag));
						printf("\n\t AOM_save filetag"); fflush(stdout);

						ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
						result = AOM_save(filetag);
						printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

						ITK_CALL(AOM_lock(aNewDataset));
						ITK_CALL(AE_add_dataset_named_ref2(aNewDataset,reference_nameDS,tagRefType,filetag));

						ITK_CALL(AOM_save(aNewDataset));
						printf("\n\t AOM_save Dataset"); fflush(stdout);
						ITK_CALL(AOM_unlock(aNewDataset));
						ITK_CALL(GRM_create_relation(objTag,aNewDataset,Relatn_type1,NULLTAG,&relation));
						ITK_CALL(GRM_save_relation(relation));
						ITK_CALL(AOM_refresh(objTag,0));*/

						if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchsd2,&secondary_objectsd1)!=ITK_ok)PrintErrorStack();
						printf("\n alias datasets in preaction on checkin  :%d\n",n_attchsd2);fflush(stdout);

						if(n_attchsd2>0)
						{
							for (k1=0; k1<n_attchsd2; k1++)
							{
								primaryd1=secondary_objectsd1[k1];
								if(TCTYPE_ask_object_type(primaryd1,&objTypeTagDid1))PrintErrorStack();
								if(TCTYPE_ask_name(objTypeTagDid1,type_name3d))PrintErrorStack();
								printf("\n type_name3d in preaction on checkin  :%s\n",type_name3d);fflush(stdout);

								if (tc_strcmp(type_name3d,"Text")==0)
								{
									printf("\n Call service to convert text to alias \n");fflush(stdout);

									ITK_CALL(AOM_ask_value_string(primaryd1,"object_name",&DatasetNameD));
									AlTEXTFileName=malloc(2000);
									tc_strcpy(AlTEXTFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
									tc_strcat(AlTEXTFileName,Item_id);
									tc_strcat(AlTEXTFileName," ");
									tc_strcat(AlTEXTFileName,"-r='");
									tc_strcat(AlTEXTFileName,desc.revision_id);
									tc_strcat(AlTEXTFileName,"'");
									tc_strcat(AlTEXTFileName," ");
									tc_strcat(AlTEXTFileName,"-dt=Text -dn='");
									tc_strcat(AlTEXTFileName,DatasetNameD);
									tc_strcat(AlTEXTFileName,"'");
									tc_strcat(AlTEXTFileName," ");
									tc_strcat(AlTEXTFileName,"-pr=1 -pn=SIEMENS  -tn=aliasasmconv -ty=COMMAND_LINE");
									printf("\n AlTEXTFileName before system is Text preaction on checkin =>%s\n", AlTEXTFileName);fflush(stdout);

									system(AlTEXTFileName);

									printf("\n AlTEXTFileName dispatcher_create_rqst shell Text preaction on checkin=>%s\n", AlTEXTFileName);fflush(stdout);

									CALLAPI(GRM_find_relation(objTag,primaryd1,Relatn_type1,&relation_fnd3));
									CALLAPI(RES_is_checked_out(primaryd1,&checkout2));
									printf("\n  checkout2 ====== %d\n",checkout2);fflush(stdout);
								}
								else
								{
									printf("\n not a TEXT file so no need to call test to assembly \n");fflush(stdout);
								}
							}
							if (checkout2==0)
							{
								printf("\n DataSet relation delete TEXT FILE \n");fflush(stdout);
								CALLAPI(GRM_delete_relation	(relation_fnd3));
								printf("\n DataSet relation delete success  TEXT FILE \n");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n no dependent child items under this assembly \n");fflush(stdout);
					}
				}
				else
				{
					printf("\n  checkin_method_1--design group not ST and dataset attached hence skipping alias assy management \n");fflush(stdout);
				}
				//}
				//else
				//{
				//printf("\n dataset greater than 0 \n");fflush(stdout);
				//}
				/**************************************************ALIAS ASSY MANAGEMENT***************************************************/
				/**********************************************************END*************************************************************/

				/***********Starting Dispatcher request code for JT creation by Sharvari on 16-12-2016**************************/

				printf("\n checkin_method_1--TCDCFound CMI2Part call JT service for CATPART..CatPrtCN:[%d] CatPrdt:[%d] CmiDrwCnt:[%d] ",CatPrtCN,CatPrdt,CmiDrwCnt);fflush(stdout);

				if ( ( CatPrtCN > 0 ) || ( CatPrdt > 0 ) || ( CmiDrwCnt > 0) )
				{
					if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchsd,&secondary_objectsd)!=ITK_ok)PrintErrorStack();
					printf("\n checkin_method_1--Number of DId :%d ",n_attchsd);fflush(stdout);

					if(n_attchsd>0)
					{
						for (k = 0; k < n_attchsd; k++)
						{
							primaryd=secondary_objectsd[k];
							if(TCTYPE_ask_object_type(primaryd,&objTypeTagDid))PrintErrorStack();
							if(TCTYPE_ask_name(objTypeTagDid,type_name2d))PrintErrorStack();
							printf("\n checkin_method_1--type_name2d  :%s ",type_name2d);fflush(stdout);

							if (strcmp(type_name2d,"CMI2Product")==0)
							{
								ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
								JTTransFileName=malloc(2000);
								strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
								//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

								strcat(JTTransFileName,Item_id);
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-r='");
								//strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								//strcat(JTTransFileName, "-dt=CMI2Part");
								strcat(JTTransFileName, "-dt=CMI2Product  -dn='");
								strcat(JTTransFileName,DatasetName);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5prdtojt -ty=COMMAND_LINE");
								printf("\nTCDCJTTransFileName before system is CMI2Product =>[%s]\n", JTTransFileName);fflush(stdout);
								system(JTTransFileName);
								//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
								//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
								//system(JTTransFileName);
								printf("\n checkin_method_1--TCDCAfter dispatcher_create_rqst shell CMI2Product=>[%s]\n", JTTransFileName);fflush(stdout);
							}
							if (strcmp(type_name2d,"CMI2Part")==0)
							{
								ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
								JTTransFileName=malloc(2000);
								strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
								//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

								strcat(JTTransFileName,Item_id);
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-r='");
								//strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								//strcat(JTTransFileName, "-dt=CMI2Part");
								strcat(JTTransFileName, "-dt=CMI2Part  -dn='");
								strcat(JTTransFileName,DatasetName);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5tojt -ty=COMMAND_LINE");
								printf("\n checkin_method_1--TCDCJTTransFileName before system catpart is=>[%s]\n", JTTransFileName);fflush(stdout);
								system(JTTransFileName);
								//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
								//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
								//system(JTTransFileName);
								printf("\n checkin_method_1--TCDCAfter dispatcher_create_rqst shell catpartt=>[%s]\n", JTTransFileName);fflush(stdout);
							}
							if (strcmp(type_name2d,"CMI2Drawing")==0)
							{
								ITK_CALL(AOM_ask_value_string(primaryd,"object_name",&DatasetName));
								JTTransFileName=malloc(2000);
								strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
								//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

								strcat(JTTransFileName,Item_id);
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-r='");
								//strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,desc.revision_id);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								//strcat(JTTransFileName, "-dt=CMI2Part");
								strcat(JTTransFileName, "-dt=CMI2Drawing  -dn='");
								strcat(JTTransFileName,DatasetName);
								strcat(JTTransFileName,"'");
								strcat(JTTransFileName," ");
								strcat(JTTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5drwtopdf -ty=COMMAND_LINE");
								printf("\n checkin_method_1--TCDCJTTransFileName before system is CMI2Drawing =>%s\n", JTTransFileName);fflush(stdout);
								system(JTTransFileName);
								//printf("\nTCDCAfter excecuting shell=>%s\n", JTTransFileName);fflush(stdout);
								//printf("\nTCDCJTTransFileName dispatcher_create_rqst before system is=>%s\n", JTTransFileName);fflush(stdout);
								//system(JTTransFileName);
								printf("\n checkin_method_1--TCDCAfter dispatcher_create_rqst shell CMI2Drawing=>[%s]\n", JTTransFileName);fflush(stdout);

							}
						}
					}
				}

				/************** Alias begin********************/
				if(GRM_list_secondary_objects_only(objTag,reln_type,&n_attchsd1,&secondary_objectsd1)!=ITK_ok)PrintErrorStack();
				printf("\n checkin_method_1--alias datasets in preaction on checkin: [%d] ",n_attchsd1);fflush(stdout);

				if(n_attchsd1>0)
				{
					for (k1=0; k1<n_attchsd1; k1++)
					{
						primaryd1=secondary_objectsd1[k1];
						if(TCTYPE_ask_object_type(primaryd1,&objTypeTagDid1))PrintErrorStack();
						if(TCTYPE_ask_name(objTypeTagDid1,type_name3d))PrintErrorStack();
						printf("\n checkin_method_1--type_name3d in preaction on checkin:[%s]\n",type_name3d);fflush(stdout);

						if (tc_strcmp(type_name3d,"T5_Alias")==0)
						{
							printf("\n checkin_method_1--Call service to convert Alias to CATPart \n");fflush(stdout);

							ITK_CALL(AOM_ask_value_string(primaryd1,"object_name",&DatasetNameD));
							AlTransFileName=malloc(2000);
							tc_strcpy(AlTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");

							tc_strcat(AlTransFileName,Item_id);
							tc_strcat(AlTransFileName," ");
							tc_strcat(AlTransFileName,"-r='");

							tc_strcat(AlTransFileName,desc.revision_id);
							tc_strcat(AlTransFileName,"'");
							tc_strcat(AlTransFileName," ");

							tc_strcat(AlTransFileName, "-dt=T5_Alias  -dn='");
							tc_strcat(AlTransFileName,DatasetNameD);
							tc_strcat(AlTransFileName,"'");
							tc_strcat(AlTransFileName," ");
							tc_strcat(AlTransFileName,"-pr=1 -pn=SIEMENS    -tn=aliastocatpart -ty=COMMAND_LINE");
							printf("\n checkin_method_1--AlTransFileName before system is T5_Alias preaction on checkin =>[%s]\n", AlTransFileName);fflush(stdout);

							system(AlTransFileName);

							printf("\n checkin_method_1--AlTransFileName dispatcher_create_rqst shell T5_Alias preaction on checkin=>[%s]\n", AlTransFileName);fflush(stdout);
						}
						else
						{
							printf("\n checkin_method_1--no need to call Alias to CATpart \n");fflush(stdout);
						}
					}
				}
				/************** Alias ends********************/

				//Added by Ajinkya on 13 June for catiav5toanalysis//
				//added -----------//

				if(QRY_find("ControlObjects", &qryCmiTag));
				if (qryCmiTag)
				{
					printf("\n checkin_method_1--qryCmiTag:Found Query ControlObjects ");fflush(stdout);

					cmiCtrObjct[0] = "CheckinCtr";
					if(QRY_execute(qryCmiTag, n_refcmi,	cmi_qry_entry, cmiCtrObjct, &rsltcmiCount, &cmiCntrlObjectTag));

					printf("\n checkin_method_1--rsltcmiCount :%d:", rsltcmiCount); fflush(stdout);
					if(rsltcmiCount > 0)
					{
						if (AOM_ask_value_string(cmiCntrlObjectTag[0],"t5_Userinfo1",&cminfo1)!=ITK_ok)PrintErrorStack();
						printf("\n checkin_method_1--cminfo1 is.:[%s]", cminfo1);fflush(stdout);

						if(tc_strcmp(cminfo1,"Y") == 0)
						{
							printf("\n checkin_method_1--Inside ~~control obejct as value of infoline1-- %s  \n",cminfo1); fflush(stdout);

							Part_Desg=subString(Item_id, 8, 2);
							desgrpcmi=subString(Item_id, 4, 2);

							printf("\n checkin_method_1--5th and 6th digits are[%s]", desgrpcmi);fflush(stdout);
							printf("\n checkin_method_1--9th and 10th digits are[%s]", Part_Desg);fflush(stdout);

							if((tc_strcmp(desgrpcmi,"60")==0) ||  (tc_strcmp(desgrpcmi,"61")==0) ||(tc_strcmp(desgrpcmi,"62")==0) || (tc_strcmp(desgrpcmi,"63")==0)|| (tc_strcmp(desgrpcmi,"64")==0)
							|| (tc_strcmp(desgrpcmi,"65")==0) ||  (tc_strcmp(desgrpcmi,"70")==0) ||(tc_strcmp(desgrpcmi,"71")==0)|| (tc_strcmp(desgrpcmi,"72")==0)|| (tc_strcmp(desgrpcmi,"73")==0)
							|| (tc_strcmp(desgrpcmi,"74")==0) ||  (tc_strcmp(desgrpcmi,"77")==0)|| (tc_strcmp(desgrpcmi,"79")==0) || (tc_strcmp(desgrpcmi,"80")==0)|| (tc_strcmp(desgrpcmi,"88")==0)
							|| (tc_strcmp(desgrpcmi,"89")==0) )
							{
								printf("\n checkin_method_1--Printing required design group value :[%s]",desgrpcmi);fflush(stdout);

								if((tc_strcmp(Part_Desg,"33")==0) ||  (tc_strcmp(Part_Desg,"82")==0) || (tc_strcmp(Part_Desg,"86")==0))
								{
									printf("\n checkin_method_1--Inside required 9th and 10th digit value:[%s]",Part_Desg);fflush(stdout);
									if (tc_strcmp(type_name3d,"CMI2Part")==0)
									{
										printf("\n checkin_method_1--Call service to convert catiav5toanalysis \n");fflush(stdout);

										ITK_CALL(AOM_ask_value_string(primaryd1,"object_name",&DatasetNameD));
										AlTransFileName=malloc(2000);
										tc_strcpy(AlTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");

										tc_strcat(AlTransFileName,Item_id);
										tc_strcat(AlTransFileName," ");
										tc_strcat(AlTransFileName,"-r='");

										tc_strcat(AlTransFileName,desc.revision_id);
										tc_strcat(AlTransFileName,"'");
										tc_strcat(AlTransFileName," ");

										tc_strcat(AlTransFileName, "-dt=CMI2Part  -dn='");
										tc_strcat(AlTransFileName,DatasetNameD);
										tc_strcat(AlTransFileName,"'");
										tc_strcat(AlTransFileName," ");
										tc_strcat(AlTransFileName,"-pr=1 -pn=SIEMENS    -tn=catiav5toanalysis -ty=COMMAND_LINE");

										printf("\n checkin_method_1--CMI2Part AlTransFileName before system is CMI2Part preaction on checkin =>[%s] ", AlTransFileName);fflush(stdout);

										system(AlTransFileName);

										printf("\n checkin_method_1--CMI2Part AlTransFileName dispatcher_create_rqst shell CMI2Part preaction on checkin=>[%s] ", AlTransFileName);fflush(stdout);
									}
									else
									{
										printf("\n checkin_method_1--no need to call CMI2Part to CATpart \n");fflush(stdout);
									}
								}
							}
						}
						else
						{
							 printf("\n checkin_method_1--Else loop ## start control obejct  value of infoline1--[%s] ",cminfo1); fflush(stdout);
						}
					}
				}
				//end on 13 June//
			}

			printf("\n checkin_method_1--Know LHRhFlag going to change values to -1 ");fflush(stdout);
			LHRhFlag= -1;

			//Hrishikesh TZ 1.71
			char *sPartnumber = NULL;
			if( AOM_ask_value_string(objTag,"item_id",&sPartnumber)!=ITK_ok);PrintErrorStack();
			//end

			//RRR TCUA 1.45
			printf("\n checkin_method_1--sPartnumber:[%s] Desc_obj2: [%s] sPartType1: [%s] DesignGrpProE:[%s] sDesignGrp:[%s]  ProAsmCN:[%d]  CatPrdt:[%d]",sPartnumber,Desc_obj2,sPartType1,DesignGrpProE,sDesignGrp,ProAsmCN,CatPrdt);fflush(stdout);

			if(tc_strcmp(desgrp,"ST")!=0) //new adi
			{
				//if((tc_strstr(Desc_obj2,"NR") != NULL) && (tc_strcmp(sPartType1,"G")==0))
				if((tc_strstr(Desc_obj2,"NR") != NULL) && (tc_strcmp(sPartType1,"G")==0) && (tc_strstr(sPartnumber,"GCK")==NULL)  ) //GCK added Hrishikesh TZ 1.71
				{
					CADDatasetExistflag = 1;

					if((tc_strstr(DesignGrpProE,sDesignGrp)!=NULL)&&((ProAsmCN==0)&&(CatPrdt==0)&&(ProPrtCN==0)&&(CatPrtCN==0))) //Adi 1.32
					{
						CADDatasetExistflag=0;

						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Please attach ProE CAD-dataset to 'NR' revision. You cannot check-in this ProE GroupID without CAD.");
						return ITK_errStore;
					}
					printf("\n checkin_method_1--CADDatasetExistflag:: %d ",CADDatasetExistflag);fflush(stdout);
				}
			}
			//

			/*** RRR...Start..Por-assembly membership childs validation for ERC released or attached to same DML warning msg is added as per requirement from migration team of TCUA to TCE  ***/
			printf("\n checkin_method_1--TCDCProAsmCN :[%d] ",ProAsmCN);fflush(stdout);
			if( ProAsmCN > 0 )
			{
				int n_entry = 1;
				int rsltCount = 0;
				tag_t qryTag = NULLTAG;
				tag_t *CntrolObjectTag = NULLTAG;
				char *qry_entry[1] = {"SYSCD"};
				char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
				char *info5r = NULL;
				char *info1r = NULL;

				if(QRY_find("ControlObjects", &qryTag));
				if (qryTag)
				{
					printf("\n checkin_method_1--ERCVali:Found Query ControlObjects ");fflush(stdout);
					qry_values2[0] = "ERCVali";
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
					printf("\t  rsltCount :%d:", rsltCount); fflush(stdout);

					if(rsltCount > 0)
					{
						if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo5",&info5r)!=ITK_ok)   PrintErrorStack();
						printf(" info5r is = [%s] ", info5r);fflush(stdout);
						if (AOM_ask_value_string(CntrolObjectTag[0],"t5_Userinfo1",&info1r)!=ITK_ok)   PrintErrorStack();
						printf(" info1r is = [%s]", info1r);fflush(stdout);
					}
				}
				else
				{
					printf("\n  checkin_method_1--ERCVali:Not Found Query ControlObjects \n");fflush(stdout);
				}

				if (tc_strcmp(info5r,"ON")==0)
				{
					int result2=0, n_attch_asm=0, ip=0, status_count=0, rs=0;
					tag_t ProRelation_type, *ProAsmMemtag, *status_list= NULLTAG;
					tag_t ProObjItemMaster = NULLTAG;
					tag_t ProObjRev = NULLTAG;
					char *ProObjName = NULL;
					char *ProObjId = NULL;
					char *ProObjRelSt = NULL;
					char* ProProjectId = NULL ;
					char* ProObjRevSeq = NULL ;
					char* ErcReviewChildList = NULL;
					char* ErcCarryOverChildList = NULL;
					char* ErcLatestChildList = NULL;
					char* ErcReviewChildTextPath = NULL;
					int RlzRevFlag = 0;
					int ProAsmChildErrorflag=0;
					int ProAsmCarryOverChildErrorflag=0;
					int ProAsmLatestChildErrorflag=0;
					int LatestRevUsedFlag=0;
					FILE *textfp = NULL;
					tag_t file = NULLTAG;
					IMF_file_t descriptor;

					ErcReviewChildList = (char* ) malloc ( 5000 * sizeof ( char ) ) ;
					ErcCarryOverChildList = (char* ) malloc (5000 * sizeof ( char ) ) ;
					ErcLatestChildList = (char* ) malloc (2000 * sizeof ( char ) ) ;

					tc_strcpy ( ErcReviewChildList, "\n1. List of 'ERC Review' childs are used under assembly CAD Creo-Membership relation, are to be released with respective DMLs:\n");
					tc_strcpy ( ErcCarryOverChildList, "\n2. Please use 'ERC released' revision of below Carry-over child parts used under assembly CAD: \n");
					tc_strcpy ( ErcLatestChildList, "\n3. Following Latest revision of childs are not attached to assembly CAD Creo-Membership relation: \n");

					result2 = GRM_find_relation_type("Pro2_membership", &ProRelation_type);
					printf("\n checkin_method_1--GRM_find_relation_type Pro2_membership ----> :%d:",result2);fflush(stdout);

					ITK_CALL(GRM_list_secondary_objects_only(primarydProAsmDS, ProRelation_type, &n_attch_asm,&ProAsmMemtag));
					printf("\n checkin_method_1--ProAsmMem from ProAsm dataset :%d: ",n_attch_asm);fflush(stdout);

					if(n_attch_asm>0)
					{
						ProAsmChildErrorflag=0;
						ProAsmCarryOverChildErrorflag=0;
						ProAsmLatestChildErrorflag=0;

						for (ip = 0; ip < n_attch_asm; ip++)
						{
							ifail = AOM_ask_value_string(ProAsmMemtag[ip],"item_id",&ProObjName);
							ifail = AOM_ask_value_string(ProAsmMemtag[ip],"item_revision_id",&ProObjId);
							ifail = AOM_ask_value_string(ProAsmMemtag[ip],"t5_ProjectCode",&ProProjectId);

							printf("\n checkin_method_1--Creo-Child: [%s]  revision: [%s]  ProProjectId: [%s] ",ProObjName,ProObjId,ProProjectId); fflush(stdout);

							RlzRevFlag=0;
							if (WSOM_ask_release_status_list(ProAsmMemtag[ip],&status_count,&status_list)==ITK_ok)
							printf("\n checkin_method_1--status_count: [%d] => ", status_count);fflush(stdout);

							for (rs = 0; rs < status_count; rs++)
							{
								if (AOM_ask_name(status_list[rs], &ProObjRelSt)==ITK_ok)
								printf("\t :%s ", ProObjRelSt);fflush(stdout);
								if ((tc_strcmp(ProObjRelSt,"T5_LcsErcRlzd")==0)||(tc_strcmp(ProObjRelSt,"ERC Released")==0))
								{
									RlzRevFlag=1;
									break;
								}
							}
							printf("  ----RlzRevFlag: %d ", RlzRevFlag);fflush(stdout);

							if ((tc_strstr(info1r,ProProjectId)==NULL) && (tc_strcmp(info1r,"")!=0))
							{
								printf("\n checkin_method_1--Checking Carry-over Project Part: %s , %s , %s ",ProObjName,ProObjId,ProProjectId); fflush(stdout);
								printf(" if-Condn-Carry-over--RlzRevFlag: %d ", RlzRevFlag);fflush(stdout);
								if (RlzRevFlag==0)
								{
									tc_strcat ( ErcCarryOverChildList, ProObjName );
									tc_strcat ( ErcCarryOverChildList, "/" );
									tc_strcat ( ErcCarryOverChildList, ProObjId );
									tc_strcat ( ErcCarryOverChildList, ",\n");

									ProAsmCarryOverChildErrorflag=ProAsmCarryOverChildErrorflag+1;
								}
							}
							else
							{
								LatestRevUsedFlag=0;

								if (ITEM_find_item(ProObjName,&ProObjItemMaster)==ITK_ok)
								if (ITEM_ask_latest_rev(ProObjItemMaster, &ProObjRev)==ITK_ok)
								ifail = AOM_ask_value_string(ProObjRev,"item_revision_id",&ProObjRevSeq);

								printf("\n checkin_method_1--Comparing::: ProObjRevSeq: [%s]   ProObjId: [%s]",ProObjRevSeq, ProObjId);fflush(stdout);

								if (tc_strcmp(ProObjId,ProObjRevSeq)==0)
								{
									LatestRevUsedFlag=1;

									printf("  LatestRevUsedFlag: [%d]",LatestRevUsedFlag);fflush(stdout);
									if (RlzRevFlag==0)
									{
										tc_strcat ( ErcReviewChildList, ProObjName );
										tc_strcat ( ErcReviewChildList, "/" );
										tc_strcat ( ErcReviewChildList, ProObjId );
										tc_strcat ( ErcReviewChildList, ",\n");

										ProAsmChildErrorflag=ProAsmChildErrorflag+1;

										printf("  ProAsmChildErrorflag: [%d]",ProAsmChildErrorflag);fflush(stdout);
									}
								}
								else
								{
									tc_strcat ( ErcLatestChildList, ProObjName );
									tc_strcat ( ErcLatestChildList, "/" );
									tc_strcat ( ErcLatestChildList, ProObjId );
									tc_strcat ( ErcLatestChildList, ",\n");

									ProAsmLatestChildErrorflag=ProAsmLatestChildErrorflag+1;
								}
							}
						}

						printf("\n checkin_method_1--ProAsmChildErrorflag: [%d]",ProAsmChildErrorflag);fflush(stdout);
						if ( ProAsmChildErrorflag > 0 )
						{
							int nReq_attchs = 0;
							int ir = 0;
							tag_t req_rel_t = NULLTAG;
							tag_t ds_req_rel_t = NULLTAG;
							tag_t wordLatestDat_t = NULLTAG;
							tag_t DataSet_tag = NULLTAG;
							tag_t secReqObjTypeTag = NULLTAG;
							tag_t *sec_Req_objs = NULLTAG;
							char type_nameR[TCTYPE_name_size_c+1];
							tag_t datasettype, NewTextDS, Fndrelation = NULLTAG;

							printf("\n checkin_method_1--Creating text dataset for ERC Review parts....");fflush(stdout);

							//if(GRM_find_relation_type("IMAN_requirement", &req_rel_t)!=ITK_ok)PrintErrorStack();
							if(GRM_find_relation_type("IMAN_reference", &req_rel_t)!=ITK_ok)PrintErrorStack();

							if(GRM_list_secondary_objects_only(objTag, req_rel_t ,&nReq_attchs,&sec_Req_objs)==ITK_ok)
							printf("\n checkin_method_1--Text--nReq_attchs: %d",nReq_attchs);fflush(stdout);
							if(nReq_attchs>0)
							{
								for (ir=0; ir<nReq_attchs; ir++)
								{
									if(TCTYPE_ask_object_type(sec_Req_objs[ir], &secReqObjTypeTag));
									if(TCTYPE_ask_name(secReqObjTypeTag,type_nameR));
									printf("\n checkin_method_1--ir: %d  type_nameR: %s",ir,type_nameR);fflush(stdout);

									if (tc_strcmp(type_nameR,"Text")==0)
									{
										DataSet_tag = sec_Req_objs[ir];

										//if(GRM_find_relation( DataSet_tag, objTag, req_rel_t ,&Fndrelation)!=ITK_ok)PrintErrorStack();
										//if(Fndrelation == NULLTAG)
										//{
										if(GRM_find_relation( objTag, DataSet_tag, req_rel_t ,&Fndrelation)!=ITK_ok)PrintErrorStack();
										//}
										if(Fndrelation != NULLTAG)
										{
											printf("\t ---removing old relation " ); fflush(stdout);
											if(GRM_delete_relation(Fndrelation)!=ITK_ok)PrintErrorStack();
											printf("\t ..done\n" ); fflush(stdout);
										}
									}
								}
							}

							printf("\n checkin_method_1--CheckinItemId: [%s]", CheckinItemId);fflush(stdout);

							ErcReviewChildTextPath=(char *) MEM_alloc(200 * sizeof(char ));//create log file to attach to folder
							tc_strcpy(ErcReviewChildTextPath,"/tmp/");
							tc_strcat(ErcReviewChildTextPath,CheckinItemId);
							tc_strcat(ErcReviewChildTextPath,".txt");

							printf("\n checkin_method_1--ErcReviewChildTextPath: [%s]", ErcReviewChildTextPath);fflush(stdout);

							textfp = fopen(ErcReviewChildTextPath,"w");
							printf("\n checkin_method_1--ErcReviewChildList: %s\n",ErcReviewChildList);fflush(stdout);
							fprintf(textfp,"%s\n",ErcReviewChildList);fflush(textfp);

							if(textfp!=NULL)
							{
								fclose(textfp);
							}
							textfp=NULL;

							if(AE_find_datasettype("Text", &datasettype)==ITK_ok)
							if (datasettype == NULLTAG)
							{
								printf("\n checkin_method_1--Dataset Type 'Text' not found!\n");fflush(stdout);
								//exit (EXIT_FAILURE);
							}
							else
							{
								datasetItemId=(char *) MEM_alloc(100 * sizeof(char ));
								tc_strcpy(datasetItemId,CheckinItemId);
								tc_strcat(datasetItemId,"_ERCReviewChildList");

								printf("\n checkin_method_1--Dataset Creation, ");fflush(stdout);
								if(AE_create_dataset_with_id(datasettype,datasetItemId,"List of ERC Review parts","","",&NewTextDS)!=ITK_ok)PrintErrorStack();
								if(AE_save_myself(NewTextDS));
								printf(" Relation Creation, ");fflush(stdout);
								if(GRM_create_relation(objTag,NewTextDS,req_rel_t,NULLTAG,&ds_req_rel_t)!=ITK_ok)PrintErrorStack();
								printf(" done, ");fflush(stdout);
								if(AOM_load(ds_req_rel_t)!=ITK_ok)PrintErrorStack();
								printf(" load, ");fflush(stdout);
								if(GRM_save_relation(ds_req_rel_t)!=ITK_ok)PrintErrorStack();
								printf(" save, ");fflush(stdout);
								if(AE_ask_dataset_latest_rev(NewTextDS,&wordLatestDat_t));
								printf(" lst rev, ");fflush(stdout);
								if(AOM_refresh(wordLatestDat_t,TRUE)!=ITK_ok)PrintErrorStack();
								if(AE_import_named_ref(wordLatestDat_t,"Text",ErcReviewChildTextPath,NULL,SS_TEXT)!=ITK_ok)PrintErrorStack();
								if(AE_import_named_ref(NewTextDS,"Text",ErcReviewChildTextPath,NULL,SS_TEXT)!=ITK_ok)PrintErrorStack();
								printf(" name ref, ");fflush(stdout);
								if(AE_save_myself(wordLatestDat_t)!=ITK_ok)PrintErrorStack();
								if(AE_save_myself(NewTextDS));
								if(AOM_refresh (objTag, 0)!=ITK_ok)PrintErrorStack();
								printf(" refresh, ");fflush(stdout);
								//remove(ErcReviewChildTextPath);
								printf("\n checkin_method_1--DML Print report End. \n");fflush(stdout);
								if(ErcReviewChildTextPath) MEM_free(ErcReviewChildTextPath);
								if(datasetItemId) MEM_free(datasetItemId);
								printf("\n checkin_method_1--TEXT dataset is created...."); fflush(stdout);
							}
						}
						printf("\n checkin_method_1--ProAsmCarryOverChildErrorflag: [%d]  ProAsmLatestChildErrorflag: [%d]",ProAsmCarryOverChildErrorflag,ProAsmLatestChildErrorflag);fflush(stdout);
						if ((ProAsmCarryOverChildErrorflag > 0) || (ProAsmLatestChildErrorflag > 0))
						{
							if ((ProAsmCarryOverChildErrorflag > 0) && (ProAsmLatestChildErrorflag > 0))
							{
								tc_strcat ( ErcCarryOverChildList,ErcLatestChildList);
								ErcCarryOverChildList[strlen(ErcCarryOverChildList)] = '\0';
							}
							else if (ProAsmLatestChildErrorflag > 0)
							{
								tc_strcpy ( ErcCarryOverChildList,"");
								tc_strcat ( ErcCarryOverChildList,ErcLatestChildList);
								ErcCarryOverChildList[strlen(ErcCarryOverChildList)] = '\0';
							}
							printf("\n checkin_method_1--List: [%s]",ErcCarryOverChildList);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErcCarryOverChildList);

							return ITK_errStore;
						}
						printf("\n checkin_method_1--End of validation CreoAsm. ");fflush(stdout);
					} //End of if(n_attch_asm>0)

					printf("\n  checkin_method_1--End of validation--------- \n");fflush(stdout);
				} //End for if (tc_strcmp(info5r,"ON")==0)
			}
			/*** RRR...End..Por-assembly membership childs validation for ERC released or attached to same DML warning msg is added as per requirement from migration team of TCUA to TCE  ***/
		}
	}
	//fclose(fpSrc);


	if(QRY_find("ControlObjects", &CntrlObjQry));
	if (CntrlObjQry)
	{
		printf("\n checkin_method_1--ControlObjects query Found ");fflush(stdout);

		QryCntr_values[0] = "KeyCompCod" ;
		if(QRY_execute(CntrlObjQry, Key_qry_entry, QryCntr_entry, QryCntr_values, &CntlObjCount, &CntObj_Tag));
	}
	else
	{
		printf("\n checkin_method_1--ControlObjects query Not Found ");fflush(stdout);
	}

	printf("\n checkin_method_1--ControlObjects Count= [%d]",CntlObjCount);fflush(stdout);

	printf("\n checkin_method_1--Type Name= [%s]",type_name);fflush(stdout);

	if(CntlObjCount>0)
	{
		if (strcmp(type_name,"Design Revision")==0)
		{
			ITK_CALL(AOM_UIF_ask_value(objTag,"t5_ColourInd",&ColInd));

			printf("\n checkin_method_1--Color Ind= [%s]  ",ColInd);fflush(stdout);

			if (strcmp(ColInd,"Y")==0)
			{
				if( AOM_ask_value_string(objTag,"t5_PartType",&Key_PartType)!=ITK_ok);PrintErrorStack();
				printf("\n checkin_method_1--Part Type= [%s]  ",Key_PartType);fflush(stdout);

				if((tc_strcmp(Key_PartType,"A")==0 || tc_strcmp(Key_PartType,"C")==0))
				{
					if( AOM_ask_value_string(objTag,"item_revision_id",&Rev_idStr)!=ITK_ok);PrintErrorStack();

					printf("\n checkin_method_1--Rev_idStr is %s  ",Rev_idStr);fflush(stdout);
					if (tc_strstr(Rev_idStr,"NR")!=0)
					{
						ITK_CALL( AOM_ask_value_string(objTag,"t5_CategoryName",&KeyWordDesc)!=ITK_ok);
						printf("\n checkin_method_1--Key Word Desc is   %s  ",KeyWordDesc);fflush(stdout);

						ITK_CALL( AOM_ask_value_string(objTag,"t5_DesignGrp",&DgnGrp)!=ITK_ok);
						printf("\n checkin_method_1--Design Grp is   %s  ",DgnGrp);fflush(stdout);


						ITK_CALL( AOM_ask_value_string(objTag,"t5_PrtCatCode",&CmpCode)!=ITK_ok);
						printf("\n checkin_method_1--Comp code to be verify   %s  ",CmpCode);fflush(stdout);


						if((tc_strcmp(KeyWordDesc,"")==0) || (strcmp(KeyWordDesc,"")==0) || (strlen(KeyWordDesc)<=0))
						{
							printf("\n checkin_method_1--Keyword found Null does not needs to validate for Comp Code  ");fflush(stdout);
						}
						else if ((tc_strcmp(CmpCode,"")==0) || (strcmp(CmpCode,"")==0) || (strlen(CmpCode)<=0))
						{
							printf("\n checkin_method_1--Comp Code found Null does not needs to validate ");fflush(stdout);
						}
						else
						{

							Keyqry_values[0] = KeyWordDesc ;
							Keyqry_values[1] = DgnGrp;

							ITK_CALL(QRY_find("KeyWordQryforDR", &queryKey));
							if (queryKey)
							{
								ITK_CALL(QRY_execute(queryKey, Key_entries, qryKey_entries, Keyqry_values, &Key_found, &Keycntr_objects));
							}
							printf("\n checkin_method_1--Keyword Key_found:%d", Key_found);fflush(stdout);


							if(Key_found>0)
							{
								printf("\n checkin_method_1--Inside If ");fflush(stdout);

								for (key = 0; key < Key_found; key++)
								{
									ITK_CALL ( AOM_ask_value_strings(Keycntr_objects[key],"fnd0library",&PropNum,&CmpCode_List));
									printf("\n checkin_method_1--Total Comp Code :%d", PropNum);fflush(stdout);

									for (prop = 0; prop < PropNum; prop++)
									{
										printf("\n checkin_method_1--Comp Code %d is   %s  ",prop,CmpCode_List[prop]);fflush(stdout);

										 tc_strcat(CompCodeCatList,CmpCode_List[prop]);
										 tc_strcat(CompCodeCatList,", ");

										 printf("\n checkin_method_1--CompCodeCatList is   %s  ",CompCodeCatList);fflush(stdout);

										if(tc_strcmp(CmpCode,CmpCode_List[prop])==0)
										{
											Flag=1;
										}
									}
								}

								if(Flag==1)
								{
									printf("\n checkin_method_1--Comp Code found on keyword obj in classification.  ");fflush(stdout);
								}
								else
								{
									printf("\n checkin_method_1--Comp Code not found on keyword obj in classification. ");fflush(stdout);

									EMH_store_error_s2(EMH_severity_error,ITK_errStore,"Selected CompCode is not linked with Keyword Description, Kindly please select from further list",CompCodeCatList);
									return ITK_errStore;
								}
							}
						}
					}
					else
					{
						printf("\n checkin_method_1--[Inside Else Part ]***");fflush(stdout);
					}
				}
			}
		}
	}

	//CompCode Update Validation
	if (CntrlObjQry)
	{
		printf("\n checkin_method_1--inside Comp Code Update Validation *****  ");fflush(stdout);

		CmpCdUpd_val[0] = "CompCodUpd" ;
		if(QRY_execute(CntrlObjQry, CmpCdUpd, CmpCdUpd_entry, CmpCdUpd_val, &CmpCdUpdCnt, &CC_CtrlObjSet));
	}
	printf("\n\t checkin_method_1--Control Objects Count (CmpCdUpdCnt) = %d  type_name: [%s] ",CmpCdUpdCnt,type_name);fflush(stdout);

	if(CmpCdUpdCnt>0)
	{
		if (strcmp(type_name,"Design Revision")==0)
		{
			ITK_CALL(AOM_UIF_ask_value(objTag,"t5_ColourInd",&Clr_Ind));
			printf("\n\t checkin_method_1--Color Ind= [%s]  ",Clr_Ind);fflush(stdout);

			if (strcmp(Clr_Ind,"Y")==0)
			{
				if( AOM_ask_value_string(objTag,"item_revision_id",&RevisionString)!=ITK_ok);

				if (tc_strstr(RevisionString,"NR")!=0)
				{
				printf("\n\t checkin_method_1--Inside if, Part is NR  ");fflush(stdout);
				}
				else
				{
					printf("\n\t checkin_method_1--Inside else, Part is not NR  ");fflush(stdout);

					if( AOM_ask_value_string(objTag,"item_id",&item_IdStr)!=ITK_ok);

					ITK_CALL(ITEM_find_item( item_IdStr, &Item_tagT ));
					ITK_CALL(ITEM_list_all_revs(Item_tagT,&rev_cnt,&rev_list_set));
					printf("\n\t checkin_method_1--rev_cnt is %d  ",rev_cnt);fflush(stdout);
					if(rev_cnt != 0)
					{
						FlagKey=0;
						for(iji=(rev_cnt-1);iji>=0;iji--)
						{
							ITK_CALL(AOM_UIF_ask_value(rev_list_set[iji],"release_status_list",&Rlstatus));
							printf("\n\t checkin_method_1--Rlstatus %s  ",Rlstatus);fflush(stdout);
							if(Rlstatus)
							{
								if(strstr(Rlstatus,"ERC Released"))
								{
									LatestRev_tag= rev_list_set[iji];
									if( AOM_ask_value_string(LatestRev_tag,"item_revision_id",&NewRevisionString)!=ITK_ok);

									printf("\n\t checkin_method_1--NewRevisionString is %s \n",NewRevisionString);fflush(stdout);

									FlagKey=1;

									break;
								}
							}
						}
						printf("\n\t checkin_method_1--FlagKey = [%d] \n",FlagKey);fflush(stdout);

						if(FlagKey==1)
						{
							if( AOM_ask_value_string(objTag,"t5_PrtCatCode",&CompCoDeStr)!=ITK_ok);
							if( AOM_ask_value_string(LatestRev_tag,"t5_PrtCatCode",&PreCompCoDeStr)!=ITK_ok);

							printf("\n\t checkin_method_1--New Comp Code = [%s] previous comp code = [%s]  ",CompCoDeStr,PreCompCoDeStr);fflush(stdout);

							if(strcmp(CompCoDeStr,PreCompCoDeStr)==0)
							{
								printf("\n\t checkin_method_1--No change in Comp Code  ");fflush(stdout);
							}
							else
							{
								ITKCALL(GRM_find_relation_type("TC_Is_Represented_By", &Clr_Relation));
								ITKCALL(GRM_list_primary_objects_only(LatestRev_tag,Clr_Relation,&ClrPrtcnt,&ClrPrtSet));
								printf("\n\t checkin_method_1--Clr Part count is = [%d]  ",ClrPrtcnt);  fflush(stdout);

								if (ClrPrtcnt>0)
								{
									printf("\n\t checkin_method_1--Giving the error message for comp Code not matching  ");fflush(stdout);

									EMH_store_error_s2(EMH_severity_error,ITK_errStore,"Comp Code of current revision is not match with previous official revision."," Only changes allowed via comp code & colour indicator update DML.");
									return ITK_errStore;
								}
								else
								{
									printf("\n\t checkin_method_1--No clr part attach to previous revision so no need to validate  ");fflush(stdout);
								}
							}
						}
					}
				}
			}
		}
	}
	//CompCode Update Validation: End

	// Track and Trace Validation: Start
	if (strcmp(type_name,"Design Revision")==0)
	{
		int		TTCtrEtry1				= 1;
		int		TTQryC1					= 0;
		tag_t	TT_CtrObjQryTag1		= NULLTAG;
		tag_t	*TTCtrObjSet1			= NULLTAG;
		char    *TTQryEtry1[1]			= {"SYSCD"};
		char    **TTQryVal1				=  (char **) MEM_alloc(100 * sizeof(char *));
		char	*ErrorMsg			= NULL;
		ErrorMsg = (char	*)MEM_alloc(500);

		QRY_find("ControlObjQry", &TT_CtrObjQryTag1);
		if (TT_CtrObjQryTag1)
		{
			TTQryVal1[0] = "TTCTECTS";
			QRY_execute(TT_CtrObjQryTag1, TTCtrEtry1, TTQryEtry1, TTQryVal1, &TTQryC1, &TTCtrObjSet1);
		}
		printf("\n checkin_method_1--TTQryC1-Control object found = [%d] ",TTQryC1);fflush(stdout);

		if(TTQryC1>0)
		{
			int		n_found				= 0;
			int		n_entries			= 2;

			tag_t	*Keywordmodule		= NULLTAG;
			tag_t	query				= NULLTAG;

			char	*ItemId				= NULL;
			char	*KeyDes				= NULL;
			char	*DGroup				= NULL;
			char	*ModuleString		= NULL;
			char	*tok_value1			= NULL;
			char	*tok_value2			= NULL;
			char	*DTTattr			= NULL;
			char	*DCTECTS			= NULL;
			char	*PartType			= NULL;
			char	*Barcode			= NULL;

			char	*qry_entries[2]		= {"Name","ext_1"};
			char	**qry_values		= (char **) MEM_alloc(10 * sizeof(char *));

			if (AOM_ask_value_string(objTag,"item_id",&ItemId)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_CategoryName",&KeyDes)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_DesignGrp",&DGroup)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_TrackTrace",&DTTattr)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_CTECTS",&DCTECTS)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_PartType",&PartType)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_Barcode",&Barcode)!=ITK_ok);

			printf("\n checkin_method_1--Item = [%s] Keyword = [%s] Desig group = [%s] Track and Trace = [%s] CTE_CTS = [%s] ",ItemId,KeyDes,DGroup,DTTattr,DCTECTS);fflush(stdout);

			if ((tc_strcmp(KeyDes,"")!=0) && (tc_strcmp(KeyDes,NULL)!=0))
			{
				if ((tc_strcmp(PartType,"A")==0) || (tc_strcmp(PartType,"C")==0) || (tc_strcmp(PartType,"T")==0))
				{
					printf("\n\t checkin_method_1--Inside If of DR and part tye either of A,C or T ");fflush(stdout);

					qry_values[0] = KeyDes ;
					qry_values[1] = DGroup;

					QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query);
					if (query)
					{
						QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &Keywordmodule);
					}
					printf("\n\t checkin_method_1--Keyword n_found: [%d] ", n_found);fflush(stdout);

					if(n_found>0)
					{
						AOM_ask_value_string(Keywordmodule[0],"ext_2",&ModuleString);

						tok_value1 = tc_strtok(ModuleString,",");
						tok_value2 = tc_strtok(NULL,",");

						printf("\n\t checkin_method_1--tok_value1 = [%s] tok_value2 = [%s] ",tok_value1,tok_value2);fflush(stdout);

						if (tc_strcmp(tok_value1,"T&T")==0)
						{
							if (tc_strcmp(DTTattr,"Yes")!=0)
							{
								tc_strcpy(ErrorMsg,"");
								tc_strcat(ErrorMsg,"Update 'Track and Trace' as 'Yes' on Tc Part [");
								tc_strcat(ErrorMsg,ItemId);
								tc_strcat(ErrorMsg,"] as it is applicable for recall");
								printf("\n\t checkin_method_1--7.ErrorMsg= [%s]",ErrorMsg);fflush(stdout);

								EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
								return ITK_errStore;
							}
							else
							{
								printf("\n\t checkin_method_1--Track and Trace is OK ********** ");fflush(stdout);

							}
						}
						if ((tc_strcmp(tok_value2,"NA")!=0) && (tc_strcmp(tok_value2,"")!=0) && (tc_strcmp(tok_value2,NULL)!=0))
						{
							if (tc_strcmp(tok_value2,DCTECTS)!=0)
							{
								tc_strcpy(ErrorMsg,"");
								tc_strcat(ErrorMsg,"Update 'Critical to Emission_Critical to Safety_Critical to Quality' as '");
								tc_strcat(ErrorMsg,tok_value2);
								tc_strcat(ErrorMsg,"' on Tc Part [");
								tc_strcat(ErrorMsg,ItemId);
								tc_strcat(ErrorMsg,"] as it is applicable for recall");

								printf("\n\t checkin_method_1--6.ErrorMsg= [%s]",ErrorMsg);fflush(stdout);

								EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
								return ITK_errStore;
							}
							else
							{
								printf("\n\t checkin_method_1--Critical to emission and critical to saferty is OK ********** ");fflush(stdout);
							}
						}
					}
					else
					{
						tc_strcpy(ErrorMsg,"");
						tc_strcat(ErrorMsg,"Keyword Module [");
						tc_strcat(ErrorMsg,KeyDes);
						tc_strcat(ErrorMsg,"] is not available in system");

						printf("\n\t checkin_method_1--5.ErrorMsg==[%s]",ErrorMsg);fflush(stdout);
					}

					if (tc_strcmp(DTTattr,"Yes")==0)  // added by Gajanan CR_F22_0123
					{

						if(tc_strlen(Barcode) == 0)
						{
							tc_strcpy(ErrorMsg,"");
							tc_strcat(ErrorMsg,"For Parts with T &T Barcode is mandatory, Please Update Barcode, Go to Menu bar=>>Tools=>>Product Structure Classes =>> Update Barcode For T and T parts  and Check in again");
							tc_strcat(ErrorMsg,ItemId);
							tc_strcat(ErrorMsg,"] as it is applicable for recall");

							printf("\n\t checkin_method_1--4.ErrorMsg= [%s]",ErrorMsg);fflush(stdout);

							EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
							return ITK_errStore;
						}
						else
						{
							printf("\n\tcheckin_method_1--Barcode is ok********** ");fflush(stdout);
						}
					}
				}
			}
			else
			{
				printf("\n\t checkin_method_1--Keyword not availabe on TC Part no need to test.");fflush(stdout);
			}
		}

		// added by Gajanan CR_F22_0229 for Target Weight
		char	*ItemId						= NULL;
		char	*PartType					= NULL;
		char	*DRStatus					= NULL;
		char	*sRolledupWt				= NULL;
		char*	 sUsrInfo					= NULL;
		char*	 sUsrInfo1					= NULL;
		char*	 sTagretWt					= NULL;
		double	 dTagretWt					= 0.0;
		double	 dRolledupWt				= 0.0;
		double   RWtandTargWTDiffCnt		= 0.0;
		double   ctrlObjDiff				= 0.0;
		double   mCtrlObjDiff				= 0.0;
		double   pCtrlObjDiff				= 0.0;
		int		 n_entries					= 1;
		int		 n_entries1					= 1;
		int		 n_found					= 0;
		int		 n_found1					= 0;
		int		 i;
		int		 status						 = 0;
		tag_t	query						= NULLTAG;
		tag_t   *CntrlObjectTag1			= NULLTAG;
		tag_t	query1						= NULLTAG;
		tag_t   *CntrlObject_Tag1			= NULLTAG;

		if (AOM_ask_value_string(objTag,"item_id",&ItemId)!=ITK_ok);
		if (AOM_ask_value_string(objTag,"t5_PartType",&PartType)!=ITK_ok);
		if (AOM_ask_value_string(objTag,"t5_PartStatus",&DRStatus)!=ITK_ok);
		if (AOM_ask_value_string(objTag,"t5_TargetWt",&sTagretWt)!=ITK_ok);
		if (AOM_ask_value_string(objTag,"t5_RolledupWt",&sRolledupWt)!=ITK_ok);

		printf("\n\t checkin_method_1--Item Id= [%s] ",ItemId);fflush(stdout);
		printf("\n\t checkin_method_1--Part type= [%s] ",PartType);fflush(stdout);
		printf("\n\t checkin_method_1--DR/AR Status= [%s] ",DRStatus);fflush(stdout);
		printf("\n\t checkin_method_1--Target weight= [%.3f] ",dTagretWt);fflush(stdout);
		printf("\n\t checkin_method_1--Roll up weight= [%s] ",sRolledupWt);fflush(stdout);

		if(sTagretWt != NULL)
		{
			dTagretWt=atof(sTagretWt);
		}
		printf("\n\t checkin_method_1--Targetweight double value=[%f] ",dTagretWt);fflush(stdout);

		if(sRolledupWt != NULL)
		{
			dRolledupWt=atof(sRolledupWt);
		}
		printf("\n\t checkin_method_1--Roll up weight double value=[%f] ",dRolledupWt);fflush(stdout);

		char *qry_entries1[1]	=	{"SYSCD"};
		char **qry_values1    =  (char **) MEM_alloc(10 * sizeof(char *));

		QRY_find("Control Objects...",&query1);
		if (query1)
		{
			qry_values1[0] = "TARGETWTCHECK" ;
			QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &CntrlObject_Tag1);
		}
		printf("\n\t checkin_method_1--Control Object TARGETWTCHECK count found= [%d] ",n_found1);fflush(stdout);

		if(n_found1>0)
		{
			AOM_ask_value_string(CntrlObject_Tag1[0],"t5_Userinfo1",&sUsrInfo1);
			printf("\n\t checkin_method_1--Control Object value] [%s] ",sUsrInfo1);fflush(stdout);

			if (tc_strcmp(sUsrInfo1,"TargetCheckFlag")==0)
			{
				if (tc_strcmp(PartType,"M")==0)
				{
					printf("\n\t checkin_method_1--Inside module prt condition"); fflush(stdout);

					if (tc_strcmp(DRStatus,"DR2")==0 ||tc_strcmp(DRStatus,"DR3")==0 || tc_strcmp(DRStatus,"AR2")==0 ||tc_strcmp(DRStatus,"AR3")==0)
					{    printf("\n\t Inside DR2/DR3 status Condition");

						if(dTagretWt <= 0 ||dTagretWt <= 0.00 || dTagretWt <= 0.000 ||dTagretWt == 0.000000 ||sTagretWt == NULL)
						{
							printf("\n\t checkin_method_1--Fill the Target Weight attribute Is Mandatory and Check in again");fflush(stdout);

							tc_strcpy(ErrorMsg,"");
							tc_strcat(ErrorMsg,"Fill the Target Weight attribute Is Mandatory and Check in again");
							tc_strcat(ErrorMsg,ItemId);
							tc_strcat(ErrorMsg,"] as it is applicable for recall");

							printf("\n\t checkin_method_1--Error3= [%s]",ErrorMsg);fflush(stdout);

							EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
							return ITK_errStore;

							//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Fill the Target Weight attribute Is Mandatory and Check in again");
							// return ITK_errStore;
						}
						else
						{
							printf("\n\t checkin_method_1--Target Weight is ok********** ");fflush(stdout);
						}
					}
					else
					{
						printf("\n\t  checkin_method_1--DR/AR 2 and 3Status Not Getting..."); fflush(stdout);
					}

					if (tc_strcmp(DRStatus,"DR3")==0 || tc_strcmp(DRStatus,"AR3")==0 || tc_strcmp(DRStatus,"DR4")==0 || tc_strcmp(DRStatus,"AR4")==0)
					{
						if(sRolledupWt == NULL || tc_strlen(sRolledupWt)==0)
						{
							tc_strcpy(ErrorMsg,"");

							tc_strcat(ErrorMsg,"Generate weight rollup for this module using menu (Send Module to structure manager ), tools- weight roll up menu, check in Again");
							tc_strcat(ErrorMsg,ItemId);
							tc_strcat(ErrorMsg,"] as it is applicable for recall");

							printf("\n\t checkin_method_1--Error1== [%s]",ErrorMsg);fflush(stdout);

							EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
							return ITK_errStore;
							//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Generate weight rollup for this module using menu (Send Module to structure manager ), tools- weight roll up menu, check in Again");
							// return ITK_errStore;
						}
						else
						{
							printf("\n\t checkin_method_1--Inside DR3 status Condition");fflush(stdout);

							//RWtandTargWTDiffCnt = ( abs(dTagretWt-dRolledupWt) / ( (dTagretWt+dRolledupWt)/2.0 ) ) * 100;
							RWtandTargWTDiffCnt = (dTagretWt - dRolledupWt) * (1/dTagretWt) * 100;

							printf("\n\t checkin_method_1--Rollup weight and Target Wieght perc Difference = [%.3f] ",RWtandTargWTDiffCnt);fflush(stdout);

							char    *qry_entries[1]	=	{"SYSCD"};
							char    **qry_values    =  (char **) MEM_alloc(10 * sizeof(char *));

							QRY_find("Control Objects...",&query);
							if (query)
							{
								qry_values[0] = "TARGETWT" ;
								QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &CntrlObjectTag1);
							}
							printf("\n\t checkin_method_1--Control Object count found= [%d] ",n_found);fflush(stdout);

							for (i = 0; i < n_found; i++)
							{
								AOM_ask_value_string(CntrlObjectTag1[i],"t5_Userinfo1",&sUsrInfo);
								printf("\n\t checkin_method_1--Control Object value= [%s] ",sUsrInfo);fflush(stdout);
							}

							ctrlObjDiff=atof(sUsrInfo);

							printf("\n\t checkin_method_1--Double Control Object value= [%f] ",sUsrInfo);fflush(stdout);

							mCtrlObjDiff=ctrlObjDiff-5;
							pCtrlObjDiff=ctrlObjDiff+5;

							printf("\n\t checkin_method_1--Control Object value Minus= [%.3f] ",mCtrlObjDiff);fflush(stdout);
							printf("\n\t checkin_method_1--Control Object value Pluse= [%.3f] ",pCtrlObjDiff);fflush(stdout);

							if (( RWtandTargWTDiffCnt >= mCtrlObjDiff ) && (RWtandTargWTDiffCnt <= pCtrlObjDiff) )
							{
								  printf("\n\t checkin_method_1--user part checked in successfull "); fflush(stdout);
							}
							else
							{
								tc_strcpy(ErrorMsg,"");
								tc_strcat(ErrorMsg,"The differene of Target weight and rolled up weight is more than +-5%. Please ensure correctness of weight for every valid part in the structure");
								tc_strcat(ErrorMsg,ItemId);
								tc_strcat(ErrorMsg,"] as it is applicable for recall");

								printf("\n\t  checkin_method_1--Error2= [%s]",ErrorMsg);fflush(stdout);
								printf("\n\t checkin_method_1--The differene of Target weight and rolled up weight is more than +-5%. Please ensure correctness of weight for every valid part in the structure");fflush(stdout);

								EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg);
								return ITK_errStore;

								//EMH_store_error_s1(EMH_severity_error,ITK_errStore,"The differene of Target weight and rolled up weight is more than +-5%. Please ensure correctness of weight for every valid part in the structure");
								//return ITK_errStore;
							}
						}
					}
					else
					{
					  printf("\n\t checkin_method_1--DR/AR 3 and above 3Status Not Getting...  ");fflush(stdout);
					}
				}
			}
		}
	}

	// Track and Trace Validation: End

	// START Design Rule check
	if (strcmp(type_name,"Design Revision")==0)
	{
		int		CtrEtry2				= 1;
		int		QryC2					= 0;
		tag_t	CtrObjQryTag2		= NULLTAG;
		tag_t	*CtrObjSet2			= NULLTAG;
		char    *QryEtry2[1]			= {"SYSCD"};
		char    **QryVal2				=  (char **) MEM_alloc(100 * sizeof(char *));
		char	*ErrorMsg2			= NULL;
		ErrorMsg2 = (char	*)MEM_alloc(500);

		QRY_find("ControlObjQry", &CtrObjQryTag2);
		if (CtrObjQryTag2 != NULLTAG)
		{
			QryVal2[0] = "DRValCkn";
			QRY_execute(CtrObjQryTag2, CtrEtry2, QryEtry2, QryVal2, &QryC2, &CtrObjSet2);
		}
		printf("\n checkin_method_1--DR Control object found = [%d]  ",QryC2);fflush(stdout);

		if(QryC2>0)
		{
			int Rel_Count = 0;

			tag_t DRRelationType = NULLTAG;
			tag_t *DesignRuleSet = NULLTAG;

			char	*ItemId				= NULL;
			char	*DesignRuleA		= NULL;
			char	*DesignRuleAR		= NULL;
			char	*ObjectType			= NULL;
			char	*ObjPartType		= NULL;


			char	*qry_entries[2]		= {"Name","ext_1"};
			char	**qry_values		= (char **) MEM_alloc(10 * sizeof(char *));

			if (AOM_ask_value_string(objTag,"item_id",&ItemId)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_DesignRuleA",&DesignRuleA)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_DesignRuleAR",&DesignRuleAR)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"object_type",&ObjectType)!=ITK_ok);
			if (AOM_ask_value_string(objTag,"t5_PartType",&ObjPartType)!=ITK_ok);

			printf("\n\t checkin_method_1--Item = [%s] Design Rule Applicability [%s] DRA Remark [%s] Object type [%s]  ObjPartType: [%s]  ",ItemId,DesignRuleA,DesignRuleAR,ObjectType,ObjPartType);fflush(stdout);

			if ((tc_strcmp(ObjectType,"Design Revision")==0) && ((tc_strcmp(ObjPartType,"M")==0)||(tc_strcmp(ObjPartType,"T")==0)))
			{
				if (tc_strcmp(DesignRuleA,"N")==0)
				{
					printf("\n\t checkin_method_1--Inside If DesignRuleA is found as N  ");fflush(stdout);

					if ((tc_strcmp(DesignRuleAR,"")==0) || (tc_strcmp(DesignRuleA,NULL)==0))
					{
						tc_strcpy(ErrorMsg2,"");
						tc_strcat(ErrorMsg2,"For 'Design Rule Applicability' with 'N', 'Design Rule Applicability Remarks' is mandatory.");
						printf("\n\t checkin_method_1--Error1:-  [%s]",ErrorMsg2);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg2);
						return ITK_errStore;
					}
					else if (tc_strlen(DesignRuleAR) < 50)
					{
						tc_strcpy(ErrorMsg2,"");
						tc_strcat(ErrorMsg2,"'Design Rule Applicability Remarks' should have at least 50 letters.");

						printf("\n\t checkin_method_1--Error2:-  [%s]",ErrorMsg2);fflush(stdout);

						EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg2);
						return ITK_errStore;
					}
				}
				else if (tc_strcmp(DesignRuleA,"Y")==0)
				{
					printf("\n\t checkin_method_1--Inside Else If DesignRuleA is found as Y  ");fflush(stdout);

					if (GRM_find_relation_type("T5_HasDesignRule", &DRRelationType)!=ITK_ok);
					if (GRM_list_secondary_objects_only(objTag,DRRelationType,&Rel_Count,&DesignRuleSet)!=ITK_ok);

					printf("\n\t  checkin_method_1--Design Rule relation Count:-  [%d]",Rel_Count);fflush(stdout);

					if (Rel_Count == 0)
					{
						printf("\n\t  checkin_method_1--No Design rule relation found   ");fflush(stdout);

						tc_strcpy(ErrorMsg2,"");
						tc_strcat(ErrorMsg2,"For 'Design Rule Applicability' with 'Y', Design revision should have Design rule attached to it. Kindly use 'Tools -> Product Structure Classes -> Update Design Rules' to create 'Part Has Design Rules' Relation");
						printf("\n\t  checkin_method_1--Error2:-  [%s]",ErrorMsg2);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,ErrorMsg2);
						return ITK_errStore;
					}
				}
			}
		}
	}
	// END Design Rule check

	//E-Certificae Validation
	if (strcmp(type_name,"Design Revision")==0)
	{
		printf("\nInside E-Certificae Validation Check ");fflush(stdout);

		ITK_CALL(AOM_ask_value_string(objTag,"item_id",&PartNum));
		tc_strdup(PartNum,&PartNumDup);

		ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&PartRev));
		tc_strdup(PartRev,&PartRevDup);

		ITK_CALL(AOM_ask_value_string(objTag,"t5_PartType",&partType));
		tc_strdup(partType,&partTypeDup);

		ITK_CALL(AOM_ask_value_string(objTag,"object_type",&pObjType));
		tc_strdup(pObjType,&pObjTypeDup);

		ITK_CALL(AOM_ask_value_string(objTag,"t5_ColourInd",&pcolInd));
		tc_strdup(pcolInd,&pcolIndDup);

		//KeyWordQryforDR - query to get Module details CLC/ALC etc.

		printf("\n checkin_method_1--Part: [%s/%s] pObjTypeDup= %s PartType= %s ",PartNumDup,PartRevDup,pObjTypeDup,partTypeDup);
		if (
			tc_strcmp(partTypeDup,"VC")==0 ||
			tc_strcmp(partTypeDup,"CCVC")==0 ||
			tc_strcmp(partTypeDup,"V")==0 ||
			tc_strcmp(partTypeDup,"T")==0 ||
			tc_strcmp(partTypeDup,"D")==0 ||
			tc_strcmp(partTypeDup,"DC")==0 ||
			tc_strcmp(partTypeDup,"DA")==0 ||
			tc_strcmp(partTypeDup,"M")==0 ||
			tc_strcmp(partTypeDup,"IM")==0 ||
			tc_strcmp(partTypeDup,"IFD")==0 ||
			tc_strcmp(partTypeDup,"G")==0 ||
			tc_strcmp(pcolIndDup,"C")==0
		)
		{
			printf("\n checkin_method_1--Part: [%s/%s] E-Certificate not required for Part Type: %s",PartNumDup,PartRevDup,partTypeDup);
		}
		else
		{
			ITK_CALL(AOM_UIF_ask_value(objTag,"t5_CMVRCertificationReqd",&cmvrInd));
			tc_strdup(cmvrInd,&cmvrIndDup);

			ITK_CALL(AOM_ask_value_string(objTag,"t5_HomologationReqd",&HlgInd));
			tc_strdup(HlgInd,&HlgIndDup);

			printf("\n checkin_method_1--Part: [%s/%s] CMVR Cert Req : %s Homologation Ind : [%s] ",PartNumDup,PartRevDup,cmvrIndDup,HlgIndDup); fflush(stdout);

			if (tc_strcmp(cmvrIndDup,"True")==0 || tc_strcmp(HlgIndDup,"Y")==0)
			{
				tc_strcpy(eCertNumStr,"");
				tc_strcpy(eCertNumStr,PartNumDup);
				tc_strcat(eCertNumStr,"/");
				tc_strcat(eCertNumStr,PartRevDup);
				printf("\n checkin_method_1--eCertNumStr : %s",eCertNumStr);

				STRNG_replace_str(eCertNumStr,";","*",&eCertNumInp);

				printf("\n checkin_method_1--eCertNumInp : %s",eCertNumInp);

				ecert_values[0] = eCertNumInp;

				if(QRY_find("tm_ECertificateQuery", &ECertQry));
				if (ECertQry)
				{
					printf("\n checkin_method_1--tm_ECertificateQuery Query Found ");fflush(stdout);
					ITK_CALL(QRY_execute_with_sort(ECertQry, one_entries, ecert_entries, ecert_values,num_to_sort,keysAttr,sort_order, &certCount, &opCertTags));
				}

				printf("\n checkin_method_1--EcertCount: [%d]",certCount);

				if (certCount<=0)
				{
					//Error Hard Check.
					printf("\n checkin_method_1--Error Hard Check : E-Certificate Not found for part : [%s] ",eCertNumStr);
					EMH_store_error_s3(EMH_severity_error,ITK_errStore,eCertNumStr," : Homologation Ind is Y or CMVR Certification Req is True hence E-Certificate is mandetory."," Create E-Certificate for this revision and then check-in");
					return ITK_errStore;
				}
			}
			else if (tc_strcmp(cmvrIndDup,"False")==0 && tc_strcmp(HlgIndDup,"N")==0)
			{
				ITK_CALL(AOM_UIF_ask_value(objTag,"t5_CategoryName",&keywDesc));
				tc_strdup(keywDesc,&keywDescDup);

				ITK_CALL(AOM_UIF_ask_value(objTag,"t5_DesignGrp",&pDesginGrp));
				tc_strdup(pDesginGrp,&pDesginGrpDup);

				printf("\n checkin_method_1--Part : %s/%s CMVR Cert Req : %s Homologation Ind : %s Keyword Desc : %s ",PartNumDup,PartRevDup,cmvrIndDup,HlgIndDup,keywDescDup); fflush(stdout);

				two_values[0] = keywDescDup;
				two_values[1] = pDesginGrpDup;

				QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &KWDescQry);
				if (KWDescQry)
				{
					QRY_execute(KWDescQry, nTwo, two_attr, two_values, &modCount, &moduleTags);
				}
				printf("\n checkin_method_1--Module Object Found : %d", modCount);fflush(stdout);

				if(modCount>0)
				{
					AOM_ask_value_string(moduleTags[0],"ext_2",&sModuleInfo);

					printf("\n checkin_method_1--Part : %s/%s sModuleInfo : %s  ",PartNumDup,PartRevDup,sModuleInfo);

					tok_value1 = tc_strtok(sModuleInfo,",");
					tok_value2 = tc_strtok(NULL,",");
					tok_value3 = tc_strtok(NULL,",");

					if (tc_strcmp(tok_value3,"CLC")==0) //Component Level Certification
					{
						//Error Hard Check.
						printf("\n checkin_method_1--Error Hard Check: Either update Homologation Reqd as Y or CMVR certification Reqd as True as this part comes under regulatory required items: [%s/%s] ",PartNumDup,PartRevDup);
						EMH_store_error_s1(EMH_severity_error,ITK_errStore,"Either update Homologation Reqd as Y or CMVR certification Reqd as True as this part comes under regulatory required items");
						return ITK_errStore;
					}
				}
			}
			else
			{
				printf("\n  checkin_method_1--[%s/%s]: E-Certification Check failed as valuse blank ",PartNumDup,PartRevDup);
			}
		}
	}
	if (strcmp(type_name,"T5_Std_WcqRevision")==0 || strcmp(type_name,"T5_VODRevision")==0)
	{
		printf("\n checkin_method_1--Std Doc Format Revision Check-IN");fflush(stdout);
		tag_t status_rel = NULLTAG;
		logical retain = 0;
		ITK_CALL(CR_create_release_status("T5_LcsReview",&status_rel));
		ITK_CALL(EPM_add_release_status(status_rel,1,&objTag,retain));
	}

	printf("\n checkin_method_1 process is completed..\n "); fflush(stdout);

	BYPASSLOADER:
	return ITK_ok;

	BYPASSTRILIXSITE:
	return ITK_ok;

	BYPASSDesGrpAMFD:
	return ITK_ok;
}

//int checkin_register_method(int *decision, va_list args)
//{
//    METHOD_id_t  method;
//
//	  *decision = ALL_CUSTOMIZATIONS;
//
//   if ( METHOD_find_method(RES_Type, RES_checkin_msg, &method) !=ITK_ok)
//   PrintErrorStack();
//
//    if (method.id != NULLTAG)
//    {
//        if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) checkin_method_1, NULL)!=ITK_ok)
//        PrintErrorStack();
//		printf("Registered as Pre-Action for check-in ");
//    }
//    else
//        printf("Method not found! ");
//
//    return ITK_ok;
//}

//DLLAPI int check_register_callbacks ()
//{
//    printf("\nTCDC\ncheckin_register_callbackssssssssss changed\n ");
//
// /*   exit(EXIT_SUCCESS);*/
//    if(CUSTOM_register_exit ( "check", "USER_init_module", (CUSTOM_EXIT_ftn_t)  checkin_register_method) !=ITK_ok);
//     PrintErrorStack();
//
//  return ( ITK_ok );
//
//
//}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void get_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Env, char *EnvOrg)
{
	int    status;
	int    k, n,int_ent_sequence;
	int    Item_ID,Item_Revision,Item_Description,xform_matrix,parent_item_seq=0,occ_xform_matrix=0,User=0;
	int    n_attchs,i,referencenumberfound,j;
	int    numBoundingBoxes,ctr;
	int    Parentsequence_id=0;
	int    dum=0;
	int sequence_id_c = 0;

	double *  boundingBoxes;

	char   *name, *Item_ID_str,*Item_Revision_str,*Item_Description_str,*xform_matrix_str,*occ_xform_matrix_str,*User_str=NULL;
	char   *dumy_Item_ID_str=NULL;
	char   *catiafileName=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	char   *ret_id,*ret_rev;
	char   type_name[TCTYPE_name_size_c+1];
	char   refname[AE_reference_size_c + 1];
	char   orig_name[IMF_filename_size_c + 1];
	char   *enterprise_sequence;
	char   pathname[SS_MAXPATHLEN + 1];
	char   path_name1[SS_MAXPATHLEN];
	char   path_name2[SS_MAXPATHLEN];
	char   *ent_seq_str;
	char   *parentrev=NULL;
	char   *parent=NULL;
	char   *parentseq=NULL;
	char   *parentdesc=NULL;
	char   *PatSeq= NULL;
	char   *ITemRevSeq,*Desc_obj,*EnvTemp= NULL;
	char command[100];
	//char *6;char *7;char *8;char *9;char *10;
	 char *username = NULL;
	 char *userid = NULL;
	 char *homeSite = NULL;
	 char *siteName = NULL;
	 char *hostName = NULL;
	 char *sUsrInfo = NULL;
	 char *sUsrInfo2 = NULL;
	 char *sUsrInfo3 = NULL;
	tag_t user_tag=NULLTAG;

	tag_t  ParentItemRevTag = NULLTAG;
	tag_t  reln_type =NULLTAG;

	tag_t  *children,itemrev;
	tag_t	*secondary_objects = NULLTAG,
			primary = NULLTAG,
			objTypeTag = NULLTAG,
			refobject = NULLTAG;

	AE_reference_type_t reftype;


	printf("\n get_bom--TCDCEnv is:%s and EnvOrg :%s\n",Env,EnvOrg);fflush(stdout);
	EnvTemp=malloc(1500);
	strcpy(EnvTemp,EnvOrg);
	printf("\n get_bom--TCDCEnvTemp  is:%s\n",EnvTemp);fflush(stdout);

	depth ++;

	if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	Item_ID_str =malloc(100);

	if(BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str));

	if( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix));
	if(BOM_line_ask_attribute_string(line, xform_matrix, &xform_matrix_str));

	printf("\n get_bom--TCDC1] Item_ID_str =%s\n",Item_ID_str);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(BOM_line_ask_attribute_string(line, Item_Revision, &Item_Revision_str));

	//printf("\nTCDC2] Item_Revision_str =%s\n",Item_Revision_str);

	if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(BOM_line_ask_attribute_tag(line, parent_item_seq, &itemrev));

	if(AOM_ask_value_int(itemrev,"sequence_id",&sequence_id_c));
	printf("\n get_bom--TCDC3] Sequence = [%d] ",sequence_id_c);

	ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(ITemRevSeq,"%d",sequence_id_c);

	if( BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
	if(BOM_line_ask_attribute_string(line, Item_Description, &Item_Description_str));
	//	printf("\nTCDC4] Item_Description_str =%s\n",Item_Description_str);

	if( BOM_line_look_up_attribute ("bl_rev_owning_user",&User));
	if(BOM_line_ask_attribute_string(line, User, &User_str));
	//printf("\nTCDCUser_str =%s\n",User_str);

	occ_xform_matrix=0;
	if( BOM_line_look_up_attribute ("bl_plmxml_def_occ_xform",&occ_xform_matrix));
	if(occ_xform_matrix_str) occ_xform_matrix_str=NULL;occ_xform_matrix_str=malloc(500);
	if(BOM_line_ask_attribute_string(line, occ_xform_matrix, &occ_xform_matrix_str));
	//	printf("\nTCDC5]  bl_plmxml_def_occ_xform =%s\n",occ_xform_matrix_str);

	if(AOM_ask_value_string(itemrev,"gov_classification",&enterprise_sequence));
	//printf("\nTCDC-----------------------enterprise_sequence -->%s\n",enterprise_sequence);

	if (AOM_ask_value_string(itemrev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
	// printf("\nTCDCDesc_obj is :%s\n",Desc_obj);

	int_ent_sequence=atoi(enterprise_sequence);

	dumy_Item_ID_str=MEM_string_copy(Item_ID_str) ;
	projectcode=subString(dumy_Item_ID_str,0,4);
	desgngrp=subString(dumy_Item_ID_str,4,2);
	//
	//	printf("\nTCDCprojectcode------->%s\n",projectcode);
	//	printf("\nTCDCdesgngrp------->%s\n",desgngrp);
	//    if (Parent)
	//	{
	//			   printf("\nTCDCThis is first line\n");
	//	}
	//	else
	//	{
	if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	if(  BOM_line_ask_attribute_string(Parent, Item_Revision, &parentrev));
	if(  BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(  BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));

	if(parent) parent=NULL;
	parent =malloc(100);
	if(BOM_line_ask_attribute_string(Parent, Item_ID, &parent));
	if(BOM_line_ask_attribute_tag(Parent, parent_item_seq, &ParentItemRevTag));
	if(AOM_ask_value_int(ParentItemRevTag,"sequence_id",&Parentsequence_id));
	PatSeq=malloc(3);
	sprintf(PatSeq,"%d",Parentsequence_id);
	if(BOM_line_ask_attribute_string(Parent, Item_Description, &parentdesc));

	//printf("\nTCDCparent---->%s\n", parent);
	//printf("\nTCDCparentrev---->%s\n",parentrev );
	//printf("\nTCDCPatSeq---->%s\n",PatSeq );
	//printf("\nTCDCparentdesc---->%s\n",parentdesc );
	//printf("\nTCDCItem_Description_str---->%s\n",Item_Description_str );
	//if(strlen(parent)>0 )

	printf("\n get_bom--TCDCItem_ID_str =%s and  parent :%s\n",Item_ID_str,parent);fflush(stdout);
	if(GRM_list_secondary_objects_only(itemrev,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
	printf("\n get_bom--TCDCn_attchs:%d",n_attchs);fflush(stdout);
	if(n_attchs>0)
	{
		for (i= 0; i < n_attchs; i++)
		{
			printf("\n get_bom--TCDCItem_ID_str:%s",Item_ID_str);fflush(stdout);
			printf("\n get_bom--TCDCItem_idP:%s",Item_idP);fflush(stdout);

			if(strcmp(Item_ID_str,Item_idP)==0 || strstr(Item_ID_str,"Spec")!=NULL )
			{
				printf("\n get_bom--TCDCEnv:%s",Env);fflush(stdout);
				if(Env)
				{
					printf("\n get_bom--TCDCAEnvTemp in getbom is:%s for\n",EnvTemp);fflush(stdout);
					Env = NULL;
					Env = malloc(1500);
					tc_strcpy(Env,EnvTemp);
					printf("\n get_bom--TCDCAEnv got orignal in getbom is:%s for i :%d\n",Env,i);fflush(stdout);
				}
				else
				{
					printf("\n get_bom--TCDCBEnvTemp in getbom is:%s for\n",EnvTemp);fflush(stdout);
					Env = NULL;
					Env = malloc(1500);
					tc_strcpy(Env,EnvTemp);
					printf("\n get_bom--TCDCBEnv got orignal in getbom is:%s for i :%d\n",Env,i);fflush(stdout);
				}
				primary=secondary_objects[i];
				if(TCTYPE_ask_object_type(primary,&objTypeTag));
				if(TCTYPE_ask_name(objTypeTag,type_name));
				//   if (AOM_ask_value_string(type_name,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
				printf("\n get_bom--TCDCtype_name in getbom is :%s\n",type_name);fflush(stdout);
				printf("\n get_bom--TCDCInside Spec :%s\n",Item_ID_str);fflush(stdout);
				//
				//  if(strcmp(type_name,"CATProduct")==0 || strcmp(type_name,"catproduct")==0 ||strcmp(type_name,"catpart")==0 ||strcmp(type_name,"t5Alias")==0 || strcmp(type_name,"CATPart")==0 ||strcmp(refname,"catdrawing")==0|| strcmp(type_name,"CATDrawing")==0 || strcmp(type_name,"DirectModel")==0)
				if(strcmp(type_name,"CMI2Product")==0 || strcmp(type_name,"CMI2Product")==0 ||strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Drawing")==0 || strcmp(type_name,"DirectModel")==0)
				{
					if(AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev));
					if(AE_ask_dataset_ref_count(primary,&referencenumberfound));
					for(j=0;j<referencenumberfound;j++)
					{
						if(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));
						printf("\n get_bom--TCDCrefname in getbom is:%s\n",refname);fflush(stdout);
						if(strcmp(refname,"CATProduct")==0 ||strcmp(refname,"catpart")==0 ||strcmp(refname,"CATDrawing")==0 || strcmp(refname,"catproduct")==0 ||strcmp(refname,"CATPart")==0||strcmp(refname,"catdrawing")==0 )
						{
							if(strcmp(refname,"catpart")==0)
							{
								if( AE_get_bounding_boxes(primary, &numBoundingBoxes, &boundingBoxes));
							}
							if( IMF_ask_original_file_name(refobject,orig_name));
							if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name1)!=ITK_ok)PrintErrorStack();

							if(strlen(path_name1) >0)
							{
								if(strstr(path_name1,"bmp")==0&&strstr(path_name1,"BMP")==0)
								{
									printf("\n get_bom--TCDCpath_name1 in getbom  is :%s\n",path_name1);fflush(stdout);
									printf("\n get_bom--TCDCorig_namein getbom  is is :%s\n",orig_name);fflush(stdout);
									printf("\n get_bom--TCDCItem_Description- beforegetbom :%s and Item_idP :%s Env before cp is :%s\n",Item_Description_str,Item_idP,Env );fflush(stdout);

									//if(strstr(path_name1,"CATProduct") || strstr(path_name1,"catproduct"))
									//{
									//strcat(Env,"/");
									//strcat(Env,Item_idP);
									//strcat(Env,".CATProduct");
									//}
									//if(strstr(path_name1,"catpart") || strstr(path_name1,"CATPart"))
									//{
									//strcat(Env,"/");
									//strcat(Env,Item_idP);
									//strcat(Env,".CATPart");
									//}

									tc_strcat(Env,"/");
									tc_strcat(Env,orig_name);
									printf("\n get_bom--TCDCEnv after all stract in getbom :%s\n",Env);fflush(stdout);

									//Added by Gajanan Rathod Date 14-11-2022

									char *ctrlQryEntriesSite[2] = {"SYSCD", "SUBSYSCD"};
									char *ctrlQryValuesSite[2] = {"HOMESITES", "HOMESITES"};
									int nEntriesSite = 2;
									int nFoundSite = 0;
									tag_t  TagCtrlQryContObjSite = NULLTAG,
										   *ctrlCntrObjectsSite = NULLTAG;

									if(QRY_find2("ControlObjQry", &TagCtrlQryContObjSite));
									if (TagCtrlQryContObjSite)
									{
										if(QRY_execute(TagCtrlQryContObjSite, nEntriesSite, ctrlQryEntriesSite, ctrlQryValuesSite, &nFoundSite, &ctrlCntrObjectsSite));
									}
									printf("\n get_bom--Objects for Query ControlObjQry from checkin validationnnn : %d", nFoundSite);fflush(stdout);

									if (nFoundSite>0)
									{

										POM_get_user(&username,&user_tag);
										SA_ask_user_identifier2	(user_tag,&userid);
										printf ("\n get_bom--Logged in user:%s %s ",userid,username);fflush(stdout);
										AOM_UIF_ask_value(user_tag,"fnd0home_site",&homeSite);
										printf("\n get_bom--Logged in fnd0home_site: %s",homeSite);fflush(stdout);

										if (strcmp(homeSite,"Trilix-Production")==0)
										{
											if( AOM_ask_value_string(ctrlCntrObjectsSite[0],"t5_Userinfo3",&sUsrInfo3)!=ITK_ok);PrintErrorStack();
											char *siteName=tc_strtok(sUsrInfo3,",");
											char *hostName=tc_strtok(NULL,",");
											printf("\n get_bom--1.TCDCsiteName and  hostName in controlobject sUsrInfo3   is :%s , %s\n",siteName,hostName);fflush(stdout);
											tc_strcpy(path_name2,"");
											//strcat(path_name2,"trlcmifms@172.26.2.61:");
											strcat(path_name2,hostName);
											strcat(path_name2,path_name1);
											printf("\n get_bom--1.TCDCpath_name2 in getbom  is :%s\n",path_name2);fflush(stdout);
											sprintf(command,"scp %s '%s'",path_name2,Env);
											system(command);
											printf("\n get_bom--1.TCDCDONE :%s\n",Env);fflush(stdout);
											printf("\n get_bom--1.TCDCEnv after  copy in getbom  is :%s\n", Env);fflush(stdout);
										}
										else if (strcmp(homeSite,"TMETC-Production")==0)
										{
											if( AOM_ask_value_string(ctrlCntrObjectsSite[0],"t5_Userinfo2",&sUsrInfo2)!=ITK_ok);PrintErrorStack();
											tc_strcpy(path_name2,"");
											//strcat(path_name2,"trlcmifms@172.26.2.61:");
											strcat(path_name2,hostName);
											strcat(path_name2,path_name1);
											printf("\n get_bom--2.TCDCpath_name2 in getbom  is :%s\n",path_name2);fflush(stdout);
											sprintf(command,"scp %s '%s'",path_name2,Env);
											system(command);
											printf("\n get_bom--2.TCDCDONE :%s\n",Env);fflush(stdout);
											printf("\n get_bom--2.TCDCEnv after  copy in getbom  is :%s\n", Env);fflush(stdout);
										}
										else
										{
											sprintf(command,"cp %s '%s'",path_name1,Env);
											system(command);
											printf("\n get_bom--3.TCDCDONE :%s\n",Env);fflush(stdout);
											printf("\n get_bom--3.TCDCEnv after  copy in getbom  is :%s\n", Env);fflush(stdout);
										}
									}
									else
									{
									  sprintf(command,"cp %s '%s'",path_name1,Env);
									  system(command);
									  printf("\n get_bom--4.TCDCDONE :%s\n",Env);fflush(stdout);
									  printf("\n get_bom--4.TCDCEnv after  copy in getbom  is :%s\n", Env);fflush(stdout);
									}
								}
							}
						}
					}
				}
			}
		   //}
		}
	}
	else
		printf("\n get_bom--TCDCThere are no data item attached to it\n");fflush(stdout);

	if(BOM_line_ask_child_lines (line, &n, &children));
	printf("\n get_bom--TCDCtotal children are :[%d] ",n);fflush(stdout);

	for (k = 0; k < n; k++)
		get_bom (children[k],line,depth,Item_idP,Env,EnvOrg);
}
static void print_bom (tag_t line,tag_t Parent, int depth,char *Item_idP,char *Item_idC,int qty,int TmpQty,FILE *fdf,FILE *fus)
{
	int status = 0;
	int k=0, n=0, int_ent_sequence=0, q=0;
	int Item_ID,Item_Revision,Item_Description,xform_matrix,parent_item_seq=0,occ_xform_matrix=0,User=0,bl_Qty=0;
	int n_attchs,i,referencenumberfound,j;
	int numBoundingBoxes,ctr;
	int Parentsequence_id=0,CatiaOccName=0;
	int Item_Type1,Item_Type2=0;
	int dum=0;
	int n_occs,io=0,Flag=0,qtyCnt1,k1=0,mulQtyIndex,cLen=0,p=0;
	int sequence_id_c = 0;

	double *  boundingBoxes;

	char *Item_ID_strW2,*Item_ID_strW3=NULL;
	char *name, *Item_ID_str,*Item_Revision_str,*Item_Description_str,*xform_matrix_str,*occ_xform_matrix_str,*User_str=NULL,*bl_Qty_str=NULL;
	char *dumy_Item_ID_str=NULL;
	char *catiafileName=NULL;
	char *CatiaOccName_str=NULL;
	char *projectcode=NULL;
	char *desgngrp=NULL;
	char *ret_id,*ret_rev;
	char *enterprise_sequence;
	char *ent_seq_str;
	char *parentrev=NULL;
	char *parent=NULL;
	char *parentseq=NULL;
	char *parentdesc=NULL;
	char *PatSeq= NULL;
	char *ITemRevSeq,*Desc_obj,*PartType,*PartType1= NULL;

	char type_name[TCTYPE_name_size_c+1];
	char refname[AE_reference_size_c + 1];
	char orig_name[IMF_filename_size_c + 1];
	char pathname[SS_MAXPATHLEN + 1];
	char path_name1[SS_MAXPATHLEN];
	char tmpchar[10];
	char tmpchar1[10];
	//char *6;char *7;char *8;char *9;char *10;

	tag_t *occs = NULLTAG;
	tag_t *secondary_objects=NULLTAG, primary=NULLTAG, objTypeTag=NULLTAG, refobject=NULLTAG;
	tag_t *children=NULLTAG, itemrev=NULLTAG;

	tag_t ParentItemRevTag,Childobject1,Childobject2 =NULLTAG;
	tag_t reln_type = NULLTAG;

	AE_reference_type_t     reftype;

	depth ++;

		if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	if(BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str));

	   if( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix));
	if(BOM_line_ask_attribute_string(line, xform_matrix, &xform_matrix_str));

	printf("\n print_bom--TCDC1] Item_ID_str =%s and xform_matrix_str :%s and Item_idC(child taken for qty ) :%s\n",Item_ID_str,xform_matrix_str,Item_idC);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(BOM_line_ask_attribute_string(line, Item_Revision, &Item_Revision_str));

	printf("\n print_bom--TCDC2] Item_Revision_str =%s ",Item_Revision_str);fflush(stdout);

	if(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	if(BOM_line_ask_attribute_tag(line, parent_item_seq, &itemrev));

	if(AOM_ask_value_int(itemrev,"sequence_id",&sequence_id_c));
	printf("\n print_bom--TCDC3] Sequence =%d ",sequence_id_c);fflush(stdout);

	ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(ITemRevSeq,"%d",sequence_id_c);

	if( BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
	if(BOM_line_ask_attribute_string(line, Item_Description, &Item_Description_str));
	printf("\n print_bom--TCDC4] Item_Description_str =%s ",Item_Description_str);fflush(stdout);

	if( BOM_line_look_up_attribute ("bl_rev_owning_user",&User));
	if(BOM_line_ask_attribute_string(line, User, &User_str));
	printf("\nTCDCUser_str =%s ",User_str);fflush(stdout);

	occ_xform_matrix=0;
	 if( BOM_line_look_up_attribute ("bl_plmxml_def_occ_xform",&occ_xform_matrix));
	if(occ_xform_matrix_str) occ_xform_matrix_str=NULL;occ_xform_matrix_str=malloc(500);
	if(BOM_line_ask_attribute_string(line, occ_xform_matrix, &occ_xform_matrix_str));
	printf("\n print_bom--TCDC5]  bl_plmxml_def_occ_xform =%s ",occ_xform_matrix_str);fflush(stdout);

	 CatiaOccName=0;
	//if( BOM_line_look_up_attribute ("catiaOccurrenceName",&CatiaOccName));
	if( BOM_line_look_up_attribute ("bl_occurrence_name",&CatiaOccName));
	if(CatiaOccName_str) CatiaOccName_str=NULL;CatiaOccName_str=malloc(200);
	if(BOM_line_ask_attribute_string(line, CatiaOccName, &CatiaOccName_str));
	printf("\n print_bom--TCDC7]  catiaOccuranceName =%s ",CatiaOccName_str);fflush(stdout);

	bl_Qty=0;
	 if( BOM_line_look_up_attribute ("bl_quantity",&bl_Qty));
	if(bl_Qty_str) bl_Qty_str=NULL;bl_Qty_str=malloc(20);
	if(BOM_line_ask_attribute_string(line, bl_Qty, &bl_Qty_str));
	printf("\n print_bom--TCDC6]  bl_Qty =%s ",bl_Qty_str);fflush(stdout);

	if(AOM_ask_value_string(itemrev,"gov_classification",&enterprise_sequence));
	printf("\n print_bom--TCDC-----------------------enterprise_sequence -->%s ",enterprise_sequence);fflush(stdout);

	if (AOM_ask_value_string(itemrev,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
	printf("\n print_bom--TCDCDesc_obj is :%s ",Desc_obj);fflush(stdout);

	 PartType=NULL;PartType=malloc(50);
	 PartType1=NULL;PartType1=malloc(50);
	//if (AOM_ask_value_string(itemrev,"t5_PartType",&PartType)!=ITK_ok)   PrintErrorStack();
	if (AOM_UIF_ask_value(itemrev,"t5_PartType",&PartType)!=ITK_ok)   PrintErrorStack();
	printf("\n print_bom--TCDCPartType is :%s ",PartType);fflush(stdout);

	if (strcmp(PartType,"C")==0)
	{
		strcpy(PartType1,"Cmponent");
	}
	if (strcmp(PartType,"A")==0)
	{
		strcpy(PartType1,"Assembly");
	}
	if (strcmp(PartType,"G")==0)
	{
		strcpy(PartType1,"Group Id");
	}
	if (strcmp(PartType,"T")==0)
	{
		strcpy(PartType1,"Technical Part List");
	}
	if (strcmp(PartType,"V")==0)
	{
		strcpy(PartType1,"Vehicle");
	}
	if (strcmp(PartType,"")==0)
	{
		strcpy(PartType1,"NULL");
	}


	printf("\n print_bom--TCDCPartType after strcpy  is :%s ",PartType1);fflush(stdout);

	int_ent_sequence=atoi(enterprise_sequence);

	dumy_Item_ID_str=MEM_string_copy(Item_ID_str) ;
	projectcode=subString(dumy_Item_ID_str,0,4);
	desgngrp=subString(dumy_Item_ID_str,4,2);

	//	printf("\nTCDCprojectcode------->%s\n",projectcode);
	//	printf("\nTCDCdesgngrp------->%s\n",desgngrp);
	//    if (Parent)
	//	{
	//			   printf("\nTCDCThis is first line\n");
	//	}
	//	else
	//	{

	if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	if(  BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));

	if(  BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));

	if(parent) parent=NULL;

	if(BOM_line_ask_attribute_string(Parent, Item_Revision, &parentrev));
	if(BOM_line_ask_attribute_string(Parent, Item_ID, &parent));
	if(BOM_line_ask_attribute_string(Parent, Item_Description, &parentdesc));

	if(BOM_line_ask_attribute_tag(Parent, parent_item_seq, &ParentItemRevTag));
	if(AOM_ask_value_int(ParentItemRevTag,"sequence_id",&Parentsequence_id));

	PatSeq=malloc(3);
	sprintf(PatSeq,"%d",Parentsequence_id);

	printf("\n print_bom--TCDCparent---->%s ", parent);fflush(stdout);
	printf("\n print_bom--TCDCparentrev---->%s ",parentrev );fflush(stdout);
	printf("\n print_bom--TCDCPatSeq---->%s ",PatSeq );fflush(stdout);
	printf("\n print_bom--TCDCparentdesc---->%s ",parentdesc );fflush(stdout);
	printf("\n print_bom--TCDCItem_Description_str---->%s ",Item_Description_str );fflush(stdout);

	Flag=0;
	if(parent)
	{
		if(strcmp(parent,Item_idP)==0) // commented last by skk on 10/15/2011 && strcmp(CatiaOccName_str,"")!=0)
		{
			printf("\n print_bom--TCDConly Single level str for  Item_idP-->%s and Item_idC :%s and qty :%d\n",Item_idP,Item_idC,qty);fflush(stdout);
			fprintf(fus,parent);
			fprintf(fus,",");
			fprintf(fus,parentrev);
			fprintf(fus,",");
			fprintf(fus,PatSeq);
			fprintf(fus,",");
			fprintf(fus,PatSeq);

			fprintf(fus,",");
			fprintf(fus,Item_ID_str);
			fprintf(fus,",");
			fprintf(fus,Item_Revision_str);
			fprintf(fus,",");
			fprintf(fus,ITemRevSeq);
			fprintf(fus,",");
			fprintf(fus,ITemRevSeq);
			fprintf(fus,",");
			fprintf(fus,Item_ID_str);
			fprintf(fus,",");
			fprintf(fus,CatiaOccName_str);
			fprintf(fus,",");
			fprintf(fus,occ_xform_matrix_str);
			fprintf(fus,",");
			if(qty==1 || qty ==0 )
			{
				fprintf(fus,"1");
				fprintf(fus,",");
			}
			if(qty >1)
			{
				sprintf(tmpchar,"%d",qty);

				printf("\n print_bom--TCDCtmpchar is:%s and bl_Qty_str :%s and TmpQty:%d ",tmpchar,bl_Qty_str,TmpQty);fflush(stdout);

				fprintf(fus,tmpchar);
				fprintf(fus,",");
			//	cLen=strlen(CatiaOccName_str);
			//	printf("\nTCDCcLen length of CatiaOccName_str :%d ",cLen);
			//	tmpchar1=subString(CatiaOccName_str,(cLen-1),1);
				//printf("\nTCDCmulQtyIndex is:%d ",mulQtyIndex);
				sprintf(tmpchar1,"%d",TmpQty);
				printf("\n print_bom--TCDCtmpchar1 index  is:%s ",tmpchar1);fflush(stdout);

				fprintf(fus,tmpchar1);
				fprintf(fus,",");
			}

			fprintf(fus,Item_ID_str);
			fprintf(fus,",");
			//fprintf(fus,User_str);
			//fprintf(fus,",");
			//fprintf(fus,"-");
			//fprintf(fus,",");
			//fprintf(fus,"reptest");
		}
		else
		{
			Flag=1;
			printf("\n print_bom--TCDCdont expand for other parts Flag: [%d] ",Flag);fflush(stdout);
		}
	}
	else
	{
		printf("\n print_bom--TCDCbl_Qty for chidren is:%d ",bl_Qty);fflush(stdout);
		printf("\n print_bom--TCDCbl_Qty for chidren is:%d ",bl_Qty);fflush(stdout);
		fprintf(fus,Item_ID_str);
		fprintf(fus,",");
		fprintf(fus,Item_Revision_str);
		fprintf(fus,",");
		fprintf(fus,ITemRevSeq);
		fprintf(fus,",");
		fprintf(fus,ITemRevSeq);
		fprintf(fus,",");
		fprintf(fus,Item_ID_str);
		fprintf(fus,",");
		fprintf(fus,Item_Revision_str);
		fprintf(fus,",");
		fprintf(fus,ITemRevSeq);
		fprintf(fus,",");
		fprintf(fus,Item_ID_str);
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,"NULL");
		fprintf(fus,",");
		fprintf(fus,Item_ID_str);
		fprintf(fus,",");
		//fprintf(fus,"-");
		//fprintf(fus,",");
		//fprintf(fus,"reptest");
	}

	printf("\n print_bom--TCDCcheck flag for single level exp: [%d] ",Flag);fflush(stdout);
	if(Flag==0)
	{
		if(GRM_list_secondary_objects_only(itemrev,reln_type,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
		printf("\n print_bom--n_attchs: [%d] ",n_attchs);fflush(stdout);
		if(n_attchs>0)
		{
			for (i= 0; i < n_attchs; i++)
			{
				primary=secondary_objects[i];

				if(TCTYPE_ask_object_type(primary,&objTypeTag));
				if(TCTYPE_ask_name(objTypeTag,type_name));

				//if (AOM_ask_value_string(type_name,"current_desc",&Desc_obj)!=ITK_ok)   PrintErrorStack();
				//printf("\n print_bom--TCDCDesc_obj is :%s ",Desc_obj);

				printf("\n i= [%d] print_bom--type_name: [%s] ", i , type_name);fflush(stdout);

				if(strcmp(type_name,"CMI2Product")==0 ||  strcmp(type_name,"CMI2Part")==0 || strcmp(type_name,"CMI2Drawing")==0 || strcmp(type_name,"DirectModel")==0)
				{
					if(AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev));
					if(AE_ask_dataset_ref_count(primary,&referencenumberfound));
					for(j=0;j<referencenumberfound;j++)
					{
						if(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));

						printf("\n\t print_bom--refname: [%s] ",refname);fflush(stdout);

						if(strcmp(refname,"catpart")==0 || strcmp(refname,"catproduct")==0 ||strcmp(refname,"catdrawing")==0 )
						{
							if(strcmp(refname,"catpart")==0)
							{
								if( AE_get_bounding_boxes(primary, &numBoundingBoxes, &boundingBoxes));
							}
							if( IMF_ask_original_file_name(refobject,orig_name));
							if(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name1)!=ITK_ok)PrintErrorStack();

							printf("\n print_bom--TCDCpath_name1 in printbomis :%s ",path_name1);fflush(stdout);
							printf("\n print_bom--TCDCorig_namein printbom is is :%s ",orig_name);fflush(stdout);
							printf("\n print_bom--TCDCItem_Description- before printbom ->%s and Item_idP :%s ",Item_Description_str,Item_idP );fflush(stdout);
							printf("\n print_bom--TCDCPartType before Actualy printis :%s ",PartType1);fflush(stdout);

							//fprintf(fus,",");
							fprintf(fus,orig_name);
							fprintf(fus,",");
							fprintf(fus,orig_name);
							fprintf(fus,",");
							fprintf(fus,ITemRevSeq);
							fprintf(fus,",");
							fprintf(fus,User_str);
							fprintf(fus,",");
							fprintf(fus,"NULL");
							fprintf(fus,",");
							fprintf(fus,"NULL");
							fprintf(fus,",");
							fprintf(fus,PartType1);
							fprintf(fus,",");
							fprintf(fus,User_str);
							fprintf(fus,",");
							fprintf(fus,Desc_obj);
							fprintf(fus,"\n");
					   }
				   }

			   }
			}
		}
		else
			printf("\n print_bom--TCDCThere are no data item attached to it ");fflush(stdout);

		if(BOM_line_ask_child_lines (line, &n, &children));

		TmpQty=0;
		p=0;

		for (k = 0; k < n; k++)
		{
			qtyCnt1=0;
			//TmpQty=0;
			if(Childobject1) Childobject1=NULLTAG;
			Childobject1=children[k];

			Item_Type1=0;
			if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_Type1));
			printf("\n print_bom--TCDCItem_Type1 for k loop :%d ",Item_Type1);fflush(stdout);
			if(Item_ID_strW2) Item_ID_strW2=NULL; Item_ID_strW2=malloc(50);
			if(BOM_line_ask_attribute_string(Childobject1, Item_Type1, &Item_ID_strW2));
			printf("\n print_bom--TCDCItem_ID_strW2 : %s for k :%d ",Item_ID_strW2,k);fflush(stdout);

			for (k1 = 0; k1 < n; k1++)
			{
				if(Childobject2) Childobject2=NULLTAG;
				Childobject2=children[k1];

				Item_Type1=0;
				if( BOM_line_look_up_attribute ("bl_item_item_id",&Item_Type2));
				printf("\n print_bom--TCDCItem_Type2 for k1 loop :%d ",Item_Type2);fflush(stdout);
				if(Item_ID_strW3) Item_ID_strW3=NULL; Item_ID_strW3=malloc(50);
				if(BOM_line_ask_attribute_string(Childobject2, Item_Type2, &Item_ID_strW3));
				printf("\n print_bom--TCDCItem_ID_strW3 : %s for k1 :%d ",Item_ID_strW3,k1);fflush(stdout);
				if (strcmp(Item_ID_strW2,Item_ID_strW3)==0)
				{
					qtyCnt1++;
					printf("\n print_bom--TCDCfound more than once before print_bom Item_ID_strW2:%s and qtyCnt1:%d  and p:%d ",Item_ID_strW2,qtyCnt1,p);fflush(stdout);

				}
			}

			printf("\n print_bom--TCDCBefore calling printbom Item_ID_strW2: %s and its qty in bom qtyCnt1:%d ",Item_ID_strW2,qtyCnt1);fflush(stdout);

			if (qtyCnt1 >1)
			{
				printf("\n print_bom--TCDCcalling  for print_bom qtyCnt1 >1 multiqty   for Item_ID_strW2 :%s for k:%d ",Item_ID_strW2,k);fflush(stdout);
				print_bom (children[k],line,depth,Item_idP,Item_ID_strW2,qtyCnt1,p,fdf,fus);
				if(qtyCnt1 >1 && p < qtyCnt1) { p=p+1;}
				printf("\n print_bom--TCDCcalling  print_bom recursively for k:%d ",k);fflush(stdout);
			}
			if (qtyCnt1<=1)
			{
				printf("\n print_bom--TCDCcallingfor print_bom qtyCnt1 <1for Item_ID_strW2 :%s for k:%d ",Item_ID_strW2,k);fflush(stdout);
				qtyCnt1=1;
				print_bom (children[k],line,depth,Item_idP,Item_ID_strW2,qtyCnt1,p,fdf,fus);
			}
		}
	}
}
int FunToCheckCharLength(tag_t Des_rev_tag,char** sError)
{
	char*	sUsrInfo			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	int     n_entry				=	1;
	char    *qry_sys_entry[1]	=	{"SYSCD"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
	int		IntCntlObj			=	0;
	tag_t   *CntrlObject_Tag    =	NULLTAG;
	char	*aModObjName		=	NULL;
	char	*sModObjDesc		=	NULL;
	char	*sModKeyDescNm		=	NULL;
	char	*sModule			=	NULL;
	char	*sCpyRefDesc		=	NULL;
	int		IsValidFlag			=	0;

	TC_write_syslog("\n Inside Custom function FunToCheckCharLength function: \n");

	// control object for FunToCheckCharLength function.

	if(QRY_find("ControlObjects", &Cntl_obj_Qtag));
	if (Cntl_obj_Qtag)
	{
		TC_write_syslog("\n FunToCheckCharLength--ModCharLen:Found Query ControlObjects \n");
	}
	else
	{
		TC_write_syslog("\n FunToCheckCharLength--ModCharLen:Not Found Query ControlObjects \n");
	}

	qry_sys_values[0] = "ModCharLen" ;
	if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
	TC_write_syslog(" \n FunToCheckCharLength--ModCharLen:IntCntlObj :%d:", IntCntlObj);

	if(IntCntlObj>0)
	{
		if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok);PrintErrorStack();
		printf("\n FunToCheckCharLength--sUsrInfo= [%s] ",sUsrInfo);fflush(stdout);

		if(strcmp(sUsrInfo,"ON")==0)
		{
			if( AOM_UIF_ask_value(Des_rev_tag,"object_name",&aModObjName)!=ITK_ok);
			if( AOM_UIF_ask_value(Des_rev_tag,"object_desc",&sModObjDesc)!=ITK_ok);
			if( AOM_UIF_ask_value(Des_rev_tag,"t5_CategoryName",&sModKeyDescNm)!=ITK_ok);
			if( AOM_UIF_ask_value(Des_rev_tag,"t5_Module",&sModule)!=ITK_ok);
			if( AOM_UIF_ask_value(Des_rev_tag,"t5_CpyRefDesc",&sCpyRefDesc)!=ITK_ok);

			TC_write_syslog("\n FunToCheckCharLength--function: [%s][%s][%s][%s]\n",aModObjName,sModObjDesc,sModKeyDescNm,sCpyRefDesc);fflush(stdout);

			if ((strlen(aModObjName) > 40) || (strlen(sModObjDesc) > 40) || (strlen(sModKeyDescNm) > 40) || (strlen(sModule) > 40))
			{
				*sError = malloc(100 * sizeof (char *) );

				strcpy(*sError,"");
				strcat(*sError,"Property: ");
				TC_write_syslog("\n Module Desc is more than 40 digit: [%s]\n", sModObjDesc);fflush(stdout);
				IsValidFlag=1;

				if(strlen(aModObjName) > 40)
				{
					strcat(*sError,"Name, ");
				}
				if(strlen(sModObjDesc) > 40)
				{
					strcat(*sError," Description, ");
				}
				if(strlen(sModKeyDescNm) > 40)
				{
					strcat(*sError," Keyword Description, ");
				}
				if(strlen(sModule) > 40)
				{
					strcat(*sError," Module, ");
				}

				strcat(*sError," should be less than or equal to 40 charecters.");

				TC_write_syslog("\n FunToCheckCharLength--ERROR: [%s] \n",*sError);
			}
			else
			{
				TC_write_syslog("\n FunToCheckCharLength--Module Name,Desc.,Keyword Desc. are less than or equal to 40 digits:\n");fflush(stdout);
				IsValidFlag=0;
				*sError = malloc(100 * sizeof (char *) );
				strcpy(*sError,"");
			}
		}
		else
		{
			TC_write_syslog("\n FunToCheckCharLength--ModCharLen control object's info1 value is not ON \n");fflush(stdout);
		}
	}
	else
	{
		TC_write_syslog("\n FunToCheckCharLength--ModCharLen control object not found.\n");fflush(stdout);
	}

	return IsValidFlag;
}

int IsThisTrilixSite(tag_t Des_rev_tag)
{
	int		flag				=	0;
	char	*sProCode			=	NULL;
	char	*sDesGrp			=	NULL;
	int 	index				=	0;
	char *  SiteName			=	NULL;
	char*	sUsrInfo			=	NULL;
	char*	sUsrInfo2			=	NULL;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	tag_t   *CntrlObject_Tag	=	NULLTAG;
	int     n_entry				=	1;
	char    *qry_sys_entry[1]	=	{"SYSCD"};
	char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
	int		IntCntlObj			=	0;

	if(PREF_ask_char_value("tm_TC_site_name",index,&SiteName)!=ITK_ok);PrintErrorStack();
	printf("\n IsThisTrilixSite--SiteName= [%s] ",SiteName);fflush(stdout);

	if(tc_strcmp(SiteName,"Trilix")==0)
	{
		TC_write_syslog("\n Inside preaction_on_checkin:checkin_method_1:IsThisTrilixSite function: Site is Trilix \n");
		ITK_CALL(AOM_UIF_ask_value(Des_rev_tag,"t5_ProjectCode",&sProCode));
		ITK_CALL(AOM_UIF_ask_value(Des_rev_tag,"t5_DesignGrp",&sDesGrp));

		if(QRY_find("ControlObjects", &Cntl_obj_Qtag));
		if (Cntl_obj_Qtag)
		{
			TC_write_syslog("\n preaction_on_checkin:checkin_method_1::IsThisTrilixSite::Found Query ControlObjects \n");
		}
		else
		{
			TC_write_syslog("\n preaction_on_checkin:checkin_method_1::IsThisTrilixSite::Not Found Query ControlObjects \n");
		}
		qry_sys_values[0] = "Trilix_Proj" ;
		if(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCntlObj, &CntrlObject_Tag));
		TC_write_syslog(" \n preaction_on_checkin:checkin_method_1::IsThisTrilixSite:SiteName:[%s]:IntCntlObj:[%d]",SiteName,IntCntlObj);
		if(IntCntlObj>0)
		{
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo1",&sUsrInfo)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(CntrlObject_Tag[0],"t5_Userinfo2",&sUsrInfo2)!=ITK_ok);PrintErrorStack();
			// if project found in info1 then not allow uaprod user to create it.
			if(tc_strstr(sUsrInfo,sProCode)!=NULL)
			{
				TC_write_syslog("\n preaction_on_checkin:checkin_method_1::IsThisTrilixSite:: Project found in Trilix site \n");
				TC_write_syslog("\n project code present flag set to 0 \n");
				// if design group found in info2 then not allow uaprod user to create it.
				if(tc_strstr(sUsrInfo2,sDesGrp)!=NULL)
				{
					TC_write_syslog("\n preaction_on_checkin:checkin_method_1::IsThisTrilixSite:: Design group is valid for Trilix site \n");
					TC_write_syslog("\n design group present flag set to 0 \n");
					flag=1;
				}
				else
				{
					TC_write_syslog("\n design group not present flag set to 1 \n");
					flag=0;
				}

			}
			else
			{
				TC_write_syslog("\n project code not present flag set to 1\n");
				flag=0;
			}
		}
	}

	return flag;
}

	/******************************************************* Added by Aashish_w Start *******************************************************/
int t5_partcategory(tag_t Des_Rev_tag,char **OutputStr)
{
	int IsValidFlag = 0;
	char *partcatgry = NULL;
	partcatgry=(char *) MEM_alloc(1000);
	char *parttype = NULL;
	char *prjcode = NULL;
	char *designGrp = NULL;
	char *itemid;
	itemid=(char *) MEM_alloc(1000);
	char *itemid_toked;
	itemid_toked=(char *) MEM_alloc(1000);
	char *itemid_toked1;
	itemid_toked1=(char *) MEM_alloc(1000);
	int itemidlength = 0;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	tag_t   Cntl_obj_Qtag2		=	NULLTAG;
	int n_entries1 = 3;
	int n_entries2 = 3;
	char *qry_entries1[3] = {"Name","SYSCD","SUBSYSCD"};
	char *qry_entries2[3] = {"Information-1","SYSCD","SUBSYSCD"};
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount1=0;
	int resultCount2=0;
	tag_t *qry_cntrlobj= NULLTAG;
	tag_t *qry_cntrlobj2= NULLTAG;
	char *userinfo1;

	*OutputStr=(char *) MEM_alloc(250);
	strcpy(*OutputStr,"");

	printf("\n Inside t5_partcategory-----------");fflush(stdout);

	if( AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry)==ITK_ok)  PrintErrorStack();
	printf("\n t5_partcategory--Part Category --------> %s \n",partcatgry);fflush(stdout);
	//if (partcatgry != NULL)
	if ( (tc_strlen(partcatgry)!=0) && (tc_strcmp(partcatgry,"")!=0))		//MBOM implementation for CV TZ-1.69
	{
		if(QRY_find("Control Objects...", &Cntl_obj_Qtag));
		if (Cntl_obj_Qtag)
		{
			printf("\n t5_partcategory--Query Found : Control Objects... \n");fflush(stdout);
		}
		else
		{
			printf("\n t5_partcategory--Query NOT Found : Control Objects... \n");fflush(stdout);
		}
		//************************************ 1.Designer has to mandatorily select the part categories from the available dropdown while creating TC part. ************************************
		if (Cntl_obj_Qtag != NULLTAG)
		{
			qry_values1[0] = partcatgry ;
			qry_values1[1] = "PRTCAT" ;
			qry_values1[2] = "PRTCAT" ;

			ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_cntrlobj));
		}

		printf("\n t5_partcategory--Count of Control object found while save validation ------------------>  %d \n",resultCount1);
		if (resultCount1 > 0)
		{
			printf("\n t5_partcategory--Inside my IF \n");fflush(stdout);
			AOM_ask_value_string(qry_cntrlobj[0],"t5_Userinfo1",&userinfo1);

			ITK_CALL(AOM_refresh(Des_Rev_tag,1));
			ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria",userinfo1));
			ITK_CALL( AOM_save(Des_Rev_tag));
			ITK_CALL(AOM_refresh(Des_Rev_tag,0));

			IsValidFlag =0;

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
			printf("\n t5_partcategory--Part Category after save --------> %s \n",partcatgry);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
			printf("\n t5_partcategory--Item ID --------> %s \n",itemid);fflush(stdout);

			//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
			if (tc_strcmp(partcatgry,"CON")==0)
			{
					printf("\n t5_partcategory--inside Part Category CON check \n");fflush(stdout);
				if (tc_strlen(itemid) == 12)
				{
					printf("\n t5_partcategory--CON Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
				}
			}
			//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
			printf("\n t5_partcategory--Part Type is ----> %s \n",parttype);fflush(stdout);
			if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
			{
				printf("\n t5_partcategory--Inside Part Type Dummy check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));
				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
				ITK_CALL( AOM_save(Des_Rev_tag));
				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
			printf("\n t5_partcategory--Project Code of Part --------> %s \n",prjcode);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
			printf("\n t5_partcategory--Design Group of Part --------> %s \n",designGrp);fflush(stdout);

			//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
			{
				//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
				itemid_toked=subString(itemid,0,1);
				printf("\n t5_partcategory--ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
				if (tc_strcmp(itemid_toked,"5")==0)
				{
					printf("\n t5_partcategory--Inside Parts starting from 5 check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
				else
				{
					printf("\n t5_partcategory--Inside Parts NOT starting from 5 check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
			}
			//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
			if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
			{
				printf("\n t5_partcategory--inside project code 1111 & design group 11 check \n");fflush(stdout);

				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory--ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory--Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory--Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
				{
					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
					{
							printf("\n t5_partcategory--Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
							ITK_CALL( AOM_save(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					else
					{
						printf("\n t5_partcategory--STD & CON Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11 & 54.Please select other value.");
					}
				}
			}
		//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
		if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
			{
					printf("\n t5_partcategory--Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
			//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
			if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
			{
				printf("\n t5_partcategory--Inside Part type Vehicle , TPL, VC CR, VC, Group ID, Dummy, Dummy TPL must carry PHN check \n");fflush(stdout);
				ITK_CALL(AOM_refresh(Des_Rev_tag,1));
				ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
				ITK_CALL( AOM_save(Des_Rev_tag));
				ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
			//******************** 7.Part number having third barrel �16� must carry TSD:TML Specification Document. ********************
			itemid_toked1=subString(itemid,6,2);
			printf("\n t5_partcategory--itemid_toked1 of 3rd baral ------> %s",itemid_toked1);
			if (tc_strcmp(itemid_toked,"16")==0)
			{
				printf("\n Inside Part number having third barrel �16� must carry TSD:TML Specification Document check \n");fflush(stdout);
				if (tc_strcmp(partcatgry,"TSD-Black")==0 || tc_strcmp(partcatgry,"TSD-Gray")==0)
				{
						printf("\n t5_partcategory--Inside Part number having third barrel �16� must carry TSD:TML Specification Document check Sucessful\n");fflush(stdout);
				}
				else
				{
					printf("\n t5_partcategory--third barrel 16 Lov BreakDown...\n");fflush(stdout);
					IsValidFlag =1;
					strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
				}
			}
		}
		else
		{
			if(QRY_find("Control Objects...", &Cntl_obj_Qtag2));

			if (Cntl_obj_Qtag2 != NULLTAG)
			{
				qry_values2[0] = partcatgry ;
				qry_values2[1] = "PRTCAT" ;
				qry_values2[2] = "PRTCAT" ;

				ITK_CALL(QRY_execute(Cntl_obj_Qtag2, n_entries2, qry_entries2, qry_values2, &resultCount2, &qry_cntrlobj2));
			}
			printf("\n t5_partcategory--B.Count of Control object 2222 found while save validation ------------------>  %d \n",resultCount2);
			if (resultCount2 > 0)
			{
				IsValidFlag =0;
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_SpareCriteria",&partcatgry));
				printf("\n t5_partcategory--B.Part Category after save --------> %s \n",partcatgry);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				printf("\n t5_partcategory--B.Item ID --------> %s \n",itemid);fflush(stdout);
				//******************** 2.CON- Consumable parts will be needed. Check will be put in not to use this part category for 12 digit ERC part. *******************
				if (tc_strcmp(partcatgry,"CON")==0)
				{
					printf("\n t5_partcategory--B.inside Part Category CON check \n");fflush(stdout);
					if (tc_strlen(itemid) == 12)
					{
						printf("\n CON Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Part Category CON:Consumable parts is invalid for 12 digit parts.");
					}
				}
				//******************** 3.As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
				printf("\n t5_partcategory--B.Part Type is ----> %s \n",parttype);fflush(stdout);
				if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0)
				{
					printf("\n t5_partcategory--B.Inside Part Type Dummy check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
				printf("\n t5_partcategory--B.Project Code of Part --------> %s \n",prjcode);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
				printf("\n t5_partcategory--B.Design Group of Part --------> %s \n",designGrp);fflush(stdout);
				//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory--B.ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory--B.Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory--B.Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				//******************** 4.System should not allow STD & CON for parts other than project code "1111" & design group "11". ********************
				if (tc_strcmp(partcatgry,"STD")==0 || tc_strcmp(partcatgry,"CON")==0 )
				{
					printf("\n t5_partcategory--B.inside project code 1111 & design group 11 check \n");fflush(stdout);

					if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
					{
						//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
						itemid_toked=subString(itemid,0,1);
						printf("\n t5_partcategory--B.ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
						if (tc_strcmp(itemid_toked,"5")==0)
						{
							printf("\n t5_partcategory--B.Inside Parts starting from 5 check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
							ITK_CALL( AOM_save(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
						else
						{
							printf("\n t5_partcategory--B.Inside Parts NOT starting from 5 check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
							ITK_CALL( AOM_save(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
					}
					else
					{
						if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
						{
							printf("\n t5_partcategory--B.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
							ITK_CALL(AOM_refresh(Des_Rev_tag,1));
							ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
							ITK_CALL( AOM_save(Des_Rev_tag));
							ITK_CALL(AOM_refresh(Des_Rev_tag,0));
						}
						else
						{
							printf("\n t5_partcategory--B.STD & CON Lov BreakDown...\n");fflush(stdout);
							IsValidFlag =1;
							strcat(*OutputStr,"Part Category STD:Standard Part & CON:Consumable parts is valid only for Project Code 1111 & Design Group 11.Please select other value.");
						}
					}
				}
				//******************** 5.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
				{
					printf("\n t5_partcategory--B.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				//******************** 6.Part type Vehicle , TPL, VC, Group ID, Dummy, Dummy TPL,VC CR must carry PHN (PHN:Phantom Assembly). ********************
				if (tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"VCCR")==0 )
				{
					printf("\n t5_partcategory--B.Inside Part type Vehicle,TPL,VC_CR,VC,Group_ID,Dummy,Dummy_TPL must carry PHN check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
				}
				//******************** 7.Part number having third barrel �16� must carry TSD:TML Specification Document. ********************
				itemid_toked1=subString(itemid,6,2);
				printf("\n t5_partcategory--B.itemid_toked1 of 3rd baral ------> %s",itemid_toked1);
				if (tc_strcmp(itemid_toked,"16")==0)
				{
					printf("\n t5_partcategory--B.Inside Part number having third barrel �16� must carry TSD:TML Specification Document check \n");fflush(stdout);
					if (tc_strcmp(partcatgry,"TSD-Black")==0 || tc_strcmp(partcatgry,"TSD-Gray")==0)
					{
						printf("\n t5_partcategory--B.Inside Part number having third barrel �16� must carry TSD:TML Specification Document check Sucessful\n");fflush(stdout);
					}
					else
					{
						printf("\n t5_partcategory--B.third barrel 16 Lov BreakDown...\n");fflush(stdout);
						IsValidFlag =1;
						strcat(*OutputStr,"Please Select Part Category as TSD-Black or TSD-Gray.");
					}
				}
			}
			else
			{
				printf("\n t5_partcategory--B.Suggestive LOV Breakdown...\n");fflush(stdout);
				IsValidFlag =1;
				strcat(*OutputStr,"Please select values of Part Category from Dropdown List Only.");
			}
		}
	}
	else
	{
		//******************** As this field is going to be mandatory, for dummy parts PHN- phantom should be stamped. *********************
		ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
		printf("\n t5_partcategory--C.Part Type is ----> %s \n",parttype);fflush(stdout);
		if (tc_strcmp(parttype,"D")==0 || tc_strcmp(parttype,"DC")==0 || tc_strcmp(parttype,"DA")==0 || tc_strcmp(parttype,"G")==0 || tc_strcmp(parttype,"V")==0 || tc_strcmp(parttype,"TPL")==0 || tc_strcmp(parttype,"VC")==0 || tc_strcmp(parttype,"VCCR")==0 )
		{
			printf("\n t5_partcategory--C.Inside Part Type Dummy check \n");fflush(stdout);
			ITK_CALL(AOM_refresh(Des_Rev_tag,1));
			ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","PHN"));
			ITK_CALL( AOM_save(Des_Rev_tag));
			ITK_CALL(AOM_refresh(Des_Rev_tag,0));
		}
		else
		{
			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_ProjectCode",&prjcode));
			printf("\n t5_partcategory--C.Project Code of Part --------> %s \n",prjcode);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_DesignGrp",&designGrp));
			printf("\n t5_partcategory--C.Design Group of Part --------> %s \n",designGrp);fflush(stdout);
			//******************** Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category. ********************

			if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"54")==0)
			{
					printf("\n t5_partcategory--C.Part with design group 54 and Project code 1111 must carry STD (STD:Standard Part) part category check \n");fflush(stdout);
					ITK_CALL(AOM_refresh(Des_Rev_tag,1));
					ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
					ITK_CALL( AOM_save(Des_Rev_tag));
					ITK_CALL(AOM_refresh(Des_Rev_tag,0));
			}
			else
			{
				ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"item_id",&itemid));
				//******************** if prj is 1111 and dsgngrp is 11 then std or con only  **************************..
				if (tc_strcmp(prjcode,"1111")==0 && tc_strcmp(designGrp,"11")==0)
				{
					//******** According to TS 11808, parts starting from 5 should carry CON as Part Category. *********
					itemid_toked=subString(itemid,0,1);
					printf("\n t5_partcategory--C.t5_partcategory--C.ItemId_Toked -------> %s \n",itemid_toked);fflush(stdout);
					if (tc_strcmp(itemid_toked,"5")==0)
					{
						printf("\n t5_partcategory--C.Inside Parts starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","CON"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
					//******** According to TS 11808,  Parts starting with other than 5 should carry STD as Part Category. *********
					else
					{
						printf("\n t5_partcategory--C.Inside Parts NOT starting from 5 check \n");fflush(stdout);
						ITK_CALL(AOM_refresh(Des_Rev_tag,1));
						ITK_CALL(AOM_UIF_set_value(Des_Rev_tag,"t5_SpareCriteria","STD"));
						ITK_CALL( AOM_save(Des_Rev_tag));
						ITK_CALL(AOM_refresh(Des_Rev_tag,0));
					}
				}
				else
				{
					IsValidFlag =1;
					strcat(*OutputStr,"Please find List of Mandatory Attributes,*Part Category*.");
				}
			}
		}
	}

	printf("\n t5_partcategory--Processing completed.... \n");fflush(stdout);

	return IsValidFlag;
}
/******************************************************* Added by Aashish_w End *******************************************************/

/******************************************************* Added by Aashish_w Start *******************************************************/
int GroupIDCheck(tag_t Des_Rev_tag,char **OutputStr)
{
	int IsValidFlag = 0;
	char *partcatgry = NULL;
	partcatgry=(char *) MEM_alloc(1000);
	char *parttype = NULL;
	char *prjcode = NULL;
	char *designGrp = NULL;
	char *itemid;
	itemid=(char *) MEM_alloc(1000);
	char *itemid_toked;
	itemid_toked=(char *) MEM_alloc(1000);
	char *itemid_toked1;
	itemid_toked1=(char *) MEM_alloc(1000);
	int itemidlength = 0;
	tag_t   Cntl_obj_Qtag		=	NULLTAG;
	tag_t   Cntl_obj_Qtag2		=	NULLTAG;
	int n_entries1 = 3;
	int n_entries2 = 3;
	char *qry_entries1[3] = {"Name","SYSCD","SUBSYSCD"};
	char *qry_entries2[3] = {"Information-1","SYSCD","SUBSYSCD"};
	char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount1=0;
	int resultCount2=0;
	tag_t *qry_cntrlobj= NULLTAG;
	tag_t *qry_cntrlobj2= NULLTAG;
	char *userinfo1;
	tag_t bom_window=NULLTAG;
	tag_t top_line=NULLTAG;
	int n_lines=0;
	tag_t *lines=NULLTAG;

	*OutputStr=(char *) MEM_alloc(250);
	strcpy(*OutputStr,"");

	printf("\n Inside GroupIDCheck...");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(Des_Rev_tag,"t5_PartType",&parttype));
	printf("\n GroupIDCheck:Part Type is ----> %s ",parttype);fflush(stdout);
	if (tc_strcmp(parttype,"G")==0)
	{
		BOM_create_window( &bom_window );

		BOM_set_window_top_line( bom_window, NULLTAG, Des_Rev_tag, NULLTAG, &top_line );

		BOM_line_ask_child_lines(top_line, &n_lines, &lines);
		if(n_lines > 1)
		{
			printf("\n GroupIDCheck is Valid...");fflush(stdout);
		}
		else
		{
			printf("\n GroupIDCheck is InValid...");fflush(stdout);
			IsValidFlag =1;
			strcat(*OutputStr,"Selected Part has 1 or no Child Part. Minimum 2 child parts must be present under selected part.");
		}
	}

	printf("\n GroupIDCheck function process is finished..\n");fflush(stdout);

	return IsValidFlag;
}
/******************************************************* Added by Aashish_w End *******************************************************/

//**************************************

						int	read_value_from_file(char* Filename)
						{
							int		count					= 0;
							
							char	*item_id							= NULL;
							char	*module_no					= NULL;
							char	*DesignRuleID						= NULL;
							char	*ChecklistImplemented					= NULL;
							char	*Remark					= NULL;
							char* irchecklist							=NULL;
							char* irchecklistobj						=NULL;
						//	char	*rev_id					= NULL;
							char	 temp[3000];
						//	  char	*SrNo					= NULL;
						   
							
							FILE* fp = NULL;
							fp = fopen(Filename, "r");
							
							if (fp != NULL)
							{
								while (fgets(temp, 3000, fp)!= NULL)
								{
									tc_strcpy(temp,stripBlanks(temp));

									if (tc_strlen(temp)	> 0	&& tc_strcmp(temp, NULL) !=	0)
									{
										//printf("\ntemp:%s",temp);
							//			SrNo = strtok(temp,	",");
							//			printf("\n Sr No:%s",SrNo);

										module_no =	strtok(temp, "|");
										printf("\n module no:%s",module_no);

									//	rev_id = strtok(NULL, ",");
								//		printf("\n rev id:%s",rev_id);

										DesignRuleID = strtok(NULL,	"|");
										printf("\nDesign RuleID:%s",DesignRuleID);

										ChecklistImplemented = strtok(NULL,	"|");
										printf("\nChecklist	Implemented:%s",ChecklistImplemented);

										Remark = strtok(NULL, "|");
										printf("\nRemark:%s",Remark);
									
										ifail =	IR_checklist(module_no,DesignRuleID,ChecklistImplemented,Remark);
									}			
									tc_strcpy(temp,	"");
								}
							}
							else 
							{
								printf("File Unable	to Open...!!");
							}
							fclose(fp);
						//	fclose(output);
							return ifail;
						}


						/********************************************************************************************
							Function:       IR_checklist
							Description:    This function takes the item_id as input and get it's all revisions 
											and checks for release status and writes information into a file.
						********************************************************************************************/
						int IR_checklist(char* module_no,char* DesignRuleID,char* ChecklistImplemented,char* Remark)
						{
							int				i 							= 0;
							int				j 							= 0;
							int				count 						= 0;
							int				count_status				= 0;

							//int PorjectCode = atoi(Project);
							
							tag_t			module_tag			= NULLTAG;	
							tag_t			moduleRev_tag			= NULL;
							tag_t           item_type_tag1           = NULLTAG;

							tag_t           item_create_input_tag1   = NULLTAG;
							
							tag_t            object1                = NULLTAG;
							
							tag_t            ChecklistRev            = NULLTAG;
							
							int                 n_items                = 0;
							int                n_items1                = 0;
							int                n_items2                = 0;
							tag_t               item_tag             = NULL;
							tag_t                module_rev         = NULLTAG;
							char               *tempRev_ID	          =NULL;
							tag_t                item_tag1           = NULL;
							
							tag_t relation_type;
							tag_t relation = NULLTAG;
							char* irchecklist=	NULL;
							
							 tag_t            tempChecklistRev            = NULLTAG;
							tag_t relation_type1;
							tag_t relation1 = NULLTAG;
							tag_t latest_rev_id         = NULLTAG;
							char 	*rev_id					= NULL;
						   
							printf("\n ******checklist creation********\n");
							
							ITK_CALL(ITEM_find_item(module_no,&item_tag));
							printf("\n  module found ");

						 //   ITK_CALL(ITEM_find_revision(item_tag,rev_id,&module_rev));
						  //  printf("\n  module rev found");

							ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));

							if (latest_rev_id)
							{
								printf("\n  module rev found");
							}
							else
							{
								printf("\n  module rev not found");
							}
						   ITK_CALL(AOM_ask_value_string(latest_rev_id,"item_revision_id",&rev_id));
						   printf("\n latest module rev:%s",rev_id);

						   ITK_CALL(ITEM_find_revision(item_tag,rev_id,&module_rev));


							// checklist id =Checklist_module_no_tempRev_ID
							char name[]="Checklist_";

							irchecklist=(char *)MEM_alloc(100);
							tc_strcpy(irchecklist,"");
							tc_strcpy(irchecklist,name);
							tc_strcat(irchecklist,stripBlanks(module_no));	    
							tc_strcat(irchecklist,"_");	
							ITK_CALL(STRNG_replace_str(rev_id,";","_",&tempRev_ID));
							printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);
							tc_strcat(irchecklist,stripBlanks(tempRev_ID));
							
							printf("\n  checklist Number:%s",irchecklist);

							ITK_CALL(ITEM_find_item(irchecklist,&item_tag1));
							printf("\nchecklist creation");

							if(item_tag1)
							{
									// function create CheckList Row Data()
									printf("\nCheck List Object is already Available.....updating\n"); fflush(stdout);
									ITK_CALL(ITEM_ask_latest_rev(item_tag1,&ChecklistRev));
								//	createCheckListRowData(item_tag1,SrNo,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented);
									createCheckListRowData(item_tag1,module_no,rev_id,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented,Remark);
									if(module_rev)
								   {
									
									printf("\nchecklist relation creation with module.....\n"); fflush(stdout); 
									ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type1));
									printf("\n module relation creation \n"); fflush(stdout);
									ITK_CALL(GRM_create_relation(module_rev,ChecklistRev,relation_type1,NULLTAG,&relation1));				
									ITK_CALL(AOM_unlock(relation1));
									GRM_save_relation(relation1);
									ITK_CALL(AOM_lock(relation1));
									printf("\nmodule RELATIONSHIP CREATED  \n");fflush(stdout);
								   }
							}
							else
							{
									//Check list object not found so creatiing check list object.

									ITK_CALL(TCTYPE_find_type("T5_IR_CHECKLIST", "Document", &item_type_tag1));         
									ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));
									ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",irchecklist));
									ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",irchecklist));
									ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));

										if(object1)
										{
											ifail = AOM_save(object1);
											ifail = AOM_refresh(object1,0);
											ifail = AOM_unlock(object1);
											printf("\nCheck List Object is created.\n"); fflush(stdout);
											ITK_CALL(ITEM_ask_latest_rev(object1,&ChecklistRev));
											// function create CheckList Row Data()
										//	createCheckListRowData(object1,SrNo,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented);
											createCheckListRowData(item_tag1,module_no,rev_id,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented,Remark);
											if(module_rev)
											{
											  printf("\nchecklist relation creation with module.....\n"); fflush(stdout); 
											  ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type1));
											  printf("\n module relation creation \n"); fflush(stdout);
											  ITK_CALL(GRM_create_relation(module_rev,ChecklistRev,relation_type1,NULLTAG,&relation1));				
											  ITK_CALL(AOM_unlock(relation1));
											  GRM_save_relation(relation1);
											  ITK_CALL(AOM_lock(relation1));
											  printf("\nmodule RELATIONSHIP CREATED  \n");fflush(stdout);
											}
										}
							}


							return ifail;
						}

						int createCheckListRowData(tag_t object,char* module_no,char* rev_id,char* irchecklist,tag_t checkListRev,char* designRule,char* checkListImp,char* Remark)
						{
							printf("\n I am in createCheckListRowData....... \n");


							char*				 irchecklistobj				= NULL;
							tag_t                item_tag2					= NULL;
							tag_t				 item_type_tag2             = NULLTAG;
							tag_t				 item_create_input_tag2     = NULLTAG;	
							tag_t				 object2					= NULLTAG;
							tag_t                ChecklistobjRev            = NULLTAG;
							tag_t				 relation_type;
							tag_t				 relation					= NULLTAG;

						/*	irchecklistobj=(char *)MEM_alloc(100);
							tc_strcpy(irchecklistobj,"");
							tc_strcpy(irchecklistobj,irchecklist);
							tc_strcat(irchecklistobj,"_CHKLIST_DATA_");
							tc_strcat(irchecklistobj,stripBlanks(srNo));
							
							printf("\n checklist data object:%s \n",irchecklistobj);*/




							//*****************************
							//checklist object name = ChecklistData_module_no_tempRev_ID_srNo
						   
						   char* tempRev_ID2=NULL;
						   char name2[]="ChecklistData_";

							irchecklistobj=(char *)MEM_alloc(100);
							tc_strcpy(irchecklistobj,"");
							tc_strcpy(irchecklistobj,name2);
							tc_strcat(irchecklistobj,stripBlanks(module_no));	    
							tc_strcat(irchecklistobj,"_");	
							ITK_CALL(STRNG_replace_str(rev_id,";","_",&tempRev_ID2));
							printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID2);
							tc_strcat(irchecklistobj,stripBlanks(tempRev_ID2));
							tc_strcat(irchecklistobj,"_");
						//	tc_strcat(irchecklistobj,stripBlanks(srNo));
						tc_strcat(irchecklistobj,stripBlanks(designRule));
							
							printf("\n  checklist data Number:%s",irchecklistobj);


						//***********************query for fetching IR properties using given design rule id**********************

									   tag_t ItemQry     = NULLTAG;
									   tag_t* ContainerTag   = NULLTAG;
									   tag_t revtag=NULLTAG;
									   char* agg =NULL;
									   char* agg_grp =NULL;
									   char* rule_desc =NULL;
									   char* Container_RevSeq=NULL;
									   int ConCount=0;
									   int Entry_count=2;
								//	   char *Entries[1] = {"Name"};
								//	   char *Entries[2] = {"Type"};
									   char **Values = (char **) MEM_alloc(100 * sizeof(char *));
									   char* errorString = NULL;
							 //        Values[0] =designRule;
								//	   Values[1] = "Interface Rule Revision";
									
									 
									char *Entries[2] = {"Name","Type"};

									

									Values[0] = designRule;
									Values[1] = "Interface Rule Revision";

									 printf("\nvalue_0:%s",Values[0]);
									 printf("\nvalue_1:%s",Values[1]);


									

								ifail=QRY_find("General...", &ItemQry);

								
								if (ItemQry)
								{ 
								 ITK_CALL(QRY_execute(ItemQry, Entry_count, Entries, Values, &ConCount, &ContainerTag));
								 
								 printf("\n Object Found : %d", ConCount);fflush(stdout);
										
								}	


							ITK_CALL(ITEM_find_item (irchecklistobj,&item_tag2));

							 if(item_tag2)
							 {

										printf("\nCheck List DATA Object is already Available.....updating properties \n"); fflush(stdout);

										ITK_CALL(ITEM_ask_latest_rev(item_tag2,&ChecklistobjRev));
										ITK_CALL(AOM_refresh(ChecklistobjRev,1));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Design_Rule_ID",designRule));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Checklist_Implemented",checkListImp));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Remark",Remark));
										  

							  if (ConCount>0)
							  {
							

								 revtag=ContainerTag[0];
								 agg=(char *) MEM_alloc(100);
								 agg_grp=(char *) MEM_alloc(100);
								 rule_desc=(char *) MEM_alloc(2000);

								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggregate",&agg));
								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggrGrp",&agg_grp));
								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRRuleDesc",&rule_desc));
								 
								  printf("\n  t5_IRAggregate:%s",agg);
								  printf("\n  t5_IRAggrGrp:%s",agg_grp);
								  printf("\n  t5_IRRuleDesc:%s",rule_desc);

								
							   }

						   
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate",agg));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate_Group",agg_grp));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Interface_Rule_Desc",rule_desc));




										//********************************************************************
										ITK_CALL(AOM_save(ChecklistobjRev));
										ITK_CALL(AOM_refresh(ChecklistobjRev,0));
										printf("\nProperties are updated\n");

										printf("\n *******checklist relation creation***********");
											
										ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&relation_type));
										printf("\n aaaaaaaaaa \n"); fflush(stdout);
										ITK_CALL(GRM_create_relation(checkListRev,ChecklistobjRev,relation_type,NULLTAG,&relation));
										printf("\n bbbbbbbbbbb \n"); fflush(stdout);
										ITK_CALL(AOM_unlock(relation));
										GRM_save_relation(relation);
										ITK_CALL(AOM_lock(relation));
										printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
							 }
							 else
							 {
									printf("\n *******checklist data object creation****");

									ITK_CALL(TCTYPE_find_type("T5_IR_CLIST_DATA", "Document", &item_type_tag2));         
									ITK_CALL(TCTYPE_construct_create_input(item_type_tag2, &item_create_input_tag2));
									ITK_CALL(AOM_set_value_string(item_create_input_tag2,"item_id",irchecklistobj));
									ITK_CALL(AOM_set_value_string(item_create_input_tag2,"object_name",irchecklistobj));
									ITK_CALL(TCTYPE_create_object (item_create_input_tag2, &object2));
									if(object2)
									{
										printf("\n T5_IR_CLIST_DATA : object created.");

										ifail = AOM_save(object2);
										ifail = AOM_refresh(object2,0);
										ifail = AOM_unlock(object2);
										printf("\nCheck List DATA  Object is created.\n"); fflush(stdout);

										ITK_CALL(ITEM_ask_latest_rev(object2,&ChecklistobjRev));
										ITK_CALL(AOM_refresh(ChecklistobjRev,1));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Design_Rule_ID",designRule));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Checklist_Implemented",checkListImp));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Remark",Remark));
										
							 
							  if (ConCount>0)
							  {
							

								 revtag=ContainerTag[0];
								 agg=(char *) MEM_alloc(100);
								 agg_grp=(char *) MEM_alloc(100);
								 rule_desc=(char *) MEM_alloc(2000);

								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggregate",&agg));
								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggrGrp",&agg_grp));
								 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRRuleDesc",&rule_desc));
								 
								 printf("\n  t5_IRAggregate:%s",agg);
								  printf("\n  t5_IRAggrGrp:%s",agg_grp);
								  printf("\n  t5_IRRuleDesc:%s",rule_desc);
							
							   }

						   
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate",agg));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate_Group",agg_grp));
										ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Interface_Rule_Desc",rule_desc));


										ITK_CALL(AOM_save(ChecklistobjRev));
										ITK_CALL(AOM_refresh(ChecklistobjRev,0));
										printf("\nProperties are updated\n");

										printf("\n *******checklist relation creation***********");
											
										ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&relation_type));
										printf("\n aaaaaaaaaa \n"); fflush(stdout);
										ITK_CALL(GRM_create_relation(checkListRev,ChecklistobjRev,relation_type,NULLTAG,&relation));
										printf("\n bbbbbbbbbbb \n"); fflush(stdout);
										ITK_CALL(AOM_unlock(relation));
										GRM_save_relation(relation);
										ITK_CALL(AOM_lock(relation));
										printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
									}
							 }

							return 0;
						}