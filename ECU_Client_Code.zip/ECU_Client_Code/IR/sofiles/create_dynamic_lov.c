/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : create_dynamic_lov.c
* Created By                   : Yogiraj
* Created On                   : 05/01/2007
* Project                      : Trillix
* Methods Defined              : CUSTOM_EXIT
* Description                  : Call Dynamic LOV for Project code and Material Class
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>

#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>

//#define ECHO(X)  printf X; IMAN_write_syslog X

#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

//static int myAskLOVLengthMethod( METHOD_message_t *msg, va_list  args ) ;
//static int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args ) ;
static int report_error(char *file, int line, char *call, int status, logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int n_errors = 0;
        int const *severities = NULL,
				  *statuses = NULL;
        const char **messages;

        EMH_ask_errors( &n_errors, &severities, &statuses, &messages );
        if (n_errors > 0)
        {
            printf("\n report_error--if= [%s]", messages[n_errors-1]); fflush(stdout);
			printf("\n report_error=%s\n", messages[n_errors-1]); fflush(stdout);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            printf("\n report_error--Else= [%s] ", error_message_string); fflush(stdout);
        }

        printf("\n report_error--error %d at line %d in [%s]", status, line, file); fflush(stdout);
        printf("\n report_error--[%s] \n", call); fflush(stdout);

        if (exit_on_error)
        {
            printf("\n report_error--Exiting program!!\n"); fflush(stdout);
            exit (status);
        }
    }
    return status;
}

static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

//int myAskLOVLengthMethod( METHOD_message_t *msg, va_list  args )
//{
//  /* va_list for LOV_ask_num_of_values_msg */
//  tag_t  lov_tag = va_arg(args, const tag_t);
//  int    *length = va_arg(args, int*);
//  char  ***values = va_arg(args, char***);
//char *item_sequence_id;
//int status;
//
//int error_code= ITK_ok,
//    n_entries = 2,
//    n_found = 0,
//ii = 0;
//tag_t query = NULLTAG,
//      *cntr_objects = NULL,
//user = NULLTAG;
//char
//    *qry_entries[2] = {"t5_SubSyscd", "t5_Syscd"},
//    *qry_values[2] =  {"Project", "Code"};
//
//printf(("\n\n myAskLOVLengthMethod\n\n"));
//TAG_free(cntr_objects);
//
//IFERR_REPORT(QRY_find("ControlObjQry", &query));
//printf(("111111111111111111"));
//IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
//printf(("wwwwwwwww"));
//*length = n_found;
//printf(("\t n_values = %d\n", *length));
//*values = (char **)MEM_alloc (*length * sizeof(char*));
//memset( *values, 0,  *length * sizeof(char*));
//for (ii = 0; ii < n_found; ii++)
//{
//ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo1",&item_sequence_id));
//
//(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
//    strcpy((*values)[ii], item_sequence_id);
//}
//TAG_free(cntr_objects);
//TAG_free(item_sequence_id);
//
//return error_code;
//}

int myAskLOVValuesMethodP( METHOD_message_t *msg, va_list  args )
{
	/* va_list for LOV_ask_values_msg */
	tag_t	lov_tag		= va_arg(args, const tag_t);
	int*	n_values	= va_arg(args, int*);
	char	***values	= va_arg(args, char***);
	char *item_sequence_id = NULL;
	int status = 0;

	int	error_code	= ITK_ok,
		n_entries	= 2,
		n_found		= 0,
		ii			= 0;

	tag_t	 query			= NULLTAG,
			*cntr_objects	= NULLTAG,
			user			= NULLTAG;

	char
	*qry_entries[2] = {"Project ID","Active"},
	*qry_values[2]	= {"*","Y"};

	printf("\n myAskLOVValuesMethodP--TCDC**********create_dynamic_lov.c::myAskLOVValuesMethodP ");fflush(stdout);

	IFERR_REPORT(QRY_find("QueryProject", &query));
	printf("\n myAskLOVValuesMethodP--TCDCAfter IFERR_REPORT : QRY_find \n");fflush(stdout);

	if (query)
	{
		printf("\n myAskLOVValuesMethodP--TCDCFound Query");fflush(stdout);

		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));

		printf("\n myAskLOVValuesMethodP--TCDC**** %d", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVValuesMethodP--TCDC####### = %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"project_id",&item_sequence_id));

			(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
			strcpy((*values)[ii], item_sequence_id);
		}
		TAG_free(cntr_objects);
		if (item_sequence_id)
		{
			TAG_free(item_sequence_id);
		}
	}
	else
	{
		printf("\n myAskLOVValuesMethodP--QueryProject entry not found ?? ");fflush(stdout);
	}

	printf("\n myAskLOVValuesMethodP--Exiting function !!\n"); fflush(stdout);

	return error_code;
}

int myAskLOVValuesMethod( METHOD_message_t *msg, va_list  args )
{
	/* va_list for LOV_ask_values_msg */
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	char *item_sequence_id = NULL;
	int status;

	int error_code = ITK_ok,
		n_entries = 2,
		n_found = 0,
		ii = 0;

	tag_t	query = NULLTAG,
			*cntr_objects = NULLTAG,
			user = NULLTAG;

	char **qry_entries =  (char **) MEM_alloc(3 * sizeof(char *));
	char **qry_values =  (char **) MEM_alloc(3 * sizeof(char *));

	char *loggedinuser = NULL;
    ITK_CALL(POM_get_user_id (&loggedinuser));
    printf("\nLogged In User : %s",loggedinuser); fflush(stdout);

    if(tc_strcmp(loggedinuser,"infodba")==0 || tc_strcmp(loggedinuser,"loader")==0)
    {
    	qry_entries[0] = "SUBSYSCD";
    	qry_entries[1] = "SYSCD";
    	qry_values[0] = "*";
    	qry_values[1] = "MATCLS";
    	n_entries = 2;
    }
    else
    {
    	qry_entries[0] = "SUBSYSCD";
    	qry_entries[1] = "SYSCD";
    	qry_entries[2] = "Delete Indicator";
    	qry_values[0] = "*";
    	qry_values[1] = "MATCLS";
    	qry_values[2] = "FALSE";
    	n_entries = 3;
    }

	/*char *qry_entries[2] = {"SUBSYSCD", "SYSCD"},
		 *qry_values[2] =  {"*", "MATCLS"};*/

	printf("\n myAskLOVValuesMethod--create_dynamic_lov.c::myAskLOVValuesMethod ");fflush(stdout);

	//IFERR_REPORT(QRY_find("ControlObjQry", &query));
	IFERR_REPORT(QRY_find("Control Objects...", &query));
	if (query)
	{
		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n myAskLOVValuesMethod--n_found== %d", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVValuesMethod--n_values== %d ", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo4",&item_sequence_id));

			(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
			strcpy((*values)[ii], item_sequence_id);
		}
		TAG_free(cntr_objects);
		if (item_sequence_id)
		{
			TAG_free(item_sequence_id);
		}
	}
	else
	{
		printf("\n myAskLOVValuesMethodP--MATCLS entry not found ?? ");fflush(stdout);
	}

	printf("\n myAskLOVValuesMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}

//Rohit Start

int myAskLOVPartPlatformValuesMethod( METHOD_message_t *msg, va_list  args )
{
	/* va_list for LOV_ask_values_msg */
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_valuespp = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	char *item_sequence_idpp;
	int status;

	int error_code = ITK_ok,
	n_entriespp = 2,
	n_foundpp = 0,
	ip = 0;

	tag_t	queryPartPlatform = NULLTAG,
			*cntr_objectspp = NULLTAG,
			user = NULLTAG;

	char
	*qry_entriespp[2] = {"SUBSYSCD", "SYSCD"},
	*qry_valuespp[2] =  {"*", "PartPlatform"};

	printf("\n myAskLOVPartPlatformValuesMethod--TCDCcreate_dynamic_lov.c::myAskLOVPartPlatformValuesMethod ");fflush(stdout);

	IFERR_REPORT(QRY_find("ControlObjQry", &queryPartPlatform));
	if (queryPartPlatform)
	{
		IFERR_REPORT(QRY_execute(queryPartPlatform, n_entriespp, qry_entriespp, qry_valuespp, &n_foundpp, &cntr_objectspp));
		printf("\n myAskLOVPartPlatformValuesMethod--TCDC== %d", n_foundpp);fflush(stdout);

		*n_valuespp = n_foundpp;
		printf("\n myAskLOVPartPlatformValuesMethod--TCDC== %d\n", *n_valuespp);fflush(stdout);

		*values = (char **)MEM_alloc (*n_valuespp * sizeof(char*));
		memset( *values, 0,  *n_valuespp * sizeof(char*));

		for (ip = 0; ip < n_foundpp; ip++)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objectspp[ip],"t5_Userinfo1",&item_sequence_idpp));

			(*values)[ip] = (char *) MEM_alloc (strlen(item_sequence_idpp) + 1);
			strcpy((*values)[ip], item_sequence_idpp);
		}
		TAG_free(cntr_objectspp);
		TAG_free(item_sequence_idpp);
	}
	else
	{
		printf("\n myAskLOVPartPlatformValuesMethod--PartPlatform entry not found ?? ");fflush(stdout);
	}

	printf("\n myAskLOVPartPlatformValuesMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}
//Rohit End

int myAskLOVKeyWordValuesMethod( METHOD_message_t *msg, va_list  args )
{
	/* va_list for LOV_ask_values_msg */
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	char *item_sequence_id = NULL;
	int status = 0;

	int error_code = ITK_ok,
		n_entries = 2,
		n_found = 0,
		ii = 0;

	tag_t	query = NULLTAG,
			*cntr_objects = NULLTAG,
			user = NULLTAG;

	char
	//*qry_entries[2] = {"t5_SubSyscd", "t5_Syscd"},
	*qry_entries[2] = {"SUBSYSCD", "SYSCD"},
	*qry_values[2] =  {"*", "KwyWord"};

	printf("\n myAskLOVKeyWordValuesMethod--create_dynamic_lov.c------");fflush(stdout);

	IFERR_REPORT(QRY_find("KeyWordQry", &query));
	if (query)
	{
		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n myAskLOVKeyWordValuesMethod--TCDC== %d", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVKeyWordValuesMethod--TCDC== %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo1",&item_sequence_id));

			(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
			strcpy((*values)[ii], item_sequence_id);
		}
		TAG_free(cntr_objects);
		TAG_free(item_sequence_id);
	}
	else
	{
		printf("\n myAskLOVKeyWordValuesMethod--KwyWord entry not found ?? ");fflush(stdout);
	}

	printf("\n myAskLOVKeyWordValuesMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}

int myAskLOVStartPartValuesMethod( METHOD_message_t *msg, va_list  args )
{
	/* va_list for LOV_ask_values_msg */
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	char *item_sequence_id=NULL;
	char *userinfo_value=NULL;
	char *role_name=NULL;
	char *design_group_name=NULL;
	char *information1_value = NULL;
	char final_information1_value[20];

	int status = 0;

	int error_code = ITK_ok,
		n_entries = 2,
		m_entries = 3,
		n_found = 0,
		ii = 0;

	tag_t	query = NULLTAG,
			*cntr_objects = NULLTAG,
			user = NULLTAG,
			role_tag  = NULLTAG;

	char
		*qry_entries[2] = {"SYSCD", "SUBSYSCD"},
		*qry_values[2] = {"TOOLTYPE", "DESIGNGROUP"},
		*qry_m_entries[3] = {"SYSCD","SUBSYSCD","Information-1"},
		*qry_m_values[3];

	printf("\n myAskLOVStartPartValuesMethod--TCDCcreate_dynamic_lov.c------ ");fflush(stdout);

	//Find Current User Role
	IFERR_REPORT(SA_ask_current_role(&role_tag));

	if(role_tag != NULLTAG)
	{
		printf("\n myAskLOVStartPartValuesMethod--create_dynamic_lov.c::Role Tag Found");fflush(stdout);
		//Get Role Name
		IFERR_REPORT(SA_ask_role_name2(role_tag,&role_name));
	}
	else
	{
		role_name = "NA";
	}
	printf("\n myAskLOVStartPartValuesMethod--RoleName == %s ", role_name);

	design_group_name = tc_strtok(role_name,"_"); //60_Designers_Group
	printf("\n myAskLOVStartPartValuesMethod--design_group_name == %s ", design_group_name);fflush(stdout);

	//Rohit
	//if(tc_STRCMP(design_group_name,"CAB") = = 0)
	if (tc_strstr(design_group_name,"CAB") != NULL)
	{		
		printf("\nFor Setting StartPart Product for Cab Designers\n"); fflush(stdout);
		qry_m_values[0] = "STARTPART";
		qry_m_values[1] = "PRT";
		qry_m_values[2] = "*CATIA*";
		

		IFERR_REPORT(QRY_find("ControlObjQryStartPrt", &query));
		if (query)
		{
			IFERR_REPORT(QRY_execute(query, m_entries, qry_m_entries, qry_m_values, &n_found, &cntr_objects));
			printf("\n myAskLOVStartPartValuesMethod--TCDCSTARTPART for CAB_Designers == %d", n_found);fflush(stdout);

			*n_values = n_found;
			printf("\n myAskLOVStartPartValuesMethod--TCDC STARTPART for CAB_Designers == %d ", *n_values);fflush(stdout);

			*values = (char **)MEM_alloc (*n_values * sizeof(char*));
			memset( *values, 0,  *n_values * sizeof(char*));
			printf("\n myAskLOVStartPartValuesMethod--TCDC STARTPART for CAB_Designers == %d ", *n_values);fflush(stdout);

			for (ii = 0; ii < n_found; ii++)
			{
				printf("\n myAskLOVStartPartValuesMethod--After ii for CAB_Designers: [%d] \n",ii);fflush(stdout);

				ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo4",&item_sequence_id));
				printf("\n myAskLOVStartPartValuesMethod--After Userinfo4 for CAB_Designers: [%s]",item_sequence_id);fflush(stdout);

				(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
				strcpy((*values)[ii], item_sequence_id);
			}
		}
		if (cntr_objects != NULLTAG)
		{
			TAG_free(cntr_objects);
		}
		if (item_sequence_id)
		{
			TAG_free(item_sequence_id);
		}


		
	}
	else
	{

	

	//	design_group_name_int = atoi(design_group_name);
	//	printf("\n design_group_name_int == %s\n", design_group_name_int);

	//	if(design_group_name_int < 0 || design_group_name_int > 99)
	//	{
	//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
	//        *qry_values[2] =  {"*", "STARTPART","NA"};
	//	}
	//	else if(design_group_name_int == 54 || design_group_name_int == 16 || design_group_name_int > 59)
	//	{
	//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
	//        *qry_values[2] =  {"*", "STARTPART","CATIA"};
	//	}
	//	else if(design_group_name_int == 54 || design_group_name_int == 16 || design_group_name_int > 59)
	//	{
	//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
	//        *qry_values[2] =  {"*", "STARTPART","CATIA"};
	//	}
	//	else
	//	{
	//		*qry_entries[2] = {"SUBSYSCD", "SYSCD","Information-1"},
	//        *qry_values[2] =  {"*", "STARTPART","PROE"};
	//	}

	IFERR_REPORT(QRY_find("ControlObjFindCadToolBasedOnDesGrp", &query));
	if (query)
	{
		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	}
	printf("\n myAskLOVStartPartValuesMethod--Objects for Query ControlObjFindCadToolBasedOnDesGrp == %d", n_found);fflush(stdout);

	if(n_found == 1)
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&userinfo_value));
		if(tc_strstr(userinfo_value, design_group_name) != NULL)
		{
			information1_value = tc_strtok(userinfo_value,"_");
			//information1_value - PROE
		}

		if(information1_value == NULL)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&userinfo_value));
			if(tc_strstr(userinfo_value, design_group_name) != NULL)
			{
				information1_value = tc_strtok(userinfo_value,"_"); 
				//information1_value - CATIA
			}
		}

		if(information1_value == NULL)
		{
			ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo3",&userinfo_value));
			if(tc_strstr(userinfo_value, design_group_name) != NULL)
			{
				information1_value = tc_strtok(userinfo_value,"_");
			}
		}
	}

	printf("\n myAskLOVStartPartValuesMethod--information1_value == %s \n", information1_value);

	qry_m_values[0] = "STARTPART";
	qry_m_values[1] = "PRT";
	if(information1_value == NULL)
	{
		qry_m_values[2] = "NA";
	}
	else
	{
		tc_strcpy(final_information1_value,"*");
		tc_strcat(final_information1_value,information1_value);
		tc_strcat(final_information1_value,"*");
		printf("\n myAskLOVStartPartValuesMethod--final_information1_value -- %s", final_information1_value);fflush(stdout);
		qry_m_values[2] = final_information1_value;
	}

	IFERR_REPORT(QRY_find("ControlObjQryStartPrt", &query));
	if (query)
	{
		IFERR_REPORT(QRY_execute(query, m_entries, qry_m_entries, qry_m_values, &n_found, &cntr_objects));
		printf("\n myAskLOVStartPartValuesMethod--TCDCSTARTPART== %d", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVStartPartValuesMethod--TCDC STARTPART== %d ", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));
		printf("\n myAskLOVStartPartValuesMethod--TCDC STARTPART== %d ", *n_values);fflush(stdout);

		for (ii = 0; ii < n_found; ii++)
		{
			printf("\n myAskLOVStartPartValuesMethod--After ii: [%d] \n",ii);fflush(stdout);

			ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo4",&item_sequence_id));
			printf("\n myAskLOVStartPartValuesMethod--After Userinfo4: [%s]",item_sequence_id);fflush(stdout);

			(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
			strcpy((*values)[ii], item_sequence_id);
		}
	}
	if (cntr_objects != NULLTAG)
	{
		TAG_free(cntr_objects);
	}
	if (item_sequence_id)
	{
		TAG_free(item_sequence_id);
	}
	}

	printf("\n myAskLOVStartPartValuesMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}
//extern DLLAPI int t5_LOV_register_method(int *decision)
//{
//    int          ifail = ITK_ok;
//    METHOD_id_t  method;
//    METHOD_id_t  methodP;
//
//    *decision = ALL_CUSTOMIZATIONS;
//
//
//    //printf("\n Inside register message for dynamic value set \n");
//    printf("create_dynamic_lov.c:t5_LOV_register_method - ");
//
//    if( ifail == ITK_ok )
//    {
//        ifail = METHOD_register_method( "T5_MatlClsLOVType",
//            LOV_ask_values_msg,
//            &myAskLOVValuesMethod,  0,
//            &method);
//    }
//    //printf("\n  registered message for dynamic value set \n");
//
//	if( ifail == ITK_ok )
//    {
//        ifail = METHOD_register_method( "T5_ProjCodeLOVType",
//            LOV_ask_values_msg,
//            &myAskLOVValuesMethodP,  0,
//            &methodP);
//    }
//    printf(" registered message for dynamic value set \n");
//
////    if( ifail == ITK_ok )
////    {
////        ifail = METHOD_register_method( "T5_ProjCodeLOVType",
////            LOV_ask_num_of_values_msg,
////            &myAskLOVLengthMethod,  0,
////            &method);
////    }
////    printf("\n  register message for dynamic value set..... \n");
//
//    if( ifail != ITK_ok )
//    {
//        EMH_store_error( EMH_severity_error, ifail );
//    }
//
//    return ifail;
//}

//
//extern DLLAPI int t5_LOV_register_callbacks ()
//{
//    int ifail    = ITK_ok;
//    printf("\n create_dynamic_lov.c:before t5_LOV_register_callbacks");
//
//    ifail=CUSTOM_register_exit ( "t5_LOV", "USER_init_module", (CUSTOM_EXIT_ftn_t)  t5_LOV_register_method);
//    printf(" - after calling t5_LOV_register_callbacks");
//
//  return ( ITK_ok );
//}


int myAskModALOVValuesMethod( METHOD_message_t *msg, va_list  args )
{
    /* va_list for LOV_ask_values_msg */
    tag_t lov_tag  = va_arg(args, const tag_t);
    int*  n_values = va_arg(args, int*);
    char  ***values = va_arg(args, char***);
	char *item_sequence_id;
	int status;

    int error_code = ITK_ok,
        n_entries = 1,
        n_found = 0,
        ii = 0;

	tag_t
        query = NULLTAG,
        *cntr_objects = NULLTAG,
        user = NULLTAG;

	char
        *qry_entries[1] = {"Module Address"},
        *qry_values[1]	= {"*"};

	//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	//char *qry_entries[1] = {"Module Address"};

	printf("\nTCDCcreate_dynamic_lov.c :: myAskModALOVValuesMethod.......................\n");fflush(stdout);

    IFERR_REPORT(QRY_find("ModuleArchRlz", &query));
	printf("\n myAskModALOVValuesMethod--TCDC--ModuleArchRlz....\n");fflush(stdout);

	if (query)
	{
		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n myAskModALOVValuesMethod--TCDC --> ModuleArchRlz :: %d", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskModALOVValuesMethod--TCDC== %d\n", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL(AOM_ask_value_string(cntr_objects[ii],"t5_ArchModuleAddress",&item_sequence_id));

			(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
			strcpy((*values)[ii], item_sequence_id);
		}

		TAG_free(cntr_objects);
		TAG_free(item_sequence_id);
	}
	else
	{
		printf("\n myAskModALOVValuesMethod--ModuleArchRlz entry not found ?? ");fflush(stdout);
	}

	printf("\n myAskModALOVValuesMethod--Exiting function !!\n"); fflush(stdout);

    return error_code;
}
/*************************************************************************
Aashish_w --> Part category LOV in TCUA Starts
*************************************************************************/
int T5_PartCategoryLOVMethod( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);

	char *item_sequence_id = NULL;
	char *Classi_class = NULL;
	char *objTypeTagk = NULL;
	char *DesignGrp = NULL;
	char *userId = NULL;
	char *parent_name = NULL;
	char *class_name = NULL;
	char *type_wso_name = NULL;
	char *user_name_string = NULL;

	char roleName[SA_name_size_c+1]  ;

	int status = 0;

	tag_t item_tag = NULLTAG;
	tag_t relns = NULLTAG, *relns1 = NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;

	WSO_description_t desc;

	int error_code = ITK_ok;
	int n_entries = 2,k=0,j=0;
	int n_entries1=2;
	int n_found = 0;
	int n_found1=0;
	int i = 0,n_relns,n_relns1=0;
	int TotalLovCount = 0;
	int iMyLovCounter = 0;
	
	tag_t query = NULLTAG, query1=NULLTAG, *cntr_objects = NULLTAG, *cntr_objects1 = NULLTAG, user = NULLTAG;
	/*tag_t type_tag = NULLTAG;
	tag_t * new_form = NULLTAG;
	tag_t objTypeTag2 = NULLTAG;
	tag_t *relation = NULLTAG;
	tag_t item_tag1 = NULLTAG;
	tag_t tRole_name =NULLTAG;
	tag_t person_tag=NULLTAG;
	tag_t user_tag=NULLTAG;*/

	/*char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));*/

	char **qry_entries =  (char **) MEM_alloc(3 * sizeof(char *));
	char **qry_values =  (char **) MEM_alloc(3 * sizeof(char *));
	char *loggedinuser = NULL;
    ITK_CALL(POM_get_user_id (&loggedinuser));
    printf("\nLogged In User : %s",loggedinuser); fflush(stdout);

    if(tc_strcmp(loggedinuser,"infodba")==0 || tc_strcmp(loggedinuser,"loader")==0)
    {
    	qry_entries[0] = "SUBSYSCD";
    	qry_entries[1] = "SYSCD";
    	qry_values[0] = "PRTCAT";
    	qry_values[1] = "PRTCAT";
    	n_entries = 2;
    }
    else
    {
    	qry_entries[0] = "SUBSYSCD";
    	qry_entries[1] = "SYSCD";
    	qry_entries[2] = "Delete Indicator";
    	qry_values[0] = "PRTCAT";
    	qry_values[1] = "PRTCAT";
    	qry_values[2] = "FALSE";
    	n_entries = 3;
    }

	//METHOD_PROP_MESSAGE_OBJECT( msg, item_tag );

	printf("\n Inside T5_PartCategoryLOVMethod Function ----- ");fflush(stdout);

	if(QRY_find("Control Objects...", &query));
	if (query)
	{
		/*qry_values[0] = "PRTCAT" ;
		qry_values[1] = "PRTCAT" ;*/

		if(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n T5_PartCategoryLOVMethod--Keyword n_found: %d ", n_found);fflush(stdout);

		*n_values = n_found;
		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		if(n_found>0)
		{
			for (i = 0; i < n_found; i++)
			{
				ITK_CALL( AOM_ask_value_string(cntr_objects[i],"object_name",&Classi_class));

				printf("\n T5_PartCategoryLOVMethod--current name -------> %s ",Classi_class);fflush(stdout);

				(*values)[iMyLovCounter] = (char *) MEM_alloc (strlen(Classi_class) + 1);
				tc_strcpy((*values)[iMyLovCounter], Classi_class);
				
				printf("\n T5_PartCategoryLOVMethod--part category i=%d (*values)[%d]:%s",i,iMyLovCounter, (*values)[iMyLovCounter]);fflush(stdout);
				
				iMyLovCounter = iMyLovCounter + 1;
			}
			TAG_free(cntr_objects);
		}
		else
		{
			printf("\n myAskModALOVValuesMethod--PRTCAT entry not found ?? ");fflush(stdout);
		}
	}
	else
	{
		printf("\n myAskModALOVValuesMethod--Query not found ?? ");fflush(stdout);
	}

	printf("\n T5_PartCategoryLOVMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}
/**************************** Aashish_w --> Part category LOV in TCUA END ********************************/
/*************************************************************************
To fetch Keyword Description from classification in LOV
*************************************************************************/
int t5_LOVKeyWordDescValuesMethod( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);

	char *item_sequence_id = NULL;
	char *Classi_class = NULL;
	char *objTypeTagk = NULL;
	char *DesignGrp = NULL;
	char *userId = NULL;
	char *parent_name = NULL;
	char *class_name = NULL;
	char *type_wso_name = NULL;
	char * user_name_string = NULL;

	char roleName[SA_name_size_c+1]  ;

	WSO_description_t desc;

	int status = 0;
	int error_code = ITK_ok;
	int n_entries = 2,k=0,j=0;
	int n_entries1=2;
	int n_found = 0;
	int n_found1=0;
	int ii = 0,n_relns,n_relns1=0;
	int TotalLovCount = 0;
	int iMyLovCounter = 0;

	tag_t item_tag = NULLTAG;
	tag_t relns = NULLTAG, *relns1 = NULLTAG;
	tag_t CurrentRoleTag = NULLTAG;
	tag_t query = NULLTAG, query1=NULLTAG, *cntr_objects = NULLTAG, *cntr_objects1 = NULLTAG, user = NULLTAG;
	tag_t type_tag = NULLTAG;
	tag_t * new_form = NULLTAG;
	tag_t objTypeTag2 = NULLTAG;
	tag_t *relation = NULLTAG;
	tag_t item_tag1 = NULLTAG;
	tag_t tRole_name =NULLTAG;
	tag_t person_tag=NULLTAG;
	tag_t user_tag=NULLTAG;

	//Start mbb
	int		QryEntryCnt			=	1;
	int		CntlObjCnt1			=	0;
	int		CntlObjCnt2			=	0;
	char	*QryEntry[1]		=	{"SYSCD"};
	char	*D_Roll				=	NULL;
	tag_t	KeyCtrObjQry		=	NULLTAG;
	tag_t	*CntObj_Tag1		=	NULLTAG;
	tag_t	*CntObj_Tag2		=	NULLTAG;
	char	**QryValue1			=	(char **) MEM_alloc(10 * sizeof(char *));
	char	**QryValue2			=	(char **) MEM_alloc(10 * sizeof(char *));
	//End mbb

	char *qry_entries[2] = {"Name","ext_1"};
	char *qry_entries1[2]={"role_name1","Name"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n t5_LOVKeyWordDescValuesMethod--Keyword description Lov Staing--------------"); fflush(stdout);

	METHOD_PROP_MESSAGE_OBJECT( msg, item_tag );

	ITK_CALL(POM_get_user_id(&userId));
	printf("\n t5_LOVKeyWordDescValuesMethod--after POM_get_user_id: [%s] \n",userId);fflush(stdout);
	
	ITK_CALL( POM_get_user(&user_name_string,&user_tag));
	printf("\n t5_LOVKeyWordDescValuesMethod--after POM_get_user: [%s] \n",user_name_string);fflush(stdout);

	ITK_CALL(SA_ask_current_role(&CurrentRoleTag));
	ITK_CALL(SA_ask_role_name(CurrentRoleTag,roleName));

	printf("\n t5_LOVKeyWordDescValuesMethod--after SA_ask_role_name: [%s] ",roleName);fflush(stdout);

	//Start mbb
	if(QRY_find("ControlObjects", &KeyCtrObjQry));
	if (KeyCtrObjQry)
	{
		printf("\n t5_LOVKeyWordDescValuesMethod--KeyCtrObjQry query Found \n");fflush(stdout);
		
		QryValue1[0] = "KeyCtrOld" ;
		QryValue2[0] = "KeyCtrNew" ;

		if(QRY_execute(KeyCtrObjQry, QryEntryCnt, QryEntry, QryValue1, &CntlObjCnt1, &CntObj_Tag1));
		if(QRY_execute(KeyCtrObjQry, QryEntryCnt, QryEntry, QryValue2, &CntlObjCnt2, &CntObj_Tag2));
	}
	else
	{
		printf("\n KeyCtrObjQry query Not Found \n");fflush(stdout);
	}

	printf("\n KeyCtrOld count = [%d] And KeyCtrNew count = [%d] = \n",CntlObjCnt1,CntlObjCnt2);fflush(stdout);

	if(CntlObjCnt1>0)
	{
		qry_values1[0]="*";
		qry_values1[1]=user_name_string;

		IFERR_REPORT(QRY_find("QryKyWrd_iUnme_oRole", &query1));
		printf("\n t5_LOVKeyWordDescValuesMethod--A.Keyword12345-- ");fflush(stdout);

		IFERR_REPORT(QRY_execute(query1, n_entries1, qry_entries1, qry_values1, &n_found1, &cntr_objects1));
		printf("\n t5_LOVKeyWordDescValuesMethod--A.Keyword54321= %d", n_found1);fflush(stdout);
		TotalLovCount = 0;
		if(n_found1>0)
		{
			printf("\n t5_LOVKeyWordDescValuesMethod--A.after for loop n_found: %d",n_found);
			
			for (j=0;j<n_found1;j++ )
			{
				//printf("\n Entered Loop \n");fflush(stdout);
				tRole_name = NULLTAG;
				char cRoleName[SA_name_size_c+1]  ;

				// printf("\n t5_LOVKeyWordDescValuesMethod--A.Before getting tag \n");fflush(stdout);
				item_tag1 = cntr_objects1[j];
				// printf("\n t5_LOVKeyWordDescValuesMethod--A.Before call: \n");fflush(stdout);
				ITK_CALL(SA_ask_groupmember_role(item_tag1,&tRole_name));
				ITK_CALL(SA_ask_role_name(tRole_name,cRoleName));
				printf("\n t5_LOVKeyWordDescValuesMethod--A.First For Loop:%s \n",cRoleName);fflush(stdout);


				ITK_CALL(AOM_ask_value_string(item_tag1,"object_name",&parent_name));
				printf("\n t5_LOVKeyWordDescValuesMethod--A.parent_name: [%s].......",parent_name);fflush(stdout);
				
				if(tc_strstr(parent_name, "dba"))
					continue;

				if(tc_strstr(parent_name,"ERC_Designers_Group")==NULL && tc_strstr(parent_name,"APL")==NULL)
				{
					continue;
				}

				printf("\n t5_LOVKeyWordDescValuesMethod--A.before1 allocate DesignGrp mem");fflush(stdout);
				DesignGrp = (char *) MEM_alloc(3 * sizeof(char ));
				printf("\n t5_LOVKeyWordDescValuesMethod--A.after1 allocate DesignGrp mem parent_name:%s",parent_name);fflush(stdout);

				if(tc_strstr(cRoleName,"APL")!=NULL)
				{
					DesignGrp[0]=cRoleName[0];
					DesignGrp[1]=cRoleName[1];
					DesignGrp[2]='\0';
				}
				else
				{
					DesignGrp[0]=parent_name[20];
					DesignGrp[1]=parent_name[21];
					DesignGrp[2]='\0';
				}

				printf("\n t5_LOVKeyWordDescValuesMethod--A.DesignGrp:%s ..............",DesignGrp);fflush(stdout);

				qry_values[0] = "*" ;
				qry_values[1] = DesignGrp;

				IFERR_REPORT(QRY_find("KeyWordQryforDR", &query));
				if (query)
				{
					IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
				}

				TotalLovCount = TotalLovCount + n_found;
			}
			printf("\n t5_LOVKeyWordDescValuesMethod--A.TotalLovCount:%d",TotalLovCount);fflush(stdout);


			iMyLovCounter = 0;

			if( TotalLovCount > 0 )
			{
				*n_values = TotalLovCount;

				*values = (char **)MEM_alloc (*n_values * sizeof(char*));
				memset( *values, 0,  *n_values * sizeof(char*));

				for (j=0;j<n_found1;j++ )
				{
					tRole_name=NULLTAG;
					char cRoleName[SA_name_size_c+1]  ;

					item_tag1 = cntr_objects1[j];

					ITK_CALL(SA_ask_groupmember_role(item_tag1,&tRole_name));
					ITK_CALL(SA_ask_role_name(tRole_name,cRoleName));
					printf("\n t5_LOVKeyWordDescValuesMethod--AB.Second For Loop: [%s] ",cRoleName);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(item_tag1,"object_name",&parent_name));
					printf("\n t5_LOVKeyWordDescValuesMethod--AB.parent_name: [%s]........",parent_name);fflush(stdout);
					
					if(tc_strstr(parent_name, "dba" ))
					{
						printf("\t continued-A..............");fflush(stdout);
						continue;
					}

					if(tc_strstr(parent_name,"ERC_Designers_Group")==NULL && tc_strstr(parent_name,"APL")==NULL)
					{
						printf("\t continued-B..............");fflush(stdout);
						continue;
					}
					
					printf("\n t5_LOVKeyWordDescValuesMethod--AB.before2 allocate DesignGrp mem");fflush(stdout);
					DesignGrp = (char *) MEM_alloc(3 * sizeof(char ));
					printf("\n t5_LOVKeyWordDescValuesMethod--AB.after2 allocate DesignGrp mem");fflush(stdout);

					if(tc_strstr(cRoleName,"APL")!=NULL)
					{
						DesignGrp[0]=cRoleName[0];
						DesignGrp[1]=cRoleName[1];
						DesignGrp[2]='\0';
					}
					else
					{
						DesignGrp[0]=parent_name[20];
						DesignGrp[1]=parent_name[21];
						DesignGrp[2]='\0';
					}

					//DesignGrp[0]=parent_name[20];
					//DesignGrp[1]=parent_name[21];
					//DesignGrp[2]='\0';


					printf("\n t5_LOVKeyWordDescValuesMethod--AB.DesignGrp:%s ..............",DesignGrp);fflush(stdout);
					
					qry_values[0] = "*" ;
					qry_values[1] = DesignGrp;

					IFERR_REPORT(QRY_find("KeyWordQryforDR", &query));
					if (query)
					{
						IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
					}
					printf("\n t5_LOVKeyWordDescValuesMethod--AB.Keyword n_found:%d", n_found);fflush(stdout);

					if(n_found>0)
					{
						printf("\n t5_LOVKeyWordDescValuesMethod--AB.Keyword *n_values: %d\n", *n_values);fflush(stdout);
						printf("\n t5_LOVKeyWordDescValuesMethod--AB.Fetching classified keyword values. Please wait...\n");fflush(stdout);

						for (ii = 0; ii < n_found; ii++)
						{
							ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"name",&Classi_class));

							(*values)[iMyLovCounter] = (char *) MEM_alloc (strlen(Classi_class) + 1);
							strcpy((*values)[iMyLovCounter], Classi_class);
							//printf("\nKeyword ii=%d (*values)[%d]:%s",ii,iMyLovCounter, (*values)[iMyLovCounter]);fflush(stdout);
							iMyLovCounter = iMyLovCounter + 1;
						}
						TAG_free(cntr_objects);
					}
				}
			}
			printf("\n t5_LOVKeyWordDescValuesMethod--A.Test1");	fflush(stdout);
		}
	}
	else if (CntlObjCnt2>0)
	{
		printf("\n t5_LOVKeyWordDescValuesMethod--B.Inside else if \n");fflush(stdout);

		ITK_CALL(SA_ask_role_name2(CurrentRoleTag,&D_Roll));

		printf("\n t5_LOVKeyWordDescValuesMethod--B.after SA_ask_role_name2:%s \n",D_Roll);fflush(stdout);

		//printf("\n roleName:%s ..............",roleName);fflush(stdout);
		//tc_strcpy(D_Roll,roleName);
		//printf("\n D_Roll:%s ..............",D_Roll);fflush(stdout);

		DesignGrp = (char *) MEM_alloc(3 * sizeof(char ));

		DesignGrp[0]=D_Roll[0];
		DesignGrp[1]=D_Roll[1];
		DesignGrp[2]='\0';

		printf("\n t5_LOVKeyWordDescValuesMethod--B.DesignGrp: [%s]...........",DesignGrp);fflush(stdout);

		qry_values[0] = "*" ;
		qry_values[1] = DesignGrp;

		IFERR_REPORT(QRY_find("KeyWordQryforDR", &query));
		IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));

		if(n_found>0)
		{
			*n_values = n_found;

			*values = (char **)MEM_alloc (*n_values * sizeof(char*));
			memset( *values, 0,  *n_values * sizeof(char*));

			printf("\n t5_LOVKeyWordDescValuesMethod--B.Keyword *n_values: %d ", *n_values);fflush(stdout);
			printf("\n t5_LOVKeyWordDescValuesMethod--B.Fetching classified keyword values. Please wait...");fflush(stdout);

			for (ii = 0; ii < n_found; ii++)
			{
				ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"name",&Classi_class));

				(*values)[iMyLovCounter] = (char *) MEM_alloc (strlen(Classi_class) + 1);
				strcpy((*values)[iMyLovCounter], Classi_class);
				//printf("\n t5_LOVKeyWordDescValuesMethod--B.Keyword ii=%d (*values)[%d]:%s",ii,iMyLovCounter, (*values)[iMyLovCounter]);fflush(stdout);
				iMyLovCounter = iMyLovCounter + 1;
			}
			TAG_free(cntr_objects);
		}

		printf("\n t5_LOVKeyWordDescValuesMethod--B.Test1_new ");	fflush(stdout);
	}
	else
	{
		printf("\n t5_LOVKeyWordDescValuesMethod--No control object found \n");fflush(stdout);
	}
	//End mbb

	printf("\n t5_LOVKeyWordDescValuesMethod--Exiting function !!\n"); fflush(stdout);

	return error_code;
}
/****************************VendorId LOV 18.08.2018********************************/
int myAskLOVValuesVendorId( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag		= va_arg(args, const tag_t);
    int* n_values	= va_arg(args, int*);
    char ***values	= va_arg(args, char***);
	char *vendor_id;
	int status;

    int error_code	= ITK_ok,
        n_entries	= 1,
        n_found		= 0,
        ii			= 0;
    tag_t
        query			= NULLTAG,
        *cntr_objects	= NULLTAG,
        user			= NULLTAG;

    char
        *qry_entries[1] = {"Name"},
        *qry_values[1]	= {"*"};

    printf("\n myAskLOVValuesVendorId--create_dynamic_lov.c::VendorId ------");fflush(stdout);

    ITK_CALL(QRY_find("VendorIdQry", &query));
	if (query)
	{
		printf("\n myAskLOVValuesVendorId--Found Query VendorIdQry");fflush(stdout);

		ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n myAskLOVValuesVendorId--No. of object found by query VendorIdQry: [%d] ", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVValuesVendorId--No. of object found by query VendorIdQry: [%d] ", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL(AOM_ask_value_string(cntr_objects[ii],"item_id",&vendor_id));

			(*values)[ii] = (char *) MEM_alloc (strlen(vendor_id) + 1);
			strcpy((*values)[ii], vendor_id);
		}
		TAG_free(cntr_objects);
		TAG_free(vendor_id);
	}
	else
	{
		printf("\n myAskLOVValuesVendorId--Not Found Query VendorIdQry");fflush(stdout);
	}

	printf("\n myAskLOVForSupplierList--Exiting function !!\n"); fflush(stdout);

    return error_code;
}
/****************************VendorId LOV 18.08.2018********************************/

/****************************Dynamic Supplier LOV  process by Rajesh on 24062019********************************/
int myAskLOVForSupplierList( METHOD_message_t *msg, va_list  args )
{
    tag_t lov_tag   = va_arg(args, const tag_t);
    int* n_values	= va_arg(args, int*);
    char ***values	= va_arg(args, char***);
	
	char *vendor_id = NULL;
	char *vendor_name = NULL;
	char *RetVendorName= NULL;
	int status=0;
    int error_code	= ITK_ok,
        n_entries	= 1,
        n_found		= 0,
        ii			= 0;
    
	tag_t
        query			= NULLTAG,
        *cntr_objects	= NULLTAG,
        user			= NULLTAG;
    
	char *qry_entries[1] = {"Name"}, *qry_values[1]	= {"*"};

    printf("\n myAskLOVForSupplierList--vendor id cmcreate_dynamic_lov.c::myAskLOVValuesVendorId ");fflush(stdout);

    ITK_CALL(QRY_find("VendorIdQry", &query));
	if (query)
	{
		printf("\n myAskLOVForSupplierList--Inside myAskLOVForSupplierList Found Query VendorIdQry");fflush(stdout);

		ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
		printf("\n myAskLOVForSupplierList--Inside myAskLOVForSupplierList No of object found by query VendorIdQry: %d ", n_found);fflush(stdout);

		*n_values = n_found;
		printf("\n myAskLOVForSupplierList--Inside myAskLOVForSupplierList No of object found by query VendorIdQry: [%d] ", *n_values);fflush(stdout);

		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));

		for (ii = 0; ii < n_found; ii++)
		{
			ITK_CALL(AOM_ask_value_string(cntr_objects[ii],"item_id",&vendor_id));
			ITK_CALL(AOM_ask_value_string(cntr_objects[ii],"object_name",&vendor_name));
			
			RetVendorName= (char *) MEM_alloc (strlen(vendor_id) + strlen(vendor_name) +1);
			
			strcpy(RetVendorName, vendor_id);
			strcat(RetVendorName, ":");
			strcat(RetVendorName, vendor_name);
			
			printf("\n myAskLOVForSupplierList--Final RetVendorName: [%s] ", RetVendorName);fflush(stdout);
			
			(*values)[ii] = (char *) MEM_alloc (strlen(RetVendorName) + 1);
			//strcpy((*values)[ii], vendor_id);
			strcpy((*values)[ii], RetVendorName);
		}
		TAG_free(cntr_objects);
		TAG_free(vendor_id);
	}
	else
	{
		printf("\n myAskLOVForSupplierList--VendorIdQry Not Found Query ?? ");fflush(stdout);
	}

	printf("\n myAskLOVForSupplierList--Exiting function !!\n"); fflush(stdout);

    return error_code;
}
/****************************End Dynamic Supplier LOV  process by Rajesh on 24062019********************************/
/*************************************************************************
To fetch DML Reason from Control Objects in LOV
*************************************************************************/
/*
int t5_LOVDMLReasonValuesMethod( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	char *item_sequence_id = NULL;
	int status=0;
	int error_code = ITK_ok,
		n_entries = 1,
		n_found = 0,
		ii = 0;
	tag_t query = NULLTAG,
		  *cntr_objects = NULLTAG,
		  user = NULLTAG;
	char *qry_entries[1] = {"SYSCD"}, *qry_values[1] =  {"DMLReason"};

	printf("\n create_dynamic_lov.c::t5_LOVDMLReasonValuesMethod ");fflush(stdout);

	IFERR_REPORT(QRY_find("Control Objects...", &query));
	IFERR_REPORT(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\nTCDC%d", n_found);fflush(stdout);

	*n_values = n_found;
	printf("\nTCDC== %d\n", *n_values);fflush(stdout);

	*values = (char **)MEM_alloc (*n_values * sizeof(char*));
	memset( *values, 0,  *n_values * sizeof(char*));

	for (ii = 0; ii < n_found; ii++)
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[ii],"t5_Userinfo3",&item_sequence_id));
		(*values)[ii] = (char *) MEM_alloc (strlen(item_sequence_id) + 1);
		strcpy((*values)[ii], item_sequence_id);
	}
	TAG_free(cntr_objects);
	TAG_free(item_sequence_id);

	return error_code;
}
int t5_LOVDMLReasonValuesMethod( METHOD_message_t *msg, va_list  args )
{
    //va_list for LOV_ask_values_msg
	logical active = TRUE;
	tag_t lov_tag = va_arg (args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);
	int   ifail = ITK_ok, ii = 0;
	char** LR_LovValue;
	int Lov_cnt=0;
	printf("\n inside t5_LOVDMLReasonValuesMethod method");fflush(stdout);
	*n_values=dynamic_dmlreason_LOV(&LR_LovValue);
	printf("\n t5_LOVDMLReasonValuesMethod==>[%d]",*n_values);fflush(stdout);
	*values = (char **) MEM_alloc (*n_values * sizeof (char*));
	//printf("\n memory allocated for *values" );fflush(stdout);
	memset (*values, 0,  *n_values * sizeof(char*));
	// printf("\n memset memory allocated for *values with *n_values size[%d]",*n_values );fflush(stdout);
	for (ii = 0; ii < *n_values; ii++)
	{
		//printf("\n inside loop to new memory allocated for *values" );fflush(stdout);
		(*values)[ii] = (char *) MEM_alloc (strlen(LR_LovValue[ii]) + 1);
		//printf("\n after new memory allocated for *values" );fflush(stdout);
		tc_strcpy ((*values)[ii], LR_LovValue[ii]);
		//printf("\n after dynamic lov copied to *values" );fflush(stdout);
	}
    printf("\n End of func t5_LOVDMLReasonValuesMethod with ifail val[%d]",ifail );fflush(stdout);
    return ifail;
}
*/

/****************************************************************************
Function:       dynamic_dmlreasonLov_LengthsMethod
Description:    dynamic_dmlreasonLov_LengthsMethod
Input:          None
Output:         None
Return value:   None
****************************************************************************/
/*
int dynamic_dmlreasonLov_LengthsMethod( METHOD_message_t *msg, va_list  args )
{
    //va_list for LOV_ask_num_of_values_msg
    tag_t lov_tag = va_arg (args, const tag_t);
    int *length = va_arg(args, int*);
    char  **VerLovValue=NULL;
    int ifail = ITK_ok;
	printf("\n 	");fflush(stdout);
	*length=dynamic_dmlreason_LOV(&VerLovValue);
	printf("\n dynamic_dmlreasonLov_LengthsMethod===>[%d]",*length);fflush(stdout);
    return ifail;
}
*/
/* ***************************************************************************
Function:       dynamic_dmlreason_LOV
Description:    dynamic_dmlreason_LOV
Input:          None
Output:         None
Return value:   None
*************************************************************************** */
/*
int dynamic_dmlreason_LOV( char*** VerLovValue  )
{
	//va_list for LOV_ask_values_msg
	
	char *user_name_string = NULL;
	int status;
	int j =0;
	tag_t* list_of_WSO_cntrl_tags=NULLTAG;
	char ***values = NULL;
	int control_number_found;
	WSO_search_criteria_t  	criteria_control;
	int ifail = ITK_ok;
	int max_char_size = 50;
	char *rolename=NULL;
	char *Version=NULL;;
	char *Version3=NULL;
	char *subSyscd=NULL;
	rolename =  MEM_alloc(100);
	Version =	  MEM_alloc(50000);
	tag_t  user = NULLTAG;
	char *VersionDup = (char *)MEM_alloc(max_char_size * strlen(Version)+1);
	char *vers = (char *)MEM_alloc(max_char_size * strlen(Version)+1);
	int Lov_cnt=0;

	printf("\n inside func dynamic_dmlreason_LOV");fflush(stdout);

	SA_init_module();
	printf("\n SA_init_module");fflush(stdout);
	POM_get_user(&user_name_string, &user);
	printf("\n POM_get_user");fflush(stdout);
	tag_t  CurrentRoleTag = NULLTAG;
	char roleName[SA_name_size_c+1]  ;
	SA_ask_current_role(&CurrentRoleTag);
	SA_ask_role_name(CurrentRoleTag,roleName);
	printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	//func start t5GetVersionList by rajesh
	WSOM_clear_search_criteria(&criteria_control);
	strcpy(criteria_control.name,"DMLReason*");
	strcpy(criteria_control.class_name,"T5_ControlObject");
	status	= WSOM_search(criteria_control, &control_number_found, &list_of_WSO_cntrl_tags);
	printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);
	for(j=0;j<control_number_found;j++)
	{
		AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_SubSyscd", &subSyscd);
		printf("\n subSyscd: %s\n",subSyscd);fflush(stdout);
		if(strcmp(subSyscd,"PVBU")==0)
		{
			printf("\n j++++++++++++++++++[%d]\n",j);fflush(stdout);
			AOM_ask_value_string( list_of_WSO_cntrl_tags[j], "t5_Userinfo3", &Version3);
			printf("\n Version3=%s\n",Version3);fflush(stdout);
			setAddStr(&Lov_cnt,VerLovValue,Version3);
		}
	}
	return Lov_cnt;
}
*/
