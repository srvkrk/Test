. /user/testcmi/.bash_profile
cd /user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPostapprovalmail/
echo "Sendmail Script Called for IRCDeviationPostapprovalmail"
echo "file path $1"
echo "From $2"
echo "To $3"
cat $1 | /usr/sbin/sendmail -f "$2" -t "$3"

