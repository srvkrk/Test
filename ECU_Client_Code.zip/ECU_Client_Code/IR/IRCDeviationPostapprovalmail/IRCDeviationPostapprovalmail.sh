echo "IR IRCDeviationPostapprovalmail Script Called"
cd /user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPostapprovalmail/
/home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable IRCDeviationPostapprovalmail
/user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPostapprovalmail/IRCDeviationPostapprovalmail -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -SM="$1" -R="$2" -id="$3"
