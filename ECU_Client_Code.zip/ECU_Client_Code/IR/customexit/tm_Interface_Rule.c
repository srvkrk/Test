/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_Interface_Rule.c
**
**
**	Date				Author			Modification
**	03-06-2024			Akshay Toke	    Code creation
* 
* SrNo		Modified By		Date			Modification
*	1		Akshay Toke 	03 Jun 2024		set dynamic participant for Interface Rule task

***********************************************************************************************************************************************************/

#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <pom/pom/pom.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#define PS_where_used_all_levels   -1 
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/****************************************************************************
*   Function name			: IRC_Data_Assign_participant_Func
*   Description				: To set dynamic participant for Interface Rule task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Akshay Toke	 set dynamic participant for Interface Rule task
*
****************************************************************************/
int IRC_Assign_participant_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
    char	*chklistdataNo			=  NULL;
	char	*DMLType		=  NULL;	
	char	*chklistdatarev		=  NULL;	
	tag_t	objTypTag		= NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	char    *qry_entry[1]  = {"SYSCD"};
	int     n_entry    = 1; 
	int     rsltCount      =  0; 
	tag_t   *CntrlObjectTag      = NULLTAG;
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char   ObjTyp[TCTYPE_name_size_c+1];
	char command[512];
	int error_code = ITK_ok;
	char* user_id =NULL;

   char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
   qry_values2[0] = "IRC";


    POM_get_user_id (&user_id);
	
	printf("\n IRC: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n IRC:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&chklistdataNo)!=ITK_ok)PrintErrorStack();

	printf("\n chklistdata Number: [%s].", chklistdataNo);fflush(stdout);
   if(AOM_ask_value_string(attachment[0],"item_revision_id",&chklistdatarev)!=ITK_ok)PrintErrorStack();
   printf("\n chklistdata Rev: [%s].", chklistdatarev);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name(objTypTag,ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);




			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
			}

			
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
				printf("\n info1 is.:[%s]\n", info1);fflush(stdout);

			/*	if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
				printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
				printf("\n info3 is.:[%s]\n", info3);fflush(stdout);*/


				   printf("\n %s:Exe logic to set reviewer start...\n",chklistdataNo);fflush(stdout);
                    char    *strg = NULL;
				    strg = malloc(1500);
					char *tempRevID = NULL;
					char *Shell_Path  = NULL;
					char command[1000];
				  

					tc_strcpy(strg,"");				
					tc_strcat(strg,stripBlanks(chklistdataNo));
					tc_strcat(strg," ");	
					ITK_CALL(STRNG_replace_str(chklistdatarev,";","_",&tempRevID));
					printf("\n After STRNG_replace_str tempRev ID %s \n",tempRevID);
					tc_strcat(strg,stripBlanks(tempRevID));
				
					
					sprintf(command,"%s %s %s",info1,strg,user_id);
					TC_write_syslog("Command = %s\n",command);
					printf("\n command to Run %s \n",command);
					system(command);
					printf("\n IRC:Reviewers set successfully.. \n");fflush(stdout);
			}
			
					

	return error_code;
}




extern int Interface_Rule_register_method(int *decision, va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	

	printf("\n before .... ");fflush(stdout);

	status = EPM_register_action_handler ("IRC_Assign_participant","IRC_Assign_participant",(EPM_action_handler_t)IRC_Assign_participant_Func);

	printf("\n after ..... ");fflush(stdout);
	return status;
}

extern DLLAPI int tm_Interface_Rule_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n\n before calling ..\n");
    ifail=CUSTOM_register_exit("tm_Interface_Rule","USER_init_module",(CUSTOM_EXIT_ftn_t)Interface_Rule_register_method);
	printf("\n\n after calling ...\n");
	
    return ( ITK_ok );
}


