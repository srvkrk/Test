//gsoap ns service name:				 Cre_IR_Checklist
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:Cre_IR_Checklis
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/Cre_IR_Checklist.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:Cre_IR_Checklist
//gsoap ns service method-documentation: Module name web service

int ns__Cre_IR_Checklist( char *module_no, char *DesignRuleID, char *status,char *Remark,char **return_);
