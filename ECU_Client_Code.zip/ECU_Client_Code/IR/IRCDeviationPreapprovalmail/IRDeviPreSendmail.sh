. /user/testcmi/.bash_profile
cd /user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/
echo "Sendmail Script Called for IRCDeviationPreapprovalmail"
echo "file path $1"
echo "From $2"
echo "To $3"
cat $1 | /usr/sbin/sendmail -f "$2" -t "$3"
