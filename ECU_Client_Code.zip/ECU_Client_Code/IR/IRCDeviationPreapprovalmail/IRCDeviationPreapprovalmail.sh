echo "IR IRCDeviationPreapprovalmail Script Called"
cd /user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/
/home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable IRCDeviationPreapprovalmail
/user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/IRCDeviationPreapprovalmail -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -SM="$1" -R="$2" -id="$3"

