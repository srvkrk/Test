#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <sa/user.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <epm/releasestatus.h>
#include <ss/ss_errors.h>
#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define PROP_set_value_string_msg   "PROP_set_value_string"

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE            *output                         = NULL;
int                     ifail                           = ITK_ok;
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              printf ("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
static void initialise (void);
int Mail_Notification(char*,char*,char*);
int read_value_from_file(char*,char*,char*);
void print_requirement()
{
        printf(
        "\nHELP:\n"
        "parameter_creation -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
        "-------------------------------------------------------------------------------------------\n\n"
        );
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
                                        It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;        
		char                    * Submodule                                     = NULL;
		char                    * Revseq                                     = NULL;
        char                    * id                                     = NULL;


        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");       
		Submodule               = ITK_ask_cli_argument("-SM=");
		Revseq                       = ITK_ask_cli_argument("-R=");
		id                       = ITK_ask_cli_argument("-id=");

        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Submodule)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);

        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");
                return ifail;
        }
        else
		{
				printf("\nLogin Successfull.....!!\n");
				printf("\nWelcome to Teamcenter.....!!\n");
				 printf("\n\t Submodule => %s*****\n",Submodule);fflush(stdout);
				 printf("\n\t Revseq => %s*****\n",Revseq);fflush(stdout);
				 printf("\n\t id => %s*****\n",id);fflush(stdout);

		}

        ifail = ITK_set_bypass(true);
    
	   if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");
                return -1;
        }


        ifail=Mail_Notification(Submodule,Revseq,id);
        
//2647A1B0170001 F_6

        printf("\nEnd of program.....!!\n");
        printf("\n*********************\n");
        ifail = ITK_exit_module(true);
        return ifail;
}

int Mail_Notification(char* Submodule,char* Revseq,char* id)
{

    tag_t	qryTag			= NULLTAG;
	tag_t *CntrlObjTag		= NULLTAG;


	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char *qry_entri[2] = {"SYSCD","SUBSYSCD"};
	qry_val[0] = "IRCDeviationPreapprovalmail";
	qry_val[1] = "IRCDeviationPreapprovalmail";
	char* FilePath          =NULL;
	char *InpFile=NULL;;
	char* error_text	=NULL;
	int n_entries				= 2;
	int qrycount			= 0;
	
						
 /*   InpFile=(char *)MEM_alloc(100);

    tc_strcpy(InpFile,"");
    tc_strcpy(InpFile,"interfering_module.csv");

    printf("\n Input FILE NAME=> [%s] ",InpFile); fflush(stdout);*/


	if(QRY_find("Control Objects...", &qryTag));
	if (qryTag)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);

		if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));

	    printf("\n\t ****qrycount => %d*****\n",qrycount);fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}

	
	

   if(qrycount>0)
	{

	/*   if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo3",&FilePath))
	   //  FilePath="/user/cvprod/shells/InterfaceRule/checkinMailNotification/";
	   printf("\n Input File path is : [%s]\n", FilePath);fflush(stdout);

		char *IpFile= NULL;
		IpFile=(char *)MEM_alloc(100);
		tc_strcpy(IpFile,"");
		strcpy(IpFile,FilePath);		
		strcat(IpFile,InpFile);
		
		printf("\n CHECKLIST FILE PATH=> [%s] ",IpFile); fflush(stdout);*/

		ifail = read_value_from_file(Submodule,Revseq,id);
	}
	else
	{
		printf("\n Mail Notificatio is OFF  :: Mail_Notification !! \n");fflush(stdout);
		
	}

}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Submodule,char* Revseq,char* id)
{

		char* error_text							=NULL;
		char* firsttep							=NULL;
		char* secondstep							=NULL;
		firsttep =(char *) MEM_alloc(150);
		secondstep =(char *) MEM_alloc(150);
		char * 	thirdstep= NULL;
		char * 	fourthstep= NULL;
		 char* modulerev							=NULL;
        char                    temp[10000];
		 char                    tmp[10000];
		 char* Rev							=NULL;
		 char* rev1							=NULL;
		 
		 
		 char* seq							=NULL;
		  char* TokCcidNum							=NULL;
        FILE            * fp                                    = NULL;
		int ifail=0;
		
        FILE			*output 			= NULL;
			                        
		tag_t item_tag		= NULLTAG;
		tag_t moduletag		= NULLTAG;
		tag_t modulerevtag		= NULLTAG;
		tag_t latest_rev_id		= NULLTAG;
		tag_t	object_owner						= NULLTAG;
		tag_t	object_owner_person					= NULLTAG;
		char* object_name          =NULL;			
		char* person_name          =NULL;			
		char *ruleid							=NULL;
		char *status							=NULL;
		char	*COCHead						= (char*)MEM_alloc(sizeof(char) * 2000);
		char	*CoC						= (char*)MEM_alloc(sizeof(char) * 5000);
		
		char			Data[100]					= "";
		char			outputFile[200]				= "";
		char command[512]							="";
		char command2[512]							="";
		char osUserName[SA_name_size_c+1];
		char*object_owner_email						= (char*)MEM_alloc(sizeof(char) * 5000);
		char                    *Designer                                      = NULL;
		char                    *aggregate                                      = NULL;
		Designer						= (char*)MEM_alloc(sizeof(char) * 350000);
	//	tc_strcpy(COCHead,"");
		tc_strcpy(COCHead,"at924736.ttl@tatamotors.com");
		tc_strcat(COCHead,",");
		tc_strcpy(Designer,"");

		tc_strcpy(CoC,"");

		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);

		char  type_name1[WSO_name_size_c + 1] = "";



	//	tc_strcat(outputFile,"/user/cvprod/shells/InterfaceRule/checkinMailNotification/");
	    tc_strcat(outputFile,"/user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/");
		tc_strcat(outputFile,Data);
		tc_strcat(outputFile,"_output.txt");


		printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);

         char	ModTime[100]= "";
	     strftime(ModTime,100,"%d %b %Y %H:%M:%S",&when);

	//**************

    Rev=(char *)MEM_alloc(60);
	 modulerev=(char *)MEM_alloc(60);

		TokCcidNum=(char *)MEM_alloc(60);
		

		tc_strcpy (TokCcidNum,"" );
		tc_strcat (TokCcidNum,Revseq);

		rev1 = tc_strtok(TokCcidNum,"_");

		seq	 = tc_strtok(NULL,"_");

		printf("\n Submodule   ==%s\n",Submodule);fflush(stdout);
		printf("\n Aftertok rev   ==%s\n",rev1);fflush(stdout);
		printf("\n Aftertok seq   ==%s\n",seq);fflush(stdout);

		tc_strcpy(Rev,rev1);
		tc_strcat(Rev,";");
		tc_strcat(Rev,seq);

		printf("\n final Rev   ==%s\n",Rev);fflush(stdout);


			

		ITK_CALL(ITEM_find_item(Submodule,&item_tag));
			
		if (item_tag)
		{
			 printf("\n  module found ");
		 

		//	ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));

		   ITK_CALL(ITEM_find_revision(item_tag,Rev,&latest_rev_id));	


				
			if (latest_rev_id)
			{
				printf("\n  module rev found");
			}
			else
			{
				printf("\n  module rev not found");
			}

			ifail = AOM_ask_value_string(latest_rev_id,"object_name",&object_name);
			printf("\nObject Name :---%s\n", object_name);

			ifail = AOM_ask_value_string(latest_rev_id,"t5_Design_Rule_ID",&ruleid);
			ifail = AOM_ask_value_string(latest_rev_id,"t5_Checklist_Implemented",&status);



		//	 firsttep=subString(Submodule, 14, 28);
		 char                    temp[10000];

			firsttep = strtok(Submodule,"_");
			printf("\n DependentSubmodule1:%s",firsttep);								

			secondstep = strtok(NULL,"_");
			printf("\n DependentSubmodule2:%s",secondstep);

			tc_strcpy (modulerev,"");
            tc_strcpy (modulerev,secondstep);
			tc_strcat (modulerev,"/");
			tc_strcat (modulerev,thirdstep);
			tc_strcat (modulerev,";");
		    tc_strcat (modulerev,fourthstep);
           
		   printf("\n modulerev :---%s\n", modulerev);

			
           
		   printf("\n Two times 1616 secondstep == %s \n ", secondstep);fflush(stdout);

		  
			ITK_CALL(ITEM_find_item(secondstep,&moduletag));
			ITK_CALL(ITEM_ask_latest_rev(moduletag,&modulerevtag));


			ifail = AOM_ask_value_string(modulerevtag,"t5_Aggregate",&aggregate);
			printf("\n aggregate :---%s\n", aggregate);

			if(tc_strstr(aggregate,"APPLICATIONS")!=NULL)
		//	if(tc_strstr(aggregate,"CHASSIS INTEGRATION-MFG")!=NULL)
			{
			 tc_strcpy(CoC,"Rajeeve Dave");
			 tc_strcat(COCHead,"rajeev.dave@tatamotors.com");
			 tc_strcat(COCHead,",");

			}
			else if(tc_strstr(aggregate,"EXTERIOR")!=NULL)
			{
			 tc_strcpy(CoC,"Prashant Navsariwala");
			 tc_strcat(COCHead,"prashant.navsariwala@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"INTERIOR")!=NULL)
			{
			 tc_strcpy(CoC,"Vijay Veer Singh");
			 tc_strcat(COCHead,"vijayveer.singh@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"Rahul Pathak");
			  tc_strcat(COCHead,"rahul.pathak@tatamotors.com");
			  tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"N Ganesh Kumar");
			 tc_strcat(COCHead,"n.ganeshkumar@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"Mahendra Petale");
			  tc_strcat(COCHead,"m.petale@tatamotors.com");
			  tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"SUSPENSION")!=NULL)
			{
			 tc_strcpy(CoC,"P Premlal");
			 tc_strcat(COCHead,"premlal.p@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL)
			{
			 tc_strcpy(CoC,"Mahesh Shridhare");
			 tc_strcat(COCHead,"mahesh.shridhare@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL)
			{
			 tc_strcpy(CoC,"Ajai Gupta");
			 tc_strcat(COCHead,"ajai.gupta@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"ENGINEBASE ENGINEERING")!=NULL)
			{
			 tc_strcpy(CoC,"Atul D Joshi");
			 tc_strcat(COCHead,"atul.djoshi@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL)
			{
			 tc_strcpy(CoC,"Kiran Bhandari");
			 tc_strcat(COCHead,"kiran.bhandari@tatamotors.com");
			 tc_strcat(COCHead,",");
			}
			else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL)
			{
			 tc_strcpy(CoC,"Mallappa Achanur");
			  tc_strcat(COCHead,"mallappa.achanur@tatamotors.com");
			  tc_strcat(COCHead,",");
			}
			
			
				ITK_CALL(WSOM_ask_object_type(latest_rev_id, type_name1));

				printf("\n type_name1 --->[%s]\n", type_name1); fflush(stdout);
											

											
				if((tc_strcmp(type_name1,"T5_IR_CLIST_DATARevision")==0)) 
				{
			
						SA_find_user(id,&object_owner);	


							/*ifail = AOM_ask_owner(modrevtag,&object_owner);
								if(ifail ==ITK_ok){

								} else 
								{
									EMH_ask_error_text(ifail,&error_text);
									printf("\nError %s", error_text);
								}*/
								ifail = SA_ask_user_person(object_owner,&object_owner_person);
								if(ifail ==ITK_ok){

								} else 
								{
									EMH_ask_error_text(ifail,&error_text);
									printf("\nError %s", error_text);
								}


								ifail =SA_ask_person_name2(object_owner_person,&person_name);
								printf("\nPerson Name: %s",person_name);
								

								ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
							
							 //   object_owner_email="at924736.ttl@tatamotors.com";

					
							/*	SA_ask_os_user_name	(object_owner,&osUserName);
								printf("\nuser Name %s",osUserName);
								
								 tc_strcpy(object_owner_email,"");
								 tc_strcpy(object_owner_email,osUserName);
							tc_strcat(object_owner_email,"@tatamotors.com");*/

								 printf("\n owninguser Mail id :---%s\n",object_owner_email);
								 int emaillength = strlen(object_owner_email);

							   printf("\n\t object_owner_email Lenght :%d",emaillength);


							 
								 if((tc_strstr(object_owner_email,"loader")==NULL) && (emaillength !=0))
								 {
									 printf("Inside loader condition");
								   if((tc_strstr(Designer,object_owner_email)==NULL))
									{
									  tc_strcat(Designer,object_owner_email);
									  tc_strcat(Designer,",");
									}
									 
								 }

			   }
										


					

					int len = strlen(COCHead);

					printf("\n\t mail To Lenght :%d",len);

					if(len >10)
					{

						output = fopen(outputFile, "w");
						if (output == NULL)
						{
							printf("ERROR: Cannot open File\n");
							return -1;
						}
						else
						{
							printf("File opened successfully.\n");
							
						}

	                   

						fprintf(output,"To:%s\n",COCHead);
						fprintf(output,"CC:%s\n",Designer);
						fprintf(output,"Subject: Interface Rule Deviation Approval -%s\n",object_name);
						fprintf(output,"\n\n");
					//	fprintf(output,"The below Rule is deviated.please provide Approval.\n\n","");'
						fprintf(output,"Object Name:%s\n\n",object_name);
						fprintf(output,"Sub module name and Rev seq:%s\n\n",modulerev);                       
					//	fprintf(output,"Rev. seq:%s\n\n",Rev);
					    fprintf(output,"Rule id:%s\n\n",ruleid);
						fprintf(output,"Design engineer's name:%s\n\n",person_name);
						fprintf(output,"Status:%s\n\n",status);
						fprintf(output,"CoC approval status:Pending\n\n");
						fprintf(output,"\n\n");
						fprintf(output,"Regards,\n");
						fprintf(output,"PLM Team\n\n");

					/*	fprintf(output,"Aggregate:%s\n\n",aggregate);
						fprintf(output,"Modified by:%s\n\n",id);
						fprintf(output,"CoC head:%s\n\n",CoC);
						fprintf(output,"Modification time:%s\n\n",ModTime);*/
						

						fclose(output);

					//	tc_strcat(command2,"chmod 777 /user/cvprod/shells/InterfaceRule/checkinMailNotification/*");
					    tc_strcat(command2,"chmod 777 /user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/*");
						system(command2);

					//	tc_strcat(command,"/user/cvprod/shells/InterfaceRule/checkinMailNotification/SendMail.sh");
						tc_strcat(command,"/user/testcmi/Dev/devgroups/Akshay/IR/IRCDeviationPreapprovalmail/IRDeviPreSendmail.sh");	
						tc_strcat(command," ");
						tc_strcat(command,outputFile);
						tc_strcat(command," ");
						tc_strcat(command,"cvprod@localhost"); //From
						tc_strcat(command," ");
						tc_strcat(command,COCHead);//TO											   
						tc_strcat(command," > myoutput.txt &");

					   
						printf("\n\tCommand :%s",command);

					
					  	system(command);
					}
					
					printf("\n*************************End of Handler*********************\n");
				
			
	
        fclose(fp);
        

	}
	return ifail;
}



































