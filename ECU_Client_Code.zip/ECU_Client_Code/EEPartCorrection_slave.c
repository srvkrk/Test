
/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File                  :   EEPartCorrection.c
*  Author                :   Sudhir
*  Module                :   Control Object create in TCUA
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>

#include <tccore/libtccore_undef.h>



int ITK_user_main(int argc,char* argv[])
{
        int z;
        int status;
    char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* arg1					= NULL;
int	ifail = ITK_ok;
        userid = ITK_ask_cli_argument( "-u=");
        password = ITK_ask_cli_argument("-pf=");
        group = ITK_ask_cli_argument( "-g=");
        arg1 = ITK_ask_cli_argument( "-i=");
ifail = ITK_auto_login();
        tag_t   query                                   = NULLTAG;
        tag_t   query3                                  = NULLTAG;
        tag_t   *Design_objects                 = NULLTAG;
        tag_t   *DesignRev_objects              = NULLTAG;
        tag_t   DesignRev_object                = NULLTAG;
        tag_t   Design_object                   = NULLTAG;
        tag_t   reln_type                               = NULLTAG;
        tag_t   primary                                 = NULLTAG;
        tag_t   objTypeTag                              = NULLTAG;
        tag_t   tagBOMwindow                    = NULLTAG;
        tag_t   tagBOMwindow1                   = NULLTAG;
        tag_t   tagRule                                 = NULLTAG;
        tag_t   tagRule1                                = NULLTAG;
        tag_t   tagBOMline                              = NULLTAG;
        tag_t   tagParentBOMline                = NULLTAG;
        tag_t   *childTagCfgTopBomLine1 = NULLTAG;
        tag_t   *Design_objects2                = NULLTAG;
		tag_t   *Design_Rev_list= NULLTAG;
		int design_count=0;
        tag_t   *parents                                = NULLTAG;
        tag_t   *childTagTopBomLine             = NULLTAG;
        tag_t   *EE_objects                             = NULLTAG;
        tag_t   *t_EERevObjs                    = NULLTAG;
        GRM_relation_t *related_object_list;
        char  type_name[TCTYPE_name_size_c+1];





        FILE* fptr = NULL;



        char *Pno                       = NULL;
        char *EEPno                     = NULL;
        char *PartNumber        = NULL;
        char *DesignGrp         = NULL;
        char *ParentNumber      = NULL;
        char *ParentDsgGrp      = NULL;
        char *ParentRev         = NULL;
        char *ChildPrtNumber= NULL;
        char *tag_blitemId      = NULL;
        char *ChildQty          = NULL;
        char *ChildRev          = NULL;
        char *AtMatrix          = NULL;
        char *RtMatrix          = NULL;
        char *Part_Revision     = NULL;


        int StrctInt   =0;
        int  n_entries1=2;
        int  n_entries3=2;
        int  n_found1,dsgrevcnt,rel=0;
        int  dsgcnt,TotalRevs,n_attchs=0;
        int  childCountCfgTopBomLine1=0;
        int  childCountTopBomLine=0;
        int  n_entries2=1;
        int  n_found2=0;

        int n_parents,n_found3 = 0;
    int *levels = 0;
        int bl_item_id   = 0;
        int bl_quantity  = 0;
        int bl_rev_item_revision_id      = 0;
        int bl_plmxml_abs_xform  = 0;
        int bl_plmxml_occ_xform  = 0;
        int i,ii,jj,EE_tags_found = 0;
        
		
		tag_t slave_relationType=NULLTAG;
		int mstrcnt=0;
		tag_t* mstrobj=NULL;
		tag_t Slave_relation_tag=NULLTAG;
tag_t DesignPart_rev=NULLTAG;
char* CurrentRevSeq=NULL;
        int n_references = 0;
    int *levels1 = NULL;
    tag_t *reference_tags = NULL;
    char **relation_type_name = NULL;
	
	
	

        char *qry_entries1[2] = {"Item ID","Type"};
		char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
        //char *qry_values1[2] = NULL;

        char *qry_entries3[3] = {"Item ID","Revision","Type"};
		char **qry_values3 = (char **) MEM_alloc(50 * sizeof(char *));
        //*qry_values3[2] = {"*","*"};

        /*const char
        *attrs1[2] = {"item_id","object_type"};
        *values1[2]     = {"*","*"};*/


        printf("\n\n\t Attempting Logging\n ");fflush(stdout);
        

        
        printf("\n\n\t Attempting Logging with User [%s], Passwd[%s], Group[%s]\n ",userid,password,group);fflush(stdout);
          
        if (ifail != ITK_ok)
	    { 
			printf("Error in Login to Teamcenter\n");
		}
		else
        {
        printf("\n\n\t Login Successfull\n ");fflush(stdout);
                //ITK_set_journalling( TRUE );
        
                printf("\n\n\t Login Successfull\n ");fflush(stdout);
                ITK_set_bypass(true);
                Pno=(char *)MEM_alloc(30);
                EEPno=(char *)MEM_alloc(30);
                tc_strcpy(Pno,arg1);
                tc_strcpy(EEPno,arg1);
                tc_strcat(Pno,"_16");
                printf("\n Input part Number is=>[%s]",Pno);fflush(stdout);
                printf("\n Input EE part Number is=>[%s]",EEPno);fflush(stdout);
                qry_values1[0] = Pno;
                qry_values1[1] = "Design";

                QRY_find2("Item...", &query);
                QRY_find2("Item Revision...", &query3);

                if(query!=NULLTAG)
                {
                        printf("\n1Query Found...");fflush(stdout);
				QRY_execute(query, n_entries1, qry_entries1, qry_values1, &n_found1, &Design_objects);
                }
                
                printf("\n Total Number of Designobjects=>[%d]",n_found1);fflush(stdout);
                
              
                                                                                               if(n_found1>0)
                                                                                               {
                                                                                                       tag_t Design_rev=NULLTAG;
																										tag_t EEPart_rev=NULLTAG;
																							   ITEM_list_all_revs(Design_objects[0],&design_count,&Design_Rev_list);
																										
																										  for(i=0;i<design_count;i++)
                                                                                                       {
                                                                                                           DesignPart_rev=Design_Rev_list[i];
																										   AOM_ask_value_string(DesignPart_rev,"Revision",&CurrentRevSeq);
																											GRM_find_relation_type("T5_ContHasSlave",&slave_relationType);
																											GRM_list_primary_objects_only(DesignPart_rev,slave_relationType,&mstrcnt,&mstrobj);
																											printf("\n Master obj --->[%d]\n", mstrcnt); fflush(stdout);
																											   for(ii=0;ii<mstrcnt;ii++)
                                                                                                           {
																											  AOM_ask_value_string(mstrobj[0],"item_id",&PartNumber);
                                                                                                             printf("\n Master obj --->[%s]\n", PartNumber); fflush(stdout);
																											  //AOM_refresh(mstrobj[0],1);
																											  GRM_find_relation(mstrobj[ii],DesignPart_rev,slave_relationType,&Slave_relation_tag);
																										   GRM_delete_relation(Slave_relation_tag );
																											 // AOM_save(mstrobj[0]);
																											  //AOM_refresh(mstrobj[0],0);
																											  
																											  if(query3!=NULLTAG)
                                                                                                                       {
                                                                                                                               printf("\n2Query Found...");fflush(stdout);
                                                                                                                               qry_values3[0] = EEPno;
                                                                                                                               qry_values3[1] = CurrentRevSeq;
			                                                                                                       			qry_values3[2] = "EE Part Revision";
                                                                                                                               QRY_execute(query3, n_entries3, qry_entries3, qry_values3, &n_found3, &EE_objects);
                                                                                                                       }
																											  if(n_found3>0)
																											  {
																										       EEPart_rev=EE_objects[0];
																											   GRM_create_relation(mstrobj[ii],EEPart_rev,slave_relationType,NULLTAG,&Slave_relation_tag);
																											   GRM_save_relation(Slave_relation_tag);
																											  }
                                                                                                           }
																										}
																								}
		}
    //   }
		
	/*	else 
		{
			printf("Error in Login to Teamcenter\n");
		return ifail;}*/

        return ITK_ok;
}
