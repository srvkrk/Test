#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

//char	* usr			=   NULL;
//char	* pass			=   NULL;
//char	* grp			=   NULL;
char	* req_item			=   NULL;
char	* req_Rev			=   NULL;
char	* req_Seq			=   NULL;
char	* req_item3			=   NULL;
char	* req1_Rev			=   NULL;
char	* req1_Seq			=   NULL;
char	*newRev				= NULL;
char	*newRev1			= NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

//extern int ITK_user_main (int argc, char ** argv )
int ITK_user_main(int argc, char* argv[])
{
	int status;
	int iStatus=0;
	
//	(void)argc;
	//(void)argv;

	initialise();

	//usr  = ITK_ask_cli_argument("-u=");
	//pass  = ITK_ask_cli_argument("-pf=");
	//grp  = ITK_ask_cli_argument("-g=");
	
	iStatus = ITK_auto_login();

//	if(ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok);
   
	//if(ITK_init_module(usr ,pass,grp)!=ITK_ok);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	req_item  = ITK_ask_cli_argument("-i=");
	req_Rev = ITK_ask_cli_argument("-r=");
	req_Seq = ITK_ask_cli_argument("-s1=");
	req_item3 = ITK_ask_cli_argument("-p=");
	req1_Rev = ITK_ask_cli_argument("-q=");
	req1_Seq = ITK_ask_cli_argument("-s2=");

	//TODO:check module rev in snapshot.
	//if(AOM_ask_value_tags(snapshotFolder_tag,"contents",&snapcount,&snapchild));
	
	printf("\nkk.CCID [%s,%s,%s]",req_item,req_Rev,req_Seq);fflush(stdout);
	printf("\nkk.Module [%s,%s,%s]",req_item3,req1_Rev,req1_Seq);fflush(stdout);

	newRev		=(char *) MEM_alloc(10);
	newRev1		=(char *) MEM_alloc(10);

	tc_strcpy(newRev,req_Rev);
	tc_strcat(newRev,"*");
	tc_strcat(newRev,req_Seq);

	tc_strcpy(newRev1,req1_Rev);
	tc_strcat(newRev1,"*");
	tc_strcat(newRev1,req1_Seq);

	int n_Input = 3;
	int CCIDCount = 0;
	int ModCount = 0;
	int n_tags_found = 0;
	int nSlvCnt = 0;
	int iMCnt = 0;
	int n_Cnt=0;
	int ifail;
	char	*qry_Input[3] = {"Item ID", "Type", "Revision"};
	char	*values[3];
	char	*values1[3];
	tag_t	ProQryCCIDObj = NULLTAG;
	tag_t	ProQryModObj = NULLTAG;
	tag_t	*CCIDObj = NULLTAG;
	tag_t	*ModObj = NULLTAG;

	tag_t	SnapshotRevTag	= NULLTAG;
	tag_t	HasSnapshot_type	= NULLTAG;
	tag_t*	Snapshotattachments	= NULLTAG;
	tag_t	Modl_rev_tags = NULLTAG;
	tag_t	window,top_line;
	tag_t	*members;
	tag_t	*tags_found = NULLTAG;
	tag_t	Part_Tag = NULLTAG;
	tag_t	MstrSlvRel = NULLTAG;
	tag_t	*tSlvAttachments = NULLTAG;
	tag_t	LatestModRevTag = NULLTAG;
	tag_t	Main_CCID_rev_tag = NULLTAG;
	tag_t	Mod_rev_tag = NULLTAG;
	int Snapcnt=0;
	char	*ModNum = NULL;
	char	*MRevIDNo = NULL;
	char	*partnum = NULL;
	char	*partrev = NULL;

	if( req_item )
	{
		//printf("\n nwRev:::::::: = %s", nwRev);fflush(stdout);
		values[0] = req_item;
		values[1] = "VCID Revision";
		values[2] = newRev;

		values1[0] = req_item3;
		values1[1] = "Design Revision";
		values1[2] = newRev1;

		if(QRY_find2("Item Revision...", &ProQryCCIDObj));
		if(ProQryCCIDObj)
		{
			 if(QRY_execute(ProQryCCIDObj, n_Input, qry_Input, values, &CCIDCount, &CCIDObj));
			 printf("\nkk.CCID count [%d]",CCIDCount);fflush(stdout);
		}

		if(QRY_find2("Item Revision...", &ProQryModObj));
		if(ProQryModObj)
		{
			 if(QRY_execute(ProQryModObj, n_Input, qry_Input, values1, &ModCount, &ModObj));
			 printf("\nkk.Module count [%d]",ModCount);fflush(stdout);
		}

		if(CCIDCount>0 && ModCount>0)
		{			
			Main_CCID_rev_tag = CCIDObj[0];
			Mod_rev_tag = ModObj[0];
			ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshot_type); 
			ifail = GRM_list_secondary_objects_only(Main_CCID_rev_tag,HasSnapshot_type,&Snapcnt,&Snapshotattachments);
			printf("\nkk.Snapcnt [%d] -------> \n",Snapcnt);fflush(stdout);

			if(Snapcnt>0)
			{
				SnapshotRevTag=Snapshotattachments[0];
				ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&LatestModRevTag));// THIS is the module based on which SS was create
										
				ITK_CALL(AOM_ask_value_string(LatestModRevTag,"item_id",&ModNum));
				ITK_CALL(AOM_ask_value_string(LatestModRevTag,"item_revision_id",&MRevIDNo));
				printf("\n[Module,Rev] [%s,%s]\n",ModNum,MRevIDNo);fflush(stdout);

				//ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&Modl_rev_tags));

				printf("\nkk.create window from snapshot");fflush(stdout);
				ifail =BOM_create_window_from_snapshot(SnapshotRevTag,&window);
				ifail = BOM_set_window_top_line (window, null_tag, Mod_rev_tag, null_tag, &top_line);
				CHECK_FAIL;

				//printf("\nkk.Modifying topline..");fflush(stdout);
				//IDC_set_window_top_line_snapshot(window,null_tag,SnapshotRevTag,top_line);

				ifail = BOM_window_show_suppressed ( window );
				CHECK_FAIL;

				ITK_CALL(BOM_set_window_pack_all(window, FALSE));
			}
		}
	}

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	//ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

//	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
//	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
//	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}
}

