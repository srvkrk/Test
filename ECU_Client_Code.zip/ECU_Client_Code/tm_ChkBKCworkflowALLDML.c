#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
#include <tc/tc_startup.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <tccore/item_msg.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <fnd0booleansolve/booleansolve.h>
#define ITK_err 919002
#define GMD_err (EMH_USER_error_base +26)
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error (EMH_USER_error_base+25)
#define PLM_error1 (EMH_USER_error_base+26)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PLM_error2 (EMH_USER_error_base+26)
#define PLM_error3 (EMH_USER_error_base+26)
#define PLM_error4 (EMH_USER_error_base+26)
#define PLM_error5 (EMH_USER_error_base+26)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -p=<project name> (required)\n"
        );	
}
int Chk_BKC_CCU_DML(char*);
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Dmlid					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Dmlid 			= ITK_ask_cli_argument("-i=");

	int			ifail 				= ITK_ok;
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Dmlid)) == 0)
	{
		print_requirement();
		return -1;
	}
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ifail = ITK_auto_login();

	ITK_CALL(ITK_set_journalling( TRUE ));

	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	ifail = Chk_BKC_CCU_DML(Dmlid);
	
		
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


int Chk_BKC_CCU_DML(char* Dmlid)
{
	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char   *Prt_object_typerev =NULL;

	char *DatasetName	    = NULL;
	char  *mdmclass_name;
	

	tag_t    Cciditemrev   = NULLTAG;

	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;

	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;

	char * username				= NULL;
	char * parent_name			= NULL;
	char * dmlTaskNo			= NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		pr					= 0;

	int	n_entriesMdm = 2;
	int n_foundMdm = 0;
	int p = 0;
	char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesMdm[2]  = {"BKC", "ChkBKCworkflow"};
	tag_t   *MdmCtrObj      = NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t  TagMdmControl     = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t  reln_typeMdm       = NULLTAG;
	tag_t  Mdmrelation        =NULLTAG;

	//

	char*	Cciditem_rev  = NULL;
	char *  PartItemRevIdSn =NULL;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	
	
	int		sn 	        = 0;

	
	int		z				= 0;
		tag_t *ccidTagrf=NULLTAG;
			char *  PartItemIdSn      =NULL;
	char  *AddPartnumber       = NULL;
	char* ErrorText;

//	char	*Dmlid		= NULL;
	tag_t    Dmltag     = NULLTAG;
	char  *AddPartnumberrev       = NULL;
	char* contents	    = NULL;
	char* partrevseq=	NULL;
	
	int s=0;
	int y=0;
	int ref=0;


	char* allparts=	NULL;
	char* Message=	NULL;

	allparts=(char *)MEM_alloc(10000);
	Message=(char *)MEM_alloc(10000);

	tc_strcpy(allparts,"");
	tc_strcpy(Message,"Parts Are Not Available In Snapshot:");


	//int length =0;
	//**************
	char	*FileName = NULL;
	time_t temp; 
    struct tm *timeptr; 
    char pAccessDate[30];
	char *sCurrentDate = NULL;
	char *sCurrentDateDup = NULL;
	char *strToBereplaceddate;
	char *strToBeUsedInsteaddate;

	FILE *fptr;


	FileName =(char *) MEM_alloc(150);
	sCurrentDate =(char *) MEM_alloc(30);
	sCurrentDateDup =(char *) MEM_alloc(30);
	strToBereplaceddate = (char*)malloc(5);
	strToBeUsedInsteaddate = (char*)malloc(5);



	printf("\nkk.Querying all ECU Modules\n"); fflush(stdout);


    time(&temp); 
    timeptr = localtime(&temp ); 
	tc_strcpy(pAccessDate,"");
    strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr); 
	tc_strcpy(sCurrentDate,pAccessDate);
	tc_strcpy(strToBereplaceddate,"/");
	tc_strcpy(strToBeUsedInsteaddate,"-");

	ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup); 

      
    printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);


    tc_strcpy(FileName,Dmlid);
	tc_strcat(FileName,"_BKCRptVCID.csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		exit(1);
	}
	fprintf(fptr,"%s,%s,%s,%s,%s","DML Number","VCID Number","VCID Revision","status","Parts not Updated");fflush(fptr);

	//*****************


	ITK_CALL(POM_get_user_id (&username));
	printf("\n Inside the CCU_DML DMLworkflow Session User is : %s \n",username); fflush(stdout);

	if((tc_strcmp(username,"info") !=0) && (tc_strcmp(username,"load") !=0))
	{

	tag_t ProQryContObj=NULLTAG;
    char    *info1         = NULL;
    char    *bkcstr		    = NULL;
	char	*qry_BInput[2]   = {"Name", "Release Type"};
	char	*qry_BVal[2] = {"T5_LcsErcRlzd", "Backward Compatible VCID Release"};
	int		B_InputX		= 2;
	int     CountB			= 0;
	int     iPCnt			= 0;
	tag_t	*CnObjB		    = NULLTAG;
	
	  if(QRY_find2("ERCDMLReleased_Type", &ProQryContObj));
	  if(ProQryContObj)
	  {
		  if(QRY_execute(ProQryContObj, B_InputX, qry_BInput, qry_BVal, &CountB, &CnObjB));
		  printf("\n CONT Objects for CCID transfer LIVE  == %d\n", CountB);fflush(stdout);
		  if(CountB >0)
		  {
			  	
				for(iPCnt=0; iPCnt<CountB; ++iPCnt)
				{
					int		partcntrf	        = 0;
					int		CCID 	        = 0;
					int		snapcount 	        = 0;
					int		partaddcnt				= 0;
					
					DMLTaskTag = CnObjB[iPCnt];
					tc_strcpy(allparts,"");



						/*	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
							printf("\n Inside the CCU_DML DMLworkflow  ...\n");fflush(stdout);

							ITK_CALL(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
							printf("\n CCU_DML DMLworkflow - CurrentTask: %s \n",CurrentTask);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
							printf("\n CCU_DML DMLworkflow - Parent Name: %s \n",parent_name);fflush(stdout);

							CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
							printf("\n CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);*/

						//   if(noAttachment > 0)
						//	{  
							//	ITK_CALL(ITEM_find_item(Dmlid,&Dmltag));//cmt
							//	ITK_CALL(ITEM_ask_latest_rev(Dmltag,&DMLTaskTag));//cmt

							   if (DMLTaskTag)
							   {
								printf("\n  dml rev found");
							   }


							//	printf("\n Inside for --CCU DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
							//	DMLTaskTag = attachments[0];

								if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
								printf("\n CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);
						if (tc_strcmp(dmlTaskNo,"21PP226O06")==0)
						{
							printf("\n excluding - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

						}
						else
					    {
						

								if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();

								if (MdmDML_tag != NULLTAG)
								{
								  printf("\n DML tag is not null for CCU DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);

								  if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

								  if(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&Rel_type)!=ITK_ok)PrintErrorStack();
								  printf("\n for CCU DMLworkflow  DML Rel_type: [%s]", Rel_type);fflush(stdout);
					//
					//			   ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_ERCBusiUt",&BusUnitDV));
					//			   printf("\n CCU DML business unit for :%s \n",BusUnitDV);fflush(stdout);
					//
					//				ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_PlntToPlnt",&DMLDRdvp));
					//				printf("\n CCU Plant to plant  :%s \n",DMLDRdvp);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
									printf("\n CCU DML number for DVP :%s \n",dmlNo);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"t5_rlstype",&DMLtype));
									printf("\n CCU DML Release type for DVP :%s \n",DMLtype);fflush(stdout);

									printf("\n  Inside the CCU DML - \n");fflush(stdout);

									if(QRY_find2("ControlObjQry", &TagMdmControl));

									if(QRY_execute(TagMdmControl, n_entriesMdm, qry_entriesMdm, qry_valuesMdm, &n_foundMdm, &MdmCtrObj));
									printf("\n Control Object found for CCU DML == %d \n", n_foundMdm);fflush(stdout);

									if(n_foundMdm==1)
									{
										printf("\n As Control Object found for CCU DML == %d  \n", n_foundMdm);fflush(stdout);

									  ITK_CALL(POM_class_of_instance(MdmDMLRevTag,&class_id));
									  ITK_CALL(POM_name_of_class(class_id,&mdmclass_name));
									  printf("\n Inside the CCU DML class_name of Task :%s \n",mdmclass_name);fflush(stdout);

									  ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &MdmDMLToTaskRel));
									  ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

									  printf("\n Finding the CCU DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);

									   if (Mdmtsk_cnt>0)
									  {
										printf("\n Inside task count for CCU DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);

											for (tt=0;tt<Mdmtsk_cnt ;tt++ )
											{
												 printf("\n Now inside the task find as Task count is for CCU DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
												 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[tt],"object_type",&Taskobj_type));
												 printf("\n Now CCU DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);

												 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[tt],"item_id",&TskNmMdm));
												 printf("\n Now CCU DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);


												 ITK_CALL(GRM_find_relation_type("IMAN_reference", &Part_tobeAdd));

												 ITK_CALL(GRM_list_secondary_objects_only(MdmTsk_objects[tt], Part_tobeAdd, &partaddcnt, &addPartsTag));
												 printf("\n  No of part attached to task in  CCU DML  -: %d \n",partaddcnt);fflush(stdout);

												/*	if (partaddcnt>0)
													{
														printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);


														for (z=0;z<partaddcnt;z++)
														{
															int n=0;
															CcidADDTag=addPartsTag[z];
															AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
															if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
															if( AOM_ask_value_string(CcidADDTag,"item_revision_id",&AddPartnumberrev)!=ITK_ok);

															printf("\n CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

															partrevseq=(char *)MEM_alloc(500);
															tc_strcpy(partrevseq,"");
															tc_strcpy(partrevseq,AddPartnumber);
															tc_strcat(partrevseq,"/");	    
															tc_strcat(partrevseq,AddPartnumberrev);	

															printf("\n added part revision sequence is [%s]  \n",partrevseq); fflush(stdout);*/

															
															ITK_CALL(GRM_find_relation_type("T5_HasNewCCID", &part_tsk_relc));
															printf("\n Part addition code-Expanding T5_HasNewCCID expanded \n"); fflush(stdout);

																if (part_tsk_relc!=NULLTAG)
																{
																   printf("\n Part addition code Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

																   ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag, part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
																   printf("\n Part addition code Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);
																	   
																	   
																		if (partcntrf>0)
																		{
																			
																			for (pr=0;pr<partcntrf;pr++)
																			{   
																				//int q=0;
																				int idfound=0;
																				//////////
																				int length =0;
																				tc_strcpy(allparts,"");


																				///////
																				printf("\n Part addition code -Inside Dataset found for MDM DML  \n"); fflush(stdout);
																				DesignrevTagR=PartsTagrf[pr];

																				if(AOM_ask_value_string(DesignrevTagR,"item_id",&Prt_object_type)!=ITK_ok);
																				if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Prt_object_typerev)!=ITK_ok);
																				printf("\n Part addition code In CCID  , object_name is :%s \n",Prt_object_type);fflush(stdout);

																				if(AOM_ask_value_string(DesignrevTagR,"item_revision_id",&Cciditem_rev)!=ITK_ok);
																				printf("\n  Part addition code ccid  Cciditem_rev IS --------->[%s]\n",Cciditem_rev);fflush(stdout);

																				 ////////////////////////////



																				ITK_CALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));// new relation created in bmide
																				printf("\n Part addition code - finding HasSnapshotType \n");fflush(stdout);

																				ITK_CALL(GRM_list_secondary_objects_only(DesignrevTagR, HasSnapshotType, &CCID, &ccidTagrf));//3 sept
																				printf("\n Part addition code -Find the SNAPSHOT for CCID ---.:%d \n",CCID);fflush(stdout);



																				if(CCID>0)
																				{
																				

																				  ITK_CALL(AOM_ask_value_tags(ccidTagrf[0],"contents",&snapcount,&snapchild));//added
																				  printf("\n Part addition code- snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

																				  printf("\n 444  CCID PART to be added  Part attached new relationship [%s/%s]  \n",AddPartnumber,AddPartnumberrev); fflush(stdout);

																									  //**************
																				  tag_t	snapchilds	= NULLTAG;
																				  char* snappartrevseq=	NULL;
																				  char* snapPartnumber=	NULL;
																				  char* snapPartnumberrev=	NULL;

																				 if(snapcount>0)
																				{
																									  
																						  for (s=0;s<snapcount ;s++ )                                     
																						  {
																							 snapchilds=snapchild[s];
																							 int q=0;
																							 tc_strcat(allparts,"");

																							  if( AOM_ask_value_string(snapchilds,"item_id",&snapPartnumber)!=ITK_ok);
																							  if( AOM_ask_value_string(snapchilds,"item_revision_id",&snapPartnumberrev)!=ITK_ok);

																							  snappartrevseq=(char *)MEM_alloc(500);
																							  tc_strcpy(snappartrevseq,"");
																							  tc_strcpy(snappartrevseq,snapPartnumber);
																							  tc_strcat(snappartrevseq,"/");	    
																							  tc_strcat(snappartrevseq,snapPartnumberrev);

																							   printf("\n snapshot part revision sequence is [%s]  \n",snappartrevseq); fflush(stdout);

																							   ///////////////

																								if (partaddcnt>0)
																								{
																									printf("\n Inside part found in Mdm dml  attached to task in MDM DML -: %d \n",partaddcnt);fflush(stdout);


																									for (z=0;z<partaddcnt;z++)
																									{
																										int n=0;
																										int idfound=0;
																										int q=0;
																										// tc_strcpy(allparts,"");
																										


																										CcidADDTag=addPartsTag[z];
																										AddPartnumber =(char *) MEM_alloc(20 * sizeof(char *));
																										if( AOM_ask_value_string(CcidADDTag,"item_id",&AddPartnumber)!=ITK_ok);
																										if( AOM_ask_value_string(CcidADDTag,"item_revision_id",&AddPartnumberrev)!=ITK_ok);

																										printf("\n CCID PART to be added  Part attached new relationship [%s]  \n",AddPartnumber); fflush(stdout);

																										partrevseq=(char *)MEM_alloc(500);
																										tc_strcpy(partrevseq,"");
																										tc_strcpy(partrevseq,AddPartnumber);
																										tc_strcat(partrevseq,"/");	    
																										tc_strcat(partrevseq,AddPartnumberrev);	

																										
																										
																										printf("\n added part revision sequence is [%s]  \n",partrevseq); fflush(stdout);


																										if (tc_strcmp(partrevseq,snappartrevseq)==0)
																										 {
																											 printf("\n Checking part [%s]  in snapshot \n",partrevseq); fflush(stdout);
																											 q++;

																										 }
																										  if (tc_strcmp(AddPartnumber,snapPartnumber)==0)
																										 {
																											 idfound=1;
																											  printf("\n idfound= %d \n",idfound);fflush(stdout);
																										 }



																										 y=z+1;

																											

																											 printf("\n y : %d \n",y);fflush(stdout);
																											 printf("\n q : %d \n",q);fflush(stdout);

																											
																											  if (q==0)	 
																											  {
																												
																											//	if ((n==0) && (idfound == 1))
																												if(idfound == 1)
																												 {
																												   tc_strcat(allparts,partrevseq);
																												   tc_strcat(allparts,",");
																												//   n++;
																												//    printf("\n n= %d \n",n);fflush(stdout);
																													
																												 }
																													
																											  }
																									}
																								//	MEM_free(addPartsTag);
																								}





																							   /////////////




																						  }
																						//  MEM_free(snapchild);
																				}
																				else
																				{
																				printf("\n snapshot content not available for : %s/%s \n",Prt_object_type,Prt_object_typerev);fflush(stdout);
																				fprintf(fptr,"\n%s,%s,%s,%s,%s",dmlNo,Prt_object_type,Prt_object_typerev,"Snapshot data not Available",allparts);fflush(fptr);

																				}
																						  
																				
																							 
																				
																			//	MEM_free(ccidTagrf);
																				}
																				else
																				{
																				printf("\n snapshot not available for : %s/%s \n",Prt_object_type,Prt_object_typerev);fflush(stdout);
																				fprintf(fptr,"\n%s,%s,%s,%s,%s",dmlNo,Prt_object_type,Prt_object_typerev,"Snapshot not Available",allparts);fflush(fptr);

																				}

																				//////////

																				 length = strlen(allparts);
																				 printf("\n length : %d \n",length);fflush(stdout);
																				 if(length > 0)
																				{

																				fprintf(fptr,"\n%s,%s,%s,%s,%s",dmlNo,Prt_object_type,Prt_object_typerev,"Updation Require",allparts);fflush(fptr);

																				}
																				 
																				//////////


																			}
																		//	MEM_free(PartsTagrf);

																		 }



															   }
												//		}//partaddcnt
													
														 
														/*  length = strlen(allparts);
														  printf("\n length : %d \n",length);fflush(stdout);
														  if(length > 1)
														  {
														  printf("\n Given parts are not available in snapshot : %s \n",allparts);fflush(stdout);
														 fprintf(fptr,"\n%s,%s",Dmlid,allparts);fflush(fptr);
														  }*/
						
														  
												//	}//if (partaddcnt>0)
														

											}

									  }

									}
									else
									{
										printf("\n Else Control Object is off for checking Chk_BKC_CCU_DML == %d  \n", n_foundMdm);fflush(stdout);
									}

								}

				}//bypass 21PP226O06
						//   }


						//
					/*	if (partcntrf>0)
						{
						MEM_free(PartsTagrf);
						}
						if(CCID>0)
						{
						MEM_free(ccidTagrf);
						}

						 if(snapcount>0)
						{
						MEM_free(snapchild);
						}
						if (partaddcnt>0)
						{
						MEM_free(addPartsTag);
						}*/



				}
		  }
	  }
	}//loader

	printf ("\n--------------CCU_DML=Completed--------------------\n");fflush(stdout);

	return ITK_ok;
}
 
