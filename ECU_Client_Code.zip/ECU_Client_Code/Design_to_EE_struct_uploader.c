
#include <stdio.h>
//#include <tc/tc.h>
#include <qry/qry.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
//#include <itk/mem.h>
#include <string.h>
#include <ps/ps.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int read_value_from_file(char*);
int Get_Qry_Execute(char*, char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Part_no					= NULL;
	//char			* filename1					= NULL;
    char *Folder_name=NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Part_no		    = ITK_ask_cli_argument("-i=");
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = read_value_from_file(Part_no);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_value_from_file(char* Part_no)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
    
	
	char *Part_RevSeq	= NULL;
	char* Rem_part=NULL;
	
	int row=0;
	
	char 			temp[500];

//Part_no=(char *) MEM_alloc(100);
Part_RevSeq=(char *) MEM_alloc(100);
char* Filename_1=NULL;
Filename_1=(char *) MEM_alloc(100);
tc_strcpy(Filename_1,"");
tc_strcpy(Filename_1,Part_no);
tc_strcat(Filename_1,"_Rlz.txt");

printf("\nFilename1: %s", Filename_1);
	
	FILE* fp = NULL;
	fp = fopen(Filename_1, "r");
	
	if (fp != NULL)
	{

		while (fgets(temp, 500, fp)!= NULL)
		{
	
	       row ++;
			if(row==1)
			continue;
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				
                Part_no =strtok(temp,"^");
				printf("\nPart_no:%s",Part_no);

				Part_RevSeq = strtok(NULL,"^");
				printf("\nPart_RevSeq:%s",Part_RevSeq);
				
				Rem_part = strtok(NULL,",");
				printf("\nRemaining_part:%s",Rem_part);
				
				ifail = Get_Qry_Execute(Part_no,Part_RevSeq);
              
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	

	      
			 fclose(fp);
	return ifail;
}

int Get_Qry_Execute(char* Part_no,char* Part_RevSeq)
{
tag_t	top_line    = NULLTAG;
	int bvrfound		= 0;
	tag_t  *children	= NULLTAG;
	char* partNumber 	= NULL;
	char* PartType      = NULL;
	char* LatChildName      = NULL;
	char* ObjType       = NULL;
	char* BLObjType     = NULL;
	tag_t	sn_rule		= NULLTAG;
	tag_t	window		= NULLTAG;
	
	tag_t PartTagItem=NULLTAG;
	int count=0;
	tag_t* Obj_tag = NULLTAG;
	tag_t revtag = NULLTAG;
	char * Part_no1=NULL;
Part_no1=(char *) MEM_alloc(300);

	tc_strcpy(Part_no1,Part_no);
 tc_strcat(Part_no1,"_16");
 
int PartCount=0;
int PartCount1=0;
int ifail           = ITK_ok;
tag_t ItemQry     = NULLTAG;
int Entry_count=2;
char *Entries[2] = {"Item ID","Revision"};
char **Values = (char **) MEM_alloc(50 * sizeof(char *));
char **Values1 = (char **) MEM_alloc(50 * sizeof(char *));
tag_t* PartTag   = NULLTAG;
tag_t* PartTag1   = NULLTAG;
Values[0] = Part_no;
Values[1] = Part_RevSeq;
tc_strcpy(Part_no1,Part_no);
tc_strcat(Part_no1,"_16");
Values1[0] = Part_no1;
Values1[1] = Part_RevSeq;

int bvr_count = 0;
int jj = 0;
int n_Cnt = 0;
int bv_count = 0;
tag_t *bvrs=NULLTAG;

tag_t EEPart_rev=NULLTAG;
double d;
tag_t       bv1,bvr1       = NULLTAG;

ifail=QRY_find2("Item Revision...", &ItemQry);
    ITK_CALL(ITEM_find_item(Part_no,&PartTagItem));
	
	//ITK_CALL(AOM_ask_value_string(PartTagItem,"bl_item_item_id",&partNumber));
	
		if (ItemQry)
		{ 
	     QRY_execute(ItemQry, Entry_count, Entries, Values, &PartCount, &PartTag);
		 QRY_execute(ItemQry, Entry_count, Entries, Values1, &PartCount1, &PartTag1);
		 
    ITK_CALL(BOM_create_window (&window)); //3 sept

	ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept

	ITK_CALL(CFM_find("ERC Review And Above", &sn_rule ));

	ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

	ITK_CALL(BOM_set_window_top_line (window, null_tag,PartTag1[0],null_tag, &top_line));

	ITK_CALL(BOM_window_show_suppressed (window));

	printf("\n after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

	//ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
	

	ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
	printf("\n n_Cnt===>%s %d\n",partNumber,n_Cnt);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(children[0],"bl_item_item_id",&partNumber));
	
	ITK_CALL(ITEM_find_item(partNumber,&EEPart_rev));
	
	printf("\n Part number===>%s %d\n",partNumber,n_Cnt);fflush(stdout);
	for(jj= 0;jj< n_Cnt;jj++)  
	{
      ITK_CALL( AOM_lock( PartTagItem));
      //EEPart_rev=children[jj];
	  ITEM_list_bom_views(PartTagItem,&bv_count,&bvrs);
	  printf("\n bv_count===>%d\n",bv_count);fflush(stdout);
	  bv1=bvrs[0];
      //ITK_CALL( PS_create_bom_view( NULLTAG, "", "",PartTagItem ,&bv1 ));
      ITK_CALL(AOM_save_without_extensions( bv1 ));
      ITK_CALL( AOM_save_without_extensions( PartTagItem ));
      ITK_CALL( AOM_unlock( PartTagItem));
     

ITK_CALL( AOM_lock( PartTag[0] ));
      ITK_CALL(PS_create_bvr( bv1, "", "", false, PartTag[0],&bvr1) );
      if(bvr1 !=NULLTAG)
      {
              ITK_CALL( AOM_save_without_extensions( bvr1) );
              ITK_CALL (AOM_save_without_extensions( PartTag[0] ));
              ITK_CALL( AOM_unlock( PartTag[0] ));
              fprintf( stderr, "\n inside  PS_create_bvr..\n");
      }
	  ITK_CALL(AOM_lock(bvr1));
	tag_t   *occs2          =       NULLTAG;
                          ITK_CALL(PS_create_occurrences(bvr1, EEPart_rev, NULLTAG,1, &occs2 ));
                          ITK_CALL(PS_set_occurrence_qty(bvr1,occs2[0],1));
                          ITK_CALL(AOM_save_without_extensions(bvr1));
                          ITK_CALL(AOM_refresh(bvr1,0));
                          ITK_CALL(AOM_unlock(bvr1));
                  
	}
	}
return ifail;
}

