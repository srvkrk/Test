#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char     *f        =   NULL;
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sOpt  = ITK_ask_cli_argument("-i=");
	f = ITK_ask_cli_argument("-f=");
	//sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);

	char	*sFrmRpl;
	char	*sToRpl;

	int		n_Input = 3;
	int		nPrtCnt = 0;
	int		n_Cnt = 0;
	int		iPCnt = 0;
	int		bl_qty_form = 0;
	int		brkdncnt = 0;
	int		solnobjcnt = 0;
	int		modulecnt = 0;
	char	*values[2];
//	char	*values[1];
	char	*qry_Input[2] = {"Item ID", "Revision"};
	//char	*qry_Input[1] = {"Part Type"};
	tag_t	QryPrt = NULLTAG;
	tag_t	tPrt = NULLTAG;
	tag_t	*tpPrtObjs = NULLTAG;

	char	*sPrtVal = NULL;
	char	*sPrtRev = NULL;
	char	*sPrtTyp = NULL;
	char	*sCPartNum = NULL;
	char	*sCPartRvSq = NULL;
	char	*sCPartQty = NULL;
	char	*FileName = NULL;

	tag_t	window = NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t	tChld = NULLTAG;
	tag_t	*children = NULLTAG;
	tag_t	rel_type = NULLTAG;
	tag_t	rel_type1 = NULLTAG;
	tag_t	rel_type2 = NULLTAG;
	tag_t*	brkdnobjs = NULLTAG;
	tag_t*	solnobjs = NULLTAG;
	tag_t	brkdnobj = NULLTAG;
	tag_t	solnobj = NULLTAG;
	tag_t*  moduleno = NULLTAG;
    tag_t modulelatestrev = NULLTAG;

	logical lIsQtyModified = false;

	time_t temp; 
    struct tm *timeptr; 
    char pAccessDate[30];
	char *sCurrentDate = NULL;
	char *sCurrentDateDup = NULL;
	char *strToBereplaceddate;
	char *strToBeUsedInsteaddate;
	char *brkdnobjname = NULL;
	char *vehicleno = NULL;
	char *vehrevseq = NULL;
	
	char *modulenoname = NULL;
    char *modulerevseq = NULL;
	FILE *fptr;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	FileName =(char *) MEM_alloc(150);
	sCurrentDate =(char *) MEM_alloc(30);
	sCurrentDateDup =(char *) MEM_alloc(30);
	strToBereplaceddate = (char*)malloc(5);
	strToBeUsedInsteaddate = (char*)malloc(5);



	printf("\n kk.Querying all ECU Modules\n"); fflush(stdout);

	values[0] = sOpt;
	values[1] = f;


//
//	tag_t dataset_rel_type=NULLTAG;			
//	int DsCnt=0;
//	tag_t* datasetobj1=NULLTAG;
//	tag_t Datasetobj3=NULLTAG;
	tag_t part=NULLTAG;
	tag_t objTag=NULLTAG;
//	char* Dataset_name=NULL;
//	int NR_count=0;
//	tag_t* Named_ref=NULLTAG;
//	int i=0;
//	int k=0;
//	int j=0;
//	tag_t Named_ref_obj=NULLTAG;
	tag_t TagQryContObj=NULLTAG;
//	char* NR_Filename=NULL;
//
char* objectname=NULL;



			tag_t dataset_rel_type=NULLTAG;			
			int DsCnt=0;
			tag_t* datasetobj1=NULLTAG;
			tag_t Datasetobj3=NULLTAG;
			char* Dataset_name=NULL;
			int NR_count=0;
			tag_t* Named_ref=NULLTAG;
			int atk=0;
			tag_t Named_ref_obj=NULLTAG;
			tag_t TagQryContObjdataseln=NULLTAG;
			char* NR_Filename=NULL;
			char		*errordataset				= NULL;	
	   //   errordataset	=(char* )malloc( 500 * sizeof (char));	       
			errordataset = (char *)MEM_alloc(500);



		int	n_entriesd_dataln = 2;
		int n_found_dataln = 0;

		char *qry_entries_dataln[2] = {"SYSCD", "SUBSYSCD"};
		char *qry_values_dataln[2] = {"EE_dataln", "datasetvalidation"};
		tag_t *cntr_objects_dataln =NULLTAG;

	      printf("\n Dataset Space and Length validation Start");fflush(stdout);
		  if(QRY_find2("ControlObjQry", &TagQryContObj));
		if(QRY_execute(TagQryContObj,n_entriesd_dataln,qry_entries_dataln, qry_values_dataln, &n_found_dataln, &cntr_objects_dataln));
		printf("\n Dataset Space and Length validation Start ControlObjQry == %d", n_found_dataln);fflush(stdout);

		if(n_found_dataln>0)
		{
		
		
			printf("\n dmlNo : %s \n",sOpt);fflush(stdout);
			printf("\n rev : %s \n",f);fflush(stdout);

		ITK_CALL(ITEM_find_item(sOpt,&part));
		

		ITK_CALL(ITEM_find_revision(part,f,&objTag));


			if(objTag)
			{
			


							   //    objTag=tpPrtObjs[iPCnt];
				   ITK_CALL(AOM_ask_value_string(objTag,"object_name",&objectname));
				   printf("\n objectname  : %s", objectname);fflush(stdout); 





				   			  ITK_CALL(GRM_find_relation_type("IMAN_specification", &dataset_rel_type));
			  ITK_CALL(GRM_list_secondary_objects_only(objTag,dataset_rel_type,&DsCnt,&datasetobj1));
			  printf("\n sec Object Found : %d", DsCnt);fflush(stdout);
				
				if(DsCnt>0)
				  {
					  for( atk=0; atk<DsCnt; atk++)
					  {
						 printf("\n checking dataset");fflush(stdout);
						 Datasetobj3=datasetobj1[atk];
						 Dataset_name=(char *) MEM_alloc(100);
						 ITK_CALL(AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name));
						  
						 printf("\n dataset name : %s", Dataset_name);fflush(stdout);  		
						 printf("\nchecking for Named ref file");fflush(stdout);
						 ITK_CALL(AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref));
						   
						 printf("\n named ref found :%d=",NR_count);fflush(stdout); 
						 
						 if(NR_count>0)
						  { 

							 printf("\n checking named references\n");fflush(stdout);
						//	 j=0;
						 //    while(j<NR_count)
						 //    { 
								// printf("\n+++++++++++++++++\nloop start:%d NR_count:%d\n",j);fflush(stdout);   
								 tag_t Named_ref_obj=NULLTAG;  
							//	 char   NR_Filename[IMF_filename_size_c + 1]; 
								 AE_reference_type_t     reftype2; 
								 char *file_type = NULL;
								 char* NR_Filename=NULL; 
								 ITK_CALL(AE_find_dataset_named_ref2(Datasetobj3,0,&file_type,&reftype2,&Named_ref_obj));
								 ITK_CALL(IMF_ask_original_file_name2(Named_ref_obj,&NR_Filename)); 
								 printf("\n checking file:%s type:%s",NR_Filename,file_type);fflush(stdout);  
								 

								 int length = strlen(NR_Filename);
								 printf("\n file length : %d \n",length);fflush(stdout);
								  if(length > 100)
								  {

									 tc_strcpy(errordataset,"");
									 tc_strcat(errordataset,"dataset length should be less than 100 character: ");
									 tc_strcat(errordataset,NR_Filename);

									  printf("\n At. Inside dataset length validation : %s",NR_Filename);fflush(stdout);

									/*  EMH_clear_errors();
									  EMH_store_error_s1(EMH_severity_error,ITK_err,errordataset);

									  return ITK_err;*/
									  printf("\n %s",errordataset);fflush(stdout);
									
									}
								
							
									if (strchr(NR_Filename,' ')) 
									{ 

										 tc_strcpy(errordataset,"");
										 tc_strcat(errordataset,"While creating file name (dataset) there should be no space in it: ");
										 tc_strcat(errordataset,NR_Filename);
										
										/* printf("\n At. Inside dataset space validation : %s",NR_Filename);fflush(stdout);
										 EMH_clear_errors();
										 EMH_store_error_s1(EMH_severity_error,ITK_err,errordataset);
										 return ITK_err;*/
										 printf("\n %s",errordataset);fflush(stdout);
																	
									}
								 
								 printf("\n loop end +++++++++++++++++");fflush(stdout);   
						//	 }
						
						  }

					 }
					  printf("\n Dataset Space and Length validation End");fflush(stdout);
				 }
				   





































//					 ITK_CALL(GRM_find_relation_type("IMAN_specification", &dataset_rel_type));
//				  ITK_CALL(GRM_list_secondary_objects_only(objTag,dataset_rel_type,&DsCnt,&datasetobj1));
//				  printf("\n sec Object Found : %d", DsCnt);fflush(stdout);
//				if(DsCnt>0)
//				{
//				  for( i=0; i<DsCnt; i++)
//				  {
//					 printf("\n checking dataset");fflush(stdout);
//					 Datasetobj3=datasetobj1[i];
//					 Dataset_name=(char *) MEM_alloc(100);
//					 ITK_CALL(AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name));
//					  
//					 printf("\n dataset name : %s", Dataset_name);fflush(stdout);  		
//					 printf("\nchecking for Named ref file");fflush(stdout);
//					 ITK_CALL(AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref));
//					   
//					 printf("\n named ref found :%d=",NR_count);fflush(stdout); 
//					 
//					 if(NR_count>0)
//					  { 
//
//						 printf("\n checking named references\n======================\n");fflush(stdout);
//						 j=0;
//					 //    while(j<NR_count)
//					//     { 
//							 printf("\n+++++++++++++++++\nloop start:%d NR_count:%d\n",j);fflush(stdout);   
//							 tag_t Named_ref_obj=NULLTAG;  
//						//	 char   NR_Filename[IMF_filename_size_c + 1]; 
//							 AE_reference_type_t     reftype2; 
//							 char *file_type = NULL;
//							 char* NR_Filename=NULL; 
//							 ITK_CALL(AE_find_dataset_named_ref2(Datasetobj3,0,&file_type,&reftype2,&Named_ref_obj));
//							 ITK_CALL(IMF_ask_original_file_name2(Named_ref_obj,&NR_Filename)); 
//							 printf("\n checking file:%s type:%s",NR_Filename,file_type);fflush(stdout);  
//							 
//
//							 int length = strlen(NR_Filename);
//							 printf("\n file length : %d \n",length);fflush(stdout);
//							  if(length > 100)
//							  {
//
//									printf("\n At. Inside dataset length validation : %s",NR_Filename);fflush(stdout);
//								/*	EMH_clear_errors();
//									EMH_store_error_s1(EMH_severity_error,ITK_err,"dataset length should be less than 100 character");
//									return ITK_err;*/
//								
//							  }
//							
//						
//							 if (strchr(NR_Filename,' ')) 
//							 { 
//								 printf("\n file name Contains space :%s", NR_Filename);fflush(stdout); 
//								 printf("\n At. Inside dataset Space validation : %s",NR_Filename);fflush(stdout);
//							/*	EMH_clear_errors();
//								EMH_store_error_s1(EMH_severity_error,ITK_err,"While creating file name (dataset) there should be no space in it");
//								return ITK_err;*/
//								 
//								
//							 }
//							 
//							 printf("\n loop end +++++++++++++++++");fflush(stdout);   
//						// }
//					
//				}
//
//
//				}
//			}
			



						
						printf("\n ************************************************************************* \n");
					 
					//}
				//}
			}

       }//co
	   else
		{
		   printf("\n Control object is of for  Dataset Space and Length validation for EE Part\n");fflush(stdout);
		}
     
	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

/*	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

