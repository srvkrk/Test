/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*,char*,char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");


		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				count	 				= 0;
	
	char 			*item_id				= NULL;
	char 			*rev_id					= NULL;
	char 			*partNumber					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				item_id = strtok(temp, ",");
				printf("\nInput DML:%s",item_id);

				partNumber = strtok(NULL, ",");
				printf("\nInput partNumber:%s",partNumber);

				rev_id = strtok(NULL, ",");
				printf("\nInput rev_id:%s",rev_id);
				
				ifail = check_rel_status(item_id,partNumber,rev_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       check_rel_status
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int check_rel_status(char* item_id,char* partNumber,char* rev_id)
{


	tag_t *attachments	   = NULLTAG;
	tag_t DMLTaskTag	   = NULLTAG;
	tag_t rootTask		   = NULLTAG;
	char *CurrentTask		= NULL;
	char *BusUnitDV			= NULL;
	char *DMLDRdvp			= NULL;
	char *dmlNo             =NULL;
	char* DMLtype		    = NULL;
	char* Taskobj_type	    = NULL;
	char *TskNmMdm			=  NULL;
	char  *Partnumber       = NULL;
	char   *Prt_object_type =NULL;
	char *DatasetName	    = NULL;
	char  *mdmclass_name;
		
	char		   *firsttok      =NULL;
	 char		   *secondtok	  =NULL;
	 char		   *thirdtok	  =NULL;
	 char		   *forthtok	  =NULL;
	
	tag_t    Cciditemrev   = NULLTAG;
	
	char    *str		    = NULL;
	tag_t	*DMLObj		    = NULLTAG;
	int ifail;
	int status;
	int iStatus			=0;
	char	*Rel_type   = NULL;
	char*  SnapshotId		= NULL; 

	tag_t	MdmDMLRevTag		= NULLTAG;
	tag_t	ProQryObj			= NULLTAG;
	tag_t	ProQryContObj		= NULLTAG;
	tag_t   MdmDMLToTaskRel	    = NULLTAG;
	tag_t	MdmDML_tag			= NULLTAG;
	tag_t   class_id            =NULLTAG;
	tag_t  *MdmTsk_objects	    = NULLTAG;
	tag_t  *MdmPartsTag          =NULLTAG;
	tag_t	Mdm_tsk_rel		    = NULLTAG;
	tag_t	DesignrMdmTag		= NULLTAG;
	tag_t	part_tsk_relc		    = NULLTAG;
	tag_t	 HasRefCCIDRelTypen		 = NULLTAG;
	tag_t*	attccidTag		 = NULLTAG;
	tag_t	latest_Cciditem	= NULLTAG;
	tag_t	 HasSnapshotType	  = NULLTAG;
	tag_t  *SnapTag		      = NULLTAG;
	tag_t	ProQrySSObj			= NULLTAG;
	tag_t	*snapObj		  = NULLTAG;
	tag_t*	 snapchild				= NULL;
	tag_t	 SnChild			  = NULLTAG;
	tag_t	CcidADDTag		= NULLTAG;
	
	int     noAttachment      = 0;
	int     Mdmtsk_cnt		  = 0;
	int     tt		          = 0;
	int     partcnt		       = 0;
	int     sn		       = 0;

	char* username				= NULL;
	char* parent_name			= NULL;
	char* dmlTaskNo			= NULL;
	char* AddPartnumber       = NULL;
	char* PartItemIdSn       =NULL;
	 char* PartItemRevIdSn   =NULL;

	char*	 OldSnapshotNo				 = NULL;
	int		newccidcnt			= 0;
	int		AttachmentCount	    = 0;
	int		partcntrf	        = 0;
	int		pr					= 0;
	int		attccidcnt     = 0;
	int SnapCnt =0;
	int		icnt     = 0;
	int		iy     = 0;
	char*	 CCIDNo= NULL;
	char*	 CCIDNoRev= NULL;
	char   *PartRevID =NULL;
	int		CCID 	        = 0;
	int		snapcount 	        = 0;
	int SnpshotSeq = 0;
	int UpdatedSeq =0;
	char	NewSnapshotSeq[20];
	char	*qry_Input1[1]	  = {"Name"};
 	char	*values1[1];
	char*	 Cciditem_rev			 = NULL;
	int		n_Input1					 = 1;
	int		SnapshotCount     = 0;
	int		in     = 0;
	int		zr     = 0;
	int		partaddcnt	= 0;
	tag_t  *addPartsTag          =NULLTAG;
	tag_t   *PartsTagrf       = NULLTAG;
	tag_t	 Part_tobeAdd	    = NULLTAG;
	tag_t	DesignrevTagR	 = NULLTAG;
	tag_t	des_rel_tag	 = NULLTAG;
	tag_t *ccidTagrf=NULLTAG;

	int		count			=0;
	tag_t	item_tag		= NULLTAG;
	tag_t	eepart_tag		= NULLTAG;
	tag_t	eepartrev_tag		= NULLTAG;
	tag_t	*rev_list		= NULL;
	char* ErrorText =NULL;
	char* eepart =NULL;
	logical lispartfound;

		//////////////////
char	*selecVCID = NULL;
char	*selecVCIDrev = NULL;
char	*tempRev_ID = NULL;
fflush(NULL);



char	*FileName = NULL;
//char     *f        =   NULL;
FileName =(char *) MEM_alloc(150);
FILE *fptr;

//	  ifail=AOM_ask_value_string(itemrev_tagc,"item_id",&selecVCID);
//	  ifail=AOM_ask_value_string(itemrev_tagc,"item_revision_id",&selecVCIDrev);
	  




	/////////////////////

	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_list_all_revs (item_tag, &count, &rev_list);
	CHECK_FAIL;	

	if(count>0)
	{
		printf("\n Inside for --PartReplace_DML DMLworkflow - Target Attachment:%d \n",noAttachment);fflush(stdout);
		DMLTaskTag = rev_list[0];
		if(AOM_ask_value_string(DMLTaskTag,"item_id",&dmlTaskNo)!=ITK_ok)PrintErrorStack();
		printf("\n PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout); 
		if(ITEM_find_item(dmlTaskNo, &MdmDML_tag)!=ITK_ok)PrintErrorStack();
		if (MdmDML_tag != NULLTAG)
		{
			printf("\n DML tag is not null for PartReplace_DML DMLworkflow - DML No: [%s] \n", dmlTaskNo);fflush(stdout);
			if(ITEM_ask_latest_rev(MdmDML_tag, &MdmDMLRevTag)!=ITK_ok)PrintErrorStack();

			ITK_CALL(AOM_ask_value_string(MdmDMLRevTag,"item_id",&dmlNo));
			printf("\n PartReplace_DML DML number for :%s \n",dmlNo);fflush(stdout);

			ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &MdmDMLToTaskRel));
			ITK_CALL(GRM_list_secondary_objects_only(MdmDMLRevTag,MdmDMLToTaskRel,&Mdmtsk_cnt,&MdmTsk_objects));

			printf("\n Finding the PartReplace_DML Task count is -- %d \n",Mdmtsk_cnt);fflush(stdout);
			if (Mdmtsk_cnt>0)
			{
				printf("\n Inside task count for PartReplace_DML --- %d \n" ,Mdmtsk_cnt); fflush(stdout);
				 for (in=0;in<Mdmtsk_cnt ;in++ )
				 {
					 lispartfound=false;
						 printf("\n Now inside the task find as Task count is for PartReplace_DML-- %d \n",Mdmtsk_cnt);fflush(stdout);
						 ITK_CALL(AOM_ask_value_string(MdmTsk_objects[in],"object_type",&Taskobj_type));
						 printf("\n Now PartReplace_DML -Taskobj_type is :%s \n",Taskobj_type);fflush(stdout);
						 
						 ITK_CALL(AOM_UIF_ask_value(MdmTsk_objects[in],"item_id",&TskNmMdm));
						 printf("\n Now PartReplace_DML -Task name  is :%s \n",TskNmMdm);fflush(stdout);


						 if(tc_strcmp(TskNmMdm,partNumber)==0)
						 {

						//	  GRM_find_relation_type(relation_type_name[ii],&des_rel_typ);
							 GRM_find_relation(MdmDMLRevTag,MdmTsk_objects[in],MdmDMLToTaskRel,&des_rel_tag);
							 ITK_CALL(GRM_delete_relation(des_rel_tag));											                                                          
							 GRM_save_relation(des_rel_tag);
							 lispartfound=true;
						 }

						 if (lispartfound=true)
						 {
							 	if(tc_strstr(partNumber,"_") != NULL)
								 {
									eepart=strtok(partNumber,"_");
									printf("\n eepart =====> [%s]", eepart);fflush(stdout); //getting dml number here

									ifail = ITEM_find_item (eepart, &eepart_tag);
									ITK_CALL(ITEM_find_revision(eepart_tag,rev_id,&eepartrev_tag));								
									GRM_create_relation(MdmDMLRevTag,eepartrev_tag,MdmDMLToTaskRel,NULLTAG,&des_rel_tag);
									GRM_save_relation(des_rel_tag);
									printf("\n eepart Relation creation succesful=====> [%s]", eepart);fflush(stdout);

								 }

						 }


				 }// for loop for Mdmtsk_cnt ends

			}// if for Mdmtsk_cnt ends

		}// if ends for MdmDML_tag

	}// if ends for count 

	return ifail;
}
