/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: IR_checklist.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
**  IR_checklist -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


read_value_from_info(proj);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -p=<project name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* proj					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	proj 			= ITK_ask_cli_argument("-pc=");
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(proj)) == 0)
	{
		print_requirement();
		return -1;
	}
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ifail = ITK_auto_login();

	ITK_CALL(ITK_set_journalling( TRUE ));

	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
/*	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/
	
		ifail = read_value_from_info(proj);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_info(char* prj)
{
	printf("\nkk.Input Option is [%s]",prj); fflush(stdout);

    char *info1CCID			 = NULL;
	char *info2CCID			 = NULL;
	char *info3CCID			 = NULL;
	char *info4CCID			 = NULL;
	char *info5CCID			 = NULL;
	char *info6CCID			 = NULL;
	char *info7CCID			 = NULL;
	char *info8CCID			 = NULL;
	char *info9CCID			 = NULL;
	char *info10CCID			 = NULL;
	char* finalInfoCCID       = NULL;
	finalInfoCCID = (char *) MEM_alloc(5000 * sizeof(char *));
    tc_strcpy(finalInfoCCID,"");
	int     i=0;
	int		n_Input = 2;
	int		ctlobjcnt = 0;
	char	*values[2];
	char	*qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	
	tag_t	QryPrt = NULLTAG;
	tag_t	*ctlobjs = NULL;

	


	printf("\nkk.Querying all Control objects\n"); fflush(stdout);

//	values[0] = "CCID";
//	values[1] = "PROJCT";

    values[0] = "ECU";
	values[1] = "OTAModify";

  

	if(QRY_find2("Control Objects...", &QryPrt));
	if(QryPrt)
	{
		if(QRY_execute(QryPrt, n_Input, qry_Input, values, &ctlobjcnt, &ctlobjs));
		printf("\n control object count is [%d]\n", ctlobjcnt);fflush(stdout);

		if(ctlobjcnt>0)
		{
			

         finalInfoCCID=Getcontrolobjinfo(ctlobjs,ctlobjcnt);

		}

		printf("\n\t finalInfoCCID string value After concat: %s\n \n",finalInfoCCID);



	}
	
	return 0;
}



int Getcontrolobjinfo(tag_t* ctlobjs,int ctlobjcnt)
{
	char *info1CCID			 = NULL;
	char *info2CCID			 = NULL;
	char *info3CCID			 = NULL;
	char *info4CCID			 = NULL;
	char *info5CCID			 = NULL;
	char *info6CCID			 = NULL;
	char *info7CCID			 = NULL;
	char *info8CCID			 = NULL;
	char *info9CCID			 = NULL;
	char *info10CCID			 = NULL;
	char* finalInfoCCID       = NULL;
	int CheckFlag =0;
    int i=0;

	finalInfoCCID = (char *) MEM_alloc(10000 * sizeof(char *));
	TC_write_syslog("\n start:Getcontrolobjinfo.");
    for(i =0;i < ctlobjcnt;i++)
	{
		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo1",&info1CCID));
		printf("\n info1CCID Project Codes List [%s]",info1CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo2",&info2CCID));
		printf("\n info2CCID Project Codes List [%s]",info2CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo3",&info3CCID));
		printf("\n info3CCID Project Codes List [%s]",info3CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo4",&info4CCID));
		printf("\n info4CCID Project Codes List [%s]",info4CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo5",&info5CCID));
		printf("\n info5CCID Project Codes List [%s]",info5CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo6",&info6CCID));
		printf("\n info6CCID Project Codes List [%s]",info6CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo7",&info7CCID));
		printf("\n info7CCID Project Codes List [%s]",info7CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo8",&info8CCID));
		printf("\n info8CCID Project Codes List [%s]",info8CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_Userinfo9",&info9CCID));
		printf("\n info9CCID Project Codes List [%s]",info9CCID); fflush(stdout);

		ITK_CALL(AOM_ask_value_string(ctlobjs[i],"t5_userinfo10",&info10CCID));
		printf("\n info10CCID Project Codes List [%s]",info10CCID); fflush(stdout);


		if(info1CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info1CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info2CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info2CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info3CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info3CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info4CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info4CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info5CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info5CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info6CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info6CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info7CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info7CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info8CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info8CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info9CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info9CCID);
			tc_strcat(finalInfoCCID,",");
		}
		if(info10CCID != NULL)
		{
			tc_strcat(finalInfoCCID,info10CCID);
			tc_strcat(finalInfoCCID,",");
		}

	}



  return finalInfoCCID;
}
