#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//s#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include <ics/ics2.h>
//#include<ics/iman_ics.h>

int status;

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);


char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
//char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char *inputfile=NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
 
{
 
		int ifail;
	 
	//	int status;
	 
		int iStatus=0;

		(void)argc;
	 
		(void)argv;

		initialise();

		sUsr  = ITK_ask_cli_argument("-u=");
	 
		spass  = ITK_ask_cli_argument("-pf=");
	 
		sDB  = ITK_ask_cli_argument("-g=");
	//	inputfile = ITK_ask_cli_argument("-i=");

		iStatus = ITK_auto_login();

		if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	 
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	 
		ITK_CALL(ITK_set_journalling( TRUE ));


	//	logical lIsQtyModified = false;

		time_t temp;
	 
		struct tm *timeptr;
	 
		char pAccessDate[30];
	 
		char *sCurrentDate = NULL;
	 
		char *sCurrentDateDup = NULL;
	 
		char *strToBereplaceddate;
	 
		char *strToBeUsedInsteaddate;
		char	*tplid = NULL;
	 
		char	*sPrtRev = NULL;
		char	*FileName = NULL;

		FILE *fptr;

	 
		FileName =(char *) MEM_alloc(150);
	 
		sCurrentDate =(char *) MEM_alloc(30);
	 
		sCurrentDateDup =(char *) MEM_alloc(30);
	 
		strToBereplaceddate = (char*)malloc(5);
	 
		strToBeUsedInsteaddate = (char*)malloc(5);
		
		time(&temp);
	 
		timeptr = localtime(&temp );
	 
		tc_strcpy(pAccessDate,"");
	 
		strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
	 
		tc_strcpy(sCurrentDate,pAccessDate);
	 
		tc_strcpy(strToBereplaceddate,"/");
	 
		tc_strcpy(strToBeUsedInsteaddate,"-");

		ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);
	 
		//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
	 
		printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

		tc_strcpy(FileName,"ParaDescUpdate");
	 
		tc_strcat(FileName,sCurrentDateDup);
	 
		tc_strcat(FileName,"_log.csv");

		printf("kk.log file name is : [%s]\n",FileName);

		fptr = fopen(FileName,"w");

		if(fptr==NULL)
	 
		{
	 
			printf("Error! in log File opening!!!");  fflush(stdout);
	 
			exit(1);
	 
		}


//fprintf(fptr,"%s,%s,%s,%s","Hardware Part Number","ECU Name/Type","ECU ABRR NAME","Containers");fflush(fptr);
fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s","paradesc","name","ECUType","Vendor","Version","dataType","Unit","legth","DID,Applicable","Readable","Remark");fflush(fptr);


								   //partTag=Hardware
								   tag_t ctlobjtag=NULLTAG;
								   tag_t ecuCtrObj=NULLTAG;
								   tag_t* ecuCtrObjs=NULLTAG;
									int	n_entriesMdm = 1;
									int	icnt = 0;
									int n_foundMdm = 0;
									int p = 0;
									char *qry_entriesMdm[1] = {"Name"};
									char *qry_valuesMdm[1]  = {"*"};
									
									 char* 	paradesc 					= NULL;
									 char* 	name 					= NULL;
									 char* 	ECUType 					= NULL;
									 char* 	Vendor 					= NULL;
									 char* 	Version 					= NULL;
									 char* 	dataType 					= NULL;
									 char* 	Unit 					= NULL;
									 char* 	legth 					= NULL;
									 char* 	DID 					= NULL;
									 char* 	Applicable 					= NULL;
									 char* 	Readable 					= NULL;
									 char* checkedout		    = NULL;
									 

								   if(QRY_find2("EEPara", &ctlobjtag));

								   if(QRY_execute(ctlobjtag, n_entriesMdm, qry_entriesMdm, qry_valuesMdm, &n_foundMdm, &ecuCtrObjs));
								   printf("\n Control Object found for Para Desc Updation == %d \n", n_foundMdm);fflush(stdout);

									if(n_foundMdm >0)
									{
										for(icnt=0;icnt<n_foundMdm;icnt++)
										 {
											ecuCtrObj=ecuCtrObjs[icnt];
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_t5EPDesc",&paradesc));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"object_name",&name));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_ECUType",&ECUType));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_ECUVendor",&Vendor));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_ECUVersion",&Version));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPType",&dataType));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPUnit",&Unit));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPLen",&legth));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPDidValue",&DID));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPApplicable",&Applicable));
											ITK_CALL(AOM_ask_value_string(ecuCtrObj,"t5_EPReadable",&Readable));

											printf("\n paradesc ----- [%s]",paradesc); fflush(stdout);
											printf("\n name ----- [%s]",name); fflush(stdout);
											printf("\n ECUType ----- [%s]",ECUType); fflush(stdout);
											printf("\n Vendor ----- [%s]",Vendor); fflush(stdout);
											printf("\n Version ----- [%s]",Version); fflush(stdout);
											printf("\n dataType ----- [%s]",dataType); fflush(stdout);
											printf("\n Unit ----- [%s]",Unit); fflush(stdout);
											printf("\n legth ----- [%s]",legth); fflush(stdout);
											printf("\n DID ----- [%s]",DID); fflush(stdout);
											printf("\n Applicable ----- [%s]",Applicable); fflush(stdout);
											printf("\n Readable ----- [%s]",Readable); fflush(stdout);
											

											int		len = 0;

											len = strlen(paradesc);

											

											

											if (len == 0)
											{
												ITK_CALL(AOM_UIF_ask_value(ecuCtrObj,"checked_out",&checkedout));
				                                printf("\n checkedout :%s \n",checkedout);fflush(stdout);

												if (tc_strcmp(checkedout,"Y")==0)
											    {
												fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",paradesc,name,ECUType,Vendor,Version,dataType,Unit,legth,DID,Applicable,Readable,"Pending due to check out");fflush(fptr);
											    }
											    else
												{
												 printf("\n paradesc is empty so Updating..."); fflush(stdout);
												 ITK_CALL(AOM_refresh(ecuCtrObj,1));
												 ITK_CALL(AOM_set_value_string(ecuCtrObj,"t5_t5EPDesc",name));
												 ITK_CALL(AOM_save_without_extensions( ecuCtrObj) )
											     ITK_CALL(AOM_refresh(ecuCtrObj,0));
												 fprintf(fptr,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",paradesc,name,ECUType,Vendor,Version,dataType,Unit,legth,DID,Applicable,Readable,"Para Desc Updated");fflush(fptr);

												}
											}
										  

										 }

									 }


							
							

                printf("===============================================================================================\n");
			//	}
		//}

	ITK_exit_module(true);

	return status;
	 
	}

	static void initialise (void)
	 
	{
	 
		int ifail;

		/* <kc> pr#397778 July2595 exit if autologin() fail */
	 
		if ((ifail = ITK_auto_login()) != ITK_ok)
	 
		   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	 
		CHECK_FAIL;

		/* these tokens come from bom_attr.h */
	 
		initialise_attribute (bomAttr_lineName, &name_attribute);
	 
		initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	 

	 
		CHECK_FAIL;
	 
	}

	static void initialise_attribute (char *name,  int *attribute)
	 
	{
	 
		int ifail, mode;


	 
		CHECK_FAIL;
	 
	
	 
	}


	

//50081139L 5008113916L^ 5008113916L_R1 A;1
//28800242R^2880024216R^ 2880024216R_R1 A;1
//50080455L^5008035516L^ 5008035516L_R1 A;1
 