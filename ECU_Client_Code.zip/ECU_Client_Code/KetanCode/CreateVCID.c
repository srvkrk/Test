#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
//static void initialise_attribute (char *name,  int *attribute);

char *sVCIDNum = NULL;
char *sVCIDRev = NULL;
char *sPurpose = NULL;
char *sTitle = NULL;
char *sDRSt = NULL;
char *sDMLNum = NULL;
char *sAppl = NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sVCIDNum  = ITK_ask_cli_argument("-vcid=");
	sVCIDRev = ITK_ask_cli_argument("-rev=");
	sPurpose = ITK_ask_cli_argument("-prps=");
	sTitle = ITK_ask_cli_argument("-titl=");
	sDRSt = ITK_ask_cli_argument("-dr=");
	sDMLNum = ITK_ask_cli_argument("-dml=");
	sAppl = ITK_ask_cli_argument("-appl=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	char *sVCIDTyp = NULL;
	tag_t tVCIDMstr = NULLTAG;
	tag_t tVCIDRev = NULLTAG;
	tag_t tFndVCIDM = NULLTAG;
	
	//sCmp_Report =(char *) MEM_alloc(150);

	printf("\nkk.Input details are.. \n [VCID:%s]\n[Rev:%s]\n[Baseline Puspose:%s]\n[Baseline Title:%s]\n[DR status:%s]\n[DML Number:%s]\n[Applicability:%s]\n",sVCIDNum,sVCIDRev,sPurpose,sTitle,sDRSt,sDMLNum,sAppl); fflush(stdout);
	
	ITK_CALL(ITEM_find_item(sVCIDNum,&tFndVCIDM));
	if(tFndVCIDM != NULLTAG)
	{
		ITK_CALL(AOM_ask_value_string(tFndVCIDM,"object_type",&sVCIDTyp));
		printf("\nkk.VCID [%s,%s] is already created!!!\n",sVCIDNum,sVCIDTyp); fflush(stdout);
	}
	else
	{
		printf("\nkk.Creating VCID [%s]\n",sVCIDNum); fflush(stdout);
		ITK_CALL(ITEM_create_item(sVCIDNum,sVCIDNum,"T5_CCID","A;1",&tVCIDMstr,&tVCIDRev));
		
		if(tVCIDRev != NULLTAG)
		{
			AOM_set_value_string(tVCIDRev,"object_desc",sPurpose);
			AOM_set_value_string(tVCIDRev,"object_name",sTitle);
			AOM_set_value_string(tVCIDRev,"t5_CCIDDRStatus",sDRSt);
			AOM_set_value_string(tVCIDRev,"t5_CCIDApplicability",sAppl);
			
			//TODO: create VCID's relation with DML & Part rev
			AOM_save_without_extensions(tVCIDRev);
			printf("\nkk.Values updated.\n"); fflush(stdout);
		}
	}
		
	printf("\nkk.VCID creation code completed.\n"); fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}


