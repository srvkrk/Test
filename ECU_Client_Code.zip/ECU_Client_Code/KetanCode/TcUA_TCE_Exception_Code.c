#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>
#include <pie/pie.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sPart			=   NULL;
char	* sRevSeq		=   NULL;
//char	* sAttrName		=   NULL;
//char	* sAttrVal		=   NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

struct EcuBomStrut
{
	tag_t child_objs;//CHild
	int child_objs_lvl;//LVL
	char *child_obj_name;//Name
	char *child_obj_rev;//Rev;Seq
	char *child_sw_typ;//S/W Part Type
}*get_EcuBomStrut;

struct ConData
{
	char *Part;
	char *RvSq;
	char *EcuTyp;
	char *SwTyp;
	char *Appl;
	char *RdWrt;
	char *SpKit;
	char *HsPar;
	char *MstSlv;
}*get_ConData;

struct ParClause
{
	char *ParName;//item_id
	char *ParDesc;//t5_t5EPDesc
	char *Appl;//t5_EPApplicable
	char *RdWrt;//t5_EPReadable
	char *DataTyp;//t5_EPType
	char *DidVal;//t5_EPDidValue
	char *Length;//t5_EPLen
	char *Unit;//t5_EPUnit
	char *UsrVal;//t5_BitValue
	
}*get_ParClause;

struct ParData
{
	char *Part;
	char *RvSq;
	char *EcuTyp;
	char *SwTyp;
	char *Appl;
	char *RdWrt;
	struct ParClause *ParCls;
	int ParClsSize;
}*get_ParData;

struct DataSet
{
	char *DtSet;
	char *NmRef;
}*get_DataSet;

struct SwData
{
	char *Part;
	char *RvSq;
	char *EcuTyp;
	char *SwTyp;
	char *Appl;
	char *RdWrt;
	struct DataSet *Set;
	int DtSetSize;
}*get_SwData;

int EcuBomFindPart(struct EcuBomStrut arEcuBomStrut[],int* iStChldCnt,char *sChkPrt)
{
	int iPCnt = 0;
	printf("\nkk.checking Part [%s] in set of [%d] parts.",sChkPrt,*iStChldCnt);fflush(stdout);
	for(iPCnt=0; iPCnt<=*iStChldCnt; ++iPCnt)
	{
		if(tc_strcmp(arEcuBomStrut[iPCnt].child_obj_name,sChkPrt)==0)
		{
			return 1;
		}
	}
	return 0;
}

int stFindConPart(struct ConData arConData[],int nConPrtCnt,char *sFndPrt)
{
	int iPCnt = 0;
	for(iPCnt=0; iPCnt<nConPrtCnt; ++iPCnt)
	{
		if(tc_strcmp(arConData[iPCnt].Part,sFndPrt)==0)
		{
			return iPCnt;
		}
	}
	return -1;
}

int stFindParPart(struct ParData arParData[],int nParPrtCnt,char *sFndPrt)
{
	int iPCnt = 0;
	//printf("\nkk.checking Part [%s] in set of [%d] parts.",sChkPrt,*iStChldCnt);fflush(stdout);
	for(iPCnt=0; iPCnt<nParPrtCnt; ++iPCnt)
	{
		if(tc_strcmp(arParData[iPCnt].Part,sFndPrt)==0)
		{
			return iPCnt;
		}
	}
	return -1;
}

int stFindSwPart(struct SwData arSwData[],int nSwPrtCnt,char *sFndPrt)
{
	int iPCnt = 0;
	//printf("\nkk.checking Part [%s] in set of [%d] parts.",sChkPrt,*iStChldCnt);fflush(stdout);
	for(iPCnt=0; iPCnt<nSwPrtCnt; ++iPCnt)
	{
		if(tc_strcmp(arSwData[iPCnt].Part,sFndPrt)==0)
		{
			return iPCnt;
		}
	}
	return -1;
}

void GetParPrts(tag_t pPrt,struct EcuBomStrut arEcuBomStrut[],int iStChldCnt,char **sCnParPrts)
{
	int ifail;
	int nPrcnt = 0;
	int iPp = 0;
	int iStCnt = 0;
	char *sPrPrt = NULL;
	char *sPrRev = NULL;
	char *sPrSw = NULL;
	char *sStPrtTyp = NULL;
	char *sStPrt = NULL;
	char *sPrTyp = NULL;
	char *sTmp = NULL;
	char *sFrmRpl = NULL;
	char *sToRpl = NULL;
	char *sPrRevSeq = NULL;
	tag_t ConParRel_type = NULLTAG;
	tag_t *tpPrPrts = NULLTAG;
	
	sTmp = (char *) MEM_alloc(50);
	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	
	ifail = GRM_find_relation_type("T5_ContHasPara",&ConParRel_type); 
	if(ConParRel_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(pPrt,ConParRel_type,&nPrcnt,&tpPrPrts));
		CHECK_FAIL;
		printf("\nkk.Number of Con-Par relations are [%d]",nPrcnt);fflush(stdout);
		if(nPrcnt>0)
		{
			for(iPp=0; iPp<nPrcnt; ++iPp)
			{
				ITKCALL(AOM_ask_value_string(tpPrPrts[iPp],"item_id",&sPrPrt));
				ITKCALL(AOM_ask_value_string(tpPrPrts[iPp],"item_revision_id",&sPrRev));
				ITKCALL(AOM_ask_value_string(tpPrPrts[iPp],"object_type",&sPrTyp));
				if(tc_strcmp(sPrTyp,"T5_EE_PartRevision")==0)
				{
					ITKCALL(AOM_ask_value_string(tpPrPrts[iPp],"t5_SwPartType",&sPrSw));
					
					for(iStCnt=0; iStCnt<=iStChldCnt; ++iStCnt)
					{
						//pStPrt = arEcuBomStrut[iStCnt].child_objs;
						ITKCALL(AOM_ask_value_string(arEcuBomStrut[iStCnt].child_objs,"object_type", &sStPrtTyp));
						if(tc_strcmp(sStPrtTyp,"T5_EE_PartRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(arEcuBomStrut[iStCnt].child_objs,"t5_SwPartType",&sStPrt));
							if(tc_strcmp(sPrSw,sStPrt)==0 && tc_strcmp(sPrPrt,arEcuBomStrut[iStCnt].child_obj_name)==0 && tc_strcmp(sPrRev,arEcuBomStrut[iStCnt].child_obj_rev)==0)
							{
								printf("\nkk.Con-Par Rel Found.");fflush(stdout);
								tc_strcpy(sFrmRpl,";");
								tc_strcpy(sToRpl,"_");
								ifail =STRNG_replace_str(sPrRev,sFrmRpl,sToRpl,&sPrRevSeq); 
								tc_strcpy(sTmp,sPrPrt);
								tc_strcat(sTmp,"_");
								tc_strcat(sTmp,sPrRevSeq);
								if(tc_strcmp(*sCnParPrts,"NA")==0)
								{
									tc_strcpy(*sCnParPrts,sTmp);
								}
								else
								{
									tc_strcat(*sCnParPrts,";");
									tc_strcat(*sCnParPrts,sTmp);
								}
							}
						}
					}
				}
			}
		}
	}
}

void GetSlavePrts(tag_t pPrt,struct EcuBomStrut arEcuBomStrut[],int iStChldCnt,char **sSlavePrts)
{
	int ifail;
	int iStCnt = 0;
	int iSp = 0;
	int nSlvcnt = 0;
	char *sSlPrt = NULL;
	char *sSlRev = NULL;
	char *sSlSw = NULL;
	char *sStPrt = NULL;
	char *sStPrtTyp = NULL;
	char *sTmp = NULL;
	char *sFrmRpl = NULL;
	char *sToRpl = NULL;
	char *sSlRevSeq = NULL;
	//tag_t pStPrt = NULLTAG;
	tag_t MstrSlvRel_type = NULLTAG;
	tag_t *tpSlvPrts = NULLTAG;
	
	sTmp = (char *) MEM_alloc(50);
	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	
	ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvRel_type); 
	if(MstrSlvRel_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(pPrt,MstrSlvRel_type,&nSlvcnt,&tpSlvPrts));
		CHECK_FAIL;
		printf("\nkk.Number of Slave containers are [%d]",nSlvcnt);fflush(stdout);
		if(nSlvcnt>0)
		{
			for(iSp=0; iSp<nSlvcnt; ++iSp)
			{
				ITKCALL(AOM_ask_value_string(tpSlvPrts[iSp],"item_id",&sSlPrt));
				ITKCALL(AOM_ask_value_string(tpSlvPrts[iSp],"item_revision_id",&sSlRev));
				ITKCALL(AOM_ask_value_string(tpSlvPrts[iSp],"t5_SwPartType",&sSlSw));
				
				for(iStCnt=0; iStCnt<=iStChldCnt; ++iStCnt)
				{
					//pStPrt = arEcuBomStrut[iStCnt].child_objs;
					ITKCALL(AOM_ask_value_string(arEcuBomStrut[iStCnt].child_objs,"object_type", &sStPrtTyp));
					if(tc_strcmp(sStPrtTyp,"T5_EE_PartRevision")==0)
					{
						ITKCALL(AOM_ask_value_string(arEcuBomStrut[iStCnt].child_objs,"t5_SwPartType",&sStPrt));
						if(tc_strcmp(sSlSw,sStPrt)==0 && tc_strcmp(sSlPrt,arEcuBomStrut[iStCnt].child_obj_name)==0 && tc_strcmp(sSlRev,arEcuBomStrut[iStCnt].child_obj_rev)==0)
						{
							printf("\nkk.Slave containers Found [%s].",sSlPrt);fflush(stdout);
							tc_strcpy(sFrmRpl,";");
							tc_strcpy(sToRpl,"_");
							ifail =STRNG_replace_str(sSlRev,sFrmRpl,sToRpl,&sSlRevSeq); 
							tc_strcpy(sTmp,sSlPrt);
							tc_strcat(sTmp,"_");
							tc_strcat(sTmp,sSlRevSeq);
							if(tc_strcmp(*sSlavePrts,"NA")==0)
							{
								tc_strcpy(*sSlavePrts,sTmp);
							}
							else
							{
								tc_strcat(*sSlavePrts,";");
								tc_strcat(*sSlavePrts,sTmp);
							}
						}
					}
				}
			}
		}
	}
}

void ECU_BOM_Explosion(tag_t top_line,int reqLevel,int level,struct EcuBomStrut arEcuBomStrut[],int* iStChldCnt)
{
	int nClRlFound = 0;
	char** sClRlName = NULL;
	char** sClRlVal = NULL;
	tag_t b_window = NULLTAG;
	tag_t tRevRule = NULLTAG;
	tag_t tModTopLine = NULLTAG;
	tag_t tClRlObj = NULLTAG;
	tag_t* tpClRlObj = NULLTAG;
	
	int nChPrtCnt = 0;
	int iIfPartInList = 0;
	int iChtemTag = 0;
	int iChCnt = 0;
	tag_t* tpChPrtObjs = NULLTAG;
	tag_t tChItemRev = NULLTAG;
	
	char *sChPartNum = NULL;
	char *sChPartRev = NULL;
	char *sChObjTyp = NULL;
	char *sChPartSW = NULL;
	char *sPrPartNum = NULL;
	char *sPrPartRev = NULL;
	char *sPrObjTyp = NULL;
	char *sPrPartSW = NULL;
	char *sNAVal = NULL;
	
	sNAVal = (char*)malloc(5);
	
	tc_strcpy(sNAVal,"NA");
	
	if( level >= reqLevel )
	{
		return;
	}
	
	if (level==0)
	{
		if(BOM_create_window (&b_window)!=ITK_ok)PrintErrorStack();
		if(CFM_find( "ERC release and above", &tRevRule )!=ITK_ok)PrintErrorStack();
		if(BOM_set_window_config_rule( b_window, tRevRule )!=ITK_ok)PrintErrorStack();
		if(BOM_set_window_pack_all (b_window, true)!=ITK_ok)PrintErrorStack();
		if(BOM_set_window_top_line (b_window, NULLTAG, top_line, NULLTAG, &tModTopLine)!=ITK_ok)PrintErrorStack();
		if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &nClRlFound, &tpClRlObj )!=ITK_ok)   PrintErrorStack();
		if(nClRlFound>0)
		{
			tClRlObj = tpClRlObj[0];
			ITKCALL(AOM_ask_value_string(tModTopLine, "bl_item_item_id", &sPrPartNum));
			ITKCALL(AOM_ask_value_string(tModTopLine, "bl_rev_item_revision_id", &sPrPartRev));
			ITKCALL(AOM_ask_value_string(tModTopLine, "bl_item_object_type", &sPrObjTyp));
			ITKCALL(AOM_ask_value_string(tModTopLine, "bl_T5_EE_PartRevision_t5_SwPartType", &sPrPartSW));
			//ITKCALL(AOM_ask_value_string(top_line, "item_id", &sPrPartNum));
			//ITKCALL(AOM_ask_value_string(top_line, "item_revision_id", &sPrPartRev));
			//ITKCALL(AOM_ask_value_string(top_line, "object_type", &sPrObjTyp));
			//ITKCALL(AOM_ask_value_string(top_line, "t5_SwPartType", &sPrPartSW));
			printf("\nkk. Parent Part is [%s,%s,%s,%s]",sPrPartNum,sPrPartRev,sPrObjTyp,sPrPartSW);fflush(stdout);
			*iStChldCnt = *iStChldCnt+1;
			//arEcuBomStrut[*iStChldCnt].child_objs = tClRlObj;
			arEcuBomStrut[*iStChldCnt].child_objs = top_line;
			arEcuBomStrut[*iStChldCnt].child_objs_lvl = level;
			arEcuBomStrut[*iStChldCnt].child_obj_name = sPrPartNum;
			arEcuBomStrut[*iStChldCnt].child_obj_rev = sPrPartRev;
			arEcuBomStrut[*iStChldCnt].child_sw_typ = sNAVal;
			
			if(BOM_window_set_closure_rule(b_window,tClRlObj, 0, sClRlName,sClRlVal )!=ITK_ok)   PrintErrorStack();
			//if(BOM_line_ask_child_lines (tModTopLine, &nChPrtCnt, &tpChPrtObjs));
		}
		if(BOM_line_ask_child_lines (tModTopLine, &nChPrtCnt, &tpChPrtObjs));
	}
	else
	{
		if(BOM_line_ask_child_lines (top_line, &nChPrtCnt, &tpChPrtObjs));
	}
	for(iChCnt=0; iChCnt<nChPrtCnt; ++iChCnt)
	{
		BOM_line_unpack (tpChPrtObjs[iChCnt]);
		//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChtemTag);
		//BOM_line_ask_attribute_tag(tpChPrtObjs[iChCnt], iChtemTag, &tChItemRev);
		AOM_ask_value_tag(tpChPrtObjs[iChCnt], bomAttr_lineItemRevTag, &tChItemRev);
		if(tChItemRev!=NULLTAG)
		{
			iIfPartInList = 0;
			ITKCALL(AOM_ask_value_string(tChItemRev, "item_id", &sChPartNum));
			ITKCALL(AOM_ask_value_string(tChItemRev, "item_revision_id", &sChPartRev));
			ITKCALL(AOM_ask_value_string(tChItemRev, "object_type", &sChObjTyp));
			ITKCALL(AOM_ask_value_string(tChItemRev, "t5_SwPartType", &sChPartSW));
			printf("\nkk.Part is [%s,%s,%s,%s]",sChPartNum,sChPartRev,sChObjTyp,sChPartSW);fflush(stdout);
			iIfPartInList = EcuBomFindPart(arEcuBomStrut,iStChldCnt,sChPartNum);
			if(iIfPartInList == 0)
			{
				*iStChldCnt = *iStChldCnt+1;
				arEcuBomStrut[*iStChldCnt].child_objs = tChItemRev;
				arEcuBomStrut[*iStChldCnt].child_objs_lvl = level;
				arEcuBomStrut[*iStChldCnt].child_obj_name = sChPartNum;
				arEcuBomStrut[*iStChldCnt].child_obj_rev = sChPartRev;
				if(tc_strcmp(sChObjTyp,"T5_EE_PartRevision")==0)
				{
					arEcuBomStrut[*iStChldCnt].child_sw_typ = sChPartSW;
				}
				else
				{
					arEcuBomStrut[*iStChldCnt].child_sw_typ = sNAVal;
				}
				level = level + 1;
				
				ECU_BOM_Explosion(tpChPrtObjs[iChCnt],reqLevel,level,arEcuBomStrut,iStChldCnt);
			}
		}
	}
}

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	//int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sPart  = ITK_ask_cli_argument("-i=");
	sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	//iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Inputs are [%s,%s]",sPart,sRevSeq); fflush(stdout);

	char* sRvSq = NULL;
	char* sRv_Sq = NULL;
	char	*sFrmRpl;
	char	*sToRpl;
	int		n_Input = 3;
	int		nPrtCnt = 0;
	char	*qry_Input[3] = {"Item ID", "Type", "Revision"};
	tag_t	*tpPrtObjs = NULL;
	tag_t	QryPrt = NULLTAG;
	char	*values[3];
	tag_t	tPrt = NULLTAG;
	int iStCnt = 0;
	char *sPrtTyp = NULL;
	char *sPrtSWTyp = NULL;
	char *sOwnr = NULL;
	char *sPrtEcuTyp = NULL;
	char *sPrtAppl = NULL;
	char *sPrtRdWrt = NULL;
	tag_t pStPrt = NULLTAG;
	char *sSlvPrts = NULL;
	char *sParPrts = NULL;
	
	int nDtCnt = 0;
	int nClsCnt = 0;
	int iDCnt = 0;
	int iPCnt = 0;
	int iSCnt  = 0;
	int iFCnt = 0;
	int iTCnt = 0;
	char *sDtSetTyp = NULL;
	char *sDtSetName = NULL;
	//char refname[AE_reference_size_c + 1];
	char *refname = NULL;
	AE_reference_type_t reftype;
	//char nmRefName[IMF_filename_size_c + 1];
	char *nmRefName = NULL;
	tag_t nmRefObj = NULLTAG;
	tag_t DtSetRel = NULLTAG;
	tag_t EErelation_type = NULLTAG;
	tag_t tDtSet = NULLTAG;
	tag_t tParCls = NULLTAG;
	tag_t tParClsRel = NULLTAG;
	tag_t *tpDtSet = NULLTAG;
	tag_t *tpParCls = NULLTAG;
	
	char *sPrtParName = NULL;
	char *sPrtParNameTr = NULL;
	char *sPrtParDec = NULL;
	char *sPrtParAppl = NULL;
	char *sPrtParRdWrt = NULL;
	char *sPrtParDt = NULL;
	char *sPrtParDid = NULL;
	char *sPrtParLen = NULL;
	char *sPrtParUnit = NULL;
	char *sPrtParDefVal = NULL;
	char *sCallSh = NULL;
	
	int indx = -1;
	int nTClCnt = 0;
	int nTDtCnt = 0;
	char *sPrt = NULL;
	char *sTClCnt = NULL;
	char *sTDtCnt = NULL;
	char *sTmp = NULL;
	char *sTemp = NULL;
	
	char *sRs = NULL;
	char *sEcu = NULL;
	char *sSw = NULL;
	char *sAppl = NULL;
	char *sRW = NULL;
	char *sSP = NULL;
	char *sPar = NULL;
	char *sSlv = NULL;
	
	char *sPName = NULL;
	char *sPDesc = NULL;
	char *sPAppl = NULL;
	char *sPRW = NULL;
	char *sPDT = NULL;
	char *sPDid = NULL;
	char *sPLen = NULL;
	char *sPUnt = NULL;
	char *sPUsrVal = NULL;
	
	char *sPDS = NULL;
	char *sPNmRf = NULL;
	
	char *sNAVal = NULL;
				
	char	*FileName_con = NULL;
	char	*FileName_par = NULL;
	char	*FileName_sw = NULL;
	FILE	*fptr_con;
	FILE	*fptr_par;
	FILE	*fptr_sw;
	
	char	*FileName_con_tce = NULL;
	char	*FileName_par_tce = NULL;
	char	*FileName_sw_tce = NULL;
	FILE	*fptr_read_con;
	FILE	*fptr_read_par;
	FILE	*fptr_read_sw;
	
	char *FileName_con_mis = NULL;
	char *FileName_par_mis = NULL;
	char *FileName_sw_mis = NULL;
	FILE	*fptr_mis_con;
	FILE	*fptr_mis_par;
	FILE	*fptr_mis_sw;
	
	char *sHead = NULL;
	char *sTce = NULL;
	char *sTcUA = NULL;
	char *sHPRevSeq = NULL;
	char *sDsgnPrts = NULL;
	
	char sTcePar[5];
	char sTcuaPar[5];
	
	int nSKCnt = 0;
	char *sSpKitPart = NULL;
	tag_t spkit_rel = NULLTAG;
	tag_t *tpSKObjs = NULLTAG;
	
	
	logical lMisFound = false;
	logical lFileFound = false;
	logical lParFound = false;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	sNAVal = (char*)malloc(5);
	sTemp = (char*)MEM_alloc(25);
	FileName_con =(char *) MEM_alloc(150);
	FileName_par =(char *) MEM_alloc(150);
	FileName_sw =(char *) MEM_alloc(150);
	FileName_con_tce =(char *) MEM_alloc(150);
	FileName_par_tce =(char *) MEM_alloc(150);
	FileName_sw_tce =(char *) MEM_alloc(150);
	FileName_con_mis =(char *) MEM_alloc(150);
	FileName_par_mis =(char *) MEM_alloc(150);
	FileName_sw_mis =(char *) MEM_alloc(150);
	sHead =(char *) MEM_alloc(1000);
	sTce =(char *) MEM_alloc(1000);
	sTcUA =(char *) MEM_alloc(1000);
		
	tc_strcpy(sNAVal,"NA");
	int stPrtCnt = -1;
	struct EcuBomStrut stEcuBom[500];
	int stTcUA_Con_Cnt = 0;
	struct ConData stTcUA_Con_Data[100];
	int stTcUA_Sw_Cnt = 0;
	struct SwData stTcUA_Sw_Data[100];
	int stTcUA_Par_Cnt = 0;
	struct ParData stTcUA_Par_Data[100];
	
	int stTCE_Con_Cnt = 0;
	struct ConData stTCE_Con_Data[100];
	int stTCE_Sw_Cnt = 0;
	struct SwData stTCE_Sw_Data[100];
	int stTCE_Par_Cnt = 0;
	struct ParData stTCE_Par_Data[100];

	tc_strcpy(sFrmRpl,";");
	tc_strcpy(sToRpl,"_");
	ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRvSq); 

	tc_strcpy(FileName_con,sPart);
	tc_strcat(FileName_con,"_");
	tc_strcat(FileName_con,sRvSq);
	tc_strcat(FileName_con,"_con.csv");
	printf("kk.Output file name is : [%s]\n",FileName_con);
	fptr_con = fopen(FileName_con,"w");
	if(fptr_con==NULL)
	{
		printf("Error in File [%s] opening!!!",FileName_con);  fflush(stdout);
		exit(1);
	}
	
	tc_strcpy(FileName_par,sPart);
	tc_strcat(FileName_par,"_");
	tc_strcat(FileName_par,sRvSq);
	tc_strcat(FileName_par,"_par.csv");
	printf("kk.Output file name is : [%s]\n",FileName_par);
	fptr_par = fopen(FileName_par,"w");
	if(fptr_par==NULL)
	{
		printf("Error in File [%s] opening!!!",FileName_par);  fflush(stdout);
		exit(1);
	}
	
	tc_strcpy(FileName_sw,sPart);
	tc_strcat(FileName_sw,"_");
	tc_strcat(FileName_sw,sRvSq);
	tc_strcat(FileName_sw,"_sw.csv");
	printf("kk.Output file name is : [%s]\n",FileName_sw);
	fptr_sw = fopen(FileName_sw,"w");
	if(fptr_sw==NULL)
	{
		printf("Error in File [%s] opening!!!",FileName_sw);  fflush(stdout);
		exit(1);
	}
	//fprintf(fptr_con,"Mismatch will be printed here.");fflush(fptr_con);

	if(QRY_find2("Item Revision...", &QryPrt));
	if(QryPrt)
	{
		tc_strcpy(sFrmRpl,";");
		tc_strcpy(sToRpl,"*");
		ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRv_Sq); 

		printf("kk.Querying Part [%s,%s]",sPart,sRv_Sq);fflush(stdout);
		values[0] = sPart;
		values[1] = "Design Revision";
		//values[1] = "EE Part Revision";
		values[2] = sRv_Sq;
		if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObjs));
		printf("kk.Part Size [%d]",nPrtCnt);fflush(stdout);
		if(nPrtCnt>0)
		{
			tPrt = tpPrtObjs[0];
			//1.Get the BOM.
			ECU_BOM_Explosion(tPrt,99,0,stEcuBom,&stPrtCnt);
			printf("kk.Total number of parts from expansion are : [%d]\n",stPrtCnt);
		}
		
		//2.Create con, par, sw struct & files.
		if(stPrtCnt>=0)
		{
			for(iStCnt=0; iStCnt<=stPrtCnt; ++iStCnt)
			{
				pStPrt = stEcuBom[iStCnt].child_objs;
				ITKCALL(AOM_ask_value_string(pStPrt,"object_type", &sPrtTyp));
				ITKCALL(AOM_UIF_ask_value(pStPrt,"owning_user", &sOwnr));
				printf("kk.class,owner of part [%s] is [%s,%s]\n",stEcuBom[iStCnt].child_obj_name,sPrtTyp,sOwnr);
				if(tc_strcmp(sPrtTyp,"T5_EE_PartRevision")==0 && tc_strstr(sOwnr,"loader")!=NULL)
				{
					ITKCALL(AOM_ask_value_string(pStPrt,"t5_EcuType", &sPrtEcuTyp));
					ITKCALL(AOM_ask_value_string(pStPrt,"t5_AppForEOL", &sPrtAppl));
					ITKCALL(AOM_ask_value_string(pStPrt,"t5_EPReadable", &sPrtRdWrt));
					ITKCALL(AOM_ask_value_string(pStPrt,"t5_SwPartType",&sPrtSWTyp));
					if(tc_strcmp(sPrtSWTyp,"CON")==0)
					{
						printf("kk.part is Container\n");
						
						stTcUA_Con_Data[stTcUA_Con_Cnt].Part = stEcuBom[iStCnt].child_obj_name;
						stTcUA_Con_Data[stTcUA_Con_Cnt].RvSq = stEcuBom[iStCnt].child_obj_rev;//sNAVal
						if(sPrtEcuTyp != NULL)
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].EcuTyp = sPrtEcuTyp;
						}
						else
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].EcuTyp = sNAVal;
						}
						if(sPrtSWTyp != NULL)
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].SwTyp = sPrtSWTyp;
						}
						else
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].SwTyp = sNAVal;
						}
						if(sPrtAppl != NULL)
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].Appl = sPrtAppl;
						}
						else
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].Appl = sNAVal;
						}
						if(sPrtRdWrt != NULL)
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].RdWrt = sPrtRdWrt;
						}
						else
						{
							stTcUA_Con_Data[stTcUA_Con_Cnt].RdWrt = sNAVal;
						}
						
						ITKCALL(GRM_find_relation_type("T5_HasSpareKit", &spkit_rel));
						if(spkit_rel != NULLTAG)
						{
							ITKCALL(GRM_list_secondary_objects_only(pStPrt,spkit_rel,&nSKCnt,&tpSKObjs));
							CHECK_FAIL;
							printf("\nkk.No of spkit obj found [%d]",nSKCnt); fflush(stdout);
							if(nSKCnt > 0)
							{
								if(AOM_ask_value_string(tpSKObjs[0],"item_id",&sSpKitPart)!=ITK_ok);
								stTcUA_Con_Data[stTcUA_Con_Cnt].SpKit = sSpKitPart;
							}
							else
							{
								stTcUA_Con_Data[stTcUA_Con_Cnt].SpKit = sNAVal;
							}
						}
						
						//Get ConHasPar parts
						sParPrts = NULL;
						sParPrts =(char *) MEM_alloc(8000);
						tc_strcpy(sParPrts,"NA");
						GetParPrts(pStPrt,stEcuBom,stPrtCnt,&sParPrts);
						//if(sParPrts != NULL)
						//{
						printf("\nkk.Con has Par part is [%s]\n",sParPrts);
						stTcUA_Con_Data[stTcUA_Con_Cnt].HsPar = sParPrts;
						//}
						//Get Slave parts
						sSlvPrts = NULL;
						sSlvPrts =(char *) MEM_alloc(8000);
						tc_strcpy(sSlvPrts,"NA");
						GetSlavePrts(pStPrt,stEcuBom,stPrtCnt,&sSlvPrts);
						//if(sSlvPrts != NULL)
						//{
						printf("\nkk.Slave Containers are [%s]\n",sSlvPrts);
						stTcUA_Con_Data[stTcUA_Con_Cnt].MstSlv = sSlvPrts;
						//}
						stTcUA_Con_Cnt++;
						fprintf(fptr_con,"%s,%s\n",stEcuBom[iStCnt].child_obj_name,stEcuBom[iStCnt].child_obj_rev);fflush(fptr_con);
					}
					else if(tc_strcmp(sPrtSWTyp,"PRM")==0)
					{
						printf("kk.part is Parameter\n");
						stTcUA_Par_Data[stTcUA_Par_Cnt].Part = stEcuBom[iStCnt].child_obj_name;
						stTcUA_Par_Data[stTcUA_Par_Cnt].RvSq = stEcuBom[iStCnt].child_obj_rev;
						if(sPrtEcuTyp != NULL)
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].EcuTyp = sPrtEcuTyp;
						}
						else
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].EcuTyp = sNAVal;
						}
						if(sPrtSWTyp != NULL)
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].SwTyp = sPrtSWTyp;
						}
						else
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].SwTyp = sNAVal;
						}
						if(sPrtAppl != NULL)
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].Appl = sPrtAppl;
						}
						else
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].Appl = sNAVal;
						}
						if(sPrtRdWrt != NULL)
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].RdWrt = sPrtRdWrt;
						}
						else
						{
							stTcUA_Par_Data[stTcUA_Par_Cnt].RdWrt = sNAVal;
						}
						stTcUA_Par_Data[stTcUA_Par_Cnt].ParClsSize = 0;
						
						ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type); 
						if(EErelation_type != NULLTAG)
						{
							ifail = GRM_list_secondary_objects_only(pStPrt,EErelation_type,&nClsCnt,&tpParCls);
							printf("\nkk.Number of Parameter Clauses attached are [%d]\n",nClsCnt); fflush(stdout);	
							if(nClsCnt>0)
							{
								stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls = (struct ParClause *)malloc(nClsCnt * sizeof(struct ParClause));
								stTcUA_Par_Data[stTcUA_Par_Cnt].ParClsSize = nClsCnt;
								for(iPCnt=0; iPCnt<nClsCnt; ++iPCnt)
								{
									tParCls = tpParCls[iPCnt];
									
									ITKCALL(AOM_ask_value_string(tParCls,"item_id",&sPrtParName));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_t5EPDesc",&sPrtParDec));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPApplicable",&sPrtParAppl));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPReadable",&sPrtParRdWrt));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPType",&sPrtParDt));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPDidValue",&sPrtParDid));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPLen",&sPrtParLen));
									ITKCALL(AOM_ask_value_string(tParCls,"t5_EPUnit",&sPrtParUnit));
									ifail = GRM_find_relation(pStPrt,tParCls,EErelation_type,&tParClsRel);
									ITKCALL(AOM_ask_value_string(tParClsRel,"t5_BitValue",&sPrtParDefVal));
									if(sPrtParName != NULL)
									{
										tc_strcpy(sFrmRpl,",");
										tc_strcpy(sToRpl," ");
										ifail =STRNG_replace_str(sPrtParName,sFrmRpl,sToRpl,&sPrtParNameTr); 
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].ParName = sPrtParNameTr;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].ParName = sNAVal;
									}
									if(sPrtParDec != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].ParDesc = sPrtParDec;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].ParDesc = sNAVal;
									}
									if(sPrtParAppl != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Appl = sPrtParAppl;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Appl = sNAVal;
									}
									if(sPrtParRdWrt != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].RdWrt = sPrtParRdWrt;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].RdWrt = sNAVal;
									}
									if(sPrtParDt != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].DataTyp = sPrtParDt;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].DataTyp = sNAVal;
									}
									if(sPrtParDid != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].DidVal = sPrtParDid;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].DidVal = sNAVal;
									}
									if(sPrtParLen != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Length = sPrtParLen;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Length = sNAVal;
									}
									if(sPrtParUnit != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Unit = sPrtParUnit;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].Unit = sNAVal;
									}
									if(sPrtParDefVal != NULL)
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].UsrVal = sPrtParDefVal;
									}
									else
									{
										stTcUA_Par_Data[stTcUA_Par_Cnt].ParCls[iPCnt].UsrVal = sNAVal;
									}
								}
							}
						}
						stTcUA_Par_Cnt++;
						fprintf(fptr_par,"%s,%s\n",stEcuBom[iStCnt].child_obj_name,stEcuBom[iStCnt].child_obj_rev);fflush(fptr_par);
					}
					else if(tc_strcmp(sPrtSWTyp,"CAL")==0 || tc_strcmp(sPrtSWTyp,"CFG")==0 || tc_strcmp(sPrtSWTyp,"BAS")==0 || tc_strcmp(sPrtSWTyp,"APP")==0 || tc_strcmp(sPrtSWTyp,"PBL")==0 || tc_strcmp(sPrtSWTyp,"SBL")==0 || tc_strcmp(sPrtSWTyp,"HCL")==0 || tc_strcmp(sPrtSWTyp,"HWC")==0)
					{
						printf("kk.part is Hw/Sw\n");
						stTcUA_Sw_Data[stTcUA_Sw_Cnt].Part = stEcuBom[iStCnt].child_obj_name;
						stTcUA_Sw_Data[stTcUA_Sw_Cnt].RvSq = stEcuBom[iStCnt].child_obj_rev;
						if(sPrtEcuTyp != NULL)
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].EcuTyp = sPrtEcuTyp;
						}
						else
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].EcuTyp = sNAVal;
						}
						if(sPrtSWTyp != NULL)
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].SwTyp = sPrtSWTyp;
						}
						else
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].SwTyp = sNAVal;
						}
						if(sPrtAppl != NULL)
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].Appl = sPrtAppl;
						}
						else
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].Appl = sNAVal;
						}
						if(sPrtRdWrt != NULL)
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].RdWrt = sPrtRdWrt;
						}
						else
						{
							stTcUA_Sw_Data[stTcUA_Sw_Cnt].RdWrt = sNAVal;
						}
						stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize = 0;
						//check if Set=NULL required
						
						//Get DataSetName & Get Named Ref
						if(tc_strcmp(sPrtSWTyp,"HWC")!=0)
						{
							ifail = GRM_find_relation_type("IMAN_specification",&DtSetRel);
							if(DtSetRel != NULLTAG)
							{
								ifail = GRM_list_secondary_objects_only(pStPrt,DtSetRel,&nDtCnt,&tpDtSet);
								printf("\nkk.Number of Dataset(s) attached are [%d]\n",nDtCnt); fflush(stdout);	
								if(nDtCnt>0)
								{
									//stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set = (struct DataSet *)malloc(nDtCnt * sizeof(struct DataSet));
									//stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize = nDtCnt;
									for(iDCnt=0; iDCnt<nDtCnt; ++iDCnt)
									{
										tDtSet = tpDtSet[iDCnt];
										ITKCALL(AOM_ask_value_string(tDtSet,"object_type",&sDtSetTyp));
										if((tc_strcmp(sDtSetTyp,"T5_IndepBin")==0)||(tc_strcmp(sDtSetTyp,"MSWordX")==0)||(tc_strcmp(sDtSetTyp,"MSWord")==0)
										||(tc_strcmp(sDtSetTyp,"MSWordTemplate")==0)||(tc_strcmp(sDtSetTyp,"MSWordTemplateX")==0)||(tc_strcmp(sDtSetTyp,"Text")==0))
										{
											if(stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize == 0)
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set = (struct DataSet *)MEM_alloc(sizeof(struct DataSet));
											}
											else
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set = (struct DataSet *)MEM_realloc(stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set, (stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize+1) * sizeof(struct DataSet));
											}
											stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize++;
											ITKCALL(AOM_ask_value_string(tDtSet,"object_name",&sDtSetName));
											//ifail = AE_find_dataset_named_ref(tDtSet,0,refname,&reftype,&nmRefObj);
											ifail = AE_find_dataset_named_ref2(tDtSet,0,&refname,&reftype,&nmRefObj);
											if(nmRefObj)
											{
												ifail =(IMF_ask_original_file_name2(nmRefObj,&nmRefName));
											}
											printf("\tDataSet name & name ref [%s,%s]\n",sDtSetName,nmRefName); fflush(stdout);
											
											if(sDtSetName != NULL)
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set[iDCnt].DtSet = sDtSetName;
											}
											else
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set[iDCnt].DtSet = sNAVal;
											}
											if(nmRefName != NULL)
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set[iDCnt].NmRef = (char*)MEM_alloc( tc_strlen(nmRefName) *sizeof(char));
												tc_strcpy(stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set[iDCnt].NmRef,nmRefName);
											}
											else
											{
												stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set[iDCnt].NmRef = sNAVal;
											}
										}
									}
								}
							}
						}
						stTcUA_Sw_Cnt++;
						fprintf(fptr_sw,"%s,%s\n",stEcuBom[iStCnt].child_obj_name,stEcuBom[iStCnt].child_obj_rev);fflush(fptr_sw);
					}
				}
				else if(tc_strcmp(sPrtTyp,"T5_EE_PartRevision")!=0 && tc_strstr(stEcuBom[iStCnt].child_obj_name,"K2A0")==NULL && tc_strstr(stEcuBom[iStCnt].child_obj_name,"H1A1")==NULL && tc_strstr(stEcuBom[iStCnt].child_obj_name,"16R")==NULL)
				{
					//Write Part,Rev,class in other file..check if not T5_EE_PartRevision
					printf("\nkk.Design Part found, conversion needed. [%s]\n",stEcuBom[iStCnt].child_obj_name); fflush(stdout);	
					if(sDsgnPrts == NULL)
					{
						sDsgnPrts = (char*)MEM_alloc( 250 *sizeof(char));
						tc_strcpy(sDsgnPrts,stEcuBom[iStCnt].child_obj_name);
						tc_strcat(sDsgnPrts,"_");
						tc_strcat(sDsgnPrts,stEcuBom[iStCnt].child_obj_rev);
					}
					else
					{
						tc_strcat(sDsgnPrts,"-");
						tc_strcat(sDsgnPrts,stEcuBom[iStCnt].child_obj_name);
						tc_strcat(sDsgnPrts,"_");
						tc_strcat(sDsgnPrts,stEcuBom[iStCnt].child_obj_rev);
					}
				}
			}
		}
		
		//3.Load inputs from TCE.
		sCallSh = malloc(500);
		tc_strcpy(sCallSh,"./GetTCEData.sh ");
		tc_strcat(sCallSh,sPart);
		tc_strcat(sCallSh," ");
		tc_strcat(sCallSh,sRvSq);
		printf("\nkk.Calling shell [%s]\n",sCallSh);fflush(stdout);
		system(sCallSh);
		
		tc_strcpy(FileName_con_tce,sPart);
		tc_strcat(FileName_con_tce,"_");
		tc_strcat(FileName_con_tce,sRvSq);
		tc_strcat(FileName_con_tce,"_con_tce.csv");
		printf("kk.Output file name is : [%s]\n",FileName_con_tce);
		fptr_read_con = fopen(FileName_con_tce,"r");
		if(fptr_read_con==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_con_tce);  fflush(stdout);
			exit(1);
		}
		
		tc_strcpy(FileName_par_tce,sPart);
		tc_strcat(FileName_par_tce,"_");
		tc_strcat(FileName_par_tce,sRvSq);
		tc_strcat(FileName_par_tce,"_par_tce.csv");
		printf("kk.Output file name is : [%s]\n",FileName_par_tce);
		fptr_read_par = fopen(FileName_par_tce,"r");
		if(fptr_read_par==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_par_tce);  fflush(stdout);
			exit(1);
		}
		
		tc_strcpy(FileName_sw_tce,sPart);
		tc_strcat(FileName_sw_tce,"_");
		tc_strcat(FileName_sw_tce,sRvSq);
		tc_strcat(FileName_sw_tce,"_sw_tce.csv");
		printf("kk.Output file name is : [%s]\n",FileName_sw_tce);
		fptr_read_sw = fopen(FileName_sw_tce,"r");
		if(fptr_read_sw==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_sw_tce);  fflush(stdout);
			exit(1);
		}
		
		char *sRead_con = NULL;
		char *sRead_par = NULL;
		char *sRead_sw = NULL;
		char *sRead_con_tok = NULL;
		char *sRead_par_tok = NULL;
		char *sRead_sw_tok = NULL;
		sRead_con =(char *) MEM_alloc(8000);
		sRead_par =(char *) MEM_alloc(8000);
		sRead_sw =(char *) MEM_alloc(8000);
		sRead_con_tok =(char *) MEM_alloc(8000);
		sRead_par_tok =(char *) MEM_alloc(8000);
		sRead_sw_tok =(char *) MEM_alloc(8000);
		
		printf("\nkk.Reading con file from TCE."); fflush(stdout);
		while(fgets(sRead_con,8000,fptr_read_con)!=NULL)
		{
			tc_strcpy(sRead_con_tok,sRead_con);
			sPrt = tc_strtok(sRead_con_tok,",");
			printf("\nkk.Part %s.",sPrt); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].Part = (char*)MEM_alloc( tc_strlen(sPrt) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].Part,sPrt);
			sRs = tc_strtok(NULL,",");
			printf("\nkk.Rev Seq %s.",sRs); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].RvSq = (char*)MEM_alloc( tc_strlen(sRs) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].RvSq,sRs);
			sEcu = tc_strtok(NULL,",");
			printf("\nkk.ECU Typ %s.",sEcu); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].EcuTyp = (char*)MEM_alloc( tc_strlen(sEcu) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].EcuTyp,sEcu);
			sSw = tc_strtok(NULL,",");
			printf("\nkk.S/w typ %s.",sSw); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].SwTyp = (char*)MEM_alloc( tc_strlen(sSw) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].SwTyp,sSw);
			sAppl = tc_strtok(NULL,",");
			printf("\nkk.Appl %s.",sAppl); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].Appl = (char*)MEM_alloc( tc_strlen(sAppl) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].Appl,sAppl);
			sRW = tc_strtok(NULL,",");
			printf("\nkk.RdWrite %s.",sRW); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].RdWrt = (char*)MEM_alloc( tc_strlen(sRW) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].RdWrt,sRW);
			sSP = tc_strtok(NULL,",");
			printf("\nkk.Spare Kit %s.",sSP); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].SpKit = (char*)MEM_alloc( tc_strlen(sSP) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].SpKit,sSP);
			sPar = tc_strtok(NULL,",");
			printf("\nkk.has Par part %s.",sPar); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].HsPar = (char*)MEM_alloc( tc_strlen(sPar) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].HsPar,sPar);
			sSlv = tc_strtok(NULL,",");
			printf("\nkk.Master - Slave %s.",sSlv); fflush(stdout);
			stTCE_Con_Data[stTCE_Con_Cnt].MstSlv = (char*)MEM_alloc( tc_strlen(sSlv) *sizeof(char));
			tc_strcpy(stTCE_Con_Data[stTCE_Con_Cnt].MstSlv,sSlv);
			stTCE_Con_Cnt++;
			sPrt = NULL;
			sRs = NULL;
			sEcu = NULL;
			sSw = NULL;
			sAppl = NULL;
			sRW = NULL;
			sSP = NULL;
			sPar = NULL;
			sSlv = NULL;
		}
		
		printf("\nkk.Reading par file from TCE."); fflush(stdout);
		while(fgets(sRead_par,8000,fptr_read_par)!=NULL)
		{
			tc_strcpy(sRead_par_tok,sRead_par);
			sPrt = tc_strtok(sRead_par_tok,",");
			indx = stFindParPart(stTCE_Par_Data,stTCE_Par_Cnt,sPrt);
			printf("\nkk.indx = %d.",indx); fflush(stdout);
			if(indx<0)
			{
				printf("\nkk.Adding Parameter part and clauses."); fflush(stdout);
				stTCE_Par_Data[stTCE_Par_Cnt].Part = (char*)MEM_alloc( tc_strlen(sPrt) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].Part,sPrt);
				sRs = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].RvSq = (char*)MEM_alloc( tc_strlen(sRs) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].RvSq,sRs);
				sEcu = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].EcuTyp = (char*)MEM_alloc( tc_strlen(sEcu) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].EcuTyp,sEcu);
				sSw = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].SwTyp = (char*)MEM_alloc( tc_strlen(sSw) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].SwTyp,sSw);
				sAppl = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].Appl = (char*)MEM_alloc( tc_strlen(sAppl) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].Appl,sAppl);
				sRW = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].RdWrt = (char*)MEM_alloc( tc_strlen(sRW) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].RdWrt,sRW);
				sTClCnt = tc_strtok(NULL,",");
				nTClCnt = atoi(sTClCnt);
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls = (struct ParClause *)malloc(nTClCnt * sizeof(struct ParClause));
				stTCE_Par_Data[stTCE_Par_Cnt].ParClsSize = 0;
				sPName = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].ParName = (char*)MEM_alloc( tc_strlen(sPName) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].ParName,sPName);
				sPDesc = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].ParDesc = (char*)MEM_alloc( tc_strlen(sPDesc) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].ParDesc,sPDesc);
				sPAppl = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Appl = (char*)MEM_alloc( tc_strlen(sPAppl) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Appl,sPAppl);
				sPRW = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].RdWrt = (char*)MEM_alloc( tc_strlen(sPRW) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].RdWrt,sPRW);
				sPDT = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].DataTyp = (char*)MEM_alloc( tc_strlen(sPDT) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].DataTyp,sPDT);
				sPDid = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].DidVal = (char*)MEM_alloc( tc_strlen(sPDid) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].DidVal,sPDid);
				sPLen = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Length = (char*)MEM_alloc( tc_strlen(sPLen) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Length,sPLen);
				sPUnt = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Unit = (char*)MEM_alloc( tc_strlen(sPUnt) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].Unit,sPUnt);
				sPUsrVal = tc_strtok(NULL,",");
				stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].UsrVal = (char*)MEM_alloc( tc_strlen(sPUsrVal) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[stTCE_Par_Cnt].ParCls[0].UsrVal,sPUsrVal);
				stTCE_Par_Data[stTCE_Par_Cnt].ParClsSize++;
				stTCE_Par_Cnt++;
				sPrt = NULL;
				sRs = NULL;
				sEcu = NULL;
				sSw = NULL;
				sAppl = NULL;
				sRW = NULL;
				
				sPName = NULL;
				sPDesc = NULL;
				sPAppl = NULL;
				sPRW = NULL;
				sPDT = NULL;
				sPDid = NULL;
				sPLen = NULL;
				sPUnt = NULL;
				sPUsrVal = NULL;
			}
			else
			{
				printf("\nkk.Adding clauses only."); fflush(stdout);
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sPName = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].ParName = (char*)MEM_alloc( tc_strlen(sPName) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].ParName,sPName);
				sPDesc = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].ParDesc = (char*)MEM_alloc( tc_strlen(sPDesc) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].ParDesc,sPDesc);
				sPAppl = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Appl = (char*)MEM_alloc( tc_strlen(sPAppl) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Appl,sPAppl);
				sPRW = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].RdWrt = (char*)MEM_alloc( tc_strlen(sPRW) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].RdWrt,sPRW);
				sPDT = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].DataTyp = (char*)MEM_alloc( tc_strlen(sPDT) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].DataTyp,sPDT);
				sPDid = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].DidVal = (char*)MEM_alloc( tc_strlen(sPDid) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].DidVal,sPDid);
				sPLen = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Length = (char*)MEM_alloc( tc_strlen(sPLen) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Length,sPLen);
				sPUnt = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Unit = (char*)MEM_alloc( tc_strlen(sPUnt) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].Unit,sPUnt);
				sPUsrVal = tc_strtok(NULL,",");
				stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].UsrVal = (char*)MEM_alloc( tc_strlen(sPUsrVal) *sizeof(char));
				tc_strcpy(stTCE_Par_Data[indx].ParCls[stTCE_Par_Data[indx].ParClsSize].UsrVal,sPUsrVal);
				stTCE_Par_Data[indx].ParClsSize++;
				
				sPName = NULL;
				sPDesc = NULL;
				sPAppl = NULL;
				sPRW = NULL;
				sPDT = NULL;
				sPDid = NULL;
				sPLen = NULL;
				sPUnt = NULL;
				sPUsrVal = NULL;
			}
		}
		
		printf("\nkk.Reading sw file from TCE."); fflush(stdout);
		while(fgets(sRead_sw,8000,fptr_read_sw)!=NULL)
		{
			tc_strcpy(sRead_sw_tok,sRead_sw);
			sPrt = tc_strtok(sRead_sw_tok,",");
			printf("\nkk.Part %s.",sPrt); fflush(stdout);
			indx = stFindSwPart(stTCE_Sw_Data,stTCE_Sw_Cnt,sPrt);
			if(indx<0)
			{
				printf("\nkk.adding SW part entry."); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].Part = (char*)MEM_alloc( tc_strlen(sPrt) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].Part,sPrt);
				sRs = tc_strtok(NULL,",");
				printf("\nkk.Rev Seq %s.",sRs); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].RvSq = (char*)MEM_alloc( tc_strlen(sRs) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].RvSq,sRs);
				sEcu = tc_strtok(NULL,",");
				printf("\nkk.ECU Typ %s.",sEcu); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].EcuTyp = (char*)MEM_alloc( tc_strlen(sEcu) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].EcuTyp,sEcu);
				sSw = tc_strtok(NULL,",");
				printf("\nkk.SW Typ %s.",sSw); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].SwTyp = (char*)MEM_alloc( tc_strlen(sSw) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].SwTyp,sSw);
				sAppl = tc_strtok(NULL,",");
				printf("\nkk.Applicability Typ %s.",sAppl); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].Appl = (char*)MEM_alloc( tc_strlen(sAppl) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].Appl,sAppl);
				sRW = tc_strtok(NULL,",");
				printf("\nkk.Read Write %s.",sRW); fflush(stdout);
				stTCE_Sw_Data[stTCE_Sw_Cnt].RdWrt = (char*)MEM_alloc( tc_strlen(sRW) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].RdWrt,sRW);
				sTDtCnt = tc_strtok(NULL,",");
				nTDtCnt = atoi(sTDtCnt);
				printf("\nkk.Data set size %d.",nTDtCnt); fflush(stdout);
				if(nTDtCnt == 0)
				{
					stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize = nTDtCnt;
				}
				else
				{
					stTCE_Sw_Data[stTCE_Sw_Cnt].Set = (struct DataSet *)MEM_alloc(nTDtCnt * sizeof(struct DataSet));
					stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize = 0;
					sPDS = tc_strtok(NULL,",");
					printf("\nkk.data set name %s.",sPDS); fflush(stdout);
					stTCE_Sw_Data[stTCE_Sw_Cnt].Set[stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize].DtSet = (char*)MEM_alloc( tc_strlen(sPDS) *sizeof(char));
					tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].Set[stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize].DtSet,sPDS);
					sPNmRf = tc_strtok(NULL,",");
					printf("\nkk.file name %s.",sPNmRf); fflush(stdout);
					stTCE_Sw_Data[stTCE_Sw_Cnt].Set[stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize].NmRef = (char*)MEM_alloc( tc_strlen(sPNmRf) *sizeof(char));
					tc_strcpy(stTCE_Sw_Data[stTCE_Sw_Cnt].Set[stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize].NmRef,sPNmRf);
					stTCE_Sw_Data[stTCE_Sw_Cnt].DtSetSize++;
				}
				stTCE_Sw_Cnt++;
				
				sPrt = NULL;
				sRs = NULL;
				sEcu = NULL;
				sSw = NULL;
				sAppl = NULL;
				sRW = NULL;
				
				sPDS = NULL;
				sPNmRf = NULL;
			}
			else
			{
				printf("\nkk.adding File entry only."); fflush(stdout);
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sTmp = tc_strtok(NULL,",");
				sPDS = tc_strtok(NULL,",");
				printf("\nkk.data set name %s.",sPDS); fflush(stdout);
				stTCE_Sw_Data[indx].Set[stTCE_Sw_Data[indx].DtSetSize].DtSet = (char*)MEM_alloc( tc_strlen(sPDS) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[indx].Set[stTCE_Sw_Data[indx].DtSetSize].DtSet,sPDS);
				sPNmRf = tc_strtok(NULL,",");
				printf("\nkk.file name %s.",sPNmRf); fflush(stdout);
				stTCE_Sw_Data[indx].Set[stTCE_Sw_Data[indx].DtSetSize].NmRef = (char*)MEM_alloc( tc_strlen(sPNmRf) *sizeof(char));
				tc_strcpy(stTCE_Sw_Data[indx].Set[stTCE_Sw_Data[indx].DtSetSize].NmRef,sPNmRf);
				stTCE_Sw_Data[indx].DtSetSize++;
				
				sPDS = NULL;
				sPNmRf = NULL;
			}
		}
		
		//4.compare & write mismatch.
		printf("\nPrinting TcUA CON data:[%d]\n",stTcUA_Con_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTcUA_Con_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",stTcUA_Con_Data[iPCnt].Part,stTcUA_Con_Data[iPCnt].RvSq,stTcUA_Con_Data[iPCnt].EcuTyp,stTcUA_Con_Data[iPCnt].SwTyp,stTcUA_Con_Data[iPCnt].Appl,stTcUA_Con_Data[iPCnt].RdWrt,stTcUA_Con_Data[iPCnt].SpKit,stTcUA_Con_Data[iPCnt].HsPar,stTcUA_Con_Data[iPCnt].MstSlv); fflush(stdout);
		}
		printf("\nPrinting TCE CON data:[%d]\n",stTCE_Con_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTCE_Con_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",stTCE_Con_Data[iPCnt].Part,stTCE_Con_Data[iPCnt].RvSq,stTCE_Con_Data[iPCnt].EcuTyp,stTCE_Con_Data[iPCnt].SwTyp,stTCE_Con_Data[iPCnt].Appl,stTCE_Con_Data[iPCnt].RdWrt,stTCE_Con_Data[iPCnt].SpKit,stTCE_Con_Data[iPCnt].HsPar,stTCE_Con_Data[iPCnt].MstSlv); fflush(stdout);
		}
		
		printf("\nPrinting TcUA SW data:[%d]\n",stTcUA_Sw_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTcUA_Sw_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%d\n",stTcUA_Sw_Data[iPCnt].Part,stTcUA_Sw_Data[iPCnt].RvSq,stTcUA_Sw_Data[iPCnt].EcuTyp,stTcUA_Sw_Data[iPCnt].SwTyp,stTcUA_Sw_Data[iPCnt].Appl,stTcUA_Sw_Data[iPCnt].RdWrt,stTcUA_Sw_Data[iPCnt].DtSetSize); fflush(stdout);
			for(iSCnt=0; iSCnt<stTcUA_Sw_Data[iPCnt].DtSetSize; ++iSCnt)
			{
				printf("%s,%s\n",stTcUA_Sw_Data[iPCnt].Set[iSCnt].DtSet,stTcUA_Sw_Data[iPCnt].Set[iSCnt].NmRef); fflush(stdout);
			}
		}
		printf("\nPrinting TCE SW data:[%d]\n",stTCE_Sw_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTCE_Sw_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%d\n",stTCE_Sw_Data[iPCnt].Part,stTCE_Sw_Data[iPCnt].RvSq,stTCE_Sw_Data[iPCnt].EcuTyp,stTCE_Sw_Data[iPCnt].SwTyp,stTCE_Sw_Data[iPCnt].Appl,stTCE_Sw_Data[iPCnt].RdWrt,stTCE_Sw_Data[iPCnt].DtSetSize); fflush(stdout);
			for(iSCnt=0; iSCnt<stTCE_Sw_Data[iPCnt].DtSetSize; ++iSCnt)
			{
				printf("%s,%s\n",stTCE_Sw_Data[iPCnt].Set[iSCnt].DtSet,stTCE_Sw_Data[iPCnt].Set[iSCnt].NmRef); fflush(stdout);
			}
		}
		
		printf("\nPrinting TcUA PAR data:[%d]\n",stTcUA_Par_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTcUA_Par_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%d\n",stTcUA_Par_Data[iPCnt].Part,stTcUA_Par_Data[iPCnt].RvSq,stTcUA_Par_Data[iPCnt].EcuTyp,stTcUA_Par_Data[iPCnt].SwTyp,stTcUA_Par_Data[iPCnt].Appl,stTcUA_Par_Data[iPCnt].RdWrt,stTcUA_Par_Data[iPCnt].ParClsSize); fflush(stdout);
			for(iSCnt=0; iSCnt<stTcUA_Par_Data[iPCnt].ParClsSize; ++iSCnt)
			{
				printf("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",stTcUA_Par_Data[iPCnt].ParCls[iSCnt].ParName,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].ParDesc,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].Appl,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].RdWrt,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].DataTyp,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].DidVal,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].Length,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].Unit,stTcUA_Par_Data[iPCnt].ParCls[iSCnt].UsrVal); fflush(stdout);
			}
		}
		printf("\nPrinting TCE PAR data:[%d]\n",stTCE_Par_Cnt); fflush(stdout);
		for(iPCnt=0; iPCnt<stTCE_Par_Cnt; ++iPCnt)
		{
			printf("%s,%s,%s,%s,%s,%s,%d\n",stTCE_Par_Data[iPCnt].Part,stTCE_Par_Data[iPCnt].RvSq,stTCE_Par_Data[iPCnt].EcuTyp,stTCE_Par_Data[iPCnt].SwTyp,stTCE_Par_Data[iPCnt].Appl,stTCE_Par_Data[iPCnt].RdWrt,stTCE_Par_Data[iPCnt].ParClsSize); fflush(stdout);
			for(iSCnt=0; iSCnt<stTCE_Par_Data[iPCnt].ParClsSize; ++iSCnt)
			{
				printf("%s,%s,%s,%s,%s,%s,%s,%s,%s\n",stTCE_Par_Data[iPCnt].ParCls[iSCnt].ParName,stTCE_Par_Data[iPCnt].ParCls[iSCnt].ParDesc,stTCE_Par_Data[iPCnt].ParCls[iSCnt].Appl,stTCE_Par_Data[iPCnt].ParCls[iSCnt].RdWrt,stTCE_Par_Data[iPCnt].ParCls[iSCnt].DataTyp,stTCE_Par_Data[iPCnt].ParCls[iSCnt].DidVal,stTCE_Par_Data[iPCnt].ParCls[iSCnt].Length,stTCE_Par_Data[iPCnt].ParCls[iSCnt].Unit,stTCE_Par_Data[iPCnt].ParCls[iSCnt].UsrVal); fflush(stdout);
			}
		}
		
		tc_strcpy(FileName_con_mis,sPart);
		tc_strcat(FileName_con_mis,"_");
		tc_strcat(FileName_con_mis,sRvSq);
		tc_strcat(FileName_con_mis,"_con_mismatch.csv");
		printf("kk.Mismatch file name is : [%s]\n",FileName_con_mis);fflush(stdout);
		fptr_mis_con = fopen(FileName_con_mis,"w");
		if(fptr_mis_con==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_con_mis);  fflush(stdout);
			exit(1);
		}
		
		tc_strcpy(FileName_par_mis,sPart);
		tc_strcat(FileName_par_mis,"_");
		tc_strcat(FileName_par_mis,sRvSq);
		tc_strcat(FileName_par_mis,"_par_mismatch.csv");
		printf("kk.Mismatch file name is : [%s]\n",FileName_par_mis);fflush(stdout);
		fptr_mis_par = fopen(FileName_par_mis,"w");
		if(fptr_mis_par==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_par_mis);  fflush(stdout);
			exit(1);
		}
		
		tc_strcpy(FileName_sw_mis,sPart);
		tc_strcat(FileName_sw_mis,"_");
		tc_strcat(FileName_sw_mis,sRvSq);
		tc_strcat(FileName_sw_mis,"_sw_mismatch.csv");
		printf("kk.Mismatch file name is : [%s]\n",FileName_sw_mis);fflush(stdout);
		fptr_mis_sw = fopen(FileName_sw_mis,"w");
		if(fptr_mis_sw==NULL)
		{
			printf("Error in File [%s] opening!!!",FileName_sw_mis);  fflush(stdout);
			exit(1);
		}
		
		printf("kk.Checking container mismatch...\n");fflush(stdout);
		if(stTcUA_Con_Cnt > 0 && stTCE_Con_Cnt > 0)
		{
			for(iPCnt=0; iPCnt<stTCE_Con_Cnt; ++iPCnt)
			{
				lMisFound = false;
				tc_strcpy(sHead,",Part,Rev;Seq,");
				tc_strcpy(sTce,"TCE,");
				tc_strcat(sTce,stTCE_Con_Data[iPCnt].Part);
				tc_strcat(sTce,",");
				tc_strcat(sTce,stTCE_Con_Data[iPCnt].RvSq);
				tc_strcat(sTce,",");
				tc_strcpy(sTcUA,"TcUA,");
				tc_strcat(sTcUA,stTCE_Con_Data[iPCnt].Part);
				tc_strcat(sTcUA,",");
				tc_strcat(sTcUA,stTCE_Con_Data[iPCnt].RvSq);
				tc_strcat(sTcUA,",");
				indx = stFindConPart(stTcUA_Con_Data,stTcUA_Con_Cnt,stTCE_Con_Data[iPCnt].Part);
				printf("kk.index val [%d]\n",indx);fflush(stdout);
				if(indx >= 0)
				{
					if(tc_strcmp(stTCE_Con_Data[iPCnt].EcuTyp,stTcUA_Con_Data[indx].EcuTyp) != 0)
					{
						tc_strcat(sHead,"ECU Type,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].EcuTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Con_Data[indx].EcuTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Con_Data[iPCnt].SwTyp,stTcUA_Con_Data[indx].SwTyp) != 0)
					{
						tc_strcat(sHead,"S/W Type,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].SwTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Con_Data[indx].SwTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Con_Data[iPCnt].Appl,stTcUA_Con_Data[indx].Appl) != 0)
					{
						tc_strcat(sHead,"Applicability,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].Appl);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Con_Data[indx].Appl);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Con_Data[iPCnt].RdWrt,stTcUA_Con_Data[indx].RdWrt) != 0)
					{
						tc_strcat(sHead,"Read/Write,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].RdWrt);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Con_Data[indx].RdWrt);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Con_Data[iPCnt].SpKit,stTcUA_Con_Data[indx].SpKit) != 0)
					{
						tc_strcat(sHead,"SpareKit,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].SpKit);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Con_Data[indx].SpKit);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					/*if(tc_strstr(stTcUA_Con_Data[indx].HsPar,stTCE_Con_Data[iPCnt].HsPar) == NULL)
					{
						tc_strcat(sHead,"Con Has Par,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].HsPar);
						tc_strcat(sTce,",");
						//tc_strcat(sTcUA,stTcUA_Con_Data[indx].HsPar);
						tc_strcat(sTcUA,"NA,");
						lMisFound = true;
					}*/
					printf("kk.Container-Parameter relation check.stPrtCnt[%d]\n",stPrtCnt);fflush(stdout);
					for(iStCnt=0; iStCnt<=stPrtCnt; ++iStCnt)
					{
						printf("kk.checking.. [%s,%s]\n",stEcuBom[iStCnt].child_obj_name,stEcuBom[iStCnt].child_sw_typ);fflush(stdout);
						if(tc_strcmp(stEcuBom[iStCnt].child_sw_typ,"PRM")==0)
						{
							printf("kk.Par part found!!\n");fflush(stdout);
							tc_strcpy(sFrmRpl,";");
							tc_strcpy(sToRpl,"_");
							ifail =STRNG_replace_str(stEcuBom[iStCnt].child_obj_rev,sFrmRpl,sToRpl,&sHPRevSeq); 
							tc_strcpy(sTemp,stEcuBom[iStCnt].child_obj_name);
							tc_strcat(sTemp,"_");
							tc_strcat(sTemp,sHPRevSeq);
							printf("kk.Value of temp [%s].\n",sTemp);fflush(stdout);
							if(tc_strstr(stTCE_Con_Data[iPCnt].HsPar,sTemp) != NULL)
							{
								if(tc_strstr(stTcUA_Con_Data[indx].HsPar,sTemp) == NULL)
								{
									tc_strcat(sHead,"Con Has Par,");
									tc_strcat(sTce,sTemp);
									tc_strcat(sTce,",");
									//tc_strcat(sTcUA,stTcUA_Con_Data[indx].HsPar);
									tc_strcat(sTcUA,"NA,");
									lMisFound = true;
								}
							}
						}
					}
					/*if(tc_strstr(stTcUA_Con_Data[indx].MstSlv,stTCE_Con_Data[iPCnt].MstSlv) == NULL)
					{
						tc_strcat(sHead,"Master-Slave,");
						tc_strcat(sTce,stTCE_Con_Data[iPCnt].MstSlv);
						tc_strcat(sTce,",");
						//tc_strcat(sTcUA,stTcUA_Con_Data[indx].MstSlv);
						tc_strcat(sTcUA,"NA,");
						lMisFound = true;
					}*/
					printf("kk.Master-Slave relation check.\n");fflush(stdout);
					for(iStCnt=0; iStCnt<=stPrtCnt; ++iStCnt)
					{
						if(tc_strcmp(stEcuBom[iStCnt].child_sw_typ,"CON")==0)
						{
							tc_strcpy(sFrmRpl,";");
							tc_strcpy(sToRpl,"_");
							ifail =STRNG_replace_str(stEcuBom[iStCnt].child_obj_rev,sFrmRpl,sToRpl,&sHPRevSeq); 
							tc_strcpy(sTemp,stEcuBom[iStCnt].child_obj_name);
							tc_strcat(sTemp,"_");
							tc_strcat(sTemp,sHPRevSeq);
							if(tc_strstr(stTCE_Con_Data[iPCnt].MstSlv,sTemp) != NULL)
							{
								if(tc_strstr(stTcUA_Con_Data[indx].MstSlv,sTemp) == NULL)
								{
									tc_strcat(sHead,"Master-Slave,");
									tc_strcat(sTce,sTemp);
									tc_strcat(sTce,",");
									//tc_strcat(sTcUA,stTcUA_Con_Data[indx].HsPar);
									tc_strcat(sTcUA,"NA,");
									lMisFound = true;
								}
							}
						}
					}
					if(lMisFound)
					{
						printf("kk.Writing con mismatch for part [%s]\n",stTCE_Con_Data[iPCnt].Part);fflush(stdout);
						fprintf(fptr_mis_con,"%s\n",sHead);fflush(fptr_mis_con);
						fprintf(fptr_mis_con,"%s\n",sTce);fflush(fptr_mis_con);
						fprintf(fptr_mis_con,"%s\n\n",sTcUA);fflush(fptr_mis_con);
					}
				}
			}
			if(sDsgnPrts != NULL && tc_strlen(sDsgnPrts)>0)
			{
				fprintf(fptr_mis_con,"\nConvert following parts from Design to EE:\n%s\n",sDsgnPrts);fflush(fptr_mis_con);
			}
		}
		fclose(fptr_mis_con);
		
		printf("kk.Checking software mismatch...\n");fflush(stdout);
		if(stTcUA_Sw_Cnt > 0 && stTCE_Sw_Cnt > 0)
		{
			for(iPCnt=0; iPCnt<stTCE_Sw_Cnt; ++iPCnt)
			{
				lMisFound = false;
				tc_strcpy(sHead,",Part,Rev;Seq,");
				tc_strcpy(sTce,"TCE,");
				tc_strcat(sTce,stTCE_Sw_Data[iPCnt].Part);
				tc_strcat(sTce,",");
				tc_strcat(sTce,stTCE_Sw_Data[iPCnt].RvSq);
				tc_strcat(sTce,",");
				tc_strcpy(sTcUA,"TcUA,");
				tc_strcat(sTcUA,stTCE_Sw_Data[iPCnt].Part);
				tc_strcat(sTcUA,",");
				tc_strcat(sTcUA,stTCE_Sw_Data[iPCnt].RvSq);
				tc_strcat(sTcUA,",");
				indx = stFindSwPart(stTcUA_Sw_Data,stTcUA_Sw_Cnt,stTCE_Sw_Data[iPCnt].Part);
				if(indx >= 0)
				{
					if(tc_strcmp(stTCE_Sw_Data[iPCnt].EcuTyp,stTcUA_Sw_Data[indx].EcuTyp) != 0)
					{
						tc_strcat(sHead,"ECU Type,");
						tc_strcat(sTce,stTCE_Sw_Data[iPCnt].EcuTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Sw_Data[indx].EcuTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Sw_Data[iPCnt].SwTyp,stTcUA_Sw_Data[indx].SwTyp) != 0)
					{
						tc_strcat(sHead,"S/W Type,");
						tc_strcat(sTce,stTCE_Sw_Data[iPCnt].SwTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Sw_Data[indx].SwTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Sw_Data[iPCnt].Appl,stTcUA_Sw_Data[indx].Appl) != 0)
					{
						tc_strcat(sHead,"Applicability,");
						tc_strcat(sTce,stTCE_Sw_Data[iPCnt].Appl);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Sw_Data[indx].Appl);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Sw_Data[iPCnt].RdWrt,stTcUA_Sw_Data[indx].RdWrt) != 0)
					{
						tc_strcat(sHead,"Read/Write,");
						tc_strcat(sTce,stTCE_Sw_Data[iPCnt].RdWrt);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Sw_Data[indx].RdWrt);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					//check all attached files also
					if(stTCE_Sw_Data[iPCnt].DtSetSize > 0)
					{
						for(iFCnt=0; iFCnt<stTCE_Sw_Data[iPCnt].DtSetSize; ++iFCnt)
						{
							lFileFound = false;
							for(iTCnt=0; iTCnt<stTcUA_Sw_Data[indx].DtSetSize; ++iTCnt)
							{
								if(tc_strcmp(stTCE_Sw_Data[iPCnt].Set[iFCnt].DtSet,stTcUA_Sw_Data[indx].Set[iTCnt].DtSet)==0)
								{
									lFileFound = true;
								}
							}
							if(lFileFound == false)
							{
								tc_strcat(sHead,"File,");
								tc_strcat(sTce,stTCE_Sw_Data[iPCnt].Set[iFCnt].DtSet);
								tc_strcat(sTce,",");
								//tc_strcat(sTcUA,stTcUA_Sw_Data[indx].RdWrt);
								tc_strcat(sTcUA,"NA,");
								lMisFound = true;
							}
						}
					}
					if(lMisFound)
					{
						printf("kk.Writing sw mismatch for part [%s]\n",stTCE_Sw_Data[iPCnt].Part);fflush(stdout);
						fprintf(fptr_mis_sw,"%s\n",sHead);fflush(fptr_mis_sw);
						fprintf(fptr_mis_sw,"%s\n",sTce);fflush(fptr_mis_sw);
						fprintf(fptr_mis_sw,"%s\n\n",sTcUA);fflush(fptr_mis_sw);
					}
				}
			}
		}
		fclose(fptr_mis_sw);
		
		printf("kk.Checking parameter mismatch...\n");fflush(stdout);
		if(stTcUA_Par_Cnt > 0 && stTCE_Par_Cnt > 0)
		{
			for(iPCnt=0; iPCnt<stTCE_Par_Cnt; ++iPCnt)
			{
				lMisFound = false;
				tc_strcpy(sHead,",Part,Rev;Seq,");
				tc_strcpy(sTce,"TCE,");
				tc_strcat(sTce,stTCE_Par_Data[iPCnt].Part);
				tc_strcat(sTce,",");
				tc_strcat(sTce,stTCE_Par_Data[iPCnt].RvSq);
				tc_strcat(sTce,",");
				tc_strcpy(sTcUA,"TcUA,");
				tc_strcat(sTcUA,stTCE_Par_Data[iPCnt].Part);
				tc_strcat(sTcUA,",");
				tc_strcat(sTcUA,stTCE_Par_Data[iPCnt].RvSq);
				tc_strcat(sTcUA,",");
				indx = stFindParPart(stTcUA_Par_Data,stTcUA_Par_Cnt,stTCE_Par_Data[iPCnt].Part);
				if(indx >= 0)
				{
					if(tc_strcmp(stTCE_Par_Data[iPCnt].EcuTyp,stTcUA_Par_Data[indx].EcuTyp) != 0)
					{
						tc_strcat(sHead,"ECU Type,");
						tc_strcat(sTce,stTCE_Par_Data[iPCnt].EcuTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Par_Data[indx].EcuTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Par_Data[iPCnt].SwTyp,stTcUA_Par_Data[indx].SwTyp) != 0)
					{
						tc_strcat(sHead,"S/W Type,");
						tc_strcat(sTce,stTCE_Par_Data[iPCnt].SwTyp);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Par_Data[indx].SwTyp);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Par_Data[iPCnt].Appl,stTcUA_Par_Data[indx].Appl) != 0)
					{
						tc_strcat(sHead,"Applicability,");
						tc_strcat(sTce,stTCE_Par_Data[iPCnt].Appl);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Par_Data[indx].Appl);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(tc_strcmp(stTCE_Par_Data[iPCnt].RdWrt,stTcUA_Par_Data[indx].RdWrt) != 0)
					{
						tc_strcat(sHead,"Read/Write,");
						tc_strcat(sTce,stTCE_Par_Data[iPCnt].RdWrt);
						tc_strcat(sTce,",");
						tc_strcat(sTcUA,stTcUA_Par_Data[indx].RdWrt);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					if(stTCE_Par_Data[iPCnt].ParClsSize != stTcUA_Par_Data[indx].ParClsSize)
					{
						tc_strcat(sHead,"Par Count,");
						sprintf(sTcePar,"%d", stTCE_Par_Data[iPCnt].ParClsSize);
						tc_strcat(sTce,sTcePar);
						tc_strcat(sTce,",");
						sprintf(sTcuaPar,"%d", stTcUA_Par_Data[indx].ParClsSize);
						tc_strcat(sTcUA,sTcuaPar);
						tc_strcat(sTcUA,",");
						lMisFound = true;
					}
					//TODO:check for all parameter clauses, all values
					if(stTCE_Par_Data[iPCnt].ParClsSize > 0)
					{
						for(iFCnt=0; iFCnt<stTCE_Par_Data[iPCnt].ParClsSize; ++iFCnt)
						{
							lParFound = false;
							for(iTCnt=0; iTCnt<stTcUA_Par_Data[indx].ParClsSize; ++iTCnt)
							{
								if(tc_strcmp(stTCE_Par_Data[iPCnt].ParCls[iFCnt].ParName,stTcUA_Par_Data[indx].ParCls[iTCnt].ParName)==0)
								{
									lParFound = true;
								}
							}
							if(lParFound == false)
							{
								tc_strcat(sHead,"Par Name,");
								tc_strcat(sTce,stTCE_Par_Data[iPCnt].ParCls[iFCnt].ParName);
								tc_strcat(sTce,",");
								//tc_strcat(sTcUA,stTcUA_Sw_Data[indx].RdWrt);
								tc_strcat(sTcUA,"NA,");
								lMisFound = true;
							}
						}
					}
					if(lMisFound)
					{	
						printf("kk.Writing par mismatch for part [%s]\n",stTCE_Par_Data[iPCnt].Part);fflush(stdout);
						fprintf(fptr_mis_par,"%s\n",sHead);fflush(fptr_mis_par);
						fprintf(fptr_mis_par,"%s\n",sTce);fflush(fptr_mis_par);
						fprintf(fptr_mis_par,"%s\n\n",sTcUA);fflush(fptr_mis_par);
					}
				}
			}
		}
		fclose(fptr_mis_par);
	}
	
	printf("\nkk.Freeing Memory...\n"); fflush(stdout);
	

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	//ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	//ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}
static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

	//ifail = BOM_line_look_up_attribute (name, attribute);	
	CHECK_FAIL;
	/*ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

