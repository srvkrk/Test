#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>
#include <tc/folder.h>


#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
//static void initialise_attribute (char *name,  int *attribute);

char *sInpTPLNum = NULL;

int create_snapshot(tag_t tTPLObj,char* sVCIDSnap,tag_t tVCIDRev,char* Filename);
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sInpTPLNum  = ITK_ask_cli_argument("-tpl=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	int i = 0;
	int iVCnt = 0;
	int iVCCnt = 0;
	int nSnpCnt = 0;
	int nDmlCnt = 0;
	int nPrtCnt = 0;
	int nModCnt = 0;
	int nVcCnt = 0;
	int nVCIDRevCnt = 0;
	logical lIsVCRelFound;
	char *sInputLine = NULL;
	char *sFileRead = NULL;
	char *sVCIDNum = NULL;
	char *sVCIDRev = NULL;
	char *sVCIDSeq = NULL;
	char *sVCIDTitl = NULL;
	char *sVCIDPrps = NULL;
	char *sVCIDFile = NULL;
	char *sTPLNum = NULL;
	char *sTPLRev = NULL;
	char *sTPLSeq = NULL;
	char *sVCIDCtgy = NULL;
	char *sVCIDAppl = NULL;
	char *sVCIDVer = NULL;
	char *sVCIDTyp = NULL;
	char *sVCIDSnap = NULL;
	char *sVCIDSnpTyp = NULL;
	char *sTPLRvSq = NULL;
	char *sRefVCNum = NULL;
	char *sDate = NULL;
	char *sVCs = NULL;
	char *sVCNum = NULL;
	char *sFndVCIDRev = NULL;
	tag_t tFndVCIDM = NULLTAG;
	tag_t tVCIDMstr = NULLTAG;
	tag_t tVCIDRev = NULLTAG;
	tag_t tFndVCIDSnp = NULLTAG;
	tag_t tQrySnap = NULLTAG;
	tag_t *tpSnpObj = NULLTAG;
	tag_t tHsNewVCIDRel = NULLTAG;
	tag_t *tpDmlObj = NULLTAG;
	tag_t tFndDmlM = NULLTAG;
	tag_t tDMLRev = NULLTAG;
	tag_t tNewVCIDRel = NULLTAG;
	tag_t *tpPrtObjs = NULLTAG;
	tag_t tIsMmbrOfVCID = NULLTAG;
	tag_t *tpModObj = NULLTAG;
	tag_t tTPLObj = NULLTAG;
	tag_t tMmbrVCIDRel = NULLTAG;
	tag_t tRefCCVs = NULLTAG;
	tag_t *tpVCs = NULLTAG;
	tag_t tVCItmM = NULLTAG;
	tag_t tRefCCVRel = NULLTAG;
	tag_t *tpVCIDRevs = NULLTAG;
	
	FILE* fptr = NULL;
	
	sFileRead =(char *) MEM_alloc(150);
	sVCIDVer =(char *) MEM_alloc(6);
	sVCIDSnap =(char *) MEM_alloc(25);
	sTPLRvSq =(char *) MEM_alloc(10);

	printf("\nkk.Input TPL is.. \n [%s]\n",sInpTPLNum); fflush(stdout);
	tc_strcpy(sFileRead,sInpTPLNum);
	tc_strcat(sFileRead,".csv");
	fptr=fopen(sFileRead,"r");
	if(fptr == NULL)
	{
		printf("Error! in File opening...%s",sFileRead);  fflush(stdout);
		exit(1);
	}
	
	//ITK_CALL(ITEM_find_item("23CU002011",&tFndDmlM));//CV
	ITK_CALL(ITEM_find_item("14PM503604",&tFndDmlM));//PV
	ITK_CALL(ITEM_ask_latest_rev(tFndDmlM, &tDMLRev));
	
	if(fptr!=NULL)
	{
		sInputLine=(char *) MEM_alloc(1000);
		
		while(fgets(sInputLine,1000,fptr)!=NULL)
		{
			logical Tplfound =false;
			tVCIDRev = NULLTAG;
			for (i = 0; i < strlen(sInputLine); i++)
			{
				if ( sInputLine[i] == '\n' || sInputLine[i] == '\r' )
					sInputLine[i] = '\0';
			}
			sVCIDNum = tc_strtok(sInputLine,"^");
			sVCIDRev = tc_strtok(NULL,"^");
			sVCIDSeq = tc_strtok(NULL,"^");
			sVCIDTitl = tc_strtok(NULL,"^");
			sVCIDPrps = tc_strtok(NULL,"^");
			sVCIDFile = tc_strtok(NULL,"^");
			sTPLNum = tc_strtok(NULL,"^");
			sTPLRev = tc_strtok(NULL,"^");
			sTPLSeq = tc_strtok(NULL,"^");
			sVCIDCtgy = tc_strtok(NULL,"^");
			sVCIDAppl = tc_strtok(NULL,"^");
			sDate = tc_strtok(NULL,"^");
			sVCs = tc_strtok(NULL,"^");
			
			printf("\nkk.Processing [%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s]\n",sVCIDNum,sVCIDRev,sVCIDSeq,sVCIDTitl,sVCIDPrps,sVCIDFile,sTPLNum,sTPLRev,sTPLSeq,sVCIDCtgy,sVCIDAppl); fflush(stdout);
			
			tc_strcpy(sVCIDVer,sVCIDRev);
			tc_strcat(sVCIDVer,";");
			tc_strcat(sVCIDVer,sVCIDSeq);
			printf("\nkk.concat VCID version is [%s]\n",sVCIDVer); fflush(stdout);
				
			ITK_CALL(ITEM_find_item(sVCIDNum,&tFndVCIDM));
			if(tFndVCIDM != NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(tFndVCIDM,"object_type",&sVCIDTyp));
				printf("\nkk.VCID [%s,%s] is already created!!!\n",sVCIDNum,sVCIDTyp); fflush(stdout);
				if(ITEM_list_all_revs(tFndVCIDM,&nVCIDRevCnt,&tpVCIDRevs));
				if(nVCIDRevCnt>0)
				{
					for(iVCnt=0; iVCnt<nVCIDRevCnt; ++iVCnt)
					{
						ITK_CALL(AOM_ask_value_string(tpVCIDRevs[iVCnt],"item_revision_id",&sFndVCIDRev));
						if(tc_strcmp(sFndVCIDRev,sVCIDVer)==0)
						{
							tVCIDRev = tpVCIDRevs[iVCnt];
							printf("\nkk.VCID version found [%s,%s]\n",sVCIDNum,sFndVCIDRev); fflush(stdout);
							break;
						}
					}
				}
			}
			else
			{
				printf("\nkk.Creating VCID [%s]\n",sVCIDNum); fflush(stdout);
				ITK_CALL(ITEM_create_item(sVCIDNum,sVCIDNum,"T5_CCID",sVCIDVer,&tVCIDMstr,&tVCIDRev));
				
				if(tVCIDRev != NULLTAG)
				{
					AOM_set_value_string(tVCIDRev,"object_desc",sVCIDPrps);
					AOM_set_value_string(tVCIDRev,"object_name",sVCIDTitl);
					AOM_set_value_string(tVCIDRev,"t5_CCIDDRStatus","DR3");
					AOM_set_value_string(tVCIDRev,"t5_CCIDApplicability",sVCIDAppl);
					
					//create VCID's relation with DML , Part rev and VC
					AOM_save_without_extensions(tVCIDRev);
					printf("\nkk.Values updated.\n"); fflush(stdout);
				}
			}
			
			if(tVCIDRev != NULLTAG)
			{	
				ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&tHsNewVCIDRel));
				ITK_CALL(GRM_list_primary_objects_only(tVCIDRev,tHsNewVCIDRel,&nDmlCnt,&tpDmlObj));
				if(nDmlCnt>0)
				{
					printf("\nkk.VCID is already attached to DML.\n"); fflush(stdout);
				}
				else
				{
					ITK_CALL(GRM_create_relation(tDMLRev,tVCIDRev,tHsNewVCIDRel,NULLTAG,&tNewVCIDRel));
					ITK_CALL(GRM_save_relation(tNewVCIDRel));
					ITK_CALL(AOM_refresh(tDMLRev,1));
					ITK_CALL(AOM_save_without_extensions(tDMLRev));
					ITK_CALL(AOM_refresh(tDMLRev,0));
				}
				
				ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&tIsMmbrOfVCID));
				ITK_CALL(GRM_list_primary_objects_only(tVCIDRev,tIsMmbrOfVCID,&nModCnt,&tpModObj));
				if(nModCnt>0)
				{
					printf("\nkk.VCID is already attached to ECU Module/TPL.\n"); fflush(stdout);
					Tplfound = true;
				}
				else
				{
					const char **sAttr  = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **sVals = (const char **) MEM_alloc(2 * sizeof(char *));
					sAttr[0] = "item_id";
					sVals[0] = (char *)sTPLNum;
					tc_strcpy(sTPLRvSq,sTPLRev);
					tc_strcat(sTPLRvSq,";");
					tc_strcat(sTPLRvSq,sTPLSeq);
					ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,sAttr,sVals,sTPLRvSq,&nPrtCnt,&tpPrtObjs));
					printf("\nkk.TPL count is [%d].\n",nPrtCnt); fflush(stdout);
					if(nPrtCnt>0)
					{
						tTPLObj = tpPrtObjs[0];
						ITK_CALL(GRM_create_relation(tTPLObj,tVCIDRev,tIsMmbrOfVCID,NULLTAG,&tMmbrVCIDRel));
						ITK_CALL(GRM_save_relation(tMmbrVCIDRel));
						ITK_CALL(AOM_refresh(tTPLObj,1));
						ITK_CALL(AOM_save_without_extensions(tTPLObj));
						ITK_CALL(AOM_refresh(tTPLObj,0));
					}
				}
				
				ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&tRefCCVs));
				ITK_CALL(GRM_list_secondary_objects_only(tVCIDRev,tRefCCVs,&nVcCnt,&tpVCs));
				printf("\nkk.ref VC count is [%d]  \n",nVcCnt); fflush(stdout);
				sVCNum = tc_strtok(sVCs,":");
				while(sVCNum != NULL)
				{
					lIsVCRelFound = false;
					if(nVcCnt>0)
					{
						for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
						{
							if(AOM_ask_value_string(tpVCs[iVCCnt],"item_id",&sRefVCNum)!=ITK_ok);
							printf("\nkk.checking VC [%s]",sRefVCNum); fflush(stdout);
							if(tc_strcmp(sVCNum,sRefVCNum)==0)
							{
								printf("\nkk.References CCV relation exists for VC %s\n",sRefVCNum); fflush(stdout);
								lIsVCRelFound = true;
								break;
							}
						}
					}
					if(lIsVCRelFound == false)
					{
						printf("\nkk.Attaching VC [%s] to VCID [%s]\n",sVCNum,sVCIDNum); fflush(stdout);
						ITK_CALL(ITEM_find_item(sVCNum,&tVCItmM));
						if(tVCItmM != NULLTAG)
						{
							ITK_CALL(GRM_create_relation(tVCIDRev,tVCItmM, tRefCCVs, NULLTAG,&tRefCCVRel));
							printf("\nkk.Created relation between [%s,%s,%s] and [%s]",sVCIDNum,sVCIDRev,sVCIDRev,sVCNum);fflush(stdout);
							ITK_CALL(GRM_save_relation(tRefCCVRel));
						}
					}
					sVCNum = tc_strtok(NULL,":");
				}
				//}
			//}
					
			
				//TODO: Create snapshot.
				tc_strcpy(sVCIDSnap,sVCIDNum);
				tc_strcat(sVCIDSnap,"_");
				tc_strcat(sVCIDSnap,sVCIDRev);
				tc_strcat(sVCIDSnap,"_");
				tc_strcat(sVCIDSnap,sVCIDSeq);
				//ITK_CALL(ITEM_find_item(sVCIDSnap,&tFndVCIDSnp));
				int n_Input = 1;
				char	*qry_Input[1]	  = {"Name"}; 
				char	*qry_SnpVal[1];
				if(QRY_find2("SnapShot",&tQrySnap));
				if(tQrySnap)
				{
					qry_SnpVal[0]=sVCIDSnap;
					if(QRY_execute(tQrySnap, n_Input, qry_Input, qry_SnpVal,&nSnpCnt,&tpSnpObj));
					printf("\nkk.Snapshot count is:[%d]\n", nSnpCnt);fflush(stdout);
				}
				
				//if(tFndVCIDSnp != NULLTAG)
				if(nSnpCnt > 0)
				{
					tFndVCIDSnp = tpSnpObj[0];
					ITK_CALL(AOM_ask_value_string(tFndVCIDSnp,"object_type",&sVCIDSnpTyp));
					printf("\nkk.VCID Snapshot [%s,%s] is already created!!!\n",sVCIDSnap,sVCIDSnpTyp); fflush(stdout);
				}
				else
				{
					printf("\nkk.Create Snapshot for VCID [%s].\n",sVCIDSnap); fflush(stdout);
					//BOM_create_snapshot(window,SnapshotNo,"Snapshot for ECU",&snapshot));
					
					if (Tplfound==true)
					{
						printf("\nkk.inside tpl rel found\n"); fflush(stdout);
						create_snapshot(tpModObj[0],sVCIDSnap,tVCIDRev,sVCIDFile);
					}
					else
					{
						printf("\nkk.inside after tpl rel creation\n"); fflush(stdout);
					create_snapshot(tTPLObj,sVCIDSnap,tVCIDRev,sVCIDFile);
					}
					
				}
			}

			///////////
	/*		tag_t vctag =NULLTAG;
			tag_t HasECUModulereltag =NULLTAG;
			tag_t vclatestrevtag =NULLTAG;
			tag_t tpltag =NULLTAG;
			tag_t latrelrefccvreltag =NULLTAG;
			tag_t* hasecumodreltags =NULLTAG;
			int hasecumodrelcnt=0;
			char *VCNo = NULL;
			VCNo = tc_strtok(sVCs,":");
		  while(VCNo != NULL)
		   {

			ITK_CALL(ITEM_find_item(VCNo,&vctag));
			if(vctag != NULLTAG)
			{

				ITK_CALL(ITEM_ask_latest_rev(vctag,&vclatestrevtag));

				ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&HasECUModulereltag));
				ITK_CALL(GRM_list_secondary_objects_only(vclatestrevtag,HasECUModulereltag,&hasecumodrelcnt,&hasecumodreltags));
				printf("\n CCVCHasECUModule count [%d]= \n",hasecumodrelcnt);fflush(stdout);

				if (hasecumodrelcnt==0)
					{

						printf("\n i am in if condition \n");fflush(stdout);

						ITK_CALL(ITEM_find_item(sTPLNum,&tpltag));
							if(tpltag == NULLTAG)
							{
								printf("\n Tpl not found:%s\n",sTPLNum);
								
							}
							else
							{

							  ITK_CALL(GRM_create_relation(vclatestrevtag,tpltag,HasECUModulereltag,NULLTAG,&latrelrefccvreltag));				

							  ITK_CALL(AOM_unlock(latrelrefccvreltag));

							  GRM_save_relation(latrelrefccvreltag);

							  ITK_CALL(AOM_lock(latrelrefccvreltag));
							}
					}
		    }
			else
			{
				printf("\n Vehicle not found:%s\n",sVCs);

			}
			VCNo = tc_strtok(NULL,":");
		}*/
		









			//////////////
		}
	}
			
	printf("\nkk.VCID migration code completed.\n"); fflush(stdout);

	ITK_exit_module(true);

	return status;
}

int create_snapshot(tag_t tTPLObj,char* sVCIDSnap,tag_t tVCIDRev,char* Filename)
{
	int ifail;
    tag_t window = NULLTAG;
    tag_t	sn_rule		 = NULLTAG; 
    tag_t	top_line		 = NULLTAG; 
    tag_t	snapshot		 = NULLTAG; 
    tag_t	HasSnapshotType		 = NULLTAG; 
    tag_t	Rel_task		 = NULLTAG; 
    

    if(BOM_create_window (&window));
	//CHECK_FAIL;

	if(CFM_find("ERC release and above", &sn_rule ));

	if(BOM_set_window_config_rule( window, sn_rule ));

	 if(BOM_set_window_top_line (window, null_tag, tTPLObj, null_tag, &top_line));
	//CHECK_FAIL;

	if(BOM_window_show_suppressed (window));
	//CHECK_FAIL;

	if(BOM_set_window_pack_all(window, FALSE));

	if(top_line!=NULLTAG)
	{
		if(BOM_create_snapshot(window,sVCIDSnap,"Snapshot for ECU",&snapshot));

		if(snapshot!=NULLTAG)
		{

			if(AOM_lock(snapshot))
			printf("\n after snapshot creation :\n");fflush(stdout);
			if(AOM_save_without_extensions( snapshot))
			if(AOM_refresh(snapshot,1));
			if(AOM_unlock(snapshot));

			printf("\n tm_ECUNewSnapshot snapshot unlocked :\n");fflush(stdout);

			if(GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType));
			printf("\n tm_ECUNewSnapshot after finding HasSnapshotType \n");fflush(stdout);

			if(HasSnapshotType!=NULLTAG)
			{
				printf("\n creating relation between ccid and snapshot \n");fflush(stdout);
				if(GRM_create_relation(tVCIDRev,snapshot,HasSnapshotType,NULLTAG,&Rel_task));
				if(GRM_save_relation (Rel_task));
				if(AOM_refresh(tVCIDRev,1));
				if(AOM_save_without_extensions(tVCIDRev));
				if(AOM_refresh(tVCIDRev,0));
				printf("\n tm_ECUNewSnapshot SNAPSHOT RELATION CREATED WITH THE DESIGN REV:\n");fflush(stdout);


				////////////////////////////////////

				int snapcount=0;
				int sn=0;
				tag_t*	snapchild		 = NULLTAG;
				tag_t	SnChild		 = NULLTAG;
				char * PartItemIdSn=NULL;



			  if(AOM_ask_value_tags(snapshot,"contents",&snapcount,&snapchild));//added
			  printf("\n\n\t snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

			  if(snapcount >0)
			  {
				  printf("\n\n\t delete old data \n");fflush(stdout);
					for (sn=0;sn<snapcount;sn++)
					 {

						SnChild=snapchild[sn];

						if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
						printf("\n\n\t Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout); 

						if(AOM_lock(snapshot));
						if(FL_remove(snapshot,SnChild));
						printf("\n\n\t  after fl remove AA \n");fflush(stdout);
			
						if(AOM_save_without_extensions(snapshot));
							
						if(AOM_refresh(snapshot,0));

						if(AOM_unlock(snapshot));

						
					 }// for snapcount ends
					 printf("\n\n\t all relationship deleted   \n");fflush(stdout);

			  }

				///////////////////////////////////////

				int				count	 				= 0;
				
				char 			*partnumber				= NULL;
				char 			*rev_id					= NULL;
				char 			*Nextrev_id					= NULL;
				char 			*attr_value				= NULL;
				char 			temp[200];
				
				FILE* fp = NULL;
				fp = fopen(Filename, "r");
				
				char 			*VCIDNumber					= NULL;
				char 			*vcidrevseq					= NULL;
				char 			*vcidrev					= NULL;
				char 			*vcidseq					= NULL;
				char 			*VCIDNumber1					= NULL;
				char 			*VCIDNumber2					= NULL;
				char 			*extension					= NULL;
				char 			*tempextenstion					= NULL;

				tag_t VCIDNumberitem_tag	   = NULLTAG;
				tag_t vcidrevseq_tag	   = NULLTAG;

				vcidrevseq =(char *) MEM_alloc(150);
				VCIDNumber =(char *) MEM_alloc(150);

				printf("\nInput Filename befor is :%s",Filename);
				ifail=STRNG_replace_str(Filename,".","_",&tempextenstion);
				printf("\nInput Filename tempextenstion :%s",tempextenstion);

				VCIDNumber1 = strtok(tempextenstion, "_");
				printf("\nInput VCIDNumber1:%s",VCIDNumber1);

				VCIDNumber2 = strtok(NULL, "_");
				printf("\nInput VCIDNumber2:%s",VCIDNumber2);

				vcidrev = strtok(NULL, "_");
				printf("\nInput vcidrev:%s",vcidrev);

				vcidseq = strtok(NULL, "_");
				printf("\nInput vcidseq:%s",vcidseq);

				extension = strtok(NULL, "_");
				printf("\nInput extension:%s",extension);



				tc_strcpy(VCIDNumber,"");	
				tc_strcat(VCIDNumber,VCIDNumber1);
				tc_strcat(VCIDNumber,"_");
				tc_strcat(VCIDNumber,VCIDNumber2);

				tc_strcpy(vcidrevseq,"");	
				tc_strcat(vcidrevseq,vcidrev);
				tc_strcat(vcidrevseq,";");
				tc_strcat(vcidrevseq,vcidseq);

				printf("\nInput VCID:%s/%s",VCIDNumber,vcidrevseq);


				int ifail;
				tag_t	item_tag		= NULLTAG;
				tag_t	itemrev_tag		= NULLTAG;

				tag_t	*ccidTagrf		= NULLTAG;
				//tag_t	*snapchild		= NULLTAG;
				tag_t	 HasSnapshotType	  = NULLTAG;
				int SnapCnt=0;
			//	int snapcount=0;
				char* ErrorText =NULL;
				fflush(NULL);


				char	*FName = NULL;
				FName =(char *) MEM_alloc(150);
				FILE *fptr;
				tc_strcpy(FName,"/user/uaprodtrl/KetanKore/MigrateVCID/");
				tc_strcat(FName,VCIDNumber);
				tc_strcat(FName,"_");
				tc_strcat(FName,vcidrev);
				tc_strcat(FName,"_");
				tc_strcat(FName,vcidseq);
				tc_strcat(FName,"_log.csv");

				fptr = fopen(FName,"w");
				 
				if(fptr==NULL)
				{
					printf("Error! in log File opening!!!");  fflush(stdout);
					//exit(1);
				}
				else
				{
					printf("\nlog File opening!!!");  fflush(stdout);
				}

				 fprintf(fptr,"%s,%s,%s,%s","VCID Number","part Added","part Not Added","Part Not Available in TCUA");fflush(fptr);

				ifail = ITEM_find_item (VCIDNumber, &VCIDNumberitem_tag);
				if (VCIDNumberitem_tag)
				{
								 
				  ifail = ITEM_find_revision(VCIDNumberitem_tag,vcidrevseq, &vcidrevseq_tag);
							
				   rev_id =(char *) MEM_alloc(150);
				   char	*rev = NULL;
				   char	*id = NULL;
				
					if (fp != NULL)
					{
						while (fgets(temp, 200, fp)!= NULL)
						{
							tc_strcpy(temp,stripBlanks(temp));

							if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
							{
								partnumber = strtok(temp, "^");
								printf("\nInput partnumber:%s",partnumber);

								rev = strtok(NULL, "^");
								printf("\nInput rev:%s",rev);

								id = strtok(NULL, "^");
								printf("\nInput id:%s",id);


								tc_strcpy(rev_id,"");	
								tc_strcat(rev_id,rev);
								tc_strcat(rev_id,";");
								tc_strcat(rev_id,id);

								printf("\nrev_id:%s",rev_id);

									ifail = ITEM_find_item (partnumber, &item_tag);
									
								if (item_tag!=NULLTAG)
								{
									printf("\n part found:%s",partnumber);
									//CHECK_FAIL;
									 
									ifail = ITEM_find_revision(item_tag,rev_id, &itemrev_tag);
								//	CHECK_FAIL;

									if (itemrev_tag!=NULLTAG)
									{
										printf("\n part rev found:%s/%s",partnumber,rev_id);
										 ifail=GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshotType);// new relation created in bmide 
										 printf("\n  DataSnap -now get CCID has  HasSnapshotType \n");fflush(stdout);

										 ifail = GRM_list_secondary_objects_only(vcidrevseq_tag,HasSnapshotType,&SnapCnt,&ccidTagrf);
										 printf("\n  DataSnap -Check how many Snapshot in Refrences Relationship =============>>> %d  \n",SnapCnt);fflush(stdout);


										 ifail=AOM_lock(ccidTagrf[0]);
																										
																												
										ifail = FL_insert(ccidTagrf[0],itemrev_tag,999);
										if(ifail != ITK_ok)
										{
											EMH_ask_error_text(ifail,&ErrorText);
											printf("\n  ErrorText :::: ********* [%s]\n\n",ErrorText);fflush(stdout);

											fprintf(fptr,"\n%s/%s,%s,%s/%s,%s",VCIDNumber,vcidrevseq," ",partnumber,rev_id," ");fflush(fptr);
										}

										printf("\n PartReplace_DML  Part addition code-%s having sequence - %s \n",partnumber,rev_id );fflush(stdout);

										ifail=AOM_save_without_extensions(ccidTagrf[0]);

										ifail=AOM_refresh(ccidTagrf[0],0);

										ifail=AOM_unlock(ccidTagrf[0]);

										printf("\n  PartReplace_DML Relation OF nr part added in Snapshot\n");fflush(stdout);

									//	fprintf(fptr,"\n%s/%s,%s/%s,%s",VCIDNumber,vcidrevseq,partnumber,rev_id," ");fflush(fptr);

						
									}
									else
								    {
										printf("\n part rev found:%s/%s",partnumber,rev_id);
										fprintf(fptr,"\n%s/%s,%s,%s/%s,%s",VCIDNumber,vcidrevseq," ",partnumber,rev_id," ");fflush(fptr);
								     }
								}
								else
								{
									printf("\n part not found:%s",partnumber);
									fprintf(fptr,"\n%s/%s,%s,%s,%s",VCIDNumber,vcidrevseq," "," ",partnumber);fflush(fptr);
								 }

							}			
							tc_strcpy(temp, "");
						}
					}
					else 
					{
						printf("File Unable to Open...!!");
					}
			}
				fclose(fp);
				

				////////////////////////////////////////
			}
		}
	}
	return 0;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}

