#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>
#include<ics/ics2.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void initialise (void);

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void GetDmlDetails(tag_t tVCIDRv, char **sDmlNo, char **sRelType,char **sStat, char **sRemarks)
{
	int ifail;
	int nCntDml = 0;
	int iCntDml = 0;
	int nTsks = 0;
	int iRfPrt = 0;
	int nRfPrt = 0;
	int nSnpCnt = 0;
	int nSnpPrtCnt = 0;
	int iSnCnt = 0;
	logical lAddOnce = false;
	char *type_dml_name = NULL;
	char *sTskNum = NULL;
	char *sRfPrtNum = NULL;
	char *sRfPrtRev = NULL;
	char *sSnPrtNum = NULL;
	char *sSnPrtRev = NULL;
	tag_t tHNVRel = NULLTAG;
	tag_t tDMLRev = NULLTAG;
	tag_t tDMLType = NULLTAG;
	tag_t tDmlTskRel = NULLTAG;
	tag_t tTskList = NULLTAG;
	tag_t tTskRefRel = NULLTAG;
	tag_t tRfPrt = NULLTAG;
	tag_t tVcidSnpRel = NULLTAG;
	tag_t tSnpPrt = NULLTAG;
	tag_t *tpDMLRev = NULLTAG;
	tag_t *tpTskList = NULLTAG;
	tag_t *tpRfPrtkList = NULLTAG;
	tag_t *tpSnapList = NULLTAG;
	tag_t *tpSnpCntPrts = NULLTAG;
	
	ITKCALL(GRM_find_relation_type("T5_HasNewCCID",&tHNVRel));  
	ITKCALL(GRM_find_relation_type("IMAN_reference",&tTskRefRel)); 
	ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&tDmlTskRel)); 
	ITKCALL(GRM_find_relation_type("T5_CCIDHasSnapshot",&tVcidSnpRel)); 
	if(tHNVRel != NULLTAG && tTskRefRel != NULLTAG && tDmlTskRel != NULLTAG && tVcidSnpRel != NULLTAG)
	{
		//printf("\n Hs new VCID rel found \n ");fflush(stdout);
				
		GRM_list_primary_objects_only(tVCIDRv,tHNVRel,&nCntDml,&tpDMLRev);
		printf("\nkk.No of DMLs FOUND [%d]",nCntDml); fflush(stdout);
		if(nCntDml>0)
		{
			for(iCntDml=0; iCntDml<nCntDml; ++iCntDml)
			{
				tDMLRev	= tpDMLRev[iCntDml];
				if(TCTYPE_ask_object_type(tDMLRev,&tDMLType));
				if(TCTYPE_ask_name2(tDMLType,&type_dml_name));
				printf("\nkk.type_dml_name for object [%s]", type_dml_name); fflush(stdout);
				if(tc_strcmp(type_dml_name,"ChangeRequestRevision")==0)
				{
					ITKCALL(AOM_ask_value_string(tDMLRev,"item_id",sDmlNo));
					ITKCALL(AOM_ask_value_string(tDMLRev,"t5_rlstype",sRelType));
					
					if(tc_strcmp(*sRelType,"BKC")==0)
					{
						GRM_list_secondary_objects_only(tVCIDRv,tVcidSnpRel,&nSnpCnt,&tpSnapList);
						printf("\nkk.Snapshot count is [%d]",nSnpCnt); fflush(stdout);
						if(nSnpCnt > 0)
						{
							ITKCALL(AOM_ask_value_tags(tpSnapList[0],"contents",&nSnpPrtCnt,&tpSnpCntPrts));
							printf("\nkk.Number of parts under Snapshot is [%d]",nSnpPrtCnt); fflush(stdout);
						}
						else
						{
							if(lAddOnce == false)
							{
								tc_strcpy(*sStat,"Error");
								lAddOnce = true;
							}
							if(*sRemarks == NULL)
							{
								*sRemarks =(char *) MEM_alloc(50);
								tc_strcpy(*sRemarks,"Snapshot not found.");
							}
						}
		
						GRM_list_secondary_objects_only(tDMLRev,tDmlTskRel,&nTsks,&tpTskList);
						printf("\nkk.No of Task found [%d]", nTsks); fflush(stdout);
						if(nTsks > 0)
						{
							tTskList = tpTskList[0];
							ITKCALL(AOM_ask_value_string(tTskList,"item_id",&sTskNum));
							printf("\nkk.Task Name [%s]", sTskNum); fflush(stdout);
							GRM_list_secondary_objects_only(tTskList,tTskRefRel,&nRfPrt,&tpRfPrtkList);
							printf("\nkk.Total parts attached to Task is [%d]", nRfPrt); fflush(stdout);
							for(iRfPrt=0; iRfPrt<nRfPrt; ++iRfPrt)
							{
								tRfPrt = tpRfPrtkList[iRfPrt];
								ITKCALL(AOM_ask_value_string(tRfPrt,"item_id",&sRfPrtNum));
								ITKCALL(AOM_ask_value_string(tRfPrt,"item_revision_id",&sRfPrtRev));
								
								for(iSnCnt=0; iSnCnt<nSnpPrtCnt; ++iSnCnt)
								{
									tSnpPrt = tpSnpCntPrts[iSnCnt];
									ITKCALL(AOM_ask_value_string(tSnpPrt,"item_id",&sSnPrtNum));
									ITKCALL(AOM_ask_value_string(tSnpPrt,"item_revision_id",&sSnPrtRev));
									if(tc_strcmp(sRfPrtNum,sSnPrtNum) == 0)
									{
										printf("\nkk.Comparing Part [%s,%s,%s]", sRfPrtNum,sRfPrtRev,sSnPrtRev); fflush(stdout);
										if(tc_strcmp(sRfPrtRev,sSnPrtRev) != 0)
										{
											printf("\nkk.Part [%s] not replaced", sRfPrtNum); fflush(stdout);
											if(lAddOnce == false)
											{
												tc_strcpy(*sStat,"Error");
												lAddOnce = true;
											}
											if(*sRemarks == NULL)
											{
												*sRemarks =(char *) MEM_alloc(500);
												tc_strcpy(*sRemarks,sRfPrtNum);
											}
											else
											{
												tc_strcat(*sRemarks,"-");
												tc_strcat(*sRemarks,sRfPrtNum);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;
	logical lValFound = false;

	//char *sRead_vc = NULL;
	//char *sRead_vc_tok = NULL;
	//char *sVeh = NULL;
	int nRvCnt = 0;
	int iRvCnt = 0;
	//int nRefVCCnt = 0;
	//char *sPrt = NULL;
	//char *sSSPrt = NULL;
	char *sVCIDRev = NULL;
	char *sVCID = NULL;
	char *sFileName_out = NULL;
	char *sDmlNum = NULL;
	char *sDmlRelTyp = NULL;
	char *sStatus = NULL;
	char *sRmrks = NULL;
	char *sUser = NULL;
	char *sPassFl = NULL;
	char *sGrp = NULL;
	//char *sMajMod = NULL;
	//char *sFuel = NULL;
	//char *qry_Input[1] = {"Item ID"};
	//char *qry_Input[3] = {"Item ID", "Type", "Revision"};
	//char *values[1];
	//tag_t newVcidRel = NULLTAG;
	//tag_t RefCCVTag = NULLTAG;
	//tag_t *tpVCIDs = NULLTAG;
	//tag_t *tpRefVC = NULLTAG;
	tag_t tVcid = NULLTAG;
	tag_t tRvList = NULLTAG;
	tag_t *tpRvList = NULLTAG;
	
	//int n_Input = 1;
	//int nVehCnt = 0;
	//tag_t qryVC = NULLTAG;
	//tag_t *tpVeh = NULLTAG;
	
	FILE *fptr_out;
	//FILE *fptr_vc;
	
	//sRead_vc =(char *) MEM_alloc(50);
	//sRead_vc_tok =(char *) MEM_alloc(50);
	//sVeh =(char *) MEM_alloc(50);
	//sMajMod =(char *) MEM_alloc(50);
	//sFuel =(char *) MEM_alloc(50);
	sFileName_out =(char *) MEM_alloc(100);
	sStatus =(char *) MEM_alloc(10);

	(void)argc;
	(void)argv;

	initialise();

	sUser = ITK_ask_cli_argument("-u=");
	sPassFl = ITK_ask_cli_argument("-pf=");
	sGrp = ITK_ask_cli_argument("-g=");
	sVCID = ITK_ask_cli_argument("-vcid=");

	iStatus = ITK_auto_login();

	if( ITK_init_module(sUser,sPassFl,sGrp)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Getting VCID BKC Report for [%s]",sVCID); fflush(stdout);
	
	tc_strcpy(sFileName_out,sVCID);
	tc_strcat(sFileName_out,"_Bkc_Report.csv");
	fptr_out = fopen(sFileName_out,"w");
	if(fptr_out==NULL)
	{
		printf("\nError in File [%s] opening!!!",sFileName_out); fflush(stdout);
		exit(1);
	}
	
	fprintf(fptr_out, "VCID,Rev,DML,Rel Type,Status?,Remarks,\n"); fflush(fptr_out);
	
	ITK_CALL(ITEM_find_item(sVCID,&tVcid));
	//ITK_CALL(ITEM_ask_latest_rev(tVeh,&tVehRev));
	if(tVcid != NULLTAG)
	{
		ITK_CALL(ITEM_list_all_revs(tVcid,&nRvCnt,&tpRvList));
		
		printf("\nkk.VCID revision count is [%d]",nRvCnt); fflush(stdout);
		if(nRvCnt > 0)
		{
			for(iRvCnt=0; iRvCnt<nRvCnt; ++iRvCnt)
			{
				tRvList = tpRvList[iRvCnt];
				if(AOM_ask_value_string(tRvList,"item_revision_id",&sVCIDRev)!=ITK_ok);
				printf("\nkk.VCID-Rev [%s,%s]",sVCID,sVCIDRev); fflush(stdout);
				
				tc_strcpy(sStatus,"Ok");
				GetDmlDetails(tRvList,&sDmlNum,&sDmlRelTyp,&sStatus,&sRmrks);
				printf("\nkk.[DML,Rel Type] is [%s,%s]",sDmlNum,sDmlRelTyp); fflush(stdout);
				
				//TODO: write info in file.
				if(sRmrks == NULL)
				{
					fprintf(fptr_out, "%s,%s,%s,%s,%s,NA,\n", sVCID,sVCIDRev,sDmlNum,sDmlRelTyp,sStatus); fflush(fptr_out);
				}
				else
				{
					fprintf(fptr_out, "%s,%s,%s,%s,%s,%s,\n", sVCID,sVCIDRev,sDmlNum,sDmlRelTyp,sStatus,sRmrks); fflush(fptr_out);
				}
				sRmrks = NULL;
			}
		}
	}
	else
	{
		printf("\nkk.VCID [%s] not found in TcUA.",sVCID); fflush(stdout);
		fprintf(fptr_out,"VCID [%s] not found in TcUA.",sVCID); fflush(fptr_out);
	}
	
	
	fclose(fptr_out);

	printf("\nkk...Report Generation Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

}
