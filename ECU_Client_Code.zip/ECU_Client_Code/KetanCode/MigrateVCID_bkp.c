#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
//static void initialise_attribute (char *name,  int *attribute);

char *sInpTPLNum = NULL;


void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sInpTPLNum  = ITK_ask_cli_argument("-tpl=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	int i = 0;
	int iVCnt = 0;
	int iVCCnt = 0;
	int nSnpCnt = 0;
	int nDmlCnt = 0;
	int nPrtCnt = 0;
	int nModCnt = 0;
	int nVcCnt = 0;
	int nVCIDRevCnt = 0;
	logical lIsVCRelFound;
	char *sInputLine = NULL;
	char *sFileRead = NULL;
	char *sVCIDNum = NULL;
	char *sVCIDRev = NULL;
	char *sVCIDSeq = NULL;
	char *sVCIDTitl = NULL;
	char *sVCIDPrps = NULL;
	char *sVCIDFile = NULL;
	char *sTPLNum = NULL;
	char *sTPLRev = NULL;
	char *sTPLSeq = NULL;
	char *sVCIDCtgy = NULL;
	char *sVCIDAppl = NULL;
	char *sVCIDVer = NULL;
	char *sVCIDTyp = NULL;
	char *sVCIDSnap = NULL;
	char *sVCIDSnpTyp = NULL;
	char *sTPLRvSq = NULL;
	char *sRefVCNum = NULL;
	char *sDate = NULL;
	char *sVCs = NULL;
	char *sVCNum = NULL;
	char *sFndVCIDRev = NULL;
	tag_t tFndVCIDM = NULLTAG;
	tag_t tVCIDMstr = NULLTAG;
	tag_t tVCIDRev = NULLTAG;
	tag_t tFndVCIDSnp = NULLTAG;
	tag_t tQrySnap = NULLTAG;
	tag_t *tpSnpObj = NULLTAG;
	tag_t tHsNewVCIDRel = NULLTAG;
	tag_t *tpDmlObj = NULLTAG;
	tag_t tFndDmlM = NULLTAG;
	tag_t tDMLRev = NULLTAG;
	tag_t tNewVCIDRel = NULLTAG;
	tag_t *tpPrtObjs = NULLTAG;
	tag_t tIsMmbrOfVCID = NULLTAG;
	tag_t *tpModObj = NULLTAG;
	tag_t tTPLObj = NULLTAG;
	tag_t tMmbrVCIDRel = NULLTAG;
	tag_t tRefCCVs = NULLTAG;
	tag_t *tpVCs = NULLTAG;
	tag_t tVCItmM = NULLTAG;
	tag_t tRefCCVRel = NULLTAG;
	tag_t *tpVCIDRevs = NULLTAG;
	
	FILE* fptr = NULL;
	
	sFileRead =(char *) MEM_alloc(150);
	sVCIDVer =(char *) MEM_alloc(6);
	sVCIDSnap =(char *) MEM_alloc(25);
	sTPLRvSq =(char *) MEM_alloc(10);

	printf("\nkk.Input TPL is.. \n [%s]\n",sInpTPLNum); fflush(stdout);
	tc_strcpy(sFileRead,sInpTPLNum);
	tc_strcat(sFileRead,".csv");
	fptr=fopen(sFileRead,"r");
	if(fptr == NULL)
	{
		printf("Error! in File opening...%s",sFileRead);  fflush(stdout);
		exit(1);
	}
	
	//ITK_CALL(ITEM_find_item("23CU002011",&tFndDmlM));//CV
	ITK_CALL(ITEM_find_item("14PM503604",&tFndDmlM));//PV
	ITK_CALL(ITEM_ask_latest_rev(tFndDmlM, &tDMLRev));
	
	if(fptr!=NULL)
	{
		sInputLine=(char *) MEM_alloc(1000);
		
		while(fgets(sInputLine,1000,fptr)!=NULL)
		{
			tVCIDRev = NULLTAG;
			for (i = 0; i < strlen(sInputLine); i++)
			{
				if ( sInputLine[i] == '\n' || sInputLine[i] == '\r' )
					sInputLine[i] = '\0';
			}
			sVCIDNum = tc_strtok(sInputLine,"^");
			sVCIDRev = tc_strtok(NULL,"^");
			sVCIDSeq = tc_strtok(NULL,"^");
			sVCIDTitl = tc_strtok(NULL,"^");
			sVCIDPrps = tc_strtok(NULL,"^");
			sVCIDFile = tc_strtok(NULL,"^");
			sTPLNum = tc_strtok(NULL,"^");
			sTPLRev = tc_strtok(NULL,"^");
			sTPLSeq = tc_strtok(NULL,"^");
			sVCIDCtgy = tc_strtok(NULL,"^");
			sVCIDAppl = tc_strtok(NULL,"^");
			sDate = tc_strtok(NULL,"^");
			sVCs = tc_strtok(NULL,"^");
			
			printf("\nkk.Processing [%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s]\n",sVCIDNum,sVCIDRev,sVCIDSeq,sVCIDTitl,sVCIDPrps,sVCIDFile,sTPLNum,sTPLRev,sTPLSeq,sVCIDCtgy,sVCIDAppl); fflush(stdout);
			
			tc_strcpy(sVCIDVer,sVCIDRev);
			tc_strcat(sVCIDVer,";");
			tc_strcat(sVCIDVer,sVCIDSeq);
			printf("\nkk.concat VCID version is [%s]\n",sVCIDVer); fflush(stdout);
				
			ITK_CALL(ITEM_find_item(sVCIDNum,&tFndVCIDM));
			if(tFndVCIDM != NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(tFndVCIDM,"object_type",&sVCIDTyp));
				printf("\nkk.VCID [%s,%s] is already created!!!\n",sVCIDNum,sVCIDTyp); fflush(stdout);
				if(ITEM_list_all_revs(tFndVCIDM,&nVCIDRevCnt,&tpVCIDRevs));
				if(nVCIDRevCnt>0)
				{
					for(iVCnt=0; iVCnt<nVCIDRevCnt; ++iVCnt)
					{
						ITK_CALL(AOM_ask_value_string(tpVCIDRevs[iVCnt],"item_revision_id",&sFndVCIDRev));
						if(tc_strcmp(sFndVCIDRev,sVCIDVer)==0)
						{
							tVCIDRev = tpVCIDRevs[iVCnt];
							printf("\nkk.VCID version found [%s,%s]\n",sVCIDNum,sFndVCIDRev); fflush(stdout);
							break;
						}
					}
				}
			}
			else
			{
				printf("\nkk.Creating VCID [%s]\n",sVCIDNum); fflush(stdout);
				ITK_CALL(ITEM_create_item(sVCIDNum,sVCIDNum,"T5_CCID",sVCIDVer,&tVCIDMstr,&tVCIDRev));
				
				if(tVCIDRev != NULLTAG)
				{
					AOM_set_value_string(tVCIDRev,"object_desc",sVCIDPrps);
					AOM_set_value_string(tVCIDRev,"object_name",sVCIDTitl);
					AOM_set_value_string(tVCIDRev,"t5_CCIDDRStatus","DR3");
					AOM_set_value_string(tVCIDRev,"t5_CCIDApplicability",sVCIDAppl);
					
					//create VCID's relation with DML , Part rev and VC
					AOM_save_without_extensions(tVCIDRev);
					printf("\nkk.Values updated.\n"); fflush(stdout);
				}
			}
			
			if(tVCIDRev != NULLTAG)
			{	
				ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&tHsNewVCIDRel));
				ITK_CALL(GRM_list_primary_objects_only(tVCIDRev,tHsNewVCIDRel,&nDmlCnt,&tpDmlObj));
				if(nDmlCnt>0)
				{
					printf("\nkk.VCID is already attached to DML.\n"); fflush(stdout);
				}
				else
				{
					ITK_CALL(GRM_create_relation(tDMLRev,tVCIDRev,tHsNewVCIDRel,NULLTAG,&tNewVCIDRel));
					ITK_CALL(GRM_save_relation(tNewVCIDRel));
					ITK_CALL(AOM_refresh(tDMLRev,1));
					ITK_CALL(AOM_save_without_extensions(tDMLRev));
					ITK_CALL(AOM_refresh(tDMLRev,0));
				}
				
				ITK_CALL(GRM_find_relation_type("T5_IsMemberOfCCID",&tIsMmbrOfVCID));
				ITK_CALL(GRM_list_primary_objects_only(tVCIDRev,tIsMmbrOfVCID,&nModCnt,&tpModObj));
				if(nModCnt>0)
				{
					printf("\nkk.VCID is already attached to ECU Module/TPL.\n"); fflush(stdout);
				}
				else
				{
					const char **sAttr  = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **sVals = (const char **) MEM_alloc(2 * sizeof(char *));
					sAttr[0] = "item_id";
					sVals[0] = (char *)sTPLNum;
					tc_strcpy(sTPLRvSq,sTPLRev);
					tc_strcat(sTPLRvSq,";");
					tc_strcat(sTPLRvSq,sTPLSeq);
					ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,sAttr,sVals,sTPLRvSq,&nPrtCnt,&tpPrtObjs));
					printf("\nkk.TPL count is [%d].\n",nPrtCnt); fflush(stdout);
					if(nPrtCnt>0)
					{
						tTPLObj = tpPrtObjs[0];
						ITK_CALL(GRM_create_relation(tTPLObj,tVCIDRev,tIsMmbrOfVCID,NULLTAG,&tMmbrVCIDRel));
						ITK_CALL(GRM_save_relation(tMmbrVCIDRel));
						ITK_CALL(AOM_refresh(tTPLObj,1));
						ITK_CALL(AOM_save_without_extensions(tTPLObj));
						ITK_CALL(AOM_refresh(tTPLObj,0));
					}
				}
				
				ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&tRefCCVs));
				ITK_CALL(GRM_list_secondary_objects_only(tVCIDRev,tRefCCVs,&nVcCnt,&tpVCs));
				printf("\nkk.ref VC count is [%d]  \n",nVcCnt); fflush(stdout);
				sVCNum = tc_strtok(sVCs,":");
				while(sVCNum != NULL)
				{
					lIsVCRelFound = false;
					if(nVcCnt>0)
					{
						for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
						{
							if(AOM_ask_value_string(tpVCs[iVCCnt],"item_id",&sRefVCNum)!=ITK_ok);
							printf("\nkk.checking VC [%s]",sRefVCNum); fflush(stdout);
							if(tc_strcmp(sVCNum,sRefVCNum)==0)
							{
								printf("\nkk.References CCV relation exists for VC %s\n",sRefVCNum); fflush(stdout);
								lIsVCRelFound = true;
								break;
							}
						}
					}
					if(lIsVCRelFound == false)
					{
						printf("\nkk.Attaching VC [%s] to VCID [%s]\n",sVCNum,sVCIDNum); fflush(stdout);
						ITK_CALL(ITEM_find_item(sVCNum,&tVCItmM));
						if(tVCItmM != NULLTAG)
						{
							ITK_CALL(GRM_create_relation(tVCIDRev,tVCItmM, tRefCCVs, NULLTAG,&tRefCCVRel));
							printf("\nkk.Created relation between [%s,%s,%s] and [%s]",sVCIDNum,sVCIDRev,sVCIDRev,sVCNum);fflush(stdout);
							ITK_CALL(GRM_save_relation(tRefCCVRel));
						}
					}
					sVCNum = tc_strtok(NULL,":");
				}
				//}
			//}
					
			
				//TODO: Create snapshot.
				tc_strcpy(sVCIDSnap,sVCIDNum);
				tc_strcat(sVCIDSnap,"_");
				tc_strcat(sVCIDSnap,sVCIDRev);
				tc_strcat(sVCIDSnap,"_");
				tc_strcat(sVCIDSnap,sVCIDSeq);
				//ITK_CALL(ITEM_find_item(sVCIDSnap,&tFndVCIDSnp));
				int n_Input = 1;
				char	*qry_Input[1]	  = {"Name"}; 
				char	*qry_SnpVal[1];
				if(QRY_find2("SnapShot",&tQrySnap));
				if(tQrySnap)
				{
					qry_SnpVal[0]=sVCIDSnap;
					if(QRY_execute(tQrySnap, n_Input, qry_Input, qry_SnpVal,&nSnpCnt,&tpSnpObj));
					printf("\nkk.Snapshot count is:[%d]\n", nSnpCnt);fflush(stdout);
				}
				
				//if(tFndVCIDSnp != NULLTAG)
				if(nSnpCnt > 0)
				{
					tFndVCIDSnp = tpSnpObj[0];
					ITK_CALL(AOM_ask_value_string(tFndVCIDSnp,"object_type",&sVCIDSnpTyp));
					printf("\nkk.VCID Snapshot [%s,%s] is already created!!!\n",sVCIDSnap,sVCIDSnpTyp); fflush(stdout);
				}
				else
				{
					printf("\nkk.Create Snapshot for VCID [%s].\n",sVCIDSnap); fflush(stdout);
					//BOM_create_snapshot(window,SnapshotNo,"Snapshot for ECU",&snapshot));
				}
			}
		}
	}
			
	printf("\nkk.VCID migration code completed.\n"); fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}

