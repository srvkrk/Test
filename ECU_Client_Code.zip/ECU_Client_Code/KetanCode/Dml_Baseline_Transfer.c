#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include<ics/ics2.h>
//#include<ics/iman_ics.h>
//#include <tcfile_cache.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

char* Con_Part_List=NULL;


static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
//static void initialise (void);
static void initialise_attribute (char *name,  int *attribute);
//static void ExpandMultiLevelBom (tag_t bom_line_tag, int depth,FILE *fptr);
static void Container_List(tag_t);
int  Expansion_TPL_16(tag_t LatestModRevTag ,tag_t top_line,tag_t rule,char * VCnumberDup,char * RevIDNo,char * ObjDescFinal,char * vcDrStatDup,char * vcProjDup,char * partnumDup, tag_t tSnapFl,char* sVCID_Num,char* VCID_Rev);

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int setFindStr1(int *count,char ***strset,char* str)
 {
	int j   =0;

	//tmp = sizeof(*strset); 

	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
		if(tc_strcmp((*strset)[j],str)==0) //check this
		//if(tc_strcmp(*strset[j],str)==0)

		return j;

	}
	return -1;
 }

 int setFindStr2(int *start, int *count,char ***strset,char* str)
 {
	int j =0;
	for(j=*start;j<*count;j++) 
	{
		printf("\nkk.inside setFindStr2 %d \n",*count);fflush(stdout);
		printf("\nkk.setFindStr2 value is ===%s",(*strset)[j]);fflush(stdout);

		if(tc_strcmp((*strset)[j],str)==0)
			return j;
	}
	return -1;
 }

struct BomChldStrut_EE
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
	char *GrpID;
}*get_BomChldStrut_EE;

void Multi_Get_Part_BOM_Lvl_Col(tag_t top_line,int reqLevel,int level,tag_t SnapshotRevTag ,struct BomChldStrut_EE BomChldStrut[],int* StructChldCnt,char *GrpNum)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n_Cnt=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;

	char*			partColInd					=NULL;
	//tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	char* PrtCmpCode 	= NULL;

	int iCON =0;											 //18 SEPT
	int y =0;												 //18 SEPT
	char	**CONDetails		  =	NULL;					 //18 SEPT
	CONDetails = (char**)MEM_alloc( 1 * sizeof *CONDetails );//18 SEPT
	char * PartType = NULL;									 //18 SEPT
	char * child_item_id = NULL;							 //18 SEPT
	char * sPrtTyp = NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}
	
	if (level==0)
	{

	tag_t Modl_rev_tags = NULLTAG;
	ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&Modl_rev_tags));
				BomChldStrut[*StructChldCnt].child_objs = top_line;
				BomChldStrut[*StructChldCnt].child_objs_bvr=Modl_rev_tags;
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				BomChldStrut[*StructChldCnt].GrpID=GrpNum;

		ITKCALL(BOM_create_window (&window));
		BOM_create_window_from_snapshot(SnapshotRevTag,&window);
		ITKCALL(BOM_set_window_pack_all (window, true));

		BOM_set_window_top_line(window, null_tag,Modl_rev_tags ,null_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 3.42 Backend

	}

		tag_t objTypeTag = NULLTAG;
	char * partNumberRev =NULL;

	char * SnapNumber =NULL;

	
	ITKCALL(AOM_ask_value_string(SnapshotRevTag,"object_name",&SnapNumber));
	printf("\n Snapshot Name===>%s\n",SnapNumber);fflush(stdout);

	  ITKCALL(AOM_ask_value_string(top_line,"bl_rev_item_revision_id",&partNumberRev));
	printf("\n partNumberRevr===>%s\n",partNumberRev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));
    printf("\n Part number===>%s\n",partNumber);fflush(stdout);


		ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n_Cnt);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n_Cnt; k++)
		{
			int MatchFlag=0;																			   //18 SEPT
		
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			AOM_ask_value_tag(children[k], bomAttr_lineItemRevTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{
               ITKCALL( AOM_ask_value_string(t_ChildItemRev,"t5_SwPartType",&PartType));                   //18 SEPT
		       printf("\n t_ChildItemRev tag found ===>%s\n",PartType);fflush(stdout);					   //18 SEPT

			   ITKCALL(AOM_ask_value_string(t_ChildItemRev, "item_id", &child_item_id ));				   //18 SEPT
			   printf("\n t_ChildItemRev tag found  child_item_id===>%s\n",child_item_id);fflush(stdout);  //18 SEPT
			   
			   ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &sPrtTyp));
			   printf("\nkk.Part Type is [%s]\n",sPrtTyp);fflush(stdout);
			   
		       if(tc_strcmp(PartType,"CON")==0)                                                            //18 SEPT
				{
					//int ww=0;
					char* containerMatch=NULL;
					for (y=0;y<*StructChldCnt+1;y++)													   //18 SEPT
					{
						printf("\n..IN Expansion_TPL_16 structure.. :%d\n",y);fflush(stdout);			   //18 SEPT
						containerMatch=NULL;															   //18 SEPT
						
						tag_t ChildRevBomLine=NULLTAG;
				
						if( AOM_ask_value_string(BomChldStrut[y].child_objs,"item_id",&containerMatch)!=ITK_ok);//18 SEPT
						if (tc_strcmp(containerMatch,child_item_id)==0)											//18 SEPT
						{
							printf("\n..CONTAINER MATCH FOUND  :\n");fflush(stdout);
							MatchFlag=1;																	    //18 SEPT
							break;
						
						}
					}																						    //18 SEPT
																					
				}
				if (MatchFlag==0)																			    //18 SEPT
				{
					printf("\n..match not found.hence proceeding \n");fflush(stdout);
					*StructChldCnt	=	*StructChldCnt+1;
					//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k];
					BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
					BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
					BomChldStrut[*StructChldCnt].child_objs_lvl=level;
					BomChldStrut[*StructChldCnt].GrpID=GrpNum;

					if(tc_strcmp(sPrtTyp,"G")==0)
					{
						Multi_Get_Part_BOM_Lvl_Col(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,child_item_id);
					}
					else
					{
						Multi_Get_Part_BOM_Lvl_Col(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,GrpNum);
					}
				}

			}
		}
		level = level - 1;
	

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}



FILE *fptr;
FILE *fptr1;
FILE *fptr2;
FILE *fptr3;
FILE *fptr4;
FILE *fptr5;
FILE *fptr6;
FILE *fptr7;
FILE *fptr8;
FILE *fptr9;

char	**HWCList			=	NULL;
char	**CALList			=	NULL;
char	**PBLList			=	NULL;
char	**SBLList			=	NULL;
char	**BASList			=	NULL;
char	**APPList			=	NULL;
char	**STKList			=	NULL;
char	**VCIList			=	NULL;
char	**CFGList			=	NULL;
char	**PRMList			=	NULL;
char	**CONList			=	NULL;
char	**ParaList			=	NULL;
char	**ConatainerTypeListX=	NULL;
char	**ConatainerList	=   NULL;
char	**ConatainerRev		=   NULL;	
char	*DML_name			=   NULL;
char	*DML_Desc			=   NULL;
char	*DML_TrDesc			=	NULL;
char	* VCnumber			=   NULL;
char	* Vehnumber			=   NULL;
char	* VCnumberDup		=   NULL;
//char	* VehNumDup		=   NULL;
char	* req_item			=   NULL;
char	*	t5CountryValDup =   NULL;
char	*	t5MajorModelDup =   NULL;
char	*	t5NoEcuDup		=   NULL;
char	*	t5ABSValDup		=   NULL;
char	*	Noval			=  "0";
int     iWriteRPar			=   0;
int     iWriteRCon			=   0;
int     iWriteRConType		=   0;
int     iWriteRConrev		=   0;
int     iWriteP				=   0;
int		supfile				=   0;
int		calfilecnt			=   0;
tag_t	DMLRevTag			= NULLTAG;
char *req_item2				= NULL;
char *req_item3				= NULL;
tag_t	Mod_rev_tag				= NULLTAG;
tag_t	LatestModRevTag				= NULLTAG;
char	**ECUTypFull			=	NULL;
char	**ECUTypAbr			=	NULL;
int iECU1 = 0;
int iECU2 = 0;



static void initialise (void);
//static void initialise_attribute (char *name,  int *attribute);



void getCurrentDateTimeA(char* CurrentDate)
{ 
    time_t temp ; 
    struct tm *timeptr ; 
    char pAccessDate[30]; 

	CurrentDate		=(char *) MEM_alloc(30);
    time( &temp ); 
      
    tc_strcpy(pAccessDate,"");
    timeptr = localtime( &temp ); 

    strftime(pAccessDate, sizeof(pAccessDate), "%x - %I:%M%p", timeptr); 
      
    //printf("Formatted date & time : %s\n", pAccessDate ); 
	tc_strcpy(CurrentDate,pAccessDate);
	printf("\n CurrentDate AAAAAAA :%s\n",CurrentDate);
   // return(0); 
} 




char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* subStrParDsc (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(1100);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void strip(char *s) 
{ 
	char *p2 = s; 
	while(*s != '\0')
	{
		if(*s != '\t' && *s != '\n'  && *s != '\r') 
		{
			*p2++ = *s++; 
		} else
		{
			++s; 
		} 
	} 
	*p2 = '\0';
} 

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	int		count_tsk				= 0;
	int		pp						= 0;
	int		rr						= 0;
	int		aa						= 0;
	int  	n_parents				= 0;
	int  	count_DML				= 0;
	int  	*levels				    = 0;
	int  	VCcnt				    = 0;
	int  	Modcnt				    = 0;

	char *req_item2Dup				= NULL;
	char *req_item2DupS				= NULL;
	//char *inputfile					= NULL;
	char *outputfile				= NULL;
	char *partnumDup				= NULL;				
	char *object_type				= NULL;
	char *RevIDNo					= NULL;
	char *PartNo					= NULL;
	char *type_name					= NULL;
	char *task_name					= NULL;
	char *type_dml_name				= NULL;
	char *Report_Name				= NULL;
	char *Proj_Details				= NULL;
	char *VehicleC_Details			= NULL;
	char *Report_Para				= NULL;
	char *Report_Struct				= NULL;
	char *File_List					= NULL;
	char *Support_Master			= NULL;
	char *User_File					= NULL;
	char *VC_Details				= NULL;
	char *Assy_obj					= NULL;
	char *Assy_Rev					= NULL;
	char *Objdesc					= NULL;
	//char *VCnumber					= NULL;
	char *VCnumberRev				= NULL;
	char *VCnumberRevDup			= NULL;
	char *ProjDup					= NULL;
	char *Proj						= NULL;
	char *PartTypeM					= NULL;
	char *Techspecobjectdesc		= NULL;
	char *ModuleNoDup				= NULL;
	char *Modnumber					= NULL;
	char *vcDrStat					= NULL;
	char *vcDrStatDup				= NULL;
	char *vcProj					= NULL;
	char *vcProjDup					= NULL;
	char *vcVhProjDup				= NULL;
	char *MRevIDNo					= NULL;
	char *VCVal						= "NA";
	char *nwRev						= NULL;
	char *sTmpNum					= NULL;
	char *VCPartType				= NULL;
	char *sSysStr					= NULL;
	sSysStr = (char *) MEM_alloc(500);

	char*   NoObjDes				= "";

	tag_t window, rule, item_tag = null_tag, top_line;

	tag_t   LatestRev				= NULLTAG;
	tag_t   LatestModRevTag			= NULLTAG;
    tag_t	tsk_part_sol_rel_type	= NULLTAG;
    tag_t	techspec_rel_type		= NULLTAG;
    //tag_t	Design_rev_tag			= NULLTAG;
    //tag_t	Design_rev_tag_BL			= NULLTAG;
	tag_t   Vehicle_tag				= NULLTAG;
    tag_t	Main_CCID_rev_tag		= NULLTAG;
    tag_t	LatestRevTag			= NULLTAG;
	tag_t	objTaskTypeTag			= NULLTAG;
	tag_t	objDMLTypeTag			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	tag_t	dml_task_rel_type		= NULLTAG;
	tag_t	CCVCrelation_type       = NULLTAG;
	tag_t   *VCattachments			= NULLTAG;
	tag_t   *Modattachments			= NULLTAG;
	tag_t Mod_rev_tagP;
	tag_t	ReferencesCCVTag		= NULLTAG;
	tag_t	ProQryCCIDObj			= NULLTAG;

	tag_t	*TaskRevision			= NULLTAG;
	tag_t   *DMLRevision            = NULLTAG;
	tag_t	*parents				= NULLTAG;
	tag_t	*CCIDObj				= NULLTAG;
	tag_t	*tpDMLRv				= NULLTAG;
	tag_t	tDMLRev				= NULLTAG;
	tag_t	tHasNewVCIDRel			= NULLTAG;
	tag_t	*tpDmlVCIDs			= NULLTAG;

	int		n_Input					= 1;
	//int		CCIDCount				= 0;
	int		nDmlCount				= 0;
	int		nDmlVCIDCnt				= 0;
	int		iDVCnt				= 0;
	int		n_tags_found			= 0;
	int		n_tags_found1			= 0;
	int		desccnt					= 0;
	int		Objdesclength		    = 0;
	int		ccv						= 0;
	char	*sVCIDNum				= NULL;
	char	*sVCIDRev				= NULL;
	char	*cRplStr				= NULL;
	char	*ObjDescFinal				= NULL;
	char	*qry_Input[1]			= {"ID"};
	char	*values[1];
	tag_t   CCIDRev					= NULLTAG;
	tag_t	*tags_found				= NULL;
	tag_t	*tags_foundX			= NULL;

	//added by ajinkya//
	tag_t	window1	        = NULLTAG;
	tag_t	DesignMstrTag			= NULLTAG;
	tag_t	bl_Child_dv				= NULLTAG;
	tag_t  *children1				= NULLTAG;

	tag_t	sn_rule1				= NULLTAG; 
	tag_t	top_line1	    = NULLTAG;
	tag_t	DesignRevTag	= NULLTAG; 
	tag_t	VehVcTag		= NULLTAG; 
	int		n_Cnt1					= 3;
	int		jcnt				= 0;
	char *partNumber						= NULL;
	char	*LatChildName			=	NULL;
	char    *PartType1              = NULL;
	char    * Item_id_VEH = NULL; 

	tag_t *ProjCnObj				 = NULL;
	int		noOfInput					 = 2;
	int    ProjCodeCount				 = 0;
	int    CheckFlag				 = 0;
	int    bl						 = 0;
	int	  iBlItemIDseq				 = 0;
	char	*qryInputForProCode[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qryProjValForProCode[2] = {"CCID", "PROJCT"};
	tag_t	ProjectCodeQuery			 = NULLTAG;
	char	*info1					 = NULL;

	////For Altroz way Control Object
	tag_t AltrozWayQuery			 = NULLTAG;
	int	   noOfInputAltWay			 = 2;
	char *qryInputForAltWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForAltWay[2]     = {"Project", "AltrozWay"};
	int   AltWayCount				 = 0;
	tag_t *AltWayCnObj				 = NULL;
	//char *info1AltrozWay			 = NULL;

	////For Hornbill VCs Control Object
	tag_t HornbillWayQuery			 = NULLTAG;
	int	   noOfInputHornbillWay			 = 2;
	char *qryInputForHornbillWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForHornbillWay[2]     = {"Hornbill_Way_VC", "Hornbill_Way"};
	int   HornbillWayCount				 = 0;
	tag_t *HornbillWayCnObj				 = NULL;

	char *info1HornbillWay			 = NULL;
	char *info2HornbillWay			 = NULL;
	char *info3HornbillWay			 = NULL;
	char *info4HornbillWay			 = NULL;
	char *info5HornbillWay			 = NULL;
	char *info6HornbillWay			 = NULL;
	char *info7HornbillWay			 = NULL;
	char *info8HornbillWay			 = NULL;
	char *info9HornbillWay			 = NULL;
	char *info10HornbillWay			 = NULL;
	char* finalInfoHornbillWay       = NULL;

	int honbill =0;

	//Query For ECU Type Cntrl Obj
	
	tag_t ECUTypeQuery			 = NULLTAG;
	int	   noECUTypeEnt			 = 2;
	char *qryInputForECUType[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForECUType[2]     = {"ECU", "Mapping"};
	int  ECUTypeCount				 = 0;
	tag_t *ECUTypeCnObj				 = NULL;
	char *info1ECUType			 = NULL;
	char *info2ECUType			 = NULL;
	int iECnt =0;
	
	logical is16R				= false;
	logical lCallFnOnce			= true;

	//end


	(void)argc;
	(void)argv;

	initialise();

	//req_item  = ITK_ask_cli_argument("-i=");// Baseline number  -i=5442E4Z01016_01 -r='A'
	//req_item2 = ITK_ask_cli_argument("-r=");// revision 'A' LATER ON 'A;1'
	//req_item3 = ITK_ask_cli_argument("-s=");// sequence 1
	req_item  = ITK_ask_cli_argument("-dml=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));


	printf("\nkk.DML number is [%s]\n",req_item);fflush(stdout);

	//inputfile=(char *) MEM_alloc(50);

	//fprintf(fptr6,"\n Vc No,Desc ,Part_No,Part_Rev_Seq,Cal_Part,Cal File Name,Cal_Rev,Cal_Seq,ECU Type,HW_Part,HW_Rev,HW_Seq,VEH_Part,VEH_Rev,VEH_Seq,CFG_Part,CFG_Rev,CFG_Seq,APP_Part,APP_Rev,APP_Seq,PBL_Part,PBL_Rev,PBL_Seq,SBL_Part,SBL_Rev,SBL_Seq,No_Of_ECU\n");
	//req_item2Dup=(char *) MEM_alloc(20);
	//tc_strcpy(req_item2Dup,req_item2);//A;1
	//printf("\n req_item2Dup== %s", req_item2Dup);fflush(stdout);

	//req_item2DupS = tc_strtok(req_item2Dup,";");//A
	//req_item3 =tc_strtok(NULL,"");//1


	//printf("\n req_item2DupS== %s", req_item2DupS);fflush(stdout);
	//printf("\n req_item3== %s", req_item3);fflush(stdout);

	/*tc_strcpy(nwRev,"");
	//strcat(nwRev,req_item2Dup);
	tc_strcat(nwRev,req_item2DupS);
	tc_strcat(nwRev,"*");
	tc_strcat(nwRev,req_item3);
	printf("\nAAAAAAAAA  nwRev:::::::: = %s\n", nwRev);fflush(stdout);*/

	if( req_item )
	{
		//printf("\n nwRev:::::::: = %s", nwRev);fflush(stdout);
		values[0] = req_item;
		//values[1] = "VCID Revision";
		//values[2] = nwRev;

		if(QRY_find2("ERC DML", &ProQryCCIDObj));
		if(ProQryCCIDObj)
		{
			if(QRY_execute(ProQryCCIDObj, n_Input, qry_Input, values, &nDmlCount, &tpDMLRv));
			printf("\nkk.DML count is [%d]", nDmlCount);fflush(stdout);
		}
		if(nDmlCount < 1)
		{
			printf("\nkk.DML [%s] not found in PLM.\n",req_item);fflush(stdout);
			exit(0);
		}
		
		ECUTypFull = (char**)MEM_alloc( 1 * sizeof *ECUTypFull );
		ECUTypAbr = (char**)MEM_alloc( 1 * sizeof *ECUTypAbr );
		if(QRY_find2("ControlObjQry",&ECUTypeQuery));
		if(ECUTypeQuery)
		{
			 if(QRY_execute(ECUTypeQuery, noECUTypeEnt, qryInputForECUType, qryProjValForECUType, &ECUTypeCount, &ECUTypeCnObj));
			 printf("\n CONT for ECUTypeQuery CntrlObj == %d\n", ECUTypeCount);fflush(stdout);
		}
		else
		{
			printf("\n ContrlObj for ECUTypeQuery not found.");fflush(stdout);
		}
		if(ECUTypeCount >0)
		{
			for(iECnt=0; iECnt<ECUTypeCount; ++iECnt)
			{
				if (AOM_ask_value_string(ECUTypeCnObj[iECnt],"t5_Userinfo1",&info1ECUType)!=ITK_ok);
				printf("\n  info1ECUType [%s]",info1ECUType); fflush(stdout);
				setAddStr(&iECU1,&ECUTypFull,info1ECUType);

				if (AOM_ask_value_string(ECUTypeCnObj[iECnt],"t5_Userinfo2",&info2ECUType)!=ITK_ok);
				printf("\n info2ECUType [%s]",info2ECUType); fflush(stdout);
				setAddStr(&iECU2,&ECUTypAbr,info2ECUType);
			}
		}
		
		tDMLRev = tpDMLRv[0];
		ITK_CALL(GRM_find_relation_type("T5_HasNewCCID",&tHasNewVCIDRel));
		ITK_CALL(GRM_list_secondary_objects_only(tDMLRev,tHasNewVCIDRel,&nDmlVCIDCnt,&tpDmlVCIDs));
		printf("\nkk.VCID count in DML is [%d]", nDmlVCIDCnt);fflush(stdout);
		
		File_List =(char *) MEM_alloc(150);
		tc_strcpy(File_List,"/tmp/");
		tc_strcat(File_List,req_item);
		tc_strcat(File_List,"_Files.csv");
		
		fptr4 = fopen(File_List,"a+");
		if(fptr4==NULL)
		{
			printf("Error! in File opening...%s",File_List);  fflush(stdout);
			exit(1);
		}
		
		for(iDVCnt=0; iDVCnt<nDmlVCIDCnt; ++iDVCnt)
		{
			iWriteRPar			=   0;
			iWriteRCon			=   0;
			iWriteRConType		=   0;
			iWriteRConrev		=   0;
			iWriteP				=   0;
			supfile				=   0;
			calfilecnt			=   0;
			lCallFnOnce			= true;
			t5CountryValDup	=(char *) MEM_alloc(150);
			t5MajorModelDup	=(char *) MEM_alloc(150);
			t5NoEcuDup		=(char *) MEM_alloc(150);
			t5ABSValDup		=(char *) MEM_alloc(150);
			nwRev		=(char *) MEM_alloc(10);

			ParaList			= (char**)MEM_alloc( 1 * sizeof *ParaList );
			ConatainerTypeListX = (char**)MEM_alloc( 5 * sizeof *ConatainerTypeListX );
			ConatainerList		= (char**)MEM_alloc( 1 * sizeof *ConatainerList );
			ConatainerRev		= (char**)MEM_alloc( 1 * sizeof *ConatainerRev );
			
			Main_CCID_rev_tag = tpDmlVCIDs[iDVCnt];
			
			ITK_CALL(AOM_ask_value_string(Main_CCID_rev_tag,"item_id",&sVCIDNum));
			ITK_CALL(AOM_ask_value_string(Main_CCID_rev_tag,"item_revision_id",&sVCIDRev));
			printf("\nkk.Processing VCID [%s,%s]\n", sVCIDNum,sVCIDRev);fflush(stdout);

			Proj=subString(sVCIDNum,0,4); 
			printf("\n  Proj is ------------- [%s]\n",Proj);fflush(stdout);
		
			ProjDup=(char *) MEM_alloc(10);
			tc_strcpy(ProjDup,Proj);
			printf("\n  ProjDup ------------- [%s]\n",ProjDup); fflush(stdout);	
			 		   
			ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&ReferencesCCVTag));
			printf("\n After ReferencesCCVTag\n");fflush(stdout);

			ITK_CALL(GRM_list_secondary_objects_only(Main_CCID_rev_tag,ReferencesCCVTag,&VCcnt,&VCattachments));
			printf("\n VCcnt is ============= [%d]  \n",VCcnt); fflush(stdout);	

			
			Report_Name		=(char *) MEM_alloc(150);
			Report_Para		=(char *) MEM_alloc(150);
			Report_Struct	=(char *) MEM_alloc(150);
			Support_Master	=(char *) MEM_alloc(150);
			User_File		=(char *) MEM_alloc(150);
			VC_Details		=(char *) MEM_alloc(150);
			Proj_Details	=(char *) MEM_alloc(150);
			VehicleC_Details	=(char *) MEM_alloc(150);

			if (VCcnt > 0)
			{
				tc_strcpy(VehicleC_Details,"/tmp/");
				tc_strcat(VehicleC_Details,sVCIDNum);
				tc_strcat(VehicleC_Details,"_VCCRList.csv");

				printf("\n 66 after VCCRList.csv  \n");fflush(stdout);
				fptr9 = fopen(VehicleC_Details,"w"); // to handle multiple VC's
	
				for (ccv=0;ccv<VCcnt;ccv++ )
				{
					DesignMstrTag = VCattachments[ccv];

					ITK_CALL(ITEM_ask_latest_rev(DesignMstrTag,&DesignRevTag));


					VCnumberDup=(char *) MEM_alloc(50);
					vcProjDup=(char *) MEM_alloc(10);
					vcDrStatDup=(char *) MEM_alloc(10);
					vcVhProjDup ==(char *) MEM_alloc(10);

					if (DesignRevTag)
					{
						printf("\n DesignRevTag VC TO VEHICLE TAG FOUND  \n");fflush(stdout);
						if( AOM_ask_value_string(DesignRevTag,"item_id",&VCnumber)!=ITK_ok);
						tc_strcpy(VCnumberDup,VCnumber);
						printf("\n VC number get  is [%s]  \n",VCnumberDup); fflush(stdout);
						ITK_CALL(AOM_ask_value_string(DesignRevTag,"t5_PartType",&VCPartType));
						//ITK_CALL(AOM_ask_value_string(DesignRevTag,"bl_Design Revision_t5_PartType",&VCPartType));
						//ITK_CALL(AOM_ask_value_string(DesignRevTag,"bl_Design t5_RevPartType",&VCPartType));
						printf("\n VC Part Type : [%s] \n",VCPartType);
						vcVhProjDup=subString(VCnumber,0,4);
						printf("\n vcVhProjDup : [%s] \n",vcVhProjDup);



					}
					else
					{
						printf("\n null DesignRevTag- VC TO VEHICLE TAG FOUND  \n");fflush(stdout);
						exit(0);
					}	
					//Check if CCID is enable or not
					//if(tc_strstr(info1,ProjDup)!=NULL)
					//{
					//printf("\n CCID is enable and Project Code is : %s \n",ProjDup);fflush(stdout);
					//if(tc_strstr(info1HornbillWay,VCnumberDup) != NULL || tc_strcmp(ProjDup,"5445")==0 && tc_strcmp(VCPartType,"CCVC")==0)
					//if((tc_strstr(info1HornbillWay,VCnumberDup) != NULL || tc_strcmp(vcVhProjDup,"5445")==0) && tc_strcmp(VCPartType,"CCVC")==0)
					/*if((tc_strstr(finalInfoHornbillWay,VCnumberDup) != NULL || tc_strcmp(vcVhProjDup,"5445")==0) && tc_strcmp(VCPartType,"CCVC")==0)
					{
						printf("\n inside Hornwill way, VC with proj %s \n",vcVhProjDup);fflush(stdout);
						VehVcTag = DesignRevTag;	

					}*/
					//else if(tc_strstr(info1AltrozWay,ProjDup) != NULL || tc_strcmp(ProjDup,"5477")==0 && tc_strcmp(VCPartType,"V")==0)
					//else //if((tc_strstr(info1AltrozWay,vcVhProjDup) != NULL || tc_strcmp(vcVhProjDup,"5477")==0) && tc_strcmp(VCPartType,"V")==0)
					//{
					//printf("\n inside else, VC with proj %s \n",vcVhProjDup);
					VehVcTag = DesignRevTag;
					if(tc_strcmp(VCPartType,"VCCR")==0)
					{
						tc_strcpy(VCnumberDup,VCnumber);
					}
					else if(tc_strstr(VCnumber,"R")!=NULL)
					{
						sTmpNum=subString(VCnumber,0,8);
						tc_strcpy(VCnumberDup,sTmpNum);
						tc_strcat(VCnumberDup,"000R");
					}
					else if(tc_strstr(VCnumber,"L")!=NULL)
					{
						sTmpNum=subString(VCnumber,0,8);
						tc_strcpy(VCnumberDup,sTmpNum);
						tc_strcat(VCnumberDup,"000L");
					}
					printf("\nkk.Concatenated VC number is [%s]\n",VCnumberDup);fflush(stdout);
					//}
					/*else
					{
						printf("\nContinuing...\n");  fflush(stdout);
						continue;
					}	
					}
					else 
					{
						printf("\n CCID is NOT enable and Project Code is : %s \n",ProjDup);fflush(stdout);
					}*/
					//if(tc_strcmp(ProjDup,"5442")==0 && tc_strcmp(VCPartType,"V")==0)
					//{
						//printf("\n inside Veh with proj 5442\n");  fflush(stdout);
						//VehVcTag = DesignRevTag;
					//	sTmpNum=subString(VCnumber,0,8);
					//	tc_strcpy(VCnumberDup,sTmpNum);
					//	tc_strcat(VCnumberDup,"000R");
					//	printf("\nConcatenated VC number is [%s]\n",VCnumberDup);fflush(stdout);
					//} 
					//////else if(tc_strcmp(ProjDup,"5445")==0 && tc_strcmp(VCPartType,"CCVC")==0)
					//else if(tc_strstr(info1,ProjDup)!=NULL && tc_strcmp(VCPartType,"CCVC")==0)
				//	{
						//printf("\n inside VC with proj %s \n",ProjDup);fflush(stdout);
						//VehVcTag = DesignRevTag;
					//}
					
					//else
					//{
					//	printf("\nContinuing...\n");  fflush(stdout);
						//continue;
					//}
					/////////////////////////////////////////////////////////////////////////////////////////////////////////

				 	/*ITK_CALL(BOM_create_window (&window1)); //3 sept	
					ITK_CALL(BOM_set_window_pack_all (window1, true));//3 sept
					ITK_CALL(CFM_find("ERC Review And Above", &sn_rule1 ));
					ITK_CALL(BOM_set_window_config_rule( window1, sn_rule1 )); 
					printf("\n 11111111111 VehVcTag VC TO VEHICLE TAG FOUND  \n");fflush(stdout);
						
					ITK_CALL(BOM_set_window_top_line (window1, null_tag,VehVcTag,null_tag, &top_line1));




					ITK_CALL(BOM_window_show_suppressed (window1));

					printf("\n -------------------VC to Vehicle Expansion----- \n");fflush(stdout);

					
					ITK_CALL(AOM_ask_value_string(top_line1,"bl_item_item_id",&partNumber));// 3 sept
					printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);

					ITK_CALL(BOM_line_ask_child_lines (top_line1, &n_Cnt1, &children1)); //3 sept
					printf("\n\n\t\t **** VC contains child objects are :: %d \n", n_Cnt1);fflush(stdout);

					if (n_Cnt1>0)
					{
						printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt1);fflush(stdout);
						for (jcnt=0;jcnt<n_Cnt1;jcnt++)
						{
							printf("\n\n\t\t Inside for loop \n");fflush(stdout);

							bl_Child_dv=children1[jcnt];

							ITK_CALL(AOM_ask_value_string( bl_Child_dv,"bl_item_item_id",&LatChildName));
							printf("\n DVP-VC LatChildName Parts Id : [%s] \n",LatChildName);
					
							ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_PartType",&PartType1));
							printf("\nChildName Parts Type 11 : [%s] \n",PartType1);
							if((tc_strcmp(PartType1,"V")==0) || (tc_strcmp(PartType1,"Vehicle")==0))
							{
								Design_rev_tag_BL = bl_Child_dv;
								printf("\nCopying Vehicle Object from VC Object\n");fflush(stdout);
								break;
							}
						}
					}

						if (Design_rev_tag_BL)
						{

								printf("\n666 - VC TO VEHICLE TAG FOUND  \n");fflush(stdout);
						}
						else
						{
							printf("\n null - VC TO VEHICLE TAG FOUND  \n");fflush(stdout);
						}*/


				 //end//

				// ITK_CALL(ITEM_ask_latest_rev(Design_rev_tag,&LatestRev));
				 //if( AOM_ask_value_string(LatestRev,"item_id",&VCnumber)!=ITK_ok);
				 //if( AOM_ask_value_string(VehVcTag,"item_id",&VehNumDup)!=ITK_ok);
				// tc_strcpy(VehNumDup,Vehnumber);
				// printf("\n VEHICLE PART numberDup is [%s]  \n",VehNumDup); fflush(stdout);

				// if( AOM_ask_value_string(LatestRev,"t5_PartStatus",&vcDrStat)!=ITK_ok);
				 if( AOM_ask_value_string(VehVcTag,"t5_PartStatus",&vcDrStat)!=ITK_ok);
				 tc_strcpy(vcDrStatDup,vcDrStat);
				 printf("\n Vehicle DR  is [%s]  \n",vcDrStatDup); fflush(stdout);

				 if( AOM_ask_value_string(VehVcTag,"t5_ProjectCode",&vcProj)!=ITK_ok);
				 tc_strcpy(vcProjDup,vcProj);
				 printf("\n Vehicle ProjDup is [%s]  \n",vcProjDup); fflush(stdout);

				 //ITK_CALL(ITEM_find_item(VehNumDup,&Design_rev_tag));
				//printf("\n Function called FOR getting Vehicle Tag \n");fflush(stdout);

				//if( AOM_ask_value_string(Design_rev_tag,"item_id",&Item_id_VEH)!=ITK_ok);
			
				printf("\n  Veehicle Item ID is  ---->%s \n",Item_id_VEH); fflush(stdout);
				

				 
				//ITK_CALL(ITEM_ask_latest_rev(Design_rev_tag,&Vehicle_tag));
			
				/*if (Design_rev_tag)
				{

						printf("\n 77 - Design_rev_tag FOUND  \n");fflush(stdout);
				}
				else
				{
					printf("\n 88 - Else Design_rev_tag NULL FOUND  \n");fflush(stdout);
				}*/

				 ITK_CALL(AOM_ask_value_string(VehVcTag,"object_desc",&Objdesc));
				 printf("\n Vehicle Object_desc = [%s]\n",Objdesc);fflush(stdout);

				 ITK_CALL(AOM_ask_value_string(VehVcTag,"item_revision_id",&RevIDNo));
				 printf("\n V RevIDNo is  = [%s]\n", RevIDNo);fflush(stdout);

				printf("\n 55 VC number before creating file   = [%s]\n", VCnumberDup);fflush(stdout);				 	

				if(VCnumberDup)
				  {
					printf("\n CREATING CSV  \n");fflush(stdout);
					tc_strcpy(Report_Name,"/tmp/");
					tc_strcat(Report_Name,VCnumberDup);
					tc_strcat(Report_Name,"_VC.csv");//not for grpid

					printf("\n CREATING para CSV  \n");fflush(stdout);

					tc_strcpy(Report_Para,"/tmp/");
					tc_strcat(Report_Para,VCnumberDup);
					tc_strcat(Report_Para,"_Para.csv");

					tc_strcpy(Report_Struct,"/tmp/");
					tc_strcat(Report_Struct,VCnumberDup);
					tc_strcat(Report_Struct,"_Struct.csv");

					tc_strcpy(Support_Master,"/tmp/");
					tc_strcat(Support_Master,VCnumberDup);
					tc_strcat(Support_Master,"_SuppMstr.csv");

					tc_strcpy(User_File,"/tmp/");
					tc_strcat(User_File,VCnumberDup);
					tc_strcat(User_File,"_Summary.csv");

					tc_strcpy(VC_Details,"/tmp/");
					tc_strcat(VC_Details,VCnumberDup);
					tc_strcat(VC_Details,"_VCList.csv");

					printf("\n CREATING projlist CSV  \n");fflush(stdout);

					tc_strcpy(Proj_Details,"/tmp/");
					tc_strcat(Proj_Details,VCnumberDup);
					tc_strcat(Proj_Details,"_ProjList.csv");



				
					fptr1 = fopen(Report_Name,"w");
					fptr2 = fopen(Report_Para,"w");
					fptr3 = fopen(Report_Struct,"w");
					fptr5 = fopen(Support_Master,"w");
					fptr6 = fopen(User_File,"w");
					fptr7 = fopen(VC_Details,"w");
					fptr8 = fopen(Proj_Details,"w");


					printf("\n after fptr9  \n");fflush(stdout);
				  }

				  printf("\n before VCnumberDup  fptr9  \n");fflush(stdout); 
				  fprintf(fptr9,"%s\n",VCnumberDup);fflush(fptr9);
	
				 fprintf(fptr8,"%s\n",ProjDup);fflush(fptr8);

//				 printf("\n before VCnumberDup  fptr9  \n");fflush(stdout); 
//				 fprintf(fptr9,"%s\n",VCnumberDup);fflush(fptr9);

				 tag_t	SnapshotRevTag	= NULLTAG;
				 tag_t	HasSnapshot_type	= NULLTAG;
				 tag_t*	Snapshotattachments	= NULL;
				 int Snapcnt=0;

				 ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshot_type); 
				 printf("\n  Expansion_TPL_16 after snapshot rel \n");fflush(stdout);

				 ifail = GRM_list_secondary_objects_only(Main_CCID_rev_tag,HasSnapshot_type,&Snapcnt,&Snapshotattachments);
				 printf("\n  Snapcnt [%d] -------> \n",Snapcnt);fflush(stdout);
		

				 if (Snapcnt > 0)
				 {
					//Mod_rev_tag = Modattachments[0];
					//ModuleNoDup=(char *) MEM_alloc(50);
					//if( AOM_ask_value_string(Mod_rev_tag,"item_id",&Modnumber)!=ITK_ok);

					//ITEM_ask_item_of_rev(Mod_rev_tag,&Mod_rev_tagP); 	
					//ITEM_ask_item_of_rev(Mod_rev_tag,&LatestModRevTag); 

					SnapshotRevTag=Snapshotattachments[0];
					//Mod_rev_tag = Modattachments[0];
					 ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&LatestModRevTag));// THIS is the module based on which SS was create
									
					ITK_CALL(AOM_ask_value_string(LatestModRevTag,"item_id",&partnumDup));
					printf("\n partnumDup is   = [%s]\n", partnumDup);fflush(stdout);

					ITK_CALL(AOM_ask_value_string(LatestModRevTag,"item_revision_id",&MRevIDNo));
					printf("\n MRevIDNo is  = [%s]\n", MRevIDNo);fflush(stdout);
					 
					ITK_CALL(PS_where_used_all(LatestModRevTag,1,&n_parents,&levels,&parents));
					printf("\n Part attached to  count : %d\n",n_parents); fflush(stdout);

					if(n_parents>0)
					  {
						for (aa=0;aa<n_parents;aa++ )
						  {
							if(AssyTag) AssyTag=NULLTAG;
							AssyTag=parents[aa];

							ITK_CALL(AOM_ask_value_string(AssyTag,"item_id",&Assy_obj));
							printf("\n\t parent ID  is :%s",Assy_obj);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(AssyTag,"item_revision_id",&Assy_Rev));
							printf("\n\t parent REV ID  is :%s",Assy_Rev);fflush(stdout);
						  }
					  }


						printf("\n\t 11111111111--  :%s",Objdesc);fflush(stdout);
							if(tc_strcmp(Objdesc,"")!=0) //14aug changes
							{
								printf("\n\t 22222222222222 --  :%s",Objdesc);fflush(stdout);
								printf("\n\t parent REV ID  is :%s",Assy_Rev);fflush(stdout);
								Objdesclength = tc_strlen(Objdesc);
								for(desccnt=0;desccnt<Objdesclength;desccnt++)
								{
									printf("\n\t 333333333333--  :%s",Objdesc);fflush(stdout);
									if(Objdesc[desccnt]=='\n')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='`')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='~')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='|')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='&')
										Objdesc[desccnt] ='-';
//
//									if(Objdesc[desccnt]=='#')
//										Objdesc[desccnt] =' ';
//
//									if(Objdesc[desccnt]=='@')
//										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='^')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]=='!')
										Objdesc[desccnt] =' ';

									if(Objdesc[desccnt]==',')
										Objdesc[desccnt] =' ';
									printf("\n 44444444444 [%c]\n",Objdesc[desccnt]);fflush(stdout);
								}
								printf("\n 55555555555 [%c]\n",Objdesc[desccnt]);fflush(stdout);
								//val=(char **)MEM_alloc(sizeof(char **));
								ObjDescFinal = (char *)MEM_alloc (Objdesclength * sizeof(char));
								tc_strcpy(ObjDescFinal,Objdesc);
								printf("\n ObjDescFinal is----------------- = [%s]\n",ObjDescFinal);fflush(stdout);
							}//14aug changes
							else
							{
								  ObjDescFinal=(char *) MEM_alloc(100);
								  tc_strcpy(ObjDescFinal,NoObjDes);
								  printf("\n else else ObjDescFinal is --------- [%s]\n",ObjDescFinal); fflush(stdout);
							}

					int ic=0,xc=0;
					int theAttributeCount =0;
					int *theAttributeIds ;
					char **theAttributeNames = NULL;
					int *theAttributeValCounts=0;
					char***       theAttributeValues = NULL;
					char***       theAttributeOptimizedUnits = NULL;
					char* 	attrId = NULL;
					attrId = (char *) MEM_alloc(50 * sizeof(char));
					tag_t Design_rev_cls_tag    = NULLTAG;
					tc_strcpy(t5CountryValDup,"NA");
					tc_strcpy(t5MajorModelDup,"NA");
					tc_strcpy(t5NoEcuDup,"0");
					tc_strcpy(t5ABSValDup,"NA");
					(ICS_ask_classification_object(DesignMstrTag,&Design_rev_cls_tag));
					if(Design_rev_cls_tag)
					{
						ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
						if(theAttributeCount>0)
						{
							for(ic=0;ic<theAttributeCount;ic++)
							{
								sprintf(attrId,"%d",theAttributeIds[ic]);
								if(tc_strcmp(theAttributeNames[ic],"[VC]COUNTRIES_OF_EXPORT")==0)
								{
									tc_strcpy(t5CountryValDup,"");
									for(xc=0;xc<theAttributeValCounts[ic];xc++)
									{
										tc_strcat(t5CountryValDup,theAttributeValues[ic][xc]);
									}

									printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
									printf("\n attrId:[%s]",attrId);fflush(stdout);
									printf("\n theAttribute value:[%s] ",t5CountryValDup);fflush(stdout);
								}
								if(tc_strcmp(theAttributeNames[ic],"[VC]MAJORMODEL")==0)
								{
									tc_strcpy(t5MajorModelDup,"");
									for(xc=0;xc<theAttributeValCounts[ic];xc++)
									{
										tc_strcat(t5MajorModelDup,theAttributeValues[ic][xc]);
									}

									printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
									printf("\n attrId:[%s]",attrId);fflush(stdout);
									printf("\n theAttribute value:[%s] ",t5MajorModelDup);fflush(stdout);
								}
								if(tc_strcmp(theAttributeNames[ic],"Total number of ECUs")==0)
								{
									tc_strcpy(t5NoEcuDup,"");
									for(xc=0;xc<theAttributeValCounts[ic];xc++)
									{
										tc_strcat(t5NoEcuDup,theAttributeValues[ic][xc]);
									}

									printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
									printf("\n attrId:[%s]",attrId);fflush(stdout);
									printf("\n theAttribute value:[%s] ",t5NoEcuDup);fflush(stdout);
								}
								if(tc_strcmp(theAttributeNames[ic],"SAFETY_FEATURES")==0)
								{
									tc_strcpy(t5ABSValDup,"");
									for(xc=0;xc<theAttributeValCounts[ic];xc++)
									{
										tc_strcat(t5ABSValDup,theAttributeValues[ic][xc]);
									}

									printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
									printf("\n attrId:[%s]",attrId);fflush(stdout);
									printf("\n theAttribute value:[%s] ",t5ABSValDup);fflush(stdout);
								}
							}
						}
					}
					else
					{
						printf("\n Design_rev_cls_tag NOT Found.."); fflush(stdout);//10

					}

					printf("\n uv transfer  \n ");fflush(stdout);

					int pp = 0;
					int count_DML = 0;
					int nDscLen = 0;
					int iDscLen = 0;
					char *type_dml_name = NULL;
					tag_t	tsk_part_sol_rel_type	= NULLTAG;
					tag_t   *DMLRevision            = NULLTAG;
					tag_t	DMLRevTag			= NULLTAG;
					tag_t	objDMLTypeTag			= NULLTAG;
					
					ITKCALL(GRM_find_relation_type("T5_HasNewCCID",&tsk_part_sol_rel_type));  
					if(tsk_part_sol_rel_type!=NULLTAG)
					{
						printf("\n Hs new VCID rel found \n ");fflush(stdout);
						GRM_list_primary_objects_only(Main_CCID_rev_tag,tsk_part_sol_rel_type,&count_DML,&DMLRevision);
						printf("\nkk.No of DML FOUND ----------- %d",count_DML);fflush(stdout);
						if(count_DML>0)
						{
							for(pp=0;pp<count_DML;pp++)
							{
								DMLRevTag	=	NULLTAG;
								DMLRevTag	=	DMLRevision[pp];
								if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
								if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
								printf("\nkk.type_dml_name for object     %s \n", type_dml_name);fflush(stdout);
								if(tc_strcmp(type_dml_name,"ChangeRequestRevision")==0)
								{
									ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&DML_name));
									ITKCALL(AOM_ask_value_string(DMLRevTag,"object_desc",&DML_Desc));
									if(tc_strcmp(DML_Desc,"")!=0)
									{
										nDscLen = tc_strlen(DML_Desc);
										printf("\n\tkk.DML length and desc is [%d,%s]",nDscLen,DML_Desc);fflush(stdout);
										for(iDscLen=0;iDscLen<nDscLen;iDscLen++)
										{
											if(DML_Desc[iDscLen]=='\n')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]=='`')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]=='~')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]=='|')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]=='&')
												DML_Desc[iDscLen] ='-';

											if(DML_Desc[iDscLen]=='^')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]=='!')
												DML_Desc[iDscLen] =' ';

											if(DML_Desc[iDscLen]==',')
												DML_Desc[iDscLen] =' ';
											
											if(DML_Desc[iDscLen]=='\'')
												DML_Desc[iDscLen] =' ';
											//printf("\n 44444444444 [%c]\n",DML_Desc[iDscLen]);fflush(stdout);
										}
										//val=(char **)MEM_alloc(sizeof(char **));
										if(nDscLen > 99)
										{
											DML_TrDesc = (char *)MEM_alloc (100);
											DML_TrDesc = subString(DML_Desc,0,99);
										}
										else
										{
											DML_TrDesc = (char *)MEM_alloc (nDscLen * sizeof(char));
											tc_strcpy(DML_TrDesc,DML_Desc);
										}
										//printf("\n DML_TrDesc is----------------- = [%s]\n",DML_TrDesc);fflush(stdout);
									}
									else
									{
										  DML_TrDesc=(char *) MEM_alloc(100);
										  tc_strcpy(DML_TrDesc,"NA");
										  //printf("\nkk.DML_TrDesc is --------- [%s]\n",DML_TrDesc); fflush(stdout);
									}
									printf("\nkk.DML name and desc is [%s,%s]\n",DML_name,DML_TrDesc);fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n No DML found...!!!\n");fflush(stdout);
							DML_TrDesc=(char *) MEM_alloc(100);
							tc_strcpy(DML_TrDesc,"NA");
							tc_strcpy(DML_name,"NA");
						}
					}  

					
				  }

				tag_t Modl_rev_tags = NULLTAG;
				ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&Modl_rev_tags));

				ifail =BOM_create_window_from_snapshot(SnapshotRevTag,&window);
				
				printf("\n  After BOM_create_window------- \n");fflush(stdout);

				//ifail = BOM_set_window_top_line (window, null_tag, SnapshotRevTag, null_tag, &top_lineS);

				//ifail = BOM_set_window_top_line (window, null_tag, Design_rev_tag, null_tag, &top_line);
				ifail = BOM_set_window_top_line (window, null_tag, Modl_rev_tags, null_tag, &top_line);
				CHECK_FAIL;

				ifail = BOM_window_show_suppressed ( window );
				CHECK_FAIL;

				ITK_CALL(BOM_set_window_pack_all(window, FALSE));

				if(fptr1==NULL)
				{
					printf("Error! in File opening...%s",Report_Name);  fflush(stdout);
					exit(1);
				}
				if(fptr2==NULL)
				{
					printf("Error! in File opening...%s",Report_Para);  fflush(stdout);
					exit(1);
				}
				if(fptr3==NULL)
				{
					printf("Error! in File opening...%s",Report_Struct);  fflush(stdout);
					exit(1);
				}
				if(fptr5==NULL)
				{
					printf("Error! in File opening...%s",Support_Master);  fflush(stdout);
					exit(1);
				}
				if(fptr6==NULL)
				{
					printf("Error! in File opening...%s",User_File);  fflush(stdout);
					exit(1);
				}
				if(fptr7==NULL)
				{
					printf("Error! in File opening...%s",VC_Details);  fflush(stdout);
					exit(1);
				}
			   if(fptr8==NULL)
				{
					printf("Error! in File opening...%s",Proj_Details);  fflush(stdout);
					exit(1);
				}


				printf("\n Calling all functions now...\n");  fflush(stdout);

				//Container_List (top_line,rule,VCnumberDup,RevIDNo,Objdesc);
				if(lCallFnOnce)
				{
					lCallFnOnce = false;
					Container_List(SnapshotRevTag);
				}

				printf("\n END OF Container_List AAAA..\n");  fflush(stdout);

				Expansion_TPL_16 (LatestModRevTag,top_line,rule,VCnumberDup,RevIDNo,ObjDescFinal,vcDrStatDup,vcProjDup,partnumDup,SnapshotRevTag,sVCIDNum,sVCIDRev);
			}
		}
		else
		{  
			VCnumberDup=(char *) MEM_alloc(50);

			tc_strcpy(VCnumberDup,VCVal);
			printf("\n else VCnumberDup ============= [%s]  \n",VCnumberDup); fflush(stdout);
		}
		
		*ParaList = NULL;
		*ConatainerTypeListX = NULL;
		*ConatainerList = NULL;
		*ConatainerRev = NULL;
		
		//Call data transfer shell here
		printf("\nkk.Calling VCID transfer shell.\n"); fflush(stdout);
		char *sTmpVCIDRv = NULL;
		ITK_CALL(STRNG_replace_str(sVCIDRev,";","_",&sTmpVCIDRv));
		
		tc_strcpy(sSysStr,"./Dml_VCID_Transfer.sh ");	//TODO: create this shell 
		tc_strcat(sSysStr,sVCIDNum);
		tc_strcat(sSysStr," '");
		tc_strcat(sSysStr,sVCIDRev);
		tc_strcat(sSysStr,"' > /tmp/");
		tc_strcat(sSysStr,sVCIDNum);
		tc_strcat(sSysStr,"_");
		tc_strcat(sSysStr,sTmpVCIDRv);
		tc_strcat(sSysStr,"_VCID_Transfer.log");
		
		printf("\nkk.Calling command:\n%s\n",sSysStr); fflush(stdout);
		
		system(sSysStr);
	}

	MEM_free(tags_found);
	}
	else
	{
		printf ("Pls enter input part ?? \n"); fflush(stdout);
		exit (0);
	}

	if (DesignMstrTag == null_tag)
	{
		printf ("\n references CCV rel not found -DesignMstrTag ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item); fflush(stdout);
		exit (0);
	}

	printf("\nkk...Data Generation Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}
    			
void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }

    if(index != 0)
    {
        /* Shift all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}

int  Expansion_TPL_16(tag_t LatestModRevTag ,tag_t top_line,tag_t rule,char * VCnumberDup,char * RevIDNo,char * ObjDescFinal,char * vcDrStatDup,char * vcProjDup,char * partnumDup, tag_t tSnapFl,char* sVCID_Num,char* sVCID_Rev)
{

	int		statusZ;
	int		statusZZ;
	int		ww            = 0;
	int		yy            = 0;
	int		n_tags_found4 = 0;
	int		n_tags_found6 = 0;
	int		jj			  = 0;
	int		cnt			  = 0;
	int		cntX		  = 0;
	int		countZ		  = 0;
	int		countZZ		  = 0;
	int		calfiletest   = 0;
	int		CalFlileReq   = 0;
	int		kp			  = 0;
	int		bb		      = 0;
	int     flag		  = 0;
	int     flagX		  = 0;
	int     iWrite		  = 0;
	int     iRead		  = 0;
	int     iRead2		  = 0;
	int     m			  = 0;
	int     mm			  = 0;
	int     index		  = 0;
	int     indexcon	  = 0;
	int     wx			  = 0;
	int     wy			  = 0;
	int     PartCnt		  = 0;
	int     num			  = 0;
	int     pCnt			  = 0;
	int     ms			  = 0;
	int     mt			  = 0;
	int     ss			  = 0;
	int iCnt =0;		
	int iPrIndx = 0;
	int iStrtIndx = 0;

tag_t top_lineS;
	tag_t  *tags_found4   = NULL;
	tag_t  *tags_found6   = NULL;
	tag_t   ChildRev      = NULLTAG;
	tag_t   ContChildRev  = NULLTAG;

	tag_t   SpkitTag	  = NULLTAG;
	tag_t   Sparekit      = NULLTAG;
	tag_t sp_kit_rel_type = NULLTAG;
	tag_t Parameter_type  = NULLTAG;
	tag_t	namedrefobject     = NULLTAG;
	tag_t	ParaPtr       = NULLTAG;
	

	char* container		  = NULL;
	char* containerrev	  = NULL;
	char* ConProject	  = NULL;
	char* EEPartType	  = NULL;
	char* PartType		  = NULL;
	char* TPLEOL		  = NULL;
	char* ContEOL		  = NULL;
	char* Cnt_EcuType	  = NULL;
	char* Sp_ItemID		  = NULL;
	char* Sp_ItemREV	  = NULL;
	char* Sp_ItemRV		  = NULL;
	char* contpartrev	  = NULL;
	char* contpart		  = NULL;
	char* ProjectC		  = NULL;
	char* ChdPartType	  = NULL;
	char* Desg			  = NULL;
	char* ownername		  = NULL;

	//char orig_name[IMF_filename_size_c + 1];
	char *orig_name = NULL;
	char *pathname		  = NULL;
	char *relative_path		  = NULL;

	char * test_file      = NULL;
	char * test_file2      = NULL;
	char * test_file3     = NULL;
	char * test_fileX      = NULL;
	char *cRplStr		  =	NULL;
	char *cRplStrdup		  =	NULL;
	char *NewcRplStrdup		  =	NULL;
	char *sParaDesc = NULL;



	char	*contpartrevdup		= NULL;
	char	*ContainerRevValDup	= NULL;

	char*	EOLDup			=	NULL;
	char*	EOL_Val			=	NULL;
	//char*	EOL_Val_Both	=	"BOTH";
	//char*	EOL_Val_N		=	"N";
	char*	EOL				=	NULL;
	char*	EOLNA			=	"NA";
	char*	ValBoth			=	"BOTH";
	char*	WriteVal		=	"WRITE";
	char*	ReadVal			=	"READ";
	char*	ServVal			=	"SERVICE";
	char*	NoValStr		=	"NA";
	char*	EOL_Val_Both	=	"BOTH";
	char*	EOL_Val_N		=	"N";
	char*	sAll			=	"ALL";
	char*   objtype			=	NULL;
	char*   AtttachFileNames  = NULL;
	char*   Sticker			  = NULL;
	char*   Pr_Boot_Loader_Sm = NULL;
	char*   Pr_Boot_Loader	  = NULL;
	char*   BasicSw			  = NULL;
	char*   BASIC			  = "NA";
	char*   SLV				  = "NA";
	char*   Se_Boot_Loader    = NULL;
	char*   Se_Boot_Loader_Sm = NULL;
	char*   AppSw_Sm	      = NULL;
	char*   AppSw		      = NULL;
	char*   CalSw		      = NULL;
	char*   CalSw_Sm	      = NULL;
	char*   CalSw_SmDup	      = NULL;
	char*   CfgSw_Sm	      = NULL;
	char*   CfgSw		      = NULL;
	char*   VehCal		      = NULL;
	char*   VehCal_Sm	      = NULL;
	char*   HwPart_Sm	      = NULL;
	char*   HwPart		      = NULL;
	char*   CalSwDup	      = NULL;
	char*   CalFileName	      = NULL;
	char*   NoParaDes	      = "";

	char *CurrentDate		  = NULL;;
	char * DateDup		      = NULL;
	char * ItemId2		      = NULL;
	char * ItemId1		      = NULL;

	char	**SWDetails		  =	NULL;
	char	**HWDetails	      =	NULL;
	char * PRM_EcuType		  = NULL;
	char * sParPrt			  = NULL;
	char * paraecutype		  = NULL;
	char * paradesc			  = NULL;
	char * sVehicleType		  = NULL;
	char * sMVehicleType	  = NULL;
	char * sSVehicleType	  = NULL;
	char * ParaApp			  = NULL;
	char * ParaRead			  = NULL;
	char * DefValue			  = NULL;
	char * ValSer			  = "SERVICE";


	char * paraunit		     = NULL;
	char * paraeptype		 = NULL;
	char * paraeptypedup	 = NULL;
	char * paralen			 = NULL;
	char * paramin			 = NULL;
	char * paramax			 = NULL;
	char * parastep			 = NULL;
	char * ParaDIDVal		 = NULL;
	char * paradoc			 = NULL;
	char * 	 Noval			 = "0";
	char * paradocdupS		 = NULL;
	char * paravalid		 = NULL;
	char * paravallist		 = NULL;
	char * CreDate			 = NULL;
	char * ParaAppdup_Val    = NULL;
	char * ParaReaddup_Val   = NULL;
	char * conitemid	     = NULL;
	char * conitemrevid	     = NULL;

	char * ChildRevitemid	 = NULL;
	char * ChildRevitemrevid = NULL;
	char * slavecontainer    = NULL;
	char * mastercontainer   = NULL;
	char * containerslv      = NULL;
	char * containermst      = NULL;
	char * byte1             = NULL;
	char * byte_size         = NULL;
	char * name              = NULL;
	char * DRStatus          = NULL;
	char * CalFileNameDup    = NULL;
	char * BitValue          = NULL;

	char * CCIDNumberS       = NULL;
	char * CCIDNumberDupS    = NULL;
	char * Cciditem_rev      = NULL;
	char * CCIDRevDupS       = NULL;
	//char * CcidSeq           = NULL;
	//char * CCIDSeqDupS       = NULL;
	int CcidSeq;
	char * CcidAppDupS       = NULL;
	char * CcidAppS          = NULL;

	char * Cciditem_revS     = NULL;
	char * MltCciditem_rev   = NULL;
	char * MltCCIDNumberS    = NULL;
	char * MltCCIDSeqDupS    = NULL;
	char * MltCCIDRevDupS    = NULL;
	char * MltCCIDNumberDupS = NULL;
	char * CCIDRevDupS1 = NULL;
	//long		byte1			= 0;

	int ifail;
	int status;
	int iStatus=0;
	int referencenumberfound =0;
	int cntEE =0;
	int ee =0;
	int ic =0;
	int ValFlag =0;
	int Slvcnt =0;
	int Mstrcnt =0;
	int Msflag =0;
	int Mflag =0;
	int Sflag =0;
	int paradesccnt =0;
	int paradesclength =0;
	int paraeptypelength =0;
	int paraccnt =0;
	int 	mach_type = SS_UNIX_MACHINE;

	tag_t window, item_tag = null_tag,top_line2;
	tag_t window2               = NULLTAG;
	tag_t *childrenZ;
	tag_t *childrenZZ;
	tag_t *attachments			= NULLTAG;
	tag_t *attachmentsX			= NULLTAG;
	tag_t *attachmentsEE		= NULLTAG;
	tag_t *Slvattachments		= NULLTAG;
	tag_t *Mstrattachments		= NULLTAG;
	tag_t dataset				= NULLTAG;
	tag_t SlaveNo				= NULLTAG;
	tag_t MstrNo				= NULLTAG;
	tag_t ParaMaster			= NULLTAG;
	tag_t relation_type         = NULLTAG;
	tag_t EErelation_type       = NULLTAG;
	tag_t ConPararelation_type  = NULLTAG;
	tag_t MstrSlvrelation_type  = NULLTAG;
	char	 *NewDate			= NULL;
	char *type					= NULL;
	//char *MltCcidSeq					= NULL;
	int MltCcidSeq;

	tag_t*	PartTags			= NULLTAG;
	tag_t	relationprop		= NULLTAG;
	tag_t*	Prm_Reltags			= NULLTAG;
	tag_t	PrmRelTag			= NULLTAG;
	tag_t	HasNewCCID_type		= NULLTAG;
	tag_t	HasSnapshot_type	= NULLTAG;
	tag_t  *CCIDattachments		= NULLTAG;
	tag_t  *Snapshotattachments	= NULLTAG;
	int		CCIDcnt				= 0;
	int		Snapcnt				= 0;
	int		cc					= 0;
	tag_t 	CCIDRevTag			= NULLTAG;
	tag_t 	CCIDMstRevTag			= NULLTAG;
	tag_t 	SnapshotRevTag			= NULLTAG;

	tag_t type_tag			= NULLTAG;
	tag_t property_tag		= NULLTAG;
	tag_t base_prop_tag		= NULLTAG;
	tag_t base_type_tag		= NULLTAG;

	int *order = (int* )MEM_alloc(sizeof(int));
	order[0] =0;
	int n_sorted_tags =0;
	tag_t *sorted_tags = NULLTAG;


//char * ParaReaddup_Val =NULL;
char * parastepdup   =NULL;
char * paradocdup   =NULL;
char* containermstrev =NULL;
char* mastercontainerrev =NULL;


	//int length	=0;	  
	//int byte1int	=0;	  
	long byte1int	=0;	  

	char *reference_nameDS=NULL;	
	reference_nameDS=(char *) MEM_alloc(15);

	char *Exfile=NULL;	
	Exfile=(char *) MEM_alloc(300);

	AE_reference_type_t reftype;
	//char refname[AE_reference_size_c + 1];
	char *refname = NULL;
	//pathname		 =(char *) MEM_alloc(300);
	AtttachFileNames =(char *) MEM_alloc(4000);

    SWDetails = (char**)MEM_alloc( 1 * sizeof *SWDetails );
    HWDetails = (char**)MEM_alloc( 1 * sizeof *HWDetails );

	time_t temp ; 
    struct tm *timeptr ; 
    char pAccessDate[30]; 

	CurrentDate		=(char *) MEM_alloc(30);
    time( &temp ); 
      
    tc_strcpy(pAccessDate,"");
    timeptr = localtime( &temp ); 

    strftime(pAccessDate, sizeof(pAccessDate), "%x - %I:%M%p", timeptr); 
      
    printf("Formatted date & time  Expansion_TPL_16 : %s\n", pAccessDate ); 
	tc_strcpy(CurrentDate,pAccessDate);
	printf("\n CurrentDate AAAAAAA Expansion_TPL_16 :%s\n",CurrentDate);

	char * CurrentDateDup =NULL;
	char * GetPartNum =NULL;
	char * RevTPL =NULL;
	char * CurrentDateDupNew =NULL;
	CurrentDateDup=(char *) MEM_alloc(50);
	CurrentDateDupNew=(char *) MEM_alloc(50);

	char	*strToBereplaceddate;
	char	*strToBeUsedInsteaddate;

	strToBereplaceddate		=	(char*)malloc(5);
	tc_strcpy(strToBereplaceddate,"/");

	strToBeUsedInsteaddate	=	(char*)malloc(5);
	tc_strcpy(strToBeUsedInsteaddate,"-");

	ifail =STRNG_replace_str (CurrentDate,strToBereplaceddate, strToBeUsedInsteaddate,&CurrentDateDup); 
	printf("\n..CurrentDateDup [%s].. \n",CurrentDateDup);fflush(stdout);//02-13-2020 04:33PM

    tc_strcpy(CurrentDateDupNew,CurrentDateDup); 
																														
    NewDate=subString(CurrentDateDupNew,0,10); 
    printf("\n NewDate is ------------  = [%s]\n", NewDate);fflush(stdout);

	ifail = GRM_find_relation_type("T5_IsMemberOfCCID",&HasNewCCID_type); 
	printf("\n  Expansion_TPL_16 after HasNewCCID_type ======== \n");fflush(stdout);

	ifail = GRM_list_secondary_objects_only(LatestModRevTag,HasNewCCID_type,&CCIDcnt,&CCIDattachments);

	 if( AOM_ask_value_string(LatestModRevTag,"item_id",&GetPartNum)!=ITK_ok);  
	  printf("\n GetPartNum-----------  = [%s]\n", GetPartNum);fflush(stdout);

	 
	 if( AOM_ask_value_string(LatestModRevTag,"item_revision_id",&RevTPL)!=ITK_ok);  
	  printf("\n RevTPL-----------  = [%s]\n", RevTPL);fflush(stdout);

	
	//ITK_CALL(ITEM_ask_latest_rev(LatestModRevTag,&CCIDRevTag));

   printf("\n CCIDcnt is============= [%d]  \n",CCIDcnt); fflush(stdout);	
	if (CCIDcnt > 0)
	 {
		if (CCIDcnt > 1)
		 {
		   CCIDNumberDupS     = NULL;
		   CCIDRevDupS		   = NULL;
		   CCIDNumberDupS	   =(char *) MEM_alloc(50);
		   CCIDRevDupS		   =(char *) MEM_alloc(5);
		   CCIDRevDupS1		   =(char *) MEM_alloc(5);
		   CcidAppDupS		   =(char *) MEM_alloc(10);
		   for (cc=0;cc<CCIDcnt;cc++ )
			 {
				 CCIDRevTag=CCIDattachments[cc];
				// ITK_CALL(ITEM_ask_latest_rev(CCIDMstRevTag,&CCIDRevTag));
//				 MltCCIDNumberDupS     = NULL;
//				 MltCCIDRevDupS		   = NULL;
//				 MltCCIDSeqDupS		   = NULL;
//				 MltCCIDNumberDupS	   =(char *) MEM_alloc(50);
//				 MltCCIDRevDupS		   =(char *) MEM_alloc(5);
//				 MltCCIDSeqDupS		   =(char *) MEM_alloc(5);
//
//				 if(AOM_ask_value_string(CCIDRevTag,"item_id",&MltCCIDNumberS)==ITK_ok);
//				 tc_strcpy(MltCCIDNumberDupS,MltCCIDNumberS);			  
//				 printf("\n MltCCIDNumberDupS is  = [%s]\n", MltCCIDNumberDupS);fflush(stdout);
//				  
//				 if(AOM_ask_value_string(CCIDRevTag,"item_revision_id",&MltCciditem_rev)==ITK_ok);
//				 tc_strcpy(MltCCIDRevDupS,MltCciditem_rev);
//				 printf("\n MltCCIDRevDupS IS --------->[%s]\n",MltCCIDRevDupS);fflush(stdout);
//
//				 //if(AOM_ask_value_string(CCIDRevTag,"sequence_id",&MltCcidSeq)==ITK_ok);
//				 if(AOM_ask_value_int(CCIDRevTag,"sequence_id",&MltCcidSeq)==ITK_ok);
//				// tc_strcpy(MltCCIDSeqDupS,MltCcidSeq);
//				// printf("\n MltCCIDSeqDupS IS --------->[%s]\n",MltCCIDSeqDupS);fflush(stdout);
//
//				 if((tc_strcmp(MltCCIDNumberDupS,req_item)==0) && (tc_strcmp(MltCCIDRevDupS,req_item2)==0))
//				 {
//					 printf("\n match found \n");fflush(stdout);
//					 break;
//				 }



				 if(AOM_ask_value_string(CCIDRevTag,"item_id",&CCIDNumberS)==ITK_ok);
				 tc_strcpy(CCIDNumberDupS,CCIDNumberS);			  
				 printf("\n CCIDNumberDupS is  = [%s]\n", CCIDNumberDupS);fflush(stdout);
				  printf("\n input VCID iS --------->[%s]\n",sVCID_Num);fflush(stdout);
				 printf("\n CCIDRevDupS1 IS --------->[%s]\n",CCIDRevDupS1);fflush(stdout);
				 printf("\n input rev iS --------->[%s]\n",sVCID_Rev);fflush(stdout);
				  
				 if(AOM_ask_value_string(CCIDRevTag,"item_revision_id",&Cciditem_rev)==ITK_ok);
				 tc_strcpy(CCIDRevDupS1,Cciditem_rev);
				
				

				 if((tc_strcmp(CCIDNumberDupS,sVCID_Num)==0) && (tc_strcmp(CCIDRevDupS1,sVCID_Rev)==0))
				 {
					 printf("\n match found \n");fflush(stdout);
					 break;
				 }
			 }

			 if((CCIDNumberDupS)!=NULL && tc_strlen(CCIDNumberDupS)>0)
			 {
			   printf("\n CCIDNumberDupS is  = [%s]\n", CCIDNumberDupS);fflush(stdout);							
			 }
			 else
			 {
				tc_strcpy(CCIDNumberDupS,"NA");
				printf("\n CCIDNumberDupS is  = [%s]\n", CCIDNumberDupS);fflush(stdout);	
			 }

			 char	*strToBereplR=NULL;
			 char	*strToBeUsedR=NULL;

			 strToBereplR		=	(char*)malloc(5);
			 tc_strcpy(strToBereplR,";");

			 strToBeUsedR	=	(char*)malloc(5);
			 tc_strcpy(strToBeUsedR,"");

			 ifail =(STRNG_replace_str (Cciditem_rev,strToBereplR, strToBeUsedR,&Cciditem_revS));
			 printf("\n Cciditem_revS is  = [%s]\n", Cciditem_revS);fflush(stdout);

			 tc_strcpy(CCIDRevDupS,Cciditem_revS);

			 if((CCIDRevDupS)!=NULL && tc_strlen(CCIDRevDupS)>0)
			 {
			    printf("\n CCIDRevDupS is  = [%s]\n", CCIDRevDupS);fflush(stdout);
			 }
			 else
			 {
				tc_strcpy(CCIDRevDupS,"NA");
				printf("\n CCIDRevDupS is  = [%s]\n", CCIDRevDupS);fflush(stdout);	
			 }

			 if(AOM_ask_value_string(CCIDRevTag,"t5_CCIDApplicability",&CcidAppS)==ITK_ok);
			 //tc_strcpy(CcidAppDupS,CcidAppS);
			 if((CcidAppS)!=NULL && tc_strlen(CcidAppS)>0)
			 {
				if(tc_strstr(CcidAppS,"BothES")!=NULL) 
				{					
					tc_strcpy(CcidAppDupS,ValBoth);
				}
				else if (tc_strstr(CcidAppS,"NotApp")!=NULL)
				{					
					tc_strcpy(CcidAppDupS,NoValStr);
				}
				else if (tc_strstr(CcidAppS,"Service")!=NULL)
				{					
					tc_strcpy(CcidAppDupS,ServVal);
				}
				else
				{
					tc_strcpy(CcidAppDupS,CcidAppS);
				}
			   printf("\n CcidAppDupS is  = [%s]\n", CcidAppDupS);fflush(stdout);							
			 }
			 else
			 {
				tc_strcpy(CcidAppDupS,"NA");
				printf("\n CcidAppDupS is  = [%s]\n", CcidAppDupS);fflush(stdout);	
			 }

		 }
		 else
		 {
			 
			 CCIDRevTag=CCIDattachments[0];
			 //ITK_CALL(ITEM_ask_latest_rev(CCIDMstRevTag,&CCIDRevTag));

			 CCIDNumberDupS		   =(char *) MEM_alloc(50);
			 CCIDRevDupS		   =(char *) MEM_alloc(5);
			 //CCIDSeqDupS		   =(char *) MEM_alloc(5);
			 CcidAppDupS		   =(char *) MEM_alloc(10);

			 if(AOM_ask_value_string(CCIDRevTag,"item_id",&CCIDNumberS)==ITK_ok);
			 tc_strcpy(CCIDNumberDupS,CCIDNumberS);			  

			 if((CCIDNumberDupS)!=NULL && tc_strlen(CCIDNumberDupS)>0)
			 {
			   printf("\n CCIDNumberDupS is  = [%s]\n", CCIDNumberDupS);fflush(stdout);							
			 }
			 else
			 {
				tc_strcpy(CCIDNumberDupS,"NA");
				printf("\n CCIDNumberDupS is  = [%s]\n", CCIDNumberDupS);fflush(stdout);	
			 }

			 if(AOM_ask_value_string(CCIDRevTag,"item_revision_id",&Cciditem_rev)==ITK_ok);
			 printf("\n Cciditem_rev is  = [%s]\n", Cciditem_rev);fflush(stdout);	
			
			 char	*strToBereplR=NULL;
			 char	*strToBeUsedR=NULL;

			 strToBereplR		=	(char*)malloc(5);
			 tc_strcpy(strToBereplR,";");

			 strToBeUsedR	=	(char*)malloc(5);
			 tc_strcpy(strToBeUsedR,"");

			 ifail =(STRNG_replace_str (Cciditem_rev,strToBereplR, strToBeUsedR,&Cciditem_revS));
			 printf("\n Cciditem_revS is  = [%s]\n", Cciditem_revS);fflush(stdout);

			 tc_strcpy(CCIDRevDupS,Cciditem_revS);

			 if((CCIDRevDupS)!=NULL && tc_strlen(CCIDRevDupS)>0)
			 {
			    printf("\n CCIDRevDupS is  = [%s]\n", CCIDRevDupS);fflush(stdout);
			 }
			 else
			 {
				tc_strcpy(CCIDRevDupS,"NA");
				printf("\n CCIDRevDupS is  = [%s]\n", CCIDRevDupS);fflush(stdout);	
			 }
	

			 //if(AOM_ask_value_string(CCIDRevTag,"sequence_id",&CcidSeq)==ITK_ok); 
			 if(AOM_ask_value_int(CCIDRevTag,"sequence_id",&CcidSeq)==ITK_ok); 
			 //tc_strcpy(CCIDSeqDupS,CcidSeq);
			 printf("\n CcidSeq is AA = [%d]\n", CcidSeq);fflush(stdout);
			 //if((CcidSeq)!=NULL && tc_strlen(CcidSeq)>0)
			 if((CcidSeq)>0)
			 {
			   printf("\n CcidSeq is  = [%d]\n", CcidSeq);fflush(stdout);							
			 }
			 else
			 {
				//tc_strcpy(CcidSeq,"NA");
				printf("\n else CcidSeq is  = [%d]\n", CcidSeq);fflush(stdout);	
			 }

			 if(AOM_ask_value_string(CCIDRevTag,"t5_CCIDApplicability",&CcidAppS)==ITK_ok);
			 //tc_strcpy(CcidAppDupS,CcidAppS);
			 if((CcidAppS)!=NULL && tc_strlen(CcidAppS)>0)
			 {
				if(tc_strstr(CcidAppS,"BothES")!=NULL) 
				{					
					tc_strcpy(CcidAppDupS,ValBoth);
				}
				else if (tc_strstr(CcidAppS,"NotApp")!=NULL)
				{					
					tc_strcpy(CcidAppDupS,NoValStr);
				}
				else if (tc_strstr(CcidAppS,"Service")!=NULL)
				{					
					tc_strcpy(CcidAppDupS,ServVal);
				}
				else
				{
					tc_strcpy(CcidAppDupS,CcidAppS);
				}
			   printf("\n CcidAppDupS is  = [%s]\n", CcidAppDupS);fflush(stdout);							
			 }
			 else
			 {
				tc_strcpy(CcidAppDupS,"NA");
				printf("\n CcidAppDupS is  = [%s]\n", CcidAppDupS);fflush(stdout);	
			 }
		 }
	 }
	else
	 { 
		  printf("\n nothing found in new ccid relation \n"); fflush(stdout);	
	 }


	 printf("\n data added -- ECU COUNT BEFORE ADDING TO FILE--%s\n",t5NoEcuDup); fflush(stdout);	
	//fprintf(fptr1," \n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n",Cnt_EcuTypeDup,container,containerrevdup,VCnumberDup,Objdesc,DML_name,t5NoEcuDup,vcDrStatDup,vcProjDup);fflush(fptr1);
	//fprintf(fptr1," \n %s,%s%s,%s,%s,%s,%s,%s,%s,%s \n",CCIDNumberDupS,CCIDRevDupS,req_item3,CcidAppDupS,VCnumberDup,ObjDescFinal,DML_name,t5NoEcuDup,vcDrStatDup,vcProjDup);fflush(fptr1);
	fprintf(fptr1,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",CCIDNumberDupS,CCIDRevDupS,CcidAppDupS,VCnumberDup,ObjDescFinal,DML_name,t5NoEcuDup,vcDrStatDup,vcProjDup,DML_TrDesc);fflush(fptr1);
	//fprintf(fp1,"\n%s,%s%s,%s,%s,%s,%s,%s,%s,%s,\n",BaseLineNumberDupS,BaseLineRevDupS,BaseLineSeqDupS,BaseLineAppDupS,vcnoDup,vcdescDup,DmlNo,t5NoEcuDup,vcDrStatDup,vcProjDup);fflush(fp1);

//	fclose(fptr1);

	ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshot_type); 
	printf("\n  Expansion_TPL_16 after snapshot rel \n");fflush(stdout);

	ifail = GRM_list_secondary_objects_only(CCIDRevTag,HasSnapshot_type,&Snapcnt,&Snapshotattachments);
	printf("\n  Snapcnt [%d] -------> \n",Snapcnt);fflush(stdout);
    
	if(Snapcnt >0)													//18 SEPT	
	{																//18 SEPT	
      SnapshotRevTag=Snapshotattachments[0];		                //18 SEPT				
	  printf("\n  After SnapshotRevTag------- \n");fflush(stdout);	//18 SEPT	
	
//	 for (ss=0;ss<Snapcnt;ss++ )												    //18 SEPT	
//			 {																		//18 SEPT	
//				 SnapshotRevTag=Snapshotattachments[0];								//18 SEPT	
//				 printf("\n  After SnapshotRevTag------- \n");fflush(stdout);       //18 SEPT	
//			 }                                                                      //18 SEPT	

	//ifail = BOM_create_window (&window);
	//ifail =BOM_create_window_from_snapshot(SnapshotRevTag,&window);
	
	//printf("\n  After BOM_create_window------- \n");fflush(stdout);

	//ifail = BOM_set_window_top_line (window, null_tag, SnapshotRevTag, null_tag, &top_lineS);
	
	//printf("\n  After top_lineS------- \n");fflush(stdout);

	////ifail = BOM_window_show_suppressed ( window );
	

	////ITK_CALL(BOM_set_window_pack_all(window, FALSE));


	//countZ=0;
	//ITK_CALL(AOM_load(SnapshotRevTag));


	//printf("\n  After AOM_load \n");fflush(stdout);

	//statusZ = BOM_line_ask_child_lines (top_line, &countZ, &childrenZ);
	//printf("\n  countZ   -------> [%d] \n",countZ);fflush(stdout);


	int level 				= 0;				
	int StructChldCnt   =    0;
	int www   =    0;
	int arr   =    0;
	char *containerID =NULL;
	char *containerrevID =NULL;
	char *mastercontainerrevID =NULL;
	struct			BomChldStrut_EE	ChldStrutBdySh[5000];
	int tml1 =0;
	int tml2 =0;
	tag_t snapShotChild = NULLTAG;
	char* PartItemIdSn =NULL;
	char* PartItemRevIdSn =NULL;
	char* itemIDGotFromStct =NULL;
	char* itemIDGotFromStctt5_SwPartType =NULL;
	char* PartObjectType =NULL;
	char* PartSWType =NULL;
	logical MatchFound = false;
	tag_t windowW1 =NULLTAG;
	tag_t ruletag1;
	tag_t top_lineW =NULLTAG;
	int countW=0;
	tag_t* childrenW =NULLTAG;
	int chCount1 =0;
	int iChildItemTag1 =0;
	tag_t t_ChildItemRev1 =NULLTAG;
	char* child_item_id1 =NULL;
	char* sGrpID =NULL;

	Multi_Get_Part_BOM_Lvl_Col(LatestModRevTag,99,level,SnapshotRevTag,ChldStrutBdySh,&StructChldCnt,"NA");
	printf ("\n Child Count count %d \n",StructChldCnt);fflush(stdout);

	ITK_CALL(AOM_ask_value_tags(SnapshotRevTag,"contents",&countZ,&childrenZ)); //////// 
    printf("\n  countZ  contents -------> [%d] \n",countZ);fflush(stdout);

	for(tml1 =0; tml1 < countZ ;tml1++ )
	{
		MatchFound =false;
		snapShotChild = childrenZ[tml1];

		if(AOM_ask_value_string(snapShotChild,"item_id",&PartItemIdSn)!=ITK_ok);
		printf("\n Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout);

		if(AOM_ask_value_string(snapShotChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);
		printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);

		if(AOM_ask_value_string(snapShotChild,"object_type",&PartObjectType)!=ITK_ok);
		printf("\n  PartObjectType -------> %s \n", PartObjectType);fflush(stdout);

		 if(tc_strcmp(PartObjectType,"T5_EE_PartRevision")==0)
		 {
			if(AOM_ask_value_string(snapShotChild,"t5_SwPartType",&PartSWType)!=ITK_ok);
			printf("\n  PartSWType -------> %s \n", PartSWType);fflush(stdout);

			if(tc_strcmp(PartSWType,"CON")==0 || tc_strcmp(PartSWType,"PRM")==0)
			//if(tc_strcmp(PartSWType,"CON")==0)
			{
				
					for (tml2=0;tml2 < StructChldCnt;tml2++)													   //18 SEPT
					{
						
						if( AOM_ask_value_string(ChldStrutBdySh[tml2].child_objs,"item_id",&itemIDGotFromStct)!=ITK_ok);
						printf("\n  itemIDGotFromStct -------> %s \n", itemIDGotFromStct);fflush(stdout);

						if( AOM_ask_value_string(ChldStrutBdySh[tml2].child_objs,"t5_SwPartType",&itemIDGotFromStctt5_SwPartType)!=ITK_ok);
						printf("\n  itemIDGotFromStctt5_SwPartType -------> %s \n", itemIDGotFromStctt5_SwPartType);fflush(stdout);

						if(tc_strcmp(itemIDGotFromStctt5_SwPartType,"CON")==0 || tc_strcmp(itemIDGotFromStctt5_SwPartType,"PRM")==0)
						{
							if(tc_strcmp(PartItemIdSn,itemIDGotFromStct)==0)
							{
										MatchFound = true;
										printf("MatchFound..... is true:::");
										break;
							}
						}
					}
					if(MatchFound == false)
					{
						//need to add tag to child tags
						printf("MatchFound ::::: false  :::");
						printf("\n I am in 16R TLP Expansion function :: , Part is need to add in structure from snapshot is :: [%s]", PartItemIdSn);fflush(stdout);
						//ifail = BOM_create_window (&windowW1);
						ifail = BOM_create_window_from_snapshot (tSnapFl,&windowW1);
						CHECK_FAIL;
						
						//ifail = CFM_find( "Latest Released", &rule );
						//ifail = CFM_find( "ERC release and above", &ruletag1 );
						//printf ("\n after rev rule \n"); fflush(stdout);
						//ifail = BOM_set_window_config_rule( windowW1, ruletag1 );
						//CHECK_FAIL;
						ifail = BOM_set_window_top_line (windowW1, null_tag, snapShotChild, null_tag, &top_lineW); 
						CHECK_FAIL;
						ifail = BOM_window_show_suppressed ( windowW1 );
						CHECK_FAIL;
						ifail =(BOM_set_window_pack_all(windowW1, FALSE));
						CHECK_FAIL;

						
						ifail = BOM_line_ask_child_lines (top_lineW, &countW, &childrenW);
						printf ("\n Chils of Container from snapshot :: %d \n",countW); fflush(stdout);

						//ITKCALL(AOM_ask_value_tag(snapShotChild,"topLine",&Modl_rev_tags));
						StructChldCnt = StructChldCnt +1; 

						//ChldStrutBdySh[StructChldCnt].child_objs = top_lineW;
						//ChldStrutBdySh[StructChldCnt].child_objs_bvr=top_lineW;
						//ChldStrutBdySh[StructChldCnt].child_objs_lvl=1;

						ChldStrutBdySh[StructChldCnt].child_objs = snapShotChild;
						ChldStrutBdySh[StructChldCnt].child_objs_bvr=top_lineW;
						ChldStrutBdySh[StructChldCnt].child_objs_lvl=1;
						ChldStrutBdySh[StructChldCnt].GrpID="NA";
						
						for(chCount1 =0; chCount1 < countW ; chCount1 ++)
						{
							

							BOM_line_unpack (childrenW[chCount1]);
							//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag1);
							//BOM_line_ask_attribute_tag(childrenW[chCount1], iChildItemTag1, &t_ChildItemRev1);
							AOM_ask_value_tag(childrenW[chCount1], bomAttr_lineItemRevTag, &t_ChildItemRev1);

							 ITKCALL(AOM_ask_value_string(t_ChildItemRev1, "item_id", &child_item_id1 ));				   //18 SEPT
							 printf("\n child_item_id1 tag found  child_item_id===>%s\n",child_item_id1);fflush(stdout); 
							
							StructChldCnt = StructChldCnt +1; 
							ChldStrutBdySh[StructChldCnt].child_objs = t_ChildItemRev1;
							ChldStrutBdySh[StructChldCnt].child_objs_bvr=childrenW[chCount1];
							ChldStrutBdySh[StructChldCnt].child_objs_lvl=2;
							ChldStrutBdySh[StructChldCnt].GrpID="NA";
							
						}

						//tempPartTag = SnChild;
						//children[countX]=SnChild;
						//countX++;
					}

			}
		 }

	
	}



	if(StructChldCnt >0)
	{
	   char* totalArray  [StructChldCnt+1];
	   //const char **totalArray  = (const char **) MEM_alloc(2 * sizeof(char *));
	   for (www=0;www<StructChldCnt+1;www++)
		{
			tag_t ChildRevBomLineXX=NULLTAG;
			if( AOM_ask_value_string(ChldStrutBdySh[www].child_objs,"item_id",&containerID)!=ITK_ok);

			if( AOM_ask_value_string(ChldStrutBdySh[www].child_objs,"item_revision_id",&containerrevID)!=ITK_ok);

//			    =ChldStrutBdySh[ww].child_objs_bvr;
			totalArray[www] = MEM_alloc(50);
			
			tc_strcpy(totalArray[www],containerID);
			tc_strcat(totalArray[www],"_");
			tc_strcat(totalArray[www],containerrevID);

			printf("\n [%d]  totalArray -- %s\n",www,totalArray[www] );fflush(stdout);
		}


		//for (ww=0;ww<countZ;ww++)
		for (ww=0;ww<StructChldCnt+1;ww++)
		 {
			printf("\n..IN Expansion_TPL_16 structure.. :%d\n",ww);fflush(stdout);
			container=NULL;
			containerrev=NULL;
			tag_t ChildRevBomLine=NULLTAG;
			//if( AOM_ask_value_string(childrenZ[ww],"bl_item_item_id",&container)!=ITK_ok);
			//if( AOM_ask_value_string(childrenZ[ww],"item_id",&container)!=ITK_ok);
			if( AOM_ask_value_string(ChldStrutBdySh[ww].child_objs,"item_id",&container)!=ITK_ok);

			//if( AOM_ask_value_string(childrenZ[ww],"bl_rev_item_revision_id",&containerrev)!=ITK_ok);
			//if( AOM_ask_value_string(childrenZ[ww],"item_revision_id",&containerrev)!=ITK_ok);
			if( AOM_ask_value_string(ChldStrutBdySh[ww].child_objs,"item_revision_id",&containerrev)!=ITK_ok);

			ChildRevBomLine=ChldStrutBdySh[ww].child_objs_bvr;
			sGrpID=ChldStrutBdySh[ww].GrpID;

   
			//if( AOM_ask_value_string(childrenZ[ww],"bl_Design Revision_t5_ProjectCode ",&ConProject)!=ITK_ok);
			printf("\n inside Expansion_TPL_16 structure  container is [%s] -----> & containerrev is ---->[%s] \n",container,containerrev);fflush(stdout);

		if((container)&&(containerrev))
		 {
			// if((tc_strcmp(container,req_item)==0) && (tc_strcmp(containerrev,req_item2)==0))

			const char **attrs3  = (const char **) MEM_alloc(2 * sizeof(char *));
			const char **values3 = (const char **) MEM_alloc(2 * sizeof(char *));
			attrs3[0]	   ="item_id";
			//attrs3[1]      ="object_type";
			values3[0]     = (char *)container;
			//values3[1]     = "Design";
			//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
			ifail = ITEM_find_item_revs_by_key_attributes(1,attrs3, values3,containerrev, &n_tags_found4, &tags_found4);
			MEM_free(attrs3);
			MEM_free(values3);

			if (n_tags_found4>0)
			{
			   ChildRev= tags_found4[0];
			}

			if( AOM_ask_value_string(ChildRev,"t5_ProjectCode",&ConProject)!=ITK_ok);

			if( AOM_ask_value_string(ChildRev,"t5_SwPartType",&PartType)!=ITK_ok);

			if( AOM_ask_value_string(ChildRev,"t5_EE_PartType",&EEPartType)!=ITK_ok);

			if( AOM_ask_value_string(ChildRev,"t5_AppForEOL",&TPLEOL)!=ITK_ok);

			if( AOM_ask_value_string(ChildRev,"t5_AppForEOL",&ContEOL)!=ITK_ok);
			if( AOM_ask_value_string(ChildRev,"t5_PartStatus",&DRStatus)!=ITK_ok);
			printf("\n Expansion_TPL_16 structure   ConProject is ---> [%s]  PartType is ---> [%s]    EEPartType is ---> [%s]  TPLEOL is ---> [%s]  ContEOL is ---> [%s] DRStatus is ---> [%s] \n",ConProject,PartType,EEPartType,TPLEOL,ContEOL,DRStatus); fflush(stdout);

			char	*strToBerepl1R;
			char	*strToBeUsed1R;
			char	*containerrevdup;

			strToBerepl1R		=	(char*)malloc(5);
			tc_strcpy(strToBerepl1R,";");

			strToBeUsed1R	=	(char*)malloc(5);
			tc_strcpy(strToBeUsed1R,"_");

			ifail =(STRNG_replace_str (containerrev,strToBerepl1R, strToBeUsed1R,&containerrevdup));
			printf("\n containerrevdup containerrevdup    ConProject is ---> [%s]\n",containerrevdup);fflush(stdout);

			char * ContEOLDup =NULL;
			ContEOLDup=(char *) MEM_alloc(100);
			char * ContEOLDup_Val =NULL;
			ContEOLDup_Val=(char *) MEM_alloc(100);

			if((ContEOL))
			 {			   
				tc_strcpy(ContEOLDup,ContEOL); 
			 }
			else
			 {
				tc_strcpy(ContEOLDup,EOLNA);
			 }
		
			if(ContEOLDup)
			 {

				if(tc_strstr(ContEOLDup,"BothES")!=NULL) 
				{					
					tc_strcpy(ContEOLDup_Val,ValBoth);
				}
				else if (tc_strstr(ContEOLDup,"NotApp")!=NULL)
				{					
					tc_strcpy(ContEOLDup_Val,ValBoth);
				}
				else if (tc_strstr(ContEOLDup,"Service")!=NULL)
				{					
					tc_strcpy(ContEOLDup_Val,ServVal);
				}
				else if (tc_strstr(ContEOLDup,"t5all")!=NULL)
				{					
					tc_strcpy(ContEOLDup_Val,sAll);
				}
				else
				{
					tc_strcpy(ContEOLDup_Val,ContEOLDup);
				}
			 }
			 
			char * TPLEOLDUP =NULL;
			TPLEOLDUP=(char *) MEM_alloc(100);
			char * TPLEOLVAL =NULL;
			TPLEOLVAL=(char *) MEM_alloc(100);

			if((TPLEOL))
			{
				tc_strcpy(TPLEOLDUP,TPLEOL);
			}
			if (tc_strstr(TPLEOLDUP,"BothES")!=0)
			{
				tc_strcpy(TPLEOLVAL,EOL_Val_Both);
			}
			else if (tc_strstr(TPLEOLDUP,"NotApp")!=0)
			{
				tc_strcpy(TPLEOLVAL,EOL_Val_N);
			}
			else
			{
				tc_strcpy(TPLEOLVAL,TPLEOLDUP);
			}

//			if(container)
//			 {
				//if(tc_strstr(container,"16R")==0  &&  tc_strstr(container,"16L")==0 )
				//{
				//	printf("\n..IN Expansion_TPL_16 structure 16R FOUND.. \n");fflush(stdout);
				//	Expansion_TPL_16 (childrenZ[ww],rule,PartNo,Assy_Rev,Objdesc,container);
				
				//}

				if(tc_strcmp(EEPartType,"G")==0)
				{
					printf("\t IN Expansion_TPL_16 GROUP id FOUND  \n"); fflush(stdout);


					//Expansion_GrpId( ChildRev,rule,PartNo,Objdesc); 
					//Expansion_GrpId( ChildRev,ChildRevBomLine,VCnumberDup,ObjDescFinal); //uncomment later
				}
				else if((tc_strcmp(PartType,"CON")==0)||(tc_strcmp(PartType,"Container")==0) && (tc_strcmp(EEPartType,"G")!=0))
				{
					printf("\t INSIDE CONTAINER AND NOT GRP ID CONDITION =========> [%s]\n",container); fflush(stdout);

					supfile=0;
					//calfiletest=0;
					CalFlileReq=0;
					char * totalstr = NULL;

					char * mastercontainerMstr = NULL;
										
					//ADD MASTER SLAVE CODES HERE

					sVehicleType=NULL;	
					
					ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvrelation_type); 
					{
						sVehicleType = NULL;
					  if(MstrSlvrelation_type != NULLTAG)
					  {
						  int Flag_Master=0;
						printf("\n Expansion_TPL_16 MstrSlvrelation_type relation found......");	fflush(stdout);	
						//sVehicleType=(char *) MEM_alloc(30);								
					    
						GRM_list_primary_objects_only(ChildRev,MstrSlvrelation_type,&Mstrcnt,&Mstrattachments);
						printf("\n  NO OF Mstrcnt ----------- %d",Mstrcnt);fflush(stdout);

						 if(Mstrcnt>0)
						  {
							 sVehicleType=NULL;
							 for(mt=0;mt<Mstrcnt;mt++)
							  {
								printf("\n AFTER MstrSlvrelation_type =========> \n"); fflush(stdout);
								MstrNo = Mstrattachments[mt];
									
								if( AOM_ask_value_string(ChildRev,"item_id",&mastercontainer)!=ITK_ok);
								printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainer); fflush(stdout);

								if( AOM_ask_value_string(MstrNo,"item_id",&mastercontainerMstr)!=ITK_ok);
								printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainerMstr); fflush(stdout);

								if( AOM_ask_value_string(MstrNo,"item_revision_id",&mastercontainerrevID)!=ITK_ok);
								printf("\n IN Expansion_TPL_16 mastercontainerrevID ---------  [%s]\n",mastercontainerrevID); fflush(stdout);


								ITKCALL(GRM_list_secondary_objects_only(MstrNo,MstrSlvrelation_type,&Slvcnt,&Slvattachments));
								CHECK_FAIL; //slave has container
							
								for (ms=0;ms<Slvcnt;ms++)
								{
									if( AOM_ask_value_string(Slvattachments[ms],"item_id",&containermst)!=ITK_ok);
									printf("\n IN Expansion_TPL_16 containermst ---------  [%s]\n",containermst); fflush(stdout);
									
									if(tc_strcmp(mastercontainer,containermst)==0)
									{
										
										if( AOM_ask_value_string(ChildRev,"item_revision_id",&mastercontainerrev)!=ITK_ok);//primary
										printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainerrev); fflush(stdout);	
										
										if( AOM_ask_value_string(Slvattachments[ms],"item_revision_id",&containermstrev)!=ITK_ok);//secondary
										printf("\n IN Expansion_TPL_16 containermst ---------  [%s]\n",containermstrev); fflush(stdout)	;


										if(tc_strcmp(containermstrev,mastercontainerrev) == 0)
										{
											totalstr = NULL;
											totalstr = MEM_alloc(50);

											tc_strcpy(totalstr,mastercontainerMstr);
											tc_strcat(totalstr,"_");
											tc_strcat(totalstr,mastercontainerrevID);	

											for(arr=0;arr<StructChldCnt;arr++)
											{
												if(tc_strcmp(totalArray[arr], totalstr) == 0)
												{
													if(sVehicleType==NULL)
													{
														sVehicleType=(char *) MEM_alloc(100);
														tc_strcpy(sVehicleType,"S_"); 
														tc_strcat(sVehicleType,mastercontainerMstr);
													}
													else
													{
														tc_strcat(sVehicleType,";S_"); 
														tc_strcat(sVehicleType,mastercontainerMstr);
													}
													printf("\n sVehicleType issssssssss. mastercontainer...[%s]..\n",sVehicleType);	fflush(stdout);
													break;
												}
											}
											printf("\n match found mastercontainer \n"); 
											Flag_Master=1;												
										    break;
										}

										
									}
								 }
							  }
						   }
			                             printf("\n match found mastercontainer \n");	
							  if (Flag_Master==0)
							  {

                                ITKCALL(GRM_list_secondary_objects_only(ChildRev,MstrSlvrelation_type,&Slvcnt,&Slvattachments));
								CHECK_FAIL; //slave has container
								printf("\n  NO OF Slvcnt ----------- %d",Slvcnt);fflush(stdout);

								 if(Slvcnt>0)
								  {
									 sVehicleType=NULL;
									 for(mt=0;mt<Slvcnt;mt++)
									  {
										printf("\n AFTER MstrSlvrelation_type =========> \n"); fflush(stdout);
										MstrNo = Slvattachments[mt];
									
										if( AOM_ask_value_string(ChildRev,"item_id",&mastercontainer)!=ITK_ok);
										printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainer); fflush(stdout);

										if( AOM_ask_value_string(MstrNo,"item_id",&mastercontainerMstr)!=ITK_ok);
										printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainerMstr); fflush(stdout);
										if( AOM_ask_value_string(MstrNo,"item_revision_id",&mastercontainerrevID)!=ITK_ok);
										printf("\n IN Expansion_TPL_16 mastercontainerrevID ---------  [%s]\n",mastercontainerrevID); fflush(stdout);
		


										GRM_list_primary_objects_only(MstrNo,MstrSlvrelation_type,&Mstrcnt,&Mstrattachments);
										printf("\n  NO OF Mstrcnt ----------- %d",Mstrcnt);fflush(stdout);

										for (ms=0;ms<Mstrcnt;ms++)
										{
											if( AOM_ask_value_string(Mstrattachments[ms],"item_id",&containermst)!=ITK_ok);
											printf("\n IN Expansion_TPL_16 containermst ---------  [%s]\n",containermst); fflush(stdout)	;
											
											if(tc_strcmp(mastercontainer,containermst)==0)
											{
												
												if( AOM_ask_value_string(ChildRev,"item_revision_id",&mastercontainerrev)!=ITK_ok);//primary
												printf("\n IN Expansion_TPL_16 mastercontainer ---------  [%s]\n",mastercontainerrev); fflush(stdout);	
												
												if( AOM_ask_value_string(Mstrattachments[ms],"item_revision_id",&containermstrev)!=ITK_ok);//secondary
												printf("\n IN Expansion_TPL_16 containermst ---------  [%s]\n",containermstrev); fflush(stdout)	;

												if(tc_strcmp(containermstrev,mastercontainerrev) == 0)
												{

													totalstr = NULL;
													totalstr = MEM_alloc(50);

													tc_strcpy(totalstr,mastercontainerMstr);
													tc_strcat(totalstr,"_");
													tc_strcat(totalstr,mastercontainerrevID);	

													for(arr=0;arr<StructChldCnt;arr++)
													{
														printf("\n totalArray ====>  [%s]  & totalstr ======> [%s]\n",totalArray[arr], totalstr);fflush(stdout);
														if(tc_strcmp(totalArray[arr], totalstr) == 0)
														{
															if(sVehicleType==NULL)
															{
																sVehicleType=(char *) MEM_alloc(50);
																tc_strcpy(sVehicleType,"M_"); 
																tc_strcat(sVehicleType,mastercontainerMstr);
															}
															else
															{
																tc_strcat(sVehicleType,";M_"); 
																tc_strcat(sVehicleType,mastercontainerMstr);
															}
														printf("\n sVehicleType issssssssss. mastercontainer...[%s]..\n",sVehicleType);	fflush(stdout);
														break;
														}
													}
													printf("\n match found mastercontainer \n"); fflush(stdout);
													Flag_Master=1;												
													break;
												}

		
											}
										 }
									  }
								   }														

						      }
								
							  if(!sVehicleType)
							   {
								  sVehicleType=(char *) MEM_alloc(50);
								  tc_strcpy(sVehicleType,"NA");
							  }
					  }
				  } 

			

					printf("\n sVehicleType issssssssss final ....[%s]..\n",sVehicleType);	fflush(stdout);
					if( AOM_ask_value_string(ChildRev,"t5_EcuType",&Cnt_EcuType)!=ITK_ok);
					printf("\t ChildRev t5ECUType   is -----> [%s]\n",Cnt_EcuType); fflush(stdout);

					char * Cnt_EcuTypeDup =NULL;
					Cnt_EcuTypeDup=(char *) MEM_alloc(100);

					if((Cnt_EcuType)!= NULL)
					{
						printf("\n Cnt_EcuType is NOT NULL-----> [%s]\n",Cnt_EcuType); fflush(stdout);

						/*if(tc_strstr(Cnt_EcuType,"Gateway Domain Controller")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"GDC");
						else if(tc_strstr(Cnt_EcuType,"Front Radar (ADAS)")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"FRM");
						else if(tc_strstr(Cnt_EcuType,"Passive Entry Passive Start")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"PEPS");
						else if(tc_strstr(Cnt_EcuType,"Infotainment Head Unit")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"IHU");
						else if(tc_strstr(Cnt_EcuType,"Radar")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RDR");
						else if(tc_strstr(Cnt_EcuType,"3in1-DC DC Converter")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"3DC");
						else if(tc_strstr(Cnt_EcuType,"3in1-On Board Charger")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"3OBC");
						else if(tc_strstr(Cnt_EcuType,"Vehicle Immobilizer Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"VICM");
						else if(tc_strstr(Cnt_EcuType,"Rear Corner Radar")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RCR");
						else if(tc_strstr(Cnt_EcuType,"Memory Seat Controller")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"MSC");
						else if(tc_strstr(Cnt_EcuType,"Park Distance Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"PACM");
						else if(tc_strstr(Cnt_EcuType,"Power Steering Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"PSCM");
						else if(tc_strstr(Cnt_EcuType,"Tire Pressure Monitor System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TPMS");
						else if(tc_strstr(Cnt_EcuType,"Transmission Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TCM");
						else if(tc_strstr(Cnt_EcuType,"Drive Mode Controller/Switch")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"DMC");
						else if(tc_strstr(Cnt_EcuType,"Transmission control unit")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TCU");
						else if(tc_strstr(Cnt_EcuType,"Instrument Panel Cluster")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"IPC");
						else if(tc_strstr(Cnt_EcuType,"Torque On Demand Controller")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TOD");
						else if(tc_strstr(Cnt_EcuType,"Engine Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ECM");
						else if(tc_strstr(Cnt_EcuType,"Window Winding Auto Down Controller")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"WWAD");
						else if(tc_strstr(Cnt_EcuType,"Retarder")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RTD");
						else if(tc_strstr(Cnt_EcuType,"Tachograph")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TCG");
						else if(tc_strstr(Cnt_EcuType,"Telematics")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"TMC");
						else if(tc_strstr(Cnt_EcuType,"Multiplexing")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"MPX");
						else if(tc_strstr(Cnt_EcuType,"Hybrid ECU")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"HCU");
						else if(tc_strstr(Cnt_EcuType,"Auto Transmission System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ATS");
						else if(tc_strstr(Cnt_EcuType,"Electronically Controlled  Air Suspension")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ECAS");
						else if(tc_strstr(Cnt_EcuType,"Emergency Braking System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"EBS");
						else if(tc_strstr(Cnt_EcuType,"Exhaust Gas Recirculation")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"EGR");
						else if(tc_strstr(Cnt_EcuType,"Antilock Braking System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ABS");
						else if(tc_strstr(Cnt_EcuType,"Selective Catalytic Reduction")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"SCR");
						else if(tc_strstr(Cnt_EcuType,"Electronic Steering Column Lock")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ESCL");
						else if(tc_strstr(Cnt_EcuType,"Unique Identification")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"UI");
						else if(tc_strstr(Cnt_EcuType,"DC-DC Converter")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"DDC");
						else if(tc_strstr(Cnt_EcuType,"Motor Controller Unit")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"MCU");
						else if(tc_strstr(Cnt_EcuType,"Battery Management System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"BMS");
						else if(tc_strstr(Cnt_EcuType,"Gear Shift Advisor")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"GSA");
						else if(tc_strstr(Cnt_EcuType,"Advanced Driver Assistance System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ADAS");
						else if(tc_strstr(Cnt_EcuType,"On Board Charger")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"OBC");
						else if(tc_strstr(Cnt_EcuType,"Wireless Power Charger")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"WPC");
						else if(tc_strstr(Cnt_EcuType,"Antilock/Electronic Braking System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ABS");
						else if(tc_strstr(Cnt_EcuType,"Dosing Control Unit")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"DCU");
						else if(tc_strstr(Cnt_EcuType,"3in1 Combo Unit, DC-DC CONVERTER, OBC, PDU")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"3IN1");
						else if(tc_strstr(Cnt_EcuType,"Battery Cooling System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"BCS");
						else if(tc_strstr(Cnt_EcuType,"Reverse Auto Emergency Braking System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"REBS");
						else if(tc_strstr(Cnt_EcuType,"Driver Drowsiness and Inattentive Detection System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"DIDS");
						else if(tc_strstr(Cnt_EcuType,"LDWS System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"LDWS");
						else if(tc_strstr(Cnt_EcuType,"AEBS RADAR System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ARS");
						else if(tc_strstr(Cnt_EcuType,"Electronic Stability Program")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ESP");
						else if(tc_strstr(Cnt_EcuType,"Front Camera (ADAS)")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"FCM");
						else if(tc_strstr(Cnt_EcuType,"Kick Sensor Hfa Ecu")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"KSH");
						else if(tc_strstr(Cnt_EcuType,"Restraints Control Module (Airbag)")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RCM");
						else if(tc_strstr(Cnt_EcuType,"Front Park Assist System")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"FPAS");
						else if(tc_strstr(Cnt_EcuType,"Power Operated Tailgate ECU")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"POTE");
						else if(tc_strstr(Cnt_EcuType,"Body Control Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"BCM");
						else if(tc_strstr(Cnt_EcuType,"Powertrain Data Logger")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"PDL");
						else if(tc_strstr(Cnt_EcuType,"Heating, Ventilation, and Air Conditioning")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"HVA");
						else if(tc_strstr(Cnt_EcuType,"Fully Automated Temperature Control")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"FATC");	
						else if(tc_strstr(Cnt_EcuType,"AUXILIARY INVERTER")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"AXI");
						else if(tc_strstr(Cnt_EcuType,"AUXILIARY INVERTER,AIR COMPRESSOR")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"AXAC");
						else if(tc_strstr(Cnt_EcuType,"AUXILIARY INVERTER,STEERING PUMP")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"AXSP");
						else if(tc_strstr(Cnt_EcuType,"Inter CAN Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"ICM");
						else if(tc_strstr(Cnt_EcuType,"RF Receiver Module")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RFRM");
						else if(tc_strstr(Cnt_EcuType,"APA ECU")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"AECU");
						else if(tc_strstr(Cnt_EcuType,"Radar")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"RDR");
						else if(tc_strstr(Cnt_EcuType,"Wireless Power Charger")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"WPC");
						else if(tc_strstr(Cnt_EcuType,"Dosing Control Unit")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"DCU");
						else if(tc_strstr(Cnt_EcuType,"Seat Belt Reminder")!=NULL)
						tc_strcpy(Cnt_EcuTypeDup,"SBR");
						else*/
						tc_strcpy(Cnt_EcuTypeDup,"NA");
						for(iCnt=0; iCnt<iECU1; ++iCnt)
						{
							  if(tc_strcmp((ECUTypFull)[iCnt],Cnt_EcuType)==0)
							  {
								tc_strcpy(Cnt_EcuTypeDup,(ECUTypAbr)[iCnt]);
							  }
						 }
					}

					ITKCALL(GRM_find_relation_type("T5_HasSpareKit", &sp_kit_rel_type));

					if(sp_kit_rel_type != NULLTAG)
					{
						printf("\n\t Expansion_TPL_16 SPARE KIT relation found......");	fflush(stdout);	
																												 
						ITKCALL(GRM_list_secondary_objects_only(ChildRev,sp_kit_rel_type,&cnt,&attachments));
						CHECK_FAIL;

						if (cnt > 0)
						{
						  for(jj=0;jj<cnt;jj++)
						  {
								Sparekit = attachments[jj];

								if( AOM_ask_value_string(Sparekit,"item_id",&Sp_ItemID)!=ITK_ok);
								printf("\t Expansion_TPL_16 Sp_ItemID NUMBER  is [%s]\n",Sp_ItemID); fflush(stdout);

								if(AOM_ask_value_string(Sparekit,"item_revision_id",&Sp_ItemREV)!=ITK_ok);
								printf("\t Expansion_TPL_16 Sp_ItemREV NUMBER  is [%s]\n",Sp_ItemREV); fflush(stdout);
								 
								char *sToRpl = NULL;
								sToRpl		=	(char*)malloc(5);
								tc_strcpy(sToRpl,";");
								char *sToBeRpl = NULL;
								sToBeRpl	=	(char*)malloc(5);
								tc_strcpy(sToBeRpl,",");

								ifail =(STRNG_replace_str (Sp_ItemREV,sToRpl,sToBeRpl,&Sp_ItemRV));
								printf("\nkk.Spare kit Rev is [%s]\n",Sp_ItemRV);fflush(stdout);

								//char * HwPart =NULL;
								HwPart=(char *) MEM_alloc(100);
								
								//char * HwPart_Sm =NULL;
								HwPart_Sm=(char *) MEM_alloc(100);

								/*char * ContEOLDup_Val =NULL;
								ContEOLDup_Val=(char *) MEM_alloc(100);

								if(ContEOL)
								{

								if(tc_strstr(ContEOL,"BothES")!=NULL) 
								{					
									tc_strcpy(ContEOLDup,ValBoth);
								}
								else if (tc_strstr(ContEOLDup,"NotApp")!=NULL)
								{					
									tc_strcpy(ContEOLDup,ValBoth);
								}
								else if (tc_strstr(ContEOLDup,"Service")!=NULL)
								{					
									tc_strcpy(ContEOLDup,ServVal);
								}
								else
								{
									tc_strcpy(ContEOLDup_Val,ContEOLDup);
								}
								}*/
								tc_strcpy(HwPart,Sp_ItemID);
								tc_strcat(HwPart,",");
								tc_strcat(HwPart,"NA");
								tc_strcat(HwPart,",");
								tc_strcat(HwPart,Sp_ItemRV);
								//tc_strcat(HwPart,"_");
								//tc_strcat(HwPart,ContEOLDup_Val);


								tc_strcpy(HwPart_Sm,Sp_ItemID);
								tc_strcat(HwPart_Sm,",");
								tc_strcat(HwPart_Sm,Sp_ItemREV);

							}
						}
					}

					printf ("\n Expansion_TPL_16 fptr11111111111111111 ---> \n"); fflush(stdout);

					//fprintf(fptr1," \n %s,%s,%s,%s,%s \n",Cnt_EcuTypeDup,container,containerrevdup,DML_name,req_item);fflush(fptr1);
					//fprintf(fp1,  "\ n %s,%s %s,%s,%s,%s,%s,%s,%s,%s,\n",BaseLineNumberDupS,BaseLineRevDupS,BaseLineSeqDupS,BaseLineAppDupS,vcnoDup,vcdescDup,DML_name,t5NoEcuDup,vcDrStatDup,vcProjDup);fflush(fp1);

                   //ChildRev

				   	//ifail = BOM_create_window (&window2);
					//CHECK_FAIL;

					//ifail = CFM_find( "Latest Released", &rule );
					//ifail = CFM_find( "ERC release and above", &rule );

					//printf ("\n after rev rule window2 \n"); fflush(stdout);

					//ifail = BOM_set_window_config_rule( window2, rule );
					//CHECK_FAIL;

					//ifail = BOM_set_window_top_line (window2, null_tag, ChildRev, null_tag, &top_line2);
					//CHECK_FAIL;

					//ifail = BOM_window_show_suppressed ( window2 );
					//CHECK_FAIL;

					//ifail = (BOM_set_window_pack_all(window2, FALSE));

					countZZ=0;
					statusZZ = BOM_line_ask_child_lines (ChildRevBomLine, &countZZ, &childrenZZ);

					printf ("\n line 1120 IN Expansion_TPL_16 countZZ is --->%d \n",countZZ); fflush(stdout);

					//if(countZZ >0)
					// {
						//printf("\n..line 1124  Expansion_TPL_16 \n");fflush(stdout);
						// CalFileNameDup=NULL;
						 test_file2=NULL;
						 //CalFileNameDup			 =(char *) MEM_alloc(300);
						 //test_file2			 =(char *) MEM_alloc(300);
						 for(yy=0;yy<countZZ;yy++)
						    {
							   // CalFileNameDup=NULL;
						      //  CalFileNameDup			 =(char *) MEM_alloc(300);
							 // tc_strcpy(CalFileNameDup,"");
							  printf("---------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);

							  
								if(AOM_ask_value_string(childrenZZ[yy],"bl_item_item_id",&contpart)!=ITK_ok);
													
								if( AOM_ask_value_string(childrenZZ[yy],"bl_rev_item_revision_id",&contpartrev)!=ITK_ok);
								//printf("\n contpartrev ID--->[%s] \n",contpartrev);fflush(stdout);

								//if( AOM_ask_value_string(childrenZZ[yy],"bl_Design Revision_t5_ProjectCode",&ProjectC)!=ITK_ok);
								printf("\n  1135  Expansion_TPL_16  contpart ID  is---> [%s] ontpartrev ID--->[%s] \n",contpart,contpartrev);fflush(stdout);

								/////adiiiiiiiiii adddddddd condition here
								if((contpartrev)!=NULL && tc_strlen(contpartrev)>0)
								{

								const char **attrs6  = (const char **) MEM_alloc(2 * sizeof(char *));
								const char **values6 = (const char **) MEM_alloc(2 * sizeof(char *));
								attrs6[0]	   = "item_id";
								//attrs6[1]      = "object_type";
								values6[0]     = (char *)contpart;
								//values6[1]     = "Design";
								//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
								ifail = ITEM_find_item_revs_by_key_attributes(1,attrs6, values6,contpartrev, &n_tags_found6, &tags_found6);
								CHECK_FAIL;
								MEM_free(attrs6);
								MEM_free(values6);

								if (n_tags_found6>0)
								{
								   ContChildRev= tags_found6[0];
								   printf("\n ContChildRev tags founddd \n");fflush(stdout);
								}

								if( AOM_ask_value_string(ContChildRev,"item_id",&conitemid)!=ITK_ok);

								printf("\n Expansion_TPL_16 conitemid  is----> [%s]\n",conitemid);

								if( AOM_ask_value_string(ContChildRev,"t5_software_rev",&conitemrevid)!=ITK_ok);
								if((conitemrevid)!=NULL && tc_strlen(conitemrevid)>0)
								{
									printf("\nkk.s/w ver revision [%s] found for part [%s] \n",conitemrevid,conitemid);fflush(stdout);
								}
								else
								{
									if( AOM_ask_value_string(ContChildRev,"item_revision_id",&conitemrevid)!=ITK_ok);//A;1
								}

								printf("\n Expansion_TPL_16 conitemrevid  is----> [%s]\n",conitemrevid);

								char	*strToBerepl1RR =NULL;
								char	*strToBeUsed1RR =NULL;
								char	*conitemreviddup=NULL;//A;1

								strToBerepl1RR		=	(char*)malloc(5);
								tc_strcpy(strToBerepl1RR,";");

								strToBeUsed1RR	=	(char*)malloc(5);
								tc_strcpy(strToBeUsed1RR,"_");

								ifail =(STRNG_replace_str (conitemrevid,strToBerepl1R, strToBeUsed1R,&conitemreviddup));
								printf("\n conitemreviddup    ConProject is ---> [%s]\n",conitemreviddup);fflush(stdout);//A_1
								
								char	*conitemreviddupS		=	NULL;
								char	*conitemrevidduptokS	=	NULL;
								conitemreviddupS		=	(char*)malloc(10);
								tc_strcpy(conitemreviddupS,conitemreviddup);
								printf("\n Expansion_TPL_16 conitemreviddupS  is----> [%s]\n",conitemreviddupS);
								printf("\n Expansion_TPL_16 conitemreviddup AAAA  is----> [%s]\n",conitemreviddup);

								conitemrevidduptokS = tc_strtok (conitemreviddupS,"_");
								conitemreviddupS =tc_strtok(NULL,"");
								printf("\n Expansion_TPL_16 conitemrevidduptokS  is----> [%s]\n",conitemrevidduptokS);//A
								printf("\n Expansion_TPL_16 conitemreviddupS AFTER TOK is----> [%s]\n",conitemreviddupS);//1


								if( AOM_ask_value_string(ContChildRev,"t5_ProjectCode",&ProjectC)!=ITK_ok);

								if( AOM_ask_value_string(ContChildRev,"t5_AppForEOL",&EOL)!=ITK_ok);

								if( AOM_ask_value_string(ContChildRev,"t5_SwPartType",&ChdPartType)!=ITK_ok);

								if( AOM_ask_value_string(ContChildRev,"t5_DesignGrp",&Desg)!=ITK_ok);

								printf("\n Expansion_TPL_16 Desg GROUP  is----> [%s], ProjectC is --->[%s],EOL  is----> [%s],ChdPartType is ---->[%s]\n",Desg,ProjectC,EOL,ChdPartType); fflush(stdout);

								char	*strToBereplR=NULL;
								char	*strToBeUsedR=NULL;
				
								strToBereplR		=	(char*)malloc(5);
								tc_strcpy(strToBereplR,";");

								strToBeUsedR	=	(char*)malloc(5);
								tc_strcpy(strToBeUsedR,"_");

								ifail =(STRNG_replace_str (conitemrevid,strToBereplR, strToBeUsedR,&contpartrevdup));



								char	*strToBereplRQ=NULL;
								char	*strToBeUsedRQ=NULL;
								char	*contpartrevdupSS11=NULL;
								char	*contpartrevdupSS11copy=NULL;
								char	*contpartrevdupSS=NULL;
								contpartrevdupSS=	(char*)malloc(30);
								contpartrevdupSS11copy=	(char*)malloc(30);
								char	*contpartrevdupSS11tokS		=	NULL;
								char	*contpartseqdupSS11	=	NULL;
					

								tc_strcpy(contpartrevdupSS,contpartrevdup);
								printf("\n Expansion_TPL_16 contpartrevdupSS ------------>[%s] \n",contpartrevdupSS);fflush(stdout);//G_2

								
								strToBereplRQ		=	(char*)malloc(5);
								tc_strcpy(strToBereplRQ,"_");
	
								strToBeUsedRQ	=	(char*)malloc(5);
								tc_strcpy(strToBeUsedRQ,",");

								ifail =(STRNG_replace_str (contpartrevdupSS,strToBereplRQ, strToBeUsedRQ,&contpartrevdupSS11));//g,2
								tc_strcpy(contpartrevdupSS11copy,contpartrevdupSS11);

				
								//contpartrevdupSS11tokS = tc_strtok (contpartrevdupSS11copy,"_");
								//contpartseqdupSS11 =tc_strtok(NULL,"");

								printf("\n Expansion_TPL_16 contpartrevdupSS11copy  is----> [%s]\n",contpartrevdupSS11copy);//G,2   G
								//printf("\n Expansion_TPL_16 contpartseqdupSS11 AFTER TOK is----> [%s]\n",contpartseqdupSS11);//NULL   2


									
								char * EOLDup =NULL;
								EOLDup=(char *) MEM_alloc(100);
								if((EOL)!=NULL && tc_strlen(EOL)>0)
								{
									
								   if(tc_strstr(EOL,"BothES")!=NULL) 
									{
										tc_strcpy(EOLDup,ValBoth);
										printf("\n..AFTER ValBoth COPY EOLDUP VALUE IS------>[%s] \n",EOLDup);fflush(stdout);
									}
								   else if (tc_strstr(EOL,"NotApp")!=NULL)
									{
										tc_strcpy(EOLDup,EOLNA);
										printf("\n..AFTER EOLNA COPY EOLDUP VALUE IS------>[%s] \n",EOLDup);fflush(stdout);
									}
								   else if (tc_strstr(EOL,"Service")!=NULL)
									{
										tc_strcpy(EOLDup,ServVal);
										printf("\n..AFTER ServVal COPY EOLDUP VALUE IS------>[%s] \n",EOLDup);fflush(stdout);
									}
								}
								else 
								{ 
									tc_strcpy(EOLDup,NoValStr);
									printf("\n..AFTER EOL COPY EOLDUP VALUE IS------>[%s] \n",EOLDup);fflush(stdout);
								}
								
								if((EOLDup)!=NULL && tc_strlen(EOLDup)>0)  
								{
								   	printf("\n..AAAAAA Expansion_TPL_16 EOLDup value is ------>[%s] \n",EOLDup);fflush(stdout);

								}
								else
								{
									//printf("..Expansion_TPL_16 in else loop of contpart %s",contpart);fflush(stdout);
									tc_strcpy(EOLDup,NoValStr);
									printf("\n..BBBBBB Expansion_TPL_16 EOLDup value is ------>[%s] \n",EOLDup);fflush(stdout);
								}

								//printf("\n Expansion_TPL_16 ContChildRev  is----> [%s] [%s]\n",conitemid ,conitemrevid);fflush(stdout);

								ifail = GRM_find_relation_type("IMAN_specification",&relation_type); 
			
								ifail = GRM_list_secondary_objects_only(ContChildRev,relation_type,&cntX,&attachmentsX);
								printf("\n attachmentsX ============= %d \n",cntX); fflush(stdout);	
									if (cntX > 0)
									  {	
										tc_strcpy(test_file2,"");
										test_file =NULL;
											test_file2 =NULL;
											test_fileX =NULL;
											test_file3 =NULL;
											pathname =NULL;
											test_file=(char *) MEM_alloc(300);
											test_file2=(char *) MEM_alloc(300);
											test_fileX=(char *) MEM_alloc(300);
											test_file3=(char *) MEM_alloc(300);
											//09-10-2023 ; update
											tc_strcpy(test_file,"NA");

										for(bb=0;bb<cntX;bb++)
										{	

											dataset = attachmentsX[bb];
											if( AOM_ask_value_string(dataset,"object_type",&objtype)!=ITK_ok);
											printf("\n  Expansion_TPL_16 objtype is ======== %s \n",objtype);fflush(stdout);
											

											if((tc_strstr(objtype,"CMI2")!=NULL)||(tc_strstr(objtype,"CAT")!=NULL)||(tc_strstr(objtype,"Creo")!=NULL)||(tc_strstr(objtype,"ProPrt")!=NULL)||(tc_strstr(objtype,"ProDrw")!=NULL))
											 {
												printf("\n Expansion_TPL_16  proe OR catia datasets SO CONTINUE \n"); fflush(stdout);
												
												//tc_strcpy(test_file,NoValStr);

												tc_strcpy(test_file,"NA");
												printf("\n else test_file not ok ------ %s\n",test_file); fflush(stdout);
												
												tc_strcpy(test_file2,"");
												tc_strcat(test_file2,"NA");
												printf("\n else test_file2 not ok ------ %s\n",test_file2); fflush(stdout);

											 }
											 else
											 {

												printf("\n  objtype not creo or catia \n");fflush(stdout);
												ifail = AE_find_dataset_named_ref2(dataset,0,&refname,&reftype,&namedrefobject);
												//ifail = AE_ask_dataset_named_ref2(dataset,"T5_abm",&reftype,&namedrefobject);
												//CHECK_FAIL;
												printf("\n after AE_find_dataset_named_ref \n");fflush(stdout);
												//ask_property_value_by_name(objtype, "Type", &type);

												//printf("\n type ======== \n",&type);fflush(stdout);

												if(namedrefobject)
												{
													//if(tc_strcmp(objtype,"T5_IndepBin")==0)
													//Text Added 11-10-2023
												    if((tc_strcmp(objtype,"T5_IndepBin")==0)||(tc_strcmp(objtype,"MSWordX")==0)||(tc_strcmp(objtype,"MSWord")==0)
														||(tc_strcmp(objtype,"MSWordTemplate")==0)||(tc_strcmp(objtype,"MSWordTemplateX")==0) || (tc_strcmp(objtype,"Text")==0))
													{
														printf("\t namedrefobject found \n"); fflush(stdout);
														ifail =(IMF_ask_original_file_name2(namedrefobject,&orig_name));
														printf("\t orig_name: in Rendering [%s]\n",orig_name); fflush(stdout);

														ifail = IMF_ask_file_pathname2(namedrefobject,mach_type,&pathname);	
														//ifail =(IMF_ask_file_pathname(namedrefobject,mach_type,pathname));	
														printf("\t pathname [%s]\n",pathname); fflush(stdout);

														//ifail = (IMF_ask_relative_path2(namedrefobject,&relative_path));
														//printf("\t relative_path [%s]\n",relative_path); fflush(stdout);

														ifail =( AOM_UIF_ask_value(namedrefobject,"file_size",&byte1));
														printf("\n byte1 size is --------- [%s]\n",byte1); fflush(stdout);

														ifail =( AOM_UIF_ask_value(namedrefobject,"file_name",&name));
														printf("\n name name is --------- [%s]\n",name); fflush(stdout);

														ifail =( AOM_ask_value_string(namedrefobject,"byte_size",&byte_size));
														printf("\n byte_sizeis --------- [%s]\n",byte_size); fflush(stdout);
																												
														//byte1int = atoi(byte1);
														byte1int = atol(byte1);
														printf("\n byte1int size is --------- [%d]\n",byte1int); fflush(stdout);
	

														tc_strcpy(test_file,pathname);
														printf("\n test_file [%s]\n",test_file); fflush(stdout);

														tc_strcpy(test_fileX,"/tmp");
														tc_strcat(test_fileX,"/");
														tc_strcat(test_fileX,orig_name);
														printf("\n test_fileX [%s]\n",test_fileX); fflush(stdout);
														
														tc_strcpy(test_file2,"");
														tc_strcat(test_file2,orig_name);
														printf("\n test_file2 [%s]\n",test_file2); fflush(stdout);////

//														tc_strcpy(test_file3,test_file2);
//														printf("\n test_file3 new [%s]\n",test_file3); fflush(stdout);
//
//														ItemId1 = tc_strtok(test_file3, ".");
//														ItemId2 = tc_strtok(NULL, ".");//.s //.swp
//
//														printf("\n test_file2 after after  [%s]\n",test_file2); fflush(stdout);
//														printf("\n ItemId1 after after -------- [%s]\n",ItemId1); fflush(stdout);
//														printf("\n ItemId2 after after -------- [%s]\n",ItemId2); fflush(stdout);
//
														//T5_IndepBin
//														printf("\t Inside reference_nameDS %s\n",reference_nameDS); fflush(stdout);
														tc_strcpy(Exfile," ");
														//strcpy(Exfile,"/home/testcmi/Adi/DIGIBUCK/BOMListJT/");
														//tc_strcpy(Exfile,"/user/bsd05818/Adi/");
														tc_strcpy(Exfile,"/tmp/");
														tc_strcat(Exfile,orig_name);
														printf("\t exporting now\n"); fflush(stdout);
														//AE_export_named_ref(dataset,reference_nameDS,Exfile);
														IMF_export_file(namedrefobject,Exfile);
														printf("\t Exfile is ---- [%s]\n",Exfile); fflush(stdout);
														strcpy(Exfile," ");
														flagX=0;
													}
//														else
//														{
//															tc_strcpy(test_file2,"");
//															tc_strcat(test_file2,"NA");
//															printf("\n AAAAA test_file2 AAAAAA [%s]\n",test_file2); fflush(stdout);
//														}
													}
													else
													{
														printf("\n problem with named reference of tpl \n"); fflush(stdout);
														flagX=1;
														tc_strcpy(test_file2,"");
														tc_strcat(test_file2,"NA");
														printf("\n AAAAA test_file2 AAAAAA [%s]\n",test_file2); fflush(stdout);
													}

															supfile=1;
															//if  ((nlsStrCmp(ChdPartTypeDup,"CAL") == 0 || nlsStrCmp(ChdPartTypeDup,"HCL") == 0) && (nlsStrStr(ContEOLDup,"Both")!=NULL || nlsStrCmp(ContEOLDup,"EOL")==0))

															if(((tc_strcmp(ChdPartType,"CAL") == 0)|| tc_strcmp(ChdPartType,"HCL") == 0) && ((tc_strstr(ContEOLDup,"Both")!=NULL) || tc_strcmp(ContEOLDup,"EOL")==0))
															{
																printf("\n..Container having Applicability ......%s",ContEOLDup);fflush(stdout);
																CalFlileReq=1;
															}

															if(tc_strcmp(ChdPartType,"CAL") == 0 || tc_strcmp(ChdPartType,"HCL") == 0)
															{	
																CalFileNameDup=NULL;
																CalFileNameDup=(char *) MEM_alloc(100);
																tc_strcpy(CalFileNameDup,test_file2);
																printf("\nkk.CalFileName is: [%s]",CalFileNameDup);fflush(stdout);
															}
														//}
												   //}
											    }											

											//CalFileName=(char *) MEM_alloc(100);
											

											if (!(tc_strcmp(ChdPartType,"CAL") == 0 || tc_strcmp(ChdPartType,"HCL") == 0))
											{
												printf("\n Part is not calibaration SW");fflush(stdout);
												//calfiletest=0;
												
											}
											else
											{										
												//tc_strcpy(CalFileName,relative_path);
												if ((tc_strstr(TPLEOLVAL,"BOTH")!=0) || (tc_strstr(TPLEOLVAL,"EOL")!=0))
												{
													calfiletest=1;
												}
												else
												{
													calfiletest=0;
												}
											}

										//if((tc_strcmp(test_file,"NA") != 0 ) && (flagX!=1))
										if((tc_strcmp(test_file,"NA") != 0 ) && (flagX==0))
											{
												printf("\n EOLDup is  [%s]   &  ContEOLDup is  [%s]  ContEOLDup_Val is  [%s]============ \n",EOLDup,ContEOLDup,ContEOLDup_Val);fflush(stdout);
												fprintf(fptr5,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%ld \n",VCnumberDup,container,conitemid,test_file2,containerrevdup,conitemrevidduptokS,conitemreviddupS,DML_name,EOLDup,byte1int);fflush(fptr5); 
												printf("\n NEWWWWWWWWWWWWWWWW fptr4444444444444444  ============ \n");fflush(stdout);
												fprintf(fptr4,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",vcProjDup,Desg,test_fileX,conitemid,contpartrevdupSS11copy,NewDate,container,containerrevdup,DML_name,EOLDup,test_file2);fflush(fptr4);
												//replacing container project by vc project
											}
										}
									}

						    iWrite  =0;	
						   
							printf("\n Expansion_TPL_16 contpartrevdup ------------>[%s] \n",contpartrevdup);fflush(stdout);//G_2
							printf("\n Expansion_TPL_16 ChdPartType ------------>[%s] \n",ChdPartType);fflush(stdout);//G_2
							printf("\n Expansion_TPL_16 test_file2 ------------>[%s] \n",test_file2);fflush(stdout);

//							char	*strToBereplRQ=NULL;
//							char	*strToBeUsedRQ=NULL;
//							char	*contpartrevdupSS11=NULL;
//							char	*contpartrevdupSS=NULL;
//							contpartrevdupSS=	(char*)malloc(30);
//				
//
//							tc_strcpy(contpartrevdupSS,contpartrevdup);
//							printf("\n Expansion_TPL_16 contpartrevdupSS ------------>[%s] \n",contpartrevdupSS);fflush(stdout);//G_2
//
//								
//								strToBereplRQ		=	(char*)malloc(5);
//								tc_strcpy(strToBereplRQ,"_");
//	
//								strToBeUsedRQ	=	(char*)malloc(5);
//								tc_strcpy(strToBeUsedRQ,",");
//
//								ifail =(STRNG_replace_str (contpartrevdupSS,strToBereplRQ, strToBeUsedRQ,&contpartrevdupSS11));

						  
						   if (tc_strcmp(ChdPartType, "STK") == 0)
							{							  
								flag=1;
								Sticker	=(char *) MEM_alloc(tc_strlen(contpart)+tc_strlen(contpartrevdupSS11)+tc_strlen(EOLDup)+25);
								tc_strcpy(Sticker,contpart);
								tc_strcat(Sticker,",");
								tc_strcat(Sticker,contpartrevdupSS11);
								tc_strcat(Sticker,"_");
								tc_strcat(Sticker,EOLDup);
								printf("\n Expansion_TPL_16 Sticker ------------>[%s] \n",Sticker);fflush(stdout);
							}
							else if (tc_strcmp(ChdPartType, "PBL") == 0)
							{
								Pr_Boot_Loader_Sm=(char *) MEM_alloc(200);
								Pr_Boot_Loader	 =(char *) MEM_alloc(100);

								tc_strcpy(Pr_Boot_Loader_Sm,contpart);
								tc_strcat(Pr_Boot_Loader_Sm,",");
								tc_strcat(Pr_Boot_Loader_Sm,contpartrevdupSS11);

								printf("\n Expansion_TPL_16 PBL Pr_Boot_Loader_Sm ------------>[%s] \n",Pr_Boot_Loader_Sm);fflush(stdout);

								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(SWDetails,contpart);//?????
								setAddStr(&iWrite,&SWDetails,contpart);

								tc_strcpy(Pr_Boot_Loader,contpart);
								tc_strcat(Pr_Boot_Loader,",");
								tc_strcat(Pr_Boot_Loader,contpartrevdupSS11);
								tc_strcat(Pr_Boot_Loader,"_");
								tc_strcat(Pr_Boot_Loader,EOLDup);
								printf("\n Expansion_TPL_16 PBL Pr_Boot_Loader ------------>[%s] \n",Pr_Boot_Loader);fflush(stdout);

							}
							else if (tc_strcmp(ChdPartType, "SBL") == 0)
							{
								Se_Boot_Loader_Sm =(char *) MEM_alloc(200);
								Se_Boot_Loader	 =(char *) MEM_alloc(100);

								tc_strcpy(Se_Boot_Loader_Sm,contpart);
								tc_strcat(Se_Boot_Loader_Sm,",");
								tc_strcat(Se_Boot_Loader_Sm,contpartrevdupSS11);

								printf("\n Expansion_TPL_16 SBL Se_Boot_Loader_Sm ------------>[%s] \n",Se_Boot_Loader_Sm);fflush(stdout);

								
								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(SWDetails,contpart); //?????
								setAddStr(&iWrite,&SWDetails,contpart);

								tc_strcpy(Se_Boot_Loader,contpart);
								tc_strcat(Se_Boot_Loader,",");
								tc_strcat(Se_Boot_Loader,contpartrevdupSS11);
								tc_strcat(Se_Boot_Loader,"_");
								tc_strcat(Se_Boot_Loader,EOLDup);

								printf("\n Expansion_TPL_16 SBL Se_Boot_Loader ------------>[%s] \n",Se_Boot_Loader);fflush(stdout);


							}
							else if (tc_strcmp(ChdPartType, "BAS") == 0)
							{
								BasicSw			 =(char *) MEM_alloc(100);

								//low_set_add_str(SWDetails,contpart); //?????
								tc_strcpy(BasicSw,contpart);
								tc_strcat(BasicSw,"_");
								tc_strcat(BasicSw,contpartrevdup);
								tc_strcat(BasicSw,"_");
								tc_strcat(BasicSw,EOLDup);

								printf("\n Expansion_TPL_16 BAS BasicSw ------------>[%s] \n",BasicSw);fflush(stdout);

							}
							else if (tc_strcmp(ChdPartType, "APP") == 0)
							{
								AppSw			 =(char *) MEM_alloc(200);
								AppSw_Sm	     =(char *) MEM_alloc(200);
								tc_strcpy(AppSw_Sm,contpart);
								tc_strcat(AppSw_Sm,",");
								tc_strcat(AppSw_Sm,contpartrevdupSS11);

								printf("\n Expansion_TPL_16 APP AppSw_Sm ------------>[%s] \n",AppSw_Sm);fflush(stdout);
								
								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(SWDetails,contpart);//>????
								setAddStr(&iWrite,&SWDetails,contpart);

								tc_strcpy(AppSw,contpart);
								tc_strcat(AppSw,",");
								tc_strcat(AppSw,contpartrevdupSS11);
								tc_strcat(AppSw,"_");
								tc_strcat(AppSw,EOLDup);

								

							}
							else if (tc_strcmp(ChdPartType,"CAL") == 0)
							{
								//CalFileNameDup = NULL;

								printf("\n Expansion_TPL_16 test_file2 ------------>[%s] \n",test_file2);fflush(stdout);
																
								CalSw_Sm	     =(char *) MEM_alloc(100);
								CalSw			 =(char *) MEM_alloc(100);
								//CalFileNameDup			 =(char *) MEM_alloc(100);
								tc_strcpy(CalSw_Sm,"");
								tc_strcat(CalSw_Sm,contpart);
								tc_strcat(CalSw_Sm,",");
								//tc_strcat(CalSw_Sm,CalFileName);
								tc_strcat(CalSw_Sm,test_file2);
								tc_strcat(CalSw_Sm,",");
								tc_strcat(CalSw_Sm,contpartrevdupSS11);
								printf("\n Expansion_TPL_16 CAL CalSw_Sm ------------>[%s] \n",CalSw_Sm);fflush(stdout);

								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

							//low_set_add_str(SWDetails,contpart);//????
							   setAddStr(&iWrite,&SWDetails,contpart);

								tc_strcpy(CalSw,contpart);
								tc_strcat(CalSw,",");
								tc_strcat(CalSw,contpartrevdupSS11);
								//tc_strcat(CalSw,"_");
								//tc_strcat(CalSw,EOLDup);

								//tc_strcpy(CalSwDup,contpartrev);
								//tc_strcat(CalSwDup,"_");
								//tc_strcat(CalSwDup,EOLDup);

								printf("\n Expansion_TPL_16 CAL CalSw ------------>[%s] \n",CalSw);fflush(stdout);

								//tc_strcpy(CalFileNameDup,"");
								//tc_strcat(CalFileNameDup,test_file2);
								printf("\n CalFileNameDup CAL CalSw isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);
								
							if(CalFileNameDup)
								 {
									printf("\n	value in CALFILENAME so continue %s  \n",CalFileNameDup);fflush(stdout);
									//break;
								 }
								else
								 {	
									tc_strcpy(CalFileNameDup,"");
									tc_strcat(CalFileNameDup,"NA");
									printf("\n cal file is null so setting to  %s\n",CalFileNameDup);fflush(stdout);
								 }

								printf("\n 2121221212221211111 CalFileNameDup CAL CalSw isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);

							}
							else if (tc_strcmp(ChdPartType, "CFG") == 0)
							{
								CfgSw_Sm		 =(char *) MEM_alloc(200);
								CfgSw		     =(char *) MEM_alloc(100);
								tc_strcpy(CfgSw_Sm,contpart);
								tc_strcat(CfgSw_Sm,",");
								tc_strcat(CfgSw_Sm,contpartrevdupSS11);

								printf("\n Expansion_TPL_16 CFG CfgSw_Sm ------------>[%s] \n",CfgSw_Sm);fflush(stdout);

								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(SWDetails,contpart);//????
								setAddStr(&iWrite,&SWDetails,contpart);
								tc_strcpy(CfgSw,contpart);
								tc_strcat(CfgSw,",");
								tc_strcat(CfgSw,contpartrevdupSS11);
								tc_strcat(CfgSw,"_");
								tc_strcat(CfgSw,EOLDup);

								printf("\n Expansion_TPL_16 CFG CfgSw ------------>[%s] \n",CfgSw);fflush(stdout);

							}
							else if (tc_strcmp(ChdPartType, "VCI") == 0)
							{
								VehCal			 =(char *) MEM_alloc(100);
								VehCal_Sm		 =(char *) MEM_alloc(200);

								tc_strcpy(VehCal_Sm,contpart);
								tc_strcat(VehCal_Sm,",");
								tc_strcat(VehCal_Sm,contpartrevdupSS11);

								printf("\n Expansion_TPL_16  VCI VehCal_Sm ------------>[%s] \n",VehCal_Sm);fflush(stdout);

								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(SWDetails,contpart);//????
								setAddStr(&iWrite,&SWDetails,contpart);
								tc_strcpy(VehCal,contpart);
								tc_strcat(VehCal,",");
								tc_strcat(VehCal,contpartrevdupSS11);
								tc_strcat(VehCal,"_");
								tc_strcat(VehCal,EOLDup);

								printf("\n Expansion_TPL_16 VCI VehCal ------------>[%s] \n",VehCal);fflush(stdout);

							}
							else if (tc_strcmp(ChdPartType,"HWC") == 0)
							{
								HwPart			 =(char *) MEM_alloc(100);
								HwPart_Sm		 =(char *) MEM_alloc(200);

								tc_strcpy(HwPart_Sm,contpart);
								tc_strcat(HwPart_Sm,",");
								tc_strcat(HwPart_Sm,contpartrevdupSS11);
								printf("\n Expansion_TPL_16 HWC HwPart_Sm ------------>[%s] \n",HwPart_Sm);fflush(stdout);

								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");

								//low_set_add_str(HWDetails,contpart);//?????
								setAddStr(&iWrite,&HWDetails,contpart);
								tc_strcpy(HwPart,contpart);
								tc_strcat(HwPart,",");
								tc_strcat(HwPart,contpartrevdupSS11);
								//tc_strcat(HwPart,"_");
								//tc_strcat(HwPart,EOLDup);
								printf("\n Expansion_TPL_16 HWC HwPart ------------>[%s] \n",HwPart);fflush(stdout);

								//if(HwPart)//just added.
								 //{
									//printf("\n some value in  HwPart so continue %s  \n",HwPart);fflush(stdout);
									//break;
								 //}/
							}
							else if (tc_strcmp(ChdPartType,"HCL") == 0)
							{
								CalSw		 =(char *) MEM_alloc(200);
								CalSwDup	 =(char *) MEM_alloc(200);
								VehCal	     =(char *) MEM_alloc(100);
								CalSw_Sm	 =(char *) MEM_alloc(200);
								VehCal_Sm	 =(char *) MEM_alloc(100);
								//CalFileNameDup			 =(char *) MEM_alloc(100);
								//Cal code
								tc_strcpy(CalSw_Sm,contpart);
								tc_strcat(CalSw_Sm,",");
								//tc_strcat(CalSw_Sm,CalFileName);
								tc_strcat(CalSw_Sm,test_file2);
								tc_strcat(CalSw_Sm,",");
								tc_strcat(CalSw_Sm,contpartrevdupSS11);
								printf("\n Expansion_TPL_16 HCL CalSw_Sm ------------>[%s] \n",CalSw_Sm);fflush(stdout);
								
								tc_strcat(contpart,",");
								tc_strcat(contpart,"NA");
								
								setAddStr(&iWrite,&SWDetails,contpart);

								tc_strcpy(CalSw,contpart);
								tc_strcat(CalSw,",");
								tc_strcat(CalSw,contpartrevdupSS11);
								//tc_strcat(CalSw,"_");
								//tc_strcat(CalSw,EOLDup);
								printf("\n Expansion_TPL_16 HCL CalSw ------------>[%s] \n",CalSw);fflush(stdout);


								tc_strcpy(CalSwDup,contpartrevdupSS11);
								tc_strcat(CalSwDup,"_");
								tc_strcat(CalSwDup,EOLDup);

								tc_strcpy(VehCal_Sm,contpart);
								tc_strcat(VehCal_Sm,",");
								tc_strcat(VehCal_Sm,contpartrevdupSS11);
								printf("\n 44 Expansion_TPL_16 HCL VehCal_Sm ------------>[%s] \n",VehCal_Sm);fflush(stdout);
								
								setAddStr(&iWrite,&SWDetails,contpart);
								tc_strcpy(VehCal,contpart);
								tc_strcat(VehCal,",");
								tc_strcat(VehCal,contpartrevdupSS11);
								tc_strcat(VehCal,"_");
								tc_strcat(VehCal,EOLDup);
								printf("\n 55 Expansion_TPL_16 HCL VehCal ------------>[%s] \n",VehCal);fflush(stdout);

								printf("\n 34343 CalFileNameDup -------->[%s] \n",CalFileNameDup);fflush(stdout);

								printf("\n  test_file2 -------->[%s] \n",test_file2);fflush(stdout);
								
								//tc_strcpy(CalFileNameDup,"");
								//tc_strcat(CalFileNameDup,test_file2);

								printf("\n  ttt- CalFileNameDup -------->[%s] \n",CalFileNameDup);fflush(stdout);
								
								printf("\n 66 CalFileNameDup HCL isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);

								if(CalFileNameDup)
								 {
									printf("\n some value in  HCL CALFILENAME so continue %s  \n",CalFileNameDup);fflush(stdout);
									//break;
								 }
								else
								 {	
									tc_strcpy(CalFileNameDup,"");
									tc_strcat(CalFileNameDup,"NA");
									printf("\n  HCL cal file is null so setting to  %s\n",CalFileNameDup);fflush(stdout);
								 }
								
							}
							printf("\n CalFileNameDup CAL CalSw isssss  ------------>[%s]---------------------------------------%s \n",CalFileNameDup, ChdPartType);fflush(stdout);

							printf("---------------------------------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
							}//23 sept
						} //NEW REMOVED
						printf("\n HwPart is AAAAAAAAA ------------>[%s] \n",HwPart);fflush(stdout);

						printf("\n 3333333333333333333333333333333333333333333333333333333333333333CalFileNameDup CAL CalSw isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);
						if((HwPart)!=NULL && tc_strlen(HwPart)>0)
						{
							printf("\n HwPart %s\n", HwPart);fflush(stdout);						
						}
						else
						{
							HwPart			 =(char *) MEM_alloc(100);
                            tc_strcpy(HwPart,"NA,-,-,-");
							printf("\n else HwPart %s\n", HwPart);fflush(stdout);
						}

						if((HwPart_Sm)!=NULL && tc_strlen(HwPart_Sm)>0)
						{
							printf("\n HwPart_Sm %s \n",HwPart_Sm);fflush(stdout);							
						}
						else
						{
							 HwPart_Sm			 =(char *) MEM_alloc(100);
                             tc_strcpy(HwPart_Sm,"-,-,-");
							 printf("\n else HwPart_Sm %s \n",HwPart_Sm);fflush(stdout);
						}

						if((VehCal)!=NULL && tc_strlen(VehCal)>0)
						{
							printf("\n VehCal is %s\n",VehCal);fflush(stdout);							
						}
						else
						{
							VehCal			 =(char *) MEM_alloc(100);
                            tc_strcpy(VehCal,"NA,-,-,-");
							printf("\n else VehCal %s\n",VehCal);fflush(stdout);	
						}

						if((VehCal_Sm)!=NULL && tc_strlen(VehCal_Sm)>0)
						{
							printf("\n VehCal_Sm is  %s\n",VehCal_Sm);fflush(stdout);
						}
						else
						{
							VehCal_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(VehCal_Sm,"-,-,-");
							printf("\n VehCal_Sm %s\n",VehCal_Sm);fflush(stdout);
						}

						if((CfgSw)!=NULL && tc_strlen(CfgSw)>0)
						{
							printf("\n CfgSw %s\n",CfgSw);fflush(stdout);
						}
						else
						{
							CfgSw			 =(char *) MEM_alloc(100);
                            tc_strcpy(CfgSw,"NA,-,-,-");
							printf("\n else  CfgSw %s\n",CfgSw);fflush(stdout);
						}

						if((CfgSw_Sm)!=NULL && tc_strlen(CfgSw_Sm)>0)
						{
							printf("\n CfgSw_Sm is %s\n",CfgSw_Sm);fflush(stdout);						
						}
						else
						{
							CfgSw_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(CfgSw_Sm,"-,-,-");
							printf("\n else CfgSw_Sm %s \n",CfgSw_Sm);fflush(stdout);	
						}

						

						if((CalSw)!=NULL && tc_strlen(CalSw)>0)
						{
							printf("\n CalSw is %s\n",CalSw);fflush(stdout);
						}
						else
						{
							CalSw			 =(char *) MEM_alloc(100);
                            tc_strcpy(CalSw,"NA,-,-,-");
							printf("\n else CalSw %s\n",CalSw);fflush(stdout);
						}

						printf("\n 444444444444444444444444444444444444444444444444444444444444444444444 CalFileNameDup CAL CalSw isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);

						if((CalSw_Sm)!=NULL && tc_strlen(CalSw_Sm)>0)
						{
							printf("\n CalSw_Sm is %s\n",CalSw_Sm);fflush(stdout);	
							
						}
						else
						{
							CalSw_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(CalSw_Sm,"-,-,-,-");
							printf("\n else CalSw_Sm is %s\n",CalSw_Sm);fflush(stdout);

						}

						printf("\n 55555555555555555555555555555555555555555555555555555555555555555555555555555555555555 CalFileNameDup CAL CalSw isssss  ------------>[%s] \n",CalFileNameDup);fflush(stdout);
						printf("\n TEST1111 \n");fflush(stdout);
						if((AppSw)!=NULL && tc_strlen(AppSw)>0)
						{
							printf("\n AppSw\n");fflush(stdout);
						}
						else
						{
							AppSw			 =(char *) MEM_alloc(100);
                            tc_strcpy(AppSw,"NA,-,-,-");
						}

						if((AppSw_Sm)!=NULL && tc_strlen(AppSw_Sm)>0)
						{
							printf("\n AppSw_Sm\n");fflush(stdout);
						}
						else
						{
							AppSw_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(AppSw_Sm,"-,-,-");
						}
	
						if((BasicSw)!=NULL && tc_strlen(BasicSw)>0)
						{
							printf("\n BasicSw\n");fflush(stdout);							
						}
						else
						{
							BasicSw			 =(char *) MEM_alloc(100);
                            tc_strcpy(BasicSw,"NA");
						}

						if((Se_Boot_Loader)!=NULL && tc_strlen(Se_Boot_Loader)>0)
						{
							printf("\n Se_Boot_Loader\n");fflush(stdout);
						}
						else
						{
							Se_Boot_Loader			 =(char *) MEM_alloc(100);
                            tc_strcpy(Se_Boot_Loader,"NA,-,-,-");
						}

						if((Se_Boot_Loader_Sm)!=NULL && tc_strlen(Se_Boot_Loader_Sm)>0)
						{
							printf("\n Se_Boot_Loader_Sm\n");fflush(stdout);
						}
						else
						{
							Se_Boot_Loader_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(Se_Boot_Loader_Sm,"-,-,-");
						}

						if((Pr_Boot_Loader)!=NULL && tc_strlen(Pr_Boot_Loader)>0)
						{
							printf("\n Pr_Boot_Loader\n");fflush(stdout);
						}
						else
						{   
							Pr_Boot_Loader			 =(char *) MEM_alloc(100);
							tc_strcpy(Pr_Boot_Loader,"NA,-,-,-");
						}

						if((Pr_Boot_Loader_Sm)!=NULL && tc_strlen(Pr_Boot_Loader_Sm)>0)
						{
							printf("\n Pr_Boot_Loader_Sm\n");fflush(stdout);
						}
						else
						{
							Pr_Boot_Loader_Sm			 =(char *) MEM_alloc(100);
                            tc_strcpy(Pr_Boot_Loader_Sm,"-,-,-");
						}
	
						if((Sticker)!=NULL && tc_strlen(Sticker)>0)
						{
							 printf("\n Sticker not null \n");fflush(stdout);
						}
						else
						{
							Sticker			 =(char *) MEM_alloc(100);
                          //  tc_strcpy(Sticker,"-,-,-,");//changed
                            tc_strcpy(Sticker,"-,-,-");//changed
						}
						if(flag==0)
						{
							Sticker			 =(char *) MEM_alloc(100);
							tc_strcpy(Sticker,"-,-,-");
						}
						printf("\n TEST2222 \n");fflush(stdout);
					// }//new added

						 printf("\n CalFileNameDup is $$$$$$$$$$$$$$$$$$$$$$ %s  \n",CalFileNameDup);fflush(stdout);

/*
						  if((tc_strstr(CalFileNameDup,".crc")!=NULL)||(tc_strstr(CalFileNameDup,".rec")!=NULL)||(tc_strstr(CalFileNameDup,".s")!=NULL)||(tc_strstr(CalFileNameDup,".n07")!=NULL)
							||(tc_strstr(CalFileNameDup,".s07")!=NULL)||(tc_strstr(CalFileNameDup,".N07")!=NULL)||(tc_strstr(CalFileNameDup,".S07")!=NULL)||(tc_strstr(CalFileNameDup,".S19")!=NULL)
							||(tc_strstr(CalFileNameDup,".hex")!=NULL)||(tc_strstr(CalFileNameDup,".ecs")!=NULL)||(tc_strstr(CalFileNameDup,".par")!=NULL)||(tc_strstr(CalFileNameDup,".sol")!=NULL)
							||(tc_strstr(CalFileNameDup,".mhx")!=NULL)||(tc_strstr(CalFileNameDup,".ulp")!=NULL)||(tc_strstr(CalFileNameDup,".swl")!=NULL)||(tc_strstr(CalFileNameDup,".bin")!=NULL)
							||(tc_strstr(CalFileNameDup,".abm")!=NULL)||(tc_strstr(CalFileNameDup,".iso")!=NULL)||(tc_strstr(CalFileNameDup,".sal")!=NULL)||(tc_strstr(CalFileNameDup,".idx")!=NULL)
							||(tc_strstr(CalFileNameDup,".sqfs")!=NULL)||(tc_strstr(CalFileNameDup,".hxk")!=NULL)||(tc_strstr(CalFileNameDup,".docx")!=NULL))*/
						//if(CalFileNameDup)
//						 {
//							//printf("\n indep binary file found  %s  \n",CalFileNameDup);fflush(stdout);
//							CalFlileReq=1;
//							printf("\n CalFlileReq value is  %d  \n",CalFlileReq);fflush(stdout);
//						 }
						if((CalFileNameDup)!=NULL && tc_strlen(CalFileNameDup)>0)
						 {
							if(tc_strcmp(CalFileNameDup,"NA")!=0)
							 {
								//printf("\n indep binary file found  %s  \n",CalFileNameDup);fflush(stdout);
								CalFlileReq=1;
								printf("\n CalFlileReq value is  %d  \n",CalFlileReq);fflush(stdout);
							 }
						 }
						else
						 {	
							CalFileNameDup			 =(char *) MEM_alloc(100);
							tc_strcpy(CalFileNameDup,"NA");
							printf("\n cal file is null so setting to  %s\n",CalFileNameDup);fflush(stdout);
						 }

						 printf("\n TEST3333 \n");fflush(stdout);
					// }//new adityaaa

						   
						//if(tc_strstr(container,"16R")==0  &&  tc_strstr(container,"16L")==0 )
						//{
							
							if((Sticker))
							{
								printf("\n Expansion_TPL_16  fptr33333333333333333333 \n");fflush(stdout);
								//fprintf(fptr3,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",req_item,Objdesc,container,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,Sticker,containerrevdup,ConProject,"NA",DML_name,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,sVehicleType,DRStatus);fflush(fptr3);//M_ASAS
								fprintf(fptr3,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",VCnumberDup,ObjDescFinal,container,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,Sticker,containerrevdup,ConProject,"NA",DML_name,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,sVehicleType,sGrpID);fflush(fptr3);
							//  fprintf(fp3,"  \n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,\n",vcnoDup,vcdescDup,containerDup,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,",",StickerDup,containerrevdup,ConProjectDup,"NA",DmlNo,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,"_");fflush(fp3);
							
							}
							else
							{
								printf("\n Expansion_TPL_16 else else fptr33333333333333333333 -------------- \n");fflush(stdout);
								//fprintf(fptr3,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,%s\n",req_item,Objdesc,container,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,",",Sticker,containerrevdup,ConProject,"NA",DML_name,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,sVehicleType,DRStatus);fflush(fptr3);
								fprintf(fptr3,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s\n",VCnumberDup,ObjDescFinal,container,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,",",Sticker,containerrevdup,ConProject,"NA",DML_name,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,sVehicleType,sGrpID);fflush(fptr3);

																																//54455424000R,X445 PETROL BS6 MT SEAT FABRIC JALI BLUE TECHY,544516261204,NA,-,-,-,IPC,NA,544516262003,NA,NR,2,NA,-,-,-,544516301132,NA,NR,2_BOTH,544516301130,NA,_BOTH,544216301141,NA,A,2_BOTH,544216301142,NA,F,2_BOTH,-,-,-,A_2,5445,NA,16PP251702,0,1,BOTH,NA,X445,NA,11,DAB+PAB+ABS,NA
						       	//fprintf(fp3,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%s,\n",vcnoDup,vcdescDup,containerDup,CalSw,Cnt_EcuTypeDup,CalFileNameDup,HwPart,VehCal,CfgSw,AppSw,Pr_Boot_Loader,Se_Boot_Loader,StickerDup,containerrevdup,ConProjectDup,"NA",DmlNo,CalFlileReq,supfile,ContEOLDup_Val,t5CountryValDup,t5MajorModelDup,BasicSw,t5NoEcuDup,t5ABSValDup,"_");fflush(fp3);

						    }
						//}
						//if(tc_strstr(container,"16R")==0  &&  tc_strstr(container,"16L")==0 )
						//{
							printf("\n Expansion_TPL_16 fptr6666666666666666 \n");fflush(stdout);
							//fprintf(fptr6,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",req_item,Objdesc,container,containerrev,CalSw_Sm,Cnt_EcuTypeDup,HwPart_Sm,VehCal_Sm,CfgSw_Sm,AppSw_Sm,Pr_Boot_Loader_Sm,Se_Boot_Loader_Sm,t5NoEcuDup);fflush(fptr6);
							fprintf(fptr6,"\n'%s,%s,'%s,%s,'%s,%s,'%s,'%s,'%s,'%s,'%s,'%s,%s\n",VCnumberDup,ObjDescFinal,container,containerrev,CalSw_Sm,Cnt_EcuTypeDup,HwPart_Sm,VehCal_Sm,CfgSw_Sm,AppSw_Sm,Pr_Boot_Loader_Sm,Se_Boot_Loader_Sm,t5NoEcuDup);fflush(fptr6);
						//	fprintf(fp6,  "\n'%s,%s,'%s,%s,'%s,%s,'%s,'%s,'%s,'%s,'%s,'%s,%s,\n",vcnoDup,vcdescDup,containerDup,containerrevdup,CalSw_Sm,Cnt_EcuTypeDup,HwPart_Sm,VehCal_Sm,CfgSw_Sm,AppSw_Sm,Pr_Boot_Loader_Sm,Se_Boot_Loader_Sm,t5NoEcuDup);fflush(fp6);
						CalSw_Sm="";
						VehCal_Sm="";
						Se_Boot_Loader_Sm="";
						AppSw_Sm="";
						CfgSw_Sm="";
						Pr_Boot_Loader_Sm="";
						HwPart_Sm="";
						CalFileNameDup="";
						test_file2="";
						//}
						

						flag=0;
				

						if((HwPart))
						{
							//MEM_free (HwPart);
							HwPart=NULL;
						}
						printf("\n..VehCal Expansion_TPL_16 going to file.. %s\n",VehCal);fflush(stdout);
						if((VehCal)!=NULL)
						{
							VehCal=NULL;
							printf("\n..inside mem freee VehCal \n");fflush(stdout);
							//MEM_free (VehCal); 							
						}
						printf("\n.CfgSw Expansion_TPL_16 .befor going to file..%s\n",CfgSw);fflush(stdout);
						if((CfgSw)!=NULL)
						{
							//MEM_free (CfgSw); 
							printf("\n..inside mem freee CfgSw \n");fflush(stdout);
							CfgSw=NULL;
						}
						printf("\n.CalSw Expansion_TPL_16 .befor going to file..%s\n",CalSw);fflush(stdout);
						if((CalSw)!=NULL)
						{
							//MEM_free (CalSw); 
							CalSw=NULL;
							printf("\n..inside mem freee CalSw \n");fflush(stdout);
						}
						printf("\n.AppSw Expansion_TPL_16 .befor going to file..%s\n",AppSw);fflush(stdout);
						if((AppSw)!=NULL)
						{
							AppSw=NULL;
							//MEM_free (AppSw);
							printf("\n..inside mem freee AppSw \n");fflush(stdout);
						}
						printf("\n.BasicSw Expansion_TPL_16 .befor going to file..%s\n",BasicSw);fflush(stdout);
						if((BasicSw)!=NULL)
						{
							//MEM_free (BasicSw); 
							BasicSw=NULL;
							printf("\n..inside mem freee BasicSw \n");fflush(stdout);
						}
						printf("\n.Se_Boot_Loader Expansion_TPL_16 .befor going to file..%s\n",Se_Boot_Loader);fflush(stdout);
						if((Se_Boot_Loader)!=NULL)
						{
							//MEM_free (Se_Boot_Loader);
							Se_Boot_Loader=NULL;
							printf("\n..inside mem freee Se_Boot_Loader \n");fflush(stdout);
						}
						printf("\n..Pr_Boot_Loader Expansion_TPL_16 befor going to file..%s\n",Pr_Boot_Loader);fflush(stdout);
						if((Pr_Boot_Loader)!=NULL)
						{
							//MEM_free (Pr_Boot_Loader); 	
							Pr_Boot_Loader=NULL;
						}
						printf("\n..Sticker Expansion_TPL_16 befor going to file..%s\n",Sticker);fflush(stdout);
						if((Sticker)!=NULL)
						{
							//MEM_free (Sticker);
							Sticker=NULL;
						}
						//}//NEW ADDED
					//}
				}
				else
				{ 

					if ((tc_strcmp(PartType,"PRM") == 0) && (tc_strcmp(EEPartType,"G")!=0))
					{

						if( AOM_ask_value_string(ChildRev,"item_id",&sParPrt)!=ITK_ok);
						printf("\nkk.Parameter Part number is [%s]\n",sParPrt); fflush(stdout);
						if( AOM_ask_value_string(ChildRev,"t5_EcuType",&PRM_EcuType)!=ITK_ok);
						printf("\n Expansion_TPL_16 inside pArt type  PRM_EcuType --------> [%s]\n",PRM_EcuType); fflush(stdout);


						//if( AOM_ask_value_string(ChildRev,"item_revision_id",&PRM_EcuRevType)!=ITK_ok);
						//printf("\n Expansion_TPL_16 PRM_EcuRevType --------> [%s]\n",PRM_EcuRevType); fflush(stdout);

						char * PRM_EcuTypeDup =NULL;
						PRM_EcuTypeDup=(char *) MEM_alloc(100);

						if((PRM_EcuType)!=NULL)
						{
							printf("\n prm value found --------> [%s]\n",PRM_EcuType); fflush(stdout);

							tc_strcpy(PRM_EcuTypeDup,"NA");
							for(iCnt=0; iCnt<iECU1; ++iCnt)
							{
								  if(tc_strcmp((ECUTypFull)[iCnt],PRM_EcuType)==0)
								  {
									tc_strcpy(PRM_EcuTypeDup,(ECUTypAbr)[iCnt]);
								  }
							 }
						}
						else 
						{
							printf("\n ECU value NOT found SO SETTING value as NA-------->\n"); fflush(stdout);
							tc_strcpy(PRM_EcuTypeDup,"NA");
						}

						char * ContainerRevVal =NULL;
						ContainerRevVal=(char *) MEM_alloc(100);
						//char * ContainerRevValDuptk =NULL;					
						//ContainerRevValDuptk=(char *) MEM_alloc(100);
						
						char * ContainerRevValDup =NULL;
						ContainerRevValDup=(char *) MEM_alloc(100);
						//ContainerRevValDup1=(char *) MEM_alloc(100);

						char* ContainerListVal	=	NULL;
						ContainerListVal=(char *) MEM_alloc(100);

						char	*strToBereplacedre;
						char	*strToBeUsedInsteadre;
		
						strToBereplacedre		=	(char*)malloc(5);
						tc_strcpy(strToBereplacedre,";");

						strToBeUsedInsteadre	=	(char*)malloc(5);
						tc_strcpy(strToBeUsedInsteadre,"_");//k_2


						

						printf("\n PRM_EcuTypeDup VALUE IS  --------> [%s]\n",PRM_EcuTypeDup); fflush(stdout);
						//printf("\n ContainerRevValDup VALUE IS  --------> [%s]\n",ContainerRevValDup); fflush(stdout);
					    
						iStrtIndx = 0;
						iPrIndx = setFindStr2(&iStrtIndx,&iWriteRPar,&ParaList,sParPrt);
						if(iPrIndx>=0)
						{
							do
							{
								tc_strcpy(ContainerListVal,ConatainerList[iPrIndx]);
								tc_strcpy(ContainerRevVal,ConatainerRev[iPrIndx]);
								ifail =STRNG_replace_str (ContainerRevVal,strToBereplacedre,strToBeUsedInsteadre,&ContainerRevValDup);

								//Generate Parameter Data
								if(iPrIndx>=0)
								{
									if( AOM_ask_value_string(ChildRev,"item_id",&ChildRevitemid)!=ITK_ok);
									printf("\n ChildRevitemid     --------> [%s]\n",ChildRevitemid); fflush(stdout);

									if( AOM_ask_value_string(ChildRev,"item_revision_id",&ChildRevitemrevid)!=ITK_ok);
									printf("\n ChildRevitemrevid     --------> [%s]\n",ChildRevitemrevid); fflush(stdout);

									ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type);
								
									if(EErelation_type != NULLTAG)
									{
										ifail = GRM_list_secondary_objects_only(ChildRev,EErelation_type,&cntEE,&attachmentsEE);
										printf("\n Expansion_TPL_16  T5_EEPrm AFTER GRM_list_secondary cntEE  ---------- %d\n",cntEE); fflush(stdout);
										if(cntEE > 0)
										{
											ITK_CALL(TCTYPE_find_type("T5_EPara","T5_EPara",&type_tag));
											ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"t5_EPDidValue",&property_tag));
											ITK_CALL(PROPDESC_ask_base_descriptor(property_tag,&base_prop_tag,&base_type_tag));
											ifail = AOM_sort_tags_by_properties(cntEE,attachmentsEE,1,&base_prop_tag,order,&n_sorted_tags,&sorted_tags);

											for(ee=0;ee<n_sorted_tags;ee++)
											{
												printf("\n para TESTTTTTT --------- %d\n",ee);fflush(stdout);
												ParaPtr = sorted_tags[ee];

												ifail = AOM_ask_value_string(ParaPtr,"t5_ECUType",&paraecutype);
												printf("\n para master ecutype   is ---------- [%s]\n",paraecutype); fflush(stdout);								

												ifail = AOM_ask_value_string(ParaPtr,"t5_t5EPDesc",&paradesc); 
												printf("\n parameter desc   is --------- [%s]\n",paradesc); fflush(stdout);

																			
												ifail = GRM_find_relation(ChildRev,ParaPtr,EErelation_type,&relationprop);

												ifail = AOM_ask_value_string(relationprop,"t5_BitValue",&DefValue);
												printf("\n DefValue is --------- [%s]\n",DefValue); fflush(stdout);
												
												char * DefValuedup   =NULL;
												char * printValueS   =NULL;
												printValueS=(char *) MEM_alloc(1000);
																						
												ifail =(STRNG_replace_str (DefValue, "'", " ",&DefValuedup));
												printf("\n DefValuedup qqqqqqqqqqqqqqqqqqqqqqqqq is --------- [%s]\n",DefValuedup); fflush(stdout);
												strip(DefValuedup);																					//uncomment for handling \n

												printf("\n DefValuedup is --------- [%s]\n",DefValuedup); fflush(stdout);										
												if(tc_strcmp(paradesc,"")!=0)
												{
													paradesclength = tc_strlen(paradesc);
													for(paradesccnt=0;paradesccnt<paradesclength;paradesccnt++)
													{
														if(paradesc[paradesccnt]=='\n')
															paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='`')
															//paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='~')
															//paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='|')
															//paradesc[paradesccnt] =' ';

														if(paradesc[paradesccnt]=='&')
															paradesc[paradesccnt] ='-';

														if(paradesc[paradesccnt]==',')
															paradesc[paradesccnt] =' ';

														printf("\n [%c]\n",paradesc[paradesccnt]);fflush(stdout);
													}
													cRplStr = (char *)MEM_alloc (paradesclength * sizeof(char));
													cRplStrdup=(char *) MEM_alloc(5000);
													tc_strcpy(cRplStr,paradesc);
													printf("\n parameter desc newwwwwwww   is --------- [%s]\n",cRplStr); fflush(stdout);
													
													if(cRplStr)
													{
														tc_strcpy(cRplStrdup,cRplStr);
														tc_strcat(cRplStrdup,";");
														tc_strcat(cRplStrdup,DefValuedup);

														
														NewcRplStrdup=(char *) MEM_alloc(5000);
														ifail =(STRNG_replace_str (cRplStrdup, "'", "_",&NewcRplStrdup));
														printf("\n 11 NewcRplStrdup   is --------- [%s]\n",NewcRplStrdup); fflush(stdout);
													}
												}	
												else
												{
													cRplStrdup=(char *) MEM_alloc(5000);
													tc_strcpy(cRplStrdup,NoParaDes);											  																						
													//tc_strcpy(cRplStrdup,"NA");
													tc_strcat(cRplStrdup,";");
													tc_strcat(cRplStrdup,DefValuedup);
													printf("\nkk.1 NoParaDes   is --------- [%s]\n",cRplStrdup); fflush(stdout);	

													NewcRplStrdup=(char *) MEM_alloc(5000);
													ifail =(STRNG_replace_str (cRplStrdup, "'", "_",&NewcRplStrdup));
													printf("\n NewcRplStrdup   is --------- [%s]\n",NewcRplStrdup); fflush(stdout);
												}

												AOM_ask_value_string(ParaPtr,"t5_EPApplicable",&ParaApp); //changed from ifail to itkcall
												printf("\t Expansion_TPL_16 parameter applicable val   is --------- [%s]\n",ParaApp); fflush(stdout);
												printf("\n testing 0000 here  --------- \n");fflush(stdout);
												 //if(ParaApp)
												 
												ParaAppdup_Val=NULL;
												ParaAppdup_Val=(char *) MEM_alloc(100);
												if((ParaApp)!=NULL && tc_strlen(ParaApp)>0)
												{
													
													if(tc_strcmp(ParaApp,"BothES")==0) 
													{											
														tc_strcpy(ParaAppdup_Val,ValBoth);												
													}
													else if(tc_strcmp(ParaApp,"Both")==0) 
													{											
														tc_strcpy(ParaAppdup_Val,ValBoth);												
													}
													else if(tc_strcmp(ParaApp,"EOL")==0) 
													{
														tc_strcpy(ParaAppdup_Val,"EOL");
													}
													//else if (tc_strstr(ParaApp,"NotApp")!=NULL)
													else if(tc_strcmp(ParaApp,"NotApp")==0) 
													{	
														tc_strcpy(ParaAppdup_Val,"NA");
													}
													//else if (tc_strstr(ParaApp,"Service")!=NULL)
													else if(tc_strcmp(ParaApp,"Service")==0) 
													{	
														tc_strcpy(ParaAppdup_Val,ValSer);
													}
													else if(tc_strcmp(ParaApp,"FOTA")==0) 
													{
														tc_strcpy(ParaAppdup_Val,"FOTA");
													}
													else if(tc_strcmp(ParaApp,"t5all")==0) 
													{
														tc_strcpy(ParaAppdup_Val,"ALL");
													}
												}
												else
												{
													printf("\n testing BEFORE 7777 here  --------- \n");fflush(stdout);
													//ParaAppdup_Val=(char *) MEM_alloc(100);
													tc_strcpy(ParaAppdup_Val,NoValStr);
												}

												printf("\n testing 9999 here  ---------%s \n",ParaAppdup_Val);fflush(stdout);

												//ITK_CALL(AOM_ask_value_string(ParaPtr,"t5_EPReadable",&ParaRead));
												AOM_ask_value_string(ParaPtr,"t5_EPReadable",&ParaRead);
												printf("\t Expansion_TPL_16 parameter READ val   is --------- [%s]\n",ParaRead); fflush(stdout);

												ParaReaddup_Val=NULL;
												ParaReaddup_Val=(char *) MEM_alloc(100);
												 
												// if(ParaRead)
												if((ParaRead)!=NULL && tc_strlen(ParaRead)>0)
												{												
													
													//if(tc_strstr(ParaApp,"BothRW")!=NULL) 
													//if(tc_strstr(ParaRead,"Both")!=NULL) 
													if(tc_strcmp(ParaRead,"Both")==0) 
													{					
														tc_strcpy(ParaReaddup_Val,ValBoth);
													}
													else if(tc_strcmp(ParaRead,"BothRW")==0) 
													{					
														tc_strcpy(ParaReaddup_Val,ValBoth);
													}									
													//else if (tc_strstr(ParaRead,"Write")!=NULL)
													else if(tc_strcmp(ParaRead,"Write1")==0) 
													{					
														tc_strcpy(ParaReaddup_Val,WriteVal);
													}
													//else if (tc_strstr(ParaRead,"Read Only")!=NULL)
													else if(tc_strcmp(ParaRead,"Read Only")==0) 
													{					
														tc_strcpy(ParaReaddup_Val,ReadVal);
													}
													else
													{
														tc_strcpy(ParaReaddup_Val,EOLNA);
													}
													printf("\n ParaReaddup_Val    is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
												}
												else
												{
													//ParaReaddup_Val=(char *) MEM_alloc(100);
													tc_strcpy(ParaReaddup_Val,NoValStr);
													printf("\n ParaReaddup_Val  elseeeee  is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
												}

												ITK_CALL( AOM_ask_value_string(ParaPtr,"t5_EPUnit",&paraunit));
												printf("\t Expansion_TPL_16 paraunit val   is --------- [%s]\n",paraunit); fflush(stdout);

												ITK_CALL( AOM_ask_value_string(ParaPtr,"t5_EPType",&paraeptype));
												printf("\t Expansion_TPL_16 paraeptype   is --------- [%s]\n",paraeptype); fflush(stdout);


												if((paraeptype))
												{
													printf("\t paraeptype not null \n",paraeptype); fflush(stdout);
													
													paraeptypelength = tc_strlen(paraeptype);
													for(paraccnt=0;paraccnt<paraeptypelength;paraccnt++)
													{
														if(paraeptype[paraccnt]=='\n')
															paraeptype[paraccnt] =' ';

														if(paraeptype[paraccnt]==',')
															paraeptype[paraccnt] =' ';

														if(paraeptype[paraccnt]=='&')
															paraeptype[paraccnt] ='-';

														printf("\n [%c]\n",paraeptype[paraccnt]);fflush(stdout);
													}
													
													//NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
													//tc_strcpy(NewDesc,Desc);
													tc_strdup(paraeptype,&paraeptypedup);
													
													//tc_strdup(paraeptype,&paraeptypedup);
													printf("\n paraeptypedupppppppppppppppppp is --------------- [%s]\n",paraeptypedup); fflush(stdout);
													strip(paraeptypedup);																					
													printf("\n paraeptypedup is --------- [%s]\n",paraeptypedup); fflush(stdout);								
												}
												else
												{	 paraeptypedup=NULL;
													 paraeptypedup=(char *) MEM_alloc(100);
													 tc_strcpy(paraeptypedup,NoValStr);
													 printf("\n in else paraeptypedup issssssss--------- [%s]\n",paraeptypedup); fflush(stdout);
												}


												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPLen",&paralen));
												printf("\t paralen is --------- [%s]\n",paralen); fflush(stdout);

												if((paralen))
												{
													printf("\t paralen not null \n",paralen); fflush(stdout);
												}
												else
												{    
													 paralen=NULL;
													 paralen=(char *) MEM_alloc(25);
													 tc_strcpy(paralen,Noval);
												}

												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPMin",&paramin));//value will be null
												printf("\n Expansion_TPL_16 paramin is --------- [%s]\n",paramin); fflush(stdout);

												if((paramin) && tc_strlen(paramin)>0)
												{
													printf("\n paramin not null [%s] \n",paramin); fflush(stdout);
												}
												else
												{
													 paramin=NULL;
													 paramin=(char *) MEM_alloc(25);
													 tc_strcpy(paramin,Noval);
													 printf("\n paramin ------- [%s] \n",paramin); fflush(stdout);
												}

												ifail = AOM_ask_value_string(ParaPtr,"t5_EPMax",&paramax);//value will be null
												printf("\n Expansion_TPL_16 paramax is --------- [%s]\n",paramax); fflush(stdout);

												if((paramax)&& tc_strlen(paramax)>0)
												{
													printf("\n paramax not null [%s]\n",paramax); fflush(stdout);
												}
												else
												{
													paramax=NULL;
													 paramax=(char *) MEM_alloc(25);
													 tc_strcpy(paramax,Noval);
													 printf("\n paramax ------- [%s] \n",paramax); fflush(stdout);
												}

												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPStep",&parastep));//?????check if attribute name is on master or rev
												printf("\n Expansion_TPL_16 parastep is --------- [%s]\n",parastep); fflush(stdout);

												
												
												if((parastep)&& tc_strlen(parastep)>0)
												{
													parastepdup=NULL;
													parastepdup=(char *) MEM_alloc(50);
													tc_strcpy(parastepdup,parastep);
													printf("\n Expansion_TPL_16 parastepdup is --------- [%s]\n",parastepdup); fflush(stdout);
												}
												else
												{
													parastepdup=NULL;
													parastepdup=(char *) MEM_alloc(50);
													tc_strcpy(parastepdup,Noval);
													printf("\n else Expansion_TPL_16 parastepdup is --------- [%s]\n",parastepdup); fflush(stdout);
												}

												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPDidValue",&ParaDIDVal));
												printf("\n Expansion_TPL_16 ParaDIDVal is --------- [%s]\n",ParaDIDVal); fflush(stdout);
												
												if((ParaDIDVal))
												{
													printf("\n ParaDIDVal not null \n",ParaDIDVal); fflush(stdout);
												}
												else
												{
													 ParaDIDVal=NULL;
													 ParaDIDVal=(char *) MEM_alloc(50);
													 tc_strcpy(ParaDIDVal,NoValStr);
													 printf("\n ParaDIDVal value is [%s] \n",ParaDIDVal); fflush(stdout);
												}

												ifail =( AOM_ask_value_string(ParaPtr,"object_name",&paradoc));
												printf("\n Expansion_TPL_16 paradoc is --------- [%s]\n",paradoc); fflush(stdout);

												if(paradoc)
												{
													paradocdup=NULL;
													paradocdup=(char *) MEM_alloc(75);
													tc_strcpy(paradocdup,paradoc);
											
												}
												else
												{
													paradocdup=NULL;
													paradocdup=(char *) MEM_alloc(75);
													tc_strcpy(paradocdup,"NA");
												}

												printf("\n Expansion_TPL_16 paradocdup  paradocdup is --------- [%s]\n",paradocdup); fflush(stdout);

												int paradocccnt=0;
												int paradocduplength=0;

												if(tc_strcmp(paradocdup,"")!=0)
												{
													paradocduplength = tc_strlen(paradocdup);
													for(paradocccnt=0;paradocccnt<paradocduplength;paradocccnt++)
													{
														if(paradocdup[paradocccnt]=='\n')
															paradocdup[paradocccnt] =' ';

														if(paradocdup[paradocccnt]==',')
															paradocdup[paradocccnt] =' ';

														if(paradocdup[paradocccnt]=='&')
															paradocdup[paradocccnt] ='-';

														printf("\n [%c]\n",paradocdup[paradocccnt]);fflush(stdout);
													}
												}
												tc_strdup(paradocdup,&paradocdupS);
																						
												printf("\n Expansion_TPL_16 paradocdupS is --------- [%s]\n",paradocdupS); fflush(stdout);

													char * NewparadocdupS   =NULL;
												NewparadocdupS=(char *) MEM_alloc(100);

												ifail =(STRNG_replace_str (paradocdupS, "'", "_",&NewparadocdupS));
												printf("\n NewparadocdupS   is --------- [%s]\n",NewparadocdupS); fflush(stdout);

												//ifail =( AOM_ask_value_string(ParaMaster,"t5_EPValid",&paravalid));//?????check if attribute name is on master or rev
												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPValid",&paravalid));//?????check if attribute name is on master or rev
												printf("\n Expansion_TPL_16  paravalid is --------- [%s]\n",paravalid); fflush(stdout);

												if((paravalid))
												{
													if (tc_strcmp(paravalid,"T1") == 0)
													{
														ValFlag=1;
													}
													else
													{
														ValFlag=0;
													}
												}
												else
												{
													ValFlag=0;
												}

												CreDate=NULL;
												//ifail =( AOM_ask_value_string(ParaPtr,"creation_date",&CreDate));
												ifail =( AOM_UIF_ask_value(ParaPtr,"creation_date",&CreDate));
												printf("\n CreDate is --------- [%s]\n",CreDate); fflush(stdout);
												
												ifail =( AOM_ask_value_string(ParaPtr,"t5_EPValueList",&paravallist));
												printf("\n paravallist is --------- [%s]\n",paravallist); fflush(stdout);

												char * paravallistdup   =NULL;
												paravallistdup=(char *) MEM_alloc(50);

												if((paravallist)!=NULL  && tc_strlen(paravallist)>0)
												{
												   tc_strcpy(paravallistdup,paravallist);
												   printf("\n 1111 paravallistdup is --------- [%s]\n",paravallistdup); fflush(stdout);
												}
												else
												{
												   tc_strcpy(paravallistdup,NoValStr);
												   printf("\n 2222 paravallistdup is --------- [%s]\n",paravallistdup); fflush(stdout);
												}

												printf("\n ParaReaddup_Val QQQQQQQQQQQQQQQQQQQQQQQQ    is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
												//printf("\n Expansion_TPL_16 fptr22222222222222222 \n");fflush(stdout);
												if(tc_strlen(NewcRplStrdup)>1000)
												{
													sParaDesc = subStrParDsc(NewcRplStrdup,0,500);
												}
												else
												{
													sParaDesc =(char *) MEM_alloc(2500);
													tc_strcpy(sParaDesc,NewcRplStrdup);
												}

												//printf(fptr2,"\n %s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d\n",container,paradocdupS,cRplStr,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,req_item,ParaAppdup_Val,ParaReaddup_Val,cntEE);fflush(fptr2);
												printf("%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s\n",container,NewparadocdupS,sParaDesc,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);fflush(fptr2);
												fprintf(fptr2,"\n %s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s\n",container,NewparadocdupS,sParaDesc,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);fflush(fptr2);
												//sprintf(printValueS,"%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s",container,paradocdupS,cRplStr,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);
												//fprintf(fptr2,"%s\n",printValueS);fflush(fptr2);																													
											}
										}
									}
								}

								iStrtIndx=iPrIndx+1;
								iPrIndx = setFindStr2(&iStrtIndx,&iWriteRPar,&ParaList,sParPrt);
							}while(iPrIndx>=0);
						}
						else
						{
							if (tc_strstr(PRM_EcuTypeDup,"NA")==NULL) //value should not be NA
							{															
									index	=-1;
									int containtercount =0;
									int conn_tags_found3 =0;
									int newSlvcnt =0;
										tag_t  *contags_found3   = NULL;
										tag_t MstrSlvrelation_type2  = NULLTAG;
										tag_t  MstrChildrev   = NULLTAG;
										tag_t * newSlvattachments   = NULLTAG;
										char* MScontain=NULL;
									for(mm=0;mm<iWriteRConType;mm++) // changed from <= to < because of exceptional handler error
									{
										printf("\n inside snapshot transfer ConatainerTypeListX[mm]TEst123 : %s, PRM_EcuTypeDup : %s, ConatainerList : %s, Container id == %s\n",ConatainerTypeListX[mm],PRM_EcuTypeDup,ConatainerList[mm],container);fflush(stdout);
										if(tc_strcmp(ConatainerTypeListX[mm],PRM_EcuTypeDup)==0)

										{
											containtercount = containtercount + 1;
											
										}
									}

									printf("\nContainer Count == %d", containtercount);fflush(stdout);

									//setsize > 1 look for master slave relationship
									if(containtercount>1)
									{ 
										for(mm=0;mm<iWriteRConType;mm++) // changed from <= to < because of exceptional handler error
										{
											printf("\n inside snapshot transfer ConatainerTypeListX[mm] : %s, PRM_EcuTypeDup : %s, ConatainerList : %s\n",ConatainerTypeListX[mm],PRM_EcuTypeDup,ConatainerList[mm]);fflush(stdout);
											if(tc_strcmp(ConatainerTypeListX[mm],PRM_EcuTypeDup)==0)

											{
												index = mm;
												printf("\n ELSE index value is  :-------------- %d \n",index);fflush(stdout);
											

												const char **conattrs3 = (const char **) MEM_alloc(2 * sizeof(char *));
												const char **convalues3 = (const char **) MEM_alloc(2 * sizeof(char *));
												conattrs3[0] ="item_id";
											
												 convalues3[0] = ConatainerList[index];
									
												ifail =(ITEM_find_item_revs_by_key_attributes(1,conattrs3, convalues3,ConatainerRev[index], &conn_tags_found3, &contags_found3));
												CHECK_FAIL;
												MEM_free(conattrs3);
												MEM_free(convalues3);

												if (conn_tags_found3>0)
												{
												   MstrChildrev= contags_found3[0];
												   //printf("\n INSIDE TPL_BOM_List  Childrev \n");fflush(stdout);

												   if( AOM_ask_value_string(MstrChildrev,"item_id",&MScontain)!=ITK_ok);

													ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvrelation_type2); 
													{																		
														if(MstrSlvrelation_type2 != NULLTAG)
														 {
															 ITKCALL(GRM_list_secondary_objects_only(MstrChildrev,MstrSlvrelation_type2,&newSlvcnt,&newSlvattachments));

															 if (newSlvcnt>0)
															 {
																 break;
															 }
															 
														 }
													}
												}																																
											}
										}
									}
									else
									{
										for(mm=0;mm<iWriteRConType;mm++) // changed from <= to < because of exceptional handler error
										{
											printf("\n inside snapshot transfer ConatainerTypeListX[mm] : %s, PRM_EcuTypeDup : %s, ConatainerList : %s\n",ConatainerTypeListX[mm],PRM_EcuTypeDup,ConatainerList[mm]);fflush(stdout);
											if(tc_strcmp(ConatainerTypeListX[mm],PRM_EcuTypeDup)==0)

											{
												index = mm;
												printf("\n ELSE index value is  :-------------- %d \n",index);fflush(stdout);
												break;
											}
										}
									}
									if(index >= 0)
									{							
										tc_strcpy(ContainerListVal,ConatainerList[index]);
										//ContainerListVal=low_set_get_str(ConatainerList,index);								
										tc_strcpy(ContainerRevVal,ConatainerRev[index]);

										//ContainerRevValDup = tc_strtok (ContainerRevValDuptk,";"); HH

										ifail =STRNG_replace_str (ContainerRevVal,strToBereplacedre, strToBeUsedInsteadre,&ContainerRevValDup);


										printf("\n..Expansion_TPL_16 222222 Parameter matches with container is :%s having revision %s and ECUTYPE %s",ContainerListVal,ContainerRevValDup,PRM_EcuTypeDup);fflush(stdout);

									}
									else
									{
										printf("\n..Expansion_TPL_16 No match for parameter .");fflush(stdout);
										tc_strcpy(ContainerListVal,NoValStr);
										tc_strcpy(ContainerRevValDup,NoValStr);;
									}
							}
							else
							{
								printf("\n..Expansion_TPL_16 No type for comparison .%s,%s",PRM_EcuTypeDup,container);fflush(stdout);

								tc_strcpy(ContainerListVal,NoValStr);
								tc_strcpy(ContainerRevValDup,NoValStr);
						
							}
							if(index>=0)
							{
							  if( AOM_ask_value_string(ChildRev,"item_id",&ChildRevitemid)!=ITK_ok);
							  printf("\n ChildRevitemid     --------> [%s]\n",ChildRevitemid); fflush(stdout);

							  if( AOM_ask_value_string(ChildRev,"item_revision_id",&ChildRevitemrevid)!=ITK_ok);
							  printf("\n ChildRevitemrevid     --------> [%s]\n",ChildRevitemrevid); fflush(stdout);

							  ifail = GRM_find_relation_type("T5_EEPrm",&EErelation_type);
							
							  if(EErelation_type != NULLTAG)
								{
								  ifail = GRM_list_secondary_objects_only(ChildRev,EErelation_type,&cntEE,&attachmentsEE);
								  printf("\n Expansion_TPL_16  T5_EEPrm AFTER GRM_list_secondary cntEE  ---------- %d\n",cntEE); fflush(stdout);
								  if (cntEE > 0)
									{
										ITK_CALL(TCTYPE_find_type("T5_EPara","T5_EPara",&type_tag));
										ITK_CALL(TCTYPE_ask_property_by_name(type_tag,"t5_EPDidValue",&property_tag));
										ITK_CALL(PROPDESC_ask_base_descriptor(property_tag,&base_prop_tag,&base_type_tag));
										ifail = AOM_sort_tags_by_properties(cntEE,attachmentsEE,1,&base_prop_tag,order,&n_sorted_tags,&sorted_tags);


									 for(ee=0;ee<n_sorted_tags;ee++)
										{
										  printf("\n para TESTTTTTT --------- %d\n",ee);fflush(stdout);
										  ParaPtr = sorted_tags[ee];
									
										  //if(ITEM_ask_item_of_rev  ( ParaPtr,&ParaMaster) );
										  

										  ifail = AOM_ask_value_string(ParaPtr,"t5_ECUType",&paraecutype);
										  printf("\n para master ecutype   is ---------- [%s]\n",paraecutype); fflush(stdout);								

										  ifail = AOM_ask_value_string(ParaPtr,"t5_t5EPDesc",&paradesc); 
										  printf("\n parameter desc   is --------- [%s]\n",paradesc); fflush(stdout);

																		
											ifail = GRM_find_relation(ChildRev,ParaPtr,EErelation_type,&relationprop);

											ifail = AOM_ask_value_string(relationprop,"t5_BitValue",&DefValue);
											printf("\n DefValue is --------- [%s]\n",DefValue); fflush(stdout);
											
											char * DefValuedup   =NULL;
											char * printValueS   =NULL;
											printValueS=(char *) MEM_alloc(1000);
																					
											//ifail =(STRNG_replace_str (DefValue,"\n","\0",&DefValuedup1));
										//	tc_strdup(DefValue,&DefValuedup);
											ifail =(STRNG_replace_str (DefValue, "'", " ",&DefValuedup));
											printf("\n DefValuedup qqqqqqqqqqqqqqqqqqqqqqqqq is --------- [%s]\n",DefValuedup); fflush(stdout);
											strip(DefValuedup);																					//uncomment for handling \n

											printf("\n DefValuedup is --------- [%s]\n",DefValuedup); fflush(stdout);										
											
											


										  
								
										  //if((paradesc))
										 if(tc_strcmp(paradesc,"")!=0)
											{
												paradesclength = tc_strlen(paradesc);
												for(paradesccnt=0;paradesccnt<paradesclength;paradesccnt++)
													{
														if(paradesc[paradesccnt]=='\n')
															paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='`')
															//paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='~')
															//paradesc[paradesccnt] =' ';

														//if(paradesc[paradesccnt]=='|')
															//paradesc[paradesccnt] =' ';

														if(paradesc[paradesccnt]=='&')
															paradesc[paradesccnt] ='-';

														if(paradesc[paradesccnt]==',')
															paradesc[paradesccnt] =' ';

														printf("\n [%c]\n",paradesc[paradesccnt]);fflush(stdout);
													}
												cRplStr = (char *)MEM_alloc (paradesclength * sizeof(char));
												cRplStrdup=(char *) MEM_alloc(5000);
												tc_strcpy(cRplStr,paradesc);
												printf("\n parameter desc newwwwwwww   is --------- [%s]\n",cRplStr); fflush(stdout);

												
												if(cRplStr)
												{
													tc_strcpy(cRplStrdup,cRplStr);
													tc_strcat(cRplStrdup,";");
													tc_strcat(cRplStrdup,DefValuedup);

													
													NewcRplStrdup=(char *) MEM_alloc(5000);
													ifail =(STRNG_replace_str (cRplStrdup, "'", "_",&NewcRplStrdup));
													printf("\n 11 NewcRplStrdup   is --------- [%s]\n",NewcRplStrdup); fflush(stdout);
												}
											
											}	
											else
											{
												  cRplStrdup=(char *) MEM_alloc(5000);
												  tc_strcpy(cRplStrdup,NoParaDes);											  																						
												  //tc_strcpy(cRplStrdup,"NA");
												  tc_strcat(cRplStrdup,";");
												  tc_strcat(cRplStrdup,DefValuedup);
												  printf("\nkk.2 NoParaDes   is --------- [%s]\n",cRplStrdup); fflush(stdout);	

												   NewcRplStrdup=(char *) MEM_alloc(5000);
												  ifail =(STRNG_replace_str (cRplStrdup, "'", "_",&NewcRplStrdup));
												  printf("\n NewcRplStrdup   is --------- [%s]\n",NewcRplStrdup); fflush(stdout);
											}


											AOM_ask_value_string(ParaPtr,"t5_EPApplicable",&ParaApp); //changed from ifail to itkcall
											printf("\t Expansion_TPL_16 parameter applicable val   is --------- [%s]\n",ParaApp); fflush(stdout);
											printf("\n testing 0000 here  --------- \n");fflush(stdout);
											 //if(ParaApp)
											 
												ParaAppdup_Val=NULL;
												ParaAppdup_Val=(char *) MEM_alloc(100);
											if((ParaApp)!=NULL && tc_strlen(ParaApp)>0)
											 {
												
												if(tc_strcmp(ParaApp,"BothES")==0) 
												{											
													tc_strcpy(ParaAppdup_Val,ValBoth);												
												}
												else if(tc_strcmp(ParaApp,"Both")==0) 
												{											
													tc_strcpy(ParaAppdup_Val,ValBoth);												
												}
												else if(tc_strcmp(ParaApp,"EOL")==0) 
												{
													tc_strcpy(ParaAppdup_Val,"EOL");
												}
												//else if (tc_strstr(ParaApp,"NotApp")!=NULL)
												else if(tc_strcmp(ParaApp,"NotApp")==0) 
												{	
													tc_strcpy(ParaAppdup_Val,"NA");
												}
												//else if (tc_strstr(ParaApp,"Service")!=NULL)
												else if(tc_strcmp(ParaApp,"Service")==0) 
												{	
													tc_strcpy(ParaAppdup_Val,ValSer);
												}
												else if(tc_strcmp(ParaApp,"FOTA")==0) 
												{
													tc_strcpy(ParaAppdup_Val,"FOTA");
												}
												else if(tc_strcmp(ParaApp,"t5all")==0) 
												{
													tc_strcpy(ParaAppdup_Val,"ALL");
												}
											}
											else
											{
												printf("\n testing BEFORE 7777 here  --------- \n");fflush(stdout);
												//ParaAppdup_Val=(char *) MEM_alloc(100);
												tc_strcpy(ParaAppdup_Val,NoValStr);
											}

											printf("\n testing 9999 here  ---------%s \n",ParaAppdup_Val);fflush(stdout);

											//ITK_CALL(AOM_ask_value_string(ParaPtr,"t5_EPReadable",&ParaRead));
											AOM_ask_value_string(ParaPtr,"t5_EPReadable",&ParaRead);
											printf("\t Expansion_TPL_16 parameter READ val   is --------- [%s]\n",ParaRead); fflush(stdout);

											ParaReaddup_Val=NULL;
											ParaReaddup_Val=(char *) MEM_alloc(100);
											 
											// if(ParaRead)
											if((ParaRead)!=NULL && tc_strlen(ParaRead)>0)
											 {												
												
												//if(tc_strstr(ParaApp,"BothRW")!=NULL) 
												//if(tc_strstr(ParaRead,"Both")!=NULL) 
												if(tc_strcmp(ParaRead,"Both")==0) 
												{					
													tc_strcpy(ParaReaddup_Val,ValBoth);
												}
												else if(tc_strcmp(ParaRead,"BothRW")==0) 
												{					
													tc_strcpy(ParaReaddup_Val,ValBoth);
												}									
												//else if (tc_strstr(ParaRead,"Write")!=NULL)
												else if(tc_strcmp(ParaRead,"Write1")==0) 
												{					
													tc_strcpy(ParaReaddup_Val,WriteVal);
												}
												//else if (tc_strstr(ParaRead,"Read Only")!=NULL)
												else if(tc_strcmp(ParaRead,"Read Only")==0) 
												{					
													tc_strcpy(ParaReaddup_Val,ReadVal);
												}
												else
												{
													tc_strcpy(ParaReaddup_Val,EOLNA);
												}
												printf("\n ParaReaddup_Val    is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
											}
											else
											{
												//ParaReaddup_Val=(char *) MEM_alloc(100);
												tc_strcpy(ParaReaddup_Val,NoValStr);
												printf("\n ParaReaddup_Val  elseeeee  is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
											}

											ITK_CALL( AOM_ask_value_string(ParaPtr,"t5_EPUnit",&paraunit));
											printf("\t Expansion_TPL_16 paraunit val   is --------- [%s]\n",paraunit); fflush(stdout);

											ITK_CALL( AOM_ask_value_string(ParaPtr,"t5_EPType",&paraeptype));
											printf("\t Expansion_TPL_16 paraeptype   is --------- [%s]\n",paraeptype); fflush(stdout);


											if((paraeptype))
											{
												printf("\t paraeptype not null \n",paraeptype); fflush(stdout);
												
												paraeptypelength = tc_strlen(paraeptype);
												for(paraccnt=0;paraccnt<paraeptypelength;paraccnt++)
												{
													if(paraeptype[paraccnt]=='\n')
														paraeptype[paraccnt] =' ';

													if(paraeptype[paraccnt]==',')
														paraeptype[paraccnt] =' ';

													if(paraeptype[paraccnt]=='&')
														paraeptype[paraccnt] ='-';

													printf("\n [%c]\n",paraeptype[paraccnt]);fflush(stdout);
												}
												
												//NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
												//tc_strcpy(NewDesc,Desc);
												tc_strdup(paraeptype,&paraeptypedup);
												
												//tc_strdup(paraeptype,&paraeptypedup);
												printf("\n paraeptypedupppppppppppppppppp is --------------- [%s]\n",paraeptypedup); fflush(stdout);
												strip(paraeptypedup);																					
												printf("\n paraeptypedup is --------- [%s]\n",paraeptypedup); fflush(stdout);								
											}
											else
											{	 paraeptypedup=NULL;
												 paraeptypedup=(char *) MEM_alloc(100);
												 tc_strcpy(paraeptypedup,NoValStr);
												 printf("\n in else paraeptypedup issssssss--------- [%s]\n",paraeptypedup); fflush(stdout);
											}


											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPLen",&paralen));
											printf("\t paralen is --------- [%s]\n",paralen); fflush(stdout);

											if((paralen))
											{
												printf("\t paralen not null \n",paralen); fflush(stdout);
											}
											else
											{    
												 paralen=NULL;
												 paralen=(char *) MEM_alloc(25);
												 tc_strcpy(paralen,Noval);
											}

											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPMin",&paramin));//value will be null
											printf("\n Expansion_TPL_16 paramin is --------- [%s]\n",paramin); fflush(stdout);

											if((paramin) && tc_strlen(paramin)>0)
											{
												printf("\n paramin not null [%s] \n",paramin); fflush(stdout);
											}
											else
											{
												 paramin=NULL;
												 paramin=(char *) MEM_alloc(25);
												 tc_strcpy(paramin,Noval);
												 printf("\n paramin ------- [%s] \n",paramin); fflush(stdout);
											}

											ifail = AOM_ask_value_string(ParaPtr,"t5_EPMax",&paramax);//value will be null
											printf("\n Expansion_TPL_16 paramax is --------- [%s]\n",paramax); fflush(stdout);

											if((paramax)&& tc_strlen(paramax)>0)
											{
												printf("\n paramax not null [%s]\n",paramax); fflush(stdout);
											}
											else
											{
												paramax=NULL;
												 paramax=(char *) MEM_alloc(25);
												 tc_strcpy(paramax,Noval);
												 printf("\n paramax ------- [%s] \n",paramax); fflush(stdout);
											}

											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPStep",&parastep));//?????check if attribute name is on master or rev
											printf("\n Expansion_TPL_16 parastep is --------- [%s]\n",parastep); fflush(stdout);

											
											
											if((parastep)&& tc_strlen(parastep)>0)
											{
												parastepdup=NULL;
												parastepdup=(char *) MEM_alloc(50);
												tc_strcpy(parastepdup,parastep);
												printf("\n Expansion_TPL_16 parastepdup is --------- [%s]\n",parastepdup); fflush(stdout);
											}
											else
											{
												parastepdup=NULL;
												parastepdup=(char *) MEM_alloc(50);
												tc_strcpy(parastepdup,Noval);
												printf("\n else Expansion_TPL_16 parastepdup is --------- [%s]\n",parastepdup); fflush(stdout);
											}

											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPDidValue",&ParaDIDVal));
											printf("\n Expansion_TPL_16 ParaDIDVal is --------- [%s]\n",ParaDIDVal); fflush(stdout);
											
											if((ParaDIDVal))
											{
												printf("\n ParaDIDVal not null \n",ParaDIDVal); fflush(stdout);
											}
											else
											{
												 ParaDIDVal=NULL;
												 ParaDIDVal=(char *) MEM_alloc(50);
												 tc_strcpy(ParaDIDVal,NoValStr);
												 printf("\n ParaDIDVal value is [%s] \n",ParaDIDVal); fflush(stdout);
											}

											ifail =( AOM_ask_value_string(ParaPtr,"object_name",&paradoc));
											printf("\n Expansion_TPL_16 paradoc is --------- [%s]\n",paradoc); fflush(stdout);

											if(paradoc)
											{
												paradocdup=NULL;
												paradocdup=(char *) MEM_alloc(75);
												tc_strcpy(paradocdup,paradoc);
										
											}
											else
											{
												paradocdup=NULL;
												paradocdup=(char *) MEM_alloc(75);
												tc_strcpy(paradocdup,"NA");
											}

											printf("\n Expansion_TPL_16 paradocdup  paradocdup is --------- [%s]\n",paradocdup); fflush(stdout);

											int paradocccnt=0;
											int paradocduplength=0;

											if(tc_strcmp(paradocdup,"")!=0)
											{
												paradocduplength = tc_strlen(paradocdup);
												for(paradocccnt=0;paradocccnt<paradocduplength;paradocccnt++)
												{
													if(paradocdup[paradocccnt]=='\n')
														paradocdup[paradocccnt] =' ';

													if(paradocdup[paradocccnt]==',')
														paradocdup[paradocccnt] =' ';

													if(paradocdup[paradocccnt]=='&')
														paradocdup[paradocccnt] ='-';

													printf("\n [%c]\n",paradocdup[paradocccnt]);fflush(stdout);
												}
											}
											tc_strdup(paradocdup,&paradocdupS);
																					
											printf("\n Expansion_TPL_16 paradocdupS is --------- [%s]\n",paradocdupS); fflush(stdout);

												char * NewparadocdupS   =NULL;
											NewparadocdupS=(char *) MEM_alloc(100);

											ifail =(STRNG_replace_str (paradocdupS, "'", "_",&NewparadocdupS));
											printf("\n NewparadocdupS   is --------- [%s]\n",NewparadocdupS); fflush(stdout);

											//ifail =( AOM_ask_value_string(ParaMaster,"t5_EPValid",&paravalid));//?????check if attribute name is on master or rev
											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPValid",&paravalid));//?????check if attribute name is on master or rev
											printf("\n Expansion_TPL_16  paravalid is --------- [%s]\n",paravalid); fflush(stdout);

											if((paravalid))
											{
											 if (tc_strcmp(paravalid,"T1") == 0)
												{
													ValFlag=1;
												}
												else
												{
													ValFlag=0;
												}
											}
											else
											{
												ValFlag=0;
											}

											CreDate=NULL;
											//ifail =( AOM_ask_value_string(ParaPtr,"creation_date",&CreDate));
											ifail =( AOM_UIF_ask_value(ParaPtr,"creation_date",&CreDate));
											printf("\n CreDate is --------- [%s]\n",CreDate); fflush(stdout);
											
											ifail =( AOM_ask_value_string(ParaPtr,"t5_EPValueList",&paravallist));
											printf("\n paravallist is --------- [%s]\n",paravallist); fflush(stdout);

											char * paravallistdup   =NULL;
											paravallistdup=(char *) MEM_alloc(50);

											if((paravallist)!=NULL  && tc_strlen(paravallist)>0)
											{
											   tc_strcpy(paravallistdup,paravallist);
											   printf("\n 1111 paravallistdup is --------- [%s]\n",paravallistdup); fflush(stdout);
											}
											else
											{
											   tc_strcpy(paravallistdup,NoValStr);
											   printf("\n 2222 paravallistdup is --------- [%s]\n",paravallistdup); fflush(stdout);
											}

											printf("\n ParaReaddup_Val QQQQQQQQQQQQQQQQQQQQQQQQ    is --------- [%s]\n",ParaReaddup_Val); fflush(stdout);
											//printf("\n Expansion_TPL_16 fptr22222222222222222 \n");fflush(stdout);
											if(tc_strlen(NewcRplStrdup)>1000)
											{
												sParaDesc = subStrParDsc(NewcRplStrdup,0,500);
											}
											else
											{
												sParaDesc =(char *) MEM_alloc(2500);
												tc_strcpy(sParaDesc,NewcRplStrdup);
											}

											//printf(fptr2,"\n %s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d\n",container,paradocdupS,cRplStr,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,req_item,ParaAppdup_Val,ParaReaddup_Val,cntEE);fflush(fptr2);
											printf("%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s\n",container,NewparadocdupS,sParaDesc,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);fflush(fptr2);
											fprintf(fptr2,"\n %s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s\n",container,NewparadocdupS,sParaDesc,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);fflush(fptr2);
											//sprintf(printValueS,"%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%s,%s",container,paradocdupS,cRplStr,paraeptypedup,ValFlag,paramin,paramax,parastepdup,paralen,paravallistdup,paraunit,"NA",PRM_EcuTypeDup,DefValuedup,ContainerListVal,ContainerRevValDup,DML_name,VCnumberDup,ParaAppdup_Val,ParaReaddup_Val,cntEE,ParaDIDVal,containerrevdup);
											//fprintf(fptr2,"%s\n",printValueS);fflush(fptr2);																													
										}
									}
								}
							}
						}
					}
			    }

			//}	
		 }
		}
	}
	} //18SEPT

	if(fptr2) fclose(fptr2);
}
						   			
/*static void TPL_BOM_List(tag_t top_line,tag_t snapshotFolder_tag)
{

	tag_t window,windowW, Rrule, item_tag = null_tag,top_lineW;
	tag_t *children;
	tag_t *childrenY;
	tag_t *childrenW;
	tag_t *tags_found3  = NULL;
	tag_t itemTag		= NULLTAG;
	int revCount		=0;
	tag_t* revList		= NULLTAG;
	int revListCounter	= 0;
	tag_t *tags_found5  = NULL;
	tag_t Childrev      = NULLTAG;
	tag_t ChildW        = NULLTAG;
	

	int countX			= 0;
	int countW			= 0;
	int i				= 0;
	int kk				= 0;
	int iw				= 0;
	int n_tags_found3   = 0;
	int n_tags_found5   = 0;
	int statusX;
	int statusW;
	char* container		= NULL;
	char* PartType		= NULL;
	char* containerrev	= NULL;
	char* containerIDAddedFromSnapShot =NULL;
	char* containerIDAddedFromSnapShot_rev_ID=NULL;
	char* contain		= NULL;
	char* Cnt_EcuType	= NULL;
	char* ChildPart		= NULL;
	char* ChildPartType = NULL;
	char* ChildPartrev  = NULL;
	char* sModNum  = NULL;

	FILE *fptr;

	int ifail;
	int status;
	int sn =0;

	int depth  =0;
	int iWriteX  =0;

	int snapcount =0;
	tag_t *snapchild =NULLTAG;
	tag_t SnChild = NULLTAG;
	char* PartItemIdSn =NULL;
	char* PartItemRevIdSn =NULL;
	char* PartObjectType =NULL;
	char* PartSWType =NULL;
	int chCount =0;
	char* containerSnpacmp = NULL;
	char* objectStringTopLine = NULL;
	logical MatchFound = false;
	logical isShanpshotAddedPart = false;
	//int status =0;
	tag_t tempPartTag= NULLTAG;

	tag_t rule =NULLTAG;

	char* itemRevID = NULL;


	HWCList = (char**)MEM_alloc( 1 * sizeof *HWCList );
	CALList = (char**)MEM_alloc( 1 * sizeof *CALList );
	PBLList = (char**)MEM_alloc( 1 * sizeof *PBLList );
	SBLList = (char**)MEM_alloc( 1 * sizeof *SBLList );
	BASList = (char**)MEM_alloc( 1 * sizeof *BASList );
	APPList = (char**)MEM_alloc( 1 * sizeof *APPList );
	STKList = (char**)MEM_alloc( 1 * sizeof *STKList );
	VCIList = (char**)MEM_alloc( 1 * sizeof *VCIList );
	CFGList = (char**)MEM_alloc( 1 * sizeof *CFGList );
	PRMList = (char**)MEM_alloc( 1 * sizeof *PRMList );
	CONList = (char**)MEM_alloc( 1 * sizeof *CONList );

	printf("\n inside TPL BOM list \n");fflush(stdout);

	
	if(AOM_ask_value_string(top_line,"object_string",&objectStringTopLine)!=ITK_ok);
	printf("\n  objectStringTopLine -------> %s \n", objectStringTopLine);fflush(stdout);
	
	//if(AOM_ask_value_string(top_line,"item_id",&sTpItemNum)!=ITK_ok);
	sModNum=subString(req_item,0,8); 
	printf("\nkk.substr VCID num : [%s]", sModNum);fflush(stdout);

	countX=0;
	statusX = BOM_line_ask_child_lines (top_line, &countX, &children);

	printf ("\n INSIDE TPL_BOM_List countX is --->%d \n",countX); fflush(stdout);

	if(countX>0)
	{
		//28-03-2023
		if(AOM_ask_value_tags(snapshotFolder_tag,"contents",&snapcount,&snapchild));//added
		printf("\n  snapcount  contents -------> [%d] \n",snapcount);fflush(stdout);

		for (sn=0;sn<snapcount;sn++)															
		{
			MatchFound =false;
			SnChild=snapchild[sn];

			if(AOM_ask_value_string(SnChild,"item_id",&PartItemIdSn)!=ITK_ok);
			printf("\n Item id of part attched in snapshot : [%s]", PartItemIdSn);fflush(stdout);

			if(AOM_ask_value_string(SnChild,"item_revision_id",&PartItemRevIdSn)!=ITK_ok);
			printf("\n  Revision of part -------> %s \n", PartItemRevIdSn);fflush(stdout);

			if(AOM_ask_value_string(SnChild,"object_type",&PartObjectType)!=ITK_ok);
			printf("\n  PartObjectType -------> %s \n", PartObjectType);fflush(stdout);

			if(tc_strcmp(PartObjectType,"T5_EE_PartRevision")==0)
			{
				if(AOM_ask_value_string(SnChild,"t5_SwPartType",&PartSWType)!=ITK_ok);
				printf("\n  PartSWType -------> %s \n", PartSWType);fflush(stdout);
				//if(tc_strcmp(PartSWType,"Container")==0 || tc_strcmp(PartSWType,"Parameter")==0)
				if(tc_strcmp(PartSWType,"CON")==0 || tc_strcmp(PartSWType,"PRM")==0)
				{
					for(chCount =0;chCount < countX ; chCount++)
					{
						if( AOM_ask_value_string(children[chCount],"bl_item_item_id",&containerSnpacmp)!=ITK_ok);
						printf("\n  containerSnpacmp--->[%s] \n",containerSnpacmp);fflush(stdout);
						
						if(tc_strcmp(PartItemIdSn,containerSnpacmp)==0)
						{
							MatchFound = true;
							printf("MatchFound..... is true:::");
							break;
						}
					}
					if(MatchFound == false)
					{
						//need to add tag to child tags
						printf("MatchFound ::::: false  :::");

						printf("\n Extra Container is added from snapshot folder is ::s: [%s]", PartItemIdSn);fflush(stdout);
						tempPartTag = SnChild;
						children[countX]=SnChild;
						countX++;
					}
				}
			}
			//for 16R TPL
			else
			{
				if(tc_strcmp(PartObjectType,"Design Revision")==0 && tc_strstr(PartItemIdSn,sModNum)==NULL)
				{
					for(chCount =0;chCount < countX ; chCount++)
					{

						if( AOM_ask_value_string(children[chCount],"bl_item_item_id",&containerSnpacmp)!=ITK_ok);
						printf("\n  containerSnpacmp--->[%s] \n",containerSnpacmp);fflush(stdout);
						
						if(tc_strcmp(PartItemIdSn,containerSnpacmp)==0)
						{
							MatchFound = true;
							printf("MatchFound..... is true:::");
							break;
						}
					}
					
					if(MatchFound == false)
					{
						//need to add tag to child tags
						printf("MatchFound ::::: false  :::");
						printf("\n 16R i.e. Design Revision found....");
						printf("\n Extra Container is added from snapshot folder is ::s: [%s]", PartItemIdSn);fflush(stdout);
						tempPartTag = SnChild;
						children[countX]=SnChild;
						countX++;
					}
				}
			}
		}

		printf ("\n After modification Child Tag :: ->%d \n",countX); fflush(stdout);
		  //printf("\n..16R has a structure.. \n");fflush(stdout);
		for (i=0;i<countX;i++)
		{
			n_tags_found3 =0;
			tags_found3		=   NULLTAG;
			itemTag			=	NULLTAG;
			container		=	NULL;
			containerrev	=   NULL;
			revCount		=   0;
			revList			= NULLTAG;

			if( AOM_ask_value_string(children[i],"bl_item_item_id",&container)!=ITK_ok);
			//printf("\n  TPL_BOM_List container is --->[%s] \n",container);fflush(stdout);

			if( AOM_ask_value_string(children[i],"bl_rev_item_revision_id",&containerrev)!=ITK_ok);
			printf("\t TPL_BOM_List container is --->[%s] & containerrev is ----> [%s]\n",container,containerrev); fflush(stdout);
			
			
			if (revCount>0)
			{
				  // Childrev= tags_found3[0];
				   //printf("\n INSIDE TPL_BOM_List  Childrev \n");fflush(stdout);
					if( AOM_ask_value_string(Childrev,"item_id",&contain)!=ITK_ok);
					printf("\n  TPL_BOM_List contain  --->[%s] \n",contain);fflush(stdout);

					if( AOM_ask_value_string(Childrev,"t5_SwPartType",&PartType)!=ITK_ok);
					printf("\n PartType  TPL_BOM_List ... %s \n",PartType);fflush(stdout);

					iWriteX  =0;
					//if(container)
					//{
					   if (tc_strcmp(PartType, "CON") == 0)
						{
						   printf("\n TPL_BOM_List Container found with part type CON... %s \n",container);fflush(stdout);

							if( AOM_ask_value_string(Childrev,"t5_EcuType",&Cnt_EcuType)!=ITK_ok);
							
							if((Cnt_EcuType))
							{
								printf("\t TPL_BOM_List Cnt_EcuType [%s]\n",Cnt_EcuType); fflush(stdout);
							}
							else
							{
								Cnt_EcuType=(char *) MEM_alloc(10);
								tc_strcpy(Cnt_EcuType,"NA"); 
								printf("\t TPL_BOM_List Cnt_EcuType  %s \n",Cnt_EcuType); fflush(stdout);
							}

							//tc_strcpy(CONList,container); 

							setAddStr(&iWriteX,&CONList,container);
							
							if(isShanpshotAddedPart)
							{
								printf("\n\t **** I am here go get childs of part which is taken from snapshot\t\n");
								ifail = BOM_create_window (&windowW);
								CHECK_FAIL;
								//ifail = CFM_find( "Latest Released", &rule );
								ifail = CFM_find( "ERC release and above", &rule );
								printf ("\n after rev rule \n"); fflush(stdout);
								ifail = BOM_set_window_config_rule( windowW, rule );
								CHECK_FAIL;
								ifail = BOM_set_window_top_line (windowW, null_tag, Childrev, null_tag, &top_lineW); 
								CHECK_FAIL;
								ifail = BOM_window_show_suppressed ( windowW );
								CHECK_FAIL;
								ifail =(BOM_set_window_pack_all(windowW, FALSE));
								CHECK_FAIL;

								countW=0;
								statusW = BOM_line_ask_child_lines (top_lineW, &countW, &childrenW);
								printf ("\n   TPL_BOM_List countW is --->%d \n",countW); fflush(stdout);
							}
							else
							{
								countW=0;
								statusW = BOM_line_ask_child_lines (children[i], &countW, &childrenW);
								printf ("\n   TPL_BOM_List countW is --->%d \n",countW); fflush(stdout);
							}
							//ifail = BOM_create_window (&windowW);
							//CHECK_FAIL;
							////ifail = CFM_find( "Latest Released", &rule );
							//ifail = CFM_find( "ERC release and above", &rule );

							//printf ("\n after rev rule \n"); fflush(stdout);

							//ifail = BOM_set_window_config_rule( windowW, rule );
							//CHECK_FAIL;

							//ifail = BOM_set_window_top_line (windowW, null_tag, Childrev, null_tag, &top_lineW); 
							//CHECK_FAIL;

							//ifail = BOM_window_show_suppressed ( windowW );
							//CHECK_FAIL;

							//ifail =(BOM_set_window_pack_all(windowW, FALSE));
							///CHECK_FAIL;

							

							if(countW >0)
							{
							   printf("\n.TPL_BOM_List .INSIDE . childrenW. \n");fflush(stdout);

							   for (iw=0;iw<countW;iw++)
								 {
									if( AOM_ask_value_string(childrenW[iw],"bl_item_item_id",&ChildPart)!=ITK_ok);
									//printf("\n TPL_BOM_List ChildPart is  XXXXX--->[%s] \n",ChildPart);fflush(stdout);

									if( AOM_ask_value_string(childrenW[iw],"bl_rev_item_revision_id",&ChildPartrev)!=ITK_ok);
									printf("\t TPL_BOM_List ChildPart is ---->[%s] & ChildPartrev is -----> [%s]\n",ChildPart,ChildPartrev); fflush(stdout);

									const char **attrs5  = (const char **) MEM_alloc(2 * sizeof(char *));
									const char **values5 = (const char **) MEM_alloc(2 * sizeof(char *));
									attrs5[0]	   ="item_id";
									attrs5[1]      ="object_type";
									values5[0]     = (char *)ChildPart;
									values5[1]     = "Design";
									//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
									ifail =(ITEM_find_item_revs_by_key_attributes(2,attrs5, values5,ChildPartrev, &n_tags_found5, &tags_found5));
									CHECK_FAIL;
									MEM_free(attrs5);
									MEM_free(values5);

									if (n_tags_found5>0)
									{
									   ChildW= tags_found5[0];
									}

									if( AOM_ask_value_string(ChildW,"t5_SwPartType",&ChildPartType)!=ITK_ok);
									printf("\t TPL_BOM_List ChildPartType [%s]\n",ChildPartType); fflush(stdout);

									if (tc_strcmp(ChildPartType, "HWC") == 0)
									{
										setAddStr(&iWriteX,&HWCList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "CAL") == 0 || tc_strcmp(ChildPartType, "HCL") == 0)
									{
										setAddStr(&iWriteX,&CALList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "PBL") == 0)
									{
										setAddStr(&iWriteX,&PBLList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "SBL") == 0)
									{
										setAddStr(&iWriteX,&SBLList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "BAS") == 0)
									{
										setAddStr(&iWriteX,&BASList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "APP") == 0)
									{
										setAddStr(&iWriteX,&APPList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "STK") == 0)
									{
										setAddStr(&iWriteX,&STKList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "VCI") == 0 || tc_strcmp(ChildPartType, "HCL") == 0)
									{
										setAddStr(&iWriteX,&VCIList,ChildPart);
									}
									else if (tc_strcmp(ChildPartType, "CFG") == 0)
									{
										setAddStr(&iWriteX,&CFGList,ChildPart);
									}
								}
							}						
						}
						else if (tc_strcmp(PartType, "STK") == 0)
						{
							printf("\n TPL_BOM_List STK found number is ---->: %s",container);
							//low_set_add_str(STKList,container); 
							setAddStr(&iWriteX,&STKList,container);
						}
						else if (tc_strcmp(PartType, "PRM") == 0)
						{
							char *sParmPart = NULL;
							sParmPart=(char *) MEM_alloc(50);
							tc_strcpy(sParmPart,container);
							tc_strcat(sParmPart,",");
							tc_strcat(sParmPart,containerrev);
							printf("\n TPL_BOM_List parameter found number is ---->: %s",sParmPart);
							setAddStr(&iWriteP,&PRMList,sParmPart);
							printf("\n after PRMList\n");
						}
					//}
			} //  
			else
			{
				printf("\t TPL_BOM_List container is --->[%s] & containerrev is ----> [%s],I am in TPL_BOM_List\n",container,containerrev);
			}
		} 
	}			
}*/

static void TPL_BOM_List(tag_t tSnapShot)
{
	int nSnapCnt = 0;
	int iSnCnt = 0;
	char *sSWPrtTyp = NULL;
	char *container = NULL;
	char *containerrev = NULL;
	tag_t tSnapContent = NULLTAG;
	tag_t* tpSnapContent = NULLTAG;
	printf("\nInside TPL BOM list Fn\n");fflush(stdout);

	PRMList = (char**)MEM_alloc( 1 * sizeof *PRMList );
	CONList = (char**)MEM_alloc( 1 * sizeof *CONList );

	if(AOM_ask_value_tags(tSnapShot,"contents",&nSnapCnt,&tpSnapContent));
	printf("\nkk.snap count [%d] \n",nSnapCnt);fflush(stdout);
	for(iSnCnt=0; iSnCnt<nSnapCnt; ++iSnCnt)
	{
		tSnapContent = tpSnapContent[iSnCnt];
		if(AOM_ask_value_string(tSnapContent,"t5_SwPartType",&sSWPrtTyp)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_id",&container)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_revision_id",&containerrev)!=ITK_ok);
		printf("\nkk.Part [%s,%s],S/W Part Type [%s]",container,containerrev,sSWPrtTyp);fflush(stdout);

		if(tc_strcmp(sSWPrtTyp,"PRM") == 0)
		{
			char *sParmPart = NULL;
			sParmPart=(char *) MEM_alloc(50);
			tc_strcpy(sParmPart,container);
			tc_strcat(sParmPart,",");
			tc_strcat(sParmPart,containerrev);
			printf("\nkk.Adding Parameter [%s]",sParmPart);
			setAddStr(&iWriteP,&PRMList,sParmPart);
			printf("\n after PRMList\n");
		}
	}
}

//========================= END OF TPL_BOM_List =============================================== 

static void Container_List(tag_t tSnapShot)
{
	int ifail;
	int nSnapCnt = 0;
	int iSnCnt = 0;
	int cntt = 0;
	int pq = 0;
	int iCnt = 0;
	int ind = 0;
	int SlvcntS = 0;
	int FATC_flag	= 0;
	int FATC_S_flag	= 0;
	char *sSWPrtTyp = NULL;
	char *container = NULL;
	char *containerrev = NULL;
	char *sEcuType = NULL;
	char *tmpcon	= "TEMP";
	char *parapart	= NULL;
	char *parrevseq	= NULL;
	char *sParPart	= NULL;
	char *Cnt_EcuTypeDup	= NULL;
	tag_t tSnapContent = NULLTAG;
	tag_t  ConPararelation_type  = NULLTAG;
	tag_t  ConHasParaPtr		 = NULLTAG;
	tag_t MstrSlvrelation_typeS  = NULLTAG;
	tag_t* tpSnapContent = NULLTAG;
	tag_t *Paraattachments	= NULLTAG;
	tag_t *SlvattachmentsS	= NULLTAG;
	printf("\nInside Container_List Fn\n");fflush(stdout);

	PRMList = (char**)MEM_alloc( 1 * sizeof *PRMList );
	CONList = (char**)MEM_alloc( 1 * sizeof *CONList );
	
	TPL_BOM_List(tSnapShot);

	if(AOM_ask_value_tags(tSnapShot,"contents",&nSnapCnt,&tpSnapContent));
	printf("\nkk.snap count [%d] \n",nSnapCnt);fflush(stdout);
	for(iSnCnt=0; iSnCnt<nSnapCnt; ++iSnCnt)
	{
		tSnapContent = tpSnapContent[iSnCnt];
		if(AOM_ask_value_string(tSnapContent,"t5_SwPartType",&sSWPrtTyp)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_id",&container)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_revision_id",&containerrev)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"t5_EcuType",&sEcuType)!=ITK_ok);
		printf("\nkk.Part [%s,%s],S/W Part Type [%s],ECU Type [%s]",container,containerrev,sSWPrtTyp,sEcuType);fflush(stdout);

		if(tc_strcmp(sSWPrtTyp,"CON") == 0)
		{
			ifail = GRM_find_relation_type("T5_ContHasPara",&ConPararelation_type);  
			if(ConPararelation_type != NULLTAG)
			{
				printf("\nkk.Relation found.");	fflush(stdout);
				ITKCALL(GRM_list_secondary_objects_only(tSnapContent,ConPararelation_type,&cntt,&Paraattachments));
				printf("\nkk.cntt value is  --------------------- %d\n",cntt);fflush(stdout);
				if (cntt > 0)
				{				 	
					for(pq=0;pq<cntt;pq++)
					{
						ConHasParaPtr = Paraattachments[pq];
						if( AOM_ask_value_string(ConHasParaPtr,"item_id",&parapart)!=ITK_ok);
						if( AOM_ask_value_string(ConHasParaPtr,"item_revision_id",&parrevseq)!=ITK_ok);
						printf("\t parapart   is -----------[%s,%s]\n",parapart,parrevseq); fflush(stdout);

						char *sParPart = NULL;
						sParPart=(char *) MEM_alloc(50);
						tc_strcpy(sParPart,parapart);
						tc_strcat(sParPart,",");
						tc_strcat(sParPart,parrevseq);
						printf("\nkk.Searching Par part [%s]...",sParPart);

						ind=setFindStr1(&iWriteP,&PRMList,sParPart);
						if(ind>=0)
						{	
							printf("\nkk.Added Par in ParaList.");fflush(stdout);
							setAddStr(&iWriteRCon,&ConatainerList,container);
							setAddStr(&iWriteRConType,&ConatainerTypeListX,"TEMP");
							setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
							setAddStr(&iWriteRPar,&ParaList,parapart);
							//bIsConParFound = TRUE;
						}
					}
				}
			}
					  		
			if(sEcuType)
			{	
				printf("\n sEcuType not null \n"); fflush(stdout);
				Cnt_EcuTypeDup	=	NULL;
				Cnt_EcuTypeDup=(char *) MEM_alloc(10);

				if (tc_strstr(sEcuType,"Fully Automated Temperature Control")!=NULL)
				{
					tc_strcpy(Cnt_EcuTypeDup,"FATC");
					FATC_flag = 0;  
					ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvrelation_typeS); 
					{
						if(MstrSlvrelation_typeS != NULLTAG)
						{
							printf("\n Expansion_TPL_16 MstrSlvrelation_typeSSSSSSSSSSSSSSSS relation found......\n");	fflush(stdout);	
							
							ITKCALL(GRM_list_secondary_objects_only(tSnapContent,MstrSlvrelation_typeS,&SlvcntS,&SlvattachmentsS));
							CHECK_FAIL;

							if (SlvcntS > 0)
							{	
								printf("\nAdded in SlvcntS");fflush(stdout);
								setAddStr(&iWriteRCon,&ConatainerList,container);
								setAddStr(&iWriteRConType,&ConatainerTypeListX,Cnt_EcuTypeDup);
								setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
								setAddStr(&iWriteRPar,&ParaList,tmpcon);
								FATC_flag = 1;
								continue;

							}
							else
							{
								FATC_S_flag = 1;
							}
						}
					}
				}
				else 
				{
					tc_strcpy(Cnt_EcuTypeDup,"NA");
				}
				for(iCnt=0; iCnt<iECU1; ++iCnt)
				{
					if(tc_strcmp((ECUTypFull)[iCnt],sEcuType)==0)
					{
						tc_strcpy(Cnt_EcuTypeDup,(ECUTypAbr)[iCnt]);
					}
				}
														
				printf("\nkk.Cnt_EcuTypeDup value is [%s]\n",Cnt_EcuTypeDup);fflush(stdout);
				setAddStr(&iWriteRCon,&ConatainerList,container);
				setAddStr(&iWriteRConType,&ConatainerTypeListX,Cnt_EcuTypeDup);
				setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
				setAddStr(&iWriteRPar,&ParaList,tmpcon); 

			}
			else
			{
				tc_strcpy(Cnt_EcuTypeDup,"NA");
				printf("\n test Cnt_EcuTypeDup value is  :-------------- %s \n",Cnt_EcuTypeDup);fflush(stdout);
			}										
		}
	}
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	//ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	//ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}
static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

	//ifail = BOM_line_look_up_attribute (name, attribute);	
	CHECK_FAIL;
	/*ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

