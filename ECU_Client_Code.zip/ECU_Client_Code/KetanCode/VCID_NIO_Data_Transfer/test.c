#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include<cJSON.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

char* Con_Part_List=NULL;

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

int iVarntsCnt = 0;
logical lAreValsAdded = false;
int iECU1 = 0;
int iECU2 = 0;
char **ECUTypFull = NULL;
char **ECUTypAbr = NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\nkk.setAddStr [%s]",(*strset)[*count-1]);fflush(stdout);

}

struct Variants
{
	char *vcNumber;
	char *variantName;
	char *vcFuelType;
	char *vcTransmissionType;
	char *vcEmissionNorm;
	logical isConnectedCar;
	logical hasPeps;
	char *variantReleaseYear;
	char *variantReleaseMonth;
	char *vcIdNumber;
	char *vcIdReleaseDate;
}*get_Variants;

struct Models
{
	char *vehicleModelName;
	char *platformName;
	char *modelType;
	char *modelReleaseYear;
	struct Variants *stVarnts;
}*get_Models;

struct VehicleTenant
{
	char *tenantType;
	struct Models *stModl;
}*get_VehicleTenant;

struct BomChldStrut_EE
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
	char *GrpID;
}*get_BomChldStrut_EE;

void Multi_Get_Part_BOM_Lvl(tag_t top_line,int reqLevel,int level,tag_t SnapshotRevTag ,struct BomChldStrut_EE BomChldStrut[],int* StructChldCnt,char *GrpNum)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n_Cnt=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;

	char*			partColInd					=NULL;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	char* PrtCmpCode 	= NULL;

	int iCON =0;											 //18 SEPT
	int y =0;												 //18 SEPT
	char	**CONDetails		  =	NULL;					 //18 SEPT
	CONDetails = (char**)MEM_alloc( 1 * sizeof *CONDetails );//18 SEPT
	char * PartType = NULL;									 //18 SEPT
	char * child_item_id = NULL;							 //18 SEPT
	char * sPrtTyp = NULL;
	tag_t objTypeTag = NULLTAG;
	char * partNumberRev =NULL;
	char * SnapNumber =NULL;


	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}
	
	if (level==0)
	{

		tag_t Modl_rev_tags = NULLTAG;
		ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&Modl_rev_tags));
		BomChldStrut[*StructChldCnt].child_objs = top_line;
		BomChldStrut[*StructChldCnt].child_objs_bvr=Modl_rev_tags;
		BomChldStrut[*StructChldCnt].child_objs_lvl=level;
		BomChldStrut[*StructChldCnt].GrpID=GrpNum;

		ITKCALL(BOM_create_window (&window));
		BOM_create_window_from_snapshot(SnapshotRevTag,&window);
		ITKCALL(BOM_set_window_pack_all (window, true));

		BOM_set_window_top_line(window, null_tag,Modl_rev_tags ,null_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 3.42 Backend

	}

	ITKCALL(AOM_ask_value_string(SnapshotRevTag,"object_name",&SnapNumber));
	printf("\n Snapshot Name===>%s\n",SnapNumber);fflush(stdout);

	ITKCALL(AOM_ask_value_string(top_line,"bl_rev_item_revision_id",&partNumberRev));
	printf("\n partNumberRevr===>%s\n",partNumberRev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));
    printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
	printf("\nkk.No of child objects are n : %d\n",n_Cnt);fflush(stdout);

	level = level + 1;
	for (k = 0; k < n_Cnt; k++)
	{
		int MatchFlag=0;
	
		BOM_line_unpack (children[k]);
		AOM_ask_value_tag(children[k], bomAttr_lineItemRevTag, &t_ChildItemRev);
		if(t_ChildItemRev!=NULLTAG)
		{
			ITKCALL( AOM_ask_value_string(t_ChildItemRev,"t5_SwPartType",&PartType));
			printf("\n t_ChildItemRev tag found ===>%s\n",PartType);fflush(stdout);

			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "item_id", &child_item_id ));
			printf("\n t_ChildItemRev tag found  child_item_id===>%s\n",child_item_id);fflush(stdout);

			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &sPrtTyp));
			printf("\nkk.Part Type is [%s]\n",sPrtTyp);fflush(stdout);
		   
			if(tc_strcmp(PartType,"CON")==0)
			{
				char* containerMatch=NULL;
				for (y=0;y<*StructChldCnt+1;y++)
				{
					printf("\n..IN Expansion_TPL_16 structure.. :%d\n",y);fflush(stdout);
					containerMatch=NULL;
					
					if( AOM_ask_value_string(BomChldStrut[y].child_objs,"item_id",&containerMatch)!=ITK_ok);
					if (tc_strcmp(containerMatch,child_item_id)==0)
					{
						printf("\n..CONTAINER MATCH FOUND  :\n");fflush(stdout);
						MatchFlag=1;
						break;
					}
				}															
			}
			if (MatchFlag==0)
			{
				printf("\n..match not found.hence proceeding \n");fflush(stdout);
				*StructChldCnt	=	*StructChldCnt+1;
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
				BomChldStrut[*StructChldCnt].GrpID=GrpNum;

				if(tc_strcmp(sPrtTyp,"G")==0)
				{
					Multi_Get_Part_BOM_Lvl(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,child_item_id);
				}
				else
				{
					Multi_Get_Part_BOM_Lvl(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,GrpNum);
				}
			}
		}
	}
	level = level - 1;
	
	MEM_free (childrenTag);

	CLEANUP:
		printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}

int Model_Var_Input_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, char *sVCIDRelDate, struct VehicleTenant *stVehTent, int nVcCnt, tag_t *tpVCItmList)
{
	int status;
	int ifail;
	int ic = 0;
	int xc = 0;
	//int nVCCnt;
	int iVCCnt;
	logical lHasTel = false;
	logical lHasPeps = false;
	int theAttributeCount =0;
	int *theAttributeIds;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char*** theAttributeValues = NULL;
	char*** theAttributeOptimizedUnits = NULL;
	char *sVCNum = NULL;
	char *sProdLine = NULL;
	char *sMajorModel = NULL;
	char *sPlatform = NULL;
	char *sVehType = NULL;
	char *sModelRelYr = NULL;
	char *sVariant = NULL;
	char *sFuel = NULL;
	char *sTrnsmsn = NULL;
	char *sEmmisnNrms = NULL;
	char *sVarRelYr = NULL;
	char *sVarRelMnth = NULL;
	char *sVCIDNum = NULL;
	tag_t tVehMCls = NULLTAG;
	tag_t tVehM = NULLTAG;
	
	sProdLine =(char *) MEM_alloc(10);
	sMajorModel =(char *) MEM_alloc(20);
	sPlatform =(char *) MEM_alloc(20);
	sVehType =(char *) MEM_alloc(20);
	sModelRelYr =(char *) MEM_alloc(20);
	sVariant =(char *) MEM_alloc(50);
	sFuel =(char *) MEM_alloc(20);
	sTrnsmsn =(char *) MEM_alloc(20);
	sEmmisnNrms =(char *) MEM_alloc(50);
	sVarRelYr =(char *) MEM_alloc(10);
	sVarRelMnth =(char *) MEM_alloc(10);
	sVCIDNum =(char *) MEM_alloc(25);
	
	cJSON *rfc_root;
	cJSON *Tenant_detail_req;
	cJSON *single_model_req;
	cJSON *models_req;
	cJSON *single_variant_req;
	cJSON *variants_req;
	char *MVI_out;
	
	rfc_root = cJSON_CreateObject();
	Tenant_detail_req = cJSON_CreateObject();

	single_model_req = cJSON_CreateObject();
	models_req = cJSON_CreateArray();

	single_variant_req = cJSON_CreateObject();
	variants_req = cJSON_CreateArray();
	
	if(nVcCnt>0)
	{
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];

			tc_strcpy(sProdLine,"NA");
			tc_strcpy(sMajorModel,"NA");
			tc_strcpy(sPlatform,"NA");
			tc_strcpy(sVehType,"NA");
			tc_strcpy(sModelRelYr,"2024");
			tc_strcpy(sVariant,"NA");
			tc_strcpy(sFuel,"NA");
			tc_strcpy(sTrnsmsn,"NA");
			tc_strcpy(sEmmisnNrms,"NA");
			tc_strcpy(sVarRelYr,"2024");//TODO: take this val from PLM
			tc_strcpy(sVarRelMnth,"02");
			
			ICS_ask_classification_object(tVehM,&tVehMCls);
			ITK_CALL(ICS_ico_ask_attributes_optimized(tVehMCls,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
			if(theAttributeCount>0)
			{
				for(ic=0; ic<theAttributeCount; ++ic)
				{
					//TODO:Write these values in a structure & create a json file
					if(tc_strcmp(theAttributeNames[ic],"PRODUCT LINE")==0)
					{
						tc_strcpy(sProdLine,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sProdLine,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						//printf("\n attrId:[%s]",attrId);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sProdLine);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"[VC]MAJORMODEL")==0)
					{
						tc_strcpy(sMajorModel,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sMajorModel,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sMajorModel);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"PLATFORM")==0)
					{
						tc_strcpy(sPlatform,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sPlatform,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sPlatform);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"VEHICLE TYPE")==0)
					{
						tc_strcpy(sVehType,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sVehType,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sVehType);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"VARIANT")==0)
					{
						tc_strcpy(sVariant,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sVariant,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sVariant);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"FUEL(FUEL)")==0)
					{
						tc_strcpy(sFuel,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sFuel,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sFuel);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"TRANSMISSION")==0)
					{
						tc_strcpy(sTrnsmsn,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sTrnsmsn,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sTrnsmsn);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"EMMISION_NORMS(EMMISION_NORMS)")==0)
					{
						tc_strcpy(sEmmisnNrms,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sEmmisnNrms,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sEmmisnNrms);fflush(stdout);
					}
				}
			}
			
			if(lAreValsAdded == false)
			{
				stVehTent->tenantType = sProdLine;
				stVehTent->stModl = (struct Models *)MEM_alloc(sizeof(struct Models));
				stVehTent->stModl[0].vehicleModelName = sMajorModel;
				stVehTent->stModl[0].platformName = sPlatform;
				stVehTent->stModl[0].modelType = sVehType;
				stVehTent->stModl[0].modelReleaseYear = sModelRelYr; //TODO: take this val from PLM
								
				cJSON_AddItemToObject(rfc_root, "vehicleTenant", Tenant_detail_req);
				cJSON_AddItemToObject(Tenant_detail_req, "tenantType", cJSON_CreateString(sProdLine));

				cJSON_AddItemToObject(Tenant_detail_req, "models", models_req);
				cJSON_AddItemToArray(models_req, single_model_req = cJSON_CreateObject());

				cJSON_AddItemToObject(single_model_req, "vehicleModelName", cJSON_CreateString(sMajorModel));
				cJSON_AddItemToObject(single_model_req, "platformName", cJSON_CreateString(sPlatform));
				cJSON_AddItemToObject(single_model_req, "modelType", cJSON_CreateString(sVehType));
				cJSON_AddItemToObject(single_model_req, "modelReleaseYear", cJSON_CreateString(sModelRelYr));
				//cJSON_AddNumberToObject(single_model_req, "modelReleaseYear", 2022);
				lAreValsAdded = true;
			}
			
			if(iVarntsCnt == 0)
			{
				stVehTent->stModl[0].stVarnts = (struct Variants *)MEM_alloc(sizeof(struct Variants));
			}
			else
			{
				//stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set = (struct DataSet *)MEM_realloc(stTcUA_Sw_Data[stTcUA_Sw_Cnt].Set, (stTcUA_Sw_Data[stTcUA_Sw_Cnt].DtSetSize+1) * sizeof(struct DataSet));
				stVehTent->stModl[0].stVarnts = (struct Variants *)MEM_realloc(stVehTent->stModl[0].stVarnts, (iVarntsCnt+1) * sizeof(struct Variants));
				iVarntsCnt++;
			}
			
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcNumber = sVCNum;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].variantName = sVariant;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcFuelType = sFuel;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcTransmissionType = sTrnsmsn;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcEmissionNorm = sEmmisnNrms;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].isConnectedCar = lHasTel;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].hasPeps = lHasPeps;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].variantReleaseYear = sVarRelYr;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].variantReleaseMonth = sVarRelMnth;
			tc_strcpy(sVCIDNum,sInpVCID);
			tc_strcat(sVCIDNum,"-");
			tc_strcat(sVCIDNum,sInpVCIDRv);
			tc_strcat(sVCIDNum,sInpVCIDSq);
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcIdNumber = sVCIDNum;
			stVehTent->stModl[0].stVarnts[iVarntsCnt].vcIdReleaseDate = sVCIDRelDate;
			
			cJSON_AddItemToObject(single_model_req, "variants", variants_req);
			cJSON_AddItemToArray(variants_req, single_variant_req = cJSON_CreateObject());

			cJSON_AddItemToObject(single_variant_req, "vcNumber", cJSON_CreateString(sVCNum));
			cJSON_AddItemToObject(single_variant_req, "variantName", cJSON_CreateString(sVariant));
			cJSON_AddItemToObject(single_variant_req, "vcFuelType", cJSON_CreateString(sFuel));
			cJSON_AddItemToObject(single_variant_req, "vcTransmissionType", cJSON_CreateString(sTrnsmsn));
			cJSON_AddItemToObject(single_variant_req, "vcEmissionNorm", cJSON_CreateString(sEmmisnNrms));
			if(lHasTel == true)
			{
				cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateString("true"));
			}
			else
			{
				cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateString("false"));
			}
			if(lHasPeps == true)
			{
				cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateString("true"));
			}
			else
			{
				cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateString("false"));
			}
			cJSON_AddItemToObject(single_variant_req, "variantReleaseYear", cJSON_CreateString(sVarRelYr));
			cJSON_AddItemToObject(single_variant_req, "variantReleaseMonth", cJSON_CreateString(sVarRelMnth));
			//cJSON_AddNumberToObject(single_variant_req, "variantReleaseYear", 2022);
			//cJSON_AddNumberToObject(single_variant_req, "variantReleaseMonth", 9);
			cJSON_AddItemToObject(single_variant_req, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			cJSON_AddItemToObject(single_variant_req, "vcIdReleaseDate", cJSON_CreateString(sVCIDRelDate));
		}
	}
	
	MVI_out = cJSON_Print(rfc_root);
    printf("%s\n", MVI_out);
	
	FILE *fpMod = fopen("model-variant-input.json","w");
	if (fpMod != NULL)
	{
		fprintf(fpMod, "%s", MVI_out);
	}
	fclose(fpMod);
	free(MVI_out);
    cJSON_Delete(rfc_root);
	
	CLEANUP:
		printf("\nInside Model_Var_Input_St CLEANUP");fflush(stdout);
	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}

extern int ITK_user_main (int argc, char ** argv )
{
	int status;
	int ifail;
	int iECnt;
	int level = 0;
	int nSnapCnt = 0;
	int nCntDML = 0;
	int iCntDML = 0;
	char *sVCID = NULL;
	char *sRevSeq = NULL;
	char *sRevSeqDup = NULL;
	char *sRevnSeq = NULL;
	char *sVCIDRev = NULL;
	char *sVCIDSeq = NULL;
	char *info1ECUType = NULL;
	char *info2ECUType = NULL;
	char *sDmlType = NULL;
	char *sDML_name = NULL;
	char *sVCIDRelDt = NULL;
	
	int n_Input = 3;
	int nVCIDCnt;
	char *values[3];
	char *qry_Input[3] = {"Item ID", "Type", "Revision"};
	tag_t *tpVCIDObjs = NULL;
	tag_t ProQryVCID = NULLTAG;
	
	int nECUTypeEnt = 2;
	int nECUTypCnt;
	char *qryInputECUType[2] = {"SYSCD", "SUBSYSCD"};
	char *qryProjValECUType[2] = {"ECU", "Mapping"};
	tag_t ECUTypeQuery = NULLTAG;
	tag_t *tpECUTypeCnObj = NULLTAG;
	
	tag_t tVCIDObj = NULLTAG;
	tag_t ReferencesCCVTag = NULLTAG;
	tag_t *tpVCItmObj = NULLTAG;
	tag_t tSnap = NULLTAG;
	tag_t tTopLine = NULLTAG;
	tag_t HasSnapshot_type = NULLTAG;
	tag_t *tpSnapObj = NULLTAG;
	tag_t tNewVCIDRel = NULLTAG;
	tag_t *tpDMLRev = NULLTAG;
	tag_t tDMLTypeTg = NULLTAG;
	int nVCCnt = 0;
	
	int StructChldCnt = 0;
	struct BomChldStrut_EE	ChldStrutBdySh[5000];
	
	struct VehicleTenant VehTent[1];
	
	sRevSeqDup=(char *) MEM_alloc(10);
	sRevnSeq=(char *) MEM_alloc(10);
	ECUTypFull = (char**)MEM_alloc( 1 * sizeof *ECUTypFull );
	ECUTypAbr = (char**)MEM_alloc( 1 * sizeof *ECUTypAbr );
	
	(void)argc;
	(void)argv;

	initialise();
	
	sVCID  = ITK_ask_cli_argument("-i=");
	sRevSeq = ITK_ask_cli_argument("-r=");
	
	tc_strcpy(sRevSeqDup,sRevSeq);
	printf("\n sRevSeqDup == [%s]", sRevSeqDup);fflush(stdout);

	sVCIDRev = tc_strtok(sRevSeqDup,";");
	sVCIDSeq =tc_strtok(NULL,"");
	
	tc_strcpy(sRevnSeq,sVCIDRev);
	tc_strcat(sRevnSeq,"*");
	tc_strcat(sRevnSeq,sVCIDSeq);
	printf("\nkk.Rev and Seq = [%s]\n", sRevnSeq);fflush(stdout);
	
	if(sVCID)
	{
		values[0] = sVCID;
		values[1] = "VCID Revision";
		values[2] = sRevnSeq;

		if(QRY_find2("Item Revision...", &ProQryVCID));
		if(ProQryVCID)
		{
			 if(QRY_execute(ProQryVCID, n_Input, qry_Input, values, &nVCIDCnt, &tpVCIDObjs));
			 printf("\nkk.VCID count is == %d", nVCIDCnt);fflush(stdout);
		}

		if(nVCIDCnt == 0)
		{
			printf ("\nkk.VCID %s is not found!!!\n", sVCID); fflush(stdout);
			exit(0);
		}
		
		if(nVCIDCnt>0)
		{
			tVCIDObj = tpVCIDObjs[0];
			
			if(QRY_find2("ControlObjQry",&ECUTypeQuery));
			if(ECUTypeQuery)
			{
				 if(QRY_execute(ECUTypeQuery, nECUTypeEnt, qryInputECUType, qryProjValECUType, &nECUTypCnt, &tpECUTypeCnObj));
				 printf("\n CONT for ECUTypeQuery CntrlObj == %d\n", nECUTypCnt);fflush(stdout);
			}
			else
			{
				printf("\n ContrlObj for ECUTypeQuery not found.");fflush(stdout);
			}
			if(nECUTypCnt >0)
			{
				for(iECnt=0; iECnt<nECUTypCnt; ++iECnt)
				{
					if (AOM_ask_value_string(tpECUTypeCnObj[iECnt],"t5_Userinfo1",&info1ECUType)!=ITK_ok);
					printf("\n  info1ECUType [%s]",info1ECUType); fflush(stdout);
					setAddStr(&iECU1,&ECUTypFull,info1ECUType);

					if (AOM_ask_value_string(tpECUTypeCnObj[iECnt],"t5_Userinfo2",&info2ECUType)!=ITK_ok);
					printf("\n info2ECUType [%s]",info2ECUType); fflush(stdout);
					setAddStr(&iECU2,&ECUTypAbr,info2ECUType);
				}
			}
			
			ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshot_type); 
			ifail = GRM_list_secondary_objects_only(tVCIDObj,HasSnapshot_type,&nSnapCnt,&tpSnapObj);
			printf("\nkk.Snapshot count [%d] -------> \n",nSnapCnt);fflush(stdout);
			if(nSnapCnt>0)
			{
				tSnap = tpSnapObj[0];
				ITKCALL(AOM_ask_value_tag(tSnap,"topLine",&tTopLine));
				Multi_Get_Part_BOM_Lvl(tTopLine,99,level,tSnap,ChldStrutBdySh,&StructChldCnt,"NA");
				printf ("\nkk.Child Count [%d] \n",StructChldCnt);fflush(stdout);
			}
			
			ITKCALL(GRM_find_relation_type("T5_HasNewCCID",&tNewVCIDRel));
			if(tNewVCIDRel!=NULLTAG)
			{
				printf("\n Hs new VCID rel found \n ");fflush(stdout);
				GRM_list_primary_objects_only(tVCIDObj,tNewVCIDRel,&nCntDML,&tpDMLRev);
				printf("\nkk.No of DML FOUND [%d]",nCntDML);fflush(stdout);
				if(nCntDML>0)
				{
					for(iCntDML=0; iCntDML<nCntDML; ++iCntDML)
					{
						if(TCTYPE_ask_object_type(tpDMLRev[iCntDML],&tDMLTypeTg));
						if(TCTYPE_ask_name2(tDMLTypeTg,&sDmlType));
						printf("\nkk.class of DML [%s]",sDmlType);fflush(stdout);
						if(tc_strcmp(sDmlType,"ChangeRequestRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(tpDMLRev[iCntDML],"item_id",&sDML_name));
							ITKCALL(AOM_ask_value_string(tpDMLRev[iCntDML],"CMClosureDate",&sVCIDRelDt));
							printf("\nkk.Closure date of DML %s is [%s]",sDML_name,sVCIDRelDt);fflush(stdout);
						}
					}
				}
			}
			
			ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&ReferencesCCVTag));
			ITK_CALL(GRM_list_secondary_objects_only(tVCIDObj,ReferencesCCVTag,&nVCCnt,&tpVCItmObj));
			printf("\nkk.VC count is [%d]\n",nVCCnt); fflush(stdout);
			
			Model_Var_Input_St(sVCID,sVCIDRev,sVCIDSeq,sVCIDRelDt,&VehTent[0],nVCCnt,tpVCItmObj);
			
			/*if(nVCCnt>0)
			{
				for(iVCCnt=0; iVCCnt<nVCCnt; ++iVCCnt)
				{
					tVCItmObj = tpVCItmObj[iVCCnt];
					//Model_Var_Input_St(tVCItmObj,sVCID,sVCIDRev,sVCIDSeq,sVCIDRelDt,&VehTent[0],nVCCnt,tpVCItmObj);
					//TODO:Print VehTent structure
				}
			}*/
		}
	}
	
	printf("\nkk...VCID NIO Data Generation Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}
