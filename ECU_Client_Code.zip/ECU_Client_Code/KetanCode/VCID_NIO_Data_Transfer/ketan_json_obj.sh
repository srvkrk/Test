rm -f ketan_json_obj ketan_json_obj.o
cc -o ketan_json_obj ketan_json_obj.c -lcurl libcjson.a libcjson_utils.a -I/home/erc3dev/devgroup/dbk_uadev/rest_api/12112024/cJSON-master -L/usr/lib/x86_64-linux-gnu
./ketan_json_obj
