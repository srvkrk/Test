#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include <fclasses/tc_date.h>
#include <cJSON.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

char* Con_Part_List=NULL;

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

//int iVarntsCnt = 0;
logical lAreValsAdded = false;
int iECU1 = 0;
int iECU2 = 0;
char **ECUTypFull = NULL;
char **ECUTypAbr = NULL;
int     iWriteRPar			=   0;
int     iWriteRCon			=   0;
int     iWriteRConType		=   0;
int     iWriteRConrev		=   0;
int     iWriteP				=   0;
char	**PRMList			=	NULL;
char	**ConatainerTypeListX=	NULL;
char	**ConatainerList	=   NULL;
char	**ConatainerRev		=   NULL;
char	**ParaList			=	NULL;
logical lEcuDataInput;
logical lEcuSoftwareReleaseInput;
logical lEcuDidParamInput;
logical lEcuOptVal;
int iEcuDidFileCnt = 0;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

		if(tc_strcmp((*strset)[j],str)==0)
		
		return j;
	}
	return -1;
}
 
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	tc_strcpy((*strset)[*count-1],str);
	printf("\nkk.setAddStr [%s]",(*strset)[*count-1]);fflush(stdout);

}

struct BomChldStrut_EE
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
	char *GrpID;
}*get_BomChldStrut_EE;

void Multi_Get_Part_BOM_Lvl(tag_t top_line,int reqLevel,int level,tag_t SnapshotRevTag ,struct BomChldStrut_EE BomChldStrut[],int* StructChldCnt,char *GrpNum, char *sRelPartList)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n_Cnt=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;

	char*			partColInd					=NULL;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	char* PrtCmpCode 	= NULL;

	int iCON =0;
	int y =0;
	char	**CONDetails		  =	NULL;
	CONDetails = (char**)MEM_alloc( 1 * sizeof *CONDetails );
	char * PartType = NULL;
	char * child_item_id = NULL;
	char * sPrtTyp = NULL;
	tag_t objTypeTag = NULLTAG;
	char * partNumberRev =NULL;
	char * SnapNumber =NULL;


	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}
	
	if (level==0)
	{

		tag_t Modl_rev_tags = NULLTAG;
		ITKCALL(AOM_ask_value_tag(SnapshotRevTag,"topLine",&Modl_rev_tags));
		BomChldStrut[*StructChldCnt].child_objs = top_line;
		BomChldStrut[*StructChldCnt].child_objs_bvr=Modl_rev_tags;
		BomChldStrut[*StructChldCnt].child_objs_lvl=level;
		BomChldStrut[*StructChldCnt].GrpID=GrpNum;

		ITKCALL(BOM_create_window (&window));
		BOM_create_window_from_snapshot(SnapshotRevTag,&window);
		ITKCALL(BOM_set_window_pack_all (window, true));

		BOM_set_window_top_line(window, null_tag,Modl_rev_tags ,null_tag, &top_line);
		BOM_window_show_suppressed(window);//TZ 3.42 Backend

	}

	ITKCALL(AOM_ask_value_string(SnapshotRevTag,"object_name",&SnapNumber));
	printf("\n Snapshot Name===>%s\n",SnapNumber);fflush(stdout);

	ITKCALL(AOM_ask_value_string(top_line,"bl_rev_item_revision_id",&partNumberRev));
	printf("\n partNumberRevr===>%s\n",partNumberRev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));
    printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
	printf("\nkk.No of child objects are n : %d\n",n_Cnt);fflush(stdout);

	level = level + 1;
	for (k = 0; k < n_Cnt; k++)
	{
		int MatchFlag=0;
	
		BOM_line_unpack (children[k]);
		AOM_ask_value_tag(children[k], bomAttr_lineItemRevTag, &t_ChildItemRev);
		if(t_ChildItemRev!=NULLTAG)
		{
			ITKCALL( AOM_ask_value_string(t_ChildItemRev,"t5_SwPartType",&PartType));
			printf("\n t_ChildItemRev tag found ===>%s\n",PartType);fflush(stdout);

			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "item_id", &child_item_id ));
			printf("\n t_ChildItemRev tag found  child_item_id===>%s\n",child_item_id);fflush(stdout);

			ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &sPrtTyp));
			printf("\nkk.Part Type is [%s]\n",sPrtTyp);fflush(stdout);
		   
			if(tc_strcmp(PartType,"CON")==0)
			{
				char* containerMatch=NULL;
				for (y=0;y<*StructChldCnt+1;y++)
				{
					printf("\n..IN Expansion_TPL_16 structure.. :%d\n",y);fflush(stdout);
					containerMatch=NULL;
					
					if( AOM_ask_value_string(BomChldStrut[y].child_objs,"item_id",&containerMatch)!=ITK_ok);
					if (tc_strcmp(containerMatch,child_item_id)==0)
					{
						printf("\n..CONTAINER MATCH FOUND  :\n");fflush(stdout);
						MatchFlag=1;
						break;
					}
				}															
			}
			if (MatchFlag==0)
			{
				printf("\n..match not found.hence proceeding \n");fflush(stdout);
				if(tc_strstr(sRelPartList,"ALL")!=NULL || tc_strstr(sRelPartList,child_item_id)!=NULL)
				{
					printf("\nkk.Part [%s] added in BOM struct.",child_item_id);fflush(stdout);
					*StructChldCnt	=	*StructChldCnt+1;
					BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
					BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
					BomChldStrut[*StructChldCnt].child_objs_lvl=level;
					BomChldStrut[*StructChldCnt].GrpID=GrpNum;
				}

				if(tc_strcmp(sPrtTyp,"G")==0)
				{
					Multi_Get_Part_BOM_Lvl(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,child_item_id,sRelPartList);
				}
				else
				{
					Multi_Get_Part_BOM_Lvl(children[k],reqLevel,level,SnapshotRevTag,BomChldStrut,StructChldCnt,GrpNum,sRelPartList);
				}
			}
		}
	}
	level = level - 1;
	
	MEM_free (childrenTag);

	CLEANUP:
		printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}

static void TPL_BOM_List(tag_t tSnapShot)
{
	int nSnapCnt = 0;
	int iSnCnt = 0;
	char *sSWPrtTyp = NULL;
	char *container = NULL;
	char *containerrev = NULL;
	tag_t tSnapContent = NULLTAG;
	tag_t* tpSnapContent = NULLTAG;
	printf("\nInside TPL BOM list Fn\n");fflush(stdout);

	PRMList = (char**)MEM_alloc( 1 * sizeof *PRMList );
	
	if(AOM_ask_value_tags(tSnapShot,"contents",&nSnapCnt,&tpSnapContent));
	printf("\nkk.snap count [%d] \n",nSnapCnt);fflush(stdout);
	for(iSnCnt=0; iSnCnt<nSnapCnt; ++iSnCnt)
	{
		tSnapContent = tpSnapContent[iSnCnt];
		if(AOM_ask_value_string(tSnapContent,"t5_SwPartType",&sSWPrtTyp)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_id",&container)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_revision_id",&containerrev)!=ITK_ok);
		printf("\nkk.Part [%s,%s],S/W Part Type [%s]",container,containerrev,sSWPrtTyp);fflush(stdout);

		if(tc_strcmp(sSWPrtTyp,"PRM") == 0)
		{
			char *sParmPart = NULL;
			sParmPart=(char *) MEM_alloc(50);
			tc_strcpy(sParmPart,container);
			tc_strcat(sParmPart,",");
			tc_strcat(sParmPart,containerrev);
			printf("\nkk.Adding Parameter [%s]",sParmPart);
			setAddStr(&iWriteP,&PRMList,sParmPart);
			printf("\n after PRMList\n");
		}
	}
}

static void Container_List(tag_t tSnapShot)
{
	int ifail;
	int nSnapCnt = 0;
	int iSnCnt = 0;
	int cntt = 0;
	int pq = 0;
	int iCnt = 0;
	int ind = 0;
	int SlvcntS = 0;
	int FATC_flag	= 0;
	int FATC_S_flag	= 0;
	char *sSWPrtTyp = NULL;
	char *container = NULL;
	char *containerrev = NULL;
	char *sEcuType = NULL;
	char *tmpcon	= "TEMP";
	char *parapart	= NULL;
	char *parrevseq	= NULL;
	char *sParPart	= NULL;
	char *Cnt_EcuTypeDup	= NULL;
	tag_t tSnapContent = NULLTAG;
	tag_t  ConPararelation_type  = NULLTAG;
	tag_t  ConHasParaPtr		 = NULLTAG;
	tag_t MstrSlvrelation_typeS  = NULLTAG;
	tag_t* tpSnapContent = NULLTAG;
	tag_t *Paraattachments	= NULLTAG;
	tag_t *SlvattachmentsS	= NULLTAG;
	printf("\nInside Container_List Fn\n");fflush(stdout);

	PRMList = (char**)MEM_alloc( 1 * sizeof *PRMList );

	TPL_BOM_List(tSnapShot);

	if(AOM_ask_value_tags(tSnapShot,"contents",&nSnapCnt,&tpSnapContent));
	printf("\nkk.snap count [%d] \n",nSnapCnt);fflush(stdout);
	for(iSnCnt=0; iSnCnt<nSnapCnt; ++iSnCnt)
	{
		tSnapContent = tpSnapContent[iSnCnt];
		if(AOM_ask_value_string(tSnapContent,"t5_SwPartType",&sSWPrtTyp)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_id",&container)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"item_revision_id",&containerrev)!=ITK_ok);
		if(AOM_ask_value_string(tSnapContent,"t5_EcuType",&sEcuType)!=ITK_ok);
		printf("\nkk.Part [%s,%s],S/W Part Type [%s],ECU Type [%s]",container,containerrev,sSWPrtTyp,sEcuType);fflush(stdout);

		if(tc_strcmp(sSWPrtTyp,"CON") == 0)
		{
			ifail = GRM_find_relation_type("T5_ContHasPara",&ConPararelation_type);  
			if(ConPararelation_type != NULLTAG)
			{
				printf("\nkk.Relation found.");	fflush(stdout);
				ITKCALL(GRM_list_secondary_objects_only(tSnapContent,ConPararelation_type,&cntt,&Paraattachments));
				printf("\nkk.cntt value is  --------------------- %d\n",cntt);fflush(stdout);
				if (cntt > 0)
				{				 	
					for(pq=0;pq<cntt;pq++)
					{
						ConHasParaPtr = Paraattachments[pq];
						if( AOM_ask_value_string(ConHasParaPtr,"item_id",&parapart)!=ITK_ok);
						if( AOM_ask_value_string(ConHasParaPtr,"item_revision_id",&parrevseq)!=ITK_ok);
						printf("\tkk.Parameyter Part is [%s,%s]\n",parapart,parrevseq); fflush(stdout);

						char *sParPart = NULL;
						sParPart=(char *) MEM_alloc(50);
						tc_strcpy(sParPart,parapart);
						tc_strcat(sParPart,",");
						tc_strcat(sParPart,parrevseq);
						printf("\nkk.Searching Par part [%s]...",sParPart);

						ind=setFindStr1(&iWriteP,&PRMList,sParPart);
						if(ind>=0)
						{	
							printf("\nkk.Added Par in ParaList.");fflush(stdout);
							setAddStr(&iWriteRCon,&ConatainerList,container);
							setAddStr(&iWriteRConType,&ConatainerTypeListX,"TEMP");
							setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
							setAddStr(&iWriteRPar,&ParaList,parapart);
							//bIsConParFound = TRUE;
						}
					}
				}
			}
					  		
			if(sEcuType)
			{	
				printf("\nkk.sEcuType not null \n"); fflush(stdout);
				Cnt_EcuTypeDup	=	NULL;
				Cnt_EcuTypeDup=(char *) MEM_alloc(10);

				if (tc_strstr(sEcuType,"Fully Automated Temperature Control")!=NULL)
				{
					tc_strcpy(Cnt_EcuTypeDup,"FATC");
					FATC_flag = 0;  
					ifail = GRM_find_relation_type("T5_ContHasSlave",&MstrSlvrelation_typeS); 
					{
						if(MstrSlvrelation_typeS != NULLTAG)
						{
							ITKCALL(GRM_list_secondary_objects_only(tSnapContent,MstrSlvrelation_typeS,&SlvcntS,&SlvattachmentsS));
							CHECK_FAIL;

							if (SlvcntS > 0)
							{	
								printf("\nAdded in SlvcntS");fflush(stdout);
								setAddStr(&iWriteRCon,&ConatainerList,container);
								setAddStr(&iWriteRConType,&ConatainerTypeListX,Cnt_EcuTypeDup);
								setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
								setAddStr(&iWriteRPar,&ParaList,tmpcon);
								FATC_flag = 1;
								continue;

							}
							else
							{
								FATC_S_flag = 1;
							}
						}
					}
				}
				else 
				{
					tc_strcpy(Cnt_EcuTypeDup,"NA");
				}
				for(iCnt=0; iCnt<iECU1; ++iCnt)
				{
					if(tc_strcmp((ECUTypFull)[iCnt],sEcuType)==0)
					{
						tc_strcpy(Cnt_EcuTypeDup,(ECUTypAbr)[iCnt]);
					}
				}
														
				printf("\nkk.Cnt_EcuTypeDup value is [%s]\n",Cnt_EcuTypeDup);fflush(stdout);
				setAddStr(&iWriteRCon,&ConatainerList,container);
				setAddStr(&iWriteRConType,&ConatainerTypeListX,Cnt_EcuTypeDup);
				setAddStr(&iWriteRConrev,&ConatainerRev,containerrev);
				setAddStr(&iWriteRPar,&ParaList,tmpcon); 

			}
			else
			{
				tc_strcpy(Cnt_EcuTypeDup,"NA");
				printf("\nkk.Cnt_EcuTypeDup value is : %s \n",Cnt_EcuTypeDup);fflush(stdout);
			}										
		}
	}
}

logical CheckIfPartInBom(char *sFndPrtNum, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int ifail;
	int iPCnt;
	char *sBmPrtNum = NULL;
	
	for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
	{
		if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"item_id",&sBmPrtNum)!=ITK_ok);
		//if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_SwPartType",&sBmSwPTyp)!=ITK_ok);
		if(tc_strcmp(sBmPrtNum,sFndPrtNum)==0)
		{
			return true;
		}
	}
	return false;
}

logical CheckIfParApplicbl(char *sFndPrtNum, char *sFndECUTyp, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[], char **sParPartNum)
{
	int ifail;
	int ind;
	int iPCnt;
	char *sBmPrtNum = NULL;
	char *sBmEcuTyp = NULL;
	char *sBmSwPTyp = NULL;
	
	ind=setFindStr1(&iWriteRCon,&ConatainerList,sFndPrtNum);
	if(ind >= 0)//TODO: Handle FATC case
	{
		if(tc_strcmp(ParaList[ind],"TEMP")==0)
		{
			for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_EcuType",&sBmEcuTyp)!=ITK_ok);
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_SwPartType",&sBmSwPTyp)!=ITK_ok);
				if(tc_strcmp(sBmSwPTyp,"PRM")==0 && tc_strcmp(sBmEcuTyp,sFndECUTyp)==0)
				{
					if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"item_id",&sBmPrtNum)!=ITK_ok);
					tc_strcpy(*sParPartNum,sBmPrtNum);
					return true;
				}
			}
		}
		else
		{
			tc_strcpy(*sParPartNum,ParaList[ind]);
			return true;
		}
	}
	
	return false;
}
static void GetMasterHwNum(tag_t tSlavePrt, cJSON **js_obj, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int ifail;
	int nMstCnt;
	int iMstCnt;
	int iPrtCnt;
	int nPrtCnt;
	int iBmCnt;
	int istats;
	logical lIsSlvFound = false;
	char *sMstConPrt = NULL;
	char *sMstConRev = NULL;
	char *sBmConPrt = NULL;
	char *sBmConRev = NULL;
	char *sMSwPrtTyp = NULL;
	char *sMHwPrtNum = NULL;
	char *sMHwEcuTyp = NULL;
	tag_t tMstCon = NULLTAG;
	tag_t tMstrSlvRel = NULLTAG;
	tag_t tChldPrt = NULLTAG;
	tag_t *tMstConObjs = NULLTAG;
	tag_t *tpChldPrt = NULLTAG;
	cJSON *ms_arr;
	cJSON *slv_obj;
	
	ifail = GRM_find_relation_type("T5_ContHasSlave",&tMstrSlvRel);
	if(tMstrSlvRel != NULLTAG)
	{
		//GRM_list_primary_objects_only(tSlavePrt,tMstrSlvRel,&nMstCnt,&tMstConObjs);
		GRM_list_secondary_objects_only(tSlavePrt,tMstrSlvRel,&nMstCnt,&tMstConObjs);
		printf("\nkk.No of Master containers [%d]",nMstCnt); fflush(stdout);
		for(iMstCnt=0; iMstCnt<nMstCnt; ++iMstCnt)
		{
			if(AOM_ask_value_string(tMstConObjs[iMstCnt],"item_id",&sMstConPrt)!=ITK_ok);
			if(AOM_ask_value_string(tMstConObjs[iMstCnt],"item_revision_id",&sMstConRev)!=ITK_ok);
			for(iBmCnt=0; iBmCnt<=nBomPrtCnt; ++iBmCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"item_id",&sBmConPrt)!=ITK_ok);
				if(AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"item_revision_id",&sBmConRev)!=ITK_ok);
				//printf("\nkk.Slave part [%s,%s] BoM part [%s,%s]",sMstConPrt,sMstConRev,sBmConPrt,sBmConRev); fflush(stdout);
				if(tc_strcmp(sMstConPrt,sBmConPrt)==0 && tc_strcmp(sMstConRev,sBmConRev)==0)
				{
					tMstCon = BomChldStrut[iBmCnt].child_objs_bvr;
					
					istats = BOM_line_ask_child_lines (tMstCon, &nPrtCnt, &tpChldPrt);
					printf("\nkk.Size of Container Childs are :[%d]",nPrtCnt);fflush(stdout);
					for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
					{
						tChldPrt = tpChldPrt[iPrtCnt];
						if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sMSwPrtTyp)!=ITK_ok);
						if(tc_strcmp(sMSwPrtTyp,"HWC")==0)
						{
							if( AOM_ask_value_string(tChldPrt,"bl_item_item_id",&sMHwPrtNum)!=ITK_ok);
							if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_EcuType",&sMHwEcuTyp)!=ITK_ok);
							printf("\nkk.Hardware part number for Con part is :[%s,%s]",sMHwPrtNum,sMHwEcuTyp);fflush(stdout);
							//tc_strcpy(*sMstHwNum,sMHwPrtNum);
							
							if(lIsSlvFound ==  false)
							{
								lIsSlvFound = true;
								cJSON_AddItemToObject(*js_obj, "isMasterECU", cJSON_CreateString("Yes"));
								ms_arr = cJSON_CreateArray();
								cJSON_AddItemToObject(*js_obj, "slaveEcuProperties", ms_arr);	
							}
							
							cJSON_AddItemToArray(ms_arr, slv_obj = cJSON_CreateObject());
							cJSON_AddItemToObject(slv_obj, "slaveEcuName", cJSON_CreateString(sMHwEcuTyp));
							cJSON_AddItemToObject(slv_obj, "slaveSubPartNumber", cJSON_CreateString(sMHwPrtNum));
							break;
						}
					}
				}
			}
		}
		if(lIsSlvFound ==  false)
		{
			cJSON_AddItemToObject(*js_obj, "isMasterECU", cJSON_CreateString("No"));
			ms_arr = cJSON_CreateArray();
			cJSON_AddItemToObject(*js_obj, "slaveEcuProperties", ms_arr);
			//cJSON_AddItemToArray(ms_arr, slv_obj = cJSON_CreateObject());
		}
	}
}

static void GetHwPrtForPar(char *sParPrtNum, char *sParECUTyp, char **sHardwrNum, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int ifail;
	int ind;
	int iPCnt;
	int iCnt;
	int nPrtCnt;
	int iPrtCnt;
	int istats;
	char *sBmPrtNum = NULL;
	char *sCSwPrtNum = NULL;
	char *sBmEcuTyp = NULL;
	char *sBmSwPTyp = NULL;
	char *sCSwPrtTyp = NULL;
	tag_t tConPrt = NULLTAG;
	tag_t *tpChldPrt = NULLTAG;
	tag_t tChldPrt = NULLTAG;
	
	ind=setFindStr1(&iWriteRPar,&ParaList,sParPrtNum);
	if(ind >= 0)
	{
		for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
		{
			if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"item_id",&sBmPrtNum)!=ITK_ok);
			if(tc_strcmp(sBmPrtNum,ConatainerList[ind])==0)
			{
				printf("\nkk.Container found using Par part.");fflush(stdout);
				tConPrt = BomChldStrut[iPCnt].child_objs;
				break;
			}
		}
	}
	else
	{
		for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
		{
			if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_EcuType",&sBmEcuTyp)!=ITK_ok);
			if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_SwPartType",&sBmSwPTyp)!=ITK_ok);
			if(tc_strcmp(sBmSwPTyp,"CON")==0 && tc_strcmp(sBmEcuTyp,sParECUTyp)==0)
			{
				printf("\nkk.Container found using ECU Type.");fflush(stdout);
				tConPrt = BomChldStrut[iPCnt].child_objs_bvr;
				break;
			}
		}
	}
	if(tConPrt != NULLTAG)
	{
		istats = BOM_line_ask_child_lines (tConPrt, &nPrtCnt, &tpChldPrt);
		printf("\nkk.Size of Container Childs:- [%d]",nPrtCnt);fflush(stdout);
		for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
		{
			tChldPrt = tpChldPrt[iPrtCnt];
			if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sCSwPrtTyp)!=ITK_ok);
			if(tc_strcmp(sCSwPrtTyp,"HWC")==0)
			{
				if( AOM_ask_value_string(tChldPrt,"bl_item_item_id",&sCSwPrtNum)!=ITK_ok);
				printf("\nkk.Hardware part number for par part %s is :[%s]",sParPrtNum,sCSwPrtNum);fflush(stdout);
				tc_strcpy(*sHardwrNum,sCSwPrtNum);
				break;
			}
		}
	}
}

static void GetParSwVerVal(char *sPrtNum, char *sAbrEcuTyp,char **sSwVersnVal, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int ifail;
	int ind;
	int iPCnt;
	int iCnt;
	//int iCntPC;
	int nCntPC;
	char *sParPrtNum;
	//char *sParVend;
	//char *sParDidVal;
	//char *sParDataTyp;
	//char *sParRdWrt;
	char *sParEcuTyp;
	char *sParSwPrtTyp;
	char *sUsrEntVal;
	//char *sParEcuTypAbr;
	
	tag_t tEERel_type = NULLTAG;
	tag_t tParCls = NULLTAG;
	tag_t *tpParCls = NULLTAG;
	tag_t tParPrt = NULLTAG;
	tag_t tParRelProp = NULLTAG;
	
	//sParEcuTypAbr =(char *) MEM_alloc(10);
	
	ind=setFindStr1(&iWriteRCon,&ConatainerList,sPrtNum);
	if(ind >= 0)
	{
		if(tc_strcmp(ParaList[ind],"TEMP")==0)
		{
			for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_EcuType",&sParEcuTyp)!=ITK_ok);
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_SwPartType",&sParSwPrtTyp)!=ITK_ok);
				if(tc_strcmp(sParSwPrtTyp,"PRM")==0)
				{
					for(iCnt=0; iCnt<iECU1; ++iCnt)
					{
						if(tc_strcmp((ECUTypFull)[iCnt],sParEcuTyp)==0)
						{
							//tc_strcpy(sParEcuTypAbr,(ECUTypAbr)[iCnt]);
							if(tc_strcmp((ECUTypAbr)[iCnt],sAbrEcuTyp)==0)
							{
								printf("\nkk.Par tag found by matching ECU Type."); fflush(stdout);
								tParPrt = BomChldStrut[iPCnt].child_objs;
							}
						}
					}
				}
			}
		}
		else
		{
			for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"item_id",&sParPrtNum)!=ITK_ok);
				if(tc_strcmp(sParPrtNum,ParaList[ind])==0)
				{
					printf("\nkk.Par tag found by matching Parameter part."); fflush(stdout);
					tParPrt = BomChldStrut[iPCnt].child_objs;
					break;
				}
			}
		}
		if(tParPrt != NULLTAG)
		{
			ifail = GRM_find_relation_type("T5_EEPrm",&tEERel_type);
			if(tEERel_type != NULLTAG)
			{
				ifail = GRM_list_secondary_objects_only(tParPrt,tEERel_type,&nCntPC,&tpParCls);
				printf("\nkk.Count of parameter clauses [%d]",nCntPC); fflush(stdout);
				if(nCntPC>0)
				{
				//for(iCntPC=0; iCntPC<nCntPC; ++iCntPC)
				//{
					tParCls = tpParCls[0];
					//if(AOM_ask_value_string(tParCls,"t5_ECUVendor",&sParVend)!=ITK_ok);
					//if(AOM_ask_value_string(tParCls,"t5_EPDidValue",&sParDidVal)!=ITK_ok);
					//'7205','F181','F1A7','F195','F194','F189','F188','7278','7241','F124'
					//if(AOM_ask_value_string(tParCls,"t5_EPType",&sParDataTyp)!=ITK_ok);
					//if(AOM_ask_value_string(tParCls,"t5_EPReadable",&sParRdWrt)!=ITK_ok);
					ifail = GRM_find_relation(tParPrt,tParCls,tEERel_type,&tParRelProp);
					ifail = AOM_ask_value_string(tParRelProp,"t5_BitValue",&sUsrEntVal);
					
					//tc_strcpy(*sVendor,sParVend);
					//tc_strcpy(*sDIDVal,sParDidVal);
					//tc_strcpy(*sDataTyp,sParDataTyp);
					tc_strcpy(*sSwVersnVal,sUsrEntVal);
				//}
				}
			}
		}
	}
}

static void GetParVals(char *sPrtNum, char *sAbrEcuTyp,char **sVendor, char **sDIDVal, char **sDataTyp, char **sReadWrite, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int ifail;
	int ind;
	int iPCnt;
	int iCnt;
	//int iCntPC;
	int nCntPC;
	char *sParPrtNum;
	char *sParVend;
	char *sParDidVal;
	char *sParDataTyp;
	char *sParRdWrt;
	char *sParEcuTyp;
	char *sParSwPrtTyp;
	//char *sParEcuTypAbr;
	
	tag_t tEERel_type = NULLTAG;
	tag_t tParCls = NULLTAG;
	tag_t *tpParCls = NULLTAG;
	tag_t tParPrt = NULLTAG;
	
	//sParEcuTypAbr =(char *) MEM_alloc(10);
	
	ind=setFindStr1(&iWriteRCon,&ConatainerList,sPrtNum);
	if(ind >= 0)
	{
		if(tc_strcmp(ParaList[ind],"TEMP")==0)
		{
			for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_EcuType",&sParEcuTyp)!=ITK_ok);
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"t5_SwPartType",&sParSwPrtTyp)!=ITK_ok);
				if(tc_strcmp(sParSwPrtTyp,"PRM")==0)
				{
					for(iCnt=0; iCnt<iECU1; ++iCnt)
					{
						if(tc_strcmp((ECUTypFull)[iCnt],sParEcuTyp)==0)
						{
							//tc_strcpy(sParEcuTypAbr,(ECUTypAbr)[iCnt]);
							if(tc_strcmp((ECUTypAbr)[iCnt],sAbrEcuTyp)==0)
							{
								printf("\nkk.Par tag found by matching ECU Type."); fflush(stdout);
								tParPrt = BomChldStrut[iPCnt].child_objs;
							}
						}
					}
				}
			}
		}
		else
		{
			for(iPCnt=0; iPCnt<=nBomPrtCnt; ++iPCnt)
			{
				if(AOM_ask_value_string(BomChldStrut[iPCnt].child_objs,"item_id",&sParPrtNum)!=ITK_ok);
				if(tc_strcmp(sParPrtNum,ParaList[ind])==0)
				{
					printf("\nkk.Par tag found by matching Parameter part."); fflush(stdout);
					tParPrt = BomChldStrut[iPCnt].child_objs;
					break;
				}
			}
		}
		if(tParPrt != NULLTAG)
		{
			ifail = GRM_find_relation_type("T5_EEPrm",&tEERel_type);
			if(tEERel_type != NULLTAG)
			{
				ifail = GRM_list_secondary_objects_only(tParPrt,tEERel_type,&nCntPC,&tpParCls);
				printf("\nkk.Count of parameter clauses [%d]",nCntPC); fflush(stdout);
				if(nCntPC>0)
				{
				//for(iCntPC=0; iCntPC<nCntPC; ++iCntPC)
				//{
					tParCls = tpParCls[0];
					if(AOM_ask_value_string(tParCls,"t5_ECUVendor",&sParVend)!=ITK_ok);
					if(AOM_ask_value_string(tParCls,"t5_EPDidValue",&sParDidVal)!=ITK_ok);
					//'7205','F181','F1A7','F195','F194','F189','F188','7278','7241','F124'
					if(AOM_ask_value_string(tParCls,"t5_EPType",&sParDataTyp)!=ITK_ok);
					if(AOM_ask_value_string(tParCls,"t5_EPReadable",&sParRdWrt)!=ITK_ok);
					
					tc_strcpy(*sVendor,sParVend);
					tc_strcpy(*sDIDVal,sParDidVal);
					tc_strcpy(*sDataTyp,sParDataTyp);
					tc_strcpy(*sReadWrite,sParRdWrt);
				//}
				}
			}
		}
	}
}

int GetPartRelDate(char *sSwPrtNum, char *sSwPrtRev, char **sSwRelDate)
{
	int ifail;
	int nRlStatCnt;
	int iRlStatCnt;
	int nPrtCnt;
	char *sRelStat = NULL;
	char *sPrtRelDt = NULL;
	date_t dPrtRelDt;
	tag_t tPrtObj = NULLTAG;
	tag_t *tpRelStatList = NULLTAG;
	tag_t *tpPrtObj = NULLTAG;
	
	const char **attrs6  = (const char **) MEM_alloc(2 * sizeof(char *));
	const char **values6 = (const char **) MEM_alloc(2 * sizeof(char *));
	
	attrs6[0]	   = "item_id";
	values6[0]     = (char *)sSwPrtNum;
	ifail = ITEM_find_item_revs_by_key_attributes(1,attrs6, values6,sSwPrtRev, &nPrtCnt, &tpPrtObj);
	printf("\nkk.Qry Part count is [%d]", nPrtCnt);fflush(stdout);
	if(nPrtCnt > 0)
	{
		tPrtObj = tpPrtObj[0];
		ITKCALL(WSOM_ask_release_status_list(tPrtObj,&nRlStatCnt,&tpRelStatList));
		printf("\nkk.Release status count is [%d]", nRlStatCnt);fflush(stdout);
		if(nRlStatCnt>0)
		{
			for(iRlStatCnt=0; iRlStatCnt<nRlStatCnt; ++iRlStatCnt)
			{
				ITKCALL(AOM_ask_value_string(tpRelStatList[iRlStatCnt],"object_name",&sRelStat));
				printf("\nkk.Release Status Val [%s]", sRelStat);fflush(stdout);
				if(tc_strstr(sRelStat,"ERC Released")!=NULL || tc_strstr(sRelStat,"T5_LcsErcRlzd")!=NULL)
				{
					ITKCALL(AOM_ask_value_date(tpRelStatList[iRlStatCnt],"date_released",&dPrtRelDt));
					if(ITK_ok != (ifail = DATE_date_to_string(dPrtRelDt,"%d-%b-%Y %H:%M",&sPrtRelDt)))
					{
						return ifail;
					}
				}
			}
		}
		printf("\nkk.Closure date of part is [%s]",sPrtRelDt);fflush(stdout);
		tc_strcpy(*sSwRelDate,sPrtRelDt);
	}
}

static void GetApplicabilityVal(char *sPrtAppl,char **sPrtApplVal)
{
	if(tc_strcmp(sPrtAppl,"BothES")==0)
	{
		tc_strcpy(*sPrtApplVal,"Both");
	}
	else if(tc_strcmp(sPrtAppl,"NotApp")==0)
	{
		tc_strcpy(*sPrtApplVal,"NA");
	}
	else if(tc_strcmp(sPrtAppl,"t5all")==0)
	{
		tc_strcpy(*sPrtApplVal,"All");
	}
	else
	{
		tc_strcpy(*sPrtApplVal,sPrtAppl);
	}
}

static void GetSwFileNames(char *sSwPrtNum, char *sSwPrtRev, char **sFileNames)
{
	int ifail;
	int nFCnt;
	int iFCnt;
	int nPrtCnt;
	logical lIsFirstFIle = false;
	char *sDtObjTyp = NULL;
	char *sRefName = NULL;
	char *sOrgName = NULL;
	char *sFilePath = NULL;
	tag_t tImanRel = NULLTAG;
	tag_t tNmdRefObj = NULLTAG;
	tag_t tDataSt = NULLTAG;
	tag_t *tpAtchObjs = NULLTAG;
	tag_t tPrtObj = NULLTAG;
	tag_t *tpPrtObj = NULLTAG;
	AE_reference_type_t reftype;
	
	const char **attrs6  = (const char **) MEM_alloc(2 * sizeof(char *));
	const char **values6 = (const char **) MEM_alloc(2 * sizeof(char *));
	sFilePath =(char *) MEM_alloc(200);
	
	attrs6[0]	   = "item_id";
	values6[0]     = (char *)sSwPrtNum;
	ifail = ITEM_find_item_revs_by_key_attributes(1,attrs6, values6,sSwPrtRev, &nPrtCnt, &tpPrtObj);
	printf("\nkk.Qry Part count is [%d]", nPrtCnt);fflush(stdout);
	if(nPrtCnt > 0)
	{
		tPrtObj = tpPrtObj[0];
		ifail = GRM_find_relation_type("IMAN_specification",&tImanRel);		
		ifail = GRM_list_secondary_objects_only(tPrtObj,tImanRel,&nFCnt,&tpAtchObjs);
		printf("\nkk.Attachments found [%d]",nFCnt); fflush(stdout);
		for(iFCnt=0; iFCnt<nFCnt; ++iFCnt)
		{
			tDataSt = tpAtchObjs[iFCnt];
			if( AOM_ask_value_string(tDataSt,"object_type",&sDtObjTyp)!=ITK_ok);
			printf("\nkk.Object Type is [%s]",sDtObjTyp);fflush(stdout);
			if((tc_strcmp(sDtObjTyp,"T5_IndepBin")==0)||(tc_strcmp(sDtObjTyp,"MSWordX")==0)||(tc_strcmp(sDtObjTyp,"MSWord")==0)
			||(tc_strcmp(sDtObjTyp,"MSWordTemplate")==0)||(tc_strcmp(sDtObjTyp,"MSWordTemplateX")==0) || (tc_strcmp(sDtObjTyp,"Text")==0))
			{
				ifail = AE_find_dataset_named_ref2(tDataSt,0,&sRefName,&reftype,&tNmdRefObj);
				
				if(tNmdRefObj != NULLTAG)
				{
					ifail =(IMF_ask_original_file_name2(tNmdRefObj,&sOrgName));
					printf("\nkk.Org file name is [%s]\n",sOrgName); fflush(stdout);
					if(lIsFirstFIle == false)
					{
						tc_strcpy(*sFileNames,sOrgName);
						lIsFirstFIle = true;
					}
					else
					{
						tc_strcat(*sFileNames,",");
						tc_strcat(*sFileNames,sOrgName);
					}
					tc_strcpy(sFilePath,"Files/");
					tc_strcat(sFilePath,sOrgName);
					IMF_export_file(tNmdRefObj,sFilePath);
				}
			}
		}
	}
}

int Get_Prod_Line_Category(char *sVCID, char *sVCIDRev, char *sVCIDSeq, int nVcCnt, tag_t *tpVCItmList)
{
	int status;
	int ifail;
	int ic = 0;
	int xc = 0;
	int theAttributeCount =0;
	int *theAttributeIds;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char*** theAttributeValues = NULL;
	char*** theAttributeOptimizedUnits = NULL;
	char *sProdLine = NULL;
	tag_t tVehM = NULLTAG;
	tag_t tVehMCls = NULLTAG;
	
	sProdLine =(char *) MEM_alloc(10);
	
	if(nVcCnt > 0)
	{
		tVehM = tpVCItmList[0];
		tc_strcpy(sProdLine,"");
		ICS_ask_classification_object(tVehM,&tVehMCls);
		ITK_CALL(ICS_ico_ask_attributes_optimized(tVehMCls,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
		if(theAttributeCount>0)
		{
			for(ic=0; ic<theAttributeCount; ++ic)
			{
				if(tc_strcmp(theAttributeNames[ic],"PRODUCT LINE")==0)
				{
					for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
					{
						tc_strcat(sProdLine,theAttributeValues[ic][xc]);
					}

					printf("\nkk.Category: Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
					printf("\nkk.Category: Attribute Value:[%s]",sProdLine);fflush(stdout);
				}
			}
		}
		
		FILE *fpCat = fopen("Category_PV_EV.txt","w");
		if (fpCat != NULL)
		{
			fprintf(fpCat, "%s", sProdLine);
		}
		fclose(fpCat);
	}
	
	CLEANUP:
		printf("\nInside Get_Prod_Line_Category CLEANUP");fflush(stdout);
	return status;
}

int Model_Var_Input_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, char *sVCIDRelDate, logical lHasTel, logical lHasPeps, int nVcCnt, tag_t *tpVCItmList)
{
	int status;
	int ifail;
	int ic = 0;
	int xc = 0;
	//int nVCCnt;
	int iVCCnt;
	int nModelRelYr;
	int nVarRelYr;
	int nVarRelMnth;
	//logical lHasTel = false;
	//logical lHasPeps = false;
	int theAttributeCount =0;
	int *theAttributeIds;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char*** theAttributeValues = NULL;
	char*** theAttributeOptimizedUnits = NULL;
	char *sVCNum = NULL;
	char *sVCNumTr = NULL;
	char *sVCNumDup = NULL;
	char *sProdLine = NULL;
	char *sMajorModel = NULL;
	char *sPlatform = NULL;
	char *sVehType = NULL;
	char *sModelRelYr = NULL;
	char *sVariant = NULL;
	char *sFuel = NULL;
	char *sTrnsmsn = NULL;
	char *sEmmisnNrms = NULL;
	char *sVarRelYr = NULL;
	char *sVarRelMnth = NULL;
	char *sVCIDNum = NULL;
	char *sVCDesc = NULL;
	tag_t tVehMCls = NULLTAG;
	tag_t tVehM = NULLTAG;
	tag_t tVehRv = NULLTAG;
	
	sProdLine =(char *) MEM_alloc(10);
	sMajorModel =(char *) MEM_alloc(20);
	sPlatform =(char *) MEM_alloc(20);
	sVehType =(char *) MEM_alloc(20);
	sModelRelYr =(char *) MEM_alloc(20);
	sVariant =(char *) MEM_alloc(50);
	sFuel =(char *) MEM_alloc(20);
	sTrnsmsn =(char *) MEM_alloc(20);
	sEmmisnNrms =(char *) MEM_alloc(50);
	sVarRelYr =(char *) MEM_alloc(10);
	sVarRelMnth =(char *) MEM_alloc(10);
	sVCIDNum =(char *) MEM_alloc(25);
	sVCNumDup =(char *) MEM_alloc(25);
	
	cJSON *rfc_root;
	cJSON *Tenant_detail_req;
	cJSON *single_model_req;
	cJSON *models_req;
	cJSON *single_variant_req;
	cJSON *variants_req;
	char *MVI_out;
	
	rfc_root = cJSON_CreateObject();
	Tenant_detail_req = cJSON_CreateObject();

	single_model_req = cJSON_CreateObject();
	models_req = cJSON_CreateArray();

	single_variant_req = cJSON_CreateObject();
	variants_req = cJSON_CreateArray();
	
	if(nVcCnt>0)
	{
		tc_strcpy(sVCIDNum,sInpVCID);
		tc_strcat(sVCIDNum,"-");
		tc_strcat(sVCIDNum,sInpVCIDRv);
		tc_strcat(sVCIDNum,sInpVCIDSq);
			
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];

			tc_strcpy(sProdLine,"NA");
			tc_strcpy(sMajorModel,"NA");
			tc_strcpy(sPlatform,"NA");
			tc_strcpy(sVehType,"NA");
			tc_strcpy(sModelRelYr,"2024");//TODO: take this val from PLM
			nModelRelYr = 2024;
			tc_strcpy(sVariant,"NA");
			tc_strcpy(sFuel,"NA");
			tc_strcpy(sTrnsmsn,"NA");
			tc_strcpy(sEmmisnNrms,"NA");
			tc_strcpy(sVarRelYr,"2024");//TODO: take this val from PLM
			nVarRelYr = 2024;
			tc_strcpy(sVarRelMnth,"04");
			nVarRelMnth = 04;
			
			ICS_ask_classification_object(tVehM,&tVehMCls);
			ITK_CALL(ICS_ico_ask_attributes_optimized(tVehMCls,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
			if(theAttributeCount>0)
			{
				for(ic=0; ic<theAttributeCount; ++ic)
				{
					if(tc_strcmp(theAttributeNames[ic],"PRODUCT LINE")==0)
					{
						tc_strcpy(sProdLine,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sProdLine,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						//printf("\n attrId:[%s]",attrId);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sProdLine);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"[VC]MAJORMODEL")==0)
					{
						tc_strcpy(sMajorModel,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sMajorModel,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sMajorModel);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"PLATFORM")==0)
					{
						tc_strcpy(sPlatform,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sPlatform,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sPlatform);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"[VC]VEHICLE_TYPE(VEHICLE_TYPE)")==0)
					{
						tc_strcpy(sVehType,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sVehType,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sVehType);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"VARIANT")==0)
					{
						tc_strcpy(sVariant,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sVariant,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sVariant);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"[VC]FUEL(FUEL)")==0)
					{
						tc_strcpy(sFuel,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sFuel,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sFuel);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"TRANSMISSION TYPE")==0)
					{
						tc_strcpy(sTrnsmsn,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sTrnsmsn,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sTrnsmsn);fflush(stdout);
					}
					if(tc_strcmp(theAttributeNames[ic],"[VC]EMMISSION_NORMS(EMMISSION_NORMS)")==0)
					{
						tc_strcpy(sEmmisnNrms,"");
						for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
						{
							tc_strcat(sEmmisnNrms,theAttributeValues[ic][xc]);
						}

						printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
						printf("\nkk.Attribute Value:[%s]",sEmmisnNrms);fflush(stdout);
					}
				}
			}
			
			if(lAreValsAdded == false)
			{
				cJSON_AddItemToObject(rfc_root, "vehicleTenant", Tenant_detail_req);
				cJSON_AddItemToObject(Tenant_detail_req, "tenantType", cJSON_CreateString(sProdLine));

				cJSON_AddItemToObject(Tenant_detail_req, "models", models_req);
				cJSON_AddItemToArray(models_req, single_model_req = cJSON_CreateObject());

				cJSON_AddItemToObject(single_model_req, "vehicleModelName", cJSON_CreateString(sMajorModel));
				cJSON_AddItemToObject(single_model_req, "platformName", cJSON_CreateString(sPlatform));
				cJSON_AddItemToObject(single_model_req, "modelType", cJSON_CreateString(sVehType));
				//cJSON_AddItemToObject(single_model_req, "modelReleaseYear", cJSON_CreateString(sModelRelYr));
				cJSON_AddItemToObject(single_model_req, "modelReleaseYear", cJSON_CreateNumber(nModelRelYr));
				cJSON_AddItemToObject(single_model_req, "variants", variants_req);
			
				lAreValsAdded = true;
			}
			
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"R") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000R");
			}
			else if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"L") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000L");
			}
			else
			{
				tc_strcpy(sVCNumDup,sVCNum);
			}
			printf("\nkk.VC Number is [%s]", sVCNumDup);
			if(ITEM_ask_latest_rev (tVehM,&tVehRv)!=ITK_ok);
			if (AOM_ask_value_string(tVehRv,"object_desc",&sVCDesc)!=ITK_ok);
			
			cJSON_AddItemToArray(variants_req, single_variant_req = cJSON_CreateObject());
			cJSON_AddItemToObject(single_variant_req, "vcNumber", cJSON_CreateString(sVCNumDup));
			cJSON_AddItemToObject(single_variant_req, "variantName", cJSON_CreateString(sVariant));
			cJSON_AddItemToObject(single_variant_req, "vcDescription", cJSON_CreateString(sVCDesc));
			cJSON_AddItemToObject(single_variant_req, "vcFuelType", cJSON_CreateString(sFuel));
			cJSON_AddItemToObject(single_variant_req, "vcTransmissionType", cJSON_CreateString(sTrnsmsn));
			cJSON_AddItemToObject(single_variant_req, "vcEmissionNorm", cJSON_CreateString(sEmmisnNrms));
			if(lHasTel == true)
			{
				//cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateString("true"));
				cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateTrue());
			}
			else
			{
				//cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateString("false"));
				cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateFalse());
			}
			if(lHasPeps == true)
			{
				//cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateString("true"));
				cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateTrue());
			}
			else
			{
				//cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateString("false"));
				cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateFalse());
			}
			//cJSON_AddItemToObject(single_variant_req, "variantReleaseYear", cJSON_CreateString(sVarRelYr));
			cJSON_AddItemToObject(single_variant_req, "variantReleaseYear", cJSON_CreateNumber(nVarRelYr));
			//cJSON_AddItemToObject(single_variant_req, "variantReleaseMonth", cJSON_CreateString(sVarRelMnth));
			cJSON_AddItemToObject(single_variant_req, "variantReleaseMonth", cJSON_CreateNumber(nVarRelMnth));
			cJSON_AddItemToObject(single_variant_req, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			cJSON_AddItemToObject(single_variant_req, "vcIdReleaseDate", cJSON_CreateString(sVCIDRelDate));
		}
	}
	
	MVI_out = cJSON_Print(rfc_root);
    printf("\n%s\n", MVI_out);
	
	FILE *fpMod = fopen("model-variant-input.json","w");
	if (fpMod != NULL)
	{
		fprintf(fpMod, "%s", MVI_out);
	}
	fclose(fpMod);
	free(MVI_out);
    cJSON_Delete(rfc_root);
	
	CLEANUP:
		printf("\nInside Model_Var_Input_St CLEANUP");fflush(stdout);
	return status;
}

int Ecu_Did_Param_Input_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, int nVcCnt, tag_t *tpVCItmList, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[], char *sParamPart, char *sParFileName)
{
	int status;
	int ifail;
	int iCntPC;
	int nCntPC;
	int iVCCnt;
	int iBmCnt;
	
	char *sVCNum = NULL;
	char *sVCNumTr = NULL;
	char *sVCNumDup = NULL;
	char *sVCIDNum = NULL;
	char *sChSwPrtTyp = NULL;
	char *sChSwPrtNum = NULL;
	char *sChECUTyp = NULL;
	char *DefVal = NULL;
	char *sHwNum = NULL;
	char *sParDidVal = NULL;
	char *sParDataTyp = NULL;
	char *sParRdWrt = NULL;
	char *sParName = NULL;
	char *sUsrEntVal = NULL;
	char *sChSwOtaCbpl = NULL;
	char *sChSwPrtAppl = NULL;
	char *sChSwPrtApplVal = NULL;
	char *sParAppl = NULL;
	char *sParApplVal = NULL;
	char *MVI_out;	
	
	cJSON *rfc_root;
	cJSON *veh_var;
	cJSON *veh_var_obj;
	cJSON *domains;
	cJSON *domains_obj;
	cJSON *ecu_arr;
	cJSON *ecu_obj;
	cJSON *didfl_arr;
	cJSON *didfl_obj;
	cJSON *par_arr;
	cJSON *par_obj;
	
	tag_t tVehM = NULLTAG;
	tag_t tEERel_type = NULLTAG;
	tag_t *tpParCls = NULLTAG;
	tag_t tParCls = NULLTAG;
	tag_t tParRelProp = NULLTAG;
	
	sVCIDNum =(char *) MEM_alloc(20);
	sVCNumDup =(char *) MEM_alloc(20);
	DefVal =(char *) MEM_alloc(10);
	sHwNum =(char *) MEM_alloc(10);
	
	rfc_root = cJSON_CreateObject();
	veh_var = cJSON_CreateArray();
	//domains = cJSON_CreateArray();
	//ecu_arr = cJSON_CreateArray();
	
	cJSON_AddItemToObject(rfc_root, "vehicleVariant", veh_var);
	
	tc_strcpy(DefVal,"DEFAULT");
	
	if(nVcCnt>0)
	{
		tc_strcpy(sVCIDNum,sInpVCID);
		tc_strcat(sVCIDNum,"-");
		tc_strcat(sVCIDNum,sInpVCIDRv);
		tc_strcat(sVCIDNum,sInpVCIDSq);
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"R") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000R");
			}
			else if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"L") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000L");
			}
			else
			{
				tc_strcpy(sVCNumDup,sVCNum);
			}
			printf("\nkk.VC Number is [%s]", sVCNumDup);
			
			cJSON_AddItemToArray(veh_var, veh_var_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(veh_var_obj, "vcNumber", cJSON_CreateString(sVCNumDup));
			cJSON_AddItemToObject(veh_var_obj, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			domains = cJSON_CreateArray();
			cJSON_AddItemToObject(veh_var_obj, "domains", domains);
			cJSON_AddItemToArray(domains, domains_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(domains_obj, "domainName",cJSON_CreateString(DefVal));
			ecu_arr = cJSON_CreateArray();
			cJSON_AddItemToObject(domains_obj, "ecus",ecu_arr);
			
			if(nBomPrtCnt>0)
			{
				for(iBmCnt=0; iBmCnt<=nBomPrtCnt; ++iBmCnt)
				{
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"item_id",&sChSwPrtNum)!=ITK_ok);
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_SwPartType",&sChSwPrtTyp)!=ITK_ok);
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_AppForEOL",&sChSwPrtAppl)!=ITK_ok);
					printf("\nkk.S/W Part Type:[%s,%s]",sChSwPrtNum,sChSwPrtTyp);fflush(stdout);
					if(tc_strcmp(sChSwPrtTyp,"PRM")==0 && tc_strcmp(sChSwPrtNum,sParamPart)==0)
					{
						lEcuDidParamInput = true;
						printf("\nkk.Parameter Found.");fflush(stdout);
						
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_EcuType",&sChECUTyp)!=ITK_ok);
						cJSON_AddItemToArray(ecu_arr, ecu_obj = cJSON_CreateObject());
						if(sChECUTyp != NULL)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString(sChECUTyp));
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString("NA"));
						}
						
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_OTACapable",&sChSwOtaCbpl)!=ITK_ok);
						if(tc_strcmp(sChSwOtaCbpl,"Yes")==0)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateTrue());
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateFalse());
						}
						
						sChSwPrtApplVal =(char *) MEM_alloc(10);
						GetApplicabilityVal(sChSwPrtAppl,&sChSwPrtApplVal);
						cJSON_AddItemToObject(ecu_obj, "ecuHardwareApplicabilityEolOrService", cJSON_CreateString(sChSwPrtApplVal));
						
						tc_strcpy(sHwNum,"NA");
						GetHwPrtForPar(sChSwPrtNum,sChECUTyp,&sHwNum,nBomPrtCnt,BomChldStrut);
						cJSON_AddItemToObject(ecu_obj, "ecuHardwarePartNumber", cJSON_CreateString(sHwNum));
						didfl_arr = cJSON_CreateArray();
						cJSON_AddItemToObject(ecu_obj, "didFiles",didfl_arr);
						cJSON_AddItemToArray(didfl_arr, didfl_obj = cJSON_CreateObject());
						cJSON_AddItemToObject(didfl_obj, "vcId", cJSON_CreateString(sInpVCID));
						par_arr = cJSON_CreateArray();
						cJSON_AddItemToObject(ecu_obj, "partitionSoftwareProperties",par_arr);
						
						ifail = GRM_find_relation_type("T5_EEPrm",&tEERel_type);
						if(tEERel_type != NULLTAG)
						{
							ifail = GRM_list_secondary_objects_only(BomChldStrut[iBmCnt].child_objs,tEERel_type,&nCntPC,&tpParCls);
							printf("\nkk.Count of parameter clauses [%d]",nCntPC); fflush(stdout);
							for(iCntPC=0; iCntPC<nCntPC; ++iCntPC)
							{
								tParCls = tpParCls[iCntPC];
								if(AOM_ask_value_string(tParCls,"t5_EPDidValue",&sParDidVal)!=ITK_ok);
								if(AOM_ask_value_string(tParCls,"t5_EPType",&sParDataTyp)!=ITK_ok);
								if(AOM_ask_value_string(tParCls,"t5_EPReadable",&sParRdWrt)!=ITK_ok);
								if(AOM_ask_value_string(tParCls,"t5_EPApplicable",&sParAppl)!=ITK_ok);
								if(AOM_ask_value_string(tParCls,"object_name",&sParName)!=ITK_ok);
								ifail = GRM_find_relation(BomChldStrut[iBmCnt].child_objs,tParCls,tEERel_type,&tParRelProp);
								ifail = AOM_ask_value_string(tParRelProp,"t5_BitValue",&sUsrEntVal);
								//printf("\nkk.DefValue is --------- [%s]\n",sUsrEntVal); fflush(stdout);
								
								cJSON_AddItemToArray(par_arr, par_obj = cJSON_CreateObject());
								cJSON_AddItemToObject(par_obj, "ecuDIDAddress", cJSON_CreateString(sParDidVal));
								cJSON_AddItemToObject(par_obj, "ecuDIDFormat", cJSON_CreateString(sParDataTyp));
								cJSON_AddItemToObject(par_obj, "ecuDIDReadWrite", cJSON_CreateString(sParRdWrt));
								sParApplVal =(char *) MEM_alloc(10);
								GetApplicabilityVal(sParAppl,&sParApplVal);
								cJSON_AddItemToObject(par_obj, "ecuDidApplicabilityEolOrService", cJSON_CreateString(sParApplVal));
								//cJSON_AddItemToObject(par_obj, "softwarePartitionType", cJSON_CreateString("Parameter"));
								cJSON_AddItemToObject(par_obj, "ecuDIDDescription", cJSON_CreateString(sParName));
								cJSON_AddItemToObject(par_obj, "ecuUserEnteredValue", cJSON_CreateString(sUsrEntVal));
							}
						}
					}
				}
			}
		}
	}
	
	MVI_out = cJSON_Print(rfc_root);
    printf("\n%s\n", MVI_out);
	
	if(lEcuDidParamInput == true)
	{
		printf("\nkk.Creating par file [%s]", sParFileName);
		FILE *fpDid = fopen(sParFileName,"w");
		if (fpDid != NULL)
		{
			fprintf(fpDid, "%s", MVI_out);
		}
		fclose(fpDid);
	}
	free(MVI_out);
    cJSON_Delete(rfc_root);
	
	CLEANUP:
		printf("\nInside Ecu_Did_Param_Input_St CLEANUP");fflush(stdout);
	return status;
}

int Ecu_Software_Release_Input_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, int nVcCnt, tag_t *tpVCItmList, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int status;
	int ifail;
	int iVCCnt;
	int iBmCnt;
	int nPrtCnt;
	int iPrtCnt;
	int istats;
	int iCnt;
	logical lIsParApplicbl;
	logical lIsPartInBom;
	logical lIsSwVerArrAdd;
	char *sVCIDNum = NULL;
	char *sVCNum = NULL;
	char *sVCNumTr = NULL;
	char *sVCNumDup = NULL;
	char *DefVal = NULL;
	char *sChECUTyp = NULL;
	char *sChSwPrtTyp = NULL;
	char *sSwVerVal = NULL;
	char *sSwVerRelDt = NULL;
	char *sSwVerFileNames = NULL;
	char *sCSwPrtTyp = NULL;
	char *sCHwPrtTyp = NULL;
	char *sChSwPrtNum = NULL;
	char *sChHwPrtNum = NULL;
	char *sChSwPrtRev = NULL;
	char *sChHwPrtRev = NULL;
	char *sChECUTypAbr = NULL;
	char *sChSwPrtNm = NULL;
	char *sVendr = NULL;
	char *sDIDArrr = NULL;
	char *sDIDFrmt = NULL;
	char *sDIDRdWr = NULL;
	char *sEcuDidFileName = NULL;
	char *sEcuDidFileCnt = NULL;
	char *sParPrtNum = NULL;
	char *sChECUAppl = NULL;
	char *sChECUApplVal = NULL;
	char *sChECUOtaCbpl = NULL;
	char *sChHwPrtAppl = NULL;
	char *sChHwPrtApplVal = NULL;
	char *sChSwOtaCpbl = NULL;
	char *sChSwAppl = NULL;
	char *sChSwApplVal = NULL;
	char *sChSwOwnUsr = NULL;
	char *MVI_out;
	
	tag_t tVehM = NULLTAG;
	tag_t tChildPrts = NULLTAG;
	tag_t tChldPrt = NULLTAG;
	tag_t tChHwPrt = NULLTAG;
	tag_t *tpChldPrt = NULLTAG;
	
	cJSON *rfc_root;
	cJSON *veh_var;
	cJSON *veh_var_obj;
	cJSON *domains;
	cJSON *domains_obj;
	cJSON *ecu_arr;
	cJSON *ecu_obj;
	cJSON *sw_ver_arr;
	cJSON *sw_ver_obj;
	cJSON *config_arr;
	cJSON *config_obj;
	
	sVCIDNum =(char *) MEM_alloc(25);
	sVCNumDup =(char *) MEM_alloc(25);
	DefVal =(char *) MEM_alloc(10);
	sChECUTypAbr =(char *) MEM_alloc(10);
	sSwVerVal =(char *) MEM_alloc(1000);
	sSwVerRelDt =(char *) MEM_alloc(50);
	sSwVerFileNames =(char *) MEM_alloc(500);
	sVendr =(char *) MEM_alloc(100);
	sDIDArrr =(char *) MEM_alloc(10);
	sDIDFrmt =(char *) MEM_alloc(10);
	sDIDRdWr =(char *) MEM_alloc(10);
	sEcuDidFileName =(char *) MEM_alloc(20);
	sEcuDidFileCnt =(char *) MEM_alloc(5);
	sParPrtNum =(char *) MEM_alloc(20);
	
	rfc_root = cJSON_CreateObject();
	veh_var = cJSON_CreateArray();
	//domains = cJSON_CreateArray();
	//ecu_arr = cJSON_CreateArray();
	
	
	cJSON_AddItemToObject(rfc_root, "vehicleVariant", veh_var);
	
	tc_strcpy(DefVal,"DEFAULT");
	
	if(nVcCnt>0)
	{
		tc_strcpy(sVCIDNum,sInpVCID);
		tc_strcat(sVCIDNum,"-");
		tc_strcat(sVCIDNum,sInpVCIDRv);
		tc_strcat(sVCIDNum,sInpVCIDSq);
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"R") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000R");
			}
			else if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"L") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000L");
			}
			else
			{
				tc_strcpy(sVCNumDup,sVCNum);
			}
			printf("\nkk.VC Number is [%s]", sVCNumDup);
			
			cJSON_AddItemToArray(veh_var, veh_var_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(veh_var_obj, "vcNumber", cJSON_CreateString(sVCNumDup));
			cJSON_AddItemToObject(veh_var_obj, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			domains = cJSON_CreateArray();
			cJSON_AddItemToObject(veh_var_obj, "domains", domains);
			cJSON_AddItemToArray(domains, domains_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(domains_obj, "domainName",cJSON_CreateString(DefVal));
			ecu_arr = cJSON_CreateArray();
			cJSON_AddItemToObject(domains_obj, "ecus",ecu_arr);
			
			if(nBomPrtCnt>0)
			{
				for(iBmCnt=0; iBmCnt<=nBomPrtCnt; ++iBmCnt)
				{
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"item_id",&sChSwPrtNm)!=ITK_ok);
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_SwPartType",&sChSwPrtTyp)!=ITK_ok);
					printf("\nkk.S/W Part Type of part %s is [%s]",sChSwPrtNm,sChSwPrtTyp);fflush(stdout);
					if(tc_strcmp(sChSwPrtTyp,"CON")==0)
					{
						tc_strcpy(sVendr,"NA");
						tc_strcpy(sDIDArrr,"NA");
						tc_strcpy(sDIDFrmt,"NA");
						tc_strcpy(sDIDRdWr,"NA");
						lEcuSoftwareReleaseInput = true;
						lIsParApplicbl = false;
						lIsSwVerArrAdd = false;
						printf("\nkk.Container Found.");fflush(stdout);
						tc_strcpy(sSwVerVal,"NA");
						
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_EcuType",&sChECUTyp)!=ITK_ok);
						for(iCnt=0; iCnt<iECU1; ++iCnt)
						{
							if(tc_strcmp((ECUTypFull)[iCnt],sChECUTyp)==0)
							{
								tc_strcpy(sChECUTypAbr,(ECUTypAbr)[iCnt]);
							}
						}
						GetParSwVerVal(sChSwPrtNm,sChECUTypAbr,&sSwVerVal,nBomPrtCnt,BomChldStrut);
						
						cJSON_AddItemToArray(ecu_arr, ecu_obj = cJSON_CreateObject());
						if(sChECUTyp != NULL)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString(sChECUTyp));
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString("NA"));
						}
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_AppForEOL",&sChECUAppl)!=ITK_ok);
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_OTACapable",&sChECUOtaCbpl)!=ITK_ok);
						sChECUApplVal =(char *) MEM_alloc(10);
						GetApplicabilityVal(sChECUAppl,&sChECUApplVal);
						cJSON_AddItemToObject(ecu_obj, "ecuApplicability", cJSON_CreateString(sChECUApplVal));
						if(tc_strcmp(sChECUOtaCbpl,"Yes")==0)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateTrue());
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateFalse());
						}
						cJSON_AddItemToObject(ecu_obj, "ecuVcId", cJSON_CreateString(sInpVCID));
						
						//"vendorName": "H65600:HELLA INDIA AUTOMOTIVE PVT LTD",
						//"ecuHardwarePartNumber": "546616212002",
						//"ecuHardwareType": "Hardware Control Module",
						//"ecuHardwareVersion": "NR1",
						//"plmdidfileName": "ecu1didfile.json",
						
						GetParVals(sChSwPrtNm,sChECUTypAbr,&sVendr,&sDIDArrr,&sDIDFrmt,&sDIDRdWr,nBomPrtCnt,BomChldStrut);
						cJSON_AddItemToObject(ecu_obj, "vendorName", cJSON_CreateString(sVendr));
						
						tChildPrts=BomChldStrut[iBmCnt].child_objs_bvr;
						istats = BOM_line_ask_child_lines (tChildPrts, &nPrtCnt, &tpChldPrt);
						printf("\nkk.Size of Container Childs:[%d]",nPrtCnt);fflush(stdout);
						
						for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
						{
							tChHwPrt = tpChldPrt[iPrtCnt];
							if( AOM_ask_value_string(tChHwPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sCHwPrtTyp)!=ITK_ok);
							if(tc_strcmp(sCHwPrtTyp,"HWC")==0)
							{
								if( AOM_ask_value_string(tChHwPrt,"bl_item_item_id",&sChHwPrtNum)!=ITK_ok);
								if( AOM_ask_value_string(tChHwPrt,"bl_rev_item_revision_id",&sChHwPrtRev)!=ITK_ok);
								if( AOM_ask_value_string(tChHwPrt,"bl_T5_EE_PartRevision_t5_AppForEOL",&sChHwPrtAppl)!=ITK_ok);
								printf("\nkk.HW Part number is :[%s,%s]",sChHwPrtNum,sChHwPrtRev);fflush(stdout);
								
								cJSON_AddItemToObject(ecu_obj, "ecuHardwarePartNumber", cJSON_CreateString(sChHwPrtNum));
								sChHwPrtApplVal =(char *) MEM_alloc(10);
								GetApplicabilityVal(sChHwPrtAppl,&sChHwPrtApplVal);
								cJSON_AddItemToObject(ecu_obj, "ecuHardwareApplicabilityEolOrService", cJSON_CreateString(sChHwPrtApplVal));
								cJSON_AddItemToObject(ecu_obj, "ecuHardwareType", cJSON_CreateString("Hardware Control Module"));
								cJSON_AddItemToObject(ecu_obj, "ecuHardwareVersion", cJSON_CreateString(sChHwPrtRev));
								break;
							}
						}
						
						//check if parameter file applicable & add below entry
						//iEcuDidFileCnt,ecu1didfile.json
						tc_strcpy(sParPrtNum,"NA");
						lIsParApplicbl = CheckIfParApplicbl(sChSwPrtNm,sChECUTyp,nBomPrtCnt,BomChldStrut,&sParPrtNum);
						if(lIsParApplicbl == true)
						{
							tc_strcpy(sEcuDidFileName,"ecu");
							sprintf(sEcuDidFileCnt,"%d",++iEcuDidFileCnt);
							tc_strcat(sEcuDidFileName,sEcuDidFileCnt);
							tc_strcat(sEcuDidFileName,"didfile.json");
							printf("\nkk.ECU DID file name is :[%s]",sEcuDidFileName);fflush(stdout);
							cJSON_AddItemToObject(ecu_obj, "plmdidfileName", cJSON_CreateString(sEcuDidFileName));
							Ecu_Did_Param_Input_St(sInpVCID,sInpVCIDRv,sInpVCIDSq,nVcCnt,tpVCItmList,nBomPrtCnt,BomChldStrut,sParPrtNum,sEcuDidFileName);
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "plmdidfileName", cJSON_CreateString("NA"));
						}
			  
						//sw_ver_arr = cJSON_CreateArray();
						//cJSON_AddItemToObject(ecu_obj, "partitionSoftwareVersions",sw_ver_arr);
						for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
						{
							lIsPartInBom = false;
							tChldPrt = tpChldPrt[iPrtCnt];
							if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sCSwPrtTyp)!=ITK_ok);
							if(tc_strcmp(sCSwPrtTyp,"APP")==0 || tc_strcmp(sCSwPrtTyp,"CAL")==0 || tc_strcmp(sCSwPrtTyp,"BAS")==0 || tc_strcmp(sCSwPrtTyp,"CFG")==0 || tc_strcmp(sCSwPrtTyp,"PBL")==0 || tc_strcmp(sCSwPrtTyp,"SBL")==0)
							{
								tc_strcpy(sSwVerRelDt,"NA");
								tc_strcpy(sSwVerFileNames,"NA");
								
								if( AOM_ask_value_string(tChldPrt,"bl_item_item_id",&sChSwPrtNum)!=ITK_ok);
								if( AOM_ask_value_string(tChldPrt,"bl_rev_item_revision_id",&sChSwPrtRev)!=ITK_ok);
								if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_OTACapable",&sChSwOtaCpbl)!=ITK_ok);
								if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_AppForEOL",&sChSwAppl)!=ITK_ok);
								printf("\nkk.SW Part number is :[%s,%s,%s]",sChSwPrtNum,sChSwPrtRev,sChSwOtaCpbl);fflush(stdout);
								
								lIsPartInBom = CheckIfPartInBom(sChSwPrtNum,nBomPrtCnt,BomChldStrut);
								
								if(lIsPartInBom == true)
								{
									if(lIsSwVerArrAdd == false)
									{
										sw_ver_arr = cJSON_CreateArray();
										cJSON_AddItemToObject(ecu_obj, "partitionSoftwareVersions",sw_ver_arr);
										lIsSwVerArrAdd = true;
									}
									
									cJSON_AddItemToArray(sw_ver_arr, sw_ver_obj = cJSON_CreateObject());
									if(tc_strcmp(sCSwPrtTyp,"APP")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Application Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"CAL")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Calibration Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"BAS")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Basic Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"CFG")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Configuration Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"PBL")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Primary Boot Loader"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"SBL")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionType", cJSON_CreateString("Secondary Boot Loader"));
									}
									
									if(tc_strcmp(sChSwOtaCpbl,"Yes")==0)
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwareOtaApplicable", cJSON_CreateTrue());
									}
									else
									{
										cJSON_AddItemToObject(sw_ver_obj, "softwareOtaApplicable", cJSON_CreateFalse());
									}
									cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionVersion", cJSON_CreateString(sSwVerVal));
									cJSON_AddItemToObject(sw_ver_obj, "softwarePartNumber", cJSON_CreateString(sChSwPrtNum));
									sChSwApplVal =(char *) MEM_alloc(10);
									GetApplicabilityVal(sChSwAppl,&sChSwApplVal);
									cJSON_AddItemToObject(sw_ver_obj, "softwareApplicabilityEolOrService", cJSON_CreateString(sChSwApplVal));
									
									GetPartRelDate(sChSwPrtNum,sChSwPrtRev,&sSwVerRelDt);
									cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionReleaseDate", cJSON_CreateString(sSwVerRelDt));
									
									if( AOM_ask_value_string(tChldPrt,"bl_rev_owning_user",&sChSwOwnUsr)!=ITK_ok);
									cJSON_AddItemToObject(sw_ver_obj, "releaseCocName", cJSON_CreateString(sChSwOwnUsr));
									
									GetSwFileNames(sChSwPrtNum,sChSwPrtRev,&sSwVerFileNames);
									cJSON_AddItemToObject(sw_ver_obj, "softwarePartitionFileName", cJSON_CreateString(sSwVerFileNames));
								}
							}
						}
						
						/*config_arr = cJSON_CreateArray();
						cJSON_AddItemToObject(ecu_obj, "configVersions",config_arr);
						cJSON_AddItemToArray(config_arr, config_obj = cJSON_CreateObject());
						
						lIsParApplicbl = CheckIfParApplicbl(sChSwPrtNm,sChECUTyp,nBomPrtCnt,BomChldStrut);
						if(lIsParApplicbl == true)
						{
							//cJSON_AddItemToObject(config_obj, "ecuParameterization", cJSON_CreateString("ecu-did-param-input.json"));
							cJSON_AddItemToObject(config_obj, "ecuParameterization", cJSON_CreateTrue());
						}
						else
						{
							//cJSON_AddItemToObject(config_obj, "ecuParameterization", cJSON_CreateString("NA"));
							cJSON_AddItemToObject(config_obj, "ecuParameterization", cJSON_CreateFalse());
						}
						cJSON_AddItemToObject(config_obj, "vcId", cJSON_CreateString(sInpVCID));*/
					}
				}
			}
		}
	}
	
	MVI_out = cJSON_Print(rfc_root);
    printf("\n%s\n", MVI_out);
	
	if(lEcuSoftwareReleaseInput == true)
	{
		FILE *fpSw = fopen("ecu-software-release-did-input.json","w");
		if (fpSw != NULL)
		{
			fprintf(fpSw, "%s", MVI_out);
		}
		fclose(fpSw);
	}
	
	free(MVI_out);
    cJSON_Delete(rfc_root);
	
	CLEANUP:
		printf("\nInside Ecu_Software_Release_Input_St CLEANUP");fflush(stdout);
	return status;
}

int Ecu_Data_Input_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, int nVcCnt, tag_t *tpVCItmList, int nBomPrtCnt, struct BomChldStrut_EE BomChldStrut[])
{
	int status;
	int ifail;
	int iVCCnt;
	int iBmCnt;
	int istats;
	int nPrtCnt;
	int iPrtCnt;
	int iCnt;
	logical lIsPartInBom;
	logical lIsSwArrAdded;
	char *sVCIDNum = NULL;
	char *sVCNum = NULL;
	char *sVCNumTr = NULL;
	char *sVCNumDup = NULL;
	char *DefVal = NULL;
	char *sChECUTyp = NULL;
	char *sChSwPrtNum = NULL;
	char *sChSwPrtTyp = NULL;
	char *sChHwPrtTyp = NULL;
	char *sCSwPrtTyp = NULL;
	char *sChHwPrtNum = NULL;
	char *sChHwPrtApplVal = NULL;
	char *sChHwPrtRev = NULL;
	char *sChHwPrtRevRpl = NULL;
	char *sChHwPrtAppl = NULL;
	char *sVendr = NULL;
	char *sDIDArrr = NULL;
	char *sDIDFrmt = NULL;
	char *sDIDRdWr = NULL;
	char *sEcuAbrNm = NULL;
	char *sToRpl = NULL;
	char *sToBeUsd = NULL;
	//char *sMstrHwNum = NULL;
	char *sChECUAppl = NULL;
	char *sChECUApplVal = NULL;
	char *sChECUOtaCbpl = NULL;
	char *MVI_out;
								
	tag_t tVehM = NULLTAG;
	tag_t tChildPrts = NULLTAG;
	tag_t tChildObj = NULLTAG;
	tag_t tChldPrt = NULLTAG;
	tag_t *tpChldPrt = NULLTAG;
	
	cJSON *rfc_root;
	cJSON *veh_var;
	cJSON *veh_var_obj;
	cJSON *domains;
	cJSON *domains_obj;
	cJSON *ecu_arr;
	cJSON *ecu_obj;
	cJSON *hw_obj;
	cJSON *sw_arr;
	//cJSON *ms_arr;
	cJSON *sw_obj;
	//cJSON *slv_obj;
	
	sVCIDNum =(char *) MEM_alloc(25);
	sVCNumDup =(char *) MEM_alloc(25);
	DefVal =(char *) MEM_alloc(10);
	sVendr =(char *) MEM_alloc(100);
	sDIDArrr =(char *) MEM_alloc(10);
	sDIDFrmt =(char *) MEM_alloc(10);
	sDIDRdWr =(char *) MEM_alloc(10);
	sEcuAbrNm =(char *) MEM_alloc(10);
	//sMstrHwNum =(char *) MEM_alloc(50);
	sToRpl = (char*)malloc(5);
	sToBeUsd = (char*)malloc(5);
	
	tc_strcpy(sToRpl,";");
	tc_strcpy(sToBeUsd,"");
	
	rfc_root = cJSON_CreateObject();
	veh_var = cJSON_CreateArray();
	//veh_var_obj = cJSON_CreateObject();
	//domains = cJSON_CreateArray();
	//domains_obj = cJSON_CreateObject();
	//ecu_arr = cJSON_CreateArray();
	//ecu_obj = cJSON_CreateObject();
	//hw_obj = cJSON_CreateObject();
	//sw_arr = cJSON_CreateArray();
	//sw_obj = cJSON_CreateObject();
	
	tc_strcpy(DefVal,"DEFAULT");
	
	cJSON_AddItemToObject(rfc_root, "vehicleVariant", veh_var);
	
	if(nVcCnt>0)
	{
		tc_strcpy(sVCIDNum,sInpVCID);
		tc_strcat(sVCIDNum,"-");
		tc_strcat(sVCIDNum,sInpVCIDRv);
		tc_strcat(sVCIDNum,sInpVCIDSq);
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"R") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000R");
			}
			else if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"L") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000L");
			}
			else
			{
				tc_strcpy(sVCNumDup,sVCNum);
			}
			printf("\nkk.VC Number is [%s]", sVCNumDup);
			
			cJSON_AddItemToArray(veh_var, veh_var_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(veh_var_obj, "vcNumber", cJSON_CreateString(sVCNumDup));
			cJSON_AddItemToObject(veh_var_obj, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			domains = cJSON_CreateArray();
			cJSON_AddItemToObject(veh_var_obj, "domains", domains);
			cJSON_AddItemToArray(domains, domains_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(domains_obj, "domainName",cJSON_CreateString(DefVal));
			ecu_arr = cJSON_CreateArray();
			cJSON_AddItemToObject(domains_obj, "ecus",ecu_arr);
			
			if(nBomPrtCnt>0)
			{
				for(iBmCnt=0; iBmCnt<=nBomPrtCnt; ++iBmCnt)
				{
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"item_id",&sChSwPrtNum)!=ITK_ok);
					if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_SwPartType",&sChSwPrtTyp)!=ITK_ok);
					printf("\nkk.S/W Part Type :[%s]",sChSwPrtTyp);fflush(stdout);
					if(tc_strcmp(sChSwPrtTyp,"CON")==0)
					{
						lEcuDataInput = true;
						lIsSwArrAdded = false;
						printf("\nkk.Container Found.");fflush(stdout);
						tc_strcpy(sVendr,"NA");
						tc_strcpy(sDIDArrr,"NA");
						tc_strcpy(sDIDFrmt,"NA");
						tc_strcpy(sDIDRdWr,"NA");
						
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_EcuType",&sChECUTyp)!=ITK_ok);
						cJSON_AddItemToArray(ecu_arr, ecu_obj = cJSON_CreateObject());
						if(sChECUTyp != NULL)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString(sChECUTyp));
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuType", cJSON_CreateString("NA"));
						}
						
						for(iCnt=0; iCnt<iECU1; ++iCnt)
						{
							if(tc_strcmp((ECUTypFull)[iCnt],sChECUTyp)==0)
							{
								tc_strcpy(sEcuAbrNm,(ECUTypAbr)[iCnt]);
								break;
							}
						}
						
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_AppForEOL",&sChECUAppl)!=ITK_ok);
						if( AOM_ask_value_string(BomChldStrut[iBmCnt].child_objs,"t5_OTACapable",&sChECUOtaCbpl)!=ITK_ok);
						sChECUApplVal =(char *) MEM_alloc(10);
						GetApplicabilityVal(sChECUAppl,&sChECUApplVal);
						cJSON_AddItemToObject(ecu_obj, "ecuApplicability", cJSON_CreateString(sChECUApplVal));
						if(tc_strcmp(sChECUOtaCbpl,"Yes")==0)
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateTrue());
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "ecuOtaCapable", cJSON_CreateFalse());
						}
						GetParVals(sChSwPrtNum,sEcuAbrNm,&sVendr,&sDIDArrr,&sDIDFrmt,&sDIDRdWr,nBomPrtCnt,BomChldStrut);
						
						cJSON_AddItemToObject(ecu_obj, "ecuAbbrName", cJSON_CreateString(sEcuAbrNm));
						if(tc_strcmp(sEcuAbrNm,"BCM")==0)
						{
							cJSON_AddItemToObject(ecu_obj, "vendorName", cJSON_CreateString("APTIV"));
						}
						else if(tc_strcmp(sEcuAbrNm,"TMC")==0)
						{
							cJSON_AddItemToObject(ecu_obj, "vendorName", cJSON_CreateString("HARMAN"));
						}
						else
						{
							cJSON_AddItemToObject(ecu_obj, "vendorName", cJSON_CreateString(sVendr));
						}
						//cJSON_AddItemToObject(ecu_obj, "ecuReport", cJSON_CreateString("true"));
						cJSON_AddItemToObject(ecu_obj, "ecuReport", cJSON_CreateTrue());
						cJSON_AddItemToObject(ecu_obj, "ecuVcId", cJSON_CreateString(sInpVCID));
						hw_obj = cJSON_CreateObject();
						cJSON_AddItemToObject(ecu_obj, "hardwareProperties", hw_obj);
						
						tChildPrts=BomChldStrut[iBmCnt].child_objs_bvr;
						tChildObj=BomChldStrut[iBmCnt].child_objs;
						istats = BOM_line_ask_child_lines (tChildPrts, &nPrtCnt, &tpChldPrt);
						printf("\nkk.Size of Container Childs :[%d]",nPrtCnt);fflush(stdout);
						for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
						{
							lIsPartInBom = false;
							tChldPrt = tpChldPrt[iPrtCnt];
							if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sChHwPrtTyp)!=ITK_ok);
							if(tc_strcmp(sChHwPrtTyp,"HWC")==0)
							{
								printf("\nkk.Hardware part found for ECU [%s]",sChECUTyp);fflush(stdout);
								if( AOM_ask_value_string(tChldPrt,"bl_item_item_id",&sChHwPrtNum)!=ITK_ok);
								if( AOM_ask_value_string(tChldPrt,"bl_rev_item_revision_id",&sChHwPrtRev)!=ITK_ok);
								ifail =(STRNG_replace_str(sChHwPrtRev,sToRpl,sToBeUsd,&sChHwPrtRevRpl));
								if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_AppForEOL",&sChHwPrtAppl)!=ITK_ok);
								lIsPartInBom = CheckIfPartInBom(sChHwPrtNum,nBomPrtCnt,BomChldStrut);
								
								if(lIsPartInBom == true)
								{
									cJSON_AddItemToObject(hw_obj, "ecuHardwarePartNumber", cJSON_CreateString(sChHwPrtNum));
									sChHwPrtApplVal =(char *) MEM_alloc(10);
									GetApplicabilityVal(sChHwPrtAppl,&sChHwPrtApplVal);
									cJSON_AddItemToObject(hw_obj, "ecuHardwareApplicabilityEolOrService", cJSON_CreateString(sChHwPrtApplVal));
									cJSON_AddItemToObject(hw_obj, "ecuHardwareType", cJSON_CreateString("Hardware Control Module"));
									cJSON_AddItemToObject(hw_obj, "ecuHardwareVersion", cJSON_CreateString(sChHwPrtRevRpl));
									
									//tc_strcpy(sMstrHwNum,"NA");
									GetMasterHwNum(tChildObj,&hw_obj,nBomPrtCnt,BomChldStrut);
									//cJSON_AddItemToObject(hw_obj, "MasterECU", cJSON_CreateString(sMstrHwNum));
									break;
								}
							}
						}
						//sw_arr = cJSON_CreateArray();
						//cJSON_AddItemToObject(ecu_obj, "partitionSoftwareProperties", sw_arr);
						for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
						{
							lIsPartInBom = false;
							tChldPrt = tpChldPrt[iPrtCnt];
							if( AOM_ask_value_string(tChldPrt,"bl_T5_EE_PartRevision_t5_SwPartType",&sCSwPrtTyp)!=ITK_ok);
							if(tc_strcmp(sCSwPrtTyp,"APP")==0 || tc_strcmp(sCSwPrtTyp,"CAL")==0 || tc_strcmp(sCSwPrtTyp,"BAS")==0 || tc_strcmp(sCSwPrtTyp,"CFG")==0 || tc_strcmp(sCSwPrtTyp,"PBL")==0 || tc_strcmp(sCSwPrtTyp,"SBL")==0)
							{
								if( AOM_ask_value_string(tChldPrt,"bl_item_item_id",&sChHwPrtNum)!=ITK_ok);
								if( AOM_ask_value_string(tChldPrt,"bl_rev_item_revision_id",&sChHwPrtRev)!=ITK_ok);
								
								lIsPartInBom = CheckIfPartInBom(sChHwPrtNum,nBomPrtCnt,BomChldStrut);
								if(lIsPartInBom == true)
								{
									if(lIsSwArrAdded == false)
									{
										sw_arr = cJSON_CreateArray();
										cJSON_AddItemToObject(ecu_obj, "partitionSoftwareProperties", sw_arr);
										lIsSwArrAdded = true;
									}
									
									cJSON_AddItemToArray(sw_arr, sw_obj = cJSON_CreateObject());
									if(tc_strcmp(sCSwPrtTyp,"APP")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Application Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"CAL")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Calibration Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"BAS")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Basic Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"CFG")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Configuration Software"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"PBL")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Primary Boot Loader"));
									}
									else if(tc_strcmp(sCSwPrtTyp,"SBL")==0)
									{
										cJSON_AddItemToObject(sw_obj, "softwarePartitionType", cJSON_CreateString("Secondary Boot Loader"));
									}
									cJSON_AddItemToObject(sw_obj, "partitionDIDAddress", cJSON_CreateString(sDIDArrr));
									cJSON_AddItemToObject(sw_obj, "partitionDIDFormat", cJSON_CreateString(sDIDFrmt));
									cJSON_AddItemToObject(sw_obj, "partitionDIDReadWrite", cJSON_CreateString(sDIDRdWr));
								}
							}
						}
					}
				}
			}
		}
	}
	
	MVI_out = cJSON_Print(rfc_root);
    printf("\n%s\n", MVI_out);
	
	if(lEcuDataInput == true)
	{
		FILE *fpEcu = fopen("ecu-data-input.json","w");
		if (fpEcu != NULL)
		{
			fprintf(fpEcu, "%s", MVI_out);
		}
		fclose(fpEcu);
	}
	
	free(MVI_out);
    cJSON_Delete(rfc_root);
	
	CLEANUP:
		printf("\nInside Ecu_Data_Input_St CLEANUP");fflush(stdout);
	return status;
}

int Ecu_Opt_Val_St(char *sInpVCID, char *sInpVCIDRv, char *sInpVCIDSq, int nVcCnt, tag_t *tpVCItmList)
{
	int status;
    int ifail;
	int ic = 0;
	int xc = 0;
	int iVCCnt = 0;
	int nSVRCnt = 0;
	char *sVCIDNum = NULL;
	char *sVCNumDup = NULL;
	char *sVCNum = NULL;
	char *sVCDesc = NULL;
	char *sAttrVal = NULL;
	char *MVI_out = NULL;
	char *sVCNumTr = NULL;
	char *sVarRlTxt = NULL;

	tag_t tVehM = NULLTAG;
	tag_t tVehRv = NULLTAG;
	tag_t tVehMCls = NULLTAG;
	tag_t tDervFrSVR = NULLTAG;
	tag_t tSVRObjs = NULLTAG;
	tag_t *tpSVRObjs = NULLTAG;

	int theAttributeCount =0;
	int *theAttributeIds;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char*** theAttributeValues = NULL;
	char*** theAttributeOptimizedUnits = NULL;

	cJSON *rfc_root;
	cJSON *veh_var;
	cJSON *veh_var_obj;
	cJSON *attrList;
	cJSON *attrs;
	cJSON *attrs_obj;

	sVCIDNum =(char *) MEM_alloc(25);
	sVCNumDup =(char *) MEM_alloc(25);
	sAttrVal =(char *) MEM_alloc(50);

	rfc_root = cJSON_CreateObject();
    veh_var = cJSON_CreateArray();

	cJSON_AddItemToObject(rfc_root, "vehicleVariant", veh_var);
	if(nVcCnt>0)
	{
		tc_strcpy(sVCIDNum,sInpVCID);
		tc_strcat(sVCIDNum,"-");
		tc_strcat(sVCIDNum,sInpVCIDRv);
		tc_strcat(sVCIDNum,sInpVCIDSq);
		for(iVCCnt=0; iVCCnt<nVcCnt; ++iVCCnt)
		{
			tVehM = tpVCItmList[iVCCnt];
			if (AOM_ask_value_string(tVehM,"item_id",&sVCNum)!=ITK_ok);
			if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"R") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000R");
			}
			else if(tc_strlen(sVCNum) == 9 && tc_strstr(sVCNum,"L") != NULL)
			{
				sVCNumTr = subString(sVCNum,0,8);
				tc_strcpy(sVCNumDup,sVCNumTr);
				tc_strcat(sVCNumDup,"000L");
			}
			else
			{
				tc_strcpy(sVCNumDup,sVCNum);
			}
			printf("\nkk.VC Number is: [%s]", sVCNumDup);
			if(ITEM_ask_latest_rev (tVehM,&tVehRv)!=ITK_ok);
			if (AOM_ask_value_string(tVehRv,"object_desc",&sVCDesc)!=ITK_ok);

			cJSON_AddItemToArray(veh_var, veh_var_obj = cJSON_CreateObject());
			cJSON_AddItemToObject(veh_var_obj, "vcNumber", cJSON_CreateString(sVCNumDup));
			cJSON_AddItemToObject(veh_var_obj, "vcDesc", cJSON_CreateString(sVCDesc));
			cJSON_AddItemToObject(veh_var_obj, "vcIdNumber", cJSON_CreateString(sVCIDNum));
			attrList = cJSON_CreateObject();
			cJSON_AddItemToObject(veh_var_obj, "AttributeList", attrList);
			attrs = cJSON_CreateArray();
			cJSON_AddItemToObject(attrList, "Attributes", attrs);

			ICS_ask_classification_object(tVehM,&tVehMCls);
			ITK_CALL(ICS_ico_ask_attributes_optimized(tVehMCls,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
			if(theAttributeCount>0)
			{
				lEcuOptVal = true;
				for(ic=0; ic<theAttributeCount; ++ic)
				{
					cJSON_AddItemToArray(attrs, attrs_obj = cJSON_CreateObject());
					cJSON_AddItemToObject(attrs_obj, "Name",cJSON_CreateString(theAttributeNames[ic]));
					tc_strcpy(sAttrVal,"");
					for(xc=0; xc<theAttributeValCounts[ic]; ++xc)
					{
							tc_strcat(sAttrVal,theAttributeValues[ic][xc]);
					}
					cJSON_AddItemToObject(attrs_obj, "Value",cJSON_CreateString(sAttrVal));

					printf("\nkk.Attribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
					printf("\nkk.Attribute Value:[%s]",sAttrVal);fflush(stdout);
				}
			}

			int nPrCnt = 0;
			int iPCnt = 0;
			int nResCnt = 0;
			int iRCnt = 0;
			int iVCnt = 0;
			int n_entOptFam = 1;
			int nEntOptFamVal = 2;
			int nResOptValCnt = 0;
			char *sPrObjTyp = NULL;
			char *sCfgCtxt = NULL;
			char *sOptValFamName = NULL;
			char *sOptValueName = NULL;
			char *sOptValueId = NULL;
			char *sVarExpr = NULL;
			sVarExpr = (char*) MEM_alloc(200);
			char *qry_entriesOptFam[] = {"ID"};
			char *qry_entriesOptFamVal[] = {"Thread ID","ID"};
			char **qry_valuesOptFam = (char **) MEM_alloc(10 * sizeof(char *));
			char **qry_valuesOptFamVal = (char **) MEM_alloc(10 * sizeof(char *));
			tag_t tPrmObj = NULLTAG;
			tag_t tObjTypPr = NULLTAG;
			tag_t *tpPrmObj = NULLTAG;
			tag_t tQryOptValFamly = NULLTAG;
			tag_t *tpOptValFam = NULLTAG;
			tag_t tOptValFam = NULLTAG;
			tag_t tQryOptFamVal = NULLTAG;
			tag_t tOptFamVal = NULLTAG;
			tag_t *tpOptFamVal = NULLTAG;
			ITKCALL(GRM_find_relation_type("T5_DerivedFromSVR",&tDervFrSVR));
			if(tDervFrSVR!=NULLTAG)
			{
				//TODO:Get latest Released vehicle
				ITK_CALL(GRM_list_secondary_objects_only(tVehRv,tDervFrSVR,&nSVRCnt,&tpSVRObjs));
				printf("\nkk.SVR count is [%d]",nSVRCnt);fflush(stdout);
				if(nSVRCnt>0)
				{
					tSVRObjs = tpSVRObjs[0];
					//if(AOM_ask_value_string(tSVRObjs,"cfg0VariantRuleText",&sVarRlTxt)!=ITK_ok);
					BSLV_get_variant_expression(NULLTAG,tSVRObjs,&sVarRlTxt);
					//printf("\nkk.Variant Rule text :\n%s",sVarRlTxt);fflush(stdout);
					printf("\nkk.Variant Rule length [%d] and text :\n%s",tc_strlen(sVarRlTxt),sVarRlTxt);fflush(stdout);
					
					ITK_CALL(GRM_list_primary_objects_only(tSVRObjs,NULLTAG,&nPrCnt,&tpPrmObj));
					printf("\nkk.Primary obj count [%d] ",nPrCnt);fflush(stdout);
					for(iPCnt=0; iPCnt<nPrCnt; ++iPCnt)
					{
						tPrmObj=tpPrmObj[iPCnt];							
						ITK_CALL(TCTYPE_ask_object_type(tPrmObj,&tObjTypPr));
						ITK_CALL(TCTYPE_ask_name2(tObjTypPr,&sPrObjTyp));	  
						printf( "\nkk.Obj type:%s\n",sPrObjTyp);
						if(tc_strcmp(sPrObjTyp,"Cfg0ProductItem")==0)
						{
							ITK_CALL(AOM_ask_value_string(tPrmObj,"item_id",&sCfgCtxt));
							printf("\nkk.Cft Ctxt item id is : %s\n",sCfgCtxt);
							break;
						}
					}
					
					if(QRY_find2("Cfg0OptionFamiliesFromIDs", &tQryOptValFamly));
					if(tQryOptValFamly)
					{
						qry_valuesOptFam[0] = sCfgCtxt;
						if(QRY_execute(tQryOptValFamly, n_entOptFam, qry_entriesOptFam, qry_valuesOptFam, &nResCnt, &tpOptValFam));
						printf("\nkk.Opt val famly count [%d]\n", nResCnt); fflush(stdout);
						for(iRCnt=0; iRCnt<nResCnt; ++iRCnt)
						{
							tOptValFam = tpOptValFam[iRCnt];
							if(AOM_ask_value_string(tOptValFam,"object_name",&sOptValFamName)!=ITK_ok);
							printf("\nkk.Opt val family name [%s]\n", sOptValFamName); fflush(stdout);

							if(QRY_find2("__Cfg0OptionValuesFromOptionFamilyIDs", &tQryOptFamVal));
							if(tQryOptFamVal)
							{
								qry_valuesOptFamVal[0]= sOptValFamName;
								qry_valuesOptFamVal[1]= sCfgCtxt;
								if(QRY_execute(tQryOptFamVal, nEntOptFamVal, qry_entriesOptFamVal, qry_valuesOptFamVal, &nResOptValCnt, &tpOptFamVal));
								for(iVCnt=0; iVCnt<nResOptValCnt; ++iVCnt)
								{
									tOptFamVal = tpOptFamVal[iVCnt];
									if(AOM_ask_value_string(tOptFamVal,"object_name",&sOptValueName)!=ITK_ok);
									if(AOM_ask_value_string(tOptFamVal,"cfg0ObjectId",&sOptValueId)!=ITK_ok);
									printf("\n\tkk.Opt value [%s,%s]\n", sOptValueName,sOptValueId); fflush(stdout);

									if(tc_strstr(sOptValFamName," ") != NULL)
									{
										tc_strcpy(sVarExpr,"'");
										tc_strcat(sVarExpr,sOptValFamName);
										tc_strcat(sVarExpr,"' = ");
									}
									else
									{
										tc_strcpy(sVarExpr,sOptValFamName);
										tc_strcat(sVarExpr," = ");
									}
									if(tc_strstr(sOptValueName," ") != NULL)
									{
										tc_strcat(sVarExpr,"'");
										tc_strcat(sVarExpr,sOptValueName);
										tc_strcat(sVarExpr,"'");
									}
									else
									{
										tc_strcat(sVarExpr,sOptValueName);
									}

									//TODO:Find only applicable option value.
									if(tc_strstr(sVarRlTxt,sVarExpr) != NULL)
									{
										cJSON_AddItemToArray(attrs, attrs_obj = cJSON_CreateObject());
										cJSON_AddItemToObject(attrs_obj, "Name",cJSON_CreateString(sOptValFamName));
										cJSON_AddItemToObject(attrs_obj, "Value",cJSON_CreateString(sOptValueName));
									}
								}
							}
						}
					}
				}
			}

			int iCPCnt = 0;
			int iMCnt = 0;
			int n_Input = 1;
			int n_InpCM = 1;
			int nClPrtCnt;
			int nClMstCnt;
			char *values[1];
			char *valuesCM[1];
			char *qry_Input[1] = {"ID"};
			char *qry_InpCM[1] = {"Colour Serial"};
			char *sVehQry = NULL;
			char *sClPrtName = NULL;
			char *sClMst = NULL;
			char *sClBsRed = NULL;
			char *sClBsGreen = NULL;
			char *sClBsBlue = NULL;
			char *sClBsRGB = NULL;
			char *sClMstObjStr = NULL;
			tag_t tClrPrtObjs = NULLTAG;
			tag_t tClrMstObjs = NULLTAG;
			tag_t *tpClrPrtObjs = NULLTAG;
			tag_t *tpClrMstObjs = NULLTAG;
			tag_t ProQryClPrt = NULLTAG;
			tag_t ProQryClMst = NULLTAG;
			sVehQry = (char*) MEM_alloc(20);
			sClBsRGB = (char*) MEM_alloc(20);
			if(QRY_find2("ClrPart", &ProQryClPrt));
			if(ProQryClPrt)
			{
				tc_strcpy(sVehQry,sVCNum);
				tc_strcat(sVehQry,"*");
				printf("\nkk.Querying Colour part [%s]", sVehQry);fflush(stdout);
				
				values[0] = sVehQry;
				if(QRY_execute(ProQryClPrt, n_Input, qry_Input, values, &nClPrtCnt, &tpClrPrtObjs));
				printf("\nkk.Colour part count is == %d", nClPrtCnt);fflush(stdout);
				for(iCPCnt=0; iCPCnt<nClPrtCnt; ++iCPCnt)
				{
					tClrPrtObjs = tpClrPrtObjs[iCPCnt];
					if(AOM_ask_value_string(tClrPrtObjs,"object_name",&sClPrtName)!=ITK_ok);
					printf("\nkk.processing Colour part [%s]", sClPrtName);fflush(stdout);
					sClMst = subString(sClPrtName,9,2);
					printf("\nkk.Colour Master is [%s]", sClMst);fflush(stdout);
					
					if(QRY_find2("ClrMaster", &ProQryClMst));
					if(ProQryClMst)
					{
						valuesCM[0] = sClMst;
						if(QRY_execute(ProQryClMst, n_InpCM, qry_InpCM, valuesCM, &nClMstCnt, &tpClrMstObjs));
						printf("\nkk.Colour Master count is == %d", nClMstCnt);fflush(stdout);
						for(iMCnt=0; iMCnt<nClMstCnt; ++iMCnt)
						{
							tClrMstObjs = tpClrMstObjs[iMCnt];
							if(AOM_ask_value_string(tClrMstObjs,"object_string",&sClMstObjStr)!=ITK_ok);
							if(AOM_ask_value_string(tClrMstObjs,"t5_BaseRed",&sClBsRed)!=ITK_ok);
							if(AOM_ask_value_string(tClrMstObjs,"t5_BaseGreen",&sClBsGreen)!=ITK_ok);
							if(AOM_ask_value_string(tClrMstObjs,"t5_BaseBlue",&sClBsBlue)!=ITK_ok);
							printf("\nkk.Clr Master [%s] RGB value [%s,%s,%s]",sClMstObjStr,sClBsRed,sClBsGreen,sClBsBlue);fflush(stdout);
							tc_strcpy(sClBsRGB,sClBsRed);
							tc_strcat(sClBsRGB,":");
							tc_strcat(sClBsRGB,sClBsGreen);
							tc_strcat(sClBsRGB,":");
							tc_strcat(sClBsRGB,sClBsBlue);
							printf("\nkk.Writing RGB value [%s]", sClBsRGB);fflush(stdout);
							
							cJSON_AddItemToArray(attrs, attrs_obj = cJSON_CreateObject());
							cJSON_AddItemToObject(attrs_obj, "Name",cJSON_CreateString(sClPrtName));
							cJSON_AddItemToObject(attrs_obj, "Value",cJSON_CreateString(sClBsRGB));
						}
					}
				}
			}
		}
	}

	MVI_out = cJSON_Print(rfc_root);
	printf("\n%s\n", MVI_out);

	if(lEcuOptVal == true)
	{
		FILE *fpOpt = fopen("ecu-optionval-input.json","w");
		if (fpOpt != NULL)
		{
			fprintf(fpOpt, "%s", MVI_out);
		}
		fclose(fpOpt);
	}

	free(MVI_out);
	cJSON_Delete(rfc_root);

	CLEANUP:
		printf("\nInside Ecu_Opt_Val_St CLEANUP");fflush(stdout);
	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}

extern int ITK_user_main (int argc, char ** argv )
{
	int status;
	int ifail;
	int iECnt;
	int nVCCnt;
	int level = 0;
	int nSnapCnt = 0;
	int nCntDML = 0;
	int iCntDML = 0;
	int iCPrt = 0;
	int nRelStatCnt = 0;
	int iRelStatCnt = 0;
	int iTskCnt = 0;
	int nTskCnt = 0;
	int iPrtCnt = 0;
	int nPrtCnt = 0;
	logical lSnHasTel = false;
	logical lSnHasPeps = false;
	char *sVCID = NULL;
	char *sRevSeq = NULL;
	char *sRevSeqDup = NULL;
	char *sRevnSeq = NULL;
	char *sVCIDRev = NULL;
	char *sVCIDSeq = NULL;
	char *info1ECUType = NULL;
	char *info2ECUType = NULL;
	char *sDmlType = NULL;
	char *sDML_name = NULL;
	char *sVCIDRelDt = NULL;
	date_t dVCIDRelDt;
	char *sRelStat = NULL;
	char *sTskType = NULL;
	char *sTskPrtNum = NULL;
	char *sRelPrtList = NULL;
	char *sUsr = NULL;
	char *sPswrd = NULL;
	char *sGrp = NULL;
	
	int n_Input = 3;
	int nVCIDCnt;
	char *values[3];
	char *qry_Input[3] = {"Item ID", "Type", "Revision"};
	tag_t *tpVCIDObjs = NULL;
	tag_t ProQryVCID = NULLTAG;
	
	int nECUTypeEnt = 2;
	int nECUTypCnt;
	char *qryInputECUType[2] = {"SYSCD", "SUBSYSCD"};
	char *qryProjValECUType[2] = {"ECU", "Mapping"};
	tag_t ECUTypeQuery = NULLTAG;
	tag_t *tpECUTypeCnObj = NULLTAG;
	
	tag_t tVCIDObj = NULLTAG;
	tag_t ReferencesCCVTag = NULLTAG;
	tag_t *tpVCItmObj = NULLTAG;
	tag_t tSnap = NULLTAG;
	tag_t tTopLine = NULLTAG;
	tag_t HasSnapshot_type = NULLTAG;
	tag_t *tpSnapObj = NULLTAG;
	tag_t tNewVCIDRel = NULLTAG;
	tag_t *tpDMLRev = NULLTAG;
	tag_t tDMLTypeTg = NULLTAG;
	tag_t *tpRelStatList = NULLTAG;
	tag_t tDMLToTskRel = NULLTAG;
	tag_t *tpTskObjs = NULLTAG;
	tag_t tTskType = NULLTAG;
	tag_t tTskPrt = NULLTAG;
	tag_t *tpPrtObjs = NULLTAG;
	
	int StructChldCnt = 0;
	struct BomChldStrut_EE	ChldStrutBdySh[5000];
	sRelPrtList = (char *) MEM_alloc(1000);
	
	//struct VehicleTenant VehTent[1];
	
	sRevSeqDup=(char *) MEM_alloc(10);
	sRevnSeq=(char *) MEM_alloc(10);
	ParaList			= (char**)MEM_alloc( 1 * sizeof *ParaList );
	ConatainerTypeListX = (char**)MEM_alloc( 5 * sizeof *ConatainerTypeListX );
	ConatainerList		= (char**)MEM_alloc( 1 * sizeof *ConatainerList );
	ConatainerRev		= (char**)MEM_alloc( 1 * sizeof *ConatainerRev );
	ECUTypFull = (char**)MEM_alloc( 1 * sizeof *ECUTypFull );
	ECUTypAbr = (char**)MEM_alloc( 1 * sizeof *ECUTypAbr );
	
	lEcuDataInput = false;
	lEcuSoftwareReleaseInput = false;
	lEcuDidParamInput = false;
	lEcuOptVal = false;

	(void)argc;
	(void)argv;

	initialise();
	
	status = ITK_auto_login();
	
	sUsr  = ITK_ask_cli_argument("-u=");
	sPswrd  = ITK_ask_cli_argument("-pf=");
	sGrp  = ITK_ask_cli_argument("-g=");

	if( ITK_init_module(sUsr,sPswrd,sGrp)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	sVCID  = ITK_ask_cli_argument("-i=");
	sRevSeq = ITK_ask_cli_argument("-r=");
	
	tc_strcpy(sRevSeqDup,sRevSeq);
	printf("\n sRevSeqDup == [%s]", sRevSeqDup);fflush(stdout);

	sVCIDRev = tc_strtok(sRevSeqDup,";");
	sVCIDSeq =tc_strtok(NULL,"");
	
	tc_strcpy(sRevnSeq,sVCIDRev);
	tc_strcat(sRevnSeq,"*");
	tc_strcat(sRevnSeq,sVCIDSeq);
	printf("\nkk.Rev and Seq = [%s]\n", sRevnSeq);fflush(stdout);
	
	if(tc_strcmp(sRevnSeq,"A*1")==0)
	{
		tc_strcpy(sRelPrtList,"ALL");
	}
	else
	{
		tc_strcpy(sRelPrtList,"NA,");
	}
	
	if(sVCID)
	{
		values[0] = sVCID;
		values[1] = "VCID Revision";
		values[2] = sRevnSeq;

		if(QRY_find2("Item Revision...", &ProQryVCID));
		if(ProQryVCID)
		{
			 if(QRY_execute(ProQryVCID, n_Input, qry_Input, values, &nVCIDCnt, &tpVCIDObjs));
			 printf("\nkk.VCID count is == %d", nVCIDCnt);fflush(stdout);
		}

		if(nVCIDCnt == 0)
		{
			printf ("\nkk.VCID %s is not found!!!\n", sVCID); fflush(stdout);
			exit(0);
		}
		
		if(nVCIDCnt>0)
		{
			tVCIDObj = tpVCIDObjs[0];
			
			if(QRY_find2("ControlObjQry",&ECUTypeQuery));
			if(ECUTypeQuery)
			{
				 if(QRY_execute(ECUTypeQuery, nECUTypeEnt, qryInputECUType, qryProjValECUType, &nECUTypCnt, &tpECUTypeCnObj));
				 printf("\n CONT for ECUTypeQuery CntrlObj == %d\n", nECUTypCnt);fflush(stdout);
			}
			else
			{
				printf("\n ContrlObj for ECUTypeQuery not found.");fflush(stdout);
			}
			if(nECUTypCnt >0)
			{
				for(iECnt=0; iECnt<nECUTypCnt; ++iECnt)
				{
					if (AOM_ask_value_string(tpECUTypeCnObj[iECnt],"t5_Userinfo1",&info1ECUType)!=ITK_ok);
					printf("\n  info1ECUType [%s]",info1ECUType); fflush(stdout);
					setAddStr(&iECU1,&ECUTypFull,info1ECUType);

					if (AOM_ask_value_string(tpECUTypeCnObj[iECnt],"t5_Userinfo2",&info2ECUType)!=ITK_ok);
					printf("\n info2ECUType [%s]",info2ECUType); fflush(stdout);
					setAddStr(&iECU2,&ECUTypAbr,info2ECUType);
				}
			}
			
			ITKCALL(GRM_find_relation_type("T5_HasNewCCID",&tNewVCIDRel));
			if(tNewVCIDRel!=NULLTAG)
			{
				printf("\n Hs new VCID rel found \n ");fflush(stdout);
				GRM_list_primary_objects_only(tVCIDObj,tNewVCIDRel,&nCntDML,&tpDMLRev);
				printf("\nkk.No of DML FOUND [%d]",nCntDML);fflush(stdout);
				if(nCntDML>0)
				{
					for(iCntDML=0; iCntDML<nCntDML; ++iCntDML)
					{
						if(TCTYPE_ask_object_type(tpDMLRev[iCntDML],&tDMLTypeTg));
						if(TCTYPE_ask_name2(tDMLTypeTg,&sDmlType));
						printf("\nkk.class of DML [%s]",sDmlType);fflush(stdout);
						if(tc_strcmp(sDmlType,"ChangeRequestRevision")==0)
						{
							ITKCALL(AOM_ask_value_string(tpDMLRev[iCntDML],"item_id",&sDML_name));
							ITKCALL(WSOM_ask_release_status_list(tpDMLRev[iCntDML],&nRelStatCnt,&tpRelStatList));
							printf("\nkk.Release status count is [%d]", nRelStatCnt);fflush(stdout);
							if(nRelStatCnt>0)
							{
								for(iRelStatCnt=0; iRelStatCnt<nRelStatCnt; ++iRelStatCnt)
								{
									ITKCALL(AOM_ask_value_string(tpRelStatList[iRelStatCnt],"object_name",&sRelStat));
									printf("\nkk.Release Status Val [%s]", sRelStat);fflush(stdout);
									if(tc_strstr(sRelStat,"ERC Released")!=NULL || tc_strstr(sRelStat,"T5_LcsErcRlzd")!=NULL)
									{
										//ITKCALL(AOM_ask_value_string(tpRelStatList[iRelStatCnt],"date_released",&sVCIDRelDt));
										ITKCALL(AOM_ask_value_date(tpRelStatList[iRelStatCnt],"date_released",&dVCIDRelDt));
										if(ITK_ok != (ifail = DATE_date_to_string(dVCIDRelDt,"%d-%b-%Y %H:%M",&sVCIDRelDt )))
										{
											return ifail;
										}
									}
								}
							}
							printf("\nkk.Closure date of DML %s is [%s]",sDML_name,sVCIDRelDt);fflush(stdout);
							
							if(tc_strcmp(sRevnSeq,"A*1")!=0)
							{
								ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&tDMLToTskRel));
								ITK_CALL(GRM_list_secondary_objects_only(tpDMLRev[iCntDML],tDMLToTskRel,&nTskCnt,&tpTskObjs));
								for(iTskCnt=0; iTskCnt<nTskCnt; ++iTskCnt)
								{
									if(TCTYPE_ask_object_type(tpTskObjs[iTskCnt],&tTskType));
									if(TCTYPE_ask_name2(tTskType,&sTskType));
									printf("\nkk.class of Task [%s]",sTskType);fflush(stdout);
									if(tc_strcmp(sTskType,"T5_ChangeTaskRevision")==0)
									{
										ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&tTskPrt));
										if(tTskPrt!=NULLTAG)
										{
											ITK_CALL(GRM_list_secondary_objects_only(tpTskObjs[iTskCnt],tTskPrt,&nPrtCnt,&tpPrtObjs));
											for(iPrtCnt=0; iPrtCnt<nPrtCnt; ++iPrtCnt)
											{
												if(AOM_ask_value_string(tpPrtObjs[iPrtCnt],"item_id",&sTskPrtNum)!=ITK_ok);
												printf("\nkk.Part attached to task is [%s]",sTskPrtNum);fflush(stdout);
												tc_strcat(sRelPrtList,sTskPrtNum);
												tc_strcat(sRelPrtList,",");
											}
										}
									}
								}
								printf("\nkk.List of released parts [%s]",sRelPrtList);fflush(stdout);
							}
						}
					}
				}
			}
			
			ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&HasSnapshot_type); 
			ifail = GRM_list_secondary_objects_only(tVCIDObj,HasSnapshot_type,&nSnapCnt,&tpSnapObj);
			printf("\nkk.Snapshot count [%d] -------> \n",nSnapCnt);fflush(stdout);
			if(nSnapCnt>0)
			{
				tSnap = tpSnapObj[0];
				ITKCALL(AOM_ask_value_tag(tSnap,"topLine",&tTopLine));
				Multi_Get_Part_BOM_Lvl(tTopLine,99,level,tSnap,ChldStrutBdySh,&StructChldCnt,"NA",sRelPrtList);
				printf ("\nkk.Child Count [%d] \n",StructChldCnt);fflush(stdout);
				Container_List(tSnap);
			}
			
			for(iCPrt=0; iCPrt<=StructChldCnt; ++iCPrt)
			{
				char *sConPTyp = NULL;
				char *sConPart = NULL;
				char *sConEcuTyp = NULL;
				char *sConSwPTyp = NULL;
				if(AOM_ask_value_string(ChldStrutBdySh[iCPrt].child_objs,"object_type",&sConPTyp)!=ITK_ok);
				if(AOM_ask_value_string(ChldStrutBdySh[iCPrt].child_objs,"item_id",&sConPart)!=ITK_ok);
				printf ("\nkk.[part,class] [%s,%s]",sConPart,sConPTyp);fflush(stdout);
				if(tc_strcmp(sConPTyp,"T5_EE_PartRevision")==0)
				{
					
					if(AOM_ask_value_string(ChldStrutBdySh[iCPrt].child_objs,"t5_EcuType",&sConEcuTyp)!=ITK_ok);
					if(AOM_ask_value_string(ChldStrutBdySh[iCPrt].child_objs,"t5_SwPartType",&sConSwPTyp)!=ITK_ok);
					printf ("\nkk.[ECU Type,SW Part Type] [%s,%s] \n",sConEcuTyp,sConSwPTyp);fflush(stdout);
					if(tc_strcmp(sConSwPTyp,"CON")==0 && tc_strcmp(sConEcuTyp,"Telematics")==0)
					{
						lSnHasTel = true;
					}
					else if(tc_strcmp(sConSwPTyp,"CON")==0 && tc_strcmp(sConEcuTyp,"Passive Entry Passive Start")==0)
					{
						lSnHasPeps = true;
					}
				}
			}
			
			ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&ReferencesCCVTag));
			ITK_CALL(GRM_list_secondary_objects_only(tVCIDObj,ReferencesCCVTag,&nVCCnt,&tpVCItmObj));
			printf("\nkk.VC count is [%d]\n",nVCCnt); fflush(stdout);
			
			Get_Prod_Line_Category(sVCID,sVCIDRev,sVCIDSeq,nVCCnt,tpVCItmObj);
			if(tc_strcmp(sRevSeq,"A;1")==0)
			{
				Model_Var_Input_St(sVCID,sVCIDRev,sVCIDSeq,sVCIDRelDt,lSnHasTel,lSnHasPeps,nVCCnt,tpVCItmObj);
				Ecu_Opt_Val_St(sVCID,sVCIDRev,sVCIDSeq,nVCCnt,tpVCItmObj);
			}
			//if data is blank, don't create files & consider child part if present in release.
			Ecu_Data_Input_St(sVCID,sVCIDRev,sVCIDSeq,nVCCnt,tpVCItmObj,StructChldCnt,ChldStrutBdySh);
			Ecu_Software_Release_Input_St(sVCID,sVCIDRev,sVCIDSeq,nVCCnt,tpVCItmObj,StructChldCnt,ChldStrutBdySh);
			//Ecu_Did_Param_Input_St(sVCID,sVCIDRev,sVCIDSeq,nVCCnt,tpVCItmObj,StructChldCnt,ChldStrutBdySh);
		}
	}
	
	printf("\nkk...VCID NIO Data Generation Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}
