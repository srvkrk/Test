#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<cJSON.h>

int main()
{
	cJSON *rfc_root;
	cJSON *Tenant_detail_req;
	cJSON *single_model_req;
	cJSON *models_req;
	cJSON *single_variant_req;
	cJSON *variants_req;
	char *out;

	
	rfc_root = cJSON_CreateObject();
	Tenant_detail_req = cJSON_CreateObject();
	
	single_model_req = cJSON_CreateObject();
	models_req = cJSON_CreateArray();
	
	single_variant_req = cJSON_CreateObject();
	variants_req = cJSON_CreateArray();
	
	
	
	cJSON_AddItemToObject(rfc_root, "vehicleTenant", Tenant_detail_req);
	//cJSON_AddItemToObject(rfc_root, "tenantType", cJSON_CreateString("EV"));
	cJSON_AddItemToObject(Tenant_detail_req, "tenantType", cJSON_CreateString("EV"));
	
	cJSON_AddItemToObject(Tenant_detail_req, "models", models_req);
	cJSON_AddItemToArray(models_req, single_model_req = cJSON_CreateObject());
	
	cJSON_AddItemToObject(single_model_req, "vehicleModelName", cJSON_CreateString("TATA HARRIER EV"));
	cJSON_AddItemToObject(single_model_req, "platformName", cJSON_CreateString("Q5"));
	cJSON_AddItemToObject(single_model_req, "modelType", cJSON_CreateString("HARRIER EV"));
	cJSON_AddNumberToObject(single_model_req, "modelReleaseYear", 2022);
	
	cJSON_AddItemToObject(single_model_req, "variants", variants_req);
	cJSON_AddItemToArray(variants_req, single_variant_req = cJSON_CreateObject());
	
	cJSON_AddItemToObject(single_variant_req, "vcNumber", cJSON_CreateString("54731927000R"));
	cJSON_AddItemToObject(single_variant_req, "variantName", cJSON_CreateString("ETURNA-LR FEARLESS +"));
	cJSON_AddItemToObject(single_variant_req, "vcFuelType", cJSON_CreateString("PURE EV"));
	cJSON_AddItemToObject(single_variant_req, "vcTransmissionType", cJSON_CreateString("AUTOMATIC"));
	cJSON_AddItemToObject(single_variant_req, "vcEmissionNorm", cJSON_CreateString("NA"));
	cJSON_AddItemToObject(single_variant_req, "isConnectedCar", cJSON_CreateString("true"));
	cJSON_AddItemToObject(single_variant_req, "hasPeps", cJSON_CreateString("false"));
	cJSON_AddNumberToObject(single_variant_req, "variantReleaseYear", 2022);
	cJSON_AddNumberToObject(single_variant_req, "variantReleaseMonth", 9);
	cJSON_AddItemToObject(single_variant_req, "vcIdNumber", cJSON_CreateString("5473E4Z01006_01_E9"));
	cJSON_AddItemToObject(single_variant_req, "vcIdReleaseDate", cJSON_CreateString("2025-03-04T11:48:00Z"));
	
	
	out = cJSON_Print(rfc_root);
	printf("%s\n", out);
	
	FILE *fp = fopen("vehicleTenant.json","w");
	
	if ( fp != NULL )
	{
		
		fprintf(fp, "%s", out);
	
	}
	
	fclose(fp);
	fp = NULL;
	
	free(out);
	cJSON_Delete(rfc_root);
	return 0;
	
}