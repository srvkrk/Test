echo "compiling..."
./compile VCID_NIO_Data_Transfer.c
exit_stat=$?
if [ $exit_stat == 0 ]; then
echo "linking..."
./linkitk -o VCID_NIO_Data_Transfer VCID_NIO_Data_Transfer.o
#exit_stat1=$?
#else
#exit_stat1=-1
fi
#if [ $exit_stat1 == 0 ]; then
#echo "patching..."
#/home/erc3dev/Teamcenter14/TC_ROOT/tcldPatch/tcPatchExecutable VCID_NIO_Data_Transfer
#fi

