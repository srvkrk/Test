#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>
#include<ics/ics2.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void initialise (void);

int Getmailid(char *sUser, char **sUserMail)
{
	int ifail;
	int status;
	char *sFStr = NULL;
	char *sSStr = NULL;
	tag_t tUsr = NULLTAG;
	tag_t tPrsn = NULLTAG;
	
	sFStr = tc_strtok(sUser,"(");
	sSStr = tc_strtok(NULL,")");
	printf("\nkk.Getting mail of user id [%s]",sSStr); fflush(stdout);
	
	ITK_CALL(SA_find_user2(sSStr,&tUsr));
	ITK_CALL(SA_ask_user_person(tUsr,&tPrsn));
	ITK_CALL(SA_ask_person_email_address(tPrsn,sUserMail));
}

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	int iVCnt = 0;
	int nVCIDCnt = 0;
	int nRefVCCnt = 0;
	int nPrtcpntCnt = 0;
	int iPCnt = 0;
	char *sDmlNum = NULL;
	char *sVCIDNum = NULL;
	char *sVCIDRev = NULL;
	char *sFileName = NULL;
	char *sMailFileNm = NULL;
	char *sVCIDNo = NULL;
	char *sVCIDRv = NULL;
	char *sUser = NULL;
	char *sPassFl = NULL;
	char *sGrp = NULL;
	char *sTypName = NULL;
	char *sCERevr = NULL;
	char *sReqEmailID = NULL;
	char *qry_Input[1] = {"ID"};
	char *values[1];
	tag_t newVcidRel = NULLTAG;
	tag_t RefCCVTag = NULLTAG;
	tag_t *tpVCIDs = NULLTAG;
	tag_t *tpRefVC = NULLTAG;
	tag_t tDml = NULLTAG;
	tag_t tVCIDs = NULLTAG;
	tag_t tHsPrtcpntRel = NULLTAG;
	tag_t *tpPrtcpnt = NULLTAG;
	tag_t tPrtcpt = NULLTAG;
	tag_t tPrtcptTyp = NULLTAG;
	
	int n_Input = 1;
	int nDmlCnt = 0;
	tag_t qryDml = NULLTAG;
	tag_t *tpDml = NULLTAG;
	
	FILE *fptr;
	FILE *fptrM;

	(void)argc;
	(void)argv;

	initialise();

	sUser = ITK_ask_cli_argument("-u=");
	sPassFl = ITK_ask_cli_argument("-pf=");
	sGrp = ITK_ask_cli_argument("-g=");
	sDmlNum = ITK_ask_cli_argument("-dml=");

	iStatus = ITK_auto_login();

	if( ITK_init_module(sUser,sPassFl,sGrp)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sFileName =(char *) MEM_alloc(100);
	sMailFileNm =(char *) MEM_alloc(100);
	printf("\nkk.Getting VCID List from DML [%s]",sDmlNum); fflush(stdout);
	values[0] = sDmlNum;
	
	if(QRY_find2("ERC DML", &qryDml));
	if(qryDml)
	{
		if(QRY_execute(qryDml, n_Input, qry_Input, values, &nDmlCnt, &tpDml));
		printf("\nkk.Count of DML [%d]", nDmlCnt);fflush(stdout);
		if(nDmlCnt > 0)
		{
			tDml = tpDml[0];
			ITKCALL(GRM_find_relation_type("T5_HasNewCCID",&newVcidRel)); 
			ITKCALL(GRM_find_relation_type("HasParticipant",&tHsPrtcpntRel)); 
			if(tHsPrtcpntRel != NULLTAG)
			{
				tc_strcpy(sMailFileNm,"/tmp/");
				tc_strcat(sMailFileNm,sDmlNum);
				tc_strcat(sMailFileNm,"_ECUMailList.csv");
				fptrM = fopen(sMailFileNm,"w");
				if(fptrM == NULL)
				{
					printf("Error in file opening!!! %s",sMailFileNm); fflush(stdout);
					exit(1);
				}
					
				ITKCALL(GRM_list_secondary_objects_only(tDml,tHsPrtcpntRel,&nPrtcpntCnt,&tpPrtcpnt));
				printf("\nkk.DML participant's count is [%d]", nPrtcpntCnt);fflush(stdout);
				if(nPrtcpntCnt > 0)
				{
					for(iPCnt=0; iPCnt<nPrtcpntCnt; ++iPCnt)
					{
						tPrtcpt = tpPrtcpnt[iPCnt];
						ITKCALL(TCTYPE_ask_object_type(tPrtcpt,&tPrtcptTyp));
						ITKCALL(TCTYPE_ask_name2(tPrtcptTyp,&sTypName));
						ITKCALL(AOM_UIF_ask_value(tPrtcpt,"fnd0AssigneeUser",&sCERevr));
						printf("\nkk.Type name,participant [%s,%s]", sTypName,sCERevr);fflush(stdout);
						if(tc_strcmp(sTypName,"Requestor")==0)
						{
							Getmailid(sCERevr,&sReqEmailID);
							printf("\nkk.User Mail of [%s] is [%s]", sTypName,sReqEmailID);fflush(stdout);
							fprintf(fptrM,"%s,",sReqEmailID);fflush(fptrM);
						}
					}
				}
			}
			/*tag_t TaskFlow = NULLTAG;
			if(QRY_find2("Audit - Workflow General_TML",&TaskFlow));
			if(TaskFlow != NULLTAG)
			{
				int nDmlResCnt = 0;
				int iDCnt = 0;
				char    *TaskFlow_qry_entry[2]  = {"Job Name","Name"};
				char    **TaskFlow_qry_values     =  (char **) MEM_alloc(100 * sizeof(char *));
				TaskFlow_qry_values[0] = sDmlNum;
				TaskFlow_qry_values[1] = "CVBU CE Review";
				char *EventTypeName = NULL;
				char *TaskState = NULL;
				char *TaskResult = NULL;
				tag_t tDmlJbs = NULLTAG;
				tag_t *tpDmlResObjs = NULLTAG;
				if(QRY_execute(TaskFlow, 2, TaskFlow_qry_entry, TaskFlow_qry_values,&nDmlResCnt,&tpDmlResObjs));
				printf("\nkk.Count is:[%d]\n",nDmlResCnt);fflush(stdout);
				if(nDmlResCnt>0)
				{
					for(iDCnt=0; iDCnt<nDmlResCnt; ++iDCnt)
					{
						tDmlJbs = tpDmlResObjs[iDCnt];
						AOM_ask_value_string(tDmlJbs,"fnd0EventTypeName",&EventTypeName);
						AOM_ask_value_string(tDmlJbs,"task_state",&TaskState);
						AOM_ask_value_string(tDmlJbs,"task_result",&TaskResult);
						printf("\nkk.[Event, state, result] : [%s,%s,%s]\n",EventTypeName,TaskState,TaskResult);fflush(stdout);
					}
				}
			}*/
			if(newVcidRel != NULLTAG)
			{
				ITKCALL(GRM_list_secondary_objects_only(tDml,newVcidRel,&nVCIDCnt,&tpVCIDs));
				printf("\nkk.Number of VCIDs are [%d]", nVCIDCnt);fflush(stdout);
				if(nVCIDCnt > 0)
				{
					tc_strcpy(sFileName,"/tmp/");
					tc_strcat(sFileName,sDmlNum);
					tc_strcat(sFileName,"_DataChk.csv");
					fptr = fopen(sFileName,"w");
					if(fptr == NULL)
					{
						printf("Error in file opening!!! %s",sFileName); fflush(stdout);
						exit(1);
					}
					
					for(iVCnt=0; iVCnt<nVCIDCnt; ++iVCnt)
					{
						tVCIDs = tpVCIDs[iVCnt];
						ITK_CALL(AOM_ask_value_string(tVCIDs,"item_id",&sVCIDNum));
						ITK_CALL(AOM_ask_value_string(tVCIDs,"item_revision_id",&sVCIDRev));
						printf("\nkk.[VCID Number, Rev] [%s,%s]", sVCIDNum,sVCIDRev);fflush(stdout);
						ifail =(STRNG_replace_str(sVCIDNum, "_", "",&sVCIDNo));
						ifail =(STRNG_replace_str(sVCIDRev, ";", "",&sVCIDRv));
						printf("\nkk.[VCID Number, Rev] [%s,%s]", sVCIDNo,sVCIDRv);fflush(stdout);
						ITK_CALL(GRM_find_relation_type("T5_ReferencesCCV",&RefCCVTag));
						ITK_CALL(GRM_list_secondary_objects_only(tVCIDs,RefCCVTag,&nRefVCCnt,&tpRefVC));
						if(nRefVCCnt > 0)
						{
							fprintf(fptr,"%s,%s,Ref_CVV\n",sVCIDNo,sVCIDRv);fflush(fptr);
						}
						else
						{
							fprintf(fptr,"%s,%s,No_Ref_CCV\n",sVCIDNo,sVCIDRv);fflush(fptr);
						}
					}
				}
			}
		}
	}
	

	printf("\nkk...Send mail code Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

}
