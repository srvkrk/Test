#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
//static void initialise_attribute (char *name,  int *attribute);

char* sVCID1	= NULL;
char* sVCID2	= NULL;
char* sVCIDVer1	= NULL;
char* sVCIDVer2	= NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

int IsVCIDRevLatest(char *sVCIDNumber,char *sVCIDRevSeq,logical *lIsVCIDLatest)
{
	int status;
	char *sLtstVCIDNum = NULL;
	char *sLtstVCIDRevSeq = NULL;
	tag_t tDesgVCID = NULLTAG;
	tag_t tVCIDLtstRev = NULLTAG;

	ITK_CALL(ITEM_find_item(sVCIDNumber,&tDesgVCID));
	ITK_CALL(ITEM_ask_latest_rev(tDesgVCID,&tVCIDLtstRev));
	if(tVCIDLtstRev != NULLTAG)
	{
		if(AOM_ask_value_string(tVCIDLtstRev,"item_id",&sLtstVCIDNum)!=ITK_ok);
		if(AOM_ask_value_string(tVCIDLtstRev,"item_revision_id",&sLtstVCIDRevSeq)!=ITK_ok);
		printf("\nkk.Latest VCID is [%s,%s]",sLtstVCIDNum,sLtstVCIDRevSeq);fflush(stdout);
		if(tc_strcmp(sVCIDNumber,sLtstVCIDNum)==0 && tc_strcmp(sVCIDRevSeq,sLtstVCIDRevSeq)==0)
		{
			printf("\nkk.Latest VCID Found.");fflush(stdout);
			*lIsVCIDLatest = true;
		}
	}
	return 0;
}

int QueryVCID(char *sVCID, char *sVer, int *nCnt, tag_t **tpVCIDObj)
{
	int n_Input = 3;
	char *sRev = NULL;
	char *sSeq = NULL;
	char *sNVer = NULL;
	char *sNewVer = NULL;
	char *qry_Input[3] = {"Item ID", "Type", "Revision"};
	char *values[3];
	tag_t ProQryVCID = NULLTAG;
	
	sNVer =(char *) MEM_alloc(10);
	sNewVer =(char *) MEM_alloc(10);
	
	tc_strcpy(sNVer,sVer);
	sRev = tc_strtok(sNVer,";");
	sSeq = tc_strtok(NULL,";");
	
	tc_strcpy(sNewVer,sRev);
	tc_strcat(sNewVer,"*");
	tc_strcat(sNewVer,sSeq);
	printf("\nkk.New version val [%s]", sNewVer);fflush(stdout);
	
	values[0] = sVCID;
	values[1] = "VCID Revision";
	values[2] = sNewVer;

	if(QRY_find2("Item Revision...", &ProQryVCID));
	if(ProQryVCID)
	{
		 if(QRY_execute(ProQryVCID, n_Input, qry_Input, values, nCnt, tpVCIDObj));
		 printf("\nkk.QUERY VCID count [%d]", *nCnt);fflush(stdout);
	}
	return 0;
}

static void GetNewVersn(char *sVer, char **sNewVer)
{
	char *sRev = NULL;
	char *sSeq = NULL;
	
	sRev = tc_strtok(sVer,";");
	sSeq = tc_strtok(NULL,";");
	
	tc_strcpy(*sNewVer,sRev);
	tc_strcat(*sNewVer,"_");
	tc_strcat(*sNewVer,sSeq);
}
static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sVCID1  = ITK_ask_cli_argument("-vcid1=");
	sVCIDVer1  = ITK_ask_cli_argument("-ver1=");
	sVCID2 = ITK_ask_cli_argument("-vcid2=");
	sVCIDVer2 = ITK_ask_cli_argument("-ver2=");

	iStatus = ITK_auto_login();

	if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	int s1 = 0;
	int s2 = 0;
	int nSnap1cnt = 0;
	int nSnap2cnt = 0;
	int nSnap1PrtCnt = 0;
	int nSnap2PrtCnt = 0;
	int nPrevRvCnt = 0;
	int nV1Cnt = 0;
	int nV2Cnt = 0;
	char *sVCIDObjStr1 = NULL;
	char *sVCIDObjStr2 = NULL;
	char *sSnpPrt1 = NULL;
	char *sSnpPrt2 = NULL;
	char *sSnpPrt1Rv = NULL;
	char *sSnpPrt2Rv = NULL;
	char *sCmp_Report = NULL;
	char *sNewVer1 = NULL;
	char *sNewVer2 = NULL;
	tag_t tVCID1 = NULLTAG;
	tag_t tVCID2 = NULLTAG;
	tag_t tVCID1Ver = NULLTAG;
	tag_t tVCID2Ver = NULLTAG;
	tag_t tSnapRel = NULLTAG;
	tag_t tImanBO = NULLTAG;
	tag_t *tpSnap1 = NULLTAG;
	tag_t *tpSnap2 = NULLTAG;
	tag_t *tpSnap1Parts = NULLTAG;
	tag_t *tpSnap2Parts = NULLTAG;
	tag_t *tpPrevRvObj = NULLTAG;
	tag_t *tpVCID1 = NULLTAG;
	tag_t *tpVCID2 = NULLTAG;
	FILE *fCmpRep;
	
	sCmp_Report =(char *) MEM_alloc(150);

	printf("\nkk.Input VCIDs [%s,%s]",sVCID1,sVCID2); fflush(stdout);
	
	//ITK_CALL(ITEM_find_item(sVCID1,&tVCID1));
	//ITK_CALL(ITEM_find_item(sVCID2,&tVCID2));
	ITK_CALL(QueryVCID(sVCID1,sVCIDVer1,&nV1Cnt,&tpVCID1));
	printf("\nkk.VCID1 count is [%d]", nV1Cnt);fflush(stdout);
	if(nV1Cnt>0)
	{
		tVCID1 = tpVCID1[0];
	}
	ITK_CALL(QueryVCID(sVCID2,sVCIDVer2,&nV2Cnt,&tpVCID2));
	printf("\nkk.VCID2 count is [%d]", nV2Cnt);fflush(stdout);
	if(nV2Cnt>0)
	{
		tVCID2 = tpVCID2[0];
	}
	
	if(tVCID1 && tVCID2)
	{	
		sNewVer1 =(char *) MEM_alloc(10);
		sNewVer2 =(char *) MEM_alloc(10);
		GetNewVersn(sVCIDVer1,&sNewVer1);
		GetNewVersn(sVCIDVer2,&sNewVer2);
		tc_strcpy(sCmp_Report,"VCID_Compare_Report_");
		tc_strcat(sCmp_Report,sVCID1);
		tc_strcat(sCmp_Report,"_");
		tc_strcat(sCmp_Report,sNewVer1);
		tc_strcat(sCmp_Report,"_");
		tc_strcat(sCmp_Report,sVCID2);
		tc_strcat(sCmp_Report,"_");
		tc_strcat(sCmp_Report,sNewVer2);
		tc_strcat(sCmp_Report,".csv");
		fCmpRep = fopen(sCmp_Report,"w");
		if(fCmpRep==NULL)
		{
			printf("Error! in File opening...%s",sCmp_Report);  fflush(stdout);
			exit(1);
		}
		fprintf(fCmpRep,",%s-%s,%s-%s\n",sVCID1,sNewVer1,sVCID2,sNewVer2); fflush(fCmpRep);
		fprintf(fCmpRep,"Part,Rev,Rev\n"); fflush(fCmpRep);
		
		//ITK_CALL(ITEM_ask_latest_rev(tVCID1,&tVCID1Ver));
		//ITK_CALL(ITEM_ask_latest_rev(tVCID2,&tVCID2Ver));
		
		//if(tVCID1Ver && tVCID2Ver)
		//{
			ITK_CALL(AOM_ask_value_string(tVCID1,"item_revision_id",&sVCIDObjStr1));
			ITK_CALL(AOM_ask_value_string(tVCID2,"item_revision_id",&sVCIDObjStr2));
			printf("\nkk.Comparing VCIDs [%s,%s and %s,%s]",sVCID1,sVCIDObjStr1,sVCID2,sVCIDObjStr2); fflush(stdout);
			
			ifail = GRM_find_relation_type("T5_CCIDHasSnapshot",&tSnapRel);
			ifail = GRM_list_secondary_objects_only(tVCID1,tSnapRel,&nSnap1cnt,&tpSnap1);
			ifail = GRM_list_secondary_objects_only(tVCID2,tSnapRel,&nSnap2cnt,&tpSnap2);
			printf("\nkk.Snapshot child count of both VCIDs are [%d,%d]",nSnap1cnt,nSnap2cnt); fflush(stdout);
			//if count is 0 then get prev VCID
			if(nSnap2cnt == 0)
			{
				GRM_find_relation_type("IMAN_based_on",&tImanBO);
				GRM_list_secondary_objects_only(tVCID2,tImanBO,&nPrevRvCnt,&tpPrevRvObj);
				printf("\nkk.Prev obj count is [%d]",nPrevRvCnt); fflush(stdout);
				if(nPrevRvCnt>0)
				{
					ifail = GRM_list_secondary_objects_only(tpPrevRvObj[0],tSnapRel,&nSnap2cnt,&tpSnap2);
					printf("\nkk.Snapshot child count of VCID is [%d]",nSnap2cnt); fflush(stdout);
				}
			}
			if(nSnap1cnt > 0 && nSnap2cnt > 0)
			{
				if(AOM_ask_value_tags(tpSnap1[0],"contents",&nSnap1PrtCnt,&tpSnap1Parts));
				if(AOM_ask_value_tags(tpSnap2[0],"contents",&nSnap2PrtCnt,&tpSnap2Parts));
				for(s1=0; s1<nSnap1PrtCnt; ++s1)
				{
					ITK_CALL(AOM_ask_value_string(tpSnap1Parts[s1],"item_id",&sSnpPrt1));
					ITK_CALL(AOM_ask_value_string(tpSnap1Parts[s1],"item_revision_id",&sSnpPrt1Rv));
					for(s2=0; s2<nSnap2PrtCnt; ++s2)
					{
						ITK_CALL(AOM_ask_value_string(tpSnap2Parts[s2],"item_id",&sSnpPrt2));
						ITK_CALL(AOM_ask_value_string(tpSnap2Parts[s2],"item_revision_id",&sSnpPrt2Rv));
						
						if(tc_strcmp(sSnpPrt1,sSnpPrt2)==0)
						{
							printf("%s,%s,%s\n",sSnpPrt1,sSnpPrt1Rv,sSnpPrt2Rv); fflush(stdout);
							if(tc_strcmp(sSnpPrt1Rv,sSnpPrt2Rv)==0)
							{
								fprintf(fCmpRep,"%s,%s,%s,Rev Match\n",sSnpPrt1,sSnpPrt1Rv,sSnpPrt2Rv); fflush(fCmpRep);
							}
							else
							{
								fprintf(fCmpRep,"%s,%s,%s,Rev Mismatch\n",sSnpPrt1,sSnpPrt1Rv,sSnpPrt2Rv); fflush(fCmpRep);
							}
						}
					}
				}
			}
		//}
	}
	if(fCmpRep) fclose(fCmpRep);
	
	printf("\nkk.VCID compare code completed.\n"); fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;
}


