#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include<ics/ics.h>
#include<ics/ics2.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void initialise (void);

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;
	logical lValFound = false;

	char *sRead_vc = NULL;
	char *sRead_vc_tok = NULL;
	char *sVeh = NULL;
	//int iVCnt = 0;
	//int nVCIDCnt = 0;
	//int nRefVCCnt = 0;
	char *sPrt = NULL;
	char *sSSPrt = NULL;
	char *sVehRev = NULL;
	char *sFileName = NULL;
	char *sFileName_out = NULL;
	//char *sVCIDRv = NULL;
	char *sUser = NULL;
	char *sPassFl = NULL;
	char *sGrp = NULL;
	char *sMajMod = NULL;
	char *sFuel = NULL;
	char *qry_Input[1] = {"Item ID"};
	//char *qry_Input[3] = {"Item ID", "Type", "Revision"};
	char *values[1];
	//tag_t newVcidRel = NULLTAG;
	//tag_t RefCCVTag = NULLTAG;
	//tag_t *tpVCIDs = NULLTAG;
	//tag_t *tpRefVC = NULLTAG;
	tag_t tVeh = NULLTAG;
	tag_t tVehRev = NULLTAG;
	
	int n_Input = 1;
	int nVehCnt = 0;
	tag_t qryVC = NULLTAG;
	tag_t *tpVeh = NULLTAG;
	
	FILE *fptr_out;
	FILE *fptr_vc;
	
	sRead_vc =(char *) MEM_alloc(50);
	sRead_vc_tok =(char *) MEM_alloc(50);
	sVeh =(char *) MEM_alloc(50);
	sMajMod =(char *) MEM_alloc(50);
	sFuel =(char *) MEM_alloc(50);
	sFileName_out =(char *) MEM_alloc(100);

	(void)argc;
	(void)argv;

	initialise();

	sUser = ITK_ask_cli_argument("-u=");
	sPassFl = ITK_ask_cli_argument("-pf=");
	sGrp = ITK_ask_cli_argument("-g=");
	sFileName = ITK_ask_cli_argument("-file=");

	iStatus = ITK_auto_login();

	if( ITK_init_module(sUser,sPassFl,sGrp)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Getting VC tech spec details from file [%s]",sFileName); fflush(stdout);
	
	fptr_vc = fopen(sFileName,"r");
	if(fptr_vc==NULL)
	{
		printf("Error in File [%s] opening!!!",sFileName);  fflush(stdout);
		exit(1);
	}
	
	tc_strcpy(sFileName_out,"vc_list_out.csv");
	fptr_out = fopen(sFileName_out,"w");
	if(fptr_out==NULL)
	{
		printf("Error in File [%s] opening!!!",sFileName_out);  fflush(stdout);
		exit(1);
	}
	
	while(fgets(sRead_vc,50,fptr_vc)!=NULL)
	{
		tc_strcpy(sRead_vc_tok,sRead_vc);
		sPrt = tc_strtok(sRead_vc_tok,"\n");
		printf("\nkk.VC number is %s.",sPrt); fflush(stdout);
		
		if(tc_strstr(sPrt,"000R") != NULL)
		{
			sSSPrt = subString(sPrt,0,8); 
			tc_strcpy(sVeh,sSSPrt);
			tc_strcat(sVeh,"R");
		}
		else if(tc_strstr(sPrt,"000L") != NULL)
		{
			sSSPrt = subString(sPrt,0,8); 
			tc_strcpy(sVeh,sSSPrt);
			tc_strcat(sVeh,"L");
		}
		else
		{
			tc_strcpy(sVeh,sPrt);
		}
		printf("\nkk.Veh number is [%s]",sVeh); fflush(stdout);
		
		ITK_CALL(ITEM_find_item(sVeh,&tVeh));
		ITK_CALL(ITEM_ask_latest_rev(tVeh,&tVehRev));
		
		if(tVehRev)
		{
			ITK_CALL(AOM_ask_value_string(tVehRev,"item_revision_id",&sVehRev));
			printf("\nkk.Veh Rev is [%s]",sVehRev); fflush(stdout);
			
			int ic=0,xc=0;
			int theAttributeCount =0;
			int *theAttributeIds ;
			char **theAttributeNames = NULL;
			int *theAttributeValCounts=0;
			char***       theAttributeValues = NULL;
			char***       theAttributeOptimizedUnits = NULL;
			char* 	attrId = NULL;
			attrId = (char *) MEM_alloc(50 * sizeof(char));
			tag_t tVehClsObj = NULLTAG;
			tc_strcpy(sMajMod,"NA");
			tc_strcpy(sFuel,"NA");
			
			ITK_CALL(ICS_ask_classification_object(tVeh,&tVehClsObj));
			if(tVehClsObj)
			{
				ITK_CALL( ICS_ico_ask_attributes_optimized(tVehClsObj,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
				if(theAttributeCount>0)
				{
					tc_strcpy(sMajMod,"");
					tc_strcpy(sFuel,"");
					for(ic=0;ic<theAttributeCount;ic++)
					{
						//lValFound = false;
						sprintf(attrId,"%d",theAttributeIds[ic]);
						if(tc_strcmp(theAttributeNames[ic],"[VC]MAJORMODEL")==0)
						{
							for(xc=0;xc<theAttributeValCounts[ic];xc++)
							{
								tc_strcat(sMajMod,theAttributeValues[ic][xc]);
							}

							printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
							printf("\n attrId:[%s]",attrId);fflush(stdout);
							printf("\n theAttribute value:[%s] ",sMajMod);fflush(stdout);
							//lValFound = true;
						}
						if(tc_strcmp(theAttributeNames[ic],"[VC]FUEL(FUEL)")==0)
						{
							for(xc=0;xc<theAttributeValCounts[ic];xc++)
							{
								tc_strcat(sFuel,theAttributeValues[ic][xc]);
							}

							printf("\n theAttribute Name :[%s]",theAttributeNames[ic]);fflush(stdout);
							printf("\n attrId:[%s]",attrId);fflush(stdout);
							printf("\n theAttribute value:[%s] ",sFuel);fflush(stdout);
							//lValFound = true;
						}
						
						/*if(lValFound)
						{
							fprintf(fptr_out,"%s,%s,%s\n",sPrt,sFuel,sMajMod); fflush(fptr_out);
						}*/
					}
					printf("kk.%s,%s,%s\n",sPrt,sFuel,sMajMod);fflush(stdout);
					fprintf(fptr_out,"%s,%s,%s\n",sPrt,sFuel,sMajMod); fflush(fptr_out);
				}
			}
		}
	
		/*if(QRY_find2("Item...", &qryVC));
		if(qryVC)
		{
			values[0] = sVeh;
			//values[1] = "VCID Revision";
			//values[2] = nwRev;
		
			if(QRY_execute(qryVC, n_Input, qry_Input, values, &nVehCnt, &tpVeh));
			printf("\nkk.Veh Count is [%d]", nVehCnt);fflush(stdout);
			if(nVehCnt > 0)
			{
				tVeh = tpVeh[0];
				//ITK_CALL(ITEM_find_item(sVeh,&Design_rev_tag));
				
			}
		}*/
	}
	
	fclose(fptr_out);

	printf("\nkk...Data Generation Completed...\n");  fflush(stdout);

	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

}
