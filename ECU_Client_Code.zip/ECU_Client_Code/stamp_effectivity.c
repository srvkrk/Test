
/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                : Rupali Rane
*  Module                : Stamp Design Revision Effectivity and LCS State in TCUA
*  Code                  : RlzStatusAndEffStamp.c
*  Created on    : May 23, 2017
*
*
* Modification History :
* S.No  Date                    CR No   Modified By    Modification Notes
***************************************************************************/
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/releasestatus.h>
#include <time.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X)     \
                if(Debug) \
                { \
                        printf(#X);     \
                } \
                fflush(NULL);   \
                status=X;  \
                if (status != ITK_ok )  \
                { \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
 \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);   \
                        for( index=0; index<n_ifails; index++)  \
                        {  \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }  \
                        return status;  \
                }  \
                else \
                { \
                        if(Debug)       \
                        printf("\tSUCCESS\n");                          \
                } \

#define TCTYPE_name_size_c 100



#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

int setLifeCycle(tag_t itemRev,char* lifeCycleS);
int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS,char *Rlz_Date);
void getNextDate(char *DatetoConvert,char cnextAccessDate[30]);
void  getMonth( int m ,char cMonth[30]);
char *Rlz_Date=NULL;
char* Creation_date=NULL;
tag_t attr_idDR = NULLTAG;
tag_t attr_idCR = NULLTAG;
logical date_is_validDR =false;
date_t DRRelDate_tag;

static void initialise (void)
{
        int ifail;

        if ((ifail = ITK_auto_login()) != ITK_ok)
     //   if ((ifail = TC_auto_login()) != ITK_ok)
        fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
        CHECK_FAIL;
}
extern int ITK_user_main (int argc, char ** argv )
{
        int status;
        int i = 0;

        char *inputfile=NULL;
        char *user=NULL;
        char *pwd=NULL;
        char *group=NULL;
        char *inputline=NULL;
        char *itemId = NULL;
        char *revId = NULL;
        char *seq = NULL;
        char *lifecycleS = NULL;
        char *ReveffDateFrom = NULL;
        char *ReveffDateTo = NULL;
        char *revisionID = NULL;
        char *ItmSeqID = NULL;
        char *itemRevSeq = NULL;
date_t CreateionDate_tag;
        tag_t *rev=NULLTAG;
        tag_t revTag=NULLTAG;

        char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
        char **values = (char **) MEM_alloc(2 * sizeof(char *));

        char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

        char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
        char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

        const char *qry_entries[1] = {"item_id"};
        const char *qry_values123[1];
        char *currentRevID = NULL;

        int n_count_item=0;
        FILE *fptr;
        //FILE *fptr1;
        //char* line;

        inputfile = ITK_ask_cli_argument("-i=");
        user = ITK_ask_cli_argument("-u=");
        pwd = ITK_ask_cli_argument("-p=");
        group = ITK_ask_cli_argument("-g=");



     //   initialise();
	 /////////
	 int				ifail 						= ITK_ok;
	 ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);


	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}





	 ///////////


        printf("\ninputfile= %s \n\n",inputfile );fflush(stdout);

        fptr = fopen(inputfile,"r");;

        if(fptr!=NULL)
        {
                inputline=(char *) MEM_alloc(100);
                while(fgets(inputline,100,fptr)!=NULL)
                {
                        printf("\n"); fflush(stdout);
                        fputs(inputline,stdout);

                        itemId = tc_strtok(inputline,"^");
                        itemRevSeq = tc_strtok(NULL,"^");
                        lifecycleS = tc_strtok(NULL,"^");
                        ReveffDateFrom = tc_strtok(NULL,"^");
                        ReveffDateTo = tc_strtok(NULL,"^");
						Rlz_Date=tc_strtok(NULL,"^");
						Creation_date=tc_strtok(NULL,"^");

                        printf("\t item id   = [%s] ",itemId); fflush(stdout);
                        printf("\n\t itemRevSeq   = [%s] ",itemRevSeq); fflush(stdout);
                        printf("\n\t lifecycleS   = [%s] ",lifecycleS); fflush(stdout);
                        printf("\n\t ReveffDateFrom = [%s] ",ReveffDateFrom); fflush(stdout);
                        printf("\n\t ReveffDateTo = [%s]  \n\t ",ReveffDateTo); fflush(stdout);
                        printf("\n\t Released Date = [%s]  \n\t ",Rlz_Date); fflush(stdout);
                        printf("\n\t Creation Date = [%s]  \n\t ",Creation_date); fflush(stdout);
                        qry_values123[0] = itemId;

                        ITK_CALL(ITEM_find_items_by_key_attributes(1,qry_entries,qry_values123,&n_count_item,&rev));
                        printf("\t n_count_item=:%d \n\t ",n_count_item); fflush(stdout);
                        if(n_count_item>0)
                        {


                                ITK_CALL(ITEM_find_revision(rev[0],itemRevSeq,&revTag));
                                if(revTag)
                                {
                                        printf("\t ITEM_find_revision Found...\n\t ");fflush(stdout);
                                        ITK_CALL (ITK_string_to_date(Rlz_Date , &DRRelDate_tag));
                                        ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
                                        ITK_CALL(AOM_UIF_ask_value(revTag,"item_revision_id",&currentRevID));
                                        ITK_CALL(AOM_UIF_ask_value(revTag,"sequence_id",&ItmSeqID));
                                        printf(" currentRevID=[%s]  ItmSeqID=[%s] ",currentRevID,ItmSeqID);fflush(stdout);
                                         ITK_CALL(AOM_lock(revTag)); 
                                        ITK_CALL (ITK_string_to_date(Creation_date , &CreateionDate_tag));
										ITK_CALL (POM_set_creation_date(revTag,CreateionDate_tag));
										ITK_CALL (POM_set_attr_date(1, &revTag, attr_idDR, DRRelDate_tag));
										ITK_CALL (AOM_save_without_extensions(revTag));
										ITK_CALL(AOM_unlock(revTag));
										
		 
                                                setLifeCycle(revTag,lifecycleS);
                                        
                                        ITK_CALL(CreateEffctivity(revTag, ReveffDateFrom,ReveffDateTo,lifecycleS,Rlz_Date));
                                }
                                else
                                {
                                        printf("\n\t ?????? No rev found  %s %s\n",itemId,revId); fflush(stdout);

                                        
                                }
                        }
                }
        }

        ITK_CALL(POM_logout(false));
        return status;
}
int setLifeCycle(tag_t itemRev,char* lifeCycleS)
{
        int status;
        tag_t   status2=NULLTAG;
        tag_t   release_status_object=NULLTAG;
        logical retain=false;
        char* lcsToset=NULL;

        tag_t class_id =     NULLTAG;

        lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

                strcpy(lcsToset,lifeCycleS);

        printf("   InsetLifeCycle...lcsToset:[%s]\n\t ",lcsToset); fflush(stdout);

        ITK_CALL(RELSTAT_create_release_status(lcsToset,&status2));
    //    ITK_CALL(CR_create_release_status2(lcsToset,&status2));
       
        printf("\n\t "); fflush(stdout);
        ITK_CALL(POM_attr_id_of_attr("release_status_list","Design_0_Revision_alt",&release_status_object));fflush(stdout);

        if(status2)
        {
                printf("\n\t "); fflush(stdout);
                ITK_CALL(AOM_save_without_extensions(status2));
                printf("\n\t "); fflush(stdout);
                ITK_CALL(AOM_refresh(status2,0));

                printf("   InsetLifeCycle...lcsToset:==> [%s] \n\t ",lcsToset); fflush(stdout);

                ITK_CALL(POM_refresh_instances(1, &itemRev, NULLTAG, POM_modify_lock));
                printf("\n\t "); fflush(stdout);
                ITK_CALL(POM_class_of_instance(itemRev,&class_id));
                printf("\n\t "); fflush(stdout);
                //ITK_CALL(POM_unload_instances (1,&itemRev));
                ITK_CALL(POM_load_instances(1,&itemRev,class_id,1));
                printf("\n\t "); fflush(stdout);
                printf("   InsetLifeCycle...lcsToset:222[%s]",lcsToset); fflush(stdout);

                printf("\n\t "); fflush(stdout);
                //ITK_CALL(TCTYPE_ask_object_type(status2,&release_status_object));
                //ITK_CALL(POM_append_attr_tags(1, &itemRev, release_status_object , 1, &status2 ));
                ITK_CALL(POM_set_attr_tag(1, &itemRev, release_status_object , status2 ));
                printf("\n\t "); fflush(stdout);
                //ITK_CALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,0,1));
                printf("   InsetLifeCycle...lcsToset:333[%s]",lcsToset); fflush(stdout);
                ITK_CALL(POM_save_instances(1,&itemRev,true));
                //ITK_CALL(POM_refresh_instances(1,&itemRev,class_id,2));
        }
        //ITK_CALL(AOM_save_without_extensions(itemRev));
        //ITK_CALL(AOM_unlock(itemRev));
}
int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS,char *Rlz_Date)
{
        int status = 0;
        int ifail = 0;
        int status_count=0;
        int ss=0;
        int StatusFlg=0;

        char* ReleaseStatus=NULL;
        char* ReleaseStatus2=NULL;
        char* lcsToset=NULL;
        char* CurrentRelStatus=NULL;

        char FrmNextDate[20]={0};
        char ToNextDate[20]={0};

        logical retain_released_date =false;
        logical is_v7  ;

        date_t test_date_1;
        date_t DayTommorow ;
        date_t test_date_2;
        date_t *start_end_date = NULL;

        tag_t release_status =NULLTAG;
        tag_t release_status2 =NULLTAG;
        tag_t eff_d = NULLTAG;

        tag_t* status_list = NULLTAG;

        /******Start Release status Variable initialisation***********/
        int                     st_relList_count                =0;
        int                     Rel_cnt                                 =0;
        tag_t*          relstatus_list                  =NULLTAG;
        char            *WSO_Name_RelVal                =NULL ;
        tag_t           tReleaseStatusList_checkin=NULLTAG;
        int                     n_values_checkin                        =0;
        int                     cunt1                                   =       0;
        tag_t*          attr_tags_checkin               =       NULLTAG;
        logical         *is_it_null_checkin             =   NULL;
        logical         *is_it_empty_checkin    =   NULL;
        tag_t           class_id                                =     NULLTAG;
        char            *class_name                             =    NULL;
        logical         log1;
        tag_t propEff_tag =NULLTAG;
        char* EffDateValue =NULL;
        int EffectivityFlag=0;


        /******End Release status ariable initialisation***********/

        lcsToset =(char *) MEM_alloc(20 * sizeof(char *));


  
                strcpy(lcsToset,lifeCycleS);
        

        printf("\n\t   lcsToset:[%s]",lcsToset); fflush(stdout);
        printf("   FromDate..[%s]",FromDate); fflush(stdout);
        printf("   ToDate..[%s]",ToDate); fflush(stdout);

        if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
        {
                printf(" ...ifail..."); fflush(stdout);
                return ifail;
        }
        printf("\n\t   REV status_count: %d \n\t   ",status_count);fflush(stdout);
        if (status_count == 0)  // No Status, so the Item is not yet Released
        {
                printf("\n\t   No Status, so the Item is not yet Released...............\n\t "); fflush(stdout);
        }

        if(((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0)) && (strcmp(lcsToset,"ERCREVIEW")==0))
        {
                if (status_count == 0)
                {
                        if(ITK_ok != (ifail = RELSTAT_create_release_status(lcsToset,&release_status2)))      return ifail;
                        if(ITK_ok != (ifail = AOM_ask_name(release_status2, &ReleaseStatus2))) return ifail;
                        printf("\n\t   Created ReleaseStatus2: %s",ReleaseStatus2);fflush(stdout);
                        if(ITK_ok != (ifail = RELSTAT_add_release_status(release_status2,1,&itemrev,retain_released_date)))return ifail;
                }

                return 0;
        }

        if (status_count > 0) 
        {
                for(ss=0; ss<status_count ; ss++)
                {
                        release_status=status_list[ss];

                        ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&CurrentRelStatus));
                        printf("\t   ........CurrentRelStatus: %s ",CurrentRelStatus);fflush(stdout);
                        if(strcmp(CurrentRelStatus,lcsToset)==0)
                        {
                                StatusFlg ++;

                            //    if(ITK_ok != (ifail = PROP_ask_property_by_name(status_list[ss],"effectivity_text",&propEff_tag))) return ifail;
                            //    if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&EffDateValue))) return ifail;
                                if(ITK_ok != (ifail = AOM_ask_value_string(status_list[ss],"effectivity_text",&EffDateValue))) return ifail;

                                printf("\t EffDateValue: [%s]",EffDateValue);fflush(stdout);

                                if ((tc_strcmp(EffDateValue,"")==0) || (strlen(EffDateValue)==0))
                                {
                                        EffectivityFlag=0;
                                }
                                else
                                {
                                        EffectivityFlag=1;
                                }

                                break;
                        }
                }
        }
        printf("\n\t   StatusFlg: [%d]  EffectivityFlag: [%d]",StatusFlg,EffectivityFlag);fflush(stdout);

        if((StatusFlg != 0) && (EffectivityFlag==1))
        {
                return 0;
        }

        printf("\n\t   Removing previously created release status......\n\t   "); fflush(stdout);
        
        ITK_CALL(POM_class_of_instance(itemrev,&class_id));
        printf("\t   "); fflush(stdout);
        ITK_CALL(POM_name_of_class(class_id,&class_name));
        printf("\t   class_name is :%s\n\t   ",class_name);fflush(stdout);

        if(StatusFlg == 0)
        {
                release_status =NULLTAG;
                printf("\n\t   *********Stamping Releasing item*******......"); fflush(stdout);
                if(ITK_ok != (ifail = RELSTAT_create_release_status(lcsToset,&release_status)))       return ifail;

                if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
                printf("\n\t   ******************* ReleaseStatus: %s",ReleaseStatus);fflush(stdout);

                if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
                {
                        printf(" ..ifail..."); fflush(stdout);
                        return ifail;
                }
                printf("\n\t   REV status_count after ERC Released Stamped: %d \n\t   ",status_count);fflush(stdout);
                ITK_CALL(RELSTAT_add_release_status(release_status,1,&itemrev,retain_released_date)); printf("\t   "); fflush(stdout);
                if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&is_v7)))        return ifail;
                printf("\n\t   is_v7:%d",is_v7); fflush(stdout);
                if(is_v7 != true)
                {
                        printf("\t ------is_v7 is not true ....."); fflush(stdout);
                }
                else
                {
                        printf("\t ------is_v7 is  true ....."); fflush(stdout);
                }
        }

        if((strcmp(FromDate,"-")!=0) && (strcmp(ToDate,"-")!=0))
        {
                getNextDate(FromDate,FrmNextDate);
                getNextDate(ToDate,ToNextDate);

                printf("\n\t   FrmNextDate:%s",FrmNextDate); fflush(stdout);
                printf("   ToNextDate:%s",ToNextDate); fflush(stdout);
                

                if(ITK_ok != (ifail = ITK_string_to_date(FrmNextDate, &test_date_1)))
                {
                        return ifail;
                }
                if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
                {
                        return ifail;
                }

                start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

                start_end_date[0] = test_date_1;
                start_end_date[1] = test_date_2;

                if(ITK_ok != (ifail = WSOM_status_clear_effectivities(release_status)))
                {
                        return ifail;
                }

                if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
                {
                        return ifail;
                }

                if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
                {
                        return ifail;
                }
        }
     ITK_CALL (ITK_string_to_date(Rlz_Date , &DRRelDate_tag));
        ITK_CALL (POM_attr_id_of_attr("date_released", "Design_0_Revision_alt", &attr_idDR));
        ITK_CALL(AOM_lock(release_status)); printf("\t   "); fflush(stdout);
		ITK_CALL(AOM_refresh(release_status,1));
        ITK_CALL (POM_set_attr_date(1, &release_status, attr_idDR, DRRelDate_tag));
        ITK_CALL (AOM_save_without_extensions(release_status));
        ITK_CALL(AOM_refresh(release_status,1));
         ITK_CALL(AOM_unlock(release_status));
        
		

        return status;
}
void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
        int day, month, year, nd, nm, ny, ndays;
        int ch1;
        int Monthas;
        int ch;

        time_t  temp;

    date_t DayTommorow ;

        struct tm *timeptr;
        struct tm *timeptr1;

        char pAccessDate[20];
        char pAccessDate1[20];
        char DateS[20];
        char CCMonth[30];

        char* strDay;
        char* strMon;
        char* strYear;
        char* cMonth ;

        temp = time(NULL);

        tc_strcpy(pAccessDate,"");

        

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);

        getMonth(Monthas,CCMonth);

        printf("\n\t strYear:%s",strYear); fflush(stdout);
        printf("\t CCMonth:%s",CCMonth); fflush(stdout);
        printf("\t strDay:%s",strDay); fflush(stdout);

        tc_strcpy(cnextAccessDate,strDay);
        tc_strcat(cnextAccessDate,"-");
        tc_strcat(cnextAccessDate,CCMonth);
        tc_strcat(cnextAccessDate,"-");
        tc_strcat(cnextAccessDate,strYear);
        tc_strcat(cnextAccessDate," ");
        tc_strcat(cnextAccessDate,"00:00");

        printf("\n\t cnextAccessDate:%s",cnextAccessDate); fflush(stdout);
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
          {
                tc_strcpy(cMonth,"Jan");
          }
          else if(m==2)
          {
                tc_strcpy(cMonth,"Feb");
          }
          else if(m==3)
          {
                tc_strcpy(cMonth,"Mar");
          }
          else if(m==4)
          {
                tc_strcpy(cMonth,"Apr");
          }
          else if(m==5)
          {
                tc_strcpy(cMonth,"May");
          }
          else if(m==6)
          {
                tc_strcpy(cMonth,"Jun");
          }
          else if(m==7)
          {
                tc_strcpy(cMonth,"Jul");
          }
          else if(m==8)
          {
                tc_strcpy(cMonth,"Aug");
          }
          else if(m==9)
          {
                tc_strcpy(cMonth,"Sep");
          }
          else if(m==10)
          {
                tc_strcpy(cMonth,"Oct");
          }
          else if(m==11)
          {
                tc_strcpy(cMonth,"Nov");
          }
          else if(m==12)
          {
                tc_strcpy(cMonth,"Dec");
          }
}
