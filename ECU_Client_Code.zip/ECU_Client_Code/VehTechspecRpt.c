#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//s#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include <ics/ics2.h>
//#include<ics/iman_ics.h>

int status;

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);


char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
//char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char *inputfile=NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
 
{
 
		int ifail;
	 
	//	int status;
	 
		int iStatus=0;

		(void)argc;
	 
		(void)argv;

		initialise();

		sUsr  = ITK_ask_cli_argument("-u=");
	 
		spass  = ITK_ask_cli_argument("-pf=");
	 
		sDB  = ITK_ask_cli_argument("-g=");
		inputfile = ITK_ask_cli_argument("-i=");

		iStatus = ITK_auto_login();

		if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	 
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	 
		ITK_CALL(ITK_set_journalling( TRUE ));


	//	logical lIsQtyModified = false;

		time_t temp;
	 
		struct tm *timeptr;
	 
		char pAccessDate[30];
	 
		char *sCurrentDate = NULL;
	 
		char *sCurrentDateDup = NULL;
	 
		char *strToBereplaceddate;
	 
		char *strToBeUsedInsteaddate;
		char	*tplid = NULL;
	 
		char	*sPrtRev = NULL;
		char	*FileName = NULL;

		FILE *fptr;

	 
		FileName =(char *) MEM_alloc(150);
	 
		sCurrentDate =(char *) MEM_alloc(30);
	 
		sCurrentDateDup =(char *) MEM_alloc(30);
	 
		strToBereplaceddate = (char*)malloc(5);
	 
		strToBeUsedInsteaddate = (char*)malloc(5);
		
		time(&temp);
	 
		timeptr = localtime(&temp );
	 
		tc_strcpy(pAccessDate,"");
	 
		strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr);
	 
		tc_strcpy(sCurrentDate,pAccessDate);
	 
		tc_strcpy(strToBereplaceddate,"/");
	 
		tc_strcpy(strToBeUsedInsteaddate,"-");

		ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup);
	 
		//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
	 
		printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

		tc_strcpy(FileName,"vehTPLRelCre");
	 
		tc_strcat(FileName,sCurrentDateDup);
	 
		tc_strcat(FileName,"_log.csv");

		printf("kk.log file name is : [%s]\n",FileName);

		fptr = fopen(FileName,"w");

		if(fptr==NULL)
	 
		{
	 
			printf("Error! in log File opening!!!");  fflush(stdout);
	 
			exit(1);
	 
		}


fprintf(fptr,"%s,%s,%s,%s","Vehicle Number","Tech spec availability","Total Number of ECU","Vehicle availability in TCUA");fflush(fptr);

	 FILE* fp=NULL;
	 FILE* fperror=NULL;
	 char* tplnumber=NULL;
	 char* vehnumber=NULL;
	  char* inputline=NULL;

			fp=fopen(inputfile,"r");
		fperror=fopen("error.log","a");
		if(fp!=NULL)
		{
				inputline=(char *) MEM_alloc(1000);
				
				while(fgets(inputline,1000,fp)!=NULL)
				{

					vehnumber=strtok(inputline,"^");  //1
					printf("\n veh number is [%s]\n",vehnumber);

					
				

						int		i = 0;
					 
						int		n_Input = 1;
					 
						int		nPrtCnt = 0;
					 
						int		n_Cnt = 0;
					 
						int		iPCnt = 0;
					 
						int		bl_qty_form = 0;

						int     vcidcnt   = 0;
						int     hasecumodrelcnt   = 0;

						int  crevcidcnt   = 0;
					 
						int        v=0;
						int        t=0;
						int    CheckFlag = 0;
					 
						char	*values[1];		
					 
						char	*qry_Input[1] = {"Item ID"};
					 
						tag_t	QryPrt = NULLTAG;
					 
						tag_t	tpltag = NULLTAG;
						tag_t	vctag = NULLTAG;
						tag_t	*tpPrtObjs = NULL;

						tag_t   rel_type3 = NULLTAG;
						tag_t   HasECUModulereltag = NULLTAG;

						tag_t modulelatestrev = NULLTAG;
					 
						tag_t*   vcidno   = NULLTAG;
						tag_t*   hasecumodreltags   = NULLTAG;

						tag_t*   crevcidno   = NULLTAG;

					 
						tag_t   item_tag   = NULLTAG;
						tag_t   vcidtag   = NULLTAG;
						tag_t   vcidlatestrevtag   = NULLTAG;
						tag_t   refccvreltag   = NULLTAG;
						tag_t   vclatestrevtag   = NULLTAG;
						tag_t   vclatestrelrevtag   = NULLTAG;
						

					 
						char	*sPrtTyp = NULL;
					 
						char	*sCPartNum = NULL;
					 
						char	*sCPartRvSq = NULL;
					 
						char	*sCPartQty = NULL;
																					
						char *modulerevseq = NULL;
					 
						char *vcidname     = NULL;
						char *availtplid     = NULL;
					 
						char *VcidLatestRevseq   = NULL;
						 char *ObjCCidName  = NULL;
						 char *vcidlatestrev  = NULL;
						 char *vclatestrev  = NULL;
						 logical lIsQtyModified = false;
						 logical chkvehrev = false;
															
						int theAttributeCount =0;
						int  	ic=0;
						int  	xc=0;
						int *theAttributeIds;
						int		t5NoEcuDupint  = 0;
						char **theAttributeNames = NULL;
						int *theAttributeValCounts=0;
						char***       theAttributeValues = NULL;
						char***       theAttributeOptimizedUnits = NULL;
							char* 	attrId 					= NULL;
							attrId = (char *) MEM_alloc( 50 * sizeof(char) );

								char 	*attributeNameDup 			= NULL;
							char 	*attributeValueDup 			= NULL;
							attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
							attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );

							tag_t   Design_rev_cls_tag   = NULLTAG;

							ITK_CALL(ITEM_find_item(vehnumber,&vctag));
							if(vctag == NULLTAG)
							{
							  printf("\n veh found:%s\n",vehnumber);
							  fprintf(fptr,"\n%s,%s,%s,%s",vehnumber,"","","NO");fflush(fptr);
							}
							else
							{
							  printf("\n Veh found:%s\n",vehnumber);	
							  
							  ITK_CALL(ITEM_ask_latest_rev(vctag,&vclatestrevtag));
					 
							  ITK_CALL(AOM_ask_value_string(vclatestrevtag,"item_revision_id",&vclatestrev));
							   printf("\n VC Latest Rev------>  %s/%s \n ", vehnumber,vclatestrev);fflush(stdout);

							   (ICS_ask_classification_object(vctag,&Design_rev_cls_tag));

								if(Design_rev_cls_tag)
								{
									ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
									if(theAttributeCount>0)
									{
										for(ic=0;ic<theAttributeCount;ic++)
										{
											sprintf(attrId,"%d",theAttributeIds[ic]);

											tc_strcpy(attributeNameDup,"");
											tc_strcpy(attributeNameDup,theAttributeNames[ic]);
											//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,ic);fflush(stdout);

											if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
											{
												tc_strcpy(attributeValueDup,"");
												for(xc=0;xc<theAttributeValCounts[ic];xc++)
												{
													
													tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
													
												}

												printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
												printf("\n attrId:[%s]",attrId);fflush(stdout);
												printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

												t5NoEcuDupint=atoi(attributeValueDup);
												printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);
												fprintf(fptr,"\n%s,%s,%d,%s",vehnumber,"",t5NoEcuDupint,"");fflush(fptr);

											}

										}
									}
								}
								else
								{
									printf("\n Design_rev_cls_tag NOT Found...");fflush(stdout);
									fprintf(fptr,"\n%s,%s,%s,%s",vehnumber,"Tech spec Not Available","","");fflush(fptr);
								}




					 

							
			 




														////////////
												/*		int vehrevcnt=0;
														tag_t *veh_rev_list = NULLTAG;																									
														tag_t vehrev = NULLTAG;
														char* vehid =NULL;
														char* vehrevid =NULL;
														int mi=0;																									
														char *vehrevrelstus = NULL;
														char *laterelstvehrevid = NULL;
														
														laterelstvehrevid=(char *) MEM_alloc(50);

														tag_t latrelrefccvreltag = NULLTAG;
														tag_t *lvehno = NULLTAG;
														int lccvcnt=0;
														int vt=0;
														char *availtplidonlatrelveh = NULL;


														ITK_CALL(ITEM_list_all_revs(vctag,&vehrevcnt,&veh_rev_list));
														printf("\n vehrevcnt=%d \n",vehrevcnt);fflush(stdout);

														
	

														

													/////////////////////////////////////////



													ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&HasECUModulereltag));

													ITK_CALL(GRM_list_secondary_objects_only(vclatestrevtag,HasECUModulereltag,&hasecumodrelcnt,&hasecumodreltags));

													printf("\n CCVCHasECUModule count [%d]= \n",hasecumodrelcnt);fflush(stdout);

													if (hasecumodrelcnt>0)
													{
														printf("\n i am in if condition \n");fflush(stdout);

														for(t=0; t<hasecumodrelcnt; ++t)

														  {
															 ITK_CALL(AOM_ask_value_string(hasecumodreltags[t],"item_id",&availtplid));
															  printf("\n available relation  [%s] \n",availtplid);fflush(stdout);

															  printf("\n available Tpl=[%s] and tplnumber=[%s] \n",availtplid,tplnumber);fflush(stdout);



															 if (tc_strcmp(availtplid,tplnumber)==0)
															 {
																 lIsQtyModified=true;
																 printf("\n veh relation is already available [%s/%s -%s] \n ", tplnumber,modulerevseq,vehnumber);fflush(stdout);
																
																//  fprintf(fptr,"\n%s,%s,%s/%s,%s,%s,%s,%s",tplnumber,modulerevseq,vehnumber,vclatestrev,"",laterelstvehrevid,"","");fflush(fptr);

																 //////////
																  ITKCALL(ITEM_find_revision(vctag,laterelstvehrevid,&vclatestrelrevtag));
																  ITK_CALL(GRM_list_secondary_objects_only(vclatestrelrevtag,HasECUModulereltag,&lccvcnt,&lvehno));
																  if (lccvcnt==0)
																	{
																	   

																	 //  ITKCALL(ITEM_find_revision(vctag,laterelstvehrevid,&vclatestrelrevtag));
																	   ITK_CALL(GRM_create_relation(vclatestrelrevtag,tpltag,HasECUModulereltag,NULLTAG,&latrelrefccvreltag));				

																	  ITK_CALL(AOM_unlock(latrelrefccvreltag));

																	  GRM_save_relation(latrelrefccvreltag);

																	  ITK_CALL(AOM_lock(latrelrefccvreltag));
                                                                     fprintf(fptr,"\n%s,%s,%s/%s,%s,%s,%s,%s,%s",tplnumber,modulerevseq,vehnumber,vclatestrev,"",laterelstvehrevid,"","","");fflush(fptr);
																	 
																	}
																	else
																	 { if (tc_strcmp(laterelstvehrevid,vclatestrev)==0)
																       {
																		printf("\n veh latest and latest release rev are same [%s] [%s]\n",vclatestrev,laterelstvehrevid);fflush(stdout);
																		fprintf(fptr,"\n%s,%s,%s/%s,%s,%s,%s,%s,%s",tplnumber,modulerevseq,vehnumber,vclatestrev,"","","","","");fflush(fptr);

																	   }
																	   else
																		 {

															
																			ITK_CALL(AOM_ask_value_string(lvehno[0],"item_id",&availtplidonlatrelveh));
															                  printf("\n available relation on latest release veh rev[%s] \n",availtplidonlatrelveh);fflush(stdout);
																			  fprintf(fptr,"\n%s,%s,%s/%s,%s,%s,%s,%s,%s",tplnumber,modulerevseq,vehnumber,vclatestrev,"","",availtplidonlatrelveh,"","");fflush(fptr);
																		 }

																		

																	   
																	 }




															 }

														  }

													}

													//if (lIsQtyModified==false)
													else
													{
														printf("\n i am in else condition \n");fflush(stdout);
													
													  ITK_CALL(GRM_create_relation(vclatestrevtag,tpltag,HasECUModulereltag,NULLTAG,&refccvreltag));				

													  ITK_CALL(AOM_unlock(refccvreltag));

													  GRM_save_relation(refccvreltag);

													  ITK_CALL(AOM_lock(refccvreltag));
												//	   fprintf(fptr,"\n%s,%s,%s,%s,%s,%s",tplnumber,modulerevseq,"",vehnumber,"","");fflush(fptr);

															ITKCALL(ITEM_find_revision(vctag,laterelstvehrevid,&vclatestrelrevtag));
															ITK_CALL(GRM_list_secondary_objects_only(vclatestrelrevtag,HasECUModulereltag,&lccvcnt,&lvehno));

															printf("\n CCVCHasECUModule count on latest Release VC [%d]= \n",lccvcnt);fflush(stdout);

															if (lccvcnt==0)
															{
															
													

															   ITKCALL(ITEM_find_revision(vctag,laterelstvehrevid,&vclatestrelrevtag));
															   ITK_CALL(GRM_create_relation(vclatestrelrevtag,tpltag,HasECUModulereltag,NULLTAG,&latrelrefccvreltag));				

															  ITK_CALL(AOM_unlock(latrelrefccvreltag));

															  GRM_save_relation(latrelrefccvreltag);

															  ITK_CALL(AOM_lock(latrelrefccvreltag));

															 fprintf(fptr,"\n%s,%s,%s,%s/%s,%s,%s,%s,%s",tplnumber,modulerevseq,"",vehnumber,vclatestrev,laterelstvehrevid,"","","");fflush(fptr);
															}
															else
															 {
																if (tc_strcmp(laterelstvehrevid,vclatestrev)==0)
																{
																	printf("\n veh latest and latest release rev are same [%s] [%s]\n",vclatestrev,laterelstvehrevid);fflush(stdout);
																	 fprintf(fptr,"\n%s,%s,%s,%s/%s,%s,%s,%s,%s",tplnumber,modulerevseq,"",vehnumber,vclatestrev,"","","","");fflush(fptr);

																}
																else
																 {

																  ITK_CALL(AOM_ask_value_string(lvehno[0],"item_id",&availtplidonlatrelveh));
																  printf("\n available relation on latest release veh [%s] \n",availtplidonlatrelveh);fflush(stdout);

															      fprintf(fptr,"\n%s,%s,%s,%s/%s,%s,%s,%s,%s",tplnumber,modulerevseq,"",vehnumber,vclatestrev,"",availtplidonlatrelveh,"","");fflush(fptr);
																 }
															 }



													 



													  }*/



										  
										   
					 
									


							  }
				 

					  
					//		MEM_free(tpPrtObjs);
					//		MEM_free(crevcidno);
							
							

                printf("===============================================================================================\n");
				}
		}

	ITK_exit_module(true);

	return status;
	 
	}

	static void initialise (void)
	 
	{
	 
		int ifail;

		/* <kc> pr#397778 July2595 exit if autologin() fail */
	 
		if ((ifail = ITK_auto_login()) != ITK_ok)
	 
		   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	 
		CHECK_FAIL;

		/* these tokens come from bom_attr.h */
	 
		initialise_attribute (bomAttr_lineName, &name_attribute);
	 
		initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	 

	 
		CHECK_FAIL;
	 
	}

	static void initialise_attribute (char *name,  int *attribute)
	 
	{
	 
		int ifail, mode;


	 
		CHECK_FAIL;
	 
	
	 
	}


	

//50081139L 5008113916L^ 5008113916L_R1 A;1
//28800242R^2880024216R^ 2880024216R_R1 A;1
//50080455L^5008035516L^ 5008035516L_R1 A;1
 