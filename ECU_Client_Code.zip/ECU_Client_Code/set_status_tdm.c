/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: IR_checklist.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** IR_checklist -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int IR_checklist(char*,char*,char*);
//int createCheckListRowData(tag_t,char*,char*,tag_t,char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	  ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int		count	 				= 0;
	
	char	*item_id							= NULL;
	char	*module_no					= NULL;
	char	*PartType						= NULL;
	char	*ChecklistImplemented					= NULL;
	char* irchecklist                           =NULL;
	char* irchecklistobj                        =NULL;
	char 	*rev_id					= NULL;
	char 	 temp[200];
    char	*SrNo					= NULL;
   
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//printf("\ntemp:%s",temp);
				SrNo = strtok(temp, ",");
				printf("\n Sr No:%s",SrNo);

				module_no = strtok(NULL, ",");
				printf("\n module no:%s",module_no);

				rev_id = strtok(NULL, ",");
				printf("\n rev id:%s",rev_id);

				
			
				ifail = IR_checklist(SrNo,module_no,rev_id);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       IR_checklist
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int IR_checklist(char*SrNo,char* module_no,char*rev_id)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;

	//int PorjectCode = atoi(Project);
	
	tag_t			module_tag			= NULLTAG;	
	tag_t			moduleRev_tag			= NULL;
	tag_t           item_type_tag1           = NULLTAG;

	tag_t           item_create_input_tag1   = NULLTAG;
	
	tag_t            object1                = NULLTAG;
	
	tag_t            ChecklistRev            = NULLTAG;
	
    int                 n_items                = 0;
	int                n_items1                = 0;
	int                n_items2                = 0;
	tag_t               item_tag             = NULL;
	tag_t                module_rev         = NULLTAG;
	char               *tempRev_ID	          =NULL;
	tag_t                item_tag1           = NULL;
	
    tag_t relation_type;
	tag_t relation = NULLTAG;
	char* irchecklist=	NULL;
	
	 tag_t            tempChecklistRev            = NULLTAG;
    tag_t relation_type1;
	tag_t relation1 = NULLTAG;
   
	tag_t tp_close_status_tag;
	
	ITK_CALL(ITEM_find_item(module_no,&item_tag));
	printf("\n  module found ");

    ITK_CALL(ITEM_find_revision(item_tag,rev_id,&module_rev));
    printf("\n  module rev found");
	
  //  ITK_CALL(RELSTAT_create_release_status("APLC Released",&tp_close_status_tag));
//  ITK_CALL(RELSTAT_create_release_status("STDSIC Released",&tp_close_status_tag));
 // ITK_CALL(RELSTAT_create_release_status("ERC Released",&tp_close_status_tag));
 // ITK_CALL(RELSTAT_create_release_status("TestPlan Closed",&tp_close_status_tag));
//	  ITK_CALL(RELSTAT_create_release_status("GreenReport Closed",&tp_close_status_tag));
	  ITK_CALL(RELSTAT_create_release_status("TestPlan Creation",&tp_close_status_tag));
	if(ifail == ITK_ok) 
		 {
		     printf("\nTestPlan Closed status found");
				 

		} else {

			
			printf("\nValue not set");
						 //return ifail;
		}

    if(module_rev)
	  {
		printf("\nmodule rev found.....\n"); fflush(stdout); 
		ITK_CALL(AOM_refresh(module_rev,0));
		
	//  ITK_CALL(AOM_set_value_string(module_rev,"t5_PartType",PartType));   
		ITK_CALL(RELSTAT_add_release_status(tp_close_status_tag,1,&module_rev,false));
		if(ifail == ITK_ok) 
		{
				
				  printf("\nAPLC Released status added to part Revision successfully");

		} else {
						
						 printf("\nValue not set");
						 //return ifail;
				}
//		ITK_CALL(AOM_save(module_rev));
		ITK_CALL(AOM_refresh(module_rev,1));
	
		printf("\nproperty updated  \n");fflush(stdout);
	   }
	
	 else
	{
		printf("\n Module not found  \n");fflush(stdout);	
	}


	return 0;
}



