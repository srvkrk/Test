#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int ,int ,tag_t , int *);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char     *f        =   NULL;
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sOpt  = ITK_ask_cli_argument("-i=");
	f = ITK_ask_cli_argument("-f=");
	//sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);

	char	*sFrmRpl;
	char	*sToRpl;

//	int		i = 0;
	int		t = 0;
//	int		k = 0;
	//int		l = 0;
	int		n_Input = 3;
	int		nPrtCnt = 0;
	int		n_Cnt = 0;
	int		iPCnt = 0;
	int		bl_qty_form = 0;
	int		brkdncnt = 0;
	int		solnobjcnt = 0;
	int		modulecnt = 0;
	int		VehNocnt = 0;
	char	*values[3];
//	char	*values[1];
	char	*qry_Input[3] = {"Name", "date_released_after", "Release Type"};
	//char	*qry_Input[1] = {"Part Type"};
	tag_t	QryPrt = NULLTAG;
	tag_t	tPrt = NULLTAG;
	tag_t	*tpPrtObjs = NULL;

	char	*sPrtVal = NULL;
	char	*sPrtRev = NULL;
	char	*sPrtTyp = NULL;
	char	*sCPartNum = NULL;
	char	*sCPartRvSq = NULL;
	char	*sCPartQty = NULL;
	char	*FileName = NULL;

	tag_t	window = NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t	tChld = NULLTAG;
	tag_t	*children = NULLTAG;
	tag_t	rel_type = NULLTAG;
	tag_t	rel_type1 = NULLTAG;
	tag_t	rel_type2 = NULLTAG;
	tag_t*	brkdnobjs = NULLTAG;
	tag_t*	VehNos = NULLTAG;
	tag_t	brkdnobj = NULLTAG;
	tag_t	VehNo = NULLTAG;
	tag_t*  moduleno = NULLTAG;
	tag_t  VehNolatestrev = NULLTAG;
    tag_t modulelatestrev = NULLTAG;

	logical lIsQtyModified = false;

	time_t temp; 
    struct tm *timeptr; 
    char pAccessDate[30];
	char *sCurrentDate = NULL;
	char *sCurrentDateDup = NULL;
	char *strToBereplaceddate;
	char *strToBeUsedInsteaddate;
	char *NewVCID = NULL;
	char *NewVCIDRev = NULL;
	char *vehicleno = NULL;
	char *vehrevseq = NULL;
	
	
	char *modulenoname = NULL;
    char *modulerevseq = NULL;
	FILE *fptr;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	FileName =(char *) MEM_alloc(150);
	sCurrentDate =(char *) MEM_alloc(30);
	sCurrentDateDup =(char *) MEM_alloc(30);
	strToBereplaceddate = (char*)malloc(5);
	strToBeUsedInsteaddate = (char*)malloc(5);
//	modulenoname = (char*)malloc(100);
//	modulerevseq = (char*)malloc(50);

	//sVCIDObjStr = (char*)malloc(50);
	//VCIDList = (char**)MEM_alloc(1 * sizeof *VCIDList);
	
	tc_strcpy(sFrmRpl,";");
	tc_strcpy(sToRpl,"*");
	ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRevSeq); 

	printf("\n kk.Querying all ECU Modules\n"); fflush(stdout);

	values[0] = "T5_LcsErcRlzd";
	values[1] = sOpt;
	values[2] = "ECU Parts Release";
	//values[0] = "ECU Module";

    time(&temp); 
    timeptr = localtime(&temp ); 
	tc_strcpy(pAccessDate,"");
    strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr); 
	tc_strcpy(sCurrentDate,pAccessDate);
	tc_strcpy(strToBereplaceddate,"/");
	tc_strcpy(strToBeUsedInsteaddate,"-");



	int n_references = 0;
	int *levels1 = 0;
	tag_t *reference_tags = NULL;
	char **relation_type_name = NULL;
	int num_of_references=0;
	int ii= 0;
	char  type_name1[WSO_name_size_c + 1] = "";

	tag_t DMLLTagn = NULLTAG;
	char *t5current_namen = NULL;

	ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup); 
	//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
      
    printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

	tc_strcpy(FileName,f);
//	tc_strcat(FileName,sCurrentDateDup);
//	tc_strcat(FileName,".csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		exit(1);
	}
 fprintf(fptr,"%s,%s,%s,%s,%s","ECU DML","VCNO","Tech Spec Header","Module Number","Container count");fflush(fptr);
//     fprintf(fptr,"%s,%s,%s,%s","ECU DML","VCID Number","Vehicle Number","Module Number");fflush(fptr);
//	if(QRY_find2("ERCDMLReleased_Type", &QryPrt));
//	if(QryPrt)
//	{
	//	if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObjs));
	//	printf("\n  DML Released count is [%d]\n", nPrtCnt);fflush(stdout);

		if(ITEM_find_item(sOpt,&DMLLTagn)!=ITK_ok)PrintErrorStack();
		 if(ITEM_ask_latest_rev(DMLLTagn,&tPrt)!=ITK_ok)PrintErrorStack();
		ifail = AOM_ask_value_string(tPrt,"current_id",&t5current_namen);
		printf("\n\n\t\t t5current_namen is : %s",t5current_namen);fflush(stdout);

	//	if(nPrtCnt>0)
	//	{	
		//	for(iPCnt=0; iPCnt<nPrtCnt; ++iPCnt)
		//	{
				lIsQtyModified = false;
			///	tPrt = tpPrtObjs[iPCnt];
				ITK_CALL(AOM_ask_value_string(tPrt,"item_id",&sPrtVal));
				ITK_CALL(AOM_ask_value_string(tPrt,"item_revision_id",&sPrtRev));
			
				printf("\nkk.Value is [%s,%s]\n",sPrtVal,sPrtRev);fflush(stdout);

				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&rel_type));

				ITK_CALL(GRM_list_secondary_objects_only(tPrt,rel_type,&brkdncnt,&brkdnobjs));

				printf("\n brkdncnt %d \n", brkdncnt);fflush(stdout);

           if(brkdncnt>0)
			{
				for(t=0;t<brkdncnt;t++)
				{
					brkdnobj = brkdnobjs[t];

					ITK_CALL(AOM_ask_value_string(brkdnobj,"item_id",&NewVCID));
					 ITK_CALL(AOM_ask_value_string(brkdnobj,"item_revision_id",&NewVCIDRev));

					 
				
						printf("\n NewVCID %d : %s/%s \n", t, NewVCID,NewVCIDRev);fflush(stdout);

					 char* DMLBRKID       = NULL;
					 DMLBRKID = (char *) MEM_alloc(5000 * sizeof(char *));
					 tc_strcpy(DMLBRKID,"");
					 tc_strcpy(DMLBRKID,sPrtVal);
					 tc_strcat(DMLBRKID,"_16");


                    printf("\n DMLBRKID %d : %s \n", t, DMLBRKID);fflush(stdout);

///////////////////////////////////////////////////////////////////////////////////////////////

char*	username				= NULL;
	tag_t	root_task				= NULLTAG;
	tag_t	*attachments			= NULLTAG;
	int		ifail					= 0;

	int				i 							= 0;
	int				j 							= 0;
	int				k 							= 0;
	int				l 							= 0;
	int				q							= 0;
	int				count1 						= 0;
	int				count 						= 0;
	int				n_attchs 					= 0;
	int				count_status				= 0;
	int				partcnt						= 0;
	int				sequence_id					= 0;
	//int             NR_REV_CHECK				= 0;

	tag_t			item_tag					= NULLTAG;
	tag_t			*status_list				= NULLTAG;
	tag_t			DMLLcmTag					= NULLTAG;
	tag_t			DMLLTag					= NULLTAG;
	tag_t			class_id					= NULLTAG;
	tag_t			class_id1					= NULLTAG;
	tag_t			tsk_dml_rel_type			= NULLTAG;
	tag_t			*DMLRevision				= NULLTAG;
	tag_t			*secondary_objects			= NULLTAG;
	tag_t			*PartsTag					= NULLTAG;
	tag_t			objTypeTag					= NULLTAG;


	tag_t			DMLRevTag					= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			AssyTag						= NULLTAG;

	char			*status_name				= NULL;

	char			*rev_id						= NULL;
	char			*releaseType				= NULL;
	char			*t5current_name				= NULL;
	char			*s							= NULL;
	char			*class_name					= NULL;
	char			*class_name1				= NULL;
	char		   *projectname					= NULL;
	char		   *DMLNumber					= NULL;
	char		   *taskGrp					    = NULL;
	char		   *current_name				= NULL;
	char		   *t5current_name1				= NULL;
	char		   *object_type					= NULL;
	char		   *Part_no						= NULL;
	char		   *ProjCode						= NULL;
	char		   *tempPart_no					= NULL;
	//char		   type_name=NULL;14.3
	char*		   type_name= NULL;
	char		   *NRRevCheck					= NULL;
	char		   *token						= NULL;
	char		  *masterObjStr =NULL;
	char		   *childWithNR_ERC_Review			 = NULL;

	EPM_decision_t decision						= EPM_go;
	tag_t	CCVCrelation_typeDR	= NULLTAG;
	tag_t	*CCVCTags		= NULLTAG;
	tag_t	VCMasterTag =NULLTAG;
	tag_t   VCLatestRev =NULLTAG;
	char* VCNO =NULL;
	char* vcObjStr =NULL;
	char* vcRevID =NULL;
	char* vcLatestRevID =NULL;
	int CCVCCount =0;
	char    *PartType               = NULL;
	char *VCPartType				= NULL;
	char* VCMasterTagObjStr			= NULL;


	tag_t	VCVehicalDesignMasterTag	= NULLTAG;
	int level 			       =    0;
	int containerCount         =    0;

	childWithNR_ERC_Review						=(char *)MEM_alloc(500);

	tc_strcpy(childWithNR_ERC_Review," ");
	tc_strcat(childWithNR_ERC_Review,"Part No : ");


	char		   *DMLtype						= NULL;
	char		   *DMLNo						= NULL;
	logical is_latest;
	logical VCVehNotAttach =true;
	logical alrozWay =false;
	logical hornbillWay =false;
	tag_t	MasterTag	= NULLTAG;

	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;

	char * ECUCountErrModuleRel		= NULL;
	char* VCTypeErr   =NULL;
	char Container_count_string[50];

	//int  	options;
	int  	n_shared_sites;
	int  	ic=0;
	int		xc=0;
	char	** shared_sites ;
	char* attributeValue		= NULL;
	char* attributeValue1		= NULL;
	tag_t Design_rev_cls_tag    = NULLTAG;
	char    *t5NoEcuDup             = NULL;
	int		t5NoEcuDupint  = 0;
	NRRevCheck=(char *)MEM_alloc(300);
	//

	////For Altroz way Control Object
	tag_t AltrozWayQuery			 = NULLTAG;
	int	   noOfInputAltWay			 = 2;
	char *qryInputForAltWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForAltWay[2]     = {"Project", "AltrozWay"};
	int   AltWayCount				 = 0;
	tag_t *AltWayCnObj				 = NULLTAG;
	char *info1AltrozWay			 = NULL;

	////For Hornbill VCs Control Object
	tag_t HornbillWayQuery			 = NULLTAG;
	int	   noOfInputHornbillWay			 = 2;
	char *qryInputForHornbillWay[2]       = {"SYSCD", "SUBSYSCD"};
	char *qryProjValForHornbillWay[2]     = {"Hornbill_Way_VC", "Hornbill_Way"};
	int   HornbillWayCount				 = 0;
	tag_t *HornbillWayCnObj				 = NULLTAG;

	char *info1HornbillWay			 = NULL;
	char *info2HornbillWay			 = NULL;
	char *info3HornbillWay			 = NULL;
	char *info4HornbillWay			 = NULL;
	char *info5HornbillWay			 = NULL;
	char *info6HornbillWay			 = NULL;
	char *info7HornbillWay			 = NULL;
	char *info8HornbillWay			 = NULL;
	char *info9HornbillWay			 = NULL;
	char *info10HornbillWay			 = NULL;

	char* finalInfoHornbillWay       = NULL;
	int honbill =0;


	//Control Obj for On and Off Validation.
	tag_t	qry_t1_ecuCntVal	= NULLTAG;
	char **qry_val3_ecuCntVal = (char **) MEM_alloc(100 * sizeof(char *));
	char    *qry_entr1_ecuCntVal[1]  = {"SYSCD"};
	int n_entr1_ecuCntVal = 1;
	int rsltCunt1_ecuCntVal=0;
	tag_t *CntrlObjTag1_ecuCntVal=NULLTAG;

	//27-07-2023 : Way of reading Tech Spec Value changed.
	int theAttributeCount =0;
	int *theAttributeIds;
	char **theAttributeNames = NULL;
	int *theAttributeValCounts=0;
	char***       theAttributeValues = NULL;
	char***       theAttributeOptimizedUnits = NULL;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );

	//****************new
	char	*qry_Ip[2]   = {"SYSCD", "SUBSYSCD"};
	char	*qry_Vals[2] = {"Bypass","ECU"};
	int		n_Ip		 = 2;
	int     QCountC		 = 0;
	tag_t QryContObj = NULLTAG;
	tag_t	*CnObjCnt	 = NULLTAG;

	char    *projectlist    = NULL;
	int prjbypassFlag       =0;

					if(tc_strcmp(DMLBRKID,NewVCID)==0)
					{

											/////////////////////////////////////////////////////main

						/*	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
		printf("\n\n\t\t Root task found");
		CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count1,&attachments));
		printf("\n\n\t\t EPM_ask_attachments of :: %d",count1);



		if(count1 > 0)
		{
			DMLLcmTag = attachments[0];
		}*/
		if(ITEM_find_item(DMLBRKID,&DMLLTag)!=ITK_ok)PrintErrorStack();
		 if(ITEM_ask_latest_rev(DMLLTag,&DMLLcmTag)!=ITK_ok)PrintErrorStack();
		ifail = AOM_ask_value_string(DMLLcmTag,"current_id",&DMLBRKID);
		printf("\n\n\t\t DMLBRKID is : %s",DMLBRKID);fflush(stdout);

		 if ( ifail != ITK_ok)
		 {
			 EMH_ask_error_text( ifail,&s);
			 printf("Error with AOM_ask_value_string : %s \n",s);
			 MEM_free(s);
			 return ifail;
		 }

		 ifail = POM_class_of_instance(DMLLcmTag,&class_id);
		 ifail = POM_name_of_class(class_id,&class_name);
		 printf("\n\n\t\t class_name of Task :%s",class_name);fflush(stdout);
		 if(tc_strcmp(class_name,"T5_ChangeTaskRevision")==0 || tc_strcmp(class_name,"ChangeTaskRevision")==0)
		 {
			ifail = GRM_find_relation_type("T5_DMLTaskRelation",&tsk_dml_rel_type);
			if (tsk_dml_rel_type!=NULLTAG)
			{
				ifail = GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count,&DMLRevision);
				printf("\n\n\t\t ***********DML Revision from Task **********: %d",count);fflush(stdout);
			//	for (i=0;i<count ;i++ )//stopped for testing
			//	{//stopped for testing
					ifail = ITEM_rev_sequence_is_latest(DMLRevision[i],&is_latest);
					printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);
					if(is_latest != true)
					{
						printf("\n\n\t\t is_latest is not true .....\n");fflush(stdout);

					} else
					{
						DMLRevTag = DMLRevision[i];

						ifail = AOM_UIF_ask_value(DMLRevTag,"t5_cprojectcode",&projectname);
						printf("\n\n\t\t Projectname from leftObject : %s\n",projectname);fflush(stdout);

						printf("\n\n\t\t is_latest is  true .....\n");fflush(stdout);
						ifail = AOM_ask_value_string(DMLRevTag,"current_name",&current_name);
						printf("\n\n\t\t current_name is :%s\n",current_name);fflush(stdout);

						DMLNumber = strtok( current_name, "_" );
						taskGrp	  = strtok ( NULL, "_" );

						printf("\n\n\t\t DMLNumber is :%s",DMLNumber); fflush(stdout);//chk
						printf("\n\n\t\t taskGrp is :%s",taskGrp); fflush(stdout);//chk

						ifail = AOM_ask_value_int(DMLRevTag,"sequence_id",&sequence_id);
						printf("\n\n\t\t sequence_id is :%d\n",sequence_id);fflush(stdout);

						ifail = POM_class_of_instance(DMLRevTag,&class_id1);
						ifail = POM_name_of_class(class_id1,&class_name1);
						printf("\n\n\t\t class_name found1 :%s",class_name1);

						ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
						printf("\n\n\t\t DMLtype is :%s",DMLtype);fflush(stdout);

						//**********new
						if(QRY_find2("ControlObjQry", &QryContObj));
						if(QryContObj)
						{
						
						  if(QRY_execute(QryContObj, n_Ip, qry_Ip, qry_Vals, &QCountC, &CnObjCnt));

						  printf("\n Control Object found for bypass project == %d\n", QCountC);fflush(stdout);
						  if(QCountC >0)
						  {
							ITK_CALL(AOM_ask_value_string(CnObjCnt[0],"t5_Userinfo1",&projectlist));

							printf("\n bypass INFO 1 ----- [%s]",projectlist); fflush(stdout);//5482

							if(tc_strstr(projectlist,projectname)!=NULL)
							{
								 printf("\n ECUCount_Validation is bypass for =====> [%s]", projectname);fflush(stdout);
								
								  prjbypassFlag=1;
							}
						  }
						}

						if(prjbypassFlag==1)
						{

						printf("\n  ECUCount_Validation is bypass as prjbypassFlag is one \n");fflush(stdout);

						}
						else
						{


						//*******

						if(tc_strcmp(class_name1,"ChangeRequestRevision")==0)
						{
							if(strcmp(DMLtype,"")==0)
							{
								printf("\n\n\t\t t5_rlstype is NULL\n");fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "ERC-DML Type IsNULL, plz update release type as required");
								//decision = EPM_nogo;
								//eturn decision;

							} //If for DML Type check ends
							else
							{
								ifail = AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo);
								printf("\n\n\t\t DMLNo is :%s",DMLNo);fflush(stdout);

								if((strcmp(DMLtype,"EP")==0))
								{
									//Control Object for Validation on and Off.
									if(QRY_find2("ControlObjects",&qry_t1_ecuCntVal));
									if (qry_t1_ecuCntVal)
									{
										printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
									}
									else
									{
										printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
									}
									qry_val3_ecuCntVal[0] = "ECUCntValidationOnECUModule";
									if(QRY_execute(qry_t1_ecuCntVal, n_entr1_ecuCntVal, qry_entr1_ecuCntVal, qry_val3_ecuCntVal,&rsltCunt1_ecuCntVal,&CntrlObjTag1_ecuCntVal));

									if(rsltCunt1_ecuCntVal==1)//chk -tmp
									{
											//22-04-2023:: Honbillway and altroz way cntrl obj queries::
											//altroz way cntrl obj
										/*	if(QRY_find2("ControlObjQry",&AltrozWayQuery));
											if(AltrozWayQuery)
											{
												 if(QRY_execute(AltrozWayQuery, noOfInputAltWay, qryInputForAltWay, qryProjValForAltWay,&AltWayCount,&AltWayCnObj));
												 printf("\n CONT for AltozWay CntrlObj == %d\n", AltWayCount);fflush(stdout);
											}
											else
											{
												printf("\n ContrlObj for AltozWay not found.");fflush(stdout);
											}
											if(AltWayCount >0)
											{
												if (AOM_ask_value_string(AltWayCnObj[0],"t5_Userinfo1",&info1AltrozWay)!=ITK_ok);
												printf("\n Altroz Way Project Codes List [%s]",info1AltrozWay); fflush(stdout);
											}

											//Honbillway
											//222-Nov-2022 Control object for Hornbill VCs::

											if(QRY_find2("ControlObjQry",&HornbillWayQuery));
											if(HornbillWayQuery)
											{
												 if(QRY_execute(HornbillWayQuery, noOfInputHornbillWay, qryInputForHornbillWay, qryProjValForHornbillWay,&HornbillWayCount,&HornbillWayCnObj));
												 printf("\n CONT for HornbillWay CntrlObj == %d\n", HornbillWayCount);fflush(stdout);
											}
											else
											{
												printf("\n ContrlObj for HornbillWay not found.");fflush(stdout);
											}
											if(HornbillWayCount >0)
											{
													finalInfoHornbillWay = (char *) MEM_alloc(5000 * sizeof(char *));

													for(honbill =0;honbill < HornbillWayCount ;honbill++)
													{
														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo1",&info1HornbillWay)!=ITK_ok);
														printf("\n info1HornbillWay Project Codes List [%s]",info1HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo2",&info2HornbillWay)!=ITK_ok);
														printf("\n info2HornbillWay Project Codes List [%s]",info2HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo3",&info3HornbillWay)!=ITK_ok);
														printf("\n info3HornbillWay Project Codes List [%s]",info3HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo4",&info4HornbillWay)!=ITK_ok);
														printf("\n info4HornbillWay Project Codes List [%s]",info4HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo5",&info5HornbillWay)!=ITK_ok);
														printf("\n info5HornbillWay Project Codes List [%s]",info5HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo6",&info6HornbillWay)!=ITK_ok);
														printf("\n info6HornbillWay Project Codes List [%s]",info6HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo7",&info7HornbillWay)!=ITK_ok);
														printf("\n info7HornbillWay Project Codes List [%s]",info7HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo8",&info8HornbillWay)!=ITK_ok);
														printf("\n info8HornbillWay Project Codes List [%s]",info1HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_Userinfo9",&info9HornbillWay)!=ITK_ok);
														printf("\n info9HornbillWay Project Codes List [%s]",info9HornbillWay); fflush(stdout);

														if (AOM_ask_value_string(HornbillWayCnObj[honbill],"t5_userinfo10 ",&info10HornbillWay)!=ITK_ok);
														printf("\n info10HornbillWay Project Codes List [%s]",info10HornbillWay); fflush(stdout);

														if(info1HornbillWay == NULL)
														{
															tc_strcat(info1HornbillWay,"");
														}
														if(info2HornbillWay == NULL)
														{
															tc_strcat(info2HornbillWay,"");
														}
														if(info3HornbillWay == NULL)
														{
															tc_strcat(info3HornbillWay,"");
														}
														if(info4HornbillWay == NULL)
														{
															tc_strcat(info4HornbillWay,"");
														}
														if(info5HornbillWay == NULL)
														{
															tc_strcat(info5HornbillWay,"");
														}
														if(info6HornbillWay == NULL)
														{
															tc_strcat(info6HornbillWay,"");
														}
														if(info7HornbillWay == NULL)
														{
															tc_strcat(info7HornbillWay,"");
														}
														if(info8HornbillWay == NULL)
														{
															tc_strcat(info8HornbillWay,"");
														}
														if(info9HornbillWay == NULL)
														{
															tc_strcat(info9HornbillWay,"");
														}
														if(info10HornbillWay == NULL)
														{
															tc_strcat(info10HornbillWay,"");
														}



														if(finalInfoHornbillWay == NULL)
														{
															tc_strcpy(finalInfoHornbillWay,"");
															tc_strcat(finalInfoHornbillWay,info1HornbillWay);
															tc_strcat(finalInfoHornbillWay,info2HornbillWay);
															tc_strcat(finalInfoHornbillWay,info3HornbillWay);
															tc_strcat(finalInfoHornbillWay,info4HornbillWay);
															tc_strcat(finalInfoHornbillWay,info5HornbillWay);
															tc_strcat(finalInfoHornbillWay,info6HornbillWay);
															tc_strcat(finalInfoHornbillWay,info7HornbillWay);
															tc_strcat(finalInfoHornbillWay,info8HornbillWay);
															tc_strcat(finalInfoHornbillWay,info9HornbillWay);
															tc_strcat(finalInfoHornbillWay,info10HornbillWay);
														}
														else
														{
															tc_strcat(finalInfoHornbillWay,info1HornbillWay);
															tc_strcat(finalInfoHornbillWay,info2HornbillWay);
															tc_strcat(finalInfoHornbillWay,info3HornbillWay);
															tc_strcat(finalInfoHornbillWay,info4HornbillWay);
															tc_strcat(finalInfoHornbillWay,info5HornbillWay);
															tc_strcat(finalInfoHornbillWay,info6HornbillWay);
															tc_strcat(finalInfoHornbillWay,info7HornbillWay);
															tc_strcat(finalInfoHornbillWay,info8HornbillWay);
															tc_strcat(finalInfoHornbillWay,info9HornbillWay);
															tc_strcat(finalInfoHornbillWay,info10HornbillWay);

														}

												 }


											}
											printf("\n\t finalInfoHornbillWay string value After concat: %s\n \n",finalInfoHornbillWay);*/

											printf("\n\n\t\t Validation is ON ::: Check_ECU_Count_Validation_For_ECUModule");fflush(stdout);
											// Validation check for ECU Part release DML only
											ifail = GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
											if (relation_type!=NULLTAG)
											{
												ifail = GRM_list_secondary_objects_only(DMLRevTag,relation_type,&n_attchs,&secondary_objects);
												printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);

												if(n_attchs>0)
												{
													 for (j=0;j<n_attchs;j++ )
													 {
														   ifail = AOM_ask_value_string(secondary_objects[j],"current_id",&t5current_name1);
														   printf("\n\n\t\t t5current_name1 is :%s",t5current_name1);fflush(stdout);
														   if ( ifail != ITK_ok)
														   {
															 //EMH_ask_error_text( status,&s);
															 printf("Error with AOM_ask_value_string2 : %s \n",s);
															// MEM_free(s);
															 //return status;
														   }
														   else
														   {
															   ifail = AOM_ask_value_string(secondary_objects[j],"object_type",&object_type);
																printf("\n\n\t\t object_type is :%s",object_type);fflush(stdout);
																if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
																{
																	ifail = AOM_ask_value_tags(secondary_objects[j],"CMHasSolutionItem",&partcnt,&PartsTag);
																	printf("\n\n\t\t No. of Part in Solution Folder :%d \n",partcnt);fflush(stdout);

																	if (partcnt>0)
																	{
																		//This is the loop for Solution items present in Solution folder of DML:
																		for (k=0;k<partcnt ;k++ )
																		{
																				AssyTag=PartsTag[k];
																				ifail = AOM_ask_value_string(AssyTag,"object_string",&Part_no);
																				printf("\n\n\t\t Part_no  is :%s \n",Part_no);	fflush(stdout);

																				ProjCode=subString(Part_no,0,4);
																				printf("\n  ProjCode is ------------- [%s]\n",ProjCode);fflush(stdout);

																				ifail = TCTYPE_ask_object_type(AssyTag,&objTypeTag);
																				//ifail = TCTYPE_ask_name2(objTypeTag,type_name);14.3
																				ifail = TCTYPE_ask_name2(objTypeTag,&type_name);
																				printf("\n\n\t\t AssyTag type_name := %s \n",type_name);fflush(stdout);

																				ITEM_ask_item_of_rev(AssyTag,&MasterTag);
																				ifail = AOM_ask_value_string(MasterTag,"object_string",&masterObjStr);

																				ifail = AOM_ask_value_string(AssyTag,"t5_PartType",&PartType);
																				printf("\n\n\t\t t5_PartType := %s \n",PartType);fflush(stdout);

																				if(((strcmp(PartType,"EM")==0) && ((strstr(Part_no,"K2A01")!=NULL) || (strstr(Part_no,"E4Z01")!=NULL))) || (strcmp(PartType,"T")==0))
																				{

																					printf("\n ******* ECU Module Found ************");
																					ifail = GRM_find_relation_type("T5_CCVCHasECUModule",&CCVCrelation_typeDR);
																					ifail = GRM_list_primary_objects_only(MasterTag,CCVCrelation_typeDR,&CCVCCount,&CCVCTags);//Getting where ref om module master

																					printf("\n\n\t\t CCVCCount := %d \n",CCVCCount);fflush(stdout);

																					if(CCVCCount >0 )
																					{
																						for(q=0;q <CCVCCount ;q++)
																						{
																							printf("\n\n\t\t ************I am in for loop of VC and Value of counter is  := %d************* \n",q);fflush(stdout);

																							alrozWay =false;
																							hornbillWay =false;
																							////22-Nov-2022 Control ojbect for Altroz Way
																							//22-04-2023 All control object Querie need to move out of for Loop;
																							VCVehNotAttach =true;

																							if(AOM_ask_value_string(CCVCTags[q],"object_string",&vcObjStr)==ITK_ok);
																							printf("\n  VC vcObjStr  is  = [%s]\n", vcObjStr);fflush(stdout);

																							if(AOM_ask_value_string(CCVCTags[q],"item_id",&VCNO)==ITK_ok);
																							printf("\n  VC item_id  is  = [%s]\n", VCNO);fflush(stdout);

																							AOM_ask_value_string(CCVCTags[q],"t5_PartType",&VCPartType);
																							printf("\n  VC t5_PartType  is  = [%s]\n", VCPartType);fflush(stdout);

																							//24-04-2023 :: Need to process VC/V only if it is latest, if not latest then need to skip.
																							AOM_ask_value_string(CCVCTags[q],"item_revision_id",&vcRevID);
																							printf("\n VCRevID  is  = [%s]\n", vcRevID);fflush(stdout);

																							//Getting Master of VC
																							ITEM_ask_item_of_rev(CCVCTags[q],&VCMasterTag);
																							ifail = AOM_ask_value_string(VCMasterTag,"object_string",&VCMasterTagObjStr);
																							printf("\n VCMasterTagObjStr  is  = [%s]\n", VCMasterTagObjStr);fflush(stdout);

																							ITEM_ask_latest_rev(VCMasterTag,&VCLatestRev);
																							AOM_ask_value_string(VCLatestRev,"item_revision_id",&vcLatestRevID);
																							printf("\n vcLatestRevID  is  = [%s]\n", vcLatestRevID);fflush(stdout);



																							///new
																							int statuscntcurrent=0;
																					        int stcurrnt =0;																							
																							tag_t* Relstatuscurrent = NULLTAG;
																							char *Chld_Rel_current = NULL;
																							char *Relstatusscurrent = (char*)MEM_alloc(sizeof(char) * 250);
																							ITK_CALL(WSOM_ask_release_status_list(CCVCTags[q],&statuscntcurrent,&Relstatuscurrent));
																							 printf("\n statuscntcurrent:%d.", statuscntcurrent);fflush(stdout);
																							 if(statuscntcurrent > 0)
																								 {
																									for(stcurrnt=0;stcurrnt<statuscntcurrent;stcurrnt++)
																									{
																										if(AOM_ask_value_string (Relstatuscurrent[stcurrnt], "object_name", &Chld_Rel_current)!=ITK_ok)PrintErrorStack();
																										
																										printf("\n Chld_Rel_current:%s", Chld_Rel_current);fflush(stdout);
																										if((tc_strstr(Chld_Rel_current,"ERC Released")!=NULL) || (tc_strstr(Chld_Rel_current,"T5_LcsErcRlzd")!=NULL))
																										{
																											tc_strcat(Relstatusscurrent,Chld_Rel_current);
																											tc_strcat(Relstatusscurrent,",");
																										}
																									}
																								 }
																								 if ((tc_strstr(Relstatusscurrent,"ERC Released")!=NULL) || (tc_strstr(Relstatusscurrent,"T5_LcsErcRlzd")!=NULL))
																								{
																								
																							



																							//////NEW END

																							/////////

																							int statuscntlatest=0;
																							int stlatest =0;
																							int ERCRels=0;
																							tag_t* Relstatuslatest = NULLTAG;
																							char *Chld_Rel_StussLatest = NULL;
																							char *Relstatusslatest = (char*)MEM_alloc(sizeof(char) * 250);

																							 ITK_CALL(WSOM_ask_release_status_list(VCLatestRev,&statuscntlatest,&Relstatuslatest));

																								 printf("\n statuscntlatest:%d.", statuscntlatest);fflush(stdout);

																								 if(statuscntlatest > 0)
																								 {
																									for(stlatest=0;stlatest<statuscntlatest;stlatest++)
																									{
																										if(AOM_ask_value_string (Relstatuslatest[stlatest], "object_name", &Chld_Rel_StussLatest)!=ITK_ok)PrintErrorStack();
																										
																										printf("\n Chld_Rel_StussLatest:%s", Chld_Rel_StussLatest);fflush(stdout);
																										if((tc_strstr(Chld_Rel_StussLatest,"ERC Released")!=NULL) || (tc_strstr(Chld_Rel_StussLatest,"T5_LcsErcRlzd")!=NULL))
																										{
																											tc_strcat(Relstatusslatest,Chld_Rel_StussLatest);
																											tc_strcat(Relstatusslatest,",");
																										}
																									}
																								 }

																								 printf("\n Relstatusslatest ----- [%s]",Relstatusslatest); fflush(stdout);

																								if ((tc_strstr(Relstatusslatest,"ERC Released")!=NULL) || (tc_strstr(Relstatusslatest,"T5_LcsErcRlzd")!=NULL))
																								{
																									
																									ERCRels=1;
																									

																																 
																								}








																							int statuscnt=0;
																							tag_t* Relstatus = NULLTAG;
																							int st=0;
																							char *Chld_Rel_Stuss = NULL;
																							char *Relstatussnew = (char*)MEM_alloc(sizeof(char) * 250);
																							int allrevcount=0;
																							tag_t *rev_list = NULLTAG;
																							tag_t rev = NULLTAG;
																							char* id =NULL;
                                                                                            char* idrev =NULL;


																							ITK_CALL(ITEM_list_all_revs(VCMasterTag,&allrevcount,&rev_list));
																							printf("\n allrevcount=%d \n",allrevcount);fflush(stdout);

																							 for(i=allrevcount-1;i>-1;i--)
																							  {
																								 tc_strcpy(Relstatussnew,"");
																								 printf("\n inside for loop \n ");fflush(stdout);

																								 rev=rev_list[i];

																								 ITK_CALL(AOM_ask_value_string(rev,"item_id",&id));
																								 ITK_CALL(AOM_ask_value_string(rev,"item_revision_id",&idrev));

																								 ITK_CALL(WSOM_ask_release_status_list(rev,&statuscnt,&Relstatus));

																								 printf("\n Rel_Stuss:%d.", statuscnt);fflush(stdout);

																								 if(statuscnt > 0)
																								 {
																									for(st=0;st<statuscnt;st++)
																									{
																										if(AOM_ask_value_string (Relstatus[st], "object_name", &Chld_Rel_Stuss)!=ITK_ok)PrintErrorStack();
																										
																										printf("\n Rel_Stuss:%s", Chld_Rel_Stuss);fflush(stdout);
																										if((tc_strstr(Chld_Rel_Stuss,"ERC Released")!=NULL) || (tc_strstr(Chld_Rel_Stuss,"T5_LcsErcRlzd")!=NULL))
																										{
																											tc_strcat(Relstatussnew,Chld_Rel_Stuss);
																											tc_strcat(Relstatussnew,",");
																										}
																									}
																								 }

																								 printf("\n Relstatussnew ----- [%s]",Relstatussnew); fflush(stdout);

																								if ((tc_strstr(Relstatussnew,"ERC Released")!=NULL) || (tc_strstr(Relstatussnew,"T5_LcsErcRlzd")!=NULL))
																								{
																									
																									printf("\n latest release found ----- [%s]",idrev); fflush(stdout);
																									break;

																																 
																								}

																								

																							  }

																							  printf("\n latest release revision is ----- [%s]",idrev); fflush(stdout);










																							///////



																							if(((strcmp(vcLatestRevID,vcRevID)==0) && (ERCRels==1)) || (strcmp(idrev,vcRevID)==0))
																							{
																										printf("\n\t Latest VC Rev Found and need to process");fflush(stdout);


																										//**********New
																										if((tc_strcmp(VCPartType,"V")==0) || (tc_strcmp(VCPartType,"VCCR")==0))
																										{
																											ITEM_ask_item_of_rev(CCVCTags[q],&VCVehicalDesignMasterTag);
																											(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
																											if(Design_rev_cls_tag)
																											{
																												ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
																												if(theAttributeCount>0)
																												{
																													for(ic=0;ic<theAttributeCount;ic++)
																													{
																														sprintf(attrId,"%d",theAttributeIds[ic]);

																														tc_strcpy(attributeNameDup,"");
																														tc_strcpy(attributeNameDup,theAttributeNames[ic]);
																														//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,ic);fflush(stdout);

																														if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
																														{
																															tc_strcpy(attributeValueDup,"");
																															for(xc=0;xc<theAttributeValCounts[ic];xc++)
																															{
																																//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
																																tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
																																//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
																															}

																															printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
																															printf("\n attrId:[%s]",attrId);fflush(stdout);
																															printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

																															t5NoEcuDupint=atoi(attributeValueDup);
																															printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10

																														}

																													}
																												}
																											}
																											else
																											{
																												printf("\n Design_rev_cls_tag NOT Found...");fflush(stdout);
																											}
																										
																										
																																								
																										 VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,AssyTag,&containerCount);//new

																										  printf("\n ******************final count of containers  is  ****************** [%d] \n",containerCount);fflush(stdout);

																										  if(containerCount==t5NoEcuDupint)
																										  {
																											  printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
																											   //new
																											//   sprintf(Container_count_string,"%d", containerCount);
																											//	 fprintf(fptr,"\n%s,%s/%s,%s,%s,%s",sPrtVal,VCNO,vcRevID,attributeValueDup,Part_no,Container_count_string);
																												
																											 
																											 
																										  }
																										  else
																										  {
																												printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
																												printf("\n VCNO is : %s \n",VCNO);fflush(stdout);
																												printf("\n ModulNo is : %s \n",Part_no);fflush(stdout);
																												sprintf(Container_count_string,"%d", containerCount);
																												if (tc_strcmp(ECUCountErrModuleRel,"NULL") !=0) MEM_free(ECUCountErrModuleRel);
																												ECUCountErrModuleRel=(char *)MEM_alloc(600);
																												tc_strcpy(ECUCountErrModuleRel,"VC Attribute with Name 'Total number of ECUs' attribute value in Tech Spec Header of Vehicle/CCV ");
																												tc_strcat(ECUCountErrModuleRel,VCNO);
																												tc_strcat(ECUCountErrModuleRel," is ");
																												tc_strcat(ECUCountErrModuleRel,attributeValueDup);
																												tc_strcat(ECUCountErrModuleRel,"\nNo. of Containers in ECU Module ");
																												tc_strcat(ECUCountErrModuleRel,Part_no);
																												tc_strcat(ECUCountErrModuleRel," for vehicle/ccv ");
																												tc_strcat(ECUCountErrModuleRel,VCNO);
																												tc_strcat(ECUCountErrModuleRel," is ");
																												tc_strcat(ECUCountErrModuleRel,Container_count_string);

																												//printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);
																												//printf("\n EMH_severity_error= [%s] \n",ECUCountErrModuleRel);fflush(stdout);

																											/*	EMH_clear_errors();
																												EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErrModuleRel);
																												decision = EPM_nogo;
																												return decision;*/
																												 printf("\n cECUCountErrModuleRel=[%s] \n",ECUCountErrModuleRel);fflush(stdout);

																												 //new
																												 fprintf(fptr,"\n%s,%s/%s,%s,%s,%s",sPrtVal,VCNO,vcRevID,attributeValueDup,Part_no,Container_count_string);
																										  }

																										  containerCount = 0;
																										  t5NoEcuDupint = 0;




																										}
																										else
																										{
																											printf("\n\t VCPartType is other than V and VCCR..");fflush(stdout);
																										}
																										




																										//*****

//																										//Here Altroz way and Hornbill way logic will come
//																										//if((tc_strstr(info1HornbillWay,VCNO) != NULL || tc_strcmp(ProjCode,"5445")==0) && tc_strcmp(VCPartType,"CCVC")==0)
//																										if((tc_strstr(finalInfoHornbillWay,VCNO) != NULL || tc_strcmp(ProjCode,"5445")==0) && tc_strcmp(VCPartType,"CCVC")==0)
//																										{
//																											printf("\n inside Hornwill way, VC with proj %s \n",ProjCode);fflush(stdout);
//																											//VehVcTag = DesignRevTag;
//																											hornbillWay =true;
//
//																										}
//																										//else if(tc_strstr(info1AltrozWay,ProjDup) != NULL || tc_strcmp(ProjDup,"5477")==0 && tc_strcmp(VCPartType,"V")==0)
//																										else if((tc_strstr(info1AltrozWay,ProjCode) != NULL || tc_strcmp(ProjCode,"5477")==0) && tc_strcmp(VCPartType,"V")==0)
//																										{
//																											printf("\n inside Altroz way, VC with proj %s \n",ProjCode);
//
//																											alrozWay =true;
//																											//VehVcTag = DesignRevTag;
//																											//sTmpNum=subString(VCnumber,0,8);
//																											//tc_strcpy(VCnumberDup,sTmpNum);
//																											//tc_strcat(VCnumberDup,"000R");
//																											//printf("\nConcatenated VC number is [%s]\n",VCnumberDup);fflush(stdout);
//																										}
//																										else
//																										{
//																											printf("\nContinuing...\n");  fflush(stdout);
//																											continue;
//																										}
//																										//Hornbill way , Altroze way condition:
//																										if(hornbillWay && tc_strcmp(VCPartType,"CCVC")==0)
//																										{
//																											ITEM_ask_item_of_rev(CCVCTags[q],&VCVehicalDesignMasterTag);
//																											(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
//																											if(Design_rev_cls_tag)
//																											{
//																												ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
//																												if(theAttributeCount>0)
//																												{
//																													for(ic=0;ic<theAttributeCount;ic++)
//																													{
//																														sprintf(attrId,"%d",theAttributeIds[ic]);
//
//																														tc_strcpy(attributeNameDup,"");
//																														tc_strcpy(attributeNameDup,theAttributeNames[ic]);
//																														//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,ic);fflush(stdout);
//
//																														if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
//																														{
//																															tc_strcpy(attributeValueDup,"");
//																															for(xc=0;xc<theAttributeValCounts[ic];xc++)
//																															{
//																																//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
//																																tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
//																																//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
//																															}
//
//																															printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
//																															printf("\n attrId:[%s]",attrId);fflush(stdout);
//																															printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
//
//																															t5NoEcuDupint=atoi(attributeValueDup);
//																															printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10
//
//																														}
//
//																													}
//																												}
//																											}
//																											else
//																											{
//																												printf("\n Design_rev_cls_tag NOT Found...");fflush(stdout);
//																											}
////																											CALLAPI(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
////
////																											printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
////																											for(ic=0;ic<n_lov_entries;ic++)
////																											{
////																												printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
////																												(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
////
////																												(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));
////
////																												printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
////																												if(tc_strcmp(attributeValue,lov_keys[ic])==0)
////																												{
////																													printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);
////
////																													t5NoEcuDup		   =(char *) MEM_alloc(20);
////																													tc_strcpy(t5NoEcuDup,lov_values[ic]);
////
////																													printf("\n******************** ECU COUNT IS ************ =%s",t5NoEcuDup); fflush(stdout);//10
////
////																													t5NoEcuDupint=atoi(t5NoEcuDup);
////
////																													printf("\n *******************final ECU COUNT is t5NoEcuDupint *********** =%d",t5NoEcuDupint); fflush(stdout);//10
////
////																												}
////
////																											}
//																										}
//																										else if(alrozWay && tc_strcmp(VCPartType,"V")==0)
//																										{
//																											ITEM_ask_item_of_rev(CCVCTags[q],&VCVehicalDesignMasterTag);
//																											(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
//
//																											if(Design_rev_cls_tag)
//																											{
//																														ITK_CALL( ICS_ico_ask_attributes_optimized(Design_rev_cls_tag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
//																														if(theAttributeCount>0)
//																														{
//																															for(ic=0;ic<theAttributeCount;ic++)
//																															{
//																																sprintf(attrId,"%d",theAttributeIds[ic]);
//
//																																tc_strcpy(attributeNameDup,"");
//																																tc_strcpy(attributeNameDup,theAttributeNames[ic]);
//																																//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,ic);fflush(stdout);
//
//																																if(tc_strcmp(attributeNameDup,"Total number of ECUs")==0)
//																																{
//																																	tc_strcpy(attributeValueDup,"");
//																																	for(xc=0;xc<theAttributeValCounts[ic];xc++)
//																																	{
//																																		//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
//																																		tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
//																																		//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
//																																	}
//
//																																	printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
//																																	printf("\n attrId:[%s]",attrId);fflush(stdout);
//																																	printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
//
//																																	t5NoEcuDupint=atoi(attributeValueDup);
//																																	printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10
//
//																																}
//
//																															}
//																														}
//																											}
//																											else
//																											{
//																												printf("\n Design_rev_cls_tag NOT Found...");fflush(stdout);
//																											}
//
////																											CALLAPI(ICS_keylov_get_keylov("-8226",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
////
////																											printf("\n VC validation key_lov_name===[%s]--- n_lov_entries===[%d]--- options===[%d]\n",key_lov_name,n_lov_entries,options); fflush(stdout);
////																											for(ic=0;ic<n_lov_entries;ic++)
////																											{
////																												printf("\n lov_keys=[%s] lov_values=[%s]\n",lov_keys[ic],lov_values[ic]); fflush(stdout);
////																												(ICS_ask_classification_object(VCVehicalDesignMasterTag,&Design_rev_cls_tag));
////
////																												(ICS_ask_attribute_value	(Design_rev_cls_tag,"8226",&attributeValue));
////
////																												printf("\n attributeValue:::::: [%s] ",attributeValue); fflush(stdout);
////																												if(tc_strcmp(attributeValue,lov_keys[ic])==0)
////																												{
////																													printf("\n Value of classified object: \n Mascot lov_keys=%s lov_values=%s",lov_keys[ic],lov_values[ic]); fflush(stdout);
////
////																													t5NoEcuDup		   =(char *) MEM_alloc(20);
////																													tc_strcpy(t5NoEcuDup,lov_values[ic]);
////
////																													printf("\n******************** ECU COUNT IS ************ =%s",t5NoEcuDup); fflush(stdout);//10
////
////																													t5NoEcuDupint=atoi(t5NoEcuDup);
////
////																													printf("\n *******************final ECU COUNT is t5NoEcuDupint *********** =%d",t5NoEcuDupint); fflush(stdout);//10
////
////																												}
////
////																											}
//
//
//																										}
//																										else
//																										{
//																												if(hornbillWay)
//																												{
//																													printf("This VC is Hornbill way, i.e Part type should be 'CCVC'");
//
//																													//Give Error
//																													if (tc_strcmp(VCTypeErr,"NULL") !=0) MEM_free(VCTypeErr);
//																													VCTypeErr=(char *)MEM_alloc(600);
//																													tc_strcpy(VCTypeErr,"This  ");
//																													tc_strcat(VCTypeErr,VCNO);
//																													tc_strcat(VCTypeErr,", is of Hornbill way,  Part type should be CCVC, ECU Module no :");
//																													tc_strcat(VCTypeErr,Part_no);
//
//																													//printf("\n EMH_severity_error= [%s] \n",VCTypeErr);fflush(stdout);
//
//																												/*	EMH_clear_errors();
//																													EMH_store_error_s1(EMH_severity_error,ITK_err,VCTypeErr);
//																													decision = EPM_nogo;
//																													return decision;*/
//																													printf("\n VCTypeErr=[%s] \n",VCTypeErr);fflush(stdout);
//
//																												}
//																												if (alrozWay)
//																												{
//																													printf("This VC is alrozWay way, i.e Part type should be 'V'");
//																													//Give Error
//																													if (tc_strcmp(VCTypeErr,"NULL") !=0) MEM_free(VCTypeErr);
//																													VCTypeErr=(char *)MEM_alloc(600);
//																													tc_strcpy(VCTypeErr,"This  ");
//																													tc_strcat(VCTypeErr,VCNO);
//																													tc_strcat(VCTypeErr,", is of alroz way,  Part type should be V,, ECU Module no :");
//																													tc_strcat(VCTypeErr,Part_no);
//
//																													//printf("\n EMH_severity_error= [%s] \n",VCTypeErr);fflush(stdout);
//
//																												/*	EMH_clear_errors();
//																													EMH_store_error_s1(EMH_severity_error,ITK_err,VCTypeErr);
//																													decision = EPM_nogo;
//																													return decision;*/
//																													 printf("\n VCTypeErr=[%s] \n",VCTypeErr);fflush(stdout);
//																												}
//																										}
																										// Need to match ECU count for each VC
//																										//  VC_Multi_Get_Part_BOM_Lvl_Col_SW_for_ECU_Release(99,level,AssyTag,&containerCount);//chk
//																										 VC_Multi_Get_Part_BOM_Lvl_Col_SW(99,level,AssyTag,&containerCount);//new
//
//																										  printf("\n ******************final count of containers  is  ****************** [%d] \n",containerCount);fflush(stdout);
//
//																										  if(containerCount==t5NoEcuDupint)
//																										  {
//																											  printf("\n count matching well done S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
//																										  }
//																										  else
//																										  {
//																												printf("\n count does not match S= [%d] ICS = [%d]\n",containerCount,t5NoEcuDupint);fflush(stdout);
//																												printf("\n VCNO is : %s \n",VCNO);fflush(stdout);
//																												printf("\n ModulNo is : %s \n",Part_no);fflush(stdout);
//																												sprintf(Container_count_string,"%d", containerCount);
//																												if (tc_strcmp(ECUCountErrModuleRel,"NULL") !=0) MEM_free(ECUCountErrModuleRel);
//																												ECUCountErrModuleRel=(char *)MEM_alloc(600);
//																												tc_strcpy(ECUCountErrModuleRel,"VC Attribute with Name 'Total number of ECUs' attribute value in Tech Spec Header of Vehicle/CCV ");
//																												tc_strcat(ECUCountErrModuleRel,VCNO);
//																												tc_strcat(ECUCountErrModuleRel," is ");
//																												tc_strcat(ECUCountErrModuleRel,attributeValueDup);
//																												tc_strcat(ECUCountErrModuleRel,"\nNo. of Containers in ECU Module ");
//																												tc_strcat(ECUCountErrModuleRel,Part_no);
//																												tc_strcat(ECUCountErrModuleRel," for vehicle/ccv ");
//																												tc_strcat(ECUCountErrModuleRel,VCNO);
//																												tc_strcat(ECUCountErrModuleRel," is ");
//																												tc_strcat(ECUCountErrModuleRel,Container_count_string);
//
//																												//printf("\n ECUCountErr= [%s] \n",ECUCountErr);fflush(stdout);
//																												//printf("\n EMH_severity_error= [%s] \n",ECUCountErrModuleRel);fflush(stdout);
//
//																											/*	EMH_clear_errors();
//																												EMH_store_error_s1(EMH_severity_error,ITK_err,ECUCountErrModuleRel);
//																												decision = EPM_nogo;
//																												return decision;*/
//																												 printf("\n cECUCountErrModuleRel=[%s] \n",ECUCountErrModuleRel);fflush(stdout);
//																										  }
//
//																										  containerCount = 0;
//																										  t5NoEcuDupint = 0;
																							}
																							else
																							{
																								printf("\n\t Latest VC Rev NOT Found and need to Skip..!!!");fflush(stdout);
																							}

																						 }//new for skip VC which is review
																						 else
																							{

																							  printf("\n skip VC which is Not Release ----- [%s]",vcObjStr); fflush(stdout);


																							}

																						}// VC For Loop ends
																					}
																					else
																					{
																						 printf("\n No CCVC / V is attached to ECU Module."); fflush(stdout);
																						//VCVehNotAttach =false;
																					}
//																						//If CCVC or V is attached then apply this check.
//																						if(VCVehNotAttach)
//																						{
//
//																						}// if for VC Vech Attached

																				}// ECU Module Check

																				//containerCount = 0;
																				//t5NoEcuDupint = 0;
																		}// For loop for Solution Items end:
																	}

																}//If for T5_ChangeTaskRevision ends
																
														   }
													 }
												}
										}
									}
									else
									{
										printf("\n\n\t\t Validation is OFF ::: Check_ECU_Count_Validation_For_ECUModule");
									}

								}// If for EP DML Type ends
							}

						}// if for ChangeRequestRevision class check ends

					}//Avinya project bypass



					}

		//		}// For DML Revision end ////stopped for testing

			} //if for tsk_dml_rel_type relation null check

		 } //If for T5_ChangeTaskRevision ends



	    

	// If of DBA Users ends
	if(finalInfoHornbillWay !=NULL)
		MEM_free(finalInfoHornbillWay);

	if(theAttributeNames !=NULL)
		MEM_free(theAttributeNames);

	if(theAttributeValues !=NULL)
		MEM_free(theAttributeValues);

	if(theAttributeOptimizedUnits !=NULL)
		MEM_free(theAttributeOptimizedUnits);

	if(attributeNameDup !=NULL)
		MEM_free(attributeNameDup);

	if(attributeValueDup !=NULL)
		MEM_free(attributeValueDup);



	   













					////////////////////////////////////////////////////main end








					}

						

						
						
						
///////////////////////////////////////////////////////////////////////////////////////////							
				}

				   MEM_free(brkdnobjs);
			}
			else
			{
			fprintf(fptr,"\n%s",sPrtVal);
			}
				
                printf("\n **************************************CHEKING FOR NEXT DML*********************************** \n");
               
		//  }for
		  

	//	}partcnt
		
	//}reltype
     
	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

/*	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

///////////////
int GValue=1000;
int VC_Multi_Get_Part_BOM_Lvl_Col_SW(int reqLevel,int level,tag_t Mod_rev_tag, int *containerCount)
{
	int ifail;
	int status = 0;
	int iChildItemTag=0;
	char * ItemName;
	int k		    =0;
	int n_Cnt	    =0;
	int assbvr	    =0;
	int flagBVR	    =0;
	int n_values_bvr=0;

	tag_t   t_ChildItemRev;
	//tag_t	window 	    = NULLTAG;

	tag_t	top_line    = NULLTAG;
	int bvrfound		= 0;
	tag_t  *children	= NULLTAG;
	char* partNumber 	= NULL;
	char* PartType      = NULL;
	char* EE_PartType      = NULL;
	char* LatChildName      = NULL;
	char* ObjType       = NULL;
	char* BLObjType     = NULL;
	tag_t	sn_rule		= NULLTAG;
	tag_t	window		= NULLTAG;


	printf("\n INSIDE MULTI LEVEL EXP FUNCTION \n");fflush(stdout);

	if(level == reqLevel) goto CLEANUP;
	ITK_CALL(BOM_create_window (&window)); //3 sept

	ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept

	ITK_CALL(CFM_find("ERC Review And Above",&sn_rule ));

	ITK_CALL(BOM_set_window_config_rule( window, sn_rule ));

	ITK_CALL(BOM_set_window_top_line (window, null_tag,Mod_rev_tag,null_tag,&top_line));

	ITK_CALL(BOM_window_show_suppressed (window));

	printf("\n after BOM_set_window_top_line in VC_Multi_Get_Part_BOM_Lvl_1 \n");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITK_CALL(BOM_line_ask_child_lines (top_line,&n_Cnt,&children)); //3 sept
	printf("\n\n\t\t **** No of child objects are n level :: %d :: %d\n",level, n_Cnt);fflush(stdout);

	if(n_Cnt == 0) goto CLEANUP;
	for (k = 0; k < n_Cnt; k++)
	  {
		BOM_line_unpack (children[k]);
		//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag ,&iChildItemTag);
		//BOM_line_ask_attribute_tag(children[k], iChildItemTag,&t_ChildItemRev);

		if( AOM_ask_value_tag(children[k],"bl_line_object",&t_ChildItemRev)!=ITK_ok);

		if(t_ChildItemRev!=NULLTAG)
		{
			//if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_SwPartType",&PartType)!=ITK_ok);
			printf("\n t_ChildItemRev Part type  ===>%s\n",PartType);fflush(stdout);

			if( AOM_ask_value_string(children[k],"bl_T5_EE_PartRevision_t5_EE_PartType",&EE_PartType)!=ITK_ok);
			printf("\n t_ChildItemRev EE_PartType  ===>%s\n",EE_PartType);fflush(stdout);

			if( AOM_ask_value_string(children[k],"bl_item_item_id",&LatChildName)!=ITK_ok);
			printf("\n  LatChildName Parts Id : [%s] \n",LatChildName);

			char*   dRftSpectype_name=NULL;
			tag_t  DrftSpecTypeTag = NULLTAG;

			if(TCTYPE_ask_object_type(t_ChildItemRev,&DrftSpecTypeTag));
			if(TCTYPE_ask_name2(DrftSpecTypeTag,&dRftSpectype_name));

			printf("\n t_ChildItemRev tag found ===>%s\n",dRftSpectype_name);fflush(stdout);


			if(tc_strcmp(PartType,"CON")==0)
			{
				*containerCount=*containerCount+1;
				printf("\n count after is [%d] -- %s for part number -%s\n",*containerCount, PartType,LatChildName);fflush(stdout);
			}
			if(tc_strcmp(EE_PartType,"G")==0)
			{
				*containerCount=*containerCount+1;
				printf("\n count after considering Group ID  is [%d] -- %s for part number -%s\n",*containerCount, PartType,LatChildName);fflush(stdout);
			}
			else
			{
				VC_Multi_Get_Part_BOM_Lvl_Col_SW(reqLevel,level,t_ChildItemRev,containerCount);

			}

		 }
	  }
	level = level + 1;

	window = NULLTAG;

	CLEANUP:
		printf("\n Inside VC_Multi_Get_Part_BOM_Lvl_1 function CLEANUP\n");fflush(stdout);

	return 0;
}

