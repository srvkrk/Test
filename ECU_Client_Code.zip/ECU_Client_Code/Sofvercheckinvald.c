#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* dmlNo			=   NULL;
char	* rev		=   NULL;
//char	* sAttrName		=   NULL;
//char	* sAttrVal		=   NULL;
//char     *f        =   NULL;
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	dmlNo  = ITK_ask_cli_argument("-i=");
	rev = ITK_ask_cli_argument("-r=");

	int eeallrevcount=0;
	tag_t *ee_rev_list = NULLTAG;
	tag_t eerev = NULLTAG;
	tag_t eeitemtag = NULLTAG;
	tag_t part = NULLTAG;
	tag_t objTag = NULLTAG;
	char* eepartitemid =NULL;
	char* eepartid =NULL;
	char* eepartrevid =NULL;																			
	char* inform3 =NULL;																			
	int mi=0;
	char *eepartrelstatuss = NULL;
	char *eesoftrev = NULL;
	char *seleesoftrev = NULL;
	char *swparttype = NULL;


	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",dmlNo); fflush(stdout);


	         printf("\n dmlNo : %s \n",dmlNo);fflush(stdout);
         printf("\n rev : %s \n",rev);fflush(stdout);

		ITK_CALL(ITEM_find_item(dmlNo,&part));
		ITK_CALL(ITEM_find_revision(part,rev,&objTag));



		printf("\n Software version Revision validation start \n");fflush(stdout);



		//	ITK_CALL(AOM_ask_value_string(cntr_object_data,"t5_Userinfo3",&inform3));
		//	printf("\n inform3 is :%s\n",inform3);fflush(stdout);
		//	if(tc_strcmp(inform3,"softverrev")==0)
		//	{

			 ITK_CALL(AOM_ask_value_string(objTag,"t5_SwPartType",&swparttype));
			 printf("\n t5_SwPartType is :%s\n",swparttype);fflush(stdout);


				if ((tc_strcmp(swparttype,"CAL")==0) || (tc_strcmp(swparttype,"CFG")==0) || (tc_strcmp(swparttype,"APP")==0) || (tc_strcmp(swparttype,"BAS")==0) || (tc_strcmp(swparttype,"HCL")==0) || (tc_strcmp(swparttype,"PBL")==0) || (tc_strcmp(swparttype,"SBL")==0))				 
				{
					ITK_CALL(AOM_UIF_ask_value(objTag,"t5_software_rev", &seleesoftrev));
					printf("\n  t5_software_rev on Selected Revision is:[%s] \n",seleesoftrev );fflush(stdout);

						int swrevlensel = strlen(seleesoftrev);

						printf("\n soft rev length : %d \n",swrevlensel);fflush(stdout);

						   

					//if ((tc_strcmp(seleesoftrev,"")!=0) || (swrevlensel > 0))
					if (swrevlensel > 0)
					{
					
						ITK_CALL(AOM_UIF_ask_value(objTag,"item_id", &eepartitemid));
						printf("\n  eepartitemid of Selected Revision is:[%s] \n",eepartitemid );fflush(stdout);

					    ITK_CALL(ITEM_find_item(eepartitemid,&eeitemtag));
					   if (eeitemtag)
					    {
					   
							ITK_CALL(ITEM_list_all_revs(eeitemtag,&eeallrevcount,&ee_rev_list));
							printf("\n eeallrevcount=%d \n",eeallrevcount);fflush(stdout);

							if (eeallrevcount > 0)
							{
							

								 for(mi=eeallrevcount-1;mi>-1;mi--)
								  {
										
									 printf("\n inside for loop \n ");fflush(stdout);

									 eerev=ee_rev_list[mi];

									 ITK_CALL(AOM_ask_value_string(eerev,"item_id",&eepartid));
									 ITK_CALL(AOM_ask_value_string(eerev,"item_revision_id",&eepartrevid));
									 printf("\n eepartid %s \n ", eepartid);fflush(stdout);
									 printf("\n eepartrevid %s \n ", eepartrevid);fflush(stdout);

							
									 eepartrelstatuss = NULL;
									 ITK_CALL(AOM_UIF_ask_value(eerev,"release_status_list",&eepartrelstatuss));
									 TC_write_syslog ( "\n module Release_status : [%s] \n", eepartrelstatuss ) ;
									  printf("\n  module Release_status : [%s] \n" , eepartrelstatuss );fflush(stdout);
											
									 if ( tc_strstr( eepartrelstatuss,"ERC Released") != NULL )
									  {
									   printf("\n latest release found ----- [%s/%s]",eepartid,eepartrevid); fflush(stdout);
									   
									   ITK_CALL(AOM_ask_value_string(eerev,"t5_software_rev",&eesoftrev));
									   printf("\n  t5_software_rev on latest Revision is:%s/%s [%s] \n",eepartid,eepartrevid,eesoftrev );fflush(stdout);

									   	int swrevlenprev = strlen(eesoftrev);

						               printf("\n soft rev length on Previous Release Revision : %d \n",swrevlenprev);fflush(stdout);

									 //  if (tc_strcmp(eesoftrev,"")!=0)
									   if (swrevlenprev > 0)
									   {

									//	 EMH_clear_errors();
									//	 EMH_store_error_s1(EMH_severity_error,ITK_err,"The last released revision already contains a value for the 'Software Version Revision' attribute. Please clear the value of �Software Version Revision� for this revision and check-in the part");
									   //EMH_store_error_s2(EMH_severity_error,ITK_err,"The last released revision already contains a value for the 'Software Version Revision' attribute. Please clear the value of �Software Version Revision� for this revision and check-in the part",eepartrevid);
									//	 return ITK_err;
									    printf("\n The last released revision already contains a value for the 'Software Version Revision' attribute. Please clear the value of 'Software Version Revision' for this revision and check-in the part \n ");fflush(stdout);

									   }														
													
									  break;
									 }



								}
						  }
					   }
				    }
				}
		 //  }
		   printf("\n Software version Revision validation end \n");fflush(stdout);











     
	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

/*	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

