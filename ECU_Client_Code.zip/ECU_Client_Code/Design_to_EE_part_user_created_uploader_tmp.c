#include <string.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <string.h>
#include <unidefs.h>


int                     ifail                           = ITK_ok;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
              printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

int read_part_item_id(char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	
	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-f=");
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = read_part_item_id(Filename);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_part_item_id(char* Filename)
{
	
	char *Part_no = NULL;
	char *Part_no_D = NULL;
    char *ECU_type= NULL;
	char *SW_part_type= NULL;
	char *Read_write=NULL;
	char*App_EOL_Service = NULL;
	char*Part_Type = NULL;
	char*current_desc = NULL;
	char* sequence_id = NULL;
	char *Part_Status=NULL;
    char *CMVRCert=NULL;
    char *CabitkitApp=NULL;
    char *Obj_Descp=NULL;
    char *Design_group=NULL;
    char *Category_Name=NULL;
    char *LHRH_ind=NULL;
    char *Material_class=NULL;
    char *Model_ind=NULL;
    char *Spare_ind=NULL;
    char *Proj_code=NULL;
	tag_t* Release_status_list=NULL;
	//tag_t Release_status=NULL;
    char *UOM=NULL;
	char *class=NULL;
	char *EE_Part_Type=NULL;
	char* status_name=NULL;
	char*errortext=NULL;
	char temp[500];
	int ifail = ITK_ok;
	tag_t Qry_tag = NULLTAG;
	tag_t* Obj_tag = NULLTAG;
	tag_t item=NULLTAG;
	tag_t revtag=NULLTAG;
	tag_t type_tag=NULLTAG;
	tag_t create_input_tag=NULLTAG;
	int	count=0;
	int i=0;
	int ii=0;
	int status_count=0;
	tag_t EE_part_tag=NULLTAG;
	tag_t EE_item=NULLTAG;
	tag_t EE_rev_tag=NULLTAG;
	tag_t EE_rev_tag2=NULLTAG;
	
	
char* revseq=NULL;
	
	
	tag_t   query                           = NULLTAG;
int n_entries = 2;
char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
char *qry_entries[2] = {"Item ID","Revision"};

int n_found=0;

    
	
    
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 500, fp)!= NULL)
	    {
	
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
		        
		        Part_no = strtok(temp,"^");
				printf("\nPart number :%s",Part_no);
				
				revseq = strtok(NULL,"^");
				printf("\nRev seq  is:%s",revseq);
				
				ECU_type = strtok(NULL,"^");
				printf("\nECU type  is:%s",ECU_type);
				
				SW_part_type = strtok(NULL,"^");
				printf("\nSW part type  is:%s",SW_part_type);
				
				Read_write = strtok(NULL,"^");
						  
		        printf("\nValue of Read & write  is:%s",Read_write);
				
				App_EOL_Service = strtok(NULL,"^");
				
				printf("\nValue of Applicable for EOL/Service  is:%s",App_EOL_Service);
				
				Part_Type = strtok(NULL,"^");
				printf("\nPart Type  is :%s",Part_Type);

				current_desc = strtok(NULL,"^");
				printf("\ncurrent_desc  is :%s",current_desc);

                sequence_id = strtok(NULL,"^");
				printf("\nsequence_id  is :%s",sequence_id);
				
				
				 qry_values[0] = Part_no;
              qry_values[1] = revseq;
			  
				ITK_CALL(QRY_find2("Item Revision...", &query));
                ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &Obj_tag));
				printf("\nn_found :%d",n_found);
				 if(n_found==0)
				 {
					 
					  ITK_CALL(ITEM_find_item(Part_no,&EE_item));
					  
					  
					  if(EE_item==NULLTAG)
			            {
			             ITK_CALL(ITEM_create_item(Part_no,Part_no,"T5_EE_Part",default_empty_to_A(revseq),&EE_item,&EE_rev_tag));
				         ITK_CALL(AOM_save_without_extensions(EE_item));
					     ITK_CALL(AOM_save_without_extensions(EE_rev_tag));
				        }
			        else {
			          ITK_CALL(ITEM_find_item(Part_no,&EE_item));
					  ITK_CALL(ITEM_create_rev(EE_item,revseq,&EE_rev_tag));
					  ITK_CALL(AOM_save_without_extensions(EE_rev_tag));
			            }
						
					  
				 }
			 
			           else
				    {
				    printf("\nEE part is alredy there in system");
				   	}
					   
			           ITK_CALL(ITEM_find_rev(Part_no,revseq,&EE_rev_tag2));
					   if(EE_rev_tag2)
					   {
					   ITK_CALL(AOM_refresh (EE_rev_tag2, 1));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_EcuType",ECU_type));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_SwPartType",SW_part_type));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_EPReadable",Read_write));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_AppForEOL",App_EOL_Service));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_EE_PartType",Part_Type));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_PartType",Part_Type));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"current_desc",current_desc));
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"object_desc",current_desc));
					   ITK_CALL(AOM_UIF_set_value(EE_rev_tag2,"sequence_id",sequence_id));
					   
					   ITK_CALL(AOM_set_value_string(EE_rev_tag2,"t5_DesignGrp","16"));
					   ITK_CALL(AOM_save_without_extensions(EE_rev_tag2));
					   ITK_CALL(AOM_refresh (EE_rev_tag2, 0));
					   }
					
				    
		        
			}
			tc_strcpy(temp, "");
	    }
			  
	}
	else 
		
	{
		printf("File Unable to Open...!!");
	}       
	       
	return ifail;
}

