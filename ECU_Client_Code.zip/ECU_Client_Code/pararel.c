	/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_rel_status.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_rel_status -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/tcfile.h>
#include <ae/dataset.h>
//#include <itk/mem.h>
#include <string.h>


#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
/*	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}*/
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ECUCount_Validation(char*,char*);


void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlNo						= NULL;
	char			* rev						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dmlNo 			= ITK_ask_cli_argument("-dmlNo=");
	rev 			= ITK_ask_cli_argument("-rev=");

		

	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dmlNo)) == 0)
	{
		print_requirement();
		return -1;
	}
	// Login to Teamcenter
	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	ifail = ECUCount_Validation(dmlNo,rev);
	CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}


int ECUCount_Validation(char* dmlNo,char* rev)
{
	int ifail = ITK_ok;
				//Akshay

	printf("\n ***INSIDE para_clause_attach_method*** \n");fflush(stdout);


	//Start: Rupali Rahane CR-FY25-0149 Data type HEX and User Entered Value Within Range of (0to 9, A to F)
	char * DataType = NULL;
	char * UserEntervalue=NULL;
	int i=0,len;
	tag_t	Cntl_obj_Paracla =	NULLTAG;
	int n_entries11 =2;
	char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
	char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	int resultCount11=0;
	tag_t *qry_cntrlobj11= NULLTAG;
	char* userinfo_TPL_ECU=NULL;
	tag_t tEERel_type = NULLTAG;
	 tag_t objectRelTag =NULLTAG;
	 tag_t* objectRelTags =NULLTAG;
	 tag_t part=NULLTAG;
	 int tEERel_cont=0;
	 tag_t primary_object=NULLTAG;

	      printf("\n dmlNo :%s \n",dmlNo);
         printf("\n rev : %s \n",rev);

		ITK_CALL(ITEM_find_item(dmlNo,&part));
		if (part)
		{
		
		ITK_CALL(ITEM_find_revision(part,rev,&primary_object));
		if (primary_object)
		{
		


				 
				  ifail = GRM_find_relation_type("T5_EEPrm",&tEERel_type);		
				//  ifail = GRM_find_relation(primary_object,secondary_object,tEERel_type,&objectRelTag);
				if(GRM_list_secondary_objects_only(primary_object,tEERel_type,&tEERel_cont,&objectRelTags));
				 printf("\n*****objectRelTags conts***** <%d>\n",tEERel_cont);fflush(stdout);
				 
				// if(objectRelTags!=NULLTAG)
				 if(objectRelTags)
				   {
					 printf("\n inside cont of sec rel obj  \n");fflush(stdout);


					 AOM_ask_value_string(objectRelTags[0],"t5_EPType",&DataType);
			         printf("\n*****INSIDE T5_EE_PartRevision***** <%s>\n",DataType);fflush(stdout);

					 if(strcmp(DataType,"HEX")==0)
				      { 

						 printf("\n Relation Object Found\n");fflush(stdout);
						 
						 AOM_ask_value_string(objectRelTags[0],"t5_BitValue",&UserEntervalue);
						 printf("\n*****INSIDE T5_EE_PartRevision USER Enter Value***** <%s>\n",UserEntervalue);fflush(stdout);
						
					
							if(strcmp(UserEntervalue,"USD")!=0)
							{
								len= strlen(UserEntervalue);
								for(i=0;i<len;i++)
								{
									printf(" i = %d \n",i);fflush(stdout);
									printf(" UserEntervalue[i] = %c\n",(int)UserEntervalue[i]);fflush(stdout);
									if(((int)UserEntervalue[i]>=65 && (int)UserEntervalue[i]<=70) || ((int)UserEntervalue[i]>=48 && (int)UserEntervalue[i]<=57) || (int)UserEntervalue[i]==45)
									{
										printf(" UserEnterValue is ok \n"); fflush(stdout);
									}
									else 
									{
										printf("\n For Data Type Please Select Value Hex");fflush(stdout);
										//EMH_clear_errors();
										//EMH_store_error_s1(EMH_severity_error,ITK_err,"User Entered Value must contain value from this range only.0to9 and AtoF");
										//return ITK_err;  
										printf("\n User Entered Value must contain value from this range only.0to9 and AtoF");fflush(stdout);
									}
								}
							}
					  }
				    }
             
			 }
			 else
			{
           printf("\n revision not found");fflush(stdout);
			}
		}   
		else
		{
	   printf("\n item not found");fflush(stdout);
		}			
					

		   ///////////////////


	return ifail;
}
