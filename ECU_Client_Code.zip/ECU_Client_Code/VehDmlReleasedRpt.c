#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
//#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
//#include <epm/cr_effectivity.h>
#include<ics/ics.h>
//#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;
char     *f        =   NULL;
void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sOpt  = ITK_ask_cli_argument("-i=");
	f = ITK_ask_cli_argument("-f=");
	//sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);

	char	*sFrmRpl;
	char	*sToRpl;

	int		i = 0;
	int		j = 0;
	int		k = 0;
	int		l = 0;
	int		n_Input = 3;
	int		nPrtCnt = 0;
	int		n_Cnt = 0;
	int		iPCnt = 0;
	int		bl_qty_form = 0;
	int		brkdncnt = 0;
	int		solnobjcnt = 0;
	int		modulecnt = 0;
	char	*values[3];
//	char	*values[1];
	char	*qry_Input[3] = {"Name", "date_released_after", "Release Type"};
	//char	*qry_Input[1] = {"Part Type"};
	tag_t	QryPrt = NULLTAG;
	tag_t	tPrt = NULLTAG;
	tag_t	*tpPrtObjs = NULL;

	char	*sPrtVal = NULL;
	char	*sPrtRev = NULL;
	char	*sPrtTyp = NULL;
	char	*sCPartNum = NULL;
	char	*sCPartRvSq = NULL;
	char	*sCPartQty = NULL;
	char	*FileName = NULL;

	tag_t	window = NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t	tChld = NULLTAG;
	tag_t	*children = NULLTAG;
	tag_t	rel_type = NULLTAG;
	tag_t	rel_type1 = NULLTAG;
	tag_t	rel_type2 = NULLTAG;
	tag_t*	brkdnobjs = NULLTAG;
	tag_t*	solnobjs = NULLTAG;
	tag_t	brkdnobj = NULLTAG;
	tag_t	solnobj = NULLTAG;
	tag_t*  moduleno = NULLTAG;
    tag_t modulelatestrev = NULLTAG;

	logical lIsQtyModified = false;

	time_t temp; 
    struct tm *timeptr; 
    char pAccessDate[30];
	char *sCurrentDate = NULL;
	char *sCurrentDateDup = NULL;
	char *strToBereplaceddate;
	char *strToBeUsedInsteaddate;
	char *brkdnobjname = NULL;
	char *vehicleno = NULL;
	char *vehrevseq = NULL;
	
	char *modulenoname = NULL;
    char *modulerevseq = NULL;
	FILE *fptr;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	FileName =(char *) MEM_alloc(150);
	sCurrentDate =(char *) MEM_alloc(30);
	sCurrentDateDup =(char *) MEM_alloc(30);
	strToBereplaceddate = (char*)malloc(5);
	strToBeUsedInsteaddate = (char*)malloc(5);

	//sVCIDObjStr = (char*)malloc(50);
	//VCIDList = (char**)MEM_alloc(1 * sizeof *VCIDList);
	
	tc_strcpy(sFrmRpl,";");
	tc_strcpy(sToRpl,"*");
	ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRevSeq); 

	printf("\n kk.Querying all ECU Modules\n"); fflush(stdout);

	values[0] = "T5_LcsErcRlzd";
	values[1] = sOpt;
	values[2] = "Vehicle Release";
	//values[0] = "ECU Module";

    time(&temp); 
    timeptr = localtime(&temp ); 
	tc_strcpy(pAccessDate,"");
    strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr); 
	tc_strcpy(sCurrentDate,pAccessDate);
	tc_strcpy(strToBereplaceddate,"/");
	tc_strcpy(strToBeUsedInsteaddate,"-");

	ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup); 
	//printf("\n..sCurrentDateDup [%s].. \n",sCurrentDateDup);fflush(stdout);
      
    printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

	tc_strcpy(FileName,f);
//	tc_strcat(FileName,sCurrentDateDup);
//	tc_strcat(FileName,".csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		exit(1);
	}
//	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
     fprintf(fptr,"%s,%s,%s","ERC DML","Vehicle Number","Module Number");fflush(fptr);
	if(QRY_find2("ERCDMLReleased_Type", &QryPrt));
	if(QryPrt)
	{
		if(QRY_execute(QryPrt, n_Input, qry_Input, values, &nPrtCnt, &tpPrtObjs));
		printf("\n  DML Released count is [%d]\n", nPrtCnt);fflush(stdout);

		if(nPrtCnt>0)
		{	
			for(iPCnt=0; iPCnt<nPrtCnt; ++iPCnt)
			{
				lIsQtyModified = false;
				tPrt = tpPrtObjs[iPCnt];
				ITK_CALL(AOM_ask_value_string(tPrt,"item_id",&sPrtVal));
				ITK_CALL(AOM_ask_value_string(tPrt,"item_revision_id",&sPrtRev));
			//	ITK_CALL(AOM_ask_value_string(tPrt,"t5_PartType",&sPrtTyp));
				printf("\nkk.Value is [%s,%s]\n",sPrtVal,sPrtRev);fflush(stdout);

				ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&rel_type));

				ITK_CALL(GRM_list_secondary_objects_only(tPrt,rel_type,&brkdncnt,&brkdnobjs));

				printf("\n brkdncnt %d \n", brkdncnt);fflush(stdout);

				for(j=0;j<brkdncnt;j++)
				{
					brkdnobj = brkdnobjs[j];

					ITK_CALL(AOM_ask_value_string(brkdnobj,"item_id",&brkdnobjname));

					 


					if(tc_strstr(brkdnobjname,"_00")!=NULL)
					{
						printf("\n brkdnobjname %d : %s \n", j, brkdnobjname);fflush(stdout);

					  ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&rel_type1));

					  ITK_CALL(GRM_list_secondary_objects_only(brkdnobj,rel_type1,&solnobjcnt,&solnobjs));

					  printf("\n solnobjcnt : %d \n", solnobjcnt);fflush(stdout);

						
						if(solnobjcnt>0)
						{
							
						   for(k=0;k<solnobjcnt;k++)
						   {
							  solnobj =solnobjs[k];

							  ITK_CALL(AOM_ask_value_string(solnobj,"item_id",&vehicleno));

							  int len = strlen(vehicleno);
					          printf("\n vehicle number length : %d \n",len);fflush(stdout);

							  if (((len == 12) && tc_strstr(vehicleno,"000R")==NULL) || (len == 9))
							  {
							  
								  ITK_CALL(AOM_ask_value_string(solnobj,"item_revision_id",&vehrevseq));
								  printf("\n vehicle no %d : %s %s,\n", k, vehicleno,vehrevseq);fflush(stdout);
				   
								  ITK_CALL(GRM_find_relation_type("T5_CCVCHasECUModule",&rel_type2));

								  ITK_CALL(GRM_list_secondary_objects_only(solnobj,rel_type2,&modulecnt,&moduleno));
								  
									if(modulecnt>0)	
									{
									
									   for(l=0;l<modulecnt;l++)
										{
										  ITK_CALL(AOM_ask_value_string(moduleno[0],"item_id",&modulenoname));
										  ITK_CALL(ITEM_ask_latest_rev(moduleno[0],&modulelatestrev));
										  ITK_CALL(AOM_ask_value_string(modulelatestrev,"item_revision_id",&modulerevseq));
										 // printf("\n modulecnt %d \n ", modulecnt);fflush(stdout);

										  printf("\n modulenoname %s \n ", modulenoname);fflush(stdout);

										  fprintf(fptr,"\n%s,%s/%s,%s/%s",sPrtVal,vehicleno,vehrevseq,modulenoname,modulerevseq);fflush(fptr);
										}	  
									  

									   MEM_free(moduleno);
									}
									else
									{
									
									fprintf(fptr,"\n%s,%s/%s",sPrtVal,vehicleno,vehrevseq);fflush(fptr);
									
									}
						       }

						    }

					        MEM_free(solnobjs);
						  
				        }
						else
						{
						fprintf(fptr,"\n%s",sPrtVal);fflush(fptr);	
						}
					
					}

				
				}

				   MEM_free(brkdnobjs);

				
                printf("\n **************************************CHEKING FOR NEXT DML*********************************** \n");
               
			}
		}
	}
     
	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

/*	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}*/
}

