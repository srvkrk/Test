package plmsapinterface.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCSession;

import plmsapinterface.ui.tm_EPAWiseBOMLoadingDialogs;
import plmsapinterface.ui.tm_TaskWiseBOMLoadingDialogs;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;

public class tm_EPAWiseBOMLoading extends AbstractHandler {
	
	//private Shell parentshell;
	private TCSession tcsession;

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		tcsession=(TCSession)AIFUtility.getActiveDesktop().getCurrentApplication().getSession();
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
		
		//MessageDialog.openInformation(
				//window.getShell(),
				//"PLMSAPInterface",
				//"Hello, Eclipse world");
		
		tm_EPAWiseBOMLoadingDialogs EpaWiseBOMForm = new tm_EPAWiseBOMLoadingDialogs(window.getShell());
		EpaWiseBOMForm.open();
		
		//parentshell=window.getShell();
		//IStructuredSelection theSelection = (IStructuredSelection) HandlerUtil.getCurrentSelection(event);
		
		//System.out.println("Successfully got the current Selected Object.");
		//AIFComponentContext aifctxt=(AIFComponentContext)theSelection.getFirstElement();
		//TCComponent selectedObj  = (TCComponent) aifctxt.getComponent();
		
		//tm_TaskWiseBOMLoadingDialogs TaskWiseBOMForm = new tm_TaskWiseBOMLoadingDialogs(parentshell,selectedObj);
		//TaskWiseBOMForm.open();
		
		return null;
	}
}
