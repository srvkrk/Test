package plmsapinterface.ui;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.t5.services.rac.tmshellexecution.T5LinuxShellManagementService;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentPerson;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentSite;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.util.MessageBox;

import org.eclipse.swt.widgets.Button;

public class tm_EPAWiseBOMLoadingDialogs extends TitleAreaDialog {
	private Text text;
	private String text1;
	private TCComponentUser UserName = null;
	private String reportLocStr ="";
	private String EpaNum ="";
	private String TrnType ="";
	private TCComponent tcObj = null;
	TCSession			session;
	private String[] outputStr;
	String currentuser_mail_id = null;
	private Object objects[];
	TCUserService service = null;
	private Text txtBom;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public tm_EPAWiseBOMLoadingDialogs(Shell parentShell) {
		super(parentShell);
		setShellStyle(SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		setTitle("PLM-SAP BOM Transfer");
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(169, 52, 93, 31);
		lblNewLabel.setText("EPA Number:");
		
		text = new Text(container, SWT.BORDER);
		text.setBounds(291, 45, 325, 31);
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(169, 100, 78, 21);
		lblNewLabel_1.setText("Transfer Type:");
		
		txtBom = new Text(container, SWT.BORDER);
		txtBom.setEditable(false);
		txtBom.setText("EPA");
		txtBom.setBounds(291, 100, 45, 21);

		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button okBtn = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		okBtn.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				System.out.println("EpaNum:   " + EpaNum);
				
				TrnType=TrnType.trim();
				System.out.println("TrnType:   " + TrnType);
				
				if(EpaNum.equals("") || EpaNum == null)
				{
					
					setErrorMessage("Please Enter The EPA Number");
	    			return;
				}
				
				AbstractAIFUIApplication app = AIFUtility.getCurrentApplication();
				TCSession session = (TCSession) app.getSession();
				UserName = session.getUser();
				System.out.println("session user: " + session);
				
				TCComponent[] QcompTask = null;
				
				String[] qvalue = {EpaNum};
				String[] qname = {"Item ID"};
				System.out.println("query1");
				TCComponentQueryType qtype = null;
				try {
					System.out.println("query2");
					qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					System.out.println("query3");
				} catch (TCException e4) {
					// TODO Auto-generated catch block
					e4.printStackTrace();
				}
	            TCComponentQuery queryTask = null;
				try {
					System.out.println("query4");
					queryTask = (TCComponentQuery)qtype.find("EPAQueryBasedonPlant");
					System.out.println("query5");
				} catch (TCException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
	             try {
	            	 System.out.println("query6");
					QcompTask = queryTask.execute(qname, qvalue);
					System.out.println("query7");
				} catch (TCException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
	             
	            if (QcompTask.length > 0)
	 			{
	 				System.out.println("EPA Found");
	 				TCComponent QcompTaskItem = null;
	 				String epaRelStatus = null;
	 				String epaName = null;
	 				String epaPlant= null;
	 				TCComponentSite site;
	 				
	 				QcompTaskItem = QcompTask[0];
	 				
	 				try {
	 					
	 					epaName = QcompTaskItem.getTCProperty("item_id").toString();
	 					epaPlant = QcompTaskItem.getTCProperty("t5_EpaPlantA").toString();
						epaRelStatus = QcompTaskItem.getTCProperty("release_status_list").toString();
						System.out.println("EPA Name =" + epaName);
						System.out.println("EPA Plant =" + epaPlant);
						System.out.println("EPA Release Status =" + epaRelStatus);
						
						if(((epaPlant.equals("CVBU JSR")) && (epaRelStatus.contains("STDSIJ Released"))) ||
						   ((epaPlant.equals("CAR")) && (epaRelStatus.contains("STDSIC Released"))) ||
						   ((epaPlant.equals("CVBU PUNE")) && (epaRelStatus.contains("STDSIP Released"))) ||
						   ((epaPlant.equals("DHARWAD")) && (epaRelStatus.contains("STDSID Released"))) ||
						   ((epaPlant.equals("CVBU PNR")) && (epaRelStatus.contains("STDSIU Released"))) ||
						   ((epaPlant.equals("SANAND")) && (epaRelStatus.contains("STDSIA Released"))))
						{
							
							System.out.println("IFFFFFF part");
							System.out.println("EPA Name =" + epaName);
							System.out.println("EPA Release Status =" + epaRelStatus);
							
							TCComponentUser currentUser = session.getUser();
							
							TCComponentPerson person=(TCComponentPerson)currentUser.getReferenceProperty("person");
							currentuser_mail_id=person.getProperty("PA9");
							
							System.out.println("currentuser_mail_id Str: " + currentuser_mail_id);
							 objects = new Object[3];
							 objects[0] = epaName;
							 objects[1] = TrnType;
							 objects[2] = currentuser_mail_id;
							 
							 service =session.getUserService();
							 service.call("tm_PLMSAPInterfaceServ", objects);
							 
							 com.teamcenter.rac.util.MessageBox.post("EPA will be update soon in SAP, Please check after few minutes.","Attention",com.teamcenter.rac.util.MessageBox.INFORMATION);
							if(MessageBox.INFORMATION>0)
						    {
								close();
						    }
							
						}
						else
						{
							System.out.println("Else part");
							System.out.println("EPA Name =" + epaName);
							System.out.println("EPA Release Status =" + epaRelStatus);
							
							setErrorMessage("EPA not STD Released");
							return;
						}
						
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	 				
	 			}
	 			else
	 			{
	 				setErrorMessage("Please Enter The Correct EPA Number");
	    			return;
	 			}
				
			}
		});
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(838, 576);
	}
	
	 @Override
	 protected void okPressed() {
		 saveInput();
		 //close();
		//super.okPressed();
	 }
	 
	 private void saveInput() {
		 EpaNum = text.getText();
		 TrnType = txtBom.getText();
		 //grDateStr = getFormattedDate(gRdateTime);
		// fdjRevRemarkStr = fdjRevRemarkTxt.getText();
		// fdjDesRemarkStr = fdjDesRemarkTxt.getText();
		 
	 }
}
