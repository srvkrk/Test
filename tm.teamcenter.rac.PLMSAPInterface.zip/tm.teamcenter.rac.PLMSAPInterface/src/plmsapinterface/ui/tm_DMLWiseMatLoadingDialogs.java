package plmsapinterface.ui;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
//import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;

import com.t5.services.rac.tmshellexecution.T5LinuxShellManagementService;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentPerson;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentSite;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCUserService;
import com.teamcenter.rac.util.MessageBox;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;

public class tm_DMLWiseMatLoadingDialogs extends TitleAreaDialog {
	private Text text;
	private String text1;
	private TCComponentUser UserName = null;
	private String DMLNum ="";
	private Combo PlantCode;
	private String PlantCodeStr = null;
	private Combo ReqType;
	private String ReqTypeStr = null;
	private String TrnType ="";
	TCSession			session;
	private String[] outputStr;
	String currentuser_mail_id = null;
	private Object objects[];
	TCUserService service = null;
	private Text txtMaterial;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public tm_DMLWiseMatLoadingDialogs(Shell parentShell) {
		super(parentShell);
		setShellStyle(SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		setTitle("PLM-SAP Material Tranfer");
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(161, 66, 84, 25);
		lblNewLabel.setText("DML Number:");
		
		text = new Text(container, SWT.BORDER);
		text.setBounds(280, 63, 273, 25);
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(161, 122, 84, 25);
		lblNewLabel_1.setText("Plant Code:");
		
		PlantCode = new Combo(container, SWT.NONE);
		PlantCode.setBounds(280, 122, 125, 23);
		PlantCode.add("1001");
		PlantCode.add("1100");
		PlantCode.add("1500");
		PlantCode.add("2001");
		PlantCode.add("3001");
		PlantCode.add("3100");
		PlantCode.add("E201");
		PlantCode.add("7501");
		PlantCode.add("1140");
		
		Label lblNewLabel_2 = new Label(container, SWT.NONE);
		lblNewLabel_2.setBounds(161, 176, 76, 25);
		lblNewLabel_2.setText("Request Type:");
		
		ReqType = new Combo(container, SWT.NONE);
		ReqType.setBounds(280, 176, 273, 23);
		ReqType.add("Material_Create");
		ReqType.add("Material_Change");
		
		Label lblNewLabel_3 = new Label(container, SWT.NONE);
		lblNewLabel_3.setBounds(161, 231, 76, 25);
		lblNewLabel_3.setText("Transfer Type:");
		
		txtMaterial = new Text(container, SWT.BORDER);
		txtMaterial.setEditable(false);
		txtMaterial.setText("Material");
		txtMaterial.setBounds(280, 231, 61, 25);
		
		Label lblNewLabel_4 = new Label(container, SWT.NONE);
		lblNewLabel_4.setBounds(20, 283, 55, 15);
		lblNewLabel_4.setText("Note:");
		
		Label lblNewLabel_5 = new Label(container, SWT.NONE);
		lblNewLabel_5.setBounds(72, 283, 439, 15);
		lblNewLabel_5.setText(" DML and Material should be Planning Released from selected plant in PLM (TCUA)");
		
		Label lblNewLabel_6 = new Label(container, SWT.NONE);
		lblNewLabel_6.setBounds(72, 306, 509, 15);
		lblNewLabel_6.setText(" Material CS (Make Buy) and SLOC (Store Location) should not be Blank or NULL in PLM (TCUA)");
		
		Label lblNewLabel_7 = new Label(container, SWT.NONE);
		lblNewLabel_7.setBounds(72, 327, 370, 15);
		lblNewLabel_7.setText(" Material should be attached with Released input DML in PLM (TCUA)");
		
		Label lblNewLabel_8 = new Label(container, SWT.NONE);
		lblNewLabel_8.setBounds(72, 348, 333, 15);
		lblNewLabel_8.setText(" It will take 4 - 5 minutes to reflect in SAP after OK button press");
		
		Label lblNewLabel_9 = new Label(container, SWT.NONE);
		lblNewLabel_9.setBounds(72, 369, 500, 15);
		lblNewLabel_9.setText(" If any further issue please raise TMS in DPDS under category:  TEAMCENTER - PLM_SAP Issues");
		
		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		Button okBtn = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		okBtn.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				System.out.println("DML No: " + DMLNum);
				
				if(DMLNum.equals("") || DMLNum == null)
				{
					
					setErrorMessage("Please Enter The DML Number");
	    			return;
				}
				
				AbstractAIFUIApplication app = AIFUtility.getCurrentApplication();
				TCSession session = (TCSession) app.getSession();
				UserName = session.getUser();
				System.out.println("Session User: " + session);
				
				TCComponent[] QcompTask = null;
				
				String[] qvalue = {DMLNum};
				String[] qname = {"ID"};
				System.out.println("query1");
				TCComponentQueryType qtype = null;
				try {
					System.out.println("query2");
					qtype = (TCComponentQueryType) session.getTypeComponent("ImanQuery");
					System.out.println("query3");
				} catch (TCException e4) {
					// TODO Auto-generated catch block
					e4.printStackTrace();
				}
	            TCComponentQuery queryTask = null;
				try {
					System.out.println("query4");
					queryTask = (TCComponentQuery)qtype.find("APLDMLRevisionQry");
					System.out.println("query5");
				} catch (TCException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
	             try {
	            	 System.out.println("query6");
					QcompTask = queryTask.execute(qname, qvalue);
					System.out.println("query7");
				} catch (TCException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
	             
	            if (QcompTask.length > 0)
	 			{
	 				System.out.println("DML Found");
	 				TCComponent QcompTaskItem = null;
	 				String tastRelStatus = null;
	 				String tastName = null;
	 				TCComponentSite site;
	 				
	 				QcompTaskItem = QcompTask[0];
	 				
	 				try {
	 					
	 					tastName = QcompTaskItem.getTCProperty("item_id").toString();
						tastRelStatus = QcompTaskItem.getTCProperty("release_status_list").toString();
						System.out.println("DML No: " + tastName);
						System.out.println("DML Release Status: " + tastRelStatus);
						
						if(((tastName.contains("APLJ") || tastName.contains("STDJ")) && (tastRelStatus.contains("APLJ Released") || tastRelStatus.contains("STDSIJ Released"))) ||
						   ((tastName.contains("APLC") || tastName.contains("STDC")) && (tastRelStatus.contains("APLC Released") || tastRelStatus.contains("STDSIC Released"))) ||
						   ((tastName.contains("APLP") || tastName.contains("STDP")) && (tastRelStatus.contains("APLP Released") || tastRelStatus.contains("STDSIP Released"))) ||
						   ((tastName.contains("APLD") || tastName.contains("STDD")) && (tastRelStatus.contains("APLD Released") || tastRelStatus.contains("STDSID Released"))) ||
						   ((tastName.contains("APLU") || tastName.contains("STDU")) && (tastRelStatus.contains("APLU Released") || tastRelStatus.contains("STDSIU Released"))) ||
						   ((tastName.contains("APLA") || tastName.contains("STDA")) && (tastRelStatus.contains("APLA Released") || tastRelStatus.contains("STDSIA Released"))))
						{
							
							System.out.println("DML No: " + tastName);
							System.out.println("DML Release Status: " + tastRelStatus);
							
							TCComponentUser currentUser = session.getUser();
							
							TCComponentPerson person=(TCComponentPerson)currentUser.getReferenceProperty("person");
							currentuser_mail_id=person.getProperty("PA9");
							
							System.out.println("currentuser_mail_id Str: " + currentuser_mail_id);
							System.out.println("@@@@@@@@@@ BEFORE: INPUT ARGUMENT DETAILS @@@@@@@@@@");
							System.out.println("[0] DML No: " + tastName);
							System.out.println("[1] Plant Code: " + PlantCodeStr);
							System.out.println("[2] Request Type: " + ReqTypeStr);
							System.out.println("[3] Transfer Type: " + TrnType);
							System.out.println("[4] Email: " + currentuser_mail_id);
							System.out.println("@@@@@@@@@@ AFTER: INPUT ARGUMENT DETAILS @@@@@@@@@@");
							 objects = new Object[5];
							 objects[0] = tastName;
							 objects[1] = PlantCodeStr;
							 objects[2] = ReqTypeStr;
							 objects[3] = TrnType;
							 objects[4] = currentuser_mail_id;
							 
							 service =session.getUserService();
							 service.call("tm_PLMSAPInterfaceServMat", objects);
							 
							 com.teamcenter.rac.util.MessageBox.post("Hi!, Material will be created/changed soon in SAP, Please check in SAP after few minutes..!!","Attention",com.teamcenter.rac.util.MessageBox.INFORMATION);
							if(MessageBox.INFORMATION>0)
						    {
								close();
						    }
							
						}
						else
						{
							System.out.println("Else part");
							System.out.println("DML No =" + tastName);
							System.out.println("DML Release Status =" + tastRelStatus);
							
							setErrorMessage("DML is Not Planning Released");
							return;
						}
						
					} catch (TCException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	 				
	 			}
	 			else
	 			{
	 				setErrorMessage("Please Enter The Correct DML Number");
	    			return;
	 			}
				
			}
		});
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(838, 576);
	}
	
	 @Override
	 protected void okPressed() {
		 saveInput();
		 //close();
		//super.okPressed();
	 }
	 
	 private void saveInput() {
		 DMLNum = text.getText();
		 PlantCodeStr = PlantCode.getText();
		 ReqTypeStr = ReqType.getText();
		 TrnType = txtMaterial.getText();
		 //grDateStr = getFormattedDate(gRdateTime);
		// fdjRevRemarkStr = fdjRevRemarkTxt.getText();
		// fdjDesRemarkStr = fdjDesRemarkTxt.getText();
		 
	 }
}