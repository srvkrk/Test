################################################################################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	: Rupali Rane
# Created on	: Apr 10, 2017
# Project       : Teamcenter 10.1
# Module	: TCUA Proe Incremental Uploader
# Code          : TmlloadProeData_Incremental.sh
#
# Shell Usage:: Shellname Partnumber OutputRedirectedLogFilename(to grep not created part rev)
#
#################################################################################################################################################
date
cd "$1"
mainDir=`pwd`
echo "mainDir:  $mainDir"
fileNm=GenericInstance.txt
echo "fileNm: $fileNm"
fileNmMain=GenericInstance_"$1".txt
echo "fileNmMain::: $fileNmMain"
fileLhRh=LhRhPartDet.txt
echo "fileLhRh: $fileLhRh"
fileLhRhMain=LhRhPartDet_"$1".txt
echo "fileLhRhMain::: $fileLhRhMain"
filename="to_load"
partfile=${filename}_parts.txt
partfileNew=${filename}_parts_new.txt
AllPartAllRevFlag=0
AllPartAllRevSubAssyFlag=0
GenericFileExistFlag=0
LhRhPartFileExistFlag=0
if test -s "$fileNmMain"
then
	GenericFileExistFlag=1
fi
if test -s "$fileLhRhMain"
then
	LhRhPartFileExistFlag=1
fi
#ErrorFileSize=`ls -lah "$1"_ErrorMessages.txt | awk '{ print $5 }'`
ErrorFileSize=`ls -nl "$1"_ErrorMessages.txt | awk '{ print $5 }'`
echo "ErrorFileSize   $1_ErrorMessages.txt:  $ErrorFileSize"
if [ "$ErrorFileSize" -gt 30 ]
then
	echo -e "\n\n ERROR::  T-Matrix are not downloaded for all assemblies. Pls check file   $1_ErrorMessages.txt   hence not uploading....\n"
	exit 1
fi
echo "1--Processing to update Part effectivity for older revisions from ProE_Parts_To_Update.txt....................."
if test -s ProE_Parts_To_Update.txt
then
	/user/rrr05503/Shells/RlzStatusAndEffStamp -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=ProE_Parts_To_Update.txt
fi
echo "1.1--Processing to update Part effectivity for older revisions from CATIA_Parts_To_Update.txt....................."
if test -s CATIA_Parts_To_Update.txt
then
	/user/rrr05503/Shells/RlzStatusAndEffStamp -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=CATIA_Parts_To_Update.txt
fi
if [ `ls -ltr | grep ^d | wc -l` -lt 2 ];then
	echo -e "\n\n WARNING: No Assembly directory present in current directory for BOM migration, check downloading log ??????????? \n"
	exit 1
else
	echo "Assembly directory found"
fi
echo "2--Processing to upload Part creation............................................"
if test -s AllPartAllRevFile_"$1".txt
then
	nohup /user/rrr05503/Shells/TmlcreateRevForProe_CreRevAPI -i=AllPartAllRevFile_"$1".txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba >> "$1"_createRevForProe.log1 &
#	(nohup /user/rrr05503/Shells/TmlcreateRevForProe_CreRevAPI -i=AllPartAllRevFile_"$1".txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba >> "$1"_createRevForProe.log1 & ) > /dev/null 2>&1
	if [ $? != 0 ]
	then
		echo "Problem in TmlcreateRevForProe_CreRevAPI for file AllPartAllRevFile_$1.txt"
		exit 1
	else
		wait
		echo "--------------2--Part Creation is completed.............AllPartAllRevFile_$1.txt"
		AllPartAllRevFlag=1
	fi
fi
echo "AllPartAllRevFlag:   $AllPartAllRevFlag"
if [[ "$AllPartAllRevFlag" == "1" ]]; then
	grep "FAILED---" "$1"_createRevForProe.log1 > "$mainDir"/LoadingFailureMessages.txt 
	while read lineFld
	do
		echo "1.******************Input: " $lineFld
		directory=`echo $lineFld |awk -F',' '{print $5}'`
		if [ ! -d "$directory" ]; then
		##	Control will enter here if $directory doesn't exist.
			continue;
		fi
		cd "$directory"
		echo "1.Working FolderName: $directory"
		if [[ "$AllPartAllRevFlag" != "1" ]]; then
			if [[ -f "allpartsAllRev_$directory.txt" && -s "allpartsAllRev_$directory.txt" ]]; then
				/user/rrr05503/Shells/TmlcreateRevForProe_CreRevAPI -i=allpartsAllRev_"$directory".txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
				if [ $? != 0 ]
				then
					echo "Problem in TmlcreateRevForProe_CreRevAPI  $directory  for file allpartsAllRev_$directory.txt"
					exit 1
				else
					echo "--------------3..Part Creation is completed.............AllPartAllRevFile.txt"
				fi
			fi
			if [[ -f "AllPartAllRevFile.txt" && -s "AllPartAllRevFile.txt" ]]; then
				/user/rrr05503/Shells/TmlcreateRevForProe_CreRevAPI -i=AllPartAllRevFile.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
				if [ $? != 0 ]
				then
					echo "Problem in TmlcreateRevForProe_CreRevAPI  $directory  for file AllPartAllRevFile.txt"
					exit 1
				else
					echo "--------------4..Part Creation is completed.............AllPartAllRevFile_$SubAssyPart.txt"
					AllPartAllRevSubAssyFlag=1
				fi
			fi
		fi
		cd ..
	done < $1.PartList.txt
	echo "**Going to upload all revisions CAD/PDF/JT/DRW............................................"
	pwd
	if [[ -f inputAllRevJT.txt ]] && [[ ! -s inputAllRevJT.txt ]]; then
		echo "In If condition..."
		#/user/rrr05503/Shells/TmlloadAllRevJTCad.sh $1
		/user/rrr05503/Shells/test.sh $1
		if [ $? != 0 ]
		then
			echo "Problem in CAD/PDF/JT/DRW Creation/Upload in UA.."
			exit 1
		fi
	else
		echo "In else condition..."
		/user/rrr05503/Shells/TmlDataSetLoadProE -i=inputAllRevJT.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba 
		if [ $? != 0 ]
		then
			echo "Problem in allrevJT TmlDataSetLoadProE"
#			exit 1
		fi
	fi
	echo "**Going to upload Sub-Assembly Structure BOM............................................"
	if test -s $1.SubAssyPartList.txt
	then
		/user/rrr05503/Shells/TmlloadProeSubAssyData_newLogic.sh $1
	fi
	echo "**Going to upload Structure BOM............................................"
	while read lineFld
	do
		echo "2.******************Input: " $lineFld
		directory=`echo $lineFld |awk -F',' '{print $5}'`
		PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
		DirPartNm=`echo $PartDirName | cut -d"_" -f1`
		DirPartRev=`echo $PartDirName | cut -d"_" -f2`
		DirPartSeq=`echo $PartDirName | cut -d"_" -f3`
		if [ ! -d "$directory" ]; then
			continue
		fi
		cd "$directory"
		echo "2.Working FolderName: $directory"
		echo "#DELIMITER ^" > $partfile
		echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile
		while read line
		do
			echo $line
			level=`echo $line |awk -F'^' '{print $1}'`
			item=`echo $line |awk -F'^' '{print $2}'`
			rev=`echo $line |awk -F'^' '{print $3}'`
			seq=`echo $line |awk -F'^' '{print $4}'`
			desc=`echo $line |awk -F'^' '{print $5}'`
			unitofmes=`echo $line |awk -F'^' '{print $18}'`
			if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
				if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
					rev=$DirPartRev
					seq=$DirPartSeq
				fi
			fi
			parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
			#echo $parentAtr
			parentChild="$parentAtr,$item"
			echo $parentChild
			qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
			echo "qty:" $qty
			if [[ -z "$qty" ]]
			then
				qty=1
			fi
			cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
			if [[ $cntq > 1 ]]
			then
				echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
				#qty=9999
				qty=1
			else
				qty=`basename $qty`
			fi
			name=$item
			#unitofmes="-"
			quantity="1"
			echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile
		done < allparts_"$directory".txt
		if test -s  AssyBomSuperSet.txt
		then
			echo "#DELIMITER ^" > $partfileNew
			echo "#COL   Level  item  rev Seq desc occs Name Uom Qty Suppressed" >> $partfileNew
			while read line
			do
				echo $line
				level=`echo $line |awk -F'^' '{print $1}'`
				item=`echo $line |awk -F'^' '{print $2}'`
				rev=`echo $line |awk -F'^' '{print $3}'`
				seq=`echo $line |awk -F'^' '{print $4}'`
				desc=`echo $line |awk -F'^' '{print $5}'`
				unitofmes=`echo $line |awk -F'^' '{print $8}'`
				cadQty=`echo $line |awk -F'^' '{print $9}'`
				suppressTmp=`echo $line |awk -F'^' '{print $10}'`
				suppress=`echo $suppressTmp |awk -F' ,' '{print $1}'`
				ImmParent=`echo $line |awk -F'^' '{print $11}'`
				if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
					if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
						rev=$DirPartRev
						seq=$DirPartSeq
					fi
				fi
				parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
				###parentChild="$parentAtr,$item"
				parentChild="$ImmParent,$item"
				echo $parentChild
				qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
				echo "Before..qty:" $qty
				if [[ -z "$qty" ]]
				then
					qty=1
				fi
				cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
				if [[ $cntq > 1 ]]
				then
					echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
					#qty=9999
					qty=1
				else
					qty=`basename $qty`
				fi
				name=$item
				#unitofmes="-"
				quantity="1"
				if [[ "$cadQty" == 0 ]]
				then
					##qty=$cadQty
					##Below to solve non-bom multi cad quantity on 11.07.2017
					quantity="0"
				fi
				echo "After..qty:" $qty
				echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$suppress^$ImmParent^" >>  $partfileNew
			done < AssyBomSuperSet.txt
			echo "....Creating File for null qty to 9999..."
			grep -F '^9999^' to_load_parts_new.txt > nullQtyParts.txt
			while read kline
			do
				prtnm=`echo $kline |awk -F'^' '{print $2}'`
				grep -w $prtnm quantity.txt >> quantityNullParts.txt
			done < nullQtyParts.txt
		fi
		#Creating DataSets For ProE_rrr Items
		echo "....Creating DataSets For ProE_rrr Items..."
		if test -s input.txt
		then
			echo "File input.txt is already exist....."
		else
			if test -s "$directory".proe
			then
				while read jline
				do
					jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
					classNm=`echo $jline | cut -d\, -f11`
					fInstname=`echo $jline | cut -d\, -f1`
					fname=`echo $jline | cut -d\, -f2`
					#fname=`basename $fname`
					echo "fname: $fname"
					echo $fname | grep '/' >/dev/null 2>&1
					if [ "$?" -eq "0" ]; then
						echo "Found / in string"
						fname=`basename $fname`
					else
						echo "Couldnt find it"
					fi
					echo "jtname: $fname"
					prtName=`echo $fname | cut -d"." -f1`
					echo "..prtName: $prtName"
					echo "fInstname: $fInstname"
					echo $fInstname | grep '/' >/dev/null 2>&1
					if [ "$?" -eq "0" ]; then
						echo "Found / in string"
						fInstname=`basename $fInstname`
					else
						echo "Couldnt find it"
					fi
					echo $fInstname | grep '<' >/dev/null 2>&1
					if [ "$?" -eq "0" ]; then
						prtInstName=`echo $fInstname | cut -d"<" -f1`
						prtGenName2=`echo $fInstname | cut -d"<" -f2`
						prtGenName=`echo $prtGenName2 | cut -d">" -f1`
						echo "prtInstName: $prtInstName"
						echo "prtGenName: $prtGenName"
						#add here check for $prtGenName numeric/Alphanumeric for 12digitInstance<12digitGeneric>
						#if
						#else
						f_prt=`grep -iw $prtInstName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtInstName`
						echo "f_prt: $f_prt"
						if [ ! -z "$f_prt" ]; then
							f_partNo=`echo $f_prt | cut -d"^" -f2`
							f_partRev=`echo $f_prt | cut -d"^" -f3`
							f_partSeq=`echo $f_prt | cut -d"^" -f4`
							echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^"
							echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^" >>  input.txt
							#echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
							#echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
							echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
							echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
						fi
					else
						f_prt=`grep -iw $prtName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtName`
						if [ ! -z "$f_prt" ]; then
							f_partNo=`echo $f_prt | cut -d"^" -f2`
							f_partRev=`echo $f_prt | cut -d"^" -f3`
							f_partSeq=`echo $f_prt | cut -d"^" -f4`
							echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^-^Proe Des.Doc^" >>  input.txt
						fi
					fi
				done < "$directory".proe
			fi
			#Below while loop is added for Drawing and PDF-JT Dataset
			while read jline
			do
				classNm=`echo $jline | cut -d\, -f5`
				f_DataItem=`echo $jline | cut -d\, -f8`
				f_partNo=`echo $jline | cut -d\, -f7`
				f_partRevSeq=`echo $jline | cut -d\, -f6`
				f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
				f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
				fname=`echo $jline | cut -d\, -f2`
				fname=`basename $fname`
				echo $fname | grep '/' >/dev/null 2>&1
				# below fnameSuffix is added on 10.11.2016 and ALF-JT copy logic is added
				fnameSuffix=`echo $fname | cut -d\. -f2`
				if [ "$fnameSuffix" == "jt" ];then
					fnameJt=`echo $fname | cut -d\. -f1`
					#echo "fnameSuffix: $fnameSuffix"
					if [[ "$fnameJt" =~ "_ALF" ]]
					then
						echo "ALF is present found in string"
						f_partNo=`echo $jline | cut -d\, -f9`
						echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
						#echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
					elif [[ "$fnameJt" =~ "_WELD" ]]
					then
						echo "WELD is present found in string"
						f_partNo=`echo $jline | cut -d\, -f9`
						echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
						#echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
					elif [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile" -o "$classNm" == "ProPrt" -o "$classNm" == "ProAsm" -o "$classNm" == "ProAsmI" -o "$classNm" == "ProPrtI" ];then
						echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^" >>  input.txt
						#echo "-f=$jtname -type=ProDrw -d="$Drwdataset/$revision" -ref=DrwFile -item=$itemname -revision=$revision -ie=y -de=u -desc=Drawing_File -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >> jt_temp.txt
						#echo "-f=$jtname -type=PDF -d="$Drwdataset/$revision" -ref=PDF_Reference -item=$itemname -revision=$revision -ie=y -de=u -desc=PDF_File -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >> jt_temp.txt
					fi
				fi
				fnameSuffix=`echo $fname | cut -d\. -f2`
			done < "$directory".out.jt
		fi
		if [[ -f "input.txt" && -s "input.txt" ]]; then
			sort -u input.txt > input.txt1
			mv input.txt1 input.txt
			#cat input.txt
			#/user/rrr05503/Shells/TmlDataSetLoadProE -i=input.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba 
			#if [ $? != 0 ]
			#then
			#	echo "Problem in TmlDataSetLoadProE  $directory"
			#	exit 1
			#fi
		fi
		echo "**Going to load IPEM Dependancy Relation.."
		/user/rrr05503/Shells/TmlloadParts_IPEMRel -i=${filename}_parts.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on
		if [ $? != 0 ]
		then
			echo "Problem in TmlloadParts_IPEMRel for file $directory  ${filename}_parts.txt"
			exit 1
		fi
		echo "**Going to load Structure............................................"
		/user/rrr05503/Shells/TmlloadParts -i=${filename}_parts_new.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on
		if [ $? != 0 ]
		then
			echo "Problem in TmlloadParts for file $directory  ${filename}_parts_new.txt"
			exit 1
		fi
		echo "**Going to update hidden data............................................"
		if test -s suppressedTruePartList.txt
		then
			rm -rf suppressedTruePartList.txt
		fi
		grep -i "TRUE" *.pos > suppressedTruePartListTemp.txt
		while read pline
		do
			ParentAssy=`echo $pline | cut -d\, -f1`
			SupPart=`echo $pline | cut -d\, -f2`
			SupAttrVal=`echo $pline | cut -d\, -f20`
			echo "1^$SupPart^ ^ ^ ^1^$SupPart^4^1^TRUE^$ParentAssy^" >>  suppressedTruePartList.txt
			#	f_prt=`grep -iw $SupPart allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $SupPart`
			#	if [ ! -z "$f_prt" ]; then
			#		f_partNo=`echo $f_prt | cut -d"^" -f2`
			#		f_partRev=`echo $f_prt | cut -d"^" -f3`
			#		f_partSeq=`echo $f_prt | cut -d"^" -f4`
			#		f_partDes=`echo $f_prt | cut -d"^" -f5`
			#		echo "1^$f_partNo^$f_partRev^$f_partSeq^$f_partDes^1^$f_partNo^4^1^TRUE^" >>  suppressedTruePartList.txt
			#	fi
		done < suppressedTruePartListTemp.txt
		grep "TRUE" to_load_parts_new.txt >> suppressedTruePartList.txt
		if test -s suppressedTruePartList.txt
		then
			sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
			mv suppressedTruePartList.txt1 suppressedTruePartList.txt
			PartNm=`echo $PartDirName | cut -d"_" -f1`
			PartRev=`echo $PartDirName | cut -d"_" -f2`
			PartSeq=`echo $PartDirName | cut -d"_" -f3`
			echo "$PartNm-$PartRev;$PartSeq-$PartSeq"
			/user/rrr05503/Shells/UpdateBomLineSuppressAttr -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba  -i="$PartNm" -j="$PartRev;$PartSeq" -k=$PartSeq -m="Design Revision" -f=suppressedTruePartList.txt
			if [ $? != 0 ]
			then
				echo "Problem in UpdateBomLineAttr  $directory"
				exit 1
			fi
		fi
		##### Below is commented on 14.04.2017 and Generic $1_GenericInstance.txt is added at end of shell
		if [[ "$GenericFileExistFlag" != "1" ]]; then
			if [[ -f $fileNm ]] && [[ ! -s $fileNm ]]; then
				echo "11.GenericInstance File is empty" ;
			else
				echo "**Going to create generic-instance cad/dataset relation.."
				/user/rrr05503/Shells/TmlProEGeneric -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=GenericInstance.txt
				if [ $? != 0 ]
				then
					echo "Problem in TmlProEGeneric  $directory"
					exit 1
				fi
			fi
		fi
		##### Below is commented on 14.04.2017 and $1_LhRhPartDet.txt is added at end of shell
		if [[ "$LhRhPartFileExistFlag" != "1" ]]; then
			if [[ -f $fileLhRh ]] && [[ ! -s $fileLhRh ]]; then
				echo "11.LhRhPartDet File is empty" ;
			else
				echo "**Going to create LH-RH Design Master relation.."
				/user/rrr05503/Shells/TmlLhRhRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=LhRhPartDet.txt
				if [ $? != 0 ]
				then
					echo "Problem in TmlLhRhRel  $directory"
					exit 1
				fi
			fi
		fi
		##below is added on 06.04.2017 in shell
		echo "**Going to create ALF Dataset Relation.."
		#/user/rrr05503/Shells/AlfJtLoad.sh "$1" "$directory"
		nohup /user/rrr05503/Shells/AlfJtLoad.sh "$1" "$directory" > "$mainDir"/"$directory"_AlfJtLoad.log &
		if [ $? != 0 ]
		then
			echo "Problem in AlfJtLoad.sh  $directory"
			exit 1
		fi
		cd ..
	done < $1.PartList.txt
	echo "**Going to create DesignRev Drawing to Dataset relation.."
	if test -s "$1"_allRevJT.jt.temp
	then
		echo "Inside if condition.."
		#/user/rrr05503/Shells/TmlPartDSToDrwDSRel -i="$1"_allRevJT.jt.temp
		/user/rrr05503/Shells/TmlPartDSToDrwDSRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=AllPartAllRevFile_"$1".txt
	fi
	if [[ "$GenericFileExistFlag" == "1" ]]; then
		echo ".......GenericInstance File is present at  $fileNmMain"
		if [[ -f $fileNmMain ]] && [[ ! -s $fileNmMain ]]; then
			echo "12.GenericInstance File is empty  $fileNmMain"
		else
			echo "**Going to create generic-instance cad/dataset relation.."
			/user/rrr05503/Shells/TmlProEGeneric -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=GenericInstance_"$1".txt
			if [ $? != 0 ]
			then
				echo "Problem in TmlProEGeneric  $directory"
				exit 1
			fi
		fi
	fi
	if [[ -f $fileLhRhMain ]] && [[ ! -s $fileLhRhMain ]]; then
		echo "12.LhRhPartDet File is empty  $fileLhRhMain"
	else
		echo "**Going to create LH-RH Design Master relation.."
		/user/rrr05503/Shells/TmlLhRhRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=LhRhPartDet_"$1".txt
		if [ $? != 0 ]
		then
			echo "Problem in TmlLhRhRel  $directory"
			exit 1
		fi
	fi
else
	echo "--------------ERROR..Part Creation is failed, Please check log............."
	exit 1
fi
#Going to get powertrain module list from file...(Added by Kalpesh...23_oct_2018)
echo ".....Going to get the list of powertrain modules....."
while read i
do
partRevSeq=`echo $i | cut -d',' -f5`
echo "$partRevSeq"
part=`echo $partRevSeq | cut -d'_' -f1`
rev=`echo $partRevSeq | cut -d'_' -f2`
seq=`echo $partRevSeq | cut -d'_' -f3`
echo "$part" "$rev" "$seq"
if [ ${#part} = 14 ]
then
    file="input_PTmodule.txt"
    touch $file
    echo $part"^"$rev";"$seq"^">> $file
fi
done < $1.PartList.txt
echo ".....Going to update Powertrain Module attribute values....."
/user/rrr05503/Shells/update_PTmodule -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file=$file
echo "..........PTmodule Attribute value update activity Finished.........."
echo "..................Loading Finished...$1.............."
echo "  "
echo ".......... Please check file [ $mainDir/LoadingFailureMessages.txt] for loading failure data .............."
date
