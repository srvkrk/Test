######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	  : Aniket P. Kadu
# Created on	  : August 01, 2011
# Project         : Teamcenter 8.3 Trilix
#
#######################################################################################


user=$2
pass=$3
folder=$1
cd $folder
filename=`echo $1 | cut -d\_ -f1`
echo $folder
echo $filename


split -l1000 $filename.txt.fullList $filename.txt.fullList.

splitfiles=`ls $filename.txt.fullList.*`
for flist in $splitfiles
do
	echo "Importing file $flist" >> failure.log
	../createRevforParent -i=$flist -u=$user -p=$pass
	if [ $? -eq 0 ];then
		echo "Meta Data Loaded....:$flist" >> failure.log
	else
		echo "Some issue in this file : $flist" >> error.log		
	fi
	wait 
	sleep 10
done

####../createRevforParent -i=$filename.txt.fullList -u=$user -p=$pass


errorcnt=`cat error.log | wc -l`
if [ $errorcnt -eq 0 ];then

	echo "Creating structure.........1............"
	partfile=${filename}_parts.txt
	echo "#DELIMITER ^" > $partfile
	echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile

	while read line
	do


		echo $line
		level=`echo $line |awk -F'^' '{print $1}'`
		item=`echo $line |awk -F'^' '{print $2}'`
		rev=`echo $line |awk -F'^' '{print $3}'`
		seq=`echo $line |awk -F'^' '{print $4}'`
		desc=`echo $line |awk -F'^' '{print $5}'`
		qty=`echo $line |awk -F'^' '{print $6}'`

		name=$item
		unitofmes="-"
		quantity="1"

		echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile

	done < "$filename.txt.all"

	../loadParts -i=$partfile -o=on -u=$user -p=$pass
	if [ $? -eq 0 ];then
		echo "strcuture created success:loadparts" >> failure.log
		wait 
		sleep 10
		../AttachSpecFiles -i=$filename.txt.all.spec -u=$user -p=$pass
		if [ $? -eq 0 ];then
			echo "Spec file added properly" >> failure.log
		else
			echo "Some issue in adding spec file" >> error.log		
		fi
		wait 
		sleep 10	
	else
		echo "Some issue in structure creation:loadparts" >> error.log		
	fi


else

	echo "Error while loading.... Please check error file" 
		
fi