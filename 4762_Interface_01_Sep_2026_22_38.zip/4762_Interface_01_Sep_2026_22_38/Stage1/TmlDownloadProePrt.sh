######################################################################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	: Rupali Rane
# Created on	: Jan 06, 2018
# Project	: Teamcenter 10.1
# Module	: TCUA Proe Prt components Downloader
# Code		: TmlDownloadProePrt.sh
#
# Modification History :
#	S.No	Date		Modified By     Modification Notes
#	------	-----------	-------------	--------------------------------------------------------------------------------------
#
#######################################################################################################################################
date
echo "Shell Inputs are: [$1]  [$2]"
cd /uv19/UAFiles/ProE_Downloading/Downloaders/
pwd
if [ -d "$1" ]; then
rm -rf $1
fi
mkdir $1
chmod 777 $1
cd "$1"
mainDir=`pwd`
echo "Error Message list as below::" > "$1"_ErrorMessages.txt
chmod 777 "$1"_ErrorMessages.txt
/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetProEPartList_ProPrtFetchOnly Loader 123loader $1 $1.PartList.txt $1.CatiaPartList.txt
if [ $? != 0 ]
then
echo "Problem in GetPartList"
exit 1
fi
if [ -s "$1.PartList.txt" ] 
then
	echo "$1.PartList.txt has some data."
	while read l_line
	do
		echo "******* Input: " $l_line
		proedi=`echo $l_line |awk -F',' '{print $1}'`
		proeseq=`echo $l_line |awk -F',' '{print $2}'`
		proe_owner_dir=`echo $l_line |awk -F',' '{print $3}'`
		proe_owner=`echo $l_line |awk -F',' '{print $4}'`
		directory=`echo $l_line |awk -F',' '{print $5}'`
		echo "**Directory name is--------->$directory"
		mkdir $directory
		cd "$directory"
		echo " Doubt proe_di ------->$proedi "
		echo " Doubt proeseq ------->$proeseq "
		echo " Doubt proe_owner_dir ------->$proe_owner_dir "
		echo " Doubt proe_owner ------->$proe_owner "
		echo " dir name is--------->$directory"
		echo "   Input:  $proedi $proeseq $proe_owner_dir $proe_owner"
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetJTAndProeInfo Loader 123loader "$proedi" "$proeseq" "$proe_owner_dir" "$proe_owner" ${directory}.out.proe ${directory}.out.file2.jt.temp ${directory}.proe
		if [ $? != 0 ]
		then
			echo "Problem in TmlGetJTAndProeInfo"
			exit 1
		fi
		echo "directory is :---> ${directory}.out.proe"
		sort -u LhRhPartDet.txt > LhRhPartDet_a.txt
		mv LhRhPartDet_a.txt LhRhPartDet.txt
		cat LhRhPartDet.txt >> "$mainDir"/LhRhPartDet_"$1".txt
		cat AllPartAllRevFile.txt | awk '!seen[$0]++' > AllPartAllRevFile.txt1
		mv AllPartAllRevFile.txt1 AllPartAllRevFile.txt
		cat AllPartAllRevFile.txt >> "$mainDir"/AllPartAllRevFile_"$1".txt
		cd ..
	done < $1.PartList.txt
	if [ -s "$mainDir/AllPartAllRevFile_$1.txt" ] 
	then
		echo "Download all CAD/JT/DRW/PDF/Catia Data.."
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/TmlgetAllRevJTPDF.sh $1 "$2"
		echo "Assembly JT files Downloading..."
		pwd
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/TmlCadDataAvialableCheck.sh $1 "$2"

		echo "-----Executing shell DatasetGenerateFile.sh-------------------------------------------------------------------------"
		pwd
		if [[ $2 = "" ]]
		then
			/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/DatasetGenerateFile.sh "$1" "/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime" "$2"
		elif [[ $2 = "uaprod" ]]
		then
			/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/DatasetGenerateFile.sh "$1" "/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime" "$2"
		elif [[ $2 = "infodba" ]]
		then
			/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/DatasetGenerateFile.sh "$1" "/home/infodba/TCUA/TCUA_ProE_Loading" "$2"
		#elif [[ $2 = "cmitest" ]]
		#then
			#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/DatasetGenerateFile.sh "$1" "/home/infodba/TCUA/TCUA_ProE_Loading" "$2"
		else
			echo "Dataset file inputAllRevJT.txt is not generated ?????? "
			#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/DatasetGenerateFile.sh "$1" "$2" ""
		fi
	fi
else
	echo "$1.PartList.txt is empty. Please check TC part should attached to any one of CAD asm/prt...."
	exit 1
fi
pwd
find . -size 0 | xargs rm
cd ..
chmod 777 $1 $1/* $1/*/*
echo "Downloading is Finished..........."
date
