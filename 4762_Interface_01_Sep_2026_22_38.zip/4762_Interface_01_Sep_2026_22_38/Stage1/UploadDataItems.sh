######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	  : Aniket P. Kadu
# Created on	  : August 01, 2011
# Project         : Teamcenter 8.3 Trilix
#
#######################################################################################


foldername=$1
temp=`echo $1 | cut -d\_ -f1`
filename=${temp}_sorted_jt.txt
catiafilename=${temp}_sorted_catia.txt
cgrfilename=${temp}_sorted_cgr.txt
specfilename=${temp}_sorted_spec.txt
drwfilename=${temp}_sorted_catiadrw.txt

username=$2
password=$3

echo $foldername
echo $filename
echo $cgrfilename
echo $catiafilename

while read line 
do
	itemname=`echo $line |awk -F',' '{print $7}'`

	###dataset=`echo $line |awk -F',' '{print $3}'`
	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`

	revision=`echo $line |awk -F',' '{print $8}'`
        jtname=`echo $line |awk -F',' '{print $2}'`
	jtname=`basename $jtname`
	if [ "$itemname" = "" ];then		
		echo "No Jt File to Copy"
	else

		if [ -f $jtname ];then

			echo "Copying $jtname"
			echo "-f=$jtname -type=DirectModel -d="$dataset/$revision" -ref=JTPART -item=$itemname -revision=$revision -ie=y -de=u -desc=jt file -use_ds_attached_to_rev_only -relationType=IMAN_Rendering -vb" >> jt_temp.txt
		else
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
		fi	
	fi
	

done < $filename

	split -l100 jt_temp.txt jt_temp.split.
	splitfiles=`ls jt_temp.split.*`
	for flist in $splitfiles
	do
		echo "Importing file $flist"
		$TC_ROOT/bin/import_file -i=$flist -u=$username -p=$password
	done

echo $catiafilename
while read line
do

	itemname=`echo $line |awk -F',' '{print $7}'`

	###dataset=`echo $line |awk -F',' '{print $3}'`
	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`

	revision=`echo $line |awk -F',' '{print $8}'`
        catiafile=`echo $line |awk -F',' '{print $2}'`
	catiafile=`basename $catiafile`

	if [ "$itemname" = "" ];then	
		echo "Data set Empty"
	else

		res=`echo $catiafile | grep -i ".catpart"`
		echo x$res

		if [ "x$res" = "x" ];then
			catType=CATProduct
			reference=catproduct
		else
			catType=CATPart
			reference=catpart
		fi 
		
		if [ -f $catiafile ];then
			echo "-f=$catiafile -type=$catType -d="$dataset/$revision" -ref=$reference -item=$itemname -revision=$revision -ie=y -de=u -use_ds_attached_to_rev_only -desc=catia file" >> catia_temp.txt
		else
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
		fi
	fi

done < $catiafilename
	
	split -l100 catia_temp.txt catia_temp.split.
	splitfiles1=`ls catia_temp.split.*`
	for flist1 in $splitfiles1
	do
		echo "Importing file $flist1"
		$TC_ROOT/bin/import_file -i=$flist1 -u=$username -p=$password
	done


echo $cgrfilename
while read line
do
	

	itemname=`echo $line |awk -F',' '{print $7}'`

	###dataset=`echo $line |awk -F',' '{print $3}'`
	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`

	revision=`echo $line |awk -F',' '{print $8}'`
        cgrfile=`echo $line |awk -F',' '{print $2}'`
	cgrfile=`basename $cgrfile`

	res=`echo $cgrfile | grep -i ".catpart"`
	echo x$res
	if [ "x$res" = "x" ];then
	
		echo "Skipping CatProduct"

	else

		if [ "$itemname" = "" ];then	
			echo "Data set Empty"
		else
			if [ -f $cgrfile ];then
				echo "copying Cgr:$cgrfile"
				echo "-f=$cgrfile -type=CATCache -d="$dataset/$revision" -ref=catcgr -item=$itemname -revision=$revision -ie=y -de=u -use_ds_attached_to_rev_only -desc=cgr file" >> cgr_temp.txt
			else
				echo "Not At OS:$cgrfile" >> NotAtOs.txt
			fi
		fi
	fi

done < $cgrfilename
	
	split -l100 cgr_temp.txt cgr_temp.split.
	splitfiles2=`ls cgr_temp.split.*`
	for flist2 in $splitfiles2
	do
		echo "Importing file $flist2"
		$TC_ROOT/bin/import_file -i=$flist2 -u=$username -p=$password 
	done


### As of now not loading spec file.

echo $specfilename
while read line
do

	####itemname=`echo $line |awk -F',' '{print $7}'`

	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`

	itemname=$dataset

	revision=`echo $line |awk -F',' '{print $8}'`
        specfile=`echo $line |awk -F',' '{print $2}'`
	specfile=`basename $specfile`

	if [ "$itemname" = "" ];then	
		echo "Data set Empty"
	else

		res=`echo $specfile | grep -i ".catpart"`
		echo x$res

		if [ "x$res" = "x" ];then
			catType=CATProduct
			reference=catproduct
		else
			catType=CATPart
			reference=catpart
		fi 
		
		if [ -f $specfile ];then
			echo "-f=$specfile -type=$catType -d="$dataset/$revision" -ref=$reference -item=$itemname -revision=$revision -ie=y -de=u -use_ds_attached_to_rev_only -desc=catia file" >> spec_temp.txt
		else
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
		fi
	fi

done < $specfilename
	
	split -l100 spec_temp.txt spec_temp.split.
	splitfiles4=`ls spec_temp.split.*`
	for flist4 in $splitfiles4
	do
		echo "Importing file $flist4"
		$TC_ROOT/bin/import_file -i=$flist4 -u=$username -p=$password 
	done


echo $drwfilename
while read line
do

	itemname=`echo $line |awk -F',' '{print $7}'`

	###dataset=`echo $line |awk -F',' '{print $3}'`
	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`

	revision=`echo $line |awk -F',' '{print $8}'`
        drwfile=`echo $line |awk -F',' '{print $2}'`
	drwfile=`basename $drwfile`

	org_rel=`echo $line |awk -F',' '{print $5}'`

	if [ "$itemname" = "" ];then	
		echo "Data set Empty"
	else

		catType=CATDrawing
		reference=catdrawing

		if [ "$org_rel" = "Reference" ];then	
			relation=IMAN_reference
		else

			relation=IMAN_specification
		fi
		
		if [ -f $drwfile ];then
			echo "-f=$drwfile -type=$catType -d="$dataset/$revision" -ref=$reference -item=$itemname -revision=$revision -ie=y -de=u -use_ds_attached_to_rev_only -relationType=$relation -desc=catia file" >> catia_drw_temp.txt
		else
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
		fi
	fi

done < $drwfilename


split -l100 catia_drw_temp.txt catia_drw_temp.split.
splitfiles4=`ls catia_drw_temp.split.*`
for flist4 in $splitfiles4
do
	echo "Importing file $flist4"
	$TC_ROOT/bin/import_file -i=$flist4 -u=$username -p=$password 
done