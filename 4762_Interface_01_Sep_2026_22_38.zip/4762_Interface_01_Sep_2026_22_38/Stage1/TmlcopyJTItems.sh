######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	  : Aniket P. Kadu
# Created on	  : Jan 10, 2012
# Project         : Teamcenter 8.3 Trilix
# Module	  : TCUA Proe Downloader
# Code            : copyJTItems.sh
#
#######################################################################################

Vault_INFO_FILE="/user/omfprod/shells/cad/JT/JTShells/Vault_INFO"
LOCAL_IP=`hostname`
echo "Hello World"

while read jline
do
	
	echo "Processing line:$jline"
	chk_dirname=`echo $jline | cut -d\, -f3`
	
	if [ "$chk_dirname" = "" ];then
		
		echo "No Jt File to Copy"

	else

		chk_owner=`echo $jline | cut -d\, -f4`
		fname=`echo $jline | cut -d\, -f1 | sed 's/ /_/g'`
		
		jtname=`echo $jline | cut -d\, -f2`
		jtname=`basename $jtname`
		cat $Vault_INFO_FILE | grep "$LOCAL_IP" | grep "$chk_dirname" >chk_file.$$
		if [ -s chk_file.$$ ];then
			while read m
			do
				
				echo "f44444444444444444-->$f4"
				m_path=`echo $m | cut -d':' -f4`
				echo "valut path -->$m_path"
				echo "Checking di�$m_path/$fname $jtname"
				if [ -f $m_path/$fname ];then
					echo "Linking di�$m_path/$fname $jtname"
					cp "$m_path/$fname" "$2/$jtname"
									
				fi
			done <chk_file.$$
		else
			echo "vault not present locally"
		fi

	fi
done < "$1"