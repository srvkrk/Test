################################################################################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author		: Aniket Kadu / Sharvari
# Created on	: Jan 10, 2012
# Project       : Teamcenter 8.3 Trilix to TC10.1
# Module		: TCUA Proe Uploader
# Code          : loadProeData.sh
#
#	Sr.No.	Modified_on		Modified_By		Remark
#	1.	11.07.2015		Rupali/Sharvari
#	2.	09.05.2016		Rupali
#	3.	22.07.2016		Rupali			ALF-JT
#	4.	12.11.2016		Rupali			f_prt=`grep -iw $prtInstName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtInstName`
#	5.	05.04.2017		Rupali			AlfJtLoad.sh shell is added
#
#
# Shell Usage:: Shellname Partnumber OutputRedirectedLogFilename(to grep not created part rev)
#
#################################################################################################################################################
date
cd "$1"
mainDir=`pwd`
echo "mainDir:  $mainDir"
if [ `ls -ltr | grep ^d | wc -l` -lt 2 ];then
	echo -e "\n\n WARNING: No Assembly directory present in current directory for BOM migration, check downloading log ??????????? \n"
	exit 1
else
	echo "Assembly directory found"
fi
fileNm=GenericInstance.txt
echo "fileNm: $fileNm"
fileNmMain=GenericInstance_"$1".txt
echo "fileNmMain::: $fileNmMain"
fileLhRh=LhRhPartDet.txt
echo "fileLhRh: $fileLhRh"
fileLhRhMain=LhRhPartDet_"$1".txt
echo "fileLhRhMain::: $fileLhRhMain"
filename="to_load"
partfile=${filename}_parts.txt
partfileNew=${filename}_parts_new.txt
AllPartAllRevFlag=0
AllPartAllRevSubAssyFlag=0
GenericFileExistFlag=0
LhRhPartFileExistFlag=0
if test -s "$fileNmMain"
then
GenericFileExistFlag=1
fi
if test -s "$fileLhRhMain"
then
LhRhPartFileExistFlag=1
fi
ErrorFileSize=`ls -lah "$1"_ErrorMessages.txt | awk '{ print $5 }'`
echo "ErrorFileSize   $1_ErrorMessages.txt:  $ErrorFileSize"
if [ "$ErrorFileSize" -gt 30 ]
then
	echo -e "\n\n ERROR::  T-Matrix are not downloaded for all assemblies. Pls check file   $1_ErrorMessages.txt   hence not uploading....\n"
	exit 1
fi
echo "**Going to upload all Design Revisions .."
if test -s AllPartAllRevFile_"$1".txt
then
nohup /user/rrr05503/Shells/TmlcreateRevForProe_CreRevAPI -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=AllPartAllRevFile_"$1".txt >> "$1"_createRevForProe.log1 &
wait
if [ $? != 0 ]
then
echo "Problem in TmlcreateRevForProe for file AllPartAllRevFile_$1.txt"
exit 1
else
AllPartAllRevFlag=1
fi
fi
echo "AllPartAllRevFlag:   $AllPartAllRevFlag"
echo "**Going to upload all revisions CAD/PDF/JT/DRW.."
if [[ -f inputAllRevJT.txt ]] && [[ ! -s inputAllRevJT.txt ]]; then
echo "inputAllRevJT.txt File is empty"
exit 1
else
/user/rrr05503/Shells/TmlDataSetLoadProE -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=inputAllRevJT.txt
#if [ $? != 0 ]
#then
#echo "Problem in allrevJT TmlDataSetLoadProE"
#exit 1
#fi
fi
echo "**Going to upload Sub-Assembly Structure BOM.."
if test -s "$1".SubAssyPartList.txt
then
/user/rrr05503/Shells/TmlloadProeSubAssyData_newLogic.sh $1
if [ $? != 0 ]
then
echo "Problem in TmlloadProeSubAssyData_newLogic.sh  $1"
exit 1
fi
fi
echo "**Going to upload Structure BOM.."
while read lineFld
do
echo "2.******************Input: " $lineFld
directory=`echo $lineFld |awk -F',' '{print $5}'`
PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
DirPartNm=`echo $PartDirName | cut -d"_" -f1`
DirPartRev=`echo $PartDirName | cut -d"_" -f2`
DirPartSeq=`echo $PartDirName | cut -d"_" -f3`
cd "$directory"
echo "2.Working FolderName: $directory"
echo "Creating DataSets For ProE_rrr Items..."
####Below is commented on 24.03.2018 to avoid duplicate generic dataset creation
#if [[ -f input.txt ]] && [[ ! -s input.txt ]]; then
#echo "input.txt File is empty"
#else
#/user/rrr05503/Shells/TmlDataSetLoadProE -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=input.txt
#if [ $? != 0 ]
#then
#echo "Problem in TmlDataSetLoadProE  $directory"
#exit 1
#fi
#fi
echo "**Going to load IPEM Dependancy Relation.."
/user/rrr05503/Shells/TmlloadParts_IPEMRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on -i=${filename}_parts.txt
if [ $? != 0 ]
then
echo "Problem in TmlloadParts_IPEMRel for file $directory  ${filename}_parts.txt"
exit 1
fi
echo "**Going to load Structure.."
/user/rrr05503/Shells/TmlloadParts -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on -i=${filename}_parts_new.txt
if [ $? != 0 ]
then
echo "Problem in TmlloadParts for file $directory  ${filename}_parts_new.txt"
exit 1
fi
#echo "**Going to Update suppressed Attribute......"
#if test -s suppressedTruePartList.txt
#then
#sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
#mv suppressedTruePartList.txt1 suppressedTruePartList.txt
#else
#echo "  hidden data file is empty"
#fi
#PartNm=`echo $PartDirName | cut -d"_" -f1`
#PartRev=`echo $PartDirName | cut -d"_" -f2`
#PartSeq=`echo $PartDirName | cut -d"_" -f3`
#/user/rrr05503/Shells/UpdateBomLineSuppressAttr -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -m="Design Revision" -f=suppressedTruePartList.txt -i=$PartNm -j="$PartRev;$PartSeq" -k=$PartSeq
#if [ $? != 0 ]
#then
#echo "Problem in UpdateBomLineSuppressAttr  $directory"
#exit 1
#fi

###### Below is commented on 14.04.2017 and Generic $1_GenericInstance.txt is added at end of shell
#if [[ "$GenericFileExistFlag" != "1" ]]; then
#if [[ -f $fileNm ]] && [[ ! -s $fileNm ]]; then
#echo "11.GenericInstance File is empty" ;
#else
#echo "**Going to create generic-instance cad/dataset relation.."
#/user/rrr05503/Shells/TmlProEGeneric -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=GenericInstance.txt
#if [ $? != 0 ]
#then
#echo "Problem in TmlProEGeneric  $directory"
#exit 1
#fi
#fi
#fi
##### Below is commented on 14.04.2017 and $1_LhRhPartDet.txt is added at end of shell
if [[ "$LhRhPartFileExistFlag" != "1" ]]; then
if [[ -f $fileLhRh ]] && [[ ! -s $fileLhRh ]]; then
echo "11.LhRhPartDet File is empty" ;
else
echo "**Going to create LH-RH Design Master relation.."
/user/rrr05503/Shells/TmlLhRhRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=LhRhPartDet.txt
if [ $? != 0 ]
then
echo "Problem in TmlLhRhRel  $directory"
exit 1
fi
fi
fi
##below is added on 06.04.2017 in shell
echo "**Going to create ALF Dataset Relation.."
/user/rrr05503/Shells/AlfJtLoad.sh "$1" "$directory"
cd ..
done < $1.PartList.txt
echo "**Going to create DesignRev Drawing to Dataset relation.."
if test -s "$1"_allRevJT.jt.temp
then
echo "Inside if condition.."
/user/rrr05503/Shells/TmlPartDSToDrwDSRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$1"_allRevJT.jt.temp
fi
if [[ -f $fileLhRhMain ]] && [[ ! -s $fileLhRhMain ]]; then
echo "11.LhRhPartDet File is empty  $fileLhRhMain"
else
echo "**Going to create LH-RH Design Master relation.."
/user/rrr05503/Shells/TmlLhRhRel -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=LhRhPartDet_"$1".txt
if [ $? != 0 ]
then
echo "Problem in TmlLhRhRel  $directory"
exit 1
fi
fi
#if [[ "$GenericFileExistFlag" == "1" ]]; then
#echo ".......GenericInstance File is present at  $fileNmMain"
#if [[ -f $fileNmMain ]] && [[ ! -s $fileNmMain ]]; then
#echo "11.GenericInstance File is empty  $fileNmMain"
#else
#echo "**Going to create generic-instance cad/dataset relation.."
#/user/rrr05503/Shells/TmlProEGeneric -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=GenericInstance_"$1".txt
#if [ $? != 0 ]
#then
#echo "Problem in TmlProEGeneric  $directory"
#exit 1
#fi
#fi
#fi
while read lineFld
do
	echo "3.Input:  " $lineFld
	directory=`echo $lineFld |awk -F',' '{print $5}'`
	PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
	if [ ! -d "$directory" ]; then
	continue;
	fi
	cd "$directory"
	echo "5.Working FolderName: $directory"
	echo "**Going to Update suppressed Attribute......"
	if test -s suppressedTruePartList.txt
	then
		sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
		mv suppressedTruePartList.txt1 suppressedTruePartList.txt
		PartNm=`echo $PartDirName | cut -d"_" -f1`
		PartRev=`echo $PartDirName | cut -d"_" -f2`
		PartSeq=`echo $PartDirName | cut -d"_" -f3`
		/user/rrr05503/Shells/UpdateBomLineSuppressAttr -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -m="Design Revision" -f=suppressedTruePartList.txt -i=$PartNm -j="$PartRev;$PartSeq" -k=$PartSeq
		if [ $? != 0 ] 
		then
			echo "2--Problem in UpdateBomLineSuppressAttr  $directory"
			exit 1
		fi
	else
		echo " $directory   hidden data file is empty"
	fi
	cd ..
done < $1.PartList.txt
while read SubAssyPart
do
	echo "------TmlGetSubAssyProeData...Input: " $SubAssyPart
	if [ ! -d "$SubAssyPart" ]; then
	continue;
	fi
	cd "$SubAssyPart"
	while read lineFld
	do
		echo "4.Input:  " $lineFld
		directory=`echo $lineFld |awk -F',' '{print $5}'`
		PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
		if [ ! -d "$directory" ]; then
		continue;
		fi
		cd "$directory"
		echo "5.Working FolderName: $directory"
		echo "**Going to Update suppressed Attribute......"
		if test -s suppressedTruePartList.txt
		then
			sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
			mv suppressedTruePartList.txt1 suppressedTruePartList.txt
			PartNm=`echo $PartDirName | cut -d"_" -f1`
			PartRev=`echo $PartDirName | cut -d"_" -f2`
			PartSeq=`echo $PartDirName | cut -d"_" -f3`
			/user/rrr05503/Shells/UpdateBomLineSuppressAttr -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -m="Design Revision" -f=suppressedTruePartList.txt -i=$PartNm -j="$PartRev;$PartSeq" -k=$PartSeq
			if [ $? != 0 ]
			then
				echo "3--Problem in UpdateBomLineSuppressAttr  $directory"
				exit 1
			fi
		else
			echo " $directory   hidden data file is empty"
		fi
		cd ..
	done < "$SubAssyPart".PartList.txt
	cd ..
done < $1.SubAssyPartList.txt
echo "..................Loading Finished...$1.............."
date
