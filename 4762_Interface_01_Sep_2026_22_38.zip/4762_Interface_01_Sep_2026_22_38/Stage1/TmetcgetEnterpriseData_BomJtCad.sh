###################################################################################################
### Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
###
### This software is the confidential and proprietary information of TTL.
### You shall not disclose such confidential information and shall use it
### only in accordance with the terms of the license agreement.
###
###  File		 :   getEnterpriseData_BomJtCad.sh
###  Author		 :   Raghavendra B T
###  Module		 :   TCUA Downloader
###  
###                             
###
### Modification History :
### S.No    Date			CR No     Modified By            Modification Notes
####################################################################################################



./TmetcfetchMetaData_BomJtCad.sh $1 $2 $3

sleep 5

echo "\n Back to Main sheel \n"

#Copy Files
cd $1_$2_$3

mkdir JT
mkdir WIP
mkdir CE
mkdir Release
mkdir JT_REL

chmod -R 775 $1_$2_$3 

echo "\n Going to Copy CAD Physical files  -->$1_CAD_Physical.txt\n"

while read line
do
	classS=`echo "$line" | cut -d"," -f1`
	ownerNameS=`echo "$line" | cut -d"," -f2`
	fullPathS=`echo "$line" | cut -d"," -f3`
	RelativePathS=`echo "$line" | cut -d"," -f4`

	destFolder="abc"

	if [ "$ownerNameS" = "WIP Vault" ]; then
		remoteCopy="1"
		destFolder="WIP"
	fi

	
	if [ "$ownerNameS" = "CE Vault" ]; then
		remoteCopy="1"
		destFolder="CE"
	fi
	
	if [ "$ownerNameS" = "JT Vault" ]; then
		remoteCopy="1"
		destFolder="JT"
	fi

	if [ "$ownerNameS" = "Release Vault" -a "$classS" = "JT" ]; then
		remoteCopy="1"
		destFolder="JT_REL"
	fi

	if [ "$ownerNameS" = "Release Vault" -a "$classS" != "JT" ]; then		
		remoteCopy="1"
		destFolder="Release"
	fi

	Vloc_DIR=`echo $RelativePathS | cut -d"/" -f1`
	if [ "$Vloc_DIR" = "Vloc" ]; then
		CE_DIR_TO_CREATE=`dirname "$RelativePathS"`
		mkdir -p "${destFolder}/${CE_DIR_TO_CREATE}"
		destFolder="${destFolder}/${CE_DIR_TO_CREATE}"
	fi
	
	echo "rbb ----> $ownerNameS -- $destFolder -- $classS"

	echo "remoteCopy value is $remoteCopy"
	if [ -s $fullPathS ]; then
		if [ "$remoteCopy" = "0" ]; then
			scp -rp  $serverName:$fullPathS $destFolder
			if [ $? -eq 0 ]; then
				echo "File $fullPathS copied successfully."
			else
				createTar=0
				echo "File $fullPathS could not be copied."
				echo "$line" >> File_CAD_Not_Copied.txt
			fi
		else
			if [ "$destFolder" != "abc" ]; then
				echo "File $line is present with size greater than zero."
				echo "cp $fullPathS $destFolder"
				cp $fullPathS $destFolder
				if [ $? -eq 0 ]; then
					echo "File $fullPathS copied successfully."
				else
					createTar=0
					echo "File $fullPathS could not be copied."
					echo "$line" >> File_CAD_Not_Copied.txt
				fi
			else
				createTar=0
				echo "*** File $fullPathS ownername is not in the list of vault. Hence Not Copying. ***"
				echo "$line" >> File_Not_Copied_Owner_Not_Found.txt
			fi
		fi
	else
		echo "File $fullPathS does not exist or is of zero byte size."
		echo "$line" >> File_CAD_Not_Copied.txt
		createTar=0
	fi
done < $1_CAD_Physical.txt

echo "\n Going to Copy JT/PDF Physical files  -->$1_JT_Physical.txt\n"

while read line
do
	classS=`echo "$line" | cut -d"," -f1`
	ownerNameS=`echo "$line" | cut -d"," -f2`
	fullPathS=`echo "$line" | cut -d"," -f3`
	RelativePathS=`echo "$line" | cut -d"," -f4`

	destFolder="abc"

	if [ "$ownerNameS" = "WIP Vault" ]; then
		remoteCopy="1"
		destFolder="WIP"
	fi

	
	if [ "$ownerNameS" = "CE Vault" ]; then
		remoteCopy="1"
		destFolder="CE"
	fi
	
	if [ "$ownerNameS" = "JT Vault" ]; then
		remoteCopy="1"
		destFolder="JT"
	fi

	if [ "$ownerNameS" = "Release Vault" -a "$classS" = "JT" ]; then
		remoteCopy="1"
		destFolder="JT_REL"
	fi

	if [ "$ownerNameS" = "Release Vault" -a "$classS" != "JT" ]; then		
		remoteCopy="1"
		destFolder="Release"
	fi

	Vloc_DIR=`echo $RelativePathS | cut -d"/" -f1`
	if [ "$Vloc_DIR" = "Vloc" ]; then
		CE_DIR_TO_CREATE=`dirname "$RelativePathS"`
		mkdir -p "${destFolder}/${CE_DIR_TO_CREATE}"
		destFolder="${destFolder}/${CE_DIR_TO_CREATE}"
	fi
	
	echo "rbb ----> $ownerNameS -- $destFolder -- $classS"

	echo "remoteCopy value is $remoteCopy"
	if [ -s $fullPathS ]; then
		if [ "$remoteCopy" = "0" ]; then
			scp -rp  $serverName:$fullPathS $destFolder
			if [ $? -eq 0 ]; then
				echo "File $fullPathS copied successfully."
			else
				createTar=0
				echo "File $fullPathS could not be copied."
				echo "$line" >> File_JT_Not_Copied.txt
			fi
		else
			if [ "$destFolder" != "abc" ]; then
				echo "File $line is present with size greater than zero."
				echo "cp $fullPathS $destFolder"
				cp $fullPathS $destFolder
				if [ $? -eq 0 ]; then
					echo "File $fullPathS copied successfully."
				else
					createTar=0
					echo "File $fullPathS could not be copied."
					echo "$line" >> File_JT_Not_Copied.txt
				fi
			else
				createTar=0
				echo "*** File $fullPathS ownername is not in the list of vault. Hence Not Copying. ***"
				echo "$line" >> File_Not_Copied_Owner_Not_Found.txt
			fi
		fi
	else
		echo "File $fullPathS does not exist or is of zero byte size."
		echo "$line" >> File_JT_Not_Copied.txt
		createTar=0
	fi
done < $1_JT_Physical.txt

