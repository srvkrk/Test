echo "Input to shell TmlCadDataAvialableCheck.sh::  [$1]  [$2]"
var_path=`pwd`
echo $var_path
var_path2=`basename $var_path`
echo "var_path2: $var_path2"
if [ $var_path2 == "$1" ]
then
	echo "1..TmlCadDataAvialableCheck.sh..var_path:::::::::: $var_path"
else
	cd "$1"
	var_path=`pwd`
	echo "2..TmlCadDataAvialableCheck.sh..var_path:::::::::: $var_path"
fi
echo "In shell TmlCadDataAvialableCheck.sh.."
if [ -f CADnotFound_"$1".txt ]
then
rm -rf CADnotFound_"$1".txt
fi
if [ -f JTnotFound_"$1".txt ]
then
rm -rf JTnotFound_"$1".txt
fi
if [ -f "$1"_allRevCadScp.txt ]
then
rm -rf "$1"_allRevCadScp.txt
touch "$1"_allRevCadScp.txt
fi
if [ -f "$1"_allRevJTScp.txt ]
then
rm -rf "$1"_allRevJTScp.txt
touch "$1"_allRevJTScp.txt
fi
while read line1
do
	if [ "$line1" = "" ]
	then
	continue
	fi
	FullPath=`echo $line1 |awk -F',' '{print $10}'`
	#echo "FullPath: $FullPath"
	ls $FullPath 2>> CADnotFound_"$1".txt
done < "$1"_allRevCad.txt
while read line1
do
	if [ "$line1" = "" ]
	then
	continue
	fi
	FullPath=`echo $line1 |awk -F',' '{print $10}'`
	JTLocation=`echo $line1 |awk -F',' '{print $11}'`
	#echo "FullPath: $FullPath"
	#if [ "$JTLocation" = "PUNE" ]
	#then
		ls $FullPath 2>> JTnotFound_"$1".txt
	##elif [ "$JTLocation" = "JSR" ]
	##then
	#else
	#	echo "Need to copy other plant location JT in current folder for [ $JTLocation = $FullPath ]"
	#fi
done < "$1"_allRevJT.txt
while read line1
do
	if [ "$line1" = "" ]
	then
	continue
	fi
	FullPath=`echo $line1 |awk -F',' '{print $10}'`
	#echo "FullPath: $FullPath"
	ls $FullPath 2>> JTnotFound_"$1".txt
done < "$1"_allRevJT.txt1
if [ -f CADnotFound_"$1".txt ]
then
while read line
do
	a=`echo $line |awk -F' ' '{print $4}'`
	b=`echo $a | cut -d':' -f1`
	echo "CAD:  $b"
	grep "$b" "$1"_allRevCad.txt >> "$1"_allRevCadScp.txt
done < CADnotFound_"$1".txt
fi
if [ -f JTnotFound_"$1".txt ]
then
while read line
do
	a=`echo $line |awk -F' ' '{print $4}'`
	b=`echo $a | cut -d':' -f1`
	echo "JT:  $b"
	grep "$b" "$1"_allRevJT.txt >> "$1"_allRevJTScp.txt
done < JTnotFound_"$1".txt
fi
if [[ "$var_path" =~ "$1_allRevJT" ]]
then
pwd
else
	if [ ! -d "$1_allRevJT" ]; then
		mkdir "$1_allRevJT"
	fi
fi
cd "$1_allRevJT"
pwd
if [[ ( $2 == "uaprod" ) || ( -z "$2" ) ]]
then
	if [ -f $var_path/"$1"_allRevCadScp.txt ]
	then
		sort -u $var_path/"$1"_allRevCadScp.txt > $var_path/"$1"_allRevCadScp.txt1
		mv $var_path/"$1"_allRevCadScp.txt1 $var_path/"$1"_allRevCadScp.txt
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevCadScp.txt .
	else
		touch $var_path/"$1"_allRevCadScp.txt
	fi
	if [ -f $var_path/"$1"_allRevJTScp.txt ]
	then
		sort -u $var_path/"$1"_allRevJTScp.txt > $var_path/"$1"_allRevJTScp.txt1
		mv $var_path/"$1"_allRevJTScp.txt1 $var_path/"$1"_allRevJTScp.txt
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevJTScp.txt .
	else
		touch $var_path/"$1"_allRevJTScp.txt
	fi
else
	touch $var_path/"$1"_allRevJTScp.txt
	touch $var_path/"$1"_allRevCadScp.txt
	echo "Assembly JT files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevJT.txt1 .
	echo "JT files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevJT.txt .
	echo "CAD files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevCad.txt .
fi
#echo "Processing for file creation inputAllRevJT.txt ....................."
#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime"
#if [[ $2 = "" ]]
#then
#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime"
#elif [[ $2 = "uaprod" ]]
#then
#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime"
#elif [[ $2 = "infodba" ]]
#then
#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "/home/infodba/TCUA/TCUA_ProE_Loading"
##elif [[ $2 = "cmitest" ]]
##then
##/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "/home/infodba/TCUA/TCUA_ProE_Loading"
#else
#/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/New/DatasetGenerateFile.sh "$1" "$2"
#fi
echo "End of shell TmlCadDataAvialableCheck.sh....................."
