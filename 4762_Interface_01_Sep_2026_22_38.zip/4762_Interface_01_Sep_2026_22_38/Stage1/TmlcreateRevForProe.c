/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Aniket P. Kadu
*  Module		 :   TCUA Proe Uploader
*  Code			 :   createRevForProe.c
*  Created on	 :   Jan 10, 2012
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCWORKING	"T5_LcsReview"
#define ERCREVIEW	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"



#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,
                                    &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}
int setAttributesOnItemRev(tag_t* rev,char* mod_desc)
{
	int status;

	printf("\nIn function setAttributesOnItemRev\n");
	//ITK_CALL(AOM_lock(*rev));
	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",mod_desc));
	ITK_CALL(AOM_save(*rev));
	//ITK_CALL(AOM_unlock(*rev));
}

int setAttributesOnDesignRev(tag_t* rev,char* parttype,char* projectcode,char* designgroup,char* mod_desc,char* DrawingNoS,char* DrawingIndS,char* Materialclass,char* MaterialInDrwS,char* MaterialThickNessS,char* DeignOwnUnitS,char* ModelIndS,char* ColourIndS,char* WeightS,char* desc,char* t5SpareIndS)
{
	int status;
	double dweight=0;
	tag_t projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char* username=NULL;

	printf("\n  In setAttributesOnDesignRev Function\n");fflush(stdout);
	/*
	printf("\n\t designgroup:%s",designgroup);fflush(stdout);
	printf("\n\t mod_desc:%s",mod_desc);fflush(stdout);
	printf("\n\t DrawingNoS:%s",DrawingNoS);fflush(stdout);
	printf("\n\t DrawingIndS:%s",DrawingIndS);fflush(stdout);
	printf("\n\t MaterialInDrwS:%s",MaterialInDrwS);fflush(stdout);
	printf("\n\t DeignOwnUnitS:%s",DeignOwnUnitS);fflush(stdout);
	printf("\n\t ColourIndS:%s",ColourIndS);fflush(stdout);
	printf("\n\t WeightS:%s\n",WeightS);fflush(stdout);
	*/

	AOM_lock(*rev);

	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType",parttype));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ProjectCode",projectcode));

	/*ITK_CALL (PROJ_find(projectcode,&projobj));
	if(projobj !=NULLTAG)
	{
		POM_get_user(&username,&user_tag);
		printf("\n  Login username:%s\n",username);fflush(stdout);
		ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,rev ));
		printf("\n  Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n  Project not found\n");fflush(stdout);
	}*/


	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",desc));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DesignGrp",designgroup));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS));

	//ITK_CALL ( AOM_set_value_string(*rev,"t5_MatlClass",Materialclass));

	ITK_CALL ( AOM_set_value_string(*rev,"t5_Material",MaterialInDrwS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_MThickness",MaterialThickNessS));
	if(DeignOwnUnitS!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS));
	}
	else
	{
		;
	}

	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS));

	if(WeightS!=NULL)
	{
		dweight=atof(WeightS);
	}

	ITK_CALL ( AOM_set_value_double(*rev,"t5_Weight",dweight));
	ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",t5SpareIndS));

	ITK_CALL(AOM_save(*rev));
	ITK_CALL(AOM_unlock(*rev));
}


int setAttributesOnDesign(tag_t* item,char * desc,char* UnitOfMeasureS,char* LeftRhS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	ITK_CALL(AOM_lock(*item));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {strcpy(ent_uom,"-");}

	//ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	//ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
	//ITK_CALL ( AOM_set_value_string(*item,"t5_LeftRh",LeftRhS));
//	ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
//
//	printf("\n\n ent_uom:%s  \n",ent_uom);fflush(stdout);
//
//	ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
	ITK_CALL ( AOM_set_value_string(*item,"t5_LeftRh",LeftRhS));


	ITK_CALL ( AOM_set_value_string(*item,"object_desc",desc));
		ITK_CALL(AOM_save(*item));
		ITK_CALL(AOM_unlock(*item));

	//ITK_CALL ( AOM_set_value_string(*item,"uom_tag",UnitOfMeasureS));

}


int setLifeCycle(tag_t* itemRev,char* lifeCycleS)
{
		int status;
		tag_t   status2=NULLTAG;
		logical retain=false;
		char* lcsToset=NULL;

		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCWORKING);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,APLWORKING);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,APLRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,STDWORKING);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
			printf("\n This is std rel...");
			strcpy(lcsToset,STDRELEASED);
		}

		ITK_CALL(CR_create_release_status(lcsToset,&status2));
		ITK_CALL(EPM_add_release_status(status2,1,itemRev,retain));

		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
}

int convertDate(char* date,char* rDate)
{
	int status;

}

int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;


	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,date,&eff_t));
			ITK_CALL(AOM_save(status_list[0]));
			ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}
}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int org_seq_id_int=0;
	int lat_seq_id_int=0;
	int j=0;
	int i=0;
	int n_strings = 1;
	int l_strings = 80;			// Arbitrary values - Please verify proper lengths for your application!
	int tempStrLength = 80;
	int index;
	int si=0;

	logical isCheckOut=false;
	FILE* fp=NULL;

	char* inputfile=NULL;
	char* inputline=NULL;
	char* level=NULL;
	char* item_id=NULL;
	char* item_name=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* desc=NULL;
	char* qty=NULL;
	//char* dtype=NULL;
	char* atype="L";
	//char* unit_of_measure="-";

	char* ModDescriptionDupS=NULL;
	char* mod_desc=NULL;
	char* DrawingNoDupS=NULL;
	char* Materialclass=NULL;
	char* DrawingIndDupS=NULL;
	char* DrawingIndS=NULL;
	char* MaterialDupS=NULL;
	char* MaterialS=NULL;
	char* MaterialInDrwDupS=NULL;
	char* MaterialInDrwS=NULL;
	char* LeftRhDupS=NULL;
	char* LeftRhS=NULL;
	char* DeignOwnUnitDupS=NULL;
	char* DeignOwnUnitS=NULL;
	char* ModelIndDupS=NULL;
	char* ModelIndS=NULL;
	char* UnitOfMeasureDupS=NULL;
	char* UnitOfMeasureS=NULL;
	char* ColourIndDupS=NULL;
	char* ColourIndS=NULL;
	char* WeightDupS=NULL;
	char* WeightS=NULL;
	char* t5SpareIndS=NULL;
	char* MaterialThickNessS=NULL;
	char* DrawingNoS=NULL;
	char* parttype=NULL;
	char* projectcode=NULL;
	char* designgroup=NULL;
	char* rel_list=NULL;
	char* lifecycleS=NULL;

	char**	stringArray = NULL;

	tag_t newItemTag=NULLTAG;
	tag_t itemRevCreInTag=NULLTAG;
	tag_t itemRevTypeTag=NULLTAG;
	tag_t item=NULLTAG;
	tag_t itemOrg=NULLTAG;
	tag_t revOrg=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t *tags_found = NULL;

	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	 int stat_count=0;
	 int stat_count2=0;
	 tag_t relPropTag=NULLTAG ;
	 tag_t relPropTag2=NULLTAG ;
	 tag_t status2=NULLTAG ;
	 tag_t reln_type=NULLTAG ;
	 tag_t reln_type2=NULLTAG ;
	 tag_t *secondary_objects=NULLTAG ;
	 tag_t *secondary_objects2=NULLTAG ;
	 tag_t *status1=NULL;
	 tag_t  attr_name_id   = NULLTAG;
	 tag_t  primary=NULLTAG,objTypeTag=NULLTAG;
	 tag_t  primary2=NULLTAG,objTypeTag2=NULLTAG;
     char   *value         = NULL;
     char   *eff_date         = NULL;
	 tag_t class_id = NULLTAG;
	 char szClassName[100 + 1] = "";
     logical is_it_empty = FALSE;
     logical is_it_null  = FALSE;
     logical is_loaded   = FALSE;
	 char   type_name[100+1];
	 char   type_name2[100+1];
	 int release_status   = 0;
	 FILE* fperror=NULL;

	char *szbom_revision_status = NULL;
	tag_t   window, window2, rule, item_tag = null_tag, top_line;

	inputfile = ITK_ask_cli_argument("-i=");

	if( ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);

	//printf("\n Item:[%s]\nRev:[%s]\nSeq[%s]",req_item,req_rev,req_seq);fflush(stdout);

    //ITK_CALL(ITEM_find_item(req_item, &item ));
	printf("\n----------------------------------------------------\n");

	fp=fopen(inputfile,"r");
	fperror=fopen("error.log","a");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,5000,fp)!=NULL)
		{
			fputs(inputline,stdout);

			//level=strtok(inputline,"^");
			//item_id=strtok(NULL,"^");
			item_id=strtok(inputline,"^");
			item_revision_id=strtok(NULL,"^");
			item_sequence_id=strtok(NULL,"^");
			desc=strtok(NULL,"^");
			/*qty=strtok(NULL,"^");
			dtype=strtok(NULL,"^");
			atype=strtok(NULL,"^"); */
			parttype=strtok(NULL,"^");
			projectcode=strtok(NULL,"^");
			designgroup=strtok(NULL,"^");
			mod_desc=strtok(NULL,"^");
			DrawingNoS=strtok(NULL,"^");
			DrawingIndS=strtok(NULL,"^");
			Materialclass=strtok(NULL,"^");
			MaterialInDrwS=strtok(NULL,"^");
			MaterialThickNessS=strtok(NULL,"^");
			LeftRhS=strtok(NULL,"^");
			DeignOwnUnitS=strtok(NULL,"^");
			ModelIndS=strtok(NULL,"^");
			UnitOfMeasureS=strtok(NULL,"^");
			ColourIndS=strtok(NULL,"^");
			lifecycleS=strtok(NULL,"^");
			eff_date=strtok(NULL,"^");
			WeightS=strtok(NULL,"^");
			t5SpareIndS=strtok(NULL,"^");

			printf("\n  item_id:%s",item_id);fflush(stdout);
			printf("\n  item_revision_id:%s",item_revision_id);fflush(stdout);
			printf("\n  item_sequence_id:%s",item_sequence_id);fflush(stdout);
			printf("\n  desc:%s",desc);fflush(stdout);
			printf("\n  parttype:%s",parttype);fflush(stdout);
			printf("\n  projectcode:%s",projectcode);fflush(stdout);
			printf("\n  designgroup:%s",designgroup);fflush(stdout);
			printf("\n  mod_desc:%s",mod_desc);fflush(stdout);
			printf("\n  DrawingNoS:%s",DrawingNoS);fflush(stdout);
			printf("\n  DrawingIndS:%s",DrawingIndS);fflush(stdout);
			printf("\n  Materialclass:%s",Materialclass);fflush(stdout);
			printf("\n  MaterialInDrwS:%s",MaterialInDrwS);fflush(stdout);
			printf("\n  MaterialThickNessS:%s",MaterialThickNessS);fflush(stdout);
			printf("\n  LeftRhS:%s",LeftRhS);fflush(stdout);
			printf("\n  DeignOwnUnitS:%s",DeignOwnUnitS);fflush(stdout);
			printf("\n  ModelIndS:%s",ModelIndS);fflush(stdout);
			printf("\n  UnitOfMeasureS:%s",UnitOfMeasureS);fflush(stdout);
			printf("\n  ColourIndS:%s",ColourIndS);fflush(stdout);
			printf("\n  lifecycleS:%s",lifecycleS);fflush(stdout);
			printf("\n  eff_date:%s",eff_date);fflush(stdout);
			printf("\n  WeightS:%s",WeightS);fflush(stdout);
			printf("\n  t5SpareIndS:%s\n",t5SpareIndS);fflush(stdout);

			//printf("\nL:[%s],I:[%s],R:[%s],S:[%s],D:[%s],Q:[%s],DType:[%s],AType:[%s]\n",level,item_id,item_revision_id,item_sequence_id,desc,qty,dtype,atype); fflush(stdout);

			attrs[0] ="item_id";
			values[0] = (char *)item_id;
			//Querying with item id
			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

			if(n_tags_found==0)
			{
				//Keep item id and item name same
				if(strstr(atype,"N")!=NULL)
				{
					printf("Creating new Spec\n"); fflush(stdout);
					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_WeldSpot",default_empty_to_A(item_revision_id),&item,&rev));
					//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq","1"));
					//setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,desc,t5SpareIndS);
					//setAttributesOnDesign(&item,UnitOfMeasureS,LeftRhS);

				}
				else if (strstr(atype,"D")!=NULL)
				{
					printf("1..Creating new Dummy Part\n"); fflush(stdout);
					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_DummyPart",default_empty_to_A(item_revision_id),&item,&rev));
					 setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
					//setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					setLifeCycle(&rev,lifecycleS);
					if(strcmp(eff_date,"NONE to NONE")!=0)
					{
						setEffectivity(&rev,eff_date);
					}
				}
				else
				{
					printf("1..Creating new Item\n"); fflush(stdout);
					rev = NULLTAG;
					ITK_CALL(ITEM_create_item(item_id,item_id,"Design",default_empty_to_A(item_revision_id),&itemOrg,&rev));

					setAttributesOnItemRev(&itemOrg,desc);
					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					ITK_CALL(AOM_save(itemOrg));
					ITK_CALL(AOM_unlock(itemOrg));

					//ITK_CALL(ITEM_find_revision(itemOrg,item_revision_id,&rev));
					if(rev != NULLTAG)
					{
						ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
						printf("1..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
						printf("1..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

						if(atoi(item_sequence_id) == 1)
						{
					      setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
					      //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
						}

						if(atoi(item_sequence_id)<=(org_seq_id_int))
						{
							printf("1..No need to check-in check out\n"); fflush(stdout);
						}
						else
						{
							for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
							{
								//printf("1..***si::[%d]\n",si);
								ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
								if(isCheckOut)
								{
									printf("1..This is  check out....\n");
					                setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
					                //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
				 					//ITK_CALL(AOM_save(rev));
									//ITK_CALL(AOM_unlock(rev));

									if(RES_checkin(rev)!=ITK_ok)
									{
										fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
								}
								else
								{
									printf("1..This is not check out....\n"); fflush(stdout);

									ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
									printf("\nLatest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

									if (lat_seq_id_int == atoi(item_sequence_id))
									{
										printf("1..*****lat_seq_id_int is matched\n"); fflush(stdout);
										break;
									}
									else
									{
										if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
										{
											printf("1..RES_checkout failed.\n"); fflush(stdout);
											fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("1..RES_checkout is successful\n"); fflush(stdout);
										}
										//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
				                    	 setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
					                    //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
										//ITK_CALL(AOM_save(rev));
										//ITK_CALL(AOM_unlock(rev));

										if(RES_checkin(rev)!=ITK_ok)
										{
											printf("1..RES_checkin failed.\n"); fflush(stdout);
											fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("1..RES_checkin is successful\n"); fflush(stdout);
										}
									}
								}

								//ITK_CALL( AOM_save(rev));
								//ITK_CALL( AOM_unlock(rev));
								printf("1..Check-in Check out success\n"); fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n1..Revision tag not found....\n"); fflush(stdout);
					}
					//setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,desc,t5SpareIndS);
					////setAttributesOnDesign(&item,UnitOfMeasureS,LeftRhS);
					////setLifeCycle(&rev,lifecycleS);
					//if(strcmp(eff_date,"NONE to NONE")!=0)
					//{
						////setEffectivity(&rev,eff_date);
					//}
				}
				////ITK_CALL(ITEM_set_unit_of_measure(item,unit_of_measure));
				//ITK_CALL(ITEM_set_unit_of_measure(item,UnitOfMeasureS));
				//ITK_CALL(ITEM_set_rev_description(rev,desc));
				//ITK_CALL(AOM_lock(item));
				//ITK_CALL(AOM_lock(rev));
				//setAttributesOnItemRev(&itemOrg,desc);
				//setAttributesOnItemRev(&rev,desc);
				//ITK_CALL(AOM_save(itemOrg));
				//ITK_CALL(AOM_unlock(itemOrg));
				//ITK_CALL(AOM_save(rev));
				//ITK_CALL(AOM_unlock(rev));
			}
			else
			{
				item = tags_found[0];
				printf("2..Item already exists\n"); fflush(stdout);
				ITK_CALL(ITEM_find_revision(item,item_revision_id,&rev));
				if(rev != NULLTAG)
				{
					ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
					printf("2..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
					printf("2..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

					if(atoi(item_sequence_id) == 1)
					{
					       setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
		                  // setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					}

					if(atoi(item_sequence_id)<=(org_seq_id_int))
					{
						printf("2..No need to check-in check out\n"); fflush(stdout);
					}
					else
					{
						for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
						{
							printf("2..***si::[%d]\n",si);
							ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
							if(isCheckOut)
							{
								printf("2..This is  check out....\n ");
					            setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
		                        //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
								//ITK_CALL(AOM_save(rev));
								//ITK_CALL(AOM_unlock(rev));
								if(RES_checkin(rev)!=ITK_ok)
								{
									fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
								}
							}
							else
							{
								printf("2..This is not check out....\n"); fflush(stdout);

								ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
								printf("2..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

								if (lat_seq_id_int == atoi(item_sequence_id))
								{
									printf("2..*****lat_seq_id_int is matched\n"); fflush(stdout);
									break;
								}
								else
								{
									if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
									{
										printf("2..RES_checkout failed.\n"); fflush(stdout);
										fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
									else
									{
										printf("2..RES_checkout is successful\n"); fflush(stdout);
									}
									//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
					                setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
		                            //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
									//ITK_CALL(AOM_save(rev));
									//ITK_CALL(AOM_unlock(rev));
									if(RES_checkin(rev)!=ITK_ok)
									{
										printf("2..RES_checkin failed.\n"); fflush(stdout);
										fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
									else
									{
										printf("2..RES_checkin is successful\n"); fflush(stdout);
									}
								}
							}

							//ITK_CALL ( AOM_save(rev));
							//ITK_CALL ( AOM_unlock(rev));
							printf("2..Check-in Check out success\n"); fflush(stdout);

							/*if (si > 5)
							{
								printf("\n...................si::[%d]",si);
								break;
							}*/
						}
					}
				}
				else
				{
					printf("3..Item Revision not found\n");
					ITK_CALL(ITEM_create_rev(item,default_empty_to_A(item_revision_id),&rev));
					//ITK_CALL(AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
	                setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
                     //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					//ITK_CALL(AOM_save(rev));
					//ITK_CALL(AOM_unlock(rev));

					if(rev != NULLTAG)
					{
						ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
						printf("3..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
						printf("3..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

						if(atoi(item_sequence_id) == 1)
						{
					         setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
                           //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
						}

						if(atoi(item_sequence_id)<=(org_seq_id_int))
						{
							printf("3..No need to check-in check out\n"); fflush(stdout);
						}
						else
						{
							for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
							{
								//printf("3..***si::[%d]\n",si);
								ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
								if(isCheckOut)
								{
									printf("3..This is  check out....\n ");
					                setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
                                    //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
									//ITK_CALL(AOM_save(rev));
									//ITK_CALL(AOM_unlock(rev));

									if(RES_checkin(rev)!=ITK_ok)
									{
										fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
								}
								else
								{
									printf("3..This is not check out....\n"); fflush(stdout);

									ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
									printf("3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

									if (lat_seq_id_int == atoi(item_sequence_id))
									{
										printf("3..*****lat_seq_id_int is matched\n"); fflush(stdout);
										break;
									}
									else
									{
										if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
										{
											printf("3..RES_checkout failed.\n"); fflush(stdout);
											fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("3..RES_checkout is successful\n"); fflush(stdout);
										}
										//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
					                    setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS);
                                        //setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
										//ITK_CALL(AOM_save(rev));
										//ITK_CALL(AOM_unlock(rev));

										if(RES_checkin(rev)!=ITK_ok)
										{
											printf("3..RES_checkin failed.\n"); fflush(stdout);
											fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("3..RES_checkin is successful\n"); fflush(stdout);
										}
									}
								}

								//ITK_CALL ( AOM_save(rev));
								//ITK_CALL ( AOM_unlock(rev));
								printf("3..Check-in Check out success\n"); fflush(stdout);
							}
						}
					}
					printf("3..Item Revision Created\n");
				}
			}
			printf("----------------------------------------------------\n");
		}
	}
	ITK_CALL(POM_logout(false));
	if(fperror)fclose(fperror);fperror=NULL;
	return status;
}
