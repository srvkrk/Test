/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Raghavendra B T
*  Module		 :   TCUA Desing Rev Uploader
*  Code			 :   createRevForProe.c
*  Created on	 :   March 25, 2015
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCWORKING	"T5_LcsReview"
#define ERCREVIEW	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"



#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,
                                    &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}

int setAttributesOnDesignRev(tag_t* rev,char* projectcode,char *desc,char* designgroup,int sequence_id,char* mod_desc,char* DrawingNoS,char* DrawingIndS,char* Materialclass,char* MaterialInDrwS,char* MaterialThickNessS,char* DeignOwnUnitS,char* ModelIndS,char* ColourIndS,char* WeightS,char* atype,char * t5SpareIndS,char * t5SpareCriteriaS,char * t5ReliabilityS,char * t5RefPartNumberS,char * t5RecyclabilityS,char * t5RecoverableS,char * t5PunMakeBuyIndS,char * t5PunIntialAgS,char * t5PrtCatCodeS,char * t5ProductS,char * t5PkgStdS,char * t5PartStatusS,char * t5PartPropertyS,char * t5PartCodeS,char * t5NcPartNoS,char * t5ListRecSparess,char * t5HomologationReqdS,char * t5HazardousContS,char * t5EnvelopeDimenS,char * t5DismantableS,char * t5ConfigIDS,char * t5ColourIDS,char * t5ClassificationHazS,char * t5CMVRCertificationS,char * t5SurfPrtStdS,char * t5SamplesToApprS,char * t5AsmDisposalS,char * t5FinDisposalInstrS,char * t5RPDisposalInstrS,char * t5SPDisposalInstrS,char * t5WIPDisposalInstrS,char * t5LastModByS,char * t5VerCreatorS,char * t5CAEDocES,char * t5CoatedS,char * t5ConvDocS,char * t5AplCopyOfErcRevS,char * t5AppCodeS,char * t5RqstNumS,char * t5RsnCodeS,char * t5SurfaceAreaS,char * t5VolumeS,char * t5CarIntialAgencyS,char * t5CarMakeBuyIndiS,char * t5ErcIndNameS,char * t5PostRelReqS,char * t5ItmCategoryS,char * t5CopReqS,char * t5AplInvalidateS,char * t5PrtValiStatusS,char * t5DRSubStateS,char * t5KnxtDocIndS,char * t5SimValS,char * t5PerYieldS,char * t5PunStoreLocationS,char * t5AltPartNoS,char * t5RolledupWtS,char * t5PFDModReqdS,char * t5ToolIndentReqdS,char * CategoryNameS,char * t5DsgnDeptS,char * t5AplCopyOfErcSeqS)
{

	int status;
	double dweight=0;
	tag_t projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char* username=NULL;

	//ITK_CALL ( AOM_set_value_string(*rev,"t5_ProjectCode",projectcode));

//	ITK_CALL (PROJ_find(projectcode,&projobj));
//	if(projobj !=NULLTAG)
//	{
//		POM_get_user(&username,&user_tag);
//		ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
//		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,rev ));
//		printf("\nAssigned to Project\n");fflush(stdout);
//	}
//	else
//	{
//		printf("\nProject not found\n");fflush(stdout);
//	}

printf("\n keyword Desc ---->%s\n",CategoryNameS);fflush(stdout);
printf("\n Party Part Number ---->%s\n",t5RefPartNumberS);fflush(stdout);


ITK_CALL(AOM_lock(*rev));

//	ITK_CALL ( AOM_set_value_int(*rev,"sequence_id",sequence_id));     // For direct creation of sequecne
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DesignGrp",designgroup));
	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",desc));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS));
	// Added by Raghavendra B T for more attributes

	ITK_CALL ( AOM_set_value_string(*rev,"t5_RefPartNumber",t5RefPartNumberS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS));//Change PNR make buy
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunIntialAgency",t5PunIntialAgS));//change PNR Initial Agency
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_Product",t5ProductS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PkgStd",t5PkgStdS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS));//Create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartProperty",t5PartPropertyS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_NcPartNo",t5NcPartNoS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_HomologationReqd",t5HomologationReqdS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_EnvelopeDimensions",t5EnvelopeDimenS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ConfigID",t5ConfigIDS));//change its name right now it is ConfigID
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SurfPrtStd",t5SurfPrtStdS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AsmDisposalInstr",t5AsmDisposalS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_FinDisposalInstr",t5FinDisposalInstrS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RPDisposalInstr",t5RPDisposalInstrS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SPDisposalInstr",t5SPDisposalInstrS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_WIPDisposalInstr",t5WIPDisposalInstrS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_VerCreator",t5VerCreatorS));//Create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_Coated",t5CoatedS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AplCopyOfErcRev",t5AplCopyOfErcRevS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AppCode",t5AppCodeS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RqstNum",t5RqstNumS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RsnCode",t5RsnCodeS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_CarIntialAgency",t5CarIntialAgencyS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_CarMakeBuyIndicator",t5CarMakeBuyIndiS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ErcIndName",t5ErcIndNameS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ItmCategory",t5ItmCategoryS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AplInvalidate",t5AplInvalidateS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PrtValiStatus",t5PrtValiStatusS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DRSubState",t5DRSubStateS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_KnxtDocInd",t5KnxtDocIndS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_SimVal",t5SimValS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PerYield",t5PerYieldS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunStoreLocation",t5PunStoreLocationS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_AltPartNo",t5AltPartNoS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_RolledupWt",t5RolledupWtS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_EstSheetReqd",t5RolledupWtS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PFDModReqd",t5PFDModReqdS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ToolIndentReqd",t5ToolIndentReqdS));//create it
	ITK_CALL ( AOM_set_value_string(*rev,"t5_CategoryName",CategoryNameS));//create it

	// Need to check for Properties in BMIDE

	//ITK_CALL ( AOM_set_value_string(*rev,"t5_SamplesToAppr",t5SamplesToApprS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_last_mod_user",t5LastModByS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_SpareInd",t5SpareIndS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_SpareCriteria",t5SpareCriteriaS)); // Create it
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_Reliability",t5ReliabilityS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_Recyclability",t5RecyclabilityS));
    //ITK_CALL ( AOM_set_value_string(*rev,"t5_Recoverable",t5RecoverableS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_ListRecSpares",t5ListRecSparess));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_HazardousContents",t5HazardousContS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_Dismantable",t5DismantableS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_CAEDocE",t5CAEDocES));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_ConvDoc",t5ConvDocS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_SurfaceArea",t5SurfaceAreaS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_Volume",t5VolumeS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_PostRelReq",t5PostRelReqS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_CopReq",t5CopReqS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_ClassificationHazardous",t5ClassificationHazS));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_CMVRCertificationReqd",t5CMVRCertificationS));

	// Ended by Raghavendra B T for more attributes

	if (strstr(atype,"D")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd","D"));
	}
	if (strstr(atype,"A")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd","A"));
	}
	if (strstr(atype,"C")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd","C"));
	}
	if (strstr(atype,"VC")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd","VC"));
	}
	if (strstr(atype,"V")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd","V"));
	}
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_MatlClass",Materialclass));

	ITK_CALL ( AOM_set_value_string(*rev,"t5_Material",MaterialInDrwS));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_MThickness",MaterialThickNessS));
	if(DeignOwnUnitS!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS));
	}else
	{

	}

	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS));

	printf("\n In function Weight is --->%s\n",WeightS);

	if(WeightS!=NULL){
	dweight=atof(WeightS);
	}

	printf("\n In function dweight is --->%f\n",dweight);

	ITK_CALL ( AOM_set_value_double(*rev,"t5_Weight",dweight));

			ITK_CALL(AOM_save(*rev));
		ITK_CALL(AOM_unlock(*rev));


}


int setAttributesOnDesign(tag_t* item,char * desc,char* UnitOfMeasureS,char* LeftRhS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	ITK_CALL(AOM_lock(*item));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {strcpy(ent_uom,"-");}

	//ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	//ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
	//ITK_CALL ( AOM_set_value_string(*item,"t5_LeftRh",LeftRhS));


	ITK_CALL ( AOM_set_value_string(*item,"object_desc",desc));
		ITK_CALL(AOM_save(*item));
		ITK_CALL(AOM_unlock(*item));

	//ITK_CALL ( AOM_set_value_string(*item,"uom_tag",UnitOfMeasureS));

}

int setLifeCycle(tag_t* itemRev,char* lifeCycleS)
{
		int status;
		tag_t   status2=NULLTAG;
		logical retain=false;
		char* lcsToset=NULL;

		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCWORKING);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,APLWORKING);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,APLRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,STDWORKING);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
			printf("\n This is std rel...");
			strcpy(lcsToset,STDRELEASED);
		}

		ITK_CALL(CR_create_release_status(lcsToset,&status2));
		ITK_CALL(EPM_add_release_status(status2,1,itemRev,retain));

		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
}

int convertDate(char* date,char* rDate)
{
	int status;

}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		Monthas;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char*	strDay;
	char*	strMon;
	char*	strYear;
	char	DateS[20];
	char* cMonth ;
	char CCMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
//	timeptr = (struct tm *)localtime(&temp);
//	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

//	day=timeptr->tm_mday;
//	month=(timeptr->tm_mon)+1;
//	year=(timeptr->tm_year+1900);

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear);
	printf("\n CCMonth:%s\n",CCMonth);
	printf("\n strDay:%s\n",strDay);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;


	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,date,&eff_t));
			ITK_CALL(AOM_save(status_list[0]));
			ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}

}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{

		 tag_t   release_status =NULLTAG;
	     char   *ReleaseStatus=NULL;
         logical  retain_released_date =false;
	     logical  is_v7  ;
		 char FrmNextDate[20]={0};
		 char ToNextDate[20]={0};
		 date_t test_date_1;
		 date_t DayTommorow ;
		 date_t test_date_2;
		 date_t *start_end_date = NULL;
		 tag_t eff_d = NULLTAG;
     	 int		ifail	=0;
		 char* lcsToset=NULL;
		tag_t class_id=NULLTAG;
		char* class_name=NULL;

		 int	   status_count=0;
	 	 int	   ss=0;
	 	 int	   StatusFlg=0;
		 tag_t* status_list = NULLTAG;

		 int status;

		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCWORKING);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
			printf("\n This is std rel...");
			strcpy(lcsToset,ERCRELEASED);
		}


		if((strcmp(lcsToset,"T5_LcsErcRlzd")==0))
		{

		 if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
			{
			   return ifail;
			}
			printf("\n REV status_count: %d\n",status_count);fflush(stdout);
			if (status_count == 0)  /* No Status, so the Item is not yet Released */
			{
				printf("\n No Status, so the Item is not yet Released \n");

			}else{

				for(ss=0; ss<status_count ; ss++){
    			ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
                printf("\n class_name: %s\n",class_name);fflush(stdout);
                if(strcmp(class_name,lcsToset)==0)
					{
				       StatusFlg ++;
					}

				}
			}


		printf("\n StatusFlg: [%d]\n",StatusFlg);fflush(stdout);

        if(StatusFlg != 0)
	     return 0;

		 printf("\n FromDate..[%s]\n",FromDate);
		 printf("\n ToDate..[%s]\n",ToDate);
		 if((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0))
			 return 0;

		printf("\n *********Stamping Releasing item*******......\n");
		if(ITK_ok != (ifail = CR_create_release_status(lcsToset,&release_status)))	 return ifail;


		if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
		printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);

		printf("\n release_status \n");

		if(ITK_ok != (ifail = EPM_add_release_status(release_status,1,&itemrev,retain_released_date)))return ifail;

		printf("\n 111release_status \n");


			if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&is_v7)))	 return ifail;
			printf("\n is_v7:%d\n",is_v7);
			if(is_v7 != true)
			{
				printf("\n is_v7 is not true .....\n");
			}
			else
			{
				printf("\n is_v7 is  true .....\n");
			}

			getNextDate(FromDate,FrmNextDate);
			getNextDate(ToDate,ToNextDate);
			printf("\n FrmNextDate:%s",FrmNextDate);
			printf("\n ToNextDate:%s",ToNextDate);
			//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

			if(ITK_ok != (ifail = ITK_string_to_date(FrmNextDate, &test_date_1 )))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
			{
				return ifail;
			}
			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);


			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save(eff_d)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save(release_status)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
			{
				return ifail;
			}
			printf("\n effectivity done-------------:%s",FrmNextDate);

		}
  return status;
}


extern int ITK_user_main (int argc, char ** argv )
{

    int status;
	int org_seq_id_int=0;
	int j=0;
	int i=0;
	int		n_strings = 1;
	int		l_strings = 80;			// Arbitrary values - Please verify proper lengths for your application!
	int		tempStrLength = 80;
	int index;
	int item_revision_id_int;
	int si;
	int lat_seq_id_int;
	int lat_seq_id_int_1;
	logical isCheckOut=false;
	FILE* fp=NULL;

	char* inputline=NULL;
	char* level=NULL;
	char* item_id=NULL;
	char* item_name=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* desc=NULL;
	char* qty=NULL;
	char* dtype=NULL;
	char* atype="L";
	char *unit_of_measure="-";

	char* ModDescriptionDupS=NULL;
	char* mod_desc=NULL;
	char* DrawingNoDupS=NULL;
	char* Materialclass=NULL;
	char* DrawingIndDupS=NULL;
	char* DrawingIndS=NULL;
	char* MaterialDupS=NULL;
	char* MaterialS=NULL;
	char* MaterialInDrwDupS=NULL;
	char* MaterialInDrwS=NULL;
	char* LeftRhDupS=NULL;
	char* LeftRhS=NULL;
	char* DeignOwnUnitDupS=NULL;
	char* DeignOwnUnitS=NULL;
	char* ModelIndDupS=NULL;
	char* ModelIndS=NULL;
	char* UnitOfMeasureDupS=NULL;
	char* UnitOfMeasureS=NULL;
	char* ColourIndDupS=NULL;
	char* ColourIndS=NULL;
	char* WeightDupS=NULL;
	char* WeightS=NULL;
	char* MaterialThickNessS=NULL;
	char* DrawingNoS=NULL;
	char* projectcode=NULL;
	char* designgroup=NULL;
	char * rel_list=NULL;
	char * lifecycleS=NULL;

	// Added By Raghavendra B T

	char * t5SpareIndS=NULL;
	char * t5SpareCriteriaS=NULL;
	char * t5ReliabilityS=NULL;
	char * t5RefPartNumberS=NULL;
	char * t5RecyclabilityS=NULL;
	char * t5RecoverableS=NULL;
	char * t5PunMakeBuyIndS=NULL;
	char * t5PunIntialAgS=NULL;
	char * t5PrtCatCodeS=NULL;
	char * t5ProductS=NULL;
	char * t5PkgStdS=NULL;
	char * t5PartStatusS=NULL;
	char * t5PartPropertyS=NULL;
	char * t5PartCodeS=NULL;
	char * t5NcPartNoS=NULL;
	char * t5ListRecSparess=NULL;
	char * t5HomologationReqdS=NULL;
	char * t5HazardousContS=NULL;
	char * t5EnvelopeDimenS=NULL;
	char * t5DismantableS=NULL;
	char * t5ConfigIDS=NULL;
	char * t5ColourIDS=NULL;
	char * t5ClassificationHazS=NULL;
	char * t5CMVRCertificationS=NULL;
	char * t5SurfPrtStdS=NULL;
	char * t5SamplesToApprS=NULL;
	char * t5AsmDisposalS=NULL;
	char * t5FinDisposalInstrS=NULL;
	char * t5RPDisposalInstrS=NULL;
	char * t5SPDisposalInstrS=NULL;
	char * t5WIPDisposalInstrS=NULL;
	char * t5LastModByS=NULL;
	char * t5VerCreatorS=NULL;
	char * t5CAEDocES=NULL;
	char * t5CoatedS=NULL;
	char * t5ConvDocS=NULL;
	char * t5AplCopyOfErcRevS=NULL;
	char * t5AppCodeS=NULL;
	char * t5RqstNumS=NULL;
	char * t5RsnCodeS=NULL;
	char * t5SurfaceAreaS=NULL;
	char * t5VolumeS=NULL;
	char * t5CarIntialAgencyS=NULL;
	char * t5CarMakeBuyIndiS=NULL;
	char * t5ErcIndNameS=NULL;
	char * t5PostRelReqS=NULL;
	char * t5ItmCategoryS=NULL;
	char * t5CopReqS=NULL;
	char * t5AplInvalidateS=NULL;
	char * t5PrtValiStatusS=NULL;
	char * t5DRSubStateS=NULL;
	char * t5KnxtDocIndS=NULL;
	char * t5SimValS=NULL;
	char * t5PerYieldS=NULL;
	char * t5PunStoreLocationS=NULL;
	char * t5AltPartNoS=NULL;
	char * t5RolledupWtS=NULL;
	char * t5PFDModReqdS=NULL;
	char * t5ToolIndentReqdS=NULL;
	char * CategoryNameS=NULL;
	char * t5DsgnDeptS=NULL;
	char * t5AplCopyOfErcSeqS=NULL;
	char *FromDate;
	char *ToDate;

	// Ended By Raghavendra B T

	char**	stringArray = NULL;
	tag_t newItemTag=NULLTAG;
	tag_t itemRevCreInTag=NULLTAG;
	tag_t itemRevTypeTag=NULLTAG;
	tag_t item=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t *tags_found = NULL;
	char *inputfile=NULL;
	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	 int stat_count=0;
	 int stat_count2=0;
	 tag_t relPropTag=NULLTAG ;
	 tag_t relPropTag2=NULLTAG ;
	 tag_t status2=NULLTAG ;
	 tag_t reln_type=NULLTAG ;
	 tag_t reln_type2=NULLTAG ;
	 tag_t *secondary_objects=NULLTAG ;
	 tag_t *secondary_objects2=NULLTAG ;
	 tag_t *status1=NULL;
	 tag_t  attr_name_id   = NULLTAG;
	 tag_t  primary=NULLTAG,objTypeTag=NULLTAG;
	 tag_t  primary2=NULLTAG,objTypeTag2=NULLTAG;
     char   *value         = NULL;
     char   *eff_date         = NULL;
	 tag_t class_id = NULLTAG;
	 char szClassName[100 + 1] = "";
     logical is_it_empty = FALSE;
     logical is_it_null  = FALSE;
     logical is_loaded   = FALSE;
	 char   type_name[100+1];
	 char   type_name2[100+1];
	 int release_status   = 0;
	 FILE* fperror=NULL;

	char *szbom_revision_status = NULL;
	tag_t   window, window2, rule, item_tag = null_tag, top_line;

	inputfile = ITK_ask_cli_argument("-i=");

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);

	//printf("\n Item:[%s]\nRev:[%s]\nSeq[%s]",req_item,req_rev,req_seq);fflush(stdout);

    //ITK_CALL(ITEM_find_item(req_item, &item ));

	fp=fopen(inputfile,"r");
	fperror=fopen("error.log","a");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,500,fp)!=NULL)
		{
			fputs(inputline,stdout);
			level=strtok(inputline,"^");  //1
			item_id=strtok(NULL,"^"); //2
			item_revision_id=strtok(NULL,"^"); //3
			item_sequence_id=strtok(NULL,"^"); //4
			desc=strtok(NULL,"^"); //5
			qty=strtok(NULL,"^"); //6
			dtype=strtok(NULL,"^"); //7
			atype=strtok(NULL,"^"); //8

			projectcode=strtok(NULL,"^"); //9
			designgroup=strtok(NULL,"^"); //10
			mod_desc=strtok(NULL,"^");//11
			DrawingNoS=strtok(NULL,"^");//12
			DrawingIndS=strtok(NULL,"^");//13
			Materialclass=strtok(NULL,"^");//14
			MaterialInDrwS=strtok(NULL,"^");//15
			MaterialThickNessS=strtok(NULL,"^");//16
			LeftRhS=strtok(NULL,"^");//17
			DeignOwnUnitS=strtok(NULL,"^");//18
			ModelIndS=strtok(NULL,"^");//19
			UnitOfMeasureS=strtok(NULL,"^");//20
			ColourIndS=strtok(NULL,"^");//21
			lifecycleS=strtok(NULL,"^");//22
			//eff_date=strtok(NULL,"^");
			WeightS=strtok(NULL,"^");//23
			//Added By Raghavendra B T for more attributes
			t5CMVRCertificationS=strtok(NULL,"^");//24
			t5ClassificationHazS=strtok(NULL,"^");//25
			t5ColourIDS=strtok(NULL,"^");//26
			t5ConfigIDS=strtok(NULL,"^");//27
			t5DismantableS=strtok(NULL,"^");//28
			t5DsgnDeptS=strtok(NULL,"^");//29
			t5EnvelopeDimenS=strtok(NULL,"^");//30
			t5HazardousContS=strtok(NULL,"^");//31
			t5HomologationReqdS=strtok(NULL,"^");//32
			t5ListRecSparess=strtok(NULL,"^");//33
			t5NcPartNoS=strtok(NULL,"^");//34
			t5PartCodeS=strtok(NULL,"^");//35
			t5PartPropertyS=strtok(NULL,"^");//36
			t5PartStatusS=strtok(NULL,"^");//37
			t5PkgStdS=strtok(NULL,"^");//38
			t5ProductS=strtok(NULL,"^");//39
			t5PrtCatCodeS=strtok(NULL,"^");//40
			t5PunIntialAgS=strtok(NULL,"^");//41
			t5PunMakeBuyIndS=strtok(NULL,"^");//42
			t5RecoverableS=strtok(NULL,"^");//43
			t5RecyclabilityS=strtok(NULL,"^");//44
			t5RefPartNumberS=strtok(NULL,"^");//45
			t5ReliabilityS=strtok(NULL,"^");//46
			t5SpareCriteriaS=strtok(NULL,"^");//47
			t5SpareIndS=strtok(NULL,"^");//48
			t5SurfPrtStdS=strtok(NULL,"^");//49
			t5SamplesToApprS=strtok(NULL,"^");//50
			t5AsmDisposalS=strtok(NULL,"^");//51
			t5FinDisposalInstrS=strtok(NULL,"^");//52
			t5RPDisposalInstrS=strtok(NULL,"^");//53
			t5SPDisposalInstrS=strtok(NULL,"^");//54
			t5WIPDisposalInstrS=strtok(NULL,"^");//55
			t5LastModByS=strtok(NULL,"^");//56
			t5VerCreatorS=strtok(NULL,"^");//57
			t5CAEDocES=strtok(NULL,"^");//58
			t5CoatedS=strtok(NULL,"^");//59
			t5ConvDocS=strtok(NULL,"^");//60
			t5AplCopyOfErcRevS=strtok(NULL,"^");//61
			t5AplCopyOfErcSeqS=strtok(NULL,"^");//62
			t5AppCodeS=strtok(NULL,"^");//63
			t5RqstNumS=strtok(NULL,"^");//64
			t5RsnCodeS=strtok(NULL,"^");//65
			t5SurfaceAreaS=strtok(NULL,"^");//66
			t5VolumeS=strtok(NULL,"^");//67
			t5CarIntialAgencyS=strtok(NULL,"^");//68
			t5CarMakeBuyIndiS=strtok(NULL,"^");//69
			t5ErcIndNameS=strtok(NULL,"^");//70
			t5PostRelReqS=strtok(NULL,"^");//71
			t5ItmCategoryS=strtok(NULL,"^");//72
			t5CopReqS=strtok(NULL,"^");//73
			t5AplInvalidateS=strtok(NULL,"^");//74
			t5PrtValiStatusS=strtok(NULL,"^");//75
			t5DRSubStateS=strtok(NULL,"^");//76
			t5KnxtDocIndS=strtok(NULL,"^");//77
			t5SimValS=strtok(NULL,"^");//78
			t5PerYieldS=strtok(NULL,"^");//79
			t5PunStoreLocationS=strtok(NULL,"^");//80
			t5AltPartNoS=strtok(NULL,"^");//81
			t5RolledupWtS=strtok(NULL,"^");//82
			t5PFDModReqdS=strtok(NULL,"^");//83
			t5ToolIndentReqdS=strtok(NULL,"^");//84
			CategoryNameS=strtok(NULL,"^");//85
			FromDate=strtok(NULL,"^");//86
			ToDate=strtok(NULL,"^");//87


			printf("lifecycleS [%s]\n",lifecycleS);
			printf("t5DsgnDeptS [%s]\n",t5DsgnDeptS);
			printf("t5PartCodeS [%s]\n",t5PartCodeS);
			printf("t5VerCreatorS [%s]\n",t5VerCreatorS);
			printf("t5CarIntialAgencyS [%s]\n",t5CarIntialAgencyS);
			printf("t5CarMakeBuyIndiS [%s]\n",t5CarMakeBuyIndiS);
			printf("CategoryNameS [%s]\n",CategoryNameS);
			printf("FromDate [%s]\n",FromDate);
			printf("ToDate [%s]\n",ToDate);
		//Ended By Raghavendra B T for more attributes

			printf("\nL:[%s],I:[%s],R:[%s],S:[%s],D:[%s],Q:[%s],DType:[%s],AType:[%s]\n",level,item_id,item_revision_id,item_sequence_id,desc,qty,dtype,atype);
			item_revision_id_int=atoi(item_sequence_id);
			attrs[0] ="item_id";
			values[0] = (char *)item_id;
			//Querying with item id
			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

			if(n_tags_found==0)
			{
				//Keep item id and item name same
				if(strstr(atype,"N")!=NULL)
				{
					printf("Creating new Spec\n"); fflush(stdout);
					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_WeldSpot",default_empty_to_A(item_revision_id),&item,&rev));
					//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq","1"));
					//setAttributesOnDesignRev(&rev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,desc,SpareInd);
					//setAttributesOnDesign(&item,UnitOfMeasureS,LeftRhS);

				}
				else if (strstr(atype,"D")!=NULL)
				{
					printf("1..Creating new Dummy Part\n"); fflush(stdout);
					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_DummyPart",default_empty_to_A(item_revision_id),&item,&rev));
					setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
					if(strcmp(eff_date,"NONE to NONE")!=0)
					{
						setEffectivity(&rev,eff_date);
					}
				}
				else
				{
					printf("1..Creating new Item\n"); fflush(stdout);
					rev = NULLTAG;

					ITK_CALL(ITEM_create_item(item_id,item_id,"Design",default_empty_to_A(item_revision_id),&item,&rev));

					setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

					//ITK_CALL(ITEM_find_revision(itemOrg,item_revision_id,&rev));
					if(rev != NULLTAG)
					{
						ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
						printf("1..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
						printf("1..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

						if(atoi(item_sequence_id) == 1)
						{
			         		setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
	    					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
     						ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
						}

						if(atoi(item_sequence_id)<=(org_seq_id_int))
						{
							printf("1..No need to check-in check out\n"); fflush(stdout);
							ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
						}
						else
						{
							for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
							{
								//printf("1..***si::[%d]\n",si);
								ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
								if(isCheckOut)
								{
									printf("1..This is  check out....\n");
			                		setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
	    					        setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

									if(RES_checkin(rev)!=ITK_ok)
									{
										fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
								}
								else
								{
									printf("1..This is not check out....\n"); fflush(stdout);

									ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
									printf("\nLatest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

									if (lat_seq_id_int == atoi(item_sequence_id))
									{
										printf("1..*****lat_seq_id_int is matched\n"); fflush(stdout);
										ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
										break;
									}
									else
									{
										if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
										{
											printf("1..RES_checkout failed.\n"); fflush(stdout);
											fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("1..RES_checkout is successful\n"); fflush(stdout);
										}
										//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
				                       	setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
	    					            setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

										if(RES_checkin(rev)!=ITK_ok)
										{
											printf("1..RES_checkin failed.\n"); fflush(stdout);
											fprintf(fperror,"1..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("1..RES_checkin is successful\n"); fflush(stdout);
				     						ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int_1));
               								printf("\nLatest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int_1,atoi(item_sequence_id)); fflush(stdout);
											if (lat_seq_id_int_1 == atoi(item_sequence_id))
											{
												printf("1..*****lat_seq_id_int_1 is matched\n"); fflush(stdout);
												ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
											}
										}
									}
								}

								//ITK_CALL( AOM_save(rev));
								//ITK_CALL( AOM_unlock(rev));
								printf("1..Check-in Check out success\n"); fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n1..Revision tag not found....\n"); fflush(stdout);
					}
				}
			}
			else
			{
				item = tags_found[0];
				printf("2..Item already exists\n"); fflush(stdout);
				ITK_CALL(ITEM_find_revision(item,item_revision_id,&rev));
				if(rev != NULLTAG)
				{
					ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
					printf("2..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
					printf("2..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

					if(atoi(item_sequence_id) == 1)
			 		{
				    	setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
			            setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					}

					if(atoi(item_sequence_id)<=(org_seq_id_int))
					{
						printf("2..No need to check-in check out\n"); fflush(stdout);
						setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					    ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
					}
					else
					{
						for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
						{
							printf("2..***si::[%d]\n",si);
							ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
							if(isCheckOut)
							{
								printf("2..This is  check out....\n ");
		             			setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
			                    setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
								if(RES_checkin(rev)!=ITK_ok)
								{
									fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
								}
							}
							else
							{
								printf("2..This is not check out....\n"); fflush(stdout);

								ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
								printf("2..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

								if (lat_seq_id_int == atoi(item_sequence_id))
								{
									printf("2..*****lat_seq_id_int is matched\n"); fflush(stdout);
								    ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
									break;
								}
								else
								{
									if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
									{
										printf("2..RES_checkout failed.\n"); fflush(stdout);
										fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
									else
									{
										printf("2..RES_checkout is successful\n"); fflush(stdout);
									}
									//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
				                 	setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
			                        setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
									if(RES_checkin(rev)!=ITK_ok)
									{
										printf("2..RES_checkin failed.\n"); fflush(stdout);
										fprintf(fperror,"2..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
									else
									{
										printf("2..RES_checkin is successful\n"); fflush(stdout);

										ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int_1));
								        printf("2..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int_1,atoi(item_sequence_id)); fflush(stdout);

										if (lat_seq_id_int_1 == atoi(item_sequence_id))
										{
											printf("2..*****lat_seq_id_int_1 is matched\n"); fflush(stdout);
											ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
										}

									}
								}
							}

							//ITK_CALL ( AOM_save(rev));
							//ITK_CALL ( AOM_unlock(rev));
							printf("2..Check-in Check out success\n"); fflush(stdout);

							/*if (si > 5)
							{
								printf("\n...................si::[%d]",si);
								break;
							}*/
						}
					}
				}
				else
				{
					printf("3..Item Revision not found\n");
					ITK_CALL(ITEM_create_rev(item,default_empty_to_A(item_revision_id),&rev));
					//ITK_CALL(AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
					setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
			        setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

					if(rev != NULLTAG)
					{
						ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&org_seq_id_int));
						printf("3..File Sequence    :[%s]\n",item_sequence_id); fflush(stdout);
						printf("3..Orginal Sequence :[%d]\n",org_seq_id_int); fflush(stdout);

						if(atoi(item_sequence_id) == 1)
						{
	                		setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					        setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
						}

						if(atoi(item_sequence_id)<=(org_seq_id_int))
						{
							printf("3..No need to check-in check out\n"); fflush(stdout);
					        ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
						}
						else
						{
							for (si=org_seq_id_int; si<atoi(item_sequence_id) ; si++)
							{
								//printf("3..***si::[%d]\n",si);
								ITK_CALL(RES_is_checked_out(rev,&isCheckOut));
								if(isCheckOut)
								{
									printf("3..This is  check out....\n ");
		                			setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					                setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

									if(RES_checkin(rev)!=ITK_ok)
									{
										fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
									}
								}
								else
								{
									printf("3..This is not check out....\n"); fflush(stdout);

									ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int));
									printf("3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

									if (lat_seq_id_int == atoi(item_sequence_id))
									{
										printf("3..*****lat_seq_id_int is matched\n"); fflush(stdout);
								        ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
										break;
									}
									else
									{
										if(RES_checkout(rev,"loader","abc","/tmp",RES_EXPORT_FILE)!=ITK_ok)
										{
											printf("3..RES_checkout failed.\n"); fflush(stdout);
											fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("3..RES_checkout is successful\n"); fflush(stdout);
										}
										//ITK_CALL ( AOM_set_value_string(rev,"t5EntLoadedSeq",item_sequence_id));
			                    		setAttributesOnDesignRev(&rev,projectcode,desc,designgroup,item_revision_id_int,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,atype,t5SpareIndS,t5SpareCriteriaS,t5ReliabilityS,t5RefPartNumberS,t5RecyclabilityS,t5RecoverableS,t5PunMakeBuyIndS,t5PunIntialAgS,t5PrtCatCodeS,t5ProductS,t5PkgStdS,t5PartStatusS,t5PartPropertyS,t5PartCodeS,t5NcPartNoS,t5ListRecSparess,t5HomologationReqdS,t5HazardousContS,t5EnvelopeDimenS,t5DismantableS,t5ConfigIDS,t5ColourIDS,t5ClassificationHazS,t5CMVRCertificationS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,t5DsgnDeptS,t5AplCopyOfErcSeqS);
					                    setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

										if(RES_checkin(rev)!=ITK_ok)
										{
											printf("3..RES_checkin failed.\n"); fflush(stdout);
											fprintf(fperror,"3..Error with part number:[%s],[%s],[%s]\n",item_id,item_revision_id,item_sequence_id);
										}
										else
										{
											printf("3..RES_checkin is successful\n"); fflush(stdout);
		         							ITK_CALL(AOM_ask_value_int(rev,"sequence_id",&lat_seq_id_int_1));
											printf("3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int_1,atoi(item_sequence_id)); fflush(stdout);

											if (lat_seq_id_int_1 == atoi(item_sequence_id))
											{
												printf("2..*****lat_seq_id_int_1 is matched\n"); fflush(stdout);
												ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
											}

										}
									}
								}

								//ITK_CALL ( AOM_save(rev));
								//ITK_CALL ( AOM_unlock(rev));
								printf("3..Check-in Check out success\n"); fflush(stdout);
							}
						}
					}
					printf("3..Item Revision Created\n");
				}
			}
			printf("----------------------------------------------------\n");
		}
		return status;
	}
	ITK_CALL(POM_logout(false));
	if(fperror)fclose(fperror);fperror=NULL;
	return status;
}
