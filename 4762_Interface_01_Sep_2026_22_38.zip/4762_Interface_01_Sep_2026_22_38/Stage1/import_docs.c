/********************************************************************************************************
*  File			: import_docs.c
*  Created By	: Prachi Wade
*  Created On	: 09-Oct-2012
*  Project		: TCUA 	 
*  Purpose		: Client code to upload documents in TCUA from shared location
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/

#include "tc/tc_startup.h"
#include "tc/tc_macros.h"
#include "qry.h"
#include "dataset.h"
#include "tcfile.h"
#include "aom.h"
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define NUM_ENTRIES 1

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

int save_object (tag_t     object_tag)
{
    int ReturnCode;

    /*  Save the object.  */
    ReturnCode = AOM_save (object_tag);
    if (ReturnCode != ITK_ok)
    {
        printf ("ERROR %d save object.\n", ReturnCode);
        return (ReturnCode);
    }

    /* Unlock the object. */
    ReturnCode = AOM_unlock (object_tag);
    if (ReturnCode != ITK_ok)
    {
        printf ("ERROR %d unlock object.\n", ReturnCode);
    }

    return (ReturnCode);
}
  

int import_docs_in_teamcenter(char *project, tag_t project_tag)
{
	int ifail =0;
	int cnt = 0,i=0;
	char* object_name	=NULL;
	char* object_type	=NULL;
	char* dirpath	=NULL;
	char* file_name	=NULL;
	tag_t *fld_content  =NULLTAG;
		tag_t * refObject =NULLTAG;
        int ref_count;
        int k = 0;


 AE_reference_type_t reference_type;
 tag_t    	origin_object = NULLTAG;
 tag_t		new_file = NULLTAG; 
 IMF_file_t file_descriptor;
 char *user_id = NULL;
 char *filename = NULL;
 
	CALLAPI(AOM_ask_value_tags(project_tag,"contents",&cnt,&fld_content));
	printf("\n%s contents:%d\n",project,cnt);

	POM_get_user_id(&user_id);      
    printf("Currently logged User:%s\n",user_id); 

    dirpath  = MEM_alloc(500);
    filename  = MEM_alloc(500);

	CALLAPI(AOM_get_value_string(project_tag,"t8_DeliverablesPath",&dirpath)); 
	printf("\nDirPath:%s\n",dirpath);

	if(cnt>0)
	{
		for(i=0;i<cnt;i++)
		{ 

 				CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
 				CALLAPI(AOM_ask_value_string(fld_content[i],"object_type",&object_type));
			    printf("\nobject_name:%s ",object_name);
			// 	strcpy(filename,"/home/req83/NPIDocs/pip/");	////// to be changed
			 	strcpy(filename,dirpath);	////// to be changed
				CALLAPI(AE_ask_dataset_named_refs (fld_content[i], &ref_count, &refObject));
				if(ref_count>0)
			    {
					if(strcmp(object_type,"MSExcel")==0)					 
					{
						if(strstr(object_name,"Marketing_4 Box")!=NULL)
						{   
							strcat(filename,"4 Box.xls"); 
						}
						if(strstr(object_name,"Marketing_Inputs")!=NULL)
						{   
							strcat(filename,"Marketing Inputs.xls"); 
						}
						if(strstr(object_name,"Marketing_Vehicle Dimensions")!=NULL)
						{ 
							strcat(filename,"Vehicle Dimensions.xls"); 
						}
						if(strstr(object_name,"Marketing_Product Profile")!=NULL) 
						{  
							strcat(filename,"Product Profile.xls"); 
						}
						if(strstr(object_name,"Marketing_Product Price Positioning")!=NULL)
						{ 
							strcat(filename,"Product Price Positioning.xls"); 
						}
						if(strstr(object_name,"Marketing_Features List")!=NULL)
						{   
							strcat(filename,"Features List.xls"); 
						}
						if(strstr(object_name,"NPI_Letter from PMO")!=NULL)
						{   
							strcat(filename,"Letter from PMO.xls"); 
						}
						if(strstr(object_name,"ERC_Time Plan")!=NULL)
						{   
							strcat(filename,"ERC Time Plan.xls"); 
						}
						if(strstr(object_name,"ERC_Inputs")!=NULL)
						{   
							strcat(filename,"ERC Input.xls"); 
						}
						if(strstr(object_name,"ERC_Estimates")!=NULL)
						{   
							strcat(filename,"ERC Estimates.xls"); 
						}
						if(strstr(object_name,"VD_Time Plan")!=NULL)
						{   
							strcat(filename,"VD Time Plan.xls"); 
						}
						if(strstr(object_name,"VD_ Inputs")!=NULL)
						{   
							strcat(filename,"VD Input.xls"); 
						}
						if(strstr(object_name,"Manufacturing_Inputs")!=NULL)
						{   
							strcat(filename,"Manufacturing Inputs.xls");
						}
						if(strstr(object_name,"Manufacturing_Time Plan")!=NULL)
						{  
							strcat(filename,"Manufacturing Time Plan.xls"); 
						}
						if(strstr(object_name,"Manufacturing_Investments")!=NULL)
						{
							strcat(filename,"MFG Investments.xls"); 
						}
						if(strstr(object_name,"Finance_Business Case")!=NULL)
						{   
							strcat(filename,"Business Case.xls"); 
						}
						if(strstr(object_name,"NPI_9 Box")!=NULL)
						{   
							strcat(filename,"9 Box.xls"); 
						}
						if(strstr(object_name,"NPI_Approval Letter")!=NULL)
						{   
							strcat(filename,"Approval Letter.xls"); 
						}
			
 						IMF_import_file (filename,NULL,SS_BINARY,&new_file,&file_descriptor);
						if(new_file != NULLTAG)
						{
						   save_object(new_file); 						  
						   AE_ask_dataset_named_ref(fld_content[i],"excel",&reference_type,&origin_object);
						   AOM_refresh (fld_content[i],1);
						   AE_replace_dataset_named_ref(fld_content[i],origin_object,"excel",reference_type,new_file); 
						   save_object(fld_content[i]);
						}
					}
					if(strcmp(object_type,"MSPowerPoint")==0)					 
					{
						if(strstr(object_name,"Marketing_Pyramid and Slider")!=NULL)
						{  
							strcat(filename,"Pyramid and Slider.ppt"); 
						} 
						if(strstr(object_name,"ERC_PAT Preference")!=NULL)
						{   
							strcat(filename,"PAT Preference.ppt"); 
						}

						IMF_import_file(filename,NULL,SS_BINARY,&new_file,&file_descriptor);
						if(new_file != NULLTAG)
						{
							save_object(new_file);
							AE_ask_dataset_named_ref(fld_content[i],"powerpoint",&reference_type,&origin_object); 
							AOM_refresh (fld_content[i],1);
							AE_replace_dataset_named_ref(fld_content[i],origin_object,"powerpoint",reference_type,new_file); 
							save_object(fld_content[i]);
						}
					}

				}

				
		}




   }


	return ifail;

}


int ITK_user_main(int argc, char *argv[])
{
   	
	int status; 
	char *projectName = NULL; 
	char *action = NULL; 
	char	entryNamesArray[NUM_ENTRIES][QRY_uid_name_size_c+1]	= { "Name"};
	char	entryValuesArray[NUM_ENTRIES][QRY_clause_size_c+1]	= { "*"}; 
	char**	critNames = NULL;
	char**	critValues = NULL;
	int     index =0,resultCount = 0;
	int		entryCount =0;
	char**	entryNames = NULL;
	char**	entryValues = NULL;
	tag_t*	resultTags = NULLTAG;
	tag_t	queryTag	= NULLTAG;
	int ifail =0;

 
	ITK_set_journalling(TRUE);
	ITK_initialize_text_services (0);


	printf("\nAttempting auto login to Teamcenter...\n");
	
	status = ITK_auto_login ();
	if (status != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL; 
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s) with ITK_auto_login\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return status;
	}
	else
	{
		projectName = MEM_alloc(150);
	    action = MEM_alloc(50);
	

		printf("\nLogin Successful.\n");
		projectName = ITK_ask_cli_argument("-i=");
	    printf("\nprojectName:%s\n",projectName);
	 
		critNames = (char**)MEM_alloc( 2 * sizeof(char*) );
		critNames[0] = (char*)MEM_alloc( 128 * sizeof(char) );
		if(critNames[0] )
			strcpy( critNames[0], entryNamesArray[0] );
  

		strcpy(entryValuesArray[0],projectName);  		
 
		critValues =(char**)MEM_alloc( 2 * sizeof(char*) );
 		critValues[0] = (char*)MEM_alloc( 128 * sizeof(char) );
			if( critValues[0] )
			strcpy( critValues[0], entryValuesArray[0] );
 
		//*********************************************
		// DISPLAY THE CRITERIA
		//*********************************************

		for( index=0; index<NUM_ENTRIES; index++ )
		{
		   printf("**************************************%s - %s\n", critNames[index], critValues[index]);fflush(stdout);
		}

		CALLAPI( QRY_find("PCBU Project", &queryTag) );
		if(queryTag != NULLTAG)
	    {

		//*********************************************
		// DISPLAY THE VALIE ENTRIES, JUST FYI
		//*********************************************

		CALLAPI( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
		printf("\nentryCount:%d\n", entryCount);fflush(stdout);
		for( index=0; index<entryCount; index++ )
		{
		    printf("\t\t%s - %s\n", entryNames[index], entryValues[index]);
		}

		//*********************************************
		// EXECUTE THE QUERY
		//*********************************************

			CALLAPI( QRY_execute(queryTag, entryCount, critNames, critValues, &resultCount, &resultTags) );

		} 


		printf("\nQry Result:%d\n", resultCount);fflush(stdout);
		if(resultCount > 0 )
	    {
			CALLAPI(import_docs_in_teamcenter(projectName,resultTags[0]));
			//CALLAPI(export_docs_from_teamcenter(projectName,resultTags[0]));
		}
		

	}
	
	ITK_exit_module(TRUE);
	
	return status; 

} 
;
 

