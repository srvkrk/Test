#Milind Bharambe

#Set initial values
asciiflag=0
rdline=""

/misc/plmclient/bin/jttoascii $1 $2.ajt
#Read line by line
while read line
do
checkdi=`echo $line |cut -d" " -f2`
if [ "$checkdi" = 'PRT' -o "$checkdi" = 'SUB' ]; then
 asciiflag=2
 rdline=""
fi

#check blanked and CURVE word
checkblanked=`echo $checkdi | cut -d"." -f1 | awk -F"_" '{ print $NF }'`
checkcurve=`echo $checkdi | cut -d"." -f1 | awk -F"_" '{ print $1 }' | cut -d\" -f2`
if [ "$checkblanked" = 'blanked' -o "$checkcurve" = 'CURVE' ]; then
	#echo "Instance blanked or CURVE found"
	asciiflag=2
	rdline=""
fi

#create final ascii file
if [ $asciiflag != 2 ]; then
  if [ $asciiflag == 0 ]; then
    if [ "x$rdline" != "x" ]; then
      echo $rdline >> final.ajt
      rdline=""
    fi
    echo $line >> final.ajt
	
  fi
  asciiflag=0
fi

done < $2.ajt 

echo "# EOF" >> final.ajt
#jtname=`echo $1 | cut -d'.' -f1`

#create JT from final ascii file
/misc/plmclient/bin/asciitojt final.ajt $2_new.jt

rm -rf $2.ajt final.ajt 
