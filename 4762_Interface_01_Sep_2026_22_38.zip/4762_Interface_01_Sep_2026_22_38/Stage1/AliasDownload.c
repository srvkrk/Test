/***************************************************************************
*
* File            :   AliasDownload.c
* Created By      :   Sharvari Karale
* Created On      :   07/01/2011
* Project         :   Alias loader/downloader
*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include "tc.h"
#include "ae.h"
#include "unidefs.h"
#include "mem.h"
#include "tc.h"
#include "item.h"
#include "bom.h"
#include "cfm.h"
#include "ps_errors.h"
#include "grm.h"
#include "grmtype.h"
#include "workspaceobject.h"
#include "ae.h"
#include "ss_const.h"
#include "tc_string.h"
#include "tcfile.h"
#include "sample_err.h"
#include "emh.h"
#include "pom.h"
#include "ps.h"
#define TE_MAXLINELEN  128 
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <grm.h>
#include <tctype.h>
#include <aom_prop.h>
#include <tc_string.h>
#include <dataset.h>
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
static void print_bom (tag_t line,tag_t Parent, int depth,FILE *fdf,FILE *fus);
static void print_data_item(tag_t this_itemRev,char *attr);
char* subString (char* mainStringf ,int fromCharf,int toCharf);
		
extern int ITK_user_main (int argc, char ** argv )
{
    int     status;
	char    *req_item,*FileDown,*FileUses = NULL;
	char    rev_id[ITEM_id_size_c+1];
	tag_t   window, window2, rule, item_tag = null_tag, top_line;
	FILE	*fd,*fu;
	
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
  
    req_item = ITK_ask_cli_argument("-i=");
	FileDown = ITK_ask_cli_argument("-f1=");
	FileUses = ITK_ask_cli_argument("-f2=");

	fd=fopen(FileDown,"w");
    if(fd==NULL)
	{
		printf("\nError in opening the file \n");
	}

	fu=fopen(FileUses,"w");
    if(fu==NULL)
	{
		printf("\nError in opening the file \n");
	}
	
	if ( req_item )
    { 
	    tag_t *tags_found = NULL;
        int n_tags_found= 0;
        char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
        char **values = (char **) MEM_alloc(1 * sizeof(char *));
		
        attrs[0] ="item_id";
        values[0] = (char *)req_item;
		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
        MEM_free(attrs);
        MEM_free(values);        
		if (n_tags_found == 0)
        {
            printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item);
            exit (0);
        }
        else if (n_tags_found > 1)
        {
            MEM_free(tags_found);
            EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
            printf ( "More than one items matched with id %s\n", req_item);
            exit (0);
        }
	    item_tag = tags_found[0];
        MEM_free(tags_found);		
		ITK_CALL(BOM_create_window (&window));		
		ITK_CALL(CFM_find( "Latest Working", &rule ));		
		ITK_CALL(BOM_set_window_config_rule( window, rule ));		
		ITK_CALL(BOM_set_window_pack_all (window, true));
		ITK_CALL(BOM_set_window_top_line (window, item_tag, null_tag, null_tag, &top_line));
		
		print_bom (top_line,NULLTAG, 0,fd,fu);		
		fclose(fd);
		fclose(fu);	
	
	}	
	return status;
	
	
} 
//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------
static void print_bom (tag_t line,tag_t Parent, int depth,FILE *fdf,FILE *fus)
  {
    int    status;
	int    k, n,int_ent_sequence;    
	int    Item_ID,Item_Revision,Item_Description,parent_item_seq=0;    
	int    n_attchs,i,referencenumberfound,j;	
	int    numBoundingBoxes,ctr;
	int    Parentsequence_id=0;
	int    dum=0;
	
	double *  boundingBoxes;
    
	char   *name, *Item_ID_str,*Item_Revision_str,*Item_Description_str;
	char   *dumy_Item_ID_str=NULL;
	char   *catiafileName=NULL;
	char   *projectcode=NULL;
	char   *desgngrp=NULL;
	char   *ret_id,*ret_rev;
	char   type_name[TCTYPE_name_size_c+1];
	char   refname[AE_reference_size_c + 1];
	char   orig_name[IMF_filename_size_c + 1];
	char   *enterprise_sequence;
	char   pathname[SS_MAXPATHLEN + 1];
	char   *ent_seq_str;	
	char   *parentrev=NULL;
	char   *parent=NULL;
	char   *parentseq=NULL;
	char   *parentdesc=NULL;
	char   *PatSeq= NULL;
	char* item_revision_id=NULL;
	char   *ITemRevSeq= NULL;	
    
	tag_t  ParentItemRevTag,rev =NULLTAG;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t  *children,itemrev,sequence_id_c;
	tag_t  reln_type =NULLTAG;
	AE_reference_type_t     reftype;
    
	
	
	depth ++;
   
    ITK_CALL( BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
	ITK_CALL(BOM_line_ask_attribute_string(line, Item_ID, &Item_ID_str));
	
	printf("\n1] Item_ID_str =%s\n",Item_ID_str);
	
	ITK_CALL( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
	ITK_CALL(BOM_line_ask_attribute_string(line, Item_Revision, &Item_Revision_str));
	
	printf("\n2] Item_Revision_str =%s\n",Item_Revision_str);
	
	ITK_CALL(BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
	ITK_CALL(BOM_line_ask_attribute_tag(line, parent_item_seq, &itemrev));
    ITK_CALL(AOM_ask_value_int(itemrev,"sequence_id",&sequence_id_c));
	printf("\n3] Sequence =%d\n",sequence_id_c);
	ITemRevSeq = (char *) MEM_alloc( 5 * sizeof(char) );
	sprintf(ITemRevSeq,"%d",sequence_id_c);
	
	ITK_CALL( BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
	ITK_CALL(BOM_line_ask_attribute_string(line, Item_Description, &Item_Description_str));
	printf("\n4] Item_Description_str =%s\n",Item_Description_str);

	ITK_CALL(AOM_ask_value_string(itemrev,"gov_classification",&enterprise_sequence));  
    printf("\n -----------------------enterprise_sequence -->%s\n",enterprise_sequence);
	
	int_ent_sequence=atoi(enterprise_sequence);  

	dumy_Item_ID_str=MEM_string_copy(Item_ID_str) ;
	projectcode=subString(dumy_Item_ID_str,0,4);
	desgngrp=subString(dumy_Item_ID_str,4,2);

	printf("\nprojectcode------->%s\n",projectcode);
	printf("\n desgngrp------->%s\n",desgngrp);
//    if (Parent == null_tag) 
//	{
//			   printf("\nThis is first line\n");
//	}
//	else 
//	{                
//			    ITK_CALL(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision));
//			    ITK_CALL(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
//			    ITK_CALL(  BOM_line_ask_attribute_string(Parent, Item_Revision, &parentrev));
//			    ITK_CALL(  BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &parent_item_seq));
//			    ITK_CALL(  BOM_line_look_up_attribute ("bl_rev_object_desc",&Item_Description));
//			    
//			   
//			    ITK_CALL(BOM_line_ask_attribute_string(Parent, Item_ID, &parent));
//			    ITK_CALL(BOM_line_ask_attribute_tag(Parent, parent_item_seq, &ParentItemRevTag));
//			    ITK_CALL(AOM_ask_value_int(ParentItemRevTag,"sequence_id",&Parentsequence_id));
//			    PatSeq=malloc(3);
//			    sprintf(PatSeq,"%d",Parentsequence_id);
//			    ITK_CALL(BOM_line_ask_attribute_string(Parent, Item_Description, &parentdesc));
//			    printf("\n       parent---->%s\n", parent);
//				printf("\n       parentrev---->%s\n",parentrev );
//				printf("\n       PatSeq---->%s\n",PatSeq );
//				printf("\n       parentdesc---->%s\n",parentdesc );
//
//
//				fprintf(fus,parent);
//				fprintf(fus,",");
//				fprintf(fus,parentrev);
//				fprintf(fus,",");
//				fprintf(fus,PatSeq);
//				fprintf(fus,",");
//				fprintf(fus,Item_ID_str);
//				fprintf(fus,",");
//				fprintf(fus,Item_Revision_str);
//				fprintf(fus,",");
//				fprintf(fus,ITemRevSeq);
//				fprintf(fus,",");
//				
//				fprintf(fus,Item_ID_str);
//				fprintf(fus,".1");
//				fprintf(fus,",");
//				
//				fprintf(fus,"1");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"1");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"1");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"0");
//				fprintf(fus,",");
//				fprintf(fus,"1");
//				fprintf(fus,",");
//				fprintf(fus,"-");
//				fprintf(fus,",");
//				fprintf(fus,"reptest");
//				fprintf(fus,"\n");
//				//bomAttr_AbsTransformMatrix         "bl_abs_xform_matrix"
//                //bomAttr_OccTransformMatrix         "bl_occ_xform_matrix"
//				//fprintf(fus,Item_Description_str);
//				//fprintf(fus,",");
//				//fprintf(fus,"NA");
//				//fprintf(fus,",");
//				//fprintf(fus,parentdesc);
//				//fprintf(fus,",");
//				//fprintf(fus,occName);
//				//fprintf(fus,",");
//				//fprintf(fus,strQty);
//				//fprintf(fus,",");
//				//fprintf(fus,"-");
//				//fprintf(fus,",");
//				//fprintf(fus,"reptest");
//				
//
//	}
	ITK_CALL(GRM_list_secondary_objects_only(itemrev,reln_type,&n_attchs,&secondary_objects));
	printf("\n n_attchs :%d\n",n_attchs); 
	if(n_attchs>0)
	{
		for (i= 0; i < n_attchs; i++)
		{
		   primary=secondary_objects[i];
		   ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
		   ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));	
		   printf("\n type_nameeeee :%s and referencenumberfound :%d\n",type_name,referencenumberfound); 
	
		   if(strcmp(type_name,"MISC")==0)
		  {	    
//		  	ITK_CALL(ITEM_find_revision(primary,Item_Revision_str,&rev));
//			if(rev)
//			{
			  printf("\n inside if rev  :%d\n",referencenumberfound); 
			   ITK_CALL(AE_ask_dataset_id_rev(primary,&ret_id,&ret_rev));
			   ITK_CALL(AE_ask_dataset_ref_count(primary,&referencenumberfound));
			    printf("\n referencenumberfound :%d\n",referencenumberfound); 
//			  }
			   for(j=0;j<referencenumberfound;j++)
			   {
				   ITK_CALL(AE_find_dataset_named_ref(primary,j,refname,&reftype,&refobject));
				      printf("\n refname :%s\n",refname); 
				   //if(strcmp(refname,"catpart")==0 || strcmp(refname,"catproduct")==0 ||strcmp(refname,"catdrawing")==0 /*|| strcmp(refname,"JTPART")==0 */|| strcmp(refname,"t5alias")==0 )
				   //{
						   if(strcmp(refname,"catpart")==0)
						   {
									ITK_CALL( AE_get_bounding_boxes(primary, &numBoundingBoxes, &boundingBoxes));									
						   }
						   ITK_CALL( IMF_ask_original_file_name(refobject,orig_name));
						   printf("\n orig_name is :%s\n",orig_name);
                           
						   if(int_ent_sequence<sequence_id_c)
					       {
						         
								 ctr=int_ent_sequence+1;              
								 for (ctr;ctr<=sequence_id_c ;ctr++ ) 
								 {                                    
											dum=ctr;                         
											ent_seq_str = (char *) MEM_alloc( 5 * sizeof(char) );         
											sprintf(ent_seq_str,"%d",dum);
											fprintf(fdf,Item_ID_str);    
											fprintf(fdf,",");         
											fprintf(fdf,projectcode);      								 
											fprintf(fdf,",");         								 
											fprintf(fdf,desgngrp);        
											fprintf(fdf,",");         
											fprintf(fdf,Item_Description_str);    
											fprintf(fdf,",");         
											fprintf(fdf,orig_name);   
											fprintf(fdf,",");         
										/*6]*/	fprintf(fdf,"NULL");      
											fprintf(fdf,",");         
										/*7]*/	fprintf(fdf,Item_Revision_str);     
											fprintf(fdf,",");         
											fprintf(fdf,ent_seq_str); 
											fprintf(fdf,",");         
										/*8]*/	fprintf(fdf,ent_seq_str);         
											fprintf(fdf,",");         
											fprintf(fdf,"WIP");  
											fprintf(fdf,",");         
											fprintf(fdf,orig_name);   
											fprintf(fdf,",");         
											fprintf(fdf,Item_Revision_str);     
											fprintf(fdf,",");         
										/*13]*/	fprintf(fdf,ent_seq_str); 
											fprintf(fdf,",");
											fprintf(fdf,"NULL");      
											fprintf(fdf,",");         
											fprintf(fdf,"0");         
											fprintf(fdf,","); 
											fprintf(fdf,"0");         
											fprintf(fdf,",");
											fprintf(fdf,"0");         
											fprintf(fdf,",");
											fprintf(fdf,"0");         
											fprintf(fdf,",");
											fprintf(fdf,"0");         
											fprintf(fdf,",");
										/*20]*/	fprintf(fdf,"Y");         
											fprintf(fdf,",");         
											fprintf(fdf,"-");         
											fprintf(fdf,",");         
											fprintf(fdf,"-");         
											fprintf(fdf,",");         
											fprintf(fdf,"reptest");  
											fprintf(fdf,"\n"); 
											sprintf(pathname,"%s/%s","/home/uadev81/Alias_download/WIP",orig_name );
											printf("\npathname=%s\n",pathname);
											ITK_CALL(IMF_export_file(refobject,pathname));
								            printf("\nExport done successfuly\n");
								 }
						   
						   
						   }
				   //}
			   }
		   
		  }
		}
	}
//	else printf("\nThere are no data item attached to it \n");
//	ITK_CALL(BOM_line_ask_child_lines (line, &n, &children));	    
//    for (k = 0; k < n; k++)
//      print_bom (children[k],line,depth,fdf,fus);
//	
  }
 //--------------------------------------------------------------------------------------------------------------------------
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
  
  


