/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			:   TmetcBomLevelCatiaList.c
*  Author		:   Dayanand Amdapure
*  Module        :   TMETC TCUA Downloader.
*  Purpose       :   To Download Catia Parts.
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/


#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <ReadFile.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#define NUMBER 5000

//From TC Part Getting the Visualization Files...
status GetTCPartInfoForContextBOMViewJTCreationBOMLevel(ObjectPtr TCPartObjP,FILE *fp,FILE *catiafp,FILE *Refp,FILE *Refcatiafp,string partrevSeq,integer* mfail )
{

	int LatestDoc=0;
	int DataItem=0;
	int VisFile=0;
	int printedtofile=0;

	string  TCPartOwnerNameDupS=NULL;
	string  TCPartOwnerNameS=NULL;
	string  DocBIClassNameDupS=NULL;
	string  DocBIClassNameS=NULL;
	string  VisFileRelPathDupS=NULL;
	string  VisFileRelPathS=NULL;
	string  VisFileWorkingRelativePathDupS=NULL;
	string  VisFileWorkingRelativePathS=NULL;
	string  VisFileSequenceDupS=NULL;
	string  VisFileSequenceS=NULL;
	string  VisFileClassDupS=NULL;
	string  VisFileClassS=NULL;
	string  VisFileOwnerNameDupS=NULL;
	string  VisFileOwnerNameS=NULL;
	string  TCPartNumberDupS=NULL;
	string  TCPartNumberS=NULL;
	string  TCPartRevisionDupS=NULL;
	string  TCPartRevisionS=NULL;
	string  TCPartSequenceDupS=NULL;
	string  TCPartSequenceS=NULL;
	string  TCPartTypeDupS=NULL;
	string  TCPartTypeS=NULL;
	string  VisFileOwnerDirNameS=NULL;
	string  VisFileOwnerDirNameDupS=NULL;
	string  DiClassS=NULL;
	string  DiClassDupS=NULL;
	string CatiaWorkingPathDupS=NULL;
	string CatiaWorkingPathS=NULL;
	string CatiaRelPathS=NULL;
	string CatiaRelPathDupS=NULL;
	string CatiaSequenceDupS=NULL;
	string CatiaSequenceS=NULL;
	string CatiaOwnerDirNameDupS=NULL;
	string CatiaOwnerDirNameS=NULL;
	string CatiaOwnerNameDupS=NULL;
	string CatiaOwnerNameS=NULL;
	string DrawingIndDupS=NULL;
	string DrawingIndS=NULL;

	SetOfObjects  JTUsesPartFilePhyItemSO = NULL ;
	SetOfObjects  JTUsesPartFileRelSO = NULL ;
	SetOfObjects  DocumentSO = NULL ;
	SetOfObjects  DocumentRelSO = NULL ;
	SetOfObjects  LatestDocSO = NULL ;
	SetOfObjects  LatestRelDocSO = NULL ;
	SetOfObjects  DataItemSO = NULL ;
	SetOfObjects  VisualizationFileSO = NULL ;
	SetOfObjects allObjSet12=NULL;
	SetOfObjects allObjRels12=NULL;

	int printeddrwtofile=0;
	int size1=0;
	int size2=0;
	int i=0;
	ObjectPtr allObjP=0;
	ObjectPtr soObj1P=0;
	string DocClassS=NULL;
	string DrwDocNameDup=NULL;
	string DrwDocName=NULL;
	string fullPathattr=NULL;
	string fullPathattrDup=NULL;
	SET_PTR		ReqDrwSetObj;
	SetOfStrings		distDrwDocNamSOS	=	NULL;
	SetOfObjects soObj2=NULL;
	SetOfObjects soObj=NULL;
	string			sDocno			=	NULL;
	string			CatiaDisDupS			=	NULL;
	string			CatiaDisS			=	NULL;
	SqlPtr sql1=NULL;

	ObjectPtr LatestDocObjP=NULL;
	ObjectPtr proprtrevObjP=NULL;
	ObjectPtr NewDataItemObjP=NULL;
	ObjectPtr DataItemObjP=NULL;
	ObjectPtr NewVisFileObjP=NULL;
	ObjectPtr VisFileObjP=NULL;
	FILE *fperr=NULL;
	t5MethodInit("GetTCPartInfoForContextBOMViewJTCreationBOMLevel");

	//objDump(TCPartObjP);
	t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&TCPartOwnerNameDupS));
	TCPartOwnerNameS=nlsStrDup(TCPartOwnerNameDupS);
	printf("\n GetTCPartInfoForContextBOMViewJTCreationBOMLevel \n"); fflush(stdout);
	printf("\n Executing Function For Resultant TC Part OwnerNameS:%s \n",TCPartOwnerNameS); fflush(stdout);

	t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&TCPartTypeDupS));
	TCPartTypeS=nlsStrDup(TCPartTypeDupS);
	//-------
	t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&TCPartNumberDupS));
	TCPartNumberS=nlsStrDup(TCPartNumberDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&TCPartRevisionDupS));
	TCPartRevisionS=nlsStrDup(TCPartRevisionDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&TCPartSequenceDupS));
	TCPartSequenceS=nlsStrDup(TCPartSequenceDupS);

	printf("\n Executing Part Number for cateia:[%s] TCPartRevisionS :[%s]:",TCPartNumberS,TCPartRevisionS);fflush(stdout);
	printf("\n Executing Function For Resultant TC Part TCPartTypeS:%s \n",TCPartTypeS); fflush(stdout);

	if (!nlsStrCmp(TCPartOwnerNameS,"WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"JSR WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"LKO WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"HNJ WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"JSR Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"LKO Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"HNJ Release Vault") || nlsStrStr(TCPartOwnerNameS,"CE Vault")!=NULL)
	{
		printf("\n This Expand Object");fflush(stdout);
		//t5CheckMfail(ExpandObject3(PartDocClass,TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,NULL,&DocumentSO,&DocumentRelSO,mfail));
		t5CheckMfail(ExpandObject2(PartDocClass,TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail));
    	printf("\n Executing Part Number:[%s],setSize(DocumentSO)[%d]",TCPartNumberS,setSize(DocumentSO));fflush(stdout);

		if(setSize(DocumentSO)==0)
		{
			printf("\n There is no Qualified Documents for this part (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function)\n"); fflush(stdout);
			goto CLEANUP;
		}else
		{
					printf("\n This Expand Object 2");fflush(stdout);
					//fprintf(fp,"SKIPJT\n");
		}
		/* Get Latest documents from set */
		t5CheckMfail(t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail));

		printf("\n This Expand Object 3");fflush(stdout);

		for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
		{
			LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Current Running serial of LatestDoc is:%d \n",LatestDoc); fflush(stdout);
			//objDump(LatestDocObjP);
			t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
			DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Document (Business Item) Class Name is:%s \n",DocBIClassNameS); fflush(stdout);
			printf("\n Document Class:[%s]",DocBIClassNameS);
			if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulCad")==0) )
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));


				printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) NO OF Data Item available for this DocClass:%s and Count is:%d \n",DocBIClassNameS,setSize(DataItemSO)); fflush(stdout);

				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"ProPrt")==0  || nlsStrCmp(DiClassS,"ProAsm")==0 || nlsStrCmp(DiClassS,"ProDrw")==0 || nlsStrCmp(DiClassS,"x0CatPrd")==0) && (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0 || nlsStrCmp(DocBIClassNameS,"t5MulCad")==0 || nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0 || nlsStrCmp(DocBIClassNameS,"DesDoc")==0 ))
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n Cad Relative Path :[%s]",CatiaRelPathS);

								if(nlsStrStr(CatiaRelPathS,"Spec")==NULL)
								{
									printf("\n This is not a spec file");

										fprintf(catiafp,"%s",DiClassS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaOwnerNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",fullPathattrDup);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s\n",CatiaRelPathS);
										fflush(catiafp);

										fprintf(fp,"%s",TCPartNumberS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartRevisionS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartSequenceS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaDisS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaRelPathS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaOwnerDirNameS);
										fprintf(fp,"^");
										fprintf(fp,"%s",fullPathattrDup);
										fprintf(fp,"^");
										fprintf(fp,"%s\n",CatiaSequenceS);
										fflush(fp);

								}else
								{

										//This is for spec file attached to desc doc.....
										fprintf(catiafp,"%s",DiClassS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaOwnerNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",fullPathattrDup);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s\n",CatiaRelPathS);
										fflush(catiafp);

										fprintf(fp,"%s",TCPartNumberS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartRevisionS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartSequenceS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaDisS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaRelPathS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaOwnerDirNameS);
										fprintf(fp,"^");
										fprintf(fp,"%s",fullPathattrDup);
										fprintf(fp,"^");
										fprintf(fp,"%s\n",CatiaSequenceS);
										fflush(fp);
								}
						}
					}

				  }
			}else if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
				printf("\n setSize(DataItemSO):[%d]",setSize(DataItemSO));
				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name11:[%s]",DiClassS);
						if(nlsStrCmp(DiClassS,"x0CatDrw")==0)
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n Not problem here \n");fflush(stdout);

										fprintf(catiafp,"%s",DiClassS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaOwnerNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",fullPathattrDup);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s\n",CatiaRelPathS);
										fflush(catiafp);

										fprintf(fp,"%s",TCPartNumberS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartRevisionS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartSequenceS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaDisS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaRelPathS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaOwnerDirNameS);
										fprintf(fp,"^");
										fprintf(fp,"%s",fullPathattrDup);
										fprintf(fp,"^");
										fprintf(fp,"%s\n",CatiaSequenceS);
										fflush(fp);


						}else if(nlsStrCmp(DiClassS,"ProDrw")==0)
						{
								printf("\n Found out an Proe Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n problem here \n");fflush(stdout);

										fprintf(catiafp,"%s",DiClassS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaOwnerNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",fullPathattrDup);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s\n",CatiaRelPathS);
										fflush(catiafp);

										fprintf(fp,"%s",TCPartNumberS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartRevisionS);
										fprintf(fp,"^");
										fprintf(fp,"%s",TCPartSequenceS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaDisS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaRelPathS);
										fprintf(fp,"^");
										fprintf(fp,"%s",CatiaOwnerDirNameS);
										fprintf(fp,"^");
										fprintf(fp,"%s",fullPathattrDup);
										fprintf(fp,"^");
										fprintf(fp,"%s\n",CatiaSequenceS);
										fflush(fp);

						}
					}
				  }
			}
			else
			{
				 //fprintf(fp,"SKIPJT\n");
			   printf("\n Not a Valid Doc class \n"); fflush(stdout);
			}
		}

     /////////////////////////////////////////Reference ///////////////////////////////

		printf("\n that reference Expand Object");fflush(stdout);
        DocumentSO=NULL;
        DocumentRelSO=NULL;
		t5CheckDstat(ExpandObject2(InfoDwgClass,TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentSO, &DocumentRelSO,mfail));


		if(setSize(DocumentSO)==0)
		{
			printf("\n There is no Qualified Documents for this part (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function)\n"); fflush(stdout);
			goto CLEANUP;
		}else
		{
					printf("\n This Expand Object 3111");fflush(stdout);
					//fprintf(fp,"SKIPJT\n");
		}
		/* Get Latest documents from set */
		t5CheckMfail(t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail));

		printf("\n This Expand Object 41111");fflush(stdout);

		for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
		{
			LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Current Running serial of LatestDoc is_11:%d \n",LatestDoc); fflush(stdout);
			//objDump(LatestDocObjP);
			t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
			DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Document (Business Item) Class Name is:%s \n",DocBIClassNameS); fflush(stdout);
			printf("\n Document Class:[%s]",DocBIClassNameS);
			if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulCad")==0) )
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));


				printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) NO OF Data Item available for this DocClass:%s and Count is_22:%d \n",DocBIClassNameS,setSize(DataItemSO)); fflush(stdout);

				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"ProPrt")==0  || nlsStrCmp(DiClassS,"ProAsm")==0 || nlsStrCmp(DiClassS,"ProDrw")==0 || nlsStrCmp(DiClassS,"x0CatPrd")==0) && (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0 || nlsStrCmp(DocBIClassNameS,"t5MulCad")==0 || nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0 || nlsStrCmp(DocBIClassNameS,"DesDoc")==0 ))
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n Cad Relative Path :[%s]",CatiaRelPathS);

								if(nlsStrStr(CatiaRelPathS,"Spec")==NULL)
								{
									printf("\n This is not a spec file");

										fprintf(Refcatiafp,"%s",DiClassS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",CatiaOwnerNameS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",fullPathattrDup);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s\n",CatiaRelPathS);
										fflush(Refcatiafp);

										fprintf(Refp,"%s",TCPartNumberS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartRevisionS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaDisS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaRelPathS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaOwnerDirNameS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",fullPathattrDup);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s\n","Ref");
     									fflush(Refp);

								}else
								{

										//This is for spec file attached to desc doc.....
										fprintf(Refcatiafp,"%s",DiClassS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",CatiaOwnerNameS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",fullPathattrDup);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s\n",CatiaRelPathS);
										fflush(Refcatiafp);

										fprintf(Refp,"%s",TCPartNumberS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartRevisionS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaDisS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaRelPathS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaOwnerDirNameS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",fullPathattrDup);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s\n","Ref");
										fflush(Refp);
								}
						}
					}

				  }
			}else if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
				printf("\n setSize(DataItemSO):[%d]",setSize(DataItemSO));
				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name11:[%s]",DiClassS);
						if(nlsStrCmp(DiClassS,"x0CatDrw")==0)
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n problem here \n");fflush(stdout);

										fprintf(Refcatiafp,"%s",DiClassS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",CatiaOwnerNameS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",fullPathattrDup);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s\n",CatiaRelPathS);
										fflush(Refcatiafp);

										fprintf(Refp,"%s",TCPartNumberS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartRevisionS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaDisS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaRelPathS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaOwnerDirNameS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",fullPathattrDup);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s\n","Ref");
										fflush(Refp);


						}else if(nlsStrCmp(DiClassS,"ProDrw")==0)
						{
								printf("\n Found out an Proe Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(NewDataItemObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

								printf("\n problem here \n");fflush(stdout);

										fprintf(Refcatiafp,"%s",DiClassS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",CatiaOwnerNameS);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s",fullPathattrDup);
										fprintf(Refcatiafp,",");
										fprintf(Refcatiafp,"%s\n",CatiaRelPathS);
										fflush(Refcatiafp);

										fprintf(Refp,"%s",TCPartNumberS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartRevisionS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",TCPartSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaDisS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaRelPathS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaOwnerDirNameS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",fullPathattrDup);
										fprintf(Refp,"^");
										fprintf(Refp,"%s",CatiaSequenceS);
										fprintf(Refp,"^");
										fprintf(Refp,"%s\n","Ref");
										fflush(Refp);

						}
					}
				  }
			}
			else
			{
				 //fprintf(Refp,"SKIPJT\n");
			   printf("\n Not a Valid Doc class \n"); fflush(stdout);
			}
		}

	   printf("\n End of References .....\n"); fflush(stdout);

     /////////////////////////////////////////Reference ///////////////////////////////

	}
	else
	{
		printf("\n The Resultant TC Part is not in Vault(Func)..\n"); fflush(stdout);

	}
	////////////////////////////////////////////////////////////////////////////////////////////////////

CLEANUP:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) CLEANUP..\n"); fflush(stdout);
		t5PrintCleanUpModName;

		t5FreeSetOfObjects(DocumentSO);
		t5FreeSetOfObjects(DocumentRelSO);
		t5FreeSetOfObjects(LatestDocSO);
		t5FreeSetOfObjects(LatestRelDocSO);
		t5FreeSetOfObjects(DataItemSO);


EXIT:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) EXIT..\n"); fflush(stdout);
		t5CheckDstatAndReturn;

};

struct func
 {
   char InpPartNumberS[40]   ;
   char InpPartRevisionS[10]  ;
   char InpPartSequenceS[5]   ;
   char Level[5];

  } InputDataFileS[4000];


//Main Program for ContextBOMViewJTCreationBOMLevel
int main(int argc, char *argv[])
{
	int stat=0;
	int i, elmt1=0;
	int c1=0;
	int c2=0;
	int c4=0;

	string  LoginS=NULL;
	string  PasswordS=NULL;
	string  InputFileNameS=NULL;
	string  OutFileNameS=NULL;
	string  RefOutFileNameS=NULL;
	string  OutputFileNameSDup=NULL;
	string  selectedVaultS=NULL;
	string  CatiaFileS=NULL;
	string  RefCatiaFileS=NULL;
	string  partrevSeq=NULL;

	char	store[2000];

	SetOfObjects  PartResultSO = NULL ;

	ObjectPtr TCPartObjP=NULL;

	SqlPtr  InputTCPartSqlPtr = NULL;

	//File Declaration
	FILE	*fp	= NULL;
	FILE	*Refp	= NULL;
	FILE	*fpInputDataFile	= NULL;
	FILE	*fperr	= NULL;
	FILE    *catiafp=NULL;
	FILE    *Refcatiafp=NULL;

	///         ///
	string		docobjst	=	NULL;
	string		DrawingFileS	=	NULL;
	int		ii		=          0;
	SetOfStrings      dbScp	=          NULL;
	t5MethodInitWMD("ContextBOMViewJTCreationBOMLevel");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	InputFileNameS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	CatiaFileS=nlsStrAlloc(200);
	selectedVaultS=nlsStrAlloc(200);
	DrawingFileS=nlsStrAlloc(200);
	partrevSeq=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	InputFileNameS=argv[3];
	OutFileNameS=argv[4];
	CatiaFileS=argv[5];
	RefOutFileNameS=argv[6];
	RefCatiaFileS=argv[7];

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

            t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
							docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	//t5CheckDstat(getDataBaseSetByUser(&dbScp,selectedVaultS,mfail));
	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}
	//////////////////////////////////////////////////////////

	/***   To Get the Input Details From Reading Input Text File ***/

	catiafp=fopen(CatiaFileS,"a+");	fflush(catiafp);
	fp=fopen(OutFileNameS,"a+");	fflush(fp);
	Refp=fopen(RefOutFileNameS,"a+");	fflush(Refp);
	Refcatiafp=fopen(RefCatiaFileS,"a+");	fflush(Refcatiafp);

	fpInputDataFile = fopen(InputFileNameS,"r");

	 while(fgets(store, NUMBER, fpInputDataFile)!=NULL)
		{
			c1  =0;
			for(i=1; i<=5 ; i++)
			{
				c2=0;
				switch(i)
				{

				   /*** Getting Part Level***/
				   case 1:
                   for(c2=0;store[c1]!='^'; c1++)
                   {
					InputDataFileS[elmt1].Level[c2]=store[c1];
					c2++;
                   }
                   InputDataFileS[elmt1].Level[c2]='\0';
				   printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[elmt1].Level);
                   break;

                   /*** Getting Part Number***/
				   case 2:
                   for(c2=0;store[c1]!='^'; c1++)
                   {
					InputDataFileS[elmt1].InpPartNumberS[c2]=store[c1];
					c2++;
                   }
                   InputDataFileS[elmt1].InpPartNumberS[c2]='\0';
				   printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[elmt1].InpPartNumberS);
                   break;

                   /*** Getting Part Revision***/

                   case 3:
                   for(;store[c1]!='^'; c1++)
                   {
                    InputDataFileS[elmt1].InpPartRevisionS[c2]=store[c1];
                    c2++;
                   }
                   InputDataFileS[elmt1].InpPartRevisionS[c2]='\0';
				   printf("\n From Data File Input Part Revision is:%s \n",InputDataFileS[elmt1].InpPartRevisionS);
                   break;

                   /*** Getting Part Sequence***/
                   case 4:
                   for(;store[c1]!='^'; c1++)
                   {
                    InputDataFileS[elmt1].InpPartSequenceS[c2]=store[c1];
                    c2++;
                   }
                   InputDataFileS[elmt1].InpPartSequenceS[c2]='\0';
				   printf("\n From Data File Input Part Sequence is:%s \n",InputDataFileS[elmt1].InpPartSequenceS);
                   break;
				}
                c1++;
			}

			 fprintf(fpInputDataFile,"\n");
			 fflush(fpInputDataFile);
			 elmt1++;
		 }

	printf("\n File Read is get completed \n");


	for(c4=0; c4<elmt1; c4++)
	{

	printf("\n Going into next loop");fflush(stdout);
	printf("\n\n\n Reading From Buffer and Processing the Line Number:%d \n\n",c4+1); fflush(stdout);
	printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[c4].InpPartNumberS); fflush(stdout);
	printf("\n From Data File Input Part Revision is:%s \n",InputDataFileS[c4].InpPartRevisionS); fflush(stdout);
	printf("\n From Data File Input Part Sequence is:%s \n",InputDataFileS[c4].InpPartSequenceS); fflush(stdout);


	//Code For Handling Assembly and Component in the Collection
	t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InputDataFileS[c4].InpPartNumberS));
	t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RevisionAttr,InputDataFileS[c4].InpPartRevisionS));
	t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,SequenceAttr,InputDataFileS[c4].InpPartSequenceS));
	t5CheckMfail(QueryWhere(PartClass,InputTCPartSqlPtr,&PartResultSO,mfail));
	printf("\nthe setsize of PartResultSO is ---->%d\n",setSize(PartResultSO));


	nlsStrCpy(partrevSeq,InputDataFileS[c4].InpPartNumberS);
	nlsStrCat(partrevSeq,",");
	nlsStrCat(partrevSeq,InputDataFileS[c4].InpPartRevisionS);
	nlsStrCat(partrevSeq,",");
	nlsStrCat(partrevSeq,InputDataFileS[c4].InpPartSequenceS);


	if(setSize(PartResultSO)==1)
	{
		TCPartObjP=setGet(PartResultSO,0);
		printf("\n Calling the Function for GetTCPartInfoForContextBOMViewJTCreationBOMLevel \n"); fflush(stdout);
		t5CheckMfail(GetTCPartInfoForContextBOMViewJTCreationBOMLevel(TCPartObjP,fp,catiafp,Refp,Refcatiafp,partrevSeq,mfail));
		printf("\n End of the Loop foor TC Assembly Or TC Component in Collection\n"); fflush(stdout);

	}
	else if(setSize(PartResultSO)>1)
	{
		printf("\n parts found woth partnumber,revision,sequence %s,%s,%s are :%d. \n",InputDataFileS[c4].InpPartNumberS,InputDataFileS[c4].InpPartRevisionS,InputDataFileS[c4].InpPartSequenceS,setSize(PartResultSO)); fflush(stdout);
		printf("\n so,This is not Possible Use Case now \n");
		//goto EXIT;
	}
	}

fclose(Refp);
fclose(fp);
fclose(catiafp);
fclose(Refcatiafp);

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);


EXIT:
		t5CheckDstatAndReturn;
}
;
