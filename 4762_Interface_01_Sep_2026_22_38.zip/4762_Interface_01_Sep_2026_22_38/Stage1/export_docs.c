/********************************************************************************************************
*  File			: exporT_docs.c
*  Created By	: Prachi Wade
*  Created On	: 15-Oct-2011
*  Project		: TCUA 	 
*  Purpose		: Custom user exit for - checkout,checkin and cancelcheckout of an item alongwith dataset
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/


#include "tc/tc_startup.h"
#include "tc/tc_macros.h"
#include "qry.h"
#include "dataset.h"
#include "tcfile.h"
#include "aom.h"
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define NUM_ENTRIES 1

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

int save_object (tag_t     object_tag)
{
    int ReturnCode;

    /*  Save the object.  */
    ReturnCode = AOM_save (object_tag);
    if (ReturnCode != ITK_ok)
    {
        printf ("ERROR %d save object.\n", ReturnCode);
        return (ReturnCode);
    }

    /* Unlock the object. */
    ReturnCode = AOM_unlock (object_tag);
    if (ReturnCode != ITK_ok)
    {
        printf ("ERROR %d unlock object.\n", ReturnCode);
    }

    return (ReturnCode);
}


int export_docs_from_teamcenter(char *destpath,tag_t project_tag)
{
	int ifail =0;
	int cnt = 0,i=0;
	char* object_name	=NULL;
	char* object_type	=NULL;
	tag_t *fld_content  =NULLTAG;
 

 AE_reference_type_t reference_type;
 tag_t    	origin_object = NULLTAG;
 char* original_file_name	=NULL;

 char *destname = NULL;
 
	TC_write_syslog("\nexport_docs_from_teamcenter\n");
	CALLAPI(AOM_ask_value_tags(project_tag,"contents",&cnt,&fld_content));
	printf("\nProject contents:%d\n",cnt);
 
    destname  = MEM_alloc(1500);
	
	if(cnt>0)
	{
			////// to be changed
		for(i=0;i<cnt;i++)
		{ 
				strcpy(destname,destpath);
 				CALLAPI(AOM_ask_value_string(fld_content[i],"object_name",&object_name));
 				CALLAPI(AOM_ask_value_string(fld_content[i],"object_type",&object_type));
			    printf("\nobject_name:%s ",object_name);
				
				if(strcmp(object_type,"MSExcel")==0)					 
				{
				  CALLAPI(AE_ask_dataset_named_ref(fld_content[i],"excel",&reference_type,&origin_object));
				  CALLAPI(AOM_ask_value_string(origin_object,"original_file_name",&original_file_name));
				  strcat(destname,original_file_name); 	
				  printf("destname:%s ",destname);
				  CALLAPI(AE_export_named_ref(fld_content[i],"excel",destname));
				  chmod(destname,0775);
				}
				if(strcmp(object_type,"MSPowerPoint")==0)					 
				{
				  CALLAPI(AE_ask_dataset_named_ref(fld_content[i],"powerpoint",&reference_type,&origin_object));
				  CALLAPI(AOM_ask_value_string(origin_object,"original_file_name",&original_file_name));
				  strcat(destname,original_file_name); 	
				  printf("destname:%s ",destname);
				  CALLAPI(AE_export_named_ref(fld_content[i],"powerpoint",destname));
				  chmod(destname,0775);
				} 				
		}
    }

 return ifail;

}


int createdir(tag_t project_tag)
{

	char *dirpath = NULL;
	char *dirname = NULL;
	char *tmpprojname = NULL;
	char *projname = NULL;
	char *buff = NULL;
	int ifail=0;
	char *proj_gate_status = NULL;

	dirpath = (char *) MEM_alloc (sizeof (char) * 1000);
	dirname = (char *) MEM_alloc (sizeof (char) * 800);
	tmpprojname = (char *) MEM_alloc (sizeof (char) * 800);
	buff = (char *) MEM_alloc (sizeof (char) * 800);
	
	TC_write_syslog("\ninside createdir\n",dirpath);
	AOM_ask_value_string(project_tag,"object_name",&projname);
	strcpy(tmpprojname,projname);
	STRNG_replace_str(tmpprojname," ", "_",&buff);
	STRNG_replace_str(buff,".", "_",&tmpprojname);
	STRNG_replace_str(tmpprojname,"*", "_",&buff);
	STRNG_replace_str(buff,"/", "_",&tmpprojname);
	STRNG_replace_str(tmpprojname,"\\", "_",&buff);
	STRNG_replace_str(buff,"@", "_",&tmpprojname);
	STRNG_replace_str(tmpprojname,",", "_",&buff);

	strcpy(dirname,buff);

	strcpy(dirpath,"/home/req83/NPIDocs/pip/");
	strcat(dirpath,dirname);
	strcat(dirpath,"/");

	printf("\ndirpath:%s\n",dirpath);
	mkdir(dirpath,0775);
	chmod(dirpath,0775);
	
	CALLAPI(AOM_ask_value_string(project_tag,"t8_Status",&proj_gate_status));
	printf("\nproj_gate_status:%s\n",proj_gate_status);

	if(strlen(proj_gate_status) > 0)
	{
		if(strstr(proj_gate_status,"DR")==NULL)
		{
			strcat(dirpath,"PI/");
		}
		else
		{
			strcat(dirpath,proj_gate_status);
			strcat(dirpath,"/");
		}
	
	}
	else
	{
			strcat(dirpath,"PI/");
	}
	printf("\ndirpath:%s\n",dirpath);
 
	mkdir(dirpath,0775);
	chmod(dirpath,0775);
	AOM_refresh (project_tag,1);
	CALLAPI(AOM_set_value_string(project_tag,"t8_DeliverablesPath",dirpath)); 		
	save_object(project_tag); 
 
	export_docs_from_teamcenter(dirpath,project_tag);
 
	return 0;


}

int ITK_user_main(int argc, char *argv[])
{
   	
	int status; 
	char *projectName = NULL; 
	char *action = NULL; 
	char	entryNamesArray[NUM_ENTRIES][QRY_uid_name_size_c+1]	= { "Name"};
	char	entryValuesArray[NUM_ENTRIES][QRY_clause_size_c+1]	= { "*"}; 
	char**	critNames = NULL;
	char**	critValues = NULL;
	int     index =0,resultCount = 0;
	int		entryCount =0;
	char**	entryNames = NULL;
	char**	entryValues = NULL;
	tag_t*	resultTags = NULLTAG;
	tag_t	queryTag	= NULLTAG;
	int ifail =0;

 
 	ITK_initialize_text_services (0);


	printf("\nAttempting auto login to Teamcenter...\n");
	if( ITK_init_module("infodba" ,"reqm83123","dba")!=ITK_ok)   PrintErrorStack();
    if( ITK_initialize_text_services( ITK_BATCH_TEXT_MODE )!=ITK_ok)   PrintErrorStack();	
	status = ITK_auto_login ();
	if (status != ITK_ok )
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL; 
		
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s) with ITK_auto_login\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("\tError #%d, %s\n", ifails[index], texts[index]);
		}
		return status;
	}
	else
	{
		projectName = MEM_alloc(150);
	    action = MEM_alloc(50);
	

		printf("\nLogin Successful.\n");
		projectName = ITK_ask_cli_argument("-i=");
	    printf("\nprojectName:%s\n",projectName);
	 
		critNames = (char**)MEM_alloc( 2 * sizeof(char*) );
		critNames[0] = (char*)MEM_alloc( 128 * sizeof(char) );
		if(critNames[0] )
			strcpy( critNames[0], entryNamesArray[0] );
  

		strcpy(entryValuesArray[0],projectName);  		
 
		critValues =(char**)MEM_alloc( 2 * sizeof(char*) );
 		critValues[0] = (char*)MEM_alloc( 128 * sizeof(char) );
			if( critValues[0] )
			strcpy( critValues[0], entryValuesArray[0] );
 
		//*********************************************
		// DISPLAY THE CRITERIA
		//*********************************************

		for( index=0; index<NUM_ENTRIES; index++ )
		{
		   printf("**************************************%s - %s\n", critNames[index], critValues[index]);fflush(stdout);
		}

		CALLAPI( QRY_find("PCBU Project", &queryTag) );
		if(queryTag != NULLTAG)
	    {

		//*********************************************
		// DISPLAY THE VALIE ENTRIES, JUST FYI
		//*********************************************

		CALLAPI( QRY_find_user_entries(queryTag, &entryCount, &entryNames, &entryValues) );
		printf("\nentryCount:%d\n", entryCount);fflush(stdout);
		for( index=0; index<entryCount; index++ )
		{
		    printf("\t\t%s - %s\n", entryNames[index], entryValues[index]);
		}

		//*********************************************
		// EXECUTE THE QUERY
		//*********************************************

			CALLAPI( QRY_execute(queryTag, entryCount, critNames, critValues, &resultCount, &resultTags) );

		} 


		printf("\nQry Result:%d\n", resultCount);fflush(stdout);
		if(resultCount > 0 )
	    {
 			createdir(resultTags[0]);
		}
		

	}
	
	ITK_exit_module(TRUE);
	
	return status; 

} 
;
 
