/********************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Aniket P. Kadu
*  Module		 :   TCUA Proe Downloader
*  Code			 :   GetTCPartInfo.c
*  Created on	 :   Jan 10, 2012
*
*
* Modification History :
* S.No		Date			Modified By     Modification Notes
*------		-----------		-------------	----------------------------------------------------------
*	1.		06.06.2015		Rupali Rane		All revision are downloaded to upload in UA for Proe only.
*	2.		16.07.2016		Rupali Rane		TC part all attributes are added.
*	3.		28.09.2016		Rupali Rane		LH/RH logic is handled.
*	4.
*
********************************************************************************************************/
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
status GetLhRhTCPartProEInfo(string InpPartNumberS, string PartNumberDupS,FILE* fpAllRev, FILE* OutJtfp,FILE* LhRHErr,integer* mfail );
status t5SortByCreationDate(SetOfObjects *itemObjs, SetOfObjects *relObjs, integer* mfail );
status GetGenTCPartProEInfo(string InpPartNumberS, string RevisionS, string SquenceS, string InstanceRevSeqS, FILE* fpAllRev, FILE* fpGen, integer* mfail );
int SetFlagforScope(SetOfObjects ScopeObjects);

SetOfStrings dbScopeStr = NULL;
SetOfStrings dbScopeBkp = NULL;

int main(int argc, char *argv[])
{
	t5MethodInitWMD("WIPAndRELVault");

	int stat=0;
	int m=0;
	int m2=0;
	int i=0;
	int j=0;
	//int k=0;
	int ii = 0;
	int noOfDocs=0;
	int flagDocPartRev=0;
	int NonStdGenericPartFlag = 0;
	//int count = 0;
	//int pi = 0;

	char *p;

	string LoginS = NULL ;
	string PasswordS = NULL ;
	string DIClassNameS = NULL ;
	string VaultNameS = NULL ;
	string OutFileNameS = NULL;
	string OutFileNmAllRev = NULL;
	string DISequenceS = NULL;
	string LhRhOutFileNames = "LhRhPartDet.txt";
	string LhRHErrPath = "LhRhErrorParts.txt";
	string GenericInstance = "GenericInstance.txt";
	string DirNmOutJtFile = NULL;

	string temp_InstGen = NULL;
	string tempInstance = NULL;
	string tempInstanceDup = NULL;
	string InstRev = NULL;
	string InstRevDup = NULL;
	string InstSeq = NULL;
	string InstSeqDup = NULL;
	string InstanceRevSeqDup = NULL;
	string tempGen = NULL;
	string tempGenDup = NULL;
	string GenRev = NULL;
	string GenRevDup = NULL;
	string GenSeqDup = NULL;
	string GenSeq = NULL;

	SetOfObjects DISO = NULL;
	SetOfObjects DIDocSO = NULL;
	SetOfObjects DIDocRelSO = NULL;
	SetOfObjects PartSO = NULL;
	SetOfObjects partMasterSO = NULL;
	SetOfObjects partMasterRelSO = NULL;
	SetOfObjects DocPartRelSO = NULL;
	SetOfObjects DocPartSO = NULL;
	SetOfObjects docObjs = NULL;
	SetOfObjects docRelObjs = NULL;
	SetOfObjects latestDocs = NULL;
	SetOfObjects latestRelDocs = NULL;
	SetOfObjects soExpObj = NULL;
	SetOfObjects relObjSet = NULL;
	SetOfObjects hasRHItmMster = NULL;
	//SetOfObjects DocumentSO = NULL;
	//SetOfObjects DocumentRelSO = NULL;
	//SetOfObjects LatestDocs = NULL;
	//SetOfObjects LatestRelDocSO = NULL;
	//SetOfObjects DocumentRefSO = NULL;
	//SetOfObjects DocumentRefRelSO = NULL;
	//SetOfObjects LatestRefDocSO = NULL;
	//SetOfObjects LatestRefRelDocSO = NULL;
	//SetOfObjects DataItemCadSO = NULL;
	//SetOfObjects ProeInstDepOnSO = NULL;
	//SetOfObjects ProeInstDepOnRelSO = NULL;
	//SetOfObjects GenDocPartSO = NULL;
	//SetOfObjects GenDocPartRelSO = NULL;
	SetOfObjects GenericSO = NULL;
	SetOfObjects InstSO = NULL;
	SetOfObjects PartSO2 = NULL;

    ///SetOfStrings dbScpe = NULL;

	ObjectPtr TCObjP = NULL ;
	ObjectPtr TCPartObjP = NULL ;
	ObjectPtr MasterObjOP = NULL ;
	ObjectPtr JTObjP = NULL ;
	ObjectPtr DocObjP = NULL ;
	ObjectPtr docOPtr = NULL ;
	ObjectPtr contextObj = NULL;
	ObjectPtr genContextObj	= NULL;
	//ObjectPtr DocCadOPtr = NULL;
	//ObjectPtr CadDataItemObjP = NULL;
	ObjectPtr GenericObjP = NULL;

	string docobjst = NULL;
	string RelativePathS = NULL;
	string RelativePathDupS = NULL;
	string ProjectCodeS = NULL;
	string ProjectCodeDupS = NULL;
	string PartNumberDupSPrev = NULL;
	string PartNumberDupS2 = NULL;
	string PartNumberS2 = NULL;
	string RevisionDupS2 = NULL;
	string RevisionS2 = NULL;
	string SequenceDupS2 = NULL;
	string SequenceS2 = NULL;
	string ReveffDateFrom = NULL;
	string ReveffDateFromDup = NULL;
	string ReveffDateTo = NULL;
	string ReveffDateToDup = NULL;
	string PartNumberDupS = NULL;
	string PartNumberS = NULL;
	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	string datasetClassS = NULL;
	string datasetClassDupS = NULL;
	string t5DocumentTypeDupS = NULL;
	string t5DocumentTypeS = NULL;
	string t5SourceDataErrorsDupS = NULL;
	string t5SourceDataErrorsS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	string LHRhPartNumber = NULL;
	string LHRhPartNumberDupS = NULL;
	string t5RightLHDupS = NULL;
	string t5RightLH = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string t5ColourIDS = NULL;
	string t5ColourIDDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	string docClass = NULL;
	string OwnerDirS = NULL;
	string level = NULL;
	string dummypart = NULL;
	string dummypart2 = NULL;
	string t5DocumentName = NULL;
	string t5DocumentNameDupS = NULL;
	string t5DocumentRev = NULL;
	string t5DocumentRevDupS = NULL;
	string t5DocumentSeq = NULL;
	string t5DocumentSeqDupS = NULL;
	string t5CMVRCertificationS = NULL;
	string t5CMVRCertificationDupS = NULL;
	string t5ClassificationHazDupS = NULL;
	string t5ClassificationHazS = NULL;
	string t5ConfigIDS = NULL;
	string t5ConfigIDDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5ListRecSparess = NULL;
	string t5ListRecSparesDups = NULL;
	string t5NcPartNoS = NULL;
	string t5PartCodeS = NULL;
	string t5NcPartNoDupS = NULL;
	string t5PartCodeDupS = NULL;
	string t5PartPropertyS = NULL;
	string t5PartPropertyDupS = NULL;
	string t5PartStatusS = NULL;
	string t5PartStatusDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PrtCatCodeS = NULL;
	string t5PrtCatCodeDupS = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5RefPartNumberS = NULL;
	string t5RefPartNumberDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SurfPrtStdS = NULL;
	string t5SurfPrtStdDupS = NULL;
	string t5SamplesToApprS = NULL;
	string t5SamplesToApprDupS = NULL;
	string t5AsmDisposalS = NULL;
	string t5AsmDisposalDupS = NULL;
	string t5FinDisposalInstrS = NULL;
	string t5FinDisposalInstrDupS = NULL;
	string t5RPDisposalInstrS = NULL;
	string t5RPDisposalInstrDupS = NULL;
	string t5SPDisposalInstrS = NULL;
	string t5SPDisposalInstrDupS = NULL;
	string t5WIPDisposalInstrS = NULL;
	string t5WIPDisposalInstrDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5CAEDocES = NULL;
	string t5CAEDocEDupS = NULL;
	string t5CoatedS = NULL;
	string t5CoatedDupS = NULL;
	string t5ConvDocS = NULL;
	string t5ConvDocDupS = NULL;
	string t5AplCopyOfErcRevS = NULL;
	string t5AplCopyOfErcRevDupS = NULL;
	string t5AplCopyOfErcSeqS = NULL;
	string t5AplCopyOfErcSeqDupS = NULL;
	string t5AppCodeS = NULL;
	string t5AppCodeDupS = NULL;
	string t5RqstNumS = NULL;
	string t5RqstNumDupS = NULL;
	string t5RsnCodeS = NULL;
	string t5RsnCodeDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5ErcIndNameS = NULL;
	string t5ErcIndNameDupS = NULL;
	string t5PostRelReqS = NULL;
	string t5PostRelReqDupS = NULL;
	string t5ItmCategoryS = NULL;
	string t5ItmCategoryDupS = NULL;
	string t5CopReqS = NULL;
	string t5CopReqDupS = NULL;
	string t5AplInvalidateS = NULL;
	string t5AplInvalidateDupS = NULL;
	string t5PrtValiStatusS = NULL;
	string t5PrtValiStatusDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5KnxtDocIndS = NULL;
	string t5KnxtDocIndDupS = NULL;
	string t5SimValS = NULL;
	string t5SimValDupS = NULL;
	string t5PerYieldS = NULL;
	string t5PerYieldDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5AltPartNoS = NULL;
	string t5AltPartNoDupS = NULL;
	string t5RolledupWtS = NULL;
	string t5RolledupWtDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string t5PFDModReqdS = NULL;
	string t5PFDModReqdDupS = NULL;
	string t5ToolIndentReqdS = NULL;
	string t5ToolIndentReqdDupS = NULL;
	string CategoryNameDupS = NULL;
	string CategoryNameS = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;
	//string docClassGen = NULL;
	//string InstanceClass = NULL;
	//string proInstDisplayNmS = NULL;
	//string proInstDisplayNmDupS = NULL;
	//string CadDIDisplayNmS = NULL;
	//string CadDIDisplayNmSDup = NULL;
	//string CadOwnerNmS = NULL;
	//string CadOwnerNmSDup = NULL;
	//string Cadwrelativepath = NULL;
	//string Cadwrelativepath1 = NULL;
	//string CadwrelativepathDupS = NULL;
	//string asmInstanceS = NULL;
	//string GenOwnerNmS = NULL;
	//string GenOwnerNmSDup = NULL;
	//string GenDocumentRev = NULL;
	//string GenDocumentRevDup = NULL;
	//string GenDocumentSeq = NULL;
	//string GenDocumentSeqDup = NULL;
	string InstanceRevSeqS = NULL;
	//string InstanceRevSeqS2 = NULL;
	string MulCadDataItem = NULL;

	//string from_date_s = NULL;
	//string to_date_s = NULL;

	FILE *fp = NULL;
	FILE *fpAllRev = NULL;
	FILE *LhRhfp = NULL;
	FILE *LhRHErr = NULL;
	FILE *OutJtfp = NULL;
	FILE *fpGen = NULL;
	FILE *fpGen2 = NULL;

	SqlPtr DISqlPtr = NULL ;
	SqlPtr PartSqlPtr = NULL ;
	SqlPtr Sql_ptr = NULL ;

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	DIClassNameS=nlsStrAlloc(200);
	VaultNameS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	DISequenceS=nlsStrAlloc(100);
	OwnerDirS=nlsStrAlloc(100);
	dummypart=nlsStrAlloc(30);
	OutFileNmAllRev=nlsStrAlloc(200);
	DirNmOutJtFile=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	DIClassNameS=argv[3];
	DISequenceS=argv[4];
	OwnerDirS=argv[5];
	VaultNameS=argv[6];
	OutFileNameS=argv[7];
	level=argv[8];
	dummypart=argv[9];
	OutFileNmAllRev=argv[10];
	DirNmOutJtFile=argv[11];

	nlsStrCat(DirNmOutJtFile , ".out.file2.jt.temp" ) ;

	printf("\n DirNmOutJtFile:%s \n",DirNmOutJtFile);
	//printf("\n OutFileNmAllRev:%s\n",OutFileNmAllRev);

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());


	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

	fp=fopen(OutFileNameS,"a+");
	fflush(fp);

	fpAllRev=fopen(OutFileNmAllRev,"a+");
	fflush(fpAllRev);

	LhRhfp=fopen(LhRhOutFileNames,"a+");
	fflush(LhRhfp);

	LhRHErr=fopen(LhRHErrPath,"a+");
    fflush(LhRHErr);

	OutJtfp=fopen(DirNmOutJtFile,"a+");
	fflush(OutJtfp);

	fpGen=fopen(GenericInstance,"a+");
	fflush(fpGen);

	fpGen2 = fopen("GarbageDataFile.log1","w");
	fflush(fpGen2);

	dbScopeStr = low_set_create_str(2);
	dbScopeBkp = low_set_create_str(2);

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	//for (ii=0;ii<setSize(dbScopeBkp) ; ii++)
	//{
	//	docobjst=low_set_get(dbScopeBkp,ii);
	//	//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	//}

	low_set_add_str_unique(dbScopeBkp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScopeBkp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	printf("\n DB pref check -after...:");fflush(stdout);
	for (ii=0;ii<low_set_size(dbScopeBkp) ; ii++)
	{
		docobjst=low_set_get(dbScopeBkp,ii);
		printf("\t[%s]",docobjst);fflush(stdout);
	}
	printf("\n\n");fflush(stdout);


	low_set_add_str_unique(dbScopeStr, "supprod");
	low_set_add_str_unique(dbScopeStr, "suhprod");
	low_set_add_str_unique(dbScopeStr, "sujprod");
	low_set_add_str_unique(dbScopeStr, "sulprod");

	
	t5CheckDstat(oiSqlCreateSelect(&DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerNameAttr,VaultNameS));
	t5CheckDstat(oiSqlWhereAND(DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,SequenceAttr,DISequenceS));
	t5CheckDstat(oiSqlWhereAND(DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,RelativePathAttr,DIClassNameS));

    if(nlsStrStr(DIClassNameS,"CATPart")!= NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
		t5CheckMfail(QueryWhere(x0CatPrtClass,DISqlPtr,&DISO,mfail));
	}
	else if(nlsStrStr(DIClassNameS,"CATProduct")!= NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
		t5CheckMfail(QueryWhere(x0CatPrdClass,DISqlPtr,&DISO,mfail));
	}
	else if(nlsStrStr(DIClassNameS,".prt.")!= NULL || nlsStrStr(DIClassNameS,".asm.")!= NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
		t5CheckMfail(QueryWhere(ProObjClass,DISqlPtr,&DISO,mfail));
	}
	else
	{
		//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
		t5CheckMfail(QueryWhere(ProInstClass,DISqlPtr,&DISO,mfail));
	}

	oiSqlPrint(DISqlPtr);
	printf("DISO objects are...:%d",setSize(DISO));fflush(stdout);

	if(setSize(DISO)==0)
	{
		//t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScopeStr,mfail));
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;

		t5CheckDstat(oiSqlCreateSelect(&DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerNameAttr,VaultNameS));
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,SequenceAttr,DISequenceS));
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,RelativePathAttr,DIClassNameS));

		if(nlsStrStr(DIClassNameS,"CATPart")!= NULL)
		{
			t5CheckDstat(oiSqlWhereAND(DISqlPtr));
			t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
			//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
			t5CheckMfail(QueryWhere(x0CatPrtClass,DISqlPtr,&DISO,mfail));
		}
		else if(nlsStrStr(DIClassNameS,"CATProduct")!= NULL)
		{
			t5CheckDstat(oiSqlWhereAND(DISqlPtr));
			t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
			//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
			t5CheckMfail(QueryWhere(x0CatPrdClass,DISqlPtr,&DISO,mfail));
		}
		else if(nlsStrStr(DIClassNameS,".prt.")!= NULL || nlsStrStr(DIClassNameS,".asm.")!= NULL)
		{
			t5CheckDstat(oiSqlWhereAND(DISqlPtr));
			t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
			//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
			t5CheckMfail(QueryWhere(ProObjClass,DISqlPtr,&DISO,mfail));
		}
		else
		{
			//t5CheckDstat(oiSqlDescOrder(DISqlPtr,CreationDateAttr));
			t5CheckMfail(QueryWhere(ProInstClass,DISqlPtr,&DISO,mfail));
		}

		oiSqlPrint(DISqlPtr);
		printf("2..DISO objects are...:%d",setSize(DISO));fflush(stdout);

		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

		if(setSize(DISO)==0)
		{
			goto EXIT;
		}
	}

	if(setSize(DISO)>0)
    {
		NonStdGenericPartFlag = 0;

		for(j=0;j<setSize(DISO);j++)
		{
			JTObjP=setGet(DISO,j);

			//JTObjP=setGet(DISO,0);

			t5CheckDstat(objGetAttribute(JTObjP,RelativePathAttr,&RelativePathS));
			RelativePathDupS=nlsStrDup(RelativePathS);
			printf("\n RelativePathDupS:%s",RelativePathDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(JTObjP,ProjectNameAttr,&ProjectCodeS));
			if(!nlsIsStrNull(ProjectCodeS))
			{
				ProjectCodeDupS=nlsStrDup(ProjectCodeS);
			}
			else
			{
				ProjectCodeDupS=nlsStrDup("");
			}
			printf("\n ProjectCodeDupS:%s ",ProjectCodeDupS); fflush(stdout);

			if ((nlsStrCmp(ProjectCodeDupS,"1111")!=0) && (nlsStrStr(DIClassNameS,"<") != NULL))
			{
				NonStdGenericPartFlag = 1;
				printf("....NonStdGenericPartFlag:%d   [ %s ]",NonStdGenericPartFlag,DIClassNameS);fflush(stdout);
			}

			t5CheckMfail(ExpandObject2(AttachClass,JTObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
			if(SetFlagforScope(DIDocSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandObject2(AttachClass,JTObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			//sort by creation date function for DIDocSO and processing for latest part rev is added on 24.07.2015
			t5CheckMfail(t5SortBOMObjsByDate(&DIDocSO,&DIDocRelSO,mfail));
			
	        printf("\n Document objects are... :%d    dummypart: %s ",setSize(DIDocSO),dummypart); fflush(stdout);

			if(setSize(DIDocSO) <= 0)
			{
				dummypart2 = nlsStrAlloc(30);

				if (nlsStrStr(dummypart,"<") != NULL)	//condition added on 10.07.2017 for case part 270254509950.prt.2
				{
					dummypart2=strtok(dummypart,"<");
				}
				else if (nlsStrStr(dummypart,".") != NULL)
				{
					dummypart2=strtok(dummypart,".");
				}
				else
				{
					goto CLEANUP;
				}

				if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
					(dstat = oiSqlWhereBegParen(Sql_ptr))||
					(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,dummypart2))||
					(dstat = oiSqlWhereEndParen(Sql_ptr))||
					(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
				if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO2,mfail)) goto EXIT;

				printf("\n In if condn....setSize(PartSO2): %d   dummypart2:%s",setSize(PartSO2),dummypart2);

				if(setSize(PartSO2)>0)
				{
					for(ii=0;ii<setSize(PartSO2);ii++)
					{
						t5CheckDstat(objGetAttribute(setGet(PartSO2,ii),RevisionAttr,&GenRev));
						GenRevDup = nlsStrDup(GenRev);

						t5CheckDstat(objGetAttribute(setGet(PartSO2,ii),SequenceAttr,&GenSeq));
						GenSeqDup = nlsStrDup(GenSeq);

						if (ii == (setSize(PartSO2)-1))
						{
							fprintf(fp,"%s",level);		//as not present in function GetGenTCPartProEInfo on 14.04.2017
							fprintf(fp,"^");
							t5CheckDstat(GetGenTCPartProEInfo(dummypart2, GenRevDup, GenSeqDup, " ", fpAllRev, fp, mfail));
						}
						else 
						{
							t5CheckDstat(GetGenTCPartProEInfo(dummypart2, GenRevDup, GenSeqDup, " ", fpAllRev, fpGen2, mfail));
						}
					}
				}
				else
				{
					fprintf(fp,"%s",level);
					fprintf(fp,"^");
					fprintf(fp,"%s",dummypart2);
					fprintf(fp,"^");
					fprintf(fp,"%s","NR");
					fprintf(fp,"^");
					fprintf(fp,"%s","1");
					fprintf(fp,"^");
					fprintf(fp,"%s","Dummy Part for Proe."); //NomenclatureDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","D");		//PartTypeDupS		// Dummy PartType
					fprintf(fp,"^");
					fprintf(fp,"%s","1111");	//ProjectNameDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","11");		//t5DesignGroupDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","-");		//mod_desc   t5DocRemarkDupS
					fprintf(fp,"^");
					fprintf(fp," ^");			//t5DrawingNoDupS			//10
					fprintf(fp,"%s","N");		//t5DrawingIndDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","NA");		//t5MatlClassDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","-");		//t5MaterialInDrwDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","-");		//MaterialThickNessDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","NA");		//t5LeftRhDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","TELPUN");	//t5DsgnOwnDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","-");		//t5ModelIndicatorDupS;
					fprintf(fp,"^");
					fprintf(fp,"%s","4");		//UnitOfMeasureDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","N");		//t5ColourIndDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","LcsSTDRlzd");//LifeCycleStateDupS		//20
					fprintf(fp,"^");
					fprintf(fp," ^");			//t5ColourIDDupS
					fprintf(fp,"%s","0");		//WeightDupS
					fprintf(fp,"^");
					fprintf(fp,"%s","-");		//SpareIndDupS
					fprintf(fp,"^");
					fprintf(fp," ^");			//t5CMVRCertification
					fprintf(fp," ^");			//t5ClassificationHaz
					fprintf(fp," ^");			//t5ConfigID
					fprintf(fp," ^");			//t5Dismantable
					fprintf(fp," ^");			//t5DsgnDeptS
					fprintf(fp," ^");			//t5EnvelopeDimen
					fprintf(fp," ^");			//t5HazardousCont			//30
					fprintf(fp," ^");			//t5HomologationReqd
					fprintf(fp," ^");			//t5ListRecSpares
					fprintf(fp," ^");			//t5NcPartNoS
					fprintf(fp," ^");			//t5PartCodeS
					fprintf(fp," ^");			//t5PartPropertyS
					fprintf(fp," ^");			//t5PartStatusS
					fprintf(fp," ^");			//t5PkgStdS
					fprintf(fp," ^");			//t5ProductS
					fprintf(fp," ^");			//t5PrtCatCodeS
					fprintf(fp," ^");			//t5PunIntialAgS			//40
					fprintf(fp," ^");			//t5PunMakeBuyIndS
					fprintf(fp," ^");			//t5RecoverableS
					fprintf(fp," ^");			//t5RecyclabilityS
					fprintf(fp," ^");			//t5RefPartNumberS
					fprintf(fp," ^");			//t5ReliabilityS
					fprintf(fp," ^");			//t5SpareCriteriaS
					fprintf(fp," ^");			//t5SurfPrtStdS
					fprintf(fp," ^");			//t5SamplesToApprS
					fprintf(fp," ^");			//t5AsmDisposalS
					fprintf(fp," ^");			//t5FinDisposalInstrS		//50
					fprintf(fp," ^");			//t5RPDisposalInstrS
					fprintf(fp," ^");			//t5SPDisposalInstrS
					fprintf(fp," ^");			//t5WIPDisposalInstrS
					fprintf(fp,"loader^");		//t5LastModByS
					fprintf(fp," ^");			//t5VerCreatorS
					fprintf(fp," ^");			//t5CAEDocES

					fprintf(fp,"%s","N");		//t5CoatedS
					fprintf(fp,"^");

					fprintf(fp," ^");			//t5ConvDocS
					fprintf(fp," ^");			//t5AplCopyOfErcRevS
					fprintf(fp," ^");			//t5AplCopyOfErcSeqS		//60
					fprintf(fp," ^");			//t5AppCodeS
					fprintf(fp," ^");			//t5RqstNumS
					fprintf(fp," ^");			//t5RsnCodeS
					fprintf(fp," ^");			//t5SurfaceAreaS
					fprintf(fp," ^");			//t5VolumeS
					fprintf(fp," ^");			//t5CarIntialAgencyS
					fprintf(fp," ^");			//t5CarMakeBuyIndiS
					fprintf(fp," ^");			//t5ErcIndNameS
					fprintf(fp," ^");			//t5PostRelReqS
					fprintf(fp," ^");			//t5ItmCategoryS			//70
					fprintf(fp," ^");			//t5CopReqS
					fprintf(fp," ^");			//t5AplInvalidateS
					fprintf(fp," ^");			//t5PrtValiStatusS
					fprintf(fp," ^");			//t5DRSubStateS
					fprintf(fp," ^");			//t5KnxtDocIndS
					fprintf(fp," ^");			//t5SimValS
					fprintf(fp," ^");			//t5PerYieldS
					fprintf(fp," ^");			//t5PunStoreLocationS
					fprintf(fp," ^");			//t5AltPartNoS
					fprintf(fp," ^");			//t5RolledupWtS				//80
					fprintf(fp," ^");			//t5PFDModReqdS
					fprintf(fp," ^");			//t5ToolIndentReqdS
					fprintf(fp," ^");			//CategoryNameS
					fprintf(fp,"-^");			//ReveffDateFromDup
					fprintf(fp,"-^");			//ReveffDateToDup			//85
					fprintf(fp,"NA^");			//LeftRhPartDup				//86

					fprintf(fp," ^");			//Instance with semicolon separated Rev;Seq		//87

					fprintf(fp," ^");			//t5JsrIntialAgencyS		//88
					fprintf(fp," ^");			//t5JsrMakeBuyIndiS			//89
					fprintf(fp," ^");			//t5LkoIntialAgencyS		//90
					fprintf(fp," ^");			//t5LkoMakeBuyIndiS			//91
					fprintf(fp," ^");			//t5PnrIntialAgencyS		//92
					fprintf(fp," ^");			//t5PnrMakeBuyIndiS			//93
					fprintf(fp," ^");			//t5PunPCBUIntialAgencyS	//94
					fprintf(fp," ^");			//t5PunPCBUMakeBuyIndiS		//95
					fprintf(fp," ^");			//t5SgrIntialAgencyS		//96
					fprintf(fp," ^");			//t5SgrMakeBuyIndiS			//97
					fprintf(fp," ^");			//t5EstSheetReqdS			//98 
					fprintf(fp,"-^");			//PartCreDateDupS			//99 
					fprintf(fp,"-^");			//PartModDateDupS			//100
					fprintf(fp,"loader^");		//PartCreatorDup			//101
					fprintf(fp," ^");			//t5AhdIntialAgencySDup		//102
					fprintf(fp," ^");			//t5AhdMakeBuyIndSDup		//103
					fprintf(fp," ^");			//t5DwdIntialAgencySDup		//104
					fprintf(fp," ^");			//t5DwdMakeBuyIndSDup		//105
					fprintf(fp," ^");			//t5JdlIntialAgencySDup		//106
					fprintf(fp," ^");			//t5JdlMakeBuyIndSDup		//107
					fprintf(fp," ^");			//t5AhdStoreLocSDup			//108
					fprintf(fp," ^");			//t5CarStoreLocSDup			//109
					fprintf(fp," ^");			//t5DwdStoreLocSDup			//110
					fprintf(fp," ^");			//t5JdlStoreLocSDup			//111
					fprintf(fp," ^");			//t5JsrStoreLocSDup			//112
					fprintf(fp," ^");			//t5LkoStoreLocSDup			//113
					fprintf(fp," ^");			//t5PnrStoreLocSDup			//114
					fprintf(fp," ^");			//t5PunPCBUStoreLocSDup		//115
					fprintf(fp," ^");			//t5SgrStoreLocSDup			//116

					fprintf(fp,"\n"); fflush(fp);

/*					//Below fpAllRev is added on 22.10.2016
					fprintf(fpAllRev,"%s",dummypart2);
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","NR");
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","1");
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","Dummy Part for Proe."); //NomenclatureDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","D");		//PartTypeDupS		// Dummy PartType
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","1111");	//ProjectNameDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","11");		//t5DesignGroupDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","-");		//mod_desc   t5DocRemarkDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev," ^");			//t5DrawingNoDupS
					fprintf(fpAllRev,"%s","N");		//t5DrawingIndDupS			//10
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","NA");		//t5MatlClassDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","-");		//t5MaterialInDrwDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","-");		//MaterialThickNessDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","NA");		//t5LeftRhDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","TELPUN");	//t5DsgnOwnDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","-");		//t5ModelIndicatorDupS;
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","4");		//UnitOfMeasureDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","N");		//t5ColourIndDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","LcsSTDRlzd");//LifeCycleStateDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev," ^");			//t5ColourIDDupS		//20
					fprintf(fpAllRev,"%s","0");		//WeightDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev,"%s","-");		//SpareIndDupS
					fprintf(fpAllRev,"^");
					fprintf(fpAllRev," ^");			//t5CMVRCertification
					fprintf(fpAllRev," ^");			//t5ClassificationHaz
					fprintf(fpAllRev," ^");			//t5ConfigID
					fprintf(fpAllRev," ^");			//t5Dismantable
					fprintf(fpAllRev," ^");			//t5DsgnDeptS
					fprintf(fpAllRev," ^");			//t5EnvelopeDimen
					fprintf(fpAllRev," ^");			//t5HazardousCont	
					fprintf(fpAllRev," ^");			//t5HomologationReqd		//30
					fprintf(fpAllRev," ^");			//t5ListRecSpares
					fprintf(fpAllRev," ^");			//t5NcPartNoS
					fprintf(fpAllRev," ^");			//t5PartCodeS
					fprintf(fpAllRev," ^");			//t5PartPropertyS
					fprintf(fpAllRev," ^");			//t5PartStatusS
					fprintf(fpAllRev," ^");			//t5PkgStdS
					fprintf(fpAllRev," ^");			//t5ProductS
					fprintf(fpAllRev," ^");			//t5PrtCatCodeS
					fprintf(fpAllRev," ^");			//t5PunIntialAgS	
					fprintf(fpAllRev," ^");			//t5PunMakeBuyIndS			//40
					fprintf(fpAllRev," ^");			//t5RecoverableS
					fprintf(fpAllRev," ^");			//t5RecyclabilityS
					fprintf(fpAllRev," ^");			//t5RefPartNumberS
					fprintf(fpAllRev," ^");			//t5ReliabilityS
					fprintf(fpAllRev," ^");			//t5SpareCriteriaS
					fprintf(fpAllRev," ^");			//t5SurfPrtStdS
					fprintf(fpAllRev," ^");			//t5SamplesToApprS
					fprintf(fpAllRev," ^");			//t5AsmDisposalS
					fprintf(fpAllRev," ^");			//t5FinDisposalInstrS
					fprintf(fpAllRev," ^");			//t5RPDisposalInstrS		//50
					fprintf(fpAllRev," ^");			//t5SPDisposalInstrS
					fprintf(fpAllRev," ^");			//t5WIPDisposalInstrS
					fprintf(fpAllRev,"loader^");	//t5LastModByS				//53
					fprintf(fpAllRev," ^");			//t5VerCreatorS
					fprintf(fpAllRev," ^");			//t5CAEDocES

					fprintf(fpAllRev,"%s","N");		//t5CoatedS
					fprintf(fpAllRev,"^");

					fprintf(fpAllRev," ^");			//t5ConvDocS
					fprintf(fpAllRev," ^");			//t5AplCopyOfErcRevS
					fprintf(fpAllRev," ^");			//t5AplCopyOfErcSeqS
					fprintf(fpAllRev," ^");			//t5AppCodeS				//60
					fprintf(fpAllRev," ^");			//t5RqstNumS
					fprintf(fpAllRev," ^");			//t5RsnCodeS
					fprintf(fpAllRev," ^");			//t5SurfaceAreaS
					fprintf(fpAllRev," ^");			//t5VolumeS
					fprintf(fpAllRev," ^");			//t5CarIntialAgencyS
					fprintf(fpAllRev," ^");			//t5CarMakeBuyIndiS
					fprintf(fpAllRev," ^");			//t5ErcIndNameS
					fprintf(fpAllRev," ^");			//t5PostRelReqS
					fprintf(fpAllRev," ^");			//t5ItmCategoryS
					fprintf(fpAllRev," ^");			//t5CopReqS					//70
					fprintf(fpAllRev," ^");			//t5AplInvalidateS
					fprintf(fpAllRev," ^");			//t5PrtValiStatusS
					fprintf(fpAllRev," ^");			//t5DRSubStateS
					fprintf(fpAllRev," ^");			//t5KnxtDocIndS
					fprintf(fpAllRev," ^");			//t5SimValS
					fprintf(fpAllRev," ^");			//t5PerYieldS
					fprintf(fpAllRev," ^");			//t5PunStoreLocationS
					fprintf(fpAllRev," ^");			//t5AltPartNoS
					fprintf(fpAllRev," ^");			//t5RolledupWtS
					fprintf(fpAllRev," ^");			//t5PFDModReqdS				//80
					fprintf(fpAllRev," ^");			//t5ToolIndentReqdS
					fprintf(fpAllRev," ^");			//CategoryNameS
					fprintf(fpAllRev,"-^");			//ReveffDateFromDup
					fprintf(fpAllRev,"-^");			//ReveffDateToDup			//84
					fprintf(fpAllRev,"NA^");		//LeftRhPartDup				//85
					fprintf(fpAllRev," ^");			//Instance with semicolon separated Rev;Seq		//86
					fprintf(fpAllRev," ^");			//t5JsrIntialAgencyS		//87
					fprintf(fpAllRev," ^");			//t5JsrMakeBuyIndiS			//88
					fprintf(fpAllRev," ^");			//t5LkoIntialAgencyS		//99
					fprintf(fpAllRev," ^");			//t5LkoMakeBuyIndiS			//90
					fprintf(fpAllRev," ^");			//t5PnrIntialAgencyS		//91
					fprintf(fpAllRev," ^");			//t5PnrMakeBuyIndiS			//92
					fprintf(fpAllRev," ^");			//t5PunPCBUIntialAgencyS	//93
					fprintf(fpAllRev," ^");			//t5PunPCBUMakeBuyIndiS		//94
					fprintf(fpAllRev," ^");			//t5SgrIntialAgencyS		//95
					fprintf(fpAllRev," ^");			//t5SgrMakeBuyIndiS			//96
					fprintf(fpAllRev," ^");			//t5EstSheetReqdS			//97
					fprintf(fpAllRev,"-^");			//PartCreDateDupS			//98
					fprintf(fpAllRev,"-^");			//PartModDateDupS			//99
					fprintf(fpAllRev,"loader^");	//PartCreatorDup			//100
					fprintf(fpAllRev," ^");			//t5AhdIntialAgencySDup		//101
					fprintf(fpAllRev," ^");			//t5AhdMakeBuyIndSDup		//102
					fprintf(fpAllRev," ^");			//t5DwdIntialAgencySDup		//103
					fprintf(fpAllRev," ^");			//t5DwdMakeBuyIndSDup		//104
					fprintf(fpAllRev," ^");			//t5JdlIntialAgencySDup		//105
					fprintf(fpAllRev," ^");			//t5JdlMakeBuyIndSDup		//106
					fprintf(fpAllRev," ^");			//t5AhdStoreLocSDup			//107
					fprintf(fpAllRev," ^");			//t5CarStoreLocSDup			//108
					fprintf(fpAllRev," ^");			//t5DwdStoreLocSDup			//109
					fprintf(fpAllRev," ^");			//t5JdlStoreLocSDup			//110
					fprintf(fpAllRev," ^");			//t5JsrStoreLocSDup			//111
					fprintf(fpAllRev," ^");			//t5LkoStoreLocSDup			//112
					fprintf(fpAllRev," ^");			//t5PnrStoreLocSDup			//113
					fprintf(fpAllRev," ^");			//t5PunPCBUStoreLocSDup		//114
					fprintf(fpAllRev," ^");			//t5SgrStoreLocSDup			//115

					fprintf(fpAllRev,"\n"); fflush(fpAllRev);
*/
				}

				goto CLEANUP;
			}

			if(setSize(DIDocSO)>0)
			{
				//for(k=0;k<setSize(DIDocSO);k++)	// commented on 24.07.2015
				//{
					//DocObjP=setGet(DIDocSO,k);
					DocObjP=setGet(DIDocSO,0);

					t5CheckDstat(objGetAttribute(DocObjP,"Class",&datasetClassDupS));
					if(!nlsIsStrNull(datasetClassDupS))
					{
						datasetClassS=nlsStrDup(datasetClassDupS);
					}
					printf("\n  datasetClassS:%s",datasetClassS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,t5DocumentType1Attr,&t5DocumentTypeS));
					if(!nlsIsStrNull(t5DocumentTypeS))
					{
						t5DocumentTypeDupS=nlsStrDup(t5DocumentTypeS);
					}
					else
					{
						t5DocumentTypeDupS=nlsStrDup(" ");
					}
					printf("\n  t5DocumentTypeDupS:%s",t5DocumentTypeDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,DocumentNameAttr,&t5DocumentName));
					t5DocumentNameDupS=nlsStrDup(t5DocumentName);
					printf("\n  t5DocumentNameDupS:%s",t5DocumentNameDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,RevisionAttr,&t5DocumentRev));
					if(!nlsIsStrNull(t5DocumentRev))
					{
						t5DocumentRevDupS=nlsStrDup(t5DocumentRev);
					}
					else
					{
						t5DocumentRevDupS=nlsStrDup(" ");
					}
					printf("\n  t5DocumentRevDupS:%s",t5DocumentRevDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,SequenceAttr,&t5DocumentSeq));
					if(!nlsIsStrNull(t5DocumentSeq))
					{
						t5DocumentSeqDupS=nlsStrDup(t5DocumentSeq);
					}
					else
					{
						t5DocumentSeqDupS=nlsStrDup(" ");
					}
					printf("\n  t5DocumentSeqDupS:%s",t5DocumentSeqDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,t5SourceDataErrorsAttr,&t5SourceDataErrorsS));
					if(!nlsIsStrNull(t5SourceDataErrorsS))
					{
						t5SourceDataErrorsDupS=nlsStrDup(t5SourceDataErrorsS);
					}
					else
					{
						t5SourceDataErrorsDupS=nlsStrDup(" ");
					}
					printf("\n  t5SourceDataErrorsDupS:%s",t5SourceDataErrorsDupS); fflush(stdout);

					t5CheckMfail(ExpandObject2(PartDocClass,DocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
					if(SetFlagforScope(DocPartSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						t5CheckMfail(ExpandObject2(PartDocClass,DocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					printf("\n  Part objects:%d",setSize(DocPartSO));fflush(stdout);

					if(setSize(DocPartSO)>0)
					{
						for(i=0;i<setSize(DocPartSO);i++)
						{
							TCObjP=setGet(DocPartSO,i);

							t5CheckDstat(objGetAttribute(TCObjP,PartNumberAttr,&PartNumberS2));
							PartNumberDupS2=nlsStrDup(PartNumberS2);

							t5CheckDstat(objGetAttribute(TCObjP,RevisionAttr,&RevisionS2));
							RevisionDupS2=nlsStrDup(RevisionS2);

							t5CheckDstat(objGetAttribute(TCObjP,SequenceAttr,&SequenceS2));
							SequenceDupS2=nlsStrDup(SequenceS2);
							printf("\n\nAttached TCPartNumberDupS2:%s,%s,%s",PartNumberDupS2,RevisionDupS2,SequenceDupS2); fflush(stdout);

							if(i > 0)
							{
								PartNumberDupSPrev=nlsStrDup(PartNumberS2);
								if (nlsStrCmp(PartNumberDupSPrev,PartNumberDupS2) == 0)
								{
									continue;
								}
							}

                            /*if(nlsStrCmp(t5DocumentNameDupS,PartNumberDupS2) == 0 && nlsStrCmp(t5DocumentRevDupS,RevisionDupS2) == 0 && nlsStrCmp(t5DocumentSeqDupS,SequenceDupS2) == 0  || setSize(DocPartSO) == 1)
							{
                       			printf("\n **************matching DOC and parts rev");
							}else {
							printf("\n ************** Not matching DOC and parts rev");
							continue;
							}*/

							/*if((nlsStrCmp(t5DocumentNameDupS,PartNumberDupS2) == 0 && nlsStrCmp(t5DocumentRevDupS,RevisionDupS2) == 0 && nlsStrCmp(t5DocumentSeqDupS,SequenceDupS2) == 0)  || setSize(DocPartSO) == 1 )
							{
								printf("\n **************matching DOC and parts rev");
							}
							else if((setSize(DocPartSO) > 1) && (setSize(DocPartSO)-1) == i)
							{
								printf("\n ************else**matching DOC and parts rev");
							}
							else
							{
								printf("\n ************** Not matching DOC and parts rev");
								continue;
							}*/

							printf("\n **************Querying all revisions of part");

							/*t5CheckDstat(oiSqlCreateSelect(&PartSqlPtr));
							t5CheckDstat(oiSqlWhereEQ(PartSqlPtr,PartNumberAttr,PartNumberDupS2));
							t5CheckDstat(oiSqlAscOrder(PartSqlPtr,CreationDateAttr));
							t5CheckMfail(QueryWhere(PartClass,PartSqlPtr,&PartSO,mfail));
							//oiSqlPrint(PartSqlPtr);
							printf("\n PartSO objects:%d",setSize(PartSO));fflush(stdout);

							if(setSize(PartSO) == 0)
							{*/
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								t5CheckDstat(oiSqlCreateSelect(&PartSqlPtr));
								t5CheckDstat(oiSqlWhereEQ(PartSqlPtr,PartNumberAttr,PartNumberDupS2));
								t5CheckDstat(oiSqlAscOrder(PartSqlPtr,CreationDateAttr));
								t5CheckMfail(QueryWhere(PartClass,PartSqlPtr,&PartSO,mfail));
								//oiSqlPrint(PartSqlPtr);
								//printf("\n Re-querying to all DB..PartSO objects: %d ",setSize(PartSO));fflush(stdout);
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							/*}*/
							printf("\n PartSO objects:%d",setSize(PartSO));fflush(stdout);

							if(setSize(PartSO)>0)
							{
								for(m=0;m<setSize(PartSO);m++)
								{
									TCPartObjP=setGet(PartSO,m);

									if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
									if(SetFlagforScope(partMasterSO)==1)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
									}
									if (setSize(partMasterSO)>0)
									{
										MasterObjOP=setGet(partMasterSO,0);
									}

									t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberS));
									PartNumberDupS=nlsStrDup(PartNumberS);
									//printf("\n\n\t TCPartNumberDupS:%s",PartNumberDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&RevisionS));
									RevisionDupS=nlsStrDup(RevisionS);
									//printf("\n\t TCRevisionDupS :%s",RevisionDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&SequenceS));
									SequenceDupS=nlsStrDup(SequenceS);
									//printf("\n\t Sequence:%s",SequenceDupS); fflush(stdout);

									//printf("\n\n\t m:[%d]   1.TCPartNumberDupS:%s , %s , %s",m,PartNumberDupS,RevisionDupS,SequenceDupS); fflush(stdout);

									InstanceRevSeqS = nlsStrAlloc(100);
									nlsStrCpy(InstanceRevSeqS,PartNumberDupS);
									nlsStrCat(InstanceRevSeqS,";");
									nlsStrCat(InstanceRevSeqS,RevisionDupS);
									nlsStrCat(InstanceRevSeqS,";");
									nlsStrCat(InstanceRevSeqS,SequenceDupS);

									if (nlsStrCmp(datasetClassS,"t5MulCad")==0)		// added on 24.10.2016
									{
										MulCadDataItem = nlsStrAlloc(30);

										nlsStrCpy(MulCadDataItem,PartNumberDupS);
										nlsStrCat(MulCadDataItem,"_");
										nlsStrCat(MulCadDataItem,RevisionDupS);
										nlsStrCat(MulCadDataItem,"_");
										nlsStrCat(MulCadDataItem,SequenceDupS);

										printf("   ---MulCadDataItem :%s",MulCadDataItem); fflush(stdout);
									}

									t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&NomenclatureS));
									if(!nlsIsStrNull(NomenclatureS))
									{
										NomenclatureDupS=nlsStrDup(NomenclatureS);
										NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
									}
									else
									{
										NomenclatureDupS=nlsStrDup("-");
									}
									//printf("\n\t 1.NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeS));
									PartTypeDupS=nlsStrDup(PartTypeS);
									//printf("\n\t 1.PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&OwnerNameS));
									OwnerNameDupS=nlsStrDup(OwnerNameS);
									//printf("\n\t 1.OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);

									if(nlsStrStr(OwnerNameDupS,"Vault") == NULL)
									{
										//printf("\t ...this rev-seq not in Vault hence skipping from download...\n");  fflush(stdout);
										continue;
									}

									t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectNameS));
									ProjectNameDupS=nlsStrDup(ProjectNameS);
									//printf("\n\t 1.ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&t5DesignGroupS));
									if(!nlsIsStrNull(t5DesignGroupS))
									{
										t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
									}
									else
									{
										t5DesignGroupDupS=nlsStrDup(" ");
									}
									//printf("\n\t 1.t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
									if(!nlsIsStrNull(t5DocRemarkS))
									{
										t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
									}
									else
									{
										t5DocRemarkDupS=nlsStrDup("-");
									}
									t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
									//printf("\n\t 1.t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
									t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
									//printf("\n\t 1.t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

									if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
									{
										docClass = low_getspace(20);

										if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
										if(SetFlagforScope(docObjs)==1)
										{
											if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
											if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
											if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
										}
										if(setSize(docObjs) <= 0)
										{
											if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
											if(SetFlagforScope(docObjs)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}
										}
										if(setSize(docObjs) > 0)
										{
											if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
											if (setSize(latestDocs)>0)
											{
												for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
												{
													docOPtr = setGet(latestDocs, noOfDocs);
													if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
													if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
													{
														//Document Number = Drawing Document Number
														if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
														if(!nlsIsStrNull(t5DrawingNo))
														{
															t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
														}
														else
														{
															t5DrawingNoDupS = nlsStrDup(" ");
														}
													}
												}
											}
										}

										if(nlsIsStrNull(t5DrawingNoDupS))
										{
											if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
											if(SetFlagforScope(docObjs)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}

											if(setSize(docObjs) > 0)
											{
												if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
												if (setSize(latestDocs)>0)
												{
													for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
													{
														docOPtr = setGet(latestDocs, noOfDocs);
														if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
														printf("\n\t ...51..%s",docClass);
														if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
														{
															//Document Number = Drawing Document Number
															if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
															if(!nlsIsStrNull(t5DrawingNo))
															{
																t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
															}
															else
															{
																t5DrawingNoDupS = nlsStrDup(" ");
															}
														}
													}
												}
											}
										}

										if(nlsIsStrNull(t5DrawingNo))
										{
											t5DrawingNoDupS = nlsStrDup(" ");
										}
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup(" ");
									}
									//printf("\n\t 1.t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&t5MatlClassS));
									if(!nlsIsStrNull(t5MatlClassS))
									{
										t5MatlClassDupS=nlsStrDup(t5MatlClassS);
									}
									else
									{
										t5MatlClassDupS=nlsStrDup("NA");
									}
									t5MatlClassDupS=low_strssra(t5MatlClassDupS,"\n"," ");
									//printf("\n\t 1.t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&t5MaterialInDrwS));
									if(!nlsIsStrNull(t5MaterialInDrwS))
									{
										t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
									}
									else
									{
										t5MaterialInDrwDupS=nlsStrDup(" ");
									}
									t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"\n"," ");
									//printf("\n\t 1.t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessS));
									if(!nlsIsStrNull(MaterialThickNessS))
									{
										MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
									}
									else
									{
										MaterialThickNessDupS=nlsStrDup(" ");
									}
									//printf("\n\t 1.MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

									//t5CheckDstat(objGetAttribute(TCPartObjP,t5UQdupAttr,&UnitOfMeasureS));
									//if(!nlsIsStrNull(UnitOfMeasureS))
									//{
									//	UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
									//}
									//else
									//{
									//	UnitOfMeasureDupS=nlsStrDup("4");
									//}
									////printf("\n\t 1.UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

									//t5CheckDstat(objGetAttribute(TCPartObjP,t5LeftRhAttr,&t5LeftRhS));
									if (setSize(partMasterSO)>0)
									{
										t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureS));
										if(!nlsIsStrNull(UnitOfMeasureS))
										{
											UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
										}
										else
										{
											UnitOfMeasureDupS=nlsStrDup("4");
										}

										t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&t5LeftRhS));
										if(!nlsIsStrNull(t5LeftRhS))
										{
											t5LeftRhDupS=nlsStrDup(t5LeftRhS);
										}
										else
										{
											t5LeftRhDupS=nlsStrDup("NA");
										}
										if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
										{
											if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
											if(SetFlagforScope(hasRHItmMster)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}
											if (setSize(hasRHItmMster)>0)
											{
												t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
												if(!nlsIsStrNull(LHRhPartNumber))
												{
													LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
												}
												else
												{
													LHRhPartNumberDupS=nlsStrDup("NA");
												}
											}
										}
										if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
										{
											if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
											if(SetFlagforScope(hasRHItmMster)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}
											if (setSize(hasRHItmMster)>0)
											{
												t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
												if(!nlsIsStrNull(LHRhPartNumber))
												{
													LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
												}
												else
												{
													LHRhPartNumberDupS=nlsStrDup("NA");
												}
											}
										}
										if (setSize(hasRHItmMster)>0)
										{
											t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),t5LeftRhAttr,&t5RightLH));
											if(!nlsIsStrNull(t5RightLH))
											{
												t5RightLHDupS=nlsStrDup(t5RightLH);
											}
											else
											{
												t5RightLHDupS=nlsStrDup("NA");
											}
											//fprintf(LhRhfp,"%s,%s,%s,%s,\n",t5LeftRhDupS,PartNumberDupS,t5RightLHDupS,LHRhPartNumberDupS);

											fprintf(LhRhfp,"%s",t5LeftRhDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"%s",PartNumberDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"%s",t5RightLHDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"%s",LHRhPartNumberDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"%s",RevisionDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"%s",SequenceDupS);
											fprintf(LhRhfp,"^");
											fprintf(LhRhfp,"\n");
											fflush(LhRhfp);

										}
										else
										{
											if(setSize(hasRHItmMster) <= 0)
											{
												//printf("\n\t 1.*****%s  setSize(hasRHItmMster):%d  Right relation not found..",t5LeftRhDupS,setSize(hasRHItmMster)); fflush(stdout);
												fprintf(LhRHErr,"\n *****%s  setSize(hasRHItmMster):%d  Right relation not found..",t5LeftRhDupS,setSize(hasRHItmMster)); fflush(LhRHErr);

												LHRhPartNumberDupS=nlsStrDup("NA");
												t5RightLHDupS=nlsStrDup("NA");
											}
										}
										//printf("\n\t 1.**LHRhPartNumberDupS: %s    t5RightLHDupS: %s",LHRhPartNumberDupS,t5RightLHDupS);fflush(stdout);
									}
									else
									{
										t5LeftRhDupS=nlsStrDup("NA");
										UnitOfMeasureDupS=nlsStrDup("4");
									}

									//printf("\n\t 1.UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);
									//printf("\n\t 1.t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
									if(!nlsIsStrNull(t5DsgnOwnS))
									{
										t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
									}
									else
									{
										t5DsgnOwnDupS=nlsStrDup("TELPUN");
									}
									//printf("\n\t 1.t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
									if(!nlsIsStrNull(t5ModelIndicatorS))
									{
										t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
									}
									else
									{
										t5ModelIndicatorDupS=nlsStrDup(" ");
									}
									//printf("\n\t 1.t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&t5ColourIndS));
									if(!nlsIsStrNull(t5ColourIndS))
									{
										t5ColourIndDupS=nlsStrDup(t5ColourIndS);
									}
									else
									{
										t5ColourIndDupS=nlsStrDup("N");
									}
									//printf("\n\t 1.t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDS));
									if(!nlsIsStrNull(t5ColourIDS))
									{
										t5ColourIDDupS=nlsStrDup(t5ColourIDS);
									}
									else
									{
										t5ColourIDDupS=nlsStrDup(" ");
									}
									//printf("\n\t 1.t5ColourIDDupS:%s",t5ColourIDDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateS));
									if(!nlsIsStrNull(LifeCycleStateS))
									{
										LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
									}
									else
									{
										LifeCycleStateDupS=nlsStrDup("LcsReview");
									}
									//printf("\n\t 1.LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightS));
									if(!nlsIsStrNull(WeightS))
									{
										WeightDupS=nlsStrDup(WeightS);
									}
									else
									{
										WeightDupS=nlsStrDup("0");
									}
									//printf("\n\t 1.WeightDupS:%s",WeightDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,t5SpareIndAttr,&SpareIndS));
									if(!nlsIsStrNull(SpareIndS))
									{
										SpareIndDupS=nlsStrDup(SpareIndS);
									}
									else
									{
										SpareIndDupS=nlsStrDup(" ");
									}
									//printf("\n\t 1.SpareIndDupS:%s",SpareIndDupS); fflush(stdout);


									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
									t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
									//printf("\n\t 1.t5CMVRCertificationS:%s",t5CMVRCertificationS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
									t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
									//printf("\n\t 1.t5ClassificationHazS:%s",t5ClassificationHazS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
									t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
									//printf("\n\t 1.t5ConfigIDS:%s",t5ConfigIDS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
									t5DismantableS=nlsStrDup(t5DismantableDupS);
									//printf("\n\t 1.t5DismantableS:%s",t5DismantableS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
									t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
									//printf("\n\t 1.t5DsgnDeptS:%s",t5DsgnDeptS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
									t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
									//printf("\n\t 1.t5EnvelopeDimenS:%s",t5EnvelopeDimenS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
									t5HazardousContS=nlsStrDup(t5HazardousContDupS);
									//printf("\n\t 1.t5HazardousContS:%s",t5HazardousContS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
									t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
									//printf("\n\t 1.t5HomologationReqdS:%s",t5HomologationReqdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
									t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
									//printf("\n\t 1.t5ListRecSparess:%s",t5ListRecSparess); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
									t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
									//printf("\n\t 1.t5NcPartNoS:%s",t5NcPartNoS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
									t5PartCodeS=nlsStrDup(t5PartCodeDupS);
									//printf("\n\t 1.t5PartCodeS:%s",t5PartCodeS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
									t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
									//printf("\n\t 1.t5PartPropertyS:%s",t5PartPropertyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
									t5PartStatusS=nlsStrDup(t5PartStatusDupS);
									//printf("\n\t 1.t5PartStatusS:%s",t5PartStatusS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
									t5PkgStdS=nlsStrDup(t5PkgStdDupS);
									//printf("\n\t 1.t5PkgStdS:%s",t5PkgStdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
									t5ProductS=nlsStrDup(t5ProductDupS);
									//printf("\n\t 1.t5ProductS:%s",t5ProductS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
									t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
									//printf("\n\t 1.t5PrtCatCodeS:%s",t5PrtCatCodeS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
									t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
									//printf("\n\t 1.t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
									t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
									//printf("\n\t 1.t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
									t5RecoverableS=nlsStrDup(t5RecoverableDupS);
									//printf("\n\t 1.t5RecoverableS:%s",t5RecoverableS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
									t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
									//printf("\n\t 1.t5RecyclabilityS:%s",t5RecyclabilityS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
									t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
									//printf("\n\t 1.t5RefPartNumberS:%s",t5RefPartNumberS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
									t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
									//printf("\n\t 1.t5ReliabilityS:%s",t5ReliabilityS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
									t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
									t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"\n"," ");
									t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"^"," ");
									//printf("\n\t 1.t5SpareCriteriaS:%s",t5SpareCriteriaS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
									t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
									//printf("\n\t 1.t5SurfPrtStdS:%s",t5SurfPrtStdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
									t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
									//printf("\n\t 1.t5SamplesToApprS:%s",t5SamplesToApprS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
									t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
									//printf("\n\t 1.t5AsmDisposalS:%s",t5AsmDisposalS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
									t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
									//printf("\n\t 1.t5FinDisposalInstrS:%s",t5FinDisposalInstrS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
									t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
									//printf("\n\t 1.t5RPDisposalInstrS:%s",t5RPDisposalInstrS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
									t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
									//printf("\n\t 1.t5SPDisposalInstrS:%s",t5SPDisposalInstrS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
									t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
									//printf("\n\t 1.t5WIPDisposalInstrS:%s",t5WIPDisposalInstrS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
									t5LastModByS=nlsStrDup(t5LastModByDupS);
									//printf("\n\t 1.t5LastModByS:%s",t5LastModByS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
									t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
									//printf("\n\t 1.t5VerCreatorS:%s",t5VerCreatorS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
									t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
									//printf("\n\t 1.t5CAEDocES:%s",t5CAEDocES); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
									t5CoatedS=nlsStrDup(t5CoatedDupS);
									//printf("\n\t 1.t5CoatedS:%s",t5CoatedS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
									t5ConvDocS=nlsStrDup(t5ConvDocDupS);
									//printf("\n\t 1.t5ConvDocS:%s",t5ConvDocS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
									t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
									//printf("\n\t 1.t5AplCopyOfErcRevS:%s",t5AplCopyOfErcRevS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
									t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
									//printf("\n\t 1.t5AplCopyOfErcSeqS:%s",t5AplCopyOfErcSeqS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
									if(!nlsIsStrNull(t5AppCodeDupS))
									{
										t5AppCodeS=nlsStrDup(t5AppCodeDupS);
									}else {	t5AppCodeS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5AppCodeS:%s",t5AppCodeS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
									if(!nlsIsStrNull(t5RqstNumDupS))
									{
										t5RqstNumS=nlsStrDup(t5RqstNumDupS);
									}else {	t5RqstNumS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5RqstNumS:%s",t5RqstNumS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
									if(!nlsIsStrNull(t5RsnCodeDupS))
									{
										t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
									}else {	t5RsnCodeS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5RsnCodeS:%s",t5RsnCodeS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
									if(!nlsIsStrNull(t5SurfaceAreaDupS))
									{
										t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
									}else {	t5SurfaceAreaS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5SurfaceAreaS:%s",t5SurfaceAreaS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
									if(!nlsIsStrNull(t5VolumeDupS))
									{
										t5VolumeS=nlsStrDup(t5VolumeDupS);
									}else {	t5VolumeS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5VolumeS:%s",t5VolumeS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
									if(!nlsIsStrNull(t5CarIntialAgencyDupS))
									{
										t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
									}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
									if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
									{
										t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
									}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
									if(!nlsIsStrNull(t5ErcIndNameDupS))
									{
										t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
									}else {	t5ErcIndNameS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5ErcIndNameS:%s",t5ErcIndNameS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
									if(!nlsIsStrNull(t5PostRelReqDupS))
									{
										t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
									}else {	t5PostRelReqS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5PostRelReqS:%s",t5PostRelReqS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
									if(!nlsIsStrNull(t5ItmCategoryDupS))
									{
										t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
									}else {	t5ItmCategoryS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5ItmCategoryS:%s",t5ItmCategoryS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
									if(!nlsIsStrNull(t5CopReqDupS))
									{
										t5CopReqS=nlsStrDup(t5CopReqDupS);
									}else {	t5CopReqS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5CopReqS:%s",t5CopReqS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
									if(!nlsIsStrNull(t5AplInvalidateDupS))
									{
										t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
									}else {	t5AplInvalidateS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5AplInvalidateS:%s",t5AplInvalidateS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
									if(!nlsIsStrNull(t5PrtValiStatusDupS))
									{
										t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
									}else {	t5PrtValiStatusS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5PrtValiStatusS:%s",t5PrtValiStatusS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
									if(!nlsIsStrNull(t5DRSubStateDupS))
									{
										t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
									}else {	t5DRSubStateS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5DRSubStateS:%s",t5DRSubStateS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
									if(!nlsIsStrNull(t5KnxtDocIndDupS))
									{
										t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
									}else {	t5KnxtDocIndS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5KnxtDocIndS:%s",t5KnxtDocIndS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
									if(!nlsIsStrNull(t5SimValDupS))
									{
										t5SimValS=nlsStrDup(t5SimValDupS);
										t5SimValS=low_strssra(t5SimValS,"\n"," ");
									}else {	t5SimValS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5SimValS:%s",t5SimValS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
									if(!nlsIsStrNull(t5PerYieldDupS))
									{
										t5PerYieldS=nlsStrDup(t5PerYieldDupS);
									}else {	t5PerYieldS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5PerYieldS:%s",t5PerYieldS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
									if(!nlsIsStrNull(t5PunStoreLocationDupS))
									{
										t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
									}else {	t5PunStoreLocationS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5PunStoreLocationS:%s",t5PunStoreLocationS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
									if(!nlsIsStrNull(t5AltPartNoDupS))
									{
										t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
										//t5AltPartNoS=low_strssra(t5AltPartNoS,"\n"," ");
									}else {	t5AltPartNoS=nlsStrDup(" ");	}
									//printf("\n\t 1.t5AltPartNoS:%s",t5AltPartNoS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
									t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
									//printf("\n\t 1.t5RolledupWtS:%s",t5RolledupWtS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
									t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
									//printf("\n\t 1.t5PFDModReqdS:%s",t5PFDModReqdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
									t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
									//printf("\n\t 1.t5ToolIndentReqdS:%s",t5ToolIndentReqdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
									if(!nlsIsStrNull(CategoryNameDupS))
									{
										CategoryNameS=nlsStrDup(CategoryNameDupS);
										CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
										CategoryNameS=low_strssra(CategoryNameS,"^"," ");
									}else {	CategoryNameS=nlsStrDup(" ");	}
									//printf("\n\t 1.CategoryNameS:%s",CategoryNameS); fflush(stdout);

									// For effectivity extract - ERC
									t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
									// Get the configuration context object from the general context.
									t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
									// Set the option as "LkoCtxt" in the context object
									t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
									t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
									t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
									t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
									//printf("\n\t 1.  setSize(soExpObj):%d ",setSize(soExpObj)); fflush(stdout);
									if(setSize(soExpObj)>0)
									{
										if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
										if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;
										if(!nlsIsStrNull(ReveffDateFrom))
										{
											ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
										}
										else
										{
											ReveffDateFromDup = nlsStrDup(ReveffDateTo);
										}

										if(!nlsIsStrNull(ReveffDateTo))
										{
											ReveffDateToDup = nlsStrDup(ReveffDateTo);
										}
										else
										{
											ReveffDateToDup = nlsStrDup(ReveffDateFrom);
										}
									}
									else
									{
										ReveffDateFromDup = nlsStrDup("-");
										ReveffDateToDup = nlsStrDup("-");
									}

									//printf("\n\t 1.ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
									//printf("\n\t 1.ReveffDateToDup:%s ",ReveffDateToDup); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
									t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
									//printf("\n\t 1.t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
									t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
									//printf("\n\t 1.t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
									t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
									//printf("\n\t 1.t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
									t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
									//printf("\n\t 1.t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
									t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
									//printf("\n\t 1.t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
									t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
									//printf("\n\t 1.t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
									t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
									//printf("\n\t 1.t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
									t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
									//printf("\n\t 1.t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
									t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
									//printf("\n\t 1.t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
									t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
									//printf("\n\t 1.t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
									t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
									//printf("\n\t 1.t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"CreationDate",&PartCreDateS));
									if(!nlsIsStrNull(PartCreDateS))
									{
										PartCreDateDupS=nlsStrDup(PartCreDateS);
									}
									else
									{
										PartCreDateDupS=nlsStrDup("-");
									}
									//printf("\n\t 1.PartCreDateDupS:%s",PartCreDateDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"LastUpdate",&PartModDateS));
									if(!nlsIsStrNull(PartModDateS))
									{
										PartModDateDupS=nlsStrDup(PartModDateS);
									}
									else
									{
										PartModDateDupS=nlsStrDup("-");
									}
									//printf("\n\t 1.PartModDateDupS:%s",PartModDateDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"Creator",&PartCreator));
									if(!nlsIsStrNull(PartCreator))
									{
										PartCreatorDup=nlsStrDup(PartCreator);
									}
									else
									{
										PartCreatorDup=nlsStrDup("loader");
									}
									//printf("\n\t 1.PartCreatorDup: %s",PartCreatorDup); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
									if(!nlsIsStrNull(t5AhdIntialAgencyS))
									{
										t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
									}
									else
									{
										t5AhdIntialAgencySDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
									if(!nlsIsStrNull(t5AhdMakeBuyIndS))
									{
										t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
									}
									else
									{
										t5AhdMakeBuyIndSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
									if(!nlsIsStrNull(t5DwdIntialAgencyS))
									{
										t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
									}
									else
									{
										t5DwdIntialAgencySDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
									if(!nlsIsStrNull(t5DwdMakeBuyIndS))
									{
										t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
									}
									else
									{
										t5DwdMakeBuyIndSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
									if(!nlsIsStrNull(t5JdlIntialAgencyS))
									{
										t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
									}
									else
									{
										t5JdlIntialAgencySDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
									if(!nlsIsStrNull(t5JdlMakeBuyIndS))
									{
										t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
									}
									else
									{
										t5JdlMakeBuyIndSDup = nlsStrDup("");
									}

									t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
									if(!nlsIsStrNull(t5AhdStoreLocS))
									{
										t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
									}
									else
									{
										t5AhdStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarStoreLocation",&t5CarStoreLocS));
									if(!nlsIsStrNull(t5CarStoreLocS))
									{
										t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
									}
									else
									{
										t5CarStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
									if(!nlsIsStrNull(t5DwdStoreLocS))
									{
										t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
									}
									else
									{
										t5DwdStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
									if(!nlsIsStrNull(t5JdlStoreLocS))
									{
										t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
									}
									else
									{
										t5JdlStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
									if(!nlsIsStrNull(t5JsrStoreLocS))
									{
										t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
									}
									else
									{
										t5JsrStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
									if(!nlsIsStrNull(t5LkoStoreLocS))
									{
										t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
									}
									else
									{
										t5LkoStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
									if(!nlsIsStrNull(t5PnrStoreLocS))
									{
										t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
									}
									else
									{
										t5PnrStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
									if(!nlsIsStrNull(t5PunPCBUStoreLocS))
									{
										t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
									}
									else
									{
										t5PunPCBUStoreLocSDup = nlsStrDup("");
									}
									t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
									if(!nlsIsStrNull(t5SgrStoreLocS))
									{
										t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
									}
									else
									{
										t5SgrStoreLocSDup = nlsStrDup("");
									}
									
									if (m == (setSize(PartSO)-1))	// LH/RH is added on 28.09.2016 by RRR
									{
										if ((setSize(partMasterSO)>0) && ((nlsStrCmp(t5LeftRhDupS,"NA")!=0) && (!nlsIsStrNull(t5LeftRhDupS))))
										{
											if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
											{
												if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
												if(SetFlagforScope(hasRHItmMster)==1)
												{
													if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
													if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
													if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
												}
												if (setSize(hasRHItmMster)>0)
												{
													t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
													if(!nlsIsStrNull(LHRhPartNumber))
													{
														LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
													}
													else
													{
														LHRhPartNumberDupS=nlsStrDup("NA");
													}
												}
											}
											if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
											{
												if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
												if(SetFlagforScope(hasRHItmMster)==1)
												{
													if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
													if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
													if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
												}
												if (setSize(hasRHItmMster)>0)
												{
													t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
													if(!nlsIsStrNull(LHRhPartNumber))
													{
														LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
													}
													else
													{
														LHRhPartNumberDupS=nlsStrDup("NA");
													}
												}
											}
											/*if (setSize(hasRHItmMster)>0)
											{
												t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),t5LeftRhAttr,&t5RightLH));
												if(!nlsIsStrNull(t5RightLH))
												{
													t5RightLHDupS=nlsStrDup(t5RightLH);
												}
												else
												{
													t5RightLHDupS=nlsStrDup("NA");
												}
												//fprintf(LhRhfp,"%s,%s,%s,%s,\n",t5LeftRhDupS,PartNumberDupS,t5RightLHDupS,LHRhPartNumberDupS);

												//fprintf(LhRhfp,"%s",t5LeftRhDupS);
												//fprintf(LhRhfp,"^");
												//fprintf(LhRhfp,"%s",PartNumberDupS);
												//fprintf(LhRhfp,"^");
												//fprintf(LhRhfp,"%s",t5RightLHDupS);
												//fprintf(LhRhfp,"^");
												//fprintf(LhRhfp,"%s",LHRhPartNumberDupS);
												//fprintf(LhRhfp,"^");
												//fprintf(LhRhfp,"\n");
												//fflush(LhRhfp);
											}
											else
											{*/
												if(setSize(hasRHItmMster) <= 0)
												{
													printf("\n *****%s  setSize(hasRHItmMster):%d  Right relation not found",t5LeftRhDupS,setSize(hasRHItmMster)); fflush(stdout);
													fprintf(LhRHErr,"\n *****%s  setSize(hasRHItmMster):%d  Right relation not found",t5LeftRhDupS,setSize(hasRHItmMster)); fflush(LhRHErr);
												}
											//}
											//printf("\n\t 1.**LHRhPartNumberDupS: %s    t5RightLHDupS: %s",LHRhPartNumberDupS,t5RightLHDupS);fflush(stdout);

											//query part again to get all attributes to copy in allpartsAllRev file

											/*if((nlsStrCmp(LHRhPartNumberDupS,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDupS)))
											{
												t5CheckMfail(GetLhRhTCPartProEInfo(LHRhPartNumberDupS,PartNumberDupS,fpAllRev,OutJtfp,LhRHErr,mfail));
											}*/
										}
									}

									//(nlsStrCmp(datasetClassS,"DesDoc")==0)
									//if((nlsStrCmp(PartNumberDupS,PartNumberDupS2)==0) && (nlsStrCmp(RevisionDupS,t5DocumentRevDupS)==0) && (nlsStrCmp(SequenceDupS,t5DocumentSeqDupS)==0))
									//if((nlsStrCmp(PartNumberDupS,PartNumberDupS2)==0) && (((nlsStrCmp(datasetClassS,"DesDoc")==0) && (nlsStrCmp(RevisionDupS,t5DocumentRevDupS)==0) && (nlsStrCmp(SequenceDupS,t5DocumentSeqDupS)==0)) || ((nlsStrCmp(datasetClassS,"t5MulCad")==0) && (nlsStrCmp(MulCadDataItem,t5DocumentNameDupS)==0))))  //condn modified on 24.10.2016 if converted doc attched found (544246606501,B,2)
									if((nlsStrCmp(PartNumberDupS,PartNumberDupS2)==0) && (((nlsStrCmp(datasetClassS,"DesDoc")==0) && (nlsStrCmp(RevisionDupS,RevisionDupS2)==0) && (nlsStrCmp(SequenceDupS,SequenceDupS2)==0)) || ((nlsStrCmp(datasetClassS,"t5MulCad")==0) && (nlsStrCmp(MulCadDataItem,t5DocumentNameDupS)==0))))  //condn modified on 17.01.2017  for RevisionDupS2/SequenceDupS2 instead of t5DocumentRevDupS/t5DocumentSeqDupS
									{
										printf("\n\n\t m:[%d]   1.TCPartNumberDupS:%s , %s , %s",m,PartNumberDupS,RevisionDupS,SequenceDupS); fflush(stdout);

										flagDocPartRev =1;

										fprintf(fp,"%s",level);						//1		//In main
										fprintf(fp,"^");
										fprintf(fp,"%s",PartNumberDupS);			//2
										fprintf(fp,"^");
										fprintf(fp,"%s",RevisionDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",SequenceDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",NomenclatureDupS);			//desc
										fprintf(fp,"^");
										fprintf(fp,"%s",PartTypeDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",ProjectNameDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DesignGroupDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DocRemarkDupS);			//mod_desc
										fprintf(fp,"^");

										if(!nlsIsStrNull(t5DrawingNoDupS)){
											fprintf(fp,"%s",t5DrawingNoDupS);		//10		//In main
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										fprintf(fp,"%s",t5DrawingIndDupS);			 //11
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MatlClassDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MaterialInDrwDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",MaterialThickNessDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5LeftRhDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DsgnOwnDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ModelIndicatorDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",UnitOfMeasureDupS);			//18
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIndDupS);			//19
										fprintf(fp,"^");
										fprintf(fp,"%s",LifeCycleStateDupS);		//20		//In main
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIDDupS);			//21
										fprintf(fp,"^");
										fprintf(fp,"%s",WeightDupS);				//22
										fprintf(fp,"^");
										fprintf(fp,"%s",SpareIndDupS);				//23
										fprintf(fp,"^");

										if(!nlsIsStrNull(t5CMVRCertificationS)){
											fprintf(fp,"%s",t5CMVRCertificationS);	//24
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ClassificationHazS)){
											fprintf(fp,"%s",t5ClassificationHazS);	//25
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ConfigIDS)){
											fprintf(fp,"%s",t5ConfigIDS);			//26
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5DismantableS)){
											fprintf(fp,"%s",t5DismantableS);		//27
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5DsgnDeptS)){
											fprintf(fp,"%s",t5DsgnDeptS);			//28
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5EnvelopeDimenS)){
											fprintf(fp,"%s",t5EnvelopeDimenS);		//29
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5HazardousContS)){
											fprintf(fp,"%s",t5HazardousContS);		//30		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5HomologationReqdS)){
											fprintf(fp,"%s",t5HomologationReqdS);	//31
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ListRecSparess)){
											fprintf(fp,"%s",t5ListRecSparess);		//32
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5NcPartNoS)){
											fprintf(fp,"%s",t5NcPartNoS);			//33
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartCodeS)){
											fprintf(fp,"%s",t5PartCodeS);			//34
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartPropertyS)){
											fprintf(fp,"%s",t5PartPropertyS);		//35
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartStatusS)){
											fprintf(fp,"%s",t5PartStatusS);			//36
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5PkgStdS)){
											fprintf(fp,"%s",t5PkgStdS);				//37
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ProductS)){
											fprintf(fp,"%s",t5ProductS);			//38
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PrtCatCodeS)){
											fprintf(fp,"%s",t5PrtCatCodeS);			//39
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunIntialAgS)){
											fprintf(fp,"%s",t5PunIntialAgS);		//40		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunMakeBuyIndS)){
											fprintf(fp,"%s",t5PunMakeBuyIndS);		//41
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RecoverableS)){
											fprintf(fp,"%s",t5RecoverableS);		//42
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RecyclabilityS)){
											fprintf(fp,"%s",t5RecyclabilityS);		//43
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RefPartNumberS)){
											fprintf(fp,"%s",t5RefPartNumberS);		//44
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ReliabilityS)){
											fprintf(fp,"%s",t5ReliabilityS);		//45
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SpareCriteriaS)){
											fprintf(fp,"%s",t5SpareCriteriaS);		//46
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SurfPrtStdS)){
											fprintf(fp,"%s",t5SurfPrtStdS);			//47
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SamplesToApprS)){
											fprintf(fp,"%s",t5SamplesToApprS);		//48
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AsmDisposalS)){
											fprintf(fp,"%s",t5AsmDisposalS);		//49
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5FinDisposalInstrS)){
											fprintf(fp,"%s",t5FinDisposalInstrS);	//50		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RPDisposalInstrS)){
											fprintf(fp,"%s",t5RPDisposalInstrS);	//51
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SPDisposalInstrS)){
											fprintf(fp,"%s",t5SPDisposalInstrS);	//52
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5WIPDisposalInstrS)){
											fprintf(fp,"%s",t5WIPDisposalInstrS);	//53
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5LastModByS)){
											fprintf(fp,"%s",t5LastModByS);			//54
											fprintf(fp,"^");
										}else
										{
											fprintf(fp,"loader^");
										}


										if(!nlsIsStrNull(t5VerCreatorS)){
											fprintf(fp,"%s",t5VerCreatorS);			//55
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CAEDocES)){
											fprintf(fp,"%s",t5CAEDocES);			//56
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5CoatedS)){
											fprintf(fp,"%s",t5CoatedS);				//57
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5ConvDocS)){
											fprintf(fp,"%s",t5ConvDocS);			//58
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
											fprintf(fp,"%s",t5AplCopyOfErcRevS);	//59
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
											fprintf(fp,"%s",t5AplCopyOfErcSeqS);	//60		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AppCodeS)){
											fprintf(fp,"%s",t5AppCodeS);			//61
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RqstNumS)){
											fprintf(fp,"%s",t5RqstNumS);			//62
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RsnCodeS)){
											fprintf(fp,"%s",t5RsnCodeS);			//63
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SurfaceAreaS)){
											fprintf(fp,"%s",t5SurfaceAreaS);		//64
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5VolumeS)){
											fprintf(fp,"%s",t5VolumeS);				//65
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CarIntialAgencyS)){
											fprintf(fp,"%s",t5CarIntialAgencyS);	//66
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
											fprintf(fp,"%s",t5CarMakeBuyIndiS);		//67
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ErcIndNameS)){
											fprintf(fp,"%s",t5ErcIndNameS);			//68
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PostRelReqS)){
											fprintf(fp,"%s",t5PostRelReqS);			//69
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ItmCategoryS)){
											fprintf(fp,"%s",t5ItmCategoryS);		//70		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CopReqS)){
											fprintf(fp,"%s",t5CopReqS);				//71
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AplInvalidateS)){
											fprintf(fp,"%s",t5AplInvalidateS);		//72
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PrtValiStatusS)){
											fprintf(fp,"%s",t5PrtValiStatusS);		//73
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5DRSubStateS)){
											fprintf(fp,"%s",t5DRSubStateS);			//74
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5KnxtDocIndS)){
											fprintf(fp,"%s",t5KnxtDocIndS);			//75
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5SimValS)){
											fprintf(fp,"%s",t5SimValS);				//76
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PerYieldS)){
											fprintf(fp,"%s",t5PerYieldS);			//77
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunStoreLocationS)){
											fprintf(fp,"%s",t5PunStoreLocationS);	//78
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AltPartNoS)){
											fprintf(fp,"%s",t5AltPartNoS);			//79
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5RolledupWtS)){
											fprintf(fp,"%s",t5RolledupWtS);			//80		//In main
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5PFDModReqdS)){
											fprintf(fp,"%s",t5PFDModReqdS);			//81
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ToolIndentReqdS)){
											fprintf(fp,"%s",t5ToolIndentReqdS);		//82
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(CategoryNameS)){
											fprintf(fp,"%s",CategoryNameS);			//83
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(ReveffDateFromDup))
										{
											fprintf(fp,"%s",ReveffDateFromDup);		//84
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(ReveffDateToDup))
										{
											fprintf(fp,"%s",ReveffDateToDup);		//85
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										//if(!nlsIsStrNull(t5RightLHDupS))
										//{
										//	fprintf(fp,"%s",t5RightLHDupS);		//86
										//	fprintf(fp,"^");
										//}
										//else
										//{
										//	fprintf(fp," ^");
										//}
										if(!nlsIsStrNull(LHRhPartNumberDupS))
										{
											fprintf(fp,"%s",LHRhPartNumberDupS);		//86
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"NA^");
										}

										fprintf(fp," ^");	//Instance with semicolon separated Rev;Seq		//87

										//below attributes are added by rrr on 14.10.2016
										if(!nlsIsStrNull(t5JsrIntialAgencyS))
										{
											fprintf(fp,"%s",t5JsrIntialAgencyS);		//88
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5JsrMakeBuyIndiS);			//89
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5LkoIntialAgencyS))
										{
											fprintf(fp,"%s",t5LkoIntialAgencyS);		//90		//In main
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5LkoMakeBuyIndiS);			//91
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PnrIntialAgencyS))
										{
											fprintf(fp,"%s",t5PnrIntialAgencyS);		//92
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5PnrMakeBuyIndiS);			//93
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
										{
											fprintf(fp,"%s",t5PunPCBUIntialAgencyS);	//94
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5PunPCBUMakeBuyIndiS);		//95
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5SgrIntialAgencyS))
										{
											fprintf(fp,"%s",t5SgrIntialAgencyS);		//96
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5SgrMakeBuyIndiS);			//97
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5EstSheetReqdS))
										{
											fprintf(fp,"%s",t5EstSheetReqdS);			//98
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(PartCreDateDupS))
										{
											fprintf(fp,"%s",PartCreDateDupS);			//99
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"-^");
										}

										if(!nlsIsStrNull(PartModDateDupS))
										{
											fprintf(fp,"%s",PartModDateDupS);			//100		//In main
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"-^");
										}

										if(!nlsIsStrNull(PartCreatorDup))
										{
											fprintf(fp,"%s",PartCreatorDup);			//101
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"loader^");
										}
										if(!nlsIsStrNull(t5AhdIntialAgencySDup))
										{
											fprintf(fp,"%s",t5AhdIntialAgencySDup);		//102
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
										{
											fprintf(fp,"%s",t5AhdMakeBuyIndSDup);		//103
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5DwdIntialAgencySDup))
										{
											fprintf(fp,"%s",t5DwdIntialAgencySDup);		//104
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
										{
											fprintf(fp,"%s",t5DwdMakeBuyIndSDup);		//105
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JdlIntialAgencySDup))
										{
											fprintf(fp,"%s",t5JdlIntialAgencySDup);		//106
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
										{
											fprintf(fp,"%s",t5JdlMakeBuyIndSDup);		//107
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5AhdStoreLocSDup))
										{
											fprintf(fp,"%s",t5AhdStoreLocSDup);			//108
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5CarStoreLocSDup))
										{
											fprintf(fp,"%s",t5CarStoreLocSDup);			//109
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5DwdStoreLocSDup))
										{
											fprintf(fp,"%s",t5DwdStoreLocSDup);			//110		//In main
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JdlStoreLocSDup))
										{
											fprintf(fp,"%s",t5JdlStoreLocSDup);			//111
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JsrStoreLocSDup))
										{
											fprintf(fp,"%s",t5JsrStoreLocSDup);			//112
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5LkoStoreLocSDup))
										{
											fprintf(fp,"%s",t5LkoStoreLocSDup);			//113
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PnrStoreLocSDup))
										{
											fprintf(fp,"%s",t5PnrStoreLocSDup);			//114
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
										{
											fprintf(fp,"%s",t5PunPCBUStoreLocSDup);		//115
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5SgrStoreLocSDup))
										{
											fprintf(fp,"%s",t5SgrStoreLocSDup);			//116		//In main
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										fprintf(fp,"\n");
										fflush(fp);
								    	printf("\n Inside fp --------------------------121  \n"); fflush(stdout);
										fflush(fp);
									}
									else if (((setSize(PartSO)-1) == m) && (flagDocPartRev == 0))
									{
										printf("\n\n\t m:::[%d]   1.TCPartNumberDupS:%s , %s , %s",m,PartNumberDupS,RevisionDupS,SequenceDupS); fflush(stdout);

										fprintf(fp,"%s",level);
										fprintf(fp,"^");
										fprintf(fp,"%s",PartNumberDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",RevisionDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",SequenceDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",NomenclatureDupS); //desc
										fprintf(fp,"^");
										fprintf(fp,"%s",PartTypeDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",ProjectNameDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DesignGroupDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DocRemarkDupS); //mod_desc
										fprintf(fp,"^");

										if(!nlsIsStrNull(t5DrawingNoDupS)){
											fprintf(fp,"%s",t5DrawingNoDupS);		//10		//In main else if
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										fprintf(fp,"%s",t5DrawingIndDupS);			//11
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MatlClassDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MaterialInDrwDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",MaterialThickNessDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5LeftRhDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DsgnOwnDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ModelIndicatorDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",UnitOfMeasureDupS);			//18
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIndDupS);			//19
										fprintf(fp,"^");
										fprintf(fp,"%s",LifeCycleStateDupS);		//20		//In main else if
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIDDupS);			//21
										fprintf(fp,"^");
										fprintf(fp,"%s",WeightDupS);				//22
										fprintf(fp,"^");
										fprintf(fp,"%s",SpareIndDupS);				//23
										fprintf(fp,"^");

										if(!nlsIsStrNull(t5CMVRCertificationS)){
											fprintf(fp,"%s",t5CMVRCertificationS);	//24
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ClassificationHazS)){
											fprintf(fp,"%s",t5ClassificationHazS);	//25
											fprintf(fp,"^");
										}else {
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ConfigIDS)){
											fprintf(fp,"%s",t5ConfigIDS);			//26
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5DismantableS)){
											fprintf(fp,"%s",t5DismantableS);		//27
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5DsgnDeptS)){
											fprintf(fp,"%s",t5DsgnDeptS);			//28
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5EnvelopeDimenS)){
											fprintf(fp,"%s",t5EnvelopeDimenS);		//29
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5HazardousContS)){
											fprintf(fp,"%s",t5HazardousContS);		//30		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5HomologationReqdS)){
											fprintf(fp,"%s",t5HomologationReqdS);	//31
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ListRecSparess)){
											fprintf(fp,"%s",t5ListRecSparess);		//32
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5NcPartNoS)){
											fprintf(fp,"%s",t5NcPartNoS);			//33
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartCodeS)){
											fprintf(fp,"%s",t5PartCodeS);			//34
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartPropertyS)){
											fprintf(fp,"%s",t5PartPropertyS);		//35
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PartStatusS)){
											fprintf(fp,"%s",t5PartStatusS);			//36
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5PkgStdS)){
											fprintf(fp,"%s",t5PkgStdS);				//37
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ProductS)){
											fprintf(fp,"%s",t5ProductS);			//38
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PrtCatCodeS)){
											fprintf(fp,"%s",t5PrtCatCodeS);			//39
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunIntialAgS)){
											fprintf(fp,"%s",t5PunIntialAgS);		//40		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunMakeBuyIndS)){
											fprintf(fp,"%s",t5PunMakeBuyIndS);		//41
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RecoverableS)){
											fprintf(fp,"%s",t5RecoverableS);		//42
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RecyclabilityS)){
											fprintf(fp,"%s",t5RecyclabilityS);		//43
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RefPartNumberS)){
											fprintf(fp,"%s",t5RefPartNumberS);		//44
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ReliabilityS)){
											fprintf(fp,"%s",t5ReliabilityS);		//45
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SpareCriteriaS)){
											fprintf(fp,"%s",t5SpareCriteriaS);		//46
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SurfPrtStdS)){
											fprintf(fp,"%s",t5SurfPrtStdS);			//47
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SamplesToApprS)){
											fprintf(fp,"%s",t5SamplesToApprS);		//48
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AsmDisposalS)){
											fprintf(fp,"%s",t5AsmDisposalS);		//49
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5FinDisposalInstrS)){
											fprintf(fp,"%s",t5FinDisposalInstrS);	//50		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RPDisposalInstrS)){
											fprintf(fp,"%s",t5RPDisposalInstrS);	//51
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SPDisposalInstrS)){
											fprintf(fp,"%s",t5SPDisposalInstrS);	//52
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5WIPDisposalInstrS)){
											fprintf(fp,"%s",t5WIPDisposalInstrS);	//53
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5LastModByS)){
											fprintf(fp,"%s",t5LastModByS);			//54
											fprintf(fp,"^");
										}else
										{
											fprintf(fp,"loader^");
										}


										if(!nlsIsStrNull(t5VerCreatorS)){
											fprintf(fp,"%s",t5VerCreatorS);			//55
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CAEDocES)){
											fprintf(fp,"%s",t5CAEDocES);			//56
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5CoatedS)){
											fprintf(fp,"%s",t5CoatedS);				//57
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5ConvDocS)){
											fprintf(fp,"%s",t5ConvDocS);			//58
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
											fprintf(fp,"%s",t5AplCopyOfErcRevS);	//59
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
											fprintf(fp,"%s",t5AplCopyOfErcSeqS);	//60		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AppCodeS)){
											fprintf(fp,"%s",t5AppCodeS);			//61
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RqstNumS)){
											fprintf(fp,"%s",t5RqstNumS);			//62
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5RsnCodeS)){
											fprintf(fp,"%s",t5RsnCodeS);			//63
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5SurfaceAreaS)){
											fprintf(fp,"%s",t5SurfaceAreaS);		//64
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5VolumeS)){
											fprintf(fp,"%s",t5VolumeS);				//65
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CarIntialAgencyS)){
											fprintf(fp,"%s",t5CarIntialAgencyS);	//66
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
											fprintf(fp,"%s",t5CarMakeBuyIndiS);		//67
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ErcIndNameS)){
											fprintf(fp,"%s",t5ErcIndNameS);			//68
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PostRelReqS)){
											fprintf(fp,"%s",t5PostRelReqS);			//69
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ItmCategoryS)){
											fprintf(fp,"%s",t5ItmCategoryS);		//70		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5CopReqS)){
											fprintf(fp,"%s",t5CopReqS);				//71
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AplInvalidateS)){
											fprintf(fp,"%s",t5AplInvalidateS);		//72
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PrtValiStatusS)){
											fprintf(fp,"%s",t5PrtValiStatusS);		//73
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5DRSubStateS)){
											fprintf(fp,"%s",t5DRSubStateS);			//74
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5KnxtDocIndS)){
											fprintf(fp,"%s",t5KnxtDocIndS);			//75
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5SimValS)){
											fprintf(fp,"%s",t5SimValS);				//76
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PerYieldS)){
											fprintf(fp,"%s",t5PerYieldS);			//77
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5PunStoreLocationS)){
											fprintf(fp,"%s",t5PunStoreLocationS);	//78
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5AltPartNoS)){
											fprintf(fp,"%s",t5AltPartNoS);			//79
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5RolledupWtS)){
											fprintf(fp,"%s",t5RolledupWtS);			//80		//In main else if
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(t5PFDModReqdS)){
											fprintf(fp,"%s",t5PFDModReqdS);			//81
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(t5ToolIndentReqdS)){
											fprintf(fp,"%s",t5ToolIndentReqdS);		//82
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(CategoryNameS)){
											fprintf(fp,"%s",CategoryNameS);			//83
											fprintf(fp,"^");
										}else
										{
											fprintf(fp," ^");
										}


										if(!nlsIsStrNull(ReveffDateFromDup))
										{
											fprintf(fp,"%s",ReveffDateFromDup);		//84
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(ReveffDateToDup))
										{
											fprintf(fp,"%s",ReveffDateToDup);		//85
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										//if(!nlsIsStrNull(t5RightLHDupS))
										//{
										//	fprintf(fp,"%s",t5RightLHDupS);		//86
										//	fprintf(fp,"^");
										//}
										//else
										//{
										//	fprintf(fp," ^");
										//}
										if(!nlsIsStrNull(LHRhPartNumberDupS))
										{
											fprintf(fp,"%s",LHRhPartNumberDupS);		//86
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"NA^");
										}

										fprintf(fp," ^");	//Instance with semicolon separated Rev;Seq		//87

										//below attributes are added by rrr on 14.10.2016
										if(!nlsIsStrNull(t5JsrIntialAgencyS))
										{
											fprintf(fp,"%s",t5JsrIntialAgencyS);		//88
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5JsrMakeBuyIndiS);			//89
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5LkoIntialAgencyS))
										{
											fprintf(fp,"%s",t5LkoIntialAgencyS);		//90		//In main else if
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5LkoMakeBuyIndiS);			//91
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PnrIntialAgencyS))
										{
											fprintf(fp,"%s",t5PnrIntialAgencyS);		//92
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5PnrMakeBuyIndiS);			//93
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
										{
											fprintf(fp,"%s",t5PunPCBUIntialAgencyS);	//94
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5PunPCBUMakeBuyIndiS);		//95
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5SgrIntialAgencyS))
										{
											fprintf(fp,"%s",t5SgrIntialAgencyS);		//96
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
										{
											fprintf(fp,"%s",t5SgrMakeBuyIndiS);			//97
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										if(!nlsIsStrNull(t5EstSheetReqdS))
										{
											fprintf(fp,"%s",t5EstSheetReqdS);			//98
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}

										if(!nlsIsStrNull(PartCreDateDupS))
										{
											fprintf(fp,"%s",PartCreDateDupS);			//99
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"-^");
										}

										if(!nlsIsStrNull(PartModDateDupS))
										{
											fprintf(fp,"%s",PartModDateDupS);			//100		//In main else if
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"-^");
										}

										if(!nlsIsStrNull(PartCreatorDup))
										{
											fprintf(fp,"%s",PartCreatorDup);			//101		//In main else if
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp,"loader^");
										}
										if(!nlsIsStrNull(t5AhdIntialAgencySDup))
										{
											fprintf(fp,"%s",t5AhdIntialAgencySDup);		//102
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))			     
										{												     
											fprintf(fp,"%s",t5AhdMakeBuyIndSDup);		//103
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5DwdIntialAgencySDup))		     
										{												     
											fprintf(fp,"%s",t5DwdIntialAgencySDup);		//104
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))			     
										{												     
											fprintf(fp,"%s",t5DwdMakeBuyIndSDup);		//105
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5JdlIntialAgencySDup))		     
										{												     
											fprintf(fp,"%s",t5JdlIntialAgencySDup);		//106
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))			     
										{												     
											fprintf(fp,"%s",t5JdlMakeBuyIndSDup);		//107
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5AhdStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5AhdStoreLocSDup);			//108
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5CarStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5CarStoreLocSDup);			//109		//In main else if
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5DwdStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5DwdStoreLocSDup);			//110
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5JdlStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5JdlStoreLocSDup);			//111
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5JsrStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5JsrStoreLocSDup);			//112
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5LkoStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5LkoStoreLocSDup);			//113
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5PnrStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5PnrStoreLocSDup);			//114
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))		     
										{												     
											fprintf(fp,"%s",t5PunPCBUStoreLocSDup);		//115
											fprintf(fp,"^");							     
										}												     
										else											     
										{												     
											fprintf(fp," ^");							     
										}												     
										if(!nlsIsStrNull(t5SgrStoreLocSDup))			     
										{												     
											fprintf(fp,"%s",t5SgrStoreLocSDup);			//116		//In main else if
											fprintf(fp,"^");
										}
										else
										{
											fprintf(fp," ^");
										}
										fprintf(fp,"\n");

								    	printf("\n Inside fp -----------else if------------121\n"); fflush(stdout);
										fflush(fp);
									}

									if ((m == (setSize(PartSO)-1)) && (NonStdGenericPartFlag == 1))	//added on 19.01.2017 to query all revisions of non-standard Generic and project != "1111"
									{
										temp_InstGen = nlsStrAlloc(100);
										tempInstance = nlsStrAlloc(100);
										tempGen = nlsStrAlloc(100);

										nlsStrCpy(temp_InstGen,DIClassNameS);

										tempInstance = strtok(temp_InstGen,"<");
										tempGen = strtok(NULL,">");

										printf("\nGeneric tempGen---->%s",tempGen);

										tempInstanceDup=nlsStrDup(tempInstance);
										tempGenDup=nlsStrDup(tempGen);

										if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
											(dstat = oiSqlWhereBegParen(Sql_ptr))||
											(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,tempGenDup)) ||
											(dstat = oiSqlWhereEndParen(Sql_ptr))||
											(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
										if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&GenericSO,mfail)) goto EXIT;
										printf ("\t setSize(GenericSO): %d", setSize(GenericSO));

										if (setSize(GenericSO) == 0)
										{
											printf ("\n\nBefore conversion: %s", tempGenDup);
											for (p = tempGenDup; *p != '\0'; ++p)
											{
												*p = tolower(*p);
											}
											printf ("\nAfter conversion: %s", tempGenDup);

											if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
												(dstat = oiSqlWhereBegParen(Sql_ptr))||
												(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,tempGenDup)) ||
												(dstat = oiSqlWhereEndParen(Sql_ptr))||
												(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
											if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&GenericSO,mfail)) goto EXIT;
											printf ("\t setSize(GenericSO): %d", setSize(GenericSO));
										}
										
										//Below query is added on 14.04.2017
										if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
											(dstat = oiSqlWhereBegParen(Sql_ptr))||
											(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,tempInstance)) ||
											(dstat = oiSqlWhereEndParen(Sql_ptr))||
											(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
										if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&InstSO,mfail)) goto EXIT;
										printf ("\n %s  setSize(InstSO): %d",tempInstance, setSize(InstSO));

										InstanceRevSeqDup = nlsStrAlloc(100);
										nlsStrCpy(InstanceRevSeqDup,tempInstance);
										nlsStrCat(InstanceRevSeqDup,";");

										if (setSize(InstSO) > 0)
										{
											if (dstat = objGetAttribute( setGet(InstSO,0) ,RevisionAttr,&InstRev)) goto CLEANUP;
											InstRevDup=nlsStrDup(InstRev);

											if (dstat = objGetAttribute( setGet(InstSO,0) ,SequenceAttr,&InstSeq)) goto CLEANUP;
											InstSeqDup=nlsStrDup(InstSeq);
											
											nlsStrCat(InstanceRevSeqDup,InstRevDup);
											nlsStrCat(InstanceRevSeqDup,";");
											nlsStrCat(InstanceRevSeqDup,InstSeqDup);


											/*if(dstat = ExpandObject2(PartDocClass,setGet(DocPartSO,i),"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
											if (setSize(DocumentSO) > 0)
											{
												//printf("\n\t  1..Doc present "); fflush(stdout);
												if(dstat = t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail)) goto CLEANUP;
												//printf("\n 1.setSize(LatestDocSO) :%d",setSize(LatestDocSO));
												if (setSize(LatestDocSO) > 0)
												{
													t5DrwDocFlag = 0;

													for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
													{
														LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

														t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
														DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
														printf("\n 1.Document Class:[%s]",DocBIClassNameS); fflush(stdout);

														if(nlsStrCmp(DocBIClassNameS,"DesDoc")==0)
														{

														}
													}
												}
											}*/


										}
										else
										{
											nlsStrCat(InstanceRevSeqDup,"NR;1");
										}


										if (setSize(GenericSO) > 0)
										{
											for(m2=0;m2<setSize(GenericSO);m2++)
											{
												GenericObjP = setGet(GenericSO,m2);

												t5CheckDstat(objGetAttribute(GenericObjP,RevisionAttr,&GenRev));
												GenRevDup = nlsStrDup(GenRev);

												t5CheckDstat(objGetAttribute(GenericObjP,SequenceAttr,&GenSeq));
												GenSeqDup = nlsStrDup(GenSeq);

												//InstanceRevSeqS2 = nlsStrAlloc(100);
												//nlsStrCpy(InstanceRevSeqS2,PartNumberDupS);
												//nlsStrCat(InstanceRevSeqS2,";");
												//nlsStrCat(InstanceRevSeqS2,GenRevDup);
												//nlsStrCat(InstanceRevSeqS2,";");
												//nlsStrCat(InstanceRevSeqS2,GenSeqDup);

												//t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, GenRevDup, GenSeqDup, InstanceRevSeqS2, fpAllRev, fpGen, mfail));
												t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, GenRevDup, GenSeqDup, InstanceRevSeqDup, fpAllRev, fpGen, mfail));
											}
										}
										else
										{
											//t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, "NR", "1", InstanceRevSeqS2, fpAllRev, fpGen, mfail));
											t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, "NR", "1", InstanceRevSeqDup, fpAllRev, fpGen, mfail));
										}
									}
								}
							}
						}
					}
					else
					{
						printf("\n Inside part not found \n\n");

						tempGen=nlsStrAlloc(100);

						dummypart=strtok(dummypart,"./<");
						tempGen = strtok(NULL,">");

						tempGenDup=nlsStrDup(tempGen);

						fprintf(fp,"%s",level);
						fprintf(fp,"^");
						fprintf(fp,"%s",dummypart);
						fprintf(fp,"^");
						fprintf(fp,"%s","NR");
						fprintf(fp,"^");
						fprintf(fp,"%s","1");
						fprintf(fp,"^");
						fprintf(fp,"%s","Dummy Part for Proe."); //NomenclatureDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","D");		//PartTypeDupS		// Dummy PartType
						fprintf(fp,"^");
						fprintf(fp,"%s","1111");		//ProjectNameDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","11");		//t5DesignGroupDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","-");		//mod_desc   t5DocRemarkDupS
						fprintf(fp,"^");
						fprintf(fp," ^");			//t5DrawingNoDupS			//10
						fprintf(fp,"%s","N");		//t5DrawingIndDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","NA");		//t5MatlClassDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","-");		//t5MaterialInDrwDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","-");		//MaterialThickNessDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","NA");		//t5LeftRhDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","TELPUN");	//t5DsgnOwnDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","-");		//t5ModelIndicatorDupS;
						fprintf(fp,"^");
						fprintf(fp,"%s","4");		//UnitOfMeasureDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","N");		//t5ColourIndDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","LcsSTDRlzd");//LifeCycleStateDupS		//20
						fprintf(fp,"^");
						fprintf(fp," ^");			//t5ColourIDDupS
						fprintf(fp,"%s","0");		//WeightDupS
						fprintf(fp,"^");
						fprintf(fp,"%s","-");		//SpareIndDupS
						fprintf(fp,"^");
						fprintf(fp," ^");			//t5CMVRCertification
						fprintf(fp," ^");			//t5ClassificationHaz
						fprintf(fp," ^");			//t5ConfigID
						fprintf(fp," ^");			//t5Dismantable
						fprintf(fp," ^");			//t5DsgnDeptS
						fprintf(fp," ^");			//t5EnvelopeDimen
						fprintf(fp," ^");			//t5HazardousCont			//30
						fprintf(fp," ^");			//t5HomologationReqd
						fprintf(fp," ^");			//t5ListRecSpares
						fprintf(fp," ^");			//t5NcPartNoS
						fprintf(fp," ^");			//t5PartCodeS
						fprintf(fp," ^");			//t5PartPropertyS
						fprintf(fp," ^");			//t5PartStatusS
						fprintf(fp," ^");			//t5PkgStdS
						fprintf(fp," ^");			//t5ProductS
						fprintf(fp," ^");			//t5PrtCatCodeS
						fprintf(fp," ^");			//t5PunIntialAgS			//40
						fprintf(fp," ^");			//t5PunMakeBuyIndS
						fprintf(fp," ^");			//t5RecoverableS
						fprintf(fp," ^");			//t5RecyclabilityS
						fprintf(fp," ^");			//t5RefPartNumberS
						fprintf(fp," ^");			//t5ReliabilityS
						fprintf(fp," ^");			//t5SpareCriteriaS
						fprintf(fp," ^");			//t5SurfPrtStdS
						fprintf(fp," ^");			//t5SamplesToApprS
						fprintf(fp," ^");			//t5AsmDisposalS
						fprintf(fp," ^");			//t5FinDisposalInstrS		//50
						fprintf(fp," ^");			//t5RPDisposalInstrS
						fprintf(fp," ^");			//t5SPDisposalInstrS
						fprintf(fp," ^");			//t5WIPDisposalInstrS
						fprintf(fp,"loader^");		//t5LastModByS
						fprintf(fp," ^");			//t5VerCreatorS
						fprintf(fp," ^");			//t5CAEDocES

						fprintf(fp,"%s","N");		//t5CoatedS
						fprintf(fp,"^");

						fprintf(fp," ^");			//t5ConvDocS
						fprintf(fp," ^");			//t5AplCopyOfErcRevS
						fprintf(fp," ^");			//t5AplCopyOfErcSeqS		//60
						fprintf(fp," ^");			//t5AppCodeS
						fprintf(fp," ^");			//t5RqstNumS
						fprintf(fp," ^");			//t5RsnCodeS
						fprintf(fp," ^");			//t5SurfaceAreaS
						fprintf(fp," ^");			//t5VolumeS
						fprintf(fp," ^");			//t5CarIntialAgencyS
						fprintf(fp," ^");			//t5CarMakeBuyIndiS
						fprintf(fp," ^");			//t5ErcIndNameS
						fprintf(fp," ^");			//t5PostRelReqS
						fprintf(fp," ^");			//t5ItmCategoryS			//70
						fprintf(fp," ^");			//t5CopReqS
						fprintf(fp," ^");			//t5AplInvalidateS
						fprintf(fp," ^");			//t5PrtValiStatusS
						fprintf(fp," ^");			//t5DRSubStateS
						fprintf(fp," ^");			//t5KnxtDocIndS
						fprintf(fp," ^");			//t5SimValS
						fprintf(fp," ^");			//t5PerYieldS
						fprintf(fp," ^");			//t5PunStoreLocationS
						fprintf(fp," ^");			//t5AltPartNoS
						fprintf(fp," ^");			//t5RolledupWtS				//80
						fprintf(fp," ^");			//t5PFDModReqdS
						fprintf(fp," ^");			//t5ToolIndentReqdS
						fprintf(fp," ^");			//CategoryNameS
						fprintf(fp,"-^");			//ReveffDateFromDup
						fprintf(fp,"-^");			//ReveffDateToDup			//85
						fprintf(fp,"NA^");			//LeftRhPartDup				//86

						fprintf(fp," ^");	//Instance with semicolon separated Rev;Seq		//87

						fprintf(fp," ^");			//t5JsrIntialAgencyS		//88
						fprintf(fp," ^");			//t5JsrMakeBuyIndiS			//89
						fprintf(fp," ^");			//t5LkoIntialAgencyS		//90
						fprintf(fp," ^");			//t5LkoMakeBuyIndiS			//91
						fprintf(fp," ^");			//t5PnrIntialAgencyS		//92
						fprintf(fp," ^");			//t5PnrMakeBuyIndiS			//93
						fprintf(fp," ^");			//t5PunPCBUIntialAgencyS	//94
						fprintf(fp," ^");			//t5PunPCBUMakeBuyIndiS		//95
						fprintf(fp," ^");			//t5SgrIntialAgencyS		//96
						fprintf(fp," ^");			//t5SgrMakeBuyIndiS			//97
						fprintf(fp," ^");			//t5EstSheetReqdS			//98
						fprintf(fp,"-^");			//PartCreDateDupS			//99
						fprintf(fp,"-^");			//PartModDateDupS			//100
						fprintf(fp,"loader^");		//PartCreatorDup			//101
						fprintf(fp," ^");			//t5AhdIntialAgencySDup		//102
						fprintf(fp," ^");			//t5AhdMakeBuyIndSDup		//103
						fprintf(fp," ^");			//t5DwdIntialAgencySDup		//104
						fprintf(fp," ^");			//t5DwdMakeBuyIndSDup		//105
						fprintf(fp," ^");			//t5JdlIntialAgencySDup		//106
						fprintf(fp," ^");			//t5JdlMakeBuyIndSDup		//107
						fprintf(fp," ^");			//t5AhdStoreLocSDup			//108
						fprintf(fp," ^");			//t5CarStoreLocSDup			//109
						fprintf(fp," ^");			//t5DwdStoreLocSDup			//110
						fprintf(fp," ^");			//t5JdlStoreLocSDup			//111
						fprintf(fp," ^");			//t5JsrStoreLocSDup			//112
						fprintf(fp," ^");			//t5LkoStoreLocSDup			//113
						fprintf(fp," ^");			//t5PnrStoreLocSDup			//114
						fprintf(fp," ^");			//t5PunPCBUStoreLocSDup		//115
						fprintf(fp," ^");			//t5SgrStoreLocSDup			//116

						fprintf(fp,"\n"); fflush(fp);

/*						fprintf(fpAllRev,"%s",dummypart);
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","NR");
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","1");
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","Dummy Part for Proe."); //NomenclatureDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","D");		//PartTypeDupS		// Dummy PartType
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","1111");	//ProjectNameDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","11");	//t5DesignGroupDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","-");		//mod_desc   t5DocRemarkDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev," ^");			//t5DrawingNoDupS
						fprintf(fpAllRev,"%s","N");		//t5DrawingIndDupS			//10
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","NA");	//t5MatlClassDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","-");		//t5MaterialInDrwDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","-");		//MaterialThickNessDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","NA");		//t5LeftRhDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","TELPUN");	//t5DsgnOwnDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","-");		//t5ModelIndicatorDupS;
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","4");		//UnitOfMeasureDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","N");		//t5ColourIndDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","LcsSTDRlzd");//LifeCycleStateDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev," ^");			//t5ColourIDDupS		//20
						fprintf(fpAllRev,"%s","0");		//WeightDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev,"%s","-");		//SpareIndDupS
						fprintf(fpAllRev,"^");
						fprintf(fpAllRev," ^");			//t5CMVRCertification
						fprintf(fpAllRev," ^");			//t5ClassificationHaz
						fprintf(fpAllRev," ^");			//t5ConfigID
						fprintf(fpAllRev," ^");			//t5Dismantable
						fprintf(fpAllRev," ^");			//t5DsgnDeptS
						fprintf(fpAllRev," ^");			//t5EnvelopeDimen
						fprintf(fpAllRev," ^");			//t5HazardousCont	
						fprintf(fpAllRev," ^");			//t5HomologationReqd		//30
						fprintf(fpAllRev," ^");			//t5ListRecSpares
						fprintf(fpAllRev," ^");			//t5NcPartNoS
						fprintf(fpAllRev," ^");			//t5PartCodeS
						fprintf(fpAllRev," ^");			//t5PartPropertyS
						fprintf(fpAllRev," ^");			//t5PartStatusS
						fprintf(fpAllRev," ^");			//t5PkgStdS
						fprintf(fpAllRev," ^");			//t5ProductS
						fprintf(fpAllRev," ^");			//t5PrtCatCodeS
						fprintf(fpAllRev," ^");			//t5PunIntialAgS	
						fprintf(fpAllRev," ^");			//t5PunMakeBuyIndS			//40
						fprintf(fpAllRev," ^");			//t5RecoverableS
						fprintf(fpAllRev," ^");			//t5RecyclabilityS
						fprintf(fpAllRev," ^");			//t5RefPartNumberS
						fprintf(fpAllRev," ^");			//t5ReliabilityS
						fprintf(fpAllRev," ^");			//t5SpareCriteriaS
						fprintf(fpAllRev," ^");			//t5SurfPrtStdS
						fprintf(fpAllRev," ^");			//t5SamplesToApprS
						fprintf(fpAllRev," ^");			//t5AsmDisposalS
						fprintf(fpAllRev," ^");			//t5FinDisposalInstrS
						fprintf(fpAllRev," ^");			//t5RPDisposalInstrS		//50
						fprintf(fpAllRev," ^");			//t5SPDisposalInstrS
						fprintf(fpAllRev," ^");			//t5WIPDisposalInstrS
						fprintf(fpAllRev,"loader^");	//t5LastModByS
						fprintf(fpAllRev," ^");			//t5VerCreatorS
						fprintf(fpAllRev," ^");			//t5CAEDocES

						fprintf(fpAllRev,"%s","N");		//t5CoatedS
						fprintf(fpAllRev,"^");

						fprintf(fpAllRev," ^");			//t5ConvDocS
						fprintf(fpAllRev," ^");			//t5AplCopyOfErcRevS
						fprintf(fpAllRev," ^");			//t5AplCopyOfErcSeqS
						fprintf(fpAllRev," ^");			//t5AppCodeS				//60
						fprintf(fpAllRev," ^");			//t5RqstNumS
						fprintf(fpAllRev," ^");			//t5RsnCodeS
						fprintf(fpAllRev," ^");			//t5SurfaceAreaS
						fprintf(fpAllRev," ^");			//t5VolumeS
						fprintf(fpAllRev," ^");			//t5CarIntialAgencyS
						fprintf(fpAllRev," ^");			//t5CarMakeBuyIndiS
						fprintf(fpAllRev," ^");			//t5ErcIndNameS
						fprintf(fpAllRev," ^");			//t5PostRelReqS
						fprintf(fpAllRev," ^");			//t5ItmCategoryS
						fprintf(fpAllRev," ^");			//t5CopReqS					//70
						fprintf(fpAllRev," ^");			//t5AplInvalidateS
						fprintf(fpAllRev," ^");			//t5PrtValiStatusS
						fprintf(fpAllRev," ^");			//t5DRSubStateS
						fprintf(fpAllRev," ^");			//t5KnxtDocIndS
						fprintf(fpAllRev," ^");			//t5SimValS
						fprintf(fpAllRev," ^");			//t5PerYieldS
						fprintf(fpAllRev," ^");			//t5PunStoreLocationS
						fprintf(fpAllRev," ^");			//t5AltPartNoS
						fprintf(fpAllRev," ^");			//t5RolledupWtS
						fprintf(fpAllRev," ^");			//t5PFDModReqdS				//80
						fprintf(fpAllRev," ^");			//t5ToolIndentReqdS
						fprintf(fpAllRev," ^");			//CategoryNameS
						fprintf(fpAllRev,"-^");			//ReveffDateFromDup
						fprintf(fpAllRev,"-^");			//ReveffDateToDup			//84
						fprintf(fpAllRev,"NA^");		//LeftRhPartDup				//85

						fprintf(fpAllRev," ^");			//Instance with semicolon separated Rev;Seq		//86

						fprintf(fpAllRev," ^");			//t5JsrIntialAgencyS		//87
						fprintf(fpAllRev," ^");			//t5JsrMakeBuyIndiS			//88
						fprintf(fpAllRev," ^");			//t5LkoIntialAgencyS		//99
						fprintf(fpAllRev," ^");			//t5LkoMakeBuyIndiS			//90
						fprintf(fpAllRev," ^");			//t5PnrIntialAgencyS		//91
						fprintf(fpAllRev," ^");			//t5PnrMakeBuyIndiS			//92
						fprintf(fpAllRev," ^");			//t5PunPCBUIntialAgencyS	//93
						fprintf(fpAllRev," ^");			//t5PunPCBUMakeBuyIndiS		//94
						fprintf(fpAllRev," ^");			//t5SgrIntialAgencyS		//95
						fprintf(fpAllRev," ^");			//t5SgrMakeBuyIndiS			//96
						fprintf(fpAllRev," ^");			//t5EstSheetReqdS			//97
						fprintf(fpAllRev,"-^");			//PartCreDateDupS			//98
						fprintf(fpAllRev,"-^");			//PartModDateDupS			//99
						fprintf(fpAllRev,"loader^");	//PartCreatorDup			//100
						fprintf(fpAllRev," ^");			//t5AhdIntialAgencySDup		//101
						fprintf(fpAllRev," ^");			//t5AhdMakeBuyIndSDup		//102
						fprintf(fpAllRev," ^");			//t5DwdIntialAgencySDup		//103
						fprintf(fpAllRev," ^");			//t5DwdMakeBuyIndSDup		//104
						fprintf(fpAllRev," ^");			//t5JdlIntialAgencySDup		//105
						fprintf(fpAllRev," ^");			//t5JdlMakeBuyIndSDup		//106
						fprintf(fpAllRev," ^");			//t5AhdStoreLocSDup			//107
						fprintf(fpAllRev," ^");			//t5CarStoreLocSDup			//108
						fprintf(fpAllRev," ^");			//t5DwdStoreLocSDup			//109
						fprintf(fpAllRev," ^");			//t5JdlStoreLocSDup			//110
						fprintf(fpAllRev," ^");			//t5JsrStoreLocSDup			//111
						fprintf(fpAllRev," ^");			//t5LkoStoreLocSDup			//112
						fprintf(fpAllRev," ^");			//t5PnrStoreLocSDup			//113
						fprintf(fpAllRev," ^");			//t5PunPCBUStoreLocSDup		//114
						fprintf(fpAllRev," ^");			//t5SgrStoreLocSDup			//115

						fprintf(fpAllRev,"\n"); fflush(fpAllRev);
*/

/*						if (NonStdGenericPartFlag == 1)	//added on 19.01.2017 to query all revisions of non-standard Generic and project != "1111"
						{
							InstanceRevSeqS2 = nlsStrAlloc(100);
							nlsStrCpy(InstanceRevSeqS2,dummypart);
							nlsStrCat(InstanceRevSeqS2,";");
							nlsStrCat(InstanceRevSeqS2,"NR");
							nlsStrCat(InstanceRevSeqS2,";");
							nlsStrCat(InstanceRevSeqS2,"1");

							if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
								(dstat = oiSqlWhereBegParen(Sql_ptr))||
								(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,tempGenDup)) ||
								(dstat = oiSqlWhereEndParen(Sql_ptr))||
								(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
							if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&GenericSO,mfail)) goto EXIT;
							printf ("\t setSize(GenericSO): %d", setSize(GenericSO));

							if (setSize(GenericSO) == 0)
							{
								printf ("\n\nBefore conversion: %s", tempGenDup);
								for (p = tempGenDup; *p != '\0'; ++p)
								{
									*p = tolower(*p);
								}
								printf ("\nAfter conversion: %s", tempGenDup);

								if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
									(dstat = oiSqlWhereBegParen(Sql_ptr))||
									(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,tempGenDup)) ||
									(dstat = oiSqlWhereEndParen(Sql_ptr))||
									(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
								if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&GenericSO,mfail)) goto EXIT;
								printf ("\t setSize(GenericSO): %d", setSize(GenericSO));
							}

							if (setSize(GenericSO) > 0)
							{
								for(m2=0;m2<setSize(GenericSO);m2++)
								{
									GenericObjP = setGet(GenericSO,m2);

									t5CheckDstat(objGetAttribute(GenericObjP,RevisionAttr,&GenRev));
									GenRevDup = nlsStrDup(GenRev);

									t5CheckDstat(objGetAttribute(GenericObjP,SequenceAttr,&GenSeq));
									GenSeqDup = nlsStrDup(GenSeq);

									t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, GenRevDup, GenSeqDup, InstanceRevSeqS2, fpAllRev, fpGen, mfail));
								}
							}
							else
							{
								t5CheckDstat(GetGenTCPartProEInfo(tempGenDup, "NR", "1", InstanceRevSeqS2, fpAllRev, fpGen, mfail));
							}
						}
*/
						goto CLEANUP;
					}
				//}
			}
		}
	}

	if(fp)
	{
		fclose(fp);fp = NULL;
	}
	if(fpAllRev)
	{
		fclose(fpAllRev);fpAllRev = NULL;
	}
	if(LhRhfp)
	{
		fclose(LhRhfp);LhRhfp = NULL;
	}
	if(LhRHErr)
	{
		fclose(LhRHErr);LhRHErr = NULL;
	}
	if(OutJtfp)
	{
		fclose(OutJtfp);OutJtfp = NULL;
	}
	if(fpGen)
	{
		fclose(fpGen);fpGen = NULL;
	}

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(DISO);

EXIT:
	if(fp)
	{
		fclose(fp);fp = NULL;
	}
	if(fpAllRev)
	{
		fclose(fpAllRev);fpAllRev = NULL;
	}
	if(LhRhfp)
	{
		fclose(LhRhfp);LhRhfp = NULL;
	}
	if(LhRHErr)
	{
		fclose(LhRHErr);LhRHErr = NULL;
	}
	if(OutJtfp)
	{
		fclose(OutJtfp);OutJtfp = NULL;
	}
	if(fpGen)
	{
		fclose(fpGen);fpGen = NULL;
	}

	t5CheckDstatAndReturn;
}
;
status T5SortBOMObjsByDate
(
	SetOfObjects *itemObjs,
	SetOfObjects *relObjs,
	integer* mfail
)
{
	status dstat = OKAY;
	char *mod_name = "t5SortBOMObjsByDate";
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpRelObjs = NULL;
	ObjectPtr relObj = NULL;
	ObjectPtr itemObj = NULL;
	ObjectPtr relTObj = NULL;
	ObjectPtr itemTObj = NULL;
	integer count = 0;
	integer cmpCount = 0;
	ObjectPtr tmpRelObj = 0;
	string curCreDate = NULL;
	string tmpcurCreDate = NULL;
	string cmpCreDate = NULL;
	string tmpcmpCreDate = NULL;
	string DocOwnerName = NULL;
	string DocOwnerNameDup = NULL;
	string DataItemDisplNm = NULL;
	string DataItemDisplNmDup = NULL;
	*mfail = USC_OKAY;

	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		/* initalizing sorted object set */
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		t5CheckDstat(objGetAttribute(itemObj,"OwnerName",&DocOwnerName));
		DocOwnerNameDup=nlsStrDup(DocOwnerName);
		if(nlsStrStr(DocOwnerNameDup,"Vault")==NULL)
		{
			t5CheckDstat(objGetAttribute(itemObj,"DisplayedName",&DataItemDisplNm));
			if(!nlsIsStrNull(DataItemDisplNm))
			{
				DataItemDisplNmDup=nlsStrDup(DataItemDisplNm);
			}
			printf("\n\t DataItemDisplNmDup:%s  DocOwnerNameDup:%s , hence continuing to previous object....",DataItemDisplNmDup,DocOwnerNameDup); fflush(stdout);
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		/* get mainSerial */
		if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
		tmpcurCreDate = nlsStrDup(curCreDate);

		/* compare mainSerial with the new set of objects */
		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
			tmpcmpCreDate = nlsStrDup(cmpCreDate);

			if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) <= 0)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}
	/* free memory and assign to new set sorted objects */
	objDisposeAll(*itemObjs); *itemObjs = NULL;
	objDisposeAll(*relObjs); *relObjs = NULL;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:
EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
/*status GetLhRhTCPartProEInfo(string InpPartNumberS, string LhRhPartNumberDup,FILE* fpAllRev, FILE* OutJtfp,FILE* LhRHErr,integer* mfail )
{
	char *mod_name = "GetLhRhTCPartProEInfo";

	status dstat = OKAY;

	string PartNumberDupS=NULL;
	string PartNumberS=NULL;
	//string PartRevisionDupS=NULL;
	//string PartRevisionS=NULL;
	//string PartSequenceDupS=NULL;
	//string PartSequenceS=NULL;
	//string PartOwnerNameDupS=NULL;
	//string PartOwnerNameS=NULL;
	string docClass=NULL;
	string DataItClass = NULL;
	//string WorkingFileNm = NULL;
	//string WorkingFileNmDup = NULL;
	//string wrelativepath = NULL;
	//string wrelativepathDup = NULL;
	//string GenFullPath = NULL;
	//string GenFullPathDup = NULL;
	//string Sequence = NULL;
	//string SequenceDup = NULL;
	//string OwnerDirName = NULL;
	//string OwnerDirNameDup = NULL;
	//string OwnerName = NULL;
	//string OwnerNameDup = NULL;
	string PartRevSeq = NULL;

	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	//string t5DocumentTypeDupS = NULL;
	//string t5DocumentTypeS = NULL;
	//string t5SourceDataErrorsDupS = NULL;
	//string t5SourceDataErrorsS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	//string LHRhPartNumber = NULL;
	//string LHRhPartNumberDupS = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string t5ColourIDS = NULL;
	string t5ColourIDDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	//string OwnerDirS = NULL;
	//string level = NULL;
	//string dummypart = NULL;
	//string t5DocumentName = NULL;
	//string t5DocumentNameDupS = NULL;
	//string t5DocumentRev = NULL;
	//string t5DocumentRevDupS = NULL;
	//string t5DocumentSeq = NULL;
	//string t5DocumentSeqDupS = NULL;
	string t5CMVRCertificationS = NULL;
	string t5CMVRCertificationDupS = NULL;
	string t5ClassificationHazDupS = NULL;
	string t5ClassificationHazS = NULL;
	string t5ConfigIDS = NULL;
	string t5ConfigIDDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5ListRecSparess = NULL;
	string t5ListRecSparesDups = NULL;
	string t5NcPartNoS = NULL;
	string t5PartCodeS = NULL;
	string t5NcPartNoDupS = NULL;
	string t5PartCodeDupS = NULL;
	string t5PartPropertyS = NULL;
	string t5PartPropertyDupS = NULL;
	string t5PartStatusS = NULL;
	string t5PartStatusDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PrtCatCodeS = NULL;
	string t5PrtCatCodeDupS = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5RefPartNumberS = NULL;
	string t5RefPartNumberDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SurfPrtStdS = NULL;
	string t5SurfPrtStdDupS = NULL;
	string t5SamplesToApprS = NULL;
	string t5SamplesToApprDupS = NULL;
	string t5AsmDisposalS = NULL;
	string t5AsmDisposalDupS = NULL;
	string t5FinDisposalInstrS = NULL;
	string t5FinDisposalInstrDupS = NULL;
	string t5RPDisposalInstrS = NULL;
	string t5RPDisposalInstrDupS = NULL;
	string t5SPDisposalInstrS = NULL;
	string t5SPDisposalInstrDupS = NULL;
	string t5WIPDisposalInstrS = NULL;
	string t5WIPDisposalInstrDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5CAEDocES = NULL;
	string t5CAEDocEDupS = NULL;
	string t5CoatedS = NULL;
	string t5CoatedDupS = NULL;
	string t5ConvDocS = NULL;
	string t5ConvDocDupS = NULL;
	string t5AplCopyOfErcRevS = NULL;
	string t5AplCopyOfErcRevDupS = NULL;
	string t5AplCopyOfErcSeqS = NULL;
	string t5AplCopyOfErcSeqDupS = NULL;
	string t5AppCodeS = NULL;
	string t5AppCodeDupS = NULL;
	string t5RqstNumS = NULL;
	string t5RqstNumDupS = NULL;
	string t5RsnCodeS = NULL;
	string t5RsnCodeDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5ErcIndNameS = NULL;
	string t5ErcIndNameDupS = NULL;
	string t5PostRelReqS = NULL;
	string t5PostRelReqDupS = NULL;
	string t5ItmCategoryS = NULL;
	string t5ItmCategoryDupS = NULL;
	string t5CopReqS = NULL;
	string t5CopReqDupS = NULL;
	string t5AplInvalidateS = NULL;
	string t5AplInvalidateDupS = NULL;
	string t5PrtValiStatusS = NULL;
	string t5PrtValiStatusDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5KnxtDocIndS = NULL;
	string t5KnxtDocIndDupS = NULL;
	string t5SimValS = NULL;
	string t5SimValDupS = NULL;
	string t5PerYieldS = NULL;
	string t5PerYieldDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5AltPartNoS = NULL;
	string t5AltPartNoDupS = NULL;
	string t5RolledupWtS = NULL;
	string t5RolledupWtDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string t5PFDModReqdS = NULL;
	string t5PFDModReqdDupS = NULL;
	string t5ToolIndentReqdS = NULL;
	string t5ToolIndentReqdDupS = NULL;
	string CategoryNameDupS = NULL;
	string CategoryNameS = NULL;
	string ReveffDateFrom = NULL;
	string ReveffDateFromDup = NULL;
	string ReveffDateTo = NULL;
	string ReveffDateToDup = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;

	string RelativePath = NULL;
	string RelativePathDup = NULL;
	string WRelativePath = NULL;
	string WRelativePathDup = NULL;
	string OwnerDirName = NULL;
	string OwnerDirNameDup = NULL;
	string OwnerName = NULL;
	string OwnerNameDup = NULL;
	string DataItemDisplayNm = NULL;
	string DataItemDisplayNmDup = NULL;
	//string JTRelativePathS = NULL;
	//string JTRelativePathDup = NULL;
	//string JTWRelativePathS = NULL;
	//string JTWRelativePathDup = NULL;
	//string JTOwnerNameS = NULL;
	//string JTOwnerNameDupS = NULL;
	//string OwnerDirNameJTS = NULL;
	//string OwnerDirNameJTDupS = NULL;

	string DiClassDupS = NULL;
	string DiClassS = NULL;
	string DIOwnerNameDup = NULL;
	string DIOwnerName = NULL;
	string DIRelPathDup = NULL;
	string DIRelPath = NULL;
	string DIDisplayNmDup = NULL;
	string DIDisplayNm = NULL;
	string DIFileWorkingRelativePathDup = NULL;
	string DIFileWorkingRelativePath = NULL;
	string DISequenceDup = NULL;
	string DISequence = NULL;
	string DIOwnerDirNameDup = NULL;
	string DIOwnerDirName = NULL;
	string DIfullPathDup = NULL;
	string DIfullPath = NULL;
	string VisFileOwnerNameDupS = NULL;
	string VisFileOwnerNameS = NULL;
	string VisFileRelPathDupS = NULL;
	string VisFileRelPathS = NULL;
	string PdfDisDupS = NULL;
	string PdfDisS = NULL;
	string VisFileWorkingRelativePathDupS = NULL;
	string VisFileWorkingRelativePathS = NULL;
	string VisFileSequenceDupS = NULL;
	string VisFileSequenceS = NULL;
	string VisFileClassDupS = NULL;
	string VisFileClassS = NULL;
	string VisFileOwnerDirNameDupS = NULL;
	string VisFileOwnerDirNameS = NULL;
	string fullPathattrDup = NULL;
	string fullPathattr = NULL;

	SetOfObjects PartSO = NULL ;
	SetOfObjects partMasterSO = NULL;
	SetOfObjects partMasterRelSO = NULL;
	//SetOfObjects hasRHItmMster = NULL;
	SetOfObjects docObjs = NULL ;
	SetOfObjects docRelObjs = NULL ;
	SetOfObjects latestDocs = NULL ;
	SetOfObjects latestRelDocs = NULL ;
	//SetOfObjects DataItemJtSO = NULL ;
	SetOfObjects soExpObj = NULL ;
	SetOfObjects relObjSet = NULL ;
	SetOfObjects docDObjs = NULL;
	SetOfObjects docDRelObjs = NULL;
	SetOfObjects latestDocDs = NULL;
	SetOfObjects latestRelDocDs = NULL;
	SetOfObjects DocumentRefSO = NULL;
	SetOfObjects DocumentRefRelSO = NULL;
	SetOfObjects LatestRefDocSO = NULL;
	SetOfObjects LatestRefRelDocSO = NULL;
	SetOfObjects DataItemSO = NULL;
	//SetOfObjects JTPartSO = NULL;
	//SetOfObjects JTPartRelSO = NULL;
	SetOfObjects VisualizationFileSO = NULL;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr docOPtr=NULL;
	//ObjectPtr NewDataItemObjP=NULL;
	//ObjectPtr GetItemInfoObjP=NULL;
	ObjectPtr contextObj = NULL;
	ObjectPtr genContextObj	= NULL;
	ObjectPtr docDOPtr = NULL;
	ObjectPtr NewDataItemObjPtr = NULL;
	ObjectPtr GetItemInfoObjPtr = NULL;
	//ObjectPtr JTPartObjP = NULL;
	//ObjectPtr JTObjP = NULL;
	ObjectPtr NewDataItemObjP = NULL;
	ObjectPtr DataItemObjP = NULL;
	ObjectPtr proprtDIObjP = NULL;
	ObjectPtr NewVisFileObjP = NULL;
	ObjectPtr VisFileObjP = NULL;
	ObjectPtr proprtrevObjP = NULL;

	SqlPtr Sql_ptr = NULL;

	//int k = 0;
	int m = 0;
	int noOfDocs = 0;
	int DataItem = 0;
	int count = 0;
	int VisFile = 0;

	PartRevSeq=nlsStrAlloc(50);

	//printf("\n Executing... GetProEPartList.c ... \n");

	if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
		(dstat = oiSqlWhereBegParen(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
		(dstat = oiSqlWhereEndParen(Sql_ptr))||
		(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
	if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;

	printf("\n\t LH-RH--No:of Parts are :- %d",setSize(PartSO));

	if(setSize(PartSO)>0)
	{
		for(m=0;m<setSize(PartSO);m++)
		{
			TCPartObjP=setGet(PartSO,m);

			if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
			if(SetFlagforScope(partMasterSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			if (setSize(partMasterSO)>0)
			{
				MasterObjOP=setGet(partMasterSO,0);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberS));
			PartNumberDupS=nlsStrDup(PartNumberS);
			//printf("\n\n\t TCPartNumberDupS:%s",PartNumberDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&RevisionS));
			RevisionDupS=nlsStrDup(RevisionS);
			//printf("\n\t TCRevisionDupS :%s",RevisionDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&SequenceS));
			SequenceDupS=nlsStrDup(SequenceS);
			//printf("\n\t Sequence:%s",SequenceDupS); fflush(stdout);

			printf("\n\n\t LH-RH--TCPart:::::[ %s , %s , %s ]",PartNumberDupS,RevisionDupS,SequenceDupS); fflush(stdout);

			if(!nlsIsStrNull(PartNumberDupS))
			{
				nlsStrCpy(PartRevSeq,"");

				//nlsStrCpy(PartRevSeq,PartNumberDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,RevisionDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,SequenceDupS);

				nlsStrCpy(PartRevSeq,RevisionDupS);
				nlsStrCat(PartRevSeq,";");
				nlsStrCat(PartRevSeq,SequenceDupS);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&NomenclatureS));
			if(!nlsIsStrNull(NomenclatureS))
			{
				NomenclatureDupS=nlsStrDup(NomenclatureS);
			}
			else
			{
				NomenclatureDupS=nlsStrDup("-");
			}
			NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
			printf("\n\t LH-RH--NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeS));
			PartTypeDupS=nlsStrDup(PartTypeS);
			printf("\n\t LH-RH--PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&OwnerNameS));
			OwnerNameDupS=nlsStrDup(OwnerNameS);
			printf("\n\t LH-RH--OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);

			if(nlsStrStr(OwnerNameDupS,"Vault") == NULL)
			{
				printf("\t ...this rev-seq not in Vault hence skipping from download...\n");  fflush(stdout);
				continue;
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectNameS));
			ProjectNameDupS=nlsStrDup(ProjectNameS);
			printf("\n\t LH-RH--ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&t5DesignGroupS));
			if(!nlsIsStrNull(t5DesignGroupS))
			{
				t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
			}
			else
			{
				t5DesignGroupDupS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
			if(!nlsIsStrNull(t5DocRemarkS))
			{
				t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
			}
			else
			{
				t5DocRemarkDupS=nlsStrDup("-");
			}
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
			printf("\n\t LH-RH--t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
			t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
			printf("\n\t LH-RH--t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

			if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
			{
				docClass = low_getspace(20);

				if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
				if(SetFlagforScope(docObjs)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				if(setSize(docObjs) <= 0)
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
				}
				if(setSize(docObjs) > 0)
				{
					if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
					if (setSize(latestDocs)>0)
					{
						for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
						{
							docOPtr = setGet(latestDocs, noOfDocs);
							if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
							if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
							{
								//Document Number = Drawing Document Number
								if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
								if(!nlsIsStrNull(t5DrawingNo))
								{
									t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
								}
								else
								{
									t5DrawingNoDupS = nlsStrDup(" ");
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNoDupS))
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}

					if(setSize(docObjs) > 0)
					{
						if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
						if (setSize(latestDocs)>0)
						{
							for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
							{
								docOPtr = setGet(latestDocs, noOfDocs);
								if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
								printf("\n\t LH-RH--...51..%s",docClass);
								if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
								{
									//Document Number = Drawing Document Number
									if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
									if(!nlsIsStrNull(t5DrawingNo))
									{
										t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup(" ");
									}
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNo))
				{
					t5DrawingNoDupS = nlsStrDup(" ");
				}
			}
			else
			{
				t5DrawingNoDupS = nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&t5MatlClassS));
			if(!nlsIsStrNull(t5MatlClassS))
			{
				t5MatlClassDupS=nlsStrDup(t5MatlClassS);
			}
			else
			{
				t5MatlClassDupS=nlsStrDup("NA");
			}
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"\n"," ");
			printf("\n\t LH-RH--t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&t5MaterialInDrwS));
			if(!nlsIsStrNull(t5MaterialInDrwS))
			{
				t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
			}
			else
			{
				t5MaterialInDrwDupS=nlsStrDup(" ");
			}
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"\n"," ");
			printf("\n\t LH-RH--t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessS));
			if(!nlsIsStrNull(MaterialThickNessS))
			{
				MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
			}
			else
			{
				MaterialThickNessDupS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5UQdupAttr,&UnitOfMeasureS));
			//if(!nlsIsStrNull(UnitOfMeasureS))
			//{
			//	UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
			//}
			//else
			//{
			//	UnitOfMeasureDupS=nlsStrDup("4");
			//}
			//printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5LeftRhAttr,&t5LeftRhS));
			if (setSize(partMasterSO)>0)
			{
				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureS));
				if(!nlsIsStrNull(UnitOfMeasureS))
				{
					UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
				}
				else
				{
					UnitOfMeasureDupS=nlsStrDup("4");
				}

				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&t5LeftRhS));
				if(!nlsIsStrNull(t5LeftRhS))
				{
					t5LeftRhDupS=nlsStrDup(t5LeftRhS);
				}
				else
				{
					t5LeftRhDupS=nlsStrDup("NA");
				}
			}
			else
			{
				t5LeftRhDupS=nlsStrDup("NA");
				UnitOfMeasureDupS=nlsStrDup("4");
			}

			printf("\n\t LH-RH--UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);
			printf("\n\t LH-RH--t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
			if(!nlsIsStrNull(t5DsgnOwnS))
			{
				t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
			}
			else
			{
				t5DsgnOwnDupS=nlsStrDup("TELPUN");
			}
			printf("\n\t LH-RH--t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
			if(!nlsIsStrNull(t5ModelIndicatorS))
			{
				t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
			}
			else
			{
				t5ModelIndicatorDupS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&t5ColourIndS));
			if(!nlsIsStrNull(t5ColourIndS))
			{
				t5ColourIndDupS=nlsStrDup(t5ColourIndS);
			}
			else
			{
				t5ColourIndDupS=nlsStrDup("N");
			}
			printf("\n\t LH-RH--t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDS));
			if(!nlsIsStrNull(t5ColourIDS))
			{
				t5ColourIDDupS=nlsStrDup(t5ColourIDS);
			}
			else
			{
				t5ColourIDDupS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5ColourIDDupS:%s",t5ColourIDDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateS));
			if(!nlsIsStrNull(LifeCycleStateS))
			{
				LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
			}
			else
			{
				LifeCycleStateDupS=nlsStrDup("LcsReview");
			}
			printf("\n\t LH-RH--LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightS));
			if(!nlsIsStrNull(WeightS))
			{
				WeightDupS=nlsStrDup(WeightS);
			}
			else
			{
				WeightDupS=nlsStrDup("0");
			}
			printf("\n\t LH-RH--WeightDupS:%s",WeightDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5SpareIndAttr,&SpareIndS));
			if(!nlsIsStrNull(SpareIndS))
			{
				SpareIndDupS=nlsStrDup(SpareIndS);
			}
			else
			{
				SpareIndDupS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--SpareIndDupS:%s",SpareIndDupS); fflush(stdout);


			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
			if(!nlsIsStrNull(t5CMVRCertificationDupS))
			{
				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
			}
			else
			{
				t5CMVRCertificationS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5CMVRCertificationS:%s",t5CMVRCertificationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
			if(!nlsIsStrNull(t5ClassificationHazDupS))
			{
				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
			}
			else
			{
				t5ClassificationHazS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5ClassificationHazS:%s",t5ClassificationHazS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
			if(!nlsIsStrNull(t5ConfigIDDupS))
			{
				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
			}
			else
			{
				t5ConfigIDS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5ConfigIDS:%s",t5ConfigIDS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
			if(!nlsIsStrNull(t5DismantableDupS))
			{
				t5DismantableS=nlsStrDup(t5DismantableDupS);
			}
			else
			{
				t5DismantableS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5DismantableS:%s",t5DismantableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
			if(!nlsIsStrNull(t5DsgnDeptDupS))
			{
				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
			}
			else
			{
				t5DsgnDeptS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5DsgnDeptS:%s",t5DsgnDeptS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
			if(!nlsIsStrNull(t5EnvelopeDimenDupS))
			{
				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
			}
			else
			{
				t5EnvelopeDimenS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5EnvelopeDimenS:%s",t5EnvelopeDimenS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
			if(!nlsIsStrNull(t5HazardousContDupS))
			{
				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
			}
			else
			{
				t5HazardousContS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5HazardousContS:%s",t5HazardousContS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
			if(!nlsIsStrNull(t5HomologationReqdDupS))
			{
				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
			}
			else
			{
				t5HomologationReqdS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5HomologationReqdS:%s",t5HomologationReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
			if(!nlsIsStrNull(t5ListRecSparesDups))
			{
				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
			}
			else
			{
				t5ListRecSparess=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5ListRecSparess:%s",t5ListRecSparess); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
			if(!nlsIsStrNull(t5NcPartNoDupS))
			{
				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
			}
			else
			{
				t5NcPartNoS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5NcPartNoS:%s",t5NcPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
			if(!nlsIsStrNull(t5PartCodeDupS))
			{
				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
			}
			else
			{
				t5PartCodeS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5PartCodeS:%s",t5PartCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
			if(!nlsIsStrNull(t5PartPropertyDupS))
			{
				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
			}
			else
			{
				t5PartPropertyS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5PartPropertyS:%s",t5PartPropertyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
			if(!nlsIsStrNull(t5PartStatusDupS))
			{
				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
			}
			else
			{
				t5PartStatusS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5PartStatusS:%s",t5PartStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
			if(!nlsIsStrNull(t5PkgStdDupS))
			{
				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
			}
			else
			{
				t5PkgStdS=nlsStrDup(" ");
			}
			printf("\n\t LH-RH--t5PkgStdS:%s",t5PkgStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
			if(!nlsIsStrNull(t5ProductDupS))
			{
				t5ProductS=nlsStrDup(t5ProductDupS);
			}
			else {	t5ProductS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ProductS:%s",t5ProductS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
			if(!nlsIsStrNull(t5PrtCatCodeDupS))
			{
				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
			}
			else {	t5PrtCatCodeS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PrtCatCodeS:%s",t5PrtCatCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
			if(!nlsIsStrNull(t5PunIntialAgDupS))
			{
				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
			}
			else {	t5PunIntialAgS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
			if(!nlsIsStrNull(t5PunMakeBuyIndDupS))
			{
				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
			}
			else {	t5PunMakeBuyIndS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
			if(!nlsIsStrNull(t5RecoverableDupS))
			{
				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
			}
			else {	t5RecoverableS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RecoverableS:%s",t5RecoverableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
			if(!nlsIsStrNull(t5RecyclabilityDupS))
			{
				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
			}
			else {	t5RecyclabilityS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RecyclabilityS:%s",t5RecyclabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
			if(!nlsIsStrNull(t5RefPartNumberDupS))
			{
				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
			}
			else {	t5RefPartNumberS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RefPartNumberS:%s",t5RefPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
			if(!nlsIsStrNull(t5ReliabilityDupS))
			{
				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
			}
			else {	t5ReliabilityS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ReliabilityS:%s",t5ReliabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
			if(!nlsIsStrNull(t5SpareCriteriaDupS))
			{
				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
			}
			else {	t5SpareCriteriaS=nlsStrDup(" ");	}
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"\n"," ");
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"^"," ");
			printf("\n\t LH-RH--t5SpareCriteriaS:%s",t5SpareCriteriaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
			if(!nlsIsStrNull(t5SurfPrtStdDupS))
			{
				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
			}
			else {	t5SurfPrtStdS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5SurfPrtStdS:%s",t5SurfPrtStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
			if(!nlsIsStrNull(t5SamplesToApprDupS))
			{
				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
			}
			else {	t5SamplesToApprS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5SamplesToApprS:%s",t5SamplesToApprS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
			if(!nlsIsStrNull(t5AsmDisposalDupS))
			{
				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
			}
			else {	t5AsmDisposalS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AsmDisposalS:%s",t5AsmDisposalS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
			if(!nlsIsStrNull(t5FinDisposalInstrDupS))
			{
				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
			}
			else {	t5FinDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5FinDisposalInstrS:%s",t5FinDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
			if(!nlsIsStrNull(t5RPDisposalInstrDupS))
			{
				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
			}
			else {	t5RPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RPDisposalInstrS:%s",t5RPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
			if(!nlsIsStrNull(t5SPDisposalInstrDupS))
			{
				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
			}else {	t5SPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5SPDisposalInstrS:%s",t5SPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
			if(!nlsIsStrNull(t5WIPDisposalInstrDupS))
			{
				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
			}else {	t5WIPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5WIPDisposalInstrS:%s",t5WIPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
			if(!nlsIsStrNull(t5LastModByDupS))
			{
				t5LastModByS=nlsStrDup(t5LastModByDupS);
			}
			else
			{
				t5LastModByS=nlsStrDup("loader");
			}
			printf("\n\t LH-RH--t5LastModByS:%s",t5LastModByS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
			if(!nlsIsStrNull(t5VerCreatorDupS))
			{
				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
			}else {	t5VerCreatorS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5VerCreatorS:%s",t5VerCreatorS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
			if(!nlsIsStrNull(t5CAEDocEDupS))
			{
				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
			}else {	t5CAEDocES=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5CAEDocES:%s",t5CAEDocES); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
			if(!nlsIsStrNull(t5CoatedDupS))
			{
				t5CoatedS=nlsStrDup(t5CoatedDupS);
			}else {	t5CoatedS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5CoatedS:%s",t5CoatedS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
			if(!nlsIsStrNull(t5ConvDocDupS))
			{
				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
			}else {	t5ConvDocS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ConvDocS:%s",t5ConvDocS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcRevDupS))
			{
				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
			}else {	t5AplCopyOfErcRevS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AplCopyOfErcRevS:%s",t5AplCopyOfErcRevS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcSeqDupS))
			{
				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
			}else {	t5AplCopyOfErcSeqS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AplCopyOfErcSeqS:%s",t5AplCopyOfErcSeqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
			if(!nlsIsStrNull(t5AppCodeDupS))
			{
				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
			}else {	t5AppCodeS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AppCodeS:%s",t5AppCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
			if(!nlsIsStrNull(t5RqstNumDupS))
			{
				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
			}else {	t5RqstNumS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RqstNumS:%s",t5RqstNumS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
			if(!nlsIsStrNull(t5RsnCodeDupS))
			{
				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
			}else {	t5RsnCodeS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RsnCodeS:%s",t5RsnCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
			if(!nlsIsStrNull(t5SurfaceAreaDupS))
			{
				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
			}else {	t5SurfaceAreaS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5SurfaceAreaS:%s",t5SurfaceAreaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
			if(!nlsIsStrNull(t5VolumeDupS))
			{
				t5VolumeS=nlsStrDup(t5VolumeDupS);
			}else {	t5VolumeS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5VolumeS:%s",t5VolumeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
			if(!nlsIsStrNull(t5CarIntialAgencyDupS))
			{
				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
			}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
			if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
			{
				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
			}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
			if(!nlsIsStrNull(t5ErcIndNameDupS))
			{
				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
			}else {	t5ErcIndNameS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ErcIndNameS:%s",t5ErcIndNameS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
			if(!nlsIsStrNull(t5PostRelReqDupS))
			{
				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
			}else {	t5PostRelReqS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PostRelReqS:%s",t5PostRelReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
			if(!nlsIsStrNull(t5ItmCategoryDupS))
			{
				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
			}else {	t5ItmCategoryS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ItmCategoryS:%s",t5ItmCategoryS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
			if(!nlsIsStrNull(t5CopReqDupS))
			{
				t5CopReqS=nlsStrDup(t5CopReqDupS);
			}else {	t5CopReqS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5CopReqS:%s",t5CopReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
			if(!nlsIsStrNull(t5AplInvalidateDupS))
			{
				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
			}else {	t5AplInvalidateS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AplInvalidateS:%s",t5AplInvalidateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
			if(!nlsIsStrNull(t5PrtValiStatusDupS))
			{
				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
			}else {	t5PrtValiStatusS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PrtValiStatusS:%s",t5PrtValiStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
			if(!nlsIsStrNull(t5DRSubStateDupS))
			{
				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
			}else {	t5DRSubStateS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5DRSubStateS:%s",t5DRSubStateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
			if(!nlsIsStrNull(t5KnxtDocIndDupS))
			{
				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
			}else {	t5KnxtDocIndS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5KnxtDocIndS:%s",t5KnxtDocIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
			if(!nlsIsStrNull(t5SimValDupS))
			{
				t5SimValS=nlsStrDup(t5SimValDupS);
				t5SimValS=low_strssra(t5SimValS,"\n"," ");
			}else {	t5SimValS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5SimValS:%s",t5SimValS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
			if(!nlsIsStrNull(t5PerYieldDupS))
			{
				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
			}else {	t5PerYieldS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PerYieldS:%s",t5PerYieldS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
			if(!nlsIsStrNull(t5PunStoreLocationDupS))
			{
				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
			}else {	t5PunStoreLocationS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PunStoreLocationS:%s",t5PunStoreLocationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
			if(!nlsIsStrNull(t5AltPartNoDupS))
			{
				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"\n"," ");
			}else {	t5AltPartNoS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5AltPartNoS:%s",t5AltPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
			if(!nlsIsStrNull(t5RolledupWtDupS))
			{
				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
			}else {	t5RolledupWtS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5RolledupWtS:%s",t5RolledupWtS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
			if(!nlsIsStrNull(t5PFDModReqdDupS))
			{
				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
			}else {	t5PFDModReqdS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5PFDModReqdS:%s",t5PFDModReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
			if(!nlsIsStrNull(t5ToolIndentReqdDupS))
			{
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
			}else {	t5ToolIndentReqdS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--t5ToolIndentReqdS:%s",t5ToolIndentReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
			if(!nlsIsStrNull(CategoryNameDupS))
			{
				CategoryNameS=nlsStrDup(CategoryNameDupS);
				CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
				CategoryNameS=low_strssra(CategoryNameS,"^"," ");
			}else {	CategoryNameS=nlsStrDup(" ");	}
			printf("\n\t LH-RH--CategoryNameS:%s",CategoryNameS); fflush(stdout);


			// For effectivity extract
			t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
			// Get the configuration context object from the general context.
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
			// Set the option as "LkoCtxt" in the context object
			t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
			t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
			t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
			t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
			printf("\n\t LH-RH-- setSize(soExpObj):%d ",setSize(soExpObj)); fflush(stdout);
			if(setSize(soExpObj)>0)
			{
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;
				if(!nlsIsStrNull(ReveffDateFrom))
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
				}
				else
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateTo);
				}

				if(!nlsIsStrNull(ReveffDateTo))
				{
					ReveffDateToDup = nlsStrDup(ReveffDateTo);
				}
				else
				{
					ReveffDateToDup = nlsStrDup(ReveffDateFrom);
				}
			}
			else
			{
				ReveffDateFromDup = nlsStrDup("-");
				ReveffDateToDup = nlsStrDup("-");
			}

			printf("\n\t LH-RH--ReveffDateFromDup:%s",ReveffDateFromDup); fflush(stdout);
			printf("\n\t LH-RH--ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
			t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
			printf("\n\t LH-RH--t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
			t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
			printf("\n\t LH-RH--t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
			t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
			printf("\n\t LH-RH--t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
			t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
			printf("\n\t LH-RH--t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
			t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
			printf("\n\t LH-RH--t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
			t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
			printf("\n\t LH-RH--t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
			t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
			printf("\n\t LH-RH--t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
			t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
			printf("\n\t LH-RH--t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
			t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
			printf("\n\t LH-RH--t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
			t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
			printf("\n\t LH-RH--t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
			if(!nlsIsStrNull(t5EstSheetReqdDupS))
			{
				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
			}
			else
			{
				t5EstSheetReqdS=nlsStrDup(" ");	
			}
			printf("\n\t LH-RH--t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CreationDate",&PartCreDateS));
			if(!nlsIsStrNull(PartCreDateS))
			{
				PartCreDateDupS=nlsStrDup(PartCreDateS);
			}
			else
			{
				PartCreDateDupS=nlsStrDup("-");
			}
			printf("\n\t LH-RH--PartCreDateDupS:%s",PartCreDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"LastUpdate",&PartModDateS));
			if(!nlsIsStrNull(PartModDateS))
			{
				PartModDateDupS=nlsStrDup(PartModDateS);
			}
			else
			{
				PartModDateDupS=nlsStrDup("-");
			}
			printf("\n\t LH-RH--PartModDateDupS:%s",PartModDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"Creator",&PartCreator));
			PartCreatorDup=nlsStrDup(PartCreator);
			printf("\n\t LH-RH--PartCreatorDup:%s",PartCreatorDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
			if(!nlsIsStrNull(t5AhdIntialAgencyS))
			{
				t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
			}
			else
			{
				t5AhdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
			if(!nlsIsStrNull(t5AhdMakeBuyIndS))
			{
				t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
			}
			else
			{
				t5AhdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
			if(!nlsIsStrNull(t5DwdIntialAgencyS))
			{
				t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
			}
			else
			{
				t5DwdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
			if(!nlsIsStrNull(t5DwdMakeBuyIndS))
			{
				t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
			}
			else
			{
				t5DwdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
			if(!nlsIsStrNull(t5JdlIntialAgencyS))
			{
				t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
			}
			else
			{
				t5JdlIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
			if(!nlsIsStrNull(t5JdlMakeBuyIndS))
			{
				t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
			}
			else
			{
				t5JdlMakeBuyIndSDup = nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
			if(!nlsIsStrNull(t5AhdStoreLocS))
			{
				t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
			}
			else
			{
				t5AhdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarStoreLocation",&t5CarStoreLocS));
			if(!nlsIsStrNull(t5CarStoreLocS))
			{
				t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
			}
			else
			{
				t5CarStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
			if(!nlsIsStrNull(t5DwdStoreLocS))
			{
				t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
			}
			else
			{
				t5DwdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
			if(!nlsIsStrNull(t5JdlStoreLocS))
			{
				t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
			}
			else
			{
				t5JdlStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
			if(!nlsIsStrNull(t5JsrStoreLocS))
			{
				t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
			}
			else
			{
				t5JsrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
			if(!nlsIsStrNull(t5LkoStoreLocS))
			{
				t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
			}
			else
			{
				t5LkoStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
			if(!nlsIsStrNull(t5PnrStoreLocS))
			{
				t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
			}
			else
			{
				t5PnrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
			if(!nlsIsStrNull(t5PunPCBUStoreLocS))
			{
				t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
			}
			else
			{
				t5PunPCBUStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
			if(!nlsIsStrNull(t5SgrStoreLocS))
			{
				t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
			}
			else
			{
				t5SgrStoreLocSDup = nlsStrDup("");
			}


			fprintf(fpAllRev,"%s",PartNumberDupS);			//1		// in function LH-RH
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",RevisionDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SequenceDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",NomenclatureDupS); //desc
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",PartTypeDupS);  //PartType
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",ProjectNameDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DesignGroupDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DocRemarkDupS); //mod_desc
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5DrawingNoDupS)){
				fprintf(fpAllRev,"%s",t5DrawingNoDupS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"%s",t5DrawingIndDupS);		//10		// in function LH-RH
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MatlClassDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MaterialInDrwDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",MaterialThickNessDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5LeftRhDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DsgnOwnDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ModelIndicatorDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",UnitOfMeasureDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIndDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",LifeCycleStateDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIDDupS);				//20		// in function LH-RH
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",WeightDupS);					//21
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SpareIndDupS);				//22
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5CMVRCertificationS)){
				fprintf(fpAllRev,"%s",t5CMVRCertificationS);	//23
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ClassificationHazS)){
				fprintf(fpAllRev,"%s",t5ClassificationHazS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ConfigIDS)){
				fprintf(fpAllRev,"%s",t5ConfigIDS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5DismantableS)){
				fprintf(fpAllRev,"%s",t5DismantableS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DsgnDeptS)){
				fprintf(fpAllRev,"%s",t5DsgnDeptS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5EnvelopeDimenS)){
				fprintf(fpAllRev,"%s",t5EnvelopeDimenS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HazardousContS)){
				fprintf(fpAllRev,"%s",t5HazardousContS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HomologationReqdS)){
				fprintf(fpAllRev,"%s",t5HomologationReqdS);		//30		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ListRecSparess)){
				fprintf(fpAllRev,"%s",t5ListRecSparess);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5NcPartNoS)){
				fprintf(fpAllRev,"%s",t5NcPartNoS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartCodeS)){
				fprintf(fpAllRev,"%s",t5PartCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartPropertyS)){
				fprintf(fpAllRev,"%s",t5PartPropertyS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartStatusS)){
				fprintf(fpAllRev,"%s",t5PartStatusS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PkgStdS)){
				fprintf(fpAllRev,"%s",t5PkgStdS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ProductS)){
				fprintf(fpAllRev,"%s",t5ProductS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtCatCodeS)){
				fprintf(fpAllRev,"%s",t5PrtCatCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunIntialAgS)){
				fprintf(fpAllRev,"%s",t5PunIntialAgS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
				fprintf(fpAllRev,"%s",t5PunMakeBuyIndS);	//40		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecoverableS)){
				fprintf(fpAllRev,"%s",t5RecoverableS);		//41
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecyclabilityS)){
				fprintf(fpAllRev,"%s",t5RecyclabilityS);	//42
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RefPartNumberS)){
				fprintf(fpAllRev,"%s",t5RefPartNumberS);	//43
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ReliabilityS)){
				fprintf(fpAllRev,"%s",t5ReliabilityS);		//44
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SpareCriteriaS)){
				fprintf(fpAllRev,"%s",t5SpareCriteriaS);	//45
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfPrtStdS)){
				fprintf(fpAllRev,"%s",t5SurfPrtStdS);		//46
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SamplesToApprS)){
				fprintf(fpAllRev,"%s",t5SamplesToApprS);	//47
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AsmDisposalS)){
				fprintf(fpAllRev,"%s",t5AsmDisposalS);		//48
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5FinDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5FinDisposalInstrS);	//49
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5RPDisposalInstrS);	//50		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5SPDisposalInstrS);	//51
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5WIPDisposalInstrS);	//52
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5LastModByS)){
				fprintf(fpAllRev,"%s",t5LastModByS);		//53
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev,"loader^");
			}


			if(!nlsIsStrNull(t5VerCreatorS)){
				fprintf(fpAllRev,"%s",t5VerCreatorS);		//54
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CAEDocES)){
				fprintf(fpAllRev,"%s",t5CAEDocES);			//55
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CoatedS)){
				fprintf(fpAllRev,"%s",t5CoatedS);			//56
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5ConvDocS)){
				fprintf(fpAllRev,"%s",t5ConvDocS);			//57
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcRevS);	//58
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcSeqS);	//59
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AppCodeS)){
				fprintf(fpAllRev,"%s",t5AppCodeS);			//60		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RqstNumS)){
				fprintf(fpAllRev,"%s",t5RqstNumS);			//61
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RsnCodeS)){
				fprintf(fpAllRev,"%s",t5RsnCodeS);			//62
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfaceAreaS)){
				fprintf(fpAllRev,"%s",t5SurfaceAreaS);		//63
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5VolumeS)){
				fprintf(fpAllRev,"%s",t5VolumeS);			//64
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CarIntialAgencyS)){
				fprintf(fpAllRev,"%s",t5CarIntialAgencyS);	//65		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
				fprintf(fpAllRev,"%s",t5CarMakeBuyIndiS);	//66
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ErcIndNameS)){
				fprintf(fpAllRev,"%s",t5ErcIndNameS);		//67
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PostRelReqS)){
				fprintf(fpAllRev,"%s",t5PostRelReqS);		//68
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ItmCategoryS)){
				fprintf(fpAllRev,"%s",t5ItmCategoryS);		//69
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CopReqS)){
				fprintf(fpAllRev,"%s",t5CopReqS);			//70		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplInvalidateS)){
				fprintf(fpAllRev,"%s",t5AplInvalidateS);	//71
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtValiStatusS)){
				fprintf(fpAllRev,"%s",t5PrtValiStatusS);	//72
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DRSubStateS)){
				fprintf(fpAllRev,"%s",t5DRSubStateS);		//73
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5KnxtDocIndS)){
				fprintf(fpAllRev,"%s",t5KnxtDocIndS);		//74
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5SimValS)){
				fprintf(fpAllRev,"%s",t5SimValS);			//75		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PerYieldS)){
				fprintf(fpAllRev,"%s",t5PerYieldS);			//76
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunStoreLocationS)){
				fprintf(fpAllRev,"%s",t5PunStoreLocationS);	//77
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AltPartNoS)){
				fprintf(fpAllRev,"%s",t5AltPartNoS);		//78
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5RolledupWtS)){
				fprintf(fpAllRev,"%s",t5RolledupWtS);		//79
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PFDModReqdS)){
				fprintf(fpAllRev,"%s",t5PFDModReqdS);		//80		// in function LH-RH
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ToolIndentReqdS)){
				fprintf(fpAllRev,"%s",t5ToolIndentReqdS);	//81
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(CategoryNameS)){
				fprintf(fpAllRev,"%s",CategoryNameS);		//82
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(ReveffDateFromDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateFromDup);	//83
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(ReveffDateToDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateToDup);		//84
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(LhRhPartNumberDup))
			{
				fprintf(fpAllRev,"%s",LhRhPartNumberDup);		//85		// in function LH-RH
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"NA^");
			}

			fprintf(fpAllRev," ^");	//Instance with semicolon separated Rev;Seq		//86

			//below attributes are added by rrr on 14.10.2016
			if(!nlsIsStrNull(t5JsrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5JsrIntialAgencyS);		//87
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5JsrMakeBuyIndiS);		//88
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5LkoIntialAgencyS);		//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5LkoMakeBuyIndiS);		//90		// in function LH-RH
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PnrIntialAgencyS);		//91
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PnrMakeBuyIndiS);		//92
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUIntialAgencyS);	//93
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUMakeBuyIndiS);	//94
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5SgrIntialAgencyS);		//95		// in function LH-RH
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5SgrMakeBuyIndiS);		//96
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5EstSheetReqdS))
			{
				fprintf(fpAllRev,"%s",t5EstSheetReqdS);			//97
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(PartCreDateDupS))
			{
				fprintf(fpAllRev,"%s",PartCreDateDupS);			//98
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartModDateDupS))
			{
				fprintf(fpAllRev,"%s",PartModDateDupS);			//99		// in function LH-RH
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartCreatorDup))
			{
				fprintf(fpAllRev,"%s",PartCreatorDup);			//100		//in function LH-RH
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"loader^");
			}
			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5AhdIntialAgencySDup);	//101
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5AhdMakeBuyIndSDup);		//102
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdIntialAgencySDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5DwdIntialAgencySDup);	//103
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5DwdMakeBuyIndSDup);		//104
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlIntialAgencySDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5JdlIntialAgencySDup);	//105
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JdlMakeBuyIndSDup);		//106
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5AhdStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5AhdStoreLocSDup);		//107
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5CarStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5CarStoreLocSDup);		//108		//In main
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5DwdStoreLocSDup);		//109
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JdlStoreLocSDup);		//110
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JsrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JsrStoreLocSDup);		//111
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5LkoStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5LkoStoreLocSDup);		//112
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5PnrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5PnrStoreLocSDup);		//113
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5PunPCBUStoreLocSDup);	//114
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5SgrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5SgrStoreLocSDup);		//115		//In main
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"\n");

			fflush(fpAllRev);
			printf("\n Inside fpAllRev --------------------------123\n"); fflush(stdout);

//			if (m == (setSize(PartSO)-1))	// LH/RH is added on 28.09.2016 by RRR
//			{
//				if (setSize(partMasterSO)>0)
//				{
//					if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
//					{
//						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
//
//						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
//						if(!nlsIsStrNull(LHRhPartNumber))
//						{
//							LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
//						}
//						else
//						{
//							LHRhPartNumberDupS=nlsStrDup("NA");
//						}
//					}
//
//					if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
//					{
//						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
//
//						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
//						if(!nlsIsStrNull(LHRhPartNumber))
//						{
//							LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
//						}
//						else
//						{
//							LHRhPartNumberDupS=nlsStrDup("NA");
//						}
//					}
//					printf("\n\t **LHRhPartNumberDupS:%s",LHRhPartNumberDupS); fflush(stdout);
//
//					//query part again to get all attributes to copy in allpartsAllRev file
//
//					//if((nlsStrCmp(LHRhPartNumberDupS,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDupS)))
//					//{
//					//	t5CheckMfail(GetLhRhTCPartProEInfo(LHRhPartNumberDupS,PartNumberDupS,fpAllRev,OutJtfp,LhRHErr,mfail));
//					//}
//				}
//			}

			if(OutJtfp == NULL)
			{
				printf("\n *****File OutJtfp unable to open and copy cad data"); fflush(stdout);
				fprintf(LhRHErr,"\n *****File OutJtfp unable to open and copy cad data"); fflush(LhRHErr);
			}

			if (setSize(latestDocDs)>0)
			{
				objDisposeAll(latestDocDs);
				latestDocDs = NULL;
			}
			if (setSize(latestRelDocDs)>0)
			{
				objDisposeAll(latestRelDocDs);
				latestRelDocDs = NULL;
			}
			if (setSize(LatestRefDocSO)>0)
			{
				objDisposeAll(LatestRefDocSO);
				LatestRefDocSO = NULL;
			}
			if (setSize(LatestRefRelDocSO)>0)
			{
				objDisposeAll(LatestRefRelDocSO);
				LatestRefRelDocSO = NULL;
			}

			if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docDObjs,&docDRelObjs,mfail)) goto CLEANUP;
			if(SetFlagforScope(docDObjs)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docDObjs,&docDRelObjs,mfail)) goto CLEANUP;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			if (setSize(docDObjs) > 0)
			{
				//printf("\n\t  1..Doc present "); fflush(stdout);
				if(dstat = t5GetLatestDocumnets(docDObjs,docDRelObjs,&latestDocDs,&latestRelDocDs,mfail)) goto CLEANUP;
			}

			if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentRefSO,&DocumentRefRelSO,mfail)) goto CLEANUP;
			if(SetFlagforScope(DocumentRefSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentRefSO,&DocumentRefRelSO,mfail)) goto CLEANUP;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			if (setSize(DocumentRefSO) > 0)
			{
				//printf("\n\t  1..Reference Doc present"); fflush(stdout);
				if(dstat = t5GetLatestDocumnets(DocumentRefSO,DocumentRefRelSO,&LatestRefDocSO,&LatestRefRelDocSO,mfail)) goto CLEANUP;
			}

			if(setSize(latestDocDs) <= 0)
			{
				latestDocDs  = setCreate(1);
				for(count=0 ; count  < setSize(LatestRefDocSO) ; count++)
                {
					low_set_add(latestDocDs,setGet(LatestRefDocSO,count));
				}
			}
			else
			{
				low_set_cat(latestDocDs,LatestRefDocSO);
			}
			printf("\n LH-RH--setSize(docDObjs): %d   setSize(latestDocDs): %d",setSize(docDObjs),setSize(latestDocDs));

			if (setSize(latestDocDs)>0)
			{
				for(noOfDocs = 0; noOfDocs<setSize(latestDocDs); noOfDocs++)
				{
					docClass = low_getspace(10);

					docDOPtr = setGet(latestDocDs, noOfDocs);
					if(dstat = objGetClass(docDOPtr, &docClass)) goto CLEANUP;
					printf("\ndocClass: %s",docClass); fflush(stdout);

					if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;
					if(SetFlagforScope(DataItemSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}

					if(setSize(DataItemSO)>0)
					{
						DataItClass = low_getspace(10);

						for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
						{
							NewDataItemObjPtr=setGet(DataItemSO,DataItem);

							if(dstat = objGetClass(NewDataItemObjPtr, &DataItClass)) goto CLEANUP;
							printf("  DataItClass: %s",DataItClass); fflush(stdout);

							if(dstat=GetInfoItem(NewDataItemObjPtr,&GetItemInfoObjPtr,mfail)) goto CLEANUP;

							if(dstat = objGetAttribute(GetItemInfoObjPtr,"RelativePath",&RelativePath)) goto CLEANUP;
							if(!nlsIsStrNull(RelativePath))
							{
								RelativePathDup=nlsStrDup(RelativePath);
							}
							else
							{
								RelativePathDup=nlsStrDup(" ");
								continue;
							}

							if(dstat = objGetAttribute(GetItemInfoObjPtr,"WorkingRelativePath",&WRelativePath)) goto CLEANUP;
							if(!nlsIsStrNull(WRelativePath))
							{
								WRelativePathDup=nlsStrDup(WRelativePath);
							}
							else
							{
								WRelativePathDup=nlsStrDup(" ");
								continue;
							}

							if(dstat = objGetAttribute(GetItemInfoObjPtr,"OwnerDirName",&OwnerDirName)) goto CLEANUP;
							OwnerDirNameDup=nlsStrDup(OwnerDirName);

							if(dstat = objGetAttribute(GetItemInfoObjPtr,"OwnerName",&OwnerName)) goto CLEANUP;
							OwnerNameDup=nlsStrDup(OwnerName);

							t5CheckDstat(objGetAttribute(NewDataItemObjPtr,"DisplayedName",&DataItemDisplayNm));
							if(!nlsIsStrNull(DataItemDisplayNm))
							{
								DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
							}

							if((nlsStrCmp(docClass,"DesDoc") == 0) && ((nlsStrCmp(DataItClass,"ProAsm") == 0) || (nlsStrCmp(DataItClass,"ProPrt") == 0)) )
							{
								printf("\nLH-RH--%s,%s,%s,%s,%s,%s,%s,%s",RelativePathDup,WRelativePathDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(stdout);
								//fprintf(OutJtfp,"%s,%s,%s,%s,%s,%s,%s,%s\n",WRelativePathDup,OwnerDirNameDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(OutJtfp);

								//Below commented on 30.11.2016 to skip CAD Data

//								fprintf(OutJtfp,"%s,",RelativePathDup);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",WRelativePathDup);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",OwnerDirNameDup);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",OwnerNameDup);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",DataItClass);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);
//								fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);
//								fprintf(OutJtfp,"\n");
//								fflush(OutJtfp);

								//Below commented on 30.09.2016 to skip JT
//								t5CheckMfail(ExpandObject2("ProToVis",NewDataItemObjPtr,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&JTPartSO,&JTPartRelSO,mfail));
//								printf("\n number of jt files attached: %d",setSize(JTPartSO));
//								if (setSize(JTPartSO)==1)
//								{
//									JTPartObjP=setGet(JTPartSO,0);
//
//									t5CheckDstat(objCopy(&JTObjP,JTPartObjP));
//
//									t5CheckDstat(objGetAttribute(JTObjP,"RelativePath",&JTRelativePathS));
//									if(JTRelativePathDup!=NULL)
//									{
//										nlsStrFree(JTRelativePathDup);
//										JTRelativePathDup = NULL;
//									}
//									JTRelativePathDup=nlsStrDup(JTRelativePathS);
//									//printf("\n JTRelativePathDup is: %s ",JTRelativePathDup);
//
//									t5CheckDstat(objGetAttribute(JTObjP,"WorkingRelativePath",&JTWRelativePathS));
//									if(JTWRelativePathDup!=NULL)
//									{
//										nlsStrFree(JTWRelativePathDup);
//										JTWRelativePathDup = NULL;
//									}
//									JTWRelativePathDup=nlsStrDup(JTWRelativePathS);
//
//									t5CheckDstat(objGetAttribute(JTObjP,"OwnerName",&JTOwnerNameDupS));
//									JTOwnerNameS=nlsStrDup(JTOwnerNameDupS);
//
//									t5CheckDstat(objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJTDupS));
//									OwnerDirNameJTS=nlsStrDup(OwnerDirNameJTDupS);
//
//									fprintf(OutJtfp,"%s,",JTRelativePathDup);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",JTWRelativePathDup);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",OwnerDirNameJTS);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",JTOwnerNameS);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",DataItClass);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);
//									fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);
//									fprintf(OutJtfp,"\n");
//									fflush(OutJtfp);
//								}
							}
							else if((nlsStrCmp(docClass,"x0PrdDoc") == 0) )
							{
								printf("\n%s,%s,%s,%s,%s,%s,%s,%s",RelativePathDup,WRelativePathDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(stdout);
								
								//Below commented on 30.11.2016 to skip CAD Data
								//fprintf(OutJtfp,"%s,%s%s,%s,%s,%s,%s,%s\n",RelativePathDup,WRelativePathDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(OutJtfp);
							}
						}
					}
				} // for loop of setSize(latestDocs)

				//if (m == (setSize(PartSO)-1))
				//{
				if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
				{
					for(noOfDocs = 0; noOfDocs<setSize(latestDocDs); noOfDocs++)
					{
						docClass = low_getspace(10);

						docDOPtr = setGet(latestDocDs, noOfDocs);
						if(dstat = objGetClass(docDOPtr, &docClass)) goto CLEANUP;
						printf("\ndocClass: %s",docClass); fflush(stdout);

						if(nlsStrCmp(docClass,"t5DrwDoc") == 0)
						{
							if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;
							if(SetFlagforScope(DataItemSO)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}

							if(setSize(DataItemSO)>0)
							{
								for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
								{
									NewDataItemObjP=setGet(DataItemSO,DataItem);

									t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
									DiClassS=nlsStrDup(DiClassDupS);
									printf("\n Data item class name:[%s]",DiClassS);

									t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));

									if((nlsStrCmp(DiClassS,"ProDrw")==0) || (nlsStrCmp(DiClassS,"x0CatDrw")==0))
									{
										t5CheckDstat(objGetAttribute(DataItemObjP,OwnerNameAttr,&DIOwnerNameDup));
										DIOwnerName=nlsStrDup(DIOwnerNameDup);

										//if ((nlsStrCmp(DIOwnerName,"Release Vault")==NULL) || (nlsStrStr(DIOwnerName,"CE Vault")!=NULL) )
										//{
											t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&DIRelPathDup));
											DIRelPath=nlsStrDup(DIRelPathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"DisplayedName",&DIDisplayNmDup));
											DIDisplayNm=nlsStrDup(DIDisplayNmDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"WorkingRelativePath",&DIFileWorkingRelativePathDup));
											DIFileWorkingRelativePath=nlsStrDup(DIFileWorkingRelativePathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,SequenceAttr,&DISequenceDup));
											DISequence=nlsStrDup(DISequenceDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"OwnerDirName",&DIOwnerDirNameDup));
											DIOwnerDirName=nlsStrDup(DIOwnerDirNameDup);

											t5CheckDstat(GetInfoItem(DataItemObjP,&proprtDIObjP,mfail));

											t5CheckDstat(objGetAttribute(proprtDIObjP,"FullPath",&DIfullPathDup)) ;
											DIfullPath=nlsStrDup(DIfullPathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"DisplayedName",&DataItemDisplayNm));
											if(!nlsIsStrNull(DataItemDisplayNm))
											{
												DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
											}
										//}

										//Below commented on 30.11.2016 to skip Drawing/Drw/Drg CAD Data
//										fprintf(OutJtfp,"%s,",DIRelPath);fflush(OutJtfp);			 		//DataItem RelativePath
//										fprintf(OutJtfp,"%s,",DIFileWorkingRelativePath);fflush(OutJtfp);	//DataItem WorkingRelativePath
//										fprintf(OutJtfp,"%s,",DIOwnerDirName);fflush(OutJtfp);				//DataItem OwnerDirName
//										fprintf(OutJtfp,"%s,",DIOwnerName);fflush(OutJtfp);					//DataItem OwnerName
//										fprintf(OutJtfp,"%s,",DiClassS);fflush(OutJtfp);					//DataItem ClassName
//										fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);					//TC Part Rev;Seq
//										fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);				//TC PartNumber for reference drawing relation check
//										fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);		//DataItem DisplayNm
//										fprintf(OutJtfp,"\n");
//										fflush(OutJtfp);

										t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
										if(SetFlagforScope(VisualizationFileSO)==1)
										{
											if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
											t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
											if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
										}

										if(setSize(VisualizationFileSO)>0)
										{
											for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
											{
												NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

												t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));

												t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
												VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);

												//if ((nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL) || (nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL) || (nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL) )
												//{
													t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
													VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&PdfDisDupS));
													PdfDisS=nlsStrDup(PdfDisDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
													VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
													VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
													VisFileClassS=nlsStrDup(VisFileClassDupS);


													t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
													VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);

													t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));

													t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
													fullPathattrDup=nlsStrDup(fullPathattr);
												//}

												//Below commented on 30.11.2016 to skip CAD JT Data
//												fprintf(OutJtfp,"%s,",VisFileRelPathS);fflush(OutJtfp);			 	//PDF RelativePath
//												fprintf(OutJtfp,"%s,",VisFileWorkingRelativePathS);fflush(OutJtfp);	//PDF WorkingRelativePath
//												fprintf(OutJtfp,"%s,",VisFileOwnerDirNameS);fflush(OutJtfp);			//PDF OwnerDirName
//												fprintf(OutJtfp,"%s,",VisFileOwnerNameS);fflush(OutJtfp);				//PDF OwnerName
//												fprintf(OutJtfp,"%s,",VisFileClassS);fflush(OutJtfp);					//PDF ClassName
//												fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);					//TC Part Rev;Seq
//												fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);				//TC PartNumber for reference drawing relation check
//												fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);					//DataItem DisplayNm
//												fprintf(OutJtfp,"\n");
//												fflush(OutJtfp);
											}
										} // if condn end for setSize(VisualizationFileSO)
									}

								} //for loop end setSize(DataItemSO)
							} // if condn end for setSize(DataItemSO)
						}
					} // for loop of setSize(latestDocs)
				}
				//}
			} //if condn end for setSize(latestDocs)
		} // for loop of setSize(PartSO)
	} //if condn end for setSize(PartSO)
	//printf("\n");

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartSO);
		t5FreeSqlPtr(Sql_ptr);

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}*/
status t5SortByCreationDate(SetOfObjects *itemObjs, SetOfObjects *relObjs, integer* mfail )
{
	//MODNAME("t5SortByCreationDate");
   	//char *mod_name = "t5SortByCreationDate";

	status dstat = OKAY;
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpRelObjs = NULL;
   	ObjectPtr relObj = NULL;
   	ObjectPtr itemObj = NULL;
   	ObjectPtr relTObj = NULL;
   	ObjectPtr itemTObj = NULL;
	ObjectPtr tmpRelObj = 0;
	integer count = 0;
	integer cmpCount = 0;
	string curCreDate = NULL;
	string tmpcurCreDate = NULL;
	string cmpCreDate = NULL;
	string tmpcmpCreDate = NULL;
	*mfail = USC_OKAY;

	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		// initalizing sorted object set
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
		if(curCreDate!= NULL && nlsStrCmp(curCreDate,"")!=0)
		{
			tmpcurCreDate = nlsStrDup(curCreDate);
		}

		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
			if(cmpCreDate!= NULL && nlsStrCmp(cmpCreDate,"")!=0)
			{
				tmpcmpCreDate = nlsStrDup(cmpCreDate);
			}

			if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) >= 0)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
			low_set_insrt(tmpRelObjs, cmpCount, relTObj);
			low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}

	// free memory and assign to new set sorted objects
	objDisposeAll(*itemObjs); *itemObjs = NULL;
	objDisposeAll(*relObjs); *relObjs = NULL;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:
   	return( dstat );
}
status GetGenTCPartProEInfo(string InpPartNumberS, string RevisionS1, string SequenceS1, string InstanceRevSeqS, FILE* fpAllRev, FILE* fpGen, integer* mfail )
{
	char *mod_name = "GetGenTCPartProEInfo";

	status dstat = OKAY;

	string PartNumberDupS=NULL;
	string PartNumberS=NULL;
	//string PartRevisionDupS=NULL;
	//string PartRevisionS=NULL;
	//string PartSequenceDupS=NULL;
	//string PartSequenceS=NULL;
	//string PartOwnerNameDupS=NULL;
	//string PartOwnerNameS=NULL;
	string docClass=NULL;
	//string DataItClass = NULL;
	//string WorkingFileNm = NULL;
	//string WorkingFileNmDup = NULL;
	//string wrelativepath = NULL;
	//string wrelativepathDup = NULL;
	//string GenFullPath = NULL;
	//string GenFullPathDup = NULL;
	//string Sequence = NULL;
	//string SequenceDup = NULL;
	//string OwnerDirName = NULL;
	//string OwnerDirNameDup = NULL;
	//string OwnerName = NULL;
	//string OwnerNameDup = NULL;
	string PartRevSeq = NULL;

	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	//string t5DocumentTypeDupS = NULL;
	//string t5DocumentTypeS = NULL;
	//string t5SourceDataErrorsDupS = NULL;
	//string t5SourceDataErrorsS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	//string LHRhPartNumber = NULL;
	//string LHRhPartNumberDupS = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string t5ColourIDS = NULL;
	string t5ColourIDDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	/*string OwnerDirS = NULL;
	string level = NULL;
	string dummypart = NULL;
	string t5DocumentName = NULL;
	string t5DocumentNameDupS = NULL;
	string t5DocumentRev = NULL;
	string t5DocumentRevDupS = NULL;
	string t5DocumentSeq = NULL;
	string t5DocumentSeqDupS = NULL;*/
	string t5CMVRCertificationS = NULL;
	string t5CMVRCertificationDupS = NULL;
	string t5ClassificationHazDupS = NULL;
	string t5ClassificationHazS = NULL;
	string t5ConfigIDS = NULL;
	string t5ConfigIDDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5ListRecSparess = NULL;
	string t5ListRecSparesDups = NULL;
	string t5NcPartNoS = NULL;
	string t5PartCodeS = NULL;
	string t5NcPartNoDupS = NULL;
	string t5PartCodeDupS = NULL;
	string t5PartPropertyS = NULL;
	string t5PartPropertyDupS = NULL;
	string t5PartStatusS = NULL;
	string t5PartStatusDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PrtCatCodeS = NULL;
	string t5PrtCatCodeDupS = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5RefPartNumberS = NULL;
	string t5RefPartNumberDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SurfPrtStdS = NULL;
	string t5SurfPrtStdDupS = NULL;
	string t5SamplesToApprS = NULL;
	string t5SamplesToApprDupS = NULL;
	string t5AsmDisposalS = NULL;
	string t5AsmDisposalDupS = NULL;
	string t5FinDisposalInstrS = NULL;
	string t5FinDisposalInstrDupS = NULL;
	string t5RPDisposalInstrS = NULL;
	string t5RPDisposalInstrDupS = NULL;
	string t5SPDisposalInstrS = NULL;
	string t5SPDisposalInstrDupS = NULL;
	string t5WIPDisposalInstrS = NULL;
	string t5WIPDisposalInstrDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5CAEDocES = NULL;
	string t5CAEDocEDupS = NULL;
	string t5CoatedS = NULL;
	string t5CoatedDupS = NULL;
	string t5ConvDocS = NULL;
	string t5ConvDocDupS = NULL;
	string t5AplCopyOfErcRevS = NULL;
	string t5AplCopyOfErcRevDupS = NULL;
	string t5AplCopyOfErcSeqS = NULL;
	string t5AplCopyOfErcSeqDupS = NULL;
	string t5AppCodeS = NULL;
	string t5AppCodeDupS = NULL;
	string t5RqstNumS = NULL;
	string t5RqstNumDupS = NULL;
	string t5RsnCodeS = NULL;
	string t5RsnCodeDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5ErcIndNameS = NULL;
	string t5ErcIndNameDupS = NULL;
	string t5PostRelReqS = NULL;
	string t5PostRelReqDupS = NULL;
	string t5ItmCategoryS = NULL;
	string t5ItmCategoryDupS = NULL;
	string t5CopReqS = NULL;
	string t5CopReqDupS = NULL;
	string t5AplInvalidateS = NULL;
	string t5AplInvalidateDupS = NULL;
	string t5PrtValiStatusS = NULL;
	string t5PrtValiStatusDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5KnxtDocIndS = NULL;
	string t5KnxtDocIndDupS = NULL;
	string t5SimValS = NULL;
	string t5SimValDupS = NULL;
	string t5PerYieldS = NULL;
	string t5PerYieldDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5AltPartNoS = NULL;
	string t5AltPartNoDupS = NULL;
	string t5RolledupWtS = NULL;
	string t5RolledupWtDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string t5PFDModReqdS = NULL;
	string t5PFDModReqdDupS = NULL;
	string t5ToolIndentReqdS = NULL;
	string t5ToolIndentReqdDupS = NULL;
	string CategoryNameDupS = NULL;
	string CategoryNameS = NULL;
	string ReveffDateFrom = NULL;
	string ReveffDateFromDup = NULL;
	string ReveffDateTo = NULL;
	string ReveffDateToDup = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;

	/*string RelativePath = NULL;
	string RelativePathDup = NULL;
	string WRelativePath = NULL;
	string WRelativePathDup = NULL;
	string OwnerDirName = NULL;
	string OwnerDirNameDup = NULL;
	string OwnerName = NULL;
	string OwnerNameDup = NULL;
	string DataItemDisplayNm = NULL;
	string DataItemDisplayNmDup = NULL;*/
	//string JTRelativePathS = NULL;
	//string JTRelativePathDup = NULL;
	//string JTWRelativePathS = NULL;
	//string JTWRelativePathDup = NULL;
	//string JTOwnerNameS = NULL;
	//string JTOwnerNameDupS = NULL;
	//string OwnerDirNameJTS = NULL;
	//string OwnerDirNameJTDupS = NULL;

	/*string DiClassDupS = NULL;
	string DiClassS = NULL;
	string DIOwnerNameDup = NULL;
	string DIOwnerName = NULL;
	string DIRelPathDup = NULL;
	string DIRelPath = NULL;
	string DIDisplayNmDup = NULL;
	string DIDisplayNm = NULL;
	string DIFileWorkingRelativePathDup = NULL;
	string DIFileWorkingRelativePath = NULL;
	string DISequenceDup = NULL;
	string DISequence = NULL;
	string DIOwnerDirNameDup = NULL;
	string DIOwnerDirName = NULL;
	string DIfullPathDup = NULL;
	string DIfullPath = NULL;
	string VisFileOwnerNameDupS = NULL;
	string VisFileOwnerNameS = NULL;
	string VisFileRelPathDupS = NULL;
	string VisFileRelPathS = NULL;
	string PdfDisDupS = NULL;
	string PdfDisS = NULL;
	string VisFileWorkingRelativePathDupS = NULL;
	string VisFileWorkingRelativePathS = NULL;
	string VisFileSequenceDupS = NULL;
	string VisFileSequenceS = NULL;
	string VisFileClassDupS = NULL;
	string VisFileClassS = NULL;
	string VisFileOwnerDirNameDupS = NULL;
	string VisFileOwnerDirNameS = NULL;
	string fullPathattrDup = NULL;
	string fullPathattr = NULL;*/

	SetOfObjects PartSO = NULL ;
	SetOfObjects partMasterSO = NULL;
	SetOfObjects partMasterRelSO = NULL;
	//SetOfObjects hasRHItmMster = NULL;
	SetOfObjects docObjs = NULL ;
	SetOfObjects docRelObjs = NULL ;
	SetOfObjects latestDocs = NULL ;
	SetOfObjects latestRelDocs = NULL ;
	//SetOfObjects DataItemJtSO = NULL ;
	SetOfObjects soExpObj = NULL ;
	SetOfObjects relObjSet = NULL ;
	//SetOfObjects docDObjs = NULL;
	//SetOfObjects docDRelObjs = NULL;
	//SetOfObjects latestDocDs = NULL;
	//SetOfObjects latestRelDocDs = NULL;
	//SetOfObjects DocumentRefSO = NULL;
	//SetOfObjects DocumentRefRelSO = NULL;
	//SetOfObjects LatestRefDocSO = NULL;
	//SetOfObjects LatestRefRelDocSO = NULL;
	//SetOfObjects DataItemSO = NULL;
	//SetOfObjects JTPartSO = NULL;
	//SetOfObjects JTPartRelSO = NULL;
	//SetOfObjects VisualizationFileSO = NULL;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr docOPtr=NULL;
	//ObjectPtr NewDataItemObjP=NULL;
	//ObjectPtr GetItemInfoObjP=NULL;
	ObjectPtr contextObj = NULL;
	ObjectPtr genContextObj	= NULL;
	//ObjectPtr docDOPtr = NULL;
	//ObjectPtr NewDataItemObjPtr = NULL;
	//ObjectPtr GetItemInfoObjPtr = NULL;
	//ObjectPtr JTPartObjP = NULL;
	//ObjectPtr JTObjP = NULL;
	//ObjectPtr NewDataItemObjP = NULL;
	//ObjectPtr DataItemObjP = NULL;
	//ObjectPtr proprtDIObjP = NULL;
	//ObjectPtr NewVisFileObjP = NULL;
	//ObjectPtr VisFileObjP = NULL;
	//ObjectPtr proprtrevObjP = NULL;

	SqlPtr Sql_ptr = NULL;

	//int k = 0;
	int m = 0;
	int noOfDocs = 0;
	//int DataItem = 0;
	//int count = 0;
	//int VisFile = 0;

	PartRevSeq=nlsStrAlloc(50);

	//printf("\n Executing... GetProEPartList.c ... \n");

	if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
		(dstat = oiSqlWhereBegParen(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,RevisionS1))||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,SequenceAttr,SequenceS1))||
		(dstat = oiSqlWhereEndParen(Sql_ptr))||
		(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
	if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;

	printf("\nNo:of Parts are: %d",setSize(PartSO));

	if(setSize(PartSO)>0)
	{
		for(m=0;m<setSize(PartSO);m++)
		{
			TCPartObjP=setGet(PartSO,m);

			if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
			if(SetFlagforScope(partMasterSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			if (setSize(partMasterSO)>0)
			{
				MasterObjOP=setGet(partMasterSO,0);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberS));
			PartNumberDupS=nlsStrDup(PartNumberS);
			//printf("\n\n\t TCPartNumberDupS:%s",PartNumberDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&RevisionS));
			RevisionDupS=nlsStrDup(RevisionS);
			//printf("\n\t TCRevisionDupS :%s",RevisionDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&SequenceS));
			SequenceDupS=nlsStrDup(SequenceS);
			//printf("\n\t Sequence:%s",SequenceDupS); fflush(stdout);

			printf("\n\n\t TCPart:::::[ %s , %s , %s ]",PartNumberDupS,RevisionDupS,SequenceDupS); fflush(stdout);

			if(!nlsIsStrNull(PartNumberDupS))
			{
				nlsStrCpy(PartRevSeq,"");

				/*nlsStrCpy(PartRevSeq,PartNumberDupS);
				nlsStrCat(PartRevSeq,"_");
				nlsStrCat(PartRevSeq,RevisionDupS);
				nlsStrCat(PartRevSeq,"_");
				nlsStrCat(PartRevSeq,SequenceDupS);*/

				nlsStrCpy(PartRevSeq,RevisionDupS);
				nlsStrCat(PartRevSeq,";");
				nlsStrCat(PartRevSeq,SequenceDupS);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&NomenclatureS));
			if(!nlsIsStrNull(NomenclatureS))
			{
				NomenclatureDupS=nlsStrDup(NomenclatureS);
			}
			else
			{
				NomenclatureDupS=nlsStrDup("-");
			}
			NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
			printf("\n\t NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeS));
			PartTypeDupS=nlsStrDup(PartTypeS);
			printf("\n\t PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&OwnerNameS));
			OwnerNameDupS=nlsStrDup(OwnerNameS);
			printf("\n\t OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);

			if(nlsStrStr(OwnerNameDupS,"Vault") == NULL)
			{
				printf("\t ...this rev-seq not in Vault hence skipping from download...\n");  fflush(stdout);
				continue;
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectNameS));
			ProjectNameDupS=nlsStrDup(ProjectNameS);
			printf("\n\t ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&t5DesignGroupS));
			if(!nlsIsStrNull(t5DesignGroupS))
			{
				t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
			}
			else
			{
				t5DesignGroupDupS=nlsStrDup(" ");
			}
			printf("\n\t t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
			if(!nlsIsStrNull(t5DocRemarkS))
			{
				t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
			}
			else
			{
				t5DocRemarkDupS=nlsStrDup("-");
			}
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
			printf("\n\t t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
			t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
			printf("\n\t t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

			if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
			{
				docClass = low_getspace(20);

				if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
				if(SetFlagforScope(docObjs)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				if(setSize(docObjs) <= 0)
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
				}
				if(setSize(docObjs) > 0)
				{
					if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
					if (setSize(latestDocs)>0)
					{
						for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
						{
							docOPtr = setGet(latestDocs, noOfDocs);
							if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
							if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
							{
								//Document Number = Drawing Document Number
								if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
								if(!nlsIsStrNull(t5DrawingNo))
								{
									t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
								}
								else
								{
									t5DrawingNoDupS = nlsStrDup(" ");
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNoDupS))
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					if(setSize(docObjs) > 0)
					{
						if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
						if (setSize(latestDocs)>0)
						{
							for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
							{
								docOPtr = setGet(latestDocs, noOfDocs);
								if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
								printf("\n\t ...51..%s",docClass);
								if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
								{
									//Document Number = Drawing Document Number
									if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
									if(!nlsIsStrNull(t5DrawingNo))
									{
										t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup(" ");
									}
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNo))
				{
					t5DrawingNoDupS = nlsStrDup(" ");
				}
			}
			else
			{
				t5DrawingNoDupS = nlsStrDup(" ");
			}
			printf("\n\t t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&t5MatlClassS));
			if(!nlsIsStrNull(t5MatlClassS))
			{
				t5MatlClassDupS=nlsStrDup(t5MatlClassS);
			}
			else
			{
				t5MatlClassDupS=nlsStrDup("NA");
			}
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"\n"," ");
			printf("\n\t t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&t5MaterialInDrwS));
			if(!nlsIsStrNull(t5MaterialInDrwS))
			{
				t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
			}
			else
			{
				t5MaterialInDrwDupS=nlsStrDup(" ");
			}
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"\n"," ");
			printf("\n\t t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessS));
			if(!nlsIsStrNull(MaterialThickNessS))
			{
				MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
			}
			else
			{
				MaterialThickNessDupS=nlsStrDup(" ");
			}
			printf("\n\t MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5UQdupAttr,&UnitOfMeasureS));
			//if(!nlsIsStrNull(UnitOfMeasureS))
			//{
			//	UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
			//}
			//else
			//{
			//	UnitOfMeasureDupS=nlsStrDup("4");
			//}
			//printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5LeftRhAttr,&t5LeftRhS));
			if (setSize(partMasterSO)>0)
			{
				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureS));
				if(!nlsIsStrNull(UnitOfMeasureS))
				{
					UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
				}
				else
				{
					UnitOfMeasureDupS=nlsStrDup("4");
				}

				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&t5LeftRhS));
				if(!nlsIsStrNull(t5LeftRhS))
				{
					t5LeftRhDupS=nlsStrDup(t5LeftRhS);
				}
				else
				{
					t5LeftRhDupS=nlsStrDup("NA");
				}
			}
			else
			{
				t5LeftRhDupS=nlsStrDup("NA");
				UnitOfMeasureDupS=nlsStrDup("4");
			}

			printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);
			printf("\n\t t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
			if(!nlsIsStrNull(t5DsgnOwnS))
			{
				t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
			}
			else
			{
				t5DsgnOwnDupS=nlsStrDup("TELPUN");
			}
			printf("\n\t t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
			if(!nlsIsStrNull(t5ModelIndicatorS))
			{
				t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
			}
			else
			{
				t5ModelIndicatorDupS=nlsStrDup(" ");
			}
			printf("\n\t t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&t5ColourIndS));
			if(!nlsIsStrNull(t5ColourIndS))
			{
				t5ColourIndDupS=nlsStrDup(t5ColourIndS);
			}
			else
			{
				t5ColourIndDupS=nlsStrDup("N");
			}
			printf("\n\t t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDS));
			if(!nlsIsStrNull(t5ColourIDS))
			{
				t5ColourIDDupS=nlsStrDup(t5ColourIDS);
			}
			else
			{
				t5ColourIDDupS=nlsStrDup(" ");
			}
			printf("\n\t t5ColourIDDupS:%s",t5ColourIDDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateS));
			if(!nlsIsStrNull(LifeCycleStateS))
			{
				LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
			}
			else
			{
				LifeCycleStateDupS=nlsStrDup("LcsReview");
			}
			printf("\n\t LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightS));
			if(!nlsIsStrNull(WeightS))
			{
				WeightDupS=nlsStrDup(WeightS);
			}
			else
			{
				WeightDupS=nlsStrDup("0");
			}
			printf("\n\t WeightDupS:%s",WeightDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5SpareIndAttr,&SpareIndS));
			if(!nlsIsStrNull(SpareIndS))
			{
				SpareIndDupS=nlsStrDup(SpareIndS);
			}
			else
			{
				SpareIndDupS=nlsStrDup(" ");
			}
			printf("\n\t SpareIndDupS:%s",SpareIndDupS); fflush(stdout);


			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
			if(!nlsIsStrNull(t5CMVRCertificationDupS))
			{
				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
			}
			else
			{
				t5CMVRCertificationS=nlsStrDup(" ");
			}
			printf("\n\t t5CMVRCertificationS:%s",t5CMVRCertificationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
			if(!nlsIsStrNull(t5ClassificationHazDupS))
			{
				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
			}
			else
			{
				t5ClassificationHazS=nlsStrDup(" ");
			}
			printf("\n\t t5ClassificationHazS:%s",t5ClassificationHazS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
			if(!nlsIsStrNull(t5ConfigIDDupS))
			{
				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
			}
			else
			{
				t5ConfigIDS=nlsStrDup(" ");
			}
			printf("\n\t t5ConfigIDS:%s",t5ConfigIDS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
			if(!nlsIsStrNull(t5DismantableDupS))
			{
				t5DismantableS=nlsStrDup(t5DismantableDupS);
			}
			else
			{
				t5DismantableS=nlsStrDup(" ");
			}
			printf("\n\t t5DismantableS:%s",t5DismantableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
			if(!nlsIsStrNull(t5DsgnDeptDupS))
			{
				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
			}
			else
			{
				t5DsgnDeptS=nlsStrDup(" ");
			}
			printf("\n\t t5DsgnDeptS:%s",t5DsgnDeptS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
			if(!nlsIsStrNull(t5EnvelopeDimenDupS))
			{
				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
			}
			else
			{
				t5EnvelopeDimenS=nlsStrDup(" ");
			}
			printf("\n\t t5EnvelopeDimenS:%s",t5EnvelopeDimenS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
			if(!nlsIsStrNull(t5HazardousContDupS))
			{
				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
			}
			else
			{
				t5HazardousContS=nlsStrDup(" ");
			}
			printf("\n\t t5HazardousContS:%s",t5HazardousContS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
			if(!nlsIsStrNull(t5HomologationReqdDupS))
			{
				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
			}
			else
			{
				t5HomologationReqdS=nlsStrDup(" ");
			}
			printf("\n\t t5HomologationReqdS:%s",t5HomologationReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
			if(!nlsIsStrNull(t5ListRecSparesDups))
			{
				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
			}
			else
			{
				t5ListRecSparess=nlsStrDup(" ");
			}
			printf("\n\t t5ListRecSparess:%s",t5ListRecSparess); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
			if(!nlsIsStrNull(t5NcPartNoDupS))
			{
				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
			}
			else
			{
				t5NcPartNoS=nlsStrDup(" ");
			}
			printf("\n\t t5NcPartNoS:%s",t5NcPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
			if(!nlsIsStrNull(t5PartCodeDupS))
			{
				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
			}
			else
			{
				t5PartCodeS=nlsStrDup(" ");
			}
			printf("\n\t t5PartCodeS:%s",t5PartCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
			if(!nlsIsStrNull(t5PartPropertyDupS))
			{
				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
			}
			else
			{
				t5PartPropertyS=nlsStrDup(" ");
			}
			printf("\n\t t5PartPropertyS:%s",t5PartPropertyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
			if(!nlsIsStrNull(t5PartStatusDupS))
			{
				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
			}
			else
			{
				t5PartStatusS=nlsStrDup(" ");
			}
			printf("\n\t t5PartStatusS:%s",t5PartStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
			if(!nlsIsStrNull(t5PkgStdDupS))
			{
				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
			}
			else
			{
				t5PkgStdS=nlsStrDup(" ");
			}
			printf("\n\t t5PkgStdS:%s",t5PkgStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
			if(!nlsIsStrNull(t5ProductDupS))
			{
				t5ProductS=nlsStrDup(t5ProductDupS);
			}
			else {	t5ProductS=nlsStrDup(" ");	}
			printf("\n\t t5ProductS:%s",t5ProductS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
			if(!nlsIsStrNull(t5PrtCatCodeDupS))
			{
				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
			}
			else {	t5PrtCatCodeS=nlsStrDup(" ");	}
			printf("\n\t t5PrtCatCodeS:%s",t5PrtCatCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
			if(!nlsIsStrNull(t5PunIntialAgDupS))
			{
				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
			}
			else {	t5PunIntialAgS=nlsStrDup(" ");	}
			printf("\n\t t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
			if(!nlsIsStrNull(t5PunMakeBuyIndDupS))
			{
				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
			}
			else {	t5PunMakeBuyIndS=nlsStrDup(" ");	}
			printf("\n\t t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
			if(!nlsIsStrNull(t5RecoverableDupS))
			{
				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
			}
			else {	t5RecoverableS=nlsStrDup(" ");	}
			printf("\n\t t5RecoverableS:%s",t5RecoverableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
			if(!nlsIsStrNull(t5RecyclabilityDupS))
			{
				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
			}
			else {	t5RecyclabilityS=nlsStrDup(" ");	}
			printf("\n\t t5RecyclabilityS:%s",t5RecyclabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
			if(!nlsIsStrNull(t5RefPartNumberDupS))
			{
				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
			}
			else {	t5RefPartNumberS=nlsStrDup(" ");	}
			printf("\n\t t5RefPartNumberS:%s",t5RefPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
			if(!nlsIsStrNull(t5ReliabilityDupS))
			{
				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
			}
			else {	t5ReliabilityS=nlsStrDup(" ");	}
			printf("\n\t t5ReliabilityS:%s",t5ReliabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
			if(!nlsIsStrNull(t5SpareCriteriaDupS))
			{
				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
			}
			else {	
				t5SpareCriteriaS=nlsStrDup(" ");
			}
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"\n"," ");
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"^"," ");
			printf("\n\t t5SpareCriteriaS:%s",t5SpareCriteriaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
			if(!nlsIsStrNull(t5SurfPrtStdDupS))
			{
				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
			}
			else {	t5SurfPrtStdS=nlsStrDup(" ");	}
			printf("\n\t t5SurfPrtStdS:%s",t5SurfPrtStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
			if(!nlsIsStrNull(t5SamplesToApprDupS))
			{
				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
			}
			else {	t5SamplesToApprS=nlsStrDup(" ");	}
			printf("\n\t t5SamplesToApprS:%s",t5SamplesToApprS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
			if(!nlsIsStrNull(t5AsmDisposalDupS))
			{
				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
			}
			else {	t5AsmDisposalS=nlsStrDup(" ");	}
			printf("\n\t t5AsmDisposalS:%s",t5AsmDisposalS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
			if(!nlsIsStrNull(t5FinDisposalInstrDupS))
			{
				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
			}
			else {	t5FinDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t t5FinDisposalInstrS:%s",t5FinDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
			if(!nlsIsStrNull(t5RPDisposalInstrDupS))
			{
				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
			}
			else {	t5RPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t t5RPDisposalInstrS:%s",t5RPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
			if(!nlsIsStrNull(t5SPDisposalInstrDupS))
			{
				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
			}else {	t5SPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t t5SPDisposalInstrS:%s",t5SPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
			if(!nlsIsStrNull(t5WIPDisposalInstrDupS))
			{
				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
			}else {	t5WIPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t t5WIPDisposalInstrS:%s",t5WIPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
			if(!nlsIsStrNull(t5LastModByDupS))
			{
				t5LastModByS=nlsStrDup(t5LastModByDupS);
			}else {	t5LastModByS=nlsStrDup("loader");	}
			printf("\n\t t5LastModByS:%s",t5LastModByS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
			if(!nlsIsStrNull(t5VerCreatorDupS))
			{
				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
			}else {	t5VerCreatorS=nlsStrDup(" ");	}
			printf("\n\t t5VerCreatorS:%s",t5VerCreatorS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
			if(!nlsIsStrNull(t5CAEDocEDupS))
			{
				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
			}else {	t5CAEDocES=nlsStrDup(" ");	}
			printf("\n\t t5CAEDocES:%s",t5CAEDocES); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
			if(!nlsIsStrNull(t5CoatedDupS))
			{
				t5CoatedS=nlsStrDup(t5CoatedDupS);
			}else {	t5CoatedS=nlsStrDup(" ");	}
			printf("\n\t t5CoatedS:%s",t5CoatedS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
			if(!nlsIsStrNull(t5ConvDocDupS))
			{
				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
			}else {	t5ConvDocS=nlsStrDup(" ");	}
			printf("\n\t t5ConvDocS:%s",t5ConvDocS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcRevDupS))
			{
				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
			}else {	t5AplCopyOfErcRevS=nlsStrDup(" ");	}
			printf("\n\t t5AplCopyOfErcRevS:%s",t5AplCopyOfErcRevS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcSeqDupS))
			{
				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
			}else {	t5AplCopyOfErcSeqS=nlsStrDup(" ");	}
			printf("\n\t t5AplCopyOfErcSeqS:%s",t5AplCopyOfErcSeqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
			if(!nlsIsStrNull(t5AppCodeDupS))
			{
				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
			}else {	t5AppCodeS=nlsStrDup(" ");	}
			printf("\n\t t5AppCodeS:%s",t5AppCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
			if(!nlsIsStrNull(t5RqstNumDupS))
			{
				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
			}else {	t5RqstNumS=nlsStrDup(" ");	}
			printf("\n\t t5RqstNumS:%s",t5RqstNumS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
			if(!nlsIsStrNull(t5RsnCodeDupS))
			{
				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
			}else {	t5RsnCodeS=nlsStrDup(" ");	}
			printf("\n\t t5RsnCodeS:%s",t5RsnCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
			if(!nlsIsStrNull(t5SurfaceAreaDupS))
			{
				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
			}else {	t5SurfaceAreaS=nlsStrDup(" ");	}
			printf("\n\t t5SurfaceAreaS:%s",t5SurfaceAreaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
			if(!nlsIsStrNull(t5VolumeDupS))
			{
				t5VolumeS=nlsStrDup(t5VolumeDupS);
			}else {	t5VolumeS=nlsStrDup(" ");	}
			printf("\n\t t5VolumeS:%s",t5VolumeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
			if(!nlsIsStrNull(t5CarIntialAgencyDupS))
			{
				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
			}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
			printf("\n\t t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
			if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
			{
				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
			}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
			printf("\n\t t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
			if(!nlsIsStrNull(t5ErcIndNameDupS))
			{
				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
			}else {	t5ErcIndNameS=nlsStrDup(" ");	}
			printf("\n\t t5ErcIndNameS:%s",t5ErcIndNameS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
			if(!nlsIsStrNull(t5PostRelReqDupS))
			{
				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
			}else {	t5PostRelReqS=nlsStrDup(" ");	}
			printf("\n\t t5PostRelReqS:%s",t5PostRelReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
			if(!nlsIsStrNull(t5ItmCategoryDupS))
			{
				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
			}else {	t5ItmCategoryS=nlsStrDup(" ");	}
			printf("\n\t t5ItmCategoryS:%s",t5ItmCategoryS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
			if(!nlsIsStrNull(t5CopReqDupS))
			{
				t5CopReqS=nlsStrDup(t5CopReqDupS);
			}else {	t5CopReqS=nlsStrDup(" ");	}
			printf("\n\t t5CopReqS:%s",t5CopReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
			if(!nlsIsStrNull(t5AplInvalidateDupS))
			{
				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
			}else {	t5AplInvalidateS=nlsStrDup(" ");	}
			printf("\n\t t5AplInvalidateS:%s",t5AplInvalidateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
			if(!nlsIsStrNull(t5PrtValiStatusDupS))
			{
				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
			}else {	t5PrtValiStatusS=nlsStrDup(" ");	}
			printf("\n\t t5PrtValiStatusS:%s",t5PrtValiStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
			if(!nlsIsStrNull(t5DRSubStateDupS))
			{
				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
			}else {	t5DRSubStateS=nlsStrDup(" ");	}
			printf("\n\t t5DRSubStateS:%s",t5DRSubStateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
			if(!nlsIsStrNull(t5KnxtDocIndDupS))
			{
				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
			}else {	t5KnxtDocIndS=nlsStrDup(" ");	}
			printf("\n\t t5KnxtDocIndS:%s",t5KnxtDocIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
			if(!nlsIsStrNull(t5SimValDupS))
			{
				t5SimValS=nlsStrDup(t5SimValDupS);
				t5SimValS=low_strssra(t5SimValS,"\n"," ");
			}else {	t5SimValS=nlsStrDup(" ");	}
			printf("\n\t t5SimValS:%s",t5SimValS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
			if(!nlsIsStrNull(t5PerYieldDupS))
			{
				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
			}else {	t5PerYieldS=nlsStrDup(" ");	}
			printf("\n\t t5PerYieldS:%s",t5PerYieldS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
			if(!nlsIsStrNull(t5PunStoreLocationDupS))
			{
				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
			}else {	t5PunStoreLocationS=nlsStrDup(" ");	}
			printf("\n\t t5PunStoreLocationS:%s",t5PunStoreLocationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
			if(!nlsIsStrNull(t5AltPartNoDupS))
			{
				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"\n"," ");
			}else {	t5AltPartNoS=nlsStrDup(" ");	}
			printf("\n\t t5AltPartNoS:%s",t5AltPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
			if(!nlsIsStrNull(t5RolledupWtDupS))
			{
				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
			}else {	t5RolledupWtS=nlsStrDup(" ");	}
			printf("\n\t t5RolledupWtS:%s",t5RolledupWtS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
			if(!nlsIsStrNull(t5PFDModReqdDupS))
			{
				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
			}else {	t5PFDModReqdS=nlsStrDup(" ");	}
			printf("\n\t t5PFDModReqdS:%s",t5PFDModReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
			if(!nlsIsStrNull(t5ToolIndentReqdDupS))
			{
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
			}else {	t5ToolIndentReqdS=nlsStrDup(" ");	}
			printf("\n\t t5ToolIndentReqdS:%s",t5ToolIndentReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
			if(!nlsIsStrNull(CategoryNameDupS))
			{
				CategoryNameS=nlsStrDup(CategoryNameDupS);
				CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
				CategoryNameS=low_strssra(CategoryNameS,"^"," ");
			}else {	CategoryNameS=nlsStrDup(" ");	}
			printf("\n\t CategoryNameS:%s",CategoryNameS); fflush(stdout);


			// For effectivity extract
			t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
			// Get the configuration context object from the general context.
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
			// Set the option as "LkoCtxt" in the context object
			t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
			t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
			t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
			t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
			printf("\n\t  setSize(soExpObj):%d ",setSize(soExpObj)); fflush(stdout);
			if(setSize(soExpObj)>0)
			{
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;
				if(!nlsIsStrNull(ReveffDateFrom))
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
				}
				else
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateTo);
				}

				if(!nlsIsStrNull(ReveffDateTo))
				{
					ReveffDateToDup = nlsStrDup(ReveffDateTo);
				}
				else
				{
					ReveffDateToDup = nlsStrDup(ReveffDateFrom);
				}
			}
			else
			{
				ReveffDateFromDup = nlsStrDup("-");
				ReveffDateToDup = nlsStrDup("-");
			}

			printf("\n\t ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
			printf("\n\t ReveffDateToDup:%s \n",ReveffDateToDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
			t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
			printf("\n\t t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
			t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
			printf("\n\t t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
			t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
			printf("\n\t t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
			t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
			printf("\n\t t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
			t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
			printf("\n\t t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
			t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
			printf("\n\t t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
			t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
			printf("\n\t t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
			t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
			printf("\n\t t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
			t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
			printf("\n\t t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
			t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
			printf("\n\t t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
			if(!nlsIsStrNull(t5EstSheetReqdDupS))
			{
				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
			}else {	t5EstSheetReqdS=nlsStrDup(" ");	}
			printf("\n\t t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CreationDate",&PartCreDateS));
			if(!nlsIsStrNull(PartCreDateS))
			{
				PartCreDateDupS=nlsStrDup(PartCreDateS);
			}
			else
			{
				PartCreDateDupS=nlsStrDup("-");
			}
			printf("\n\t PartCreDateDupS:%s \n",PartCreDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"LastUpdate",&PartModDateS));
			if(!nlsIsStrNull(PartModDateS))
			{
				PartModDateDupS=nlsStrDup(PartModDateS);
			}
			else
			{
				PartModDateDupS=nlsStrDup("-");
			}
			printf("\n\t PartModDateDupS:%s \n",PartModDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"Creator",&PartCreator));
			PartCreatorDup=nlsStrDup(PartCreator);
			printf("\n\t PartCreatorDup:%s \n",PartCreatorDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
			if(!nlsIsStrNull(t5AhdIntialAgencyS))
			{
				t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
			}
			else
			{
				t5AhdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
			if(!nlsIsStrNull(t5AhdMakeBuyIndS))
			{
				t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
			}
			else
			{
				t5AhdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
			if(!nlsIsStrNull(t5DwdIntialAgencyS))
			{
				t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
			}
			else
			{
				t5DwdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
			if(!nlsIsStrNull(t5DwdMakeBuyIndS))
			{
				t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
			}
			else
			{
				t5DwdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
			if(!nlsIsStrNull(t5JdlIntialAgencyS))
			{
				t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
			}
			else
			{
				t5JdlIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
			if(!nlsIsStrNull(t5JdlMakeBuyIndS))
			{
				t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
			}
			else
			{
				t5JdlMakeBuyIndSDup = nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
			if(!nlsIsStrNull(t5AhdStoreLocS))
			{
				t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
			}
			else
			{
				t5AhdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarStoreLocation",&t5CarStoreLocS));
			if(!nlsIsStrNull(t5CarStoreLocS))
			{
				t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
			}
			else
			{
				t5CarStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
			if(!nlsIsStrNull(t5DwdStoreLocS))
			{
				t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
			}
			else
			{
				t5DwdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
			if(!nlsIsStrNull(t5JdlStoreLocS))
			{
				t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
			}
			else
			{
				t5JdlStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
			if(!nlsIsStrNull(t5JsrStoreLocS))
			{
				t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
			}
			else
			{
				t5JsrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
			if(!nlsIsStrNull(t5LkoStoreLocS))
			{
				t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
			}
			else
			{
				t5LkoStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
			if(!nlsIsStrNull(t5PnrStoreLocS))
			{
				t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
			}
			else
			{
				t5PnrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
			if(!nlsIsStrNull(t5PunPCBUStoreLocS))
			{
				t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
			}
			else
			{
				t5PunPCBUStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
			if(!nlsIsStrNull(t5SgrStoreLocS))
			{
				t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
			}
			else
			{
				t5SgrStoreLocSDup = nlsStrDup("");
			}


			fprintf(fpAllRev,"%s",PartNumberDupS);			//1		//In Function GetGenTCPartProEInfo
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",RevisionDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SequenceDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",NomenclatureDupS);	//desc
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",PartTypeDupS);		//PartType
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",ProjectNameDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DesignGroupDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DocRemarkDupS);		//mod_desc
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5DrawingNoDupS)){
				fprintf(fpAllRev,"%s",t5DrawingNoDupS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"%s",t5DrawingIndDupS);		//10
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MatlClassDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MaterialInDrwDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",MaterialThickNessDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5LeftRhDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DsgnOwnDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ModelIndicatorDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",UnitOfMeasureDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIndDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",LifeCycleStateDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIDDupS);				//20
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",WeightDupS);					//21
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SpareIndDupS);				//22
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5CMVRCertificationS)){
				fprintf(fpAllRev,"%s",t5CMVRCertificationS);//23
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ClassificationHazS)){
				fprintf(fpAllRev,"%s",t5ClassificationHazS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ConfigIDS)){
				fprintf(fpAllRev,"%s",t5ConfigIDS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5DismantableS)){
				fprintf(fpAllRev,"%s",t5DismantableS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DsgnDeptS)){
				fprintf(fpAllRev,"%s",t5DsgnDeptS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5EnvelopeDimenS)){
				fprintf(fpAllRev,"%s",t5EnvelopeDimenS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HazardousContS)){
				fprintf(fpAllRev,"%s",t5HazardousContS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HomologationReqdS)){
				fprintf(fpAllRev,"%s",t5HomologationReqdS);	//30
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ListRecSparess)){
				fprintf(fpAllRev,"%s",t5ListRecSparess);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5NcPartNoS)){
				fprintf(fpAllRev,"%s",t5NcPartNoS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartCodeS)){
				fprintf(fpAllRev,"%s",t5PartCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartPropertyS)){
				fprintf(fpAllRev,"%s",t5PartPropertyS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartStatusS)){
				fprintf(fpAllRev,"%s",t5PartStatusS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PkgStdS)){
				fprintf(fpAllRev,"%s",t5PkgStdS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ProductS)){
				fprintf(fpAllRev,"%s",t5ProductS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtCatCodeS)){
				fprintf(fpAllRev,"%s",t5PrtCatCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunIntialAgS)){
				fprintf(fpAllRev,"%s",t5PunIntialAgS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
				fprintf(fpAllRev,"%s",t5PunMakeBuyIndS);	//40
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecoverableS)){
				fprintf(fpAllRev,"%s",t5RecoverableS);		//41
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecyclabilityS)){
				fprintf(fpAllRev,"%s",t5RecyclabilityS);	//42
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RefPartNumberS)){
				fprintf(fpAllRev,"%s",t5RefPartNumberS);	//43
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ReliabilityS)){
				fprintf(fpAllRev,"%s",t5ReliabilityS);		//44
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SpareCriteriaS)){
				fprintf(fpAllRev,"%s",t5SpareCriteriaS);	//45
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfPrtStdS)){
				fprintf(fpAllRev,"%s",t5SurfPrtStdS);		//46
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SamplesToApprS)){
				fprintf(fpAllRev,"%s",t5SamplesToApprS);	//47
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AsmDisposalS)){
				fprintf(fpAllRev,"%s",t5AsmDisposalS);		//48
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5FinDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5FinDisposalInstrS);	//49
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5RPDisposalInstrS);	//50
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5SPDisposalInstrS);	//51
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5WIPDisposalInstrS);	//52
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5LastModByS)){
				fprintf(fpAllRev,"%s",t5LastModByS);		//53
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev,"loader^");
			}


			if(!nlsIsStrNull(t5VerCreatorS)){
				fprintf(fpAllRev,"%s",t5VerCreatorS);		//54
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CAEDocES)){
				fprintf(fpAllRev,"%s",t5CAEDocES);			//55
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CoatedS)){
				fprintf(fpAllRev,"%s",t5CoatedS);			//56
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5ConvDocS)){
				fprintf(fpAllRev,"%s",t5ConvDocS);			//57
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcRevS);	//58
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcSeqS);	//59
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AppCodeS)){
				fprintf(fpAllRev,"%s",t5AppCodeS);			//60
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RqstNumS)){
				fprintf(fpAllRev,"%s",t5RqstNumS);			//61
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RsnCodeS)){
				fprintf(fpAllRev,"%s",t5RsnCodeS);			//62
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfaceAreaS)){
				fprintf(fpAllRev,"%s",t5SurfaceAreaS);		//63
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5VolumeS)){
				fprintf(fpAllRev,"%s",t5VolumeS);			//64
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CarIntialAgencyS)){
				fprintf(fpAllRev,"%s",t5CarIntialAgencyS);	//65
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
				fprintf(fpAllRev,"%s",t5CarMakeBuyIndiS);	//66
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ErcIndNameS)){
				fprintf(fpAllRev,"%s",t5ErcIndNameS);		//67
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PostRelReqS)){
				fprintf(fpAllRev,"%s",t5PostRelReqS);		//68
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ItmCategoryS)){
				fprintf(fpAllRev,"%s",t5ItmCategoryS);		//69
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CopReqS)){
				fprintf(fpAllRev,"%s",t5CopReqS);			//70
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplInvalidateS)){
				fprintf(fpAllRev,"%s",t5AplInvalidateS);	//71
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtValiStatusS)){
				fprintf(fpAllRev,"%s",t5PrtValiStatusS);	//72
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DRSubStateS)){
				fprintf(fpAllRev,"%s",t5DRSubStateS);		//73
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5KnxtDocIndS)){
				fprintf(fpAllRev,"%s",t5KnxtDocIndS);		//74
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5SimValS)){
				fprintf(fpAllRev,"%s",t5SimValS);			//75
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PerYieldS)){
				fprintf(fpAllRev,"%s",t5PerYieldS);			//76
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunStoreLocationS)){
				fprintf(fpAllRev,"%s",t5PunStoreLocationS);	//77
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AltPartNoS)){
				fprintf(fpAllRev,"%s",t5AltPartNoS);		//78
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5RolledupWtS)){
				fprintf(fpAllRev,"%s",t5RolledupWtS);		//79
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PFDModReqdS)){
				fprintf(fpAllRev,"%s",t5PFDModReqdS);		//80
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ToolIndentReqdS)){
				fprintf(fpAllRev,"%s",t5ToolIndentReqdS);	//81
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(CategoryNameS)){
				fprintf(fpAllRev,"%s",CategoryNameS);		//82
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(ReveffDateFromDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateFromDup);	//83
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(ReveffDateToDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateToDup);		//84
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"NA^");		//85   //LhRhPartNumberDup

			if(!nlsIsStrNull(InstanceRevSeqS))
			{
				fprintf(fpAllRev,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //86   //InstanceRevSeqS
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			//below attributes are added by rrr on 14.10.2016
			if(!nlsIsStrNull(t5JsrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5JsrIntialAgencyS);		//87
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5JsrMakeBuyIndiS);		//88
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5LkoIntialAgencyS);		//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5LkoMakeBuyIndiS);		//90
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PnrIntialAgencyS);		//91
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PnrMakeBuyIndiS);		//92
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUIntialAgencyS);	//93
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUMakeBuyIndiS);	//94
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5SgrIntialAgencyS);		//95
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5SgrMakeBuyIndiS);		//96
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5EstSheetReqdS))
			{
				fprintf(fpAllRev,"%s",t5EstSheetReqdS);			//97
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(PartCreDateDupS))
			{
				fprintf(fpAllRev,"%s",PartCreDateDupS);			//98
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartModDateDupS))
			{
				fprintf(fpAllRev,"%s",PartModDateDupS);			//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartCreatorDup))
			{
				fprintf(fpAllRev,"%s",PartCreatorDup);			//100
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"loader^");
			}
			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5AhdIntialAgencySDup);	//101
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5AhdMakeBuyIndSDup);		//102
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdIntialAgencySDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5DwdIntialAgencySDup);	//103
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5DwdMakeBuyIndSDup);		//104
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlIntialAgencySDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5JdlIntialAgencySDup);	//105
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JdlMakeBuyIndSDup);		//106
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5AhdStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5AhdStoreLocSDup);		//107
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5CarStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5CarStoreLocSDup);		//108
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5DwdStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5DwdStoreLocSDup);		//109
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JdlStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JdlStoreLocSDup);		//110
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5JsrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5JsrStoreLocSDup);		//111
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5LkoStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5LkoStoreLocSDup);		//112
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5PnrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5PnrStoreLocSDup);		//113
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))			     
			{													     
				fprintf(fpAllRev,"%s",t5PunPCBUStoreLocSDup);	//114
				fprintf(fpAllRev,"^");							     
			}													     
			else												     
			{													     
				fprintf(fpAllRev," ^");							     
			}													     
			if(!nlsIsStrNull(t5SgrStoreLocSDup))				     
			{													     
				fprintf(fpAllRev,"%s",t5SgrStoreLocSDup);		//115		//In Function GetGenTCPartProEInfo
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"\n");
			fflush(fpAllRev);

			printf("\n Inside fpAllRev --------------------------123\n"); fflush(stdout);
			
			printf("\n Inside fpGen --------------------------125\n"); fflush(stdout);

			fprintf(fpGen,"%s",PartNumberDupS);			//1
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",RevisionDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",SequenceDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",NomenclatureDupS);	//desc
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",PartTypeDupS);		//PartType
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",ProjectNameDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5DesignGroupDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5DocRemarkDupS);		//mod_desc
			fprintf(fpGen,"^");

			if(!nlsIsStrNull(t5DrawingNoDupS)){
				fprintf(fpGen,"%s",t5DrawingNoDupS);
				fprintf(fpGen,"^");
			}else {
				fprintf(fpGen," ^");
			}

			fprintf(fpGen,"%s",t5DrawingIndDupS);		//10
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5MatlClassDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5MaterialInDrwDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",MaterialThickNessDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5LeftRhDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5DsgnOwnDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5ModelIndicatorDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",UnitOfMeasureDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5ColourIndDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",LifeCycleStateDupS);
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",t5ColourIDDupS);				//20
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",WeightDupS);					//21
			fprintf(fpGen,"^");
			fprintf(fpGen,"%s",SpareIndDupS);				//22
			fprintf(fpGen,"^");

			if(!nlsIsStrNull(t5CMVRCertificationS)){
				fprintf(fpGen,"%s",t5CMVRCertificationS);//23
				fprintf(fpGen,"^");
			}else {
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ClassificationHazS)){
				fprintf(fpGen,"%s",t5ClassificationHazS);
				fprintf(fpGen,"^");
			}else {
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ConfigIDS)){
				fprintf(fpGen,"%s",t5ConfigIDS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5DismantableS)){
				fprintf(fpGen,"%s",t5DismantableS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5DsgnDeptS)){
				fprintf(fpGen,"%s",t5DsgnDeptS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5EnvelopeDimenS)){
				fprintf(fpGen,"%s",t5EnvelopeDimenS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5HazardousContS)){
				fprintf(fpGen,"%s",t5HazardousContS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5HomologationReqdS)){
				fprintf(fpGen,"%s",t5HomologationReqdS);	//30
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ListRecSparess)){
				fprintf(fpGen,"%s",t5ListRecSparess);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5NcPartNoS)){
				fprintf(fpGen,"%s",t5NcPartNoS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PartCodeS)){
				fprintf(fpGen,"%s",t5PartCodeS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PartPropertyS)){
				fprintf(fpGen,"%s",t5PartPropertyS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PartStatusS)){
				fprintf(fpGen,"%s",t5PartStatusS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5PkgStdS)){
				fprintf(fpGen,"%s",t5PkgStdS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ProductS)){
				fprintf(fpGen,"%s",t5ProductS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PrtCatCodeS)){
				fprintf(fpGen,"%s",t5PrtCatCodeS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PunIntialAgS)){
				fprintf(fpGen,"%s",t5PunIntialAgS);
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
				fprintf(fpGen,"%s",t5PunMakeBuyIndS);	//40
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RecoverableS)){
				fprintf(fpGen,"%s",t5RecoverableS);		//41
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RecyclabilityS)){
				fprintf(fpGen,"%s",t5RecyclabilityS);	//42
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RefPartNumberS)){
				fprintf(fpGen,"%s",t5RefPartNumberS);	//43
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ReliabilityS)){
				fprintf(fpGen,"%s",t5ReliabilityS);		//44
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5SpareCriteriaS)){
				fprintf(fpGen,"%s",t5SpareCriteriaS);	//45
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5SurfPrtStdS)){
				fprintf(fpGen,"%s",t5SurfPrtStdS);		//46
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5SamplesToApprS)){
				fprintf(fpGen,"%s",t5SamplesToApprS);	//47
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5AsmDisposalS)){
				fprintf(fpGen,"%s",t5AsmDisposalS);		//48
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5FinDisposalInstrS)){
				fprintf(fpGen,"%s",t5FinDisposalInstrS);	//49
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RPDisposalInstrS)){
				fprintf(fpGen,"%s",t5RPDisposalInstrS);	//50
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5SPDisposalInstrS)){
				fprintf(fpGen,"%s",t5SPDisposalInstrS);	//51
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
				fprintf(fpGen,"%s",t5WIPDisposalInstrS);	//52
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5LastModByS)){
				fprintf(fpGen,"%s",t5LastModByS);		//53
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen,"loader^");
			}


			if(!nlsIsStrNull(t5VerCreatorS)){
				fprintf(fpGen,"%s",t5VerCreatorS);		//54
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5CAEDocES)){
				fprintf(fpGen,"%s",t5CAEDocES);			//55
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5CoatedS)){
				fprintf(fpGen,"%s",t5CoatedS);			//56
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5ConvDocS)){
				fprintf(fpGen,"%s",t5ConvDocS);			//57
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
				fprintf(fpGen,"%s",t5AplCopyOfErcRevS);	//58
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
				fprintf(fpGen,"%s",t5AplCopyOfErcSeqS);	//59
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5AppCodeS)){
				fprintf(fpGen,"%s",t5AppCodeS);			//60
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RqstNumS)){
				fprintf(fpGen,"%s",t5RqstNumS);			//61
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5RsnCodeS)){
				fprintf(fpGen,"%s",t5RsnCodeS);			//62
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5SurfaceAreaS)){
				fprintf(fpGen,"%s",t5SurfaceAreaS);		//63
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5VolumeS)){
				fprintf(fpGen,"%s",t5VolumeS);			//64
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5CarIntialAgencyS)){
				fprintf(fpGen,"%s",t5CarIntialAgencyS);	//65
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
				fprintf(fpGen,"%s",t5CarMakeBuyIndiS);	//66
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ErcIndNameS)){
				fprintf(fpGen,"%s",t5ErcIndNameS);		//67
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PostRelReqS)){
				fprintf(fpGen,"%s",t5PostRelReqS);		//68
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ItmCategoryS)){
				fprintf(fpGen,"%s",t5ItmCategoryS);		//69
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5CopReqS)){
				fprintf(fpGen,"%s",t5CopReqS);			//70
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5AplInvalidateS)){
				fprintf(fpGen,"%s",t5AplInvalidateS);	//71
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PrtValiStatusS)){
				fprintf(fpGen,"%s",t5PrtValiStatusS);	//72
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5DRSubStateS)){
				fprintf(fpGen,"%s",t5DRSubStateS);		//73
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5KnxtDocIndS)){
				fprintf(fpGen,"%s",t5KnxtDocIndS);		//74
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5SimValS)){
				fprintf(fpGen,"%s",t5SimValS);			//75
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PerYieldS)){
				fprintf(fpGen,"%s",t5PerYieldS);		//76
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5PunStoreLocationS)){
				fprintf(fpGen,"%s",t5PunStoreLocationS);//77
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5AltPartNoS)){
				fprintf(fpGen,"%s",t5AltPartNoS);		//78
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5RolledupWtS)){
				fprintf(fpGen,"%s",t5RolledupWtS);		//79
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(t5PFDModReqdS)){
				fprintf(fpGen,"%s",t5PFDModReqdS);		//80
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(t5ToolIndentReqdS)){
				fprintf(fpGen,"%s",t5ToolIndentReqdS);	//81
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(CategoryNameS)){
				fprintf(fpGen,"%s",CategoryNameS);		//82
				fprintf(fpGen,"^");
			}else
			{
				fprintf(fpGen," ^");
			}


			if(!nlsIsStrNull(ReveffDateFromDup))
			{
				fprintf(fpGen,"%s",ReveffDateFromDup);	//83
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}

			if(!nlsIsStrNull(ReveffDateToDup))
			{
				fprintf(fpGen,"%s",ReveffDateToDup);	//84
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}

			fprintf(fpGen,"NA^");						//85   //LhRhPartNumberDup

			if(!nlsIsStrNull(InstanceRevSeqS))
			{
				fprintf(fpGen,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //86   //InstanceRevSeqS
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}

			//below attributes are added by rrr on 14.10.2016
			if(!nlsIsStrNull(t5JsrIntialAgencyS))
			{
				fprintf(fpGen,"%s",t5JsrIntialAgencyS);		//87
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
			{
				fprintf(fpGen,"%s",t5JsrMakeBuyIndiS);		//88
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5LkoIntialAgencyS))
			{
				fprintf(fpGen,"%s",t5LkoIntialAgencyS);		//99
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
			{
				fprintf(fpGen,"%s",t5LkoMakeBuyIndiS);		//90
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5PnrIntialAgencyS))
			{
				fprintf(fpGen,"%s",t5PnrIntialAgencyS);		//91
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
			{
				fprintf(fpGen,"%s",t5PnrMakeBuyIndiS);		//92
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
			{
				fprintf(fpGen,"%s",t5PunPCBUIntialAgencyS);	//93
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
			{
				fprintf(fpGen,"%s",t5PunPCBUMakeBuyIndiS);	//94
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5SgrIntialAgencyS))
			{
				fprintf(fpGen,"%s",t5SgrIntialAgencyS);		//95
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
			{
				fprintf(fpGen,"%s",t5SgrMakeBuyIndiS);		//96
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(t5EstSheetReqdS))
			{
				fprintf(fpGen,"%s",t5EstSheetReqdS);		//97
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			if(!nlsIsStrNull(PartCreDateDupS))
			{
				fprintf(fpGen,"%s",PartCreDateDupS);		//98
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen,"-^");
			}
			if(!nlsIsStrNull(PartModDateDupS))
			{
				fprintf(fpGen,"%s",PartModDateDupS);		//99
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen,"-^");
			}

			if(!nlsIsStrNull(PartCreatorDup))
			{
				fprintf(fpGen,"%s",PartCreatorDup);			//100
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen,"loader^");
			}
			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
			{
				fprintf(fpGen,"%s",t5AhdIntialAgencySDup);	//101
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))			     
			{												     
				fprintf(fpGen,"%s",t5AhdMakeBuyIndSDup);	//102
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5DwdIntialAgencySDup))		     
			{												     
				fprintf(fpGen,"%s",t5DwdIntialAgencySDup);	//103
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))			     
			{												     
				fprintf(fpGen,"%s",t5DwdMakeBuyIndSDup);	//104
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5JdlIntialAgencySDup))		     
			{												     
				fprintf(fpGen,"%s",t5JdlIntialAgencySDup);	//105
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))			     
			{												     
				fprintf(fpGen,"%s",t5JdlMakeBuyIndSDup);	//106
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5AhdStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5AhdStoreLocSDup);		//107
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5CarStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5CarStoreLocSDup);		//108
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5DwdStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5DwdStoreLocSDup);		//109
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5JdlStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5JdlStoreLocSDup);		//110
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5JsrStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5JsrStoreLocSDup);		//111
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5LkoStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5LkoStoreLocSDup);		//112
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5PnrStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5PnrStoreLocSDup);		//113
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))		     
			{												     
				fprintf(fpGen,"%s",t5PunPCBUStoreLocSDup);	//114
				fprintf(fpGen,"^");							     
			}												     
			else											     
			{												     
				fprintf(fpGen," ^");						     
			}												     
			if(!nlsIsStrNull(t5SgrStoreLocSDup))			     
			{												     
				fprintf(fpGen,"%s",t5SgrStoreLocSDup);		//115		//In Function GetGenTCPartProEInfo
				fprintf(fpGen,"^");
			}
			else
			{
				fprintf(fpGen," ^");
			}
			fprintf(fpGen,"\n");
			fflush(fpGen);

			/*if (m == (setSize(PartSO)-1))	// LH/RH is added on 28.09.2016 by RRR
			{
				if (setSize(partMasterSO)>0)
				{
					if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;

						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
						if(!nlsIsStrNull(LHRhPartNumber))
						{
							LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
						}
						else
						{
							LHRhPartNumberDupS=nlsStrDup("NA");
						}
					}

					if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;

						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
						if(!nlsIsStrNull(LHRhPartNumber))
						{
							LHRhPartNumberDupS=nlsStrDup(LHRhPartNumber);
						}
						else
						{
							LHRhPartNumberDupS=nlsStrDup("NA");
						}
					}
					printf("\n\t **LHRhPartNumberDupS:%s",LHRhPartNumberDupS); fflush(stdout);

					//query part again to get all attributes to copy in allpartsAllRev file

					//if((nlsStrCmp(LHRhPartNumberDupS,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDupS)))
					//{
					//	t5CheckMfail(GetLhRhTCPartProEInfo(LHRhPartNumberDupS,PartNumberDupS,fpAllRev,OutJtfp,LhRHErr,mfail));
					//}
				}
			}*/

			//if(OutJtfp == NULL)
			//{
			//	printf("\n *****File OutJtfp unable to open and copy cad data"); fflush(stdout);
			//	fprintf(LhRHErr,"\n *****File OutJtfp unable to open and copy cad data"); fflush(LhRHErr);
			//}

			/*if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docDObjs,&docDRelObjs,mfail)) goto CLEANUP;
			if (setSize(docDObjs) > 0)
			{
				//printf("\n\t  1..Doc present "); fflush(stdout);
				if(dstat = t5GetLatestDocumnets(docDObjs,docDRelObjs,&latestDocDs,&latestRelDocDs,mfail)) goto CLEANUP;
			}

			if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentRefSO,&DocumentRefRelSO,mfail)) goto CLEANUP;
			if (setSize(DocumentRefSO) > 0)
			{
				//printf("\n\t  1..Reference Doc present"); fflush(stdout);
				if(dstat = t5GetLatestDocumnets(DocumentRefSO,DocumentRefRelSO,&LatestRefDocSO,&LatestRefRelDocSO,mfail)) goto CLEANUP;
			}

			if(setSize(latestDocDs) <= 0)
			{
				latestDocDs  = setCreate(1);
				for(count=0 ; count  < setSize(LatestRefDocSO) ; count++)
                {
					low_set_add(latestDocDs,setGet(LatestRefDocSO,count));
				}
			}
			else
			{
				low_set_cat(latestDocDs,LatestRefDocSO);
			}
			printf("\nsetSize(docDObjs): %d   setSize(latestDocDs): %d",setSize(docDObjs),setSize(latestDocDs));

			if (setSize(latestDocDs)>0)
			{
				for(noOfDocs = 0; noOfDocs<setSize(latestDocDs); noOfDocs++)
				{
					docClass = low_getspace(10);

					docDOPtr = setGet(latestDocDs, noOfDocs);
					if(dstat = objGetClass(docDOPtr, &docClass)) goto CLEANUP;
					printf("\ndocClass: %s",docClass); fflush(stdout);

					if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;

					if(setSize(DataItemSO)>0)
					{
						DataItClass = low_getspace(10);

						for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
						{
							NewDataItemObjPtr=setGet(DataItemSO,DataItem);

							if(dstat = objGetClass(NewDataItemObjPtr, &DataItClass)) goto CLEANUP;
							printf("  DataItClass: %s",DataItClass); fflush(stdout);

							if((nlsStrCmp(docClass,"DesDoc") == 0) && ((nlsStrCmp(DataItClass,"ProAsm") == 0) || (nlsStrCmp(DataItClass,"ProPrt") == 0)) )
							{
								if(dstat=GetInfoItem(NewDataItemObjPtr,&GetItemInfoObjPtr,mfail)) goto CLEANUP;

								if(dstat = objGetAttribute(GetItemInfoObjPtr,"RelativePath",&RelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(RelativePath))
								{
									RelativePathDup=nlsStrDup(RelativePath);
								}
								else
								{
									RelativePathDup=nlsStrDup(" ");
									continue;
								}

								if(dstat = objGetAttribute(GetItemInfoObjPtr,"WorkingRelativePath",&WRelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(WRelativePath))
								{
									WRelativePathDup=nlsStrDup(WRelativePath);
								}
								else
								{
									WRelativePathDup=nlsStrDup(" ");
									continue;
								}

								if(dstat = objGetAttribute(GetItemInfoObjPtr,"OwnerDirName",&OwnerDirName)) goto CLEANUP;
								OwnerDirNameDup=nlsStrDup(OwnerDirName);

								if(dstat = objGetAttribute(GetItemInfoObjPtr,"OwnerName",&OwnerName)) goto CLEANUP;
								OwnerNameDup=nlsStrDup(OwnerName);

								t5CheckDstat(objGetAttribute(NewDataItemObjPtr,"DisplayedName",&DataItemDisplayNm));
								if(!nlsIsStrNull(DataItemDisplayNm))
								{
									DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
								}

								printf("\n%s,%s,%s,%s,%s,%s,%s,%s",RelativePathDup,WRelativePathDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(stdout);
								//fprintf(OutJtfp,"%s,%s,%s,%s,%s,%s,%s,%s\n",WRelativePathDup,OwnerDirNameDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(OutJtfp);

								fprintf(OutJtfp,"%s,",RelativePathDup);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",WRelativePathDup);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",OwnerDirNameDup);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",OwnerNameDup);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",DataItClass);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);
								fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);
								fprintf(OutJtfp,"\n");
								fflush(OutJtfp);

								//Below commented on 30.09.2016 to skip JT
								//t5CheckMfail(ExpandObject2("ProToVis",NewDataItemObjPtr,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&JTPartSO,&JTPartRelSO,mfail));
								//printf("\n number of jt files attached: %d",setSize(JTPartSO));
								//if (setSize(JTPartSO)==1)
								//{
								//	JTPartObjP=setGet(JTPartSO,0);
								//	t5CheckDstat(objCopy(&JTObjP,JTPartObjP));
								//	t5CheckDstat(objGetAttribute(JTObjP,"RelativePath",&JTRelativePathS));
								//	if(JTRelativePathDup!=NULL)
								//	{
								//		nlsStrFree(JTRelativePathDup);
								//		JTRelativePathDup = NULL;
								//	}
								//	JTRelativePathDup=nlsStrDup(JTRelativePathS);
								//	//printf("\n JTRelativePathDup is: %s ",JTRelativePathDup);
								//	t5CheckDstat(objGetAttribute(JTObjP,"WorkingRelativePath",&JTWRelativePathS));
								//	if(JTWRelativePathDup!=NULL)
								//	{
								//		nlsStrFree(JTWRelativePathDup);
								//		JTWRelativePathDup = NULL;
								//	}
								//	JTWRelativePathDup=nlsStrDup(JTWRelativePathS);
								//	t5CheckDstat(objGetAttribute(JTObjP,"OwnerName",&JTOwnerNameDupS));
								//	JTOwnerNameS=nlsStrDup(JTOwnerNameDupS);
								//
								//	t5CheckDstat(objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJTDupS));
								//	OwnerDirNameJTS=nlsStrDup(OwnerDirNameJTDupS);
								//
								//	fprintf(OutJtfp,"%s,",JTRelativePathDup);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",JTWRelativePathDup);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",OwnerDirNameJTS);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",JTOwnerNameS);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",DataItClass);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);
								//	fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);
								//	fprintf(OutJtfp,"\n");
								//	fflush(OutJtfp);
								//}
							}
							else if((nlsStrCmp(docClass,"x0PrdDoc") == 0) )
							{
								printf("\n%s,%s,%s,%s,%s,%s,%s,%s",WRelativePathDup,OwnerDirNameDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(stdout);
								//fprintf(OutJtfp,"%s,%s%s,%s,%s,%s,%s,%s\n",WRelativePathDup,OwnerDirNameDup,OwnerDirNameDup,OwnerNameDup,DataItClass,PartRevSeq,PartNumberDupS,DataItemDisplayNmDup); fflush(OutJtfp);
							}
						}
					}
				} // for loop of setSize(latestDocs)

				//if (m == (setSize(PartSO)-1))
				//{
				if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
				{
					for(noOfDocs = 0; noOfDocs<setSize(latestDocDs); noOfDocs++)
					{
						docClass = low_getspace(10);

						docDOPtr = setGet(latestDocDs, noOfDocs);
						if(dstat = objGetClass(docDOPtr, &docClass)) goto CLEANUP;
						printf("\ndocClass: %s",docClass); fflush(stdout);

						if(nlsStrCmp(docClass,"t5DrwDoc") == 0)
						{
							if(dstat = ExpandObject5(AttachClass,docDOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail)) goto CLEANUP;

							if(setSize(DataItemSO)>0)
							{
								for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
								{
									NewDataItemObjP=setGet(DataItemSO,DataItem);

									t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
									DiClassS=nlsStrDup(DiClassDupS);
									printf("\n Data item class name:[%s]",DiClassS);

									t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));

									if((nlsStrCmp(DiClassS,"ProDrw")==0) || (nlsStrCmp(DiClassS,"x0CatDrw")==0))
									{
										t5CheckDstat(objGetAttribute(DataItemObjP,OwnerNameAttr,&DIOwnerNameDup));
										DIOwnerName=nlsStrDup(DIOwnerNameDup);

										//if ((nlsStrCmp(DIOwnerName,"Release Vault")==NULL) || (nlsStrStr(DIOwnerName,"CE Vault")!=NULL) )
										//{
											t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&DIRelPathDup));
											DIRelPath=nlsStrDup(DIRelPathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"DisplayedName",&DIDisplayNmDup));
											DIDisplayNm=nlsStrDup(DIDisplayNmDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"WorkingRelativePath",&DIFileWorkingRelativePathDup));
											DIFileWorkingRelativePath=nlsStrDup(DIFileWorkingRelativePathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,SequenceAttr,&DISequenceDup));
											DISequence=nlsStrDup(DISequenceDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"OwnerDirName",&DIOwnerDirNameDup));
											DIOwnerDirName=nlsStrDup(DIOwnerDirNameDup);

											t5CheckDstat(GetInfoItem(DataItemObjP,&proprtDIObjP,mfail));

											t5CheckDstat(objGetAttribute(proprtDIObjP,"FullPath",&DIfullPathDup)) ;
											DIfullPath=nlsStrDup(DIfullPathDup);

											t5CheckDstat(objGetAttribute(DataItemObjP,"DisplayedName",&DataItemDisplayNm));
											if(!nlsIsStrNull(DataItemDisplayNm))
											{
												DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
											}
										//}

										fprintf(OutJtfp,"%s,",DIRelPath);fflush(OutJtfp);			 		//DataItem RelativePath
										fprintf(OutJtfp,"%s,",DIFileWorkingRelativePath);fflush(OutJtfp);	//DataItem WorkingRelativePath
										fprintf(OutJtfp,"%s,",DIOwnerDirName);fflush(OutJtfp);				//DataItem OwnerDirName
										fprintf(OutJtfp,"%s,",DIOwnerName);fflush(OutJtfp);					//DataItem OwnerName
										fprintf(OutJtfp,"%s,",DiClassS);fflush(OutJtfp);					//DataItem ClassName
										fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);					//TC Part Rev;Seq
										fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);				//TC PartNumber for reference drawing relation check
										fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);		//DataItem DisplayNm
										fprintf(OutJtfp,"\n");
										fflush(OutJtfp);

										t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));

										if(setSize(VisualizationFileSO)>0)
										{
											for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
											{
												NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

												t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));

												t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
												VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);

												//if ((nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL) || (nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL) || (nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL) )
												//{
													t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
													VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&PdfDisDupS));
													PdfDisS=nlsStrDup(PdfDisDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
													VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
													VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);

													t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
													VisFileClassS=nlsStrDup(VisFileClassDupS);


													t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
													VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);

													t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));

													t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
													fullPathattrDup=nlsStrDup(fullPathattr);
												//}

												fprintf(OutJtfp,"%s,",VisFileRelPathS);fflush(OutJtfp);			 	//PDF RelativePath
												fprintf(OutJtfp,"%s,",VisFileWorkingRelativePathS);fflush(OutJtfp);	//PDF WorkingRelativePath
												fprintf(OutJtfp,"%s,",VisFileOwnerDirNameS);fflush(OutJtfp);			//PDF OwnerDirName
												fprintf(OutJtfp,"%s,",VisFileOwnerNameS);fflush(OutJtfp);				//PDF OwnerName
												fprintf(OutJtfp,"%s,",VisFileClassS);fflush(OutJtfp);					//PDF ClassName
												fprintf(OutJtfp,"%s,",PartRevSeq);fflush(OutJtfp);					//TC Part Rev;Seq
												fprintf(OutJtfp,"%s,",PartNumberDupS);fflush(OutJtfp);				//TC PartNumber for reference drawing relation check
												fprintf(OutJtfp,"%s,",DataItemDisplayNmDup);fflush(OutJtfp);					//DataItem DisplayNm
												fprintf(OutJtfp,"\n");
												fflush(OutJtfp);
											}
										} // if condn end for setSize(VisualizationFileSO)
									}
								} //for loop end setSize(DataItemSO)
							} // if condn end for setSize(DataItemSO)
						}
					} // for loop of setSize(latestDocs)
				}
				//}
			} //if condn end for setSize(latestDocs)
			*/
		} // for loop of setSize(PartSO)
	} //if condn end for setSize(PartSO)
	else
	{
		printf("\n Inside fpAllRev ---------GetGenTCPartProEInfo-----------------131\n"); fflush(stdout);

		fprintf(fpAllRev,"%s",InpPartNumberS);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",RevisionS1);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",SequenceS1);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","Dummy Part for Proe."); //NomenclatureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","D");		//PartTypeDupS		// Dummy PartType
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","1111");	//ProjectNameDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","11");	//t5DesignGroupDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//mod_desc   t5DocRemarkDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5DrawingNoDupS
		fprintf(fpAllRev,"%s","N");		//t5DrawingIndDupS			//10
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");	//t5MatlClassDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//t5MaterialInDrwDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//MaterialThickNessDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");		//t5LeftRhDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","TELPUN");	//t5DsgnOwnDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//t5ModelIndicatorDupS;
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","4");		//UnitOfMeasureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","N");		//t5ColourIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","LcsSTDRlzd");//LifeCycleStateDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5ColourIDDupS		//20
		fprintf(fpAllRev,"%s","0");		//WeightDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//SpareIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5CMVRCertification
		fprintf(fpAllRev," ^");			//t5ClassificationHaz
		fprintf(fpAllRev," ^");			//t5ConfigID
		fprintf(fpAllRev," ^");			//t5Dismantable
		fprintf(fpAllRev," ^");			//t5DsgnDeptS
		fprintf(fpAllRev," ^");			//t5EnvelopeDimen
		fprintf(fpAllRev," ^");			//t5HazardousCont	
		fprintf(fpAllRev," ^");			//t5HomologationReqd		//30
		fprintf(fpAllRev," ^");			//t5ListRecSpares
		fprintf(fpAllRev," ^");			//t5NcPartNoS
		fprintf(fpAllRev," ^");			//t5PartCodeS
		fprintf(fpAllRev," ^");			//t5PartPropertyS
		fprintf(fpAllRev," ^");			//t5PartStatusS
		fprintf(fpAllRev," ^");			//t5PkgStdS
		fprintf(fpAllRev," ^");			//t5ProductS
		fprintf(fpAllRev," ^");			//t5PrtCatCodeS
		fprintf(fpAllRev," ^");			//t5PunIntialAgS	
		fprintf(fpAllRev," ^");			//t5PunMakeBuyIndS			//40
		fprintf(fpAllRev," ^");			//t5RecoverableS
		fprintf(fpAllRev," ^");			//t5RecyclabilityS
		fprintf(fpAllRev," ^");			//t5RefPartNumberS
		fprintf(fpAllRev," ^");			//t5ReliabilityS
		fprintf(fpAllRev," ^");			//t5SpareCriteriaS
		fprintf(fpAllRev," ^");			//t5SurfPrtStdS
		fprintf(fpAllRev," ^");			//t5SamplesToApprS
		fprintf(fpAllRev," ^");			//t5AsmDisposalS
		fprintf(fpAllRev," ^");			//t5FinDisposalInstrS
		fprintf(fpAllRev," ^");			//t5RPDisposalInstrS		//50
		fprintf(fpAllRev," ^");			//t5SPDisposalInstrS
		fprintf(fpAllRev," ^");			//t5WIPDisposalInstrS
		fprintf(fpAllRev,"loader^");	//t5LastModByS
		fprintf(fpAllRev," ^");			//t5VerCreatorS
		fprintf(fpAllRev," ^");			//t5CAEDocES

		fprintf(fpAllRev,"%s","N");		//t5CoatedS
		fprintf(fpAllRev,"^");

		fprintf(fpAllRev," ^");			//t5ConvDocS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcRevS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcSeqS
		fprintf(fpAllRev," ^");			//t5AppCodeS				//60
		fprintf(fpAllRev," ^");			//t5RqstNumS
		fprintf(fpAllRev," ^");			//t5RsnCodeS
		fprintf(fpAllRev," ^");			//t5SurfaceAreaS
		fprintf(fpAllRev," ^");			//t5VolumeS
		fprintf(fpAllRev," ^");			//t5CarIntialAgencyS
		fprintf(fpAllRev," ^");			//t5CarMakeBuyIndiS
		fprintf(fpAllRev," ^");			//t5ErcIndNameS
		fprintf(fpAllRev," ^");			//t5PostRelReqS
		fprintf(fpAllRev," ^");			//t5ItmCategoryS
		fprintf(fpAllRev," ^");			//t5CopReqS					//70
		fprintf(fpAllRev," ^");			//t5AplInvalidateS
		fprintf(fpAllRev," ^");			//t5PrtValiStatusS
		fprintf(fpAllRev," ^");			//t5DRSubStateS
		fprintf(fpAllRev," ^");			//t5KnxtDocIndS
		fprintf(fpAllRev," ^");			//t5SimValS
		fprintf(fpAllRev," ^");			//t5PerYieldS
		fprintf(fpAllRev," ^");			//t5PunStoreLocationS
		fprintf(fpAllRev," ^");			//t5AltPartNoS
		fprintf(fpAllRev," ^");			//t5RolledupWtS
		fprintf(fpAllRev," ^");			//t5PFDModReqdS				//80
		fprintf(fpAllRev," ^");			//t5ToolIndentReqdS
		fprintf(fpAllRev," ^");			//CategoryNameS
		fprintf(fpAllRev,"-^");			//ReveffDateFromDup
		fprintf(fpAllRev,"-^");			//ReveffDateToDup			//84
		fprintf(fpAllRev,"NA^");		//LeftRhPartDup				//85

		fprintf(fpAllRev," ^");			//Instance with semicolon separated Rev;Seq		//86

		fprintf(fpAllRev," ^");			//t5JsrIntialAgencyS		//87
		fprintf(fpAllRev," ^");			//t5JsrMakeBuyIndiS			//88
		fprintf(fpAllRev," ^");			//t5LkoIntialAgencyS		//99
		fprintf(fpAllRev," ^");			//t5LkoMakeBuyIndiS			//90
		fprintf(fpAllRev," ^");			//t5PnrIntialAgencyS		//91
		fprintf(fpAllRev," ^");			//t5PnrMakeBuyIndiS			//92
		fprintf(fpAllRev," ^");			//t5PunPCBUIntialAgencyS	//93
		fprintf(fpAllRev," ^");			//t5PunPCBUMakeBuyIndiS		//94
		fprintf(fpAllRev," ^");			//t5SgrIntialAgencyS		//95
		fprintf(fpAllRev," ^");			//t5SgrMakeBuyIndiS			//96
		fprintf(fpAllRev," ^");			//t5EstSheetReqdS			//97
		fprintf(fpAllRev,"-^");			//PartCreDateDupS			//98
		fprintf(fpAllRev,"-^");			//PartModDateDupS			//99
		fprintf(fpAllRev,"loader^");	//PartCreatorDup			//100
		fprintf(fpAllRev," ^");			//t5AhdIntialAgencySDup		//101
		fprintf(fpAllRev," ^");			//t5AhdMakeBuyIndSDup		//102
		fprintf(fpAllRev," ^");			//t5DwdIntialAgencySDup		//103
		fprintf(fpAllRev," ^");			//t5DwdMakeBuyIndSDup		//104
		fprintf(fpAllRev," ^");			//t5JdlIntialAgencySDup		//105
		fprintf(fpAllRev," ^");			//t5JdlMakeBuyIndSDup		//106
		fprintf(fpAllRev," ^");			//t5AhdStoreLocSDup			//107
		fprintf(fpAllRev," ^");			//t5CarStoreLocSDup			//108
		fprintf(fpAllRev," ^");			//t5DwdStoreLocSDup			//109
		fprintf(fpAllRev," ^");			//t5JdlStoreLocSDup			//110
		fprintf(fpAllRev," ^");			//t5JsrStoreLocSDup			//111
		fprintf(fpAllRev," ^");			//t5LkoStoreLocSDup			//112
		fprintf(fpAllRev," ^");			//t5PnrStoreLocSDup			//113
		fprintf(fpAllRev," ^");			//t5PunPCBUStoreLocSDup		//114
		fprintf(fpAllRev," ^");			//t5SgrStoreLocSDup			//115

		fprintf(fpAllRev,"\n"); fflush(fpAllRev);
	}
	//printf("\n");

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartSO);
		t5FreeSqlPtr(Sql_ptr);

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
int SetFlagforScope(SetOfObjects ScopeObjects)
{
	ObjectPtr ScopeObjectPtr = NULL;
	int counter = 0;
	string ScopeObjectclass = NULL;
	string ScopeObjectclassDup = NULL;
	status	dstat = OKAY;

	for(counter = 0; counter < setSize(ScopeObjects); counter ++)
	{
		ScopeObjectPtr = setGet(ScopeObjects,counter);
		if(dstat = objGetClass(ScopeObjectPtr, &ScopeObjectclass)) goto CLEANUP;
		if(!nlsIsStrNull(&ScopeObjectclass))
		{
			ScopeObjectclassDup = nlsStrDup(ScopeObjectclass);
		}

		if (nlsStrCmp(ScopeObjectclass,"OscItem")==0)
		{
			printf("\nObject Found %s hence again expanding by applying dbscope",ScopeObjectclass);
			return 1;
		}
	}
	CLEANUP:
	return 0;
}
