/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* Author		  : Dayanand Amdapure
* Created on	  : Nov 23, 2018
*  Module		 :   TCUA EPA Uploader
*  Code			 :   EPACreate.c
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <pie/pie.h>// For Multilevel BOM explode
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define NULLDATE   (POM_null_date()) 

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002

int cnt = 0;
int cntFlag = 0;
#define Debug TRUE
 FILE*      fp2=NULL;
 FILE*      fp3=NULL;

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}									\

//#define TCTYPE_name_size_c 100
int stringsize =0;
/**
 * Remove leading whitespace characters from string
 */
void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) malloc(3);
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}


struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */
	int          max_char_size = 80;
    char *    Correct_date = (char *)MEM_alloc(max_char_size * sizeof(char));

	*date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
     if(strlen (date)>10)
	     {
			Correct_date=subString(date,0,20);
			printf("  Correct_date [%s]",Correct_date);
			retcode = DATE_string_to_date ( Correct_date , "%y/%m/%d-%H:%M:%S:" , &month , &day , &year , &hour , &minute , &second);
		 }
		 else
		{
			strcpy(Correct_date,date);
			strcat(Correct_date,"-00:00:00:");
			printf("  Correct_date [%s]",Correct_date);
			retcode = DATE_string_to_date ( Correct_date , "%y/%m/%d-%H:%M:%S:" , &month , &day , &year , &hour , &minute , &second);
		}
		printf("  month [%d]",month);
		printf("  day [%d]",day);
		printf("  year [%d]",year);
		printf("  hour [%d]",hour);
		printf("  minute [%d]",minute);
		printf("  second [%d]",second);

	if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
	    printf("  Date is not valid [%d]",month);
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
	    printf("  Date is valid [%d]",month);

    }

	printf("  ---return from validate_date.");

    return retcode;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getPrevDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( --nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}
void reverse(char *s)
{
   int length, c;
   char *begin, *end, temp;
 
   length = tc_strlen(s);
   begin  = s;
   end    = s;
 
   for (c = 0; c < length - 1; c++)
      end++;
 
   for (c = 0; c < length/2; c++)
   {        
      temp   = *end;
      *end   = *begin;
      *begin = temp;
 
      begin++;
      end--;
   }
}

void tm_GetGroupFromDML(char	*cDMLNumber, char	**cRolename)
{

	printf("\nInside tm_GetRoleFromDML DML Number: %s",cDMLNumber);fflush(stdout);
	
	*cRolename	=	NULL;
	*cRolename	=	(char *) MEM_alloc(20 * sizeof(char *));
	if (tc_strstr(cDMLNumber,"APLC")!=NULL)
	{
		tc_strcpy(*cRolename,"APLCAR");
	}
	else if (tc_strstr(cDMLNumber,"APLP")!=NULL)
	{
		tc_strcpy(*cRolename,"APLPUNE");
	}
	else if (tc_strstr(cDMLNumber,"APLJ")!=NULL)
	{
		tc_strcpy(*cRolename,"APLJSR");
	}
	else if (tc_strstr(cDMLNumber,"APLD")!=NULL)
	{
		tc_strcpy(*cRolename,"APLDWD");
	}
	else if (tc_strstr(cDMLNumber,"APLJ")!=NULL)
	{
		tc_strcpy(*cRolename,"APLJSR");
	}
	else if (tc_strstr(cDMLNumber,"APLS")!=NULL)
	{
		tc_strcpy(*cRolename,"APLAHD");
	}
	else if (tc_strstr(cDMLNumber,"APLL")!=NULL)
	{
		tc_strcpy(*cRolename,"APLLKO");
	}
	else if (tc_strstr(cDMLNumber,"APLU")!=NULL)
	{
		tc_strcpy(*cRolename,"APLPNR");
	}
	else if (tc_strstr(cDMLNumber,"APLV")!=NULL)
	{
		tc_strcpy(*cRolename,"APLUV");
	}
	else
	{
		tc_strcpy(*cRolename,"APLCAR");
	}

	printf("\nInside tm_GetRoleFromDML ROLE: %s",*cRolename);fflush(stdout);
}

void  GetPlantForDMLORTask( char * item_id ,char  getPlant[40])
{
    printf( "item_id:%s\n", item_id);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,item_id);
	reverse(item_idCpy);
	revStr	=	(char *)MEM_alloc(50);
	tc_strcpy(revStr,item_idCpy);
	printf("\n revStr Find %s.......",revStr);fflush(stdout);
	tmpStr	=	strtok(revStr,"_");
	printf("\n tmpStr Find %s.......",tmpStr);fflush(stdout);
	revStr1	=	(char *)MEM_alloc(50);
	reverse(tmpStr);
	tc_strcpy(revStr1,tmpStr);
	printf("\n revStr1 Find %s.......",revStr1);fflush(stdout);
	tc_strcpy(getPlant,revStr1);

	printf( "getPlant:%s\n", getPlant);
}

void  GetPlantWiseRelStatAtAPL( char * item_id ,char  getLCSAPLWrkg[40],char  getLCSAPLRlzd[40])
{

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char  ItemIDCpy[40];   

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 
	 char *APLWrkng			= NULL;
	 char *APLRlzd			= NULL;	

	 printf( "item_id:%s\n", item_id);
	tc_strcpy(ItemIDCpy,item_id);
	printf("\n ItemIDCpy is : %s\n",ItemIDCpy);fflush(stdout);
	Dsgn_No=tc_strtok(ItemIDCpy,"_");	
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);
	 

	 if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &APLWrkng);
				printf("\n APLWrkng: %s\n",APLWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &APLRlzd);
				printf("\n APLRlzd: %s\n",APLRlzd);fflush(stdout);

				tc_strcpy(getLCSAPLWrkg,APLWrkng);
				tc_strcpy(getLCSAPLRlzd,APLRlzd);
			}
			else
			{
				tc_strcpy(getLCSAPLWrkg,"T5_LcsAPLpWrkg");
				tc_strcpy(getLCSAPLRlzd,"T5_LcsAplpRlzd");
			}

	printf( "getLCSAPLWrkg:%s\n", getLCSAPLWrkg);
	printf( "getLCSAPLRlzd:%s\n", getLCSAPLRlzd);

}

void  get_CtrlVal_APLLcsInf( char * Tsk_Own_Grp ,char  RevRuleInfo1[40],char  BVRInfo2[40],char  CurMskInfo3[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevRule 			= NULL;
	 char *viewfrmCtrl		= NULL;
	 char *CurVwMask		= NULL;
	 //char *Info4Ctrl		= NULL;
	 //char *Info5Ctrl		= NULL;
	// char *Info6Ctrl		= NULL;
	// char *Info7Ctrl		= NULL;
	// char *Info8Ctrl		= NULL;
	// char *Info9Ctrl		= NULL;

	 if(QRY_find("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLLcsInf";
				qry_valuesCntrl1[1]=Tsk_Own_Grp;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &viewfrmCtrl);
				printf("\n viewfrmCtrl: %s\n",viewfrmCtrl);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &CurVwMask);
				printf("\n CurVwMask: %s\n",CurVwMask);fflush(stdout);

				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(BVRInfo2,viewfrmCtrl);
				tc_strcpy(CurMskInfo3,CurVwMask);
					
			}
			else
			{
				tc_strcpy(RevRuleInfo1,"ERC release and above");
				tc_strcpy(BVRInfo2,"View");
				tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskC");
			}
}

int tm_SVRSolveBOM(tag_t t_tasktag,tag_t DML_tag)
{
	int		status;
	int		pltcnt					=	0;
	int		iplt					=	0;
	int		ipltf					=	0;
	int		ivar					=	0;
	int		n_bom_views				=	0;
	int		rulefound				=	0;
	int		n_count					=	0;
	int		count					=	0;
	int		ichld					=	0;
	int		n_lines2				=	0;
	int		iChildItemTag			=	0;
	int		dmlcount				=	0;
	int		idml					=	0;
	int		st_count				=	0;
	int		iaplrlz					=	0;
	int		ist						=	0;

	char	*roleName				=	NULL;
	char	*ModuleQty				=	NULL;
	char	*SVR_Object				=	NULL;
	char	*SVR_Object_Rev_id		=	NULL;
	char	*Module_SeqId		    =	NULL;
	char	*Module_RevId		    =	NULL;
	char	*objecttype				=	NULL;
	char	*objectname				=	NULL;
	char	*Archtype_name			=	NULL;
	char	*arch_item_id			=	NULL;
	char	*ModPartNo				=	NULL;
	char	*item_Rev_Seq			=	NULL;
	char	*item_Rev_DRStatus		=	NULL;
	char	*class_name1			=	NULL;
	char	*apl_dr_status			=	NULL;
	char	*itemid					=	NULL;
	char	*cGroupname				=	NULL;
	char	*SVR_revNumber			=	NULL;
	char	*ErrString				=	NULL;
	char	*release_name			=	NULL;
	char	**rulename				=	NULL;
	char	**rulevalue				=	NULL;

char	*MES_Itemcategry 		        =	NULL;
char	*MES_ItemcategryDup  		        =	NULL;
char	*MES_Plant   				=	NULL;
char	*MES_PlantDup  				=	NULL;
char	*PartClass_name  	                =	NULL;
char	*MES_Shop  				=	NULL;
char	*MES_ShopDup   				=	NULL;
char	*MES_Line  				=	NULL;
char	*MES_LineDup  				=	NULL;
char	*MES_Station   				=	NULL;
char	*MES_StationDup   	                =	NULL;
char	*CarMakebuy   				=	NULL;
char	*CarMakebuyDup   	                =	NULL;
char	*part_typeDup   		        =	NULL;
char	*PartTypeToPrintS   		        =	NULL;
char	*part_type        		        =	NULL;
char	*CarMakebuyDup1        		        =	NULL;



	
	char	PlantName[40];
	char 	LcsAplWrkg[40];
	char 	LcsAplRlzd[40];

	tag_t	CurrentRoleTag			=	NULLTAG;
	tag_t	t_TaskToRef				=	NULLTAG;
	tag_t	t_TaskToPart			=	NULLTAG;
	tag_t	t_CCVCHasSnapShot		=	NULLTAG;
	tag_t	t_platform				=	NULLTAG;
	tag_t	t_primary				=	NULLTAG;
	tag_t	t_variant				=	NULLTAG;
	tag_t	bom_view				=	NULLTAG;
	tag_t	item					=	NULLTAG;
	tag_t	bom_window				=	NULLTAG;
	tag_t	rule					=	NULLTAG;
	tag_t	close_tag				=	NULLTAG;
	tag_t	top_lne					=	NULLTAG;
	tag_t   bom_variant_rule		=	NULLTAG;
	tag_t  	objTypeTag1				=	NULLTAG;
	tag_t	Childobject				=	NULLTAG;
	tag_t	t_ChildItemRev			=	NULLTAG;
	tag_t	t_DMLTaskRel			=	NULLTAG;
	tag_t	t_CCVctosvrltn			=	NULLTAG;
	tag_t	t_Colrtobasicrltn		=	NULLTAG;
	tag_t	PartChildobj			=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	t_SVRRevision			=	NULLTAG;
	tag_t	t_SVRRevisiont			=	NULLTAG;
	tag_t	class_id1				=	NULLTAG;
	tag_t	plat				=	NULLTAG;
	tag_t	Platrev				=	NULLTAG;
	tag_t	RevTypTag				=	NULLTAG;

	tag_t	*pltList				=	NULLTAG;
	tag_t	*bom_views				=	NULLTAG;
	tag_t	*closurerule			=	NULLTAG;
	tag_t	*ArchNodeLines			=	NULLTAG;
	tag_t	*ColIndChilds			=	NULLTAG;
	tag_t	*lines2					=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	*SVRRevision			=	NULLTAG;
	tag_t	*SVRRevision2			=	NULLTAG;
	tag_t	*status_list			=	NULLTAG;
	tag_t	*platforms			=	NULLTAG;
	
	char*     file_asm5=NULL;
	char*     Platrev1=NULL;
	char*     RevTyp=NULL;
	char*     DML_task=NULL;
	char*     SVR_revNumber2=NULL;
	char*     SVRCCVCNo=NULL;
	
	

	printf("\nInside tm_solveBOMSVR");fflush(stdout);

	//ITKCALL(SA_ask_current_role(&CurrentRoleTag));
	//ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
	//printf("\n\n  roleName : %s\n",roleName); fflush(stdout);
	file_asm5=(char *) MEM_alloc(500);

	char    *qry_entryCntrl1[3]  	= 	{"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= 	(char **) MEM_alloc(5 * sizeof(char *));
	tag_t	qryTagCntrl1			=	NULLTAG;
	int     n_entryCntrl1    		= 	3;
	int		control_number_found,SVRcount,SVRcount2,refsvrn	=	0;
	tag_t	*list_of_WSO_cntrl_tags	=	NULLTAG;
	if(QRY_find("Control Objects...", &qryTagCntrl1));
	
	if(qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLCCVRlzDuplicate";
		qry_valuesCntrl1[1]="APLCCVRlzDuplicate";;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found, &list_of_WSO_cntrl_tags));
		printf("\nNo. of control object found : %d",control_number_found);fflush(stdout);
		//if(control_number_found>0)
		{
			ITKCALL(GRM_find_relation_type("CMReferences",&t_TaskToRef));//Reference Items
			ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&t_TaskToPart));//Solution Item
			ITKCALL(GRM_find_relation_type("T5_PartHasSnapShot",&t_CCVCHasSnapShot));//Part Has Snap Shot
			ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&t_DMLTaskRel));//Part Has Snap Shot
			ITKCALL(GRM_find_relation_type("T5_DerivedFromSVR",&t_CCVctosvrltn));// CCVC to SVR
			ITKCALL(GRM_find_relation_type("TC_Is_Represented_By",&t_Colrtobasicrltn));//Color CCVC to Basic CCVC
			
			ITKCALL(AOM_ask_value_string(t_tasktag,"item_id",&itemid));
			printf("\t  CCVC No ...%s\n", itemid);fflush(stdout);

			ITKCALL(AOM_ask_value_string(DML_tag,"item_id",&DML_task));
			printf("\t  DML no ...%s\n", DML_task);fflush(stdout);
			ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_CCVctosvrltn,&SVRcount,&SVRRevision));
			ITKCALL(GRM_list_secondary_objects_only(DML_tag,t_TaskToRef,&SVRcount2,&SVRRevision2));

			
       //ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_CCVctosvrltn,&SVRcount,&SVRRevision));//Get DML from task
       printf("\t  No of SVR attached to CCVC ...%d\n", SVRcount);fflush(stdout);
	   if (SVRcount>0)
	   {
		   t_SVRRevision=SVRRevision[0];

		   ITKCALL(AOM_ask_value_string(t_SVRRevision,"item_id" , &SVR_revNumber));
        
		  printf("\t   SVR  NO attached to CCVC  is ...%s\n", SVR_revNumber);fflush(stdout);
	   }
	   else if(SVRcount2>0)
			{

	   for (refsvrn=0; refsvrn<SVRcount2; refsvrn++)
	      {

       t_SVRRevisiont=SVRRevision2[refsvrn];

      ITKCALL(AOM_ask_value_string(t_SVRRevisiont,"current_name" , &SVR_revNumber2));
		   printf("\t   SVR  NO attached DML  is ...%s\n", SVR_revNumber2);fflush(stdout);
      SVRCCVCNo=subString(SVR_revNumber2,0,12);
	  printf("\t   CCVC from SVR  NO is ...%s\n", SVRCCVCNo);fflush(stdout);
						 if (tc_strcmp(itemid,SVRCCVCNo)==0)
						{
                     t_SVRRevision=SVRRevision2[refsvrn];
						}

	               }
	   
	             }
				 else
			        {
				  printf("\t   as SVR is not attached to CCVC or DML hence not printing bOM of CCVC ...%s\n", itemid);fflush(stdout);
				 
				 }

      ITK_CALL(ITEM_find_item("X4", &plat));
	
	   ITK_CALL(ITEM_ask_latest_rev(plat, &Platrev));
	   	if(TCTYPE_ask_object_type(Platrev, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);
      ITKCALL(AOM_ask_value_string(Platrev,"item_revision_id",&Platrev1));
	   printf("\nPlatform Revsion is :%s",Platrev1);fflush(stdout);


	  if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
			{
			
			t_primary=Platrev;
			}
				
			tm_GetGroupFromDML(DML_task, &cGroupname);
			printf("\ngroup Name :%s",cGroupname);fflush(stdout);
			GetPlantForDMLORTask( DML_task ,PlantName);
			printf("\nPlantName :%s",PlantName);fflush(stdout);
			
			GetPlantWiseRelStatAtAPL(DML_task,LcsAplWrkg,LcsAplRlzd);
			printf("\n LcsAplWrkg: %s \n",LcsAplWrkg);
			printf("\n LcsAplRlzd: %s \n",LcsAplRlzd);
			
			char	RevRuleInfo1[40];
			char	BVRInfo2[40];
			char	currviewmask[40];
			get_CtrlVal_APLLcsInf(cGroupname,RevRuleInfo1,BVRInfo2,currviewmask);
			printf("\nRevision Rule : %s , BVR : %s , View Mask : %s \n",RevRuleInfo1,BVRInfo2,currviewmask);fflush(stdout);
										
			//Get DML from Task
//			if (t_DMLTaskRel!=NULLTAG)
//			{
//				ITKCALL(GRM_list_primary_objects_only(t_tasktag,t_DMLTaskRel,&dmlcount,&DMLRevision));//Get DML from task
//				printf("\n\t\t APL DML Revision from Task : %d",dmlcount); fflush(stdout);
//				for (idml=0;idml<dmlcount ;idml++ )
//				{
//					DMLRevTag = DMLRevision[idml];					
//					ITKCALL(POM_class_of_instance(DMLRevTag,&class_id1));
//					ITKCALL(POM_name_of_class(class_id1,&class_name1));
//					printf("\n\t class_name found1 :%s",class_name1); fflush(stdout);
//
//					if(tc_strcmp(class_name1,"T5_APLDMLRevision")==0)
//					{
//						ITKCALL(AOM_ask_value_string( DMLRevTag, "t5_cDRstatus", &apl_dr_status));
//						printf("\n erc_dmlrelztype: %s\n",apl_dr_status);fflush(stdout);
//					}
//				}
//			}
			//if (t_TaskToRef!=NULLTAG)
			{
				printf("\nFetch SVR from task");fflush(stdout);

				//ITKCALL(GRM_list_secondary_objects_only(t_tasktag,t_TaskToRef,&pltcnt,&pltList));
				//printf("\nNumber of SVRS found in Reference Item : %d",pltcnt);fflush(stdout);
				//if (pltcnt>0)
				{
					//for(iplt=0;iplt<pltcnt;iplt++)
					{
						printf("\nFind Platform");fflush(stdout);
						//t_platform	=	pltList[iplt];
						//if(AOM_ask_value_string(t_platform,"object_type",&objecttype));
					//	if(AOM_ask_value_string(t_platform,"object_name",&objectname));
						printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
//						if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
//						{
//							printf("\nPlatform found...");fflush(stdout);
//							//t_primary	=	t_platform;
//							t_primary	=	pltList[iplt];
//							break;
//						}
					}
					///for(ivar=0;ivar<pltcnt;ivar++)
					{
						printf("\nFind attached variant rule");fflush(stdout);
						t_variant	=	t_SVRRevision;

						if(AOM_ask_value_string(t_variant,"object_type",&objecttype));
						if(AOM_ask_value_string(t_variant,"object_name",&objectname));
						printf("\nObject name : %s and type : %s",objectname,objecttype);fflush(stdout);
						if(tc_strcmp(objecttype,"VariantRule")==0)
						{
							printf("\ninside VariantRule found");fflush(stdout);
							//if (ipltf==0)
							{
								//ipltf++;
								printf("\nVariant Rule found in relation"); fflush(stdout);
								if(t_variant!=NULLTAG)
								{
									if (t_primary!=NULLTAG)
									{
										printf("\nt_primary is not nulltag");fflush(stdout);
									}
									if ( ITEM_ask_item_of_rev( t_primary, &item ));
									if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
									printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
									bom_view = bom_views[0];
									


									if (bom_view!=NULLTAG)
									{
										   //tc_strcpy(file_asm5,"/user/aplstdgrp/Nana/TCUA_MES_Files/");
//											//tc_strcat(file_asm,cNextDate);
//											tc_strcat(file_asm5,"Incremental_BOM_");
//											tc_strcat(file_asm5,objectname);
//											tc_strcat(file_asm5,".xml");
//											printf("\n File Name is %s\n",file_asm5);fflush(stdout);


										// fp2= fopen(file_asm5,"a+");


//										 fprintf(fp5,"<?xml version=");
//										 fprintf(fp5,"\"1.0\"");
//										 fprintf(fp5," encoding=");
//										 fprintf(fp5,"\"UTF-8\"");
//										 fprintf(fp5,"?>");
//										 fprintf(fp5,"\n<PROTOCOL name=");
//										 fprintf(fp5,"\"COMPLETE_BOM_MASTER");
//										 fprintf(fp5,"\" timestamp=\"");
//										 fprintf(fp5,"1267827515336\" version=\"1.0\">\n"); fflush(fp5);
//										 printf("\n File Name is 1\n");//fflush(stdout);
//										  fprintf(fp5,"\t<TRANSACTION>\n");// fflush(fp5);
//										 fprintf(fp5,"\t\t<INSERT>\n");//fflush(fp5);

                                        printf("\n File Name is 2\n");fflush(stdout);
										ITKCALL(BOM_create_window(&bom_window));fflush(stdout);
										printf("\n File Name is 3\n");fflush(stdout);
										//ITKCALL(CFM_find("APLC release and above", &rule));
										ITKCALL(CFM_find(RevRuleInfo1, &rule));
										printf("\nView found check.......%d\n",n_bom_views); fflush(stdout);
										ITKCALL(BOM_set_window_config_rule(bom_window, rule));
										ITKCALL(PIE_find_closure_rules("BOMLineskipforunconfiguredAPLC",PIE_TEAMCENTER, &rulefound, &closurerule ));

										printf ("\nrule count %d \n",rulefound);fflush(stdout);
										if (rulefound > 0)
										{
											close_tag = closurerule[0];
											printf ("closure rule found \n"); fflush(stdout);
										}

										ITKCALL(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
										ITKCALL(BOM_set_window_pack_all(bom_window, FALSE));
										ITKCALL(BOM_set_window_top_line( bom_window, NULLTAG, t_primary, NULLTAG, &top_lne ));
										ITKCALL(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));

										ITKCALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag1));
										ITKCALL(TCTYPE_ask_name2(objTypeTag1,&Archtype_name));
										printf("\n Archtype_name------> %s\n",Archtype_name);fflush(stdout);

										if(top_lne!=NULLTAG)
										{

														SVR_Object=strtok(objectname,"_"); //2
			                                            SVR_Object_Rev_id=strtok(NULL,","); //3



											ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
											printf("\n n_count --------> : %d\n", n_count);

											ITKCALL(BOM_window_hide_unconfigured(bom_window));
											ITKCALL(BOM_window_show_variants(bom_window));
											ITKCALL(BOM_window_apply_variant_configuration(bom_window,1,&t_variant));
											ITKCALL(BOM_window_hide_variants(bom_window));
											ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
											printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node
											if (count >0)
											{	
												for (ichld=0;ichld<count ;ichld++ )
												{
													if(Childobject) Childobject=NULLTAG;
													Childobject=ColIndChilds[ichld];

													ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
													printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
													//if (tc_strcmp(apl_dr_status,item_Rev_DRStatus)==0)
													//Check for BIW module and bolted module
													if(lines2) lines2=NULL;
													ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
													printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);
													if (n_lines2==1)
													{
														if(PartChildobj) PartChildobj=NULLTAG;
														if(ModPartNo) ModPartNo=NULL;
														if(item_Rev_Seq) item_Rev_Seq=NULL;
														PartChildobj=lines2[0];

														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
														printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);
															
														ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
														printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

													     Module_RevId=strtok(item_Rev_Seq,";"); //2
			                                            Module_SeqId=strtok(NULL,","); //3


													ITKCALL(AOM_ask_value_string(PartChildobj, "bl_quantity", &ModuleQty));
														printf("\n Module Quantity is --> : %s\n",ModuleQty); fflush(stdout);

														
														int iChildItemTag=0;
														tag_t t_ChildItemRev=NULLTAG;
														BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
														BOM_line_ask_attribute_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);
													ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_CarMakeBuyIndicator", &CarMakebuy));
														printf("\n Module Quantity is --> : %s\n",CarMakebuy); fflush(stdout);



															        fprintf(fp2,"\t\t\t\t\t<CHILD>\n");
																	fprintf(fp2,"\t\t\t\t\t\t<PARTNUMBER>");
																	fprintf(fp2,ModPartNo);
																	fprintf(fp2,"</PARTNUMBER>\n");
																	fprintf(fp2,"\t\t\t\t\t\t<REVISION>");
																	fprintf(fp2,Module_RevId);
																	fprintf(fp2,"</REVISION>\n");
																	fprintf(fp2,"\t\t\t\t\t\t<SEQUENCE>");
																	fprintf(fp2,Module_SeqId);
																	fprintf(fp2,"</SEQUENCE>\n");
																	fprintf(fp2,"\t\t\t\t\t\t<QUANTITY>");
																	fprintf(fp2,ModuleQty);
																	fprintf(fp2,"</QUANTITY>\n");
																	fprintf(fp2,"\t\t\t\t\t\t<GROUPFLAG>");						   
																	fprintf(fp2,"1");						
																	fprintf(fp2,"</GROUPFLAG>\n");
													//				fprintf(fp,"\t\t\t\t<ITEMNAME>");
													//				fprintf(fp,"");
													//				fprintf(fp,"</ITEMNAME>\n");
																	fprintf(fp2,"\t\t\t\t\t</CHILD>\n");
														  printf("\n Part Type is %s\n",ModPartNo);fflush(stdout);

                         ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_ItmCategory", &MES_Itemcategry));
						  //printf("\n Part Type is Item cate\n");fflush(stdout);
										
												if (MES_Itemcategry)
												{
													tc_strdup(MES_Itemcategry,&MES_ItemcategryDup);
												}
                                       //printf("\n Part Type is Item cate \n",MES_ItemcategryDup);fflush(stdout);

						ITKCALL( AOM_ask_value_string(t_ChildItemRev,"object_desc",&MES_Plant));
											if (MES_Plant)
												{
													tc_strdup(MES_Plant,&MES_PlantDup);
												}
                                       printf("\n Part Desc is %s\n",MES_Plant);fflush(stdout);
											if (tc_strcmp(PartClass_name,"Design Revision")==0)
												{													
											ITKCALL (AOM_UIF_ask_value(t_ChildItemRev,"t5_MeShop",&MES_Shop));
												}
												else if (tc_strcmp(PartClass_name,"T5_ClrPartRevision")==0)
												{
													AOM_UIF_ask_value(t_ChildItemRev,"t5_MesShop",&MES_Shop);                                                   
												}
										//  printf("\n Part Desc22 is %s\n",MES_Plant);fflush(stdout);
											if (MES_Shop)
												{
													tc_strdup(MES_Shop,&MES_ShopDup);
												}
										//AOM_UIF_ask_value(PartChildobj,"t5_MesLine",&MES_Line);
											if (MES_Line)
												{
													tc_strdup(MES_Line,&MES_LineDup);
												}
										//AOM_UIF_ask_value(PartChildobj,"t5_MesStation",&MES_Station);
											if (MES_Station)
												{
													tc_strdup(MES_Station,&MES_StationDup);
												}
												
													
							//	ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_CarMakeBuyIndicator", &CarMakebuy));												
												
									//  printf("\n Part Desc33 is %s\n",MES_Plant);fflush(stdout);	
												if (CarMakebuy)
												{
													tc_strdup(CarMakebuy,&CarMakebuyDup);
												}
												 //CarMakebuyDup1 = strtok(CarMakebuyDup," ");

												 							
								ITKCALL(AOM_ask_value_string(t_ChildItemRev, "t5_PartType", &part_typeDup));												
										//  printf("\n Part Type is %s\n",part_typeDup);fflush(stdout);		
										

                         PartTypeToPrintS=(char *) MEM_alloc(500);

											if (tc_strlen(part_typeDup)==0)
												{
												  strcpy(PartTypeToPrintS,"(Null)");
													
												}else
									                {
													tc_strdup(part_typeDup,&part_type);
												    }

                                                  // printf("\n Part Type22 is %s\n",part_type);fflush(stdout);
												if(tc_strcmp(part_type,"VC")==0) 	
													{					
														strcpy(PartTypeToPrintS,"Vehicle Combination");
													}
													else if(tc_strcmp(part_type,"V")==0) 	
													{
														 
														strcpy(PartTypeToPrintS,"Vehicle");
													}
													else if(tc_strcmp(part_type,"A")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Assembly");
													}
													else if(tc_strcmp(part_type,"C")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Component");
														
													}
													else if(tc_strcmp(part_type,"D")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Dummy");
													}
													else if(tc_strcmp(part_type,"G")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Group Id");
													}
													else if(tc_strcmp(part_type,"SA")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Assembly");
													}
													else if(tc_strcmp(part_type,"SP")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Part");
													}
													else if(tc_strcmp(part_type,"IFD")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Information Fittement Drawing");
													}
													else if(tc_strcmp(part_type,"M")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Module");
													}
													else if(tc_strcmp(part_type,"TD")==0) 
													{
														strcpy(PartTypeToPrintS,"Table Drawinig");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}
												   else 
													{
														strcpy(PartTypeToPrintS,"(Null)");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}

                             printf("\n starting file priniting\n");fflush(stdout);

									fprintf(fp3,"\t\t\t<PART>\n"); 
									fprintf(fp3,"\t\t\t\t<PARTTYPE>");
									fprintf(fp3,"Module");
									fprintf(fp3,"</PARTTYPE>\n");
									fprintf(fp3,"\t\t\t\t<PARTNUMBER>");
									fprintf(fp3,ModPartNo);
									fprintf(fp3,"</PARTNUMBER>\n");
									fprintf(fp3,"\t\t\t\t<REVISION>");
									fprintf(fp3,Module_RevId);
									fprintf(fp3,"</REVISION>\n");
									fprintf(fp3,"\t\t\t\t<SEQUENCE>");
									fprintf(fp3,Module_SeqId);
									fprintf(fp3,"</SEQUENCE>\n");
									fprintf(fp3,"\t\t\t\t<ITEMNAME>");
									fprintf(fp3,"Null");
									fprintf(fp3,"</ITEMNAME>\n");
									fprintf(fp3,"\t\t\t\t<SHOP>");
									if(tc_strlen(MES_ShopDup)==0)
                                 	{
									   fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_ShopDup);
									   
									    }

									fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
                                    if(tc_strlen(MES_LineDup)==0)
									{
									fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_LineDup);
									      
									    }

									fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
                                  if(tc_strlen(MES_StationDup)==0)
                                   	{
									 fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_StationDup);
									     
									    }

								fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<DESCRIPTION>");
							    fprintf(fp3,MES_PlantDup);
							    fprintf(fp3,"</DESCRIPTION>\n");
								fprintf(fp3,"\t\t\t\t<ITEMCATEGORY>");
								 if(tc_strlen(MES_StationDup)>0)
                                   	{
									 fprintf(fp3,MES_StationDup);
									
									}
									else{										
									      fprintf(fp3,"Null");
									    }					

							    fprintf(fp3,"</ITEMCATEGORY>\n");
								fprintf(fp3,"\t\t\t\t<CS>");
							    fprintf(fp3,CarMakebuy);
							    fprintf(fp3,"</CS>\n");
								fprintf(fp3,"\t\t\t\t<UOM>");
							    fprintf(fp3,"4");
							    fprintf(fp3,"</UOM>\n");
								fprintf(fp3,"\t\t\t\t<PLANT>");
							    fprintf(fp3,"1100");
							    fprintf(fp3,"</PLANT>\n");

								fprintf(fp3,"\t\t\t\t<Optional1>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional1>\n");
							    fprintf(fp3,"\t\t\t\t<Optional2>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional2>\n");
								fprintf(fp3,"\t\t\t\t<Optional3>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional3>\n");
								fprintf(fp3,"\t\t\t\t<OBSOLETEFLAG>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</OBSOLETEFLAG>\n");
									fprintf(fp3,"\t\t\t</PART>\n");

														//fprintf(fp,"%s,%s,%s,%s\n",objectname,arch_item_id,ModPartNo,item_Rev_DRStatus);fflush(fp);
													}
													else if(n_lines2>1)
													{
														printf("\nNo child found in arch node : %s",arch_item_id);
//														ErrString	=	NULL;
//														ErrString	=	(char	*)MEM_alloc(300);
//														tc_strcpy(ErrString,"More than one module solved in Architecture Node ");
//														tc_strcat(ErrString,arch_item_id);
//														tc_strcat(ErrString," After SVR ");
//														tc_strcat(ErrString,objectname);
//														tc_strcat(ErrString," applied on platform.\n");
//														setAddStr(icount,SetChildRelErr,ErrString);
														//fprintf(fp,"%s,%s,More than one module solve\n",objectname,arch_item_id);fflush(stdout);
													}
													else
													{
														printf("\nNo child found in arch node : %s",arch_item_id);
														//fprintf(fp,"%s,%s,0\n",objectname,arch_item_id);fflush(stdout);
													}
												}																						
											}

//											 fprintf(fp5,"\t\t\t</PARENT>\n");
//											   fprintf(fp5,"\t\t</INSERT>\n");
//										  fprintf(fp5,"\t</TRANSACTION>\n");
//										  fprintf(fp5,"</PROTOCOL>\n");

										}
									}
								}
							}
						}
					}
				}
				//else
				{
					printf("\nNo SVR attached with Task");fflush(stdout);
				}
			}
		}
	}
fflush(stdout);
//fflush(fp5);
// fclose (fp5);
	return status;
}

int tm_SVRAttributmstr(tag_t CCVCTag)
{

	int status;
    char *  	DMLName=NULL;
	char *     AQEngineer=NULL;
	char *     AQGroupLeader=NULL;
	char *     ActionByAgency=NULL;
	char *     ActionTobeTaken=NULL;
	char *     ClosureComments=NULL;
	char *     Customer=NULL;
	char *     DateOfIntroInVC2=NULL;
	char *     DateOfIntroInVC3=NULL;
	char *     DateOfIntroInVC4=NULL;
	char *     DateOfIntroInVCE2=NULL;
	char *     DateOfIntroInVCE3=NULL;
	char *     EmailAdd=NULL;
	char *     EpaMeetinDate=NULL;
	char *    EpaPlantA=NULL;
	char *    InterchangeCodes=NULL;
	char *    MEPA_NO=NULL;
	char *    MbpaCreDate=NULL;
	char *    MbpaCretor=NULL;
	char *    MepaCreDate=NULL;
	char *    MepaCretor=NULL;
	char *    PlanningStatus=NULL;
	char *    WbsPriority=NULL;
	char *    t5AggreCutOffNo=NULL;
	char *    t5AggreCutOffNo1=NULL;
	char *    t5AppModelList=NULL;
	char * *   t5AppModelListArry=NULL;
	char * *   t5ModelListArry=NULL;
	char *    t5BomComu=NULL;
	char *    t5BreakPointDate=NULL;
	char *    t5BtchCode=NULL;
	char *    t5CTChange=NULL;
	char *    t5Category_code1=NULL;
	char * *   t5Category_code1Arry=NULL;
	char *    t5Category_code2=NULL;
	char *    t5Category_code3=NULL;
	char *    t5Category_code4=NULL;
	char * *   t5Category_code4Arry=NULL;
	char *    t5Category_code5=NULL;
	char *    t5Category_code6=NULL;
	char *    t5ChasisNo=NULL;
	char *    t5ChasisNo2=NULL;
	char *    t5ChasisNo3=NULL;
	char *    t5ChasisNo4=NULL;
	char *    t5ChasisNoE=NULL;
	char *    t5ChasisNoE2=NULL;
	char *    t5ChasisNoE3=NULL;
	char *    t5ChasisNoE4=NULL;
	char *    t5ChasisTypeList=NULL;
	char **    t5ChasisTypeListArry=NULL;
	char *    t5CommnMepaStr=NULL;
	char *    t5CostReduction=NULL;
	char *    t5DesignGroup=NULL;
	char *    t5DisposalAction1=NULL;
	char *    t5DisposalAction2=NULL;
	char *    t5DisposalAction3=NULL;
	char *    t5DisposalAction4=NULL;
	char *    t5DisposalAction5=NULL;
	char *    t5DumCompln=NULL;
	char *    t5DumEpNo=NULL;
	char *    t5ECNTstRepNo=NULL;
	char *    t5EPACategory_code1=NULL;
	char *    t5EPAClosureDate=NULL;
	char *     t5EpaClass=NULL;
	char *     t5EpaClassDate=NULL;
	char *     t5EpaFolUpInd=NULL;
	char *     t5EpaSet=NULL;
	char *     t5EpaStatus=NULL;
	char *     t5EpaTskCrDate=NULL;
	char *     t5EpaType=NULL;
	char **    t5EpaTypeArry=NULL;
	char *     t5EpaValidity=NULL;
	char *     t5FialReq=NULL;
	char *     t5Introduction_type=NULL;
	char *     t5IsActionReqbySer=NULL;
	char *     t5IsDumEp=NULL;
	char *     t5IsSubAggReq=NULL;
	char *     t5IsToolReq=NULL;
	char *     t5IsTryOutReq=NULL;
	char *     t5LogisticsRemarks=NULL;
	char *     t5LstPODate=NULL;
	char *     t5LstSmplDate=NULL;
	char *     t5MBPARemarks=NULL;
	char *     t5MEPAQADate=NULL;
	char *     t5MailAlert=NULL;
	char *     t5MbpaDesc=NULL;
	char *     t5MbpaNo=NULL;
	char *     t5MepaReason=NULL;
	char *     t5ModOfIntrod=NULL;
	char *     t5ModelList=NULL;
	char *     t5POCheckStatus=NULL;
	char *     t5POLockDate=NULL;
	char *     t5PPMRemarks=NULL;
	char *     t5PartYesNo=NULL;
	char *     t5PartialReason=NULL;
	char *     t5QACRemarks=NULL;
	char *     t5ReadinessDate=NULL;
	char *     t5ReleaseNotes=NULL;
	char *     t5RemarkAppModel=NULL;
	char *     t5RemarksBP=NULL;
	char *     t5RemarksEPAClosure=NULL;
	char *     t5RemarksMEPAQA=NULL;
	char *     t5RemarksPOLock=NULL;
	char *     t5RemarksReadiness=NULL;
	char *     t5RemarksStocks=NULL;
	char *     t5RemarksTryout=NULL;
	char *     t5RevRemarks=NULL;
	char *     t5RjVECNo=NULL;
	char *     t5RygSts=NULL;
	char *     t5SORSendDate=NULL;
	char *     t5ServAction=NULL;
	char *     t5ServActionAgg=NULL;
	char *     t5StocksSCMDate=NULL;
	char *     t5TSRemarks=NULL;
	char *     t5TargetDtIntro=NULL;
	char *     t5TargetDtIntroHis=NULL;
	char *     t5TmpEcnNo=NULL;
	char *     t5TrgtDtIntRem=NULL;
	char *     t5TryoutDate=NULL;
	char *     t5VDRemarks=NULL;
	char *     t5VQARemarks=NULL;
	char *     t5tcfAggregate=NULL;
	char *     t5tcfAggregate1=NULL;
	char **     t5tcfAggregateArry=NULL;
	char *     tentativeDateLogistic=NULL;
	char *     tentativeDateSCM=NULL;
	char *     tx0Addressee=NULL;
	char *     tx0DateReceived=NULL;
	char *     ERCRelDate=NULL;
	char *     inputfile=NULL;
	char *     Outputfile=NULL;
	char*       inputline=NULL;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t item=NULLTAG;
	tag_t *item_rev=NULLTAG;
	char* item_id=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
				tag_t tag_query;


	char *entries[2] = {"ID","Revision"};
	//char **values =	(char **) MEM_alloc(10 * sizeof(char *));


  	int          n_tags_found= 0;
	int	count,cnt=0;
	int	j,ik,i,count2,tscount=0;
	int          max_char_size = 80;

	char*	 current_name		= NULL;
	char*	 SVRDescription	= NULL;
	char*     file_asm4=NULL;
	char*	 t5NoEcuDup		= NULL;
	char*	 Safety_fetures		= NULL;
	char*	 Fuel_Type		= NULL;
	char*	 Emsn_Norms		= NULL;
	char*	 VehicleID		= NULL;
	char*	 VehicleD		= NULL;
	char*	 Speedometerratio		= NULL;
	char*	 Transaxletype		= NULL;
	char*	 Steering_Type		= NULL;
	char*	 Transaxle_Ratio		= NULL;
	char*	 Transmission_Type		= NULL;
	char*	 parttype		= NULL;
	char*	 current_name2		= NULL;
	char*	 current_name3		= NULL;
	char*	 colorCCVC_No		= NULL;
	char*	 BasicVC_No		= NULL;
	char*	 ccvRevId		= NULL;
	char     *clsKeyAtrrId= NULL;
	char * 	t5IsStructEPA=NULL;
	char * 	attributeValue=NULL;
	char * 	ColorIndicator=NULL;
	char  	*CCVC_Number=NULL;
	char  	*AttrVal=NULL;
	char *    EpaPlantAc = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    InterchangeCodesC = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    WbsPriorityC = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    t5MailAlertC = (char *)MEM_alloc(max_char_size * sizeof(char));
	tag_t*   tags_found1 = NULL;
	tag_t*   tags_found2 = NULL;
	tag_t*   EpaTag = NULL;
	tag_t*   EpaTagRev = NULL;
	tag_t	relation_type = NULLTAG;
	tag_t*			PartDmlTags			= NULLTAG;
	tag_t objTypeRefTag              =    NULLTAG;
	 tag_t *DMLRevision = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t DMLRevTag = NULLTAG;
	tag_t item3 = NULLTAG;
	tag_t item2 = NULLTAG;

	tag_t	ccvMstrTag = NULLTAG;
    tag_t relation_type_tag = NULLTAG;
    tag_t relation_type_tag2 = NULLTAG;
    tag_t *		techspec_objects;
    tag_t *		techspec_objects2;
	tag_t *ClsObjTag = NULLTAG;
	tag_t *Design_rev_cls_tag = NULLTAG;
	 tag_t			PartDmlTag				= NULLTAG;

			char keyPrefix[10];
			tc_strcpy(keyPrefix,"-");
			tc_strcat(keyPrefix,clsKeyAtrrId);
			printf("\n  input keyPrefix[%s]",keyPrefix); fflush(stdout);
			const char * key_lov_id=keyPrefix; //cls attr id for ChassisTypeNo_TYP_APPRVL_NO
			char * key_lov_name;
			int   options;
			int   options1;
			int   options2;
			int   options3;
			//int i;
			int keyfound,tscount2=0;
			int   n_lov_entries;
			int   n_lov_entries1;
			char ** lov_keys;
			char ** lov_values;
			logical * deprecated_staus;
			char * owning_site;
			char *keyLovOfCCVNo=(char*) MEM_alloc( 1 * sizeof(lov_keys) );
			int   n_shared_sites;
			char ** shared_sites ;
				 logical is_latest;

				 file_asm4=(char *) MEM_alloc(500);
	
	char			type_name_ref[TCTYPE_name_size_c+1];
	//FILE*      fp=NULL;
	FILE*      fp4=NULL;

printf("\n  Inside CCVC Attribute master function .... "); fflush(stdout);
if(CCVCTag)
			{
				
				//for (i=0; i<n_tags_found; i++)
				{

					item = CCVCTag;
				
				//ITK_CALL(ITEM_ask_latest_rev(item,&item_rev));
				//ITK_CALL(AOM_ask_value_date(item_rev,"date_released",&ERCRelDate));
				ITKCALL(AOM_ask_value_string(item,"item_id" , &CCVC_Number))
				ITKCALL(AOM_ask_value_string(item,"t5_PartType" , &parttype))
					ITKCALL(AOM_ask_value_string(item,"item_revision_id",&ccvRevId));
					
                          printf("\n CCVC Number  is %s\n",CCVC_Number);fflush(stdout);
					ITKCALL(AOM_ask_value_string(item,"t5_ColourInd",&ColorIndicator));
					printf("\n\n\t\t Revision and Part Type,color indicator is :%s,%s,%s\n",ccvRevId,parttype,ColorIndicator);fflush(stdout);

                         ITK_CALL(AOM_UIF_ask_value(item,"object_desc",&SVRDescription));
					//if (strcmp(item_revision_id,current_name3)==0)
					//if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
					{
						if(tc_strstr(parttype,"V")!=NULL)	//allowing CCV/V
						{

							//if(tc_strstr(ccvRevId,"NR")!=NULL)
							{

					tc_strcpy(file_asm4,"/user/aplstdgrp/Nana/TCUA_MES_Files/MES_");
					//tc_strcat(file_asm4,cNextDate);
					tc_strcat(file_asm4,CCVC_Number);
					tc_strcat(file_asm4,"_AttriBute_Matser");					
					tc_strcat(file_asm4,".xml");
					printf("\n File Name is %s\n",file_asm4);fflush(stdout);
						fp4=fopen(file_asm4,"a+");

					  
					fprintf(fp4,"<?xml version=");
					fprintf(fp4,"\"1.0\"");
					fprintf(fp4," encoding=");
					fprintf(fp4,"\"UTF-8\"");
					fprintf(fp4,"?>");

						 fprintf(fp4,"\n<PROTOCOL name=");
						  //fprintf(fp,"");
						 fprintf(fp4,"\"ATTRIBUTE_MASTER");
						 fprintf(fp4,"\" timestamp=\"");
						 fprintf(fp4,"1267827515336\" version=\"1.0\">\n"); fflush(fp4);
						 fprintf(fp4,"\t<AttributeMaster>\n");
                  if((tc_strcmp(parttype,"CCVC")==0) && (tc_strcmp(ColorIndicator,"C")==0))
                   {
					   VehicleID=subString(CCVC_Number,0,8);
					    printf(" B.Vehicle ID is %s...\n",VehicleID);fflush(stdout);
					   VehicleD=subString(CCVC_Number,11,12);
					   printf(" Vehicle Drive is %s...\n",VehicleD);fflush(stdout);
					   tc_strcat(VehicleID,VehicleD);
					   printf("Basic Vehicle No is %s...\n",VehicleID);fflush(stdout);


					   		   values[0]=VehicleID;
		                        values[1]="NR;1";

		   ITKCALL(QRY_find("Design Revision",&tag_query));
			printf("Searching... design rev \n");fflush(stdout);

			//Querying with item id
			//ITK_CALL(ITEM_find_items_by_key_attributes(1,entries, values, &n_tags_found, &tags_found));
			 ITKCALL(QRY_execute(tag_query,1, entries, values,&n_tags_found,&tags_found1));
			printf(" Vehicle tags_found1  --->[%d]\n",n_tags_found);
			item = tags_found1[0];


                   }

				   
                  
                       ITK_CALL(AOM_ask_value_string(item,"item_id",&BasicVC_No));
					   printf("BasicVC_No.%s\n",BasicVC_No);fflush(stdout);
						ITKCALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
					ITKCALL(GRM_list_secondary_objects_only(item,relation_type_tag,&tscount,&techspec_objects ));
                           printf("Searching.. vehichle spec.%d\n",tscount);fflush(stdout);
				
                  if(tscount==0)
						{
					 printf(" Inside Horn Bill Logic\n");

	    if((tc_strcmp(parttype,"CCVC")==0) && (tc_strcmp(ColorIndicator,"C")==0))
                   {

			printf(" Inside Horn Bill Logic Item id is %s\n",CCVC_Number);
					   VehicleID=subString(CCVC_Number,0,8);
					    printf(" B.Vehicle ID is %s...\n",VehicleID);fflush(stdout);
					   VehicleD=subString(CCVC_Number,11,12);
					   printf(" Vehicle Drive is %s...\n",VehicleD);fflush(stdout);
					    tc_strcat(VehicleID,"000");
					   tc_strcat(VehicleID,VehicleD);
					   printf("Basic Vehicle No is %s...\n",VehicleID);fflush(stdout);


					   		   values[0]=VehicleID;
		                        values[1]="NR;1";

		   ITKCALL(QRY_find("Design Revision",&tag_query));
			printf("Searching.. design rev2.\n");fflush(stdout);
			
			//MEM_free (item);
			//MEM_free (tags_found);
			//tag_t item=NULLTAG;

			//Querying with item id
			//ITK_CALL(ITEM_find_items_by_key_attributes(1,entries, values, &n_tags_found, &tags_found));
			 ITKCALL(QRY_execute(tag_query,1, entries, values,&n_tags_found,&tags_found2));
			printf(" Vehicle tags_found2  --->[%d]\n",n_tags_found);
			
			item2 = tags_found2[0];
			          ITK_CALL(AOM_ask_value_string(item2,"item_id",&colorCCVC_No));
					   printf("colorCCVC_No.%s\n",colorCCVC_No);fflush(stdout);


                   }
				 
				      }

                       ITK_CALL(AOM_ask_value_string(item2,"item_id",&colorCCVC_No));
					   printf("colorCCVC_No.%s\n",colorCCVC_No);fflush(stdout);
					  ITKCALL(GRM_find_relation_type("T5_VCSpec", &relation_type_tag2));
				      ITKCALL(GRM_list_secondary_objects_only(item2,relation_type_tag2,&tscount2,&techspec_objects2 ));
                           printf("Searching3...%d\n",tscount2);fflush(stdout);
						   if (tscount>0)
						   {
							   item3=tags_found1[0];

						   }
						   else{
							   item3=tags_found2[0];
						   
						         }

					
						//if( (tscount>0) || (tscount2>0) )
						{	
							printf("master tag finding...\n");fflush(stdout);
					ITKCALL(ITEM_ask_item_of_rev(item3,&ccvMstrTag));	
					 printf("master tag found...\n");fflush(stdout);
							//find the classified object for above tech Spec
							if(ccvMstrTag)
							{

                             printf("Classifying the master.\n");fflush(stdout);
							ITKCALL(AOM_ask_value_tags(ccvMstrTag,"IMAN_classification",&cnt,&ClsObjTag));
								printf("\n classified object count[%d] for CCV[%s] !!",cnt,CCVC_Number); fflush(stdout);
								if(cnt>0)
								{
									ITK_CALL(ICS_keylov_get_keylov("-8001",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8001",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										t5NoEcuDup   =(char *) MEM_alloc(20);
										tc_strcpy(t5NoEcuDup,lov_values[i]);

										printf("\n Major Model  COUNT IS  =%s",t5NoEcuDup); fflush(stdout);

										} 
										}
										/********** END OF CODE ***********/

									ITK_CALL(ICS_keylov_get_keylov("-8123",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8123",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Transaxletype   =(char *) MEM_alloc(20);
										tc_strcpy(Transaxletype,lov_values[i]);

										printf("\n Transaxletype IS  =%s",Transaxletype); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/

								      ITK_CALL(ICS_keylov_get_keylov("-8223",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8223",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Speedometerratio   =(char *) MEM_alloc(20);
										tc_strcpy(Speedometerratio,lov_values[i]);

										printf("\n Speedometerratio IS  =%s",Speedometerratio); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/


								 ITK_CALL(ICS_keylov_get_keylov("-8036",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8036",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Emsn_Norms   =(char *) MEM_alloc(20);
										tc_strcpy(Emsn_Norms,lov_values[i]);

										printf("\n Emission Norms are  =%s",Emsn_Norms); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/

									   ITK_CALL(ICS_keylov_get_keylov("-8037",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8037",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Fuel_Type   =(char *) MEM_alloc(20);
										tc_strcpy(Fuel_Type,lov_values[i]);

										printf("\nFuel_Type is  =%s",Fuel_Type); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/


								     ITK_CALL(ICS_keylov_get_keylov("-8069",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8069",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Safety_fetures   =(char *) MEM_alloc(20);
										tc_strcpy(Safety_fetures,lov_values[i]);

										printf("\n Safety_fetures are  =%s",Safety_fetures); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/

									  ITK_CALL(ICS_keylov_get_keylov("-8200",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8200",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Transmission_Type   =(char *) MEM_alloc(20);
										tc_strcpy(Transmission_Type,lov_values[i]);

										printf("\n Transmission Typee  =%s",Transmission_Type); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/

								        ITK_CALL(ICS_keylov_get_keylov("-8124",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8124",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Transaxle_Ratio  =(char *) MEM_alloc(20);
										tc_strcpy(Transaxle_Ratio,lov_values[i]);

										printf("\n Transaxle_Ratio is  =%s",Transaxle_Ratio); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/

								    ITK_CALL(ICS_keylov_get_keylov("-8012",&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										//CALLAPI(ICS_keylov_get_keylov(key_lov_id,&key_lov_name,&options,&n_lov_entries,&lov_keys,&lov_values,&deprecated_staus,&owning_site,&n_shared_sites,&shared_sites));
										printf("\n key_lov_name=%s n_lov_entries=%d options=%d",key_lov_name,n_lov_entries,options); fflush(stdout);
										for(i=0;i<n_lov_entries;i++) 
										{
										 //printf("\n lov_keys=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										   (ICS_ask_classification_object(ccvMstrTag,&Design_rev_cls_tag));

										// ITK_CALL( ICS_ask_attribute_value (Design_rev_cls_tag,"[VC]MAJORMODEL",&attributeValue));
										   (ICS_ask_attribute_value (Design_rev_cls_tag,"8012",&attributeValue));

										//printf("\n attributeValue: %s ",attributeValue); fflush(stdout);

										if(tc_strcmp(attributeValue,lov_keys[i])==0)
										{
										printf("\n Value of classified object: \n Major Model=%s lov_values=%s",lov_keys[i],lov_values[i]); fflush(stdout);

										Steering_Type  =(char *) MEM_alloc(20);
										tc_strcpy(Steering_Type,lov_values[i]);

										printf("\n Steering_Type is  =%s",Steering_Type); fflush(stdout);

										} 
										}
				
										/********** END OF CODE ***********/


									
        								fprintf(fp4,"\t\t\t\t<vehicle_code>");
										fprintf(fp4,CCVC_Number);
										fprintf(fp4,"</vehicle_code>\n");
										fprintf(fp4,"\t\t\t\t<description>");
										fprintf(fp4,SVRDescription);
										fprintf(fp4,"</description>\n");
										fprintf(fp4,"\t\t\t\t<Drive>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Drive>\n");
										fprintf(fp4,"\t\t\t\t<CombMonitor>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</CombMonitor>\n");
										fprintf(fp4,"\t\t\t\t<RearSeatBelt>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</RearSeatBelt>\n");
										fprintf(fp4,"\t\t\t\t<AcType>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</AcType>\n");
										fprintf(fp4,"\t\t\t\t<Tyre>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Tyre>\n");
										fprintf(fp4,"\t\t\t\t<BrakingSystem>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</BrakingSystem>\n");
										fprintf(fp4,"\t\t\t\t<AirbagType>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</AirbagType>\n");
										fprintf(fp4,"\t\t\t\t<Market>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Market>\n");
										fprintf(fp4,"\t\t\t\t<Destination>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Destination>\n");
										fprintf(fp4,"\t\t\t\t<ProductFamily>");
										fprintf(fp4,t5NoEcuDup);
										fprintf(fp4,"</ProductFamily>\n");
										fprintf(fp4,"\t\t\t\t<InteriorColor>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</InteriorColor>\n");
										fprintf(fp4,"\t\t\t\t<Encap>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Encap>\n");
										fprintf(fp4,"\t\t\t\t<GVW>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</GVW>\n");
										fprintf(fp4,"\t\t\t\t<FAW>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</FAW>\n");
										fprintf(fp4,"\t\t\t\t<RAW>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</RAW>\n");
										fprintf(fp4,"\t\t\t\t<GCM>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</GCM>\n");
										fprintf(fp4,"\t\t\t\t<TARE>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</TARE>\n");
										fprintf(fp4,"\t\t\t\t<PD>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</PD>\n");
										fprintf(fp4,"\t\t\t\t<Chassis>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Chassis>\n");
										fprintf(fp4,"\t\t\t\t<HomologationNo>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</HomologationNo>\n");
										fprintf(fp4,"\t\t\t\t<EngineCode>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</EngineCode>\n");
										fprintf(fp4,"\t\t\t\t<EngDesc>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</EngDesc>\n");
										fprintf(fp4,"\t\t\t\t<EngineCC>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</EngineCC>\n");
										fprintf(fp4,"\t\t\t\t<BarrelCode>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</BarrelCode>\n");
										fprintf(fp4,"\t\t\t\t<TACode>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</TACode>\n");
										fprintf(fp4,"\t\t\t\t<TADesc>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</TADesc>\n");
										fprintf(fp4,"\t\t\t\t<TAModel>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</TAModel>\n");
										fprintf(fp4,"\t\t\t\t<ControlType>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</ControlType>\n");
										fprintf(fp4,"\t\t\t\t<GearKit>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</GearKit>\n");
										fprintf(fp4,"\t\t\t\t<First_Ratio>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</First_Ratio>\n");				
										fprintf(fp4,"\t\t\t\t<fuel>");
										fprintf(fp4,Fuel_Type);
										fprintf(fp4,"</fuel>\n");
										fprintf(fp4,"\t\t\t\t<ems_norms>");
										fprintf(fp4,Emsn_Norms);
										fprintf(fp4,"</ems_norms>\n");
										fprintf(fp4,"\t\t\t\t<steer_type>");
										fprintf(fp4,Steering_Type);
										fprintf(fp4,"</steer_type>\n");
										//fprintf(fp4,"\t\t\t\t<product_family>");
										//fprintf(fp4,AttVal4);
										//fprintf(fp4,"</product_family>\n");
										fprintf(fp4,"\t\t\t\t<final_ratio>");
										fprintf(fp4,Transaxle_Ratio);
										fprintf(fp4,"</final_ratio>\n");
										fprintf(fp4,"\t\t\t\t<ta_type>");
										fprintf(fp4,Transaxletype);
										fprintf(fp4,"</ta_type>\n");
										fprintf(fp4,"\t\t\t\t<Transmission>");
										fprintf(fp4,Transmission_Type);
										fprintf(fp4,"</Transmission>\n");
										fprintf(fp4,"\t\t\t\t<Speedometer_Ratio>");
										fprintf(fp4,Speedometerratio);
										fprintf(fp4,"</Speedometer_Ratio>\n");
										fprintf(fp4,"\t\t\t\t<Safety_Features>");
										fprintf(fp4,Safety_fetures);
										fprintf(fp4,"</Safety_Features>\n");
										fprintf(fp4,"\t\t\t\t<ColorName>");
										//fprintf(fp4,VCColourIDDupS);
										fprintf(fp4,"</ColorName>\n");
										fprintf(fp4,"\t\t\t\t<Spare1>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Spare1>\n");
										fprintf(fp4,"\t\t\t\t<Spare2>");
										fprintf(fp4,"Null");
										fprintf(fp4,"</Spare2>\n");

									
                           printf("\n\n\t\t Revisions are matching hence updating the CS %s\n",AttrVal);fflush(stdout);
									//decision = EPM_go;
									//return EPM_go;
								}
							
							

							}
						}

						  fprintf(fp4,"\t</AttributeMaster>\n");
                         fprintf(fp4,"</PROTOCOL>\n");
						}

					}					
					}

				}




			    printf("I am at the end of programme --->\n");
				//fprintf(fp2, " %s , %s  \n",item_id, current_name );

			}


}
extern int ITK_user_main (int argc, char ** argv )
{

    int status;

	char*  	DMLName=NULL;
	char*     AQEngineer=NULL;
	char*     AQGroupLeader=NULL;
	char*     ActionByAgency=NULL;
	char*     ActionTobeTaken=NULL;
	char*     ClosureComments=NULL;
	char*     Customer=NULL;
	char*     DateOfIntroInVC2=NULL;
	char*     DateOfIntroInVC3=NULL;
	char*     DateOfIntroInVC4=NULL;
	char*     DateOfIntroInVCE2=NULL;
	char*     DateOfIntroInVCE3=NULL;
	char*     EmailAdd=NULL;
	char*     EpaMeetinDate=NULL;
	char*    EpaPlantA=NULL;
	char*    InterchangeCodes=NULL;
	char*    MEPA_NO=NULL;
	char*    MbpaCreDate=NULL;
	char*    MbpaCretor=NULL;
	char*    MepaCreDate=NULL;
	char*    MepaCretor=NULL;
	char*    PlanningStatus=NULL;
	char*    WbsPriority=NULL;
	char*    t5AggreCutOffNo=NULL;
	char*    t5AggreCutOffNo1=NULL;
	char*    t5AppModelList=NULL;
	char**   t5AppModelListArry=NULL;
	char**   t5ModelListArry=NULL;
	char*    t5BomComu=NULL;
	char*    t5BreakPointDate=NULL;
	char*    t5BtchCode=NULL;
	char*    t5CTChange=NULL;
	char*    t5Category_code1=NULL;
	char**   t5Category_code1Arry=NULL;
	char*    t5Category_code2=NULL;
	char*    t5Category_code3=NULL;
	char*    t5Category_code4=NULL;
	char**   t5Category_code4Arry=NULL;
	char*    t5Category_code5=NULL;
	char*    t5Category_code6=NULL;
	char*    t5ChasisNo=NULL;
	char*    t5ChasisNo2=NULL;
	char*    t5ChasisNo3=NULL;
	char*    t5ChasisNo4=NULL;
	char*    t5ChasisNoE=NULL;
	char*    t5ChasisNoE2=NULL;
	char*    t5ChasisNoE3=NULL;
	char*    t5ChasisNoE4=NULL;
	char*    t5ChasisTypeList=NULL;
	char**    t5ChasisTypeListArry=NULL;
	char*    t5CommnMepaStr=NULL;
	char*    t5CostReduction=NULL;
	char*    t5DesignGroup=NULL;
	char*    t5DisposalAction1=NULL;
	char*    t5DisposalAction2=NULL;
	char*    t5DisposalAction3=NULL;
	char*    t5DisposalAction4=NULL;
	char*    t5DisposalAction5=NULL;
	char*    t5DumCompln=NULL;
	char*    t5DumEpNo=NULL;
	char*    t5ECNTstRepNo=NULL;
	char*    t5EPACategory_code1=NULL;
	char*    t5EPAClosureDate=NULL;
	char*     t5EpaClass=NULL;
	char*     t5EpaClassDate=NULL;
	char*     t5EpaFolUpInd=NULL;
	char*     t5EpaSet=NULL;
	char*     t5EpaStatus=NULL;
	char*     t5EpaTskCrDate=NULL;
	char*     t5EpaType=NULL;
	char**    t5EpaTypeArry=NULL;
	char*     t5EpaValidity=NULL;
	char*     t5FialReq=NULL;
	char*     t5Introduction_type=NULL;
	char*     t5IsActionReqbySer=NULL;
	char*     t5IsDumEp=NULL;
	char*     t5IsSubAggReq=NULL;
	char*     t5IsToolReq=NULL;
	char*     t5IsTryOutReq=NULL;
	char*     t5LogisticsRemarks=NULL;
	char*     t5LstPODate=NULL;
	char*     t5LstSmplDate=NULL;
	char*     t5MBPARemarks=NULL;
	char*     t5MEPAQADate=NULL;
	char*     t5MailAlert=NULL;
	char*     t5MbpaDesc=NULL;
	char*     t5MbpaNo=NULL;
	char*     t5MepaReason=NULL;
	char*     t5ModOfIntrod=NULL;
	char*     t5ModelList=NULL;
	char*     t5POCheckStatus=NULL;
	char*     t5POLockDate=NULL;
	char*     t5PPMRemarks=NULL;
	char*     t5PartYesNo=NULL;
	char*     t5PartialReason=NULL;
	char*     t5QACRemarks=NULL;
	char*     t5ReadinessDate=NULL;
	char*     t5ReleaseNotes=NULL;
	char*     t5RemarkAppModel=NULL;
	char*     t5RemarksBP=NULL;
	char*     t5RemarksEPAClosure=NULL;
	char*     t5RemarksMEPAQA=NULL;
	char*     t5RemarksPOLock=NULL;
	char*     t5RemarksReadiness=NULL;
	char*     t5RemarksStocks=NULL;
	char*     t5RemarksTryout=NULL;
	char*     t5RevRemarks=NULL;
	char*     t5RjVECNo=NULL;
	char*     t5RygSts=NULL;
	char*     t5SORSendDate=NULL;
	char*     t5ServAction=NULL;
	char*     t5ServActionAgg=NULL;
	char*     t5StocksSCMDate=NULL;
	char*     t5TSRemarks=NULL;
	char*     t5TargetDtIntro=NULL;
	char*     t5TargetDtIntroHis=NULL;
	char*     t5TmpEcnNo=NULL;
	char*     t5TrgtDtIntRem=NULL;
	char*     t5TryoutDate=NULL;
	char*     t5VDRemarks=NULL;
	char*     t5VQARemarks=NULL;
	char*     t5tcfAggregate=NULL;
	char*     t5tcfAggregate1=NULL;
	char**     t5tcfAggregateArry=NULL;
	char*     tentativeDateLogistic=NULL;
	char*     tentativeDateSCM=NULL;
	char*     tx0Addressee=NULL;
	char*     tx0DateReceived=NULL;
	char*     ERCRelDate=NULL;
	char*     inputfile=NULL;
	char*     Outputfile=NULL;
	char*       inputline=NULL;
    char *part_type			= NULL;
    char *part_typeDup			= NULL;
    char *PartTypeToPrintS			= NULL;
    char *assy_noDup			= NULL;
    char *PrtRev			= NULL;
	char *PrtRevDup=NULL;
    char *PrtSeqDup=NULL;

	tag_t item=NULLTAG;
	tag_t *item_rev=NULLTAG;
	char* item_id=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;

	char* MES_ItemcategryDup=NULL;
	char* MES_Itemcategry=NULL;
	char* MES_PlantDup=NULL;
	char* MES_Plant=NULL;
	char* MES_ShopDup=NULL;
	char* MES_Shop=NULL;
	char* MES_LineDup=NULL;
	char* MES_Line=NULL;
	char* MES_StationDup=NULL;
	char* MES_Station=NULL;
	char* CarMakebuyDup=NULL;
	char* CarMakebuy=NULL;
	char* CarMakebuyDup1=NULL;
	char* Task_id=NULL;
	tag_t tag_query;
	char *entries[2] = {"ID","Revision"};
	//char **values =	(char **) MEM_alloc(10 * sizeof(char *));
  	int          n_tags_found= 0;
	int	count=0;
	int	j,ik,count2=0;
	int          max_char_size = 80;

	char*	 current_name		= NULL;
	char * 	t5IsStructEPA=NULL;
	char *    EpaPlantAc = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    InterchangeCodesC = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    WbsPriorityC = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *    t5MailAlertC = (char *)MEM_alloc(max_char_size * sizeof(char));
	tag_t*   tags_found = NULL;
	tag_t*   EpaTag = NULL;
	tag_t*   EpaTagRev = NULL;
	tag_t	relation_type = NULLTAG;
	tag_t*			PartDmlTags			= NULLTAG;
	tag_t objTypeRefTag              =    NULLTAG;
	 tag_t *DMLRevision = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t DMLRevTag = NULLTAG;
	 tag_t			PartDmlTag				= NULLTAG;

	// tag_t		relation_type		= NULLTAG;
	 tag_t *TaskRevision		= NULLTAG;
	 tag_t		*PartTags			= NULLTAG;
	 tag_t		*outTag				= NULLTAG;
	 tag_t		TaskRevTag			= NULLTAG;
	 tag_t	DMLTag			=	NULLTAG;
	 tag_t		LatestRev			= NULLTAG;
	 tag_t	item_rev_tag			= NULLTAG;


	 void ***report;

	char			*ClosureRName							= NULL;
	char			*RevisionRName							= NULL;
	char            *DriverVCLCS                            =NULL ;
	char			*ClosureRNamePrdItm						= NULL;
	char			*RevisionRNamePrdItm					= NULL;
	char			*ViewBVRPrdItm							= NULL;
	char            *DriverVC = NULL;
	char			*ViewBVR		= NULL;
	
	char	*AplDMLNum		=	NULL;
	char	*AplDMLNumeDup		=	NULL;
	char	*Proj_CodeDup		=	NULL;
	char	*Proj_Code		=	NULL;
	char	*rel_type		=	NULL;
	char	*dml_id		=	NULL;
	char*     file_asm=NULL;
	char*     file_asm2=NULL;
	char* date_dup=NULL;
	char* sysdate=NULL;
	char* start_date_dup=NULL;
	char* start_date="26-Jul-2020 00:00";
	char* End_date="28-Jul-2020 00:00";
	char* date1=NULL;
	char* date2=NULL;
	char* date3=NULL;
	char* Task_id2=NULL;
	char 		*FromDt1			=	NULLTAG;
	char 		*ToDt1				=	NULLTAG;
	char cNextDate[20]={0};
	char cTodayDate[20]={0};
	const char * select_attrs[]={"puid"};
	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	date_t		FromDt_t;
	date_t		ToDt_t;
	date_t		vals[2];
	int  rows = 0, columns,TaskCnt,pcount = 0;
	int		iDMLCnt=0,tcount=0,resultCount	=	0;
	int n_entries = 1;
	int StructChldCnt=0;
    tag_t		queryTag			= NULLTAG;

	char type_name[TCTYPE_name_size_c+1]; 
	char PartClass_name[TCTYPE_name_size_c+1]; 
    tag_t objTypeTag = NULLTAG; 
    tag_t objTypeTagP = NULLTAG; 

	 logical is_latest;
	
	char			type_name_ref[TCTYPE_name_size_c+1];
	FILE*      fp=NULL;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

		ViewBVR=(char *) MEM_alloc(200 * sizeof(char *));
	   struct	BomChldStrut	ChldStrutAPL[5000];
			ClosureRName=(char *) MEM_alloc(200 * sizeof(char *));
			RevisionRName=(char *) MEM_alloc(200 * sizeof(char *));
			ViewBVR=(char *) MEM_alloc(200 * sizeof(char *));
			ClosureRNamePrdItm=(char *) MEM_alloc(200 * sizeof(char *));
			RevisionRNamePrdItm=(char *) MEM_alloc(200 * sizeof(char *));
			ViewBVRPrdItm=(char *) MEM_alloc(200 * sizeof(char *));
			char **values2 =	(char **) MEM_alloc(10 * sizeof(char *));
			PartTypeToPrintS=(char *) MEM_alloc(40 * sizeof(char));
            //inputline=(char *) MEM_alloc(5000);


	inputfile = ITK_ask_cli_argument("-i=");
	Outputfile = ITK_ask_cli_argument("-o=");



 
	ITK_CALL(ITK_auto_login( ));  

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_set_journalling( TRUE ));

getPrevDate(cNextDate);
getCurrentDateTime(cTodayDate);
//start_date='26-Sep-2019 00:00';


	printf("\ncTodayDate%s, cNextDate:%s",cTodayDate,date3);
//	printf("\nSysdte is %s",sysdate);fflush(stdout);
//	printf("\nstart_date is %s",start_date);fflush(stdout);

	ITK_string_to_date(start_date,&FromDt_t);
	//ITK_string_to_date(cNextDate,&FromDt_t);
	//ITK_string_to_date(cTodayDate,&ToDt_t);
	ITK_string_to_date(End_date,&ToDt_t);

	vals[0]=FromDt_t;
	vals[1]=ToDt_t;
	
	
	/** Creating a POM Query **/
	ITK_CALL(POM_enquiry_create("find_Dml_Number"));
	printf("***** POM_enquiry_create Query created *********\n");fflush(stdout);

	/** Adding select attribute to Query **/

	ITK_CALL(POM_enquiry_add_select_attrs ("find_Dml_Number","T5_APLDMLRevision",1,select_attrs));

	printf("***** POM_enquiry_add_select_attrs created *********\n");fflush(stdout);

	/**Setting Released Date **/
	ITK_CALL(POM_enquiry_set_date_value ("find_Dml_Number","expr_dates", 2 ,(const date_t*)vals,POM_enquiry_bind_value));

	/** creating between Expression **/

	ITK_CALL(POM_enquiry_set_attr_expr ("find_Dml_Number","expr_dates_between","T5_APLDMLRevision","t5_APLReleaseDate",POM_enquiry_between,"expr_dates"));

	/**Setting the Where Expression **/

	printf("******Before Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);

	ITK_CALL(POM_enquiry_set_where_expr ("find_Dml_Number","expr_dates_between"));

	printf("******After  Executing POM_enquiry_set_where_expr *********\n");fflush(stdout);

	printf("******Before Executing POM_enquiry_execute *********\n");fflush(stdout);
	POM_enquiry_add_order_attr ("find_Dml_Number", "POM_application_object", "t5_APLReleaseDate", POM_enquiry_asc_order);
	ITK_CALL(POM_enquiry_execute("find_Dml_Number", &rows, &columns, &report));
	
	printf("******After Executing POM_enquiry_execute *********\n");fflush(stdout);
	ITK_CALL(POM_enquiry_delete("find_Dml_Number"));
	
	printf(" \n number of rows %d and coloumn %d\n",rows,columns);fflush(stdout);
	file_asm=(char *) MEM_alloc(50);
	file_asm2=(char *) MEM_alloc(50);

	int iDML	=	0;
	int n_attchs =0;
	if (rows > 0)
	{
		for (iDML=0; iDML<rows ;iDML++ )
		{
				AplDMLNum		=	NULL;
				Proj_Code		=	NULL;
				AplDMLNumeDup		=	NULL;
				Proj_CodeDup		=	NULL;
				rel_type		=	NULL;



				tag_t	DMLTag2			=	NULLTAG;

				DMLTag2	=	 *(tag_t*)(report[iDML][0]);

				ITK_CALL(AOM_ask_value_string(DMLTag2,"item_id",&AplDMLNum));
				tc_strdup(AplDMLNum,&AplDMLNumeDup);
				ITK_CALL(AOM_ask_value_string( DMLTag2, "t5_cprojectcode", &Proj_Code));
				tc_strdup(Proj_Code,&Proj_CodeDup);
				printf(" \n  APL DML No is- %s and Project code %s\n",AplDMLNumeDup,Proj_CodeDup);fflush(stdout);

				if(QRY_find("APLDMLRevisionQry", &queryTag));
				if (queryTag)
				{
					printf("\nQuery Found : APLDMLRevisionQry\n");fflush(stdout);
				}
				else
				{
					printf("\n Query NotFound : APLDMLRevisionQry\n");fflush(stdout);
					//goto CLEANUP;
				}
				printf("\nAfter QRY_find : APLDMLRevisionQry\n");fflush(stdout);
				printf("\nInput APL DML : %s\n ", AplDMLNumeDup);fflush(stdout);

				qry_values[0] = AplDMLNumeDup;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));

				printf("\nResultCount :%d:\n", resultCount);fflush(stdout);

				if(resultCount>0)
				{
					DMLTag=outTag[0];


					ITK_CALL(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
					ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name)); 
					printf("\n Inside Break type_name is  %s\n",type_name);fflush(stdout);


					/*Break Down into Task*/
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
					//printf("\n Relation Type : %s",relation_type);fflush(stdout);

					if(relation_type!=NULLTAG)
					{
						printf("\n Inside Break Down to Tasks\n");fflush(stdout);
						if(DMLTag!=NULLTAG)
						{
							printf("\n Inside Break Down to Tasks2\n");fflush(stdout);

							ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&dml_id));
							printf("\n\n\t\t  dml_id  is :%s",dml_id);	fflush(stdout);

							ITK_CALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&tcount,&TaskRevision));

							printf("\n APL DML Revision to Task Count : %d",tcount);fflush(stdout);
							
						}
						else
						{
							printf("\n DML TAG IS NULL ");fflush(stdout);
						}
						printf("\n APL DML Revision to Task Count : %d",tcount);fflush(stdout);
					}
					else
					{
						printf("\n Relation TAG IS NULL ");fflush(stdout);
					}

					
					tc_strcpy(file_asm,"/user/aplstdgrp/Nana/TCUA_MES_Files/");
					//tc_strcat(file_asm,cNextDate);
					tc_strcat(file_asm,"Incremental_MM_");
					tc_strcat(file_asm,AplDMLNum);
					tc_strcat(file_asm,".xml");
					printf("\n File Name is %s\n",file_asm);fflush(stdout);

					fp3= fopen(file_asm,"a+");

					fprintf(fp3,"<?xml version=");
					fprintf(fp3,"\"1.0\"");
					fprintf(fp3," encoding=");
					fprintf(fp3,"\"UTF-8\"");
					fprintf(fp3,"?>");
					fprintf(fp3,"\n<PROTOCOL name=");	
					fprintf(fp3,"\"MATERIAL_MASTER");
					fprintf(fp3,"\" timestamp=\"");
					fprintf(fp3,"1267827515336\" version=\"1.0\">\n"); fflush(fp3);
					fprintf(fp3,"\t<TRANSACTION>\n");
					fprintf(fp3,"\t\t<INSERT>\n");
                       

					 tc_strcpy(file_asm2,"/user/aplstdgrp/Nana/TCUA_MES_Files/");
					//tc_strcat(file_asm,cNextDate);
					tc_strcat(file_asm2,"Incremental_BOM_");
					tc_strcat(file_asm2,AplDMLNum);
					tc_strcat(file_asm2,".xml");
					printf("\n File Name is %s\n",file_asm);fflush(stdout);

					     fp2= fopen(file_asm2,"a+");

						 fprintf(fp2,"<?xml version=");
						 fprintf(fp2,"\"1.0\"");
						 fprintf(fp2," encoding=");
						 fprintf(fp2,"\"UTF-8\"");
						 fprintf(fp2,"?>");
						 fprintf(fp2,"\n<PROTOCOL name=");
						 fprintf(fp2,"\"COMPLETE_BOM_MASTER");
						 fprintf(fp2,"\" timestamp=\"");
						 fprintf(fp2,"1267827515336\" version=\"1.0\">\n"); fflush(fp2);
						 fprintf(fp2,"\t<TRANSACTION>\n");
						 fprintf(fp2,"\t\t<INSERT>\n");


					if (tcount>0)
					{

						for (TaskCnt=0;TaskCnt<tcount ;TaskCnt++ )
						{
							TaskRevTag = TaskRevision[TaskCnt];

							ITK_CALL(TCTYPE_ask_object_type(TaskRevTag,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name)); 
							ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&Task_id2));						
							//printf("\n TaskRevTag %s\n Inside Break type_name is  %s\n",Task_id,type_name);fflush(stdout);


							pcount=0;
							ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
							printf("\nTask To Part Count : %d\n",pcount);fflush(stdout);

							if (pcount>0)
							{
								int Partcount	=	0;
                               for (Partcount=0;Partcount<pcount ;Partcount++ )
								{
							     char ViewBVR[100];
								  LatestRev=PartTags[Partcount];

								  				ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_typeDup));
												ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_id",&assy_noDup));
												ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&PrtRev));
													    PrtRevDup = strtok(PrtRev,";");
				                                        PrtSeqDup = strtok(NULL, ";" );



														ITK_CALL(TCTYPE_ask_object_type(LatestRev,&objTypeTagP));
														ITK_CALL(TCTYPE_ask_name(objTypeTagP,PartClass_name)); 
														printf("\n PartClass_name is  %s\n",PartClass_name);fflush(stdout);

                                                printf("\n Part No%s,%s,%s\n",assy_noDup,PrtRevDup,PrtSeqDup);fflush(stdout);
								  				ITK_CALL(AOM_ask_value_string(LatestRev,"t5_ItmCategory",&MES_Itemcategry));
												if (MES_Itemcategry)
												{
													tc_strdup(MES_Itemcategry,&MES_ItemcategryDup);
												}
												ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_desc",&MES_Plant));
											if (MES_Plant)
												{
													tc_strdup(MES_Plant,&MES_PlantDup);
												}												
											if (tc_strcmp(PartClass_name,"Design Revision")==0)
												{
													ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_MeShop",&MES_Shop));
												}
												else if (tc_strcmp(PartClass_name,"T5_ClrPartRevision")==0)
												{
                                                   ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_MesShop",&MES_Shop));
												}
												
											if (MES_Shop)
												{
													tc_strdup(MES_Shop,&MES_ShopDup);
												}
											   ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_MesLine",&MES_Line));
											if (MES_Line)
												{
													tc_strdup(MES_Line,&MES_LineDup);
												}
												ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_MesStation",&MES_Station));
											if (MES_Station)
												{
													tc_strdup(MES_Station,&MES_StationDup);
												}
												
												
												ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_CarMakeBuyIndicator",&CarMakebuy));
												if (CarMakebuy)
												{
													tc_strdup(CarMakebuy,&CarMakebuyDup);
												}
												 CarMakebuyDup1 = strtok(CarMakebuyDup," ");

													fprintf(fp2,"\t\t\t<PARENT>\n");
													fprintf(fp2,"\t\t\t\t<ASSYPARTNUMBER>");
													fprintf(fp2,assy_noDup);
													fprintf(fp2,"</ASSYPARTNUMBER>\n");
													fprintf(fp2,"\t\t\t\t<ASSYREVISION>");
													fprintf(fp2,PrtRevDup);
													fprintf(fp2,"</ASSYREVISION>\n");
													fprintf(fp2,"\t\t\t\t<ASSYSEQUENCE>");
													fprintf(fp2,PrtSeqDup);
													fprintf(fp2,"</ASSYSEQUENCE>\n");
												if(tc_strcmp(part_typeDup,"CCVC")==0) 	
													{	
													tm_SVRAttributmstr(LatestRev);
													tm_SVRSolveBOM(LatestRev,DMLTag);
													//fprintf(fp2,"\t\t\t</PARENT>\n");
														
													}
												

                                              printf("\n Part Type is %s\n",part_typeDup);fflush(stdout);
											if (tc_strlen(part_typeDup)==0)
												{
												printf("\n Part Type is 1\n");fflush(stdout);
												  strcpy(PartTypeToPrintS,"(Null)");
													
												}else
									                {
													printf("\n Part Type is 2\n");fflush(stdout);
													tc_strdup(part_typeDup,&part_type);
												    }
                                                 printf("\n Part Type is 3\n");fflush(stdout);
												if(tc_strcmp(part_type,"VC")==0) 	
													{					
														strcpy(PartTypeToPrintS,"Vehicle Combination");
													}
													else if(tc_strcmp(part_type,"V")==0) 	
													{
														 
														strcpy(PartTypeToPrintS,"Vehicle");
													}
													else if(tc_strcmp(part_type,"A")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Assembly");
													}
													else if(tc_strcmp(part_type,"C")==0)  
													{
														printf("\n Part Type is comp 4\n");fflush(stdout);
														//PartTypeToPrintS = NULL;
														strcpy(PartTypeToPrintS,"Component");
														printf("\n Part Type is comp 5\n");fflush(stdout);
													}
													else if(tc_strcmp(part_type,"D")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Dummy");
													}
													else if(tc_strcmp(part_type,"G")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Group Id");
													}
													else if(tc_strcmp(part_type,"SA")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Assembly");
													}
													else if(tc_strcmp(part_type,"SP")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Part");
													}
													else if(tc_strcmp(part_type,"IFD")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Information Fittement Drawing");
													}
													else if(tc_strcmp(part_type,"M")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Module");
													}
													else if(tc_strcmp(part_type,"TD")==0) 
													{
														strcpy(PartTypeToPrintS,"Table Drawinig");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}
												   else 
													{
														strcpy(PartTypeToPrintS,"(Null)");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}
									printf("\n Part Type is  6\n");fflush(stdout);

									fprintf(fp3,"\t\t\t<PART>\n"); 
									fprintf(fp3,"\t\t\t\t<PARTTYPE>");
									fprintf(fp3,PartTypeToPrintS);
									fprintf(fp3,"</PARTTYPE>\n");
									fprintf(fp3,"\t\t\t\t<PARTNUMBER>");
									fprintf(fp3,assy_noDup);
									fprintf(fp3,"</PARTNUMBER>\n");
									fprintf(fp3,"\t\t\t\t<REVISION>");
									fprintf(fp3,PrtRev);
									fprintf(fp3,"</REVISION>\n");
									fprintf(fp3,"\t\t\t\t<SEQUENCE>");
									fprintf(fp3,PrtSeqDup);
									fprintf(fp3,"</SEQUENCE>\n");
									fprintf(fp3,"\t\t\t\t<ITEMNAME>");
									fprintf(fp3,"Null");
									fprintf(fp3,"</ITEMNAME>\n");
									fprintf(fp3,"\t\t\t\t<SHOP>");
									if(tc_strlen(MES_ShopDup)==0)
                                 	{
									   fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_ShopDup);
									   
									    }

									fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
                                    if(tc_strlen(MES_LineDup)==0)
									{
									fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_LineDup);
									      
									    }

									fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
                                  if(tc_strlen(MES_StationDup)==0)
                                   	{
									 fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_StationDup);
									     
									    }

								fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<DESCRIPTION>");
							    fprintf(fp3,MES_PlantDup);
							    fprintf(fp3,"</DESCRIPTION>\n");
								fprintf(fp3,"\t\t\t\t<ITEMCATEGORY>");
								 if(tc_strlen(MES_StationDup)>0)
                                   	{
									 fprintf(fp3,MES_StationDup);
									
									}
									else{										
									      fprintf(fp3,"Null");
									    }					

							    fprintf(fp3,"</ITEMCATEGORY>\n");
								fprintf(fp3,"\t\t\t\t<CS>");
							    fprintf(fp3,CarMakebuyDup1);
							    fprintf(fp3,"</CS>\n");
								fprintf(fp3,"\t\t\t\t<UOM>");
							    fprintf(fp3,"4");
							    fprintf(fp3,"</UOM>\n");
								fprintf(fp3,"\t\t\t\t<PLANT>");
							    fprintf(fp3,"1100");
							    fprintf(fp3,"</PLANT>\n");

								fprintf(fp3,"\t\t\t\t<Optional1>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional1>\n");
							    fprintf(fp3,"\t\t\t\t<Optional2>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional2>\n");
								fprintf(fp3,"\t\t\t\t<Optional3>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional3>\n");
								fprintf(fp3,"\t\t\t\t<OBSOLETEFLAG>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</OBSOLETEFLAG>\n");

									fprintf(fp3,"\t\t\t</PART>\n");
									fflush(fp3);
									 printf("\n No of Stations details 4\n"); fflush(stdout);


									 	tc_strcpy(ClosureRName,"BOMViewClosureRuleERC");
										tc_strcpy(RevisionRName,"ERC release and above APLC");
										//tc_strcpy(RevisionRName,"Latest Working");
										tc_strcpy(ViewBVR,"View");

										tc_strcpy(ClosureRNamePrdItm,"BOMViewClosureRuleAPLC");
										tc_strcpy(ViewBVRPrdItm,"APLC View");

										ITKCALL(QRY_find("Driver VC Query",&tag_query));
										printf("Searching...\n");fflush(stdout);

										DriverVCLCS=NULL;
										DriverVCLCS=(char *)MEM_alloc(1000);

								  tc_strcpy(DriverVCLCS,"ERC Released;APL Released;STDSI Working;STDSI Released");

										printf("nArgument passed in is: %s...\n",DriverVC);fflush(stdout);
										printf("nArgument passed in is: %s...\n",DriverVCLCS);fflush(stdout);

									   values2[0]=DriverVC;
									   values2[1]=DriverVCLCS;

								   //  ITKCALL(ITEM_ask_latest_rev(LatestRev,&item_rev_tag));
                      
					  StructChldCnt=0;


					ITKCALL(Get_Part_BOM_Lvl(LatestRev,1,ClosureRNamePrdItm,RevisionRName,ViewBVR,ChldStrutAPL,&StructChldCnt));
				     fprintf(fp2,"\t\t\t</PARENT>\n");
					 printf("\n\t\t No of child at first level are StructChldCnt:%d\n",StructChldCnt);fflush(stdout);
								}
							
							}



						}


					}

  fprintf(fp2,"\t\t</INSERT>\n");
  fprintf(fp2,"\t</TRANSACTION>\n");
  fprintf(fp2,"</PROTOCOL>\n");

  fprintf(fp3,"\t\t</INSERT>\n");
  fprintf(fp3,"\t</TRANSACTION>\n");
  fprintf(fp3,"</PROTOCOL>\n");

				}
			}
	}


	//fp=fopen(inputfile,"r");
	//fp2=fopen(Outputfile,"w");
	/*if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(5000);
		while(fgets(inputline,5000,fp)!=NULL)
		{

			fputs(inputline,stdout);
    		printf("DMLName is --->%s\n",inputline);
			item_id=NULL;
			item_revision_id=NULL;
			//item_sequence_id=NULL;

			item_id=strtok(inputline,","); //2
			item_revision_id=strtok(NULL,","); //3
			//item_sequence_id=strtok(NULL,"^"); //4

			printf("item_id [%s]\n",item_id);fflush(stdout);
			printf("item_revision_id [%s]\n",item_revision_id);fflush(stdout);
			//printf("item_sequence_id [%s]\n",item_sequence_id);fflush(stdout);

			//trimLeading(inputline);
			printf("inputline is --->%s\n",inputline);
			//attrs[0] ="item_id";
			//values[0] = (char *)inputline;
		   values[0]=item_id;
		   values[1]=item_revision_id;

		   ITKCALL(QRY_find("Design Revision",&tag_query));
			printf("Searching...\n");fflush(stdout);

			//Querying with item id
			//ITK_CALL(ITEM_find_items_by_key_attributes(1,entries, values, &n_tags_found, &tags_found));
			 ITKCALL(QRY_execute(tag_query,1, entries, values,&n_tags_found,&tags_found));
			printf("n_tags_found  --->[%d]\n",n_tags_found);
			if(n_tags_found>0)
			{
				item = tags_found[0];
				//ITK_CALL(ITEM_ask_latest_rev(item,&item_rev));
				//ITK_CALL(AOM_ask_value_date(item_rev,"date_released",&ERCRelDate));




					GRM_find_relation_type("CMHasSolutionItem",&relation_type);
					GRM_list_primary_objects_only(item,relation_type,&count,&PartDmlTags);

					printf("\n\n\t\t Part to ERC DML to Task : %d",count);fflush(stdout);
					if(count >0)
					{
				   for (ik=0;ik<count ;ik++ )
				   {
					PartDmlTag=PartDmlTags[ik];//task pointer
					printf("\n\n\t\t INSIDE: ");fflush(stdout);



						ITKCALL(TCTYPE_ask_object_type(PartDmlTag,&objTypeRefTag));//task pointer
						ITKCALL(TCTYPE_ask_name(objTypeRefTag,type_name_ref));
						printf("\nTCDCtype_name_ref isss :%s\n",type_name_ref);fflush(stdout);
			//

						  //if (strcmp(type_name_ref,"A9_APLTaskRevision")==0)
						  if (strcmp(type_name_ref,"T5_APLTaskRevision")==0)
							{
								ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
								if (tsk_dml_rel_type!=NULLTAG)
								 {

									ITKCALL(GRM_list_primary_objects_only(PartDmlTag,tsk_dml_rel_type,&count2,&DMLRevision));
									printf("\n\n\t\t DML Revision from Task : %d",count2);fflush(stdout);		//task to dml

									for (j=0;j<count2 ;j++ )
									{
										ITKCALL(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
										printf("\n\n\t\t is_latest : %d\n",is_latest);fflush(stdout);



											DMLRevTag = DMLRevision[j];//DML
											ITKCALL(AOM_ask_value_string(DMLRevTag,"item_id",&current_name));
											printf("\n\n\t\t dml is :%s\n",current_name);fflush(stdout);

									}

								 }
							}
				   }
					}


			    printf("ERCRelDate is --->%s\n",ERCRelDate);
				fprintf(fp2, " %s , %s  \n",item_id, current_name );

			}
		}
	}*/



	ITK_CALL(POM_logout(false));
	return status;
	//fclose (fp);
	    fclose (fp2);
		fclose (fp3);
	CLEANUP:

	//ITK_CALL(POM_logout(false));
	return status;
}

void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	char * ItemRevName ;
    char*	 Chitem_Revid		= NULL;
	char*	 Chitem_Seqid		= NULL;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;

	
	char* partNumber 	= NULL;
	char	*c_Qty	;


	

	//Outputfile = ITK_ask_cli_argument("-o=");

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);
        // fprintf(fp2,"\t\t\t\t\t<CHILD>\n");


	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			if(t_ChildItemRev!=NULLTAG)
			{

				c_Qty			= NULL;
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
//				AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&ItemRevName);
//                  Chitem_Revid=strtok(ItemRevName,";");
//				  Chitem_Seqid=strtok(NULL,"");       

                    
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;
              //AOM_ask_value_string(t_ChildItemRev,"bl_quantity",&c_Qty);
		                   //printf("\nQty==>%s\n",c_Qty);fflush(stdout);

//							fprintf(fp2,"\t\t\t\t\t\t<PARTNUMBER>");
//							fprintf(fp2,ItemName);
//							fprintf(fp2,"</PARTNUMBER>\n");
//							fprintf(fp2,"\t\t\t\t\t\t<REVISION>");
//							fprintf(fp2,Chitem_Revid);
//							fprintf(fp2,"</REVISION>\n");
//							fprintf(fp2,"\t\t\t\t\t\t<SEQUENCE>");
//							fprintf(fp2,Chitem_Seqid);
//							fprintf(fp2,"</SEQUENCE>\n");
//							fprintf(fp2,"\t\t\t\t\t\t<QUANTITY>");
//							fprintf(fp2,c_Qty);
//							fprintf(fp2,"</QUANTITY>\n");
//							fprintf(fp2,"\t\t\t\t\t\t<GROUPFLAG>");						   
//							fprintf(fp2,"1");						
//							fprintf(fp2,"</GROUPFLAG>\n");
//			//				fprintf(fp,"\t\t\t\t<ITEMNAME>");
//			//				fprintf(fp,"");
//			//				fprintf(fp,"</ITEMNAME>\n");
//							fprintf(fp2,"\t\t\t\t\t</CHILD>\n");

				//Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}

int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;
    PIE_scope_t  scope;
	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			part_type					=NULL;
	char*			ItemRevName					=NULL;
	char*			Chitem_Revid					=NULL;
	char*			Chitem_Seqid					=NULL;
	char*			viewTok					=NULL;
	char *PartTypeToPrintS			= NULL;
	char *part_typeDup			= NULL;

	char* MES_ItemcategryDup=NULL;
	char* MES_Itemcategry=NULL;
	char* MES_PlantDup=NULL;
	char* MES_Plant=NULL;
	char* MES_ShopDup=NULL;
	char* MES_Shop=NULL;
	char* MES_LineDup=NULL;
	char* MES_Line=NULL;
	char* MES_StationDup=NULL;
	char* MES_Station=NULL;
	char* CarMakebuyDup=NULL;
	char* CarMakebuy=NULL;
	char* CarMakebuyDup1=NULL;

	tag_t   t_ChildItemRev;
	char PartClass_name[TCTYPE_name_size_c+1]; 
    tag_t objTypeTagP = NULLTAG; 
	char * ItemName ;
	PartTypeToPrintS=(char *) MEM_alloc(40 * sizeof(char));

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		ItemRevName			= NULL;
		Chitem_Revid			= NULL;
		Chitem_Seqid			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\n Get_Part_BOM_Lvl Qty==>%s\n",c_Qty);fflush(stdout);

	   AOM_ask_value_string(objChild,"item_revision_id",&ItemRevName);
                  Chitem_Revid=strtok(ItemRevName,";");
				  Chitem_Seqid=strtok(NULL,"");  
	 AOM_ask_value_string(objChild,"t5_PartType",&part_typeDup);

				   printf("\nGet_Part_BOM_Lvl PartNumber==>%s\n",ItemName);fflush(stdout);
				  printf("\nGet_Part_BOM_Lvl RevId==>%s\n",Chitem_Revid);fflush(stdout);
				  printf("\nGet_Part_BOM_Lvl SeqId==>%s\n",Chitem_Seqid);fflush(stdout);
				  printf("\n Get_Part_BOM_Lvl Qty==>%s\n",c_Qty);fflush(stdout);

				           fprintf(fp2,"\t\t\t\t\t<CHILD>\n");
				  			fprintf(fp2,"\t\t\t\t\t\t<PARTNUMBER>");
							fprintf(fp2,ItemName);
							fprintf(fp2,"</PARTNUMBER>\n");
							fprintf(fp2,"\t\t\t\t\t\t<REVISION>");
							fprintf(fp2,Chitem_Revid);
							fprintf(fp2,"</REVISION>\n");
							fprintf(fp2,"\t\t\t\t\t\t<SEQUENCE>");
							fprintf(fp2,Chitem_Seqid);
							fprintf(fp2,"</SEQUENCE>\n");
							fprintf(fp2,"\t\t\t\t\t\t<QUANTITY>");
							fprintf(fp2,c_Qty);
							fprintf(fp2,"</QUANTITY>\n");
							fprintf(fp2,"\t\t\t\t\t\t<GROUPFLAG>");						   
							fprintf(fp2,"1");						
							fprintf(fp2,"</GROUPFLAG>\n");
			//				fprintf(fp,"\t\t\t\t<ITEMNAME>");
			//				fprintf(fp,"");
			//				fprintf(fp,"</ITEMNAME>\n");
							fprintf(fp2,"\t\t\t\t\t</CHILD>\n");


													   TCTYPE_ask_object_type(objChild,&objTypeTagP);
													   TCTYPE_ask_name(objTypeTagP,PartClass_name); 
														printf("\n PartClass_name is  %s\n",PartClass_name);fflush(stdout);

										AOM_ask_value_string(objChild,"t5_ItmCategory",&MES_Itemcategry);
												if (MES_Itemcategry)
												{
													tc_strdup(MES_Itemcategry,&MES_ItemcategryDup);
												}
									    AOM_UIF_ask_value(objChild,"object_desc",&MES_Plant);
											if (MES_Plant)
												{
													tc_strdup(MES_Plant,&MES_PlantDup);
												}

											if (tc_strcmp(PartClass_name,"Design Revision")==0)
												{													
													AOM_UIF_ask_value(objChild,"t5_MeShop",&MES_Shop);
												}
												else if (tc_strcmp(PartClass_name,"T5_ClrPartRevision")==0)
												{
													AOM_UIF_ask_value(objChild,"t5_MesShop",&MES_Shop);                                                   
												}
										
											if (MES_Shop)
												{
													tc_strdup(MES_Shop,&MES_ShopDup);
												}
										AOM_UIF_ask_value(objChild,"t5_MesLine",&MES_Line);
											if (MES_Line)
												{
													tc_strdup(MES_Line,&MES_LineDup);
												}
										AOM_UIF_ask_value(objChild,"t5_MesStation",&MES_Station);
											if (MES_Station)
												{
													tc_strdup(MES_Station,&MES_StationDup);
												}
												
												
										AOM_UIF_ask_value(objChild,"t5_CarMakeBuyIndicator",&CarMakebuy);
												if (CarMakebuy)
												{
													tc_strdup(CarMakebuy,&CarMakebuyDup);
												}
												 CarMakebuyDup1 = strtok(CarMakebuyDup," ");


											if (tc_strlen(part_typeDup)==0)
												{
												  strcpy(PartTypeToPrintS,"(Null)");
													
												}else
									                {
													tc_strdup(part_typeDup,&part_type);
												    }


												if(tc_strcmp(part_type,"VC")==0) 	
													{					
														strcpy(PartTypeToPrintS,"Vehicle Combination");
													}
													else if(tc_strcmp(part_type,"V")==0) 	
													{
														 
														strcpy(PartTypeToPrintS,"Vehicle");
													}
													else if(tc_strcmp(part_type,"A")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Assembly");
													}
													else if(tc_strcmp(part_type,"C")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Component");
														
													}
													else if(tc_strcmp(part_type,"D")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Dummy");
													}
													else if(tc_strcmp(part_type,"G")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Group Id");
													}
													else if(tc_strcmp(part_type,"SA")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Assembly");
													}
													else if(tc_strcmp(part_type,"SP")==0)  
													{
														
														strcpy(PartTypeToPrintS,"Stage Part");
													}
													else if(tc_strcmp(part_type,"IFD")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Information Fittement Drawing");
													}
													else if(tc_strcmp(part_type,"M")==0)  
													{
														 
														strcpy(PartTypeToPrintS,"Module");
													}
													else if(tc_strcmp(part_type,"TD")==0) 
													{
														strcpy(PartTypeToPrintS,"Table Drawinig");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}
												   else 
													{
														strcpy(PartTypeToPrintS,"(Null)");
														printf("\n The part doesn't belong to any of these part types\n");fflush(stdout);
													}



									fprintf(fp3,"\t\t\t<PART>\n"); 
									fprintf(fp3,"\t\t\t\t<PARTTYPE>");
									fprintf(fp3,PartTypeToPrintS);
									fprintf(fp3,"</PARTTYPE>\n");
									fprintf(fp3,"\t\t\t\t<PARTNUMBER>");
									fprintf(fp3,ItemName);
									fprintf(fp3,"</PARTNUMBER>\n");
									fprintf(fp3,"\t\t\t\t<REVISION>");
									fprintf(fp3,Chitem_Revid);
									fprintf(fp3,"</REVISION>\n");
									fprintf(fp3,"\t\t\t\t<SEQUENCE>");
									fprintf(fp3,Chitem_Seqid);
									fprintf(fp3,"</SEQUENCE>\n");
									fprintf(fp3,"\t\t\t\t<ITEMNAME>");
									fprintf(fp3,"Null");
									fprintf(fp3,"</ITEMNAME>\n");
									fprintf(fp3,"\t\t\t\t<SHOP>");
									if(tc_strlen(MES_ShopDup)==0)
                                 	{
									   fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_ShopDup);
									   
									    }

									fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
                                    if(tc_strlen(MES_LineDup)==0)
									{
									fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_LineDup);
									      
									    }

									fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
                                  if(tc_strlen(MES_StationDup)==0)
                                   	{
									 fprintf(fp3,"Null");
									}
									else{
										fprintf(fp3,MES_StationDup);
									     
									    }

								fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<SHOP>");                 
								fprintf(fp3,"Null");
							    fprintf(fp3,"</SHOP>\n");
								fprintf(fp3,"\t\t\t\t<ASSY-Line>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</ASSY-Line>\n");
								fprintf(fp3,"\t\t\t\t<STATIONCODE>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</STATIONCODE>\n");
								fprintf(fp3,"\t\t\t\t<DESCRIPTION>");
							    fprintf(fp3,MES_PlantDup);
							    fprintf(fp3,"</DESCRIPTION>\n");
								fprintf(fp3,"\t\t\t\t<ITEMCATEGORY>");
								 if(tc_strlen(MES_StationDup)>0)
                                   	{
									 fprintf(fp3,MES_StationDup);
									
									}
									else{										
									      fprintf(fp3,"Null");
									    }					

							    fprintf(fp3,"</ITEMCATEGORY>\n");
								fprintf(fp3,"\t\t\t\t<CS>");
							    fprintf(fp3,CarMakebuyDup1);
							    fprintf(fp3,"</CS>\n");
								fprintf(fp3,"\t\t\t\t<UOM>");
							    fprintf(fp3,"4");
							    fprintf(fp3,"</UOM>\n");
								fprintf(fp3,"\t\t\t\t<PLANT>");
							    fprintf(fp3,"1100");
							    fprintf(fp3,"</PLANT>\n");

								fprintf(fp3,"\t\t\t\t<Optional1>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional1>\n");
							    fprintf(fp3,"\t\t\t\t<Optional2>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional2>\n");
								fprintf(fp3,"\t\t\t\t<Optional3>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</Optional3>\n");
								fprintf(fp3,"\t\t\t\t<OBSOLETEFLAG>");
							    fprintf(fp3,"Null");
							    fprintf(fp3,"</OBSOLETEFLAG>\n");
									fprintf(fp3,"\t\t\t</PART>\n");




	}
	return ifail;
}