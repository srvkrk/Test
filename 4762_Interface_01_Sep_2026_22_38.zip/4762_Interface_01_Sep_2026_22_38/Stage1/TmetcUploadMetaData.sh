######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author		  : Raghavendra B T
# Created on	  : March 25, 2015
# Project         : Teamcenter 10.1 TMETC
#
#######################################################################################
user=$2
pass=$3
folder=$1

filename=`echo $1 | cut -d\_ -f1`
echo $folder
echo $filename

splitfiles=`ls $filename.TCPartList.txt`

echo $splitfiles

for flist in $splitfiles
do
	echo "Importing file in shell  $flist" >> failure.log
	/home/ukua10/rbb/Daya_Catia/TmetccreateRevforParent -i=$flist -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in TmetccreateRevforParent"
		exit 1
	fi
	wait
	sleep 10
done

splitfiles11=`ls $filename.TCPartList_Child.txt`
for flist1 in $splitfiles11
do
	echo "Importing file in shell  $flist1" >> failure.log
	/home/ukua10/rbb/Daya_Catia/TmetccreateRevforParent -i=$flist1 -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in createRevforChild"
		exit 1
	fi
	wait
	sleep 10
done

echo "check error.log"
ls -lrt  error.log
errorcnt=`cat error.log | wc -l`
if [ $errorcnt -eq 0 ];then

	echo "Creating structure.........122............"
	partfile=${filename}_parts.txt

	echo "#DELIMITER ^" > $partfile
	echo "#COL   Level  item  rev Seq desc occs Name Uom Qty LhRh" >> $partfile

	while read line
	do


		echo $line
		level=`echo $line |awk -F'^' '{print $1}'`
		item=`echo $line |awk -F'^' '{print $2}'`
		rev=`echo $line |awk -F'^' '{print $3}'`
		seq=`echo $line |awk -F'^' '{print $4}'`
		desc=`echo $line |awk -F'^' '{print $5}'`
		qty=`echo $line |awk -F'^' '{print $6}'`
                LhRh=`echo $line |awk -F'^' '{print $9}'`

		name=$item
		unitofmes="-"
               
	        Rh="LH CATIA"
		Lh="RH CATIA"
		Rp="LH PROE"
		Lp="RH PROE"

		echo "qty is:" $qty
		echo "LhRh is:" $LhRh
                 
		if [ $qty = 0 ]
		then
				quantity=0
				echo "i am testing 0"
		else
				quantity=$qty
				echo "i am testing 1"
		fi


                 if [ "$LhRh" == "$Rh" ]
                 then
      		        level=$((level+1))
         		echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$LhRh" >>  $partfile

		 elif  [ "$LhRh" == "$Lh" ]
                 then
      		        level=$((level+1))
         		echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$LhRh" >>  $partfile
                  
		  elif  [ "$LhRh" == "$Rp" ]
                  then
      		        level=$((level+1))
         		echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$LhRh" >>  $partfile

		  elif  [ "$LhRh" == "$Lp" ]
                  then
      		        level=$((level+1))
         		echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$LhRh" >>  $partfile

		  else
			echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$LhRh" >>  $partfile
		  fi


	done < "$filename.txt"

	/home/ukua10/rbb/Daya_Catia/TmetcloadParts -i=$partfile -o=on -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in TmetcloadParts"
		exit 1
	fi

	if [ $? -eq 0 ];then
		echo "strcuture created success:TmetcloadParts" >> failure.log
		wait
		sleep 10
		#/home/trlxcmi/TCUA/AttachSpecFiles -i=$filename.txt.all.spec -u=$user -p=$pass
		if [ $? -eq 0 ];then
			echo "Spec file added properly" >> failure.log
		else
			echo "Some issue in adding spec file" >> error.log
		fi
		wait
		sleep 10
	else
		echo "Some issue in structure creation:TmetcloadParts" >> error.log
	fi


else

	echo "Error while loading.... Please check error file"

fi

RefJTfile=${filename}_to_load_RefJT.txt
RefJTfile_Load=${filename}_to_load_RefJT_ready.txt
RefCADfile=${filename}_to_load_RefCAD.txt
RefCADfile_Load=${filename}_to_load_RefCAD_ready.txt
CADfile=${filename}_to_load_CAD.txt
JTfile=${filename}_to_load_JT.txt
JTfile_Load=${filename}_to_load_JT_ready.txt
CADfile_Load=${filename}_to_load_CAD_ready.txt

echo "\nGoing to Upload Physical Ref data(CATIA/JT/PDF) -->$RefCADfile\n"
echo "\nGoing to Upload Physical data(CATIA/JT/PDF) -->$CADfile\n"
echo "\nGoing to open catia load list -->${filename}_UniCAD.txt\n"


	while read liner
	do


		PartNumber=`echo $liner |awk -F'^' '{print $1}'`
		Rev=`echo $liner |awk -F'^' '{print $2}'`
		Seq=`echo $liner |awk -F'^' '{print $3}'`
		CADName=`echo $liner |awk -F'^' '{print $4}'`
		RelPath=`echo $liner |awk -F'^' '{print $5}'`
		OwnerDir=`echo $liner |awk -F'^' '{print $6}'`
		FullPath=`echo $liner |awk -F'^' '{print $7}'`
		DSeq=`echo $liner |awk -F'^' '{print $8}'`
		DRef=`echo $liner |awk -F'^' '{print $9}'`


		path_2=/home/ukua10/rbb/Daya_Catia/${folder}


			if [ "${OwnerDir}" = "Rel_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/Release/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "Rel_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/Release/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "CE_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/CE/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "WIP_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/WIP/${RelPath}"
				echo " New Path is $NewPath_1"
			fi


	echo "$PartNumber^$Rev^$Seq^$CADName^$NewPath_1^$DSeq^$DRef" >>  $RefCADfile

	done < "${filename}_RefUniCAD.txt"



	while read line1
	do


		PartNumber=`echo $line1 |awk -F'^' '{print $1}'`
		Rev=`echo $line1 |awk -F'^' '{print $2}'`
		Seq=`echo $line1 |awk -F'^' '{print $3}'`
		CADName=`echo $line1 |awk -F'^' '{print $4}'`
		RelPath=`echo $line1 |awk -F'^' '{print $5}'`
		OwnerDir=`echo $line1 |awk -F'^' '{print $6}'`
		FullPath=`echo $line1 |awk -F'^' '{print $7}'`
		DSeq=`echo $line1 |awk -F'^' '{print $8}'`


		path_2=/home/ukua10/rbb/Daya_Catia/${folder}


			if [ "${OwnerDir}" = "Rel_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/Release/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "Rel_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/Release/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "CE_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/CE/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "WIP_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/WIP/${RelPath}"
				echo " New Path is $NewPath_1"
			fi


	echo "$PartNumber^$Rev^$Seq^$CADName^$NewPath_1^$DSeq" >>  $CADfile

	done < "${filename}_UniCAD.txt"


	while read $linejt
	do


		PartNumber=`echo $linejt |awk -F'^' '{print $1}'`
		Rev=`echo $linejt |awk -F'^' '{print $2}'`
		Seq=`echo $linejt |awk -F'^' '{print $3}'`
		CADName=`echo $linejt |awk -F'^' '{print $4}'`
		RelPath=`echo $linejt |awk -F'^' '{print $5}'`
		OwnerDir=`echo $linejt |awk -F'^' '{print $6}'`
		FullPath=`echo $linejt |awk -F'^' '{print $7}'`
		DSeq=`echo $linejt |awk -F'^' '{print $8}'`
                DRef=`echo $liner |awk -F'^' '{print $9}'`

		path_2=/home/ukua10/rbb/Daya_Catia/${folder}


			if [ "${OwnerDir}" = "JT_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/JT/${RelPath}"
				echo " New Path is $NewPath_1"
			fi

			if [ "${OwnerDir}" = "Rel_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/JT_REL/${RelPath}"
				echo " New Path is $NewPath_1"
			fi



	echo "$PartNumber^$Rev^$Seq^$CADName^$NewPath_1^$DSeq^$DRef" >>  $RefJTfile

	done < "${filename}_RefUniJT.txt"


	while read line2
	do


		PartNumber=`echo $line2 |awk -F'^' '{print $1}'`
		Rev=`echo $line2 |awk -F'^' '{print $2}'`
		Seq=`echo $line2 |awk -F'^' '{print $3}'`
		CADName=`echo $line2 |awk -F'^' '{print $4}'`
		RelPath=`echo $line2 |awk -F'^' '{print $5}'`
		OwnerDir=`echo $line2 |awk -F'^' '{print $6}'`
		FullPath=`echo $line2 |awk -F'^' '{print $7}'`
		DSeq=`echo $line2 |awk -F'^' '{print $8}'`
     
                echo "RelPath ....$RelPath"
                echo "OwnerDir ....$OwnerDir"
		
		path_2=/home/ukua10/rbb/Daya_Catia/${folder}


			if [ "${OwnerDir}" = "JT_CAD_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/JT/${RelPath}"
				echo " New Path is $NewPath_1"
			elif  [ "${OwnerDir}" = "Rel_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/JT_REL/${RelPath}"
				echo " New Path is $NewPath_1"        	        
			elif  [ "${OwnerDir}" = "WIP_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/WIP/${RelPath}"
				echo " New Path is $NewPath_1"
			
			elif  [ "${OwnerDir}" = "CE_Vault_Loc" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/CE/${RelPath}"
				echo " New Path is $NewPath_1"
		       
			elif  [ "${OwnerDir}" = "Rel_Vault_Loc_Pdf" ]; then

				name=`basename "$FullPath"`
				NewPath_1="${path_2}/Release/${RelPath}"
				echo " New Path is $NewPath_1"
			 fi
			
		   
                echo "RelPath after....$RelPath"

	echo "$PartNumber^$Rev^$Seq^$CADName^$NewPath_1^$DSeq" >>  $JTfile

	done < "${filename}_UniJT.txt"

sort  $JTfile | uniq > $JTfile_Load
sort  $RefJTfile | uniq > $RefJTfile_Load
sort  $CADfile | uniq > $CADfile_Load
sort  $RefCADfile | uniq > $RefCADfile_Load

sleep 5

while read kline
do
	echo "Loading JT/PDF Files in to TCUA"
	/home/ukua10/rbb/Daya_Catia/TmetcDataSetLoad -i=$kline -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in TmetcDataSetLoad"
		exit 1
	fi

done < "$JTfile_Load"

while read rline
do
	echo "Loading Ref CAD Files in to TCUA"
	/home/ukua10/rbb/Daya_Catia/TmetcDataSetLoad -i=$rline -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in TmetcDataSetLoad"
		exit 1
	fi

done < "$RefCADfile_Load"


while read mline
do
	echo "Loading CAD Files in to TCUA"
	/home/ukua10/rbb/Daya_Catia/TmetcDataSetLoad -i=$mline -u=$user -p=$pass
	if [ $? != 0 ]
	then
		echo "Problem in TmetcDataSetLoad"
		exit 1
	fi

done < "$CADfile_Load"



