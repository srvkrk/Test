/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File		 :   ContextBOMViewTCPartMultiExplosion.c (old: ExpandAssyWithCxt.c)
*  Author	 :   Aniket P. Kadu
*  Module        :   TCUA Downloader.
*  Purpose       :   To Download Bom Parts.
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <ReadFile.h>
#include <tel.h>
#include <Mtimsgh.h>
#define NUMBER 5000

//char*  get_date(char datein[11]);

/* Recursive function used in t5GetMultiLevelExplosion */
status t5GetExplosion_new
	(
		ObjectPtr		partObj,
		integer			reqLevel,
		ObjectPtr       contextObj,
		SetOfObjects	*childObjs,
		SetOfObjects	*childRelObjs,
		SetOfStrings	*levels,
		SetOfStrings	*type,
		integer*		level,
		integer*		mfail
	)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5GetExplosion_new";
	SetOfObjects    itemObjs    = NULL;
	SetOfObjects    relObjs     = NULL;
	SetOfObjects    itemObjSet  = NULL;
   	ObjectPtr		relObj		= NULL;
   	ObjectPtr		itemObj		= NULL;
	ObjectPtr       qryDef     = NULL;
   	integer			cnt			= 0;
	string			integerStr  = NULL;
	string			tempStr  = NULL;
	NVSET		textInserts	= NULL;
   					*mfail 		= USC_OKAY;

	if( *level >= reqLevel )
		   return (dstat);

	 if (dstat = ExpandRelationWithCtxt("AsRevRev", partObj, "PartsInAssembly", contextObj, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail))
		goto CLEANUP;
	printf("\ncalling ExpSetForUses\n");fflush(stdout);

	 if (*mfail)
		goto CLEANUP;

	if(*type == NULL)
	{
			*type = setCreate(1);
	}
	if(setSize(itemObjs)==0)
	{
		setAddStr(*type,"COMP_TYPE_UA");
	}else
	{
		setAddStr(*type,"ASSY_TYPE_UA");
	}

	/* Get the objects from set and do recusive call */
	*level = *level + 1;
	for( cnt=0; cnt<setSize(itemObjs); cnt++)
	{
		itemObj = setGet(itemObjs, cnt);
		relObj = setGet(relObjs, cnt);

		if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
		if(dstat = ulyCopyObjectToSet(relObj, childRelObjs)) goto CLEANUP;

		integerStr = nlsStrAlloc(6);
		sprintf(integerStr, "%d", *level);
		tempStr = nlsStrDup(integerStr);
		nlsStrFree(integerStr); integerStr = NULL;

		if(*levels == NULL) *levels = setCreate(1);
		setAddStr(*levels, tempStr);

		/* recursive call */
		if( dstat = t5GetExplosion_new(itemObj, reqLevel, contextObj, childObjs, childRelObjs, levels, type , level, mfail))
			goto CLEANUP;
		if(*mfail)
			goto CLEANUP;
		if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;
	}
	*level = *level - 1;

CLEANUP:
	if(itemObjs)  objDisposeAll(itemObjs); itemObjs = NULL;
	if(relObjs)	  objDisposeAll(relObjs); relObjs = NULL;

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}


/* This function returns Multilevel explosion of a give part object */
status t5GetMultiLevelExplosion_new
(
		ObjectPtr		partObj,
		integer			reqLevel,
		ObjectPtr       contextObj,
		SetOfObjects*	childObjs,
		SetOfObjects*	childRelObjs,
		SetOfStrings*	levels,
		SetOfStrings*	type,
		integer*		mfail
)
{
	status			dstat		= OKAY;
   	char			*mod_name 	= "t5GetMultiLevelExplosion_new";
	integer			level		= 0;
   	NVSET		textInserts	= NULL;
					*mfail 		= USC_OKAY;

	/* call to a function to track level */
	if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;

	if( dstat = t5GetExplosion_new(partObj, reqLevel, contextObj, childObjs, childRelObjs, levels , type , &level, mfail))
		goto CLEANUP;
	if(*mfail)
		goto CLEANUP;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}

//From TC Part Getting the Visualization Files...
status GetTCPartInfoForContextBOMViewMultiSingleExplosion(ObjectPtr TCPartObjP,string BOMConfigContextS,/*FILE *fp,*/FILE* OrgFp,FILE* OrgLhRhFp,string matverifyfilename,FILE* LhRHErr,integer* mfail )
{

	int MultiLevel=99;
	int ChildCount=0;


	SetOfObjects  partMasterRelSO = NULL ;
	string  ChildPartNumberDupS=NULL;
	string  ChildPartNumberS=NULL;
	string  ChildPartRevisionDupS=NULL;
	string  ChildPartRevisionS=NULL;
	string  ChildPartSequenceDupS=NULL;
	string  ChildPartSequenceS=NULL;
	string  ChildPartOwnerNameDupS=NULL;
	string  ChildPartOwnerNameS=NULL;
	string  level=NULL;
	string  p_type=NULL;

	SetOfObjects  ChildPartsSO = NULL ;
	SetOfObjects  ChildRelPartsSO = NULL ;
	SetOfObjects  partMasterSO = NULL ;


	string DescriptionDupS=NULL;
	string DescriptionS=NULL;
	string QuantityDupS=NULL;
	string QuantityS=NULL;
	string PartTypeDupS=NULL;
	string PartTypeS=NULL;

	SetOfStrings Levels= NULL;
	SetOfStrings type= NULL;

	ObjectPtr genContext=NULL;
	ObjectPtr CtxtObj=NULL;
	ObjectPtr genContext1=NULL;
	ObjectPtr CtxtObj1=NULL;
	ObjectPtr GenContextObjP=NULL;
	ObjectPtr ContextObjP=NULL;
	ObjectPtr ChildPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr ChildRelObjP=NULL;

	// Added By Raghavendra B T for more TC Part Attributes
	string t5CMVRCertificationS =	NULL;
	string t5CMVRCertificationDupS =	NULL;
	string t5ClassificationHazDupS =	NULL;
	string t5ClassificationHazS =	NULL;
	string t5ColourIDS =	NULL;
	string t5ColourIDDupS =	NULL;
	string t5ConfigIDS =	NULL;
	string t5ConfigIDDupS =	NULL;
	string t5DismantableS =	NULL;
	string t5DismantableDupS =	NULL;
	string t5DsgnDeptS =	NULL;
	string t5DsgnDeptDupS =	NULL;
	string t5EnvelopeDimenS =	NULL;
	string t5EnvelopeDimenDupS =	NULL;
	string t5HazardousContS =	NULL;
	string t5HazardousContDupS =	NULL;
	string t5HomologationReqdS =	NULL;
	string t5HomologationReqdDupS =	NULL;
	string t5ListRecSparess =	NULL;
	string t5ListRecSparesDups =	NULL;
	string t5NcPartNoS =	NULL;
	string t5PartCodeS =	NULL;
	string t5NcPartNoDupS =	NULL;
	string t5PartCodeDupS =	NULL;
	string t5PartPropertyS =	NULL;
	string t5PartPropertyDupS =	NULL;
	string t5PartStatusS =	NULL;
	string t5PartStatusDupS =	NULL;
	string t5PkgStdS =	NULL;
	string t5PkgStdDupS =	NULL;
	string t5ProductS =	NULL;
	string t5ProductDupS =	NULL;
	string t5PrtCatCodeS =	NULL;
	string t5PrtCatCodeDupS =	NULL;
	string t5PunIntialAgS =	NULL;
	string t5PunIntialAgDupS =	NULL;
	string t5PunMakeBuyIndS =	NULL;
	string t5PunMakeBuyIndDupS =	NULL;
	string t5RecoverableS =	NULL;
	string t5RecoverableDupS =	NULL;
	string t5RecyclabilityS =	NULL;
	string t5RecyclabilityDupS =	NULL;
	string t5RefPartNumberS =	NULL;
	string t5RefPartNumberDupS =	NULL;
	string t5ReliabilityS =	NULL;
	string t5ReliabilityDupS =	NULL;
	string t5SpareCriteriaS =	NULL;
	string t5SpareCriteriaDupS =	NULL;
	string t5SpareIndS =	NULL;
	string t5SpareIndDupS =	NULL;
	string t5SurfPrtStdS =	NULL;
	string t5SurfPrtStdDupS =	NULL;
	string t5SamplesToApprS =	NULL;
	string t5SamplesToApprDupS =	NULL;
	string t5AsmDisposalS =	NULL;
	string t5AsmDisposalDupS =	NULL;
	string t5FinDisposalInstrS =	NULL;
	string t5FinDisposalInstrDupS =	NULL;
	string t5RPDisposalInstrS =	NULL;
	string t5RPDisposalInstrDupS =	NULL;
	string t5SPDisposalInstrS =	NULL;
	string t5SPDisposalInstrDupS =	NULL;
	string t5WIPDisposalInstrS =	NULL;
	string t5WIPDisposalInstrDupS =	NULL;
	string t5LastModByS =	NULL;
	string t5LastModByDupS =	NULL;
	string t5VerCreatorS =	NULL;
	string t5VerCreatorDupS =	NULL;
	string t5CAEDocES =	NULL;
	string t5CAEDocEDupS =	NULL;
	string t5CoatedS =	NULL;
	string t5CoatedDupS =	NULL;
	string t5ConvDocS =	NULL;
	string t5ConvDocDupS =	NULL;
	string t5AplCopyOfErcRevS =	NULL;
	string t5AplCopyOfErcRevDupS =	NULL;
	string t5AplCopyOfErcSeqS =	NULL;
	string t5AplCopyOfErcSeqDupS =	NULL;
	string t5AppCodeS =	NULL;
	string t5AppCodeDupS =	NULL;
	string t5RqstNumS =	NULL;
	string t5RqstNumDupS =	NULL;
	string t5RsnCodeS =	NULL;
	string t5RsnCodeDupS =	NULL;
	string t5SurfaceAreaS =	NULL;
	string t5SurfaceAreaDupS =	NULL;
	string t5VolumeS =	NULL;
	string t5VolumeDupS =	NULL;
	string t5CarIntialAgencyS =	NULL;
	string t5CarIntialAgencyDupS =	NULL;
	string t5CarMakeBuyIndiS =	NULL;
	string t5CarMakeBuyIndiDupS =	NULL;
	string t5ErcIndNameS =	NULL;
	string t5ErcIndNameDupS =	NULL;
	string t5PostRelReqS =	NULL;
	string t5PostRelReqDupS =	NULL;
	string t5ItmCategoryS =	NULL;
	string t5ItmCategoryDupS =	NULL;
	string t5CopReqS =	NULL;
	string t5CopReqDupS =	NULL;
	string t5AplInvalidateS =	NULL;
	string t5AplInvalidateDupS =	NULL;
	string t5PrtValiStatusS =	NULL;
	string t5PrtValiStatusDupS =	NULL;
	string t5DRSubStateS =	NULL;
	string t5DRSubStateDupS =	NULL;
	string t5KnxtDocIndS =	NULL;
	string t5KnxtDocIndDupS =	NULL;
	string t5SimValS =	NULL;
	string t5SimValDupS =	NULL;
	string t5PerYieldS =	NULL;
	string t5PerYieldDupS =	NULL;
	string t5PunStoreLocationS =	NULL;
	string t5PunStoreLocationDupS =	NULL;
	string t5AltPartNoS =	NULL;
	string t5AltPartNoDupS =	NULL;
	string t5RolledupWtS =	NULL;
	string t5RolledupWtDupS =	NULL;
	string t5EstSheetReqdS =	NULL;
	string t5EstSheetReqdDupS =	NULL;
	string t5PFDModReqdS =	NULL;
	string t5PFDModReqdDupS =	NULL;
	string t5ToolIndentReqdS =	NULL;
	string t5ToolIndentReqdDupS =	NULL;
	string CategoryNameDupS =	NULL;
	string CategoryNameS =	NULL;


	// Ended By Raghavendra B T for more TC Part Attributes

	int z=0;
	int i=0;
	int relSize=0;
	char decimalQty[10];
	FILE* matfp=NULL;
	FILE* matverifyfp=NULL;
	string matfilename=NULL;
	string QuantityDup=NULL;
	ObjectPtr	ChildRelOP=NULL;
	int			qty=0;
	string		Quantity		=	NULL;
	string		LeftPartNumberDupS=NULL;
	string		RightPartNumberDupS=NULL;
	string		LeftPartNumberS=NULL;
	string		RightPartNumberS=NULL;
	string		ChildRelClassNameDupS	=	NULL;
	string		ChildRelClassNameS	=	NULL;
	string		LhRh_type        	=	NULL;
	string		Matrix11Dup		=	NULL;
	string		Matrix11		=	NULL;
	string		Matrix12Dup		=	NULL;
	string		Matrix12		=	NULL;
	string		Matrix13Dup		=	NULL;
	string		Matrix13		=	NULL;
	string		Matrix14Dup		=	NULL;
	string		Matrix14		=	NULL;
	string		Matrix21Dup		=	NULL;
	string		Matrix21		=	NULL;
	string		Matrix22Dup		=	NULL;
	string		Matrix22		=	NULL;
	string		Matrix23Dup		=	NULL;
	string		Matrix23		=	NULL;
	string		Matrix24Dup		=	NULL;
	string		Matrix24		=	NULL;
	string		Matrix31Dup		=	NULL;
	string		Matrix31		=	NULL;
	string		Matrix32Dup		=	NULL;
	string		Matrix32		=	NULL;
	string		Matrix33Dup		=	NULL;
	string		Matrix33		=	NULL;
	string		Matrix34Dup		=	NULL;
	string		Matrix34		=	NULL;
	string		Matrix41Dup		=	NULL;
	string		Matrix41		=	NULL;
	string		Matrix42Dup		=	NULL;
	string		Matrix42		=	NULL;
	string		Matrix43Dup		=	NULL;
	string		Matrix43		=	NULL;
	string		Matrix44Dup		=	NULL;
	string		Matrix44		=	NULL;
	ObjectPtr	revEffObj		=	NULL;
	string      RelnObidDup=NULL;
	string		ChildPartMQRelTMatrix11S=	NULL;
	string		ChildPartMQRelTMatrix12S=	NULL;
	string		ChildPartMQRelTMatrix13S=	NULL;
	string		ChildPartMQRelTMatrix14S=	NULL;
	string		ChildPartMQRelTMatrix21S=	NULL;
	string		ChildPartMQRelTMatrix22S=	NULL;
	string		ChildPartMQRelTMatrix23S=	NULL;
	string		ChildPartMQRelTMatrix24S=	NULL;
	string		ChildPartMQRelTMatrix31S=	NULL;
	string		ChildPartMQRelTMatrix32S=	NULL;
	string		ChildPartMQRelTMatrix33S=	NULL;
	string		ChildPartMQRelTMatrix34S=	NULL;
	string		ChildPartMQRelTMatrix41S=	NULL;
	string		ChildPartMQRelTMatrix42S=	NULL;
	string		ChildPartMQRelTMatrix43S=	NULL;
	string		ChildPartMQRelTMatrix44S=	NULL;
	string		LeftPartObjOBIDS	=	NULL ;
	string		RightPartMstrObjOBIDS11	=	NULL ;
	SqlPtr		MultyQtySqlPtr		=	NULL ;
	SetOfObjects	MultyQtyRelPartSO	=	NULL;
	ObjectPtr	RelQtyPartObjP		=	NULL ;
	int		sizeoftable		=	0;
	int		orgSequence		=	0;
	int		k		=	0;
	string		RelnObid		=	NULL;
	string		ChildPartQuantityS	=	NULL;
	int		ChildMQPart		=	0;
	string      intnameDupS=NULL;
	string      Instnamedup=NULL;
	string      Instname=NULL;
	string newInstancename=NULL;
	string indexS=NULL;
	string indexDupS=NULL;
	string ProjectCodeDupS=NULL;
	string ProjectCodeS=NULL;
	string DesignGroupDupS=NULL;
	string DesignGroupS=NULL;

	string ModDescriptionDupS=NULL;
	string ModDescriptionS=NULL;
	string DrawingNoDupS=NULL;
	string DrawingNoS=NULL;
	string DrawingIndDupS=NULL;
	string DrawingIndS=NULL;
	string MaterialDupS=NULL;
	string MaterialS=NULL;
	string MaterialInDrwDupS=NULL;
	string MaterialInDrwS=NULL;
	string LeftRhDupS=NULL;
	string LeftRhS=NULL;
	string DeignOwnUnitDupS=NULL;
	string DeignOwnUnitS=NULL;
	string ModelIndDupS=NULL;
	string ModelIndS=NULL;
	string UnitOfMeasureDupS=NULL;
	string UnitOfMeasureS=NULL;
	string ColourIndDupS=NULL;
	string ColourIndS=NULL;
	string WeightDupS=NULL;
	string WeightS=NULL;
	string MaterialThickNessDupS=NULL;
	string MaterialThickNessS=NULL;
	string LifeCycleStateDupS=NULL;
	string LifeCycleStateS=NULL;
	SetOfObjects	soExpObj		= NULL;
	SetOfObjects	relObjSet		= NULL;
	SetOfObjects	hasRHItmMster		= NULL;
	SetOfObjects	hasRHTCPart  		= NULL;
	SetOfObjects	hasRHTCPartRelObj	= NULL;
	SetOfObjects	itemObjs        	= NULL;
	SetOfObjects	relObjs         	= NULL;

	ObjectPtr		contextObjE		= NULL;
	ObjectPtr		genContextObjE	= NULL;
	ObjectPtr		relobj			= NULL;
	ObjectPtr		busItemsRight	= NULL;
	ObjectPtr		hasRHItmM    	= NULL;
	string          start_date=NULL;
	string          end_date=NULL;
	string          fromdate=NULL;
	string          todate=NULL;
	string from_date_s=NULL;
	string to_date_s=NULL;

	t5MethodInit("GetTCPartInfoForContextBOMViewMultiSingleExplosion");


	/* setting of session context preferences */
	t5CheckMfail(SetUpContext(objClass(TCPartObjP),TCPartObjP,&GenContextObjP,mfail));

	/* Get the configuration context object from the general context. */
	t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,GenContextObjP,&ContextObjP,mfail));

	/* Set the option as "Latest Revision with State" in the context object */
	t5CheckDstat(objSetAttribute(ContextObjP,ExpandOnRevisionAttr, "PscLastRev"));
	t5CheckDstat(objSetAttribute(ContextObjP,"NavigateViewBitPos","0"));
	t5CheckDstat(objSetAttribute(ContextObjP,"CfgItemId","GlobalCtxt"));
	t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNetworkAttr,"EAS"));
	t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNameAttr,"ERC"));
	t5CheckDstat(objSetAttribute(ContextObjP,PsmExpIncludeZeroQtyAttr,"-"));
	//t5CheckDstat(objSetAttribute(ContextObjP,t5ExpIncludeOtherUserItemsAttr,"-"));

	//Setting the BOMConfigContextS Configuration Context Based on the User Selection...
	if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP And Release Vaults"))
	{
		printf("\n Entering inside as Latest From WIP And Release Vaults...\n");
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));

	}
	if(!nlsStrCmp(BOMConfigContextS,"Latest From Release Vault Only"))
	{
	  t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
	  t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
	  t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));
	  t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
	  t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));

	}

	if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP Vault Only"))
	{

	   printf("\n Entering inside as Latest From WIP Vaults Only...\n");
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
		//t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsWorking","+"));

	}

	t5CheckDstat(objSetObject(GenContextObjP,ConfigCtxtBlobAttr, ContextObjP));
	printf("\n Ending in to Configuration Context Settings in ContextBOMViewTCPartMultiExplosion..\n");

	/* Get the explosion with context */
	//printf("\n Expansion of the object based on Configuration Context Settings ..\n");

	//objDump(GenContextObjP);
	t5CheckMfail(t5GetMultiLevelExplosion_new(TCPartObjP,MultiLevel,GenContextObjP,&ChildPartsSO,&ChildRelPartsSO,&Levels,&type,mfail));

	printf("\n Total Number of Multi Level Explosion Parts in ContextBOMViewTCPartMultiExplosion:%d \n",setSize(ChildPartsSO));
	if(setSize(ChildPartsSO)==0)
	{
		printf("\n There no Single Level Children is found for this TPL in ContextBOMViewTCPartMultiExplosion\n");
		goto CLEANUP;
	}

	printf("\n No. of objects in type:[%d]",setSize(type));
	if(setSize(ChildPartsSO)>0)
	{
		for(ChildCount=0;ChildCount<setSize(ChildPartsSO);ChildCount++)
		{
			printf("\n Count is:%d \n",ChildCount);

			ChildPartObjP=setGet(ChildPartsSO,ChildCount);
			ChildRelObjP=setGet(ChildRelPartsSO,ChildCount);

			t5CheckMfail(ExpandObject2(ItemRevClass,ChildPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) ;
			MasterObjOP=setGet(partMasterSO,0);

			level=setGet(Levels,ChildCount);
			p_type=setGet(type,ChildCount+1);

			t5CheckDstat(objGetAttribute(ChildPartObjP,PartNumberAttr,&ChildPartNumberDupS));
			ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
			printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,RevisionAttr,&ChildPartRevisionDupS));
			ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
			printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,SequenceAttr,&ChildPartSequenceDupS));
			ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
			printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

//			t5CheckDstat(objGetAttribute(ChildPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
//			ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);
//			printf("\n  Child TC Part ChildPartOwnerNameS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartOwnerNameS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,NomenclatureAttr,&DescriptionDupS));
			DescriptionS=nlsStrDup(DescriptionDupS);
			DescriptionS=low_strssra(DescriptionS,"\n"," ");
			printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildRelObjP,QuantityAttr,&QuantityDupS));
			QuantityS=nlsStrDup(QuantityDupS);
			printf("\n  Child TC Part QuantityS in ContextBOMViewTCPartMultiExplosion:%s \n",QuantityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,PartTypeAttr,&PartTypeDupS));
			PartTypeS=nlsStrDup(PartTypeDupS);
			printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);


//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5DocRemarksAttr,&ModDescriptionDupS));
//			ModDescriptionS=nlsStrDup(ModDescriptionDupS);
//			ModDescriptionS=low_strssra(DescriptionS,"\n"," ");
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5DrawingNoAttr,&DrawingNoDupS));
//			DrawingNoS=nlsStrDup(DrawingNoDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5DrawingIndAttr,&DrawingIndDupS));
//			DrawingIndS=nlsStrDup(DrawingIndDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5MatlClassAttr,&MaterialDupS));
//			MaterialS=nlsStrDup(MaterialDupS);
//
//			MaterialS=low_strssra(MaterialS,"\n"," ");
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5MaterialAttr,&MaterialInDrwDupS));
//			MaterialInDrwS=nlsStrDup(MaterialInDrwDupS);
//
//
//			MaterialInDrwS=low_strssra(MaterialInDrwS,"\n"," ");
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5MThicknessAttr,&MaterialThickNessDupS));
//			MaterialThickNessS=nlsStrDup(MaterialThickNessDupS);
//
//
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5DsgnOwnAttr,&DeignOwnUnitDupS));
//			DeignOwnUnitS=nlsStrDup(DeignOwnUnitDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5ModelIndicatorAttr,&ModelIndDupS));
//			ModelIndS=nlsStrDup(ModelIndDupS);
//
//
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5ColourIndAttr,&ColourIndDupS));
//			ColourIndS=nlsStrDup(ColourIndDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5WeightAttr,&WeightDupS));
//			WeightS=nlsStrDup(WeightDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,ProjectNameAttr,&ProjectCodeDupS));
//			ProjectCodeS=nlsStrDup(ProjectCodeDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,t5DesignGroupAttr,&DesignGroupDupS));
//			DesignGroupS=nlsStrDup(DesignGroupDupS);
//
//
//			t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&LeftRhDupS));
//			LeftRhS=nlsStrDup(LeftRhDupS);
//
//			t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureDupS));
//			UnitOfMeasureS=nlsStrDup(UnitOfMeasureDupS);
//
//			t5CheckDstat(objGetAttribute(ChildPartObjP,LifeCycleStateAttr,&LifeCycleStateDupS));
//			LifeCycleStateS=nlsStrDup(LifeCycleStateDupS);
//
//			// Added By Raghavendra B T for more TC Part Attributes
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
//				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
//				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ColourID",&t5ColourIDDupS));
//				t5ColourIDS=nlsStrDup(t5ColourIDDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ConfigID",&t5ConfigIDDupS));
//				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Dismantable",&t5DismantableDupS));
//				t5DismantableS=nlsStrDup(t5DismantableDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
//				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
//				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5HazardousContents",&t5HazardousContDupS));
//				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
//				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
//				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
//				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PartCode",&t5PartCodeDupS));
//				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PartProperty",&t5PartPropertyDupS));
//				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PartStatus",&t5PartStatusDupS));
//				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PkgStd",&t5PkgStdDupS));
//				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Product",&t5ProductDupS));
//				t5ProductS=nlsStrDup(t5ProductDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
//				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
//				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
//				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Recoverable",&t5RecoverableDupS));
//				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
//				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
//				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Reliability",&t5ReliabilityDupS));
//				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
//				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SpareInd",&t5SpareIndDupS));
//				t5SpareIndS=nlsStrDup(t5SpareIndDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
//				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
//				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
//				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
//				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
//				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
//				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
//				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5LastModBy",&t5LastModByDupS));
//				t5LastModByS=nlsStrDup(t5LastModByDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5VerCreator",&t5VerCreatorDupS));
//				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
//				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Coated",&t5CoatedDupS));
//				t5CoatedS=nlsStrDup(t5CoatedDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ConvDoc",&t5ConvDocDupS));
//				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
//				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
//				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AppCode",&t5AppCodeDupS));
//				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5RqstNum",&t5RqstNumDupS));
//				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5RsnCode",&t5RsnCodeDupS));
//				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
//				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5Volume",&t5VolumeDupS));
//				t5VolumeS=nlsStrDup(t5VolumeDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
//				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
//				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
//				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
//				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
//				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5CopReq",&t5CopReqDupS));
//				t5CopReqS=nlsStrDup(t5CopReqDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
//				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
//				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5DRSubState",&t5DRSubStateDupS));
//				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
//				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5SimVal",&t5SimValDupS));
//				t5SimValS=nlsStrDup(t5SimValDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PerYield",&t5PerYieldDupS));
//				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
//				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
//				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
//				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
//				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
//				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
//				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
//				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
//
//
//				t5CheckDstat(objGetAttribute(ChildPartObjP,"CategoryName",&CategoryNameDupS));
//				CategoryNameS=nlsStrDup(CategoryNameDupS);


				// Ended By Raghavendra B T for more TC Part Attributes

			fprintf(OrgFp,"%s",level);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartNumberS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartRevisionS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartSequenceS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",DescriptionS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",QuantityS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",p_type);
			fprintf(OrgFp,"^");


			printf("\n ChildPartNumberS[%s]\n",ChildPartNumberS);fflush(stdout);


			LeftRhDupS = NULL;
			LeftRhS = NULL;
			t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&LeftRhDupS));
			LeftRhS=nlsStrDup(LeftRhDupS);

			printf("\n LeftRhS[%s]\n",LeftRhS);fflush(stdout);
            if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0)
			{
			fprintf(OrgFp,"%s",PartTypeS);
			fprintf(OrgFp,"^");
		    fprintf(OrgFp,"%s\n","RH");
			}else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0)
			{
			fprintf(OrgFp,"%s",PartTypeS);
			fprintf(OrgFp,"^");
		    fprintf(OrgFp,"%s\n","LH");
			}
            else{
			   fprintf(OrgFp,"%s\n",PartTypeS);
			 }


	        if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0 )
			{
				fprintf(OrgLhRhFp,"%s",level);
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","RH");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",QuantityS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",p_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);



			    t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
				printf("\n inside LeftRhS[%s]\n",LeftRhS);fflush(stdout);
                if(setSize(hasRHItmMster) == 0)
				{
				  fprintf(LhRHErr,"%s",ChildPartNumberS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s",ChildPartRevisionS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s",ChildPartSequenceS);
				}
				if(setSize(hasRHItmMster) >0)
				{
                   hasRHItmM = low_set_get(hasRHItmMster,0);

				t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
				//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
				//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

				t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
    			t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
				t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
			//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

				if(hasRHItmM)
					t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 000 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
               if(setSize(hasRHTCPart) >0)
				{
				busItemsRight = low_set_get(hasRHTCPart,0);
				t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
				//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
				//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

				t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
    			t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
				t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
			//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));
			   if(busItemsRight)
				   if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail))
					goto CLEANUP;
				printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
						LhRh_type = NULL;
			            LhRh_type=nlsStrAlloc(50);
				}
				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
    			DescriptionS    =NULL;
	    		t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
    			PartTypeS    =NULL;
			    t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

			    fprintf(OrgLhRhFp,"%s","1");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LeftRhS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","1");
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LhRh_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);

				fprintf(OrgFp,"%s",level);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartNumberS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartRevisionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartSequenceS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",DescriptionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s","1");
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",LhRh_type);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",PartTypeS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s\n",LeftRhS);


			}else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0 )
			{

			    fprintf(OrgLhRhFp,"%s",level);
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","LH");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",QuantityS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",p_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);

			    t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
				if(setSize(hasRHItmMster) >0)
				{
                   hasRHItmM = low_set_get(hasRHItmMster,0);

				t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
				//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
				//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

				//t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
    			t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
				t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
			//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

				if(hasRHItmM)
					t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 111 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
               if(setSize(hasRHTCPart) >0)
				{
				busItemsRight = low_set_get(hasRHTCPart,0);
				t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
				//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
				//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

				t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
    			t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
				t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
			    if(busItemsRight)
				   if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail))
					goto CLEANUP;
				printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
						LhRh_type = NULL;
			            LhRh_type=nlsStrAlloc(50);
				}
				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
    			DescriptionS    =NULL;
	    		t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
    			PartTypeS    =NULL;
			    t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

			    fprintf(OrgLhRhFp,"%s","1");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LeftRhS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","1");
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LhRh_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);


				fprintf(OrgFp,"%s",level);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartNumberS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartRevisionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartSequenceS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",DescriptionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s","1");
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",LhRh_type);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",PartTypeS);
             	fprintf(OrgFp,"^");
			    fprintf(OrgFp,"%s\n",LeftRhS);
			}

			//orgSequence=atoi(ChildPartSequenceS);
			//sprintf(orgSequence,"%d",ChildPartSequenceS);
			//for(k=1;k<=orgSequence;k++)
			//{
//				fprintf(fp,"%s",level);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",ChildPartNumberS);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",ChildPartRevisionS);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",ChildPartSequenceS);
//				//fprintf(fp,"%d",k);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",DescriptionS);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",QuantityS);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",p_type);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",PartTypeS);
//				fprintf(fp,"^");
//
//				fprintf(fp,"%s",ProjectCodeS);
//				fprintf(fp,"^");
//				fprintf(fp,"%s",DesignGroupS);
//				fprintf(fp,"^");
//
//				if(!nlsIsStrNull(ModDescriptionS))
//				{
//					fprintf(fp,"%s",ModDescriptionS);
//					fprintf(fp,"^");
//				}else
//				{
//					fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(DrawingNoS))
//				{
//					fprintf(fp,"%s",DrawingNoS);
//					fprintf(fp,"^");
//				}else
//				{
//					fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(DrawingIndS))
//				{
//					fprintf(fp,"%s",DrawingIndS);
//					fprintf(fp,"^");
//				}else
//				{
//					fprintf(fp," ^");
//				}
//
//
//				if(!nlsIsStrNull(MaterialS)){
//				fprintf(fp,"%s",MaterialS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(MaterialInDrwS)){
//				fprintf(fp,"%s",MaterialInDrwS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(MaterialThickNessS)){
//				fprintf(fp,"%s",MaterialThickNessS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(LeftRhS)){
//				fprintf(fp,"%s",LeftRhS);
//				fprintf(fp,"^");
//				}else
//				{
//					fprintf(fp," ^");
//				}
//
//
//				if(!nlsIsStrNull(DeignOwnUnitS)){
//				fprintf(fp,"%s",DeignOwnUnitS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(ModelIndS)){
//				fprintf(fp,"%s",ModelIndS);
//				fprintf(fp,"^");
//				}else
//				{
//					fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(UnitOfMeasureS)){
//				fprintf(fp,"%s",UnitOfMeasureS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//				if(!nlsIsStrNull(ColourIndS)){
//				fprintf(fp,"%s",ColourIndS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
//
//				if(!nlsIsStrNull(LifeCycleStateS)){
//				fprintf(fp,"%s",LifeCycleStateS);
//				fprintf(fp,"^");
//				}else
//				{
//						fprintf(fp," ^");
//				}
//
////				if(!nlsIsStrNull(from_date_s)){
////				fprintf(fp,"%s to %s",from_date_s,to_date_s);
////				fprintf(fp,"^");
////				}else
////				{
////						fprintf(fp," ^");
////				}
//
//
//
//				fprintf(fp,"%s",WeightS);
//				fprintf(fp,"^");
//
//				// Added By Raghavendra B T for more TC Part Attributes
//					if(!nlsIsStrNull(t5CMVRCertificationS)){
//					fprintf(fp,"%s",t5CMVRCertificationS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ClassificationHazS)){
//					fprintf(fp,"%s",t5ClassificationHazS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ColourIDS)){
//					fprintf(fp,"%s",t5ColourIDS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ConfigIDS)){
//					fprintf(fp,"%s",t5ConfigIDS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5DismantableS)){
//					fprintf(fp,"%s",t5DismantableS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5DsgnDeptS)){
//					fprintf(fp,"%s",t5DsgnDeptS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5EnvelopeDimenS)){
//					fprintf(fp,"%s",t5EnvelopeDimenS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5HazardousContS)){
//					fprintf(fp,"%s",t5HazardousContS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5HomologationReqdS)){
//					fprintf(fp,"%s",t5HomologationReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ListRecSparess)){
//					fprintf(fp,"%s",t5ListRecSparess);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5NcPartNoS)){
//					fprintf(fp,"%s",t5NcPartNoS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartCodeS)){
//					fprintf(fp,"%s",t5PartCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartPropertyS)){
//					fprintf(fp,"%s",t5PartPropertyS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartStatusS)){
//					fprintf(fp,"%s",t5PartStatusS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5PkgStdS)){
//					fprintf(fp,"%s",t5PkgStdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ProductS)){
//					fprintf(fp,"%s",t5ProductS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PrtCatCodeS)){
//					fprintf(fp,"%s",t5PrtCatCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunIntialAgS)){
//					fprintf(fp,"%s",t5PunIntialAgS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunMakeBuyIndS)){
//					fprintf(fp,"%s",t5PunMakeBuyIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RecoverableS)){
//					fprintf(fp,"%s",t5RecoverableS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RecyclabilityS)){
//					fprintf(fp,"%s",t5RecyclabilityS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RefPartNumberS)){
//					fprintf(fp,"%s",t5RefPartNumberS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ReliabilityS)){
//					fprintf(fp,"%s",t5ReliabilityS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SpareCriteriaS)){
//					fprintf(fp,"%s",t5SpareCriteriaS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SpareIndS)){
//					fprintf(fp,"%s",t5SpareIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SurfPrtStdS)){
//					fprintf(fp,"%s",t5SurfPrtStdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SamplesToApprS)){
//					fprintf(fp,"%s",t5SamplesToApprS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AsmDisposalS)){
//					fprintf(fp,"%s",t5AsmDisposalS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5FinDisposalInstrS)){
//					fprintf(fp,"%s",t5FinDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RPDisposalInstrS)){
//					fprintf(fp,"%s",t5RPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SPDisposalInstrS)){
//					fprintf(fp,"%s",t5SPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5WIPDisposalInstrS)){
//					fprintf(fp,"%s",t5WIPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5LastModByS)){
//					fprintf(fp,"%s",t5LastModByS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5VerCreatorS)){
//					fprintf(fp,"%s",t5VerCreatorS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CAEDocES)){
//					fprintf(fp,"%s",t5CAEDocES);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5CoatedS)){
//					fprintf(fp,"%s",t5CoatedS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5ConvDocS)){
//					fprintf(fp,"%s",t5ConvDocS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
//					fprintf(fp,"%s",t5AplCopyOfErcRevS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
//					fprintf(fp,"%s",t5AplCopyOfErcSeqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AppCodeS)){
//					fprintf(fp,"%s",t5AppCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RqstNumS)){
//					fprintf(fp,"%s",t5RqstNumS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RsnCodeS)){
//					fprintf(fp,"%s",t5RsnCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SurfaceAreaS)){
//					fprintf(fp,"%s",t5SurfaceAreaS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5VolumeS)){
//					fprintf(fp,"%s",t5VolumeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CarIntialAgencyS)){
//					fprintf(fp,"%s",t5CarIntialAgencyS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
//					fprintf(fp,"%s",t5CarMakeBuyIndiS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ErcIndNameS)){
//					fprintf(fp,"%s",t5ErcIndNameS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PostRelReqS)){
//					fprintf(fp,"%s",t5PostRelReqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ItmCategoryS)){
//					fprintf(fp,"%s",t5ItmCategoryS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CopReqS)){
//					fprintf(fp,"%s",t5CopReqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AplInvalidateS)){
//					fprintf(fp,"%s",t5AplInvalidateS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PrtValiStatusS)){
//					fprintf(fp,"%s",t5PrtValiStatusS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5DRSubStateS)){
//					fprintf(fp,"%s",t5DRSubStateS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5KnxtDocIndS)){
//					fprintf(fp,"%s",t5KnxtDocIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5SimValS)){
//					fprintf(fp,"%s",t5SimValS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PerYieldS)){
//					fprintf(fp,"%s",t5PerYieldS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunStoreLocationS)){
//					fprintf(fp,"%s",t5PunStoreLocationS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AltPartNoS)){
//					fprintf(fp,"%s",t5AltPartNoS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5RolledupWtS)){
//					fprintf(fp,"%s",t5RolledupWtS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
////
////					if(!nlsIsStrNull(t5EstSheetReqdS)){
////					fprintf(fp,"%s",t5EstSheetReqdS);
////					fprintf(fp,"^");
////					}else
////					{
////						fprintf(fp," ^");
////					}
//
//					if(!nlsIsStrNull(t5PFDModReqdS)){
//					fprintf(fp,"%s",t5PFDModReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ToolIndentReqdS)){
//					fprintf(fp,"%s",t5ToolIndentReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(CategoryNameS)){
//					fprintf(fp,"%s",CategoryNameS);
//					fprintf(fp,"\n");
//					}else
//					{
//						fprintf(fp,"\n");
//					}


					// Ended By Raghavendra B T for more TC Part Attributes

			//}

			//fflush(fp);


		}
	}


	 matverifyfp=fopen(matverifyfilename,"w");

	 relSize=setSize(ChildRelPartsSO);
	 for(i=0;i<relSize;i++)
	 {
		ChildRelOP=setGet(ChildRelPartsSO,i);
		if(dstat=objGetAttribute(ChildRelOP,LeftNameAttr,&LeftPartNumberDupS)) goto EXIT;
		if(dstat=objGetAttribute(ChildRelOP,RightNameAttr,&RightPartNumberDupS)) goto EXIT;
		if(LeftPartNumberDupS)
		LeftPartNumberS=nlsStrDup(LeftPartNumberDupS);
		if(RightPartNumberDupS)
		RightPartNumberS=nlsStrDup(RightPartNumberDupS);
		if(dstat=objGetAttribute(ChildRelOP,QuantityAttr,&QuantityDup)) goto EXIT;
		if(QuantityDup!=NULL)
		Quantity=nlsStrDup(QuantityDup);

		LeftPartNumberS=strtok(LeftPartNumberS,",");
		RightPartNumberS=strtok(RightPartNumberS,",");

		fprintf(matverifyfp,"%s,%s,%s\n",LeftPartNumberS,RightPartNumberS,Quantity);

		matfilename=nlsStrAlloc(50);
		nlsStrCpy(matfilename,LeftPartNumberS);
		nlsStrCat(matfilename,".");
		nlsStrCat(matfilename,RightPartNumberS);
		nlsStrCat(matfilename,".mat.txt");

		matfp=fopen(matfilename,"w");
		t5CheckDstat(objGetAttribute(ChildRelOP,LToRNameAttr,&ChildRelClassNameDupS));
		ChildRelClassNameS=nlsStrDup(ChildRelClassNameDupS);

		t5CheckDstat(objGetObject(ChildRelOP,AssocRelationObjAttr,&revEffObj));
		t5CheckDstat(objGetAttribute(revEffObj,OBIDAttr,&RelnObidDup));
		RelnObid=nlsStrDup(RelnObidDup);

		printf("\n Matrix for [%s][%s][%s]",LeftPartNumberS,RightPartNumberS,ChildRelClassNameS);

		if(!nlsStrCmp(ChildRelClassNameS,"Uses Parts"))
		{
				printf("\n Uses Parts");
				sprintf(decimalQty,"%d",atoi(Quantity));
				if(nlsStrCmp(decimalQty,Quantity)==0)
				{
					qty=atoi(decimalQty);
				}else{
					qty=1;
				}
				//printf("\n Multi Quantity Is : %d ",qty);
				//printf("\n Getting Martix the normal way");fflush(stdout);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix11Attr,&Matrix11Dup)) goto EXIT;
				if(Matrix11Dup!=NULL)
				Matrix11=nlsStrDup(Matrix11Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix12Attr,&Matrix12Dup)) goto EXIT;
				if(Matrix12Dup!=NULL)
				Matrix12=nlsStrDup(Matrix12Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix13Attr,&Matrix13Dup)) goto EXIT;
				if(Matrix13Dup!=NULL)
				Matrix13=nlsStrDup(Matrix13Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix14Attr,&Matrix14Dup)) goto EXIT;
				if(Matrix14Dup!=NULL)
				Matrix14=nlsStrDup(Matrix14Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix21Attr,&Matrix21Dup)) goto EXIT;
				if(Matrix21Dup!=NULL)
				Matrix21=nlsStrDup(Matrix21Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix22Attr,&Matrix22Dup)) goto EXIT;
				if(Matrix22Dup!=NULL)
				Matrix22=nlsStrDup(Matrix22Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix23Attr,&Matrix23Dup)) goto EXIT;
				if(Matrix23Dup!=NULL)
				Matrix23=nlsStrDup(Matrix23Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix24Attr,&Matrix24Dup)) goto EXIT;
				if(Matrix24Dup!=NULL)
				Matrix24=nlsStrDup(Matrix24Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix31Attr,&Matrix31Dup)) goto EXIT;
				if(Matrix31Dup!=NULL)
				Matrix31=nlsStrDup(Matrix31Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix32Attr,&Matrix32Dup)) goto EXIT;
				if(Matrix32Dup!=NULL)
				Matrix32=nlsStrDup(Matrix32Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix33Attr,&Matrix33Dup)) goto EXIT;
				if(Matrix33Dup!=NULL)
				Matrix33=nlsStrDup(Matrix33Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix34Attr,&Matrix34Dup)) goto EXIT;
				if(Matrix34Dup!=NULL)
				Matrix34=nlsStrDup(Matrix34Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix41Attr,&Matrix41Dup)) goto EXIT;
				if(Matrix41Dup!=NULL)
				Matrix41=nlsStrDup(Matrix41Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix42Attr,&Matrix42Dup)) goto EXIT;
				if(Matrix42Dup!=NULL)
				Matrix42=nlsStrDup(Matrix42Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix43Attr,&Matrix43Dup)) goto EXIT;
				if(Matrix43Dup!=NULL)
				Matrix43=nlsStrDup(Matrix43Dup);

				if(dstat=objGetAttribute(ChildRelOP,TMatrix44Attr,&Matrix44Dup)) goto EXIT;
				if(Matrix44Dup!=NULL)
				Matrix44=nlsStrDup(Matrix44Dup);

				t5CheckDstat(objGetAttribute(ChildRelOP,g0InstanceNameAttr,&Instname));
				Instnamedup=nlsStrDup(Instname);

				for(z=0;z<qty;z++)
				{

					fprintf(matfp,"%s,%s,%s,%s",Matrix11,Matrix12,Matrix13,Matrix14);
					fprintf(matfp,",%s,%s,%s,%s",Matrix21,Matrix22,Matrix23,Matrix24);
					fprintf(matfp,",%s,%s,%s,%s",Matrix31,Matrix32,Matrix33,Matrix34);
					fprintf(matfp,",%s,%s,%s,%s,%s\n",Matrix41,Matrix42,Matrix43,Matrix44,Instnamedup);
					fflush(matfp);
				}

		}else
		{


						printf("\n Uses Elements");

						t5CheckDstat(objGetAttribute(ChildRelOP,LeftAttr,&LeftPartObjOBIDS));
						printf("\n Multi Quantity Assembly PartNumber(Left OBID) is:%s \n",LeftPartObjOBIDS);
						t5CheckDstat(objGetAttribute(ChildRelOP,RightAttr,&RightPartMstrObjOBIDS11));
						//printf("\n Multi Quantity Children PartNumber(Right OBID) is:%s \n",RightPartMstrObjOBIDS11);
						t5CheckDstat(oiSqlCreateSelect(&MultyQtySqlPtr));
						t5CheckDstat(oiSqlWhereEQ(MultyQtySqlPtr,OBIDAttr,RelnObid));
						t5CheckMfail(QueryWhere3(x2AsmPoQClass,MultyQtySqlPtr,0,SC_SCOPE_OF_SESSION,&MultyQtyRelPartSO,mfail));
						printf("\n Set Size of the Object in x2AsmPoQ is:%d \n",setSize(MultyQtyRelPartSO));

						if(setSize(MultyQtyRelPartSO)!=0)
						{
							RelQtyPartObjP = (ObjectPtr)low_set_get(MultyQtyRelPartSO,0);
							//RelQtyPartObjP =setGet(MultyQtyRelPartSO,0);
							t5CheckDstat(objGetTableSize(RelQtyPartObjP,"x0TrafoList",&sizeoftable));
							//printf("\n Full table name size is After Setting:%d \n",sizeoftable);
							t5CheckDstat(objGetAttribute(RelQtyPartObjP,QuantityAttr,&ChildPartQuantityS));
							//printf("\n Multi Quantity Value is:%s \n",ChildPartQuantityS);
							sprintf(decimalQty,"%d",atoi(ChildPartQuantityS));
							if(nlsStrCmp(decimalQty,ChildPartQuantityS)==0)
							{
							qty=atoi(ChildPartQuantityS);
							}else{
							qty=1;
							}

							printf("\n Multi Quantity Is : [%d,%d] ",qty,sizeoftable);
							//printf("\n MulitQunatity Valuse is (After Int Conv):%d \n",ChildPartMQuantityS);
							for(ChildMQPart=0;ChildMQPart<sizeoftable;ChildMQPart++)
							{



							//objDump(RelQtyPartObjP);
							//printf("\n Current Running Serial for the Index Matrix is:%d \n",ChildMQPart);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix11Attr,&ChildPartMQRelTMatrix11S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix11Attr value is:%s \n",ChildPartMQRelTMatrix11S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,x0TrafoIndexAttr,&indexDupS));
							indexS=nlsStrDup(indexDupS);
							if(nlsIsStrNull(indexS))
							{
								continue;
								fprintf(matfp,"1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0\n");
								fflush(matfp);
							}
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix12Attr,&ChildPartMQRelTMatrix12S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix12Attr value is:%s \n",ChildPartMQRelTMatrix12S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix13Attr,&ChildPartMQRelTMatrix13S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix13Attr value is:%s \n",ChildPartMQRelTMatrix13S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix14Attr,&ChildPartMQRelTMatrix14S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix14Attr value is:%s \n",ChildPartMQRelTMatrix14S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix21Attr,&ChildPartMQRelTMatrix21S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix21Attr value is:%s \n",ChildPartMQRelTMatrix21S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix22Attr,&ChildPartMQRelTMatrix22S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix22Attr value is:%s \n",ChildPartMQRelTMatrix22S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix23Attr,&ChildPartMQRelTMatrix23S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix23Attr value is:%s \n",ChildPartMQRelTMatrix23S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix24Attr,&ChildPartMQRelTMatrix24S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix24Attr value is:%s \n",ChildPartMQRelTMatrix24S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix31Attr,&ChildPartMQRelTMatrix31S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix31Attr value is:%s \n",ChildPartMQRelTMatrix31S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix32Attr,&ChildPartMQRelTMatrix32S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix32Attr value is:%s \n",ChildPartMQRelTMatrix32S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix33Attr,&ChildPartMQRelTMatrix33S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix33Attr value is:%s \n",ChildPartMQRelTMatrix33S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix34Attr,&ChildPartMQRelTMatrix34S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix34Attr value is:%s \n",ChildPartMQRelTMatrix34S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix41Attr,&ChildPartMQRelTMatrix41S));
							//printf("\n Getting Full table x0TrafoListAttr   TMatrix41Attr value is:%s \n",ChildPartMQRelTMatrix41S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix42Attr,&ChildPartMQRelTMatrix42S));
							//printf("\n Getting Full table x0TrafoListAttr  TMatrix42Attr value is:%s \n",ChildPartMQRelTMatrix42S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix43Attr,&ChildPartMQRelTMatrix43S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix43Attr value is:%s \n",ChildPartMQRelTMatrix43S);
							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix44Attr,&ChildPartMQRelTMatrix44S));
							//printf("\n Getting Full table x0TrafoListAttr TMatrix44Attr value is:%s \n",ChildPartMQRelTMatrix44S);

							t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,g0InstanceNameAttr,&Instname));
							Instnamedup=nlsStrDup(Instname);

							newInstancename=nlsStrAlloc(500);

							if(nlsIsStrNull(Instnamedup))
							{

										t5CheckDstat(objGetAttribute(RelQtyPartObjP,g0InstanceNameAttr,&Instname));
										printf("\n 1.Instance name:[%s]",Instname);
										Instnamedup=nlsStrDup(Instname);

										nlsStrCpy(newInstancename,Instnamedup);
										nlsStrCat(newInstancename,"#");
										nlsStrCat(newInstancename,indexS);
										printf("\n Get Attribute 1 :[%s]",newInstancename);
							}else
							{
										nlsStrCpy(newInstancename,Instnamedup);
										printf("\n Get Attribute 2 :[%s]",newInstancename);
							}

							fprintf(matfp,"%s,%s,%s,%s",ChildPartMQRelTMatrix11S,ChildPartMQRelTMatrix12S,ChildPartMQRelTMatrix13S,ChildPartMQRelTMatrix14S);
							fprintf(matfp,",%s,%s,%s,%s",ChildPartMQRelTMatrix21S,ChildPartMQRelTMatrix22S,ChildPartMQRelTMatrix23S,ChildPartMQRelTMatrix24S);
							fprintf(matfp,",%s,%s,%s,%s",ChildPartMQRelTMatrix31S,ChildPartMQRelTMatrix32S,ChildPartMQRelTMatrix33S,ChildPartMQRelTMatrix34S);
							fprintf(matfp,",%s,%s,%s,%s,%s\n",ChildPartMQRelTMatrix41S,ChildPartMQRelTMatrix42S,ChildPartMQRelTMatrix43S,ChildPartMQRelTMatrix44S,newInstancename);



							}
						}
		}
		fclose(matfp);
		matfp=NULL;
	 }




CLEANUP:
		//fclose(matverifyfp);matverifyfp=NULL;
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(ChildPartsSO);
		t5FreeSetOfObjects(ChildRelPartsSO);


EXIT:
		t5CheckDstatAndReturn;

};


//Main Program for ContextBOMViewTCPartMultiExplosion
int main(int argc, char *argv[])
{
	int stat=0;
	int ChildCount=0;

	SetOfObjects	soExpObj		= NULL;
	SetOfObjects	relObjSet		= NULL;
	ObjectPtr		contextObjE		= NULL;
	ObjectPtr		genContextObjE	= NULL;
	ObjectPtr		relobj			= NULL;
	string          start_date=NULL;
	string          end_date=NULL;
	string          fromdate=NULL;
	string          todate=NULL;
	string from_date_s=NULL;
	string to_date_s=NULL;

	string  ChildPartNumberDupS=NULL;
	string  ChildPartNumberS=NULL;
	string  ChildPartRevisionDupS=NULL;
	string  ChildPartRevisionS=NULL;
	string  ChildPartSequenceDupS=NULL;
	string  ChildPartSequenceS=NULL;
	string  ChildPartOwnerNameDupS=NULL;
	string  ChildPartOwnerNameS=NULL;
	string  LoginS=NULL;
	string  PasswordS=NULL;
	string  OutFileNameS=NULL;
	string  InpPartNumberS=NULL;
	string  InpPartRevisionS=NULL;
	string  InpPartSequenceS=NULL;
	string  BOMConfigContextS=NULL;
	string  selectedVaultS=NULL;
	string  DescriptionDupS=NULL;
	string  DescriptionS=NULL;
	SetOfObjects  TCPartObjPLRSO = NULL ;
	SetOfObjects  TCPartObjPLRRelSO = NULL ;
	SetOfObjects  PartResultSO = NULL ;
	SetOfObjects  PartResultRelSO = NULL ;
	SetOfObjects  NamedBLSO = NULL ;
	SetOfObjects  partMasterSO = NULL ;
	SetOfObjects  partMasterRelSO = NULL ;
	SetOfObjects	hasRHItmMster		= NULL;
	SetOfObjects	hasRHTCPart  		= NULL;
	SetOfObjects	hasRHTCPartRelObj	= NULL;
	SetOfObjects	itemObjs	= NULL;
	SetOfObjects	relObjs	= NULL;

	string PartTypeDupS=NULL;
	string PartTypeS=NULL;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOPLR=NULL;
	ObjectPtr ChildPartObjP=NULL;
	ObjectPtr NamedBLPtr=NULL;
	ObjectPtr hasRHItmM=NULL;
	ObjectPtr genContext=NULL;
	ObjectPtr CtxtObj=NULL;
	ObjectPtr busItemsRight=NULL;
	ObjectPtr genContext1=NULL;
	ObjectPtr CtxtObj1=NULL;

	SqlPtr  InputTCPartSqlPtr = NULL;
	SqlPtr  MasterObjOP = NULL;


	string LhRh_type=NULL;
	string ModDescriptionDupS=NULL;
	string ModDescriptionS=NULL;
	string DrawingNoDupS=NULL;
	string DrawingNoS=NULL;
	string DrawingIndDupS=NULL;
	string DrawingIndS=NULL;
	string MaterialDupS=NULL;
	string MaterialS=NULL;
	string MaterialInDrwDupS=NULL;
	string MaterialInDrwS=NULL;
	string DeignOwnUnitDupS=NULL;
	string DeignOwnUnitS=NULL;
	string ModelIndDupS=NULL;
	string ModelIndS=NULL;
	string UnitOfMeasureDupS=NULL;
	string UnitOfMeasureS=NULL;
	string ColourIndDupS=NULL;
	string ColourIndS=NULL;
	string WeightDupS=NULL;
	string WeightS=NULL;
	string MaterialThickNessDupS=NULL;
	string MaterialThickNessS=NULL;
	string ProjectCodeDupS=NULL;
	string ProjectCodeS=NULL;
	string DesignGroupDupS=NULL;
	string DesignGroupS=NULL;
	string LifeCycleStateDupS=NULL;
	string LifeCycleStateS=NULL;
	///         ///

	// Added By Raghavendra B T for more TC Part Attributes
	string t5CMVRCertificationS =	NULL;
	string t5CMVRCertificationDupS =	NULL;
	string t5ClassificationHazDupS =	NULL;
	string t5ClassificationHazS =	NULL;
	string t5ColourIDS =	NULL;
	string t5ColourIDDupS =	NULL;
	string t5ConfigIDS =	NULL;
	string t5ConfigIDDupS =	NULL;
	string t5DismantableS =	NULL;
	string t5DismantableDupS =	NULL;
	string t5DsgnDeptS =	NULL;
	string t5DsgnDeptDupS =	NULL;
	string t5EnvelopeDimenS =	NULL;
	string t5EnvelopeDimenDupS =	NULL;
	string t5HazardousContS =	NULL;
	string t5HazardousContDupS =	NULL;
	string t5HomologationReqdS =	NULL;
	string t5HomologationReqdDupS =	NULL;
	string t5ListRecSparess =	NULL;
	string t5ListRecSparesDups =	NULL;
	string t5NcPartNoS =	NULL;
	string t5PartCodeS =	NULL;
	string t5NcPartNoDupS =	NULL;
	string t5PartCodeDupS =	NULL;
	string t5PartPropertyS =	NULL;
	string t5PartPropertyDupS =	NULL;
	string t5PartStatusS =	NULL;
	string t5PartStatusDupS =	NULL;
	string t5PkgStdS =	NULL;
	string t5PkgStdDupS =	NULL;
	string t5ProductS =	NULL;
	string t5ProductDupS =	NULL;
	string t5PrtCatCodeS =	NULL;
	string t5PrtCatCodeDupS =	NULL;
	string t5PunIntialAgS =	NULL;
	string t5PunIntialAgDupS =	NULL;
	string t5PunMakeBuyIndS =	NULL;
	string t5PunMakeBuyIndDupS =	NULL;
	string t5RecoverableS =	NULL;
	string t5RecoverableDupS =	NULL;
	string t5RecyclabilityS =	NULL;
	string t5RecyclabilityDupS =	NULL;
	string t5RefPartNumberS =	NULL;
	string t5RefPartNumberDupS =	NULL;
	string t5ReliabilityS =	NULL;
	string t5ReliabilityDupS =	NULL;
	string t5SpareCriteriaS =	NULL;
	string t5SpareCriteriaDupS =	NULL;
	string t5SpareIndS =	NULL;
	string t5SpareIndDupS =	NULL;
	string t5SurfPrtStdS =	NULL;
	string t5SurfPrtStdDupS =	NULL;
	string t5SamplesToApprS =	NULL;
	string t5SamplesToApprDupS =	NULL;
	string t5AsmDisposalS =	NULL;
	string t5AsmDisposalDupS =	NULL;
	string t5FinDisposalInstrS =	NULL;
	string t5FinDisposalInstrDupS =	NULL;
	string t5RPDisposalInstrS =	NULL;
	string t5RPDisposalInstrDupS =	NULL;
	string t5SPDisposalInstrS =	NULL;
	string t5SPDisposalInstrDupS =	NULL;
	string t5WIPDisposalInstrS =	NULL;
	string t5WIPDisposalInstrDupS =	NULL;
	string t5LastModByS =	NULL;
	string t5LastModByDupS =	NULL;
	string t5VerCreatorS =	NULL;
	string t5VerCreatorDupS =	NULL;
	string t5CAEDocES =	NULL;
	string t5CAEDocEDupS =	NULL;
	string t5CoatedS =	NULL;
	string t5CoatedDupS =	NULL;
	string t5ConvDocS =	NULL;
	string t5ConvDocDupS =	NULL;
	string t5AplCopyOfErcRevS =	NULL;
	string t5AplCopyOfErcRevDupS =	NULL;
	string t5AplCopyOfErcSeqS =	NULL;
	string t5AplCopyOfErcSeqDupS =	NULL;
	string t5AppCodeS =	NULL;
	string t5AppCodeDupS =	NULL;
	string t5RqstNumS =	NULL;
	string t5RqstNumDupS =	NULL;
	string t5RsnCodeS =	NULL;
	string t5RsnCodeDupS =	NULL;
	string t5SurfaceAreaS =	NULL;
	string t5SurfaceAreaDupS =	NULL;
	string t5VolumeS =	NULL;
	string t5VolumeDupS =	NULL;
	string t5CarIntialAgencyS =	NULL;
	string t5CarIntialAgencyDupS =	NULL;
	string t5CarMakeBuyIndiS =	NULL;
	string t5CarMakeBuyIndiDupS =	NULL;
	string t5ErcIndNameS =	NULL;
	string t5ErcIndNameDupS =	NULL;
	string t5PostRelReqS =	NULL;
	string t5PostRelReqDupS =	NULL;
	string t5ItmCategoryS =	NULL;
	string t5ItmCategoryDupS =	NULL;
	string t5CopReqS =	NULL;
	string t5CopReqDupS =	NULL;
	string t5AplInvalidateS =	NULL;
	string t5AplInvalidateDupS =	NULL;
	string t5PrtValiStatusS =	NULL;
	string t5PrtValiStatusDupS =	NULL;
	string t5DRSubStateS =	NULL;
	string t5DRSubStateDupS =	NULL;
	string t5KnxtDocIndS =	NULL;
	string t5KnxtDocIndDupS =	NULL;
	string t5SimValS =	NULL;
	string t5SimValDupS =	NULL;
	string t5PerYieldS =	NULL;
	string t5PerYieldDupS =	NULL;
	string t5PunStoreLocationS =	NULL;
	string t5PunStoreLocationDupS =	NULL;
	string t5AltPartNoS =	NULL;
	string t5AltPartNoDupS =	NULL;
	string t5RolledupWtS =	NULL;
	string t5RolledupWtDupS =	NULL;
	string t5EstSheetReqdS =	NULL;
	string t5EstSheetReqdDupS =	NULL;
	string t5PFDModReqdS =	NULL;
	string t5PFDModReqdDupS =	NULL;
	string t5ToolIndentReqdS =	NULL;
	string t5ToolIndentReqdDupS =	NULL;
	string CategoryNameDupS =	NULL;
	string CategoryNameS =	NULL;
	string LeftRhDupS=NULL;
	string LeftRhS=NULL;
	string		LhRHErrPath	=	"LHRHErrorParts.txt" ;


	// Ended By Raghavendra B T for more TC Part Attributes
	string		docobjst	=	NULL;
	int		ii		=          0;
	int		orgSequence		=          0;
	int		k		=          0;
	SetOfStrings      dbScp	=          NULL;
	SetOfStrings      frozenListSS	=          NULL;
	string matvfilename=NULL;
	string OrgOutFileNames=NULL;
	string OrgLhRhOutFileNames=NULL;
	//File Declaration
	//FILE	*fp	= NULL;
	FILE	*Orgfp	= NULL;
	FILE	*OrgLhRhfp	= NULL;
	FILE	*LhRHErr	= NULL;

	t5MethodInitWMD("ContextBOMViewTCPartMultiExplosion");

	printf("\n Executing... main:ContextBOMViewTCPartMultiExplosion.c ... \n");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	InpPartNumberS=nlsStrAlloc(200);
	InpPartRevisionS=nlsStrAlloc(200);
	InpPartSequenceS=nlsStrAlloc(200);
	BOMConfigContextS=nlsStrAlloc(200);
	selectedVaultS=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	InpPartNumberS=argv[3];
	InpPartRevisionS=argv[4];
	InpPartSequenceS=argv[5];
	BOMConfigContextS=argv[6];
	//OutFileNameS=argv[7];
	OrgOutFileNames=argv[7];
	OrgLhRhOutFileNames=argv[8];

	//printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}


	///////////////////////////////////////
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	//t5CheckDstat(getDataBaseSetByUser(&dbScp,selectedVaultS,mfail));
	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}
	//////////////////////////////////////////////////////////



	/***   To Get the Input Details From Reading Input Text File ***/

	//fp=fopen(OutFileNameS,"a+");
	//fflush(fp);
	//printf("\n From Data File Input Part Number is in ContextBOMViewTCPartMultiExplosion:%s \n",InpPartNumberS);
	//printf("\n From Data File Input Part Revision is in ContextBOMViewTCPartMultiExplosion:%s \n",InpPartRevisionS);
	//printf("\n From Data File Input Part Sequence is in ContextBOMViewTCPartMultiExplosion:%s \n",InpPartSequenceS);
	//printf("\n From Data File Input BOMConfigContextS is in ContextBOMViewTCPartMultiExplosion:%s \n",BOMConfigContextS);

	Orgfp=fopen(OrgOutFileNames,"a+");
	fflush(Orgfp);


	OrgLhRhfp=fopen(OrgLhRhOutFileNames,"a+");
	fflush(OrgLhRhfp);


	LhRHErr=fopen(LhRHErrPath,"a+");
    fflush(LhRHErr);

	//Code For Handling Assembly and Component in the Collection
	if(nlsStrCmp(BOMConfigContextS,"Latest From WIP And Release Vaults")==0 || nlsStrCmp(BOMConfigContextS,"Latest From Release Vault Only")==0 || nlsStrCmp(BOMConfigContextS,"Latest From WIP Vault Only")==0)
	{

		printf("\n Inside Normal Explosion");

		t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InpPartNumberS));
		t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RevisionAttr,InpPartRevisionS));
		t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,SequenceAttr,InpPartSequenceS));

		t5CheckMfail(QueryWhere3(PartClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&PartResultSO,mfail));

		if(setSize(PartResultSO)==0) goto CLEANUP;

		if(setSize(PartResultSO)==1)
		{
				TCPartObjP=setGet(PartResultSO,0);


//				t5CheckMfail(ExpandObject2(ItemRevClass,TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) ;
//				MasterObjOP=setGet(partMasterSO,0);
//
				t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
//				ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);
//				printf("\n  Child TC Part ChildPartOwnerNameS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartOwnerNameS); fflush(stdout);
//
				t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

				t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
//
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&ModDescriptionDupS));
//				ModDescriptionS=nlsStrDup(ModDescriptionDupS);
//				ModDescriptionS=low_strssra(DescriptionS,"\n"," ");
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingNoAttr,&DrawingNoDupS));
//				DrawingNoS=nlsStrDup(DrawingNoDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&DrawingIndDupS));
//				DrawingIndS=nlsStrDup(DrawingIndDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&MaterialDupS));
//				MaterialS=nlsStrDup(MaterialDupS);
//
//				MaterialS=low_strssra(MaterialS,"\n"," ");
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&MaterialInDrwDupS));
//				MaterialInDrwS=nlsStrDup(MaterialInDrwDupS);
//
//				MaterialInDrwS=low_strssra(MaterialInDrwS,"\n"," ");
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessDupS));
//				MaterialThickNessS=nlsStrDup(MaterialThickNessDupS);
//
//				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&LeftRhDupS));
//				LeftRhS=nlsStrDup(LeftRhDupS);
//
//				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureDupS));
//				UnitOfMeasureS=nlsStrDup(UnitOfMeasureDupS);
//
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&DeignOwnUnitDupS));
//				DeignOwnUnitS=nlsStrDup(DeignOwnUnitDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&ModelIndDupS));
//				ModelIndS=nlsStrDup(ModelIndDupS);
//
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&ColourIndDupS));
//				ColourIndS=nlsStrDup(ColourIndDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightDupS));
//				WeightS=nlsStrDup(WeightDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectCodeDupS));
//				ProjectCodeS=nlsStrDup(ProjectCodeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&DesignGroupDupS));
//				DesignGroupS=nlsStrDup(DesignGroupDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateDupS));
//				LifeCycleStateS=nlsStrDup(LifeCycleStateDupS);
//
//				// Added By Raghavendra B T for more TC Part Attributes
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
//				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
//				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDDupS));
//				t5ColourIDS=nlsStrDup(t5ColourIDDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
//				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
//				t5DismantableS=nlsStrDup(t5DismantableDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
//				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
//				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
//				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
//				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
//				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
//				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
//				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
//				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
//				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
//				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
//				t5ProductS=nlsStrDup(t5ProductDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
//				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
//				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
//				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
//				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
//				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
//				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
//				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
//				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareInd",&t5SpareIndDupS));
//				t5SpareIndS=nlsStrDup(t5SpareIndDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
//				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
//				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
//				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
//				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
//				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
//				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
//				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
//				t5LastModByS=nlsStrDup(t5LastModByDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
//				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
//				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
//				t5CoatedS=nlsStrDup(t5CoatedDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
//				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
//				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
//				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
//				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
//				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
//				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
//				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
//				t5VolumeS=nlsStrDup(t5VolumeDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
//				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
//				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
//				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
//				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
//				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
//				t5CopReqS=nlsStrDup(t5CopReqDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
//				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
//				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
//				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
//				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
//				t5SimValS=nlsStrDup(t5SimValDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
//				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
//				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
//				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
//				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
//				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
//				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
//				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
//				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
//
//
//				t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
//				CategoryNameS=nlsStrDup(CategoryNameDupS);
//
//
//				// Ended By Raghavendra B T for more TC Part Attributes
//
//				from_date_s=nlsStrAlloc(20);
//				to_date_s=nlsStrAlloc(20);
//				if(nlsStrCmp(LifeCycleStateS,"LcsReview")==0)
//				{
//						printf("\n This is not a released Part.....");
//						nlsStrCpy(from_date_s,"NONE");
//						nlsStrCpy(to_date_s,"NONE");
//				}else if(nlsStrCmp(LifeCycleStateS,"LcsWorking")==0)
//				{
//						printf("\n This is not a released Part.....");
//						nlsStrCpy(from_date_s,"NONE");
//						nlsStrCpy(to_date_s,"NONE");
//				}



				matvfilename=nlsStrAlloc(100);
				nlsStrCpy(matvfilename,ChildPartNumberS);
				nlsStrCat(matvfilename,"_Verfiy.mat.txt");

				fprintf(Orgfp,"0");//(level);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartNumberS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartRevisionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartSequenceS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",DescriptionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"1^ASSY_TYPE_UA^");//(QuantityS);

				t5CheckMfail(ExpandObject2(ItemRevClass,TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&TCPartObjPLRSO,&TCPartObjPLRRelSO,mfail)) ;
				if(setSize(TCPartObjPLRSO) >0)MasterObjOPLR=setGet(TCPartObjPLRSO,0);

				t5CheckDstat(objGetAttribute(MasterObjOPLR,t5LeftRhAttr,&LeftRhDupS));
				LeftRhS=nlsStrDup(LeftRhDupS);

				printf("\n LeftRhS[%s]\n",LeftRhS);fflush(stdout);
				if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0)
				{
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n","RH");
				}else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0)
				{
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n","LH");
				}
				else{
				   fprintf(Orgfp,"%s\n",PartTypeS);
				 }

				fprintf(OrgLhRhfp,"%s","0");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s","RH");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",DescriptionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s","1");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s","ASSY_TYPE_UA");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s\n",PartTypeS);


				if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0 )
				{

					t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
					if(setSize(hasRHItmMster) >0)
					{
					   hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
				//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
						t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
					}

					printf("\ncalling ExpSetForUses hasRHTCPart 222 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				   if(setSize(hasRHTCPart) >0)
					{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
				//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));
				   if(busItemsRight)
					   if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail))
						goto CLEANUP;
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
					}

					if(LhRh_type == NULL)
					{
							LhRh_type = NULL;
							LhRh_type=nlsStrAlloc(50);
					}
					if(setSize(itemObjs)==0)
					{
						nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
					}else
					{
						nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
					}

					ChildPartNumberDupS=NULL;
					ChildPartNumberS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
					ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
					printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

					ChildPartRevisionDupS=NULL;
					ChildPartRevisionS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
					ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
					printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

					ChildPartSequenceDupS=NULL;
					ChildPartSequenceS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
					ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
					printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

					DescriptionDupS =NULL;
					DescriptionS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
					DescriptionS=nlsStrDup(DescriptionDupS);
					DescriptionS=low_strssra(DescriptionS,"\n"," ");
					printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

					PartTypeDupS =NULL;
					PartTypeS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
					PartTypeS=nlsStrDup(PartTypeDupS);
					printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

					fprintf(OrgLhRhfp,"%s","1");
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",LeftRhS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",DescriptionS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s","1");
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",LhRh_type);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s\n",PartTypeS);

					fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartNumberS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartRevisionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartSequenceS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",DescriptionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",LhRh_type);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",PartTypeS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s\n",LeftRhS);


				}else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0 )
				{
//
//					fprintf(OrgLhRhfp,"%s","0");
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s","LH");
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s",DescriptionS);
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s","1");
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s","ASSY_TYPE_UA");
//					fprintf(OrgLhRhfp,"^");
//					fprintf(OrgLhRhfp,"%s\n",PartTypeS);

					t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
					if(setSize(hasRHItmMster) >0)
					{
					   hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					//t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
				//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
						t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
					}

					printf("\ncalling ExpSetForUses hasRHTCPart 333 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				   if(setSize(hasRHTCPart) >0)
					{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
					if(busItemsRight)
					   if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail))
						goto CLEANUP;
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
					}

					if(LhRh_type == NULL)
					{
							LhRh_type = NULL;
							LhRh_type=nlsStrAlloc(50);
					}
					if(setSize(itemObjs)==0)
					{
						nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
					}else
					{
						nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
					}

					ChildPartNumberDupS=NULL;
					ChildPartNumberS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
					ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
					printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

					ChildPartRevisionDupS=NULL;
					ChildPartRevisionS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
					ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
					printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

					ChildPartSequenceDupS=NULL;
					ChildPartSequenceS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
					ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
					printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

					DescriptionDupS =NULL;
					DescriptionS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
					DescriptionS=nlsStrDup(DescriptionDupS);
					DescriptionS=low_strssra(DescriptionS,"\n"," ");
					printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

					PartTypeDupS =NULL;
					PartTypeS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
					PartTypeS=nlsStrDup(PartTypeDupS);
					printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

					fprintf(OrgLhRhfp,"%s","1");
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",LeftRhS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",DescriptionS);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s","1");
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s",LhRh_type);
					fprintf(OrgLhRhfp,"^");
					fprintf(OrgLhRhfp,"%s\n",PartTypeS);


					fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartNumberS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartRevisionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartSequenceS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",DescriptionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",LhRh_type);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",PartTypeS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s\n",LeftRhS);
				}

//
//    			fprintf(OrgLhRhfp,"0");//(level);
//				fprintf(OrgLhRhfp,"^");
//				fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
//				fprintf(OrgLhRhfp,"^");
//				fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
//				fprintf(OrgLhRhfp,"^");
//				fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
//				fprintf(OrgLhRhfp,"^");
//				fprintf(OrgLhRhfp,"%s",DescriptionS);
//				fprintf(OrgLhRhfp,"^");
//				fprintf(OrgLhRhfp,"1^ASSY_TYPE_UA^%s\n",PartTypeS);//(QuantityS);
//


				//orgSequence=atoi(ChildPartSequenceS);
				//sprintf(orgSequence,"%d",ChildPartSequenceS);
				//for(k=1;k<=orgSequence;k++)
				//{
//					fprintf(fp,"0");//(level);
//					fprintf(fp,"^");
//					fprintf(fp,"%s",ChildPartNumberS);
//					fprintf(fp,"^");
//					fprintf(fp,"%s",ChildPartRevisionS);
//					fprintf(fp,"^");
//					fprintf(fp,"%s",ChildPartSequenceS);
//					//fprintf(fp,"%d",k);
//					fprintf(fp,"^");
//					fprintf(fp,"%s",DescriptionS);
//					fprintf(fp,"^");
//					fprintf(fp,"1^ASSY_TYPE_UA^%s^",PartTypeS);//(QuantityS);
//
//					fprintf(fp,"%s",ProjectCodeS);
//					fprintf(fp,"^");
//					fprintf(fp,"%s",DesignGroupS);
//					fprintf(fp,"^");
//
//
//					if(!nlsIsStrNull(ModDescriptionS))
//					{
//						fprintf(fp,"%s",ModDescriptionS);
//						fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(DrawingNoS))
//					{
//						fprintf(fp,"%s",DrawingNoS);
//						fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(DrawingIndS))
//					{
//						fprintf(fp,"%s",DrawingIndS);
//						fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(MaterialS)){
//					fprintf(fp,"%s",MaterialS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(MaterialInDrwS)){
//					fprintf(fp,"%s",MaterialInDrwS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(MaterialThickNessS)){
//					fprintf(fp,"%s",MaterialThickNessS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(LeftRhS)){
//					fprintf(fp,"%s",LeftRhS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(DeignOwnUnitS)){
//					fprintf(fp,"%s",DeignOwnUnitS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(ModelIndS)){
//					fprintf(fp,"%s",ModelIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(UnitOfMeasureS)){
//					fprintf(fp,"%s",UnitOfMeasureS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(ColourIndS)){
//					fprintf(fp,"%s",ColourIndS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(LifeCycleStateS)){
//					fprintf(fp,"%s",LifeCycleStateS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					// commented for TMETC bcoz of denis issue
////					if(!nlsIsStrNull(from_date_s)){
////					fprintf(fp,"%s to %s",from_date_s,to_date_s);
////					fprintf(fp,"^");
////					}else
////					{
////							fprintf(fp," ^");
////					}
//
//					fprintf(fp,"%s",WeightS);
//					fprintf(fp,"^");
//
//					// Added By Raghavendra B T for more TC Part Attributes
//					if(!nlsIsStrNull(t5CMVRCertificationS)){
//					fprintf(fp,"%s",t5CMVRCertificationS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ClassificationHazS)){
//					fprintf(fp,"%s",t5ClassificationHazS);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ColourIDS)){
//					fprintf(fp,"%s",t5ColourIDS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ConfigIDS)){
//					fprintf(fp,"%s",t5ConfigIDS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5DismantableS)){
//					fprintf(fp,"%s",t5DismantableS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5DsgnDeptS)){
//					fprintf(fp,"%s",t5DsgnDeptS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5EnvelopeDimenS)){
//					fprintf(fp,"%s",t5EnvelopeDimenS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5HazardousContS)){
//					fprintf(fp,"%s",t5HazardousContS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5HomologationReqdS)){
//					fprintf(fp,"%s",t5HomologationReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ListRecSparess)){
//					fprintf(fp,"%s",t5ListRecSparess);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5NcPartNoS)){
//					fprintf(fp,"%s",t5NcPartNoS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartCodeS)){
//					fprintf(fp,"%s",t5PartCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartPropertyS)){
//					fprintf(fp,"%s",t5PartPropertyS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PartStatusS)){
//					fprintf(fp,"%s",t5PartStatusS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5PkgStdS)){
//					fprintf(fp,"%s",t5PkgStdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ProductS)){
//					fprintf(fp,"%s",t5ProductS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PrtCatCodeS)){
//					fprintf(fp,"%s",t5PrtCatCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunIntialAgS)){
//					fprintf(fp,"%s",t5PunIntialAgS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunMakeBuyIndS)){
//					fprintf(fp,"%s",t5PunMakeBuyIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RecoverableS)){
//					fprintf(fp,"%s",t5RecoverableS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RecyclabilityS)){
//					fprintf(fp,"%s",t5RecyclabilityS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RefPartNumberS)){
//					fprintf(fp,"%s",t5RefPartNumberS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ReliabilityS)){
//					fprintf(fp,"%s",t5ReliabilityS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SpareCriteriaS)){
//					fprintf(fp,"%s",t5SpareCriteriaS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SpareIndS)){
//					fprintf(fp,"%s",t5SpareIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SurfPrtStdS)){
//					fprintf(fp,"%s",t5SurfPrtStdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SamplesToApprS)){
//					fprintf(fp,"%s",t5SamplesToApprS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AsmDisposalS)){
//					fprintf(fp,"%s",t5AsmDisposalS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5FinDisposalInstrS)){
//					fprintf(fp,"%s",t5FinDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RPDisposalInstrS)){
//					fprintf(fp,"%s",t5RPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SPDisposalInstrS)){
//					fprintf(fp,"%s",t5SPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5WIPDisposalInstrS)){
//					fprintf(fp,"%s",t5WIPDisposalInstrS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5LastModByS)){
//					fprintf(fp,"%s",t5LastModByS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5VerCreatorS)){
//					fprintf(fp,"%s",t5VerCreatorS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CAEDocES)){
//					fprintf(fp,"%s",t5CAEDocES);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5CoatedS)){
//					fprintf(fp,"%s",t5CoatedS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5ConvDocS)){
//					fprintf(fp,"%s",t5ConvDocS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
//					fprintf(fp,"%s",t5AplCopyOfErcRevS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
//					fprintf(fp,"%s",t5AplCopyOfErcSeqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AppCodeS)){
//					fprintf(fp,"%s",t5AppCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RqstNumS)){
//					fprintf(fp,"%s",t5RqstNumS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5RsnCodeS)){
//					fprintf(fp,"%s",t5RsnCodeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5SurfaceAreaS)){
//					fprintf(fp,"%s",t5SurfaceAreaS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5VolumeS)){
//					fprintf(fp,"%s",t5VolumeS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CarIntialAgencyS)){
//					fprintf(fp,"%s",t5CarIntialAgencyS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
//					fprintf(fp,"%s",t5CarMakeBuyIndiS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ErcIndNameS)){
//					fprintf(fp,"%s",t5ErcIndNameS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PostRelReqS)){
//					fprintf(fp,"%s",t5PostRelReqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ItmCategoryS)){
//					fprintf(fp,"%s",t5ItmCategoryS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5CopReqS)){
//					fprintf(fp,"%s",t5CopReqS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AplInvalidateS)){
//					fprintf(fp,"%s",t5AplInvalidateS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PrtValiStatusS)){
//					fprintf(fp,"%s",t5PrtValiStatusS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5DRSubStateS)){
//					fprintf(fp,"%s",t5DRSubStateS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5KnxtDocIndS)){
//					fprintf(fp,"%s",t5KnxtDocIndS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5SimValS)){
//					fprintf(fp,"%s",t5SimValS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PerYieldS)){
//					fprintf(fp,"%s",t5PerYieldS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5PunStoreLocationS)){
//					fprintf(fp,"%s",t5PunStoreLocationS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5AltPartNoS)){
//					fprintf(fp,"%s",t5AltPartNoS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5RolledupWtS)){
//					fprintf(fp,"%s",t5RolledupWtS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//
//					if(!nlsIsStrNull(t5PFDModReqdS)){
//					fprintf(fp,"%s",t5PFDModReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(t5ToolIndentReqdS)){
//					fprintf(fp,"%s",t5ToolIndentReqdS);
//					fprintf(fp,"^");
//					}else
//					{
//						fprintf(fp," ^");
//					}
//
//					if(!nlsIsStrNull(CategoryNameS)){
//					fprintf(fp,"%s",CategoryNameS);
//					fprintf(fp,"\n");
//					}else
//					{
//						fprintf(fp,"\n");
//					}
//
//					// Ended By Raghavendra B T for more TC Part Attributes
				//}

				printf("\n Calling the Function for GetTCPartInfoForContextBOMViewMultiSingleExplosion in ContextBOMViewTCPartMultiExplosion\n"); fflush(stdout);
				t5CheckMfail(GetTCPartInfoForContextBOMViewMultiSingleExplosion(TCPartObjP,BOMConfigContextS,/*fp,*/Orgfp,OrgLhRhfp,matvfilename,LhRHErr,mfail));

		}
		if(setSize(PartResultSO)>1)
		{
			printf("\n This is not Possible Use Case now \n");
			goto EXIT;
		}

	}else
	{
		printf("\n Inside Named Baseline Explosion");
		t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,BaselineNameAttr,BOMConfigContextS));

		t5CheckMfail(QueryWhere3(NamedBlClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&NamedBLSO,mfail));
		if(setSize(NamedBLSO)==0) goto CLEANUP;

		if(setSize(NamedBLSO)>=1)
		{

			NamedBLPtr=setGet(NamedBLSO,0);
			t5CheckMfail(ExpandObject2(NBlToWIClass,NamedBLPtr,"WorkItemsMembersOfNamedBl",SC_SCOPE_OF_SESSION,&PartResultSO,&PartResultRelSO,mfail));

			for(ChildCount=0;ChildCount<setSize(PartResultSO);ChildCount++)
			{
				printf("\n Count is:%d \n",ChildCount);

				ChildPartObjP=setGet(PartResultSO,ChildCount);

				t5CheckDstat(objGetAttribute(ChildPartObjP,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
				ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);
				printf("\n  Child TC Part ChildPartOwnerNameS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartOwnerNameS); fflush(stdout);

//				fprintf(fp,"%s",ChildPartNumberS);
//				fprintf(fp,",");
//				fprintf(fp,"%s",ChildPartRevisionS);
//				fprintf(fp,",");
//				fprintf(fp,"%s",ChildPartSequenceS);
//				fprintf(fp,",");
//				fprintf(fp,"%s\n",ChildPartOwnerNameS);
//				fflush(fp);

			}


		}


	}

	//fclose(fp);
	fclose(Orgfp);


CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);
		t5FreeSqlPtr(InputTCPartSqlPtr);


EXIT:
		t5CheckDstatAndReturn;
}
;

