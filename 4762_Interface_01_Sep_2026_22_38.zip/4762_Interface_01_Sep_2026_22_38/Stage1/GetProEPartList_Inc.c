/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File				:   GetProEPartList.c
*  Author			:   
*  Module			:   TCUA Downloader.
*  Purpose			:   To get TC Part List
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <ReadFile.h>
#include <tel.h>
#include <Mtimsgh.h>
#define NUMBER 5000
int main(int argc, char *argv[])
{
	t5MethodInitWMD("GetProEPartList");

	int stat=0;

	string docobjst	= NULL;
	string PartNumberDupS=NULL;
	string PartNumberS=NULL;
	string PartRevisionDupS=NULL;
	string PartRevisionS=NULL;
	string PartSequenceDupS=NULL;
	string PartSequenceS=NULL;
	string PartOwnerNameDupS=NULL;
	string PartOwnerNameS=NULL;
	//string LoginS=NULL;
	//string PasswordS=NULL;
	string InpPartNumberS=NULL;
	string InpPartRevS=NULL;
	string InpPartSeqS=NULL;
	string InpPartOwnerS=NULL;
	string OutFileNameS=NULL;
	string CatiaDIOutFileNm=NULL;
	string LcStateChageFileNm=NULL;
	string docClass=NULL;
	string DataItClass = NULL;
	string WorkingFileNm = NULL;
	string WorkingFileNmDup = NULL;
	string Sequence = NULL;
	string SequenceDup = NULL;
	string OwnerDirName = NULL;
	string OwnerDirNameDup = NULL;
	string OwnerName = NULL;
	string OwnerNameDup = NULL;
	string PartRevSeq = NULL;

	SetOfObjects PartResultSO = NULL ;
	SetOfObjects PartResultSO2 = NULL ;
	SetOfObjects PartResultSO3 = NULL ;
	SetOfObjects docObjs = NULL ;
	SetOfObjects docRelObjs = NULL ;
	SetOfObjects latestDocs = NULL ;
	SetOfObjects latestRelDocs = NULL ;
	SetOfObjects DataItemJtSO = NULL ;

	ObjectPtr TCPartObjP = NULL;
	//ObjectPtr TCPartSupObjP = NULL;
	ObjectPtr docOPtr = NULL;
	ObjectPtr NewDataItemObjP = NULL;
	ObjectPtr GetItemInfoObjP = NULL;

	SqlPtr Sql_ptr = NULL;

	int ii = 0;
	int k = 0;
	int noOfDocs = 0;
	int DataItem = 0;
	int ReleaseVaultFlag = 0;

	SetOfStrings dbScp	= NULL;

	FILE *fp = NULL;
	FILE *fpCDI = NULL;
	FILE *fpLcs = NULL;

	//LoginS=nlsStrAlloc(200);
	//PasswordS=nlsStrAlloc(200);
	InpPartNumberS=nlsStrAlloc(200);
	InpPartRevS=nlsStrAlloc(200);
	InpPartSeqS=nlsStrAlloc(200);
	InpPartOwnerS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	CatiaDIOutFileNm=nlsStrAlloc(200);
	LcStateChageFileNm=nlsStrAlloc(200);
	PartRevSeq=nlsStrAlloc(50);

	//LoginS=argv[1];
	//PasswordS=argv[2];
	InpPartNumberS=argv[1];
	InpPartRevS=argv[2];
	InpPartSeqS=argv[3];
	InpPartOwnerS=argv[4];
	OutFileNameS=argv[5];
	CatiaDIOutFileNm=argv[6];
	LcStateChageFileNm=argv[7];

	//printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());
	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));
	//t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));
	t5CheckDstat(clLogin2 ("Loader","123loader",&stat));
	if (stat!=OKAY)
	{
		//printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		printf("\n Invalid User Name or PasswordS....... \n");  fflush(stdout);
		goto EXIT;
	}

	printf("\n Executing... GetProEPartList_Inc.c ... \n"); fflush(stdout);

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
		docobjst=low_set_get(dbScp,ii);
		//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}
	low_set_add_str(dbScp, "suhprod");
	//low_set_add_str(dbScp, "sujprod");
	//low_set_add_str(dbScp, "sulprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	printf("\n DB pref check -after: "); fflush(stdout);
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\t[%s]",docobjst); fflush(stdout);
	}
	printf("\n"); fflush(stdout);

	fp=fopen(OutFileNameS,"a+");
	fflush(fp);

	fpCDI=fopen(CatiaDIOutFileNm,"a+");
	fflush(fpCDI);

	fpLcs=fopen(LcStateChageFileNm,"a+");
	fflush(fpLcs);

	if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
		(dstat = oiSqlWhereBegParen(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,InpPartRevS))||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,SequenceAttr,InpPartSeqS))||
		(dstat = oiSqlWhereEndParen(Sql_ptr)));
		//(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
	if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartResultSO,mfail)) goto EXIT;

	printf("\n No:of Parts are :- %d ",setSize(PartResultSO)); fflush(stdout);

	if(setSize(PartResultSO) == 0)
	{
		printf("\t............Part is not found,  %s, %s, %s \n\n",InpPartNumberS,InpPartRevS,InpPartSeqS); fflush(stdout);
		goto CLEANUP;
	}

	if(setSize(PartResultSO)>0)
	{
		ReleaseVaultFlag = 1;

		for(k=0;k<setSize(PartResultSO);k++)
		{
			TCPartObjP=setGet(PartResultSO,k);
			//TCPartObjP=setGet(PartResultSO,(setSize(PartResultSO)-1));

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberDupS));
			PartNumberS=nlsStrDup(PartNumberDupS);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&PartRevisionDupS));
			PartRevisionS=nlsStrDup(PartRevisionDupS);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&PartSequenceDupS));
			PartSequenceS=nlsStrDup(PartSequenceDupS);
			
			printf("\nTCPart:::::[%s , %s , %s]",PartNumberS,PartRevisionS,PartSequenceS); fflush(stdout);

			if(!nlsIsStrNull(PartNumberS))
			{
				nlsStrCpy(PartRevSeq,"");

				nlsStrCpy(PartRevSeq,PartNumberS);
				nlsStrCat(PartRevSeq,"_");
				nlsStrCat(PartRevSeq,PartRevisionS);
				nlsStrCat(PartRevSeq,"_");
				nlsStrCat(PartRevSeq,PartSequenceS);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&PartOwnerNameDupS));
			PartOwnerNameS=nlsStrDup(PartOwnerNameDupS);
			
			printf("\tOwnerName: %s",PartOwnerNameS); fflush(stdout);
			if(nlsStrStr(PartOwnerNameS,"Vault")==NULL)
			{
				printf("\t ...this rev-seq not in vault hence skipping from download...\n"); fflush(stdout);
				continue;
			}

			if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
			printf("\nsetSize(docObjs): %d",setSize(docObjs));
			if(setSize(docObjs) > 0)
			{
				if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
				//printf("\nsetSize(latestDocs): %d",setSize(latestDocs));
				if (setSize(latestDocs)>0)
				{
					for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
					{
						docClass = low_getspace(10);

						docOPtr = setGet(latestDocs, noOfDocs);
						if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
						printf("\ndocClass: %s",docClass); fflush(stdout);

						//if((nlsStrCmp(docClass,"DesDoc") == 0))
						//{
							if(dstat = ExpandObject5(AttachClass,docOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP;
							if(setSize(DataItemJtSO)>0)
							{
								DataItClass = low_getspace(10);

								for(DataItem=0;DataItem<setSize(DataItemJtSO);DataItem++)
								{
									NewDataItemObjP=setGet(DataItemJtSO,DataItem);

									if(dstat = objGetClass(NewDataItemObjP, &DataItClass)) goto CLEANUP;
									printf("  DataItClass: %s",DataItClass); fflush(stdout);

									if((nlsStrCmp(docClass,"DesDoc") == 0) && ((nlsStrCmp(DataItClass,"ProAsm") == 0) || (nlsStrCmp(DataItClass,"ProPrt") == 0)) )
									//if((nlsStrCmp(docClass,"DesDoc") == 0) && (nlsStrStr(DataItClass,"ProAsm") !=NULL) )
									{
										if(dstat=GetInfoItem(NewDataItemObjP,&GetItemInfoObjP,mfail)) goto CLEANUP;

										if(dstat = objGetAttribute(GetItemInfoObjP,"OwnerName",&OwnerName)) goto CLEANUP;
										OwnerNameDup=nlsStrDup(OwnerName);

										if(nlsStrStr(OwnerNameDup,"Vault")==NULL)
										{
											continue;
										}

										if(dstat = objGetAttribute(GetItemInfoObjP,"RelativePath",&WorkingFileNm)) goto CLEANUP;
										WorkingFileNmDup=nlsStrDup(WorkingFileNm);

										if(dstat = objGetAttribute(GetItemInfoObjP,"Sequence",&Sequence)) goto CLEANUP;
										SequenceDup=nlsStrDup(Sequence);

										if(dstat = objGetAttribute(GetItemInfoObjP,"OwnerDirName",&OwnerDirName)) goto CLEANUP;
										OwnerDirNameDup=nlsStrDup(OwnerDirName);


										printf("\n%s,%s,%s,%s,%s,",WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
										fprintf(fp,"%s,%s,%s,%s,%s,\n",WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
									}
									else if((nlsStrCmp(docClass,"x0PrdDoc") == 0) )
									{
										printf("\ndocClass... %s,%s,%s,%s,",PartNumberS,PartRevisionS,PartSequenceS,docClass); fflush(stdout);
										fprintf(fpCDI,"%s,%s,%s,%s,\n",PartNumberS,PartRevisionS,PartSequenceS,docClass); fflush(stdout);
									}
								}
							}
						//} // if condn for docClass
					}
				}
			}
		} //for loop of setSize(PartResultSO)
	}
	//printf("\n");
	
/*
	//For latest part query
	if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
		(dstat = oiSqlWhereBegParen(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,SupersededAttr,"-"))||
		(dstat = oiSqlWhereEndParen(Sql_ptr))||
		(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
	if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartResultSO2,mfail)) goto EXIT;

	printf("\n (Release Vault) No:of Parts are :- %d\n",setSize(PartResultSO2));

	if((setSize(PartResultSO2)>0) && (ReleaseVaultFlag == 1))
	{
		TCPartSupObjP = setGet(PartResultSO2,0);

		t5CheckDstat(objGetAttribute(TCPartSupObjP,OwnerNameAttr,&PartOwnerNameDupS));
		PartOwnerNameS=nlsStrDup(PartOwnerNameDupS);

		printf("\nLatest superseded TC Part Owner Name is:%s",PartOwnerNameS); fflush(stdout);

		if(nlsStrCmp(PartOwnerNameS,"Release Vault")== 0)
		{
			goto CLEANUP;
		}
		else
		{
			t5CheckDstat(objGetAttribute(TCPartSupObjP,RevisionAttr,&PartRevisionDupS));
			PartRevisionS=nlsStrDup(PartRevisionDupS);

			printf("\t  LatestPartRevisionS: %s",PartRevisionS); fflush(stdout);

			if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
				(dstat = oiSqlWhereBegParen(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
				(dstat = oiSqlWhereAND(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,PartRevisionS))||
				(dstat = oiSqlWhereEndParen(Sql_ptr))||
				(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
			if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartResultSO3,mfail)) goto EXIT;

			if(setSize(PartResultSO3)>0)
			{
				ReleaseVaultFlag = 0;

				for(k=0;k<setSize(PartResultSO3);k++)
				{
					TCPartObjP=setGet(PartResultSO3,k);

					t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberDupS));
					PartNumberS=nlsStrDup(PartNumberDupS);

					t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&PartRevisionDupS));
					PartRevisionS=nlsStrDup(PartRevisionDupS);

					t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&PartSequenceDupS));
					PartSequenceS=nlsStrDup(PartSequenceDupS);
					
					printf("\nTCPart:::::[%s , %s , %s]",PartNumberS,PartRevisionS,PartSequenceS); fflush(stdout);

					if(!nlsIsStrNull(PartNumberS))
					{
						nlsStrCpy(PartRevSeq,"");

						nlsStrCpy(PartRevSeq,PartNumberS);
						nlsStrCat(PartRevSeq,"_");
						nlsStrCat(PartRevSeq,PartRevisionS);
						nlsStrCat(PartRevSeq,"_");
						nlsStrCat(PartRevSeq,PartSequenceS);
					}

					t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&PartOwnerNameDupS));
					PartOwnerNameS=nlsStrDup(PartOwnerNameDupS);
					printf("\t OwnerName is:%s",PartOwnerNameS); fflush(stdout);

					if(nlsStrStr(PartOwnerNameS,"Vault")==NULL)
					{
						printf("\t ...this rev-seq not in vault hence skipping from download...\n");  fflush(stdout);
						continue;
					}

					if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
					printf("\nsetSize(docObjs): %d",setSize(docObjs));
					if(setSize(docObjs) > 0)
					{
						if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
						//printf("\nsetSize(latestDocs): %d",setSize(latestDocs));
						if (setSize(latestDocs)>0)
						{
							for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
							{
								docClass = low_getspace(10);

								docOPtr = setGet(latestDocs, noOfDocs);
								if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
								printf("\ndocClass: %s",docClass); fflush(stdout);

								//if((nlsStrCmp(docClass,"DesDoc") == 0))
								//{
									if(dstat = ExpandObject5(AttachClass,docOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP;
									if(setSize(DataItemJtSO)>0)
									{
										DataItClass = low_getspace(10);

										for(DataItem=0;DataItem<setSize(DataItemJtSO);DataItem++)
										{
											NewDataItemObjP=setGet(DataItemJtSO,DataItem);

											if(dstat = objGetClass(NewDataItemObjP, &DataItClass)) goto CLEANUP;
											printf("  DataItClass: %s",DataItClass); fflush(stdout);

											if((nlsStrCmp(docClass,"DesDoc") == 0) && ((nlsStrCmp(DataItClass,"ProAsm") == 0) || (nlsStrCmp(DataItClass,"ProPrt") == 0)) )
											{
												if(dstat=GetInfoItem(NewDataItemObjP,&GetItemInfoObjP,mfail)) goto CLEANUP;

												if(dstat = objGetAttribute(GetItemInfoObjP,"RelativePath",&WorkingFileNm)) goto CLEANUP;
												WorkingFileNmDup=nlsStrDup(WorkingFileNm);

												if(dstat = objGetAttribute(GetItemInfoObjP,"Sequence",&Sequence)) goto CLEANUP;
												SequenceDup=nlsStrDup(Sequence);

												if(dstat = objGetAttribute(GetItemInfoObjP,"OwnerDirName",&OwnerDirName)) goto CLEANUP;
												OwnerDirNameDup=nlsStrDup(OwnerDirName);

												if(dstat = objGetAttribute(GetItemInfoObjP,"OwnerName",&OwnerName)) goto CLEANUP;
												OwnerNameDup=nlsStrDup(OwnerName);

												if(nlsStrStr(OwnerNameDup,"Vault")==NULL)
												{
													continue;
												}

												printf("\n%s,%s,%s,%s,%s,",WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
												fprintf(fp,"%s,%s,%s,%s,%s,\n",WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
											}
											else if((nlsStrCmp(docClass,"x0PrdDoc") == 0) )
											{
												printf("\ndocClass...%s, %s,%s,%s,%s,%s,",docClass,WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
												fprintf(fpCDI,"%s,%s,%s,%s,%s,\n",WorkingFileNmDup,SequenceDup,OwnerDirNameDup,OwnerNameDup,PartRevSeq); fflush(stdout);
											}
										}
									} //if(setSize(DataItemJtSO)>0)
								//} // if condn for docClass
							} // for loop end here
						} // if (setSize(latestDocs)>0)
					} // if(setSize(docObjs) > 0)
				} //for loop of setSize(PartResultSO)
			} // if(setSize(PartResultSO3)>0)
		} // else end here
	} // if((setSize(PartResultSO2)>0) && (ReleaseVaultFlag == 1))
*/
	fclose(fp);

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);
		t5FreeSetOfObjects(PartResultSO2);
		t5FreeSetOfObjects(PartResultSO3);
		t5FreeSqlPtr(Sql_ptr);

EXIT:
		t5CheckDstatAndReturn;
		return 0;
}
;
