######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	:	Rupali Rane
# Created on	:	Dec 5, 2016
# Project	:	Teamcenter 10.1
# Module	:	Proe CAD/JT Data Downloader
# Code		:	TmlcopyJTItems_allrev.sh
# Modified on	:
#
#######################################################################################
Vault_INFO_FILE="/user/omfprod/shells/cad/JT/JTShells/Vault_INFO"
LOCAL_IP=`hostname`
echo "Hello World....In TmlcopyJTItems_allrev.sh shell..."
while read jline
do
	if [ "$jline" = "" ];then
	continue
	fi
	chk_dirname=`echo $jline | cut -d\, -f3`
	TCPrtRevSeq=`echo $jline | cut -d\, -f6`
	TCPartNo=`echo $jline | cut -d\, -f7`
	CadDataItem=`echo $jline | cut -d\, -f8`
	f_partRev=`echo $TCPrtRevSeq | cut -d";" -f1`
	f_partSeq=`echo $TCPrtRevSeq | cut -d";" -f2`
	RevSeq="$f_partRev"_"$f_partSeq"
	if [ ! -z "$CadDataItem" ]
	then
		echo $CadDataItem | grep '<' >/dev/null 2>&1
		if [ "$?" -eq "0" ]; then
			#CadDataItem1="-"
			CadDataItem2="-"
		else
			#CadDataItem1=`echo "$CadDataItem" | cut -d"." -f1`
			CadDataItem2=`echo "$CadDataItem" | cut -d"." -f2`
		fi
	else
		#CadDataItem1="-"
		CadDataItem2="-"
	fi
	if [ "$chk_dirname" = "" ];then
		echo "Processing line: $jline"
		echo "No CAD/JT File to Copy"
	else
		chk_owner=`echo $jline | cut -d\, -f4`
		fname=`echo $jline | cut -d\, -f1 | sed 's/ /_/g'`
		jtname=`echo $jline | cut -d\, -f2`
		jtname=`basename $jtname`
		jtNm=`echo $jtname | cut -d"." -f1`
		if [[ "$jtname" =~ "_ALF" ]]
		then
			continue;
		fi
		m_path=""
		jtnameCp="$2/$RevSeq"_"$jtname"
		echo "Processing line: $jline"
		echo "    chk_owner   :  [$chk_owner]"
		echo "    TCPartNo    : " $TCPartNo
		#echo "    TCPrtRevSeq : " $TCPrtRevSeq
		echo "    RevSeq      : " $RevSeq
		echo "    fname       : " $fname
		echo "    CadDataItem2: " $CadDataItem2
		#if [[ "$jtname" =~ ".jt" ]]
		if [[ "$jtname" =~ ".jt" ]] || [[ "$fname" =~ ".pdf" ]]
		then
			echo "    chk_dirname : " $chk_dirname
			echo "    jtnameCp    : " $jtnameCp
			if [ ! -f $jtnameCp ]
			then
				echo "    JT is not present on path $2/$RevSeq_$jtname  hence copying"
				#if [[ "$fname" =~ "Vloc" ]]
				if [[ "$chk_dirname" =~ "Rel_Vault_Loc" ]]
				then
					cp /plm/REL/$fname $jtnameCp
					if [ $? == 1 ]
					then
						scp -rp plmhor01:/plm/REL/$fname $jtnameCp
						if [ $? == 1 ]
						then
							scp -rp plmlvls01:/plm/REL/$fname $jtnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/plm/REL/$fname $jtnameCp
								if [ $? == 1 ]
								then
									echo "    Vloc_Rel_JT.............................................Unable to copy JT [ $RevSeq_$jtname ] hence continueing  ?????????"
								else
									echo "    plmjapp1c1:Vloc_Rel_JT Data is copied for [ $RevSeq_$jtname ] "
								fi
							else
								echo "    plmlvls01:Vloc_Rel_JT Data is copied for [ $RevSeq_$jtname ] "
							fi
						else
							echo "    plmhor01:Vloc_Rel_JT Data is copied for [ $RevSeq_$jtname ] "
						fi
					else
						echo "    plmpapp2c3:Vloc_Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					fi
				elif [[ "$chk_dirname" =~ "CE" ]]
				then
					if [ "$chk_owner" = "CE Vault" ]
					then
						cp /plm/CE/$fname $jtnameCp
						if [ $? == 1 ]
						then
							echo "    plmpapp2c3:CE.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
						else
							echo "    plmpapp2c3:CE Data is copied for [ $RevSeq_$jtname ] "
							m_path="/plm/CE"
						fi
					else
						scp -rp plmhor01:/plm/HCE/$fname $jtnameCp
						if [ $? == 1 ]
						then
							scp -rp plmlvls01:/plm/LCE/$fname $jtnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/plm/JCE/$fname $jtnameCp
								if [ $? == 1 ]
								then
									echo "    ALL_CE.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
								else
									echo "    plmjapp1c1:JCE Data is copied for [ $RevSeq_$jtname ] "
									m_path="/plm/JCE"
								fi
							else
								echo "    plmlvls01:LCE Data is copied for [ $RevSeq_$jtname ] "
								m_path="/plm/LCE"
							fi
						else
							echo "    plmhor01:HCE Data is copied for [ $RevSeq_$jtname ] "
							m_path="/plm/HCE"
						fi
					fi
				elif [[ "$chk_dirname" =~ "WIP" ]]
				then
					if [[ "$chk_dirname" =~ "HNJ_WIP" ]]
					then
						scp -rp plmhor01:/proj/omfcadhwvault/HNJ_WIP_Vault_Loc/$fname $jtnameCp
						if [ $? == 1 ]
						then
							echo "    plmhor01:HNJ_WIP.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
						else
							echo "    plmhor01:HNJ_WIP Data is copied for [ $RevSeq_$jtname ] "
							m_path="/proj/omfcadhwvault/HNJ_WIP_Vault_Loc"
						fi
					elif [[ "$chk_dirname" =~ "LKN_WIP" ]]
					then
						scp -rp plmlvls01:/proj/omflkowvault/LKN_WIP_Vault_Loc/$fname $jtnameCp
						if [ $? == 1 ]
						then
							echo "    plmlvls01:LKN_WIP.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
						else
							echo "    plmlvls01:LKN_WIP Data is copied for [ $RevSeq_$jtname ] "
							m_path="/proj/omflkowvault/LKN_WIP_Vault_Loc"
						fi
					elif [[ "$chk_dirname" =~ "JSR_WIP" ]]
					then
						scp -rp plmjapp1c1:/proj/omfjsrwvault/JSR_WIP_Vault_Loc/$fname $jtnameCp
						if [ $? == 1 ]
						then
							echo "    JSR_WIP.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
						else
							echo "    plmjapp1c1:JSR_WIP Data is copied for [ $RevSeq_$jtname ] "
							m_path="/proj/omfjsrwvault/JSR_WIP_Vault_Loc"
						fi
					else
						cp /proj/omfcadpwvault/WIP_CAD/$fname $jtnameCp
						if [ $? == 1 ]
						then
							echo "    Else:WIP.............................................Unable to copy cad dataItem $RevSeq_$jtname hence continueing  ?????????"
						else
							echo "    plmpapp2c3:WIP Data is copied for [ $RevSeq_$jtname ] "
							m_path="/proj/omfcadpwvault/WIP_CAD"
						fi
					fi
				else
					cp /proj/omfcadjtvault/jt_cad/$fname $jtnameCp
					if [ $? == 1 ]
					then
						scp -rp plmhor01:/proj/omfcadhjtvault/jt_cad/$fname $jtnameCp
						if [ $? == 1 ]
						then
							scp -rp plmlvls01:/proj/omfcadljtvault/jt_cad/$fname $jtnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/proj/omfcadjjtvault/jt_cad/$fname $jtnameCp
								if [ $? == 1 ]
								then
									echo "    Rel_JT.............................................Unable to copy JT [ $RevSeq_$jtname ] hence continueing  ?????????"
								else
									echo "    plmjapp1c1:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
								fi
							else
								echo "    plmlvls01:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
							fi
						else
							echo "    plmhor01:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
						fi
					else
						echo "    plmpapp2c3:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					fi
				fi
				letter1=`echo $TCPartNo | cut -c1-1`
				#echo "    letter1     : " $letter1
				#if [[ "$jtname" =~ ".jt" ]] && [[ ( "$CadDataItem2" == "asm" ) || ( "$TCPartNo" =~ "G" ) || ( "$letter1" == "G" ) ]]
				if [[ "$jtname" =~ ".jt" ]] && [[ ( "$CadDataItem2" == "asm" ) || ( "$letter1" == "G" ) ]]
				then
					echo "    Converting ASSY JT for.......................  $jtnameCp"
					/user/omfprod/devgroups/UALoading/TMLtocmitest/PuneToTMETCProE/DeleteNode.sh "$jtnameCp" "$jtNm"
					if [ $? != 0 ]
					then
						echo "    Problem in DeleteNode.sh $f_partRev $f_partSeq $jtname"
						continue
					fi
					#rm -rf "$jtnameCp"
					mv "$jtnameCp" "$jtnameCp"_org
					mv "$jtNm"_new.jt "$jtnameCp"
				fi
			else
				echo "    ** JT is already present on path  [$2/$RevSeq_$jtname]"
			fi
		else
			#echo "    chk_dirname is :" $chk_dirname
			if [ "$chk_classname" = "ProPrtI" ];then
				chk_dirname="Rel_CAD_Vault_Loc"
				CadDIname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
			else
				if [ "$chk_classname" = "ProAsmI" ];then
				chk_dirname="Rel_CAD_Vault_Loc"
				CadDIname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
			else
				CadDIname=`echo $jline | cut -d\, -f1 | sed 's/ /_/g'`
			fi
			fi
			echo "    chk_dirname : " $chk_dirname
			echo "    CadDIname   : " $CadDIname
			fname=`echo $jline | cut -d\, -f2`
			fname=`basename $fname`
			echo "    fname is    : " $fname
			fnameCp="$2/$RevSeq"_"$jtname"
			echo "    fnameCp     : " $fnameCp
			if [ ! -f $fnameCp ]; then
				echo "    Copying CAD file as it is not present on path:  $fnameCp" 
				if [[ "$chk_dirname" =~ "CE" ]]
				then
					if [[ "$chk_owner" = "CE Vault" ]]
					then
						cp /plm/CE/$CadDIname $fnameCp
						if [ $? == 1 ]
						then
							echo "    plmpapp2c3:CE.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
						else
							echo "    plmpapp2c3:CE Data is copied for [ $CadDIname ] "
							m_path="/plm/CE"
						fi
					else
						scp -rp plmhor01:/plm/HCE/$CadDIname $fnameCp
						if [ $? == 1 ]
						then
							scp -rp plmlvls01:/plm/LCE/$CadDIname $fnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/plm/JCE/$CadDIname $fnameCp
								if [ $? == 1 ]
								then
									echo "    ALL_CE.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
								else
									echo "    plmjapp1c1:JCE Data is copied for [ $CadDIname ] "
									m_path="/plm/JCE"
								fi
							else
								echo "    plmlvls01:LCE Data is copied for [ $CadDIname ] "
								m_path="/plm/LCE"
							fi
						else
							echo "    plmhor01:HCE Data is copied for [ $CadDIname ] "
							m_path="/plm/HCE"
						fi
					fi
				elif [[ "$chk_dirname" =~ "WIP" ]]
				then
					if [[ "$chk_dirname" =~ "HNJ_WIP" ]]
					then
						scp -rp plmhor01:"/proj/omfcadhwvault/HNJ_WIP_Vault_Loc/$CadDIname" $fnameCp
						if [ $? == 1 ]
						then
							echo "    plmhor01:HNJ_WIP.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
						else
							echo "    plmhor01:HNJ_WIP Data is copied for [ $CadDIname ] "
							m_path="/proj/omfcadhwvault/HNJ_WIP_Vault_Loc"
						fi
					elif [[ "$chk_dirname" =~ "LKN_WIP" ]]
					then
						scp -rp plmlvls01:"/proj/omflkowvault/LKN_WIP_Vault_Loc/$CadDIname" $fnameCp
						if [ $? == 1 ]
						then
							echo "    plmlvls01:LKN_WIP.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
						else
							echo "    plmlvls01:LKN_WIP Data is copied for [ $CadDIname ] "
							m_path="/proj/omflkowvault/LKN_WIP_Vault_Loc"
						fi
					elif [[ "$chk_dirname" =~ "JSR_WIP" ]]
					then
						scp -rp plmjapp1c1:"/proj/omfjsrwvault/JSR_WIP_Vault_Loc/$CadDIname" $fnameCp
						if [ $? == 1 ]
						then
							echo "    JSR_WIP.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
						else
							echo "    plmjapp1c1:JSR_WIP Data is copied for [ $CadDIname ] "
							m_path="/proj/omfjsrwvault/JSR_WIP_Vault_Loc"
						fi
					else
						cp "/proj/omfcadpwvault/WIP_CAD/$CadDIname" $fnameCp
						if [ $? == 1 ]
						then
							echo "    Else:WIP.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
						else
							echo "    plmpapp2c3:WIP Data is copied for [ $CadDIname ] "
							m_path="/proj/omfcadpwvault/WIP_CAD"
						fi
					fi
				elif [[ "$chk_dirname" =~ "Rel_CAD_Vault_Loc" ]]
				then
					cp /proj/omfcadrvault/Rel_CAD/$CadDIname $fnameCp
					if [ $? == 1 ]
					then
						scp -rp plmlvls01:/proj/omfcadlrvault/Rel_CAD/$CadDIname $fnameCp
						if [ $? == 1 ]
						then
							scp -rp plmhor01:/proj/omfcadhrvault/Rel_CAD/$CadDIname $fnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/proj/omfcadjrvault/Rel_CAD/$CadDIname $fnameCp
								if [ $? == 1 ]
								then
									echo "    Rel_CAD.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
								else
									echo "    plmjapp1c1:Rel_CAD Data is copied for [ $CadDIname ] "
									m_path="/proj/omfcadjrvault/Rel_CAD"
								fi
							else
									echo "    plmhor01:Rel_CAD Data is copied for [ $CadDIname ] "
									m_path="/proj/omfcadhrvault/Rel_CAD"
							fi
						else
							echo "    plmlvls01:Rel_CAD Data is copied for [ $CadDIname ] "
							m_path="/proj/omfcadlrvault/Rel_CAD"
						fi
					else
						echo "    plmpapp2c3:Rel_CAD Data is copied for [ $CadDIname ] "
						m_path="/proj/omfcadrvault/Rel_CAD"
					fi
				elif [[ "$chk_dirname" =~ "Rel_Vault_Loc" ]]
				then
					cp /plm/REL/$CadDIname $fnameCp
					if [ $? == 1 ]
					then
						scp -rp plmhor01:/plm/REL/$CadDIname $fnameCp
						if [ $? == 1 ]
						then
							scp -rp plmlvls01:/plm/REL/$CadDIname $fnameCp
							if [ $? == 1 ]
							then
								scp -rp plmjapp1c1:/plm/REL/$CadDIname $fnameCp
								if [ $? == 1 ]
								then
									echo "    REL.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
								else
									echo "    plmjapp1c1:REL Data is copied for [ $CadDIname ] "
									m_path="/plm/REL"
								fi
							else
								echo "    plmlvls01:REL Data is copied for [ $CadDIname ] "
								m_path="/plm/REL"
							fi
						else
							echo "    plmhor01:REL Data is copied for [ $CadDIname ] "
							m_path="/plm/REL"
						fi
					else
						echo "    plmpapp2c3:REL Data is copied for [ $CadDIname ] "
						m_path="/plm/REL"
					fi
				else
					#if [[ "$fname" =~ ".pdf" ]]
					#then
					#	cp /proj/omfcadjtvault/jt_cad/$fname $jtnameCp
					#	if [ $? == 1 ]
					#	then
					#		scp -rp plmhor01:/proj/omfcadhjtvault/jt_cad/$fname $jtnameCp
					#		if [ $? == 1 ]
					#		then
					#			scp -rp plmlvls01:/proj/omfcadljtvault/jt_cad/$fname $jtnameCp
					#			if [ $? == 1 ]
					#			then
					#				scp -rp plmjapp1c1:/proj/omfcadjjtvault/jt_cad/$fname $jtnameCp
					#				if [ $? == 1 ]
					#				then
					#					echo "    PDF:Rel_JT.............................................Unable to copy JT [ $RevSeq_$jtname ] hence continueing  ?????????"
					#				else
					#					echo "    PDF:plmjapp1c1:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					#				fi
					#			else
					#				echo "    PDF:plmlvls01:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					#			fi
					#		else
					#			echo "    PDF:plmhor01:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					#		fi
					#	else
					#		echo "    PDF:plmpapp2c3:Rel_JT Data is copied for [ $RevSeq_$jtname ] "
					#	fi
					#else
						echo "    Else:.............................................Unable to copy cad dataItem $CadDIname hence continueing  ?????????"
					#fi
				fi
				if [[ "$CadDIname" =~ ".CAT" ]]
				then
					echo "    fname.cgr   : " $m_path/$fname.cgr
					if ls "$m_path/$fname.cgr" 1> /dev/null 2>&1; then
						echo "cgr file does exist"
						cp "$m_path/$fname.cgr" $fnameCp.cgr
					fi
				fi
			else
				echo "    ** CAD File is already present on path  [$fnameCp]"
			fi
		fi
	fi
	echo "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------"
done < "$1"
