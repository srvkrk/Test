################################################################################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author		: Rupali Rane
# Created on	: Nov 28, 2016
# Project       : Teamcenter 10.1
# Module		: TCUA Proe Sub Assembly Uploader
# Code          : TmlloadProeSubAssyData.sh
#
# Sr.No.	Modified_on		Modified_By			Remark
#     1.
#
#################################################################################################################################################
#cd "$1"
#pwd
mainDir=`pwd`
echo $mainDir
mainDir2=`basename $mainDir`
echo "mainDir2: $mainDir2"
if [ $mainDir2 == "$1" ]
then
	echo "1.mainDir:::::::::: $mainDir"
else
	cd "$1"
	mainDir=`pwd`
	echo "2.mainDir:::::::::: $mainDir"
fi
pwd
fileNm=GenericInstance.txt
echo "fileNm: $fileNm"
fileLhRh=LhRhPartDet.txt
echo "fileLhRh: $fileLhRh"
filename="to_load"
partfile=to_load_parts.txt
partfileNew=to_load_parts_new.txt
while read SubAssyPart
do
if [[ "$SubAssyPart" =~ "/" ]]
then
	continue
fi
if [ ! -d $SubAssyPart ]
then
	echo "*******TmlGetSubAssyProeData...Input:  $SubAssyPart  directory not present hence continued..."
	continue;
fi
if [ $SubAssyPart = $1 ]
then
	echo "*******TmlGetSubAssyProeData...Input:  $SubAssyPart = $1 directory hence continued..."
	continue;
fi
echo "*******TmlGetSubAssyProeData...Input: " $SubAssyPart
cd "$SubAssyPart"
AssyPwd=`pwd`
echo "**Going to upload Structure BOM and Dataset Releations.."
while read lineFld
do
echo "SubAssy..******************Input: " $lineFld
directory=`echo $lineFld |awk -F',' '{print $5}'`
if [ ! -d $directory ]
then
continue;
fi
PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
DirPartNm=`echo $PartDirName | cut -d"_" -f1`
DirPartRev=`echo $PartDirName | cut -d"_" -f2`
DirPartSeq=`echo $PartDirName | cut -d"_" -f3`
cd "$directory"
AssyRevPwd=`pwd`
echo "SubAssy..Working FolderName: $directory"
echo "SubAssy.....Creating DataSets For ProE_rrr Items..."
####Below is commented on 24.03.2018 to avoid duplicate generic dataset creation
#if [[ -f input.txt ]] && [[ ! -s input.txt ]]; then
#echo "input.txt File is empty"
#else
#/user/rrr05503/Shells/TmlDataSetLoadProE -i=input.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
##if [ $? != 0 ]
##then
##	echo "Problem in TmlDataSetLoadProE  $directory"
##	exit 1
##fi
#fi
if [ -s to_load_parts.txt -a -s to_load_parts_new.txt ]; then
echo "SubAssy.Bom files are present"
else
cd $AssyPwd
/user/rrr05503/Shells/BomAttrTextFileGenerate.sh $SubAssyPart
cd $AssyRevPwd
fi
echo "SubAssy.**Going to load IPEM Dependancy Relation.."
/user/rrr05503/Shells/TmlloadParts_IPEMRel -i=to_load_parts.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on
if [ $? != 0 ]
then
echo "SubAssy.Problem in TmlloadParts_IPEMRel structure  $directory"
exit 1
fi
echo "SubAssy.**Going to load Structure.."
/user/rrr05503/Shells/TmlloadParts -i=to_load_parts_new.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -o=on
if [ $? != 0 ]
then
echo "SubAssy.Problem in TmlloadParts structure  $directory"
exit 1
fi
#if test -s suppressedTruePartList.txt
#then
#PartNm=`echo $PartDirName | cut -d"_" -f1`
#PartRev=`echo $PartDirName | cut -d"_" -f2`
#PartSeq=`echo $PartDirName | cut -d"_" -f3`
#/user/rrr05503/Shells/UpdateBomLineSuppressAttr -i=$PartNm -j="$PartRev;$PartSeq" -k=$PartSeq -m="Design Revision" -f=suppressedTruePartList.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
#if [ $? != 0 ]
#then
#echo "Problem in SubAssy UpdateBomLineSuppressAttr  $directory"
#exit 1
#fi
#fi
#if [[ -f $fileNm ]] && [[ ! -s $fileNm ]]; then
#echo "11.SubAssy..GenericInstance File is empty" ;
#else
#echo "SubAssy.**Going to create generic-instance cad/dataset relation.."
#/user/rrr05503/Shells/TmlProEGeneric -i=GenericInstance.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
#if [ $? != 0 ]
#then
#echo "Problem in TmlProEGeneric  $directory"
#exit 1
#fi
#fi
if [[ -f $fileLhRh ]] && [[ ! -s $fileLhRh ]]; then
echo "11.SubAssy..LhRhPartDet File is empty  $directory" ;
else
echo "SubAssy.**Going to create LH-RH Design Master relation.."
/user/rrr05503/Shells/TmlLhRhRel -i=LhRhPartDet.txt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba
if [ $? != 0 ]
then
echo "SubAssy..Problem in TmlLhRhRel  $directory"
exit 1
fi
fi
echo "**Going to create ALF Dataset Relation.."
#/user/rrr05503/Shells/AlfJtLoad.sh "$SubAssyPart" "$directory"
nohup /user/rrr05503/Shells/AlfJtLoad.sh "$SubAssyPart" "$directory" > "$mainDir"/"$directory"_AlfJtLoad.log &
if [ $? != 0 ]
then
echo "SubAssy..Problem in AlfJtLoad.sh  $directory"
exit 1
fi
cd ..
done < $SubAssyPart.PartList.txt
cd ..
done < $1.SubAssyPartList.txt
