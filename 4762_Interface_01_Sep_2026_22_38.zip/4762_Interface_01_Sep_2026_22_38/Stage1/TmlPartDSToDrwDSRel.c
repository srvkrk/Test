/*****************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Rupali Rane
*  Module		 :   TCUA Proe Uploader
*  Code			 :   TmlPartDSToDrwDSRel.c (Part dataset to Drwing dataset)
*  Created on	 :   Oct 19, 2016
*
*
* Modification History :
* S.No  Date			CR No	Modified By					Modification Notes
*
*
******************************************************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

FILE* fp=NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}
extern int ITK_user_main (int argc, char ** argv )
{
    int status;
    int result;
	int n_tags_item;
	int n_attchs;
	int i = 0;
	int ItemDataSetFlag = 0;
	int DrwDataSetFlag = 0;
	int n_attchsDrw = 0;
	int DrwDataSetRelFlag = 0;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	char *inputfile=NULL;
	char* inputline=NULL;
	char* item_id=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* desc=NULL;
	char* parttype = NULL;
	char* projectcode = NULL;
	char* designgroup = NULL;
	char* mod_desc = NULL;
	char* DrawingNoS = NULL;
	char* DrawingNoDupS = NULL;
	char* Materialclass = NULL;
	char* DrawingIndDupS = NULL;
	char* DrawingIndS = NULL;
	char* itemRevSeq = NULL;
	char* DS_item_id = NULL;

	tag_t *tags_item = NULL;
	tag_t t_item = NULL;
	tag_t t_RevTag = NULL;
	tag_t tRel_ImanSpec = NULL;
	tag_t *SecObjs = NULL;
	tag_t t_SecObjType = NULL;
	tag_t t_ItemDataSet = NULL;
	tag_t t_DrwDataSet = NULL;
	tag_t tRel_CreoDrwModel = NULL;
	tag_t Fndrelation = NULL;
	tag_t tRel_DrwModel = NULL;
	tag_t *SecObjsDrw = NULL;

	char type_name[TCTYPE_name_size_c+1] ;
	char type_name2[TCTYPE_name_size_c+1] ;

//	ITK_CALL(ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	ITK_CALL(ITK_auto_login( ));
//	ITK_CALL(ITK_set_journalling( TRUE ));

	initialise();

	inputfile = ITK_ask_cli_argument("-i=");

	fp = fopen( inputfile, "r" );

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n---------------------------------------------------------------------------------------------------\n"); fflush(stdout);

			fputs(inputline,stdout);

			item_id=strtok(inputline,"^");			//1
			item_revision_id=strtok(NULL,"^");
			item_sequence_id=strtok(NULL,"^");
			desc=strtok(NULL,"^");
			parttype=strtok(NULL,"^");
			projectcode=strtok(NULL,"^");
			designgroup=strtok(NULL,"^");
			mod_desc=strtok(NULL,"^");
			DrawingNoS=strtok(NULL,"^");
			DrawingIndS=strtok(NULL,"^");			//10

			printf("item_id:[%s , %s , %s] DrawingIndS:[%s]  ",item_id,item_revision_id,item_sequence_id,DrawingIndS); fflush(stdout);

			if (strcmp(DrawingIndS,"N")!=0)
			{
				//Querying with item id
				attrs[0] ="item_id";
				values[0] = (char *)item_id;
				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_item, &tags_item));

				if(n_tags_item > 0)
				{
					t_item = tags_item[0];

					printf("Item Found \n"); fflush(stdout);

					itemRevSeq = NULL;
					itemRevSeq=(char *) MEM_alloc(32);
					strcpy(itemRevSeq,item_revision_id);
					strcat(itemRevSeq,";");
					strcat(itemRevSeq,item_sequence_id);
					//printf("2.itemRevSeq concated is --->%s\n\n",itemRevSeq);

					ITK_CALL(ITEM_find_revision(t_item, itemRevSeq, &t_RevTag));

					if(t_RevTag != NULLTAG)
					{
						result = GRM_find_relation_type("IMAN_specification", &tRel_ImanSpec);
						printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(tRel_ImanSpec != NULL)
						{
							if(GRM_list_secondary_objects_only(t_RevTag, tRel_ImanSpec ,&n_attchs, &SecObjs));
							printf("\n\t item_tag SecObjs list n_attchs: [%d]",n_attchs); fflush(stdout);

							if(n_attchs>0)
							{
								for (i=0; i < n_attchs; i++)
								{
									if(TCTYPE_ask_object_type(SecObjs[i],&t_SecObjType));
									if(TCTYPE_ask_name(t_SecObjType,type_name));
									printf("\n\t type_name:: %s ",type_name); fflush(stdout);

									if ((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0) || (strcmp(type_name,"ProDrw")==0))
									{
										if ((strcmp(type_name,"ProPrt")==0) || (strcmp(type_name,"ProAsm")==0))
										{
											t_ItemDataSet = SecObjs[i];

											ItemDataSetFlag = 1;
										}
										if (strcmp(type_name,"ProDrw")==0)
										{
											t_DrwDataSet = SecObjs[i];

											DrwDataSetFlag = 1;
										}
									}
									else if ((strcmp(type_name,"CMI2Part")==0) || (strcmp(type_name,"CMI2Product")==0) || (strcmp(type_name,"CMI2Drawing")==0))
									{
										printf("....Converted Doc type Found, hence skipping.");fflush(stdout);
									}
								} //for loop
								printf("\n\t ItemDataSetFlag:[%d]  DrwDataSetFlag:[%d] \n\t ",ItemDataSetFlag,DrwDataSetFlag); fflush(stdout);

								if ((ItemDataSetFlag == 1) && (DrwDataSetFlag == 1))
								{
									DrwDataSetRelFlag = 0;

									ITK_CALL(GRM_find_relation_type("Pro2_drawing_model",&tRel_CreoDrwModel ));

									if(tRel_CreoDrwModel != NULLTAG)
									{
										ITK_CALL(TCTYPE_ask_name(tRel_CreoDrwModel,type_name2));
										printf("\n\t DrwModel..Type Name:: %s ............",type_name2);fflush(stdout);
									}

									/*if (strcmp(item_id,DrawingNoS) != 0 )
									{
										if(GRM_list_secondary_objects_only(t_DrwDataSet, tRel_CreoDrwModel ,&n_attchsDrw, &SecObjsDrw));
										printf("\n\t n_attchsDrw: [%d]",n_attchsDrw); fflush(stdout);

										if (n_attchsDrw > 0)
										{
											for (i=0; i < n_attchsDrw; i++)
											{
												ITK_CALL(AOM_ask_value_string(SecObjsDrw[i],"object_string",&DS_item_id));

												if (strcmp(item_id,DS_item_id) == 0 )
												{
													printf("\n\t DrwModel..Reference Drawing Relation Already Exist.\n" ); fflush(stdout);
													DrwDataSetRelFlag = 1;
													break;
												}
											}
										}
									}
									if (DrwDataSetRelFlag == 0)
									{
										ITK_CALL( GRM_find_relation( t_DrwDataSet, t_ItemDataSet, tRel_CreoDrwModel ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n\t DrwModel..Relation Already Exist.\n" ); fflush(stdout);
											//printf("\n\t Relation Already Exist...hence deleting relation from t_DrwDataSet\n\n" ); fflush(stdout);
											//ITK_CALL(GRM_delete_relation(Fndrelation));
										}
										else
										{
											printf("\n\t DrwModel..GRM_create_relation before \n\t");fflush(stdout);
											ITK_CALL(GRM_create_relation(t_DrwDataSet, t_ItemDataSet, tRel_CreoDrwModel, NULLTAG, &tRel_DrwModel));
											printf("\n\t DrwModel..GRM_create_relation After \n\t");fflush(stdout);

											if(tRel_DrwModel != NULLTAG)
											{
												ITK_CALL(AOM_refresh (t_DrwDataSet,0));
												//printf(" DrwModel..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(tRel_DrwModel));
												printf("\n\t DrwModel..GRM_save_relation:\n\n");fflush(stdout);
											}
										}
									}*/

									if (strcmp(item_id,DrawingNoS) == 0 )
									{
										ITK_CALL( GRM_find_relation( t_DrwDataSet, t_ItemDataSet, tRel_CreoDrwModel ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n\t DrwModel..Relation Already Exist.\n" ); fflush(stdout);
											//printf("\n\t Relation Already Exist...hence deleting relation from t_DrwDataSet\n\n" ); fflush(stdout);
											//ITK_CALL(GRM_delete_relation(Fndrelation));
										}
										else
										{
											printf("\n\t DrwModel..GRM_create_relation before \n\t");fflush(stdout);
											ITK_CALL(GRM_create_relation(t_DrwDataSet, t_ItemDataSet, tRel_CreoDrwModel, NULLTAG, &tRel_DrwModel));
											printf("\n\t DrwModel..GRM_create_relation After \n\t");fflush(stdout);

											if(tRel_DrwModel != NULLTAG)
											{
												ITK_CALL(AOM_refresh (t_DrwDataSet,0));
												//printf(" DrwModel..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(tRel_DrwModel));
												printf("\n\t DrwModel..GRM_save_relation:\n\n");fflush(stdout);
											}
										}
									}
									else //reference condition
									{
										ITK_CALL( GRM_find_relation( t_DrwDataSet, t_RevTag, tRel_CreoDrwModel ,&Fndrelation));
										if(Fndrelation != NULLTAG)
										{
											printf("\n\t DrwModel..Reference Revision Relation Already Exist.\n" ); fflush(stdout);
											//printf("\n\t Relation Already Exist...hence deleting relation from t_DrwDataSet\n\n" ); fflush(stdout);
											//ITK_CALL(GRM_delete_relation(Fndrelation));
										}
										else
										{
											printf("\n\t DrwModel..Reference Revision GRM_create_relation before \n\t");fflush(stdout);
											ITK_CALL(GRM_create_relation(t_DrwDataSet, t_RevTag, tRel_CreoDrwModel, NULLTAG, &tRel_DrwModel));
											printf("\n\t DrwModel..Reference Revision GRM_create_relation After \n\t");fflush(stdout);

											if(tRel_DrwModel != NULLTAG)
											{
												ITK_CALL(AOM_refresh (t_DrwDataSet,0));
												//printf(" DrwModel..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(tRel_DrwModel));
												printf("\n\t DrwModel..Reference Revision GRM_save_relation:\n\n");fflush(stdout);
											}
										}
									}
								} //if ((ItemDataSetFlag == 1) && (DrwDataSetFlag == 1))
							} //if(n_attchs>0)
						} //if(tRel_ImanSpec != NULL)
					} //if(t_RevTag != NULLTAG)
				} //if(n_tags_item > 0)
			} //if (strcmp(DrawingIndS,"N")!=0)
			else
			{
				printf("....Non-drawing Part hence 'Creo drawing item' not updated..");fflush(stdout);
			}
		} //while(fgets(inputline,1000,fp)!=NULL)
	} //if(fp!=NULL)
	else
	{
		printf("\n Input file [ %s ] NOT FOUND....",inputfile); fflush(stdout);
	}

	printf("\n---------------------------------------------------------------------------------------------------\n"); fflush(stdout);

	ITK_CALL(POM_logout(false));
	return status;
}
