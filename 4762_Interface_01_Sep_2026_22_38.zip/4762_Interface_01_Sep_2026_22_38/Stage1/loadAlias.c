#include <stdlib.h>
#include <stdio.h>

#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>

#include <tccore/tctype.h>
#include <pom/pom/pom.h>
#include <property/propdesc.h>
#include <constants/constants.h>
#include <tccore/aom_prop.h>
#include <dataset.h>


#define ITEM_ID "1234567"
#define REV_ID "001"


#define ITK_CALL(X) 							\
		printf(#X);								\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			printf("\tSUCCESS\n");				\
		}										\

static int CreateItem(char*,char*,char*);

int ITK_user_main(int argc, char* argv[])
{
	int    status;
	char* message;
	char    *req_item;
	char    *user;
	char    *Pass;
	char    *Grp;
	char    *Rev;
	char    *Seq;

	ITK_initialize_text_services (0);

	ITK_CALL(ITK_auto_login ());

	ITK_set_journalling (TRUE);
	
	user = ITK_ask_cli_argument("-u=");
	Pass = ITK_ask_cli_argument("-p=");
	//Grp = ITK_ask_cli_argument("-g=");
	req_item = ITK_ask_cli_argument("-i=");
	Rev = ITK_ask_cli_argument("-r=");
	Seq = ITK_ask_cli_argument("-s=");
/* load -u=loader -p=abc   -i=2871ST005_wheelcover -r=NR -s=1
	/* Call your function(s) here.  */

	CreateItem(req_item,Rev,Seq);


	ITK_exit_module (TRUE);
	return status;
}




static int CreateItem( char* Item, char* Revsion, char* Seq )
{
	int		index, status;
	int		n_strings = 1;
	int		l_strings = 80;
	int		tempStrLength = 80;
	tag_t itemTag = NULLTAG;
        tag_t revTag   =NULLTAG;

//	tag_t	itemTypeTag, itemMstrTypeT	ag, itemRevTypeTag, itemRevMstrTypeTag,NewDataSetTag,DataSetTypeTag;
//	tag_t	itemCreInTag, itemMstrCreInTag, itemRevCreInTag, itemRevMstrCreInTag=NULLTAG;
	tag_t	newItemTag;
	tag_t	tRelationFind	= NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	tag_t	tRelationObj	= NULLTAG;

	char**	stringArray = NULL;
	char*	tempString = NULL;
	char*	NewClass = NULL;



	printf("\n passed parameters are : Item:%s and  Revsion :%s  and  Seq :%s\n", Item,Revsion,Seq );

	ITK_CALL(ITEM_create_item(Item,
                                        Item,
                                         "Design",
                                        Revsion,
                                          &itemTag,
                                          &revTag ));
	ITK_CALL(ITEM_save_item ( itemTag ));


	ITK_CALL( AOM_save(itemTag) );
	ITK_CALL( AOM_save(revTag) );




	return ITK_ok;
}
