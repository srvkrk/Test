/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Raghavendra B T
*  Module		 :   TCUA DataSet Uploader
*  Code			 :   DataSetLoad.c
*  Created on	 :   March 25th, 2015
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100



extern int ITK_user_main (int argc, char ** argv )
{

    int status;

	int						result											= 0;
	int						count											= 0;
	int						iCounter1										= 0;
	int						i												= 0;
	char					*value											= NULL;
	char					*argstring1										= NULL;
	char					*argstring2										= NULL;
	char					*argstring3										= NULL;

	char					*user										= NULL;
	char					*pass										= NULL;
	char					*group										= NULL;
	char					*RefNo										= NULL;

	char					*itemId											= NULL;
	char					*revisionID										= NULL;
	char					*ItmSeqID										= NULL;
	char					 JTFile[256];
	char					*JTFileDesc										= NULL;
	char					*JTFileSeq										= NULL;
	char					*CreatedDate									= NULL;
	char					*ModifyDate										= NULL;
	char					*fullPath										= NULL;
	char					*VaultLocation									= NULL;
	char					*HostName										= NULL;
	char					*Owner											= NULL;
	char					*ProjectCode									= NULL;
	char					*vault											= NULL;
	char					*InDatabase										= NULL;
	char					*Randomized										= NULL;
	char					*Superseded										= NULL;
	char					*Frozen											= NULL;
	char					*LifeCycleState									= NULL;
	char					*FileStatus										= NULL;
	char					*Externallymanaged								= NULL;
	char					*FileRegisteredBy								= NULL;
	char					*ShadowCopy										= NULL;
	char					*Categoryname									= NULL;
	char					*Sitename										= NULL;
	char					*WorkingFileName								= NULL;
	char					*WorkingpathFormat								= NULL;
	char					*BulkdataLocation								= NULL;

	char					*Bulkdata										= NULL;
	char					*DataBasename									= NULL;
	char					*PartSequence									= NULL;

	char					*Status											= NULL;
	char					*relation_input									= NULL;
	char					*file_type										= NULL;

	char					*error_Text										= NULL;
	tag_t					JTDataset										= NULLTAG;
	tag_t					relation_JTDataset								= NULLTAG;

	char  					line[500]										= {'\0'};
	FILE					*input											= NULL;
	char					*object_type									= NULL;
	char					*relation_form									= NULL;
	tag_t					t_item											= NULLTAG;
	tag_t					revision										= NULLTAG;
	tag_t					*status_list									= NULLTAG;
	tag_t					release_status									= NULLTAG;
	tag_t					revstatus										= NULLTAG;
	int						x												= 0;
	int						ref_count;
	tag_t					datasettype										= NULLTAG;
	tag_t					Newdataset										= NULLTAG;
	tag_t					tool											= NULLTAG;
	tag_t					filetag											= NULLTAG;
	char					**ref_list;
	char					pathbuff[1000];
    char					*creation_date									= NULL;
	char					*text											= NULL;
	tag_t					datasetAvl										= NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType										= 1;
	int						iCountSecondary									= 0;
	tag_t					*secondaryObjects								= NULL;

	date_t				    test											= NULLDATE;
	date_t					test1										    = NULLDATE;
	char					*o											    = NULL;
	char					result1 [ 10000 ] ;
	char					 result2 [ 10000 ] ;
	char					*f												=NULL;

	char					*test11											=NULL;
	char					*test12											=NULL;
	char					*test13											=NULL;
	char					*JTid											=NULL;
	char					*JTid1											=NULL;
	char					*Creator										=NULL;
	char					*aDatasetId										=NULL;
	char					*aDatasetRev										=NULL;
	char * parent_name ;
	char * dataset_name ;
	char * parent_revision_id ;
	int parent_sequence_id ;
	int ItmSeqID_int ;

	tag_t 	aDataset =NULLTAG;


	int ii,itemcount,j=0;
	int sPartNumberTokint=0;
	int c,t=0;
	tag_t item=NULLTAG;
	tag_t *rev=NULLTAG;
	char *format=NULL;
	char *StrWeightArrayMain1=NULL;
	tag_t relation_type, relation;

	char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
    char **values = (char **) MEM_alloc(2 * sizeof(char *));

	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	tag_t  reln_type = NULLTAG;
	int    n_attchs =0;
	int    Flag_1 =0;
	GRM_relation_t *rellist;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t Fndrelation = NULLTAG;
	int nameRef_cnt;
	tag_t *namRefObject = NULL;
    int  * nFound;
    int   nlFound;
    int   ds;
    int   ass = 0;
    tag_t **  datasets;


	int n_tags_found = 0;
	tag_t query = NULLTAG;
	tag_t	master		=	NULLTAG;
	tag_t *cntr_objects = NULL;
	tag_t	*t_item1		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	int n_entries = 3;
	int n_found = 1;
	int dd = 0;
	int org_seq_id_int=0;
	char *inputfile=NULL;
	tag_t *tags_found = NULL;
	char* inputline=NULL;
	tag_t	queryTag	= NULLTAG;
	int resultCount=0;
	tag_t item_tag = NULLTAG;
	char
		*qry_entries4[3] = {"Revision","Sequence Id","ID"},
        *qry_values4[3]	= {"*","*","*"};

	char *drawingnumber;
	FILE* fp=NULL;
	char *drawingtype;
	char *relationstr;
	char *user_data_1;
	//char *type_name;
	char  type_name[TCTYPE_name_size_c+1];
    char object_name[TCTYPE_name_size_c+1] ;

//	GRM_relation_t *rellist_ctprt;
//	tag_t primary_ctprt,objTypeTag_ctprt =NULLTAG;
//	char *type_name_ctprt;
//
//	GRM_relation_t *rellist_ctdrw ;
//	tag_t primary_ctdrw,objTypeTag_ctdrw =NULLTAG;
//	char *type_name_ctdrw;
//
////	GRM_relation_t *rellist_ctdro ;
//	tag_t primary_ctpro,objTypeTag_ctpro =NULLTAG;
//	char *type_name_ctpro;

	char *DataSetNm2 = NULL;
	char *DataSetNm = NULL;

	char
        *qry_entries3[1] = {"ID"},
        *qry_values3[1]	= {"*"};



	inputfile = ITK_ask_cli_argument("-i=");

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);


	//fp=fopen(inputfile,"r");
	//if(fp!=NULL)
	//{
		//inputline=(char *) MEM_alloc(500);
		//while(fgets(inputline,500,fp)!=NULL)
		//{
			//fputs(inputline,stdout);
			itemId=strtok(inputfile,"^");  //1
			revisionID=strtok(NULL,"^"); //2
			ItmSeqID=strtok(NULL,"^"); //3
			JTid1=strtok(NULL,"^"); //4
			fullPath=strtok(NULL,"^"); //5
			JTFileSeq=strtok(NULL,"^"); //6
			RefNo=strtok(NULL,"^"); //6

			printf("itemId is --->%s\n",itemId);
			printf("revisionID is --->%s\n",revisionID);
			printf("Seq is --->%s\n",ItmSeqID);
			printf("Name is --->%s\n",JTid1);
			printf("FullPath is --->%s\n",fullPath);
			printf("CAD Sequence is --->%s\n",JTFileSeq);
			printf("Ref No --->%s\n",RefNo);

			//attrs[0] ="item_id";
			//values[0] = (char *)itemId;

			//ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n After IFERR_REPORT : QRY_find \n");

			if (queryTag)
			{
				printf("Found Query\n");

			}
			else
			{
				printf("Not Found Query");
			}

			qry_values[0] = revisionID ;
			qry_values[1] = ItmSeqID;
			qry_values[2] = itemId;
			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));

			if(resultCount>0)
			{
				//item = tags_found[0];
				printf("Item already exists\n");
				//ITK_CALL(ITEM_find_revision(item,revisionID,&rev));
				//if(rev != NULLTAG)
				//{
					for (j=0;j<resultCount;j++ )
				   {

						item_tag = rev[j];

						if(RefNo != NULL)
					    {
                        if(strcmp(RefNo,"Ref") ==0)
					    {

							if(strstr(JTid1,".CATDrawing")!=NULL)
							{
								Flag_1=0;
								ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
								printf("\nTotal n attches =%d\n",n_attchs);

								for (i= 0; i < n_attchs; i++)
								{
									printf("\n Inside loop ..............");fflush(stdout);
									//primary=secondary_objects[i];
									primary=rellist[i].secondary;
									relationstr=rellist[i].the_relation;

									ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
									ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
									printf("\n Type Name:%s ..............",type_name);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
									printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
									if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"CMI2Drawing") ==0)
									{
									Flag_1 = 1;
									printf("\n Relationship already exist !!!!.......");fflush(stdout);
									break;
									}
								}

								if (Flag_1 == 0)
								{


//									result = AE_find_datasettype("CMI2Drawing", &datasettype);
									result = AE_find_datasettype("CMI2Drawing", &datasettype);
									printf("\nType found---->%d",result);fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
									printf("\nDataset created--->%s",JTid1);fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\nDataset format set--->%d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
									printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

									if (nameRef_cnt == 0)
									{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\nGot reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\nFile Imported--->%d",result);fflush(stdout);

									result = AOM_save(filetag);
									printf("\nFile saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(Newdataset,sPartNumberTokint);

									printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
									}
									result = GRM_find_relation_type("IMAN_reference", &relation_type);
									printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
									result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
									printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
									if(Fndrelation)
									{
										printf("\n\t Relation Already Exist.\n" );fflush(stdout);
									}
									else
									{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
									}
								}
							}
						}
					}

					else ///// NON REFERENCE
					{

						if(strstr(JTid1,".jt")!=NULL)
						{

						    Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"DirectModel") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{

								result = AE_find_datasettype("DirectModel", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

						        result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);


								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);
								result = AOM_save(Newdataset);

								}

								result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
								}
								}
						}

	                 	if(strstr(JTid1,".CATPart")!=NULL)
						{

							if(strstr(JTid1,"Spec")!=NULL)
							{

						    Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{
							    result = AE_find_datasettype("CMI2AuxPart", &datasettype);
								printf("\nType found---->11%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
								}

								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
								}
								}

								}
							else ////For NON Spec files
							{

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"CMI2Part") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{

								result = AE_find_datasettype("CMI2Part", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
								}

								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
								}

								}
							 }

						}

						if(strstr(JTid1,".CATProduct")!=NULL)
						{
							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"CMI2Product") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("CMI2Product", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
								}
								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
                                result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
								}
								}

						}

						if(strstr(JTid1,".CATDrawing")!=NULL)
						{
							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"CMI2Drawing") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("CMI2Drawing", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								result = AOM_save(Newdataset);
								printf("\n Dataset seve--->%d",result);fflush(stdout);fflush(stdout);
								}

								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
								}
								}
						}

						if(strstr(JTid1,".pdf")!=NULL)
						{

						Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\nTotal n attches =%d\n",n_attchs);

							for (i= 0; i < n_attchs; i++)
							{
								printf("\n Inside loop ..............");fflush(stdout);
								//primary=secondary_objects[i];
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
								printf("\n Type Name:%s ..............",type_name);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n parent_name:%s ..............",parent_name);fflush(stdout);
								if(strcmp(parent_name,JTid1)==0 &&  strcmp(type_name,"PDF") ==0)
								{
								Flag_1 = 1;
								printf("\n Relationship already exist !!!!.......");fflush(stdout);
								break;
								}
							}

							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("PDF", &datasettype);
								printf("\nType found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,JTid1,JTFileDesc, NULL, NULL, &Newdataset);
								printf("\nDataset created--->%s",JTid1);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\nDataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****Spec Cat..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\nGot reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\nFile Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\nFile saved--->%d",result);fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\nAE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\nTool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
								}
								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d",result); fflush(stdout);
								if(Fndrelation)
								{
									printf("\n\t Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n GRM_save_relation ---->%d",result);fflush(stdout);
						        }
								}

						}
				 }
			}
				//}
			}
		//}
	//}
	ITK_CALL(POM_logout(false));
	return status;
}
