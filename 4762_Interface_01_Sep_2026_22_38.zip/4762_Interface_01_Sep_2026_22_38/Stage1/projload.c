#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <form/form.h>
#include <tccore/aom.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom_prop.h>
#include <sa/tcfile.h>
#include <tc/preferences.h>
#include <ae/ae.h>
#include <user_exits/user_exits.h>
#include <ae/datasettype.h>
#include <time.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <mechatronics/psconnection.h>
#include <tccoreext/gde.h>
#include <mechatronics/gdelink.h>
#include <tccore/tctype.h>
#include <ecm/ecm.h>
#include <ae/nxsm.h>
#include <tccore/grm.h>
#include <me/me.h>
#include <math.h>
#include <fclasses/tc_date.h>
#include <itk/mem.h>
#include <tccore/item_errors.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok)return ifail;
#ifdef WNT
#include <windows.h>
#include <mapiwin.h>
#include <winbase.h>
#endif
#ifdef UNX
#include <pwd.h>
#include <unistd.h>
#include <sys/statvfs.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#endif


static int
PrintErrorStack(
    void                      /* Utility function for error reporting */
);

#define Debug TRUE

#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                      \
                        for( index=0; index<n_ifails; index++)                                     \
                        {                                                                          \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                          \
                        return status;                                                             \
                }                                                                                  \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }                                                                               \




extern int ITK_user_main( int argc, char **argv )
{
	/*START VARIABLE DECLARATION*/
	char *file1 = NULL;
	char *Filename = NULL;
	char *DmlNumberDup = NULL;
	char *Parentsequence_id = NULL;
	char *ItemDesc = NULL;
	char *ItemRevDesc = NULL;
	char *PriorLevel = NULL;
	char *ReqDesc = NULL;
	char *reqtype = NULL;
	char *ReqOwneratt = NULL;
	char *Reqatt = NULL;
	char *level=NULL;
	char *inputfile=NULL;
	char *projid=NULL;
	char *projname=NULL;
	char *projdesc=NULL;
	char *inputline=NULL;

       int status = 0;         

	char  type_name[TCTYPE_name_size_c+1];
	char  Rev_name[TCTYPE_name_size_c+1];
	char  secondtype_name[TCTYPE_name_size_c+1];

	

	int ifail;
	int n_items=0;
	int n_attchs=0;
	int cnt=0;
	int TotalCount=0;
	int RevCnt=0;
	int all=0;

	tag_t	*item_tags		= NULL;
    tag_t    item = NULLTAG;
	tag_t	*secondary_objects		= NULLTAG;
	tag_t	user_data		= NULLTAG;
	tag_t	*relist		= NULLTAG;
	tag_t	*RelationShip		= NULLTAG;
	tag_t	Rel_type		= NULLTAG;
	tag_t	reln_type= NULLTAG;
	tag_t	objType;
	tag_t	primary;
	tag_t	tReqItem		= NULLTAG;
	tag_t	second;
	tag_t	secondobjType;
	tag_t	RevType;

	GRM_relation_t **  secondary_listl;
	GRM_relation_t **  relsecondary_listl;
	//char DmlNumberDup[];

	FILE *fp1;
	FILE *fp2;

	tag_t   *pTagAttch;
	/*END OF VAIABLE DECLARATION*/

     ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
     ITK_CALL(ITK_auto_login( ));
	 ITK_CALL(ITK_set_journalling( TRUE ));

	
	Filename=malloc(30000);
	inputfile=ITK_ask_cli_argument("-i=");

	fp1=fopen(inputfile,"r");
	fp2=fopen("error.log","a");
	if(fp1!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,500,fp1)!=NULL)
		{
			fputs(inputline,stdout);
			projid=strtok(inputline,"^");
			projname=strtok(NULL,"^");
			projdesc=strtok(NULL,"^");
			//item_sequence_id=strtok(NULL,"^");

			printf ("\n 11111111111111\n");
	ITK_CALL(PROJ_create_project( projid,projname,projdesc,&tReqItem ));
	printf ("\n 222222222222222\n");

                                               
                                }

                 }

	
	

	//fclose (fp1);
}
