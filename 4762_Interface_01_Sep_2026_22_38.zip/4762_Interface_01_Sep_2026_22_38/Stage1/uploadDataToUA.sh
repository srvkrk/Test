######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	  : Aniket P. Kadu
# Created on	  : August 01, 2011
# Project         : Teamcenter 8.3 Trilix
#
#######################################################################################


username="loader"
password="abc"

##rm -fr $1
cp -R /tmp/Data/$1 .
./UploadMetaData.sh $1 $username $password
cd $1
#ls *.jt > jtlist.txt

errorcnt=`cat error.log | wc -l`
if [ $errorcnt -eq 0 ];then
	echo "Meta Data Loaded...." >> failure.log
../UploadDataItems.sh $1 $username $password
	cd ..
else
	echo "Structure creation failed" >> failure.log
	cd ..
	exit 1
fi


###rm -fr $1
