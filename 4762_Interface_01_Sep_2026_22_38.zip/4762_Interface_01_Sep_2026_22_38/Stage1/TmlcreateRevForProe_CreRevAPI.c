/*****************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Aniket P. Kadu / Sharvari / Rupali / Dayanand
*  Module		 :   TCUA Proe Uploader
*  Code			 :   TmlcreateRevForProe.c
*  Created on	 :   Jan 10, 2012
*
*
* Modification History :
* S.No  Date			CR No	Modified By					Modification Notes
*   1.	11.07.2015				skk03433/rrr05503/			All revisions creation is handled using check-out/check-in.
*
*	2.	12.05.2016				rrr05503					New logic of Revision-Sequence is modified
*															instead of check-out/check-in.
*															More attributes are added and set on Design revision.
*
*
******************************************************************************************************************/
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>
#include <unistd.h>
#include <time.h>
/*#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/imanfile.h>
#include <ss/ss_errors.h>
#include <sa/user.h>*/
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCWORKING	"T5_LcsWorking"
#define ERCREVIEW	"T5_LcsReview"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define STDRELEASED "TCM Released"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\
unsigned int sleep(unsigned int seconds);

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
        int i;
        char *retStringf;
        retStringf = (char*) malloc(3);
        for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
        *(retStringf+i) = '\0';
        return retStringf;
}
static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

	printf("  ---return from validate_date....\n");

    return retcode;
}
int AssignProject(tag_t  itemRev,char* projectcode)
{

	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

	// ITK_CALL(AOM_lock(itemRev));
	printf("\n\t projectcode [%s]\n",projectcode);fflush(stdout);
	ITK_CALL (PROJ_find(projectcode,&projobj));
	//printf("\n\t Assigned to Project \n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	//   ITK_CALL(AOM_save(itemRev));
	//  ITK_CALL(AOM_unlock(itemRev));

	return status;
}
int setDateAttributesOnItemRev(tag_t rev_t,char* CreDateTempS,char* LastModDateS,char* CreatorS,char* LastModByS)
{
	int status = 0;
	int retcode = ITK_ok;  // Function return code
	int retcode2 = ITK_ok; // Function return code

	ITK_initialize_text_services (0);

	char* Year = NULL;
    char* Month	= NULL;
    char* Day = NULL;
    char* Hours	= NULL;
    char* Min = NULL;
    char* Sec = NULL;
    char* MicroSec = NULL;
    char* PrtCreDateS = NULL;
	char* Year2 = NULL;
    char* Month2	= NULL;
    char* Day2 = NULL;
    char* Hours2	= NULL;
    char* Min2 = NULL;
    char* Sec2 = NULL;
    char* MicroSec2 = NULL;
	char* lastModByDateS = NULL;

	//char userid[SA_user_size_c+1];

	date_t creationDate_D;
	date_t lastModByDate_D;
    logical date_is_valid = FALSE;   // Date Validation

	logical bypass = TRUE;

	tag_t user_tag = NULLTAG;
	tag_t creator_tag = NULLTAG;
	tag_t lastModBy_tag = NULLTAG;
	
	PrtCreDateS = ( char * ) MEM_alloc(30);
	lastModByDateS = ( char * ) MEM_alloc(30);

	printf("\nCreDateTempS:[%s]  LastModDateS:[%s]\n",CreDateTempS,LastModDateS); fflush(stdout);


	if(strlen(CreDateTempS)> 1)
	{
		ITK_CALL(AOM_lock(rev_t));

		Year=strtok(CreDateTempS,"/");
		Month=strtok(NULL,"/");
		Day=strtok(NULL,"-");
		Hours=strtok(NULL,":");
		Min=strtok(NULL,":");
		Sec=strtok(NULL,":");
		MicroSec=strtok(NULL,":");

		//printf("\n..1..%s",Year); fflush(stdout);
		strcpy(PrtCreDateS,"");
		strcpy(PrtCreDateS,Year);
		strcat(PrtCreDateS,"/");
		//printf("\n..2..%s",Month); fflush(stdout);
		strcat(PrtCreDateS,Month);
		strcat(PrtCreDateS,"/");
		//printf("\n..3..%s",Day); fflush(stdout);
		strcat(PrtCreDateS,Day);
		strcat(PrtCreDateS,"-");
		//printf("\n..4..%s",Hours); fflush(stdout);
		strcat(PrtCreDateS,Hours);
		strcat(PrtCreDateS,":");
		//printf("\n..5..%s",Min); fflush(stdout);
		strcat(PrtCreDateS,Min);
		strcat(PrtCreDateS,":");
		//printf("\n..6..%s",Sec); fflush(stdout);
		strcat(PrtCreDateS,Sec);

		printf("New Creation Date is --> [%s]",PrtCreDateS); fflush(stdout);
		
		retcode = validate_date( PrtCreDateS , &date_is_valid , &creationDate_D );
		if ( retcode != ITK_ok )
		{
			printf ( " Creation Date--error code %d\n\n", retcode); fflush(stdout);
			return EXIT_FAILURE;
		}

		////strcpy (userid, "cmitest");
		////ITK_CALL(SA_find_user(userid , &user_tag));

		//ITK_CALL(POM_get_user(&CreatorS, &creator_tag));
		//printf("\n CreatorS::: %s \n",CreatorS); fflush(stdout);

		ITK_CALL ( POM_set_creation_date(rev_t, creationDate_D));
		//ITK_CALL ( POM_set_owning_user(rev_t, creator_tag));
	}

	if(strlen(LastModDateS)> 1)
	{
		Year2=strtok(LastModDateS,"/");
		Month2=strtok(NULL,"/");
		Day2=strtok(NULL,"-");
		Hours2=strtok(NULL,":");
		Min2=strtok(NULL,":");
		Sec2=strtok(NULL,":");
		MicroSec2=strtok(NULL,":");

		//printf("\n..11..%s",Year2); fflush(stdout);
		strcpy(lastModByDateS,"");
		strcpy(lastModByDateS,Year2);
		strcat(lastModByDateS,"/");
		//printf("\n..12..%s",Month2); fflush(stdout);
		strcat(lastModByDateS,Month2);
		strcat(lastModByDateS,"/");
		//printf("\n..13..%s",Day2); fflush(stdout);
		strcat(lastModByDateS,Day2);
		strcat(lastModByDateS,"-");
		//printf("\n..14..%s",Hours2); fflush(stdout);
		strcat(lastModByDateS,Hours2);
		strcat(lastModByDateS,":");
		//printf("\n..15..%s",Min2); fflush(stdout);
		strcat(lastModByDateS,Min2);
		strcat(lastModByDateS,":");
		//printf("\n..16..%s",Sec2); fflush(stdout);
		strcat(lastModByDateS,Sec2);

		printf("\nNew ModByDate is --> [%s]",lastModByDateS); fflush(stdout);
		
		retcode2 = validate_date( lastModByDateS , &date_is_valid , &lastModByDate_D );
		if ( retcode2 != ITK_ok )
		{
			printf ( "  ModByDate--error code %d\n\n", retcode2); fflush(stdout);
			return EXIT_FAILURE;
		}
		//printf("\nSuccessfully validated function validate_date...\n"); fflush(stdout);

		//ITK_CALL(POM_get_user(&LastModByS, &lastModBy_tag));
		//printf("\n LastModByS::: %s \n",LastModByS); fflush(stdout);

		ITK_CALL( ITK_set_bypass ( bypass ) );
		ITK_CALL ( POM_set_modification_date(rev_t, lastModByDate_D));
		//ITK_CALL ( POM_set_modification_user(rev_t, lastModBy_tag));
		ITK_CALL(POM_set_env_info( POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "" ) );
	}
	else if(strlen(CreDateTempS)> 1)
	{
		ITK_CALL( ITK_set_bypass ( bypass ) );
		ITK_CALL ( POM_set_modification_date(rev_t, creationDate_D));
		//ITK_CALL ( POM_set_modification_user(rev_t, creator_tag));
		ITK_CALL(POM_set_env_info( POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "" ) );
	}

	if(strlen(CreDateTempS)> 1)
	{
		ITK_CALL(AOM_save(rev_t));
		ITK_CALL(AOM_unlock(rev_t));
	}

	return 0;
}
int setAttributesOnItemRev(tag_t* rev,char* desc)
{
	int status;

	printf("\nIn function setAttributesOnItemRev\n");
	//ITK_CALL(AOM_lock(*rev));
	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",desc));
	ITK_CALL(AOM_save(*rev));
	//ITK_CALL(AOM_unlock(*rev));
}
int setAttributesOnDesignRev(tag_t* rev,char* parttype,char* projectcode,char* designgroup,char* mod_desc,char* DrawingNoS,char* DrawingIndS,char* Materialclass,char* MaterialInDrwS,char* MaterialThickNessS,char* DeignOwnUnitS,char* ModelIndS,char* ColourIndS,char* t5ColourIDS,char* WeightS,char* desc,char* t5SpareIndS,char* t5CMVRCertificationS,char* t5ClassificationHazS,char* t5ConfigIDS,char* t5DismantableS,char* t5DsgnDeptS,char* t5EnvelopeDimenS,char* t5HazardousContS,char* t5HomologationReqdS,char* t5ListRecSparesS,char* t5NcPartNoS,char* t5PartCodeS,char* t5PartPropertyS,char* t5PartStatusS,char* t5PkgStdS,char* t5ProductS,char* t5PrtCatCodeS,char* t5PunIntialAgS,char* t5PunMakeBuyIndS,char* t5RecoverableS,char* t5RecyclabilityS,char* t5RefPartNumberS,char* t5ReliabilityS,char* t5SpareCriteriaS,char* t5SurfPrtStdS,char* t5SamplesToApprS,char* t5AsmDisposalS,char* t5FinDisposalInstrS,char* t5RPDisposalInstrS,char* t5SPDisposalInstrS,char* t5WIPDisposalInstrS,char* t5LastModByS,char* t5VerCreatorS,char* t5CAEDocES,char* t5CoatedS,char* t5ConvDocS,char* t5AplCopyOfErcRevS,char* t5AplCopyOfErcSeqS,char* t5AppCodeS,char* t5RqstNumS,char* t5RsnCodeS,char* t5SurfaceAreaS,char* t5VolumeS,char* t5CarIntialAgencyS,char* t5CarMakeBuyIndiS,char* t5ErcIndNameS,char* t5PostRelReqS,char* t5ItmCategoryS,char* t5CopReqS,char* t5AplInvalidateS,char* t5PrtValiStatusS,char* t5DRSubStateS,char* t5KnxtDocIndS,char* t5SimValS,char* t5PerYieldS,char* t5PunStoreLocationS,char* t5AltPartNoS,char* t5RolledupWtS,char* t5PFDModReqdS,char* t5ToolIndentReqdS,char* CategoryNameS, char* LeftRhS, char* LeftRh_item_id, char* LeftRh_item_id2 , char* t5JsrIntialAgencyS, char* t5JsrMakeBuyIndiS, char* t5LkoIntialAgencyS, char* t5LkoMakeBuyIndiS, char* t5PnrIntialAgencyS, char* t5PnrMakeBuyIndiS, char* t5PunPCBUIntialAgencyS, char* t5PunPCBUMakeBuyIndiS, char* t5SgrIntialAgencyS, char* t5SgrMakeBuyIndiS,char* t5EstSheetReqdS,char* t5AhdIntialAgencySDup,char* t5AhdMakeBuyIndSDup,char* t5DwdIntialAgencySDup,char* t5DwdMakeBuyIndSDup,char* t5JdlIntialAgencySDup,char* t5JdlMakeBuyIndSDup,char* t5AhdStoreLocSDup,char* t5CarStoreLocSDup,char* t5DwdStoreLocSDup,char* t5JdlStoreLocSDup,char* t5JsrStoreLocSDup,char* t5LkoStoreLocSDup,char* t5PnrStoreLocSDup,char* t5PunPCBUStoreLocSDup,char* t5SgrStoreLocSDup)
{
	int status;
	int ITKresult = 0;
	double dweight=0;
	tag_t projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char *ItemId = NULL;
	char *ItemRevSeq=NULL;
	//char* username=NULL;
	char* mod_desc2=NULL;
	char* t5SimValS2=NULL;
	char* t5SurfPrtStdS2=NULL;

	//printf("\n  In setAttributesOnDesignRev Function");fflush(stdout);

	AOM_lock(*rev);

	if( AOM_ask_value_string(*rev,"item_id",&ItemId)!=ITK_ok);
	if( AOM_ask_value_string(*rev,"item_revision_id",&ItemRevSeq)!=ITK_ok);


	ITK_CALL (PROJ_find(projectcode,&projobj));
	if(projobj !=NULLTAG)
	{
		printf("\n Valid Project found....setting attributes on Design Revision");fflush(stdout);

		/*POM_get_user(&username,&user_tag);
		printf("\n  Login username:%s\n",username);fflush(stdout);
		ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,rev ));
		printf("\n  Assigned to Project\n");fflush(stdout);*/

		//mod_desc2=(char *) MEM_alloc(240 * sizeof(char *));
		//t5SimValS2=(char *) MEM_alloc(33 * sizeof(char *));
		//t5SurfPrtStdS2=(char *) MEM_alloc(15 * sizeof(char *));

		//strncpy(mod_desc2,mod_desc,239);
		//mod_desc2[strlen(mod_desc2)] = '\0';

		//strncpy(t5SimValS2,t5SimValS,31);
		//t5SimValS2[strlen(t5SimValS2)] = '\0';

		//strncpy(t5SurfPrtStdS2,t5SurfPrtStdS,15);
		//t5SurfPrtStdS2[strlen(t5SurfPrtStdS2)] = '\0';

		mod_desc2 = NULL;
		mod_desc2=(char *) MEM_alloc(240);
		tc_strncpy(mod_desc2,mod_desc,239);
		mod_desc2[tc_strlen(mod_desc2)] = '\0';

		t5SimValS2 = NULL;
		t5SimValS2=(char *) MEM_alloc(32);
		tc_strncpy(t5SimValS2,t5SimValS,31);
		t5SimValS2[tc_strlen(t5SimValS2)] = '\0';

		t5SurfPrtStdS2 = NULL;
		t5SurfPrtStdS2=(char *) MEM_alloc(15);
		tc_strncpy(t5SurfPrtStdS2,t5SurfPrtStdS,14);
		t5SurfPrtStdS2[tc_strlen(t5SurfPrtStdS2)] = '\0';


		/*if ((strstr(Materialclass,"Ferrous metal and alloys") != NULL) && (strcmp(subString(Materialclass,0,3),"Nn-")!=0))
		{
			strcpy(Materialclass,"");
			strcpy(Materialclass,"Ferrous metal & alloys");
			printf("\n  New Materialclass Attribute value::[%s]\n",Materialclass);fflush(stdout);
		}
		else if (strstr(Materialclass,"Nylon based") != NULL)
		{
			strcpy(Materialclass,"");
			strcpy(Materialclass,"Nylon/PA");
			printf("\n  New Materialclass Attribute value::[%s]\n",Materialclass);fflush(stdout);
		}*/
		//printf("\n  setAttributesOnDesignRev...desc:[%s]",desc);fflush(stdout);

		ITKresult = AOM_set_value_string(*rev,"object_desc",desc);		//Part Description
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---Nomenclature/Description is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---Nomenclature/Description is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,desc); fflush(stdout); }


		if((tc_strcmp(t5AltPartNoS," ")!=0) && (tc_strcmp(t5AltPartNoS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_AltPartNo",t5AltPartNoS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_AltPartNo is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_AltPartNo is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AltPartNoS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_AltPartNo is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AltPartNoS); fflush(stdout);
		}

		ITKresult = AOM_set_value_string(*rev,"t5_AplCopyOfErcRev",t5AplCopyOfErcRevS);	//string[3]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_AplCopyOfErcRev is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_AplCopyOfErcRev is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AplCopyOfErcRevS); fflush(stdout); }

		ITKresult = AOM_set_value_string(*rev,"t5_AplCopyOfErcSeq",t5AplCopyOfErcSeqS);	//string[5]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_AplCopyOfErcSeq is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_AplCopyOfErcSeq is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AplCopyOfErcSeqS); fflush(stdout); }

		ITKresult = AOM_set_value_string(*rev,"t5_AplInvalidate",t5AplInvalidateS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_AplInvalidate is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_AplInvalidate is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AplInvalidateS); fflush(stdout); }

		if((tc_strcmp(t5CarIntialAgencyS," ")!=0) && (tc_strcmp(t5CarIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_CarIntialAgency",t5CarIntialAgencyS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_CarIntialAgency is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_CarIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CarIntialAgencyS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_CarIntialAgency is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CarIntialAgencyS); fflush(stdout);
		}

		if((tc_strcmp(t5CarMakeBuyIndiS," ")!=0) && (tc_strcmp(t5CarMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_CarMakeBuyIndicator",t5CarMakeBuyIndiS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_CarMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_CarMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CarMakeBuyIndiS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_CarMakeBuyIndicator is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CarMakeBuyIndiS); fflush(stdout);
		}
		
		if((tc_strcmp(t5ConfigIDS," ")!=0) && (tc_strcmp(t5ConfigIDS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ConfigID",t5ConfigIDS);	//change its name right now it is ConfigID
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ConfigID is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ConfigID is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ConfigIDS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_ConfigID is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ConfigIDS); fflush(stdout);
		}
		
		if((tc_strcmp(t5ColourIDS," ")!=0) && (tc_strcmp(t5ColourIDS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_ColourID is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_ColourID is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ColourIDS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_ColourID is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ColourIDS); fflush(stdout);
		}
		
		ITKresult = AOM_set_value_string(*rev,"t5_DesignGrp",designgroup);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_DesignGrp is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_DesignGrp is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,designgroup); fflush(stdout); }
		
		if((tc_strcmp(DrawingNoS," ")!=0) && (tc_strcmp(DrawingNoS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_DrawingNo is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_DrawingNo is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,DrawingNoS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_DrawingNo is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,DrawingNoS); fflush(stdout);
		}
		
		if(t5DRSubStateS!=NULL)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_DRSubState",t5DRSubStateS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_DRSubState is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_DRSubState is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5DRSubStateS); fflush(stdout); }
		}

		if(DeignOwnUnitS!=NULL)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_DsgnOwn is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_DsgnOwn is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,DeignOwnUnitS); fflush(stdout); }
		}

		//ITK_CALL(AOM_save(*rev));
		
		if(t5ErcIndNameS!=NULL)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ErcIndName",t5ErcIndNameS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ErcIndName is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ErcIndName is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ErcIndNameS); fflush(stdout); }
		}

		if(t5EnvelopeDimenS!=NULL)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_EnvelopeDimensions",t5EnvelopeDimenS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_EnvelopeDimensions is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_EnvelopeDimensions is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5EnvelopeDimenS); fflush(stdout); }
		}

		if(t5EstSheetReqdS!=NULL)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_EstSheetReqd",t5EstSheetReqdS);	//srting[32]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_EstSheetReqd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_EstSheetReqd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5EstSheetReqdS); fflush(stdout); }
		}

		if((tc_strcmp(t5HomologationReqdS," ")!=0) && (tc_strcmp(t5HomologationReqdS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_HomologationReqd",t5HomologationReqdS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_HomologationReqd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_HomologationReqd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5HomologationReqdS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_HomologationReqd is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5HomologationReqdS); fflush(stdout);
		}

		if((tc_strcmp(t5ItmCategoryS," ")!=0) && (tc_strcmp(t5ItmCategoryS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ItmCategory",t5ItmCategoryS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_ItmCategory is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_ItmCategory is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ItmCategoryS); fflush(stdout); }
		}

		if((tc_strcmp(t5KnxtDocIndS," ")!=0) && (tc_strcmp(t5KnxtDocIndS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_KnxtDocInd",t5KnxtDocIndS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_KnxtDocInd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_KnxtDocInd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5KnxtDocIndS); fflush(stdout); }
		}

		if((tc_strcmp(MaterialInDrwS," ")!=0) && (tc_strcmp(MaterialInDrwS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_Material",MaterialInDrwS);	//Part Material
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_Material is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_Material is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,MaterialInDrwS); fflush(stdout); }
		}
		if((tc_strcmp(MaterialThickNessS," ")!=0) && (tc_strcmp(MaterialThickNessS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_MThickness",MaterialThickNessS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_MThickness is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_MThickness is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,MaterialThickNessS); fflush(stdout); }
		}
		if((tc_strcmp(t5NcPartNoS," ")!=0) && (tc_strcmp(t5NcPartNoS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_NcPartNo",t5NcPartNoS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_NcPartNo is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_NcPartNo is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5NcPartNoS); fflush(stdout); }
		}
		if((tc_strcmp(t5PartCodeS," ")!=0) && (tc_strcmp(t5PartCodeS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS);	//srting[2]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PartCode is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PartCode is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PartCodeS); fflush(stdout); }
		}
		if((tc_strcmp(parttype," ")!=0) && (tc_strcmp(parttype,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PartType",parttype);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PartType is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PartType is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,parttype); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_PartType is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,parttype); fflush(stdout);
		}
		if((tc_strcmp(t5PartPropertyS," ")!=0) && (tc_strcmp(t5PartPropertyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PartProperty",t5PartPropertyS);	//srting[40]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PartProperty is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PartProperty is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PartPropertyS); fflush(stdout); }
		}
		if((tc_strcmp(t5PFDModReqdS," ")!=0) && (tc_strcmp(t5PFDModReqdS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PFDModReqd",t5PFDModReqdS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PFDModReqd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PFDModReqd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PFDModReqdS); fflush(stdout); }
		}
		if((tc_strcmp(t5PerYieldS," ")!=0) && (tc_strcmp(t5PerYieldS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PerYield",t5PerYieldS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PerYield is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PerYield is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PerYieldS); fflush(stdout); }
		}
		if((tc_strcmp(t5PkgStdS," ")!=0) && (tc_strcmp(t5PkgStdS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PkgStd",t5PkgStdS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PkgStd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PkgStd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PkgStdS); fflush(stdout); }
		}
		if((tc_strcmp(t5ProductS," ")!=0) && (tc_strcmp(t5ProductS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_Product",t5ProductS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_Product is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_Product is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ProductS); fflush(stdout); }
		}
		if((tc_strcmp(t5PrtCatCodeS," ")!=0) && (tc_strcmp(t5PrtCatCodeS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PrtCatCode is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PrtCatCode is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PrtCatCodeS); fflush(stdout); }
		}
		if((tc_strcmp(t5PrtValiStatusS," ")!=0) && (tc_strcmp(t5PrtValiStatusS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PrtValiStatus",t5PrtValiStatusS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PrtValiStatus is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PrtValiStatus is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PrtValiStatusS); fflush(stdout); }
		}
		if((tc_strcmp(t5PunIntialAgS," ")!=0) && (tc_strcmp(t5PunIntialAgS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PunIntialAgency",t5PunIntialAgS);	//change PNR Initial Agency
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PunIntialAgency is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PunIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PunIntialAgS); fflush(stdout); }
		}
		if((tc_strcmp(t5PunMakeBuyIndS," ")!=0) && (tc_strcmp(t5PunMakeBuyIndS,"")!=0))
		{	
			ITKresult = AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS);	//Change PNR make buy
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PunMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PunMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PunMakeBuyIndS); fflush(stdout); }
		}

		if((tc_strcmp(t5PunStoreLocationS," ")!=0) && (tc_strcmp(t5PunStoreLocationS,"")!=0))
		{	
			ITKresult = AOM_set_value_string(*rev,"t5_PunStoreLocation",t5PunStoreLocationS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_PunStoreLocation is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_PunStoreLocation is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PunStoreLocationS); fflush(stdout); }
		}
		if((tc_strcmp(t5RefPartNumberS," ")!=0) && (tc_strcmp(t5RefPartNumberS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_RefPartNumber",t5RefPartNumberS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_RefPartNumber is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_RefPartNumber is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RefPartNumberS); fflush(stdout); }
		}
		if((tc_strcmp(t5RolledupWtS," ")!=0) && (tc_strcmp(t5RolledupWtS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_RolledupWt",t5RolledupWtS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_RolledupWt is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_RolledupWt is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RolledupWtS); fflush(stdout); }
		}
		if((tc_strcmp(t5RqstNumS," ")!=0) && (tc_strcmp(t5RqstNumS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_RqstNum",t5RqstNumS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_RqstNum is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_RqstNum is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RqstNumS); fflush(stdout); }
		}
		if((tc_strcmp(t5RsnCodeS," ")!=0) && (tc_strcmp(t5RsnCodeS,"")!=0))
		{	
			ITKresult = AOM_set_value_string(*rev,"t5_RsnCode",t5RsnCodeS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_RsnCode is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_RsnCode is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RsnCodeS); fflush(stdout); }
		}
		if((tc_strcmp(t5SurfPrtStdS2," ")!=0) && (tc_strcmp(t5SurfPrtStdS2,"")!=0))
		{	
			ITKresult = AOM_set_value_string(*rev,"t5_SurfPrtStd",t5SurfPrtStdS2);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SurfPrtStd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SurfPrtStd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SurfPrtStdS2); fflush(stdout); }
		}
		if((tc_strcmp(t5ToolIndentReqdS," ")!=0) && (tc_strcmp(t5ToolIndentReqdS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ToolIndentReqd",t5ToolIndentReqdS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_ToolIndentReqd is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_ToolIndentReqd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ToolIndentReqdS); fflush(stdout); }
		}
		if((tc_strcmp(t5VerCreatorS," ")!=0) && (tc_strcmp(t5VerCreatorS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_VerCreator",t5VerCreatorS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_VerCreator is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_VerCreator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5VerCreatorS); fflush(stdout); }
		}
		if(WeightS!=NULL)
		{
			dweight=atof(WeightS);
			ITKresult = AOM_set_value_double(*rev,"t5_Weight",dweight);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_Weight is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_Weight is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,dweight); fflush(stdout); }
		}

		//ITK_CALL(AOM_save(*rev));

		if(tc_strcmp(LeftRhS,"NA")!=0)
		{
			if((tc_strstr(LeftRhS,"LH")!=NULL) && (strlen(LeftRh_item_id) > 11))
			{
				ITKresult = AOM_set_value_string(*rev,"t5_leftPart",LeftRh_item_id);
					if(ITKresult == 0)
					{ printf("\n  SUCCESS---1. t5_leftPart is set on Design Revision.");fflush(stdout); }
					else
					{ printf("\n  FAILED---1. t5_leftPart is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,LeftRh_item_id); fflush(stdout); }

				ITKresult = AOM_set_value_string(*rev,"t5_rightPart",LeftRh_item_id2);
					if(ITKresult == 0)
					{ printf("\n  SUCCESS---1. t5_rightPart is set on Design Revision.");fflush(stdout); }
					else
					{ printf("\n  FAILED---1. t5_rightPart is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,LeftRh_item_id2); fflush(stdout); }
			}
			if((tc_strstr(LeftRhS,"RH")!=NULL) && (strlen(LeftRh_item_id) > 11))
			{
				ITKresult = AOM_set_value_string(*rev,"t5_leftPart",LeftRh_item_id2);
					if(ITKresult == 0)
					{ printf("\n  SUCCESS---2. t5_leftPart is set on Design Revision.");fflush(stdout); }
					else
					{ printf("\n  FAILED---2. t5_leftPart is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,LeftRh_item_id2); fflush(stdout); }

				ITKresult = AOM_set_value_string(*rev,"t5_rightPart",LeftRh_item_id);
					if(ITKresult == 0)
					{ printf("\n  SUCCESS---2. t5_rightPart is set on Design Revision.");fflush(stdout); }
					else
					{ printf("\n  FAILED---2. t5_rightPart is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,LeftRh_item_id); fflush(stdout); }
			}
		}

		//Below properties are added on 14.10.2016 by RRR
		if((tc_strcmp(t5DsgnDeptS," ")!=0) && (tc_strcmp(t5DsgnDeptS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_DsgnDept",t5DsgnDeptS);	//srting[30]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_DsgnDept is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_DsgnDept is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5DsgnDeptS); fflush(stdout); }
		}
		if((tc_strcmp(t5JsrIntialAgencyS," ")!=0) && (tc_strcmp(t5JsrIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_JsrIntialAgency",t5JsrIntialAgencyS);				//srting[6]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_JsrIntialAgency is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_JsrIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5JsrIntialAgencyS); fflush(stdout); }
		}
		if((tc_strcmp(t5JsrMakeBuyIndiS," ")!=0) && (tc_strcmp(t5JsrMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_JsrMakeBuyIndicator",t5JsrMakeBuyIndiS);			//srting[32]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_JsrMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_JsrMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5JsrMakeBuyIndiS); fflush(stdout); }
		}
		if((tc_strcmp(t5LkoIntialAgencyS," ")!=0) && (tc_strcmp(t5LkoIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_LkoIntialAgency",t5LkoIntialAgencyS);				//srting[6]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_LkoIntialAgency is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_LkoIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5LkoIntialAgencyS); fflush(stdout); }

		}
		if((tc_strcmp(t5LkoMakeBuyIndiS," ")!=0) && (tc_strcmp(t5LkoMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_LkoMakeBuyIndicator",t5LkoMakeBuyIndiS);			//srting[32]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_LkoMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_LkoMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5LkoMakeBuyIndiS); fflush(stdout); }

		}
		if((tc_strcmp(ModelIndS," ")!=0) && (tc_strcmp(ModelIndS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ModelIndicator",ModelIndS);						//srting[1]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ModelIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ModelIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,ModelIndS); fflush(stdout); }

		}
		if((tc_strcmp(t5PnrIntialAgencyS," ")!=0) && (tc_strcmp(t5PnrIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PnrIntialAgency",t5PnrIntialAgencyS);				//srting[6]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PnrIntialAgency is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PnrIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PnrIntialAgencyS); fflush(stdout); }

		}
		if((tc_strcmp(t5PnrMakeBuyIndiS," ")!=0) && (tc_strcmp(t5PnrMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PnrMakeBuyIndicator",t5PnrMakeBuyIndiS);			//srting[32]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PnrMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PnrMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PnrMakeBuyIndiS); fflush(stdout); }

		}
		if((tc_strcmp(t5PunPCBUIntialAgencyS," ")!=0) && (tc_strcmp(t5PunPCBUIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PunPCBUIntialAgency",t5PunPCBUIntialAgencyS);		//srting[6]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PunPCBUIntialAgency is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PunPCBUIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PunPCBUIntialAgencyS); fflush(stdout); }

		}
		if((tc_strcmp(t5PunPCBUMakeBuyIndiS," ")!=0) && (tc_strcmp(t5PunPCBUMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndiS);	//srting[32]
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PunPCBUMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PunPCBUMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PunPCBUMakeBuyIndiS); fflush(stdout); }

		}
		if((tc_strcmp(t5ReliabilityS," ")!=0) && (tc_strcmp(t5ReliabilityS,"")!=0))
		{
			ITKresult = AOM_set_value_double(*rev,"t5_Reliability",t5ReliabilityS);						//Double
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_Reliability is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_Reliability is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ReliabilityS); fflush(stdout); }

		}
		if((tc_strcmp(t5SgrIntialAgencyS," ")!=0) && (tc_strcmp(t5SgrIntialAgencyS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_SgrIntialAgency",t5SgrIntialAgencyS);				//srting[6]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SgrIntialAgency is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SgrIntialAgency is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SgrIntialAgencyS); fflush(stdout); }
		}
		if((tc_strcmp(t5SgrMakeBuyIndiS," ")!=0) && (tc_strcmp(t5SgrMakeBuyIndiS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_SgrMakeBuyIndicator",t5SgrMakeBuyIndiS);			//srting[30]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SgrMakeBuyIndicator is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SgrMakeBuyIndicator is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SgrMakeBuyIndiS); fflush(stdout); }
		}
		if((tc_strcmp(t5SpareCriteriaS," ")!=0) && (tc_strcmp(t5SpareCriteriaS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_SpareCriteria",t5SpareCriteriaS);	//srting[40]
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SpareCriteria is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SpareCriteria is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SpareCriteriaS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_SpareCriteria is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SpareCriteriaS); fflush(stdout);
		}
		if((tc_strcmp(t5SurfaceAreaS," ")!=0) && (tc_strcmp(t5SurfaceAreaS,"")!=0))
		{
			ITKresult = AOM_set_value_double(*rev,"t5_SurfaceArea",t5SurfaceAreaS);						//Double
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SurfaceArea is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SurfaceArea is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SurfaceAreaS); fflush(stdout); }

		}
		if((tc_strcmp(t5VolumeS," ")!=0) && (tc_strcmp(t5VolumeS,"")!=0))
		{
			ITKresult = AOM_set_value_double(*rev,"t5_Volume",t5VolumeS);								//Double
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_Volume is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_Volume is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5VolumeS); fflush(stdout); }
		}
		ITK_CALL(AOM_save(*rev));

		if((tc_strcmp(projectcode," ")!=0) && (tc_strcmp(projectcode,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ProjectCode",projectcode);			//ProjectCode
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_ProjectCode is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_ProjectCode is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,projectcode); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_ProjectCode is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,projectcode); fflush(stdout);
		}

		ITK_CALL(AOM_save(*rev));

		if((tc_strcmp(Materialclass," ")!=0) && (tc_strcmp(Materialclass,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_MatlClass",Materialclass);		//values not present in LOV hence cannot update
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_MatlClass is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_MatlClass is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,Materialclass); fflush(stdout); }
		}
		printf("\n  t5SimValS2: [%s]",t5SimValS2);fflush(stdout);
		if((tc_strcmp(t5SimValS2," ")!=0) && (tc_strcmp(t5SimValS2,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_SimVal",t5SimValS2);	 //Uncomment added on 06.01.2018	Do not have LOV. Attr with simple test string 32 length
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---Addon Desc/t5_SimVal is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---Addon Desc/t5_SimVal is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,t5SimValS2); fflush(stdout); }
		}
		ITK_CALL(AOM_save(*rev));
		
		if((tc_strcmp(mod_desc2," ")!=0) && (tc_strcmp(mod_desc2,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc2);	//comment added on 12.12.2017  commented as LOV not matching
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---ModDesc/t5_DocRemarks is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---ModDesc/t5_DocRemarks is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,mod_desc2); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---ModDesc/t5_DocRemarks is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,mod_desc2); fflush(stdout);
		}

		// Logical/Boolean Attributes
		if((tc_strcmp(t5SpareIndS," ")!=0) && (tc_strcmp(t5SpareIndS,"")!=0))
		{	
			if(tc_strcmp(t5SpareIndS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_SpareInd",true);	//boolean
			}
			else if (tc_strcmp(t5SpareIndS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_SpareInd",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_SpareInd [%s] is set on Design Revision. ",t5SpareIndS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_SpareInd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SpareIndS); fflush(stdout); }
		}
		if((tc_strcmp(t5CAEDocES," ")!=0) && (tc_strcmp(t5CAEDocES,"")!=0))
		{
			if(tc_strcmp(t5CAEDocES,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CAEDocE",true);	//boolean
			}
			else if (tc_strcmp(t5CAEDocES,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CAEDocE",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_CAEDocE [%s] is set on Design Revision.",t5CAEDocES);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_CAEDocE is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CAEDocES); fflush(stdout); }
		}
		if((tc_strcmp(t5CMVRCertificationS," ")!=0) && (tc_strcmp(t5CMVRCertificationS,"")!=0))
		{
			if(tc_strcmp(t5CMVRCertificationS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",true);	//boolean
			}
			else if (tc_strcmp(t5CMVRCertificationS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_CMVRCertificationReqd [%s] is set on Design Revision.",t5CMVRCertificationS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_CMVRCertificationReqd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CMVRCertificationS); fflush(stdout); }
		}
		if((tc_strcmp(t5ConvDocS," ")!=0) && (tc_strcmp(t5ConvDocS,"")!=0))
		{
			if(tc_strcmp(t5ConvDocS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_ConvDoc",true);	//boolean
			}
			else if (tc_strcmp(t5ConvDocS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_ConvDoc",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ConvDoc [%s] is set on Design Revision.",t5ConvDocS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ConvDoc is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ConvDocS); fflush(stdout); }
		}
		if((tc_strcmp(t5CopReqS," ")!=0) && (tc_strcmp(t5CopReqS,"")!=0))
		{
			if(tc_strcmp(t5CopReqS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CopReq",true);	//boolean
			}
			else if (tc_strcmp(t5CopReqS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_CopReq",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_CopReq [%s] is set on Design Revision.",t5CopReqS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_CopReq is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CopReqS); fflush(stdout); }
		}
		if((tc_strcmp(t5DismantableS," ")!=0) && (tc_strcmp(t5DismantableS,"")!=0))
		{
			if(tc_strcmp(t5DismantableS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Dismantable",true);	//boolean
			}
			else if (tc_strcmp(t5DismantableS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Dismantable",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_Dismantable [%s] is set on Design Revision.",t5DismantableS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_Dismantable is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5DismantableS); fflush(stdout); }
		}
		if((tc_strcmp(t5HazardousContS," ")!=0) && (tc_strcmp(t5HazardousContS,"")!=0))
		{
			if(tc_strcmp(t5HazardousContS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_HazardousContents",true);	//boolean
			}
			else if (tc_strcmp(t5HazardousContS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_HazardousContents",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_HazardousContents [%s] is set on Design Revision.",t5HazardousContS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_HazardousContents is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5HazardousContS); fflush(stdout); }
		}
		if((tc_strcmp(t5ListRecSparesS," ")!=0) && (tc_strcmp(t5ListRecSparesS,"")!=0))
		{
			if(tc_strcmp(t5ListRecSparesS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_ListRecSpares",true);	//boolean
			}
			else if (tc_strcmp(t5ListRecSparesS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_ListRecSpares",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ListRecSpares [%s] is set on Design Revision.",t5ListRecSparesS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ListRecSpares is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5ListRecSparesS); fflush(stdout); }
		}
		if((tc_strcmp(t5PostRelReqS," ")!=0) && (tc_strcmp(t5PostRelReqS,"")!=0))
		{
			if(tc_strcmp(t5PostRelReqS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_PostRelReq",true);	//boolean
			}
			else if (tc_strcmp(t5PostRelReqS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_PostRelReq",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PostRelReq [%s] is set on Design Revision.",t5PostRelReqS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PostRelReq is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PostRelReqS); fflush(stdout); }

		}
		if((tc_strcmp(t5RecoverableS," ")!=0) && (tc_strcmp(t5RecoverableS,"")!=0))
		{
			if(tc_strcmp(t5RecoverableS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Recoverable",true);	//boolean
			}
			else if (tc_strcmp(t5RecoverableS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Recoverable",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_Recoverable [%s] is set on Design Revision.",t5RecoverableS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_Recoverable is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RecoverableS); fflush(stdout); }

		}
		if((tc_strcmp(t5RecyclabilityS," ")!=0) && (tc_strcmp(t5RecyclabilityS,"")!=0))
		{
			if(tc_strcmp(t5RecyclabilityS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Recyclability",true);	//boolean
			}
			else if (tc_strcmp(t5RecyclabilityS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_Recyclability",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_Recyclability [%s] is set on Design Revision.",t5RecyclabilityS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_Recyclability is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RecyclabilityS); fflush(stdout); }

		}
		if((tc_strcmp(t5SamplesToApprS," ")!=0) && (tc_strcmp(t5SamplesToApprS,"")!=0))
		{
			if(tc_strcmp(t5SamplesToApprS,"+")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_SamplesToAppr",true);	//boolean
			}
			else if (tc_strcmp(t5SamplesToApprS,"-")==0)
			{
				ITKresult = AOM_set_value_logical(*rev,"t5_SamplesToAppr",false);	//boolean
			}
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_SamplesToAppr [%s] is set on Design Revision.",t5SamplesToApprS);fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_SamplesToAppr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SamplesToApprS); fflush(stdout); }
		}

		ITK_CALL(AOM_save(*rev));
		
		
		//Attributes with LOV values
		if(strcmp(t5AppCodeS," ")==0)
		{
			ITKresult = AOM_set_value_string(*rev,"t5_AppCode","NA");
		}
		else
		{
			ITKresult = AOM_set_value_string(*rev,"t5_AppCode",t5AppCodeS);
		}
		if(ITKresult == 0)
		{ printf("\n  SUCCESS---t5_AppCode is set on Design Revision.");fflush(stdout); }
		else
		{ printf("\n  FAILED---t5_AppCode is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5AppCodeS); fflush(stdout); }

		ITKresult = AOM_set_value_string(*rev,"t5_Coated",t5CoatedS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_Coated is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_Coated is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5CoatedS); fflush(stdout); }

		ITKresult = AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ColourInd is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ColourInd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,ColourIndS); fflush(stdout); }

		if((tc_strcmp(t5AsmDisposalS," ")!=0) && (tc_strcmp(t5AsmDisposalS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_AsmDisposalInstr",t5AsmDisposalS);	//comment added on 12.12.2017  commented as LOV not matching
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_AsmDisposalInstr is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_AsmDisposalInstr is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,t5AsmDisposalS); fflush(stdout); }
		}
		if((tc_strcmp(t5FinDisposalInstrS," ")!=0) && (tc_strcmp(t5FinDisposalInstrS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_FinDisposalInstr",t5FinDisposalInstrS);	//comment added on 12.12.2017  commented as LOV not matching
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_FinDisposalInstr is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_FinDisposalInstr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5FinDisposalInstrS); fflush(stdout); }
		}
		if((tc_strcmp(t5RPDisposalInstrS," ")!=0) && (tc_strcmp(t5RPDisposalInstrS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_RPDisposalInstr",t5RPDisposalInstrS);	//comment added on 12.12.2017  commented as LOV not matching
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_RPDisposalInstr is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_RPDisposalInstr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5RPDisposalInstrS); fflush(stdout); }
		}
		if((tc_strcmp(t5WIPDisposalInstrS," ")!=0) && (tc_strcmp(t5WIPDisposalInstrS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_WIPDisposalInstr",t5WIPDisposalInstrS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_WIPDisposalInstr is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_WIPDisposalInstr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5WIPDisposalInstrS); fflush(stdout); }
		}
		if((tc_strcmp(t5SPDisposalInstrS," ")!=0) && (tc_strcmp(t5SPDisposalInstrS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_SPDisposalInstr",t5SPDisposalInstrS);
				if(ITKresult == 0)
				{ printf("\n  SUCCESS---t5_SPDisposalInstr is set on Design Revision.");fflush(stdout); }
				else
				{ printf("\n  FAILED---t5_SPDisposalInstr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5SPDisposalInstrS); fflush(stdout); }
		}

		ITKresult = AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS);
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_DrawingInd is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_DrawingInd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,DrawingIndS); fflush(stdout); }

		if((tc_strcmp(t5ClassificationHazS," ")!=0) && (tc_strcmp(t5ClassificationHazS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_ClassificationHazardous",t5ClassificationHazS);	//srting[40]	//values not present in LOV hence cannot update
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_ClassificationHazardous is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_ClassificationHazardous is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,t5ClassificationHazS); fflush(stdout); }
		}
		if((tc_strcmp(t5PartStatusS," ")!=0) && (tc_strcmp(t5PartStatusS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS);		//srting[40]	//values not present in LOV hence cannot update
			if(ITKresult == 0)
			{ printf("\n  SUCCESS---t5_PartStatus is set on Design Revision.");fflush(stdout); }
			else
			{ printf("\n  FAILED---t5_PartStatus is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,t5PartStatusS); fflush(stdout); }
		}
		else
		{
			printf("\n  AttrValBlank---t5_PartStatus is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,t5PartStatusS); fflush(stdout);
		}

		if((tc_strcmp(CategoryNameS," ")!=0) && (tc_strcmp(CategoryNameS,"")!=0))
		{
			ITKresult = AOM_set_value_string(*rev,"t5_CategoryName",CategoryNameS);		//LOV not present as in PLM
			if(ITKresult == 0)
			{
				printf("\n  SUCCESS---t5_CategoryName/Keyword Description is set on Design Revision.");fflush(stdout);
			}
			else
			{
				printf("\n  FAILED---t5_CategoryName/Keyword Description is not set on Design Revision  ??? due to LOV or too long Length [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout);
			}
		}
		else
		{
			printf("\n  AttrValBlank---t5_CategoryName/Keyword Description is not set on Design Revision as blank  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout);
		}

		//ITKresult = AOM_set_value_string(*rev,"t5_DrawingType","");	//srting[32]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_DrawingType is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_DrawingType is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }



		//ITKresult = AOM_set_value_string(*rev,"t5_CpyRefDesc","");	//srting[80]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_CpyRefDesc is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_CpyRefDesc is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }


		//ITKresult = AOM_set_value_string(*rev,"t5_DrDelInd","");	//srting[1]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_DrDelInd is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_DrDelInd is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		//ITKresult = AOM_set_value_string(*rev,"t5_OfferDrawingNumber","");						//srting[80]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_OfferDrawingNumber is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_OfferDrawingNumber is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		//ITKresult = AOM_set_value_string(*rev,"t5_OppHandDrg","");								//srting[80]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_OppHandDrg is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_OppHandDrg is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		//ITKresult = AOM_set_value_string(*rev,"t5_RefDrawing","");								//srting[80]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_RefDrawing is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_RefDrawing is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		//ITKresult = AOM_set_value_string(*rev,"t5_SheetSize","");									//srting[2]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_SheetSize is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_SheetSize is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		//ITKresult = AOM_set_value_string(*rev,"t5_WIPDisposalInstr","");							//srting[30]
			//if(ITKresult == 0)
			//{ printf("\n  SUCCESS---t5_WIPDisposalInstr is set on Design Revision.");fflush(stdout); }
			//else
			//{ printf("\n  FAILED---t5_WIPDisposalInstr is not set on Design Revision  ??? [%s,%s ,%s]",ItemId,ItemRevSeq,CategoryNameS); fflush(stdout); }

		ITK_CALL(AOM_save(*rev));
		ITK_CALL(AOM_unlock(*rev));
	}
	else
	{
		printf("\n  ?????? Project not found....hence attributes are not able to update.");fflush(stdout);
	}

	return status;
}

int setAttributesOnDesign(tag_t* item,char * desc,char* UnitOfMeasureS,char* LeftRhS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(AOM_lock(*item));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {
		//strcpy(ent_uom,"-");
		strcpy(ent_uom,FOUR);
	}

	ITK_CALL ( AOM_set_value_string(*item,"object_desc",desc));

/*	//// Below is commented on 01.02.2018 to not set UOM for Creo. In creo fraction/float Qty is unable to read because of 1 to 4 UOM, setting qty as float.

	ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	printf("\n ent_uom:%s  \n",ent_uom);fflush(stdout);
	ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure)); */

	printf("\n LeftRhS: [%s]\n",LeftRhS); fflush(stdout);
	if(strcmp(LeftRhS,"NA")!=0)
	{
		printf("\n LeftRhS:[%s] is not NA\n",LeftRhS); fflush(stdout);
		ITK_CALL ( AOM_set_value_string(*item,"t5_LeftRh",LeftRhS));	//commented on 23.05.2016 by rrr05503
	}

	ITK_CALL(AOM_save(*item));
	//ITK_CALL(AOM_unlock(*item));
	//ITK_CALL ( AOM_set_value_string(*item,"uom_tag",UnitOfMeasureS));
}

int setLifeCycle(tag_t* itemRev,char* lifeCycleS)
{
	int status;
	tag_t   status2=NULLTAG;
	logical retain=false;
	char* lcsToset=NULL;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	if(strcmp(lifeCycleS,"LcsReview")==0){printf("\n...1..."); fflush(stdout); strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsWorking")==0){printf("\n...2..."); fflush(stdout); strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){printf("\n...3..."); fflush(stdout); strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){printf("\n...4..."); fflush(stdout); strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){printf("\n...5..."); fflush(stdout); strcpy(lcsToset,APLRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){printf("\n...6..."); fflush(stdout); strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
	{
		//printf("\n This is std released.");
		printf("\n...7...");  fflush(stdout);
		strcpy(lcsToset,STDRELEASED);
	}
	else
	{
		printf("\n...8...");  fflush(stdout);
		strcpy(lcsToset,ERCREVIEW);
		//strcpy(lcsToset,ERCRELEASED);
	}

	printf("   InsetLifeCycle...lcsToset:[%s]",lcsToset); fflush(stdout);

	ITK_CALL(CR_create_release_status(lcsToset,&status2));
	ITK_CALL(EPM_add_release_status(status2,1,itemRev,retain));

	//ITK_CALL(AOM_save(*itemRev));
	//ITK_CALL(AOM_unlock(*itemRev));
}

int setEffectivity(tag_t* itemRev,char* date)
{
	int status;
	int st_count=0;

	char* class_name=NULL;

	logical date_is_valid = FALSE;
	logical ans = false;

	tag_t st_date_id =NULLTAG;
	tag_t end_date_id =NULLTAG;
	tag_t eff_t =NULLTAG;
	tag_t class_id=NULLTAG;

	date_t st_date;
	date_t end_date;

	tag_t* status_list;

	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count); fflush(stdout);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,date,&eff_t));
			ITK_CALL(AOM_save(status_list[0]));
			ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......"); fflush(stdout);
		}
		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int ch1;
	int Monthas;
	int ch;

	time_t	temp;

    date_t DayTommorow ;

 	struct tm *timeptr;
	struct tm *timeptr1;

	char pAccessDate[20];
	char pAccessDate1[20];
	char DateS[20];
	char CCMonth[30];

	char* strDay;
	char* strMon;
	char* strYear;
	char* cMonth ;

	temp = time(NULL);

	tc_strcpy(pAccessDate,"");

	//	timeptr = (struct tm *)localtime(&temp);
	//	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	//	day=timeptr->tm_mday;
	//	month=(timeptr->tm_mon)+1;
	//	year=(timeptr->tm_year+1900);

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear); fflush(stdout);
	printf("\n CCMonth:%s\n",CCMonth); fflush(stdout);
	printf("\n strDay:%s\n",strDay); fflush(stdout);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	
	printf("\n cnextAccessDate:%s\n",cnextAccessDate); fflush(stdout);
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{
	int status = 0;
	int ifail = 0;
	int status_count=0;
	int ss=0;
	int StatusFlg=0;

	char* ReleaseStatus=NULL;
	char* ReleaseStatus2=NULL;
	char* lcsToset=NULL;
	char* CurrentRelStatus=NULL;

	char FrmNextDate[20]={0};
	char ToNextDate[20]={0};

	logical retain_released_date =false;
	logical is_v7  ;

	date_t test_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;

	tag_t release_status =NULLTAG;
	tag_t release_status2 =NULLTAG;
	tag_t eff_d = NULLTAG;

	tag_t* status_list = NULLTAG;

	/******Start Release status Variable initialisation***********/
	int			st_relList_count		=0;
	int			Rel_cnt					=0; 
	tag_t*		relstatus_list			=NULLTAG; 
	char		*WSO_Name_RelVal		=NULL ;
	tag_t		tReleaseStatusList_checkin=NULLTAG; 
	int			n_values_checkin			=0; 
	int			cunt1					=	0; 
	tag_t*		attr_tags_checkin		=	NULLTAG; 
	logical		*is_it_null_checkin		=   NULL; 
	logical		*is_it_empty_checkin	=   NULL; 
	tag_t		class_id				=     NULLTAG;
	char		*class_name				=    NULL;
	logical		log1;

	/******End Release status ariable initialisation***********/

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

	/*if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCWORKING);}
	else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,APLWORKING);}
	else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,APLRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,STDWORKING);}
	else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
	{
		printf("\n This is std rel..."); fflush(stdout);
		strcpy(lcsToset,STDRELEASED);
	}
	else
	{
		strcpy(lcsToset,ERCWORKING);
	}*/

	if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
	else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
	else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
	{
		//printf("\n This is std rel..."); fflush(stdout);
		strcpy(lcsToset,ERCRELEASED);
	}
	else
	{
		strcpy(lcsToset,ERCREVIEW);
	}

	printf("\n lcsToset:[%s]",lcsToset); fflush(stdout);
	printf("   FromDate..[%s]",FromDate); fflush(stdout);
	printf("   ToDate..[%s]",ToDate); fflush(stdout);

	if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
	{
		printf(" ...ifail..."); fflush(stdout);
		return ifail;
	}
	printf("\n REV status_count: %d",status_count);fflush(stdout);
	if (status_count == 0)  /* No Status, so the Item is not yet Released */
	{
		printf("\n No Status, so the Item is not yet Released..............."); fflush(stdout);
	}
	
	if(((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0)) && (strcmp(lcsToset,"ERCREVIEW")==0))
	{
		if (status_count == 0) 
		{
			if(ITK_ok != (ifail = CR_create_release_status(lcsToset,&release_status2)))	 return ifail;

			if(ITK_ok != (ifail = AOM_ask_name(release_status2, &ReleaseStatus2))) return ifail;
			printf("\n Created ReleaseStatus2: %s",ReleaseStatus2);fflush(stdout);

			//ITK_CALL(AOM_lock(itemrev));

			if(ITK_ok != (ifail = EPM_add_release_status(release_status2,1,&itemrev,retain_released_date)))return ifail;

			/*if(ITK_ok != (ifail = AOM_save(release_status2)))
			{
				return ifail;
			}
			if(ITK_ok != (ifail = AOM_refresh( release_status2, 0 )))
			{
				return ifail;
			}

			ITK_CALL(AOM_unlock(itemrev));*/
		}

		return 0;
	}

	if (status_count > 0)  /* No Status, so the Item is not yet Released */
	{
		for(ss=0; ss<status_count ; ss++)
		{
			ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&CurrentRelStatus));
			printf("\n CurrentRelStatus: %s",CurrentRelStatus);fflush(stdout);
			if(strcmp(CurrentRelStatus,lcsToset)==0)
			{
			   StatusFlg ++;
			}
		}
	}
	printf("\n StatusFlg: [%d]",StatusFlg);fflush(stdout);

	if(StatusFlg != 0)
	{	
		return 0;
	}

	printf("\n Removing previously created release status......"); fflush(stdout);

	/*********Start for removing Release Status in CHeckIN ***************************************/
	ITK_CALL(POM_class_of_instance(itemrev,&class_id));
	ITK_CALL(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);

	ITK_CALL(POM_unload_instances (1,&itemrev));
	ITK_CALL(POM_load_instances(1,&itemrev,class_id,1));
	ITK_CALL(POM_is_loaded(itemrev,&log1));
	if(log1 == 1)
	{
		 printf(" Load Success \n " ); fflush(stdout);
	}
	else
	{
		printf("Load Failure\n"  ); fflush(stdout);
	}

	ITK_CALL( POM_length_of_attr(itemrev, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		ITK_CALL( POM_ask_attr_tags(itemrev, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d",n_values_checkin);fflush(stdout);

		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d",cunt1);fflush(stdout);

			ITK_CALL(POM_remove_from_attr(1,&itemrev,tReleaseStatusList_checkin,0,1));
			printf("\n cunt1 == 0 removedd is :%d",cunt1);fflush(stdout);

			ITK_CALL(POM_save_instances(1,&itemrev,1));
			ITK_CALL(POM_refresh_instances(1,&itemrev,class_id,2));
			ITK_CALL(AOM_lock(itemrev));

			ITK_CALL(AOM_save(itemrev));
			ITK_CALL(AOM_refresh(itemrev,1));
		}
		ITK_CALL(AOM_unlock(itemrev));
	}
/*********End for removing Release Status in CHeckIN***************************************/


	printf("\n *********Stamping Releasing item*******......"); fflush(stdout);
	if(ITK_ok != (ifail = CR_create_release_status(lcsToset,&release_status)))	 return ifail;

	if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
	printf("\n ******************* ReleaseStatus: %s",ReleaseStatus);fflush(stdout);

	if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
	{
		printf(" ..ifail..."); fflush(stdout);
		return ifail;
	}
	printf("\n REV status_count after ERC Released Stamped: %d",status_count);fflush(stdout);
	if(ITK_ok != (ifail = EPM_add_release_status(release_status,1,&itemrev,retain_released_date)))return ifail;

	if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&is_v7)))	 return ifail;
	printf("\n is_v7:%d",is_v7); fflush(stdout);
	if(is_v7 != true)
	{
		printf("\t ------is_v7 is not true ....."); fflush(stdout);
	}
	else
	{
		printf("\t ------is_v7 is  true ....."); fflush(stdout);
	}

	if((strcmp(FromDate,"-")!=0) && (strcmp(ToDate,"-")!=0))
	{
		getNextDate(FromDate,FrmNextDate);
		getNextDate(ToDate,ToNextDate);

		printf("\n FrmNextDate:%s",FrmNextDate); fflush(stdout);
		printf("   ToNextDate:%s",ToNextDate); fflush(stdout);
		//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

		if(ITK_ok != (ifail = ITK_string_to_date(FrmNextDate, &test_date_1)))
		{
			return ifail;
		}
		if(ITK_ok != (ifail = ITK_string_to_date(ToNextDate, &test_date_2 )))
		{
			return ifail;
		}

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		if(ITK_ok != (ifail = WSOM_status_clear_effectivities(release_status)))
		{
			return ifail;
		}

		if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
		{
			return ifail;
		}

		if(ITK_ok != (ifail = AOM_save(eff_d)))
		{
			return ifail;
		}
	}

	//if(ITK_ok != (ifail = AOM_save(release_status)))
	//{
	//	return ifail;
	//}
	//if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
	//{
	//	return ifail;
	//}
	
	printf("\n"); fflush(stdout);
	ITK_CALL(AOM_lock(release_status));
	ITK_CALL(AOM_save(release_status));
	ITK_CALL(AOM_refresh(release_status,0));
	ITK_CALL(AOM_unlock(release_status));

	printf("\n effectivity done-------------:%s \n",FrmNextDate); fflush(stdout);

	return status;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}
extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int org_seq_id_int=0;
	int lat_seq_id_int=0;
	int j=0;
	int i=0;
	int n_strings = 1;
	int l_strings = 80;			// Arbitrary values - Please verify proper lengths for your application!
	int tempStrLength = 80;
	int index;
	int si=0;
	int n_tags_found= 0;
	int revision_count=0;
	int release_status = 0;
	int newRevListCnt = 0;
	int ascii_LatestRev;
	int ascii_InputRev;

	logical isCheckOut=false;
	
	FILE* fp=NULL;
	FILE* fperror=NULL;

	char* inputfile=NULL;
	char* inputline=NULL;
	char* level=NULL;
	char* item_name=NULL;
	char* qty=NULL;
	//char* dtype=NULL;
	char* atype="L";
	char LRev;
	char InpRev;

	char* item_id=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* desc=NULL;
	char* parttype = NULL;
	char* projectcode = NULL;
	char* designgroup = NULL;
	char* mod_desc = NULL;
	char* DrawingNoS = NULL;
	char* DrawingNoDupS = NULL;
	char* Materialclass = NULL;
	char* DrawingIndDupS = NULL;
	char* DrawingIndS = NULL;
	char* MaterialDupS = NULL;
	char* MaterialS = NULL;
	char* MaterialInDrwDupS = NULL;
	char* MaterialInDrwS = NULL;
	char* MaterialThickNessS = NULL;
	char* LeftRhS = NULL;
	char* DeignOwnUnitS = NULL;
	char* ModelIndS = NULL;
	char* UnitOfMeasureS = NULL;
	char* ColourIndS = NULL;
	char* lifecycleS = NULL;
	char* t5ColourIDS = NULL;
	char* WeightS = NULL;
	char* t5SpareIndS = NULL;
	char* t5CMVRCertificationS = NULL;
	char* t5ClassificationHazS = NULL;
	char* t5ConfigIDS = NULL;
	char* t5DismantableS = NULL;
	char* t5DsgnDeptS = NULL;
	char* t5EnvelopeDimenS = NULL;
	char* t5HazardousContS = NULL;
	char* t5HomologationReqdS = NULL;
	char* t5ListRecSparesS = NULL;
	char* t5NcPartNoS = NULL;
	char* t5PartCodeS = NULL;
	char* t5PartPropertyS = NULL;
	char* t5PartStatusS = NULL;
	char* t5PkgStdS = NULL;
	char* t5ProductS = NULL;
	char* t5PrtCatCodeS = NULL;
	char* t5PunIntialAgS = NULL;
	char* t5PunMakeBuyIndS = NULL;
	char* t5RecoverableS = NULL;
	char* t5RecyclabilityS = NULL;
	char* t5RefPartNumberS = NULL;
	char* t5ReliabilityS = NULL;
	char* t5SpareCriteriaS = NULL;
	char* t5SurfPrtStdS = NULL;
	char* t5SamplesToApprS = NULL;
	char* t5AsmDisposalS = NULL;
	char* t5FinDisposalInstrS = NULL;
	char* t5RPDisposalInstrS = NULL;
	char* t5SPDisposalInstrS = NULL;
	char* t5WIPDisposalInstrS = NULL;
	char* t5LastModByS = NULL;
	char* t5VerCreatorS = NULL;
	char* t5CAEDocES = NULL;
	char* t5CoatedS = NULL;
	char* t5ConvDocS = NULL;
	char* t5AplCopyOfErcRevS = NULL;
	char* t5AplCopyOfErcSeqS = NULL;
	char* t5AppCodeS = NULL;
	char* t5RqstNumS = NULL;
	char* t5RsnCodeS = NULL;
	char* t5SurfaceAreaS = NULL;
	char* t5VolumeS = NULL;
	char* t5CarIntialAgencyS = NULL;
	char* t5CarMakeBuyIndiS = NULL;
	char* t5ErcIndNameS = NULL;
	char* t5PostRelReqS = NULL;
	char* t5ItmCategoryS = NULL;
	char* t5CopReqS = NULL;
	char* t5AplInvalidateS = NULL;
	char* t5PrtValiStatusS = NULL;
	char* t5DRSubStateS = NULL;
	char* t5KnxtDocIndS = NULL;
	char* t5SimValS = NULL;
	char* t5PerYieldS = NULL;
	char* t5PunStoreLocationS = NULL;
	char* t5AltPartNoS = NULL;
	char* t5RolledupWtS = NULL;
	char* t5PFDModReqdS = NULL;
	char* t5ToolIndentReqdS = NULL;
	char* CategoryNameS = NULL;
	char* ReveffDateFromDup = NULL;
	char* ReveffDateToDup = NULL;
	char* LeftRhPartDup = NULL;
	char* instanceNameTemp = NULL;
	char* instanceName = NULL;
	char* t5JsrIntialAgencyS = NULL;		
	char* t5JsrMakeBuyIndiS = NULL;		
	char* t5LkoIntialAgencyS = NULL;		
	char* t5LkoMakeBuyIndiS = NULL;		
	char* t5PnrIntialAgencyS = NULL;		
	char* t5PnrMakeBuyIndiS = NULL;		
	char* t5PunPCBUIntialAgencyS = NULL;	
	char* t5PunPCBUMakeBuyIndiS = NULL;	
	char* t5SgrIntialAgencyS = NULL;		
	char* t5SgrMakeBuyIndiS = NULL;		
	char* t5EstSheetReqdS = NULL;
	char* t5PartCreDateS = NULL;
	char* t5LastModDateS = NULL;
	char* t5PartCreatorS = NULL;
	char* t5AhdIntialAgencySDup = NULL;
	char* t5AhdMakeBuyIndSDup = NULL;
	char* t5DwdIntialAgencySDup = NULL;
	char* t5DwdMakeBuyIndSDup = NULL;
	char* t5JdlIntialAgencySDup = NULL;
	char* t5JdlMakeBuyIndSDup = NULL;
	char* t5AhdStoreLocSDup = NULL;
	char* t5CarStoreLocSDup = NULL;
	char* t5DwdStoreLocSDup = NULL;
	char* t5JdlStoreLocSDup = NULL;
	char* t5JsrStoreLocSDup = NULL;
	char* t5LkoStoreLocSDup = NULL;
	char* t5PnrStoreLocSDup = NULL;
	char* t5PunPCBUStoreLocSDup = NULL;
	char* t5SgrStoreLocSDup = NULL;

	char* rel_list = NULL;
	char* itemRevSeq = NULL;
	char* itemRevSeq1 = NULL;
	char* Item_string = NULL;
	char* eff_date = NULL;
	char *item_rev = NULL;
	char *item_seq = NULL;
	char *LatestRevSeq1 = NULL;
	char *LatestRev1 = NULL;
	char *LatestSeq1 = NULL;

	char** stringArray = NULL;

	tag_t newItemTag = NULLTAG;
	tag_t itemRevCreInTag = NULLTAG;
	tag_t itemRevTypeTag = NULLTAG;
	tag_t item = NULLTAG;
	tag_t itemOrg = NULLTAG;
	tag_t revOrg = NULLTAG;
	tag_t newRev = NULLTAG;
	tag_t latestRev = NULLTAG;

	tag_t *RevNewSeqTag = NULLTAG;
	tag_t *tags_found = NULL;
	tag_t *revisions;
	tag_t *newRevList = NULLTAG;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	tag_t reln_type=NULLTAG ;
	tag_t reln_type2=NULLTAG ;
	tag_t *secondary_objects=NULLTAG ;
	tag_t *secondary_objects2=NULLTAG ;
	tag_t *status1=NULL;
	tag_t  attr_name_id   = NULLTAG;
	tag_t  primary=NULLTAG,objTypeTag=NULLTAG;
	tag_t  primary2=NULLTAG,objTypeTag2=NULLTAG;
	char *value = NULL;
	tag_t class_id = NULLTAG;
	char szClassName[100 + 1] = "";
	logical is_it_empty = FALSE;
	logical is_it_null  = FALSE;
	logical is_loaded   = FALSE;
	char type_name[100+1];
	char type_name2[100+1];

	char *szbom_revision_status = NULL;
	tag_t   window, window2, rule, item_tag = null_tag, top_line;

	logical checkout = 0;

	time_t t;
	//time(&t);

	inputfile = ITK_ask_cli_argument("-i=");

//	if( ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	printf("\n Auto login ");fflush(stdout);
//	ITK_CALL(ITK_auto_login( ));
//	ITK_CALL(ITK_set_journalling( TRUE ));
//	printf("\n Auto login .......");fflush(stdout);

	initialise();

	//printf("\n Item:[%s]\nRev:[%s]\nSeq[%s]",req_item,req_rev,req_seq);fflush(stdout);

    //ITK_CALL(ITEM_find_item(req_item, &item ));
	printf("\n----------------------------------------------------\n");

	//printf("\n\n\nlocaltime has returned a NULL pointer in sysdate(): %s\n",ctime(&t));
	printf(" Date and time: %s\n",ctime(&t));

	fp=fopen(inputfile,"r");
	fperror=fopen("error.log","a");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(5000);
		while(fgets(inputline,5000,fp)!=NULL)
		{
			fputs(inputline,stdout);

			//level=strtok(inputline,"^");											
			//item_id=strtok(NULL,"^");

			item_id=strtok(inputline,"^");				//1
			item_revision_id=strtok(NULL,"^");
			item_sequence_id=strtok(NULL,"^");
			desc=strtok(NULL,"^");
			parttype=strtok(NULL,"^");
			projectcode=strtok(NULL,"^");
			designgroup=strtok(NULL,"^");
			mod_desc=strtok(NULL,"^");
			DrawingNoS=strtok(NULL,"^");
			DrawingIndS=strtok(NULL,"^");				//10
			Materialclass=strtok(NULL,"^");
			MaterialInDrwS=strtok(NULL,"^");
			MaterialThickNessS=strtok(NULL,"^");
			LeftRhS=strtok(NULL,"^");
			DeignOwnUnitS=strtok(NULL,"^");
			ModelIndS=strtok(NULL,"^");
			UnitOfMeasureS=strtok(NULL,"^");
			ColourIndS=strtok(NULL,"^");
			lifecycleS=strtok(NULL,"^");
			t5ColourIDS=strtok(NULL,"^");				//20
			WeightS=strtok(NULL,"^");
			t5SpareIndS=strtok(NULL,"^");
			t5CMVRCertificationS=strtok(NULL,"^");
			t5ClassificationHazS=strtok(NULL,"^");
			t5ConfigIDS=strtok(NULL,"^");
			t5DismantableS=strtok(NULL,"^");
			t5DsgnDeptS=strtok(NULL,"^");
			t5EnvelopeDimenS=strtok(NULL,"^");
			t5HazardousContS=strtok(NULL,"^");
			t5HomologationReqdS=strtok(NULL,"^");		//30
			t5ListRecSparesS=strtok(NULL,"^");
			t5NcPartNoS=strtok(NULL,"^");
			t5PartCodeS=strtok(NULL,"^");
			t5PartPropertyS=strtok(NULL,"^");
			t5PartStatusS=strtok(NULL,"^");
			t5PkgStdS=strtok(NULL,"^");
			t5ProductS=strtok(NULL,"^");
			t5PrtCatCodeS = strtok(NULL,"^");
			t5PunIntialAgS = strtok(NULL,"^");
			t5PunMakeBuyIndS = strtok(NULL,"^");		//40
			t5RecoverableS = strtok(NULL,"^");
			t5RecyclabilityS = strtok(NULL,"^");
			t5RefPartNumberS = strtok(NULL,"^");
			t5ReliabilityS = strtok(NULL,"^");
			t5SpareCriteriaS = strtok(NULL,"^");
			t5SurfPrtStdS = strtok(NULL,"^");
			t5SamplesToApprS = strtok(NULL,"^");
			t5AsmDisposalS = strtok(NULL,"^");
			t5FinDisposalInstrS = strtok(NULL,"^");
			t5RPDisposalInstrS = strtok(NULL,"^");		//50
			t5SPDisposalInstrS = strtok(NULL,"^");
			t5WIPDisposalInstrS = strtok(NULL,"^");
			t5LastModByS = strtok(NULL,"^");
			t5VerCreatorS = strtok(NULL,"^");
			t5CAEDocES = strtok(NULL,"^");
			t5CoatedS = strtok(NULL,"^");
			t5ConvDocS = strtok(NULL,"^");
			t5AplCopyOfErcRevS = strtok(NULL,"^");
			t5AplCopyOfErcSeqS = strtok(NULL,"^");
			t5AppCodeS = strtok(NULL,"^");				//60
			t5RqstNumS = strtok(NULL,"^");
			t5RsnCodeS = strtok(NULL,"^");
			t5SurfaceAreaS = strtok(NULL,"^");
			t5VolumeS = strtok(NULL,"^");
			t5CarIntialAgencyS = strtok(NULL,"^");
			t5CarMakeBuyIndiS = strtok(NULL,"^");
			t5ErcIndNameS = strtok(NULL,"^");
			t5PostRelReqS = strtok(NULL,"^");
			t5ItmCategoryS = strtok(NULL,"^");
			t5CopReqS = strtok(NULL,"^");				//70
			t5AplInvalidateS = strtok(NULL,"^");
			t5PrtValiStatusS = strtok(NULL,"^");
			t5DRSubStateS = strtok(NULL,"^");
			t5KnxtDocIndS = strtok(NULL,"^");
			t5SimValS = strtok(NULL,"^");
			t5PerYieldS = strtok(NULL,"^");
			t5PunStoreLocationS = strtok(NULL,"^");
			t5AltPartNoS = strtok(NULL,"^");
			t5RolledupWtS = strtok(NULL,"^");
			t5PFDModReqdS = strtok(NULL,"^");			//80
			t5ToolIndentReqdS = strtok(NULL,"^");		//81
			CategoryNameS = strtok(NULL,"^");			//82
			ReveffDateFromDup = strtok(NULL,"^");		//83
			ReveffDateToDup = strtok(NULL,"^");			//84
			LeftRhPartDup = strtok(NULL,"^");			//85
			instanceNameTemp = strtok(NULL,"^");		//86
			t5JsrIntialAgencyS = strtok(NULL,"^");		//87
			t5JsrMakeBuyIndiS = strtok(NULL,"^");		//88
			t5LkoIntialAgencyS = strtok(NULL,"^");		//99
			t5LkoMakeBuyIndiS = strtok(NULL,"^");		//90
			t5PnrIntialAgencyS = strtok(NULL,"^");		//91
			t5PnrMakeBuyIndiS = strtok(NULL,"^");		//92
			t5PunPCBUIntialAgencyS = strtok(NULL,"^");	//93
			t5PunPCBUMakeBuyIndiS = strtok(NULL,"^");	//94
			t5SgrIntialAgencyS = strtok(NULL,"^");		//95
			t5SgrMakeBuyIndiS = strtok(NULL,"^");		//96
			t5EstSheetReqdS = strtok(NULL,"^");			//97
			t5PartCreDateS = strtok(NULL,"^");			//98
			t5LastModDateS = strtok(NULL,"^");			//99
			t5PartCreatorS = strtok(NULL,"^");			//100

			t5AhdIntialAgencySDup = strtok(NULL,"^");	//101
			t5AhdMakeBuyIndSDup = strtok(NULL,"^");		//102
			t5DwdIntialAgencySDup = strtok(NULL,"^");	//103
			t5DwdMakeBuyIndSDup = strtok(NULL,"^");		//104
			t5JdlIntialAgencySDup = strtok(NULL,"^");	//105
			t5JdlMakeBuyIndSDup = strtok(NULL,"^");		//106
			t5AhdStoreLocSDup = strtok(NULL,"^");		//107
			t5CarStoreLocSDup = strtok(NULL,"^");		//108		//In main
			t5DwdStoreLocSDup = strtok(NULL,"^");		//109
			t5JdlStoreLocSDup = strtok(NULL,"^");		//110
			t5JsrStoreLocSDup = strtok(NULL,"^");		//111
			t5LkoStoreLocSDup = strtok(NULL,"^");		//112
			t5PnrStoreLocSDup = strtok(NULL,"^");		//113
			t5PunPCBUStoreLocSDup = strtok(NULL,"^");	//114
			t5SgrStoreLocSDup = strtok(NULL,"^");		//115		//In main

//t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup

			printf("\n  item_id			: %s",item_id ); fflush(stdout);
			printf("\n  item_revision_id: %s",item_revision_id ); fflush(stdout);
			printf("\n  item_sequence_id: %s",item_sequence_id ); fflush(stdout);
			printf("\n  desc			: %s",desc ); fflush(stdout);
			printf("\n  parttype		: %s",parttype ); fflush(stdout);
			printf("\n  projectcode		: %s",projectcode ); fflush(stdout);
			printf("\n  designgroup		: %s",designgroup ); fflush(stdout);
			printf("\n  mod_desc		: %s",mod_desc ); fflush(stdout);
			printf("\n  DrawingNoS		: %s",DrawingNoS ); fflush(stdout);
			printf("\n  DrawingIndS		: %s",DrawingIndS ); fflush(stdout);
			printf("\n  Materialclass	: %s",Materialclass ); fflush(stdout);
			printf("\n  MaterialInDrwS	: %s",MaterialInDrwS ); fflush(stdout);
			printf("\n  MaterialThickNessS: %s",MaterialThickNessS ); fflush(stdout);
			printf("\n  LeftRhS			: %s",LeftRhS ); fflush(stdout);
			printf("\n  DeignOwnUnitS	: %s",DeignOwnUnitS ); fflush(stdout);
			printf("\n  ModelIndS		: %s",ModelIndS ); fflush(stdout);
			printf("\n  UnitOfMeasureS	: %s",UnitOfMeasureS ); fflush(stdout);
			printf("\n  ColourIndS		: %s",ColourIndS ); fflush(stdout);
			printf("\n  lifecycleS		: %s",lifecycleS ); fflush(stdout);
			printf("\n  t5ColourIDS		: %s",t5ColourIDS ); fflush(stdout);
			printf("\n  WeightS			: %s",WeightS ); fflush(stdout);
			printf("\n  t5SpareIndS		: %s",t5SpareIndS ); fflush(stdout);
			/*printf("\n  t5CMVRCertificationS: %s",t5CMVRCertificationS ); fflush(stdout);
			printf("\n  t5ClassificationHazS: %s",t5ClassificationHazS ); fflush(stdout);
			printf("\n  t5ConfigIDS		: %s",t5ConfigIDS ); fflush(stdout);
			printf("\n  t5DismantableS	: %s",t5DismantableS ); fflush(stdout);
			printf("\n  t5DsgnDeptS		: %s",t5DsgnDeptS ); fflush(stdout);
			printf("\n  t5EnvelopeDimenS: %s",t5EnvelopeDimenS ); fflush(stdout);
			printf("\n  t5HazardousContS: %s",t5HazardousContS ); fflush(stdout);
			printf("\n  t5HomologationReqdS: %s",t5HomologationReqdS ); fflush(stdout);
			printf("\n  t5ListRecSparesS: %s",t5ListRecSparesS ); fflush(stdout);
			printf("\n  t5NcPartNoS		: %s",t5NcPartNoS ); fflush(stdout);
			printf("\n  t5PartCodeS		: %s",t5PartCodeS ); fflush(stdout);
			printf("\n  t5PartPropertyS	: %s",t5PartPropertyS ); fflush(stdout);
			printf("\n  t5PartStatusS	: %s",t5PartStatusS ); fflush(stdout);
			printf("\n  t5PkgStdS		: %s",t5PkgStdS ); fflush(stdout);
			printf("\n  t5ProductS		: %s",t5ProductS ); fflush(stdout);
			printf("\n  t5PrtCatCodeS	: %s",t5PrtCatCodeS ); fflush(stdout);
			printf("\n  t5PunIntialAgS	: %s",t5PunIntialAgS  ); fflush(stdout);
			printf("\n  t5PunMakeBuyIndS: %s",t5PunMakeBuyIndS ); fflush(stdout);
			printf("\n  t5RecoverableS	: %s",t5RecoverableS  ); fflush(stdout);
			printf("\n  t5RecyclabilityS: %s",t5RecyclabilityS ); fflush(stdout);
			printf("\n  t5RefPartNumberS: %s",t5RefPartNumberS ); fflush(stdout);
			printf("\n  t5ReliabilityS	: %s",t5ReliabilityS  ); fflush(stdout);
			printf("\n  t5SpareCriteriaS: %s",t5SpareCriteriaS ); fflush(stdout);
			printf("\n  t5SurfPrtStdS	: %s",t5SurfPrtStdS ); fflush(stdout);
			printf("\n  t5SamplesToApprS: %s",t5SamplesToApprS ); fflush(stdout);
			printf("\n  t5AsmDisposalS	: %s",t5AsmDisposalS  ); fflush(stdout);
			printf("\n  t5FinDisposalInstrS: %s",t5FinDisposalInstrS); fflush(stdout);
			printf("\n  t5RPDisposalInstrS: %s",t5RPDisposalInstrS ); fflush(stdout);
			printf("\n  t5SPDisposalInstrS: %s",t5SPDisposalInstrS ); fflush(stdout);
			printf("\n  t5WIPDisposalInstrS: %s",t5WIPDisposalInstrS); fflush(stdout);
			printf("\n  t5LastModByS	: %s",t5LastModByS ); fflush(stdout);
			printf("\n  t5VerCreatorS	: %s",t5VerCreatorS ); fflush(stdout);
			printf("\n  t5CAEDocES		: %s",t5CAEDocES ); fflush(stdout);
			printf("\n  t5CoatedS		: %s",t5CoatedS ); fflush(stdout);
			printf("\n  t5ConvDocS		: %s",t5ConvDocS ); fflush(stdout);
			printf("\n  t5AplCopyOfErcRevS: %s",t5AplCopyOfErcRevS ); fflush(stdout);
			printf("\n  t5AplCopyOfErcSeqS: %s",t5AplCopyOfErcSeqS ); fflush(stdout);
			printf("\n  t5AppCodeS		: %s",t5AppCodeS ); fflush(stdout);
			printf("\n  t5RqstNumS		: %s",t5RqstNumS ); fflush(stdout);
			printf("\n  t5RsnCodeS		: %s",t5RsnCodeS ); fflush(stdout);
			printf("\n  t5SurfaceAreaS	: %s",t5SurfaceAreaS  ); fflush(stdout);
			printf("\n  t5VolumeS		: %s",t5VolumeS ); fflush(stdout);
			printf("\n  t5CarIntialAgencyS: %s",t5CarIntialAgencyS ); fflush(stdout);
			printf("\n  t5CarMakeBuyIndiS: %s",t5CarMakeBuyIndiS  ); fflush(stdout);
			printf("\n  t5ErcIndNameS	: %s",t5ErcIndNameS ); fflush(stdout);
			printf("\n  t5PostRelReqS	: %s",t5PostRelReqS ); fflush(stdout);
			printf("\n  t5ItmCategoryS	: %s",t5ItmCategoryS  ); fflush(stdout);
			printf("\n  t5CopReqS		: %s",t5CopReqS ); fflush(stdout);
			printf("\n  t5AplInvalidateS: %s",t5AplInvalidateS ); fflush(stdout);
			printf("\n  t5PrtValiStatusS: %s",t5PrtValiStatusS ); fflush(stdout);
			printf("\n  t5DRSubStateS	: %s",t5DRSubStateS ); fflush(stdout);
			printf("\n  t5KnxtDocIndS	: %s",t5KnxtDocIndS ); fflush(stdout);
			printf("\n  t5SimValS		: %s",t5SimValS ); fflush(stdout);
			printf("\n  t5PerYieldS		: %s",t5PerYieldS  ); fflush(stdout);
			printf("\n  t5PunStoreLocationS: %s",t5PunStoreLocationS); fflush(stdout);
			printf("\n  t5AltPartNoS	: %s",t5AltPartNoS ); fflush(stdout);
			printf("\n  t5RolledupWtS	: %s",t5RolledupWtS ); fflush(stdout);
			printf("\n  t5PFDModReqdS	: %s",t5PFDModReqdS ); fflush(stdout);
			printf("\n  t5ToolIndentReqdS: %s",t5ToolIndentReqdS  ); fflush(stdout);
			printf("\n  CategoryNameS	: %s",CategoryNameS ); fflush(stdout);
			printf("\n  ReveffDateFromDup: %s",ReveffDateFromDup  ); fflush(stdout);
			printf("\n  ReveffDateToDup	: %s",ReveffDateToDup ); fflush(stdout);
			printf("\n  LeftRhPartDup	: %s",LeftRhPartDup ); fflush(stdout);
			printf("\n  instanceNameTemp: %s",instanceNameTemp ); fflush(stdout);
			printf("\n  t5JsrIntialAgencyS: %s",t5JsrIntialAgencyS ); fflush(stdout);
			printf("\n  t5JsrMakeBuyIndiS : %s",t5JsrMakeBuyIndiS  ); fflush(stdout);
			printf("\n  t5LkoIntialAgencyS: %s",t5LkoIntialAgencyS ); fflush(stdout);
			printf("\n  t5LkoMakeBuyIndiS : %s",t5LkoMakeBuyIndiS  ); fflush(stdout);
			printf("\n  t5PnrIntialAgencyS: %s",t5PnrIntialAgencyS ); fflush(stdout);
			printf("\n  t5PnrMakeBuyIndiS : %s",t5PnrMakeBuyIndiS  ); fflush(stdout);
			printf("\n  t5PunPCBUIntialAgencyS: %s",t5PunPCBUIntialAgencyS); fflush(stdout);
			printf("\n  t5PunPCBUMakeBuyIndiS: %s",t5PunPCBUMakeBuyIndiS); fflush(stdout);
			printf("\n  t5SgrIntialAgencyS: %s",t5SgrIntialAgencyS); fflush(stdout);
			printf("\n  t5SgrMakeBuyIndiS: %s",t5SgrMakeBuyIndiS); fflush(stdout);
			printf("\n  t5EstSheetReqdS: %s",t5EstSheetReqdS); fflush(stdout);*/
			printf("\n  t5PartCreDateS 	: %s",t5PartCreDateS  ); fflush(stdout);
			printf("\n  t5LastModDateS 	: %s",t5LastModDateS  ); fflush(stdout);
			printf("\n  t5PartCreatorS 	: %s",t5PartCreatorS  ); fflush(stdout);

			//printf("\nL:[%s],I:[%s],R:[%s],S:[%s],D:[%s],Q:[%s],DType:[%s],AType:[%s]\n",level,item_id,item_revision_id,item_sequence_id,desc,qty,dtype,atype); fflush(stdout);

			attrs[0] ="item_id";
			values[0] = (char *)item_id;
			//Querying with item id
			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

			if(n_tags_found==0)
			{
				itemRevSeq = NULL;
				itemRevSeq=(char *) MEM_alloc(32);
				strcpy(itemRevSeq,item_revision_id);
				strcat(itemRevSeq,";");
				strcat(itemRevSeq,item_sequence_id);
				//strcat(itemRevSeq,";1");
				printf("\nitemRevSeq concated is --->%s\n\n",itemRevSeq);

				//Keep item id and item name same
				if(strstr(atype,"N")!=NULL)
				{
					printf("Creating new Spec.... \n"); fflush(stdout);

					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_WeldSpot",default_empty_to_A(itemRevSeq),&item,&newRev));
					
					//setAttributesOnDesignRev(&newRev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup, t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);
					//setAttributesOnDesign(&item,UnitOfMeasureS,LeftRhS);
					//if((strcmp(ReveffDateFromDup,"-")==0) || (strcmp(ReveffDateToDup,"-")==0))
					//{
					//	setLifeCycle(&newRev,lifecycleS);
					//}
					//ITK_CALL(CreateEffctivity(newRev,ReveffDateFromDup, ReveffDateToDup ,lifecycleS));
				}
				else if (strstr(atype,"D")!=NULL)
				{
					printf("1..Creating new Dummy Part....\n"); fflush(stdout);
					
					ITK_CALL(ITEM_create_item(item_id,item_id,"T5_DummyPart",default_empty_to_A(itemRevSeq),&item,&newRev));
					
					setAttributesOnDesignRev(&newRev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,t5ColourIDS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup , t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);
					setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);
					
					if((strcmp(ReveffDateFromDup,"-")==0) || (strcmp(ReveffDateToDup,"-")==0))
					{
						setLifeCycle(&newRev,lifecycleS);
					}
					ITK_CALL(CreateEffctivity(newRev, ReveffDateFromDup, ReveffDateToDup , lifecycleS));
				}
				else
				{
					printf("1..Creating new Design Item..... \n"); fflush(stdout);
					
					newRev = NULLTAG;

					ITK_CALL(ITEM_create_item(item_id,item_id,"Design",default_empty_to_A(itemRevSeq),&itemOrg,&newRev));

					setAttributesOnItemRev(&itemOrg,desc);
					ITK_CALL(AOM_save(itemOrg));
					ITK_CALL(AOM_unlock(itemOrg));

					setAttributesOnDesign(&itemOrg,desc,UnitOfMeasureS,LeftRhS);

					if(newRev != NULLTAG)	//new logic
					{
						printf("1..Revision is created....\n");

						ITK_CALL(AOM_ask_value_string(newRev,"item_revision_id",&Item_string));

						printf("\n1.New Item Revision:[%s] %s*****",Item_string); fflush(stdout);

						if(strlen(t5PartCreDateS) > 9 )
						{
							printf("\n1..Retaining-Updating Creation/LastMod User and Date....\n"); fflush(stdout);

							ITK_CALL(setDateAttributesOnItemRev(newRev,t5PartCreDateS,t5LastModDateS,t5PartCreatorS,t5LastModByS));
						}

						setAttributesOnDesignRev(&newRev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,t5ColourIDS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup, t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);

						ITK_CALL(RES_is_checked_out(newRev,&checkout));
						printf(" ???????????? 1.checkout:[%d]\n",checkout); fflush(stdout);

						if (checkout > 0)
						{
							setAttributesOnDesignRev(&newRev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,t5ColourIDS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup, t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);
							if(RES_checkin(newRev)!=ITK_ok)
							{
								printf("1..RES_checkin failed.\n"); fflush(stdout);
							}
							else
							{
								printf("1..RES_checkin is successful\n"); fflush(stdout);
							}
						}
						else
							printf("\n"); fflush(stdout);

						if((strcmp(ReveffDateFromDup,"-")==0) || (strcmp(ReveffDateToDup,"-")==0))
						{
							setLifeCycle(&newRev,lifecycleS);
						}
						ITK_CALL(CreateEffctivity(newRev, ReveffDateFromDup, ReveffDateToDup , lifecycleS));

						/*if(RES_checkin(newRev)!=ITK_ok)
						{
							fprintf(fperror,"1..Error with part number:[%s],[%s]\n",item_id,item_revision_id);
						}*/

						printf("1..AssignProject on Revision....\n");

						ITK_CALL(AssignProject(newRev,projectcode));
					}
					else
					{
						printf("\n1..Revision tag not found....\n"); fflush(stdout);
						fprintf(fperror,"1..Error with part number:[%s],[%s] ,New Revision object is not created\n",item_id,itemRevSeq);
					}
				}
				sleep(5);
			}
			else
			{
				item = tags_found[0];

				printf("2..Item already exists \n"); fflush(stdout);

				if(ITEM_list_all_revs (item, &revision_count, &revisions));
				printf("2.Number of revision: %d\n",revision_count); fflush(stdout);

				if(ITEM_ask_latest_rev(item, &latestRev ));

				//ITK_CALL(ITEM_find_revisions(item, item_revision_id, &newRevListCnt ,&newRevList));

				itemRevSeq = NULL;
				itemRevSeq=(char *) MEM_alloc(32);
				strcpy(itemRevSeq,item_revision_id);
				strcat(itemRevSeq,";");
				strcat(itemRevSeq,item_sequence_id);
				//printf("2.itemRevSeq concated is --->%s\n\n",itemRevSeq);

				ITK_CALL(ITEM_find_revision(item,itemRevSeq,&newRev));

				if(newRev != NULLTAG)	//new logic
				{
					printf("2..Revision tag found %s .......\n",itemRevSeq); fflush(stdout);

					ITK_CALL(RES_is_checked_out(newRev,&checkout));

					if (checkout > 0)
					{
						if(RES_checkin(newRev)!=ITK_ok)
						{
							printf("2..RES_checkin failed.\n"); fflush(stdout);
						}
						else
						{
							printf("2..RES_checkin is successful\n"); fflush(stdout);
						}
					}

					//Temporary added below functions to set attribute values on design revision
					//if (strstr(Materialclass,"Ferrous metal") == NULL)
					//{
					//	printf("2..Setting attibutes for Material class::: %s .......\n",Materialclass); fflush(stdout);
					//	setAttributesOnDesignRev(&newRev,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,t5ColourIDS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup, t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);
					//}
					//ITK_CALL(CreateEffctivity(newRev, ReveffDateFromDup, ReveffDateToDup , lifecycleS));

					printf("2..AssignProject on Revision....\n");
					ITK_CALL(AssignProject(newRev,projectcode));
				}
				else
				{
					printf("3..Revision tag not found....\n"); fflush(stdout);

					ITK_CALL(AOM_ask_value_string(latestRev,"item_revision_id",&LatestRevSeq1));
					printf("3.Latest Revision of Item: %s \n",LatestRevSeq1); fflush(stdout);
					printf("3.itemRevSeq --> %s\n\n",itemRevSeq);

					/*LatestRev1 = strtok(LatestRevSeq1,";");
					LatestSeq1 = strtok(NULL,";");

					if (strstr(LatestRev1,"NR") !=NULL)
					{
						printf("1..UA Loaded Revision is [%s,%s]....\n",item_id,LatestRev1); fflush(stdout);
						ascii_LatestRev = 1;  // set for 1st NR rev
					}
					else if ((strlen(LatestRev1) >= 1) && (strstr(LatestRev1,"NR") ==NULL))
					{
						InpRev = LatestRev1[0];
						printf("..2....%c\n",InpRev); fflush(stdout);
						ascii_LatestRev = toascii(InpRev);
					}

					if (strstr(item_revision_id,"NR") !=NULL)
					{
						printf("3..File input Revision is [%s,%s]....\n",item_id,item_revision_id); fflush(stdout);
						ascii_InputRev = 1;  // set for 1st NR rev
					}
					else if ((strlen(item_revision_id) >= 1) && (strstr(item_revision_id,"NR") ==NULL))
					{
						LRev = item_revision_id[0];
						printf("..4....%c\n",LRev); fflush(stdout);
						ascii_InputRev = toascii(LRev);
					}

					printf("3..ascii_LatestRev:[%d]  %s  %c  ",ascii_LatestRev,LatestRev1,LatestRev1[0]);
					printf("  3..ascii_InputRev:[%d]  %s  %c\n",ascii_InputRev,item_revision_id,item_revision_id[0]);

					if (ascii_LatestRev > ascii_InputRev)
					{
						printf("?????? 3..UA Loaded Revision is greater than input revision from File hence skipping [%s,%s,%s]....\n\n",item_id,item_revision_id,item_sequence_id); fflush(stdout);
						continue;
					}
					else if (ascii_LatestRev == ascii_InputRev)
					{
						if (atoi(LatestSeq1) > atoi(item_sequence_id))
						{
							printf("?????? 3..UA Loaded sequence is greater than input revision from File hence skipping [%s,%s,%s]....\n\n",item_id,item_revision_id,item_sequence_id); fflush(stdout);
							continue;
						}
					}*/

					ITK_CALL(ITEM_create_rev(item,default_empty_to_A(itemRevSeq),&RevNewSeqTag));	//added on 06.06.2017
					//ITK_CALL(ITEM_copy_rev(latestRev,itemRevSeq,&RevNewSeqTag));					//commented on 06.06.2017
					
					//////ITK_CALL(ITEM_copy_rev(latestRev,itemRevSeq1,&RevNewSeqTag));
					//////ITK_CALL(ITEM_copy_rev(latestRev,NULL,&RevNewSeqTag));

					if(RevNewSeqTag != NULLTAG)
					{
						printf("3..Revision is created....\n");
						
						//if(RES_checkout(RevNewSeqTag,"loader","loader7","/tmp",RES_EXPORT_FILE)!=ITK_ok)
						//{
						//	printf("3..RES_checkout failed.\n"); fflush(stdout);
						//}
						//else
						//{
						//	printf("3..RES_checkout is successful\n"); fflush(stdout);
						//}

						ITK_CALL(AOM_ask_value_int(RevNewSeqTag,"sequence_id",&lat_seq_id_int));
						printf("3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

						if (lat_seq_id_int != atoi(item_sequence_id))
						{
							AOM_lock(RevNewSeqTag);

							ITK_CALL ( AOM_set_value_int(RevNewSeqTag,"sequence_id",atoi(item_sequence_id)));

							ITK_CALL(AOM_save(RevNewSeqTag));
							ITK_CALL(AOM_unlock(RevNewSeqTag));

							ITK_CALL(AOM_ask_value_int(RevNewSeqTag,"sequence_id",&lat_seq_id_int));
							printf("3..3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);
						}

						
						//if((strcmp(ReveffDateFromDup,"-")==0) || (strcmp(ReveffDateToDup,"-")==0))
						//{
						//	setLifeCycle(&RevNewSeqTag,lifecycleS);
						//}
						
						ITK_CALL(RES_is_checked_out(RevNewSeqTag,&checkout));
						printf(" ???????????? 3.checkout:[%d]\n",checkout); fflush(stdout);
						if (checkout > 0)
						{
							if(RES_checkin(RevNewSeqTag)!=ITK_ok)
							{
								printf("3..RES_checkin failed.\n"); fflush(stdout);
							}
							else
							{
								printf("3..RES_checkin is successful\n"); fflush(stdout);
							}
						}

						//if((strcmp(t5PartCreDateS,"")!=0) && (strcmp(t5LastModDateS,"")!=0))
						if(strlen(t5PartCreDateS) > 9 )
						{
							printf("3..Retaining-Updating Creation/LastMod User and Date....\n"); fflush(stdout);

							ITK_CALL(setDateAttributesOnItemRev(RevNewSeqTag,t5PartCreDateS,t5LastModDateS,t5PartCreatorS,t5LastModByS));
						}
						
						setAttributesOnDesignRev(&RevNewSeqTag,parttype,projectcode,designgroup,mod_desc,DrawingNoS,DrawingIndS,Materialclass,MaterialInDrwS,MaterialThickNessS,DeignOwnUnitS,ModelIndS,ColourIndS,t5ColourIDS,WeightS,desc,t5SpareIndS,t5CMVRCertificationS,t5ClassificationHazS,t5ConfigIDS,t5DismantableS,t5DsgnDeptS,t5EnvelopeDimenS,t5HazardousContS,t5HomologationReqdS,t5ListRecSparesS,t5NcPartNoS,t5PartCodeS,t5PartPropertyS,t5PartStatusS,t5PkgStdS,t5ProductS,t5PrtCatCodeS,t5PunIntialAgS,t5PunMakeBuyIndS,t5RecoverableS,t5RecyclabilityS,t5RefPartNumberS,t5ReliabilityS,t5SpareCriteriaS,t5SurfPrtStdS,t5SamplesToApprS,t5AsmDisposalS,t5FinDisposalInstrS,t5RPDisposalInstrS,t5SPDisposalInstrS,t5WIPDisposalInstrS,t5LastModByS,t5VerCreatorS,t5CAEDocES,t5CoatedS,t5ConvDocS,t5AplCopyOfErcRevS,t5AplCopyOfErcSeqS,t5AppCodeS,t5RqstNumS,t5RsnCodeS,t5SurfaceAreaS,t5VolumeS,t5CarIntialAgencyS,t5CarMakeBuyIndiS,t5ErcIndNameS,t5PostRelReqS,t5ItmCategoryS,t5CopReqS,t5AplInvalidateS,t5PrtValiStatusS,t5DRSubStateS,t5KnxtDocIndS,t5SimValS,t5PerYieldS,t5PunStoreLocationS,t5AltPartNoS,t5RolledupWtS,t5PFDModReqdS,t5ToolIndentReqdS,CategoryNameS,LeftRhS,item_id,LeftRhPartDup, t5JsrIntialAgencyS, t5JsrMakeBuyIndiS, t5LkoIntialAgencyS, t5LkoMakeBuyIndiS, t5PnrIntialAgencyS, t5PnrMakeBuyIndiS, t5PunPCBUIntialAgencyS, t5PunPCBUMakeBuyIndiS, t5SgrIntialAgencyS, t5SgrMakeBuyIndiS,t5EstSheetReqdS,t5AhdIntialAgencySDup,t5AhdMakeBuyIndSDup,t5DwdIntialAgencySDup,t5DwdMakeBuyIndSDup,t5JdlIntialAgencySDup,t5JdlMakeBuyIndSDup,t5AhdStoreLocSDup,t5CarStoreLocSDup,t5DwdStoreLocSDup,t5JdlStoreLocSDup,t5JsrStoreLocSDup,t5LkoStoreLocSDup,t5PnrStoreLocSDup,t5PunPCBUStoreLocSDup,t5SgrStoreLocSDup);
						
						ITK_CALL(CreateEffctivity(RevNewSeqTag, ReveffDateFromDup, ReveffDateToDup , lifecycleS));

						lat_seq_id_int=0;
						ITK_CALL(AOM_ask_value_int(RevNewSeqTag,"sequence_id",&lat_seq_id_int));
						printf("33..3..Latest Sequence :[%d]  item_sequence_id:[%d]\n",lat_seq_id_int,atoi(item_sequence_id)); fflush(stdout);

						//ITK_CALL(AOM_save(RevNewSeqTag));
						//ITK_CALL(AOM_unlock(RevNewSeqTag));

						setAttributesOnDesign(&item,desc,UnitOfMeasureS,LeftRhS);

						printf("3..AssignProject on Revision....\n");
						ITK_CALL(AssignProject(RevNewSeqTag,projectcode));

						printf("3..Attributes are set on Revision....\n");
					}
					else
					{
						printf("3..New Revision object is not copied....\n"); fflush(stdout);
						fprintf(fperror,"3..Error with part number:[%s],[%s] ,New Revision object is not copied\n",item_id,itemRevSeq);
					}

					//ITK_CALL( AOM_save(RevNewSeqTag));
					//ITK_CALL( AOM_unlock(RevNewSeqTag));

					sleep(5);
				}
			}
			printf("\n----------------------------------------------------\n");
			//sleep(61);
			/*if(instanceNameTemp)
			{
				instanceName=strtok(instanceNameTemp,";");
				item_rev=strtok(NULL,";");
				item_seq=strtok(NULL,";");

				itemRevSeq = NULL;
				itemRevSeq=(char *) MEM_alloc(32);
				strcpy(itemRevSeq,item_rev);
				strcat(itemRevSeq,"*");
				strcat(itemRevSeq,item_seq);

				//item_id = genericName
				if(instanceName)
				{
					attrs[0] ="item_id";
					values[0] = (char *)instanceName;
					ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

					printf(" instance..n_tags_found:: %d\n",n_tags_found);

					if(n_tags_found>0)
					{
						item = tags_found[0];

						printf(" instance..Item Found:: %s  %s,%s\n",instanceName,item_rev,item_seq);

						//ITK_CALL(ITEM_find_revision(item,item_rev,&itemRevtag2));
						ITK_CALL(ITEM_find_revision(item,itemRevSeq,&itemRevtag2));

						ITK_CALL(GRM_list_secondary_objects_only(itemRevtag2 , NULLTAG , &n_attchs, &secondary_objects));
						printf(" instance..n_attchs == %d \n",n_attchs); fflush(stdout);

						for (k = 0; k < n_attchs; k++)
						{
							ITK_CALL(TCTYPE_ask_object_type(secondary_objects[k],&DataSetObjs));
							ITK_CALL(TCTYPE_ask_name(DataSetObjs,type_name3));

							printf("\n instance..type_name3:[%s]",type_name3);

							if (strstr(type_name3,"ProAsm")!=NULL || strstr(type_name3,"ProPrt")!=NULL )
							{
								firstItemDataSettag = secondary_objects[k];

								attrs2[0] ="item_id";
								values2[0] = (char *)item_id;
								
								//Querying with item id
								ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found2, &tags_found2));
								printf(" instance..n_tags_found2:: %d",n_tags_found2);

								if(n_tags_found2>0)
								{
									item2 = tags_found2[0];
									ITK_CALL(ITEM_find_revision(item2,itemGeneric_RevSeq,&revtag3));

									if(revtag3 != NULLTAG)
									{
										ITK_CALL(GRM_find_relation_type("IPEM_master_dependency",&tRelationFind ));

										if(tRelationFind != NULLTAG)
										{
											ITK_CALL(TCTYPE_ask_name(tRelationFind,type_name));
											printf("\n instance..Type Name:%s ..............",type_name);fflush(stdout);
										}

										ITK_CALL( GRM_find_relation( firstItemDataSettag, revtag3, tRelationFind ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n\t instance..Relation Already Exist.\n\n" ); fflush(stdout);
										}
										else
										{
											printf(" instance..GRM_create_relation before:\n");fflush(stdout);
											ITK_CALL(GRM_create_relation(firstItemDataSettag,revtag3,tRelationFind,NULLTAG,&relation));
											printf(" instance..GRM_create_relation:\n");fflush(stdout);

											if(relation != NULLTAG)
											{
												ITK_CALL(AOM_refresh (firstItemDataSettag,0));
												//printf(" instance..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(relation));
												printf(" instance..GRM_save_relation:\n\n");fflush(stdout);
											}
										}
										break;
									}
								}
							} // if condn for type_name3
						} //for loop n_attchs
					} //if(n_tags_found>0)
				} //if(instanceName)

				//Pro2_instance realtion
				if(item_id)
				{
					attrs[0] ="item_id";
					values[0] = (char *)item_id;
					ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));

					printf("\n\n generic..n_tags_found:: %d\n",n_tags_found);

					if(n_tags_found>0)
					{
						item = tags_found[0];

						printf(" generic..Item Found:: %s  %s\n",item_id,itemGeneric_RevSeq);

						ITK_CALL(ITEM_find_revision(item,itemGeneric_RevSeq,&itemRevtag2));

						ITK_CALL(GRM_list_secondary_objects_only(itemRevtag2 , NULLTAG , &n_attchs, &secondary_objects));
						printf(" generic..n_attchs == %d \n",n_attchs); fflush(stdout);

						for (k = 0; k < n_attchs; k++)
						{
							ITK_CALL(TCTYPE_ask_object_type(secondary_objects[k],&DataSetObjs));
							ITK_CALL(TCTYPE_ask_name(DataSetObjs,type_name3));

							printf(" generic..type_name3:[%s]\n",type_name3);

							if (strstr(type_name3,"ProAsm")!=NULL || strstr(type_name3,"ProPrt")!=NULL )
							{
								firstItemDataSettag = secondary_objects[k];

								attrs2[0] ="item_id";
								values2[0] = (char *)instanceName;
								
								//Querying with item id
								ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found2, &tags_found2));
								printf(" generic..n_tags_found2:: %d  for itemRevSeq: %s \n",n_tags_found2,itemRevSeq);

								if(n_tags_found2>0)
								{
									item2 = tags_found2[0];
									ITK_CALL(ITEM_find_revision(item2,itemRevSeq,&revtag3));

									if(revtag3 != NULLTAG)
									{
										ITK_CALL(GRM_find_relation_type("Pro2_instance",&tRelationFind ));

										if(tRelationFind != NULLTAG)
										{
											ITK_CALL(TCTYPE_ask_name(tRelationFind,type_name));
											printf(" generic..Type Name:%s ..............\n",type_name);fflush(stdout);
										}

										ITK_CALL( GRM_find_relation( firstItemDataSettag, revtag3, tRelationFind ,&Fndrelation));

										if(Fndrelation != NULLTAG)
										{
											printf("\n generic..Relation Already Exist.\n" ); fflush(stdout);
										}
										else
										{
											printf(" generic..GRM_create_relation before:\n");fflush(stdout);
											ITK_CALL(GRM_create_relation(firstItemDataSettag,revtag3,tRelationFind,NULLTAG,&relation));
											printf(" generic..GRM_create_relation:\n");fflush(stdout);

											if(relation != NULLTAG)
											{
												ITK_CALL(AOM_refresh (firstItemDataSettag,0));
												//printf(" generic..Before GRM_save_relation\n");fflush(stdout);
												ITK_CALL(GRM_save_relation(relation));
												printf(" generic..GRM_save_relation:\n");fflush(stdout);
											}
										}
										break;
									}
								}
							} // if condn for type_name3
						} //for loop n_attchs
					} //if(n_tags_found>0)
				} // if(item_id)
			}*/
		}
	}
	ITK_CALL(POM_logout(false));
	if(fperror)fclose(fperror);fperror=NULL;
	return status;
}
