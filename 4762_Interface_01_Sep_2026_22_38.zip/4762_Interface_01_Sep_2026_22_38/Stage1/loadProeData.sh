######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	  : Aniket P. Kadu
# Created on	  : Jan 10, 2012
# Project         : Teamcenter 8.3 Trilix
# Module	  : TCUA Proe Uploader
# Code            : loadProeData.sh
#
#######################################################################################




cd "$1"
pwd

filename="to_load"
../createRevForProe -i=allparts.txt -u=loader -p=abc



partfile=${filename}_parts.txt
echo "#DELIMITER ^" > $partfile
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile

while read line
do


	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	####qty=`echo $line |awk -F'^' '{print $6}'`

	qty=`grep -w $item quantity.txt | awk -F',' '{print $2}' | tr -d ' '`


	if [[ -z "$qty" ]]
	then
		qty=1
	fi
	
	qty=`basename $qty`

	name=$item
	unitofmes="-"
	quantity="1"

	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile

done < allparts.txt


../loadParts -i=${filename}_parts.txt -u=loader -p=abc -o=on


filename=$1.out.jt
while read line 
do


	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`
	itemname=$dataset

	revision="NR"
        jtname=`echo $line |awk -F',' '{print $2}'`
	jtname=`basename $jtname`
	if [ "$itemname" = "" ];then		
		echo "No Jt File to Copy"
	else

		if [ -f $jtname ];then

			echo "Copying $jtname"
			echo "-f=$jtname -type=DirectModel -d="$dataset/$revision" -ref=JTPART -item=$itemname -revision=$revision -ie=y -de=u -desc=jt file -use_ds_attached_to_rev_only -relationType=IMAN_Rendering -vb" >> jt_temp.txt
		else
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
		fi	
	fi
	

done < $filename

$TC_ROOT/bin/import_file -i=jt_temp.txt -u=loader -p=abc