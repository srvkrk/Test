DirPathNm=`pwd`
directory="$2"
SubDirPath="$1"/"$2"
echo "SubDirPath:  $SubDirPath"
if [[ "$DirPathNm" =~ "$SubDirPath" ]]
then
	echo "Already Present in input Directory............."
	fullpath="$DirPathNm"
else
	echo "Now Present in input Directory............."
	cd "$1"/"$2"/
	DirPathNm=`pwd`
	fullpath="$DirPathNm"
fi
pwd
if test -s inputAlf.txt
then
rm -rf inputAlf.txt
fi
if test -s "$2".out.jt
then
#ls -ltr "$2".out.jt
#cat "$2".out.jt
while read jline
do
	classNm=`echo $jline | cut -d\, -f5`
	f_DataItem=`echo $jline | cut -d\, -f8`
	f_partNo=`echo $jline | cut -d\, -f7`
	f_partRevSeq=`echo $jline | cut -d\, -f6`
	f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
	f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
	
	fname=`echo $jline | cut -d\, -f2`
	fname=`basename $fname`
	#echo "out.jt..fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	
	# below fnameSuffix is added on 10.11.2016 and ALF-JT copy logic is added
	fnameSuffix=`echo $fname | cut -d\. -f2`
	if [ "$fnameSuffix" == "jt" ];then
		fnameJt=`echo $fname | cut -d\. -f1`
		#echo "fnameSuffix: $fnameSuffix"
		if [[ "$fnameJt" =~ "_ALF" ]]
		then
			echo "ALF is present found in string"

			f_partNo=`echo $jline | cut -d\, -f9`
			echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^"
			echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^" >>  inputAlf.txt
		elif [[ "$fnameJt" =~ "_WELD" ]]
		then
			echo "WELD is present found in string"

			f_partNo=`echo $jline | cut -d\, -f9`
			echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^"
			echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^" >>  inputAlf.txt
		elif [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile" -o "$classNm" == "ProPrt" -o "$classNm" == "ProAsm" -o "$classNm" == "ProAsmI" -o "$classNm" == "ProPrtI" ];then
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^" >>  input.txt
			#echo "-f=$jtname -type=ProDrw -d="$Drwdataset/$revision" -ref=DrwFile -item=$itemname -revision=$revision -ie=y -de=u -desc=Drawing_File -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >> jt_temp.txt
			#echo "-f=$jtname -type=PDF -d="$Drwdataset/$revision" -ref=PDF_Reference -item=$itemname -revision=$revision -ie=y -de=u -desc=PDF_File -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >> jt_temp.txt
		fi
	fi
done < "$directory".out.jt
if test -s inputAlf.txt
then
	ls -ltr inputAlf.txt
	sort -u inputAlf.txt > inputAlf.txt1
	mv inputAlf.txt1 inputAlf.txt
	chmod 777 inputAlf.txt
	echo "**AlfJtLoad.sh--Going to create ALF datasets...."
	/user/rrr05503/Shells/TmlDataSetLoadProE -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=inputAlf.txt
	if [ $? != 0 ]
	then
		echo "Problem in TmlDataSetLoadProE  AlfJtLoad.sh  $directory"
		exit 1
	fi
	echo "**AlfJtLoad.sh--Going to Upload ALF datasets on bomline...."
	while read jline
	do
		classNm=`echo $jline | cut -d\, -f5`
		f_partNo=`echo $jline | cut -d\, -f7`
		f_DataItem=`echo $jline | cut -d\, -f8`
		child=`echo $jline | cut -d\, -f9`
		ImmidiateParent=`echo $jline | cut -d\, -f10`

		f_partRevSeq=`echo $jline | cut -d\, -f6`
		f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
		f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
			
		fname=`echo $jline | cut -d\, -f2`
		fname=`basename $fname`
		#echo "out.jt..fname: $fname"
		echo $fname | grep '/' >/dev/null 2>&1
			
		# below fnameSuffix is added on 10.11.2016 and ALF-JT copy logic is added
		fnameSuffix=`echo $fname | cut -d\. -f2`
		if [ "$fnameSuffix" == "jt" ];then
			JtNm=`echo $jline | cut -d\, -f1`

			if [[ "$ImmidiateParent" == " " ]]
			then
				ImmidiateParent=$f_partNo
				echo "Copying Top Parent as immidiate parent found blank....$ImmidiateParent"
			fi

			if [[ "$JtNm" =~ "_ALF" ]]
			then
				#echo $jline
				#echo "ALF is present found in string [$JtNm]   [$f_DataItem]"
				#echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^"

				AlfPrtRev=`grep -iw $child allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $child | cut -d"^" -f3`
				AlfPrtSeq=`grep -iw $child allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $child | cut -d"^" -f4`

				if [[ "$ImmidiateParent" == " " ]]
				then
					echo "$f_partNo^$f_partRevSeq^$f_partSeq^$fname^$child^$child^-^$AlfPrtRev^$AlfPrtRev^ --- skipping As parent is blank"
				else
					echo "$f_partNo^$f_partRevSeq^$f_partSeq^$fname^$child^$child^$ImmidiateParent^$AlfPrtRev^$AlfPrtRev^"

/user/rrr05503/Shells/testCode_new1 -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$f_partNo -j="$f_partRevSeq" -k=$f_partSeq -m="Design Revision" -ajt=$fname -jt=$child -Child=$child -Parent=$ImmidiateParent
				fi
			elif [[ "$JtNm" =~ "_WELD" ]]
				then
				#echo "WELD is present found in string [$JtNm]   [$f_DataItem]"
				#echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^"

				AlfPrtRev=`grep -iw $child allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $child | cut -d"^" -f3`
				AlfPrtSeq=`grep -iw $child allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $child | cut -d"^" -f4`

				if [[ "$ImmidiateParent" == " " ]]
				then
					echo "$f_partNo^$f_partRevSeq^$f_partSeq^$fname^$child^$child^-^$AlfPrtRev^$AlfPrtRev^ --- skipping As parent is blank"
/user/rrr05503/Shells/testCode_new1 -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$f_partNo -j="$f_partRevSeq" -k=$f_partSeq -m="Design Revision" -ajt=$fname -jt=$child -Child=$child -Parent=$f_partNo
				else
					echo "$f_partNo^$f_partRevSeq^$f_partSeq^$fname^$child^$child^$ImmidiateParent^$AlfPrtRev^$AlfPrtRev^"
/user/rrr05503/Shells/testCode_new1 -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$f_partNo -j="$f_partRevSeq" -k=$f_partSeq -m="Design Revision" -ajt=$fname -jt=$child -Child=$child -Parent=$ImmidiateParent
				fi
			fi
		fi
	done < "$2".out.jt
else
echo -e "\n\n ALF jt is not present in Assembly $1  $2 \n"
fi
fi
echo "Shell AlfJtLoad.sh process is finished for  $2.."
