######################################################################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author	: Rupali Rane.
# Created on	: Nov 21, 2016
# Project	: Teamcenter 10.1
# Module	: TCUA Proe Downloader
# Code		: TmlGetSubAssyProeData.sh
#
# Modification History :
# S.No		Date			Modified By     Modification Notes
# ------	-----------		-------------	--------------------------------------------------------------------------------------
#
#######################################################################################################################################
echo "----------------------------------- TmlGetSubAssyProeData.sh --------------------------------------------------------------------------"
echo "Inside sub Shell TmlGetSubAssyProeData.sh to download sub Proe assembly data....$1"
var_path=`pwd`
echo $var_path
var_path2=`basename $var_path`
echo "var_path2: $var_path2"
if [ $var_path2 = "$1" ]
then
echo "1..TmlGetSubAssyProeData.sh..var_path:::::::::: $var_path"
else
cd "$1"
var_path=`pwd`
echo "2..TmlGetSubAssyProeData.sh..var_path:::::::::: $var_path"
fi
mainDir=`pwd`
while read SubAssyPart
do
echo "*******TmlGetSubAssyProeData...Input: " $SubAssyPart
if [[ "$SubAssyPart" =~ "/" ]]
then
	continue
fi
if [[ "$SubAssyPart" =~ " " ]]
then
SubAssyPart=`echo $SubAssyPart |cut -d" " -f1`
fi
echo ${#SubAssyPart}
if [ ${#SubAssyPart} == 11 ]
then
#SubAssyPartNew=`echo ${SubAssyPart:10:1}`
SubAssyPartNew=`echo $SubAssyPart | tr 'a-z' 'A-Z'`
else
SubAssyPartNew=$SubAssyPart
fi
if [[ "$1" = "$SubAssyPartNew" ]]
then
continue
fi
mkdir $SubAssyPart
cd "$SubAssyPart"
/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetProEPartList Loader 123loader $SubAssyPartNew $SubAssyPart.PartList.txt $SubAssyPart.CatiaPartList.txt
if [ $? != 0 ]
then
	echo "TmlGetSubAssyProeData....Problem in GetPartList"
	exit 1
fi
SubAssyRecordCnt=0
cat $SubAssyPart.PartList.txt | awk '!seen[$0]++' > $SubAssyPart.PartList.txt1
mv $SubAssyPart.PartList.txt1 $SubAssyPart.PartList.txt
asmPartCnt=`grep -i ".asm." "${SubAssyPart}.PartList.txt" | egrep -v "_asm" | wc -l`
if [ $asmPartCnt = 0 ]; then
echo "$SubAssyPart is attached to prt DataItem hence continueing......."
cd ..
rm -rf $SubAssyPart
continue
fi
while read l_line
do
	echo "*******TmlGetSubAssyProeData...Line: " $l_line
	proedi=`echo $l_line |awk -F',' '{print $1}'`
	proediSuffixTmp=`echo $l_line |awk -F',' '{print $1}'`
	proeseq=`echo $l_line |awk -F',' '{print $2}'`
	proe_owner_dir=`echo $l_line |awk -F',' '{print $3}'`
	proe_owner=`echo $l_line |awk -F',' '{print $4}'`
	directory=`echo $l_line |awk -F',' '{print $5}'`
	echo "**Directory name is--------->$directory"
	proediSuffix=`echo $proediSuffixTmp |cut -d"." -f2`
	if [ $proediSuffix = "prt" ]; then
		echo "$directory is attached to prt DataItem hence continueing .."
		continue
	fi
	#directory=`basename $proedi`
	mkdir $directory
	cd "$directory"
	AssyDirFile=$(pwd)
	echo "SubAssyDirFile: $AssyDirFile"
	echo " SubAssyRecordCnt -------> $SubAssyRecordCnt "
	echo " Doubt proe_di -------> $proedi "
	echo " Doubt proeseq -------> $proeseq "
	echo " Doubt proe_owner_dir -------> $proe_owner_dir "
	echo " Doubt proe_owner -------> $proe_owner "
	echo " dir name is---------> $directory"

	echo "   Input:  $proedi $proeseq $proe_owner_dir $proe_owner"
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetJTAndProeInfo Loader 123loader "$proedi" "$proeseq" "$proe_owner_dir" "$proe_owner" ${directory}.out.proe ${directory}.out.file2.jt.temp ${directory}.proe
	if [ $? != 0 ]
	then
	echo "Problem in TmlGetJTAndProeInfo"
	exit 1
	fi
	echo "directory is :---> ${directory}.out.proe"
	cat AllPartAllRevFile.txt | awk '!seen[$0]++' > AllPartAllRevFile.txt1
	mv AllPartAllRevFile.txt AllPartAllRevFile.txt_org
	mv AllPartAllRevFile.txt1 AllPartAllRevFile.txt
	sort -u GroupChildCount.txt > GroupChildCount.txt1
	mv GroupChildCount.txt1 GroupChildCount.txt
	sort -u GroupChildRelation.txt > GroupChildRelation.txt1
	mv GroupChildRelation.txt1 GroupChildRelation.txt
	echo "RecordCnt: $RecordCnt And Previous directory Filepath: " $prevDirFile
	while read pline
	do
		echo $pline
		proe_di=`echo $pline |awk -F',' '{print $1}'`
		proe_di_w=`echo $pline |awk -F',' '{print $2}'`
		proe_seq=`echo $pline |awk -F',' '{print $4}'`
		proe_ow_dir=`echo $pline |awk -F',' '{print $6}'`
		proe_ow=`echo $pline |awk -F',' '{print $7}'`
		level=`echo $pline |awk -F',' '{print $10}'`
		filename=`basename $proe_di`
		proe_partnumber=`basename $proe_di`
		echo " Doubt proe_di ------->$proe_di"
		echo " Doubt proe_seq ------->$proe_seq"
		echo " Doubt proe_ow_dir ------->$proe_ow_dir"
		echo " Doubt proe_ow ------->$proe_ow"
		echo " Doubt level ------->$level"
		echo " Doubt proe_partnumber ------->$proe_partnumber"
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetTCPartInfo Loader 123loader "$proe_di" "$proe_seq" "$proe_ow_dir" "$proe_ow" allparts_"$directory".txt $level "$proe_partnumber" allpartsAllRev_"$directory".txt "$directory"
		if [ $? != 0 ]
		then
		echo "Problem in TmlGetTCPartInfo"
		exit 1
		fi
		done < ${directory}.out.proe
		RecordCnt=`expr $RecordCnt + 1`
		#RecordCnt=$((RecordCnt+1))
		num_files=`cat ${directory}.out.file2.jt.temp | wc -l`
		#num_g_files=`expr $num_files - 1`
		echo "  num_files ------->$num_files "
		#echo "  num_g_files ------->$num_g_files "
		tail -n $num_files ${directory}.out.file2.jt.temp > ${directory}.out.file2.jt.temp2
		sort -u ${directory}.out.file2.jt.temp2 > ${directory}.out.jt
		#sort -u GenericInstance.txt > GenericInstance_a.txt
		#mv GenericInstance_a.txt GenericInstance.txt
		sort -u LhRhPartDet.txt > LhRhPartDet_a.txt
		mv LhRhPartDet_a.txt LhRhPartDet.txt
		echo "Before generating file for ASM.."
		grep -i ".asm" "${directory}.out.proe" | egrep -v "_asm" > allasmmebly.txt
		if test -s allasmmebly.txt
		then
		echo "In if condition to generate file for ASM.."
		cat allasmmebly.txt | awk '!seen[$0]++' > allasmmebly.txt1
		mv allasmmebly.txt1 allasmmebly.txt
		fi
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyProeItems.sh allasmmebly.txt /proj/ProAsmMemberCheck/
		while read aline
		do
			proe_di=`echo $aline |awk -F',' '{print $1}'`
			proe_di=`basename $proe_di`
			cd /proj/ProAsmMemberCheck
			Class=`echo $aline |cut -d\, -f11`
			InstanceAsmName_inc1=`echo $aline |cut -d\, -f1`
			InstanceAsmName_inc=`basename $InstanceAsmName_inc1`
			ParentAsmName1=`echo $aline |cut -d\, -f2`
			if [ $Class = "ProAsmI" ]; then
				ParentAsmName=`echo "$ParentAsmName1"`
			else
				ParentAsmName=`basename $ParentAsmName1`
				SeqVersion=`echo $ParentAsmName |cut -d\. -f3`
			fi
			PFullPath=`echo $aline |cut -d\, -f3`
			InstSeq=`echo $aline |cut -d\, -f4`
			ParentSeq=`echo $aline |cut -d\, -f5`
			InstaceOwnDir=`echo $aline |cut -d\, -f6`
			InstaceOwn=`echo $aline |cut -d\, -f7`
			ParentOwn=`echo $aline |cut -d\, -f8`
			ParentDirOwn=`echo $aline |cut -d\, -f9`	
			Level=`echo $aline |cut -d\, -f10`
			echo " InstanceAsmName_inc1 ------->$InstanceAsmName_inc1"
			echo " InstanceAsmName_inc ------->$InstanceAsmName_inc"
			echo " ParentAsmName1 ------->$ParentAsmName1"
			echo " ParentAsmName ------->$ParentAsmName"
			echo " PFullPath------->$PFullPath"
			echo " InstSeq ------->$InstSeq"
			echo " ParentSeq ------->$ParentSeq"
			echo " InstaceOwnDir------->$InstaceOwnDir"
			echo " InstaceOwn ------->$InstaceOwn"
			echo " ParentOwn ------->$ParentOwn"
			echo " ParentDirOwn ------->$ParentDirOwn"
			echo " Level ------->$Level"
			echo " Class ------->$Class"
			echo " $directory------->$directory"
			/user/omfprod/multicad_scripts/GetPosMatrix/Get_pos_Matrix.sh "$InstanceAsmName_inc" "$ParentAsmName" "$PFullPath" "$InstSeq" "$ParentSeq" "$InstaceOwnDir" "$InstaceOwn" "$ParentOwn" "$ParentDirOwn" "$Level" "$Class" "$directory"
		cd -
		filename=`echo $proe_di |awk -F'.' '{print $1}'`
		filename=`echo $InstanceAsmName_inc |awk -F'.' '{print $1}'`
		filename1=`echo $filename |awk -F'/' '{print $NF}'`
		#filename=${filename1}*.pos
		if [[ "$filename1" =~ "<" ]]; then
			filenameTemp=`echo "$filename1" | cut -d"<" -f1`
			filename=${filenameTemp}*.pos
		else
			if [ ! -z "$SeqVersion" ]; then
				filename=${filename1}_"$SeqVersion".pos
			else
				filename=${filename1}*.pos
			fi
		fi
		echo  " filename---->$filename"
		mv /proj/ProAsmMemberCheck/$filename ./
		prevchild=""
			echo " matrixfname shub b ---->$matrixfname "
			for matrixfname in `ls -ltr $filename | awk '{print $9}'`
			do
				while read mline
				do
					echo " testing 1111111111 "
					parentTemp=`echo $mline |awk -F',' '{print $1}'`
					f_ParentCnt=`grep $parentTemp allparts_"$directory".txt | awk ' { print $1 } ' | grep -i $parentTemp | sort -u | wc -l`
					if [[ $f_ParentCnt = 0 ]]
					then
						echo "1..parent is :" $parentTemp
						f_Parent1=`grep -iw $parentTemp allparts_"$directory".txt | awk ' { print $1 } ' | grep -i $parentTemp | sort -u`
						parent=`echo $f_Parent1 | awk -F'^' '{print $2}'`
						echo "2..parent is :" $parent
					else
						if [[ $parentTemp = "" ]]
						then
							echo "Parent $parentTemp  is not found, Please re-check "
							echo "Parent $parentTemp  is not found, Please re-check " >> "$mainDir"/"$1"_ErrorMessages.txt
							continue
						fi
						parent=$parentTemp
					fi
					pchar1="$(echo $parent | head -c 1)"
					echo "Parent length:: " ${#parent}  $pchar1
					if [ "$pchar1" = "g" ] || [ ${#parent} = 11 ];then
						Parent1=`echo "$parent" | tr '[a-z]' '[A-Z]'`
						echo "Parent1:: " $Parent1
					else
						#Parent1=`echo "$parent" | tr '[a-z]' '[A-Z]'`
						Parent1=`echo "$parent"`
						echo "Parent1== " $Parent1
					fi
					child=`echo $mline |awk -F',' '{print $2}'`
					echo "Parent caps is :" $Parent1
					echo "child is :" $child
					echo "prevchild is :" $prevchild
					# below if condition is added on 12.01.2017
					if [[ "$child" =~ "_SWP" ]]
					then
						aSWP=$child
						#child=`echo "${aSWP::-4}"`
						child=`echo "${aSWP/%_SWP/}"`
						echo "SWP is present found in string ....new string: $child"
					fi
					f_child=`grep -iw $child allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $child`
					child1=`echo $f_child | awk -F'^' '{print $2}'`
					echo "child1 is : " $child1
					if [[ $child1 = "" ]]
					then
					child1=$child
					echo "2.child1 is :" $child1
					fi
					suppFlag=`echo $mline |awk -F',' '{print $20}'`
					echo "suppFlag    :" $suppFlag
					act_matrix=`echo $mline |awk -F',' '{print $3","$4","$5","$6","$7","$8","$9","$10","$11","$12","$13","$14","$15","$16","$17","$18"," ","$20","}'`
					echo "act_matrix is : $act_matrix"
					if [ "$child" = "$prevchild" ];then
						echo "inside if"
						echo $act_matrix >> $Parent1.$child1.mat.txt
					else
						echo "inside else"
						echo $act_matrix >> $Parent1.$child1.mat.txt
						prevchild=$child
					fi
					#### Below is added on 29.03.2017 to copy child matrix on Immidiate Parent Group ###
					grpChildCnt=`grep $child1 GroupChildRelation.txt | wc -l`
					grpChild=`grep $child1 GroupChildRelation.txt`
					if [[ "$grpChildCnt" != "0" ]]; then
						GrpParent=`echo $grpChild |cut -d\, -f1`
						StringTmp="FALSE"
						if [ -f GroupChildCount.txt ]
						then
							grpChildCntRecTmp=`grep $GrpParent GroupChildCount.txt`
							grp=`echo $grpChildCntRecTmp |cut -d\, -f1`
							grpRec1=`echo $grpChildCntRecTmp |cut -d\, -f2`
							grpRec2=`echo $grpChildCntRecTmp |cut -d\, -f3`
							StringTmp=`grep $grp AssyBomSuperSet.txt | grep $child1 | sort -u | awk -F',' '{print $10}'`
						fi
						cp  $Parent1.$child1.mat.txt $Parent1.$GrpParent.mat.txt
						echo "1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0, ,$StringTmp," > $GrpParent.$child1.mat.txt
					fi
					######################
					#sort -u $Parent1.$child1.mat.txt >$Parent2.$child2.mat.txt
					#rm -f  $Parent1.$child1.mat.txt
					echo "Matrix Parent-Chaild File Name: $Parent1.$child1.mat.txt"
				done < "$matrixfname"	
			done
		done < allasmmebly.txt
		mat_file_name=`ls *.mat.txt`
		echo $mat_file_name
		for i in $mat_file_name
		do
			j=$i".123txt"
			echo "File name is :$i"	
			echo "File name jjjjjjjjjjjjjis :$j"	
			cp $i $j
			echo "File name after new is :$j"
			sort -u $j >$i
			echo "File name after sort is :$i"
			parentPrt=`echo $i |awk -F'.' '{print $1}'`
			partnumber=`echo $i |awk -F'.' '{print $2}'`
			qty=`cat $i | wc -l`
			#echo "$partnumber,$qty" >> quantity.txt
			echo "$parentPrt,$partnumber,$qty" >> quantity.txt
		   rm -f $j
		done
		echo "Current working Directory is `pwd`"
		pos_file_Cnt=`ls *.pos | wc -l`
		while read asm
		do
			AsmPart=`echo $asm |awk -F',' '{print $1}'`
			echo "$AsmPart" >> allasmmebly.txt_asm
		done < allasmmebly.txt
		sort -u allasmmebly.txt_asm > allasmmebly.txt_asm1
		mv allasmmebly.txt_asm1 allasmmebly.txt_asm
		#asmPos_Cnt=`cat allasmmebly.txt | wc -l`
		asmPos_Cnt=`cat allasmmebly.txt_asm | wc -l`
		mat_file_Cnt=`ls *.mat.txt | wc -l`
		if [ $pos_file_Cnt = 0 ]
		then
		echo "Pos T-matrix file is not downloaded for assembly [$directory]" >> "$mainDir"/"$1"_ErrorMessages.txt
		fi
		if [ $asmPos_Cnt != $pos_file_Cnt ]
		then
		echo "Pos T-matrix file is not downloaded for all assemblies in directory [$directory]" >> "$mainDir"/"$1"_ErrorMessages.txt
		fi
		cat LhRhPartDet.txt >> "$mainDir"/"$1".SubAssyPartList_1.txt
		cat AllPartAllRevFile.txt >> "$mainDir"/AllPartAllRevFile_"$1".txt
		echo "Current working Directory22222222222 is `pwd`"
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems.sh ${directory}.out.jt .
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyProeItems.sh ${directory}.proe .
		ls -ltr chk_file.*
		if test -s chk_file.* 
		then
		rm -rf chk_file.*
		fi
		prevDirFile=$(pwd)
		cd ..
		if [ $proediSuffix = "prt" ]; then
		rm -rf $directory
		fi
	done < $SubAssyPart.PartList.txt
wait
cd ..
done < $1.SubAssyPartList.txt
