#cd "$1"
var_path=`pwd`
echo $var_path
var_path2=`basename $var_path`
echo "var_path2: $var_path2"
if [ $var_path2 == "$1" ]
then
	echo "1..catFile.sh..var_path:::::::::: $var_path"
else
	cd "$1"
	var_path=`pwd`
	echo "2..catFile.sh..var_path:::::::::: $var_path"
fi
mainDir=`pwd`
fileLhRh=LhRhPartDet.txt
while read l_line
do
echo "******* Input: " $l_line
directory=`echo $l_line |awk -F',' '{print $5}'`
echo "**Directory name is--------->$directory"
cd "$directory"
#echo "------------------------- $directory--------------------------------" >> "$mainDir"/AllPartAllRevFile_"$1".txt
cat AllPartAllRevFile.txt >> "$mainDir"/AllPartAllRevFile_"$1".txt
cat GenericInstance.txt >> "$mainDir"/GenericInstance_"$1".txt
if [[ -f $fileLhRh ]] && [[ ! -s $fileLhRh ]]; then 
	echo "LhRhPartDet File is empty" ;
else
	cat LhRhPartDet.txt >> "$mainDir"/LhRhPartDet_"$1".txt
fi
cd ..
done < $1.PartList.txt
pwd
while read SubAssyPart
do
	echo "TmlGetSubAssyProeData...Input: " $SubAssyPart
	if [ -d "$SubAssyPart" ]; then
		cd "$SubAssyPart"
		while read l_line
		do 
			directory=`echo $l_line |awk -F',' '{print $5}'`
			cd "$directory"
			#echo "------------------------- $directory--------------------------------" >> "$mainDir"/AllPartAllRevFile_"$1".txt
			cat AllPartAllRevFile.txt >> "$mainDir"/AllPartAllRevFile_"$1".txt
			cat GenericInstance.txt >> "$mainDir"/GenericInstance_"$1".txt
			if [[ -f $fileLhRh ]] && [[ ! -s $fileLhRh ]]; then 
				echo "LhRhPartDet File is empty" ;
			else
				cat LhRhPartDet.txt >> "$mainDir"/LhRhPartDet_"$1".txt
			fi
			cd ..
		done < $SubAssyPart.PartList.txt
		cd ..
	else
		echo "		Directory  $SubAssyPart  not exist in folder..."
	fi
done < $1.SubAssyPartList.txt
cat AllPartAllRevFile_"$1".txt | awk '!seen[$0]++' > AllPartAllRevFile_"$1".txt1
mv AllPartAllRevFile_"$1".txt1 AllPartAllRevFile_"$1".txt
cat GenericInstance_"$1".txt | awk '!seen[$0]++' > GenericInstance_"$1".txt1
mv GenericInstance_"$1".txt1 GenericInstance_"$1".txt
cat LhRhPartDet_"$1".txt | awk '!seen[$0]++' > LhRhPartDet_"$1".txt1
mv LhRhPartDet_"$1".txt1 LhRhPartDet_"$1".txt
