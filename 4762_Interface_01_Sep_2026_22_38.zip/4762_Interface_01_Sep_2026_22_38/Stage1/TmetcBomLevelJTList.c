/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File		 :   BomLevelJtList.c
*  Author	 :   Aniket P. Kadu
*  Module        :   TCUA Downloader.
*  Purpose       :   To Download JT Parts.
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <ReadFile.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#define NUMBER 5000

//From TC Part Getting the Visualization Files...
status GetTCPartInfoForContextBOMViewJTCreationBOMLevel(ObjectPtr TCPartObjP,FILE *fp,FILE *catiafp,FILE *Reffp,FILE *Refcatiafp,integer* mfail )
{

	int LatestDoc=0;
	int DataItem=0;
	int VisFile=0;

	string  TCPartOwnerNameDupS=NULL;
	string  TCPartOwnerNameS=NULL;
	string  DocBIClassNameDupS=NULL;
	string  DocBIClassNameS=NULL;
	string  VisFileRelPathDupS=NULL;
	string  VisFileRelPathS=NULL;
	string  VisFileWorkingRelativePathDupS=NULL;
	string  VisFileWorkingRelativePathS=NULL;
	string  VisFileSequenceDupS=NULL;
	string  VisFileSequenceS=NULL;
	string  VisFileClassDupS=NULL;
	string  VisFileClassS=NULL;
	string  VisFileOwnerNameDupS=NULL;
	string  VisFileOwnerNameS=NULL;
	string  TCPartNumberDupS=NULL;
	string  TCPartNumberS=NULL;
	string  TCPartRevisionDupS=NULL;
	string  TCPartRevisionS=NULL;
	string  TCPartSequenceDupS=NULL;
	string  TCPartSequenceS=NULL;
	string  TCPartTypeDupS=NULL;
	string  TCPartTypeS=NULL;
	string  VisFileOwnerDirNameS=NULL;
	string  VisFileOwnerDirNameDupS=NULL;
	string  DiClassS=NULL;
	string  DiClassDupS=NULL;
	string CatiaWorkingPathDupS=NULL;
	string CatiaWorkingPathS=NULL;
	string CatiaRelPathS=NULL;
	string CatiaRelPathDupS=NULL;
	string CatiaSequenceDupS=NULL;
	string CatiaSequenceS=NULL;
	string CatiaOwnerDirNameDupS=NULL;
	string CatiaOwnerDirNameS=NULL;
	string CatiaOwnerNameDupS=NULL;
	string CatiaOwnerNameS=NULL;
	string fullPathattrDup=NULL;
	string fullPathattr=NULL;
	string CatiaDisS=NULL;
	string CatiaDisDupS=NULL;

	SetOfObjects  JTUsesPartFilePhyItemSO = NULL ;
	SetOfObjects  JTUsesPartFileRelSO = NULL ;
	SetOfObjects  DocumentSO = NULL ;
	SetOfObjects  DocumentRelSO = NULL ;
	SetOfObjects  LatestDocSO = NULL ;
	SetOfObjects  LatestRelDocSO = NULL ;
	SetOfObjects  DataItemSO = NULL ;
	SetOfObjects  VisualizationFileSO = NULL ;

	ObjectPtr LatestDocObjP=NULL;
	ObjectPtr NewDataItemObjP=NULL;
	ObjectPtr DataItemObjP=NULL;
	ObjectPtr NewVisFileObjP=NULL;
	ObjectPtr VisFileObjP=NULL;
	ObjectPtr proprtrevObjP=NULL;

	t5MethodInit("GetTCPartInfoForContextBOMViewJTCreationBOMLevel");

	//objDump(TCPartObjP);
	t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&TCPartOwnerNameDupS));
	TCPartOwnerNameS=nlsStrDup(TCPartOwnerNameDupS);
	printf("\n GetTCPartInfoForContextBOMViewJTCreationBOMLevel \n"); fflush(stdout);
	printf("\n Executing Function For Resultant TC Part OwnerNameS:%s \n",TCPartOwnerNameS); fflush(stdout);

	t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&TCPartTypeDupS));
	TCPartTypeS=nlsStrDup(TCPartTypeDupS);
	//-------
	t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&TCPartNumberDupS));
	TCPartNumberS=nlsStrDup(TCPartNumberDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&TCPartRevisionDupS));
	TCPartRevisionS=nlsStrDup(TCPartRevisionDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&TCPartSequenceDupS));
	TCPartSequenceS=nlsStrDup(TCPartSequenceDupS);

	printf("\n Executing Part Number:[%s]",TCPartNumberS);fflush(stdout);
	printf("\n Executing Function For Resultant TC Part TCPartTypeS:%s \n",TCPartTypeS); fflush(stdout);

	if (!nlsStrCmp(TCPartOwnerNameS,"WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"Release Vault") || nlsStrStr(TCPartOwnerNameS,"CE Vault")!=NULL)
	{
		t5CheckMfail(ExpandObject2(PartDocClass,TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail));

		t5CheckMfail(t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail));

		printf("\n LatestDocSO --->:[%d]",setSize(LatestDocSO));fflush(stdout);

		for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
		{
			LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

			t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
			DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
			printf("\n Document Class:[%s]",DocBIClassNameS);
			if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulCad")==0) )
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));

				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));

					//	if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"ProPrt")==0  || nlsStrCmp(DiClassS,"ProAsm")==0 || nlsStrCmp(DiClassS,"ProDrw")==0 || nlsStrCmp(DiClassS,"x0CatPrd")==0) && (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0 || nlsStrCmp(DocBIClassNameS,"t5MulCad")==0 || nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0 || nlsStrCmp(DocBIClassNameS,"DesDoc")==0 ))
						if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"x0CatPrd")==0) || nlsStrCmp(DiClassS,"x0CatDrw")==0 )
						{
						t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));

						if(setSize(VisualizationFileSO)>0)
						{

							for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
							{
								NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

								t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));
								t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
								VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
								VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
								VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
								VisFileClassS=nlsStrDup(VisFileClassDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
								VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
								VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);


									if ( nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL || nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL || nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL)
									{
												fprintf(catiafp,"%s",VisFileClassS);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s",VisFileOwnerNameS);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s",fullPathattrDup);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s\n",VisFileRelPathS);
												fflush(catiafp);

												fprintf(fp,"%s",TCPartNumberS);
												fprintf(fp,"^");
												fprintf(fp,"%s",TCPartRevisionS);
												fprintf(fp,"^");
												fprintf(fp,"%s",TCPartSequenceS);
												fprintf(fp,"^");
												fprintf(fp,"%s",CatiaDisS);
												fprintf(fp,"^");
												fprintf(fp,"%s",VisFileRelPathS);
												fprintf(fp,"^");

												printf("\n CatiaDisS :%s:\n",CatiaDisS); fflush(stdout);
												printf("\n fullPathattrDup :%s:\n",fullPathattrDup); fflush(stdout);

												if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"WIP"))
										         {
												 fprintf(fp,"%s","WIP_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"CE"))
										         {
												 fprintf(fp,"%s","CE_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"omfcadjtvault") )
										         {
												 fprintf(fp,"%s","JT_CAD_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf"))
										           {
												     fprintf(fp,"%s","Rel_Vault_Loc_Pdf");
												    }
												   else
												   {
												       fprintf(fp,"%s",VisFileOwnerDirNameS);
												    }
												fprintf(fp,"^");
												fprintf(fp,"%s",fullPathattrDup);
												fprintf(fp,"^");
												fprintf(fp,"1\n");
												fflush(fp);
									}

							}

						 }
					   }
					}

				  }
			}
			else if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
			{
                t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));

				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));
						if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"x0CatDrw")==0  ||  nlsStrCmp(DiClassS,"x0CatPrd")==0) )
						{
						t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));

						if(setSize(VisualizationFileSO)>0)
						{

							for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
							{
								NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

								t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));
								t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
								VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
								VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
								VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
								VisFileClassS=nlsStrDup(VisFileClassDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
								VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
								VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);


									if ( nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL || nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL || nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL)
									{
												fprintf(catiafp,"%s",VisFileClassS);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s",VisFileOwnerNameS);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s",fullPathattrDup);
												fprintf(catiafp,",");
												fprintf(catiafp,"%s\n",VisFileRelPathS);
												fflush(catiafp);

												fprintf(fp,"%s",TCPartNumberS);
												fprintf(fp,"^");
												fprintf(fp,"%s",TCPartRevisionS);
												fprintf(fp,"^");
												fprintf(fp,"%s",TCPartSequenceS);
												fprintf(fp,"^");
												fprintf(fp,"%s",CatiaDisS);
												fprintf(fp,"^");
												fprintf(fp,"%s",VisFileRelPathS);
												fprintf(fp,"^");

												printf("\n CatiaDisS :%s:\n",CatiaDisS); fflush(stdout);
												printf("\n fullPathattrDup :%s:\n",fullPathattrDup); fflush(stdout);

												if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"WIP"))
										         {
												 fprintf(fp,"%s","WIP_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"CE"))
										         {
												 fprintf(fp,"%s","CE_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"omfcadjtvault") )
										         {
												 fprintf(fp,"%s","JT_CAD_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf"))
										           {
												     fprintf(fp,"%s","Rel_Vault_Loc_Pdf");
												    }
												   else
												   {
												       fprintf(fp,"%s",VisFileOwnerDirNameS);
												    }
												fprintf(fp,"^");
												fprintf(fp,"%s",fullPathattrDup);
												fprintf(fp,"^");
												fprintf(fp,"1\n");
												fflush(fp);
									}

							}

						  }
						}
					}

				  }
			}else
			{
				 //fprintf(fp,"SKIPJT\n");
			   printf("\n Not a Valid Doc class \n"); fflush(stdout);
			}
		}

		///////////////////////For refrences /////////////////////////


        DocumentSO = NULL;
        DocumentRelSO = NULL;
        LatestDocSO = NULL;
        LatestRelDocSO = NULL;
		t5CheckMfail(ExpandObject2(InfoDwgClass,TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail));

		t5CheckMfail(t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail));

		printf("\n setSize(LatestDocSO):[%d]",setSize(LatestDocSO));

		for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
		{
			LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

			t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
			DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
			printf("\n Document Class:[%s]",DocBIClassNameS);
     		if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulCad")==0) )
	//		if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0))
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));

				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));


						t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));

						if(setSize(VisualizationFileSO)>0)
						{

							for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
							{
								NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

								t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));
								t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
								VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
								VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
								VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
								VisFileClassS=nlsStrDup(VisFileClassDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
								VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
								VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

                                    printf("\n fullPathattrDup:[%s]",fullPathattrDup);
                                    printf("\n VisFileRelPathS:[%s]",VisFileRelPathS);


									if ( nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL || nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL || nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL)
									{
												fprintf(Refcatiafp,"%s",VisFileClassS);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s",VisFileOwnerNameS);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s",fullPathattrDup);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s\n",VisFileRelPathS);
												fflush(Refcatiafp);

												fprintf(Reffp,"%s",TCPartNumberS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",TCPartRevisionS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",TCPartSequenceS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",CatiaDisS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",VisFileRelPathS);
												fprintf(Reffp,"^");
				                                if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"WIP"))
										         {
												 fprintf(Reffp,"%s","WIP_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"CE"))
										         {
												 fprintf(Reffp,"%s","CE_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"omfcadjtvault") )
										         {
												 fprintf(Reffp,"%s","JT_CAD_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf"))
										           {
												     fprintf(Reffp,"%s","Rel_Vault_Loc_Pdf");
												    }
												   else
												   {
												       fprintf(Reffp,"%s",VisFileOwnerDirNameS);
												   }

												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",fullPathattrDup);
												fprintf(Reffp,"^");
												fprintf(Reffp,"1");
												fprintf(Reffp,"^");
												fprintf(Reffp,"Ref\n");
												fflush(Reffp);
									}

							}

						}
					}

				  }
			}else if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));

				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));


						t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));

						if(setSize(VisualizationFileSO)>0)
						{

							for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
							{
								NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

								t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));
								t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
								VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&CatiaDisDupS));
								CatiaDisS=nlsStrDup(CatiaDisDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
								VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
								VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
								VisFileClassS=nlsStrDup(VisFileClassDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
								VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);
								t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
								VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);
								t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));
								t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
								fullPathattrDup=nlsStrDup(fullPathattr);

                                    printf("\n fullPathattrDup:[%s]",fullPathattrDup);
                                    printf("\n VisFileRelPathS:[%s]",VisFileRelPathS);


									if ( nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL || nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL || nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL)
									{
												fprintf(Refcatiafp,"%s",VisFileClassS);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s",VisFileOwnerNameS);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s",fullPathattrDup);
												fprintf(Refcatiafp,",");
												fprintf(Refcatiafp,"%s\n",VisFileRelPathS);
												fflush(Refcatiafp);

												fprintf(Reffp,"%s",TCPartNumberS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",TCPartRevisionS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",TCPartSequenceS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",CatiaDisS);
												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",VisFileRelPathS);
												fprintf(Reffp,"^");
				                                if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"WIP"))
										         {
												 fprintf(Reffp,"%s","WIP_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"CE"))
										         {
												 fprintf(Reffp,"%s","CE_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf") && nlsStrStr(fullPathattrDup,"omfcadjtvault") )
										         {
												 fprintf(Reffp,"%s","JT_CAD_Vault_Loc");
												 }else if(nlsStrStr(CatiaDisS,".pdf"))
										           {
												     fprintf(Reffp,"%s","Rel_Vault_Loc_Pdf");
												    }
												   else
												   {
												       fprintf(Reffp,"%s",VisFileOwnerDirNameS);
												   }

												fprintf(Reffp,"^");
												fprintf(Reffp,"%s",fullPathattrDup);
												fprintf(Reffp,"^");
												fprintf(Reffp,"1");
												fprintf(Reffp,"^");
												fprintf(Reffp,"Ref\n");
												fflush(Reffp);
									}

							}

						}
					}

				  }
			}
			else
			{
				 //fprintf(fp,"SKIPJT\n");
			   printf("\n Not a Valid Doc class \n"); fflush(stdout);
			}
		}

	}
	else
	{
		printf("\n The Resultant TC Part is not in Vault(Func)..\n"); fflush(stdout);

	}


CLEANUP:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) CLEANUP..\n"); fflush(stdout);
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(JTUsesPartFilePhyItemSO);
		t5FreeSetOfObjects(JTUsesPartFileRelSO);
		t5FreeSetOfObjects(DocumentSO);
		t5FreeSetOfObjects(DocumentRelSO);
		t5FreeSetOfObjects(LatestDocSO);
		t5FreeSetOfObjects(LatestRelDocSO);
		t5FreeSetOfObjects(DataItemSO);
		t5FreeSetOfObjects(VisualizationFileSO);

EXIT:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) EXIT..\n"); fflush(stdout);
		t5CheckDstatAndReturn;

};

struct func
 {
   char InpPartNumberS[40]   ;
   char InpPartRevisionS[10]  ;
   char InpPartSequenceS[5]   ;
   char Level[5];

  } InputDataFileS[4000];


//Main Program for ContextBOMViewJTCreationBOMLevel
int main(int argc, char *argv[])
{
	int stat=0;
	int i, elmt1=0;
	int c1=0;
	int c2=0;
	int c4=0;

	string  LoginS=NULL;
	string  PasswordS=NULL;
	string  InputFileNameS=NULL;
	string  OutFileNameS=NULL;
	string  OutputFileNameSDup=NULL;
	string  selectedVaultS=NULL;
	string  CatiaFileS=NULL;
	string  RefOutFileNameS=NULL;
	string  RefCatiaFileS=NULL;

	char	store[2000];

	SetOfObjects  PartResultSO = NULL ;

	ObjectPtr TCPartObjP=NULL;

	SqlPtr  InputTCPartSqlPtr = NULL;

	//File Declaration
	FILE	*fp	= NULL;
	FILE	*fpInputDataFile	= NULL;
	FILE    *catiafp=NULL;
	FILE	*Refpdf	= NULL;
	FILE    *Refcapdf=NULL;

	///         ///
	string		docobjst	=	NULL;
	int		ii		=          0;
	SetOfStrings      dbScp	=          NULL;



	t5MethodInitWMD("ContextBOMViewJTCreationBOMLevel");

	//printf("\n Executing... main:ContextBOMViewJTCreationBOMLevel.c ... \n");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	InputFileNameS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	CatiaFileS=nlsStrAlloc(200);
	selectedVaultS=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	InputFileNameS=argv[3];
	OutFileNameS=argv[4];
	CatiaFileS=argv[5];
    RefOutFileNameS=argv[6];
	RefCatiaFileS=argv[7];

	//selectedVaultS=argv[5];

	//printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}


	///////////////////////////////////////
            t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
							docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	//t5CheckDstat(getDataBaseSetByUser(&dbScp,selectedVaultS,mfail));
	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}
	//////////////////////////////////////////////////////////

	/***   To Get the Input Details From Reading Input Text File ***/

	fpInputDataFile = fopen(InputFileNameS,"r");

	 while(fgets(store, NUMBER, fpInputDataFile)!=NULL)
		{
			c1  =0;
			for(i=1; i<=5 ; i++)
			{
				c2=0;
				switch(i)
				{

				   /*** Getting Part Level***/
				   case 1:
                   for(c2=0;store[c1]!='^'; c1++)
                   {
					InputDataFileS[elmt1].Level[c2]=store[c1];
					c2++;
                   }
                   InputDataFileS[elmt1].Level[c2]='\0';
				   printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[elmt1].Level);
                   break;

                   /*** Getting Part Number***/
				   case 2:
                   for(c2=0;store[c1]!='^'; c1++)
                   {
					InputDataFileS[elmt1].InpPartNumberS[c2]=store[c1];
					c2++;
                   }
                   InputDataFileS[elmt1].InpPartNumberS[c2]='\0';
				   printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[elmt1].InpPartNumberS);
                   break;

                   /*** Getting Part Revision***/

                   case 3:
                   for(;store[c1]!='^'; c1++)
                   {
                    InputDataFileS[elmt1].InpPartRevisionS[c2]=store[c1];
                    c2++;
                   }
                   InputDataFileS[elmt1].InpPartRevisionS[c2]='\0';
				   printf("\n From Data File Input Part Revision is:%s \n",InputDataFileS[elmt1].InpPartRevisionS);
                   break;

                   /*** Getting Part Sequence***/
                   case 4:
                   for(;store[c1]!='^'; c1++)
                   {
                    InputDataFileS[elmt1].InpPartSequenceS[c2]=store[c1];
                    c2++;
                   }
                   InputDataFileS[elmt1].InpPartSequenceS[c2]='\0';
				   printf("\n From Data File Input Part Sequence is:%s \n",InputDataFileS[elmt1].InpPartSequenceS);
                   break;
				}
                c1++;
			}

			 fprintf(fpInputDataFile,"\n");
			 fflush(fpInputDataFile);
			 elmt1++;
		 }

printf("\n File Read is get completed \n");


	OutputFileNameSDup=nlsStrDup(OutFileNameS);

	fp=fopen(OutputFileNameSDup,"a+");	fflush(fp);
	catiafp=fopen(CatiaFileS,"a+");	fflush(catiafp);

	Refpdf=fopen(RefOutFileNameS,"a+");	fflush(Refpdf);
	Refcapdf=fopen(RefCatiaFileS,"a+");	fflush(Refcapdf);

	for(c4=0; c4<elmt1; c4++)
	{

	printf("\n\n\n Reading From Buffer and Processing the Line Number:%d \n\n",c4+1); fflush(stdout);
	printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[c4].InpPartNumberS); fflush(stdout);
	printf("\n From Data File Input Part Revision is:%s \n",InputDataFileS[c4].InpPartRevisionS); fflush(stdout);
	printf("\n From Data File Input Part Sequence is:%s \n",InputDataFileS[c4].InpPartSequenceS); fflush(stdout);


	//Code For Handling Assembly and Component in the Collection
	t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InputDataFileS[c4].InpPartNumberS));
	t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RevisionAttr,InputDataFileS[c4].InpPartRevisionS));
	t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,SequenceAttr,InputDataFileS[c4].InpPartSequenceS));

	//t5CheckMfail(QueryWhere3(PartClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&PartResultSO,mfail));
	t5CheckMfail(QueryWhere(PartClass,InputTCPartSqlPtr,&PartResultSO,mfail));
	printf("\n parts found woth partnumber,revision,sequence %s,%s,%s :%d \n",InputDataFileS[c4].InpPartNumberS,InputDataFileS[c4].InpPartRevisionS,InputDataFileS[c4].InpPartSequenceS,setSize(PartResultSO)); fflush(stdout);

	if(setSize(PartResultSO)==1)
	{
		TCPartObjP=setGet(PartResultSO,0);
		printf("\n Calling the Function for GetTCPartInfoForContextBOMViewJTCreationBOMLevel \n"); fflush(stdout);
		t5CheckMfail(GetTCPartInfoForContextBOMViewJTCreationBOMLevel(TCPartObjP,fp,catiafp,Refpdf,Refcapdf,mfail));
		printf("\n End of the Loop foor TC Assembly Or TC Component in Collection\n"); fflush(stdout);

	}
	else if(setSize(PartResultSO)>1)
	{
		printf("\n parts found woth partnumber,revision,sequence %s,%s,%s are :%d. \n",InputDataFileS[c4].InpPartNumberS,InputDataFileS[c4].InpPartRevisionS,InputDataFileS[c4].InpPartSequenceS,setSize(PartResultSO)); fflush(stdout);
		printf("\n so,This is not Possible Use Case now \n");
		//goto EXIT;
	}

	}

fclose(fp);
fclose(catiafp);


CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);


EXIT:
		t5CheckDstatAndReturn;
}
;
