echo "Input to shell: " [$1]  [$2]  [$3]
FilePath=$2
if [[ $FilePath = "" ]]
then
fullpath="/uv19/UAFiles/ProE_Downloading/ProE_Uploaders/Onetime"
#fullpath=`pwd`
else
fullpath=$FilePath
fi
echo "fullpath:  $fullpath"
var_path=`pwd`
echo $var_path
var_path2=`basename $var_path`
echo "var_path2: $var_path2"
if [[ $var_path2 =~ "$1" ]]; then
	echo "1..catFile.sh..var_path:::::::::: $var_path"
else
	cd "$1"
	var_path=`pwd`
	echo "2..catFile.sh..var_path:::::::::: $var_path"
fi
fullpathJT="$fullpath/$1/$1"_allRevJT
pwd
#fullpathJT="$fullpath/$1"_allRevJT
echo "fullpathJT:::: "$fullpathJT
rm -rf inputAllRevJT.txt
echo "TCEtoTCUADataXfr---Working on JT files ............"
while read jline
do
#echo $jline
f_fNameOrg=`echo $jline | cut -d\, -f1`
classNm=`echo $jline | cut -d\, -f5`
f_DataItem=`echo $jline | cut -d\, -f8`
f_ApplnOwnr=`echo $jline | cut -d\, -f9`
f_Fullpath=`echo $jline | cut -d\, -f10`
f_Host=`echo $jline | cut -d\, -f11`
f_HostDB=`echo $jline | cut -d\, -f12`
f_partNo=`echo $jline | cut -d\, -f7`
f_partRevSeq=`echo $jline | cut -d\, -f6`
f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
fname=`echo $jline | cut -d\, -f2`
fname2=`basename $fname`
echo $fname2 | grep '/' >/dev/null 2>&1
fnameSuffix=`echo $fname | cut -d\. -f2`
echo "********************fnameSuffix: $fnameSuffix"
fname="$f_partRev"_"$f_partSeq"_"$fname2"
echo "fname: $fname"
echo "f_Fullpath: $f_Fullpath"
echo "f_DataItem: $f_DataItem"
if [[ ( $3 == "uaprod" ) || ( -z "$3" ) ]]
then
	scpFileCnt=`grep "$f_fNameOrg" "$1"_allRevJTScp.txt | grep "$f_partRevSeq" | wc -l`
	echo "scpFileCnt: $scpFileCnt    $f_fNameOrg"
	if [ $scpFileCnt = 0 ]
	then
		FileFullpath="$f_Fullpath"
	else
		FileFullpath="$fullpathJT/$fname"
	fi
else
	FileFullpath="$fullpathJT/$fname"
fi
echo "FileFullpath:  $FileFullpath"
if [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile"  -o "$classNm" == "x0CatPrt"  -o "$classNm" == "x0CatPrd" ];then
	#echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^"
	echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^" >>  inputAllRevJT.txt
fi
if [ "$fnameSuffix" == "jt" ];then
	if [[ "$fname2" =~ "_ALF" ]]
	then
		echo "ALF is present found in string"
	else
		echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^"
		echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^" >>  inputAllRevJT.txt
	fi
fi
done < "$1"_allRevJT.txt
while read jline
do
#echo $jline
f_fNameOrg=`echo $jline | cut -d\, -f1`
classNm=`echo $jline | cut -d\, -f5`
f_DataItem=`echo $jline | cut -d\, -f8`
f_ApplnOwnr=`echo $jline | cut -d\, -f9`
f_Fullpath=`echo $jline | cut -d\, -f10`
f_Host=`echo $jline | cut -d\, -f11`
f_HostDB=`echo $jline | cut -d\, -f12`
f_partNo=`echo $jline | cut -d\, -f7`
f_partRevSeq=`echo $jline | cut -d\, -f6`
f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
fname=`echo $jline | cut -d\, -f2`
fname2=`basename $fname`
echo $fname2 | grep '/' >/dev/null 2>&1
fnameSuffix=`echo $fname | cut -d\. -f2`
echo "********************fnameSuffix: $fnameSuffix"
fname="$f_partRev"_"$f_partSeq"_"$fname2"
echo "fname: $fname"
echo "f_Fullpath: $f_Fullpath"
echo "f_DataItem: $f_DataItem"
if [[ ( $3 == "uaprod" ) || ( -z "$3" ) ]]
then
	scpFileCnt=`grep "$f_fNameOrg" "$1"_allRevJTScp.txt | grep "$f_partRevSeq" | wc -l`
	echo "scpFileCnt: $scpFileCnt    $f_fNameOrg"
	if [ $scpFileCnt = 0 ]
	then
		FileFullpath="$f_Fullpath"
	else
		FileFullpath="$fullpathJT/$fname"
	fi
else
	FileFullpath="$fullpathJT/$fname"
fi
echo "FileFullpath:  $FileFullpath"
if [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile"  -o "$classNm" == "x0CatPrt"  -o "$classNm" == "x0CatPrd" ];then
	#echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^"
	echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^" >>  inputAllRevJT.txt
fi
if [ "$fnameSuffix" == "jt" ];then
	if [[ "$fname2" =~ "_ALF" ]]
	then
		echo "ALF is present found in string"
	else
		echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^"
		echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^" >>  inputAllRevJT.txt
	fi
fi
done < "$1"_allRevJT.txt1
echo "Working on CAD file ............"
while read jline
do
#echo $jline
f_fNameOrg=`echo $jline | cut -d\, -f1`
classNm=`echo $jline | cut -d\, -f5`
f_DataItem=`echo $jline | cut -d\, -f8`
f_ApplnOwnr=`echo $jline | cut -d\, -f9`
f_Fullpath=`echo $jline | cut -d\, -f10`
f_Host=`echo $jline | cut -d\, -f11`
f_HostDB=`echo $jline | cut -d\, -f12`
f_partNo=`echo $jline | cut -d\, -f7`
f_partRevSeq=`echo $jline | cut -d\, -f6`
f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
fname=`echo $jline | cut -d\, -f2`
fname2=`basename $fname`
echo $fname2 | grep '/' >/dev/null 2>&1
fnameSuffix=`echo $fname | cut -d\. -f2`
echo "********************fnameSuffix: $fnameSuffix"
fname="$f_partRev"_"$f_partSeq"_"$fname2"
echo "fname: $fname"
echo "f_Fullpath: $f_Fullpath"
echo "f_DataItem: $f_DataItem"
if [[ ( $3 == "uaprod" ) || ( -z "$3" ) ]]
then
	scpFileCnt=`grep "$f_fNameOrg" "$1"_allRevCadScp.txt | grep "$f_partRevSeq" | wc -l`
	echo "scpFileCnt: $scpFileCnt    $f_fNameOrg"
	if [ $scpFileCnt = 0 ]
	then
		FileFullpath="$f_Fullpath"
	else
		FileFullpath="$fullpathJT/$fname"
	fi
else
	FileFullpath="$fullpathJT/$fname"
fi
echo "FileFullpath:  $FileFullpath"
echo $f_DataItem | grep '<' >/dev/null 2>&1
if [ "$?" -eq "0" ]; then
prtInstName=`echo $f_DataItem | cut -d"<" -f1`
prtGenName2=`echo $f_DataItem | cut -d"<" -f2`
prtGenName=`echo $prtGenName2 | cut -d">" -f1`
echo "prtInstName: $prtInstName"
echo "prtGenName: $prtGenName"
echo "$prtInstName^$f_partRev^$f_partSeq^$prtInstName^-^1^$classNm^Instance^-^$f_ApplnOwnr^"
echo "$prtInstName^$f_partRev^$f_partSeq^$prtInstName^-^1^$classNm^Instance^-^$f_ApplnOwnr^" >>  inputAllRevJT.txt
echo "$prtGenName^NR^1^$fname2^$FileFullpath^1^$classNm^Generic^-^$f_ApplnOwnr^"
echo "$prtGenName^NR^1^$fname2^$FileFullpath^1^$classNm^Generic^-^$f_ApplnOwnr^" >>  inputAllRevJT.txt
else
#f_prt=`grep -iw $prtName allparts_"$directory".txt | sort -u`
#if [ ! -z "$f_prt" ]; then
#f_partNo=`echo $f_prt | cut -d"^" -f2`
#f_partRev=`echo $f_prt | cut -d"^" -f3`
#f_partSeq=`echo $f_prt | cut -d"^" -f4`
echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^"
echo "$f_partNo^$f_partRev^$f_partSeq^$fname2^$FileFullpath^1^$classNm^-^$f_DataItem^$f_ApplnOwnr^" >>  inputAllRevJT.txt
if [[ "$fname2" =~ ".CATPart" ]]
then
if ls "$FileFullpath.cgr" 1> /dev/null 2>&1; then
echo "cgr file does exist"
echo "$f_partNo^$f_partRev^$f_partSeq^$fname2.cgr^$FileFullpath.cgr^1^$classNm^-^-^$f_ApplnOwnr^"
echo "$f_partNo^$f_partRev^$f_partSeq^$fname2.cgr^$FileFullpath.cgr^1^$classNm^-^-^$f_ApplnOwnr^" >>  inputAllRevJT.txt
fi
fi
#fi
fi
done < "$1"_allRevCad.txt
if [[ -f inputAllRevJT.txt ]] && [[ ! -s inputAllRevJT.txt ]]; then 
echo "inputAllRevJT.txt File is empty"
else
sort -u inputAllRevJT.txt > inputAllRevJT_2.txt
mv inputAllRevJT_2.txt inputAllRevJT.txt
fi
