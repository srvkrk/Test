
Vault_INFO_FILE="/user/omfprod/shells/cad/JT/JTShells/Vault_INFO"
LOCAL_IP=`hostname`
echo "Hello World"
echo "LOCAL_IP is :" $LOCAL_IP
echo "Vault_INFO_FILE is :" $Vault_INFO_FILE

while read jline
do
	
	echo "Processing line:$jline"
	chk_dirname=`echo $jline | cut -d\, -f6`
	chk_classname=`echo $jline | cut -d\, -f11`
	echo "chk_dirname before  is :" $chk_dirname
	
	if [ "$chk_dirname" = "" ];then
		
		echo "No Jt File to Copy"

	else
		echo "chk_dirname is :" $chk_dirname
		if [ "$chk_classname" = "ProPrtI" ];then
			chk_dirname="Rel_CAD_Vault_Loc"
			jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
		else
			if [ "$chk_classname" = "ProAsmI" ];then
			chk_dirname="Rel_CAD_Vault_Loc"
			jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
		else
			jtname=`echo $jline | cut -d\, -f1 | sed 's/ /_/g'`
		fi
		fi

		echo "chk_dirname after assigning  is :" $chk_dirname
		chk_owner=`echo $jline | cut -d\, -f7`
		
		echo "jtname after  is :" $jtname
		###jtname=`basename $jtname`
		fname=`echo $jline | cut -d\, -f2`
		fname=`basename $fname`
		echo "fname is :" $fname

		cat $Vault_INFO_FILE | grep "$LOCAL_IP" | grep "$chk_dirname" >chk_file.$$
		if [ -s chk_file.$$ ];then
			while read m
			do
				m_path=`echo $m | cut -d':' -f4`
				echo "m_path is :" $m_path
				echo "Checking di: �$m_path/$jtname $fname"
				if [ -f $m_path/$jtname ];then
					echo "Linking di�: $m_path/$jtname $fname"
					cp "$m_path/$jtname" "$2/$fname"
									
				fi
			done <chk_file.$$
		else
			echo "vault not present locally"
		fi

	fi
done < "$1"