/*************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Aniket P. Kadu
*  Module		 :   TCUA Proe Downloader
*  Code			 :   TmlGetJTAndProeInfo.c
*  Created on	 :   Jan 10, 2012
*
* Modification History :
* S.No		Date		CR No	Modified By            Modification Notes
*	1.		2013				skk03433
*	2.		Jun 2015			rrr05503/dpa06577
*	3.		Jul 2016			rrr05503				Generic-Instance logic is incorporated.
*	4.		Jan 2017			rrr05503				Superset bom is generated using Cad Bom and Uses-Parts logic is incorporated.
*************************************************************************************************************/
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <Mtimsg.h>

FILE* pfile=NULL;
FILE* fp2=NULL;
FILE* fpSuperSet = NULL;
FILE* fpAllRev = NULL;
FILE* fpGrpChilRel = NULL;
FILE* fpGrpChilCnt = NULL;
FILE *LhRhfp = NULL;
FILE *fperr	= NULL;

status GetProeAsmExpOnly2(ObjectPtr DataItemObjP,string ProeAsmRPathDupS,string DataItemClassNameDupS,SetOfStrings OBIDsetS,FILE *fp,FILE *fp1,FILE *fperr,integer* mfail,string IsProDrw,int* level);
status t5SortBOMObjsByDate(SetOfObjects *itemObjs,SetOfObjects *relObjs,integer* mfail);
status GetMultiLevelExplosionUsesPart(ObjectPtr PartObjP,string InputPart,string InpPartRev,string InpPartSeq,string BOMConfigContextS,int *GUsesLevel,integer* mfail);
status GetTCPartInfoForContextBOMViewMultiSingleExplosion(ObjectPtr TCPartObjP,string BOMConfigContextS, int *GUsesLevel,/* SetOfStrings UsesPartsSOS, FILE* OrgFp,FILE* OrgLhRhFp,string matverifyfilename,FILE* LhRHErr,*/ integer* mfail );
status t5GetMultiLevelExplosion_new
(
		ObjectPtr		partObj,
		integer			reqLevel,
		ObjectPtr       contextObj,
		SetOfObjects*	childObjs,
		SetOfObjects*	childRelObjs,
		SetOfStrings*	levels,
		SetOfStrings*	type,
		integer*		GUsesLevel,
		integer*		mfail
);
status t5GetExplosion_new
(
	ObjectPtr		partObj,
	integer			reqLevel,
	ObjectPtr       contextObj,
	SetOfObjects	*childObjs,
	SetOfObjects	*childRelObjs,
	SetOfStrings	*levels,
	SetOfStrings	*type,
	integer*		level,
	integer*		mfail
);

status GetGenTCPartProEInfo(ObjectPtr DataItemObjP, ObjectPtr TCObjP, string InpPartNumberS, string InpPartRev, string InpPartSeq, string InstanceRevSeqS, integer* mfail , int *level);
status GetGenTCPartProEInfoLHRH(ObjectPtr DataItemObjP, ObjectPtr TCObjP, string InpPartNumberS, string InpPartRev, string InpPartSeq, string InstanceRevSeqS, integer* mfail , int *Prtlevel);
int SetFlagforScope(SetOfObjects ScopeObjects);
status t5SortBOMObjsAndRemoveDuplicates(SetOfObjects *itemObjs,SetOfObjects *itemRelObjs, SetOfStrings *SortedUsesPartQtySOS ,string AssyPartno, integer* mfail);
char *  itoa ( int value, char * str, int base );

SetOfStrings dbScopeStr = NULL;
SetOfStrings dbScopeBkp = NULL;


char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
    int i;
    char *retStringf;
    retStringf = (char*) malloc(toCharf+1);
    for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
    *(retStringf+i) = '\0';
    return retStringf;
}
string ConvertToLowerCase(string lowercaseS)
{
        string temp=NULL;
        int i=0;
        char t;
        printf("\n Convert Upper to lower:[%s]",lowercaseS);

        temp=nlsStrAlloc(strlen(lowercaseS));
        memset(temp,strlen(lowercaseS),'\0');

        for(i=0;i<strlen(lowercaseS);i++)
        {
                t=tolower(lowercaseS[i]);
                temp[i]=t;
        }
		temp[nlsStrLen(temp)]='\0';		//added on 12.05.2017

        return temp;
}
status getUsrDetails
(
	char* usrDept,
	char* usrLocation,
	char* usrAgency,
	integer* mfail
)
{
	SqlPtr a_sql = NULL;
	char* user = NULL;
	char* Dept = NULL;
	char* dupDesDept = NULL;
	char* Location = NULL;
	char* Agency = NULL;
	SetOfObjects UsrSet = NULL;
	ObjectPtr CurrentUsr = NULL;

	char *mod_name = "getUsrDetails";
	status dstat = OKAY;
	*mfail = USC_OKAY;
	Dept		 = nlsStrAlloc(10);
	if (dstat = smGetSessionUsrName(&user)) goto EXIT;
	//printf(" In  side getUsrDetails  %s \n" ,user );
	fflush(stdout);
	// Getting user Data.
	if(dstat = oiSqlCreateSelect(&a_sql)) goto EXIT;
	if(dstat = oiSqlWhereEQ(a_sql,"Participant",user)) goto EXIT;
	if(dstat = QueryWhere("Usr",a_sql,&UsrSet,mfail)) goto EXIT;
	if ((dstat = oiSqlCreateSelect(&a_sql)) ||
		(dstat = oiSqlWhereEQ(a_sql,"Participant",user)) ||
		(dstat = QueryWhere("Usr",a_sql,&UsrSet,mfail)) )goto EXIT;
	if (*mfail) goto CLEANUP;

	CurrentUsr = (ObjectPtr) low_set_get(UsrSet,0);
	// Getting Various Values For Current User.
	if (dstat = objGetAttribute(CurrentUsr,"Dept",&Dept)) goto EXIT;
	if (dstat = objGetAttribute(CurrentUsr,"t5UsrLocation",&Location)) goto EXIT;
	if (dstat = objGetAttribute(CurrentUsr,"t5UsrAgency",&Agency)) goto EXIT;

	dupDesDept = nlsStrDup(Dept);

	// Copying User Department
	if (!nlsIsStrNull(Dept)) usrDept = nlsStrCpy(usrDept,dupDesDept);
	else usrDept = nlsStrCpy(usrDept,"");

	// If usrLocation is not null then set this as location else set as TMLPUN.
	if (!nlsIsStrNull(Location)) usrLocation = nlsStrCpy(usrLocation,Location);
	else usrLocation = nlsStrCpy(usrLocation,"");

	// If user Agency is null then taking Default as ERC
	if (!nlsIsStrNull(Agency)) usrAgency = nlsStrCpy(usrAgency,Agency);
	else usrAgency = nlsStrCpy(usrAgency,"ERC");

	//printf("End of getUsrDetails Location= %s \n Dept= %s Agency = %s \n\n",usrLocation,usrDept,usrAgency);
	fflush(stdout);
CLEANUP:
	// Disposing User class object Set
	if (UsrSet != NULL)
	objDisposeAll(UsrSet);

EXIT:
	if (dstat != OKAY)
	uiShowFatalError(dstat, WHERE);
	return (dstat);
}

status t0UpdateObject(ObjectPtr *itemObj,integer *mfail)
{
	char *mod_name = "t0UpdateObject";
	status dstat = OKAY;
	string SclsName = NULL;
	string SclsNameDup = NULL;
	string SframeName = NULL;
	string SframeNameDup = NULL;

	printf("\n .... inside t0UpdateObject ...  updating object ... \n"); fflush(stdout);
	if(dstat = objGetAttribute(*itemObj,"Class",&SclsName)) goto CLEANUP;
	SclsNameDup=nlsStrDup(SclsName);
	//printf("\n .... inside t0UpdateObject ...updating object ..SclsName=%s...1111\n",SclsName); fflush(stdout);
	if (dstat = BeginDbFrame(SclsNameDup,&SframeName,mfail)) goto CLEANUP;
	if (*mfail) goto CLEANUP;
	SframeNameDup=nlsStrDup(SframeName);
	//printf("\n .... inside t0UpdateObject ...  updating object ...SframeName=%s...222\n",SframeName); fflush(stdout);
	//objDump(*itemObj); fflush(stdout);
	if (dstat = UpdateDbObject(*itemObj,mfail)) goto CLEANUP;
	//printf("\nAfter UpdateDbObject ....33333.\n");fflush(stdout);

	if (*mfail != 0)
	{
		//printf("\n .... inside t0UpdateObject ...  updating object ...4444444444 \n"); fflush(stdout);
		if (dstat = ClearDbFrame(SclsNameDup,SframeNameDup,mfail)) goto CLEANUP;
		goto CLEANUP;
	}
	//printf("\n .... inside t0UpdateObject ...  updating object ... 555555555\n"); fflush(stdout);
	printf("\nParameters to End DB Frame are:[%s],[%s]",SclsNameDup,SframeNameDup);
	if (dstat = EndDbFrame(SclsNameDup,SframeNameDup,mfail)) goto CLEANUP;
	if (*mfail)  goto CLEANUP;

CLEANUP:
	//printf("\n.... in cleanup t0UpdateObject ...."); fflush(stdout);
    t5PrintCleanUpModName;

EXIT:
    if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
    return (dstat);
}

int getDatabaseScope()
{
	//char * mod_name = "getDatabaseScope";

	string userDept =NULL;
	string userLocatn=NULL;
	string userAgency=NULL;
    string dBScope=NULL;

	SqlPtr dBSqlPtr=NULL;

	SetOfObjects dBPrefSet=NULL;
	ObjectPtr dBPref=NULL;

	status rfail=OKAY;
	status dstat=OKAY;

	userDept=nlsStrAlloc(30);
	userLocatn=nlsStrAlloc(10);
	userAgency=nlsStrAlloc(10);
	dBScope=nlsStrAlloc(50);

	//printf("\nInside Get user Deatils");

	if(dstat = getUsrDetails(userDept,userLocatn,userAgency,&rfail)) goto EXIT;

	printf("\nUserDept %s",userDept);
	printf("\nUser Agency %s",userAgency);
	printf("\nUser Location %s",userLocatn);

	if(!nlsStrCmp(userLocatn,"PUNE"))
	{
		nlsStrCpy(dBScope,"ClientCode_DB_Scope");
	}else if(!nlsStrCmp(userLocatn,"LKO"))
	{
		nlsStrCpy(dBScope,"ClientCode_DB_Scope");
	}else if(!nlsStrCmp(userLocatn,"JSR"))
	{
		nlsStrCpy(dBScope,"ClientCode_DB_Scope");
	}

	if(!nlsIsStrNull(dBScope))
	{
		 if(dstat=oiSqlCreateSelect(&dBSqlPtr))goto EXIT;
		 if(dstat=oiSqlWhereEQ(dBSqlPtr,"BrowserWindowName",dBScope))goto EXIT;
		 //if(dstat=QueryDbObject(SavDbPClass,dBSqlPtr,1,TRUE,SC_SCOPE_OF_SESSION,&dBPrefSet,&rfail))goto EXIT;
		 if(dstat=QueryWhere("SavDbP",dBSqlPtr,&dBPrefSet,&rfail))goto EXIT;

		 //printf("\nSize Of Db Object Is:%d",setSize(dBPrefSet));

		 if(setSize(dBPrefSet)>0)
		 {
			dBPref=setGet(dBPrefSet,0);
			if(dBPref){
			Open(dBPref,&rfail);
			if(rfail)
				goto CLEANUP;
				//printf("\nDb Preference Set Successfully");
			}else{
				//printf("\nDb Preference Failed");
			}
		 }

		 if(dBSqlPtr)
		{
			oiSqlDispose(dBSqlPtr);
		}
	}

CLEANUP:
	//printf("\nThis is Clean up of Code");
	if(!nlsIsStrNull(userDept))  nlsStrFree(userDept);
	if(!nlsIsStrNull(userLocatn))  nlsStrFree(userLocatn);
	if(!nlsIsStrNull(userAgency))  nlsStrFree(userAgency);

EXIT:
	printf("\nThis is Exit of Code");

	return dstat;
}
//Code for getting fullpath and relativepath and working relativepath of jt  Only...
status GetFullPathJTExp(ObjectPtr InstDataItemObjP,ObjectPtr JTDataItemObjP,string IsProDrw,FILE *fp,FILE* fp1,FILE *fperr,integer* mfail,int* level)
{
//	int i=0;
//	char *ptr;
	int pi = 0;
	int ProAsmIFlag = 0;
	int lcnt = 0;
	int GenericFlag = 0;
	int GenInstanceFlag = 0;
	int tmpStrlen = 0;
	int charFlag = 0;
	int i=0;
	int t5DrwDocFlag = 0;
	int LatestDoc = 0;
	int DataItem = 0;
	int VisFile = 0;
	int NonStdGenericPartFlag = 0;
	int ii = 0;
	int jtcnt = 0;
	int TCPartExistFlag = 0;
	//int PrtInstanceMatchFlag = 0;
	//int m = 0;

	char tempstr[50]={0};
	char *p;

	string PartAndDrwRelPathDupS=NULL;
	string PartAndDrwRelPathDup=NULL;
	string PartAndDrwRelPathDup0=NULL;
	string PartAndDrwRelPathDup2=NULL;
	string DataItemFullPathS=NULL;
	string DataItemDisplayNm=NULL;
	string DataItemDisplayNmDup=NULL;
	string DataItemFullPathDup=NULL;
	string DataItemFullPathDup2=NULL;
	string DataItemFullPathDup3=NULL;
	string DataItemFullPathDup4=NULL;
	string DataItemFullPathDup5=NULL;
	string JTRelativePathS = NULL ;
	string JTRelativePathDup = NULL ;
	string JTWRelativePathS = NULL ;
	string JTWRelativePathDup = NULL ;
	string JTDataRelPathS = NULL ;
	string JTDataRelPathDup = NULL ;
	string DISeq = NULL ;
	string DISeqDup = NULL ;
	string DataItemRelPathS = NULL;
	string DataItemRelPathDupS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string JTOwnerNameS = NULL;
	string JTOwnerNameDupS = NULL;
	string JTfullPath = NULL;
	string JTfullPathDup = NULL;
	string JTHostNm = NULL;
	string JTHostNmDup = NULL;
	string JTSiteNm = NULL;
	string JTSiteNmDup = NULL;
	string wrelativepath = NULL;
	string wrelativepath1 = NULL;
	string wrelativepath2 = NULL;
	string wrelativepathDupS = NULL;
	string ProjectCodeS = NULL;
	string ProjectCodeDupS = NULL;
	string PartDocNm = NULL;
	string PartDocNmDup = NULL;
	string PartDocSeq = NULL;
	string PartDocSeqDup = NULL;
	string PartDocRev = NULL;
	string PartDocRevDup = NULL;
	string PartNumberS2 = NULL;
	string PartNumberDupS2 = NULL;
	string TCSequence = NULL;
	string TCSequenceDup = NULL;
	string TCRevision = NULL;
	string TCRevisionDup = NULL;
	string TCDrawingInd = NULL;
	string TCDrawingIndDup = NULL;
	string GenOwnDupS = NULL;
	string GenOwnS = NULL;
	/*string ClassDupS = NULL;
	string ClassS = NULL;*/
	string InstClassDupS = NULL;
	string InstClassS = NULL;
	string OwnerDirNameS = NULL;
	string OwnerDirNameDupS = NULL;
	string OwnerDirNameJTDupS = NULL;
	string OwnerDirNameJTS = NULL;
	string DIGenericName = NULL;
	string DIGenericNameDup = NULL;
	string DIGenericNameDup2 = NULL;
	string temp3 = NULL;
	string temp4 = NULL;
	string temp5 = NULL;
	string temp6 = NULL;
	string GenFullPathDupS=NULL;
	string GenFullPathS=NULL;
	string relativepathS=NULL;
	string relativepathDupS=NULL;
	string relativepathDupS2=NULL;
	string GenSeqDupS=NULL;
	string GenSeqS=NULL;
	string GenOwnDupS11=NULL;
	string GenOwnS11=NULL;
	string proAsmDisplayNmS = NULL;
	string proAsmDisplayNmDupS = NULL;
	string proAsmDisplayNmDupS2 = NULL;
	string proAsmDisplayNmDupSTmp = NULL;
	string asmInstanceS = NULL;
	string asmInstanceS2 = NULL;
	//string DiClass = NULL ;
	//string DiClassDup = NULL ;
	string DocBIClassNameDupS = NULL;
	string DocBIClassNameS = NULL;
	string DiClassDupS = NULL;
	string DiClassS = NULL;
	string DIOwnerNameDup = NULL;
	string DIOwnerName = NULL;
	string DIRelPathDup = NULL;
	string DIRelPath = NULL;
	string DIDisplayNmDup = NULL;
	string DIDisplayNm = NULL;
	string DIFileWorkingRelativePathDup = NULL;
	string DIFileWorkingRelativePath = NULL;
	string DISequenceDup = NULL;
	string DISequence = NULL;
	string DIOwnerDirNameDup = NULL;
	string DIOwnerDirName = NULL;
	string DIfullPathDup = NULL;
	string DIfullPath = NULL;
	string VisFileOwnerNameDupS = NULL;
	string VisFileOwnerNameS = NULL;
	string VisFileRelPathDupS = NULL;
	string VisFileRelPathS = NULL;
	string PdfDisDupS = NULL;
	string PdfDisS = NULL;
	string VisFileWorkingRelativePathDupS = NULL;
	string VisFileWorkingRelativePathS = NULL;
	string VisFileSequenceDupS = NULL;
	string VisFileSequenceS = NULL;
	string VisFileClassDupS = NULL;
	string VisFileClassS = NULL;
	string VisFileOwnerDirNameDupS = NULL;
	string VisFileOwnerDirNameS = NULL;
	string fullPathattrDup = NULL;
	string fullPathattr = NULL;
	string GJTRelativePathS = NULL;
	string GJTRelativePathDup = NULL;
	string GJTOwnerNameS = NULL;
	string GJTOwnerNameDupS = NULL;
	string GJTWRelativePathS = NULL;
	string GJTWRelativePathDup = NULL;
	string GOwnerDirNameJTDupS = NULL;
	string GOwnerDirNameJTS = NULL;
	string GJTfullPath = NULL;
	string GJTfullPathDup = NULL;
	string GJTHostNm = NULL;
	string GJTHostNmDup = NULL;
	string GJTSiteNm = NULL;
	string GJTSiteNmDup = NULL;
	string temp1 = NULL;
	string temp2 = NULL;
	string temp2Dup = NULL;
	string TcPrtTemp = NULL;
//	string InstRevisionDup = NULL;

	string NomenclatureS = NULL;
	string NomenclatureDupS = NULL;
	string ProjectNameS = NULL;
	string ProjectNameDupS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingNoS = NULL;
	string t5DrawingNoDupS = NULL;
	string WeightS = NULL;
	string WeightDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5PartCodeS = NULL;
	string t5PartCodeDupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string CategoryNameS = NULL;
	string CategoryNameDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5DsgnOwnS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;

	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;

	string workingrelPath = NULL;
	string workingrelPathDup = NULL;
	string workingrelPathDup0 = NULL;
	string Alf_Child = NULL;
	string Alf_ChildTemp = NULL;
	string AlfTemp = NULL;
	string Alf_Assy = NULL;
	string DItype = NULL;

	//SetPtr strReplicatedLocations = NULL ;

	ObjectPtr JTObjP=NULL;
	ObjectPtr JTPartObjP=NULL;
	ObjectPtr AsmIObjP=NULL;
	ObjectPtr PrtIObjP=NULL;
	ObjectPtr GetItmInfoDrwObjP=NULL;
	ObjectPtr LatestDocObjP=NULL;
	ObjectPtr NewDataItemObjP=NULL;
	ObjectPtr DataItemObjP=NULL;
	ObjectPtr NewVisFileObjP=NULL;
	ObjectPtr proprtDIObjP=NULL;
	ObjectPtr VisFileObjP=NULL;
	ObjectPtr proprtrevObjP=NULL;
	//ObjectPtr PrtGObjP=NULL;
	ObjectPtr GetItmInfoDataItemObjP=NULL;
	ObjectPtr GenJTPartObjP = NULL;
	ObjectPtr GenJTObjP = NULL;
	ObjectPtr GGetInfoJTPartObjP = NULL;
	ObjectPtr GenericObjP = NULL;
	ObjectPtr appdepjtPtr = NULL;
	ObjectPtr GetInfoappdepjtPtr = NULL;

	SetOfObjects ProeInstDepOnSO = NULL;
	SetOfObjects ProeInstDepOnRelSO = NULL;
	SetOfObjects DIDocSO = NULL;
	SetOfObjects DIDocRelSO = NULL;
	SetOfObjects DocPartSO = NULL;
	SetOfObjects DocPartRelSO = NULL;
	SetOfObjects DocumentSO = NULL;
	SetOfObjects DocumentRelSO = NULL;
	SetOfObjects LatestDocSO = NULL;
	SetOfObjects LatestRelDocSO = NULL;
	SetOfObjects DataItemSO = NULL;
	SetOfObjects VisualizationFileSO = NULL;
	SetOfObjects JTPartSO = NULL;
	SetOfObjects JTPartRelSO = NULL;
	SetOfObjects ProeDataItemSO = NULL;
	SetOfObjects ProeGenDataItemSO = NULL;
	//SetOfObjects ProeInstDepOnRelSO = NULL;
	//SetOfObjects ProeInstDepOnSO = NULL;
	SetOfObjects GenJTPartRelSO = NULL;
	SetOfObjects GenJTPartSO = NULL;
	SetOfObjects GenericSO = NULL;
	SetOfObjects TplJTPartSO = NULL;
	SetOfObjects TplJTPartRelSO = NULL;
	SetOfObjects JTAppDependOnSO = NULL;
//	SetOfObjects InstSO = NULL;

	SqlPtr ProeObjSqlPtr = NULL ;
	SqlPtr Sql_ptr = NULL ;

	//SetOfStrings BulkList = NULL;
	SetOfStrings GenInst = NULL;

	FILE* fpGen=NULL;
	//FILE* fpGenFile=NULL;


	SetPtr filestr = NULL;

	asmInstanceS = nlsStrAlloc(50);
	DItype = nlsStrAlloc(20);

	GenInst = low_set_create(10);


	t5MethodInit("GetFullPathJTExp");

	printf("\n inside Function GetFullPathJTExp \n");

	fpGen = fopen("GenericInstance.txt","a");
	fflush(fpGen);

	//fpGenFile = fopen("GenericInstanceFile.txt","a+");
	//fflush(fpGenFile);

	t5CheckDstat(objGetAttribute(InstDataItemObjP,"RelativePath",&PartAndDrwRelPathDupS));
	if(PartAndDrwRelPathDup!=NULL)
	{
		nlsStrFree(PartAndDrwRelPathDup);
		PartAndDrwRelPathDup = NULL;
	}
	if(!nlsIsStrNull(PartAndDrwRelPathDupS))
	{
		PartAndDrwRelPathDup=nlsStrDup(PartAndDrwRelPathDupS);
		PartAndDrwRelPathDup0=nlsStrDup(PartAndDrwRelPathDupS);
	}
	printf("\n PartAndDrwRelPathDup is :%s",PartAndDrwRelPathDup);

	t5CheckDstat(objGetAttribute(InstDataItemObjP,"DisplayedName",&DataItemDisplayNm));
	if(!nlsIsStrNull(DataItemDisplayNm))
	{
		DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
	}
	else
	{
		DataItemDisplayNmDup=nlsStrDup("");
	}
	printf("\n DataItemDisplayNmDup is :%s  ",DataItemDisplayNmDup);

	//objDump(InstDataItemObjP);
	//-----------Bulk data check start
	/*t5CheckDstat(objListGetList(InstDataItemObjP,"FileRepLocations", &strReplicatedLocations));
	printf("\n setSize(strReplicatedLocations) is :%d \n",setSize(strReplicatedLocations));

	if(setSize(strReplicatedLocations) == 0)
	{
	 // t5CheckDstat(objGetClass(InstDataItemObjP,&DiClass));
	 // DiClassDup = nlsStrDup(DiClass);

	  BulkList=NULL;
	  BulkList=setStrCreate(1);
	  setAddStr(BulkList,"qeBhJ0dabc---supprod-k7F");
	  if(dstat=objSetList(InstDataItemObjP,FileRepLocationsAttr,BulkList)) goto EXIT;
	  //printf("\nData Item : %s Sequence : %s updated\n",PartAndDrwRelPathDup,DISeqDup);fflush(stdout);
	  t5CheckMfail(t0UpdateObject(&InstDataItemObjP,mfail));
	  //printf("\nData Item : %s Sequence : %s updated\n",PartAndDrwRelPathDup,DISeqDup);fflush(stdout);
	}
	else
	{
		for (i=0;i<setSize(strReplicatedLocations) ;i++ )
		{
			ptr = low_set_get(strReplicatedLocations, i);
			//printf("\n setSize(strReplicatedLocations) ptr is :%s \n",ptr);
		}
	}*/

	//-----------Bulk data check end
	/*t5CheckDstat(GetInfoItem(InstDataItemObjP,&GetItmInfoDataItemObjP,mfail));
	objDump(GetItmInfoDataItemObjP);
	t5CheckDstat(objGetAttribute(GetItmInfoDataItemObjP,FullPathAttr,&DataItemFullPathS));
	if(DataItemFullPathDup!=NULL){nlsStrFree(DataItemFullPathDup);DataItemFullPathDup = NULL;}
	DataItemFullPathDup=nlsStrDup(DataItemFullPathS);*/

	t5CheckDstat(objGetAttribute(InstDataItemObjP,"Sequence",&DISeq));
	if(!nlsIsStrNull(DISeq))
	{
		DISeqDup = nlsStrDup(DISeq);
	}
	t5CheckDstat(objGetAttribute(InstDataItemObjP,"RelativePath",&DataItemFullPathS));
	if(!nlsIsStrNull(DataItemFullPathS))
	{
		DataItemFullPathDup=nlsStrDup(DataItemFullPathS);
		DataItemFullPathDup2=nlsStrDup(DataItemFullPathS);
		DataItemFullPathDup3=nlsStrDup(DataItemFullPathS);
		DataItemFullPathDup4=nlsStrDup(DataItemFullPathS);
		DataItemFullPathDup5=nlsStrDup(DataItemFullPathS);
	}
	t5CheckDstat(objGetAttribute(InstDataItemObjP,"OwnerName",&OwnerNameDupS));
	if(!nlsIsStrNull(OwnerNameDupS))
	{
		OwnerNameS=nlsStrDup(OwnerNameDupS);
	}
	t5CheckDstat(objGetAttribute(InstDataItemObjP,"Class",&InstClassDupS));
	if(!nlsIsStrNull(InstClassDupS))
	{
		InstClassS=nlsStrDup(InstClassDupS);
	}
	t5CheckDstat(objGetAttribute(InstDataItemObjP,"OwnerDirName",&OwnerDirNameDupS));
	if(!nlsIsStrNull(OwnerDirNameDupS))
	{
		OwnerDirNameS=nlsStrDup(OwnerDirNameDupS);
	}
	else
	{
		OwnerDirNameS=nlsStrDup("");
	}
	//printf("\n%s,%s,%s,%s\n",InstClassS,DataItemFullPathDup,OwnerNameS,OwnerDirNameS);
	//fprintf(fperr,"%s,",DataItemFullPathDup);fflush(fperr);
	t5CheckDstat(objGetAttribute(JTDataItemObjP,"RelativePath",&JTDataRelPathS));
	if(JTDataRelPathDup!=NULL)
	{
		nlsStrFree(JTDataRelPathDup);JTDataRelPathDup = NULL;
	}
	JTDataRelPathDup=nlsStrDup(JTDataRelPathS);
	//printf("\n JTDataRelPathDup is :%s \n",JTDataRelPathDup);

	t5CheckDstat(objGetAttribute(InstDataItemObjP,"RelativePath",&DataItemRelPathDupS));
	if(DataItemRelPathDupS)
	{
		DataItemRelPathS=nlsStrDup(DataItemRelPathDupS);
	}

	t5CheckDstat(objGetAttribute(InstDataItemObjP,"WorkingRelativePath",&wrelativepathDupS));
	if(!nlsIsStrNull(wrelativepathDupS))
	{
		wrelativepath=nlsStrDup(wrelativepathDupS);
		wrelativepath1=nlsStrDup(wrelativepathDupS);
		wrelativepath2=nlsStrDup(wrelativepathDupS);
	}

	printf("\t InstClassS: [%s] ",InstClassS);

	/*if(nlsStrStr(DataItemDisplayNmDup,".asm.") !=NULL)
	{
		nlsStrCpy(DItype,"ASSY_TYPE_UA");
	}
	else if(nlsStrStr(DataItemDisplayNmDup,".prt.") !=NULL)
	{
		nlsStrCpy(DItype,"COMP_TYPE_UA");
	}
	else if(nlsStrStr(DataItemDisplayNmDup,"<") !=NULL)
	{
		nlsStrCpy(DItype,"COMP_TYPE_UA");
	}
	else
	{
		nlsStrCpy(DItype,"TYPE_INVALID");
	}*/


	if(nlsStrStr(InstClassS,"ProAsm") !=NULL)
	{
		nlsStrCpy(DItype,"ASSY_TYPE_UA");
	}
	else if(nlsStrStr(InstClassS,"ProPrt") !=NULL)
	{
		nlsStrCpy(DItype,"COMP_TYPE_UA");
	}
	else
	{
		nlsStrCpy(DItype,"TYPE_INVALID");
	}

	t5CheckDstat(objGetAttribute(InstDataItemObjP,ProjectNameAttr,&ProjectCodeS));
	if(!nlsIsStrNull(ProjectCodeS))
	{
		ProjectCodeDupS=nlsStrDup(ProjectCodeS);
	}
	else
	{
		ProjectCodeDupS=nlsStrDup("");
	}
	printf("\n ProjectCodeDupS:%s ",ProjectCodeDupS); fflush(stdout);

	NonStdGenericPartFlag = 0;
	if ((nlsStrCmp(ProjectCodeDupS,"1111")!=0) && (nlsStrStr(DataItemDisplayNmDup,"<") != NULL))
	{
		NonStdGenericPartFlag = 1;
		printf("....NonStdGenericPartFlag:%d   [ %s ]",NonStdGenericPartFlag,DataItemDisplayNmDup);fflush(stdout);
	}

	if (InstDataItemObjP != NULL)
	{
		t5CheckMfail(ExpandObject2(AttachClass,InstDataItemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
		if(SetFlagforScope(DIDocSO)==1)
		{
			if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
			t5CheckMfail(ExpandObject2(AttachClass,InstDataItemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
			if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
		}

		t5CheckMfail(t5SortBOMObjsByDate(&DIDocSO,&DIDocRelSO,mfail));

		printf("\n setSize(DIDocSO) :%d",setSize(DIDocSO));

		if(setSize(DIDocSO)>0)
		{
			t5CheckDstat(objGetAttribute(setGet(DIDocSO,0),DocumentNameAttr,&PartDocNm));
			if(!nlsIsStrNull(PartDocNm))
			{
				PartDocNmDup=nlsStrDup(PartDocNm);
			}
			else
			{
				PartDocNmDup=nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(setGet(DIDocSO,0),SequenceAttr,&PartDocSeq));
			if(!nlsIsStrNull(PartDocSeq))
			{
				PartDocSeqDup=nlsStrDup(PartDocSeq);
			}
			else
			{
				PartDocSeqDup=nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(setGet(DIDocSO,0),RevisionAttr,&PartDocRev));
			if(!nlsIsStrNull(PartDocRev))
			{
				PartDocRevDup = nlsStrAlloc(50);
				PartDocRevDup=nlsStrDup(PartDocRev);
				nlsStrCat(PartDocRevDup,";");
				nlsStrCat(PartDocRevDup,PartDocSeqDup);
			}
			else
			{
				PartDocRevDup=nlsStrDup("");
			}
			printf("\n PartDocNmDup:%s  %s",PartDocNmDup,PartDocRevDup);fflush(stdout);

			t5CheckMfail(ExpandObject2(PartDocClass,setGet(DIDocSO,0),"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
			if(SetFlagforScope(DocPartSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandObject2(PartDocClass,setGet(DIDocSO,0),"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			printf("\n Part objects:%d",setSize(DocPartSO));fflush(stdout);

			if(setSize(DocPartSO)>0)
			{
				TCPartExistFlag = 1;

				printf("  TCPartExistFlag:%d",TCPartExistFlag);fflush(stdout);

				for(i=0;i<setSize(DocPartSO);i++)
				{
					if(!nlsIsStrNull(PartNumberDupS2))
					{
						PartNumberDupS2=nlsStrDup("");
					}

					t5CheckDstat(objGetAttribute(setGet(DocPartSO,i),PartNumberAttr,&PartNumberS2));
					if(!nlsIsStrNull(PartNumberS2))
					{
						PartNumberDupS2=nlsStrDup(PartNumberS2);
					}
					else
					{
						PartNumberDupS2=nlsStrDup("");
					}

					t5CheckDstat(objGetAttribute(setGet(DocPartSO,i),SequenceAttr,&TCSequence));
					if(!nlsIsStrNull(TCSequence))
					{
						TCSequenceDup=nlsStrDup(TCSequence);
					}
					else
					{
						TCSequenceDup=nlsStrDup("");
					}

					t5CheckDstat(objGetAttribute(setGet(DocPartSO,i),RevisionAttr,&TCRevision));
					if(!nlsIsStrNull(TCRevision))
					{
						TCRevisionDup = nlsStrAlloc(50);
						TCRevisionDup=nlsStrDup(TCRevision);
						nlsStrCat(TCRevisionDup,";");
						nlsStrCat(TCRevisionDup,TCSequenceDup);
					}
					else
					{
						TCRevisionDup=nlsStrDup("NR;1");
					}

					//if((nlsStrCmp(PartDocNmDup,PartNumberDupS2) == 0) && (nlsStrCmp(PartDocRevDup,TCRevisionDup) == 0))
					if(((nlsStrCmp(PartDocNmDup,PartNumberDupS2) == 0) && (nlsStrCmp(PartDocRevDup,TCRevisionDup) == 0)) || ((strlen(PartDocNmDup) == 11) && (setSize(DocPartSO) == 1)))
					{
						printf("   PartRev:[%s, %s] ............ Match Found",PartNumberDupS2,TCRevisionDup);fflush(stdout);

						t5CheckDstat(objGetAttribute(setGet(DocPartSO,i),t5DrawingIndAttr,&TCDrawingInd));
						if(!nlsIsStrNull(TCDrawingInd))
						{
							TCDrawingIndDup=nlsStrDup(TCDrawingInd);
						}
						else
						{
							TCDrawingIndDup=nlsStrDup("N");	//Added 0n 21.09.2018
						}
						printf("   TCDrawingIndDup:[%s]",TCDrawingIndDup);fflush(stdout);

						//Start of Fetching drawing PDF data
						if(nlsStrCmp(TCDrawingIndDup,"D")==0)
						{
							if(dstat = ExpandObject2(PartDocClass,setGet(DocPartSO,i),"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
							if(SetFlagforScope(DocumentSO)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if(dstat = ExpandObject2(PartDocClass,setGet(DocPartSO,i),"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}
							if (setSize(DocumentSO) > 0)
							{
								//printf("\n\t  1..Doc present "); fflush(stdout);
								if(dstat = t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail)) goto CLEANUP;
								//printf("\n 1.setSize(LatestDocSO) :%d",setSize(LatestDocSO));
								if (setSize(LatestDocSO) > 0)
								{
									t5DrwDocFlag = 0;

									for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
									{
										LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

										t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
										DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
										printf("\n 1.Document Class:[%s]",DocBIClassNameS); fflush(stdout);

										if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
										{
											t5DrwDocFlag = 1;

											t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
											if(SetFlagforScope(DataItemSO)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}

											printf("\n 1.setSize(DataItemSO) :%d",setSize(DataItemSO));
											if(setSize(DataItemSO)>0)
											{
												//CODE For Getting the Data Item Files
												for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
												{
													NewDataItemObjP=setGet(DataItemSO,DataItem);

													t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
													DiClassS=nlsStrDup(DiClassDupS);
													printf("\n Data item class name:[%s]",DiClassS);

													t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));

													if((nlsStrCmp(DiClassS,"ProDrw")==0)||(nlsStrCmp(DiClassS,"x0CatDrw")==0)||(nlsStrCmp(DiClassS,"PdfFile")==0))
													{
														t5CheckDstat(objGetAttribute(DataItemObjP,OwnerNameAttr,&DIOwnerNameDup));
														DIOwnerName=nlsStrDup(DIOwnerNameDup);

														//if ((nlsStrCmp(DIOwnerName,"Release Vault")==NULL) || (nlsStrStr(DIOwnerName,"CE Vault")!=NULL) )
														//{
															t5CheckDstat(objGetAttribute(DataItemObjP,RelativePathAttr,&DIRelPathDup));
															if(!nlsIsStrNull(DIRelPathDup))
															{
																DIRelPath=nlsStrDup(DIRelPathDup);
															}
															else
															{
																DIRelPath=nlsStrDup("");
															}

															t5CheckDstat(objGetAttribute(DataItemObjP,DisplayedNameAttr,&DIDisplayNmDup));
															if(!nlsIsStrNull(DIDisplayNmDup))
															{
																DIDisplayNm=nlsStrDup(DIDisplayNmDup);
															}
															else
															{
																DIDisplayNm=nlsStrDup("");
															}

															t5CheckDstat(objGetAttribute(DataItemObjP,WorkingRelativePathAttr,&DIFileWorkingRelativePathDup));
															DIFileWorkingRelativePath=nlsStrDup(DIFileWorkingRelativePathDup);

															t5CheckDstat(objGetAttribute(DataItemObjP,SequenceAttr,&DISequenceDup));
															DISequence=nlsStrDup(DISequenceDup);

															t5CheckDstat(objGetAttribute(DataItemObjP,OwnerDirNameAttr,&DIOwnerDirNameDup));
															DIOwnerDirName=nlsStrDup(DIOwnerDirNameDup);

															t5CheckDstat(GetInfoItem(DataItemObjP,&proprtDIObjP,mfail));

															t5CheckDstat(objGetAttribute(proprtDIObjP,FullPathAttr,&DIfullPathDup)) ;
															DIfullPath=nlsStrDup(DIfullPathDup);
														//}

														t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
														if(SetFlagforScope(VisualizationFileSO)==1)
														{
															if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
															t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
															if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
														}

														if(setSize(VisualizationFileSO)>0)
														{
															for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
															{
																NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

																t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));

																t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
																VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);

																//if ((nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL) || (nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL) || (nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL) )
																//{
																	t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
																	VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);

																	t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&PdfDisDupS));
																	PdfDisS=nlsStrDup(PdfDisDupS);

																	t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
																	VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);

																	t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
																	VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);

																	t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
																	VisFileClassS=nlsStrDup(VisFileClassDupS);


																	t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
																	VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);

																	t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));

																	t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
																	fullPathattrDup=nlsStrDup(fullPathattr);
																//}
															}
														} // if condn end for setSize(VisualizationFileSO)
														else
														{
															VisFileRelPathS=nlsStrDup("");
															PdfDisS=nlsStrDup("");
															VisFileWorkingRelativePathS=nlsStrDup("");
															VisFileSequenceS=nlsStrDup("");
															VisFileClassS=nlsStrDup("");
															VisFileOwnerDirNameS=nlsStrDup("");
															fullPathattrDup=nlsStrDup("");
														}
													}
												} // for loop end for DataItemSO
											} // if condn end for setSize(DataItemSO)
										}
									}
								} // if condn end for setSize(LatestDocSO)
							} // if condn end for (nlsStrCmp(TCDrawingIndDup,"D")==0)
						}

						if (t5DrwDocFlag == 0)
						{
							DocumentSO = NULL;
							DocumentRelSO = NULL;
							LatestDocSO = NULL;
							LatestRelDocSO = NULL;

							if(nlsStrCmp(TCDrawingIndDup,"D")==0)
							{
								if(dstat = ExpandObject2(InfoDwgClass,setGet(DocPartSO,i),"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
								if(SetFlagforScope(DocumentSO)==1)
								{
									if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
									if(dstat = ExpandObject2(InfoDwgClass,setGet(DocPartSO,i),"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
									if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
								}
								printf("\n 2.setSize(DocumentSO) :%d",setSize(DocumentSO));
								if (setSize(DocumentSO) > 0)
								{
									//printf("\n\t  1..Doc present "); fflush(stdout);
									if(dstat = t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail)) goto CLEANUP;
									//printf("\n 2.setSize(LatestDocSO) :%d",setSize(LatestDocSO));
									if (setSize(LatestDocSO) > 0)
									{
										t5DrwDocFlag = 0;

										for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
										{
											LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

											t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
											DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
											printf("\n 2.Document Class:[%s]",DocBIClassNameS);

											if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
											{
												t5DrwDocFlag = 1;

												t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
												if(SetFlagforScope(DataItemSO)==1)
												{
													if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
													t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
													if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
												}
												printf("\n 2.setSize(DataItemSO) :%d",setSize(DataItemSO));
												if(setSize(DataItemSO)>0)
												{
													//CODE For Getting the Data Item Files
													for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
													{
														NewDataItemObjP=setGet(DataItemSO,DataItem);

														t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
														DiClassS=nlsStrDup(DiClassDupS);
														printf("\n Data item class name:[%s]",DiClassS);

														t5CheckDstat(objCopy(&DataItemObjP,NewDataItemObjP));

														if((nlsStrCmp(DiClassS,"ProDrw")==0) || (nlsStrCmp(DiClassS,"x0CatDrw")==0)||(nlsStrCmp(DiClassS,"PdfFile")==0))
														{
															t5CheckDstat(objGetAttribute(DataItemObjP,OwnerNameAttr,&DIOwnerNameDup));
															DIOwnerName=nlsStrDup(DIOwnerNameDup);

															//if ((nlsStrCmp(DIOwnerName,"Release Vault")==NULL) || (nlsStrStr(DIOwnerName,"CE Vault")!=NULL) )
															//{
																t5CheckDstat(objGetAttribute(DataItemObjP,RelativePathAttr,&DIRelPathDup));
																DIRelPath=nlsStrDup(DIRelPathDup);

																t5CheckDstat(objGetAttribute(DataItemObjP,DisplayedNameAttr,&DIDisplayNmDup));
																DIDisplayNm=nlsStrDup(DIDisplayNmDup);

																t5CheckDstat(objGetAttribute(DataItemObjP,WorkingRelativePathAttr,&DIFileWorkingRelativePathDup));
																DIFileWorkingRelativePath=nlsStrDup(DIFileWorkingRelativePathDup);

																t5CheckDstat(objGetAttribute(DataItemObjP,SequenceAttr,&DISequenceDup));
																DISequence=nlsStrDup(DISequenceDup);

																t5CheckDstat(objGetAttribute(DataItemObjP,OwnerDirNameAttr,&DIOwnerDirNameDup));
																DIOwnerDirName=nlsStrDup(DIOwnerDirNameDup);

																t5CheckDstat(GetInfoItem(DataItemObjP,&proprtDIObjP,mfail));

																t5CheckDstat(objGetAttribute(proprtDIObjP,FullPathAttr,&DIfullPathDup)) ;
																DIfullPath=nlsStrDup(DIfullPathDup);
															//}

															t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
															if(SetFlagforScope(VisualizationFileSO)==1)
															{
																if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
																t5CheckMfail(ExpandObject5(GenVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&VisualizationFileSO,mfail));
																if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
															}

															if(setSize(VisualizationFileSO)>0)
															{
																for(VisFile=0;VisFile<setSize(VisualizationFileSO);VisFile++)
																{
																	NewVisFileObjP=setGet(VisualizationFileSO,VisFile);

																	t5CheckDstat(objCopy(&VisFileObjP,NewVisFileObjP));

																	t5CheckDstat(objGetAttribute(VisFileObjP,OwnerNameAttr,&VisFileOwnerNameDupS));
																	VisFileOwnerNameS=nlsStrDup(VisFileOwnerNameDupS);

																	//if ((nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL) || (nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL) || (nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL) )
																	//{
																		t5CheckDstat(objGetAttribute(VisFileObjP,RelativePathAttr,&VisFileRelPathDupS));
																		VisFileRelPathS=nlsStrDup(VisFileRelPathDupS);

																		t5CheckDstat(objGetAttribute(VisFileObjP,DisplayedNameAttr,&PdfDisDupS));
																		PdfDisS=nlsStrDup(PdfDisDupS);

																		t5CheckDstat(objGetAttribute(VisFileObjP,WorkingRelativePathAttr,&VisFileWorkingRelativePathDupS));
																		VisFileWorkingRelativePathS=nlsStrDup(VisFileWorkingRelativePathDupS);

																		t5CheckDstat(objGetAttribute(VisFileObjP,SequenceAttr,&VisFileSequenceDupS));
																		VisFileSequenceS=nlsStrDup(VisFileSequenceDupS);

																		t5CheckDstat(objGetAttribute(VisFileObjP,ClassAttr,&VisFileClassDupS));
																		VisFileClassS=nlsStrDup(VisFileClassDupS);


																		t5CheckDstat(objGetAttribute(VisFileObjP,OwnerDirNameAttr,&VisFileOwnerDirNameDupS));
																		VisFileOwnerDirNameS=nlsStrDup(VisFileOwnerDirNameDupS);

																		t5CheckDstat(GetInfoItem(VisFileObjP,&proprtrevObjP,mfail));

																		t5CheckDstat(objGetAttribute(proprtrevObjP,FullPathAttr,&fullPathattr)) ;
																		fullPathattrDup=nlsStrDup(fullPathattr);
																	//}
																}
															} // if condn end for setSize(VisualizationFileSO)
															else
															{
																VisFileRelPathS=nlsStrDup("");
																PdfDisS=nlsStrDup("");
																VisFileWorkingRelativePathS=nlsStrDup("");
																VisFileSequenceS=nlsStrDup("");
																VisFileClassS=nlsStrDup("");
																VisFileOwnerDirNameS=nlsStrDup("");
																fullPathattrDup=nlsStrDup("");
															}
														}
													} // for loop end for DataItemSO
												} // if condn end for setSize(DataItemSO)
											}
										}
									} // if condn end for setSize(LatestDocSO)
								}
							} // if condn end for (nlsStrCmp(TCDrawingIndDup,"D")==0)
						}

						//End of Fetching drawing PDF data

						break;
					}
					else
					{
						printf("   PartRev:[%s, %s] no match",PartNumberDupS2,TCRevisionDup);fflush(stdout);

						if(nlsIsStrNull(TCRevisionDup))
						{
							TCRevisionDup=nlsStrDup("");
						}
						if(nlsIsStrNull(TCSequenceDup))
						{
							TCSequenceDup=nlsStrDup("");
						}

						continue;
					}
				}
			}
			else
			{
				printf("\n\n ??? No TC part attached in PLM ... need to check  %s",PartAndDrwRelPathDup);fflush(stdout);
				TCPartExistFlag = 0;  //added on 09.11.2016

				TCRevisionDup=nlsStrDup("NR;1");
				PartNumberDupS2=nlsStrDup("");
			}
		}
		else
		{
			TCPartExistFlag = 0;  //added on 11.11.2016

			printf("\n\n ??? No attaches in PLM ... need to check  %s",PartAndDrwRelPathDup);fflush(stdout);

			//TCRevisionDup=nlsStrDup("NR");

			if(nlsIsStrNull(TCRevisionDup))
			{
				TCRevisionDup=nlsStrDup("NR;1");
				PartNumberDupS2=nlsStrDup("");
			}
		}
	}

	if ((TCPartExistFlag == 0) && (nlsIsStrNull(PartNumberDupS2)))
	{
		if(!nlsIsStrNull(PartAndDrwRelPathDup0))
		{
			if (nlsStrStr(PartAndDrwRelPathDup0,"/") !=NULL)
			{
				TcPrtTemp = nlsStrAlloc(200);

				TcPrtTemp = strtok(PartAndDrwRelPathDup0,"/");

				while (TcPrtTemp != NULL)
				{
					TcPrtTemp = strtok(NULL,"/");

					if(!nlsIsStrNull(TcPrtTemp))
					{
						PartAndDrwRelPathDup2 = nlsStrDup(TcPrtTemp);
					}
				}
				printf("\n PartAndDrwRelPathDup2: %s   ",PartAndDrwRelPathDup2);fflush(stdout);
			}
			else
			{
				PartAndDrwRelPathDup2 = nlsStrDup(PartAndDrwRelPathDup0);
			}

			if (nlsStrStr(PartAndDrwRelPathDup2,"<") !=NULL)
			{
				PartNumberDupS2=nlsStrDup(strtok(PartAndDrwRelPathDup2,"<"));
			}
			else if (nlsStrStr(PartAndDrwRelPathDup2,".") !=NULL)
			{
				PartNumberDupS2=nlsStrDup(strtok(PartAndDrwRelPathDup2,"."));
			}
			else
			{
				PartNumberDupS2=nlsStrDup(" ");
			}
		}
		else
		{
			PartNumberDupS2=nlsStrDup(" ");
		}

		printf(" [%s , %s]",PartNumberDupS2,TCRevisionDup);fflush(stdout);
	}


	t5CheckMfail(ExpandObject2("ProToVis",JTDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&JTPartSO,&JTPartRelSO,mfail));
	if(SetFlagforScope(JTPartSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2("ProToVis",JTDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&JTPartSO,&JTPartRelSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\n number of jt files attached with JTRelativePathDup is :%s  are :%d",JTDataRelPathDup,setSize(JTPartSO));
	if (setSize(JTPartSO)==1)
	{
		JTPartObjP=setGet(JTPartSO,0);
		t5CheckDstat(objCopy(&JTObjP,JTPartObjP));

		t5CheckDstat(objGetAttribute(JTObjP,"RelativePath",&JTRelativePathS));
		if(JTRelativePathDup!=NULL)
		{
			nlsStrFree(JTRelativePathDup);
			JTRelativePathDup = NULL;
		}
	    JTRelativePathDup=nlsStrDup(JTRelativePathS);
		t5CheckDstat(objGetAttribute(JTObjP,"OwnerName",&JTOwnerNameDupS));
		JTOwnerNameS=nlsStrDup(JTOwnerNameDupS);
		printf("\n JTRelativePathDup is: %s ",JTRelativePathDup);

		t5CheckDstat(objGetAttribute(JTObjP,"WorkingRelativePath",&JTWRelativePathS));
		if(JTWRelativePathDup!=NULL)
		{
			nlsStrFree(JTWRelativePathDup);
			JTWRelativePathDup = NULL;
		}
		JTWRelativePathDup=nlsStrDup(JTWRelativePathS);
		//printf("\n JTWRelativePathDup is :%s \n",JTWRelativePathDup);

		t5CheckDstat(objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJTDupS));
		OwnerDirNameJTS=nlsStrDup(OwnerDirNameJTDupS);

		if((nlsStrCmp(InstClassS,"ProPrtI")==0) || (nlsStrCmp(InstClassS,"ProAsmI")==0))
		{
			printf("\n Class is ProPrtI/ProAsmI\n");

			//printf("\nGeneric Name is 111111 ---->%s",wrelativepath);
			printf("\ninstance Name is 111111 , class is ----> %s---->%s",DataItemFullPathDup,InstClassS); fflush(stdout);

			if(nlsStrCmp(InstClassS,"ProAsmI")==0)
			{
				/*************Added on 19.07.2016***************/

				//temp4 = nlsStrAlloc(10); nlsStrCpy(temp4,"asm");
				// OR

				t5CheckDstat(GetInfoItem(InstDataItemObjP,&GetItmInfoDataItemObjP,mfail));
				t5CheckDstat(objGetAttribute(GetItmInfoDataItemObjP,WorkingRelativePathAttr,&DIGenericName));
				if(DIGenericNameDup!=NULL){nlsStrFree(DIGenericNameDup);DIGenericNameDup = NULL;}
				DIGenericNameDup=nlsStrDup(DIGenericName);
				DIGenericNameDup2=nlsStrDup(DIGenericName);

				if(nlsStrStr(DIGenericNameDup2,".") !=NULL)
				{
					temp3 = nlsStrAlloc(100);
					temp4 = nlsStrAlloc(10);

					temp3 = strtok(DIGenericNameDup2,".");
					temp4 = strtok(NULL,".");
				}
				printf("\n ProAsmI..DIGenericNameDup:%s  [%s] \n",DIGenericNameDup,temp4); fflush(stdout);
				/************/

				t5CheckMfail(ExpandObject2(ProDepndClass,InstDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail));
				if(SetFlagforScope(ProeInstDepOnSO)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					t5CheckMfail(ExpandObject2(ProDepndClass,InstDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail));
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				printf("\n Number of ProAsmI Generic Object After Expansion is: %d \n",setSize(ProeInstDepOnSO)); fflush(stdout);

				if(nlsStrStr(wrelativepath1,"/") !=NULL)
				{
					TcPrtTemp = nlsStrAlloc(200);

					TcPrtTemp = strtok(wrelativepath1,"/");

					while (TcPrtTemp != NULL)
					{
						TcPrtTemp = strtok(NULL,"/");

						if(!nlsIsStrNull(TcPrtTemp))
						{
							wrelativepath1 = nlsStrDup(TcPrtTemp);
						}
					}
					printf("\n wrelativepath1: %s   ",wrelativepath1);fflush(stdout);
				}

				if(nlsStrStr(wrelativepath1,".") !=NULL)
				{
					asmInstanceS = strtok(wrelativepath1,".");
				}

				/*************Added on 19.07.2016***************/
				ProAsmIFlag = 0;
				for(pi=0;pi<setSize(ProeInstDepOnSO);pi++)
				{
					t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
					proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);

					printf("\n ProAsmI...proAsmDisplayNmDupS:[%s] asmInstanceS:[%s]",proAsmDisplayNmDupS,asmInstanceS); fflush(stdout);

					if((nlsStrStr(proAsmDisplayNmDupS,asmInstanceS) !=NULL ) && (nlsStrStr(proAsmDisplayNmDupS,temp4) !=NULL ))
					{
						printf("\n 1.ProAsmI...Match Found "); fflush(stdout);

						ProAsmIFlag = 1;

						AsmIObjP=setGet(ProeInstDepOnSO,pi);
						break;
					}
				}

				if (ProAsmIFlag == 0)	/************/
				{
					for(pi=0;pi<setSize(ProeInstDepOnSO);pi++)
					{
						t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
						proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);

						printf("\n ProAsmI...proAsmDisplayNmDupS:[%s] asmInstanceS:[%s]",proAsmDisplayNmDupS,asmInstanceS); fflush(stdout);

						if(nlsStrStr(proAsmDisplayNmDupS,asmInstanceS) !=NULL )
						{
							printf("\n 2.ProAsmI...Match Found "); fflush(stdout);

							ProAsmIFlag = 1;

							AsmIObjP=setGet(ProeInstDepOnSO,pi);
							break;
						}
					}
				}

				//if(setSize(ProeDataItemSO)>0)
				if(setSize(ProeInstDepOnSO)>0)
				{
					//AsmIObjP=setGet(ProeDataItemSO,0);

					t5CheckDstat(GetInfoItem(AsmIObjP,&GetItmInfoDrwObjP,mfail));

					t5CheckDstat(objGetAttribute(GetItmInfoDrwObjP,"FullPath",&GenFullPathDupS));
					GenFullPathS=nlsStrDup(GenFullPathDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"RelativePath",&relativepathS));
					relativepathDupS=nlsStrDup(relativepathS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"Sequence",&GenSeqDupS));
					GenSeqS=nlsStrDup(GenSeqDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerDirName",&GenOwnDupS));
					GenOwnS=nlsStrDup(GenOwnDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerName",&GenOwnDupS11));
					GenOwnS11=nlsStrDup(GenOwnDupS11);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerDirName",&OwnerDirNameDupS));
					OwnerDirNameS=nlsStrDup(OwnerDirNameDupS);

					//printf("\n.1..wrelativepath:[%s] \n",wrelativepath); fflush(stdout);
					printf("\n.1..wrelativepath:[%s] \n",relativepathDupS); fflush(stdout);

					fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
					//fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
					fprintf(fp1,"%s,",relativepathDupS);fflush(fp1);
					fprintf(fp1,"%s,",GenFullPathS);fflush(fp1);
					fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
					fprintf(fp1,"%s,",GenSeqS);fflush(fp1);
					fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);  //
					fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS11);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS);fflush(fp1);
					fprintf(fp1,"%d,",*level);fflush(fp1);
					fprintf(fp1,"%s,",InstClassS);fflush(fp1);
					fprintf(fp1,"%s,",DItype);fflush(fp1);
					fprintf(fp1,"\n");fflush(fp1);
				}
				else
				{
					printf("\n	ProeDataItemSO not Found"); fflush(stdout);
				}
			}
			else
			{
				printf("\ndoubt 111111111111111111111111111"); fflush(stdout);

				// *************Added on 19.07.2016***************

				//temp4 = nlsStrAlloc(10); nlsStrCpy(temp4,"prt");
				// OR

				//t5CheckDstat(GetInfoItem(InstDataItemObjP,&GetItmInfoDataItemObjP,mfail));
				//t5CheckDstat(objGetAttribute(GetItmInfoDataItemObjP,WorkingRelativePathAttr,&DIGenericName));
				//if(DIGenericNameDup!=NULL){nlsStrFree(DIGenericNameDup);DIGenericNameDup = NULL;}
				//DIGenericNameDup=nlsStrDup(DIGenericName);
				//DIGenericNameDup2=nlsStrDup(DIGenericName);
				//
				//if(nlsStrStr(DIGenericNameDup2,".") !=NULL)
				//{
				//	temp3 = nlsStrAlloc(100);
				//	temp4 = nlsStrAlloc(10);
				//
				//	temp3 = strtok(DIGenericNameDup2,".");
				//	temp4 = strtok(NULL,".");
				//}
				//printf("\n ProAsmI..DIGenericNameDup:%s  [%s] \n",DIGenericNameDup,temp4); fflush(stdout);
				// ************

				if(dstat = ExpandObject2(ProDepndClass,InstDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail)) goto CLEANUP;
				if(SetFlagforScope(ProeInstDepOnSO)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2(ProDepndClass,InstDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail)) goto CLEANUP;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				printf("\n Number of ProPrtI Generic Objects: %d",setSize(ProeInstDepOnSO)); fflush(stdout);

				if(nlsStrStr(wrelativepath1,"/") !=NULL)
				{
					TcPrtTemp = nlsStrAlloc(200);

					TcPrtTemp = strtok(wrelativepath1,"/");

					while (TcPrtTemp != NULL)
					{
						TcPrtTemp = strtok(NULL,"/");

						if(!nlsIsStrNull(TcPrtTemp))
						{
							wrelativepath1 = nlsStrDup(TcPrtTemp);
						}
					}
					printf("\n wrelativepath1: %s   ",wrelativepath1);fflush(stdout);
				}

				if(nlsStrStr(wrelativepath1,".") !=NULL)
				{
					asmInstanceS = strtok(wrelativepath1,".");
				}

				if(setSize(ProeInstDepOnSO)>0)
				{
					for(pi=0;pi<setSize(ProeInstDepOnSO);pi++)
					{
						t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
						if(!nlsIsStrNull(proAsmDisplayNmS))
						{
							proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);
							proAsmDisplayNmDupS2=nlsStrDup(proAsmDisplayNmS);
						}
						else
						{
							continue;
						}

						proAsmDisplayNmDupSTmp = strtok(proAsmDisplayNmDupS2,".");

						printf("\n ProPrtI...proAsmDisplayNmDupS:[%s]  proAsmDisplayNmDupSTmp:[%s]  asmInstanceS:[%s]",proAsmDisplayNmDupS,proAsmDisplayNmDupSTmp,asmInstanceS); fflush(stdout);

						//if(nlsStrStr(proAsmDisplayNmDupS,asmInstanceS) !=NULL )
						if(nlsStrCmp(proAsmDisplayNmDupSTmp,asmInstanceS) == 0 )
						{
							printf("\n ProPrtI...Match Found "); fflush(stdout);
							//Added on 02.10.2015 by RRR
							strcpy(tempstr,"");
							strcpy(tempstr,asmInstanceS);

							tmpStrlen = strlen(tempstr);
							//printf ("\n tmpStrlen  %d",tmpStrlen);
							charFlag = 0;
							for(i=0;i<tmpStrlen;i++)
							{
								if (!isdigit(tempstr[i]))
								{
									//printf ("\n alpha");
									charFlag = 1;
									printf ("\n charFlag %d found hence skipping\n\n",charFlag);
									break;
								}
							}

							if (charFlag == 1)
							{
								filestr = low_set_read_file("/user/omfprod/devgroups/UALoading/TMLtocmitest/ProE/ListofPLMGenericParts.txt");
								printf("\n Total content - %d\n",setSize(filestr));fflush(stdout);

								for(lcnt=0;lcnt<setSize(filestr);lcnt++)
								{
									if(nlsStrCmp(proAsmDisplayNmDupS,setGet(filestr,lcnt))==0)
									{
										printf("\n ProPrtI...Match Found in file for %s and %s ",proAsmDisplayNmDupS,setGet(filestr,lcnt)); fflush(stdout);
										GenericFlag = 1;

										break;
									}
									else if (nlsStrStr(setGet(filestr,lcnt),asmInstanceS)!=NULL)	//added on 26.10.2016 by RRR
									{
										//printf("\n In else "); fflush(stdout);
										low_set_add_str(GenInst, setGet(filestr,lcnt));
									}
								}
								printf("\n ProPrtI...GenericFlag:: %d",GenericFlag); fflush(stdout);

								if (low_set_size(GenInst) > 0)	//added on 26.10.2016 by RRR
								{
									GenInstanceFlag = 0;
									for (ii=0; ii<low_set_size(GenInst); ii++)
									{
										//docobjst=low_set_get(GenInst,ii);
										//printf("\n DB pref check -after... :%s",docobjst);fflush(stdout);
										printf("\n low_set_get(GenInst,ii):: %s",low_set_get(GenInst,ii));fflush(stdout);

										temp5 = nlsStrAlloc(50);
										temp6 = nlsStrAlloc(50);

										nlsStrCpy(temp5,low_set_get(GenInst,ii));
										nlsStrCpy(temp6,low_set_get(GenInst,ii));

										if (nlsStrCmp(strtok(temp5,"."),asmInstanceS)==0)
										{
											GenInstanceFlag = 1;
											printf("... ProPrtI...Match Found"); fflush(stdout);
											break;
										}
									}
								}

								if (GenericFlag ==0)
								{
									asmInstanceS2 = nlsStrAlloc(50);

									//nlsStrCpy(asmInstanceS2,asmInstanceS);
									nlsStrCpy(asmInstanceS2,proAsmDisplayNmDupS);
									nlsStrCat(asmInstanceS2,"%");

									t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",asmInstanceS2));
									t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Superseded","-"));
									t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
									//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
									//t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
									//t5CheckMfail(QueryWhere(ProInstClass,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
									t5CheckMfail(QueryWhere(InstClassS,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

									printf("\n ProeGenDataItemSO: %d  [%s]  [%s] \n",setSize(ProeGenDataItemSO),asmInstanceS2,temp6);fflush(stdout);

									if(setSize(ProeGenDataItemSO) == 0)		//added on 26.10.2016 by RRR
									{
										if (GenInstanceFlag == 1)
										{
											t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",temp6));
											t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											//t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Superseded","-"));
											//t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
											//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
											//t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
											//t5CheckMfail(QueryWhere(ProInstClass,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
											t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

											printf("\n 11.ProeGenDataItemSO: %d   [%s]\n",setSize(ProeGenDataItemSO),temp4);fflush(stdout);
										}
										else
										{
											t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",asmInstanceS2));
											t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											//t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Superseded","-"));
											//t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
											//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
											//t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
											//t5CheckMfail(QueryWhere(ProInstClass,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
											t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

											printf("\n 12.ProeGenDataItemSO: %d   [%s]\n",setSize(ProeGenDataItemSO),asmInstanceS2);fflush(stdout);
										}
									}

									if(setSize(ProeGenDataItemSO)>0)
									{
										PrtIObjP=setGet(ProeGenDataItemSO,0);

										//if(dstat=objCopy(&PrtIObjP,PrtGObjP)) goto EXIT;
									}
								}
								else if (GenericFlag ==1)
								{
									printf("\n ....111...");fflush(stdout);

									PrtIObjP=setGet(ProeInstDepOnSO,pi);
								}
							}
							else
							{
								printf("\n ....122...");fflush(stdout);
								PrtIObjP=setGet(ProeInstDepOnSO,pi);
							}
							break;
						}
					}

					if (PrtIObjP != NULL)
					{
						t5CheckDstat(GetInfoItem(PrtIObjP,&GetItmInfoDrwObjP,mfail));

						t5CheckDstat(objGetAttribute(GetItmInfoDrwObjP,"FullPath",&GenFullPathDupS));
						GenFullPathS=nlsStrDup(GenFullPathDupS);

						t5CheckDstat(objGetAttribute(PrtIObjP,"RelativePath",&relativepathS));
						relativepathDupS=nlsStrDup(relativepathS);
						relativepathDupS2=nlsStrDup(relativepathS);

						t5CheckDstat(objGetAttribute(PrtIObjP,"Sequence",&GenSeqDupS));
						GenSeqS=nlsStrDup(GenSeqDupS);

						t5CheckDstat(objGetAttribute(PrtIObjP,"OwnerDirName",&GenOwnDupS));
						GenOwnS=nlsStrDup(GenOwnDupS);

						t5CheckDstat(objGetAttribute(PrtIObjP,"OwnerName",&GenOwnDupS11));
						GenOwnS11=nlsStrDup(GenOwnDupS11);

						t5CheckDstat(objGetAttribute(PrtIObjP,"OwnerDirName",&OwnerDirNameDupS));
						OwnerDirNameS=nlsStrDup(OwnerDirNameDupS);

						printf("\n.2..wrelativepath:[%s] \n",relativepathDupS); fflush(stdout);
						//printf("\n.2..wrelativepath:[%s] \n",wrelativepath); fflush(stdout);

						/*fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
						fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
						fprintf(fp1,"NULL,");fflush(fp1);
						fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
						fprintf(fp1,"NULL,");fflush(fp1);
						fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
						fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
						fprintf(fp1,"NULL,");fflush(fp1);
						fprintf(fp1,"NULL,");fflush(fp1);
						fprintf(fp1,"%d,",*level);fflush(fp1);
						fprintf(fp1,"%s",InstClassS);fflush(fp1);
						fprintf(fp1,"\n");fflush(fp1);*/

						fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
						//fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
						fprintf(fp1,"%s,",relativepathDupS);fflush(fp1);
						fprintf(fp1,"%s,",GenFullPathS);fflush(fp1);
						fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
						fprintf(fp1,"%s,",GenSeqS);fflush(fp1);
						fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);  //
						fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
						fprintf(fp1,"%s,",GenOwnS11);fflush(fp1);
						fprintf(fp1,"%s,",GenOwnS);fflush(fp1);
						fprintf(fp1,"%d,",*level);fflush(fp1);
						fprintf(fp1,"%s,",InstClassS);fflush(fp1);
						fprintf(fp1,"%s,",DItype);fflush(fp1);
						fprintf(fp1,"\n");fflush(fp1);
					}

	SetOfObjects GenDIDocSO = NULL;
	SetOfObjects GenDIDocRelSO = NULL;
	SetOfObjects GenDocPartSO = NULL;
	SetOfObjects GenDocPartRelSO = NULL;
	ObjectPtr GenDIDocObjP = NULL;
	//ObjectPtr PrtGenericObjP = NULL;

	string proDisplayNm = NULL;
	string proDisplayNmDup = NULL;
	string proDisplayNmDupTmp = NULL;
	//string DSClass = NULL;
	//string DSClassDup = NULL;
	string GenPart = NULL;
	string GenPartDup = NULL;
	string GenRev = NULL;
	string GenRevDup = NULL;
	string GenSeq = NULL;
	string GenSeqDup = NULL;
	string temp2Rev = NULL;
	string temp2RevDup = NULL;
	string temp2Seq = NULL;
	string temp2SeqDup = NULL;
/*					if ((NonStdGenericPartFlag == 0) || (NonStdGenericPartFlag == 1))  //Added on 05.09.2017
					{
						temp1 = nlsStrAlloc(100);
						temp2 = nlsStrAlloc(100);

						temp1 = strtok(DataItemFullPathDup4,"<");
						temp2 = strtok(NULL,">");

						temp2Dup=nlsStrDup(temp2);

						if (PrtIObjP != NULL)
						{
							t5CheckDstat(objGetAttribute(PrtIObjP,DisplayedNameAttr,&proDisplayNm));
							if(!nlsIsStrNull(proDisplayNm))
							{
								proDisplayNmDup=nlsStrAlloc(30);
								proDisplayNmDupTmp=nlsStrDup(proDisplayNm);
								proDisplayNmDup=strtok(proDisplayNmDupTmp,".");
							}

							t5CheckMfail(ExpandObject2(AttachClass,PrtIObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&GenDIDocSO,&GenDIDocRelSO,mfail));
							printf("\n GenDIDocSO: %d",setSize(GenDIDocSO));fflush(stdout);
							////sort by creation date function for GenDIDocSO and processing for latest part rev is added on 24.07.2015
							t5CheckMfail(t5SortBOMObjsByDate(&GenDIDocSO,&GenDIDocRelSO,mfail));

							if(setSize(GenDIDocSO)>0)
							{
								GenDIDocObjP = setGet(GenDIDocSO,0);

								//t5CheckDstat(objGetAttribute(GenDIDocObjP,"Class",&DSClass));
								//if(!nlsIsStrNull(DSClass))
								//{
								//	DSClassDup=nlsStrDup(DSClass);
								//}
								//printf("\t DSClassDup:%s",DSClassDup); fflush(stdout);

								t5CheckMfail(ExpandObject2(PartDocClass,GenDIDocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&GenDocPartSO,&GenDocPartRelSO,mfail));
								t5CheckMfail(t5SortBOMObjsByDate(&GenDocPartSO,&GenDocPartRelSO,mfail));
								printf("\t Generic-objects: %d",setSize(GenDocPartSO));fflush(stdout);

								if(setSize(GenDocPartSO)>0)
								{
									if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,PartNumberAttr,&GenPart)) goto CLEANUP;
									GenPartDup=nlsStrDup(GenPart);

									if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,RevisionAttr,&GenRev)) goto CLEANUP;
									GenRevDup=nlsStrDup(GenRev);

									if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,SequenceAttr,&GenSeq)) goto CLEANUP;
									GenSeqDup=nlsStrDup(GenSeq);

									if (NonStdGenericPartFlag == 0)
									{
										GenRevDup=nlsStrDup("NR");
										GenSeqDup=nlsStrDup("1");
									}
								}
								else
								{
									GenRevDup=nlsStrDup("NR");
									GenSeqDup=nlsStrDup("1");
								}
							}
							else
							{
								GenPartDup=nlsStrDup(proDisplayNmDup);
								GenRevDup=nlsStrDup("NR");
								GenSeqDup=nlsStrDup("1");
							}
						}
						else
						{
							GenRevDup=nlsStrDup("NR");
							GenSeqDup=nlsStrDup("1");
						}

						printf("\n rrr...GenPartDup: %s   GenRevDup: %s  GenSeqDup: %s   proDisplayNmDup: %s",GenPartDup,GenRevDup,GenSeqDup,proDisplayNmDup);fflush(stdout);

						DataItemFullPathDup5 = nlsStrAlloc(200);

						if (nlsStrStr(DataItemFullPathDup2,"/") !=NULL)
						{
							TcPrtTemp = nlsStrAlloc(200);

							TcPrtTemp = strtok(DataItemFullPathDup2,"/");

							while (TcPrtTemp != NULL)
							{
								TcPrtTemp = strtok(NULL,"/");

								if(!nlsIsStrNull(TcPrtTemp))
								{
									DataItemFullPathDup5 = nlsStrDup(TcPrtTemp);
								}
							}
							printf("\n DataItemFullPathDup5: %s   ",DataItemFullPathDup5);fflush(stdout);
						}
						else
						{
							DataItemFullPathDup5 = nlsStrDup(DataItemFullPathDup2);
						}

						if (nlsStrStr(DataItemFullPathDup5,"<") !=NULL)
						{
							DataItemFullPathDup5=nlsStrDup(strtok(DataItemFullPathDup5,"<"));
						}

						//Below query is added on 14.04.2017
						if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
							(dstat = oiSqlWhereBegParen(Sql_ptr))||
							(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,DataItemFullPathDup5)) ||
							(dstat = oiSqlWhereEndParen(Sql_ptr))||
							(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
						if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&InstSO,mfail)) goto EXIT;
						printf ("\n %s  setSize(InstSO): %d",DataItemFullPathDup5, setSize(InstSO));

						InstRevisionDup = nlsStrAlloc(10);
						if (setSize(InstSO) > 0)
						{
							if (dstat = objGetAttribute( setGet(InstSO,0) ,RevisionAttr,&temp2Rev)) goto CLEANUP;
							temp2RevDup=nlsStrDup(temp2Rev);

							if (dstat = objGetAttribute( setGet(InstSO,0) ,SequenceAttr,&temp2Seq)) goto CLEANUP;
							temp2SeqDup=nlsStrDup(temp2Seq);

							InstRevisionDup=nlsStrDup(temp2RevDup);
							nlsStrCat(InstRevisionDup,";");
							nlsStrCat(InstRevisionDup,temp2SeqDup);
						}
						else
						{
							InstRevisionDup=nlsStrDup("NR;1");
						}

						printf("\n Generic: %s",temp2Dup); fflush(stdout);
						printf("\n GenRevDup: %s",GenRevDup); fflush(stdout);
						printf("\n GenSeqDup: %s",GenSeqDup); fflush(stdout);
						printf("\n Instance: %s",DataItemFullPathDup5); fflush(stdout);
						printf("\n Instance Rev: %s",InstRevisionDup); fflush(stdout);

						fprintf(fpGenFile,"%s",temp2Dup);		//1
						fprintf(fpGenFile,"^");
						fprintf(fpGenFile,"%s",GenRevDup);	//2
						fprintf(fpGenFile,"^");
						fprintf(fpGenFile,"%s",GenSeqDup);	//3
						fprintf(fpGenFile,"^");
						fprintf(fpGenFile,"%s;%s^",DataItemFullPathDup5,InstRevisionDup);		//4
						fprintf(fpGenFile,"\n");
						fflush(fpGenFile);
					}*/

					if ((NonStdGenericPartFlag == 0) || (NonStdGenericPartFlag == 1))		//added on 24.10.2016 for non-standard instance<Generic> and project != "1111"
					{
						if (NonStdGenericPartFlag == 1)
						{
							if (PrtIObjP != NULL)
							{
								t5CheckDstat(objGetAttribute(PrtIObjP,DisplayedNameAttr,&proDisplayNm));
								if(!nlsIsStrNull(proDisplayNm))
								{
									proDisplayNmDup=nlsStrAlloc(30);
									proDisplayNmDupTmp=nlsStrDup(proDisplayNm);
									proDisplayNmDup=strtok(proDisplayNmDupTmp,".");
								}

								t5CheckMfail(ExpandObject2(AttachClass,PrtIObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&GenDIDocSO,&GenDIDocRelSO,mfail));
								printf("\n GenDIDocSO: %d",setSize(GenDIDocSO));fflush(stdout);
								////sort by creation date function for GenDIDocSO and processing for latest part rev is added on 24.07.2015
								t5CheckMfail(t5SortBOMObjsByDate(&GenDIDocSO,&GenDIDocRelSO,mfail));

								if(setSize(GenDIDocSO)>0)
								{
									GenDIDocObjP = setGet(GenDIDocSO,0);

									//t5CheckDstat(objGetAttribute(GenDIDocObjP,"Class",&DSClass));
									//if(!nlsIsStrNull(DSClass))
									//{
									//	DSClassDup=nlsStrDup(DSClass);
									//}
									//printf("\t DSClassDup:%s",DSClassDup); fflush(stdout);

									t5CheckMfail(ExpandObject2(PartDocClass,GenDIDocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&GenDocPartSO,&GenDocPartRelSO,mfail));
									t5CheckMfail(t5SortBOMObjsByDate(&GenDocPartSO,&GenDocPartRelSO,mfail));
									printf("\t Instance-objects: %d",setSize(GenDocPartSO));fflush(stdout);

									if(setSize(GenDocPartSO)>0)
									{
										if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,PartNumberAttr,&GenPart)) goto CLEANUP;
										GenPartDup=nlsStrDup(GenPart);

										if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,RevisionAttr,&GenRev)) goto CLEANUP;
										GenRevDup=nlsStrDup(GenRev);

										if (dstat = objGetAttribute( setGet(GenDocPartSO,0) ,SequenceAttr,&GenSeq)) goto CLEANUP;
										GenSeqDup=nlsStrDup(GenSeq);

										if (NonStdGenericPartFlag == 0)
										{
											GenRevDup=nlsStrDup("NR");
											GenSeqDup=nlsStrDup("1");
										}
									}
									else
									{
										GenRevDup=nlsStrDup("NR");
										GenSeqDup=nlsStrDup("1");
									}
								}
								else
								{
									GenPartDup=nlsStrDup(proDisplayNmDup);
									GenRevDup=nlsStrDup("NR");
									GenSeqDup=nlsStrDup("1");
								}
							}
							else
							{
								GenRevDup=nlsStrDup("NR");
								GenSeqDup=nlsStrDup("1");
							}

							printf("\n rrr...GenPartDup: %s   GenRevDup: %s  GenSeqDup: %s   proDisplayNmDup: %s",GenPartDup,GenRevDup,GenSeqDup,proDisplayNmDup);fflush(stdout);
						}
						else
						{
							GenRevDup=nlsStrDup("NR");		//Added on 03.04.2017
							GenSeqDup=nlsStrDup("1");
						}

						temp1 = nlsStrAlloc(100);
						temp2 = nlsStrAlloc(100);

						temp1 = strtok(DataItemFullPathDup3,"<");
						temp2 = strtok(NULL,">");

						printf("\nGeneric temp2---->%s",temp2);

						if(nlsIsStrNull(GenPartDup))
						{
							GenPartDup=nlsStrDup(temp2);
						}
						temp2Dup=nlsStrDup(temp2);

						printf ("\n\nBefore conversion: %s", temp2Dup);
						for (p = temp2Dup; *p != '\0'; ++p)
						{
							*p = tolower(*p);
						}
						printf ("\nAfter conversion: %s		GenPartDup:[%s]", temp2Dup , GenPartDup);

						if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
							(dstat = oiSqlWhereBegParen(Sql_ptr))||
							(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,temp2Dup)) ||
							(dstat = oiSqlWhereEndParen(Sql_ptr))||
							//(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
							(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;		//Added on 03.04.2017
						if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&GenericSO,mfail)) goto EXIT;
						printf ("\t setSize(GenericSO): %d", setSize(GenericSO));

						if (setSize(GenericSO) > 0)
						{
							GenericObjP = NULL;
							//	PrtInstanceMatchFlag = 0;
							//	for(m=0;m<setSize(GenericSO);m++)		//commented on 03.04.2017
							//	{
							//		PrtGenericObjP = setGet(GenericSO,m);
							//		if (dstat = objGetAttribute( PrtGenericObjP ,RevisionAttr,&temp2Rev)) goto CLEANUP;
							//		temp2RevDup=nlsStrDup(temp2Rev);
							//		if (dstat = objGetAttribute( PrtGenericObjP ,SequenceAttr,&temp2Seq)) goto CLEANUP;
							//		temp2SeqDup=nlsStrDup(temp2Seq);
							//		if ((nlsStrCmp(temp2RevDup,GenRevDup)==0) && (nlsStrCmp(temp2SeqDup,GenSeqDup)==0))
							//		{
							//			GenericObjP=setGet(GenericSO,m);
							//			PrtInstanceMatchFlag = 1;
							//		}
							//		t5CheckMfail(GetGenTCPartProEInfo(PrtIObjP,GenericObjP, temp2, temp2RevDup, temp2SeqDup, "", mfail, level));
							//	}
							//}
							//else
							//{
							//	PrtInstanceMatchFlag = 0;
							//	GenericObjP = NULL;
							//	t5CheckMfail(GetGenTCPartProEInfo(PrtIObjP,GenericObjP, temp2, "NR", "1", "", mfail, level));
							//}
							//if (PrtInstanceMatchFlag == 1)		//Added on 27.03.2017 as above logic is added for all instance revisions.
							//{
							//	//for(m=0;m<setSize(GenericSO);m++)
							//	//{
							//	//	GenericObjP=setGet(GenericSO,m);

								GenericObjP=setGet(GenericSO,0);		//commented on 27.03.2017 as above logic is added for all instance revisions.

								if (setSize(GenericSO) > 1)
								{
									t5CheckDstat(objGetAttribute(GenericObjP,RevisionAttr,&temp2Rev));
									if(!nlsIsStrNull(temp2Rev))
									{
										temp2RevDup=nlsStrDup(temp2Rev);
									}
									t5CheckDstat(objGetAttribute(GenericObjP,SequenceAttr,&temp2Seq));
									if(!nlsIsStrNull(temp2Seq))
									{
										temp2SeqDup=nlsStrDup(temp2Seq);
									}
									t5CheckMfail(GetGenTCPartProEInfo(PrtIObjP,GenericObjP, temp2, temp2RevDup, temp2SeqDup, "", mfail, level));
								}
								else
								{
									t5CheckMfail(GetGenTCPartProEInfo(PrtIObjP,GenericObjP, temp2, "NR", "1", "", mfail, level));
								}

								//printf("\n\n"); fflush(stdout);
								//objDump(GenericObjP);
								//printf("\n\n"); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,NomenclatureAttr,&NomenclatureS));
								if(!nlsIsStrNull(NomenclatureS))
								{
									NomenclatureDupS=nlsStrDup(NomenclatureS);
								}
								else
								{
									NomenclatureDupS=nlsStrDup("Dummy Generic Part for Proe.");
								}
								NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
								NomenclatureDupS=low_strssra(NomenclatureDupS,"^"," ");
								printf("\n\t Gen..NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,ProjectNameAttr,&ProjectNameS));
								if(!nlsIsStrNull(ProjectNameS))
								{
									ProjectNameDupS=nlsStrDup(ProjectNameS);
								}

								t5CheckDstat(objGetAttribute(GenericObjP,t5DesignGroupAttr,&t5DesignGroupS));
								if(!nlsIsStrNull(t5DesignGroupS))
								{
									t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
								}
								else
								{
									t5DesignGroupDupS=nlsStrDup(" ");
								}

								t5CheckDstat(objGetAttribute(GenericObjP,t5DrawingIndAttr,&t5DrawingIndS));  //t5DrawingInd
								if(!nlsIsStrNull(t5DrawingIndS))
								{
									t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
								}
								else
								{
									t5DrawingIndDupS=nlsStrDup("N");
								}

								if((nlsStrCmp(t5DrawingIndDupS,"S")==0) && (nlsStrCmp(ProjectNameDupS,"1111")==0) && (nlsStrLen(temp2Dup) == 11) && (nlsStrCmp(subString(temp2Dup,0,1),"0") != 0))
								{
									if(dstat = objGetAttribute (GenericObjP, "t5DrawingNo", &t5DrawingNoS)) goto CLEANUP;
									if(!nlsIsStrNull(t5DrawingNoS))
									{
										t5DrawingNoDupS = nlsStrDup(t5DrawingNoS);
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup("");
									}
								}
								printf("\n GenericSO..[%s , %s] [%s , %s]",ProjectNameDupS,t5DesignGroupDupS,t5DrawingIndDupS,t5DrawingNoDupS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,t5WeightAttr,&WeightS));
								if(!nlsIsStrNull(WeightS))
								{
									WeightDupS=nlsStrDup(WeightS);
								}
								else
								{
									WeightDupS=nlsStrDup("0.00");
								}

								t5CheckDstat(objGetAttribute(GenericObjP,"t5DsgnDept",&t5DsgnDeptDupS));
								t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
								if(!nlsIsStrNull(t5EnvelopeDimenDupS))
								{
									t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
								}

								t5CheckDstat(objGetAttribute(GenericObjP,"t5HazardousContents",&t5HazardousContDupS));
								t5HazardousContS=nlsStrDup(t5HazardousContDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
								t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PartCode",&t5PartCodeDupS));
								t5PartCodeS=nlsStrDup(t5PartCodeDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
								if(!nlsIsStrNull(t5DocRemarkS))
								{
									t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
								}
								else
								{
									t5DocRemarkDupS=nlsStrDup("NEW RELEASE");
								}
								t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
								t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"^"," ");

								t5CheckDstat(objGetAttribute(GenericObjP,"t5LastModBy",&t5LastModByDupS));
								t5LastModByS=nlsStrDup(t5LastModByDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5VerCreator",&t5VerCreatorDupS));
								t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
								t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5Volume",&t5VolumeDupS));
								t5VolumeS=nlsStrDup(t5VolumeDupS);

								t5CheckDstat(objGetAttribute(GenericObjP,"CategoryName",&CategoryNameDupS));
								CategoryNameS=nlsStrDup(CategoryNameDupS);
								CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
								CategoryNameS=low_strssra(CategoryNameS,"^"," ");

								t5CheckDstat(objGetAttribute(GenericObjP,"t5DRSubState",&t5DRSubStateDupS));
								if(!nlsIsStrNull(t5DRSubStateDupS))
								{
									t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
								}
								else
								{
									t5DRSubStateS=nlsStrDup("NA");
								}

								t5CheckDstat(objGetAttribute(GenericObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
								if(!nlsIsStrNull(t5DsgnOwnS))
								{
									t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
								}
								else
								{
									t5DsgnOwnDupS=nlsStrDup("TELPUN");
								}

								printf ("\t WeightDupS:%s  t5EnvelopeDimenDupS:%s", WeightDupS,t5EnvelopeDimenDupS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"CreationDate",&PartCreDateS));
								if(!nlsIsStrNull(PartCreDateS))
								{
									PartCreDateDupS=nlsStrDup(PartCreDateS);
								}
								else
								{
									PartCreDateDupS=nlsStrDup("-");
								}

								t5CheckDstat(objGetAttribute(GenericObjP,"LastUpdate",&PartModDateS));
								if(!nlsIsStrNull(PartModDateS))
								{
									PartModDateDupS=nlsStrDup(PartModDateS);
								}
								else
								{
									PartModDateDupS=nlsStrDup("-");
								}

								t5CheckDstat(objGetAttribute(GenericObjP,"Creator",&PartCreator));
								PartCreatorDup=nlsStrDup(PartCreator);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
								if(!nlsIsStrNull(t5PunIntialAgDupS))
								{
									t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
								}
								else {	t5PunIntialAgS=nlsStrDup(" ");	}
								//printf("\n\t t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
								if(!nlsIsStrNull(t5PunMakeBuyIndDupS))
								{
									t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
								}
								else {	t5PunMakeBuyIndS=nlsStrDup(" ");	}
								//printf("\n\t t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
								if(!nlsIsStrNull(t5CarIntialAgencyDupS))
								{
									t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
								}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
								//printf("\n\t t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
								if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
								{
									t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
								}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
								//printf("\n\t t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
								t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
								//printf("\n\t t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
								t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
								//printf("\n\t t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
								t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
								//printf("\n\t t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
								t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
								//printf("\n\t t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
								t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
								//printf("\n\t t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
								t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
								//printf("\n\t t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
								t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
								//printf("\n\t t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
								t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
								//printf("\n\t t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
								t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
								//printf("\n\t t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
								t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
								//printf("\n\t t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
								if(!nlsIsStrNull(t5EstSheetReqdDupS))
								{
									t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
								}else {	t5EstSheetReqdS=nlsStrDup(" ");	}
								//printf("\n\t t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

								t5CheckDstat(objGetAttribute(GenericObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
								if(!nlsIsStrNull(t5AhdIntialAgencyS))
								{
									t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
								}
								else { t5AhdIntialAgencySDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
								if(!nlsIsStrNull(t5AhdMakeBuyIndS))
								{
									t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
								}
								else { t5AhdMakeBuyIndSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
								if(!nlsIsStrNull(t5DwdIntialAgencyS))
								{
									t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
								}
								else { t5DwdIntialAgencySDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
								if(!nlsIsStrNull(t5DwdMakeBuyIndS))
								{
									t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
								}
								else { t5DwdMakeBuyIndSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
								if(!nlsIsStrNull(t5JdlIntialAgencyS))
								{
									t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
								}
								else { t5JdlIntialAgencySDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
								if(!nlsIsStrNull(t5JdlMakeBuyIndS))
								{
									t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
								}
								else { t5JdlMakeBuyIndSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
								if(!nlsIsStrNull(t5AhdStoreLocS))
								{
									t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
								}
								else { t5AhdStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5CarStoreLocation",&t5CarStoreLocS));
								if(!nlsIsStrNull(t5CarStoreLocS))
								{
									t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
								}
								else { t5CarStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
								if(!nlsIsStrNull(t5DwdStoreLocS))
								{
									t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
								}
								else { t5DwdStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
								if(!nlsIsStrNull(t5JdlStoreLocS))
								{
									t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
								}
								else { t5JdlStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
								if(!nlsIsStrNull(t5JsrStoreLocS))
								{
									t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
								}
								else { t5JsrStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
								if(!nlsIsStrNull(t5LkoStoreLocS))
								{
									t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
								}
								else { t5LkoStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
								if(!nlsIsStrNull(t5PnrStoreLocS))
								{
									t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
								}
								else {	t5PnrStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
								if(!nlsIsStrNull(t5PunStoreLocationDupS))
								{
									t5PunStoreLocationS = nlsStrDup(t5PunStoreLocationDupS);
								}
								else {	t5PunStoreLocationS = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
								if(!nlsIsStrNull(t5PunPCBUStoreLocS))
								{
									t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
								}
								else { t5PunPCBUStoreLocSDup = nlsStrDup(""); }

								t5CheckDstat(objGetAttribute(GenericObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
								if(!nlsIsStrNull(t5SgrStoreLocS))
								{
									t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
								}
								else { t5SgrStoreLocSDup = nlsStrDup(""); }
							//}
						}
						else
						{
							NomenclatureDupS=nlsStrDup("Dummy Generic Part for Proe.");
							ProjectNameDupS=nlsStrDup("1111");
							t5DesignGroupDupS=nlsStrDup("11");
							t5DrawingIndDupS=nlsStrDup("N");
							t5DrawingNoDupS = nlsStrDup("");
							WeightDupS=nlsStrDup("0.00");
							t5DsgnDeptS=nlsStrDup("");
							t5EnvelopeDimenS=nlsStrDup("");
							t5HazardousContS=nlsStrDup("");
							t5HomologationReqdS=nlsStrDup("");
							t5PartCodeS=nlsStrDup("");
							t5DocRemarkDupS=nlsStrDup("NEW RELEASE");
							t5LastModByS=nlsStrDup("loader");
							t5VerCreatorS=nlsStrDup("");
							t5SurfaceAreaS=nlsStrDup("");
							t5VolumeS=nlsStrDup("");
							CategoryNameS=nlsStrDup("");
							t5DRSubStateS=nlsStrDup("NA");
							t5DsgnOwnDupS=nlsStrDup("TELPUN");
							PartCreDateDupS=nlsStrDup("-");
							PartModDateDupS=nlsStrDup("-");
							PartCreatorDup=nlsStrDup("loader");

							t5PunIntialAgS         = nlsStrDup("");
							t5PunMakeBuyIndS       = nlsStrDup("");
							t5CarIntialAgencyS     = nlsStrDup("");
							t5CarMakeBuyIndiS      = nlsStrDup("");
							t5JsrIntialAgencyS     = nlsStrDup("");
							t5JsrMakeBuyIndiS      = nlsStrDup("");
							t5LkoIntialAgencyS     = nlsStrDup("");
							t5LkoMakeBuyIndiS      = nlsStrDup("");
							t5PnrIntialAgencyS     = nlsStrDup("");
							t5PnrMakeBuyIndiS      = nlsStrDup("");
							t5PunPCBUIntialAgencyS = nlsStrDup("");
							t5PunPCBUMakeBuyIndiS  = nlsStrDup("");
							t5SgrIntialAgencyS     = nlsStrDup("");
							t5SgrMakeBuyIndiS      = nlsStrDup("");
							t5EstSheetReqdS        = nlsStrDup("");
							t5AhdIntialAgencySDup  = nlsStrDup("");
							t5AhdMakeBuyIndSDup    = nlsStrDup("");
							t5DwdIntialAgencySDup  = nlsStrDup("");
							t5DwdMakeBuyIndSDup    = nlsStrDup("");
							t5JdlIntialAgencySDup  = nlsStrDup("");
							t5JdlMakeBuyIndSDup    = nlsStrDup("");
							t5AhdStoreLocSDup      = nlsStrDup("");
							t5CarStoreLocSDup      = nlsStrDup("");
							t5DwdStoreLocSDup      = nlsStrDup("");
							t5JdlStoreLocSDup      = nlsStrDup("");
							t5JsrStoreLocSDup      = nlsStrDup("");
							t5LkoStoreLocSDup      = nlsStrDup("");
							t5PnrStoreLocSDup      = nlsStrDup("");
							t5PunStoreLocationS    = nlsStrDup("");
							t5PunPCBUStoreLocSDup  = nlsStrDup("");
							t5SgrStoreLocSDup      = nlsStrDup("");
						}

						//fprintf(fpGen,"%s","1");	//level
						//fprintf(fpGen,"^");
						//fprintf(fpGen,"%s",strtok(wrelativepath2,"."));				//1
						fprintf(fpGen,"%s",temp2);				//1
						fprintf(fpGen,"^");
						//fprintf(fpGen,"%s","NR");
						fprintf(fpGen,"%s",GenRevDup);
						fprintf(fpGen,"^");
						//fprintf(fpGen,"%s","1");
						fprintf(fpGen,"%s",GenSeqDup);
						fprintf(fpGen,"^");
						//fprintf(fpGen,"%s","Dummy Generic Part for Proe."); //NomenclatureDupS
						fprintf(fpGen,"%s",NomenclatureDupS);	//desc
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","D");		//PartTypeDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","1111");		//ProjectNameDupS
						fprintf(fpGen,"^");

						if(!nlsIsStrNull(t5DesignGroupDupS))
						{
							fprintf(fpGen,"%s",t5DesignGroupDupS);					//7
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen,"11^");
						}

						if(!nlsIsStrNull(t5DocRemarkDupS))
						{
							fprintf(fpGen,"%s",t5DocRemarkDupS);//mod_desc   t5DocRemarkDupS	//8
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen,"-^");
						}

						if(!nlsIsStrNull(t5DrawingNoDupS))
						{
							fprintf(fpGen,"%s",t5DrawingNoDupS);	//t5DrawingNoDupS		//9
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5DrawingIndDupS))
						{
							fprintf(fpGen,"%s",t5DrawingIndDupS); //t5DrawingIndDupS		//10
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen,"N^");
						}

						fprintf(fpGen,"%s","NA");			//t5MatlClassDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","-");			//t5MaterialInDrwDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","-");			//MaterialThickNessDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","NA");			//t5LeftRhDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s",t5DsgnOwnDupS);	//t5DsgnOwnDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","N");			//t5ModelIndicatorDupS;  Y/N/blank
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","4");			//UnitOfMeasureDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","N");			//t5ColourIndDupS
						fprintf(fpGen,"^");
						fprintf(fpGen,"%s","LcsSTDRlzd");	//LifeCycleStateDupS
						fprintf(fpGen,"^");
						fprintf(fpGen," ^");				//t5ColourIDDupS		//20

						if(!nlsIsStrNull(WeightDupS))
						{
							fprintf(fpGen,"%s",WeightDupS);							//21
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen,"0.00^");
						}
						fprintf(fpGen,"%s","-");			//SpareIndDupS
						fprintf(fpGen,"^");

						fprintf(fpGen," ^");				//t5CMVRCertification
						fprintf(fpGen," ^");				//t5ClassificationHaz
						fprintf(fpGen," ^");				//t5ConfigID
						fprintf(fpGen," ^");				//t5Dismantable

						if(!nlsIsStrNull(t5DsgnDeptS))
						{
							fprintf(fpGen,"%s",t5DsgnDeptS);	//t5DsgnDeptS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5EnvelopeDimenS)){
							fprintf(fpGen,"%s",t5EnvelopeDimenS);	//t5EnvelopeDimenS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5HazardousContS)){
							fprintf(fpGen,"%s",t5HazardousContS);	//t5HazardousContS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5HomologationReqdS)){
							fprintf(fpGen,"%s",t5HomologationReqdS);//t5HomologationReqdS		//30
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						fprintf(fpGen," ^");			//t5ListRecSpares
						fprintf(fpGen," ^");			//t5NcPartNoS

						if(!nlsIsStrNull(t5PartCodeS)){
							fprintf(fpGen,"%s",t5PartCodeS);	//t5PartCodeS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						fprintf(fpGen," ^");			//t5PartPropertyS
						fprintf(fpGen," ^");			//t5PartStatusS
						fprintf(fpGen," ^");			//t5PkgStdS
						fprintf(fpGen," ^");			//t5ProductS
						fprintf(fpGen," ^");			//t5PrtCatCodeS

						if(!nlsIsStrNull(t5PunIntialAgS)){
							fprintf(fpGen,"%s",t5PunIntialAgS);
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5PunMakeBuyIndS)){
							fprintf(fpGen,"%s",t5PunMakeBuyIndS);	//40
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						fprintf(fpGen," ^");			//t5RecoverableS
						fprintf(fpGen," ^");			//t5RecyclabilityS
						fprintf(fpGen," ^");			//t5RefPartNumberS
						fprintf(fpGen," ^");			//t5ReliabilityS
						fprintf(fpGen," ^");			//t5SpareCriteriaS
						fprintf(fpGen," ^");			//t5SurfPrtStdS
						fprintf(fpGen," ^");			//t5SamplesToApprS
						fprintf(fpGen," ^");			//t5AsmDisposalS
						fprintf(fpGen," ^");			//t5FinDisposalInstrS
						fprintf(fpGen," ^");			//t5RPDisposalInstrS		//50
						fprintf(fpGen," ^");			//t5SPDisposalInstrS
						fprintf(fpGen," ^");			//t5WIPDisposalInstrS

						if(!nlsIsStrNull(t5LastModByS)){
							fprintf(fpGen,"%s",t5LastModByS);	//t5LastModByS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen,"loader^");
						}

						if(!nlsIsStrNull(t5VerCreatorS)){
							fprintf(fpGen,"%s",t5VerCreatorS); //t5VerCreatorS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}
						fprintf(fpGen," ^");			//t5CAEDocES

						fprintf(fpGen,"%s","N");		//t5CoatedS
						fprintf(fpGen,"^");

						fprintf(fpGen," ^");			//t5ConvDocS
						fprintf(fpGen," ^");			//t5AplCopyOfErcRevS
						fprintf(fpGen," ^");			//t5AplCopyOfErcSeqS
						fprintf(fpGen," ^");			//t5AppCodeS				//60
						fprintf(fpGen," ^");			//t5RqstNumS
						fprintf(fpGen," ^");			//t5RsnCodeS

						if(!nlsIsStrNull(t5SurfaceAreaS)){
							fprintf(fpGen,"%s",t5SurfaceAreaS); //t5SurfaceAreaS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5VolumeS)){
							fprintf(fpGen,"%s",t5VolumeS); //t5VolumeS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5CarIntialAgencyS)){
							fprintf(fpGen,"%s",t5CarIntialAgencyS);	//65
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}


						if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
							fprintf(fpGen,"%s",t5CarMakeBuyIndiS);	//66
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						fprintf(fpGen," ^");			//t5ErcIndNameS
						fprintf(fpGen," ^");			//t5PostRelReqS
						fprintf(fpGen," ^");			//t5ItmCategoryS
						fprintf(fpGen," ^");			//t5CopReqS					//70
						fprintf(fpGen," ^");			//t5AplInvalidateS
						fprintf(fpGen," ^");			//t5PrtValiStatusS

						if(!nlsIsStrNull(t5DRSubStateS)){
							fprintf(fpGen,"%s",t5DRSubStateS);//t5DRSubStateS		//73
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen,"NA^");
						}

						fprintf(fpGen," ^");			//t5KnxtDocIndS
						fprintf(fpGen," ^");			//t5SimValS
						fprintf(fpGen," ^");			//t5PerYieldS

						if(!nlsIsStrNull(t5PunStoreLocationS)){
							fprintf(fpGen,"%s",t5PunStoreLocationS);
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						fprintf(fpGen," ^");			//t5AltPartNoS
						fprintf(fpGen," ^");			//t5RolledupWtS
						fprintf(fpGen," ^");			//t5PFDModReqdS				//80
						fprintf(fpGen," ^");			//t5ToolIndentReqdS

						if(!nlsIsStrNull(CategoryNameS)){
							fprintf(fpGen,"%s",CategoryNameS);	//CategoryNameS
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}
						fprintf(fpGen,"-^");			//ReveffDateFromDup
						fprintf(fpGen,"-^");			//ReveffDateToDup			//84
						fprintf(fpGen,"NA^");			//LeftRhPartDup				//85


						////////////// Start to extract Instance Revision///////////////// 06.07.2018
						if(!nlsIsStrNull(TCRevisionDup))
						{
							fprintf(fpGen,"%s;%s^",strtok(DataItemFullPathDup2,"<"),TCRevisionDup);		//86
						}
						else
						{
							printf("\nInstance revision is blank...............???"); fflush(stdout);

							fprintf(fpGen,"%s;^",strtok(DataItemFullPathDup2,"<"));
						}
						////////////// End to extract Instance Revision///////////////// 06.07.2018


//						////////////// Start to extract Instance Revision/////////////////
////						//if(!nlsIsStrNull(TCRevisionDup))
////						//{
////						DataItemFullPathDup5 = nlsStrAlloc(200);
////
////						if (nlsStrStr(DataItemFullPathDup2,"/") !=NULL)
////						{
////							TcPrtTemp = nlsStrAlloc(200);
////
////							TcPrtTemp = strtok(DataItemFullPathDup2,"/");
////
////							while (TcPrtTemp != NULL)
////							{
////								TcPrtTemp = strtok(NULL,"/");
////
////								if(!nlsIsStrNull(TcPrtTemp))
////								{
////									DataItemFullPathDup5 = nlsStrDup(TcPrtTemp);
////								}
////							}
////							printf("\n DataItemFullPathDup5: %s   ",DataItemFullPathDup5);fflush(stdout);
////						}
////						else
////						{
////							DataItemFullPathDup5 = nlsStrDup(DataItemFullPathDup2);
////						}
////
////						//Below query is added on 14.04.2017
////						if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
////							(dstat = oiSqlWhereBegParen(Sql_ptr))||
////							(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,DataItemFullPathDup5)) ||
////							(dstat = oiSqlWhereEndParen(Sql_ptr))||
////							(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
////						if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&InstSO,mfail)) goto EXIT;
////						printf ("\n %s  setSize(InstSO): %d",DataItemFullPathDup5, setSize(InstSO));
////
////						InstRevisionDup = nlsStrAlloc(10);
////						if (setSize(InstSO) > 0)
////						{
////							if (dstat = objGetAttribute( setGet(InstSO,0) ,RevisionAttr,&temp2Rev)) goto CLEANUP;
////							temp2RevDup=nlsStrDup(temp2Rev);
////
////							if (dstat = objGetAttribute( setGet(InstSO,0) ,SequenceAttr,&temp2Seq)) goto CLEANUP;
////							temp2SeqDup=nlsStrDup(temp2Seq);
////
////							InstRevisionDup=nlsStrDup(temp2RevDup);
////							nlsStrCat(InstRevisionDup,";");
////							nlsStrCat(InstRevisionDup,temp2SeqDup);
////						}
////						else
////						{
////							InstRevisionDup=nlsStrDup("NR;1");
////						}
////
////
////						fprintf(fpGen,"%s;%s^",strtok(DataItemFullPathDup5,"<"),InstRevisionDup);		//86
////						//}
////						//else
////						//{
////						//	printf("\nInstance revision is blank...............???"); fflush(stdout);
////						//	fprintf(fpGen,"%s;^",strtok(DataItemFullPathDup2,"<"));
////						//}
//
//						DataItemFullPathDup5 = nlsStrAlloc(200);
//						if (nlsStrStr(DataItemFullPathDup2,"/") !=NULL)
//						{
//							TcPrtTemp = nlsStrAlloc(200);
//
//							TcPrtTemp = strtok(DataItemFullPathDup2,"/");
//
//							while (TcPrtTemp != NULL)
//							{
//								TcPrtTemp = strtok(NULL,"/");
//
//								if(!nlsIsStrNull(TcPrtTemp))
//								{
//									DataItemFullPathDup5 = nlsStrDup(TcPrtTemp);
//								}
//							}
//							printf("\n DataItemFullPathDup5: %s   ",DataItemFullPathDup5);fflush(stdout);
//						}
//						else
//						{
//							DataItemFullPathDup5 = nlsStrDup(DataItemFullPathDup2);
//						}
//						if (nlsStrStr(DataItemFullPathDup5,"<") !=NULL)
//						{
//							DataItemFullPathDup5=nlsStrDup(strtok(DataItemFullPathDup5,"<"));
//						}
//
//						//Below query is added on 14.04.2017
//						if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
//							(dstat = oiSqlWhereBegParen(Sql_ptr))||
//							(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,DataItemFullPathDup5)) ||
//							(dstat = oiSqlWhereEndParen(Sql_ptr))||
//							(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
//						if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&InstSO,mfail)) goto EXIT;
//						printf ("\n %s  setSize(InstSO): %d",DataItemFullPathDup5, setSize(InstSO));
//						if (setSize(InstSO) == 0)
//						{
//							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
//							if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
//								(dstat = oiSqlWhereBegParen(Sql_ptr))||
//								(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,DataItemFullPathDup5)) ||
//								(dstat = oiSqlWhereEndParen(Sql_ptr))||
//								(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
//							if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&InstSO,mfail)) goto EXIT;
//							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
//							printf ("\n DbScope...%s  setSize(InstSO): %d",DataItemFullPathDup5, setSize(InstSO));
//						}
//
//						InstRevisionDup = nlsStrAlloc(10);
//						if (setSize(InstSO) > 0)
//						{
//							if (dstat = objGetAttribute( setGet(InstSO,0) ,RevisionAttr,&temp2Rev)) goto CLEANUP;
//							temp2RevDup=nlsStrDup(temp2Rev);
//
//							if (dstat = objGetAttribute( setGet(InstSO,0) ,SequenceAttr,&temp2Seq)) goto CLEANUP;
//							temp2SeqDup=nlsStrDup(temp2Seq);
//
//							InstRevisionDup=nlsStrDup(temp2RevDup);
//							nlsStrCat(InstRevisionDup,";");
//							nlsStrCat(InstRevisionDup,temp2SeqDup);
//						}
//						else
//						{
//							InstRevisionDup=nlsStrDup("NR;1");
//						}
//
//						fprintf(fpGen,"%s;%s^",strtok(DataItemFullPathDup5,"<"),InstRevisionDup);		//86
//						////////////// End to extract Instance Revision/////////////////

						fprintf(fpGen," ^");			//t5JsrIntialAgencyS		//87
						fprintf(fpGen," ^");			//t5JsrMakeBuyIndiS			//88
						fprintf(fpGen," ^");			//t5LkoIntialAgencyS		//99
						fprintf(fpGen," ^");			//t5LkoMakeBuyIndiS			//90
						fprintf(fpGen," ^");			//t5PnrIntialAgencyS		//91
						fprintf(fpGen," ^");			//t5PnrMakeBuyIndiS			//92
						fprintf(fpGen," ^");			//t5PunPCBUIntialAgencyS	//93
						fprintf(fpGen," ^");			//t5PunPCBUMakeBuyIndiS		//94
						fprintf(fpGen," ^");			//t5SgrIntialAgencyS		//95
						fprintf(fpGen," ^");			//t5SgrMakeBuyIndiS			//96
						fprintf(fpGen," ^");			//t5EstSheetReqdS);			//97

						if(!nlsIsStrNull(PartCreDateDupS)){
							fprintf(fpGen,"%s",PartCreDateDupS); //PartCreDateDupS	//98
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(PartModDateDupS)){
							fprintf(fpGen,"%s",PartModDateDupS); //PartModDateDupS	//99
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(PartCreatorDup)){
							fprintf(fpGen,"%s",PartCreatorDup); //PartCreatorDup	//100
							fprintf(fpGen,"^");
						}else
						{
							fprintf(fpGen," ^");
						}

						if(!nlsIsStrNull(t5AhdIntialAgencySDup))
						{
							fprintf(fpGen,"%s",t5AhdIntialAgencySDup);	//101
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
						{
							fprintf(fpGen,"%s",t5AhdMakeBuyIndSDup);	//102
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5DwdIntialAgencySDup))
						{
							fprintf(fpGen,"%s",t5DwdIntialAgencySDup);	//103
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
						{
							fprintf(fpGen,"%s",t5DwdMakeBuyIndSDup);	//104
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5JdlIntialAgencySDup))
						{
							fprintf(fpGen,"%s",t5JdlIntialAgencySDup);	//105
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
						{
							fprintf(fpGen,"%s",t5JdlMakeBuyIndSDup);	//106
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5AhdStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5AhdStoreLocSDup);		//107
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5CarStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5CarStoreLocSDup);		//108
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5DwdStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5DwdStoreLocSDup);		//109
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5JdlStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5JdlStoreLocSDup);		//110
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5JsrStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5JsrStoreLocSDup);		//111
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5LkoStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5LkoStoreLocSDup);		//112
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5PnrStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5PnrStoreLocSDup);		//113
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5PunPCBUStoreLocSDup);	//114
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}
						if(!nlsIsStrNull(t5SgrStoreLocSDup))
						{
							fprintf(fpGen,"%s",t5SgrStoreLocSDup);		//115
							fprintf(fpGen,"^");
						}
						else
						{
							fprintf(fpGen," ^");
						}

						//////nlsStrCpy(DItype,"COMP_TYPE_UA");
						//if(!nlsIsStrNull(DItype))
						//{
						//	fprintf(fpGen,"%s",DItype);		//116
						//	fprintf(fpGen,"^");
						//}
						//else
						//{
						//	fprintf(fpGen,"TYPE_INVALID^");
						//}
						fflush(fpGen);
						fprintf(fpGen,"\n"); fflush(fpGen);
					}

					//Below commented on 30.09.2016 to skip JT
					//Below is uncommented on 07.12.2016 to download Generic JT
					printf("\ndoubt 222222222222222222222222"); fflush(stdout);

					if (PrtIObjP != NULL)
					{
						t5CheckMfail(ExpandObject2("ProToVis",PrtIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&GenJTPartSO,&GenJTPartRelSO,mfail));
						if(SetFlagforScope(GenJTPartSO)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							t5CheckMfail(ExpandObject2("ProToVis",PrtIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&GenJTPartSO,&GenJTPartRelSO,mfail));
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
						printf("\n setSize(GenJTPartSO) :%d",setSize(GenJTPartSO));
						if (setSize(GenJTPartSO)>0)
						{
							GenJTPartObjP=setGet(GenJTPartSO,0);

							t5CheckDstat(objCopy(&GenJTObjP,GenJTPartObjP));

							t5CheckDstat(objGetAttribute(GenJTObjP,"RelativePath",&GJTRelativePathS));
							if(GJTRelativePathDup!=NULL)
							{
								nlsStrFree(GJTRelativePathDup);
								GJTRelativePathDup = NULL;
							}
							GJTRelativePathDup=nlsStrDup(GJTRelativePathS);
							printf("\n GJTRelativePathDup is: %s ",GJTRelativePathDup);

							t5CheckDstat(objGetAttribute(GenJTObjP,"OwnerName",&GJTOwnerNameDupS));
							GJTOwnerNameS=nlsStrDup(GJTOwnerNameDupS);

							t5CheckDstat(objGetAttribute(GenJTObjP,"WorkingRelativePath",&GJTWRelativePathS));
							if(GJTWRelativePathDup!=NULL)
							{
								nlsStrFree(GJTWRelativePathDup);
								GJTWRelativePathDup = NULL;
							}
							GJTWRelativePathDup=nlsStrDup(GJTWRelativePathS);

							objGetAttribute(GenJTPartObjP,"OwnerDirName",&GOwnerDirNameJTDupS);
							GOwnerDirNameJTS=nlsStrDup(GOwnerDirNameJTDupS);

							t5CheckDstat(GetInfoItem(GenJTObjP,&GGetInfoJTPartObjP,mfail));

							t5CheckDstat(objGetAttribute(GGetInfoJTPartObjP,"FullPath",&GJTfullPath)) ;
							if(!nlsIsStrNull(GJTfullPath))
							{
								GJTfullPathDup=nlsStrDup(GJTfullPath);
							}
							else
							{
								GJTfullPathDup=nlsStrDup("-");
							}
							t5CheckDstat(objGetAttribute(GGetInfoJTPartObjP,"HostName",&GJTHostNm)) ;
							if(!nlsIsStrNull(GJTHostNm))
							{
								GJTHostNmDup=nlsStrDup(GJTHostNm);
							}
							else
							{
								GJTHostNmDup=nlsStrDup("-");
							}
							t5CheckDstat(objGetAttribute(GGetInfoJTPartObjP,"SiteName",&GJTSiteNm)) ;
							if(!nlsIsStrNull(GJTSiteNm))
							{
								GJTSiteNmDup=nlsStrDup(GJTSiteNm);
							}
							else
							{
								GJTSiteNmDup=nlsStrDup("-");
							}
							fprintf(fp,"%s,",GJTRelativePathDup);fflush(fp);//Generic JT	//RelativePath		//1
							fprintf(fp,"%s,",GJTWRelativePathDup);fflush(fp);		//WRelativePath		//2
							fprintf(fp,"%s,",GOwnerDirNameJTS);fflush(fp);			//OwnerDirNam		//3
							fprintf(fp,"%s,",GJTOwnerNameS);fflush(fp);			//OwnerName		//4
							fprintf(fp,"%s,",InstClassS);fflush(fp);			//InstClass		//5
							fprintf(fp,"NR;1,");fflush(fp);					//TCRevision		//6
							fprintf(fp,"%s,",asmInstanceS);fflush(fp);			//PartNumber		//7
							fprintf(fp,"%s,",proAsmDisplayNmDupS);fflush(fp);		//proAsmDisplayNm	//8
							fprintf(fp," ,");fflush(fp);					//Alf_Child		//9
							fprintf(fp," ,");fflush(fp);					//Alf_Assy		//10
							fprintf(fp," ,");fflush(fp);					//ApplnOwner		//11
							fprintf(fp,"%s,",GJTfullPathDup);fflush(fp);			//JTfullPath		//12
							fprintf(fp,"%s,",GJTHostNmDup);fflush(fp);			//JTHostNm		//13
							fprintf(fp,"%s,",GJTSiteNmDup);fflush(fp);			//JTSiteNm		//14
							//fprintf(fp,"%s,",DItype);fflush(fp);
							fprintf(fp,"\n");
							fflush(fp);
						}
					}
				}
				printf("\ndoubt 333333333333333333333333"); fflush(stdout);
			}
		}
		else
		{
			printf("\n.3..wrelativepath:[%s] \n",wrelativepath); fflush(stdout);

			fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
			fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
			fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%d,",*level);fflush(fp1);
			fprintf(fp1,"%s,",InstClassS);fflush(fp1);
			fprintf(fp1,"%s,",DItype);fflush(fp1);
			fprintf(fp1,"\n");fflush(fp1);

			if (/*(*level == 0) &&*/ (nlsStrStr(DataItemFullPathDup,".asm.") !=NULL))	//added on 28.10.2016 for ALF JT File download
			{
				if(dstat = ExpandObject2("ProToVis",InstDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&TplJTPartSO,&TplJTPartRelSO,mfail)) goto CLEANUP;
				if(SetFlagforScope(TplJTPartSO)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2("ProToVis",InstDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&TplJTPartSO,&TplJTPartRelSO,mfail)) goto CLEANUP;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				if(setSize(TplJTPartSO)>0)
				{
					if(dstat = ExpandObject5(AppDepndClass,setGet(TplJTPartSO,0),"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&JTAppDependOnSO,mfail)) goto CLEANUP;
					if(SetFlagforScope(JTAppDependOnSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject5(AppDepndClass,setGet(TplJTPartSO,0),"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&JTAppDependOnSO,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}

					jtcnt=setSize(JTAppDependOnSO);

					if(setSize(JTAppDependOnSO)>0)
					{
						printf("\n JT App Depends On Found: [%d]",jtcnt); fflush(stdout);

						for(i=0;i<jtcnt;i++)
						{
							appdepjtPtr =setGet(JTAppDependOnSO,i);

							if(dstat = objGetAttribute(appdepjtPtr,WorkingRelativePathAttr,&workingrelPath)) goto CLEANUP;
							if(!nlsIsStrNull(workingrelPath))
							{
								workingrelPathDup=nlsStrDup(workingrelPath);
								workingrelPathDup0=nlsStrDup(workingrelPath);
							}
							else
							{
								continue;
							}
							//printf("\n 11..workingrelPathDup: %s",workingrelPathDup); fflush(stdout);

							if((nlsStrStr(workingrelPathDup,"_ALF") != NULL) || (nlsStrStr(workingrelPathDup,"_WELD") != NULL))
							{
								printf("\n workingrelPathDup: %s",workingrelPathDup); fflush(stdout);
								//if(nlsStrStr(workingrelPathDup0,"_ALF") !=NULL)
								//{
									Alf_Child = nlsStrAlloc(100);
									Alf_ChildTemp = nlsStrAlloc(100);
									AlfTemp = nlsStrAlloc(50);
									Alf_Assy = nlsStrAlloc(50);

									Alf_ChildTemp = strtok(workingrelPathDup0,".");
									printf("\n\t Alf_ChildTemp: %s",Alf_ChildTemp); fflush(stdout);

									AlfTemp = strtok(Alf_ChildTemp,"_");
									nlsStrCpy(Alf_Child,AlfTemp);
									printf("\n\t AlfTemp: %s",AlfTemp); fflush(stdout);

									while (AlfTemp != NULL)
									{
										AlfTemp = strtok(NULL,"_");

										if((nlsStrStr(AlfTemp,"ALF") != NULL) || (nlsStrStr(AlfTemp,"WELD") != NULL))
										{
											Alf_Assy = strtok(NULL,"_");

											if(!nlsIsStrNull(Alf_Assy))
											{
												printf("\n\t    Alf_Assy: %s",Alf_Assy); fflush(stdout);
											}
											else
											{
												Alf_Assy = nlsStrDup(" ");
											}

											break;
										}
										else
										{
											Alf_Assy = nlsStrDup(" ");
										}

										nlsStrCat(Alf_Child,"_");
										nlsStrCat(Alf_Child,AlfTemp);
									}
									printf("\n\t Alf_Child: %s",Alf_Child); fflush(stdout);


									t5CheckDstat(objGetAttribute(appdepjtPtr,RelativePathAttr,&JTRelativePathS));
									if(JTRelativePathDup!=NULL)
									{
										nlsStrFree(JTRelativePathDup);
										JTRelativePathDup = NULL;
									}
									JTRelativePathDup=nlsStrDup(JTRelativePathS);
									printf("\n JTRelativePathDup is: %s ",JTRelativePathDup);

									t5CheckDstat(objGetAttribute(appdepjtPtr,WorkingRelativePathAttr,&JTWRelativePathS));
									if(JTWRelativePathDup!=NULL)
									{
										nlsStrFree(JTWRelativePathDup);
										JTWRelativePathDup = NULL;
									}
									JTWRelativePathDup=nlsStrDup(JTWRelativePathS);

									objGetAttribute(appdepjtPtr,OwnerDirNameAttr,&OwnerDirNameJTDupS);
									OwnerDirNameJTS=nlsStrDup(OwnerDirNameJTDupS);

									t5CheckDstat(objGetAttribute(appdepjtPtr,OwnerNameAttr,&JTOwnerNameDupS));
									JTOwnerNameS=nlsStrDup(JTOwnerNameDupS);
									t5CheckDstat(GetInfoItem(appdepjtPtr,&GetInfoappdepjtPtr,mfail));
									t5CheckDstat(objGetAttribute(GetInfoappdepjtPtr,"FullPath",&JTfullPath)) ;
									if(!nlsIsStrNull(JTfullPath))
									{
										JTfullPathDup=nlsStrDup(JTfullPath);
									}
									else
									{
										JTfullPathDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoappdepjtPtr,"HostName",&JTHostNm)) ;
									if(!nlsIsStrNull(JTHostNm))
									{
										JTHostNmDup=nlsStrDup(JTHostNm);
									}
									else
									{
										JTHostNmDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoappdepjtPtr,"SiteName",&JTSiteNm)) ;
									if(!nlsIsStrNull(JTSiteNm))
									{
										JTSiteNmDup=nlsStrDup(JTSiteNm);
									}
									else
									{
										JTSiteNmDup=nlsStrDup("-");
									}
									fprintf(fp,"%s,",JTRelativePathDup);fflush(fp);					//RelativePath		//1
									fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);				//WRelativePath		//2
									fprintf(fp,"%s,",OwnerDirNameJTS);fflush(fp);					//OwnerDirNam		//3
									fprintf(fp,"%s,",JTOwnerNameS);fflush(fp);					//OwnerName		//4
									fprintf(fp,"%s,",InstClassS);fflush(fp);					//InstClass		//5
									fprintf(fp,"%s,",TCRevisionDup);fflush(fp);					//TCRevision		//6
									fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);					//PartNumber		//7
									fprintf(fp," ,");fflush(fp);			//DataItemDisplayNmDup		//proAsmDisplayNm	//8
									fprintf(fp,"%s,",Alf_Child);fflush(fp);						//Alf_Child		//9
									fprintf(fp,"%s,",Alf_Assy);fflush(fp);						//Alf_Assy		//10
									fprintf(fp," ,"); fflush(fp);							//ApplnOwner		//11
									fprintf(fp,"%s,",JTfullPathDup); fflush(fp);					//JTfullPath		//12
									fprintf(fp,"%s,",JTHostNmDup);fflush(fp);					//JTHostNm		//13
									fprintf(fp,"%s,",JTSiteNmDup);fflush(fp);					//JTSiteNm		//14
									fprintf(fp,"\n");
									//fprintf(fp,"%s,",DItype);fflush(fp);
									fflush(fp);
								//}

								printf("\n   %s,%s,%s, %s,%s,%s,  %s",PartNumberDupS2,TCRevision,TCSequenceDup,Alf_Child,AlfTemp,Alf_Assy,workingrelPathDup); fflush(stdout);
							}
						}
						printf("\n"); fflush(stdout);
					}
				}
			} //if ((*level == 0) && (nlsStrStr(DataItemFullPathDup,".asm") !=NULL))
		}

		/*printf("\n...JTWRelativePathDup:[%s]-----InstClassS:[%s]  IsProDrw:[%s]\n",JTWRelativePathDup,InstClassS,IsProDrw); fflush(stdout);
		if(nlsStrCmp(IsProDrw,"ProDrw")!=0)	//commented on 30.09.2016
		{
			printf("\n %s,%s,%s,%s,%s,%s,%s,%s\n",JTRelativePathDup,JTWRelativePathDup,OwnerDirNameJTS,JTOwnerNameS,InstClassS,TCRevisionDup,PartNumberDupS2,DataItemDisplayNmDup); fflush(stdout);

			if(nlsStrCmp(InstClassS,"ProPrtI")==0)	//Added on 08.10.2016
			{
				fprintf(fp,"%s,",JTRelativePathDup);fflush(fp);
				fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);
				fprintf(fp,"%s,",OwnerDirNameJTS);fflush(fp);
				fprintf(fp,"%s,",JTOwnerNameS);fflush(fp);
				fprintf(fp,"%s,",InstClassS);fflush(fp);
				fprintf(fp,"%s,",TCRevisionDup);fflush(fp);
				fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);
				fprintf(fp,"%s,",DataItemDisplayNmDup);fflush(fp);
				//fprintf(fp,"%s,",DItype);fflush(fp);
				fprintf(fp,"\n");
				fflush(fp);
			}
		}*/

//		if((TCPartExistFlag == 0) && (nlsStrCmp(IsProDrw,"ProDrw")!=0))		//added on 09.11.2016 for non-TC part JT and Cad data downloading
//		{
//			/*case assy 544229100114
//				PartAndDrwRelPathDup is :Vloc/2871/29/2871_cl_dust_seal_small_0191_NR_1/2871_cl_dust_seal_small_0191.prt.4
//				DataItemDisplayNmDup is :2871_cl_dust_seal_small_0191.prt.4
//				ProjectCodeDupS:2871
//				setSize(DIDocSO) :1
//				PartDocNmDup:2871_cl_dust_seal_small_0191  NR;1
//				Part objects:0
//			*/
//
//			fprintf(fp,"%s,",JTRelativePathDup);fflush(fp);
//			fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);
//			fprintf(fp,"%s,",OwnerDirNameJTS);fflush(fp);
//			fprintf(fp,"%s,",JTOwnerNameS);fflush(fp);
//			fprintf(fp,"%s,",InstClassS);fflush(fp);
//			fprintf(fp,"%s,",TCRevisionDup);fflush(fp);
//			fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);
//			fprintf(fp,"%s,",DataItemDisplayNmDup);fflush(fp);
//			fprintf(fp," ,");fflush(fp);	//Alf_Child
//			fprintf(fp," ,");fflush(fp);	//Alf_Assy
//			//fprintf(fp,"%s,",DItype);fflush(fp);	//DItype
//			fprintf(fp,"\n");
//			fflush(fp);
//
//			fprintf(fp2,"%s,",DataItemFullPathDup);fflush(fp2);
//			fprintf(fp2,"%s,",wrelativepath);fflush(fp2);
//			fprintf(fp2,"NULL,");fflush(fp2);
//			fprintf(fp2,"%s,",DISeqDup);fflush(fp2);
//			fprintf(fp2,"NULL,");fflush(fp2);
//			fprintf(fp2,"%s,",OwnerDirNameS);fflush(fp2);
//			fprintf(fp2,"%s,",OwnerNameS);fflush(fp2);
//			fprintf(fp2,"NULL,");fflush(fp2);
//			fprintf(fp2,"NULL,");fflush(fp2);
//			fprintf(fp2,"%d,",*level);fflush(fp2);
//			fprintf(fp2,"%s,",InstClassS);fflush(fp2);
//			fprintf(fp2,"%s,",DItype);fflush(fp2);
//			fprintf(fp2,"\n");fflush(fp2);
//		}
		/*if(nlsStrCmp(IsProDrw,"ProDrw")!=0)		//modified on 26.11.2016 for non-TC part JT and Cad data downloading
													//commented on 07.12.2016 to stop all jt to copy in file
		{
			printf("\n In if condition of (nlsStrCmp(IsProDrw,"ProDrw")!=0)");fflush(stdout);

			fprintf(fp,"%s,",JTRelativePathDup);fflush(fp);
			fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);
			fprintf(fp,"%s,",OwnerDirNameJTS);fflush(fp);
			fprintf(fp,"%s,",JTOwnerNameS);fflush(fp);
			fprintf(fp,"%s,",InstClassS);fflush(fp);
			fprintf(fp,"%s,",TCRevisionDup);fflush(fp);
			fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);
			fprintf(fp,"%s,",DataItemDisplayNmDup);fflush(fp);
			fprintf(fp," ,");fflush(fp);	//Alf_Child
			fprintf(fp," ,");fflush(fp);	//Alf_Assy
			//fprintf(fp,"%s,",DItype);fflush(fp);	//DItype
			fprintf(fp,"\n");
			fflush(fp);
		}*/

		if(TCPartExistFlag == 0)
		{
			printf("\n In if condition of TCPartExistFlag: %d",TCPartExistFlag);fflush(stdout);

			/*case assy 544229100114
				PartAndDrwRelPathDup is :Vloc/2871/29/2871_cl_dust_seal_small_0191_NR_1/2871_cl_dust_seal_small_0191.prt.4
				DataItemDisplayNmDup is :2871_cl_dust_seal_small_0191.prt.4
				ProjectCodeDupS:2871
				setSize(DIDocSO) :1
				PartDocNmDup:2871_cl_dust_seal_small_0191  NR;1
				Part objects:0
			*/

			if ((nlsStrCmp(InstClassS,"ProPrtI")!=0) && (nlsStrCmp(InstClassS,"ProAsmI")!=0))	// Added on 24.03.2018
			{
				fprintf(fp2,"%s,",DataItemFullPathDup);fflush(fp2);
				fprintf(fp2,"%s,",wrelativepath);fflush(fp2);
				fprintf(fp2,"NULL,");fflush(fp2);
				fprintf(fp2,"%s,",DISeqDup);fflush(fp2);
				fprintf(fp2,"NULL,");fflush(fp2);
				fprintf(fp2,"%s,",OwnerDirNameS);fflush(fp2);
				fprintf(fp2,"%s,",OwnerNameS);fflush(fp2);
				fprintf(fp2,"NULL,");fflush(fp2);
				fprintf(fp2,"NULL,");fflush(fp2);
				fprintf(fp2,"%d,",*level);fflush(fp2);
				fprintf(fp2,"%s,",InstClassS);fflush(fp2);
				fprintf(fp2,"%s,",DItype);fflush(fp2);
				fprintf(fp2,"\n");fflush(fp2);
			}

			//modified on 07.12.2016 for non-TC part JT and Cad data downloading
			fprintf(fp,"%s,",JTRelativePathDup);fflush(fp);
			fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);
			fprintf(fp,"%s,",OwnerDirNameJTS);fflush(fp);
			fprintf(fp,"%s,",JTOwnerNameS);fflush(fp);
			fprintf(fp,"%s,",InstClassS);fflush(fp);
			fprintf(fp,"%s,",TCRevisionDup);fflush(fp);
			fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);
			fprintf(fp,"%s,",DataItemDisplayNmDup);fflush(fp);
			fprintf(fp," ,");fflush(fp);	//Alf_Child
			fprintf(fp," ,");fflush(fp);	//Alf_Assy
			//fprintf(fp,"%s,",DItype);fflush(fp);	//Alf_Assy
			fprintf(fp,"\n");
			fflush(fp);
		}
	}
	else if(setSize(JTPartSO)>1)
	{
		if((nlsStrCmp(InstClassS,"ProPrtI")==0) || (nlsStrCmp(InstClassS,"ProAsmI")==0))
		{
			printf("\nGeneric Name is 2222222---->:%s",wrelativepath);

			if(nlsStrCmp(InstClassS,"ProAsmI")==0)
			{
				t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
				t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",wrelativepath));
				t5CheckMfail(QueryWhere("ProAsm",ProeObjSqlPtr,&ProeDataItemSO,mfail));

				if(setSize(ProeDataItemSO)>0)
				{
					AsmIObjP=setGet(ProeDataItemSO,0);

					t5CheckDstat(GetInfoItem(AsmIObjP,&GetItmInfoDrwObjP,mfail));
					t5CheckDstat(objGetAttribute(GetItmInfoDrwObjP,"FullPath",&GenFullPathDupS));
					GenFullPathS=nlsStrDup(GenFullPathDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"Sequence",&GenSeqDupS));
					GenSeqS=nlsStrDup(GenSeqDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerDirName",&GenOwnDupS));
					GenOwnS=nlsStrDup(GenOwnDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerName",&GenOwnDupS11));
					GenOwnS11=nlsStrDup(GenOwnDupS11);

					fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
					fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
					fprintf(fp1,"%s,",GenFullPathS);fflush(fp1);
					fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
					fprintf(fp1,"%s,",GenSeqS);fflush(fp1);
					fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
					fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS11);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS);fflush(fp1);
					fprintf(fp1,"%d,",*level);fflush(fp1);
					fprintf(fp1,"%s,",InstClassS);fflush(fp1);
					fprintf(fp1,"%s,",DItype);fflush(fp1);
					fprintf(fp1,"\n");fflush(fp1);
				}
			}
			else
			{
				fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
				fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
				fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%d,",*level);fflush(fp1);
				fprintf(fp1,"%s,",InstClassS);fflush(fp1);
				fprintf(fp1,"%s,",DItype);fflush(fp1);
				fprintf(fp1,"\n");fflush(fp1);
			}
		}
		else
		{
			fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
			fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
			fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%d,",*level);fflush(fp1);
			fprintf(fp1,"%s,",InstClassS);fflush(fp1);
			fprintf(fp1,"%s,",DItype);fflush(fp1);
			fprintf(fp1,"\n");fflush(fp1);
		}

		if(nlsStrCmp(IsProDrw,"ProDrw")!=0)
		{
			fprintf(fperr,"%s,",DataItemFullPathDup);fflush(fperr);
			fprintf(fperr,"%s,",JTDataRelPathDup);fflush(fperr);
			fprintf(fperr,"MORETHANONEJT");
			fprintf(fperr,"\n");fflush(fperr);
		}
	}
	else
	{
		/*t5CheckDstat(objGetAttribute(InstDataItemObjP,ClassAttr,&ClassDupS));
		ClassS=nlsStrDup(ClassDupS);*/

		if((nlsStrCmp(InstClassS,"ProPrtI")==0) || (nlsStrCmp(InstClassS,"ProAsmI")==0))
		{
			printf("\n Class is ProPrtI/ProAsmI");

			printf("\n Generic Name is 3333333---->:%s",wrelativepath);

			if(nlsStrCmp(InstClassS,"ProAsmI")==0)
			{
				t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
				t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",wrelativepath));
				t5CheckMfail(QueryWhere("ProAsm",ProeObjSqlPtr,&ProeDataItemSO,mfail));

				if(setSize(ProeDataItemSO)>0)
				{
					AsmIObjP=setGet(ProeDataItemSO,0);

					t5CheckDstat(GetInfoItem(AsmIObjP,&GetItmInfoDrwObjP,mfail));
					t5CheckDstat(objGetAttribute(GetItmInfoDrwObjP,"FullPath",&GenFullPathDupS));
					GenFullPathS=nlsStrDup(GenFullPathDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"Sequence",&GenSeqDupS));
					GenSeqS=nlsStrDup(GenSeqDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerDirName",&GenOwnDupS));
					GenOwnS=nlsStrDup(GenOwnDupS);

					t5CheckDstat(objGetAttribute(AsmIObjP,"OwnerName",&GenOwnDupS11));
					GenOwnS11=nlsStrDup(GenOwnDupS11);

					fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
					fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
					fprintf(fp1,"%s,",GenFullPathS);fflush(fp1);
					fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
					fprintf(fp1,"%s,",GenSeqS);fflush(fp1);
					fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
					fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS11);fflush(fp1);
					fprintf(fp1,"%s,",GenOwnS);fflush(fp1);
					fprintf(fp1,"%d,",*level);fflush(fp1);
					fprintf(fp1,"%s,",InstClassS);fflush(fp1);
					fprintf(fp1,"%s,",DItype);fflush(fp1);
					fprintf(fp1,"\n");fflush(fp1);
				}
			}
			else
			{
				fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
				fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
				fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"NULL,");fflush(fp1);
				fprintf(fp1,"%d,",*level);fflush(fp1);
				fprintf(fp1,"%s,",InstClassS);fflush(fp1);
				fprintf(fp1,"%s,",DItype);fflush(fp1);
				fprintf(fp1,"\n");fflush(fp1);
			}
		}else
		{
			fprintf(fp1,"%s,",DataItemFullPathDup);fflush(fp1);
			fprintf(fp1,"%s,",wrelativepath);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%s,",OwnerDirNameS);fflush(fp1);
			fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"NULL,");fflush(fp1);
			fprintf(fp1,"%d,",*level);fflush(fp1);
			fprintf(fp1,"%s,",InstClassS);fflush(fp1);
			fprintf(fp1,"%s,",DItype);fflush(fp1);
			fprintf(fp1,"\n");fflush(fp1);

		}

		if(nlsStrCmp(IsProDrw,"ProDrw")!=0)
		{
			fprintf(fperr,"%s,",DataItemFullPathDup);fflush(fperr);
			fprintf(fperr,"%s,",InstClassS);fflush(fperr);
			fprintf(fperr,"NOJT");
			fprintf(fperr,"\n");fflush(fperr);
		}
	}

	/*if (t5DrwDocFlag == 1)		//commented on 04.11.2016
	{
		printf("\n-----%s,%s,%s,%s,%s,%s,%s,%s",DIRelPath,DIFileWorkingRelativePath,DIOwnerDirName,DIOwnerName,DiClassS,TCRevisionDup,PartNumberDupS2,DIDisplayNm); fflush(stdout);

		if((!nlsIsStrNull(DIRelPath)) && (!nlsIsStrNull(DIFileWorkingRelativePath)))
		{
			fprintf(fp,"%s,",DIRelPath);fflush(fp);			 		//DataItem RelativePath
			fprintf(fp,"%s,",DIFileWorkingRelativePath);fflush(fp);	//DataItem WorkingRelativePath
			fprintf(fp,"%s,",DIOwnerDirName);fflush(fp);			//DataItem OwnerDirName
			fprintf(fp,"%s,",DIOwnerName);fflush(fp);				//DataItem OwnerName
			fprintf(fp,"%s,",DiClassS);fflush(fp);					//DataItem ClassName
			fprintf(fp,"%s,",TCRevisionDup);fflush(fp);				//TC Part Rev;Seq
			fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);			//TC PartNumber for reference drawing relation check
			fprintf(fp,"%s,",DIDisplayNm);fflush(fp);				//DataItem DisplayNm
			fprintf(fp,"\n");
			fflush(fp);
		}

		printf("\n-----%s,%s,%s,%s,%s,%s,%s,%s\n",VisFileRelPathS,VisFileWorkingRelativePathS,VisFileOwnerDirNameS,VisFileOwnerNameS,VisFileClassS,TCRevisionDup,PartNumberDupS2,DIDisplayNm); fflush(stdout);

		//if ((nlsStrCmp(VisFileOwnerNameS,"Release Vault")==NULL) || (nlsStrStr(VisFileOwnerNameS,"CE Vault")!=NULL) || (nlsStrCmp(VisFileOwnerNameS,"JT Vault")==NULL) )
		//{
		if((!nlsIsStrNull(VisFileRelPathS)) && (!nlsIsStrNull(VisFileWorkingRelativePathS)))
		{
			fprintf(fp,"%s,",VisFileRelPathS);fflush(fp);			 	//PDF RelativePath
			fprintf(fp,"%s,",VisFileWorkingRelativePathS);fflush(fp);	//PDF WorkingRelativePath
			fprintf(fp,"%s,",VisFileOwnerDirNameS);fflush(fp);			//PDF OwnerDirName
			fprintf(fp,"%s,",VisFileOwnerNameS);fflush(fp);				//PDF OwnerName
			fprintf(fp,"%s,",VisFileClassS);fflush(fp);					//PDF ClassName
			fprintf(fp,"%s,",TCRevisionDup);fflush(fp);					//TC Part Rev;Seq
			fprintf(fp,"%s,",PartNumberDupS2);fflush(fp);				//TC PartNumber for reference drawing relation check
			fprintf(fp,"%s,",DIDisplayNm);fflush(fp);					//DataItem DisplayNm
			fprintf(fp,"\n");
			fflush(fp);
		}
		//}
	}*/

CLEANUP:
		//printf("\n Function GetFullPathJTExp CLEANUP..\n");
		t5PrintCleanUpModName;
		if(setSize(ProeInstDepOnSO))t5FreeSetOfObjects(ProeInstDepOnSO);
		if(setSize(ProeInstDepOnRelSO))t5FreeSetOfObjects(ProeInstDepOnRelSO);

EXIT:
		fclose(fpGen);
		//printf("\n Function GetFullPathJTExp EXIT..\n");
		t5CheckDstatAndReturn;
};

//Code for Handling ProPrt ProDrw Only...
/*status GetProePartAndDrwExp(ObjectPtr DataItemObjP,string PartAndDrwRelPathDupS,SetOfStrings OBIDsetS,FILE *fp,FILE *fperr,integer* mfail )
{
string PartAndDrwRelPathDup=NULL;
string DataItemFullPathS=NULL;
string DataItemFullPathDup=NULL;
string JTRelativePathS = NULL ;
string JTRelativePathDup = NULL ;
string JTWRelativePathS = NULL ;
string JTWRelativePathDup = NULL ;
ObjectPtr JTObjP=NULL;
ObjectPtr JTPartObjP=NULL;
ObjectPtr GetItmInfoDataItemObjP=NULL;
SetOfObjects ProeInstDepOnSO = NULL;
SetOfObjects ProeInstDepOnRelSO = NULL;
SetOfObjects JTPartSO = NULL;
SetOfObjects JTPartRelSO = NULL;

t5MethodInit("GetProePartAndDrwExp");
printf("\n inside Function GetProePartAndDrwExp \n");

if(PartAndDrwRelPathDup!=NULL){nlsStrFree(PartAndDrwRelPathDup);PartAndDrwRelPathDup = NULL;}
PartAndDrwRelPathDup=nlsStrDup(PartAndDrwRelPathDupS);
printf("\n PartAndDrwRelPathDup is :%s \n",PartAndDrwRelPathDup);
t5CheckDstat(GetInfoItem(DataItemObjP,&GetItmInfoDataItemObjP,mfail));
t5CheckDstat(objGetAttribute(GetItmInfoDataItemObjP,FullPathAttr,&DataItemFullPathS));
if(DataItemFullPathDup!=NULL){nlsStrFree(DataItemFullPathDup);DataItemFullPathDup = NULL;}
DataItemFullPathDup=nlsStrDup(DataItemFullPathS);
printf("\n%s\n",DataItemFullPathDup);
//fprintf(fp,"%s,",PartAndDrwRelPathDup);fflush(fp);
//fprintf(fp,"%s,",DataItemFullPathDup);fflush(fp);

t5CheckMfail(ExpandObject2(ProToVisClass,DataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&JTPartSO,&JTPartRelSO,mfail));
printf("\n number of jt files attached with JTRelativePathDup is :%s  are :%d\n",PartAndDrwRelPathDup,setSize(JTPartSO));
if (setSize(JTPartSO)==1)
{
	JTPartObjP=setGet(JTPartSO,0);
	t5CheckDstat(objCopy(&JTObjP,JTPartObjP));
	t5CheckDstat(objGetAttribute(JTObjP,RelativePathAttr,&JTRelativePathS));
	if(JTRelativePathDup!=NULL){nlsStrFree(JTRelativePathDup);JTRelativePathDup = NULL;}
	JTRelativePathDup=nlsStrDup(JTRelativePathS);
		printf("\n JTRelativePathDup is :%s \n",JTRelativePathDup);
		t5CheckDstat(objGetAttribute(JTObjP,WorkingRelativePathAttr,&JTWRelativePathS));
		if(JTWRelativePathDup!=NULL){nlsStrFree(JTWRelativePathDup);JTWRelativePathDup = NULL;}
		JTWRelativePathDup=nlsStrDup(JTWRelativePathS);
		printf("\n JTWRelativePathDup is :%s \n",JTWRelativePathDup);
		fprintf(fp,"%s,",DataItemFullPathDup);fflush(fp);
		fprintf(fp,"%s,",JTWRelativePathDup);fflush(fp);
		fprintf(fp,"%s\n",JTRelativePathDup);fflush(fp);

}
else if(setSize(JTPartSO)>1)
{
		fprintf(fp,"%s,",DataItemFullPathDup);fflush(fp);
		fprintf(fp,",\n");fflush(fp);
		//fprintf(fperr,"%s,",PartAndDrwRelPathDup);fflush(fperr);
		fprintf(fperr,"%s,",DataItemFullPathDup);fflush(fperr);
		fprintf(fperr,"MORETHANONEJT,MORETHANONEJT\n");fflush(fperr);
}
else
{
		fprintf(fp,"%s,",DataItemFullPathDup);fflush(fp);
		fprintf(fp,",\n");fflush(fp);
		//fprintf(fperr,"%s,",PartAndDrwRelPathDup);fflush(fperr);
		fprintf(fperr,"%s,",DataItemFullPathDup);fflush(fperr);
		fprintf(fperr,"NOJT,NOJT\n");fflush(fperr);
		printf("\n\n DoProeAssemblyOnlyExp There is no qualified JT i.e PartJT exists in TC ....\n");
}


CLEANUP:
		//printf("\n Function GetProePartAndDrwExp CLEANUP..\n");
		t5PrintCleanUpModName;
		if(setSize(ProeInstDepOnSO))t5FreeSetOfObjects(ProeInstDepOnSO);
		if(setSize(ProeInstDepOnRelSO))t5FreeSetOfObjects(ProeInstDepOnRelSO);

EXIT:
		//printf("\n Function GetProePartAndDrwExp EXIT..\n");
		t5CheckDstatAndReturn;

};*/

//Code for Handling Proe Assembly Instances Only...
status GetProePartInstOnlyExp2(ObjectPtr DataItemObjP,string PartInstRelativePathDupS,SetOfStrings OBIDsetS,FILE *fp,FILE* fp1,FILE *fperr,integer* mfail,string IsProDrw,int* level)
{
//	int ProInst=0,RecChkFlag=0;
	string PartInstRelativePathDup=NULL;
//	string PartInstMemClassNameDupS=NULL;
//	string PartInstMemClassNameDup=NULL;
//	string PartInstMemRPathS=NULL;
//	string PartInstMemWRPathS=NULL;
//	string PartInstMemWRPathDup=NULL;
//	string PartInstMemRPathDup=NULL;
//	string PartInstMemOBIDDupS=NULL;
//	string PartInstMemOBIDDup=NULL;
	string GeninstanceNameS = NULL ;
	string PrtIGenFullPathDup = NULL ;
	string PrtIGenFullPathS = NULL ;
	string GeninstanceNameDup = NULL ;
	string DISeq = NULL ;
	string DISeqDup = NULL ;
	string OwnerNameDupS = NULL ;
	string OwnerNameS = NULL ;

//	ObjectPtr PartInstMemObjP=NULL;
//	int JTExploreTag=0;
	//ObjectPtr JTDataItemObjP=NULL;
	//ObjectPtr GetItmInfoPrtIDataItemObjP=NULL;
	SetOfObjects ProeInstDepOnRelSO = NULL;
	SetOfObjects ProeInstDepOnSO = NULL;
	t5MethodInit("GetProePartInstOnlyExp2");
	//printf("\n inside Function GetProePartInstOnlyExp2 \n");

	printf("\n This is proe part instancle  ..... going for printintg......");
	t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));

	t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&PrtIGenFullPathDup));
	PrtIGenFullPathS=nlsStrDup(PrtIGenFullPathDup);
	t5CheckDstat(objGetAttribute(DataItemObjP,"Sequence",&DISeq));
	DISeqDup = nlsStrDup(DISeq);
	t5CheckDstat(objGetAttribute(DataItemObjP,"OwnerName",&OwnerNameDupS));
	OwnerNameS=nlsStrDup(OwnerNameDupS);

	/*printf("\n Again doubt 11111111111111111111111......\n\n");
	printf("\n ..1..PrtIGenFullPathS:[%s]\n",PrtIGenFullPathS);
	fprintf(fp1,"%s,",PrtIGenFullPathS);fflush(fp1);
	fprintf(fp1,"%s,",PrtIGenFullPathS);fflush(fp1);
	fprintf(fp1,"NULL,");fflush(fp1);
	fprintf(fp1,"%s,",DISeqDup);fflush(fp1);
	fprintf(fp1,"NULL,");fflush(fp1);
	fprintf(fp1,"(null),");fflush(fp1);
	fprintf(fp1,"%s,",OwnerNameS);fflush(fp1);
	fprintf(fp1,"NULL,");fflush(fp1);
	fprintf(fp1,"NULL,");fflush(fp1);
	fprintf(fp1,"%d,",*level);fflush(fp1);
	fprintf(fp1,"ProPrtI");fflush(fp1);
	fprintf(fp1,"\n");fflush(fp1);
	printf("\n Again doubt 2222222222222222222......\n\n");*/

	//11405698147<CROSS_REC_PAN_HEAD_SCREW_IS7483>,cross_rec_pan_head_screw_is7483.prt.1,NULL,3,NULL,(null),Obsolete Vault,NULL,NULL,2,ProPrtI
	//11405698147<CROSS_REC_PAN_HEAD_SCREW_IS7483>,11405698147<CROSS_REC_PAN_HEAD_SCREW_IS7483>,NULL,3,NULL,(null),Obsolete Vault,2,ProPrtI


	if(PartInstRelativePathDup!=NULL){nlsStrFree(PartInstRelativePathDup);PartInstRelativePathDup = NULL;}
	PartInstRelativePathDup=nlsStrDup(PartInstRelativePathDupS);
	//printf("\n PartInstRelativePathDup is :%s \n",PartInstRelativePathDup);

	// taking infoitem for getting generic of proprti
	t5CheckDstat(objGetAttribute(DataItemObjP,"WorkingRelativePath",&GeninstanceNameS));
	if(GeninstanceNameDup!=NULL){nlsStrFree(GeninstanceNameDup);GeninstanceNameDup = NULL;}
	GeninstanceNameDup=nlsStrDup(GeninstanceNameS);
	//printf("\n GeninstanceNameDup is :%s \n",GeninstanceNameDup);
	strtok(GeninstanceNameDup,".");
	//printf("\n After Strtok GeninstanceNameDup is :%s \n",GeninstanceNameDup);

	if(setSize(ProeInstDepOnSO))t5FreeSetOfObjects(ProeInstDepOnSO);
	if(setSize(ProeInstDepOnRelSO))t5FreeSetOfObjects(ProeInstDepOnRelSO);

	printf("\n Again doubt 33333333333333333333333......\n\n");
//t5CheckMfail(ExpandObject2("ProAMem",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail));
////printf("\n Number of Proe GetProePartInstOnlyExp2 Generic Object After Expansion is: %d \n",setSize(ProeInstDepOnSO));
//if(setSize(ProeInstDepOnSO)==0)
//{
//  //printf("\n There is no Qualified Generic Object For GetProePartInstOnlyExp2 this :%s \n",PartInstRelativePathDup);
//}else
//{
//
//
//*level=*level+1;
//
//for(ProInst=0;ProInst<setSize(ProeInstDepOnSO);ProInst++)
//{
//	PartInstMemObjP = low_set_get(ProeInstDepOnSO,ProInst);
//	t5CheckDstat(objGetAttribute(PartInstMemObjP,"Class",&PartInstMemClassNameDupS));
//	if(PartInstMemClassNameDup!=NULL){nlsStrFree(PartInstMemClassNameDup);PartInstMemClassNameDup = NULL;}
//	PartInstMemClassNameDup=nlsStrDup(PartInstMemClassNameDupS);
//	//printf("\n PartInstMemClassNameDup is :%s\n",PartInstMemClassNameDup);
//	t5CheckDstat(objGetAttribute(PartInstMemObjP,"RelativePath",&PartInstMemRPathS));
//	if(PartInstMemRPathDup!=NULL){nlsStrFree(PartInstMemRPathDup);PartInstMemRPathDup = NULL;}
//	PartInstMemRPathDup=nlsStrDup(PartInstMemRPathS);
//	t5CheckDstat(objGetAttribute(PartInstMemObjP,"WorkingRelativePath",&PartInstMemWRPathS));
//	if(PartInstMemWRPathDup!=NULL){nlsStrFree(PartInstMemWRPathDup);PartInstMemWRPathDup = NULL;}
//	PartInstMemWRPathDup=nlsStrDup(PartInstMemWRPathS);
//	printf("\n  ProDependentOn no %d and PartInstMemRPathDup is %s and PartInstMemWRPathDup :%s\n",ProInst,PartInstMemRPathDup,PartInstMemWRPathDup);
//	strtok(PartInstMemWRPathDup,".");
//	printf("\n After Strtok PartInstMemWRPathDup is :%s \n",PartInstMemWRPathDup);
//
//	t5CheckDstat(objGetAttribute(PartInstMemObjP,"OBID",&PartInstMemOBIDDupS));
//	if(PartInstMemOBIDDup!=NULL){nlsStrFree(PartInstMemOBIDDup);PartInstMemOBIDDup = NULL;}
//	PartInstMemOBIDDup=nlsStrDup(PartInstMemOBIDDupS);
//
//	//fprintf(pfile,"\nParent:[%s],Child[%s]",PrtIGenFullPathS,PartInstMemRPathDup);
//
//	if (!nlsStrCmp(PartInstMemClassNameDup,"ProAsmI") || !nlsStrCmp(PartInstMemClassNameDup,"ProAsm"))
//	{
//
//	printf("\n PartInstMemOBIDDup is %s\n",PartInstMemOBIDDup);
//	//printf("\n no of OBID's in set are : %d \n",setSize(OBIDsetS));
//	    RecChkFlag=low_set_find_str(OBIDsetS,PartInstMemOBIDDup);
//		if(RecChkFlag>=0)
//		{
//		  //printf("\n ERROR:: relativepath %s is recursive and its obid is :%s\n",PartInstMemRPathDup,PartInstMemOBIDDup); fflush(stdout);
//		  printf("\n Please Remove Recursion from Structure \n\n\n"); fflush(stdout);
//		 // fprintf(fp,"%s","RECURSION ERROR::");
//		 // fprintf(fp,"%s",PartInstMemRPathDup);
//		 // fprintf(fp,"%s\n"," is recursive.");fflush(fp);
//		  /*fprintf(fperr,"%s","RECURSION ERROR::");fflush(fperr);
//		  fprintf(fperr,"%s",PartInstMemRPathDup);fflush(fperr);
//		  fprintf(fperr,"%s\n"," is recursive.");fflush(fperr);*/
//		  }
//		else if (RecChkFlag==-1)
//		{
//			//printf("\n relativepath %s is not in set.so, we are adding into set \n",PartInstMemRPathDup);
//			low_set_insrt_str (OBIDsetS,0,PartInstMemOBIDDup);
//			//printf("\n no of AssmProeModelsS are : %d \n",setSize(OBIDsetS));
//			if (!nlsStrCmp(PartInstMemClassNameDup,"ProAsm"))
//			{
//				 printf("\n Calling for Function: GetProeAsmExpOnly2...\n");
//
//
//
//				 //t5CheckMfail(GetProeAsmExpOnly2(PartInstMemObjP,PartInstMemRPathDup,PartInstMemClassNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
//			}
//			else
//			{
//				printf("\n Calling for Function: GetProeAsmIExpOnly2...\n");
//				//t5CheckMfail(GetProeAsmIExpOnly2(PartInstMemObjP,PartInstMemRPathDup,PartInstMemClassNameDup,OBIDsetS,fp,fp1,mfail,IsProDrw,level));
//			}
//		}
//		else
//		{
//			//printf("\n error in low_set_find_str \n");
//		}
//	}
//	else if (!nlsStrCmp(PartInstMemClassNameDup,"ProPrtI"))
//	{
//
//	    RecChkFlag=low_set_find_str(OBIDsetS,PartInstMemOBIDDup);
//		if(RecChkFlag>=0)
//		{
//			printf("\n Part Already Present");
//		}else if (RecChkFlag==-1)
//		{
//			low_set_insrt_str(OBIDsetS,0,PartInstMemOBIDDup);
//			//t5CheckMfail(GetProePartInstOnlyExp2(PartInstMemObjP,PartInstMemRPathDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
//		}
//	}
//	else if (!nlsStrCmp(PartInstMemClassNameDup,"ProDrw") || !nlsStrCmp(PartInstMemClassNameDup,"ProPrt"))
//	{
//
//		RecChkFlag=low_set_find_str(OBIDsetS,PartInstMemOBIDDup);
//		if(RecChkFlag>=0)
//		{
//			printf("\n Part Already Present");
//		}else if (RecChkFlag==-1)
//		{
//			low_set_insrt_str(OBIDsetS,0,PartInstMemOBIDDup);
//			if (!nlsStrCmp(GeninstanceNameDup,PartInstMemWRPathDup))
//			{
//			//printf("\n generic name is :%s for part :%s are same \n",PartInstMemWRPathS,PartInstMemWRPathS);
//			//JTDataItemObjP=NULL;
//			//t5CheckDstat(objCopy(&DataItemObjP,JTDataItemObjP));
//			///////t5CheckMfail(GetFullPathJTExp(PartInstMemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
//			}
//			else
//			{
//			//printf("\n generic name is :%s for part :%s are different \n",PartInstMemWRPathS,PartInstMemWRPathS);
//			//JTDataItemObjP=NULL;
//			//t5CheckDstat(objCopy(&PartInstMemObjP,JTDataItemObjP));
//			///////t5CheckMfail(GetFullPathJTExp(PartInstMemObjP,PartInstMemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
//			}
//		}
//	}
//	else
//	{
//		printf("\nexceptional class name ::%s for data :%s \n",PartInstMemClassNameDup,PartInstRelativePathDup);
//	}
//}
//
//*level=*level-1;
//
//}
CLEANUP:
		//printf("\n Function GetProePartInstOnlyExp2 CLEANUP..\n");
		t5PrintCleanUpModName;
		if(setSize(ProeInstDepOnSO))t5FreeSetOfObjects(ProeInstDepOnSO);
		if(setSize(ProeInstDepOnRelSO))t5FreeSetOfObjects(ProeInstDepOnRelSO);

EXIT:
		//printf("\n Function GetProePartInstOnlyExp2 EXIT..\n");
		t5CheckDstatAndReturn;

};

//Code for Handling Proe Assembly Instances Only...
status GetProeAsmIExpOnly2(ObjectPtr DataItemObjP,string ProeAsmIRPathDupS,string DataItemClassNameDupS,SetOfStrings OBIDsetS,FILE *fp,FILE *fp1,FILE *fperr,integer* mfail,string IsProDrw,int* level)
{
	int ProeAsmMember=0,Prodep=0;
//	int RecChkFlag=0,RecChkFlag2=0;
	string ProeAsmIRPathDup=NULL;
	//string DataItemFullPathS=NULL;
	//string DataItemFullPathDup=NULL;
	string DataItemClassNameS=NULL;
	string ProeAsmMemberClassNameDupS=NULL;
	string ProeAsmMemberClassNameDup=NULL;
	string ProeAsmMemRPathS=NULL;
	string ProeAsmMemRPathDup=NULL;
	string ProeAsmMemOBIDDupS=NULL;
	string ProeAsmMemOBIDDup=NULL;
	//string JTRelativePathS = NULL ;
	//string JTRelativePathDup = NULL ;
	//string JTWRelativePathS = NULL ;
	//string JTWRelativePathDup = NULL ;
	string GeninstanceNameS = NULL ;
	string GeninstanceNameDup = NULL ;
	string AsmInstMemWRPathS = NULL ;
	string AsmInstMemWRPathDup = NULL ;
	string AsmIDepCNameS = NULL ;
	string AsmIDepCNameDup = NULL ;
	string AsmIDepRelativePathS = NULL ;
	string AsmIDepRelativePath = NULL ;
	string AssyIFileOBIDS = NULL ;
	string AssyIFileOBIDDup = NULL ;
	ObjectPtr ProeAsmandAsmIObjP=NULL;
	//ObjectPtr GetItmInfoDataItemObjP=NULL;
	ObjectPtr ProAsmMemObjP=NULL;
	//ObjectPtr JTPartObjP=NULL;
	//ObjectPtr JTObjP=NULL;
	//ObjectPtr JTDataItemObjP=NULL;
	ObjectPtr AsmIDepOP=NULL;
	SetOfObjects ProeAsmPhyItemSO = NULL;
	SetOfObjects ProeAsmIPhyItemSO = NULL;
	SetOfObjects ProeAsmIRelObjSO = NULL;
	SetOfObjects ProeAsmRelObjSO = NULL;
	//SetOfObjects JTPartSO = NULL;
	//SetOfObjects JTPartRelSO = NULL;

	t5MethodInit("GetProeAsmIExp");
	t5CheckDstat(objCopy(&ProeAsmandAsmIObjP,DataItemObjP));
	DataItemObjP=NULL;
	DataItemObjP=ProeAsmandAsmIObjP;
	printf("\n inside Function GetProeAsmIExp \n");



	t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));

	if(ProeAsmIRPathDup!=NULL){nlsStrFree(ProeAsmIRPathDup);ProeAsmIRPathDup = NULL;}
	ProeAsmIRPathDup=nlsStrDup(ProeAsmIRPathDupS);
	//printf("\n ProeAsmIRPathDup is :%s \n",ProeAsmIRPathDup);
	if(DataItemClassNameS!=NULL){nlsStrFree(DataItemClassNameS);DataItemClassNameS = NULL;}
	DataItemClassNameS=nlsStrDup(DataItemClassNameDupS);
	//printf("\n DataItemClassNameS is :%s\n",DataItemClassNameS);
		t5CheckDstat(objGetAttribute(DataItemObjP,"WorkingRelativePath",&GeninstanceNameS));
		if(GeninstanceNameDup!=NULL){nlsStrFree(GeninstanceNameDup);GeninstanceNameDup = NULL;}
		GeninstanceNameDup=nlsStrDup(GeninstanceNameS);
		//printf("\n GeninstanceNameDup is :%s \n",GeninstanceNameDup);
		strtok(GeninstanceNameDup,".");
		//printf("\n After Strtok GeninstanceNameDup is :%s \n",GeninstanceNameDup);

	//-------------------getting generic name of proasmi
	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

	t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
	if(SetFlagforScope(ProeAsmPhyItemSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\n doubt 11111 no of ProDependentOn are :%d\n",setSize(ProeAsmPhyItemSO));
	if(setSize(ProeAsmPhyItemSO)>0)
	{
		*level=*level+1;
		for(ProeAsmMember=0;ProeAsmMember<setSize(ProeAsmPhyItemSO);ProeAsmMember++)
		{
			//printf("\n working for ProeAsmMember number :%d\n",ProeAsmMember);
			ProAsmMemObjP = low_set_get(ProeAsmPhyItemSO,ProeAsmMember);
			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"Class",&ProeAsmMemberClassNameDupS));
			if(ProeAsmMemberClassNameDup!=NULL){nlsStrFree(ProeAsmMemberClassNameDup);ProeAsmMemberClassNameDup = NULL;}
			ProeAsmMemberClassNameDup=nlsStrDup(ProeAsmMemberClassNameDupS);
			//printf("\n ProeAsmMemberClassNameDup is :%s\n",ProeAsmMemberClassNameDup);
			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"RelativePath",&ProeAsmMemRPathS));
			if(ProeAsmMemRPathDup!=NULL){nlsStrFree(ProeAsmMemRPathDup);ProeAsmMemRPathDup = NULL;}
			ProeAsmMemRPathDup=nlsStrDup(ProeAsmMemRPathS);
			printf("\n  child assembly is ----> %s\n",ProeAsmMemRPathDup);

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OBID",&ProeAsmMemOBIDDupS));
			if(ProeAsmMemOBIDDup!=NULL){nlsStrFree(ProeAsmMemOBIDDup);ProeAsmMemOBIDDup = NULL;}
			ProeAsmMemOBIDDup=nlsStrDup(ProeAsmMemOBIDDupS);

			if (!nlsStrCmp(ProeAsmMemberClassNameDup,"ProAsmI") || !nlsStrCmp(ProeAsmMemberClassNameDup,"ProAsm"))
			{
				//printf("\n ProeAsmMemOBIDDup is %s\n",ProeAsmMemOBIDDup);
				//printf("\n no of OBID's in set are : %d \n",setSize(OBIDsetS));
				//RecChkFlag=low_set_find_str(OBIDsetS,ProeAsmMemOBIDDup);

				//if(RecChkFlag>=0)
				//{
				  //printf("\n ERROR:: relativepath %s is recursive and its obid is :%s\n",ProeAsmMemRPathDup,ProeAsmMemOBIDDup); fflush(stdout);
				//  printf("\n Please Remove Recursion from Structure \n\n\n");
				 // fprintf(fp,"%s","RECURSION ERROR::");
				 // fprintf(fp,"%s",ProeAsmMemRPathDup);
				 // fprintf(fp,"%s\n"," is recursive.");fflush(fp);
				 /* fprintf(fperr,"%s","RECURSION ERROR::");fflush(fperr);
				  fprintf(fperr,"%s",ProeAsmMemRPathDup);fflush(fperr);
				  fprintf(fperr,"%s\n"," is recursive.");fflush(fperr);*/
				//}
				//else if (RecChkFlag==-1)
				//{
					//printf("\n relativepath %s is not in set.so, we are adding into set \n",ProeAsmMemRPathDup);
				low_set_insrt_str (OBIDsetS,0,ProeAsmMemOBIDDup);
				//printf("\n no of AssmProeModelsS are : %d \n",setSize(OBIDsetS));
				//if (!nlsStrCmp(ProeAsmMemberClassNameDup,"ProAsm") || !nlsStrCmp(ProeAsmMemberClassNameDup,"ProAsmI"))
				if (!nlsStrCmp(ProeAsmMemberClassNameDup,"ProAsm"))
				{
					t5CheckDstat(objGetAttribute(ProAsmMemObjP,"WorkingRelativePath",&AsmInstMemWRPathS));
					if(AsmInstMemWRPathDup!=NULL){nlsStrFree(AsmInstMemWRPathDup);AsmInstMemWRPathDup = NULL;}
					AsmInstMemWRPathDup=nlsStrDup(AsmInstMemWRPathS);
					printf("\n  AsmInstMemWRPathDup is :%s \n",AsmInstMemWRPathDup);
					strtok(AsmInstMemWRPathDup,".");

					printf("\n After Strtok AsmInstMemWRPathDup is :%s and generic is -->%s\n",AsmInstMemWRPathDup,GeninstanceNameDup);

					if(!nlsStrCmp(GeninstanceNameDup,AsmInstMemWRPathDup))
					{
					//printf("\n ASMI if generic name is :%s for part :%s are same \n",AsmInstMemWRPathS,GeninstanceNameS);
					//JTDataItemObjP=NULL;
					//t5CheckDstat(objCopy(&DataItemObjP,JTDataItemObjP));
					t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
					if(setSize(ProeAsmIPhyItemSO))t5FreeSetOfObjects(ProeAsmIPhyItemSO);
					if(setSize(ProeAsmIRelObjSO))t5FreeSetOfObjects(ProeAsmIRelObjSO);

					t5CheckMfail(ExpandObject2("ProAMemR",ProAsmMemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmIPhyItemSO,&ProeAsmIRelObjSO,mfail));
					if(SetFlagforScope(ProeAsmIPhyItemSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						t5CheckMfail(ExpandObject2("ProAMemR",ProAsmMemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmIPhyItemSO,&ProeAsmIRelObjSO,mfail));
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					//printf("\n no of ProDependentOn are :%d\n",setSize(ProeAsmIPhyItemSO));
					if (setSize(ProeAsmIPhyItemSO)>0)
					{
						for (Prodep=0;Prodep<setSize(ProeAsmIPhyItemSO) ;Prodep++ )
						{
							AsmIDepOP=low_set_get(ProeAsmIPhyItemSO,Prodep);
							t5CheckDstat(objGetAttribute(AsmIDepOP,"Class",&AsmIDepCNameS));
							if(AsmIDepCNameDup!=NULL){nlsStrFree(AsmIDepCNameDup);AsmIDepCNameDup = NULL;}
							AsmIDepCNameDup=nlsStrDup(AsmIDepCNameS);
							//printf("\n AsmIDepCNameDup is :%s\n",AsmIDepCNameDup);

							t5CheckDstat(objGetAttribute(AsmIDepOP,"RelativePath",&AsmIDepRelativePathS));
							if(AsmIDepRelativePath!=NULL){nlsStrFree(AsmIDepRelativePath);AsmIDepRelativePath = NULL;}
							AsmIDepRelativePath=nlsStrDup(AsmIDepRelativePathS);
							printf("\n AsmIDepRelativePath is :%s \n",AsmIDepRelativePath);

							t5CheckDstat(objGetAttribute(AsmIDepOP,"OBID",&AssyIFileOBIDS));
							if(AssyIFileOBIDDup!=NULL){nlsStrFree(AssyIFileOBIDDup);AssyIFileOBIDDup = NULL;}
							AssyIFileOBIDDup=nlsStrDup(AssyIFileOBIDS);
							//printf("\n AssyIFileOBIDDup :%s \n",AssyIFileOBIDDup);

							if(!nlsStrCmp(AsmIDepCNameDup,"ProPrtI"))
							{
								//Calling for ProePartInstance Function...
								printf("\n 1..Calling for Function: GetProePartInstOnlyExp2...\n");
								t5CheckMfail(GetProePartInstOnlyExp2(AsmIDepOP,AsmIDepRelativePath,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
							}
							else if(!nlsStrCmp(AsmIDepCNameDup,"ProAsm") || (!nlsStrCmp(AsmIDepCNameDup,"ProAsmI")))
							{
								//RecChkFlag2=low_set_find_str(OBIDsetS,AssyIFileOBIDDup);
									//if (RecChkFlag2>=0)
									//{
									  //printf("\n ERROR:: relativepath %s is recursive and its obid is :%s\n",AsmIDepRelativePath,AssyIFileOBIDDup); fflush(stdout);
									//  printf("\n Please Remove Recursion from Structure \n\n\n"); fflush(stdout);
									 // fprintf(fp,"%s","RECURSION ERROR::");
									 // fprintf(fp,"%s",ProeAsmMemRPathDup);
									 // fprintf(fp,"%s\n"," is recursive.");fflush(fp);
									  /*fprintf(fperr,"%s","RECURSION ERROR::");fflush(fperr);
									  fprintf(fperr,"%s",AsmIDepRelativePath);fflush(fperr);
									  fprintf(fperr,"%s\n"," is recursive.");fflush(fperr);*/
									//}
									//else if (RecChkFlag2==-1)
									//{
										setAddStr(OBIDsetS,AssyIFileOBIDDup);
										if(!nlsStrCmp(AsmIDepCNameDup,"ProAsm"))
										{
											//printf("\n Calling for Function: GetProeAsmExpOnly2...\n");
											t5CheckMfail(GetProeAsmExpOnly2(AsmIDepOP,AsmIDepRelativePath,DataItemClassNameS,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
										}
										else
										{
											//printf("\n Calling for Function: GetProeAsmIExpOnly2...\n");
											t5CheckMfail(GetProeAsmIExpOnly2(AsmIDepOP,AsmIDepRelativePath,DataItemClassNameS,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
										}
									//}
									//else
								//	{
										//printf("\n error in low_set_find_str \n");
									//}

							}
							else if(!nlsStrCmp(AsmIDepCNameDup,"ProDrw") || !nlsStrCmp(AsmIDepCNameDup,"ProPrt"))
							{
								//Calling for ProDrw/ProPrt Function...
								//printf("\n Calling for Function: GetProePartInstOnlyExp2...\n");
								//t5CheckMfail(GetProePartAndDrwExp(DataItemObjP,RelativePathDup,OBIDsetS,fp,fperr,mfail));
								t5CheckMfail(GetFullPathJTExp(AsmIDepOP,AsmIDepOP,IsProDrw,fp,fp1,fperr,mfail,level));

							}
							else
							{
							//printf("\nexceptional class name ::%s \n",DataItemClassNameS);
							}
						}
						}
						else
						{
							//printf("\n no of ProDependentOn are :%d for data :%s \n",setSize(ProeAsmIPhyItemSO),AsmInstMemWRPathS);
						}
					}
					else
					{
						//printf("\n ASMI else generic name is :%s for part :%s are different \n",AsmInstMemWRPathS,GeninstanceNameS);
						//JTDataItemObjP=NULL;
						//t5CheckDstat(objCopy(&ProAsmMemObjP,JTDataItemObjP));
						//t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,fp,fperr,mfail));
						t5CheckMfail(GetProeAsmExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemberClassNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
					}
					//printf("\n Calling for Function: GetProeAsmExpOnly2...\n");
					//t5CheckMfail(GetProeAsmExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemberClassNameDup,OBIDsetS,fp,fperr,mfail));
				}
				else
				{
				//printf("\n Calling for Function: GetProeAsmIExpOnly2...\n");
				t5CheckMfail(GetProeAsmIExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemberClassNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
				}
				//}
				//else
				//{
					//printf("\n error in low_set_find_str \n");
				//}
			}
			else if (!nlsStrCmp(ProeAsmMemberClassNameDup,"ProPrtI"))
			{
				//RecChkFlag=low_set_find_str(OBIDsetS,AssyIFileOBIDDup);
				//if(RecChkFlag>=0)
				//{
					//printf("\n Part Already Present");
				//}else if (RecChkFlag==-1)
				//{
					low_set_insrt_str(OBIDsetS,0,AssyIFileOBIDDup);
					printf("\n 2..Calling for Function: GetProePartInstOnlyExp2...\n");
					t5CheckMfail(GetProePartInstOnlyExp2(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
				//}
			}
			else if (!nlsStrCmp(ProeAsmMemberClassNameDup,"ProDrw") || !nlsStrCmp(ProeAsmMemberClassNameDup,"ProPrt"))
			{
				printf("\n\n got it 11111111111111...\n\n");
				//t5CheckMfail(GetProePartAndDrwExp(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fp,fperr,mfail));
				//RecChkFlag=low_set_find_str(OBIDsetS,AssyIFileOBIDDup);

				//printf("\n\n got it 11111111111111 --->%d...\n\n",RecChkFlag);
				//if(RecChkFlag>=0)
				//{
					//printf("\n Part Already Present");
				//}else //if (RecChkFlag==-1)
				//{
					low_set_insrt_str(OBIDsetS,0,AssyIFileOBIDDup);
					t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
				//}
			}
			else
			{
				//printf("\nexceptional class name ::%s \n",DataItemClassNameS);
			}
		}
		*level=*level-1;
	}
	else
	{
		  //printf("\n There is no Qualified Generic Object For GetProeAsmIExp this :%s \n",ProeAsmIRPathDup);
		goto  CLEANUP;
	}

CLEANUP:
		//printf("\n Function GetProePartInstOnlyExp2 CLEANUP..\n");
		t5PrintCleanUpModName;
		if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
		if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

EXIT:
		//printf("\n Function GetProePartInstOnlyExp2 EXIT..\n");
		t5CheckDstatAndReturn;
};
//Code for Handling Proe Assembly  ...
status GetProeAsmExpOnly2(ObjectPtr DataItemObjP,string ProeAsmRPathDupS,string DataItemClassNameDupS,SetOfStrings OBIDsetS,FILE *fp,FILE *fp1,FILE *fperr,integer* mfail,string IsProDrw,int* level)
{
	int ProeDepend = 0;
	int foundmatch = 0;
	int ProeAsmMember = 0;

	string ProeDependOnNm = NULL;
	string ProeDependOnNmDup = NULL;
	string DataItemClassNameS=NULL;
	string ProeAsmMemCNameDupS=NULL;
	string ProeAsmMemCNameDup=NULL;
	string ProeAsmMemRPathS=NULL;
	string ProeAsmMemRPathDup=NULL;
	string ProeAsmMemOBIDDupS=NULL;
	string ProeAsmMemOBIDDup=NULL;
	string GeninstanceNameS = NULL ;
	string GeninstanceNameDup = NULL ;

	ObjectPtr ProeAsmObjP=NULL;
	ObjectPtr ProDependObjP=NULL;
	ObjectPtr ProAsmMemObjP=NULL;

	SetOfObjects ProeAsmPhyItemSO = NULL;
	SetOfObjects ProeAsmRelObjSO = NULL;
	SetOfObjects ProeAsmDependentOnSO = NULL;
	SetOfObjects ProeAsmDependentOnRelSO = NULL;


	t5MethodInit("GetProeAsmExpOnly2");

	t5CheckDstat(objCopy(&ProeAsmObjP,DataItemObjP));
	DataItemObjP=NULL;
	DataItemObjP=ProeAsmObjP;
	//printf("\n inside Function GetProeAsmExpOnly2 \n");

	t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));

	t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&GeninstanceNameDup));
	GeninstanceNameS=nlsStrDup(GeninstanceNameDup);

	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

	t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
	if(SetFlagforScope(ProeAsmPhyItemSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\n no. of ProAssemblyMembers are :%d",setSize(ProeAsmPhyItemSO));

	t5CheckMfail(ExpandObject2(ProDepndClass,DataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeAsmDependentOnSO,&ProeAsmDependentOnRelSO,mfail));
	if(SetFlagforScope(ProeAsmDependentOnSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2(ProDepndClass,DataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeAsmDependentOnSO,&ProeAsmDependentOnRelSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\t  no. of ProDependentOn are ::%d\n",setSize(ProeAsmDependentOnSO));

	if((setSize(ProeAsmPhyItemSO)>0) && (setSize(ProeAsmDependentOnSO)>0) && ( setSize(ProeAsmDependentOnSO) > setSize(ProeAsmPhyItemSO) ) )
	{
		for(ProeDepend=0; ProeDepend < setSize(ProeAsmDependentOnSO); ProeDepend++)
		{
			foundmatch = 0;

			ProDependObjP = setGet(ProeAsmDependentOnSO , ProeDepend);

			if(dstat = ulyFindObjectInSet(ProDependObjP,ProeAsmPhyItemSO,"DisplayedName",0,&foundmatch)) goto CLEANUP;

			if(dstat = objGetAttribute(ProDependObjP,"DisplayedName",&ProeDependOnNm)) goto CLEANUP;
			if(ProeDependOnNmDup!=NULL) { nlsStrFree(ProeDependOnNmDup); ProeDependOnNmDup = NULL; }
			ProeDependOnNmDup = nlsStrDup(ProeDependOnNm);

			if(foundmatch<0)
			{
				printf("\n %d ...No Match Found::foundmatch: %d	%s ",ProeDepend,foundmatch,ProeDependOnNm);
				printf("...");
			}
		}
	}

	if(setSize(ProeAsmPhyItemSO)==0)
	{
		//printf("\n There is no Qualified Generic Object For GetProeAsmExpOnly2 this :%s \n",ProeAsmRPathDup);
		goto CLEANUP;
	}
	else
	{
		*level=*level+1;

		for(ProeAsmMember=0;ProeAsmMember<setSize(ProeAsmPhyItemSO);ProeAsmMember++)
		{
			//printf("\n working for ProeAsmMember number :%d\n",ProeAsmMember);
			ProAsmMemObjP = low_set_get(ProeAsmPhyItemSO,ProeAsmMember);
			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"Class",&ProeAsmMemCNameDupS));
			if(ProeAsmMemCNameDup!=NULL){nlsStrFree(ProeAsmMemCNameDup);ProeAsmMemCNameDup = NULL;}
			ProeAsmMemCNameDup=nlsStrDup(ProeAsmMemCNameDupS);
			//printf("\n ProeAsmMemCNameDup is :%s\n",ProeAsmMemCNameDup);
			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"RelativePath",&ProeAsmMemRPathS));
			if(ProeAsmMemRPathDup!=NULL){nlsStrFree(ProeAsmMemRPathDup);ProeAsmMemRPathDup = NULL;}
			ProeAsmMemRPathDup=nlsStrDup(ProeAsmMemRPathS);
			printf("\n   ProAssemblyMembers no %d and ProeAsmMemRPathDup is %s",ProeAsmMember,ProeAsmMemRPathDup);

			//fprintf(pfile,"\nParent:[%s],Child[%s]",GeninstanceNameS,ProeAsmMemRPathDup);

			//if (nlsStrCmp(ProeAsmMemRPathDup,"287131603212<287131600404>") != 0)
			//{
			//	printf("....continuing.."); fflush(stdout);
			//	continue;
			//}

			//if (nlsStrCmp(ProeAsmMemRPathDup,"11341505129<HEX_FL_SCREW_TS17130>") != 0))
			//{
			//	printf("....continuing.."); fflush(stdout);
			//	continue;
			//}

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OBID",&ProeAsmMemOBIDDupS));
			if(ProeAsmMemOBIDDup!=NULL){nlsStrFree(ProeAsmMemOBIDDup);ProeAsmMemOBIDDup = NULL;}
			ProeAsmMemOBIDDup=nlsStrDup(ProeAsmMemOBIDDupS);

			if (!nlsStrCmp(ProeAsmMemCNameDup,"ProAsmI") || !nlsStrCmp(ProeAsmMemCNameDup,"ProAsm"))
			{
				printf("\n   ProeAsmMemOBIDDup is %s",ProeAsmMemOBIDDup);

				low_set_insrt_str (OBIDsetS,0,ProeAsmMemOBIDDup);

				if (!nlsStrCmp(ProeAsmMemCNameDup,"ProAsmI"))
				{
					printf("\n   Calling for Function: GetProeAsmIExpOnly2...");
					t5CheckMfail(GetProeAsmIExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
				}
				else
				{
					printf("\n   Calling for Function: GetProeAsmExpOnly2...");
					t5CheckMfail(GetProeAsmExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
				}
				printf("\n  1..%s --Calling for Function: GetFullPathJTExp...",ProeAsmMemCNameDup);
			}
			else if (!nlsStrCmp(ProeAsmMemCNameDup,"ProPrtI"))
			{
				low_set_insrt_str(OBIDsetS,0,ProeAsmMemOBIDDup);
				printf("\n  2..%s --Calling for Function: GetProePartInstOnlyExp2...",ProeAsmMemCNameDup);
				t5CheckMfail(GetProePartInstOnlyExp2(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
			}
			else if (!nlsStrCmp(ProeAsmMemCNameDup,"ProDrw"))
			{
				low_set_insrt_str(OBIDsetS,0,ProeAsmMemOBIDDup);
			}
			else if(!nlsStrCmp(ProeAsmMemCNameDup,"ProPrt"))
			{
				low_set_insrt_str(OBIDsetS,0,ProeAsmMemOBIDDup);
				//t5CheckMfail(GetProePartDrwExpOnly(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fp,fperr,mfail ));
				printf("\n  3..%s --Calling for Function: GetFullPathJTExp...",ProeAsmMemCNameDup);
				t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
			}
			else
			{
				printf("\n   exceptional class name ::%s \n",DataItemClassNameS);
				fprintf(fperr,"Exceptional Class Name:[%s]",ProeAsmMemCNameDup);
			}
		}

		*level=*level-1;
	}

CLEANUP:
	//printf("\n Function GetProePartInstOnlyExp2 CLEANUP..\n");

	t5PrintCleanUpModName;
	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

EXIT:
	//printf("\n Function GetProePartInstOnlyExp2 EXIT..\n");
	t5CheckDstatAndReturn;
};
status GetProeAndUsesPartMultiLevelSuperSetBom(ObjectPtr DataItemObjP,string ProeAsmRPathDupS,string DataItemClassNameDupS,SetOfStrings OBIDsetS,FILE *fpTemp,FILE *fpTemp1,FILE *fperr,integer* mfail,string IsProDrw,int* level, string ParentNo)
{
	int ProeDepend = 0;
	int foundmatch = 0;
	int ProeAsmMember = 0;
	int usesLevel = 0;
	int ChildCount = 0;
	int m = 0;
	int m1 = 0;
	int mn = 0;
	int mo = 0;
	int ProAsmUsesLevel = 0;
	int gn = 0;
	int GrpChildExistFlag = 0;
	//int t = 0;
	int GUsesLevel = 0;
	int GUsesLevel2 = 0;
	int ProAsmPrtLevel = 0;
	int ProePrtExistInUsesFlag = 0;
	int tmpStrlen = 0;
	int ti = 0;
	int charFlag = 0;
	int tc = 0;
	int TCPartPresentFlag = 0;
	//int MultiLevel=99;

	char tempstr[50]={0};
	//char ChildPartLwlStr[100]={0};
	//char *p;

	string ProeDependOnNm = NULL;
	string ProeDependOnNmDup = NULL;
	string DataItemClassNameS=NULL;
	string ProeAsmMemCNameDupS=NULL;
	string ProeAsmMemCNameDup=NULL;
	string ProeAsmMemRPathS=NULL;
	string ProeAsmMemRPathDup=NULL;
	string ProeAsmMemOBIDDupS=NULL;
	string ProeAsmMemOBIDDup=NULL;
	//string FrmRelPathDupS=NULL;
	//string FrmRelPathS=NULL;
	//string FrmOwnerDupS=NULL;
	//string FrmOwnerS=NULL;
	//string OwnerDirNameDupS=NULL;
	//string OwnerDirNameS=NULL;
	string GeninstanceNameS = NULL ;
	string GeninstanceNameS2 = NULL ;
	string GeninstanceNameS3 = NULL ;
	string GeninstanceNameDup = NULL ;
	string DataItemDisNm = NULL ;
	string DataItemDisNmDup = NULL ;
	string DataItemDisNmDup1 = NULL ;
	string DSClass = NULL ;
	string DSClassDup = NULL ;
	string AssyPart = NULL;
	string AssyPartDup = NULL;
	string AssyRev = NULL;
	string AssyRevDup = NULL;
	string AssySeq = NULL;
	string AssySeqDup = NULL;
	string AssyDesc = NULL;
	string AssyDescDup = NULL;
	string AssyPartType = NULL;
	string AssyPartTypeDup = NULL;
	//string AssyUQ = NULL;
	//string AssyUQDup = NULL;
	string BOMConfigContextS = NULL ;
	string ChildPartNumberS = NULL ;
	string ChildPartNumberSOrg = NULL ;
	string ChildPartNumberSConv = NULL ;
	string ChildPartNumberSConvTmp = NULL ;
	string ChildPartNumberDupS = NULL ;
	string ChildPartRev = NULL ;
	string ChildPartRevDup = NULL ;
	string ChildPartSeq = NULL ;
	string ChildPartSeqDup = NULL ;
	string ChildDesc = NULL ;
	string ChildDescDup = NULL ;
	string ChildPartType = NULL ;
	string ChildPartTypeDup = NULL ;
	string ChildQuantity = NULL ;
	string ChildQuantityDup = NULL ;
	string ChildUQ = NULL ;
	string ChildUQDup = NULL ;
	string SuppressedValStr = NULL ;
	string ProeAsmMemDisNm = NULL ;
	string ProeAsmMemDisNmDup = NULL ;
	string ProeAsmMemDisNmDup0 = NULL ;
	string ProeAsmMemDisNmDup1 = NULL ;
	string ProeAsmMemDisNmConvTmp = NULL ;
	string ProAsmPrtTemp = NULL ;
	string tmpStr = NULL;
	string tmpStr2 = NULL;
	string tmpStr3 = NULL;
	string ProAsmRelpath = NULL;
	string ProAsmSeq = NULL;
	string ProAsmOwnNm = NULL;
	string ProAsmOwnDirNm = NULL;
	string ProAsmChildPrt = NULL;
	string ProAsmChildPrtStr = NULL;
	string ProAsmChildPrtTmp = NULL;
	string GrpChild = NULL;
	string GrpChildDup = NULL;
	string GrpChildDupConv = NULL;
	string GrpChildDupConvTmp = NULL;
	string GrpChildRev = NULL;
	string GrpChildRevDup = NULL;
	string GrpChildSeq = NULL;
	string GrpChildSeqDup = NULL;
	string GrpChildDesc = NULL;
	string GrpChildDescDup = NULL;
	string GrpChildQuantity = NULL;
	string GrpChildQuantityDup = NULL;
	string GrpChildUQ = NULL;
	string GrpChildUQDup = NULL;
	string PAsmRelativePath = NULL;
	string PAsmRelativePathDup = NULL;
	string PAsmSeq = NULL;
	string PAsmSeqDup = NULL;
	string PAsmOwnNm = NULL;
	string PAsmOwnNmDup = NULL;
	string PAsmOwnDirNm = NULL;
	string PAsmOwnDirNmDup = NULL;
	string GrpChProeAsmClass = NULL;
	string GrpChProeAsmClassDup = NULL;
	string GrpChProAsmOBID = NULL;
	string GrpChProAsmOBIDDup = NULL;
	string ProPart = NULL;
	string ProPartDup = NULL;
	string ProPartRev = NULL;
	string ProPartRevDup = NULL;
	string ProPartSeq = NULL;
	string ProPartSeqDup = NULL;
	string ProPartDesc = NULL;
	string ProPartDescDup = NULL;
	//string ProPartUQ = NULL;
	//string ProPartUQDup = NULL;
	string InstancePrtRevSeq = NULL;
	string ProAsmPart = NULL;
	string DesDocOwnerNmDup = NULL;
	string DesDocOwnerNm = NULL;

	ObjectPtr ProeAsmObjP=NULL;
	ObjectPtr UsesDataItemObjP=NULL;
	ObjectPtr ProDependObjP=NULL;
	ObjectPtr ProAsmMemObjP=NULL;
	ObjectPtr GenContextObjP = NULL;
	ObjectPtr ContextObjP = NULL;
	ObjectPtr DocObjP = NULL;
	ObjectPtr TCObjP = NULL;
	ObjectPtr ChildPartObjP = NULL;
	ObjectPtr ChildRelObjP = NULL;
	ObjectPtr GrpitemObj = NULL;
	ObjectPtr GrpitemRelObj = NULL;
	ObjectPtr ProeDIPtr = NULL;
	ObjectPtr ChildMasterObjOP = NULL;
	ObjectPtr GrpChildMasterObjOP = NULL;
	ObjectPtr ProDocObjP = NULL;
	ObjectPtr ProTCObjP = NULL;
	//ObjectPtr ProPartMasterObjOP = NULL;
	ObjectPtr InstancePartObjP = NULL;

	SqlPtr ProeObjSqlPtr = NULL ;

	SetOfObjects ProeAsmPhyItemSO = NULL;
	SetOfObjects ProeAsmRelObjSO = NULL;
	SetOfObjects ProeAsmDependentOnSO = NULL;
	SetOfObjects ProeAsmDependentOnRelSO = NULL;
	SetOfObjects DIDocSO = NULL;
	SetOfObjects DIDocRelSO = NULL;
	SetOfObjects DocPartSO = NULL;
	SetOfObjects DocPartRelSO = NULL;
	SetOfObjects ChildPartsSO = NULL;
	SetOfObjects ChildRelPartsSO = NULL;
	SetOfObjects GrpitemObjs = NULL;
	SetOfObjects GrprelObjs = NULL;
	SetOfObjects ProeDISO = NULL;
	//SetOfObjects UsChildsSO = NULL;
	//SetOfObjects UsChildsRelSO = NULL;
	SetOfObjects ProDIDocSO = NULL;
	SetOfObjects ProDIDocRelSO = NULL;
	SetOfObjects ProDocPartSO = NULL;
	SetOfObjects ProDocPartRelSO = NULL;
	SetOfObjects ChildMasterSO = NULL;
	SetOfObjects ChildRelSO = NULL;
	SetOfObjects GrpChildMasterSO = NULL;
	SetOfObjects GrpChildRelSO = NULL;
	//SetOfObjects ProPartMasterSO = NULL;
	//SetOfObjects ProPartRelSO = NULL;

	SetOfStrings ProAssyMemSOS = NULL;
	SetOfStrings ProAssyMemDisSOS = NULL;
	SetOfStrings UsesPartsSOS = NULL;
	SetOfStrings SortedUsesPartQtySOS = NULL;
	//SetOfStrings type= NULL;

	BOMConfigContextS = nlsStrAlloc(100);
	SuppressedValStr = nlsStrAlloc(10);
	tmpStr = nlsStrAlloc(100);
	ProAsmChildPrt = nlsStrAlloc(100);
	ProAsmChildPrtStr = nlsStrAlloc(100);
	ProeAsmMemDisNmDup0 = nlsStrAlloc(200);
	ChildPartNumberSConvTmp = nlsStrAlloc(100);
	GrpChildDupConvTmp = nlsStrAlloc(50);

	t5MethodInit("GetProeAndUsesPartMultiLevelSuperSetBom");

	ProAssyMemSOS = NULL;
	ProAssyMemSOS = setStrCreate(1);

	ProAssyMemDisSOS = NULL;
	ProAssyMemDisSOS = setStrCreate(1);

	SortedUsesPartQtySOS = NULL;
	SortedUsesPartQtySOS = setStrCreate(1);

	t5CheckDstat(objCopy(&ProeAsmObjP,DataItemObjP));
	DataItemObjP=NULL;
	DataItemObjP=ProeAsmObjP;

	//t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,IsProDrw,fpTemp,fpTemp,fperr,mfail,level));

	t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&GeninstanceNameDup));
	GeninstanceNameS=nlsStrDup(GeninstanceNameDup);
	GeninstanceNameS2=nlsStrDup(GeninstanceNameDup);
	GeninstanceNameS3=nlsStrDup(GeninstanceNameDup);

	t5CheckDstat(objGetAttribute(DataItemObjP,"DisplayedName",&DataItemDisNm));
	if(DataItemDisNmDup != NULL)
	{
		nlsStrFree(DataItemDisNmDup); DataItemDisNmDup = NULL;
	}
	DataItemDisNmDup = nlsStrDup(DataItemDisNm);
	DataItemDisNmDup1 = nlsStrDup(DataItemDisNm);

	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

	t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
	if(SetFlagforScope(ProeAsmPhyItemSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\n 1..no. of ProAssemblyMembers are :%d",setSize(ProeAsmPhyItemSO));

	t5CheckMfail(ExpandObject2(ProDepndClass,DataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeAsmDependentOnSO,&ProeAsmDependentOnRelSO,mfail));
	if(SetFlagforScope(ProeAsmDependentOnSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2(ProDepndClass,DataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeAsmDependentOnSO,&ProeAsmDependentOnRelSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\t  1..no. of ProDependentOn are ::%d\n",setSize(ProeAsmDependentOnSO));

	if((setSize(ProeAsmPhyItemSO)>0) && (setSize(ProeAsmDependentOnSO)>0) && ( setSize(ProeAsmDependentOnSO) > setSize(ProeAsmPhyItemSO) ) )
	{
		for(ProeDepend=0; ProeDepend < setSize(ProeAsmDependentOnSO); ProeDepend++)
		{
			foundmatch = 0;

			ProDependObjP = setGet(ProeAsmDependentOnSO , ProeDepend);

			if(dstat = ulyFindObjectInSet(ProDependObjP,ProeAsmPhyItemSO,"DisplayedName",0,&foundmatch)) goto CLEANUP;

			if(dstat = objGetAttribute(ProDependObjP,"DisplayedName",&ProeDependOnNm)) goto CLEANUP;
			if(ProeDependOnNmDup!=NULL) { nlsStrFree(ProeDependOnNmDup); ProeDependOnNmDup = NULL; }
			ProeDependOnNmDup = nlsStrDup(ProeDependOnNm);

			if(foundmatch<0)
			{
				printf("\n %d ...No Match Found::foundmatch: %d	%s ",ProeDepend,foundmatch,ProeDependOnNm);
				printf("...");
			}
		}
	}

	printf("\n DataItemObjP--setSize(ProeAsmPhyItemSO): %d",setSize(ProeAsmPhyItemSO));

	for(ProeAsmMember=0;ProeAsmMember<setSize(ProeAsmPhyItemSO);ProeAsmMember++)
	{
		ProAsmMemObjP = low_set_get(ProeAsmPhyItemSO,ProeAsmMember);

		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"DisplayedName",&ProeAsmMemDisNm));
		if(ProeAsmMemDisNmDup != NULL)
		{
			nlsStrFree(ProeAsmMemDisNmDup); ProeAsmMemDisNmDup = NULL;
		}
		ProeAsmMemDisNmDup = nlsStrDup(ProeAsmMemDisNm);

		strcpy(tempstr,"");
		if (nlsStrStr(ProeAsmMemDisNmDup,"<") !=NULL)
		{
			//low_set_insrt_str(ProAssyMemSOS,0,strtok(ProeAsmMemDisNmDup,"<"));
			strcpy(tempstr,strtok(ProeAsmMemDisNmDup,"<"));
		}
		else if (nlsStrStr(ProeAsmMemDisNmDup,".") !=NULL)
		{
			//low_set_insrt_str(ProAssyMemSOS,0,strtok(ProeAsmMemDisNmDup,"."));
			strcpy(tempstr,strtok(ProeAsmMemDisNmDup,"."));
		}
		else
		{
			//low_set_insrt_str(ProAssyMemSOS,0,ProeAsmMemDisNmDup);
			strcpy(tempstr,ProeAsmMemDisNmDup);
		}

		// Added on 08.02.2019
		tmpStrlen = strlen(tempstr);
		//printf ("\n tmpStrlen  %d",tmpStrlen);
		charFlag = 0;
		for(ti=0;ti<tmpStrlen;ti++)
		{
			if (!isdigit(tempstr[ti]))
			{
				charFlag = 1;
				printf ("\n A...charFlag %d found \n",charFlag); fflush(stdout);
				break;
			}
		}
		if (charFlag == 1)	// Added on 08.02.2019
		{
			if(ProeAsmMemDisNmConvTmp != NULL)
			{
				nlsStrFree(ProeAsmMemDisNmConvTmp); ProeAsmMemDisNmConvTmp = NULL;
			}
			ProeAsmMemDisNmConvTmp = ConvertToLowerCase(ProeAsmMemDisNmDup);
			ProeAsmMemDisNmDup = nlsStrAlloc(50);
			nlsStrCpy(ProeAsmMemDisNmDup,"");
			nlsStrCat(ProeAsmMemDisNmDup,subString(ProeAsmMemDisNmConvTmp,0,nlsStrLen(ProeAsmMemDisNm)));
		}
		//else
		//{
		//	ProeAsmMemDisNmDup=nlsStrDup("");
		//	ProeAsmMemDisNmDup=nlsStrDup(ProeAsmMemDisNm);
		//}

		low_set_insrt_str(ProAssyMemSOS,0,ProeAsmMemDisNmDup);


		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"RelativePath",&PAsmRelativePath));
		if(PAsmRelativePathDup != NULL)
		{	nlsStrFree(PAsmRelativePathDup);PAsmRelativePathDup = NULL;	}
		if(!nlsIsStrNull(PAsmRelativePath))
		{
			PAsmRelativePathDup = nlsStrDup(PAsmRelativePath);
		}
		else
		{
			PAsmRelativePathDup = nlsStrDup("");
		}

		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"Sequence",&PAsmSeq));
		if(PAsmSeqDup != NULL)
		{	nlsStrFree(PAsmSeqDup);PAsmSeqDup = NULL;	}
		if(!nlsIsStrNull(PAsmSeq))
		{
			PAsmSeqDup = nlsStrDup(PAsmSeq);
		}
		else
		{
			PAsmSeqDup = nlsStrDup("");
		}

		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OwnerName",&PAsmOwnNm));
		if(PAsmOwnNmDup != NULL)
		{	nlsStrFree(PAsmOwnNmDup);PAsmOwnNmDup = NULL;	}

		if(!nlsIsStrNull(PAsmOwnNm))
		{
			PAsmOwnNmDup = nlsStrDup(PAsmOwnNm);
		}
		else
		{
			PAsmOwnNmDup = nlsStrDup("");
		}
		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OwnerDirName",&PAsmOwnDirNm));
		if(PAsmOwnDirNmDup != NULL)
		{
			nlsStrFree(PAsmOwnDirNmDup);PAsmOwnDirNmDup = NULL;
		}
		if(!nlsIsStrNull(PAsmOwnDirNm))
		{
			PAsmOwnDirNmDup = nlsStrDup(PAsmOwnDirNm);
		}
		else
		{
			PAsmOwnDirNmDup = nlsStrDup("-");
		}

		nlsStrCpy(ProeAsmMemDisNmDup0,"");

		nlsStrCpy(ProeAsmMemDisNmDup0,ProeAsmMemDisNmDup);
		nlsStrCat(ProeAsmMemDisNmDup0,",");
		nlsStrCat(ProeAsmMemDisNmDup0,PAsmRelativePathDup);
		nlsStrCat(ProeAsmMemDisNmDup0,",");
		nlsStrCat(ProeAsmMemDisNmDup0,PAsmSeqDup);
		nlsStrCat(ProeAsmMemDisNmDup0,",");
		nlsStrCat(ProeAsmMemDisNmDup0,PAsmOwnNmDup);
		nlsStrCat(ProeAsmMemDisNmDup0,",");
		nlsStrCat(ProeAsmMemDisNmDup0,PAsmOwnDirNmDup);

		low_set_insrt_str(ProAssyMemDisSOS,0,ProeAsmMemDisNmDup0);	//ProAssyMemDisSOS
	}

	printf("\n\nSetofString setSize(ProAssyMemSOS) :%d",setSize(ProAssyMemSOS)); fflush(stdout);
	for (m = 0; m < setSize(ProAssyMemSOS); m++)
	{
		tmpStr = low_set_get_str(ProAssyMemSOS , m);
		printf("\n\t%d -> %s",m,tmpStr); fflush(stdout);
	}

	/*printf("\n\n SetofString setSize(ProAssyMemDisSOS) :%d",setSize(ProAssyMemDisSOS)); fflush(stdout);
	for (m1 = 0; m1 < setSize(ProAssyMemDisSOS); m1++)
	{
		tmpStr = low_set_get_str(ProAssyMemDisSOS , m1);
		printf("\n\t %d -> %s",m1,tmpStr); fflush(stdout);
	}
	printf("\n\n"); fflush(stdout);*/

	t5CheckMfail(ExpandObject2(AttachClass,DataItemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
	if(SetFlagforScope(DIDocSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2(AttachClass,DataItemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	printf("\n\n [%s] -- DIDocSO: %d \n",DataItemDisNmDup,setSize(DIDocSO));fflush(stdout);
	////sort by creation date function for DIDocSO and processing for latest part rev is added on 24.07.2015
	t5CheckMfail(t5SortBOMObjsByDate(&DIDocSO,&DIDocRelSO,mfail));

	TCPartPresentFlag = 0;

	if(setSize(DIDocSO)>0)
	{
		//DocObjP = setGet(DIDocSO,0);
		if(setSize(DocPartSO) == 1)
		{
			DocObjP = setGet(DIDocSO,0);
		}
		else
		{
			for (tc=0; tc < setSize(DIDocSO); tc++ )
			{
				t5CheckDstat(objGetAttribute( setGet( DIDocSO , tc) ,OwnerNameAttr,&DesDocOwnerNm));
				DesDocOwnerNmDup=nlsStrDup(DesDocOwnerNm);

				//printf("\tOwnerName: %s",DesDocOwnerNmDup); fflush(stdout);
				if(nlsStrStr(DesDocOwnerNmDup,"Vault") == NULL)
				{
					//printf("\t ...this rev-seq not in vault hence skipping from download...\n");  fflush(stdout);
					continue;
				}
				else
				{
					DocObjP = setGet(DIDocSO,tc);
					break;
				}
			}
		}

		t5CheckDstat(objGetAttribute(DocObjP,"Class",&DSClass));
		if(!nlsIsStrNull(DSClass))
		{
			DSClassDup=nlsStrDup(DSClass);
		}
		printf("\t DSClassDup:%s",DSClassDup); fflush(stdout);

		t5CheckMfail(ExpandObject2(PartDocClass,DocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
		if(SetFlagforScope(DocPartSO)==1)
		{
			if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
			t5CheckMfail(ExpandObject2(PartDocClass,DocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
			if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
		}

		t5CheckMfail(t5SortBOMObjsByDate(&DocPartSO,&DocPartRelSO,mfail));
		printf("\t TCPart-objects: %d",setSize(DocPartSO));fflush(stdout);

		if(setSize(DocPartSO)>0)
		{
			TCPartPresentFlag = 1;

			UsesPartsSOS = NULL;
			UsesPartsSOS = setStrCreate(1);

			TCObjP = setGet(DocPartSO,0);

			if (dstat = objGetAttribute( TCObjP ,PartNumberAttr,&AssyPart)) goto CLEANUP;
			AssyPartDup=nlsStrDup(AssyPart);

			if (dstat = objGetAttribute( TCObjP ,RevisionAttr,&AssyRev)) goto CLEANUP;
			AssyRevDup=nlsStrDup(AssyRev);

			if (dstat = objGetAttribute( TCObjP ,SequenceAttr,&AssySeq)) goto CLEANUP;
			AssySeqDup=nlsStrDup(AssySeq);

			if (dstat = objGetAttribute( TCObjP ,NomenclatureAttr,&AssyDesc)) goto CLEANUP;
			AssyDescDup=nlsStrDup(AssyDesc);
			AssyDescDup=low_strssra(AssyDescDup,"\n"," ");
			AssyDescDup=low_strssra(AssyDescDup,"^"," ");

			if (dstat = objGetAttribute( TCObjP ,PartTypeAttr,&AssyPartType)) goto CLEANUP;
			AssyPartTypeDup=nlsStrDup(AssyPartType);

			//if (dstat = ExpandObject2("ItemRev",TCObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&AssyMasterSO,&AssyRelSO,mfail)) goto EXIT;
			//if (setSize(AssyMasterSO)>0)
			//{
			//	AssyMasterObjOP = setGet(AssyMasterSO,0);

			//	t5CheckDstat(objGetAttribute(AssyMasterObjOP,DefaultUnitOfMeasureAttr,&AssyUQ));
			//	if(!nlsIsStrNull(AssyUQ))
			//	{
			//		AssyUQDup=nlsStrDup(AssyUQ);
			//	}
			//	else
			//	{
			//		AssyUQDup=nlsStrDup("4");
			//	}
			//}

			nlsStrCpy(SuppressedValStr,"FALSE");

			//for (t=0; t < *level; t++)
			//{
			//	fprintf(fpSuperSet,"\t");fflush(stdout);
			//}
			if (nlsStrCmp(AssyPartTypeDup,"D")==0)
			{
				//Dummy has 0 Qty
				fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R0\n",*level,AssyPartDup,AssyRevDup,AssySeqDup,AssyDescDup,AssyPartDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
			}
			else
			{
				fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R0\n",*level,AssyPartDup,AssyRevDup,AssySeqDup,AssyDescDup,AssyPartDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
			}

			t5CheckMfail(GetGenTCPartProEInfo(DataItemObjP,TCObjP, AssyPartDup, AssyRevDup, AssySeqDup, InstancePrtRevSeq, mfail, level));

			/*if (nlsStrStr(GeninstanceNameS2,".") !=NULL)
			{
				fprintf(fpSuperSet,"%d,%s,FALSE,1(qty),R0\n",*level,strtok(GeninstanceNameS2,".")); fflush(fpSuperSet);
			}
			else if (nlsStrStr(GeninstanceNameS2,"<") !=NULL)
			{
				fprintf(fpSuperSet,"%d,%s,FALSE,1(qty),R0\n",*level,strtok(GeninstanceNameS2,"<")); fflush(fpSuperSet);
			}*/


			nlsStrCpy(BOMConfigContextS,"Latest From WIP And Release Vaults");

			// setting of session context preferences
			t5CheckMfail(SetUpContext(objClass(TCObjP),TCObjP,&GenContextObjP,mfail));

			// Get the configuration context object from the general context.
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,GenContextObjP,&ContextObjP,mfail));

			// Set the option as "Latest Revision with State" in the context object
			t5CheckDstat(objSetAttribute(ContextObjP,ExpandOnRevisionAttr, "PscLastRev"));
			t5CheckDstat(objSetAttribute(ContextObjP,"NavigateViewBitPos","0"));
			t5CheckDstat(objSetAttribute(ContextObjP,"CfgItemId","GlobalCtxt"));
			t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNetworkAttr,"EAS"));
			t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNameAttr,"ERC"));
			t5CheckDstat(objSetAttribute(ContextObjP,PsmExpIncludeZeroQtyAttr,"+"));
			//t5CheckDstat(objSetAttribute(ContextObjP,t5ExpIncludeOtherUserItemsAttr,"-"));

			//Setting the BOMConfigContextS Configuration Context Based on the User Selection...
			if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP And Release Vaults"))
			{
				printf("\n Entering inside as Latest From WIP And Release Vaults...\n");
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsWorking","-"));
			}
			if(!nlsStrCmp(BOMConfigContextS,"Latest From Release Vault Only"))
			{
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));
			}
			if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP Vault Only"))
			{
				printf("\n Entering inside as Latest From WIP Vaults Only...");
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
				//t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsWorking","-"));
			}

			t5CheckDstat(objSetObject(GenContextObjP,ConfigCtxtBlobAttr, ContextObjP));
			printf("\n 1.Ending in to Configuration Context Settings in ContextBOMViewTCPartMultiExplosion..\n"); fflush(stdout);

			//objDump(TCObjP);
			//printf("\n\n"); fflush(stdout);
			//objDump(GenContextObjP);

			if (dstat = ExpandRelationWithCtxt("AsRevRev",TCObjP,"PartsInAssembly",GenContextObjP,SC_SCOPE_OF_SESSION,NULL,&ChildPartsSO,&ChildRelPartsSO,mfail)) goto CLEANUP;
			if(SetFlagforScope(ChildPartsSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if (dstat = ExpandRelationWithCtxt("AsRevRev",TCObjP,"PartsInAssembly",GenContextObjP,SC_SCOPE_OF_SESSION,NULL,&ChildPartsSO,&ChildRelPartsSO,mfail)) goto CLEANUP;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			printf("\t TCPart-setSize(ChildPartsSO): %d   ParentAssembly: [%s]",setSize(ChildPartsSO),AssyPartDup); fflush(stdout);

			ParentNo = nlsStrAlloc(30);
			nlsStrCpy(ParentNo,"");
			nlsStrCpy(ParentNo,AssyPartDup);
			////sort by creation date function for ChildPartsSO and processing for latest part rev is added on 09.04.2018
			//t5CheckMfail(t5SortBOMObjsAndRemoveDuplicates(&ChildPartsSO,&ChildRelPartsSO,&SortedUsesPartQtySOS,AssyPartDup,mfail));
			//printf("\t ---Sorted-setSize(ChildPartsSO): %d    setSize(SortedUsesPartQtySOS): %d ",setSize(ChildPartsSO),setSize(SortedUsesPartQtySOS)); fflush(stdout);

			if(setSize(ChildPartsSO)>0)
			{
				usesLevel = *level;

				GUsesLevel2 = *level + 1;

				for(ChildCount=0; ChildCount<setSize(ChildPartsSO); ChildCount++)
				{
					ParentNo = nlsStrAlloc(30);
					nlsStrCpy(ParentNo,"");
					nlsStrCpy(ParentNo,AssyPartDup);
					ChildPartObjP = setGet(ChildPartsSO,ChildCount);
					ChildRelObjP = setGet(ChildRelPartsSO,ChildCount);

					t5CheckDstat(objGetAttribute(ChildPartObjP,PartNumberAttr,&ChildPartNumberDupS));
					ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
					ChildPartNumberSOrg=nlsStrDup(ChildPartNumberDupS);

					t5CheckDstat(objGetAttribute(ChildPartObjP,RevisionAttr,&ChildPartRev));
					ChildPartRevDup=nlsStrDup(ChildPartRev);

					t5CheckDstat(objGetAttribute(ChildPartObjP,SequenceAttr,&ChildPartSeq));
					ChildPartSeqDup=nlsStrDup(ChildPartSeq);

					if (dstat = objGetAttribute( ChildPartObjP ,NomenclatureAttr,&ChildDesc)) goto CLEANUP;
					ChildDescDup=nlsStrDup(ChildDesc);
					ChildDescDup=low_strssra(ChildDescDup,"\n"," ");
					ChildDescDup=low_strssra(ChildDescDup,"^"," ");

					if (dstat = objGetAttribute( ChildPartObjP ,PartTypeAttr,&ChildPartType)) goto CLEANUP;
					ChildPartTypeDup=nlsStrDup(ChildPartType);

					if (dstat = objGetAttribute(ChildRelObjP,QuantityAttr,&ChildQuantity)) goto CLEANUP;
					if(!nlsIsStrNull(ChildQuantity))
					{
						ChildQuantityDup=nlsStrDup(ChildQuantity);
					}
					else
					{
						ChildQuantityDup=nlsStrDup("1");
					}

					if (dstat = ExpandObject2("ItemRev",ChildPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&ChildMasterSO,&ChildRelSO,mfail)) goto EXIT;
					if (setSize(ChildMasterSO)>0)
					{
						ChildMasterObjOP = setGet(ChildMasterSO,0);
						t5CheckDstat(objGetAttribute(ChildMasterObjOP,DefaultUnitOfMeasureAttr,&ChildUQ));
						if(!nlsIsStrNull(ChildUQ))
						{
							ChildUQDup=nlsStrDup(ChildUQ);
						}
						else
						{
							ChildUQDup=nlsStrDup("4");
						}
					}

					printf("\n ChildCount: %d   ChildUQDup: %s  ChildQuantityDup:%s  ",ChildCount,ChildUQDup,ChildQuantityDup); fflush(stdout);

					UsesDataItemObjP = NULL;
					t5CheckMfail(GetGenTCPartProEInfo(UsesDataItemObjP,ChildPartObjP, ChildPartNumberS, ChildPartRevDup, ChildPartSeqDup, InstancePrtRevSeq, mfail, &GUsesLevel2));
					////printf("\nrrr-------%d,%s,%s",usesLevel+1,ChildPartNumberS,SuppressedValStr); fflush(stdout);
					////tmpStr = low_set_get_str(ProAssyMemDisSOS , ChildCount);
					////printf("\n\t ProAssyMemDisSOS : [%s]   ChildPartNumberS: [%s]",tmpStr,ChildPartNumberS); fflush(stdout);
					strcpy(tempstr,"");
					strcpy(tempstr,ChildPartNumberS);
					tmpStrlen = strlen(tempstr);
					//printf ("\n tmpStrlen  %d",tmpStrlen);
					charFlag = 0;
					for(ti=0;ti<tmpStrlen;ti++)
					{
						if (!isdigit(tempstr[ti]))
						{
							//printf ("\n alpha");
							charFlag = 1;
							printf ("\n 1...charFlag %d found hence skipping\n\n",charFlag); fflush(stdout);
							break;
						}
					}
					if (charFlag == 1)	// Added on 12.05.2017
					{
						ChildPartNumberSConvTmp = ConvertToLowerCase(ChildPartNumberS);
						ChildPartNumberSConv = nlsStrAlloc(100);
						nlsStrCpy(ChildPartNumberSConv,"");
						nlsStrCat(ChildPartNumberSConv,subString(ChildPartNumberSConvTmp,0,nlsStrLen(ChildPartNumberS)));
					}
					else
					{
						ChildPartNumberSConv=nlsStrDup("");
						ChildPartNumberSConv=nlsStrDup(ChildPartNumberS);
					}

					//low_set_insrt_str(UsesPartsSOS,0,ChildPartNumberS);
					low_set_insrt_str(UsesPartsSOS,0,ChildPartNumberSConv);

					printf ("\n 1..charFlag: %d  ChildPartNumberS: [%s]   ChildPartNumberSConv: [%s]",charFlag,ChildPartNumberS,ChildPartNumberSConv); fflush(stdout);
					//if ((low_set_find_str(ProAssyMemSOS,ChildPartNumberS) < 0) || (low_set_find_str(ProAssyMemSOS,ChildPartNumberSConv) < 0))
					if (low_set_find_str(ProAssyMemSOS,ChildPartNumberSConv) < 0)
					{
						printf("\t ..Uses Part is not Present in Pro-Assembly Member.."); fflush(stdout);
						//SuppressedVal = FALSE;
						if(nlsStrNCmp(ChildPartNumberS,"G",1) == 0)
						{
							if (dstat = ExpandRelationWithCtxt("AsRevRev", ChildPartObjP, "PartsInAssembly", GenContextObjP, SC_SCOPE_OF_SESSION, NULL, &GrpitemObjs, &GrprelObjs, mfail)) goto CLEANUP;
							if(SetFlagforScope(GrpitemObjs)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if (dstat = ExpandRelationWithCtxt("AsRevRev", ChildPartObjP, "PartsInAssembly", GenContextObjP, SC_SCOPE_OF_SESSION, NULL, &GrpitemObjs, &GrprelObjs, mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}

							printf("\n GrpTCPart-setSize(GrpitemObjs): %d",setSize(GrpitemObjs));fflush(stdout);

							GrpChildExistFlag = 0;
							for( gn=0; gn<setSize(GrpitemObjs); gn++)
							{
								if (dstat = objGetAttribute( setGet(GrpitemObjs, gn) ,PartNumberAttr,&GrpChild)) goto CLEANUP;
								GrpChildDup=nlsStrDup(GrpChild);

								strcpy(tempstr,"");
								strcpy(tempstr,GrpChildDup);

								tmpStrlen = strlen(tempstr);
								//printf ("\n tmpStrlen  %d",tmpStrlen);
								charFlag = 0;
								for(ti=0;ti<tmpStrlen;ti++)
								{
									if (!isdigit(tempstr[ti]))
									{
										//printf ("\n alpha");
										charFlag = 1;
										printf ("\n charFlag %d found hence skipping\n\n",charFlag);
										break;
									}
								}
								if (charFlag == 1)	// Added on 12.05.2017
								{
									GrpChildDupConvTmp = ConvertToLowerCase(GrpChildDup);
									GrpChildDupConv = nlsStrAlloc(100);
									nlsStrCpy(GrpChildDupConv,"");
									nlsStrCat(GrpChildDupConv,subString(GrpChildDupConvTmp,0,nlsStrLen(GrpChildDup)));
								}
								else
								{
									GrpChildDupConv=nlsStrDup("");
									GrpChildDupConv=nlsStrDup(GrpChildDup);
								}

								printf("\n GrpTCPart--rrr--charFlag: %d   GrpChildDup: [%s]   GrpChildDupConv: [%s]",charFlag,GrpChildDup,GrpChildDupConv);fflush(stdout);

								//if((low_set_find_str(ProAssyMemSOS,GrpChildDup) >= 0) || (low_set_find_str(ProAssyMemSOS,GrpChildDupConv) >= 0))
								if(low_set_find_str(ProAssyMemSOS,GrpChildDupConv) >= 0)	// Condition changed on 12.05.2017
								{
									//GrpChildExistFlag = 1;
									GrpChildExistFlag = GrpChildExistFlag + 1;
									fprintf(fpGrpChilRel,"%s,%s,\n",ChildPartNumberS,GrpChildDup); fflush(fpGrpChilRel);
									//break;	//commented for case TPL 5008043934L and G322793 from all comps are present under TPL CAD bom
								}
								//else
								//{
								//	GrpChildExistFlag = 0;
								//}
							}
							fprintf(fpGrpChilCnt,"%s,%d,%d\n",ChildPartNumberS,setSize(GrpitemObjs),GrpChildExistFlag); fflush(fpGrpChilRel);

							if (GrpChildExistFlag == 0)
							{
								nlsStrCpy(SuppressedValStr,"TRUE");

								//for (t=0; t< (usesLevel+1); t++)
								//{
								//	fprintf(fpSuperSet,"\t");fflush(stdout);
								//}
								//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R1\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R1\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
							}
							//else if (GrpChildExistFlag == 1)
							else if (GrpChildExistFlag > 0)
							{
								nlsStrCpy(SuppressedValStr,"FALSE");

								//for (t=0; t< (usesLevel+1); t++)
								//{
								//	fprintf(fpSuperSet,"\t");fflush(stdout);
								//}
								//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R2\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R2\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
							}

							if (setSize(GrpitemObjs) > 0)
							{
								GUsesLevel = usesLevel+2;
								ProAsmPrtLevel = usesLevel+2;

								ParentNo = nlsStrAlloc(30);
								nlsStrCpy(ParentNo,"");
								nlsStrCpy(ParentNo,ChildPartNumberS);

								for( gn=0; gn<setSize(GrpitemObjs); gn++)
								{
									GrpitemObj = setGet(GrpitemObjs, gn);
									GrpitemRelObj = setGet(GrprelObjs, gn);

									if (dstat = objGetAttribute(GrpitemObj,PartNumberAttr,&GrpChild)) goto CLEANUP;
									GrpChildDup=nlsStrDup(GrpChild);

									if (dstat = objGetAttribute( GrpitemObj ,RevisionAttr,&GrpChildRev)) goto CLEANUP;
									GrpChildRevDup=nlsStrDup(GrpChildRev);

									if (dstat = objGetAttribute( GrpitemObj ,SequenceAttr,&GrpChildSeq)) goto CLEANUP;
									GrpChildSeqDup=nlsStrDup(GrpChildSeq);

									if (dstat = objGetAttribute( GrpitemObj ,NomenclatureAttr,&GrpChildDesc)) goto CLEANUP;
									GrpChildDescDup=nlsStrDup(GrpChildDesc);

									if (dstat = objGetAttribute(GrpitemRelObj,QuantityAttr,&GrpChildQuantity)) goto CLEANUP;
									if(!nlsIsStrNull(GrpChildQuantity))
									{
										GrpChildQuantityDup=nlsStrDup(GrpChildQuantity);
									}
									else
									{
										GrpChildQuantityDup=nlsStrDup("1");
									}

									if(nlsStrNCmp(GrpChildDup,"G",1) == 0)
									{
										//GrpChildDupConv = nlsStrAlloc(20);
										//nlsStrCpy(GrpChildDupConv,"g");
										//nlsStrCat(GrpChildDupConv,subString(GrpChildDup,1,nlsStrLen(GrpChildDup)));
										//GrpChildDupConv[nlsStrLen(GrpChildDupConv)]='\0';

										//GrpChildDupConv = ConvertToLowerCase(GrpChildDup);
										GrpChildDupConvTmp = ConvertToLowerCase(GrpChildDup);
										GrpChildDupConv = nlsStrAlloc(100);
										nlsStrCpy(GrpChildDupConv,"");
										nlsStrCat(GrpChildDupConv,subString(GrpChildDupConvTmp,0,nlsStrLen(GrpChildDup)));
									}
									else	// Added on 12.05.2017
									{
										GrpChildDupConv = nlsStrDup("");
										GrpChildDupConv = nlsStrDup(GrpChildDup);
									}

									printf("\n 2..GrpChildDup: [%s]   GrpChildDupConv: [%s]  GrpChildQuantityDup: %s ",GrpChildDup,GrpChildDupConv,GrpChildQuantityDup);fflush(stdout);

									if (dstat = ExpandObject2("ItemRev",GrpitemObj,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&GrpChildMasterSO,&GrpChildRelSO,mfail)) goto EXIT;
									if (setSize(GrpChildMasterSO)>0)
									{
										GrpChildMasterObjOP = setGet(GrpChildMasterSO,0);
										t5CheckDstat(objGetAttribute(GrpChildMasterObjOP,DefaultUnitOfMeasureAttr,&GrpChildUQ));
										if(!nlsIsStrNull(GrpChildUQ))
										{
											GrpChildUQDup=nlsStrDup(GrpChildUQ);
										}
										else
										{
											GrpChildUQDup=nlsStrDup("4");
										}
									}

									UsesDataItemObjP = NULL;
									t5CheckMfail(GetGenTCPartProEInfo(UsesDataItemObjP,GrpitemObj, GrpChildDup, GrpChildRevDup, GrpChildSeqDup, InstancePrtRevSeq, mfail, &GUsesLevel));

									//if((low_set_find_str(ProAssyMemSOS,GrpChildDup) < 0) || ((low_set_find_str(ProAssyMemSOS,GrpChildDupConv) < 0) && (!nlsIsStrNull(GrpChildDupConv))))
									if(low_set_find_str(ProAssyMemSOS,GrpChildDupConv) < 0)		// Condition changed on 12.05.2017
									{
										//printf("\t ..Uses Part not Present in Pro-Assembly Member.."); fflush(stdout);

										//SuppressedVal = FALSE;

										nlsStrCpy(SuppressedValStr,"TRUE");

										//////for (t=0; t< (usesLevel+2); t++)
										//for (t=0; t< GUsesLevel; t++)
										//{
										//	fprintf(fpSuperSet,"\t");fflush(stdout);
										//}

										//fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R3\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,GrpChildDescDup,GrpChildDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
										fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R3\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,GrpChildDescDup,GrpChildDup,GrpChildQuantityDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);

										//low_set_insrt_str(UsesPartsSOS,0,GrpChildDup);
										low_set_insrt_str(UsesPartsSOS,0,GrpChildDupConv);


										// Add multi-level expansion for uses part which is not present in Pro-Assembly Member relation
										printf("\n Calling the Function for GetMultiLevelExplosionUsesPart in ContextBOMViewTCPartMultiExplosion\n"); fflush(stdout);
										if(dstat = GetMultiLevelExplosionUsesPart(GrpitemObj, GrpChildDup, GrpChildRevDup, GrpChildSeqDup,BOMConfigContextS, &GUsesLevel, mfail)) goto CLEANUP;
										printf("\n After GetMultiLevelExplosionUsesPart in ContextBOMViewTCPartMultiExplosion ?????\n"); fflush(stdout);
									}
									//else if((low_set_find_str(ProAssyMemSOS,GrpChildDup) >= 0) || ((low_set_find_str(ProAssyMemSOS,GrpChildDupConv) >= 0) && (!nlsIsStrNull(GrpChildDupConv)) ))
									else if((low_set_find_str(ProAssyMemSOS,GrpChildDupConv) >= 0) && (!nlsIsStrNull(GrpChildDupConv)) )
									{
										nlsStrCpy(SuppressedValStr,"FALSE");

										/////fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R4\n",usesLevel+2,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,SuppressedValStr); fflush(fpSuperSet);
										//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R4\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,SuppressedValStr); fflush(fpSuperSet);

										//low_set_insrt_str(UsesPartsSOS,0,GrpChildDup);
										low_set_insrt_str(UsesPartsSOS,0,GrpChildDupConv);


										// Add multi-level expansion for uses part which is present in Pro-Assembly Member relation Also
										for (mn = 0; mn < setSize(ProAssyMemDisSOS); mn++)
										{
											tmpStr2 = nlsStrAlloc(200);
											tmpStr3 = nlsStrAlloc(200);

											tmpStr = low_set_get_str(ProAssyMemDisSOS , mn);

											nlsStrCpy(tmpStr3,tmpStr);

											tmpStr2 = strtok(tmpStr3,",");

											if (nlsStrCmp(tmpStr2,GrpChildDup) == 0)
											{
												ProAsmRelpath = nlsStrAlloc(100);
												ProAsmSeq = nlsStrAlloc(5);
												ProAsmOwnNm = nlsStrAlloc(30);
												ProAsmOwnDirNm = nlsStrAlloc(30);

												ProAsmRelpath = strtok(NULL,",");
												ProAsmSeq = strtok(NULL,",");
												ProAsmOwnNm = strtok(NULL,",");
												ProAsmOwnDirNm = strtok(NULL,",");

												if (setSize(ProeDISO)>0)
												{
													objDisposeAll(ProeDISO);
												}
												ProeDISO = NULL;

												t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
												t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
												t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
												t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
												t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
												t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
												t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
												t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProAsmOwnDirNm));
												t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDISO,mfail));

												printf("\n Grp--Number of ProE Objects: %d",setSize(ProeDISO));

												if(setSize(ProeDISO)==0)
												{
													if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
													t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
													t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
													t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
													t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
													t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
													t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
													t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
													t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProAsmOwnDirNm));
													t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDISO,mfail));
													if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

													if(setSize(ProeDISO)==0)
													{
														if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
														t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
														t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
														t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
														t5CheckMfail(QueryWhere("ProInst",ProeObjSqlPtr,&ProeDISO,mfail));
														if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
														printf("\n Grp--Number of ProE Instance Objects: %d",setSize(ProeDISO));
													}
												}

												if(setSize(ProeDISO)==0)
												{
													printf("\n Grp--There are no ProE Objects with Given Input");
													continue;
												}
												else
												{
													ProeDIPtr = setGet(ProeDISO, 0);
												}

												printf("\n\t %d -> %s ...Match Found",mn,tmpStr); fflush(stdout);

												break;
											}
										}

										//objDump(ProeDIPtr);

										t5CheckDstat(objGetAttribute(ProeDIPtr,"Class",&GrpChProeAsmClass));
										if(GrpChProeAsmClassDup != NULL)
										{
											nlsStrFree(GrpChProeAsmClassDup);GrpChProeAsmClassDup = NULL;
										}
										GrpChProeAsmClassDup = nlsStrDup(GrpChProeAsmClass);

										t5CheckDstat(objGetAttribute(ProeDIPtr,"OBID",&GrpChProAsmOBID));
										if(GrpChProAsmOBIDDup!=NULL)
										{
											nlsStrFree(GrpChProAsmOBIDDup);GrpChProAsmOBIDDup = NULL;
										}
										GrpChProAsmOBIDDup=nlsStrDup(GrpChProAsmOBID);

										if (!nlsStrCmp(GrpChProeAsmClassDup,"ProAsmI") || !nlsStrCmp(GrpChProeAsmClassDup,"ProAsm"))
										{
											printf("\n GrpChild--GrpChProAsmOBIDDup is %s",GrpChProAsmOBIDDup);

											//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);
											//if (!nlsStrCmp(GrpChProeAsmClassDup,"ProAsmI"))
											//{
											//	//printf("\n GrpChild--Calling for Function: GetProeAsmIExpOnly2...");
											//	//t5CheckMfail(GetProeAsmIExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,GrpChProeAsmClassDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
											//	t5CheckMfail(GetProeAsmIExpOnly2(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
											//}
											//else
											//{
											//	//printf("\n GrpChild--Calling for Function: GetProeAsmExpOnly2...");
											//	//t5CheckMfail(GetProeAsmExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,GrpChProeAsmClassDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
											//	t5CheckMfail(GetProeAsmExpOnly2(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
											//}

											t5CheckMfail(GetProeAndUsesPartMultiLevelSuperSetBom(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel,ParentNo));
										}
										else if (!nlsStrCmp(GrpChProeAsmClassDup,"ProPrtI"))
										{
											//for (t=0; t< GUsesLevel; t++)
											//{
											//	fprintf(fpSuperSet,"\t");fflush(stdout);
											//}
											//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R4\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,SuppressedValStr); fflush(fpSuperSet);
											fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R4\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,GrpChildDescDup,GrpChildDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
											//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);

											//printf("\n GrpChild--Calling for Function: GetProePartInstOnlyExp2...");
											//t5CheckMfail(GetProePartInstOnlyExp2(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
											//t5CheckMfail(GetProePartInstOnlyExp2(ProeDIPtr,ProAsmRelpath,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
										}
										else if(!nlsStrCmp(GrpChProeAsmClassDup,"ProPrt"))
										{
											//for (t=0; t< GUsesLevel; t++)
											//{
											//	fprintf(fpSuperSet,"\t");fflush(stdout);
											//}
											//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R41\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,SuppressedValStr); fflush(fpSuperSet);
											fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R41\n",GUsesLevel,GrpChildDup,GrpChildRevDup,GrpChildSeqDup,GrpChildDescDup,GrpChildDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);

											//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);
											//printf("\n GrpChild--Calling for Function: GetFullPathJTExp...");
											//t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
											//t5CheckMfail(GetFullPathJTExp(ProeDIPtr,ProeDIPtr,IsProDrw,fp,fp1,fperr,mfail,&ProAsmPrtLevel));
										}
									}

									//low_set_insrt_str(UsesPartsSOS,0,GrpChildDup);
								}
							}
						}
						else
						{
							//if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
							//if (setSize(partMasterSO)>0)
							//{
							//	MasterObjOP=setGet(partMasterSO,0);
							//}

							nlsStrCpy(SuppressedValStr,"TRUE");

							//for (t=0; t< (usesLevel+1); t++)
							//{
							//	fprintf(fpSuperSet,"\t");fflush(stdout);
							//}
							//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,1(qty),R5\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);

							if (nlsStrCmp(ChildPartTypeDup,"D")==0)
							{
								//Dummy has 0 Qty
								//fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R5\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R5\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,ChildQuantityDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
								printf("\n 1....%d^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R5\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,ChildQuantityDup,SuppressedValStr,ParentNo); fflush(stdout);
							}
							else
							{
								//fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R51\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R51\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,ChildQuantityDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);
								printf("\n 2....%d^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R51\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,ChildQuantityDup,SuppressedValStr,ParentNo); fflush(stdout);
							}


							// Add multi-level expansion for uses part which is not present in Pro-Assembly Member relation
							printf("\n Calling the Function for GetMultiLevelExplosionUsesPart in ContextBOMViewTCPartMultiExplosion\n"); fflush(stdout);
							if(dstat = GetMultiLevelExplosionUsesPart(ChildPartObjP, ChildPartNumberS, ChildPartRevDup, ChildPartSeqDup,BOMConfigContextS, &GUsesLevel2, mfail)) goto CLEANUP;
						}
					}
					else
					{
						ProAsmPrtLevel = usesLevel+1;
						printf("\t ..Part Present in Pro-Assembly Member.."); fflush(stdout);
						//SuppressedVal = FALSE;
						nlsStrCpy(SuppressedValStr,"FALSE");

						//for (t=0; t< (usesLevel+1); t++)
						//{
						//	fprintf(fpSuperSet,"\t");fflush(stdout);
						//}
						//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,0(qty),R31\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);

						/*printf("\n\n  Rupali--setSize(ProAssyMemDisSOS): %d",setSize(ProAssyMemDisSOS));fflush(stdout);
						for (m1 = 0; m1 < setSize(ProAssyMemDisSOS); m1++)
						{
							tmpStr = low_set_get_str(ProAssyMemDisSOS , m1);
							printf("\n\t %d -> %s",m1,tmpStr); fflush(stdout);
						}
						printf("\n\n"); fflush(stdout);*/

						if (setSize(ProAssyMemDisSOS) > 0)
						{
							for (mo = 0; mo < setSize(ProAssyMemDisSOS); mo++)
							{
								tmpStr2 = nlsStrAlloc(200);
								tmpStr3 = nlsStrAlloc(200);

								tmpStr = low_set_get_str(ProAssyMemDisSOS , mo);

								nlsStrCpy(tmpStr3,tmpStr);

								tmpStr2 = strtok(tmpStr3,",");
								if (nlsStrCmp(tmpStr2,ChildPartNumberS) != 0)	//added on 26.07.2017 for case 543847100124_for_x451 tpl 5442522447R,H,4
								{
									if (nlsStrCmp(tmpStr2,ChildPartNumberSOrg) == 0)
									{
										ChildPartNumberS=nlsStrDup(ChildPartNumberSOrg);
									}
								}
								//if (nlsStrCmp(tmpStr2,ChildPartNumberS) == 0)
								if ((nlsStrCmp(tmpStr2,ChildPartNumberS) == 0) || (nlsStrCmp(tmpStr2,ChildPartNumberSConv) == 0))
								{
									//printf("\n  Rupali--tmpStr2: %s   ChildPartNumberS:%s",tmpStr2,ChildPartNumberS);fflush(stdout);
									//printf("\t  Rupali--MatchFound");fflush(stdout);

									ProAsmRelpath = nlsStrAlloc(100);
									ProAsmSeq = nlsStrAlloc(5);
									ProAsmOwnNm = nlsStrAlloc(30);
									ProAsmOwnDirNm = nlsStrAlloc(30);

									ProAsmRelpath = strtok(NULL,",");
									ProAsmSeq = strtok(NULL,",");
									ProAsmOwnNm = strtok(NULL,",");
									ProAsmOwnDirNm = strtok(NULL,",");

									printf("\n  rrr--ProAsmRelpath: %s  ProAsmSeq:%s  ProAsmOwnNm:%s  ProAsmOwnDirNm:%s",ProAsmRelpath,ProAsmSeq,ProAsmOwnNm,ProAsmOwnDirNm);fflush(stdout);

									if (setSize(ProeDISO)>0)
									{
										objDisposeAll(ProeDISO);
									}
									ProeDISO = NULL;

									t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
									t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
									t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
									t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
									t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProAsmOwnDirNm));
									t5CheckMfail(oiSqlDescOrder(ProeObjSqlPtr,CreationDateAttr));
									t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDISO,mfail));

									if(setSize(ProeDISO)==0)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
										t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
										t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
										t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
										t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
										t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
										t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
										t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProAsmOwnDirNm));
										t5CheckMfail(oiSqlDescOrder(ProeObjSqlPtr,CreationDateAttr));
										t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDISO,mfail));
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

										if(setSize(ProeDISO)==0)
										{
											if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
											t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProAsmRelpath));
											t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProAsmSeq));
											t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
											t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProAsmOwnNm));
											t5CheckMfail(oiSqlDescOrder(ProeObjSqlPtr,CreationDateAttr));
											t5CheckMfail(QueryWhere("ProInst",ProeObjSqlPtr,&ProeDISO,mfail));
											printf("\t ProEInstanceObjects: %d",setSize(ProeDISO));
											if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
										}
									}

									if(setSize(ProeDISO)==0)
									{
										printf("\t --There are no ProE Objects with Given Input");
										continue;
									}
									else
									{
										ProeDIPtr = setGet(ProeDISO, 0);

										t5CheckDstat(objGetAttribute(ProeDIPtr,"Class",&GrpChProeAsmClass));
										if(GrpChProeAsmClassDup != NULL)
										{
											nlsStrFree(GrpChProeAsmClassDup);GrpChProeAsmClassDup = NULL;
										}
										GrpChProeAsmClassDup = nlsStrDup(GrpChProeAsmClass);

										printf(" ClassDup: %s",GrpChProeAsmClassDup);

										//t5CheckDstat(objGetAttribute(ProeDIPtr,"OBID",&GrpChProAsmOBID));
										//if(GrpChProAsmOBIDDup!=NULL)
										//{
										//	nlsStrFree(GrpChProAsmOBIDDup);GrpChProAsmOBIDDup = NULL;
										//}
										//GrpChProAsmOBIDDup=nlsStrDup(GrpChProAsmOBID);

										if (!nlsStrCmp(GrpChProeAsmClassDup,"ProAsmI") || !nlsStrCmp(GrpChProeAsmClassDup,"ProAsm"))
										{
											//printf("\n --GrpChProAsmOBIDDup: %s",GrpChProAsmOBIDDup);

											//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);

											/*  //Commented on 07.02.2018 to avoid duplicate printing record in Bom file case 5039m324301sm018 and assy 284643200101
											if (nlsStrCmp(GrpChProeAsmClassDup,"ProAsmI") == 0)
											{
												//for (t=0; t< ProAsmPrtLevel; t++)
												//{
												//	fprintf(fpSuperSet,"\t");fflush(stdout);
												//}
												//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,0(qty),R319\n",ProAsmPrtLevel,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);
												if (nlsStrCmp(ChildPartTypeDup,"D")==0)
												{
													//Dummy has 0 Qty
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R318\n",ProAsmPrtLevel,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}
												else
												{
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R319\n",ProAsmPrtLevel,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}

												//printf("\n --Calling for Function: GetProeAsmIExpOnly2...");
												//t5CheckMfail(GetProeAsmIExpOnly2(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
											}*/
											/*else
											{
												//printf("\n --Calling for Function: GetProeAsmExpOnly2...");
												//t5CheckMfail(GetProeAsmExpOnly2(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
												;
											}*/

											t5CheckMfail(GetProeAndUsesPartMultiLevelSuperSetBom(ProeDIPtr,ProAsmRelpath,GrpChProeAsmClassDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel,ParentNo));
										}
										else if ((nlsStrCmp(GrpChProeAsmClassDup,"ProPrtI")==0) || (nlsStrCmp(GrpChProeAsmClassDup,"ProPrt")==0))
										{
											if (!nlsStrCmp(GrpChProeAsmClassDup,"ProPrtI"))
											{
												//for (t=0; t< (usesLevel+1); t++)
												//{
												//	fprintf(fpSuperSet,"\t");fflush(stdout);
												//}
												//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,0(qty),R315\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);
												if (nlsStrCmp(ChildPartTypeDup,"D")==0)
												{
													//Dummy has 0 Qty
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R314\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}
												else
												{
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R315\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}

												//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);

												//printf("\n --Calling for Function: GetProePartInstOnlyExp2...");
												//t5CheckMfail(GetProePartInstOnlyExp2(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
												//t5CheckMfail(GetProePartInstOnlyExp2(ProeDIPtr,ProAsmRelpath,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,&ProAsmPrtLevel));
											}
											else if(!nlsStrCmp(GrpChProeAsmClassDup,"ProPrt"))
											{
												//for (t=0; t< (usesLevel+1); t++)
												//{
												//	fprintf(fpSuperSet,"\t");fflush(stdout);
												//}
												//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,0(qty),R316\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);

												if (nlsStrCmp(ChildPartTypeDup,"D")==0)
												{
													//Dummy has 0 Qty
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R316\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}
												else
												{
													fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R317\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
												}

												//low_set_insrt_str (OBIDsetS,0,GrpChProAsmOBIDDup);

												//printf("\n --Calling for Function: GetFullPathJTExp...");
												//t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,IsProDrw,fp,fp1,fperr,mfail,level));
												//t5CheckMfail(GetFullPathJTExp(ProeDIPtr,ProeDIPtr,IsProDrw,fp,fp1,fperr,mfail,&ProAsmPrtLevel));
											}

											// Add multi-level expansion for uses part which is not present in Pro-Assembly Member relation
											printf("\n 3.Calling the Function for GetMultiLevelExplosionUsesPart in ContextBOMViewTCPartMultiExplosion"); fflush(stdout);
											if(dstat = GetMultiLevelExplosionUsesPart(ChildPartObjP, ChildPartNumberS, ChildPartRevDup, ChildPartSeqDup,BOMConfigContextS, &ProAsmPrtLevel, mfail)) goto CLEANUP;
										}
									}

									printf("\n Number of ProE Objects: %d",setSize(ProeDISO)); fflush(stdout);

									break;
								}
								//else
								//{
								//	printf("\n Both ProeMembers not matching : [%s] [%s]",tmpStr2,ChildPartNumberS); fflush(stdout);
								//}
							}
						}
						else
						{
							//for (t=0; t< (usesLevel+1); t++)
							//{
							//	fprintf(fpSuperSet,"\t");fflush(stdout);
							//}
							//fprintf(fpSuperSet,"%d,%s,%s,%s,%s,0(qty),R317\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,SuppressedValStr); fflush(fpSuperSet);
							if (nlsStrCmp(ChildPartTypeDup,"D")==0)
							{
								//Dummy has 0 Qty
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R331\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
							}
							else
							{
								fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^1^%s^%s^R332\n",usesLevel+1,ChildPartNumberS,ChildPartRevDup,ChildPartSeqDup,ChildDescDup,ChildPartNumberS,SuppressedValStr,ParentNo); fflush(fpSuperSet);
							}

							printf("\n 4.Calling the Function for GetMultiLevelExplosionUsesPart in ContextBOMViewTCPartMultiExplosion"); fflush(stdout);
							if(dstat = GetMultiLevelExplosionUsesPart(ChildPartObjP, ChildPartNumberS, ChildPartRevDup, ChildPartSeqDup,BOMConfigContextS, &ProAsmPrtLevel, mfail)) goto CLEANUP;

						}
					}
				}

				printf("\n SetofString setSize(UsesPartsSOS) :%d \n",setSize(UsesPartsSOS)); fflush(stdout);
				for (m1 = 0; m1 < setSize(UsesPartsSOS); m1++)
				{
					tmpStr = low_set_get_str(UsesPartsSOS , m1);
					printf("\n\t %d -> %s",m1,tmpStr); fflush(stdout);
				}
			}
		}
		else
		{
			//No TC part object attached in PLM

			TCPartPresentFlag = 0;

			ProAsmPart = nlsStrAlloc(50);
			if (nlsStrStr(GeninstanceNameS3,"/") !=NULL)
			{
				ProAsmPrtTemp = nlsStrAlloc(200);
				ProAsmPrtTemp = strtok(GeninstanceNameS3,"/");
				while (ProAsmPrtTemp != NULL)
				{
					ProAsmPrtTemp = strtok(NULL,"/");
					if(!nlsIsStrNull(ProAsmPrtTemp))
					{
						GeninstanceNameS2 = nlsStrDup(ProAsmPrtTemp);
					}
				}
			}
			if (nlsStrStr(GeninstanceNameS2,"<") !=NULL)
			{
				nlsStrCpy(ProAsmPart,strtok(GeninstanceNameS2,"<"));
			}
			else if (nlsStrStr(GeninstanceNameS2,".") !=NULL)
			{
				nlsStrCpy(ProAsmPart,strtok(GeninstanceNameS2,"."));
			}
			else
			{
				nlsStrCpy(ProAsmPart,GeninstanceNameS2);
			}

			//for (t=0; t< *level; t++)
			//{
			//	fprintf(fpSuperSet,"\t");fflush(stdout);
			//}
			fprintf(fpSuperSet,"%d^%s^NR^1^Dummy Part for Proe^1^%s^4^0^FALSE^%s^R6\n",*level,ProAsmPart,ProAsmPart,ParentNo); fflush(fpSuperSet);

			UsesDataItemObjP = NULL;
			TCObjP = NULL;
			t5CheckMfail(GetGenTCPartProEInfo(UsesDataItemObjP,TCObjP, ProAsmPart, "NR", "1", InstancePrtRevSeq, mfail, &GUsesLevel));
		}
	}
	else
	{
		//Any Design Document object is not attached in PLM

		TCPartPresentFlag = -1;

		ProAsmPart = nlsStrAlloc(50);
		if (nlsStrStr(GeninstanceNameS3,"/") !=NULL)
		{
			ProAsmPrtTemp = nlsStrAlloc(200);
			ProAsmPrtTemp = strtok(GeninstanceNameS3,"/");
			while (ProAsmPrtTemp != NULL)
			{
				ProAsmPrtTemp = strtok(NULL,"/");
				if(!nlsIsStrNull(ProAsmPrtTemp))
				{
					GeninstanceNameS2 = nlsStrDup(ProAsmPrtTemp);
				}
			}
		}
		if (nlsStrStr(GeninstanceNameS2,"<") !=NULL)
		{
			nlsStrCpy(ProAsmPart,strtok(GeninstanceNameS2,"<"));
		}
		else if (nlsStrStr(GeninstanceNameS2,".") !=NULL)
		{
			nlsStrCpy(ProAsmPart,strtok(GeninstanceNameS2,"."));
		}
		else
		{
			nlsStrCpy(ProAsmPart,GeninstanceNameS2);
		}

		//for (t=0; t< *level; t++)
		//{
		//	fprintf(fpSuperSet,"\t");fflush(stdout);
		//}
		fprintf(fpSuperSet,"%d^%s^NR^1^Dummy Part for Proe^1^%s^4^0^FALSE^%s^R7\n",*level,ProAsmPart,ProAsmPart,ParentNo); fflush(fpSuperSet);
		TCObjP = NULL;
		t5CheckMfail(GetGenTCPartProEInfo(DataItemObjP,TCObjP, ProAsmPart, "NR", "1", InstancePrtRevSeq, mfail, &GUsesLevel));
	}

	if(setSize(ProeAsmPhyItemSO)==0)
	{
		//printf("\n There is no Qualified Generic Object For GetProeAsmExpOnly2 this :%s \n",ProeAsmRPathDup);
		goto CLEANUP;
	}
	else
	{
		*level=*level+1;
		ProAsmUsesLevel = *level;

		//ParentNo = nlsStrAlloc(30);
		//nlsStrCpy(ParentNo,"");
		//if (setSize(DocPartSO) > 0)
		//{
		//	nlsStrCpy(ParentNo,AssyPartDup);
		//}
		//else
		//{
		//	nlsStrCpy(ParentNo, "-");
		//}
		if (TCPartPresentFlag < 1)
		{
			ParentNo = nlsStrAlloc(30);
			nlsStrCpy(ParentNo,"");
			if (nlsStrStr(DataItemDisNmDup1,".") !=NULL)
			{
				nlsStrCpy(ParentNo,strtok(DataItemDisNmDup1,"."));
			}
			else if (nlsStrStr(DataItemDisNmDup1,"<") !=NULL)
			{
				nlsStrCpy(ParentNo,strtok(DataItemDisNmDup1,"<"));
			}
			else
			{
				nlsStrCpy(ParentNo,DataItemDisNmDup1);
			}
			printf("\n  TCPartPresentFlag: %d ---------  ParentNo: %s",TCPartPresentFlag,ParentNo); fflush(stdout);
		}
		for(ProeAsmMember=0;ProeAsmMember<setSize(ProeAsmPhyItemSO);ProeAsmMember++)
		{
			ProAsmMemObjP = low_set_get(ProeAsmPhyItemSO,ProeAsmMember);

			ProePrtExistInUsesFlag = 0;

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"Class",&ProeAsmMemCNameDupS));
			if(ProeAsmMemCNameDup!=NULL)
			{
				nlsStrFree(ProeAsmMemCNameDup);ProeAsmMemCNameDup = NULL;
			}
			ProeAsmMemCNameDup=nlsStrDup(ProeAsmMemCNameDupS);

			//printf("\n ProeAsmMemCNameDup is :%s\n",ProeAsmMemCNameDup);

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"RelativePath",&ProeAsmMemRPathS));
			if(ProeAsmMemRPathDup!=NULL){nlsStrFree(ProeAsmMemRPathDup);ProeAsmMemRPathDup = NULL;}
			ProeAsmMemRPathDup=nlsStrDup(ProeAsmMemRPathS);
			printf("\n   2.ProAssemblyMembers no %d and ProeAsmMemRPathDup is %s",ProeAsmMember,ProeAsmMemRPathDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OBID",&ProeAsmMemOBIDDupS));
			if(ProeAsmMemOBIDDup!=NULL){nlsStrFree(ProeAsmMemOBIDDup);ProeAsmMemOBIDDup = NULL;}
			ProeAsmMemOBIDDup=nlsStrDup(ProeAsmMemOBIDDupS);

			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"DisplayedName",&ProeAsmMemDisNm));
			if(ProeAsmMemDisNmDup != NULL)
			{
				nlsStrFree(ProeAsmMemDisNmDup);ProeAsmMemDisNmDup = NULL;
			}
			ProeAsmMemDisNmDup = nlsStrDup(ProeAsmMemDisNm);
			ProeAsmMemDisNmDup1 = nlsStrDup(ProeAsmMemDisNm);

			nlsStrCpy(ProAsmChildPrt,"");
			nlsStrCpy(ProAsmChildPrtStr,"");
			strcpy(tempstr,"");
			if (nlsStrStr(ProeAsmMemDisNmDup1,"/") !=NULL)
			{
				ProAsmPrtTemp = nlsStrAlloc(200);
				ProAsmPrtTemp = strtok(ProeAsmMemDisNmDup1,"/");
				while (ProAsmPrtTemp != NULL)
				{
					ProAsmPrtTemp = strtok(NULL,"/");
					if(!nlsIsStrNull(ProAsmPrtTemp))
					{
						ProeAsmMemDisNmDup = nlsStrDup(ProAsmPrtTemp);
					}
				}
			}
			if (nlsStrStr(ProeAsmMemDisNmDup,"<") !=NULL)
			{
				nlsStrCpy(ProAsmChildPrt,strtok(ProeAsmMemDisNmDup,"<"));
			}
			else if (nlsStrStr(ProeAsmMemDisNmDup,".") !=NULL)
			{
				nlsStrCpy(ProAsmChildPrt,strtok(ProeAsmMemDisNmDup,"."));
			}
			else
			{
				nlsStrCpy(ProAsmChildPrt,ProeAsmMemDisNmDup);
			}
			nlsStrCpy(ProAsmChildPrtStr,ProAsmChildPrt);
			strcpy(tempstr,ProAsmChildPrt);

			// Added on 08.02.2019
			tmpStrlen = strlen(tempstr);
			//printf ("\n tmpStrlen  %d",tmpStrlen);
			charFlag = 0;
			for(ti=0;ti<tmpStrlen;ti++)
			{
				if (!isdigit(tempstr[ti]))
				{
					charFlag = 1;
					printf ("\n B...charFlag %d found \n",charFlag); fflush(stdout);
					break;
				}
			}
			if (charFlag == 1)	// Added on 08.02.2019
			{
				if(ProAsmChildPrtTmp != NULL)
				{
					nlsStrFree(ProAsmChildPrtTmp); ProAsmChildPrtTmp = NULL;
				}
				ProAsmChildPrtTmp = ConvertToLowerCase(ProAsmChildPrt);
				ProAsmChildPrt = nlsStrAlloc(50);
				nlsStrCpy(ProAsmChildPrt,"");
				nlsStrCat(ProAsmChildPrt,subString(ProAsmChildPrtTmp,0,nlsStrLen(ProAsmChildPrtStr)));
			}

			printf("\n NormalCase--ProeAsmMemDisNmDup: %s and ProAsmChildPrt: %s",ProeAsmMemDisNmDup,ProAsmChildPrt); fflush(stdout);

			if(low_set_find_str(UsesPartsSOS,ProAsmChildPrt) >= 0)
			{
				ProePrtExistInUsesFlag = 1;

				printf("\t ---1---ProePrtExistInUsesFlag: %d",ProePrtExistInUsesFlag); fflush(stdout);

				nlsStrCpy(SuppressedValStr,"FALSE");

				/*for (t=0; t< ProAsmUsesLevel; t++)
				{
					fprintf(fpSuperSet,"\t");fflush(stdout);
				}

				fprintf(fpSuperSet,"%d,%s,%s,1(qty),R8\n",ProAsmUsesLevel,ProAsmChildPrt,SuppressedValStr); fflush(fpSuperSet);
				*/
			}
			else if(low_set_find_str(UsesPartsSOS,ProAsmChildPrt) < 0)
			{
				ProePrtExistInUsesFlag = 0;

				printf("\t ---2---ProePrtExistInUsesFlag: %d",ProePrtExistInUsesFlag); fflush(stdout);

				/*nlsStrCpy(SuppressedValStr,"FALSE");

				for (t=0; t< ProAsmUsesLevel; t++)
				{
					fprintf(fpSuperSet,"\t");fflush(stdout);
				}
				fprintf(fpSuperSet,"%d,%s,%s,0(qty),R9\n",ProAsmUsesLevel,ProAsmChildPrt,SuppressedValStr); fflush(fpSuperSet);*/
			}

			if (ProePrtExistInUsesFlag == 0)
			{
				printf("\n %s ProeAsmMemCNameDup: %s --Not present in Uses Parts",ProAsmChildPrt,ProeAsmMemCNameDup);

				nlsStrCpy(SuppressedValStr,"FALSE");

				if ((nlsStrCmp(ProeAsmMemCNameDup,"ProPrt") == 0) || (nlsStrCmp(ProeAsmMemCNameDup,"ProPrtI") == 0))
				{
					if(ProPartDup != NULL)
					{
						nlsStrFree(ProPartDup); ProPartDup = NULL;
					}
					if(ProPartRevDup != NULL)
					{
						nlsStrFree(ProPartRevDup); ProPartRevDup = NULL;
					}
					if(ProPartSeqDup != NULL)
					{
						nlsStrFree(ProPartSeqDup); ProPartSeqDup = NULL;
					}
					if(ProPartDescDup != NULL)
					{
						nlsStrFree(ProPartDescDup); ProPartDescDup = NULL;
					}

					//nlsStrFree(ProPartDup); ProPartDup = NULL;
					//nlsStrFree(ProPartRevDup); ProPartRevDup = NULL;
					//nlsStrFree(ProPartSeqDup); ProPartSeqDup = NULL;
					//nlsStrFree(ProPartDescDup); ProPartDescDup = NULL;

					t5CheckMfail(ExpandObject2(AttachClass,ProAsmMemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&ProDIDocSO,&ProDIDocRelSO,mfail));
					if(SetFlagforScope(ProDIDocSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						t5CheckMfail(ExpandObject2(AttachClass,ProAsmMemObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&ProDIDocSO,&ProDIDocRelSO,mfail));
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					printf("\t ProDIDocSO: %d",setSize(ProDIDocSO));fflush(stdout);
					////sort by creation date function for ProDIDocSO and processing for latest part rev is added on 24.07.2015
					t5CheckMfail(t5SortBOMObjsByDate(&ProDIDocSO,&ProDIDocRelSO,mfail));

					if(setSize(ProDIDocSO)>0)
					{
						ProDocObjP = setGet(ProDIDocSO,0);

						//t5CheckDstat(objGetAttribute(ProDocObjP,"Class",&ProDSClass));
						//if(!nlsIsStrNull(ProDSClass))
						//{
						//	ProDSClassDup=nlsStrDup(ProDSClass);
						//}
						//printf("\t ProDSClassDup:%s",ProDSClassDup); fflush(stdout);

						t5CheckMfail(ExpandObject2(PartDocClass,ProDocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&ProDocPartSO,&ProDocPartRelSO,mfail));
						if(SetFlagforScope(ProDocPartSO)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							t5CheckMfail(ExpandObject2(PartDocClass,ProDocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&ProDocPartSO,&ProDocPartRelSO,mfail));
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
						t5CheckMfail(t5SortBOMObjsByDate(&ProDocPartSO,&ProDocPartRelSO,mfail));
						printf("\t ProTCPart-Proobjects: %d",setSize(ProDocPartSO));fflush(stdout);

						if(setSize(ProDocPartSO)>0)
						{
							ProTCObjP = setGet(ProDocPartSO,0);

							if (dstat = objGetAttribute( ProTCObjP ,PartNumberAttr,&ProPart)) goto CLEANUP;
							ProPartDup=nlsStrDup(ProPart);

							if (dstat = objGetAttribute( ProTCObjP ,RevisionAttr,&ProPartRev)) goto CLEANUP;
							ProPartRevDup=nlsStrDup(ProPartRev);

							if (dstat = objGetAttribute( ProTCObjP ,SequenceAttr,&ProPartSeq)) goto CLEANUP;
							ProPartSeqDup=nlsStrDup(ProPartSeq);

							if (dstat = objGetAttribute( ProTCObjP ,NomenclatureAttr,&ProPartDesc)) goto CLEANUP;
							ProPartDescDup=nlsStrDup(ProPartDesc);
							ProPartDescDup=low_strssra(ProPartDescDup,"\n"," ");
							ProPartDescDup=low_strssra(ProPartDescDup,"^"," ");

							//if (dstat = ExpandObject2("ItemRev",ProTCObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&ProPartMasterSO,&ProPartRelSO,mfail)) goto EXIT;
							//if (setSize(ProPartMasterSO)>0)
							//{
							//	ProPartMasterObjOP = setGet(ProPartMasterSO,0);

							//	t5CheckDstat(objGetAttribute(ProPartMasterObjOP,DefaultUnitOfMeasureAttr,&ProPartUQ));
							//	if(!nlsIsStrNull(ProPartUQ))
							//	{
							//		ProPartUQDup=nlsStrDup(ProPartUQ);
							//	}
							//	else
							//	{
							//		ProPartUQDup=nlsStrDup("4");
							//	}
							//}

						}
					}
				}

				if(nlsIsStrNull(ProPartDup))
				{
					ProPartDup=nlsStrDup(ProAsmChildPrtStr);  //Modified on 08.02.2019
				}
				if(nlsIsStrNull(ProPartRevDup))
				{
					ProPartRevDup=nlsStrDup("NR");
				}
				if(nlsIsStrNull(ProPartSeqDup))
				{
					ProPartSeqDup=nlsStrDup("1");
				}
				if(nlsIsStrNull(ProPartDescDup))
				{
					ProPartDescDup=nlsStrDup("Dummy Part for Proe");
				}

				if ((nlsStrCmp(ProeAsmMemCNameDup,"ProAsmI")==0) || (nlsStrCmp(ProeAsmMemCNameDup,"ProAsm")==0))
				{
					printf("\n   ProeAsmMemOBIDDup is %s",ProeAsmMemOBIDDup);

					//low_set_insrt_str (OBIDsetS,0,ProeAsmMemOBIDDup);

					/*if (!nlsStrCmp(ProeAsmMemCNameDup,"ProAsmI"))
					{
						printf("\n   Calling for Function: GetProeAsmIExpOnly2...");
						t5CheckMfail(GetProeAsmIExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,level));
					}
					else
					{
						printf("\n   Calling for Function: GetProeAsmExpOnly2...");
						t5CheckMfail(GetProeAsmExpOnly2(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,level));
					}*/

					t5CheckMfail(GetProeAndUsesPartMultiLevelSuperSetBom(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,level,ParentNo));
				}
				else if(nlsStrCmp(ProeAsmMemCNameDup,"ProPrtI") == 0)
				{
					//for (t=0; t< ProAsmUsesLevel; t++)
					//{
					//	fprintf(fpSuperSet,"\t");fflush(stdout);
					//}
					//fprintf(fpSuperSet,"%d,%s,%s,0(qty),R91\n",ProAsmUsesLevel,ProAsmChildPrtStr,SuppressedValStr); fflush(fpSuperSet);
					fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R91--%s\n",ProAsmUsesLevel,ProPartDup,ProPartRevDup,ProPartSeqDup,ProPartDescDup,ProPartDup,SuppressedValStr,ParentNo,ProeAsmMemCNameDup); fflush(fpSuperSet);

					InstancePartObjP = NULL;
					t5CheckMfail(GetGenTCPartProEInfo(ProAsmMemObjP,InstancePartObjP, ProPartDup,ProPartRevDup,ProPartSeqDup, InstancePrtRevSeq, mfail, level));

					//low_set_insrt_str(OBIDsetS,0,ProeAsmMemOBIDDup);
					//printf("\n   3..Calling for Function: GetProePartInstOnlyExp2...");
					//t5CheckMfail(GetProePartInstOnlyExp2(ProAsmMemObjP,ProeAsmMemRPathDup,OBIDsetS,fpTemp,fpTemp,fpTemp,mfail,IsProDrw,level));
				}
				else if(nlsStrCmp(ProeAsmMemCNameDup,"ProPrt") == 0)
				{
					//for (t=0; t< ProAsmUsesLevel; t++)
					//{
					//	fprintf(fpSuperSet,"\t");fflush(stdout);
					//}
					//fprintf(fpSuperSet,"%d,%s,%s,0(qty),R90\n",ProAsmUsesLevel,ProAsmChildPrtStr,SuppressedValStr); fflush(fpSuperSet);
					fprintf(fpSuperSet,"%d^%s^%s^%s^%s^1^%s^4^0^%s^%s^R90\n",ProAsmUsesLevel,ProPartDup,ProPartRevDup,ProPartSeqDup,ProPartDescDup,ProPartDup,SuppressedValStr,ParentNo); fflush(fpSuperSet);

					InstancePartObjP = NULL;
					t5CheckMfail(GetGenTCPartProEInfo(ProAsmMemObjP,InstancePartObjP, ProPartDup,ProPartRevDup,ProPartSeqDup, InstancePrtRevSeq, mfail, level));

					//low_set_insrt_str(OBIDsetS,0,ProeAsmMemOBIDDup);
					//t5CheckMfail(GetFullPathJTExp(ProAsmMemObjP,ProAsmMemObjP,IsProDrw,fpTemp,fpTemp,fpTemp,mfail,level));
				}
				else
				{
					printf("\t exceptional class name ::%s \n",DataItemClassNameS); fflush(stdout);
					fprintf(fpTemp,"\t Exceptional Class Name:[%s]",ProeAsmMemCNameDup); fflush(fpTemp);
				}
			}
		}

		*level=*level-1;
	}

CLEANUP:
	//printf("\n Function GetProePartInstOnlyExp2 CLEANUP..\n");
	printf("\n\n"); fflush(stdout);
	t5PrintCleanUpModName;
	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

EXIT:
	//printf("\n Function GetProeAndUsesPartMultiLevelSuperSetBom EXIT..\n"); fflush(stdout);
	t5CheckDstatAndReturn;
};

status GetProePartDrwExpOnly(ObjectPtr DataItemObjP,string ProeAsmRPathDupS,string DataItemClassNameDupS,SetOfStrings OBIDsetS,FILE *fp,FILE *fp1,FILE *fperr,integer* mfail,string IsProDrw,int* level)
{
	int ProeAsmMember=0;
	//int RecChkFlag=0;
	//string ProeAsmRPathDup=NULL;
	//string DataItemFullPathS=NULL;
	//string DataItemFullPathDup=NULL;
	//string DataItemClassNameS=NULL;
	string ProeAsmMemCNameDupS=NULL;
	string ProeAsmMemCNameDup=NULL;
	string ProeAsmMemRPathS=NULL;
	string ProeAsmMemRPathDup=NULL;
	string ProeAsmMemOBIDDupS=NULL;
	string ProeAsmMemOBIDDup=NULL;
	ObjectPtr ProeAsmObjP=NULL;
	ObjectPtr ProAsmMemObjP=NULL;
	//ObjectPtr ProAsmMemObj1P=NULL;
	SetOfObjects ProeAsmPhyItemSO = NULL;
	//SetOfObjects ProeAsmPhyItem1SO = NULL;
	SetOfObjects ProeAsmRelObjSO = NULL;
	//SetOfObjects ProeAsmRelObj1SO = NULL;
	//int d=0;

	t5MethodInit("GetProePartDrwExpOnly");
	t5CheckDstat(objCopy(&ProeAsmObjP,DataItemObjP));
	DataItemObjP=NULL;
	DataItemObjP=ProeAsmObjP;
	//printf("\n inside Function GetProePartDrwExpOnly \n");

	*level=*level+1;

	t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,IsProDrw,fp,fp1,fperr,mfail,level));

	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

	t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
	if(SetFlagforScope(ProeAsmPhyItemSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject2("ProAMemR",DataItemObjP,"ProAMemROnItems",SC_SCOPE_OF_SESSION,&ProeAsmPhyItemSO,&ProeAsmRelObjSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	//printf("\n no of ProDependentOn are------> :%d\n",setSize(ProeAsmPhyItemSO));
	if(setSize(ProeAsmPhyItemSO)==0)
	{
		//printf("\n There is no Qualified Generic Object For GetProeAsmExpOnly2 this----> :%s \n",ProeAsmRPathDupS);
		goto  CLEANUP;
	}

	for(ProeAsmMember=0;ProeAsmMember<setSize(ProeAsmPhyItemSO);ProeAsmMember++)
	{
		//printf("\n working for ProPrtDependencies number :%d\n",ProeAsmMember);
		ProAsmMemObjP = low_set_get(ProeAsmPhyItemSO,ProeAsmMember);
		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"Class",&ProeAsmMemCNameDupS));
		if(ProeAsmMemCNameDup!=NULL){nlsStrFree(ProeAsmMemCNameDup);ProeAsmMemCNameDup = NULL;}
		ProeAsmMemCNameDup=nlsStrDup(ProeAsmMemCNameDupS);
		//printf("\n ProPrtDependencies is :%s\n",ProeAsmMemCNameDup);
		t5CheckDstat(objGetAttribute(ProAsmMemObjP,"RelativePath",&ProeAsmMemRPathS));
		if(ProeAsmMemRPathDup!=NULL){nlsStrFree(ProeAsmMemRPathDup);ProeAsmMemRPathDup = NULL;}
		ProeAsmMemRPathDup=nlsStrDup(ProeAsmMemRPathS);
		//printf("\n  ProDependentOn no %d and ProPrtDependencies is %s\n",ProeAsmMember,ProeAsmMemRPathDup);

		if (!nlsStrCmp(ProeAsmMemCNameDup,"ProPrt"))
		{
			//printf("\n Calling for Function: GetProePartDrwExpOnly...\n");
			//t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,fp,fperr,mfail));
			t5CheckDstat(objGetAttribute(ProAsmMemObjP,"OBID",&ProeAsmMemOBIDDupS));
			if(ProeAsmMemOBIDDup!=NULL){nlsStrFree(ProeAsmMemOBIDDup);ProeAsmMemOBIDDup = NULL;}
			ProeAsmMemOBIDDup=nlsStrDup(ProeAsmMemOBIDDupS);

			//	RecChkFlag=low_set_find_str(OBIDsetS,ProeAsmMemOBIDDup);
			//printf("\n RegChk 1 Log is [%d]",RecChkFlag);
			//if(RecChkFlag>=0)
			//{
			//printf("\n ERROR:: relativepath %s is recursive and its obid is :%s\n",ProeAsmMemRPathDup,ProeAsmMemOBIDDup); fflush(stdout);
			// printf("\n Please Remove Recursion from Structure \n\n\n"); fflush(stdout);
			//fprintf(fp,"%s","RECURSION ERROR::");
			//fprintf(fp,"%s",ProeAsmMemRPathDup);
			//fprintf(fp,"%s\n"," is recursive."); fflush(fp);
			/*fprintf(fperr,"%s","RECURSION ERROR::");fflush(fperr);
			fprintf(fperr,"%s",ProeAsmMemRPathDup);fflush(fperr);
			fprintf(fperr,"%s\n"," is recursive.");fflush(fperr);*/
			//exit(0);
			//}
			//else if (RecChkFlag==-1)
			//{
			low_set_insrt_str (OBIDsetS,0,ProeAsmMemOBIDDup);
			t5CheckMfail(GetProePartDrwExpOnly(ProAsmMemObjP,ProeAsmMemRPathDup,ProeAsmMemCNameDup,OBIDsetS,fp,fp1,fperr,mfail,IsProDrw,level));
			//}
		}
		else
		{
			//printf("\nexceptional class name ::%s \n",DataItemClassNameS);
		}
	}

	*level=*level-1;

CLEANUP:
	//printf("\n Function GetProePartInstOnlyExp2 CLEANUP..\n");
	t5PrintCleanUpModName;
	if(setSize(ProeAsmPhyItemSO))t5FreeSetOfObjects(ProeAsmPhyItemSO);
	if(setSize(ProeAsmRelObjSO))t5FreeSetOfObjects(ProeAsmRelObjSO);

EXIT:
	//printf("\n Function GetProePartInstOnlyExp2 EXIT..\n");
	t5CheckDstatAndReturn;
};

int main(int argc, char *argv[])
{
	int stat=0;
	int DataItem=0;
	//int ProeDRwPrtMember=0;
	int ii = 0;
	int sret=0;
	int fpread;
	int fpwrite;
	int lines =0;
	int processid=0;
	int level=0;
	int level2=0;

	string LoginS = NULL ;
	string PasswordS = NULL ;
	string ProeObjectNameS = NULL ;
	string ProeObjectSequenceS = NULL ;
	string ProeObjectOwnerNameS = NULL ;
	string OutputFileNameS = NULL ;
	string OutputFileNameS2Dup = NULL ;
	string OutputFileNameS2 = NULL ;
	string AssyFileOBIDS = NULL ;
	string AssyFileOBIDDup = NULL ;
	string RelativePathS = NULL ;
	string RelativePathDup = NULL ;
	string TCPartOutPutFileErrS = NULL ;
	string OutputFileNameS1 = NULL ;
	string docobjst = NULL;
	string DataItemClassNameDupS = NULL ;
	string ProeObjectOwnerDirS = NULL ;
	string DataItemClassNameS = NULL ;

	SetOfObjects ProeDataItemSO = NULL;
	//SetOfObjects ProeDrwPrtPhyItemSO = NULL;
	//SetOfObjects ProeDrwPrtRelObjSO = NULL;
	SetOfStrings OBIDsetS =	NULL;

	ObjectPtr NewProeDataItemObjP=NULL;
	ObjectPtr DataItemObjP=NULL;
	ObjectPtr ProePartInstanceObjP=NULL;
	//ObjectPtr ProDrwPrtMemObjP=NULL;

	SqlPtr ProeObjSqlPtr = NULL ;

	//File Declaration
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	FILE *fpTemp = NULL;

	char buffer[1024];
	char tempFileName[100];
	char tempFileName1[100];
	char tempdfname[100];

	t5MethodInitWMD("JtAndProeGetDataItems");

	//printf("\n Executing... main:JtAndProeGetDataItems.c ... \n"); fflush(stdout);

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	ProeObjectNameS=nlsStrAlloc(200);
	ProeObjectSequenceS=nlsStrAlloc(10);
	ProeObjectOwnerDirS=nlsStrAlloc(10);
	ProeObjectOwnerNameS=nlsStrAlloc(50);
	OutputFileNameS=nlsStrAlloc(50);
	OutputFileNameS1=nlsStrAlloc(50);
	OutputFileNameS2=nlsStrAlloc(50);

	LoginS=argv[1];
	PasswordS=argv[2];
	ProeObjectNameS=argv[3];
	ProeObjectSequenceS=argv[4];
	ProeObjectOwnerDirS=argv[5];
	ProeObjectOwnerNameS=argv[6];
	OutputFileNameS1=argv[7];
	OutputFileNameS=argv[8];
	OutputFileNameS2=argv[9];

	printf("\nLoginS:[%s]",LoginS); fflush(stdout);
	printf("\nPassS:[%s]",PasswordS); fflush(stdout);
	printf("\nProeObj:[%s]",ProeObjectNameS); fflush(stdout);
	printf("\nPSeqS:[%s]",ProeObjectSequenceS); fflush(stdout);
	printf("\nPOwnerDirS:[%s]",ProeObjectOwnerDirS); fflush(stdout);
	printf("\nPOwnerS:[%s]",ProeObjectOwnerNameS); fflush(stdout);
	printf("\nOutS1:[%s]",OutputFileNameS1); fflush(stdout);
	printf("\nOutS:[%s]",OutputFileNameS); fflush(stdout);
	printf("\nOutS2:[%s]",OutputFileNameS2); fflush(stdout);


	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));


	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

	sret=system("rm -fr *.dat*");
	printf("\nReturn frm System:%d",sret); fflush(stdout);
	processid=getpid();
	sprintf(tempFileName,"%d",processid);
	strcat(tempFileName,".dat");
	sprintf(tempFileName1,"%d",processid);
	strcat(tempFileName1,".dat1");
	fp=fopen(tempFileName,"w");
	fp1=fopen(tempFileName1,"w");
	fflush(fp);
	fflush(fp1);

	pfile=fopen("parentchildrel.txt","w");

	OutputFileNameS2Dup=nlsStrDup(OutputFileNameS2);
	fp2=fopen(OutputFileNameS2Dup,"w");
	fflush(fp2);

	fpSuperSet = fopen("AssyBomSuperSet.txt","w");
	fflush(fpSuperSet);

	fpAllRev = fopen("AllPartAllRevFile.txt","w");
	fflush(fpAllRev);

	fpTemp = fopen("GarbageDataFile.log1","w");
	fflush(fpTemp);

	fpGrpChilRel = fopen("GroupChildRelation.txt","w");
	fflush(fpGrpChilRel);

	fpGrpChilCnt = fopen("GroupChildCount.txt","w");
	fflush(fpGrpChilCnt);

	LhRhfp=fopen("LhRhPartDet.txt","a+");
	fflush(LhRhfp);

	TCPartOutPutFileErrS=nlsStrDup(OutputFileNameS);
	strtok(TCPartOutPutFileErrS,".");
	nlsStrCat(TCPartOutPutFileErrS,"_err.log");

	printf("\n TCPartOutPutFileErrS :%s\n",TCPartOutPutFileErrS); fflush(stdout);

	fperr=fopen(TCPartOutPutFileErrS,"w");
	fflush(fperr);

	//printf("\n\n Enter Inside...program....\n"); fflush(stdout);

	dbScopeStr = low_set_create_str(2);
	dbScopeBkp = low_set_create_str(2);

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	//for (ii=0;ii<setSize(dbScopeBkp) ; ii++)
	//{
	//	docobjst=low_set_get(dbScopeBkp,ii);
	//	//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	//}

	low_set_add_str_unique(dbScopeBkp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScopeBkp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	printf("\n DB pref check -after...:");fflush(stdout);
	for (ii=0;ii<low_set_size(dbScopeBkp) ; ii++)
	{
		docobjst=low_set_get(dbScopeBkp,ii);
		printf("\t[%s]",docobjst);fflush(stdout);
	}
	printf("\n\n");fflush(stdout);

	low_set_add_str_unique(dbScopeStr, "supprod");
	low_set_add_str_unique(dbScopeStr, "suhprod");
	low_set_add_str_unique(dbScopeStr, "sujprod");
	low_set_add_str_unique(dbScopeStr, "sulprod");


	t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProeObjectNameS));
	t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProeObjectSequenceS));
	t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProeObjectOwnerNameS));
	t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProeObjectOwnerDirS));
	t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDataItemSO,mfail));

	printf("\n\n 1--Number of ProE Objects: %d",setSize(ProeDataItemSO)); fflush(stdout);

	if(setSize(ProeDataItemSO)==0)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProeObjectNameS));
		t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProeObjectSequenceS));
		t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProeObjectOwnerNameS));
		t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerDirName",ProeObjectOwnerDirS));
		t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeDataItemSO,mfail));

		printf("\n\n 2--Number of ProE Objects: %d",setSize(ProeDataItemSO)); fflush(stdout);

		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

		if(setSize(ProeDataItemSO)==0)
		{
			t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProeObjectNameS));
			t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProeObjectSequenceS));
			t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProeObjectOwnerNameS));
			t5CheckMfail(QueryWhere("ProInst",ProeObjSqlPtr,&ProeDataItemSO,mfail));

			printf("\n 3--Number of ProE Instance Objects: %d",setSize(ProeDataItemSO)); fflush(stdout);
		}
	}

	if(setSize(ProeDataItemSO)==0)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"RelativePath",ProeObjectNameS));
		t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Sequence",ProeObjectSequenceS));
		t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"OwnerName",ProeObjectOwnerNameS));
		t5CheckMfail(QueryWhere("ProInst",ProeObjSqlPtr,&ProeDataItemSO,mfail));
		printf("\n 4--Number of ProE Instance Objects: %d",setSize(ProeDataItemSO)); fflush(stdout);
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
		if(setSize(ProeDataItemSO)==0)
		{
			printf("\n There are no ProE Objects with Given Input"); fflush(stdout);
			goto EXIT;
		}
	}

	//printf("\n Entering in to Loop for fetching the Data Items ....\n"); fflush(stdout);

	//CODE For Getting the Data Item Files
	for(DataItem=0;DataItem<setSize(ProeDataItemSO);DataItem++)
	{
		NewProeDataItemObjP=setGet(ProeDataItemSO,DataItem);

		t5CheckDstat(objCopy(&DataItemObjP,NewProeDataItemObjP));

		t5CheckDstat(objGetAttribute(DataItemObjP,"RelativePath",&RelativePathS));
		if(RelativePathDup!=NULL){nlsStrFree(RelativePathDup);RelativePathDup = NULL;}
		RelativePathDup=nlsStrDup(RelativePathS);
		printf("\n RelativePathDup is :%s \n",RelativePathDup); fflush(stdout);

		t5CheckDstat(objGetAttribute(DataItemObjP,"Class",&DataItemClassNameDupS));
		if(DataItemClassNameS!=NULL){nlsStrFree(DataItemClassNameS);DataItemClassNameS = NULL;}
		DataItemClassNameS=nlsStrDup(DataItemClassNameDupS);
		//printf("\n Data Item Class Name is:%s \n",DataItemClassNameS); fflush(stdout);

		t5CheckDstat(objGetAttribute(DataItemObjP,"OBID",&AssyFileOBIDS));
		if(AssyFileOBIDDup!=NULL){nlsStrFree(AssyFileOBIDDup);AssyFileOBIDDup = NULL;}
		AssyFileOBIDDup=nlsStrDup(AssyFileOBIDS);
		//printf("\n AssyFileOBIDDup :%s \n",AssyFileOBIDDup); fflush(stdout);

		OBIDsetS=NULL;
		OBIDsetS=setStrCreate(1);

		if(!nlsStrCmp(DataItemClassNameS,"ProPrtI"))
		{
			//Calling for ProePartInstance Function...
			ProePartInstanceObjP=NULL;
			ProePartInstanceObjP=DataItemObjP;
			DataItemObjP=ProePartInstanceObjP;

			//printf("\n 4..Calling for Function: GetProePartInstOnlyExp2..."); fflush(stdout);
			t5CheckMfail(GetProePartInstOnlyExp2(DataItemObjP,RelativePathDup,OBIDsetS,fp,fp1,fperr,mfail,DataItemClassNameS,&level));
		}
		else if(!nlsStrCmp(DataItemClassNameS,"ProAsm"))
		{
			setAddStr(OBIDsetS,AssyFileOBIDDup);
			//	printf("\n Calling for Function: GetProeAsmExpOnly2...\n"); fflush(stdout);
			t5CheckMfail(GetProeAsmExpOnly2(DataItemObjP,RelativePathDup,DataItemClassNameS,OBIDsetS,fp,fp1,fperr,mfail,DataItemClassNameS,&level));
		}
		else if (!nlsStrCmp(DataItemClassNameS,"ProAsmI"))
		{
			setAddStr(OBIDsetS,AssyFileOBIDDup);
			//printf("\n Calling for Function: GetProeAsmIExpOnly2...\n"); fflush(stdout);
			t5CheckMfail(GetProeAsmIExpOnly2(DataItemObjP,RelativePathDup,DataItemClassNameS,OBIDsetS,fp,fp1,fperr,mfail,DataItemClassNameS,&level));
		}
		else if(!nlsStrCmp(DataItemClassNameS,"ProDrw") || !nlsStrCmp(DataItemClassNameS,"ProPrt"))
		{
			//Calling for ProDrw/ProPrt Function...

			ProePartInstanceObjP=NULL;
			ProePartInstanceObjP=DataItemObjP;
			DataItemObjP=ProePartInstanceObjP;

			//printf("\n Calling for Function: GetProePartInstOnlyExp2...\n"); fflush(stdout);
			//t5CheckMfail(GetProePartAndDrwExp(DataItemObjP,RelativePathDup,OBIDsetS,fp,fperr,mfail));
			//t5CheckMfail(GetFullPathJTExp(DataItemObjP,DataItemObjP,fp,fperr,mfail));

			t5CheckMfail(GetProeAsmExpOnly2(DataItemObjP,RelativePathDup,DataItemClassNameS,OBIDsetS,fp,fp1,fperr,mfail,DataItemClassNameS,&level));
		}
		//else
		//{
		//	printf("\nexceptional class name ::%s \n",DataItemClassNameS); fflush(stdout);
		//}
	}

	fclose(fp);
	fclose(fp1);

	printf("\n Value 1 :%d Vaule2 :%d",dstat,*mfail); fflush(stdout);
	if((dstat==OKAY)&&(*mfail==OKAY))
	{
		fpread=open(tempFileName,O_RDONLY);
		fpwrite=open(OutputFileNameS,O_WRONLY|O_CREAT,0700);
		printf("\n Val:%d,Val:%d",fpread,fpwrite); fflush(stdout);

		while(lines=read(fpread,buffer,1024))
		{
			write(fpwrite,buffer,lines);
		}
		close(fpread);
		close(fpwrite);

		fpread=open(tempFileName1,O_RDONLY);
		fpwrite=open(OutputFileNameS1,O_WRONLY|O_CREAT,0700);

		while(lines=read(fpread,buffer,1024))
		{
			write(fpwrite,buffer,lines);
		}
		close(fpread);
		close(fpwrite);

		strcpy(tempdfname,"rm -f ");
		strcat(tempdfname,tempFileName);
		sret=system(tempdfname);

		strcpy(tempdfname,"rm -f ");
		strcat(tempdfname,tempFileName1);
		sret=system(tempdfname);
		printf("\nReturn frm System:%d",sret); fflush(stdout);
	}
	else
	{
		fprintf(fperr,"%s","Could Not Generate Output File, dstat / mfail Not OKAY"); fflush(fperr);
	}

	printf("\n\n-----------------------Calling for Function: GetProeAndUsesPartMultiLevelSuperSetBom-----------------------\n"); fflush(stdout);
	t5CheckMfail(GetProeAndUsesPartMultiLevelSuperSetBom(DataItemObjP,RelativePathDup,DataItemClassNameS,OBIDsetS,fpTemp,fpTemp,fperr,mfail,DataItemClassNameS,&level2,"-"));

	fclose(fperr);
	fclose(pfile);

	fclose(fpSuperSet);
	fclose(fpGrpChilRel);
	fclose(fpGrpChilCnt);

	if(LhRhfp)
	{
		fclose(LhRhfp);LhRhfp = NULL;
	}

CLEANUP:
	//printf("\n CLEANUP at JtAndProeGetDataItems .\n"); fflush(stdout);

	t5PrintCleanUpModName;
	t5FreeSetOfObjects(ProeDataItemSO);

EXIT:
	//printf("\n EXIT at JtAndProeGetDataItems..\n"); fflush(stdout);
	t5CheckDstatAndReturn;
};
status t5SortBOMObjsByDate(SetOfObjects *itemObjs,SetOfObjects *relObjs,integer* mfail)
{
	status dstat = OKAY;
	char *mod_name = "t5SortBOMObjsByDate";
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpRelObjs = NULL;
	ObjectPtr relObj = NULL;
	ObjectPtr itemObj = NULL;
	ObjectPtr relTObj = NULL;
	ObjectPtr itemTObj = NULL;
	integer count = 0;
	integer cmpCount = 0;
	ObjectPtr tmpRelObj = 0;
	string curCreDate = NULL;
	string tmpcurCreDate = NULL;
	string cmpCreDate = NULL;
	string tmpcmpCreDate = NULL;
	string DocOwnerName = NULL;
	string DocOwnerNameDup = NULL;
	string DocLCS = NULL;
	string DocLCSDup = NULL;
	string DataItemDisplNm = NULL;
	string DataItemDisplNmDup = NULL;
	*mfail = USC_OKAY;

	printf("\n\t In t5SortBOMObjsByDate Functn:::: setSize(*itemObjs):%d setSize(*relObjs):%d \n",setSize(*itemObjs),setSize(*relObjs)); fflush(stdout);

	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		/* initalizing sorted object set */
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		//objDump(itemObj);

		t5CheckDstat(objGetAttribute(itemObj,"OwnerName",&DocOwnerName));
		DocOwnerNameDup=nlsStrDup(DocOwnerName);
		t5CheckDstat(objGetAttribute(itemObj,"LifeCycleState",&DocLCS));
		DocLCSDup=nlsStrDup(DocLCS);

		if (setSize(*itemObjs) > 1) //Added on 18.02.2019
		{
			//if(nlsStrStr(DocOwnerNameDup,"Vault")==NULL)
			if((nlsStrStr(DocOwnerNameDup,"Vault")==NULL) || (nlsStrCmp(DocLCSDup,"LcsWorking")==0)) //Modified on 05.10.2018
			{
				t5CheckDstat(objGetAttribute(itemObj,"DisplayedName",&DataItemDisplNm));
				if(!nlsIsStrNull(DataItemDisplNm))
				{
					DataItemDisplNmDup=nlsStrDup(DataItemDisplNm);
				}
				printf("\n\t DataItemDisplNmDup:%s  DocOwnerNameDup:%s , hence continuing to previous object....",DataItemDisplNmDup,DocOwnerNameDup); fflush(stdout);
				continue;
			}
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		/* get mainSerial */
		if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
		tmpcurCreDate = nlsStrDup(curCreDate);

		/* compare mainSerial with the new set of objects */
		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
			tmpcmpCreDate = nlsStrDup(cmpCreDate);

			/////if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) <= 0)		//commented on 13.03.3017 by rrr
			if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) >= 0)				//Added on 13.03.3017 by rrr	for loader created part revs on date like 254703140385 in PLM
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}
	/* free memory and assign to new set sorted objects */
	objDisposeAll(*itemObjs); *itemObjs = NULL;
	objDisposeAll(*relObjs); *relObjs = NULL;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}

status t5SortBOMObjsAndRemoveDuplicates(SetOfObjects *itemObjs,SetOfObjects *itemRelObjs, SetOfStrings *SortedUsesPartQtySOS ,string AssyPartno, integer* mfail)
{
	status dstat = OKAY;
	char *mod_name = "t5SortBOMObjsByDate";
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpitemObjs2 = NULL;
	ObjectPtr itemObj2 = NULL;
	ObjectPtr itemObj = NULL;
	ObjectPtr itemTObj2 = NULL;
	ObjectPtr itemTObj = NULL;
	integer count = 0;
	integer cmpCount = 0;
	ObjectPtr tmpitemObj2 = 0;
	ObjectPtr tmpitemRelObj2 = 0;
	string curPartno = NULL;
	string tmpcurPartno = NULL;
	string cmpPartno = NULL;
	string tmpcmpPartno = NULL;
	string DocOwnerName = NULL;
	string DocOwnerNameDup = NULL;
	string DataItemDisplNm = NULL;
	string DataItemDisplNmDup = NULL;
	string PartQty = NULL;
	string tmpcmpPartQty = NULL;
	string cmpPartQty = NULL;
	string partColQtyStr = NULL;
	int partCountFlag = 0;
	int partColQty = 0;
	*mfail = USC_OKAY;

	PartQty = nlsStrAlloc(100);

	for(count=0; count<setSize(*itemObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		itemObj2 = setGet(*itemObjs, count);

		/* initalizing sorted object set */
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(itemObj2, &tmpitemObjs2)) goto CLEANUP;
			continue;
		}

		t5CheckDstat(objGetAttribute(itemObj,"OwnerName",&DocOwnerName));
		DocOwnerNameDup=nlsStrDup(DocOwnerName);
		if(nlsStrStr(DocOwnerNameDup,"Vault")==NULL)
		{
			t5CheckDstat(objGetAttribute(itemObj,"DisplayedName",&DataItemDisplNm));
			if(!nlsIsStrNull(DataItemDisplNm))
			{
				DataItemDisplNmDup=nlsStrDup(DataItemDisplNm);
			}
			printf("\n\t DataItemDisplNmDup:%s  DocOwnerNameDup:%s , hence continuing to previous object....",DataItemDisplNmDup,DocOwnerNameDup); fflush(stdout);
			continue;
		}

		if(dstat = objCopy(&itemTObj2, itemObj2)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		/* get PartNumber */
		if(dstat = objGetAttribute(itemObj2, PartNumberAttr, &curPartno)) goto CLEANUP;
		tmpcurPartno = nlsStrDup(curPartno);

		/* compare PartNumber with the new set of objects */
		partCountFlag = 0;
		partColQty = 0;
		//tmpcmpPartQty = 0;
		for(cmpCount=0; cmpCount<setSize(tmpitemObjs2); cmpCount++)
		{
			tmpitemObj2 = setGet(tmpitemObjs2, cmpCount);

			tmpitemRelObj2 = setGet(*itemRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpitemObj2, PartNumberAttr, &cmpPartno)) goto CLEANUP;
			tmpcmpPartno = nlsStrDup(cmpPartno);

			/////if(nlsStrCmp(tmpcurPartno,tmpcmpPartno) <= 0)		//commented on 13.03.3017 by rrr
			if(nlsStrCmp(tmpcurPartno,tmpcmpPartno) >= 0)				//Added on 13.03.3017 by rrr	for loader created part revs on date like 254703140385 in PLM
			{
				if(!nlsIsStrNull(tmpcmpPartQty))
				{
					nlsStrFree(tmpcmpPartQty);
					tmpcmpPartQty = NULL;
				}
				if(dstat = objGetAttribute(tmpitemRelObj2, QuantityAttr, &cmpPartQty)) goto CLEANUP;
				tmpcmpPartQty = nlsStrDup(cmpPartQty);

				partCountFlag ++;

				partColQty=partColQty+atoi(tmpcmpPartQty);

				if (partCountFlag == 1)
				{
					low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				}
			}
		}
		if (partCountFlag > 1)
		{
			partColQtyStr = NULL;
			partColQtyStr = nlsStrAlloc(5);
			sprintf(partColQtyStr, "%d", partColQty );

			nlsStrCpy(PartQty,"");
			nlsStrCpy(PartQty,tmpcurPartno);
			nlsStrCpy(PartQty,",");
			nlsStrCpy(PartQty,partColQtyStr);
			low_set_insrt_str(*SortedUsesPartQtySOS,0,PartQty);
		}
	}
	/* free memory and assign to new set sorted objects */
	objDisposeAll(*itemObjs); *itemObjs = NULL;

	*itemObjs = tmpItemObjs;
	//*itemObjs = tmpitemObjs2;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
//////////////////////////////////////////////////Multi-lelvel Uses Part //////////////////////////////
status GetMultiLevelExplosionUsesPart(ObjectPtr PartObjP,string InputPart,string InpPartRev,string InpPartSeq,string BOMConfigContextS,int *GUsesLevel,integer* mfail)
{
	t5MethodInit("GetMultiLevelExplosionUsesPart");

	int ChildCount=0;
	int w = 0;
	int LHRHFlag = 0;

	SetOfObjects TCPartObjPLRSO = NULL ;
	SetOfObjects TCPartObjPLRRelSO = NULL ;
	SetOfObjects PartResultSO = NULL ;
	SetOfObjects PartResultRelSO = NULL ;
	SetOfObjects NamedBLSO = NULL;
	SetOfObjects hasRHItmMster = NULL;
	SetOfObjects hasRHTCPart = NULL;
	SetOfObjects hasRHTCPartRelObj = NULL;
	SetOfObjects itemObjs = NULL;
	SetOfObjects relObjs = NULL;
	SetOfObjects PartMasterSet = NULL;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOPLR=NULL;
	ObjectPtr ChildPartObjP=NULL;
	ObjectPtr NamedBLPtr=NULL;
	ObjectPtr hasRHItmM=NULL;
	ObjectPtr genContext=NULL;
	ObjectPtr CtxtObj=NULL;
	ObjectPtr busItemsRight=NULL;
	ObjectPtr genContext1=NULL;
	ObjectPtr CtxtObj1=NULL;
	ObjectPtr PartMstr=NULL;

	SqlPtr  InputTCPartSqlPtr = NULL;

	string ChildPartNumberDupS=NULL;
	string ChildPartNumberS=NULL;
	string ChildPartRevisionDupS=NULL;
	string ChildPartRevisionS=NULL;
	string ChildPartSequenceDupS=NULL;
	string ChildPartSequenceS=NULL;
	string ChildPartOwnerNameDupS=NULL;
	string ChildPartOwnerNameS=NULL;
	string DescriptionDupS=NULL;
	string DescriptionS=NULL;
	string PartTypeDupS=NULL;
	string PartTypeS=NULL;
	string LhRh_type=NULL;
	string LeftRhDupS=NULL;
	string LeftRhS=NULL;
	//string LhRHErrPath = "LHRHErrorParts.txt" ;
	//string matvfilename=NULL;
	//string OrgOutFileNames=NULL;
	//string OrgLhRhOutFileNames=NULL;

	//FILE	*Orgfp	= NULL;
	//FILE	*OrgLhRhfp	= NULL;
	//FILE	*LhRHErr	= NULL;

	//OrgOutFileNames = nlsStrAlloc(100);
	//OrgLhRhOutFileNames = nlsStrAlloc(100);

	/*sprintf(OrgOutFileNames,"%s.txt",InputPart);
	sprintf(OrgLhRhOutFileNames,"%s_LHRH.txt",InputPart);

	Orgfp=fopen(OrgOutFileNames,"a+");
	fflush(Orgfp);

	OrgLhRhfp=fopen(OrgLhRhOutFileNames,"a+");
	fflush(OrgLhRhfp);

	LhRHErr=fopen(LhRHErrPath,"a+");
    fflush(LhRHErr);*/

	//Code For Handling Assembly and Component in the Collection
	if(nlsStrCmp(BOMConfigContextS,"Latest From WIP And Release Vaults")==0 || nlsStrCmp(BOMConfigContextS,"Latest From Release Vault Only")==0 || nlsStrCmp(BOMConfigContextS,"Latest From WIP Vault Only")==0)
	{
		printf("\n Inside Normal Explosion");

		t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InputPart));
		t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RevisionAttr,InpPartRev));
		t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,SequenceAttr,InpPartSeq));
		t5CheckMfail(QueryWhere3(PartClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&PartResultSO,mfail));

		if(setSize(PartResultSO)==0)
		{
			if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
			t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InputPart));
			t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RevisionAttr,InpPartRev));
			t5CheckDstat(oiSqlWhereAND(InputTCPartSqlPtr));
			t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,SequenceAttr,InpPartSeq));
			t5CheckMfail(QueryWhere3(PartClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&PartResultSO,mfail));
			if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

			if(setSize(PartResultSO)==0)
			{
				goto CLEANUP;
			}
		}

		if(setSize(PartResultSO)==1)
		{
			TCPartObjP = setGet(PartResultSO,0);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&ChildPartNumberDupS));
			ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&ChildPartRevisionDupS));
			ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&ChildPartSequenceDupS));
			ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeDupS));
			PartTypeS=nlsStrDup(PartTypeDupS);

			printf("\n  TCPart--ChildPartNumberS: %s Rev:%s %s   PartTypeS: %s",ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS,PartTypeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&DescriptionDupS));
			DescriptionS=nlsStrDup(DescriptionDupS);
			DescriptionS=low_strssra(DescriptionS,"\n"," ");
			DescriptionS=low_strssra(DescriptionS,"^"," ");

			/*matvfilename=nlsStrAlloc(100);
			nlsStrCpy(matvfilename,ChildPartNumberS);
			nlsStrCat(matvfilename,"_Verfiy.mat.txt");

			fprintf(Orgfp,"0");	//(level);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"%s",ChildPartNumberS);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"%s",ChildPartRevisionS);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"%s",ChildPartSequenceS);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"%s",DescriptionS);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"1^ASSY_TYPE_UA^");//(QuantityS);*/

			t5CheckMfail(ExpandObject2(ItemRevClass,TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&TCPartObjPLRSO,&TCPartObjPLRRelSO,mfail)) ;
			if(SetFlagforScope(TCPartObjPLRSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandObject2(ItemRevClass,TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&TCPartObjPLRSO,&TCPartObjPLRRelSO,mfail)) ;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			if(setSize(TCPartObjPLRSO) >0)
			{
				MasterObjOPLR = setGet(TCPartObjPLRSO,0);
			}

			if(dstat=ExpandObject5(PWLPRlClass,TCPartObjP,"HasWeldedParts",SC_SCOPE_OF_SESSION,&PartMasterSet,mfail))goto EXIT;
			if(SetFlagforScope(PartMasterSet)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if(dstat=ExpandObject5(PWLPRlClass,TCPartObjP,"HasWeldedParts",SC_SCOPE_OF_SESSION,&PartMasterSet,mfail))goto EXIT;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			printf("\n\t NO. of Part Master (HasWeldedParts): %d",setSize(PartMasterSet));fflush(stdout);

			t5CheckDstat(objGetAttribute(MasterObjOPLR,t5LeftRhAttr,&LeftRhDupS));
			LeftRhS=nlsStrDup(LeftRhDupS);
			printf("\n LeftRhS[%s]",LeftRhS);fflush(stdout);

			/*if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0)
			{
			fprintf(Orgfp,"%s",PartTypeS);
			fprintf(Orgfp,"^");
			fprintf(Orgfp,"%s\n","RH");
			}
			else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0)
			{
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n","LH");
			}
			else if(setSize(PartMasterSet) >1 )
			{
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n","Welded");
			}
			else
			{
				fprintf(Orgfp,"%s\n",PartTypeS);
			}

			fprintf(OrgLhRhfp,"%s","0");
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s","RH");
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s",DescriptionS);
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s","1");
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s","ASSY_TYPE_UA");
			fprintf(OrgLhRhfp,"^");
			fprintf(OrgLhRhfp,"%s\n",PartTypeS);*/

			if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0 )
			{
				t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
				if(SetFlagforScope(hasRHItmMster)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}

				if(setSize(hasRHItmMster) >0)
				{
					hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
					{
						t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
						if(SetFlagforScope(hasRHTCPart)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
					}
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 222 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				if(setSize(hasRHTCPart) >0)
				{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(busItemsRight)
					{
						if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
						if(SetFlagforScope(itemObjs)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
					}
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
					LhRh_type = NULL;
					LhRh_type=nlsStrAlloc(50);
				}

				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}
				else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;

				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
				DescriptionS    =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				DescriptionS=low_strssra(DescriptionS,"^"," ");
				printf("\n  TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
				PartTypeS    =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

				/*fprintf(OrgLhRhfp,"%s","1");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",LeftRhS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",DescriptionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s","1");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",LhRh_type);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s\n",PartTypeS);

				fprintf(Orgfp,"%s","1");
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartNumberS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartRevisionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartSequenceS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",DescriptionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s","1");
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",LhRh_type);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n",LeftRhS);*/

				LHRHFlag = 1;
			}
			else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0 )
			{
				t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
				if(SetFlagforScope(hasRHItmMster)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOPLR,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}

				if(setSize(hasRHItmMster) >0)
				{
					hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					//t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
					{
						t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
						if(SetFlagforScope(hasRHTCPart)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							t5CheckMfail(ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
					}
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 333 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				if(setSize(hasRHTCPart) >0)
				{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));

					if(busItemsRight)
					{
						if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
						if(SetFlagforScope(itemObjs)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}
					}
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
					LhRh_type = NULL;
					LhRh_type=nlsStrAlloc(50);
				}
				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
				DescriptionS    =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				DescriptionS=low_strssra(DescriptionS,"^"," ");
				printf("\n  TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
				PartTypeS    =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

				/*fprintf(OrgLhRhfp,"%s","1");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",LeftRhS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",DescriptionS);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s","1");
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s",LhRh_type);
				fprintf(OrgLhRhfp,"^");
				fprintf(OrgLhRhfp,"%s\n",PartTypeS);


				fprintf(Orgfp,"%s","1");
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartNumberS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartRevisionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",ChildPartSequenceS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",DescriptionS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s","1");
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",LhRh_type);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s",PartTypeS);
				fprintf(Orgfp,"^");
				fprintf(Orgfp,"%s\n",LeftRhS);*/
				LHRHFlag = 1;
			}

			////////////////////// Welded Parts ///////////////////////////////////////////
			if(setSize(PartMasterSet)>0)
			{
				for (w=0;w<setSize(PartMasterSet) ;w++ )
				{
					printf("\n Inside setSize(PartMasterSet) [%d]\n",setSize(PartMasterSet));fflush(stdout);
					genContext = NULL;
					CtxtObj = NULL;

					if(LhRh_type == NULL)
					{
						LhRh_type = NULL;
						LhRh_type=nlsStrAlloc(50);
					}
					PartMstr=setGet(PartMasterSet,w);
					t5CheckMfail(IntSetUpContext(objClass(PartMstr),PartMstr,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));

					t5CheckMfail(ExpandRelationWithCtxt("ItemRev", PartMstr, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
					if(SetFlagforScope(hasRHTCPart)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						t5CheckMfail(ExpandRelationWithCtxt("ItemRev", PartMstr, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					printf("\n calling ExpSetForUses hasRHTCPart 222 [%d]\n",setSize(hasRHTCPart));fflush(stdout);

					if(setSize(hasRHTCPart) >0)
					{
						busItemsRight = low_set_get(hasRHTCPart,0);
						t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
						t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
						//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
						//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

						t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
						t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
						t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
						//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));
						if(busItemsRight)
						{
							if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
							if(SetFlagforScope(itemObjs)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}
						}
						printf("\n calling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
					}

					if(setSize(itemObjs)==0)
					{
						nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
					}
					else
					{
						nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
					}

					ChildPartNumberDupS=NULL;
					ChildPartNumberS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
					ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
					printf("\n  TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

					ChildPartRevisionDupS=NULL;
					ChildPartRevisionS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
					ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
					printf("\n  TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

					ChildPartSequenceDupS=NULL;
					ChildPartSequenceS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
					ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
					printf("\n  TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

					DescriptionDupS =NULL;
					DescriptionS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
					DescriptionS=nlsStrDup(DescriptionDupS);
					DescriptionS=low_strssra(DescriptionS,"\n"," ");
					DescriptionS=low_strssra(DescriptionS,"^"," ");
					printf("\n  TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

					PartTypeDupS =NULL;
					PartTypeS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
					PartTypeS=nlsStrDup(PartTypeDupS);
					printf("\n  TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

					/*fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartNumberS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartRevisionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",ChildPartSequenceS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",DescriptionS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s","1");
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",LhRh_type);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s",PartTypeS);
					fprintf(Orgfp,"^");
					fprintf(Orgfp,"%s\n","WeldedParts");*/
				}
			}

			//UsesPrtSOS=NULL;
			//UsesPrtSOS=setStrCreate(1);

			printf("\n Calling the Function for GetTCPartInfoForContextBOMViewMultiSingleExplosion in ContextBOMViewTCPartMultiExplosion\n"); fflush(stdout);
			t5CheckMfail(GetTCPartInfoForContextBOMViewMultiSingleExplosion(TCPartObjP,BOMConfigContextS, GUsesLevel,/*UsesPrtSOS, Orgfp,OrgLhRhfp,matvfilename,LhRHErr, */ mfail));
		}
		if(setSize(PartResultSO)>1)
		{
			printf("\n This is not Possible Use Case now \n");
			goto EXIT;
		}
	}
	else
	{
		printf("\n Inside Named Baseline Explosion");
		t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
		t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,BaselineNameAttr,BOMConfigContextS));

		t5CheckMfail(QueryWhere3(NamedBlClass,InputTCPartSqlPtr,1,SC_SCOPE_OF_SESSION,&NamedBLSO,mfail));
		if(setSize(NamedBLSO)==0) goto CLEANUP;

		if(setSize(NamedBLSO)>=1)
		{
			NamedBLPtr=setGet(NamedBLSO,0);

			t5CheckMfail(ExpandObject2(NBlToWIClass,NamedBLPtr,"WorkItemsMembersOfNamedBl",SC_SCOPE_OF_SESSION,&PartResultSO,&PartResultRelSO,mfail));
			if(SetFlagforScope(PartResultSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandObject2(NBlToWIClass,NamedBLPtr,"WorkItemsMembersOfNamedBl",SC_SCOPE_OF_SESSION,&PartResultSO,&PartResultRelSO,mfail));
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			for(ChildCount=0;ChildCount<setSize(PartResultSO);ChildCount++)
			{
				printf("\n Count is222:%d \n",ChildCount);

				ChildPartObjP=setGet(PartResultSO,ChildCount);

				t5CheckDstat(objGetAttribute(ChildPartObjP,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				t5CheckDstat(objGetAttribute(ChildPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
				ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);
				printf("\n  TC Part ChildPartOwnerNameS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartOwnerNameS); fflush(stdout);
			}
		}
	}

	////fclose(fp);
	//fclose(Orgfp);

CLEANUP:
	printf("\nCLEANUP GetMultiLevelExplosionUsesPart\n"); fflush(stdout);
	t5PrintCleanUpModName;

EXIT:
	t5CheckDstatAndReturn;
}
//From TC Part Getting the Visualization Files...
status GetTCPartInfoForContextBOMViewMultiSingleExplosion(ObjectPtr TCPartObjP,string BOMConfigContextS, int *GUsesLevel,/* SetOfStrings UsesPartsSOS, FILE* OrgFp,FILE* OrgLhRhFp,string matverifyfilename,FILE* LhRHErr,*/ integer* mfail )
{
	int MultiLevel=99;
	int ChildCount=0;
	/*int w=0;
	int z=0;
	int i=0;
	int relSize=0;
	int qty=0;
	int sizeoftable = 0;
	int ChildMQPart = 0;*/
	//int t = 0;
	int PrtLevel = 0;
	//int RecChkFlag = 0;
	int foundmatch2 = 0;
	int cnt = 0;

	//char decimalQty[10];

	//FILE* matfp=NULL;
	//FILE* matverifyfp=NULL;

	SetOfObjects partMasterRelSO = NULL ;
	SetOfObjects ChildPartsSO = NULL ;
	SetOfObjects ChildRelPartsSO = NULL ;
	SetOfObjects ChildPartsSOCmp = NULL ;
	SetOfObjects ChildRelPartsSOCmp = NULL ;
	SetOfObjects partMasterSO = NULL ;
	/*SetOfObjects PartMasterSet = NULL;
	SetOfObjects MultyQtyRelPartSO = NULL;
	SetOfObjects hasRHItmMster = NULL;
	SetOfObjects hasRHTCPart = NULL;
	SetOfObjects hasRHTCPartRelObj = NULL;
	SetOfObjects itemObjs = NULL;
	SetOfObjects relObjs = NULL;

	ObjectPtr genContext=NULL;
	ObjectPtr CtxtObj=NULL;
	ObjectPtr genContext1=NULL;
	ObjectPtr CtxtObj1=NULL;*/
	ObjectPtr GenContextObjP=NULL;
	ObjectPtr ContextObjP=NULL;
	ObjectPtr ChildPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr ChildRelObjP=NULL;
	/*ObjectPtr PartMstr=NULL;
	ObjectPtr ChildRelOP=NULL;
	ObjectPtr RelQtyPartObjP = NULL ;
	ObjectPtr busItemsRight = NULL;
	ObjectPtr hasRHItmM = NULL;
	ObjectPtr revEffObj = NULL;*/
	ObjectPtr UsesDataItemObjP = NULL;

	SetOfStrings Levels= NULL;
	SetOfStrings type= NULL;

	//string ChildDisplayNm = NULL;
	//string ChildDisplayNmDup = NULL;
	string ParentNo = NULL;
	string ParentNoDup = NULL;
	string ParentNoLeftDup = NULL;
	string ChildPartNumberDupS = NULL;
	string ChildPartNumberS = NULL;
	string ChildPartRevisionDupS = NULL;
	string ChildPartRevisionS = NULL;
	string ChildPartSequenceDupS = NULL;
	string ChildPartSequenceS = NULL;
	string ParentPart = NULL;
	string ParentPartLevel = NULL;
	string level = NULL;
	string p_type = NULL;
	string DescriptionDupS = NULL;
	string DescriptionS = NULL;
	string QuantityDupS = NULL;
	string QuantityS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string PartOrgIdDupS = NULL;
	string PartOrgIdS = NULL;
	string SuppressedValStr = NULL;
	string InstancePrtRevSeq = NULL;
	/*string matfilename = NULL;
	string QuantityDup = NULL;
	string Quantity  =  NULL;
	string LeftPartNumberDupS = NULL;
	string RightPartNumberDupS = NULL;
	string LeftPartNumberS = NULL;
	string RightPartNumberS = NULL;
	string ChildRelClassNameDupS = NULL;
	string ChildRelClassNameS = NULL;
	string LhRh_type = NULL;
	string Matrix11Dup = NULL;
	string Matrix11 = NULL;
	string Matrix12Dup = NULL;
	string Matrix12 = NULL;
	string Matrix13Dup = NULL;
	string Matrix13 = NULL;
	string Matrix14Dup = NULL;
	string Matrix14 = NULL;
	string Matrix21Dup = NULL;
	string Matrix21 = NULL;
	string Matrix22Dup = NULL;
	string Matrix22 = NULL;
	string Matrix23Dup = NULL;
	string Matrix23 = NULL;
	string Matrix24Dup = NULL;
	string Matrix24 = NULL;
	string Matrix31Dup = NULL;
	string Matrix31 = NULL;
	string Matrix32Dup = NULL;
	string Matrix32 = NULL;
	string Matrix33Dup = NULL;
	string Matrix33 = NULL;
	string Matrix34Dup = NULL;
	string Matrix34 = NULL;
	string Matrix41Dup = NULL;
	string Matrix41 = NULL;
	string Matrix42Dup = NULL;
	string Matrix42 = NULL;
	string Matrix43Dup = NULL;
	string Matrix43 = NULL;
	string Matrix44Dup = NULL;
	string Matrix44 = NULL;
	string RelnObidDup=NULL;
	string ChildPartMQRelTMatrix11S = NULL;
	string ChildPartMQRelTMatrix12S = NULL;
	string ChildPartMQRelTMatrix13S = NULL;
	string ChildPartMQRelTMatrix14S = NULL;
	string ChildPartMQRelTMatrix21S = NULL;
	string ChildPartMQRelTMatrix22S = NULL;
	string ChildPartMQRelTMatrix23S = NULL;
	string ChildPartMQRelTMatrix24S = NULL;
	string ChildPartMQRelTMatrix31S = NULL;
	string ChildPartMQRelTMatrix32S = NULL;
	string ChildPartMQRelTMatrix33S = NULL;
	string ChildPartMQRelTMatrix34S = NULL;
	string ChildPartMQRelTMatrix41S = NULL;
	string ChildPartMQRelTMatrix42S = NULL;
	string ChildPartMQRelTMatrix43S = NULL;
	string ChildPartMQRelTMatrix44S = NULL;
	string LeftPartObjOBIDS = NULL ;
	string RightPartMstrObjOBIDS11 = NULL ;
	string levelStr = NULL;
	string RelnObid = NULL;
	string ChildPartQuantityS  = NULL;
	string Instnamedup = NULL;
	string Instname = NULL;
	string newInstancename = NULL;
	string indexS = NULL;
	string indexDupS = NULL;
	string LeftRhDupS = NULL;
	string LeftRhS = NULL;

	SqlPtr MultyQtySqlPtr = NULL ;*/

	SuppressedValStr = nlsStrAlloc(10);


	t5MethodInit("GetTCPartInfoForContextBOMViewMultiSingleExplosion");

	// setting of session context preferences
	t5CheckMfail(SetUpContext(objClass(TCPartObjP),TCPartObjP,&GenContextObjP,mfail));

	// Get the configuration context object from the general context.
	t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,GenContextObjP,&ContextObjP,mfail));

	// Set the option as "Latest Revision with State" in the context object
	t5CheckDstat(objSetAttribute(ContextObjP,ExpandOnRevisionAttr, "PscLastRev"));
	t5CheckDstat(objSetAttribute(ContextObjP,"NavigateViewBitPos","0"));
	t5CheckDstat(objSetAttribute(ContextObjP,"CfgItemId","GlobalCtxt"));
	t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNetworkAttr,"EAS"));
	t5CheckDstat(objSetAttribute(ContextObjP,NavigateViewNameAttr,"ERC"));
	t5CheckDstat(objSetAttribute(ContextObjP,PsmExpIncludeZeroQtyAttr,"+"));
	//t5CheckDstat(objSetAttribute(ContextObjP,t5ExpIncludeOtherUserItemsAttr,"-"));

	//Setting the BOMConfigContextS Configuration Context Based on the User Selection...
	if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP And Release Vaults"))
	{
		printf("\n Entering inside as Latest From WIP And Release Vaults...\n"); fflush(stdout);
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsWorking","-"));
	}
	if(!nlsStrCmp(BOMConfigContextS,"Latest From Release Vault Only"))
	{
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAplRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDRlzd","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsSTDWrkg","+"));
	}

	if(!nlsStrCmp(BOMConfigContextS,"Latest From WIP Vault Only"))
	{
		printf("\n Entering inside as Latest From WIP Vaults Only...\n"); fflush(stdout);
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsReview","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsErcRlzd","+"));
		//t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsAPLWrkg","+"));
		t5CheckDstat(objNameValueSet(ContextObjP,LCStateListAttr,"LcsWorking","-"));
	}

	t5CheckDstat(objSetObject(GenContextObjP,ConfigCtxtBlobAttr, ContextObjP));
	printf("\n 2.Ending in to Configuration Context Settings in ContextBOMViewTCPartMultiExplosion..\n"); fflush(stdout);

	/* Get the explosion with context */
	//printf("\n Expansion of the object based on Configuration Context Settings ..\n"); fflush(stdout);

	t5CheckMfail(t5GetMultiLevelExplosion_new(TCPartObjP,MultiLevel,GenContextObjP,&ChildPartsSO,&ChildRelPartsSO,&Levels,&type,GUsesLevel,mfail));

	printf("\n\n Total Number of Multi Level Explosion Parts in ContextBOMViewTCPartMultiExplosion: %d \n",setSize(ChildPartsSO)); fflush(stdout);
	if(setSize(ChildPartsSO)==0)
	{
		printf("\n There no Single Level Children is found for this TPL in ContextBOMViewTCPartMultiExplosion\n"); fflush(stdout);
		goto CLEANUP;
	}

	printf("\n No. of objects in type:[%d]",setSize(type)); fflush(stdout);

	if(setSize(ChildPartsSO)>0)
	{
		ChildPartsSOCmp = setCreate(10);
		ChildRelPartsSOCmp = setCreate(10);
		//printf("\n 1......setSize(ChildPartsSOCmp) :%d ",setSize(ChildPartsSOCmp)); fflush(stdout);
		for( cnt=0; cnt<setSize(ChildPartsSO); cnt++)
		{
			if(dstat = ulyCopyObjectToSet(setGet(ChildPartsSO, cnt) , &ChildPartsSOCmp)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(setGet(ChildRelPartsSO, cnt) , &ChildRelPartsSOCmp)) goto CLEANUP;
			//printf("\n 2......setSize(ChildPartsSOCmp) :%d ",setSize(ChildPartsSOCmp)); fflush(stdout);
		}
		//printf("\n 3......setSize(ChildPartsSOCmp) :%d ",setSize(ChildPartsSOCmp)); fflush(stdout);
		if (setSize(ChildPartsSOCmp)<=0)
		{
			low_set_cpy(ChildPartsSO, ChildPartsSOCmp);
			low_set_cpy(ChildRelPartsSO, ChildRelPartsSOCmp);
		}

		printf("\n setSize(ChildPartsSOCmp) :%d    setSize(ChildRelPartsSOCmp): %d",setSize(ChildPartsSOCmp),setSize(ChildRelPartsSOCmp)); fflush(stdout);
		printf("\n\n Total Number of Multi Level Explosion Parts in ContextBOMViewTCPartMultiExplosion: %d \n",setSize(ChildPartsSO)); fflush(stdout);
		//nlsStrCpy(SuppressedValStr,"TRUE");  //commented on 27.04.2018
		nlsStrCpy(SuppressedValStr,"FALSE");  //added on 27.04.2018
		//for(cCnt=0;cCnt<setSize(ChildPartsSO);cCnt++)
		//{
		//	t5CheckDstat(objGetAttribute(setGet(ChildPartsSO , cCnt) , PartNumberAttr , &ChildPartNo));
		//	ChildPartNoDup=nlsStrDup(ChildPartNo);
		//	if(dstat = ulyFindObjectInSet(Part,ChildPartsSOCmp,"PartNumber",0,&foundmatch2)) goto CLEANUP;
		//}

		for(ChildCount=0;ChildCount<setSize(ChildPartsSO);ChildCount++)
		{
			//printf("\n Count is111:%d \n",ChildCount); fflush(stdout);

			ChildPartObjP = setGet(ChildPartsSO,ChildCount);
			ChildRelObjP = setGet(ChildRelPartsSO,ChildCount);

			t5CheckMfail(ExpandObject2(ItemRevClass,ChildPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) ;
			if(SetFlagforScope(partMasterSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandObject2(ItemRevClass,ChildPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) ;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			MasterObjOP=setGet(partMasterSO,0);

			level=setGet(Levels,ChildCount);
			p_type=setGet(type,ChildCount+1);

			//t5CheckDstat(objGetAttribute(ChildPartObjP,"DisplayName",&ChildDisplayNm));
			//ChildDisplayNmDup = nlsStrDup(ChildDisplayNm);

			t5CheckDstat(objGetAttribute(ChildPartObjP,PartNumberAttr,&ChildPartNumberDupS));
			ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
			//printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,RevisionAttr,&ChildPartRevisionDupS));
			ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
			//printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,SequenceAttr,&ChildPartSequenceDupS));
			ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
			//printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,NomenclatureAttr,&DescriptionDupS));
			DescriptionS=nlsStrDup(DescriptionDupS);
			DescriptionS=low_strssra(DescriptionS,"\n"," ");
			DescriptionS=low_strssra(DescriptionS,"^"," ");
			//printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildRelObjP,QuantityAttr,&QuantityDupS));
			QuantityS=nlsStrDup(QuantityDupS);
			//printf("\n  Child TC Part QuantityS in ContextBOMViewTCPartMultiExplosion:%s \n",QuantityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,PartTypeAttr,&PartTypeDupS));
			PartTypeS=nlsStrDup(PartTypeDupS);
			//printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(ChildPartObjP,OrganizationIDAttr,&PartOrgIdDupS));
			PartOrgIdS=nlsStrDup(PartOrgIdDupS);
			//printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);
			printf("\n == %s level: %s ",ChildPartNumberS,level); fflush(stdout);

			if ((nlsStrLen(ChildPartNumberS) > 12) && (nlsStrStr(PartOrgIdS,"ERC") ==NULL))
			{
				printf("\t Skipping 14-digit parts from loading,  OrgId: [%s]",PartOrgIdS); fflush(stdout);

				continue;
			}

			//if(dstat=objGetAttribute(ChildRelObjP,RightNameAttr,&ParentNo)) goto EXIT;
			if(dstat=objGetAttribute(ChildRelObjP,LeftNameAttr,&ParentNo)) goto EXIT;
			if(!nlsIsStrNull(ParentNo))
			{
				ParentNoLeftDup=nlsStrDup(ParentNo);
				ParentNoDup=strtok(ParentNoLeftDup,",");
			}

			printf("\t ---Parent: %s",ParentNoDup); fflush(stdout);
			//for (t=0; t< atoi(level); t++)
			//{
			//	fprintf(fpSuperSet,"\t");fflush(stdout);
			//}
			//fprintf(fpSuperSet,"%s,%s,%s,%s,TRUE,%s ( Uses Qty), R11\n",level,ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS,QuantityS); fflush(fpSuperSet);
			fprintf(fpSuperSet,"%s^%s^%s^%s^%s^1^%s^4^%s^%s^%s^R11\n",level,ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS,DescriptionS,ChildPartNumberS,QuantityS,SuppressedValStr,ParentNoDup); fflush(fpSuperSet);

			if(nlsStrNCmp(ChildPartNumberS,"G",1) == 0)
			{
				ParentPart = nlsStrAlloc(20);
				ParentPartLevel = nlsStrAlloc(2);

				nlsStrCpy(ParentPart,ChildPartNumberS);
				nlsStrCat(ParentPart,";");
				nlsStrCat(ParentPart,level);

				nlsStrCpy(ParentPartLevel,level);

				if (atoi(ParentPartLevel) < atoi(level))
				{
					printf("\n child level > parent level");fflush(stdout);
				}
				printf("\n ParentPart: [%s] ParentPartLevel:[%s]  level:[%s] ChildPartNumberS:[%s]",ParentPart,ParentPartLevel,level,ChildPartNumberS);fflush(stdout);
			}

			PrtLevel = atoi(level);

			t5CheckMfail(GetGenTCPartProEInfo(UsesDataItemObjP,ChildPartObjP, ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS, InstancePrtRevSeq, mfail, &PrtLevel));

			/*
			fprintf(OrgFp,"%s",level);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartNumberS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartRevisionS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",ChildPartSequenceS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",DescriptionS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",QuantityS);
			fprintf(OrgFp,"^");
			fprintf(OrgFp,"%s",p_type);
			fprintf(OrgFp,"^");

			LeftRhDupS = NULL;
			LeftRhS = NULL;
			t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&LeftRhDupS));
			LeftRhS=nlsStrDup(LeftRhDupS);
			printf("\n LeftRhS[%s]\n",LeftRhS);fflush(stdout);

			if(dstat=ExpandObject5(PWLPRlClass,ChildPartObjP,"HasWeldedParts",SC_SCOPE_OF_SESSION,&PartMasterSet,mfail))goto EXIT;

			printf("\n LeftRhS[%s]\n",LeftRhS);fflush(stdout);

			if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0)
			{
				fprintf(OrgFp,"%s",PartTypeS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s\n","RH");
			}
			else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0)
			{
				fprintf(OrgFp,"%s",PartTypeS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s\n","LH");
			}
			else if(setSize(PartMasterSet) >1 )
			{
				fprintf(OrgFp,"%s",PartTypeS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s\n","Welded");
			}
			else
			{
				fprintf(OrgFp,"%s\n",PartTypeS);
			}

	        if(nlsStrCmp(LeftRhS,"LH CATIA")==0 || nlsStrCmp(LeftRhS,"LH PROE")==0 )
			{
				fprintf(OrgLhRhFp,"%s",level);
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","RH");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",QuantityS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",p_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);

			    t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;
				printf("\n inside LeftRhS[%s]\n",LeftRhS);fflush(stdout);
                if(setSize(hasRHItmMster) == 0)
				{
				  fprintf(LhRHErr,"%s",ChildPartNumberS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s",ChildPartRevisionS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s\n",ChildPartSequenceS);
				}
				if(setSize(hasRHItmMster) >0)
				{
					hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
					{
						if (dstat = ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) goto CLEANUP;
					}
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 000 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				if(setSize(hasRHTCPart) >0)
				{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(busItemsRight)
					{
						if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
					}
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
					LhRh_type = NULL;
					LhRh_type=nlsStrAlloc(50);
				}
				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
    			DescriptionS    =NULL;
	    		t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				DescriptionS=low_strssra(DescriptionS,"^"," ");
				printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
    			PartTypeS    =NULL;
			    t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

			    fprintf(OrgLhRhFp,"%s","1");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LeftRhS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","1");
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LhRh_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);

				fprintf(OrgFp,"%s",level);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartNumberS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartRevisionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartSequenceS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",DescriptionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s","1");
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",LhRh_type);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",PartTypeS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s\n",LeftRhS);
			}
			else if(nlsStrCmp(LeftRhS,"RH CATIA")==0 || nlsStrCmp(LeftRhS,"RH PROE")==0 )
			{
			    fprintf(OrgLhRhFp,"%s",level);
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","LH");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",QuantityS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",p_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);

			    t5CheckDstat(ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) ;

				printf("\n inside LeftRhS[%s]\n",LeftRhS);fflush(stdout);
                if(setSize(hasRHItmMster) == 0)
				{
				  fprintf(LhRHErr,"%s",ChildPartNumberS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s",ChildPartRevisionS);
				  fprintf(LhRHErr,"^");
				  fprintf(LhRHErr,"%s\n",ChildPartSequenceS);
				}
				if(setSize(hasRHItmMster) >0)
				{
					hasRHItmM = low_set_get(hasRHItmMster,0);

					t5CheckMfail(IntSetUpContext(objClass(hasRHItmM),hasRHItmM,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					//t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));
					//	t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

					if(hasRHItmM)
					{
						if (dstat = ExpandRelationWithCtxt("ItemRev", hasRHItmM, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) goto CLEANUP;
					}
				}

				printf("\ncalling ExpSetForUses hasRHTCPart 111 [%d]\n",setSize(hasRHTCPart));fflush(stdout);
				if(setSize(hasRHTCPart) >0)
				{
					busItemsRight = low_set_get(hasRHTCPart,0);
					t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));

					if(busItemsRight)
					{
						if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
					}
					printf("\ncalling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
				}

				if(LhRh_type == NULL)
				{
					LhRh_type = NULL;
					LhRh_type=nlsStrAlloc(50);
				}
				if(setSize(itemObjs)==0)
				{
					nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
				}else
				{
					nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
				}

				ChildPartNumberDupS=NULL;
				ChildPartNumberS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
				printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

				ChildPartRevisionDupS=NULL;
				ChildPartRevisionS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
				printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

				ChildPartSequenceDupS=NULL;
				ChildPartSequenceS   =NULL;
				t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
				printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

				DescriptionDupS =NULL;
    			DescriptionS    =NULL;
	    		t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");
				DescriptionS=low_strssra(DescriptionS,"^"," ");
				printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

				PartTypeDupS =NULL;
    			PartTypeS    =NULL;
			    t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);
				printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);

			    fprintf(OrgLhRhFp,"%s","1");
			    fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LeftRhS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartNumberS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartRevisionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",ChildPartSequenceS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",DescriptionS);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s","1");
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s",LhRh_type);
				fprintf(OrgLhRhFp,"^");
				fprintf(OrgLhRhFp,"%s\n",PartTypeS);


				fprintf(OrgFp,"%s",level);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartNumberS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartRevisionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",ChildPartSequenceS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",DescriptionS);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s","1");
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",LhRh_type);
				fprintf(OrgFp,"^");
				fprintf(OrgFp,"%s",PartTypeS);
             	fprintf(OrgFp,"^");
			    fprintf(OrgFp,"%s\n",LeftRhS);
			}

			////////////////////// Welded Parts ///////////////////////////////////////////

			if(setSize(PartMasterSet)>0)
			{
				for (w=0;w<setSize(PartMasterSet) ;w++ )
				{
					printf("\n Inside setSize(PartMasterSet) [%d]\n",setSize(PartMasterSet));fflush(stdout);
					genContext = NULL;
					CtxtObj = NULL;
					if(LhRh_type == NULL)
					{
							LhRh_type = NULL;
							LhRh_type=nlsStrAlloc(50);
					}
					PartMstr=setGet(PartMasterSet,w);
					t5CheckMfail(IntSetUpContext(objClass(PartMstr),PartMstr,&genContext,mfail)) ;
					t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext,&CtxtObj,mfail));
					//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
					//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

					t5CheckDstat(objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"));
					t5CheckDstat(objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"));
					t5CheckDstat(objSetObject(genContext,ConfigCtxtBlobAttr,CtxtObj));
					t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext,"PscLastRev",mfail));

					t5CheckMfail(ExpandRelationWithCtxt("ItemRev", PartMstr, "StrucBIRevsOfItemMstr", genContext, SC_SCOPE_OF_SESSION, NULL, &hasRHTCPart, &hasRHTCPartRelObj,mfail)) ;
					printf("\n calling ExpSetForUses hasRHTCPart 222 [%d]\n",setSize(hasRHTCPart));fflush(stdout);

					if(setSize(hasRHTCPart) >0)
					{
						busItemsRight = low_set_get(hasRHTCPart,0);

						t5CheckMfail(IntSetUpContext(objClass(busItemsRight),busItemsRight,&genContext1,mfail)) ;
						t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genContext1,&CtxtObj1,mfail));
						//t5CheckMfail(SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",mfail));
						//t5CheckDstat(objSetAttribute(CtxtObj,LCStateListAttr,"Life Cycle State List"));

						t5CheckDstat(objSetAttribute(CtxtObj1,CfgItemIdAttr,"GlobalCtxt"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsReview","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsWorking","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsErcRlzd","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAPLWrkg","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsAplRlzd","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDWrkg","+"));
						t5CheckDstat(objNameValueSet(CtxtObj1,LCStateListAttr,"LcsSTDRlzd","+"));
						t5CheckDstat(objSetObject(genContext1,ConfigCtxtBlobAttr,CtxtObj1));
						t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genContext1,"PscLastRev",mfail));
						//t5CheckMfail(SetLcsListInCtxt(DSesGnCClass,genContext,lcstatelist,mfail));

						if(busItemsRight)
						{
							if (dstat = ExpandRelationWithCtxt(AsRevRevClass, busItemsRight, "PartsInAssembly", genContext1, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
						}
						printf("\n calling ExpSetForUses itemObjs[%d]\n",setSize(itemObjs));fflush(stdout);
					}
					if(setSize(itemObjs)==0)
					{
						nlsStrCpy(LhRh_type,"COMP_TYPE_UA");
					}
					else
					{
						nlsStrCpy(LhRh_type,"ASSY_TYPE_UA");
					}

					ChildPartNumberDupS=NULL;
					ChildPartNumberS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartNumberAttr,&ChildPartNumberDupS));
					ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
					printf("\n  Child TC Part ChildPartNumberS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartNumberS); fflush(stdout);

					ChildPartRevisionDupS=NULL;
					ChildPartRevisionS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,RevisionAttr,&ChildPartRevisionDupS));
					ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
					printf("\n  Child TC Part ChildPartRevisionS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartRevisionS); fflush(stdout);

					ChildPartSequenceDupS=NULL;
					ChildPartSequenceS   =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,SequenceAttr,&ChildPartSequenceDupS));
					ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
					printf("\n  Child TC Part ChildPartSequenceS in ContextBOMViewTCPartMultiExplosion:%s \n",ChildPartSequenceS); fflush(stdout);

					DescriptionDupS =NULL;
					DescriptionS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,NomenclatureAttr,&DescriptionDupS));
					DescriptionS=nlsStrDup(DescriptionDupS);
					DescriptionS=low_strssra(DescriptionS,"\n"," ");
					DescriptionS=low_strssra(DescriptionS,"^"," ");
					printf("\n  Child TC Part Description in ContextBOMViewTCPartMultiExplosion:%s \n",DescriptionS); fflush(stdout);

					PartTypeDupS =NULL;
					PartTypeS    =NULL;
					t5CheckDstat(objGetAttribute(busItemsRight,PartTypeAttr,&PartTypeDupS));
					PartTypeS=nlsStrDup(PartTypeDupS);
					printf("\n  Child TC Part PartType in ContextBOMViewTCPartMultiExplosion:%s \n",PartTypeS); fflush(stdout);


					levelStr = nlsStrAlloc(6);
					sprintf(levelStr,"%d",(atoi(level)+1));
					printf("\n  levelStr %s \n",levelStr); fflush(stdout);

					fprintf(OrgFp,"%s",levelStr);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",ChildPartNumberS);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",ChildPartRevisionS);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",ChildPartSequenceS);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",DescriptionS);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s","1");
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",LhRh_type);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s",PartTypeS);
					fprintf(OrgFp,"^");
					fprintf(OrgFp,"%s\n","WeldedParts");
				} //for loop of setSize(PartMasterSet)
			} // if(setSize(PartMasterSet)>0)
			*/
			if(dstat = ulyFindObjectInSet(ChildPartObjP,ChildPartsSOCmp,"PartNumber",0,&foundmatch2)) goto CLEANUP;
			printf("\n foundmatch2: %d  ChildPartNumberS: %s",foundmatch2 , ChildPartNumberS); fflush(stdout);
		} //for loop of setSize(ChildPartsSO)
	} // if(setSize(ChildPartsSO)>0)
	/*
	matverifyfp=fopen(matverifyfilename,"w");

	relSize = setSize(ChildRelPartsSO);

	for(i=0; i<relSize; i++)
	{
		ChildRelOP=setGet(ChildRelPartsSO,i);

		if(dstat=objGetAttribute(ChildRelOP,LeftNameAttr,&LeftPartNumberDupS)) goto EXIT;
		if(LeftPartNumberDupS)
			LeftPartNumberS=nlsStrDup(LeftPartNumberDupS);

		if(dstat=objGetAttribute(ChildRelOP,RightNameAttr,&RightPartNumberDupS)) goto EXIT;
		if(RightPartNumberDupS)
			RightPartNumberS=nlsStrDup(RightPartNumberDupS);

		if(dstat=objGetAttribute(ChildRelOP,QuantityAttr,&QuantityDup)) goto EXIT;
		if(QuantityDup!=NULL)
			Quantity=nlsStrDup(QuantityDup);

		LeftPartNumberS=strtok(LeftPartNumberS,",");
		RightPartNumberS=strtok(RightPartNumberS,",");
		fprintf(matverifyfp,"%s,%s,%s\n",LeftPartNumberS,RightPartNumberS,Quantity);

		matfilename=nlsStrAlloc(50);

		nlsStrCpy(matfilename,LeftPartNumberS);
		nlsStrCat(matfilename,".");
		nlsStrCat(matfilename,RightPartNumberS);
		nlsStrCat(matfilename,".mat.txt");

		matfp=fopen(matfilename,"w");

		t5CheckDstat(objGetAttribute(ChildRelOP,LToRNameAttr,&ChildRelClassNameDupS));
		ChildRelClassNameS=nlsStrDup(ChildRelClassNameDupS);

		t5CheckDstat(objGetObject(ChildRelOP,AssocRelationObjAttr,&revEffObj));
		t5CheckDstat(objGetAttribute(revEffObj,OBIDAttr,&RelnObidDup));
		RelnObid=nlsStrDup(RelnObidDup);

		printf("\n Matrix for [%s][%s][%s]",LeftPartNumberS,RightPartNumberS,ChildRelClassNameS);

		if(!nlsStrCmp(ChildRelClassNameS,"Uses Parts"))
		{
			printf("\n Uses Parts");
			sprintf(decimalQty,"%d",atoi(Quantity));
			if(nlsStrCmp(decimalQty,Quantity)==0)
			{
				qty=atoi(decimalQty);
			}
			else
			{
				qty=1;
			}
			//printf("\n Multi Quantity Is : %d ",qty);
			//printf("\n Getting Martix the normal way");fflush(stdout);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix11Attr,&Matrix11Dup)) goto EXIT;
			if(Matrix11Dup!=NULL)
			Matrix11=nlsStrDup(Matrix11Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix12Attr,&Matrix12Dup)) goto EXIT;
			if(Matrix12Dup!=NULL)
			Matrix12=nlsStrDup(Matrix12Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix13Attr,&Matrix13Dup)) goto EXIT;
			if(Matrix13Dup!=NULL)
			Matrix13=nlsStrDup(Matrix13Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix14Attr,&Matrix14Dup)) goto EXIT;
			if(Matrix14Dup!=NULL)
			Matrix14=nlsStrDup(Matrix14Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix21Attr,&Matrix21Dup)) goto EXIT;
			if(Matrix21Dup!=NULL)
			Matrix21=nlsStrDup(Matrix21Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix22Attr,&Matrix22Dup)) goto EXIT;
			if(Matrix22Dup!=NULL)
			Matrix22=nlsStrDup(Matrix22Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix23Attr,&Matrix23Dup)) goto EXIT;
			if(Matrix23Dup!=NULL)
			Matrix23=nlsStrDup(Matrix23Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix24Attr,&Matrix24Dup)) goto EXIT;
			if(Matrix24Dup!=NULL)
			Matrix24=nlsStrDup(Matrix24Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix31Attr,&Matrix31Dup)) goto EXIT;
			if(Matrix31Dup!=NULL)
			Matrix31=nlsStrDup(Matrix31Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix32Attr,&Matrix32Dup)) goto EXIT;
			if(Matrix32Dup!=NULL)
			Matrix32=nlsStrDup(Matrix32Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix33Attr,&Matrix33Dup)) goto EXIT;
			if(Matrix33Dup!=NULL)
			Matrix33=nlsStrDup(Matrix33Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix34Attr,&Matrix34Dup)) goto EXIT;
			if(Matrix34Dup!=NULL)
			Matrix34=nlsStrDup(Matrix34Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix41Attr,&Matrix41Dup)) goto EXIT;
			if(Matrix41Dup!=NULL)
			Matrix41=nlsStrDup(Matrix41Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix42Attr,&Matrix42Dup)) goto EXIT;
			if(Matrix42Dup!=NULL)
			Matrix42=nlsStrDup(Matrix42Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix43Attr,&Matrix43Dup)) goto EXIT;
			if(Matrix43Dup!=NULL)
			Matrix43=nlsStrDup(Matrix43Dup);

			if(dstat=objGetAttribute(ChildRelOP,TMatrix44Attr,&Matrix44Dup)) goto EXIT;
			if(Matrix44Dup!=NULL)
			Matrix44=nlsStrDup(Matrix44Dup);

			t5CheckDstat(objGetAttribute(ChildRelOP,g0InstanceNameAttr,&Instname));
			Instnamedup=nlsStrDup(Instname);

			for(z=0;z<qty;z++)
			{
				fprintf(matfp,"%s,%s,%s,%s",Matrix11,Matrix12,Matrix13,Matrix14);
				fprintf(matfp,",%s,%s,%s,%s",Matrix21,Matrix22,Matrix23,Matrix24);
				fprintf(matfp,",%s,%s,%s,%s",Matrix31,Matrix32,Matrix33,Matrix34);
				fprintf(matfp,",%s,%s,%s,%s,%s\n",Matrix41,Matrix42,Matrix43,Matrix44,Instnamedup);
				fflush(matfp);
			}
		}
		else
		{
			printf("\n Uses Elements");

			t5CheckDstat(objGetAttribute(ChildRelOP,LeftAttr,&LeftPartObjOBIDS));
			printf("\n Multi Quantity Assembly PartNumber(Left OBID) is:%s \n",LeftPartObjOBIDS);
			t5CheckDstat(objGetAttribute(ChildRelOP,RightAttr,&RightPartMstrObjOBIDS11));
			//printf("\n Multi Quantity Children PartNumber(Right OBID) is:%s \n",RightPartMstrObjOBIDS11);
			t5CheckDstat(oiSqlCreateSelect(&MultyQtySqlPtr));
			t5CheckDstat(oiSqlWhereEQ(MultyQtySqlPtr,OBIDAttr,RelnObid));
			t5CheckMfail(QueryWhere3(x2AsmPoQClass,MultyQtySqlPtr,0,SC_SCOPE_OF_SESSION,&MultyQtyRelPartSO,mfail));
			printf("\n Set Size of the Object in x2AsmPoQ is:%d \n",setSize(MultyQtyRelPartSO));

			if(setSize(MultyQtyRelPartSO)!=0)
			{
				RelQtyPartObjP = (ObjectPtr)low_set_get(MultyQtyRelPartSO,0);
				//RelQtyPartObjP =setGet(MultyQtyRelPartSO,0);
				t5CheckDstat(objGetTableSize(RelQtyPartObjP,"x0TrafoList",&sizeoftable));
				//printf("\n Full table name size is After Setting:%d \n",sizeoftable);
				t5CheckDstat(objGetAttribute(RelQtyPartObjP,QuantityAttr,&ChildPartQuantityS));
				//printf("\n Multi Quantity Value is:%s \n",ChildPartQuantityS);
				sprintf(decimalQty,"%d",atoi(ChildPartQuantityS));
				if(nlsStrCmp(decimalQty,ChildPartQuantityS)==0)
				{
					qty=atoi(ChildPartQuantityS);
				}
				else
				{
					qty=1;
				}

				printf("\n Multi Quantity Is : [%d,%d] ",qty,sizeoftable);
				//printf("\n MulitQunatity Valuse is (After Int Conv):%d \n",ChildPartMQuantityS);

				for(ChildMQPart=0;ChildMQPart<sizeoftable;ChildMQPart++)
				{
					//printf("\n Current Running Serial for the Index Matrix is:%d \n",ChildMQPart);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix11Attr,&ChildPartMQRelTMatrix11S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix11Attr value is:%s \n",ChildPartMQRelTMatrix11S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,x0TrafoIndexAttr,&indexDupS));
					indexS=nlsStrDup(indexDupS);

					if(nlsIsStrNull(indexS))
					{
						fprintf(matfp,"1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0\n");
						fflush(matfp);
						continue;
					}

					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix12Attr,&ChildPartMQRelTMatrix12S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix12Attr value is:%s \n",ChildPartMQRelTMatrix12S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix13Attr,&ChildPartMQRelTMatrix13S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix13Attr value is:%s \n",ChildPartMQRelTMatrix13S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix14Attr,&ChildPartMQRelTMatrix14S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix14Attr value is:%s \n",ChildPartMQRelTMatrix14S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix21Attr,&ChildPartMQRelTMatrix21S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix21Attr value is:%s \n",ChildPartMQRelTMatrix21S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix22Attr,&ChildPartMQRelTMatrix22S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix22Attr value is:%s \n",ChildPartMQRelTMatrix22S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix23Attr,&ChildPartMQRelTMatrix23S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix23Attr value is:%s \n",ChildPartMQRelTMatrix23S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix24Attr,&ChildPartMQRelTMatrix24S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix24Attr value is:%s \n",ChildPartMQRelTMatrix24S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix31Attr,&ChildPartMQRelTMatrix31S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix31Attr value is:%s \n",ChildPartMQRelTMatrix31S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix32Attr,&ChildPartMQRelTMatrix32S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix32Attr value is:%s \n",ChildPartMQRelTMatrix32S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix33Attr,&ChildPartMQRelTMatrix33S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix33Attr value is:%s \n",ChildPartMQRelTMatrix33S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix34Attr,&ChildPartMQRelTMatrix34S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix34Attr value is:%s \n",ChildPartMQRelTMatrix34S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix41Attr,&ChildPartMQRelTMatrix41S));
					//printf("\n Getting Full table x0TrafoListAttr   TMatrix41Attr value is:%s \n",ChildPartMQRelTMatrix41S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix42Attr,&ChildPartMQRelTMatrix42S));
					//printf("\n Getting Full table x0TrafoListAttr  TMatrix42Attr value is:%s \n",ChildPartMQRelTMatrix42S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix43Attr,&ChildPartMQRelTMatrix43S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix43Attr value is:%s \n",ChildPartMQRelTMatrix43S);
					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,TMatrix44Attr,&ChildPartMQRelTMatrix44S));
					//printf("\n Getting Full table x0TrafoListAttr TMatrix44Attr value is:%s \n",ChildPartMQRelTMatrix44S);

					t5CheckDstat(objGetTableAttribute(RelQtyPartObjP,x0TrafoListAttr,ChildMQPart,g0InstanceNameAttr,&Instname));
					Instnamedup=nlsStrDup(Instname);

					printf("\n 1.Instnamedup name:[%s]",Instnamedup);

					newInstancename=nlsStrAlloc(500);

					if(nlsIsStrNull(Instnamedup))
					{
						t5CheckDstat(objGetAttribute(RelQtyPartObjP,g0InstanceNameAttr,&Instname));
						printf("\n 1.Instance name:[%s]",Instname);
						Instnamedup=nlsStrDup(Instname);

						nlsStrCpy(newInstancename,Instnamedup);
						nlsStrCat(newInstancename,"#");
						nlsStrCat(newInstancename,indexS);
						printf("\n Get Attribute 1 :[%s]",newInstancename);
					}
					else
					{
						nlsStrCpy(newInstancename,Instnamedup);
						printf("\n Get Attribute 2 :[%s]",newInstancename);
					}

					fprintf(matfp,"%s,%s,%s,%s",ChildPartMQRelTMatrix11S,ChildPartMQRelTMatrix12S,ChildPartMQRelTMatrix13S,ChildPartMQRelTMatrix14S);
					fprintf(matfp,",%s,%s,%s,%s",ChildPartMQRelTMatrix21S,ChildPartMQRelTMatrix22S,ChildPartMQRelTMatrix23S,ChildPartMQRelTMatrix24S);
					fprintf(matfp,",%s,%s,%s,%s",ChildPartMQRelTMatrix31S,ChildPartMQRelTMatrix32S,ChildPartMQRelTMatrix33S,ChildPartMQRelTMatrix34S);
					fprintf(matfp,",%s,%s,%s,%s,%s\n",ChildPartMQRelTMatrix41S,ChildPartMQRelTMatrix42S,ChildPartMQRelTMatrix43S,ChildPartMQRelTMatrix44S,newInstancename);
				}
			}
		}
		fclose(matfp);
		matfp=NULL;
	}*/

CLEANUP:
		//fclose(matverifyfp);matverifyfp=NULL;
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(ChildPartsSO);
		t5FreeSetOfObjects(ChildRelPartsSO);
EXIT:
		t5CheckDstatAndReturn;
};
//This function returns Multilevel explosion of a give part object
status t5GetMultiLevelExplosion_new
(
		ObjectPtr		partObj,
		integer			reqLevel,
		ObjectPtr       contextObj,
		SetOfObjects*	childObjs,
		SetOfObjects*	childRelObjs,
		SetOfStrings*	levels,
		SetOfStrings*	type,
		integer*		GUsesLevel,
		integer*		mfail
)
{
	status dstat = OKAY;
   	char *mod_name = "t5GetMultiLevelExplosion_new";
	//integer level = 0;
   	NVSET textInserts = NULL;
	*mfail = USC_OKAY;

	// call to a function to track level
	if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE)) goto CLEANUP;
	//if( dstat = t5GetExplosion_new(partObj, reqLevel, contextObj, childObjs, childRelObjs, levels , type , &level, mfail)) goto CLEANUP;
	if( dstat = t5GetExplosion_new(partObj, reqLevel, contextObj, childObjs, childRelObjs, levels , type , GUsesLevel, mfail)) goto CLEANUP;
	if(*mfail) goto CLEANUP;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}
//Recursive function used in t5GetMultiLevelExplosion
status t5GetExplosion_new
(
	ObjectPtr		partObj,
	integer			reqLevel,
	ObjectPtr       contextObj,
	SetOfObjects	*childObjs,
	SetOfObjects	*childRelObjs,
	SetOfStrings	*levels,
	SetOfStrings	*type,
	integer*		level,
	integer*		mfail
)
{
	status dstat = OKAY;
	char *mod_name = "t5GetExplosion_new";

	SetOfObjects itemObjs = NULL;
	SetOfObjects relObjs = NULL;
	//SetOfObjects GrpitemObjs = NULL;
	//SetOfObjects GrprelObjs = NULL;

	ObjectPtr relObj = NULL;
	ObjectPtr itemObj = NULL;
	//ObjectPtr GrpitemObj = NULL;

	integer cnt = 0;
	//int RecChkFlag = 0;
	//int gn = 0;
	//int t = 0;

	string integerStr = NULL;
	string tempStr = NULL;
	string StructPartNo = NULL;
	string StructPartNoDup = NULL;
	string StructPartRev = NULL;
	string StructPartRevDup = NULL;
	string StructPartSeq = NULL;
	string StructPartSeqDup = NULL;
	string StructPartType = NULL;
	string StructPartTypeDup = NULL;
	string StructPartTypeDup2 = NULL;
	//string GrpChild = NULL;
	//string GrpChildDup = NULL;

	//string SuppressedValStr = NULL;

	//boolean SuppressedVal = TRUE;

	NVSET textInserts = NULL;
	*mfail = USC_OKAY;

	StructPartTypeDup2 = nlsStrAlloc(12);
	//SuppressedValStr = nlsStrAlloc(10);

	if( *level >= reqLevel )
		return (dstat);

	if (dstat = ExpandRelationWithCtxt("AsRevRev", partObj, "PartsInAssembly", contextObj, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
	if(SetFlagforScope(itemObjs)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		if (dstat = ExpandRelationWithCtxt("AsRevRev", partObj, "PartsInAssembly", contextObj, SC_SCOPE_OF_SESSION, NULL, &itemObjs, &relObjs, mfail)) goto CLEANUP;
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}
	//printf("\ncalling ExpSetForUses  \n");fflush(stdout);

	if (dstat = objGetAttribute(partObj,PartNumberAttr,&StructPartNo)) goto CLEANUP;
	StructPartNoDup=nlsStrDup(StructPartNo);

	if (dstat = objGetAttribute(partObj,RevisionAttr,&StructPartRev)) goto CLEANUP;
	StructPartRevDup=nlsStrDup(StructPartRev);

	if (dstat = objGetAttribute(partObj,SequenceAttr,&StructPartSeq)) goto CLEANUP;
	StructPartSeqDup=nlsStrDup(StructPartSeq);

	if (dstat = objGetAttribute(partObj,PartTypeAttr,&StructPartType)) goto CLEANUP;
	StructPartTypeDup=nlsStrDup(StructPartType);

	if(*type == NULL)
	{
		*type = setCreate(1);
	}
	if(setSize(itemObjs)==0)
	{
		setAddStr(*type,"COMP_TYPE_UA");

		nlsStrCpy(StructPartTypeDup2,"COMP_TYPE_UA");
	}
	else
	{
		setAddStr(*type,"ASSY_TYPE_UA");

		nlsStrCpy(StructPartTypeDup2,"ASSY_TYPE_UA");
	}

	/*SuppressedVal = TRUE;

	nlsStrCpy(SuppressedValStr,"TRUE");

	if(nlsStrNCmp(StructPartNoDup,"G",1) == 0)
	{
		if (dstat = ExpandRelationWithCtxt("AsRevRev", partObj, "PartsInAssembly", contextObj, SC_SCOPE_OF_SESSION, NULL, &GrpitemObjs, &GrprelObjs, mfail)) goto CLEANUP;

		for( gn=0; gn<setSize(GrpitemObjs); gn++)
		{
			GrpitemObj = setGet(GrpitemObjs, gn);

			if (dstat = objGetAttribute(GrpitemObj,PartNumberAttr,&GrpChild)) goto CLEANUP;
			GrpChildDup=nlsStrDup(GrpChild);

			if (low_set_find_str(ProAssyMemSOS,GrpChildDup) >= 0)
			{
				SuppressedVal = FALSE;

				nlsStrCpy(SuppressedValStr,"FALSE");

				break;
			}
			else
			{
				SuppressedVal = TRUE;

				nlsStrCpy(SuppressedValStr,"TRUE");
			}
		}
	}
	else
	{
		RecChkFlag = low_set_find_str(ProAssyMemSOS,StructPartNoDup);
		if(RecChkFlag >= 0)
		{
			//printf("\t ..Part Already Present"); fflush(stdout);

			SuppressedVal = FALSE;

			nlsStrCpy(SuppressedValStr,"FALSE");
		}
		else if (RecChkFlag == -1)
		{
			//printf("\t ..Part not Present"); fflush(stdout);
			SuppressedVal = TRUE;

			nlsStrCpy(SuppressedValStr,"TRUE");
		}
	}*/

	//printf("\n"); fflush(stdout);
	//for (t=0; t < *level; t++)
	//{
	//	printf("\t"); fflush(stdout);
	//}
	//printf("Level: %d --%s,%s,%s,%s,%s , %s--%d",*level,StructPartNoDup,StructPartRevDup,StructPartSeqDup,StructPartTypeDup,StructPartTypeDup2,SuppressedValStr,SuppressedVal); fflush(stdout);

	// Get the objects from set and do recusive call
	*level = *level + 1;
	for( cnt=0; cnt<setSize(itemObjs); cnt++)
	{
		itemObj = setGet(itemObjs, cnt);
		relObj = setGet(relObjs, cnt);

		if(dstat = ulyCopyObjectToSet(itemObj, childObjs)) goto CLEANUP;
		if(dstat = ulyCopyObjectToSet(relObj, childRelObjs)) goto CLEANUP;

		integerStr = nlsStrAlloc(6);
		sprintf(integerStr, "%d", *level);
		tempStr = nlsStrDup(integerStr);
		nlsStrFree(integerStr); integerStr = NULL;

		if(*levels == NULL)
			*levels = setCreate(1);
		setAddStr(*levels, tempStr);

		// recursive call
		if( dstat = t5GetExplosion_new(itemObj, reqLevel, contextObj, childObjs, childRelObjs, levels, type , level, mfail)) goto CLEANUP;
		if( dstat = uiShowText("t5GetSLBomExplosionStatusMsg1", textInserts, UI_DIALOG_TEXT , dstat, WHERE) )goto CLEANUP;
	}
	*level = *level - 1;

CLEANUP:
	if(itemObjs)  objDisposeAll(itemObjs); itemObjs = NULL;
	if(relObjs)	  objDisposeAll(relObjs); relObjs = NULL;

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
	return( dstat );
}

status GetGenTCPartProEInfo(ObjectPtr DataItemObjP, ObjectPtr TCObjP, string InpPartNumberS, string InpPartRev, string InpPartSeq, string InstanceRevSeqS, integer* mfail , int *Prtlevel)
{
	char *mod_name = "GetGenTCPartProEInfo";

	status dstat = OKAY;

	string PartNumberDupS=NULL;
	string PartNumberS=NULL;
	string docClass=NULL;
	string PartRevSeq = NULL;

	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string t5ColourIDS = NULL;
	string t5ColourIDDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	string t5CMVRCertificationS = NULL;
	string t5CMVRCertificationDupS = NULL;
	string t5ClassificationHazDupS = NULL;
	string t5ClassificationHazS = NULL;
	string t5ConfigIDS = NULL;
	string t5ConfigIDDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5ListRecSparess = NULL;
	string t5ListRecSparesDups = NULL;
	string t5NcPartNoS = NULL;
	string t5PartCodeS = NULL;
	string t5NcPartNoDupS = NULL;
	string t5PartCodeDupS = NULL;
	string t5PartPropertyS = NULL;
	string t5PartPropertyDupS = NULL;
	string t5PartStatusS = NULL;
	string t5PartStatusDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PrtCatCodeS = NULL;
	string t5PrtCatCodeDupS = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5RefPartNumberS = NULL;
	string t5RefPartNumberDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SurfPrtStdS = NULL;
	string t5SurfPrtStdDupS = NULL;
	string t5SamplesToApprS = NULL;
	string t5SamplesToApprDupS = NULL;
	string t5AsmDisposalS = NULL;
	string t5AsmDisposalDupS = NULL;
	string t5FinDisposalInstrS = NULL;
	string t5FinDisposalInstrDupS = NULL;
	string t5RPDisposalInstrS = NULL;
	string t5RPDisposalInstrDupS = NULL;
	string t5SPDisposalInstrS = NULL;
	string t5SPDisposalInstrDupS = NULL;
	string t5WIPDisposalInstrS = NULL;
	string t5WIPDisposalInstrDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5CAEDocES = NULL;
	string t5CAEDocEDupS = NULL;
	string t5CoatedS = NULL;
	string t5CoatedDupS = NULL;
	string t5ConvDocS = NULL;
	string t5ConvDocDupS = NULL;
	string t5AplCopyOfErcRevS = NULL;
	string t5AplCopyOfErcRevDupS = NULL;
	string t5AplCopyOfErcSeqS = NULL;
	string t5AplCopyOfErcSeqDupS = NULL;
	string t5AppCodeS = NULL;
	string t5AppCodeDupS = NULL;
	string t5RqstNumS = NULL;
	string t5RqstNumDupS = NULL;
	string t5RsnCodeS = NULL;
	string t5RsnCodeDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5ErcIndNameS = NULL;
	string t5ErcIndNameDupS = NULL;
	string t5PostRelReqS = NULL;
	string t5PostRelReqDupS = NULL;
	string t5ItmCategoryS = NULL;
	string t5ItmCategoryDupS = NULL;
	string t5CopReqS = NULL;
	string t5CopReqDupS = NULL;
	string t5AplInvalidateS = NULL;
	string t5AplInvalidateDupS = NULL;
	string t5PrtValiStatusS = NULL;
	string t5PrtValiStatusDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5KnxtDocIndS = NULL;
	string t5KnxtDocIndDupS = NULL;
	string t5SimValS = NULL;
	string t5SimValDupS = NULL;
	string t5PerYieldS = NULL;
	string t5PerYieldDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5AltPartNoS = NULL;
	string t5AltPartNoDupS = NULL;
	string t5RolledupWtS = NULL;
	string t5RolledupWtDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string t5PFDModReqdS = NULL;
	string t5PFDModReqdDupS = NULL;
	string t5ToolIndentReqdS = NULL;
	string t5ToolIndentReqdDupS = NULL;
	string CategoryNameDupS = NULL;
	string CategoryNameS = NULL;
	string ReveffDateFrom = NULL;
	string ReveffDateFromDup = NULL;
	string ReveffDateTo = NULL;
	string ReveffDateToDup = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;
	string DItype = NULL;
	string ClassNm = NULL;
	string ClassNmDup = NULL;
	string LHRhPartNumber = NULL;
	string LHRhPartNumberDup = NULL;
	string t5RightLH = NULL;
	string t5RightLHDupS = NULL;
	string temp2Dup = NULL;

	SetOfObjects PartSO = NULL ;
	SetOfObjects partMasterSO = NULL;
	SetOfObjects partMasterRelSO = NULL;
	SetOfObjects docObjs = NULL ;
	SetOfObjects docRelObjs = NULL ;
	SetOfObjects latestDocs = NULL ;
	SetOfObjects latestRelDocs = NULL ;
	SetOfObjects soExpObj = NULL ;
	SetOfObjects relObjSet = NULL ;
	SetOfObjects hasRHItmMster = NULL ;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr docOPtr=NULL;
	ObjectPtr contextObj = NULL;
	ObjectPtr genContextObj	= NULL;
	ObjectPtr LHRHUsesDataItemObjP = NULL;
	ObjectPtr LHRHTCObjP = NULL;

	SqlPtr Sql_ptr = NULL;

	int m = 0;
	int noOfDocs = 0;
	int tmpStrlen = 0;
	int i = 0;
	int charFlag = 0;
	int LhRhPartExistFlag = 0;

	char tempstr[50]={0};
	char *p;

	PartRevSeq = nlsStrAlloc(50);
	DItype = nlsStrAlloc(50);

	if (DataItemObjP != NULL)
	{
		t5CheckDstat(objGetAttribute(DataItemObjP,"Class",&ClassNm));
		if(!nlsIsStrNull(ClassNm))
		{
			ClassNmDup=nlsStrDup(ClassNm);
		}

		if(nlsStrStr(ClassNmDup,"ProAsm") !=NULL)
		{
			nlsStrCpy(DItype,"ASSY_TYPE_UA");
		}
		else if(nlsStrStr(ClassNmDup,"ProPrt") !=NULL)
		{
			nlsStrCpy(DItype,"COMP_TYPE_UA");
		}
		else
		{
			nlsStrCpy(DItype,"TYPE_INVALID");
		}
	}
	else
	{
		nlsStrCpy(DItype,"USES_INVALID");
	}

	if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
	/*if( (!nlsIsStrNull(InpPartRev)) && (!nlsIsStrNull(InpPartSeq)) )
	{
		if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
			(dstat = oiSqlWhereBegParen(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,InpPartRev))||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,SequenceAttr,InpPartSeq))||
			(dstat = oiSqlWhereEndParen(Sql_ptr))||
			(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
		if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
	}
	else	// Generic Case only
	{*/
		if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
			(dstat = oiSqlWhereBegParen(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
			(dstat = oiSqlWhereEndParen(Sql_ptr))||
			(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
		if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
	//}
	if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	printf("\nNo:of Parts are :- %d",setSize(PartSO));

	if (setSize(PartSO) == 0)
	{
		charFlag = 0;
		strcpy(tempstr,"");
		strcpy(tempstr,InpPartNumberS);

		tmpStrlen = strlen(tempstr);
		//printf ("\n tmpStrlen  %d",tmpStrlen);
		for(i=0;i<tmpStrlen;i++)
		{
			if (!isdigit(tempstr[i]))
			{
				//printf ("\n alpha");
				charFlag = 1;
				printf ("\n charFlag %d found hence skipping..",charFlag);
				break;
			}
		}

		if (charFlag == 1)
		{
			temp2Dup=nlsStrDup(InpPartNumberS);

			printf ("\nBefore conversion: [%s]", temp2Dup);
			for (p = temp2Dup; *p != '\0'; ++p)
			{
				*p = tolower(*p);
			}
			printf ("\t After conversion: [%s]", temp2Dup);

			if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
				(dstat = oiSqlWhereBegParen(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,temp2Dup))||
				(dstat = oiSqlWhereEndParen(Sql_ptr))||
				//(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
				(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
			if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
			printf("\n Generic no. of Parts:: %d",setSize(PartSO));
		}
	}

	if(setSize(PartSO)>0)
	{
		for(m=0;m<setSize(PartSO);m++)
		{
			TCPartObjP=setGet(PartSO,m);

			if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
			if(SetFlagforScope(partMasterSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			if (setSize(partMasterSO)>0)
			{
				MasterObjOP = setGet(partMasterSO,0);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberS));
			PartNumberDupS=nlsStrDup(PartNumberS);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&RevisionS));
			RevisionDupS=nlsStrDup(RevisionS);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&SequenceS));
			SequenceDupS=nlsStrDup(SequenceS);

			printf("\n\n\t Prtlevel: %d TCPart:::::[ %s , %s , %s ]   DItype: %s",*Prtlevel, PartNumberDupS,RevisionDupS,SequenceDupS,DItype); fflush(stdout);

			if (charFlag == 1)
			{
				printf("\t InpPartNumberS: %s",InpPartNumberS); fflush(stdout);

				RevisionDupS=nlsStrDup("NR");
				SequenceDupS=nlsStrDup("1");
			}

			if(!nlsIsStrNull(PartNumberDupS))
			{
				nlsStrCpy(PartRevSeq,"");

				//nlsStrCpy(PartRevSeq,PartNumberDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,RevisionDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,SequenceDupS);

				nlsStrCpy(PartRevSeq,RevisionDupS);
				nlsStrCat(PartRevSeq,";");
				nlsStrCat(PartRevSeq,SequenceDupS);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&NomenclatureS));
			if(!nlsIsStrNull(NomenclatureS))
			{
				NomenclatureDupS=nlsStrDup(NomenclatureS);
			}
			else
			{
				NomenclatureDupS=nlsStrDup("-");
			}
			NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
			NomenclatureDupS=low_strssra(NomenclatureDupS,"^"," ");
			printf("\n\t NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeS));
			PartTypeDupS=nlsStrDup(PartTypeS);
			printf("\n\t PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&OwnerNameS));
			OwnerNameDupS=nlsStrDup(OwnerNameS);
			printf("\n\t OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);
			if(nlsStrStr(OwnerNameDupS,"Vault")==NULL)
			{
				printf("\t ...this rev-seq not in vault hence skipping from download...\n");  fflush(stdout);
				continue;
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectNameS));
			ProjectNameDupS=nlsStrDup(ProjectNameS);
			printf("\n\t ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&t5DesignGroupS));
			if(!nlsIsStrNull(t5DesignGroupS))
			{
				t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
			}
			else
			{
				t5DesignGroupDupS=nlsStrDup(" ");
			}
			printf("\n\t t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
			if(!nlsIsStrNull(t5DocRemarkS))
			{
				t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
			}
			else
			{
				t5DocRemarkDupS=nlsStrDup("-");
			}
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"^"," ");
			printf("\n\t t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
			if(!nlsIsStrNull(t5DrawingIndS))
			{
				t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
			}
			else
			{
				t5DrawingIndDupS=nlsStrDup("N");
			}
			printf("\n\t t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

			if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
			{
				docClass = low_getspace(20);

				if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
				if(SetFlagforScope(docObjs)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}

				if(setSize(docObjs) <= 0)
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
				}
				if(setSize(docObjs) > 0)
				{
					if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
					if (setSize(latestDocs)>0)
					{
						for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
						{
							docOPtr = setGet(latestDocs, noOfDocs);
							if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
							if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
							{
								//Document Number = Drawing Document Number
								if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
								if(!nlsIsStrNull(t5DrawingNo))
								{
									t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
								}
								else
								{
									t5DrawingNoDupS = nlsStrDup("");
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNoDupS))
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}

					if(setSize(docObjs) > 0)
					{
						if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
						if (setSize(latestDocs)>0)
						{
							for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
							{
								docOPtr = setGet(latestDocs, noOfDocs);
								if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
								printf("\n\t ...51..%s",docClass);
								if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
								{
									//Document Number = Drawing Document Number
									if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
									if(!nlsIsStrNull(t5DrawingNo))
									{
										t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup("");
									}
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNo))
				{
					t5DrawingNoDupS = nlsStrDup(" ");
				}
			}
			else
			{
				t5DrawingNoDupS = nlsStrDup(" ");
			}
			printf("\n\t t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&t5MatlClassS));
			if(!nlsIsStrNull(t5MatlClassS))
			{
				t5MatlClassDupS=nlsStrDup(t5MatlClassS);
			}
			else
			{
				t5MatlClassDupS=nlsStrDup("NA");
			}
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"\n"," ");
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"^"," ");
			printf("\n\t t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&t5MaterialInDrwS));
			if(!nlsIsStrNull(t5MaterialInDrwS))
			{
				t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
			}
			else
			{
				t5MaterialInDrwDupS=nlsStrDup(" ");
			}
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"\n"," ");
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"^"," ");
			printf("\n\t t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessS));
			if(!nlsIsStrNull(MaterialThickNessS))
			{
				MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
			}
			else
			{
				MaterialThickNessDupS=nlsStrDup(" ");
			}
			printf("\n\t MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5UQdupAttr,&UnitOfMeasureS));
			//if(!nlsIsStrNull(UnitOfMeasureS))
			//{
			//	UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
			//}
			//else
			//{
			//	UnitOfMeasureDupS=nlsStrDup("4");
			//}
			//printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5LeftRhAttr,&t5LeftRhS));
			if (setSize(partMasterSO)>0)
			{
				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureS));
				if(!nlsIsStrNull(UnitOfMeasureS))
				{
					UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
				}
				else
				{
					UnitOfMeasureDupS=nlsStrDup("4");
				}

				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&t5LeftRhS));
				if(!nlsIsStrNull(t5LeftRhS))
				{
					t5LeftRhDupS=nlsStrDup(t5LeftRhS);
				}
				else
				{
					t5LeftRhDupS=nlsStrDup("NA");
				}
			}
			else
			{
				t5LeftRhDupS=nlsStrDup("NA");
				UnitOfMeasureDupS=nlsStrDup("4");
			}

			printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);
			printf("\n\t t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
			if(!nlsIsStrNull(t5DsgnOwnS))
			{
				t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
			}
			else
			{
				t5DsgnOwnDupS=nlsStrDup("TELPUN");
			}
			printf("\n\t t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
			if(!nlsIsStrNull(t5ModelIndicatorS))
			{
				t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
			}
			else
			{
				t5ModelIndicatorDupS=nlsStrDup("N");
			}
			printf("\n\t t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&t5ColourIndS));
			if(!nlsIsStrNull(t5ColourIndS))
			{
				t5ColourIndDupS=nlsStrDup(t5ColourIndS);
			}
			else
			{
				t5ColourIndDupS=nlsStrDup("N");
			}
			printf("\n\t t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDS));
			if(!nlsIsStrNull(t5ColourIDS))
			{
				t5ColourIDDupS=nlsStrDup(t5ColourIDS);
			}
			else
			{
				t5ColourIDDupS=nlsStrDup(" ");
			}
			printf("\n\t t5ColourIDDupS:%s",t5ColourIDDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateS));
			if(!nlsIsStrNull(LifeCycleStateS))
			{
				LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
			}
			else
			{
				LifeCycleStateDupS=nlsStrDup("LcsReview");
			}
			printf("\n\t LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightS));
			if(!nlsIsStrNull(WeightS))
			{
				WeightDupS=nlsStrDup(WeightS);
			}
			else
			{
				WeightDupS=nlsStrDup("0.00");
			}
			printf("\n\t WeightDupS:%s",WeightDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5SpareIndAttr,&SpareIndS));
			if(!nlsIsStrNull(SpareIndS))
			{
				SpareIndDupS=nlsStrDup(SpareIndS);
			}
			else
			{
				SpareIndDupS=nlsStrDup(" ");
			}
			printf("\n\t SpareIndDupS:%s",SpareIndDupS); fflush(stdout);


			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
			if(!nlsIsStrNull(t5CMVRCertificationDupS))
			{
				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
			}
			else
			{
				t5CMVRCertificationS=nlsStrDup(" ");
			}
			printf("\n\t t5CMVRCertificationS:%s",t5CMVRCertificationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
			if(!nlsIsStrNull(t5ClassificationHazDupS))
			{
				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
			}
			else
			{
				t5ClassificationHazS=nlsStrDup(" ");
			}
			printf("\n\t t5ClassificationHazS:%s",t5ClassificationHazS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
			if(!nlsIsStrNull(t5ConfigIDDupS))
			{
				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
			}
			else
			{
				t5ConfigIDS=nlsStrDup(" ");
			}
			//printf("\n\t t5ConfigIDS:%s",t5ConfigIDS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
			if(!nlsIsStrNull(t5DismantableDupS))
			{
				t5DismantableS=nlsStrDup(t5DismantableDupS);
			}
			else
			{
				t5DismantableS=nlsStrDup(" ");
			}
			printf("\n\t t5DismantableS:%s",t5DismantableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
			if(!nlsIsStrNull(t5DsgnDeptDupS))
			{
				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
			}
			else
			{
				t5DsgnDeptS=nlsStrDup(" ");
			}
			printf("\n\t t5DsgnDeptS:%s",t5DsgnDeptS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
			if(!nlsIsStrNull(t5EnvelopeDimenDupS))
			{
				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
			}
			else
			{
				t5EnvelopeDimenS=nlsStrDup(" ");
			}
			printf("\n\t t5EnvelopeDimenS:%s",t5EnvelopeDimenS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
			if(!nlsIsStrNull(t5HazardousContDupS))
			{
				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
			}
			else
			{
				t5HazardousContS=nlsStrDup(" ");
			}
			printf("\n\t t5HazardousContS:%s",t5HazardousContS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
			if(!nlsIsStrNull(t5HomologationReqdDupS))
			{
				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
			}
			else
			{
				t5HomologationReqdS=nlsStrDup(" ");
			}
			printf("\n\t t5HomologationReqdS:%s",t5HomologationReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
			if(!nlsIsStrNull(t5ListRecSparesDups))
			{
				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
			}
			else
			{
				t5ListRecSparess=nlsStrDup(" ");
			}
			//printf("\n\t t5ListRecSparess:%s",t5ListRecSparess); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
			if(!nlsIsStrNull(t5NcPartNoDupS))
			{
				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
			}
			else
			{
				t5NcPartNoS=nlsStrDup(" ");
			}
			printf("\n\t t5NcPartNoS:%s",t5NcPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
			if(!nlsIsStrNull(t5PartCodeDupS))
			{
				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
			}
			else
			{
				t5PartCodeS=nlsStrDup(" ");
			}
			printf("\n\t t5PartCodeS:%s",t5PartCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
			if(!nlsIsStrNull(t5PartPropertyDupS))
			{
				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
			}
			else
			{
				t5PartPropertyS=nlsStrDup(" ");
			}
			printf("\n\t t5PartPropertyS:%s",t5PartPropertyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
			if(!nlsIsStrNull(t5PartStatusDupS))
			{
				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
			}
			else
			{
				t5PartStatusS=nlsStrDup("NA");
			}
			printf("\n\t t5PartStatusS:%s",t5PartStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
			if(!nlsIsStrNull(t5PkgStdDupS))
			{
				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
			}
			else
			{
				t5PkgStdS=nlsStrDup(" ");
			}
			//printf("\n\t t5PkgStdS:%s",t5PkgStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
			if(!nlsIsStrNull(t5ProductDupS))
			{
				t5ProductS=nlsStrDup(t5ProductDupS);
			}
			else {	t5ProductS=nlsStrDup(" ");	}
			//printf("\n\t t5ProductS:%s",t5ProductS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
			if(!nlsIsStrNull(t5PrtCatCodeDupS))
			{
				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
			}
			else {	t5PrtCatCodeS=nlsStrDup(" ");	}
			//printf("\n\t t5PrtCatCodeS:%s",t5PrtCatCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
			if(!nlsIsStrNull(t5PunIntialAgDupS))
			{
				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
			}
			else {	t5PunIntialAgS=nlsStrDup(" ");	}
			//printf("\n\t t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
			if(!nlsIsStrNull(t5PunMakeBuyIndDupS))
			{
				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
			}
			else {	t5PunMakeBuyIndS=nlsStrDup(" ");	}
			//printf("\n\t t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
			if(!nlsIsStrNull(t5RecoverableDupS))
			{
				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
			}
			else {	t5RecoverableS=nlsStrDup(" ");	}
			printf("\n\t t5RecoverableS:%s",t5RecoverableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
			if(!nlsIsStrNull(t5RecyclabilityDupS))
			{
				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
			}
			else {	t5RecyclabilityS=nlsStrDup(" ");	}
			printf("\n\t t5RecyclabilityS:%s",t5RecyclabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
			if(!nlsIsStrNull(t5RefPartNumberDupS))
			{
				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
			}
			else {	t5RefPartNumberS=nlsStrDup(" ");	}
			printf("\n\t t5RefPartNumberS:%s",t5RefPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
			if(!nlsIsStrNull(t5ReliabilityDupS))
			{
				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
			}
			else {	t5ReliabilityS=nlsStrDup(" ");	}
			printf("\n\t t5ReliabilityS:%s",t5ReliabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
			if(!nlsIsStrNull(t5SpareCriteriaDupS))
			{
				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
			}
			else {
				t5SpareCriteriaS=nlsStrDup(" ");
			}
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"\n"," ");
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"^"," ");
			printf("\n\t t5SpareCriteriaS:%s",t5SpareCriteriaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
			if(!nlsIsStrNull(t5SurfPrtStdDupS))
			{
				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
			}
			else {	t5SurfPrtStdS=nlsStrDup(" ");	}
			//printf("\n\t t5SurfPrtStdS:%s",t5SurfPrtStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
			if(!nlsIsStrNull(t5SamplesToApprDupS))
			{
				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
			}
			else {	t5SamplesToApprS=nlsStrDup(" ");	}
			//printf("\n\t t5SamplesToApprS:%s",t5SamplesToApprS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
			if(!nlsIsStrNull(t5AsmDisposalDupS))
			{
				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
			}
			else {	t5AsmDisposalS=nlsStrDup(" ");	}
			//printf("\n\t t5AsmDisposalS:%s",t5AsmDisposalS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
			if(!nlsIsStrNull(t5FinDisposalInstrDupS))
			{
				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
			}
			else {	t5FinDisposalInstrS=nlsStrDup(" ");	}
			//printf("\n\t t5FinDisposalInstrS:%s",t5FinDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
			if(!nlsIsStrNull(t5RPDisposalInstrDupS))
			{
				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
			}
			else {	t5RPDisposalInstrS=nlsStrDup(" ");	}
			//printf("\n\t t5RPDisposalInstrS:%s",t5RPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
			if(!nlsIsStrNull(t5SPDisposalInstrDupS))
			{
				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
			}else {	t5SPDisposalInstrS=nlsStrDup(" ");	}
			//printf("\n\t t5SPDisposalInstrS:%s",t5SPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
			if(!nlsIsStrNull(t5WIPDisposalInstrDupS))
			{
				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
			}else {	t5WIPDisposalInstrS=nlsStrDup(" ");	}
			//printf("\n\t t5WIPDisposalInstrS:%s",t5WIPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
			if(!nlsIsStrNull(t5LastModByDupS))
			{
				t5LastModByS=nlsStrDup(t5LastModByDupS);
			}else {	t5LastModByS=nlsStrDup("loader");	}
			printf("\n\t t5LastModByS:%s",t5LastModByS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
			if(!nlsIsStrNull(t5VerCreatorDupS))
			{
				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
			}else {	t5VerCreatorS=nlsStrDup(" ");	}
			//printf("\n\t t5VerCreatorS:%s",t5VerCreatorS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
			if(!nlsIsStrNull(t5CAEDocEDupS))
			{
				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
			}else {	t5CAEDocES=nlsStrDup(" ");	}
			//printf("\n\t t5CAEDocES:%s",t5CAEDocES); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
			if(!nlsIsStrNull(t5CoatedDupS))
			{
				t5CoatedS=nlsStrDup(t5CoatedDupS);
			}else {	t5CoatedS=nlsStrDup(" ");	}
			printf("\n\t t5CoatedS:%s",t5CoatedS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
			if(!nlsIsStrNull(t5ConvDocDupS))
			{
				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
			}else {	t5ConvDocS=nlsStrDup(" ");	}
			//printf("\n\t t5ConvDocS:%s",t5ConvDocS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcRevDupS))
			{
				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
			}else {	t5AplCopyOfErcRevS=nlsStrDup(" ");	}
			//printf("\n\t t5AplCopyOfErcRevS:%s",t5AplCopyOfErcRevS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcSeqDupS))
			{
				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
			}else {	t5AplCopyOfErcSeqS=nlsStrDup(" ");	}
			//printf("\n\t t5AplCopyOfErcSeqS:%s",t5AplCopyOfErcSeqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
			if(!nlsIsStrNull(t5AppCodeDupS))
			{
				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
			}else {	t5AppCodeS=nlsStrDup(" ");	}
			//printf("\n\t t5AppCodeS:%s",t5AppCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
			if(!nlsIsStrNull(t5RqstNumDupS))
			{
				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
			}else {	t5RqstNumS=nlsStrDup(" ");	}
			//printf("\n\t t5RqstNumS:%s",t5RqstNumS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
			if(!nlsIsStrNull(t5RsnCodeDupS))
			{
				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
			}else {	t5RsnCodeS=nlsStrDup(" ");	}
			//printf("\n\t t5RsnCodeS:%s",t5RsnCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
			if(!nlsIsStrNull(t5SurfaceAreaDupS))
			{
				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
			}else {	t5SurfaceAreaS=nlsStrDup(" ");	}
			//printf("\n\t t5SurfaceAreaS:%s",t5SurfaceAreaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
			if(!nlsIsStrNull(t5VolumeDupS))
			{
				t5VolumeS=nlsStrDup(t5VolumeDupS);
			}else {	t5VolumeS=nlsStrDup(" ");	}
			//printf("\n\t t5VolumeS:%s",t5VolumeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
			if(!nlsIsStrNull(t5CarIntialAgencyDupS))
			{
				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
			}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
			//printf("\n\t t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
			if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
			{
				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
			}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
			//printf("\n\t t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
			if(!nlsIsStrNull(t5ErcIndNameDupS))
			{
				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
			}else {	t5ErcIndNameS=nlsStrDup(" ");	}
			//printf("\n\t t5ErcIndNameS:%s",t5ErcIndNameS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
			if(!nlsIsStrNull(t5PostRelReqDupS))
			{
				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
			}else {	t5PostRelReqS=nlsStrDup(" ");	}
			//printf("\n\t t5PostRelReqS:%s",t5PostRelReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
			if(!nlsIsStrNull(t5ItmCategoryDupS))
			{
				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
			}else {	t5ItmCategoryS=nlsStrDup(" ");	}
			//printf("\n\t t5ItmCategoryS:%s",t5ItmCategoryS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
			if(!nlsIsStrNull(t5CopReqDupS))
			{
				t5CopReqS=nlsStrDup(t5CopReqDupS);
			}else {	t5CopReqS=nlsStrDup(" ");	}
			//printf("\n\t t5CopReqS:%s",t5CopReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
			if(!nlsIsStrNull(t5AplInvalidateDupS))
			{
				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
			}else {	t5AplInvalidateS=nlsStrDup(" ");	}
			//printf("\n\t t5AplInvalidateS:%s",t5AplInvalidateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
			if(!nlsIsStrNull(t5PrtValiStatusDupS))
			{
				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
			}else {	t5PrtValiStatusS=nlsStrDup(" ");	}
			//printf("\n\t t5PrtValiStatusS:%s",t5PrtValiStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
			if(!nlsIsStrNull(t5DRSubStateDupS))
			{
				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
			}else {	t5DRSubStateS=nlsStrDup(" ");	}
			printf("\n\t t5DRSubStateS:%s",t5DRSubStateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
			if(!nlsIsStrNull(t5KnxtDocIndDupS))
			{
				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
			}else {	t5KnxtDocIndS=nlsStrDup(" ");	}
			//printf("\n\t t5KnxtDocIndS:%s",t5KnxtDocIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
			if(!nlsIsStrNull(t5SimValDupS))
			{
				t5SimValS=nlsStrDup(t5SimValDupS);
				t5SimValS=low_strssra(t5SimValS,"\n"," ");
				t5SimValS=low_strssra(t5SimValS,"^"," ");
			}else {	t5SimValS=nlsStrDup(" ");	}
			//printf("\n\t t5SimValS:%s",t5SimValS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
			if(!nlsIsStrNull(t5PerYieldDupS))
			{
				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
			}else {	t5PerYieldS=nlsStrDup(" ");	}
			//printf("\n\t t5PerYieldS:%s",t5PerYieldS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
			if(!nlsIsStrNull(t5PunStoreLocationDupS))
			{
				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
			}else {	t5PunStoreLocationS=nlsStrDup(" ");	}
			//printf("\n\t t5PunStoreLocationS:%s",t5PunStoreLocationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
			if(!nlsIsStrNull(t5AltPartNoDupS))
			{
				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"\n"," ");
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"^"," ");
			}else {	t5AltPartNoS=nlsStrDup(" ");	}
			//printf("\n\t t5AltPartNoS:%s",t5AltPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
			if(!nlsIsStrNull(t5RolledupWtDupS))
			{
				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
			}else {	t5RolledupWtS=nlsStrDup(" ");	}
			//printf("\n\t t5RolledupWtS:%s",t5RolledupWtS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
			if(!nlsIsStrNull(t5PFDModReqdDupS))
			{
				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
			}else {	t5PFDModReqdS=nlsStrDup(" ");	}
			//printf("\n\t t5PFDModReqdS:%s",t5PFDModReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
			if(!nlsIsStrNull(t5ToolIndentReqdDupS))
			{
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
			}else {	t5ToolIndentReqdS=nlsStrDup(" ");	}
			//printf("\n\t t5ToolIndentReqdS:%s",t5ToolIndentReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
			if(!nlsIsStrNull(CategoryNameDupS))
			{
				CategoryNameS=nlsStrDup(CategoryNameDupS);
				CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
				CategoryNameS=low_strssra(CategoryNameS,"^"," ");
			}else {	CategoryNameS=nlsStrDup(" ");	}
			printf("\n\t CategoryNameS:%s",CategoryNameS); fflush(stdout);


			// For effectivity extract
			t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
			// Get the configuration context object from the general context.
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
			// Set the option as "LkoCtxt" in the context object
			t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
			t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
			t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
			t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
			if(SetFlagforScope(soExpObj)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			printf("\n\t  setSize(soExpObj):%d    PartNumberDupS:%s ",setSize(soExpObj),PartNumberDupS); fflush(stdout);
			if(setSize(soExpObj)>0)
			{
				//if (nlsStrCmp(PartNumberDupS,"257649007502")==0)
				//{
				//	printf("\n --------------------------\n"); fflush(stdout);
				//	objDump(setGet(relObjSet,0));
				//	printf("\n --------------------------\n"); fflush(stdout);
				//}
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;
				//if(!nlsIsStrNull(ReveffDateFrom))
				if((!nlsIsStrNull(ReveffDateFrom)) && (nlsStrCmp(subString(ReveffDateFrom,0,4),"0001") != 0))  //added on 17.06.2017
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
					printf("\n\t if..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				}
				else
				{
					if((!nlsIsStrNull(ReveffDateTo)) && (nlsStrCmp(subString(ReveffDateTo,0,4),"0001") != 0))
					{
						ReveffDateFromDup = nlsStrDup(ReveffDateTo);
					}
					else
					{
						ReveffDateFromDup = nlsStrDup("-");
					}
					printf("\n\t else..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				}
				if(!nlsIsStrNull(ReveffDateTo))
				{
					ReveffDateToDup = nlsStrDup(ReveffDateTo);
					printf("\n\t if..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
				}
				else
				{
					if((!nlsIsStrNull(ReveffDateFrom)) && (nlsStrCmp(subString(ReveffDateFrom,0,4),"0001") != 0))  //added on 17.06.2017
					{
						ReveffDateToDup = nlsStrDup(ReveffDateFrom);
					}
					else
					{
						ReveffDateToDup = nlsStrDup("-");
					}
					printf("\n\t else..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
				}
			}
			else
			{
				ReveffDateFromDup = nlsStrDup("-");
				ReveffDateToDup = nlsStrDup("-");

				printf("\n\t else2..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				printf("\n\t else2..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
			t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
			//printf("\n\t t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
			t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
			//printf("\n\t t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
			t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
			//printf("\n\t t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
			t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
			//printf("\n\t t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
			t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
			//printf("\n\t t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
			t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
			//printf("\n\t t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
			t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
			//printf("\n\t t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
			t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
			//printf("\n\t t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
			t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
			//printf("\n\t t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
			t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
			//printf("\n\t t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
			if(!nlsIsStrNull(t5EstSheetReqdDupS))
			{
				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
			}else {	t5EstSheetReqdS=nlsStrDup(" ");	}
			//printf("\n\t t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CreationDate",&PartCreDateS));
			if(!nlsIsStrNull(PartCreDateS))
			{
				PartCreDateDupS=nlsStrDup(PartCreDateS);
			}
			else
			{
				PartCreDateDupS=nlsStrDup("-");
			}
			printf("\n\t PartCreDateDupS:%s",PartCreDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"LastUpdate",&PartModDateS));
			if(!nlsIsStrNull(PartModDateS))
			{
				PartModDateDupS=nlsStrDup(PartModDateS);
			}
			else
			{
				PartModDateDupS=nlsStrDup("-");
			}
			printf("\n\t PartModDateDupS:%s",PartModDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"Creator",&PartCreator));
			PartCreatorDup=nlsStrDup(PartCreator);
			printf("\n\t PartCreatorDup:%s",PartCreatorDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
			if(!nlsIsStrNull(t5AhdIntialAgencyS))
			{
				t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
			}
			else
			{
				t5AhdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
			if(!nlsIsStrNull(t5AhdMakeBuyIndS))
			{
				t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
			}
			else
			{
				t5AhdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
			if(!nlsIsStrNull(t5DwdIntialAgencyS))
			{
				t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
			}
			else
			{
				t5DwdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
			if(!nlsIsStrNull(t5DwdMakeBuyIndS))
			{
				t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
			}
			else
			{
				t5DwdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
			if(!nlsIsStrNull(t5JdlIntialAgencyS))
			{
				t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
			}
			else
			{
				t5JdlIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
			if(!nlsIsStrNull(t5JdlMakeBuyIndS))
			{
				t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
			}
			else
			{
				t5JdlMakeBuyIndSDup = nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
			if(!nlsIsStrNull(t5AhdStoreLocS))
			{
				t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
			}
			else
			{
				t5AhdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarStoreLocation",&t5CarStoreLocS));
			if(!nlsIsStrNull(t5CarStoreLocS))
			{
				t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
			}
			else
			{
				t5CarStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
			if(!nlsIsStrNull(t5DwdStoreLocS))
			{
				t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
			}
			else
			{
				t5DwdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
			if(!nlsIsStrNull(t5JdlStoreLocS))
			{
				t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
			}
			else
			{
				t5JdlStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
			if(!nlsIsStrNull(t5JsrStoreLocS))
			{
				t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
			}
			else
			{
				t5JsrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
			if(!nlsIsStrNull(t5LkoStoreLocS))
			{
				t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
			}
			else
			{
				t5LkoStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
			if(!nlsIsStrNull(t5PnrStoreLocS))
			{
				t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
			}
			else
			{
				t5PnrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
			if(!nlsIsStrNull(t5PunPCBUStoreLocS))
			{
				t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
			}
			else
			{
				t5PunPCBUStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
			if(!nlsIsStrNull(t5SgrStoreLocS))
			{
				t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
			}
			else
			{
				t5SgrStoreLocSDup = nlsStrDup("");
			}

			printf("\n\t DItype:%s",DItype); fflush(stdout);

			if (setSize(partMasterSO)>0)
			{
				if (nlsStrCmp(t5LeftRhDupS,"NA")==0)
				{
					LHRhPartNumberDup=nlsStrDup("NA");
				}
				else
				{
					LhRhPartExistFlag = 0;

					if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
						if(SetFlagforScope(hasRHItmMster)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}

						if (setSize(hasRHItmMster) > 0)
						{
							t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
							if(!nlsIsStrNull(LHRhPartNumber))
							{
								LHRhPartNumberDup=nlsStrDup(LHRhPartNumber);
							}
							else
							{
								LHRhPartNumberDup=nlsStrDup("NA");
							}
						}
						else
						{
							LHRhPartNumberDup=nlsStrDup("NA");
						}
					}

					if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
						if(SetFlagforScope(hasRHItmMster)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}

						if (setSize(hasRHItmMster) > 0)
						{
							t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
							if(!nlsIsStrNull(LHRhPartNumber))
							{
								LHRhPartNumberDup=nlsStrDup(LHRhPartNumber);
							}
							else
							{
								LHRhPartNumberDup=nlsStrDup("NA");
							}
						}
						else
						{
							LHRhPartNumberDup=nlsStrDup("NA");
						}
					}

					if (( nlsStrCmp(LHRhPartNumberDup,"NA") !=0 ) && (setSize(hasRHItmMster) > 0) )
					{
						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),t5LeftRhAttr,&t5RightLH));
						if(!nlsIsStrNull(t5RightLH))
						{
							t5RightLHDupS=nlsStrDup(t5RightLH);
						}
						else
						{
							t5RightLHDupS=nlsStrDup("NA");
						}

						fprintf(LhRhfp,"%s",t5LeftRhDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",PartNumberDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",t5RightLHDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",LHRhPartNumberDup);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",RevisionDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",SequenceDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"\n");
						fflush(LhRhfp);

						LhRhPartExistFlag = 1;
					}
				}
				printf("\n\t **LHRhPartNumberDup:%s",LHRhPartNumberDup); fflush(stdout);

				//query part again to get all attributes to copy in allpartsAllRev file

				//if((nlsStrCmp(LHRhPartNumberDup,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDup)))
				//{
				//	t5CheckMfail(GetLhRhTCPartProEInfo(LHRhPartNumberDup,PartNumberDupS,fpAllRev,OutJtfp,LhRHErr,mfail));
				//}
			}

			//fprintf(fpAllRev,"%d^",*Prtlevel);				//0	//Prtlevel

			if (charFlag == 1)
			{
				fprintf(fpAllRev,"%s",InpPartNumberS);			//1		//In Function GetGenTCPartProEInfo
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"%s",PartNumberDupS);			//1		//In Function GetGenTCPartProEInfo
				fprintf(fpAllRev,"^");
			}
			fprintf(fpAllRev,"%s",RevisionDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SequenceDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",NomenclatureDupS);	//desc
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",PartTypeDupS);		//PartType
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",ProjectNameDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DesignGroupDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DocRemarkDupS);		//mod_desc
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5DrawingNoDupS)){
				fprintf(fpAllRev,"%s",t5DrawingNoDupS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"%s",t5DrawingIndDupS);		//10
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MatlClassDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MaterialInDrwDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",MaterialThickNessDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5LeftRhDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DsgnOwnDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ModelIndicatorDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",UnitOfMeasureDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIndDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",LifeCycleStateDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIDDupS);				//20
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",WeightDupS);					//21
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SpareIndDupS);				//22
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5CMVRCertificationS)){
				fprintf(fpAllRev,"%s",t5CMVRCertificationS);//23
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ClassificationHazS)){
				fprintf(fpAllRev,"%s",t5ClassificationHazS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ConfigIDS)){
				fprintf(fpAllRev,"%s",t5ConfigIDS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5DismantableS)){
				fprintf(fpAllRev,"%s",t5DismantableS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DsgnDeptS)){
				fprintf(fpAllRev,"%s",t5DsgnDeptS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5EnvelopeDimenS)){
				fprintf(fpAllRev,"%s",t5EnvelopeDimenS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HazardousContS)){
				fprintf(fpAllRev,"%s",t5HazardousContS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HomologationReqdS)){
				fprintf(fpAllRev,"%s",t5HomologationReqdS);	//30
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ListRecSparess)){
				fprintf(fpAllRev,"%s",t5ListRecSparess);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5NcPartNoS)){
				fprintf(fpAllRev,"%s",t5NcPartNoS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartCodeS)){
				fprintf(fpAllRev,"%s",t5PartCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartPropertyS)){
				fprintf(fpAllRev,"%s",t5PartPropertyS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartStatusS)){
				fprintf(fpAllRev,"%s",t5PartStatusS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PkgStdS)){
				fprintf(fpAllRev,"%s",t5PkgStdS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ProductS)){
				fprintf(fpAllRev,"%s",t5ProductS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtCatCodeS)){
				fprintf(fpAllRev,"%s",t5PrtCatCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunIntialAgS)){
				fprintf(fpAllRev,"%s",t5PunIntialAgS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
				fprintf(fpAllRev,"%s",t5PunMakeBuyIndS);	//40
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecoverableS)){
				fprintf(fpAllRev,"%s",t5RecoverableS);		//41
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecyclabilityS)){
				fprintf(fpAllRev,"%s",t5RecyclabilityS);	//42
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RefPartNumberS)){
				fprintf(fpAllRev,"%s",t5RefPartNumberS);	//43
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ReliabilityS)){
				fprintf(fpAllRev,"%s",t5ReliabilityS);		//44
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SpareCriteriaS)){
				fprintf(fpAllRev,"%s",t5SpareCriteriaS);	//45
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfPrtStdS)){
				fprintf(fpAllRev,"%s",t5SurfPrtStdS);		//46
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SamplesToApprS)){
				fprintf(fpAllRev,"%s",t5SamplesToApprS);	//47
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AsmDisposalS)){
				fprintf(fpAllRev,"%s",t5AsmDisposalS);		//48
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5FinDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5FinDisposalInstrS);	//49
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5RPDisposalInstrS);	//50
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5SPDisposalInstrS);	//51
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5WIPDisposalInstrS);	//52
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5LastModByS)){
				fprintf(fpAllRev,"%s",t5LastModByS);		//53
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev,"loader^");
			}


			if(!nlsIsStrNull(t5VerCreatorS)){
				fprintf(fpAllRev,"%s",t5VerCreatorS);		//54
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CAEDocES)){
				fprintf(fpAllRev,"%s",t5CAEDocES);			//55
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CoatedS)){
				fprintf(fpAllRev,"%s",t5CoatedS);			//56
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5ConvDocS)){
				fprintf(fpAllRev,"%s",t5ConvDocS);			//57
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcRevS);	//58
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcSeqS);	//59
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AppCodeS)){
				fprintf(fpAllRev,"%s",t5AppCodeS);			//60
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RqstNumS)){
				fprintf(fpAllRev,"%s",t5RqstNumS);			//61
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RsnCodeS)){
				fprintf(fpAllRev,"%s",t5RsnCodeS);			//62
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfaceAreaS)){
				fprintf(fpAllRev,"%s",t5SurfaceAreaS);		//63
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5VolumeS)){
				fprintf(fpAllRev,"%s",t5VolumeS);			//64
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CarIntialAgencyS)){
				fprintf(fpAllRev,"%s",t5CarIntialAgencyS);	//65
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
				fprintf(fpAllRev,"%s",t5CarMakeBuyIndiS);	//66
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ErcIndNameS)){
				fprintf(fpAllRev,"%s",t5ErcIndNameS);		//67
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PostRelReqS)){
				fprintf(fpAllRev,"%s",t5PostRelReqS);		//68
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ItmCategoryS)){
				fprintf(fpAllRev,"%s",t5ItmCategoryS);		//69
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CopReqS)){
				fprintf(fpAllRev,"%s",t5CopReqS);			//70
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplInvalidateS)){
				fprintf(fpAllRev,"%s",t5AplInvalidateS);	//71
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtValiStatusS)){
				fprintf(fpAllRev,"%s",t5PrtValiStatusS);	//72
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DRSubStateS)){
				fprintf(fpAllRev,"%s",t5DRSubStateS);		//73
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5KnxtDocIndS)){
				fprintf(fpAllRev,"%s",t5KnxtDocIndS);		//74
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5SimValS)){
				fprintf(fpAllRev,"%s",t5SimValS);			//75
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PerYieldS)){
				fprintf(fpAllRev,"%s",t5PerYieldS);			//76
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunStoreLocationS)){
				fprintf(fpAllRev,"%s",t5PunStoreLocationS);	//77
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AltPartNoS)){
				fprintf(fpAllRev,"%s",t5AltPartNoS);		//78
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5RolledupWtS)){
				fprintf(fpAllRev,"%s",t5RolledupWtS);		//79
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PFDModReqdS)){
				fprintf(fpAllRev,"%s",t5PFDModReqdS);		//80
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ToolIndentReqdS)){
				fprintf(fpAllRev,"%s",t5ToolIndentReqdS);	//81
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(CategoryNameS)){
				fprintf(fpAllRev,"%s",CategoryNameS);		//82
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(ReveffDateFromDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateFromDup);	//83
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(ReveffDateToDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateToDup);		//84
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			//fprintf(fpAllRev,"NA^");						//85   //LHRhPartNumberDup
			if(!nlsIsStrNull(LHRhPartNumberDup))
			{
				fprintf(fpAllRev,"%s",LHRhPartNumberDup);	//85	//added on 04.04.2017
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"NA^");
			}

			if(!nlsIsStrNull(InstanceRevSeqS))
			{
				fprintf(fpAllRev,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //86   //InstanceRevSeqS
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			//below attributes are added by rrr on 14.10.2016
			if(!nlsIsStrNull(t5JsrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5JsrIntialAgencyS);		//87
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5JsrMakeBuyIndiS);		//88
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5LkoIntialAgencyS);		//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5LkoMakeBuyIndiS);		//90
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PnrIntialAgencyS);		//91
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PnrMakeBuyIndiS);		//92
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUIntialAgencyS);	//93
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUMakeBuyIndiS);	//94
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5SgrIntialAgencyS);		//95
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5SgrMakeBuyIndiS);		//96
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5EstSheetReqdS))
			{
				fprintf(fpAllRev,"%s",t5EstSheetReqdS);			//97
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(PartCreDateDupS))
			{
				fprintf(fpAllRev,"%s",PartCreDateDupS);			//98
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartModDateDupS))
			{
				fprintf(fpAllRev,"%s",PartModDateDupS);			//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartCreatorDup))
			{
				fprintf(fpAllRev,"%s",PartCreatorDup);			//100
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"loader^");
			}
			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5AhdIntialAgencySDup);	//101
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5AhdMakeBuyIndSDup);		//102
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5DwdIntialAgencySDup);	//103
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5DwdMakeBuyIndSDup);		//104
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5JdlIntialAgencySDup);	//105
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5JdlMakeBuyIndSDup);		//106
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5AhdStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5AhdStoreLocSDup);		//107
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5CarStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5CarStoreLocSDup);		//108
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5DwdStoreLocSDup);		//109
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5JdlStoreLocSDup);		//110
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5JsrStoreLocSDup);		//111
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5LkoStoreLocSDup);		//112
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5PnrStoreLocSDup);		//113
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUStoreLocSDup);	//114
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5SgrStoreLocSDup);		//115
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			/*if(!nlsIsStrNull(DItype))
			{
				fprintf(fpAllRev,"%s",DItype);		//116
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"TYPE_INVALID^");
			}*/

			fprintf(fpAllRev,"\n");
			fflush(fpAllRev);

			printf("\n Inside fpAllRev --------------------------123\n"); fflush(stdout);

//			printf("\n Inside fp --------------------------125\n"); fflush(stdout);
//
//			fprintf(fp,"%d",*level);			//1
//			fprintf(fp,"^");
//			fprintf(fp,"%s",PartNumberDupS);	//2
//			fprintf(fp,"^");
//			fprintf(fp,"%s",RevisionDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",SequenceDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",NomenclatureDupS);	//desc
//			fprintf(fp,"^");
//			fprintf(fp,"%s",PartTypeDupS);		//PartType
//			fprintf(fp,"^");
//			fprintf(fp,"%s",ProjectNameDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DesignGroupDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DocRemarkDupS);		//mod_desc
//			fprintf(fp,"^");
//
//			if(!nlsIsStrNull(t5DrawingNoDupS)){
//				fprintf(fp,"%s",t5DrawingNoDupS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			fprintf(fp,"%s",t5DrawingIndDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5MatlClassDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5MaterialInDrwDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",MaterialThickNessDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5LeftRhDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DsgnOwnDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ModelIndicatorDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",UnitOfMeasureDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ColourIndDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",LifeCycleStateDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ColourIDDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",WeightDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",SpareIndDupS);
//			fprintf(fp,"^");
//
//			if(!nlsIsStrNull(t5CMVRCertificationS)){
//				fprintf(fp,"%s",t5CMVRCertificationS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ClassificationHazS)){
//				fprintf(fp,"%s",t5ClassificationHazS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ConfigIDS)){
//				fprintf(fp,"%s",t5ConfigIDS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5DismantableS)){
//				fprintf(fp,"%s",t5DismantableS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5DsgnDeptS)){
//				fprintf(fp,"%s",t5DsgnDeptS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5EnvelopeDimenS)){
//				fprintf(fp,"%s",t5EnvelopeDimenS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5HazardousContS)){
//				fprintf(fp,"%s",t5HazardousContS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5HomologationReqdS)){
//				fprintf(fp,"%s",t5HomologationReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ListRecSparess)){
//				fprintf(fp,"%s",t5ListRecSparess);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5NcPartNoS)){
//				fprintf(fp,"%s",t5NcPartNoS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartCodeS)){
//				fprintf(fp,"%s",t5PartCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartPropertyS)){
//				fprintf(fp,"%s",t5PartPropertyS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartStatusS)){
//				fprintf(fp,"%s",t5PartStatusS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5PkgStdS)){
//				fprintf(fp,"%s",t5PkgStdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ProductS)){
//				fprintf(fp,"%s",t5ProductS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PrtCatCodeS)){
//				fprintf(fp,"%s",t5PrtCatCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunIntialAgS)){
//				fprintf(fp,"%s",t5PunIntialAgS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
//				fprintf(fp,"%s",t5PunMakeBuyIndS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RecoverableS)){
//				fprintf(fp,"%s",t5RecoverableS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RecyclabilityS)){
//				fprintf(fp,"%s",t5RecyclabilityS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RefPartNumberS)){
//				fprintf(fp,"%s",t5RefPartNumberS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ReliabilityS)){
//				fprintf(fp,"%s",t5ReliabilityS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SpareCriteriaS)){
//				fprintf(fp,"%s",t5SpareCriteriaS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SurfPrtStdS)){
//				fprintf(fp,"%s",t5SurfPrtStdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SamplesToApprS)){
//				fprintf(fp,"%s",t5SamplesToApprS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AsmDisposalS)){
//				fprintf(fp,"%s",t5AsmDisposalS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5FinDisposalInstrS)){
//				fprintf(fp,"%s",t5FinDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RPDisposalInstrS)){
//				fprintf(fp,"%s",t5RPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SPDisposalInstrS)){
//				fprintf(fp,"%s",t5SPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
//				fprintf(fp,"%s",t5WIPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5LastModByS)){
//				fprintf(fp,"%s",t5LastModByS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp,"loader^");
//			}
//
//
//			if(!nlsIsStrNull(t5VerCreatorS)){
//				fprintf(fp,"%s",t5VerCreatorS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CAEDocES)){
//				fprintf(fp,"%s",t5CAEDocES);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5CoatedS)){
//				fprintf(fp,"%s",t5CoatedS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5ConvDocS)){
//				fprintf(fp,"%s",t5ConvDocS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
//				fprintf(fp,"%s",t5AplCopyOfErcRevS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
//				fprintf(fp,"%s",t5AplCopyOfErcSeqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AppCodeS)){
//				fprintf(fp,"%s",t5AppCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RqstNumS)){
//				fprintf(fp,"%s",t5RqstNumS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RsnCodeS)){
//				fprintf(fp,"%s",t5RsnCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SurfaceAreaS)){
//				fprintf(fp,"%s",t5SurfaceAreaS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5VolumeS)){
//				fprintf(fp,"%s",t5VolumeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CarIntialAgencyS)){
//				fprintf(fp,"%s",t5CarIntialAgencyS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
//				fprintf(fp,"%s",t5CarMakeBuyIndiS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ErcIndNameS)){
//				fprintf(fp,"%s",t5ErcIndNameS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PostRelReqS)){
//				fprintf(fp,"%s",t5PostRelReqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ItmCategoryS)){
//				fprintf(fp,"%s",t5ItmCategoryS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CopReqS)){
//				fprintf(fp,"%s",t5CopReqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AplInvalidateS)){
//				fprintf(fp,"%s",t5AplInvalidateS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PrtValiStatusS)){
//				fprintf(fp,"%s",t5PrtValiStatusS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5DRSubStateS)){
//				fprintf(fp,"%s",t5DRSubStateS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5KnxtDocIndS)){
//				fprintf(fp,"%s",t5KnxtDocIndS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5SimValS)){
//				fprintf(fp,"%s",t5SimValS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PerYieldS)){
//				fprintf(fp,"%s",t5PerYieldS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunStoreLocationS)){
//				fprintf(fp,"%s",t5PunStoreLocationS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AltPartNoS)){
//				fprintf(fp,"%s",t5AltPartNoS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5RolledupWtS)){
//				fprintf(fp,"%s",t5RolledupWtS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5PFDModReqdS)){
//				fprintf(fp,"%s",t5PFDModReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ToolIndentReqdS)){
//				fprintf(fp,"%s",t5ToolIndentReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(CategoryNameS)){
//				fprintf(fp,"%s",CategoryNameS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(ReveffDateFromDup))
//			{
//				fprintf(fp,"%s",ReveffDateFromDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(ReveffDateToDup))
//			{
//				fprintf(fp,"%s",ReveffDateToDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			fprintf(fp,"NA^");					   //LhRhPartNumberDup
//
//			if(!nlsIsStrNull(InstanceRevSeqS))
//			{
//				fprintf(fp,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //InstanceRevSeqS
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5JsrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5JsrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5JsrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5LkoIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5LkoMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5PnrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5PnrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5PunPCBUIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5PunPCBUMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5SgrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5SgrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5EstSheetReqdS))
//			{
//				fprintf(fp,"%s",t5EstSheetReqdS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(PartCreDateDupS))
//			{
//				fprintf(fp,"%s",PartCreDateDupS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"-^");
//			}
//			if(!nlsIsStrNull(PartModDateDupS))
//			{
//				fprintf(fp,"%s",PartModDateDupS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"-^");
//			}
//
//			if(!nlsIsStrNull(PartCreatorDup))
//			{
//				fprintf(fp,"%s",PartCreatorDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"loader^");
//			}
//			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5AhdIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5AhdMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5DwdIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5DwdMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5JdlIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5JdlMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5AhdStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5AhdStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5CarStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5CarStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5DwdStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5JdlStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JsrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5JsrStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5LkoStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5PnrStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5PunPCBUStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5SgrStoreLocSDup);		//116
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(DItype))
//			{
//				fprintf(fp,"%s",DItype);			//117
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"TYPE_INVALID^");
//			}
//			fprintf(fp,"\n");
//			fflush(fp);

			if ((m == (setSize(PartSO)-1)) && (setSize(partMasterSO)>0))	// LH/RH is added on 04.04.2017 by RRR
			{
				//query part again to get all attributes to copy in allpartsAllRev file
				if((nlsStrCmp(LHRhPartNumberDup,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDup)))
				{
					LHRHUsesDataItemObjP = NULL;
					LHRHTCObjP = NULL;

					t5CheckMfail(GetGenTCPartProEInfoLHRH(LHRHUsesDataItemObjP,LHRHTCObjP, LHRhPartNumberDup, "NR", "1", "", mfail, Prtlevel));
				}
			}

			if (charFlag == 1)
			{
				break;
			}

		} // for loop of setSize(PartSO)
	} //if condn end for setSize(PartSO)
	else
	{
		printf("\n Inside fpAllRev ---------GetGenTCPartProEInfo-----------------131\n"); fflush(stdout);

		//fprintf(fpAllRev,"%d^",*Prtlevel);		//0	//Prtlevel

		fprintf(fpAllRev,"%s",InpPartNumberS);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",InpPartRev);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",InpPartSeq);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","Dummy Part for Proe"); //NomenclatureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","D");		//PartTypeDupS		// Dummy PartType
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","1111");	//ProjectNameDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","11");	//t5DesignGroupDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//mod_desc   t5DocRemarkDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5DrawingNoDupS
		fprintf(fpAllRev,"%s","N");		//t5DrawingIndDupS			//10
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");	//t5MatlClassDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//t5MaterialInDrwDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//MaterialThickNessDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");		//t5LeftRhDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","TELPUN");	//t5DsgnOwnDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","N");		//t5ModelIndicatorDupS;  Y/N/blank
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","4");		//UnitOfMeasureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","N");		//t5ColourIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","LcsReview");//LifeCycleStateDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5ColourIDDupS		//20
		fprintf(fpAllRev,"%s","0");		//WeightDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//SpareIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5CMVRCertification
		fprintf(fpAllRev," ^");			//t5ClassificationHaz
		fprintf(fpAllRev," ^");			//t5ConfigID
		fprintf(fpAllRev," ^");			//t5Dismantable
		fprintf(fpAllRev," ^");			//t5DsgnDeptS
		fprintf(fpAllRev," ^");			//t5EnvelopeDimen
		fprintf(fpAllRev," ^");			//t5HazardousCont
		fprintf(fpAllRev," ^");			//t5HomologationReqd		//30
		fprintf(fpAllRev," ^");			//t5ListRecSpares
		fprintf(fpAllRev," ^");			//t5NcPartNoS
		fprintf(fpAllRev," ^");			//t5PartCodeS
		fprintf(fpAllRev," ^");			//t5PartPropertyS
		fprintf(fpAllRev," ^");			//t5PartStatusS
		fprintf(fpAllRev," ^");			//t5PkgStdS
		fprintf(fpAllRev," ^");			//t5ProductS
		fprintf(fpAllRev," ^");			//t5PrtCatCodeS
		fprintf(fpAllRev," ^");			//t5PunIntialAgS
		fprintf(fpAllRev," ^");			//t5PunMakeBuyIndS			//40
		fprintf(fpAllRev," ^");			//t5RecoverableS
		fprintf(fpAllRev," ^");			//t5RecyclabilityS
		fprintf(fpAllRev," ^");			//t5RefPartNumberS
		fprintf(fpAllRev," ^");			//t5ReliabilityS
		fprintf(fpAllRev," ^");			//t5SpareCriteriaS
		fprintf(fpAllRev," ^");			//t5SurfPrtStdS
		fprintf(fpAllRev," ^");			//t5SamplesToApprS
		fprintf(fpAllRev," ^");			//t5AsmDisposalS
		fprintf(fpAllRev," ^");			//t5FinDisposalInstrS
		fprintf(fpAllRev," ^");			//t5RPDisposalInstrS		//50
		fprintf(fpAllRev," ^");			//t5SPDisposalInstrS
		fprintf(fpAllRev," ^");			//t5WIPDisposalInstrS
		fprintf(fpAllRev,"loader^");	//t5LastModByS
		fprintf(fpAllRev," ^");			//t5VerCreatorS
		fprintf(fpAllRev," ^");			//t5CAEDocES

		fprintf(fpAllRev,"%s","N");		//t5CoatedS
		fprintf(fpAllRev,"^");

		fprintf(fpAllRev," ^");			//t5ConvDocS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcRevS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcSeqS
		fprintf(fpAllRev," ^");			//t5AppCodeS				//60
		fprintf(fpAllRev," ^");			//t5RqstNumS
		fprintf(fpAllRev," ^");			//t5RsnCodeS
		fprintf(fpAllRev," ^");			//t5SurfaceAreaS
		fprintf(fpAllRev," ^");			//t5VolumeS
		fprintf(fpAllRev," ^");			//t5CarIntialAgencyS
		fprintf(fpAllRev," ^");			//t5CarMakeBuyIndiS
		fprintf(fpAllRev," ^");			//t5ErcIndNameS
		fprintf(fpAllRev," ^");			//t5PostRelReqS
		fprintf(fpAllRev," ^");			//t5ItmCategoryS
		fprintf(fpAllRev," ^");			//t5CopReqS					//70
		fprintf(fpAllRev," ^");			//t5AplInvalidateS
		fprintf(fpAllRev," ^");			//t5PrtValiStatusS
		fprintf(fpAllRev," ^");			//t5DRSubStateS
		fprintf(fpAllRev," ^");			//t5KnxtDocIndS
		fprintf(fpAllRev," ^");			//t5SimValS
		fprintf(fpAllRev," ^");			//t5PerYieldS
		fprintf(fpAllRev," ^");			//t5PunStoreLocationS
		fprintf(fpAllRev," ^");			//t5AltPartNoS
		fprintf(fpAllRev," ^");			//t5RolledupWtS
		fprintf(fpAllRev," ^");			//t5PFDModReqdS				//80
		fprintf(fpAllRev," ^");			//t5ToolIndentReqdS
		fprintf(fpAllRev," ^");			//CategoryNameS
		fprintf(fpAllRev,"-^");			//ReveffDateFromDup
		fprintf(fpAllRev,"-^");			//ReveffDateToDup			//84
		fprintf(fpAllRev,"NA^");		//LeftRhPartDup				//85

		fprintf(fpAllRev," ^");			//Instance with semicolon separated Rev;Seq		//86

		fprintf(fpAllRev," ^");			//t5JsrIntialAgencyS		//87
		fprintf(fpAllRev," ^");			//t5JsrMakeBuyIndiS			//88
		fprintf(fpAllRev," ^");			//t5LkoIntialAgencyS		//99
		fprintf(fpAllRev," ^");			//t5LkoMakeBuyIndiS			//90
		fprintf(fpAllRev," ^");			//t5PnrIntialAgencyS		//91
		fprintf(fpAllRev," ^");			//t5PnrMakeBuyIndiS			//92
		fprintf(fpAllRev," ^");			//t5PunPCBUIntialAgencyS	//93
		fprintf(fpAllRev," ^");			//t5PunPCBUMakeBuyIndiS		//94
		fprintf(fpAllRev," ^");			//t5SgrIntialAgencyS		//95
		fprintf(fpAllRev," ^");			//t5SgrMakeBuyIndiS			//96
		fprintf(fpAllRev," ^");			//t5EstSheetReqdS			//97
		fprintf(fpAllRev,"-^");			//PartCreDateDupS			//98
		fprintf(fpAllRev,"-^");			//PartModDateDupS			//99
		fprintf(fpAllRev,"loader^");	//PartCreatorDup			//100
		fprintf(fpAllRev," ^");			//t5AhdIntialAgencySDup		//101
		fprintf(fpAllRev," ^");			//t5AhdMakeBuyIndSDup		//102
		fprintf(fpAllRev," ^");			//t5DwdIntialAgencySDup		//103
		fprintf(fpAllRev," ^");			//t5DwdMakeBuyIndSDup		//104
		fprintf(fpAllRev," ^");			//t5JdlIntialAgencySDup		//105
		fprintf(fpAllRev," ^");			//t5JdlMakeBuyIndSDup		//106
		fprintf(fpAllRev," ^");			//t5AhdStoreLocSDup			//107
		fprintf(fpAllRev," ^");			//t5CarStoreLocSDup			//108
		fprintf(fpAllRev," ^");			//t5DwdStoreLocSDup			//109
		fprintf(fpAllRev," ^");			//t5JdlStoreLocSDup			//110
		fprintf(fpAllRev," ^");			//t5JsrStoreLocSDup			//111
		fprintf(fpAllRev," ^");			//t5LkoStoreLocSDup			//112
		fprintf(fpAllRev," ^");			//t5PnrStoreLocSDup			//113
		fprintf(fpAllRev," ^");			//t5PunPCBUStoreLocSDup		//114
		fprintf(fpAllRev," ^");			//t5SgrStoreLocSDup			//115

		//fprintf(fpAllRev,"COMP_TYPE_UA^");//DItype					//116

		fprintf(fpAllRev,"\n"); fflush(fpAllRev);
	}
	//printf("\n");

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartSO);
		t5FreeSqlPtr(Sql_ptr);

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
status GetGenTCPartProEInfoLHRH(ObjectPtr DataItemObjP, ObjectPtr TCObjP, string InpPartNumberS, string InpPartRev, string InpPartSeq, string InstanceRevSeqS, integer* mfail , int *Prtlevel)
{
	char *mod_name = "GetGenTCPartProEInfoLHRH";

	status dstat = OKAY;

	string PartNumberDupS=NULL;
	string PartNumberS=NULL;
	string docClass=NULL;
	string PartRevSeq = NULL;

	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string t5ColourIDS = NULL;
	string t5ColourIDDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	string t5CMVRCertificationS = NULL;
	string t5CMVRCertificationDupS = NULL;
	string t5ClassificationHazDupS = NULL;
	string t5ClassificationHazS = NULL;
	string t5ConfigIDS = NULL;
	string t5ConfigIDDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5EnvelopeDimenS = NULL;
	string t5EnvelopeDimenDupS = NULL;
	string t5HazardousContS = NULL;
	string t5HazardousContDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5ListRecSparess = NULL;
	string t5ListRecSparesDups = NULL;
	string t5NcPartNoS = NULL;
	string t5PartCodeS = NULL;
	string t5NcPartNoDupS = NULL;
	string t5PartCodeDupS = NULL;
	string t5PartPropertyS = NULL;
	string t5PartPropertyDupS = NULL;
	string t5PartStatusS = NULL;
	string t5PartStatusDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PrtCatCodeS = NULL;
	string t5PrtCatCodeDupS = NULL;
	string t5PunIntialAgS = NULL;
	string t5PunIntialAgDupS = NULL;
	string t5PunMakeBuyIndS = NULL;
	string t5PunMakeBuyIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5RefPartNumberS = NULL;
	string t5RefPartNumberDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SurfPrtStdS = NULL;
	string t5SurfPrtStdDupS = NULL;
	string t5SamplesToApprS = NULL;
	string t5SamplesToApprDupS = NULL;
	string t5AsmDisposalS = NULL;
	string t5AsmDisposalDupS = NULL;
	string t5FinDisposalInstrS = NULL;
	string t5FinDisposalInstrDupS = NULL;
	string t5RPDisposalInstrS = NULL;
	string t5RPDisposalInstrDupS = NULL;
	string t5SPDisposalInstrS = NULL;
	string t5SPDisposalInstrDupS = NULL;
	string t5WIPDisposalInstrS = NULL;
	string t5WIPDisposalInstrDupS = NULL;
	string t5LastModByS = NULL;
	string t5LastModByDupS = NULL;
	string t5VerCreatorS = NULL;
	string t5VerCreatorDupS = NULL;
	string t5CAEDocES = NULL;
	string t5CAEDocEDupS = NULL;
	string t5CoatedS = NULL;
	string t5CoatedDupS = NULL;
	string t5ConvDocS = NULL;
	string t5ConvDocDupS = NULL;
	string t5AplCopyOfErcRevS = NULL;
	string t5AplCopyOfErcRevDupS = NULL;
	string t5AplCopyOfErcSeqS = NULL;
	string t5AplCopyOfErcSeqDupS = NULL;
	string t5AppCodeS = NULL;
	string t5AppCodeDupS = NULL;
	string t5RqstNumS = NULL;
	string t5RqstNumDupS = NULL;
	string t5RsnCodeS = NULL;
	string t5RsnCodeDupS = NULL;
	string t5SurfaceAreaS = NULL;
	string t5SurfaceAreaDupS = NULL;
	string t5VolumeS = NULL;
	string t5VolumeDupS = NULL;
	string t5CarIntialAgencyS = NULL;
	string t5CarIntialAgencyDupS = NULL;
	string t5CarMakeBuyIndiS = NULL;
	string t5CarMakeBuyIndiDupS = NULL;
	string t5ErcIndNameS = NULL;
	string t5ErcIndNameDupS = NULL;
	string t5PostRelReqS = NULL;
	string t5PostRelReqDupS = NULL;
	string t5ItmCategoryS = NULL;
	string t5ItmCategoryDupS = NULL;
	string t5CopReqS = NULL;
	string t5CopReqDupS = NULL;
	string t5AplInvalidateS = NULL;
	string t5AplInvalidateDupS = NULL;
	string t5PrtValiStatusS = NULL;
	string t5PrtValiStatusDupS = NULL;
	string t5DRSubStateS = NULL;
	string t5DRSubStateDupS = NULL;
	string t5KnxtDocIndS = NULL;
	string t5KnxtDocIndDupS = NULL;
	string t5SimValS = NULL;
	string t5SimValDupS = NULL;
	string t5PerYieldS = NULL;
	string t5PerYieldDupS = NULL;
	string t5PunStoreLocationS = NULL;
	string t5PunStoreLocationDupS = NULL;
	string t5AltPartNoS = NULL;
	string t5AltPartNoDupS = NULL;
	string t5RolledupWtS = NULL;
	string t5RolledupWtDupS = NULL;
	string t5EstSheetReqdS = NULL;
	string t5EstSheetReqdDupS = NULL;
	string t5PFDModReqdS = NULL;
	string t5PFDModReqdDupS = NULL;
	string t5ToolIndentReqdS = NULL;
	string t5ToolIndentReqdDupS = NULL;
	string CategoryNameDupS = NULL;
	string CategoryNameS = NULL;
	string ReveffDateFrom = NULL;
	string ReveffDateFromDup = NULL;
	string ReveffDateTo = NULL;
	string ReveffDateToDup = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndiS = NULL;
	string t5JsrMakeBuyIndiDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndiS = NULL;
	string t5LkoMakeBuyIndiDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndiS = NULL;
	string t5PnrMakeBuyIndiDupS = NULL;
	string t5PunPCBUIntialAgencyS = NULL;
	string t5PunPCBUIntialAgencyDupS = NULL;
	string t5PunPCBUMakeBuyIndiS = NULL;
	string t5PunPCBUMakeBuyIndiDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndiS = NULL;
	string t5SgrMakeBuyIndiDupS = NULL;
	string PartCreDateS = NULL;
	string PartCreDateDupS = NULL;
	string PartModDateS = NULL;
	string PartModDateDupS = NULL;
	string PartCreator = NULL;
	string PartCreatorDup = NULL;
	string t5AhdIntialAgencyS = NULL;
	string t5AhdIntialAgencySDup = NULL;
	string t5AhdMakeBuyIndS = NULL;
	string t5AhdMakeBuyIndSDup = NULL;
	string t5AhdStoreLocS = NULL;
	string t5AhdStoreLocSDup = NULL;
	string t5CarStoreLocS = NULL;
	string t5CarStoreLocSDup = NULL;
	string t5DwdIntialAgencyS = NULL;
	string t5DwdIntialAgencySDup = NULL;
	string t5DwdMakeBuyIndS = NULL;
	string t5DwdMakeBuyIndSDup = NULL;
	string t5DwdStoreLocS = NULL;
	string t5DwdStoreLocSDup = NULL;
	string t5JdlIntialAgencyS = NULL;
	string t5JdlIntialAgencySDup = NULL;
	string t5JdlMakeBuyIndS = NULL;
	string t5JdlMakeBuyIndSDup = NULL;
	string t5JdlStoreLocS = NULL;
	string t5JdlStoreLocSDup = NULL;
	string t5JsrStoreLocS = NULL;
	string t5JsrStoreLocSDup = NULL;
	string t5LkoStoreLocS = NULL;
	string t5LkoStoreLocSDup = NULL;
	string t5PnrStoreLocS = NULL;
	string t5PnrStoreLocSDup = NULL;
	string t5PunPCBUStoreLocS = NULL;
	string t5PunPCBUStoreLocSDup = NULL;
	string t5SgrStoreLocS = NULL;
	string t5SgrStoreLocSDup = NULL;
	string DItype = NULL;
	string ClassNm = NULL;
	string ClassNmDup = NULL;
	string LHRhPartNumber = NULL;
	string LHRhPartNumberDup = NULL;
	//string t5RightLH = NULL;
	//string t5RightLHDupS = NULL;
	string temp2Dup = NULL;

	SetOfObjects PartSO = NULL ;
	SetOfObjects partMasterSO = NULL;
	SetOfObjects partMasterRelSO = NULL;
	SetOfObjects docObjs = NULL ;
	SetOfObjects docRelObjs = NULL ;
	SetOfObjects latestDocs = NULL ;
	SetOfObjects latestRelDocs = NULL ;
	SetOfObjects soExpObj = NULL ;
	SetOfObjects relObjSet = NULL ;
	SetOfObjects hasRHItmMster = NULL ;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr MasterObjOP=NULL;
	ObjectPtr docOPtr=NULL;
	ObjectPtr contextObj = NULL;
	ObjectPtr genContextObj	= NULL;
	SqlPtr Sql_ptr = NULL;

	int m = 0;
	int noOfDocs = 0;
	int tmpStrlen = 0;
	int i = 0;
	int charFlag = 0;
	int LhRhPartExistFlag = 0;

	char tempstr[50]={0};
	char *p;

	PartRevSeq = nlsStrAlloc(50);
	DItype = nlsStrAlloc(50);

	if (DataItemObjP != NULL)
	{
		t5CheckDstat(objGetAttribute(DataItemObjP,"Class",&ClassNm));
		if(!nlsIsStrNull(ClassNm))
		{
			ClassNmDup=nlsStrDup(ClassNm);
		}

		if(nlsStrStr(ClassNmDup,"ProAsm") !=NULL)
		{
			nlsStrCpy(DItype,"ASSY_TYPE_UA");
		}
		else if(nlsStrStr(ClassNmDup,"ProPrt") !=NULL)
		{
			nlsStrCpy(DItype,"COMP_TYPE_UA");
		}
		else
		{
			nlsStrCpy(DItype,"TYPE_INVALID");
		}
	}
	else
	{
		nlsStrCpy(DItype,"USES_INVALID");
	}

	/*if( (!nlsIsStrNull(InpPartRev)) && (!nlsIsStrNull(InpPartSeq)) )
	{
		if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
			(dstat = oiSqlWhereBegParen(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,RevisionAttr,InpPartRev))||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,SequenceAttr,InpPartSeq))||
			(dstat = oiSqlWhereEndParen(Sql_ptr))||
			(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
		if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
	}
	else	// Generic Case only
	{*/
		if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
			(dstat = oiSqlWhereBegParen(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,InpPartNumberS))||
			(dstat = oiSqlWhereEndParen(Sql_ptr))||
			(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
		if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
	//}
	printf("\nLHRH..No:of Parts are :- %d",setSize(PartSO));

	if (setSize(PartSO) == 0)
	{
		charFlag = 0;
		strcpy(tempstr,"");
		strcpy(tempstr,InpPartNumberS);

		tmpStrlen = strlen(tempstr);
		//printf ("\n tmpStrlen  %d",tmpStrlen);
		for(i=0;i<tmpStrlen;i++)
		{
			if (!isdigit(tempstr[i]))
			{
				//printf ("\n alpha");
				charFlag = 1;
				printf ("\n charFlag %d found hence skipping..",charFlag);
				break;
			}
		}

		if (charFlag == 1)
		{
			temp2Dup=nlsStrDup(InpPartNumberS);

			printf ("\nLHRH..Before conversion: [%s]", temp2Dup);
			for (p = temp2Dup; *p != '\0'; ++p)
			{
				*p = tolower(*p);
			}
			printf ("\t LHRH..After conversion: [%s]", temp2Dup);

			if(	(dstat = oiSqlCreateSelect(&Sql_ptr))||
				(dstat = oiSqlWhereBegParen(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,PartNumberAttr,temp2Dup))||
				(dstat = oiSqlWhereEndParen(Sql_ptr))||
				//(dstat = oiSqlAscOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
				(dstat = oiSqlDescOrder(Sql_ptr,CreationDateAttr))) goto EXIT;
			if(dstat = QueryDbObject("Part",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&PartSO,mfail)) goto EXIT;
			printf("\n Generic no. of Parts:: %d",setSize(PartSO));
		}
	}

	if(setSize(PartSO)>0)
	{
		for(m=0;m<setSize(PartSO);m++)
		{
			TCPartObjP=setGet(PartSO,m);

			if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
			if(SetFlagforScope(partMasterSO)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				if (dstat = ExpandObject2("ItemRev",TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) goto EXIT;
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}

			if (setSize(partMasterSO)>0)
			{
				MasterObjOP = setGet(partMasterSO,0);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumberS));
			PartNumberDupS=nlsStrDup(PartNumberS);

			t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&RevisionS));
			RevisionDupS=nlsStrDup(RevisionS);

			t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&SequenceS));
			SequenceDupS=nlsStrDup(SequenceS);

			printf("\n\t LHRH..Prtlevel: %d TCPart:::::[ %s , %s , %s ]   DItype: %s",*Prtlevel, PartNumberDupS,RevisionDupS,SequenceDupS,DItype); fflush(stdout);

			if (charFlag == 1)
			{
				printf("\t InpPartNumberS: %s",InpPartNumberS); fflush(stdout);

				RevisionDupS=nlsStrDup("NR");
				SequenceDupS=nlsStrDup("1");
			}

			if(!nlsIsStrNull(PartNumberDupS))
			{
				nlsStrCpy(PartRevSeq,"");

				//nlsStrCpy(PartRevSeq,PartNumberDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,RevisionDupS);
				//nlsStrCat(PartRevSeq,"_");
				//nlsStrCat(PartRevSeq,SequenceDupS);

				nlsStrCpy(PartRevSeq,RevisionDupS);
				nlsStrCat(PartRevSeq,";");
				nlsStrCat(PartRevSeq,SequenceDupS);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&NomenclatureS));
			if(!nlsIsStrNull(NomenclatureS))
			{
				NomenclatureDupS=nlsStrDup(NomenclatureS);
			}
			else
			{
				NomenclatureDupS=nlsStrDup("-");
			}
			NomenclatureDupS=low_strssra(NomenclatureDupS,"\n"," ");
			NomenclatureDupS=low_strssra(NomenclatureDupS,"^"," ");
			printf("\n\t LHRH..NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeS));
			PartTypeDupS=nlsStrDup(PartTypeS);
			printf("\n\t LHRH..PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&OwnerNameS));
			OwnerNameDupS=nlsStrDup(OwnerNameS);
			printf("\n\t LHRH..OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);
			if(nlsStrStr(OwnerNameDupS,"Vault")==NULL)
			{
				printf("\t ...this rev-seq not in vault hence skipping from download...\n");  fflush(stdout);
				continue;
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectNameS));
			ProjectNameDupS=nlsStrDup(ProjectNameS);
			printf("\n\t LHRH..ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&t5DesignGroupS));
			if(!nlsIsStrNull(t5DesignGroupS))
			{
				t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
			}
			else
			{
				t5DesignGroupDupS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
			if(!nlsIsStrNull(t5DocRemarkS))
			{
				t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
			}
			else
			{
				t5DocRemarkDupS=nlsStrDup("-");
			}
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"\n"," ");
			t5DocRemarkDupS=low_strssra(t5DocRemarkDupS,"^"," ");
			printf("\n\t LHRH..t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
			if(!nlsIsStrNull(t5DrawingIndS))
			{
				t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
			}
			else
			{
				t5DrawingIndDupS=nlsStrDup("N");
			}
			printf("\n\t LHRH..t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

			if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
			{
				docClass = low_getspace(20);

				if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
				if(SetFlagforScope(docObjs)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject2("PartDoc",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}

				if(setSize(docObjs) <= 0)
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
				}
				if(setSize(docObjs) > 0)
				{
					if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
					if (setSize(latestDocs)>0)
					{
						for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
						{
							docOPtr = setGet(latestDocs, noOfDocs);
							if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
							if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
							{
								//Document Number = Drawing Document Number
								if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
								if(!nlsIsStrNull(t5DrawingNo))
								{
									t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
								}
								else
								{
									t5DrawingNoDupS = nlsStrDup(" ");
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNoDupS))
				{
					if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
					if(SetFlagforScope(docObjs)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}

					if(setSize(docObjs) > 0)
					{
						if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
						if (setSize(latestDocs)>0)
						{
							for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
							{
								docOPtr = setGet(latestDocs, noOfDocs);
								if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
								printf("\n\t LHRH.....51..%s",docClass);
								if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
								{
									//Document Number = Drawing Document Number
									if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
									if(!nlsIsStrNull(t5DrawingNo))
									{
										t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup(" ");
									}
								}
							}
						}
					}
				}

				if(nlsIsStrNull(t5DrawingNo))
				{
					t5DrawingNoDupS = nlsStrDup(" ");
				}
			}
			else
			{
				t5DrawingNoDupS = nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&t5MatlClassS));
			if(!nlsIsStrNull(t5MatlClassS))
			{
				t5MatlClassDupS=nlsStrDup(t5MatlClassS);
			}
			else
			{
				t5MatlClassDupS=nlsStrDup("NA");
			}
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"\n"," ");
			t5MatlClassDupS=low_strssra(t5MatlClassDupS,"^"," ");
			printf("\n\t LHRH..t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&t5MaterialInDrwS));
			if(!nlsIsStrNull(t5MaterialInDrwS))
			{
				t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
			}
			else
			{
				t5MaterialInDrwDupS=nlsStrDup(" ");
			}
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"\n"," ");
			t5MaterialInDrwDupS=low_strssra(t5MaterialInDrwDupS,"^"," ");
			printf("\n\t LHRH..t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessS));
			if(!nlsIsStrNull(MaterialThickNessS))
			{
				MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
			}
			else
			{
				MaterialThickNessDupS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5UQdupAttr,&UnitOfMeasureS));
			//if(!nlsIsStrNull(UnitOfMeasureS))
			//{
			//	UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
			//}
			//else
			//{
			//	UnitOfMeasureDupS=nlsStrDup("4");
			//}
			//printf("\n\t LHRH..UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

			//t5CheckDstat(objGetAttribute(TCPartObjP,t5LeftRhAttr,&t5LeftRhS));
			if (setSize(partMasterSO)>0)
			{
				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureS));
				if(!nlsIsStrNull(UnitOfMeasureS))
				{
					UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
				}
				else
				{
					UnitOfMeasureDupS=nlsStrDup("4");
				}

				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&t5LeftRhS));
				if(!nlsIsStrNull(t5LeftRhS))
				{
					t5LeftRhDupS=nlsStrDup(t5LeftRhS);
				}
				else
				{
					t5LeftRhDupS=nlsStrDup("NA");
				}
			}
			else
			{
				t5LeftRhDupS=nlsStrDup("NA");
				UnitOfMeasureDupS=nlsStrDup("4");
			}

			printf("\n\t LHRH..UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);
			printf("\n\t LHRH..t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
			if(!nlsIsStrNull(t5DsgnOwnS))
			{
				t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
			}
			else
			{
				t5DsgnOwnDupS=nlsStrDup("TELPUN");
			}
			printf("\n\t LHRH..t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
			if(!nlsIsStrNull(t5ModelIndicatorS))
			{
				t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
			}
			else
			{
				t5ModelIndicatorDupS=nlsStrDup("N");
			}
			printf("\n\t LHRH..t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&t5ColourIndS));
			if(!nlsIsStrNull(t5ColourIndS))
			{
				t5ColourIndDupS=nlsStrDup(t5ColourIndS);
			}
			else
			{
				t5ColourIndDupS=nlsStrDup("N");
			}
			printf("\n\t LHRH..t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDS));
			if(!nlsIsStrNull(t5ColourIDS))
			{
				t5ColourIDDupS=nlsStrDup(t5ColourIDS);
			}
			else
			{
				t5ColourIDDupS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5ColourIDDupS:%s",t5ColourIDDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateS));
			if(!nlsIsStrNull(LifeCycleStateS))
			{
				LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
			}
			else
			{
				LifeCycleStateDupS=nlsStrDup("LcsReview");
			}
			printf("\n\t LHRH..LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightS));
			if(!nlsIsStrNull(WeightS))
			{
				WeightDupS=nlsStrDup(WeightS);
			}
			else
			{
				WeightDupS=nlsStrDup("0.00");
			}
			printf("\n\t LHRH..WeightDupS:%s",WeightDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,t5SpareIndAttr,&SpareIndS));
			if(!nlsIsStrNull(SpareIndS))
			{
				SpareIndDupS=nlsStrDup(SpareIndS);
			}
			else
			{
				SpareIndDupS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..SpareIndDupS:%s",SpareIndDupS); fflush(stdout);


			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
			if(!nlsIsStrNull(t5CMVRCertificationDupS))
			{
				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);
			}
			else
			{
				t5CMVRCertificationS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5CMVRCertificationS:%s",t5CMVRCertificationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
			if(!nlsIsStrNull(t5ClassificationHazDupS))
			{
				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);
			}
			else
			{
				t5ClassificationHazS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5ClassificationHazS:%s",t5ClassificationHazS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
			if(!nlsIsStrNull(t5ConfigIDDupS))
			{
				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);
			}
			else
			{
				t5ConfigIDS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5ConfigIDS:%s",t5ConfigIDS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
			if(!nlsIsStrNull(t5DismantableDupS))
			{
				t5DismantableS=nlsStrDup(t5DismantableDupS);
			}
			else
			{
				t5DismantableS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5DismantableS:%s",t5DismantableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
			if(!nlsIsStrNull(t5DsgnDeptDupS))
			{
				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);
			}
			else
			{
				t5DsgnDeptS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5DsgnDeptS:%s",t5DsgnDeptS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
			if(!nlsIsStrNull(t5EnvelopeDimenDupS))
			{
				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);
			}
			else
			{
				t5EnvelopeDimenS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5EnvelopeDimenS:%s",t5EnvelopeDimenS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
			if(!nlsIsStrNull(t5HazardousContDupS))
			{
				t5HazardousContS=nlsStrDup(t5HazardousContDupS);
			}
			else
			{
				t5HazardousContS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5HazardousContS:%s",t5HazardousContS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
			if(!nlsIsStrNull(t5HomologationReqdDupS))
			{
				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);
			}
			else
			{
				t5HomologationReqdS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5HomologationReqdS:%s",t5HomologationReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
			if(!nlsIsStrNull(t5ListRecSparesDups))
			{
				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);
			}
			else
			{
				t5ListRecSparess=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5ListRecSparess:%s",t5ListRecSparess); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
			if(!nlsIsStrNull(t5NcPartNoDupS))
			{
				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);
			}
			else
			{
				t5NcPartNoS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5NcPartNoS:%s",t5NcPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
			if(!nlsIsStrNull(t5PartCodeDupS))
			{
				t5PartCodeS=nlsStrDup(t5PartCodeDupS);
			}
			else
			{
				t5PartCodeS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5PartCodeS:%s",t5PartCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
			if(!nlsIsStrNull(t5PartPropertyDupS))
			{
				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);
			}
			else
			{
				t5PartPropertyS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5PartPropertyS:%s",t5PartPropertyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
			if(!nlsIsStrNull(t5PartStatusDupS))
			{
				t5PartStatusS=nlsStrDup(t5PartStatusDupS);
			}
			else
			{
				t5PartStatusS=nlsStrDup("NA");
			}
			printf("\n\t LHRH..t5PartStatusS:%s",t5PartStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
			if(!nlsIsStrNull(t5PkgStdDupS))
			{
				t5PkgStdS=nlsStrDup(t5PkgStdDupS);
			}
			else
			{
				t5PkgStdS=nlsStrDup(" ");
			}
			printf("\n\t LHRH..t5PkgStdS:%s",t5PkgStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
			if(!nlsIsStrNull(t5ProductDupS))
			{
				t5ProductS=nlsStrDup(t5ProductDupS);
			}
			else {	t5ProductS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ProductS:%s",t5ProductS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
			if(!nlsIsStrNull(t5PrtCatCodeDupS))
			{
				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);
			}
			else {	t5PrtCatCodeS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PrtCatCodeS:%s",t5PrtCatCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
			if(!nlsIsStrNull(t5PunIntialAgDupS))
			{
				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);
			}
			else {	t5PunIntialAgS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PunIntialAgS:%s",t5PunIntialAgS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
			if(!nlsIsStrNull(t5PunMakeBuyIndDupS))
			{
				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);
			}
			else {	t5PunMakeBuyIndS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PunMakeBuyIndS:%s",t5PunMakeBuyIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
			if(!nlsIsStrNull(t5RecoverableDupS))
			{
				t5RecoverableS=nlsStrDup(t5RecoverableDupS);
			}
			else {	t5RecoverableS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RecoverableS:%s",t5RecoverableS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
			if(!nlsIsStrNull(t5RecyclabilityDupS))
			{
				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);
			}
			else {	t5RecyclabilityS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RecyclabilityS:%s",t5RecyclabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
			if(!nlsIsStrNull(t5RefPartNumberDupS))
			{
				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);
			}
			else {	t5RefPartNumberS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RefPartNumberS:%s",t5RefPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
			if(!nlsIsStrNull(t5ReliabilityDupS))
			{
				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);
			}
			else {	t5ReliabilityS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ReliabilityS:%s",t5ReliabilityS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
			if(!nlsIsStrNull(t5SpareCriteriaDupS))
			{
				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);
			}
			else {
				t5SpareCriteriaS=nlsStrDup(" ");
			}
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"\n"," ");
			t5SpareCriteriaS=low_strssra(t5SpareCriteriaS,"^"," ");
			printf("\n\t LHRH..t5SpareCriteriaS:%s",t5SpareCriteriaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
			if(!nlsIsStrNull(t5SurfPrtStdDupS))
			{
				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);
			}
			else {	t5SurfPrtStdS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5SurfPrtStdS:%s",t5SurfPrtStdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
			if(!nlsIsStrNull(t5SamplesToApprDupS))
			{
				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);
			}
			else {	t5SamplesToApprS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5SamplesToApprS:%s",t5SamplesToApprS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
			if(!nlsIsStrNull(t5AsmDisposalDupS))
			{
				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);
			}
			else {	t5AsmDisposalS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AsmDisposalS:%s",t5AsmDisposalS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
			if(!nlsIsStrNull(t5FinDisposalInstrDupS))
			{
				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);
			}
			else {	t5FinDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5FinDisposalInstrS:%s",t5FinDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
			if(!nlsIsStrNull(t5RPDisposalInstrDupS))
			{
				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);
			}
			else {	t5RPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RPDisposalInstrS:%s",t5RPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
			if(!nlsIsStrNull(t5SPDisposalInstrDupS))
			{
				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);
			}else {	t5SPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5SPDisposalInstrS:%s",t5SPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
			if(!nlsIsStrNull(t5WIPDisposalInstrDupS))
			{
				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);
			}else {	t5WIPDisposalInstrS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5WIPDisposalInstrS:%s",t5WIPDisposalInstrS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
			if(!nlsIsStrNull(t5LastModByDupS))
			{
				t5LastModByS=nlsStrDup(t5LastModByDupS);
			}else {	t5LastModByS=nlsStrDup("loader");	}
			printf("\n\t LHRH..t5LastModByS:%s",t5LastModByS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
			if(!nlsIsStrNull(t5VerCreatorDupS))
			{
				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);
			}else {	t5VerCreatorS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5VerCreatorS:%s",t5VerCreatorS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
			if(!nlsIsStrNull(t5CAEDocEDupS))
			{
				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);
			}else {	t5CAEDocES=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5CAEDocES:%s",t5CAEDocES); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
			if(!nlsIsStrNull(t5CoatedDupS))
			{
				t5CoatedS=nlsStrDup(t5CoatedDupS);
			}else {	t5CoatedS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5CoatedS:%s",t5CoatedS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
			if(!nlsIsStrNull(t5ConvDocDupS))
			{
				t5ConvDocS=nlsStrDup(t5ConvDocDupS);
			}else {	t5ConvDocS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ConvDocS:%s",t5ConvDocS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcRevDupS))
			{
				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);
			}else {	t5AplCopyOfErcRevS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AplCopyOfErcRevS:%s",t5AplCopyOfErcRevS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
			if(!nlsIsStrNull(t5AplCopyOfErcSeqDupS))
			{
				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);
			}else {	t5AplCopyOfErcSeqS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AplCopyOfErcSeqS:%s",t5AplCopyOfErcSeqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
			if(!nlsIsStrNull(t5AppCodeDupS))
			{
				t5AppCodeS=nlsStrDup(t5AppCodeDupS);
			}else {	t5AppCodeS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AppCodeS:%s",t5AppCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
			if(!nlsIsStrNull(t5RqstNumDupS))
			{
				t5RqstNumS=nlsStrDup(t5RqstNumDupS);
			}else {	t5RqstNumS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RqstNumS:%s",t5RqstNumS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
			if(!nlsIsStrNull(t5RsnCodeDupS))
			{
				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);
			}else {	t5RsnCodeS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RsnCodeS:%s",t5RsnCodeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
			if(!nlsIsStrNull(t5SurfaceAreaDupS))
			{
				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);
			}else {	t5SurfaceAreaS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5SurfaceAreaS:%s",t5SurfaceAreaS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
			if(!nlsIsStrNull(t5VolumeDupS))
			{
				t5VolumeS=nlsStrDup(t5VolumeDupS);
			}else {	t5VolumeS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5VolumeS:%s",t5VolumeS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
			if(!nlsIsStrNull(t5CarIntialAgencyDupS))
			{
				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);
			}else {	t5CarIntialAgencyS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5CarIntialAgencyS:%s",t5CarIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
			if(!nlsIsStrNull(t5CarMakeBuyIndiDupS))
			{
				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);
			}else {	t5CarMakeBuyIndiS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5CarMakeBuyIndiS:%s",t5CarMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
			if(!nlsIsStrNull(t5ErcIndNameDupS))
			{
				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);
			}else {	t5ErcIndNameS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ErcIndNameS:%s",t5ErcIndNameS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
			if(!nlsIsStrNull(t5PostRelReqDupS))
			{
				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);
			}else {	t5PostRelReqS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PostRelReqS:%s",t5PostRelReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
			if(!nlsIsStrNull(t5ItmCategoryDupS))
			{
				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);
			}else {	t5ItmCategoryS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ItmCategoryS:%s",t5ItmCategoryS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
			if(!nlsIsStrNull(t5CopReqDupS))
			{
				t5CopReqS=nlsStrDup(t5CopReqDupS);
			}else {	t5CopReqS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5CopReqS:%s",t5CopReqS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
			if(!nlsIsStrNull(t5AplInvalidateDupS))
			{
				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);
			}else {	t5AplInvalidateS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AplInvalidateS:%s",t5AplInvalidateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
			if(!nlsIsStrNull(t5PrtValiStatusDupS))
			{
				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);
			}else {	t5PrtValiStatusS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PrtValiStatusS:%s",t5PrtValiStatusS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
			if(!nlsIsStrNull(t5DRSubStateDupS))
			{
				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);
			}else {	t5DRSubStateS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5DRSubStateS:%s",t5DRSubStateS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
			if(!nlsIsStrNull(t5KnxtDocIndDupS))
			{
				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);
			}else {	t5KnxtDocIndS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5KnxtDocIndS:%s",t5KnxtDocIndS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
			if(!nlsIsStrNull(t5SimValDupS))
			{
				t5SimValS=nlsStrDup(t5SimValDupS);
				t5SimValS=low_strssra(t5SimValS,"\n"," ");
				t5SimValS=low_strssra(t5SimValS,"^"," ");
			}else {	t5SimValS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5SimValS:%s",t5SimValS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
			if(!nlsIsStrNull(t5PerYieldDupS))
			{
				t5PerYieldS=nlsStrDup(t5PerYieldDupS);
			}else {	t5PerYieldS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PerYieldS:%s",t5PerYieldS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
			if(!nlsIsStrNull(t5PunStoreLocationDupS))
			{
				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);
			}else {	t5PunStoreLocationS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PunStoreLocationS:%s",t5PunStoreLocationS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
			if(!nlsIsStrNull(t5AltPartNoDupS))
			{
				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"\n"," ");
				//t5AltPartNoS=low_strssra(t5AltPartNoS,"^"," ");
			}else {	t5AltPartNoS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5AltPartNoS:%s",t5AltPartNoS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
			if(!nlsIsStrNull(t5RolledupWtDupS))
			{
				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);
			}else {	t5RolledupWtS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5RolledupWtS:%s",t5RolledupWtS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
			if(!nlsIsStrNull(t5PFDModReqdDupS))
			{
				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);
			}else {	t5PFDModReqdS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5PFDModReqdS:%s",t5PFDModReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
			if(!nlsIsStrNull(t5ToolIndentReqdDupS))
			{
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);
			}else {	t5ToolIndentReqdS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5ToolIndentReqdS:%s",t5ToolIndentReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
			if(!nlsIsStrNull(CategoryNameDupS))
			{
				CategoryNameS=nlsStrDup(CategoryNameDupS);
				CategoryNameS=low_strssra(CategoryNameS,"\n"," ");
				CategoryNameS=low_strssra(CategoryNameS,"^"," ");
			}else {	CategoryNameS=nlsStrDup(" ");	}
			printf("\n\t LHRH..CategoryNameS:%s",CategoryNameS); fflush(stdout);


			// For effectivity extract
			t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
			// Get the configuration context object from the general context.
			t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
			// Set the option as "LkoCtxt" in the context object
			t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
			t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
			t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
			t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
			if(SetFlagforScope(soExpObj)==1)
			{
				if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
				t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
				if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
			}
			printf("\n\t LHRH.. setSize(soExpObj):%d ",setSize(soExpObj)); fflush(stdout);
			if(setSize(soExpObj)>0)
			{
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
				if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;

				//if(!nlsIsStrNull(ReveffDateFrom))
				if((!nlsIsStrNull(ReveffDateFrom)) && (nlsStrCmp(subString(ReveffDateFrom,0,4),"0001") != 0))  //added on 17.06.2017
				{
					ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
					printf("\n\t LHRH..if..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				}
				else
				{
					if((!nlsIsStrNull(ReveffDateTo)) && (nlsStrCmp(subString(ReveffDateTo,0,4),"0001") != 0))
					{
						ReveffDateFromDup = nlsStrDup(ReveffDateTo);
					}
					else
					{
						ReveffDateFromDup = nlsStrDup("-");
					}
					printf("\n\t LHRH..else..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				}
				if(!nlsIsStrNull(ReveffDateTo))
				{
					ReveffDateToDup = nlsStrDup(ReveffDateTo);
					printf("\n\t LHRH..if..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
				}
				else
				{
					if((!nlsIsStrNull(ReveffDateFrom)) && (nlsStrCmp(subString(ReveffDateFrom,0,4),"0001") != 0))  //added on 17.06.2017
					{
						ReveffDateToDup = nlsStrDup(ReveffDateFrom);
					}
					else
					{
						ReveffDateToDup = nlsStrDup("-");
					}
					printf("\n\t LHRH..else..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
				}
			}
			else
			{
				ReveffDateFromDup = nlsStrDup("-");
				ReveffDateToDup = nlsStrDup("-");
				printf("\n\t LHRH..else2..ReveffDateFromDup:%s ",ReveffDateFromDup); fflush(stdout);
				printf("\n\t LHRH..else2..ReveffDateToDup:%s",ReveffDateToDup); fflush(stdout);
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrIntialAgency",&t5JsrIntialAgencyDupS));
			t5JsrIntialAgencyS=nlsStrDup(t5JsrIntialAgencyDupS);
			printf("\n\t LHRH..t5JsrIntialAgencyS:%s",t5JsrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrMakeBuyIndicator",&t5JsrMakeBuyIndiDupS));
			t5JsrMakeBuyIndiS=nlsStrDup(t5JsrMakeBuyIndiDupS);
			printf("\n\t LHRH..t5JsrMakeBuyIndiS:%s",t5JsrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoIntialAgency",&t5LkoIntialAgencyDupS));
			t5LkoIntialAgencyS=nlsStrDup(t5LkoIntialAgencyDupS);
			printf("\n\t LHRH..t5LkoIntialAgencyS:%s",t5LkoIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoMakeBuyIndicator",&t5LkoMakeBuyIndiDupS));
			t5LkoMakeBuyIndiS=nlsStrDup(t5LkoMakeBuyIndiDupS);
			printf("\n\t LHRH..t5LkoMakeBuyIndiS:%s",t5LkoMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrIntialAgency",&t5PnrIntialAgencyDupS));
			t5PnrIntialAgencyS=nlsStrDup(t5PnrIntialAgencyDupS);
			printf("\n\t LHRH..t5PnrIntialAgencyS:%s",t5PnrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrMakeBuyIndicator",&t5PnrMakeBuyIndiDupS));
			t5PnrMakeBuyIndiS=nlsStrDup(t5PnrMakeBuyIndiDupS);
			printf("\n\t LHRH..t5PnrMakeBuyIndiS:%s",t5PnrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUIntialAgency",&t5PunPCBUIntialAgencyDupS));
			t5PunPCBUIntialAgencyS=nlsStrDup(t5PunPCBUIntialAgencyDupS);
			printf("\n\t LHRH..t5PunPCBUIntialAgencyS:%s",t5PunPCBUIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUMakeBuyIndicator",&t5PunPCBUMakeBuyIndiDupS));
			t5PunPCBUMakeBuyIndiS=nlsStrDup(t5PunPCBUMakeBuyIndiDupS);
			printf("\n\t LHRH..t5PunPCBUMakeBuyIndiS:%s",t5PunPCBUMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrIntialAgency",&t5SgrIntialAgencyDupS));
			t5SgrIntialAgencyS=nlsStrDup(t5SgrIntialAgencyDupS);
			printf("\n\t LHRH..t5SgrIntialAgencyS:%s",t5SgrIntialAgencyS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrMakeBuyIndicator",&t5SgrMakeBuyIndiDupS));
			t5SgrMakeBuyIndiS=nlsStrDup(t5SgrMakeBuyIndiDupS);
			printf("\n\t LHRH..t5SgrMakeBuyIndiS:%s",t5SgrMakeBuyIndiS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
			if(!nlsIsStrNull(t5EstSheetReqdDupS))
			{
				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);
			}else {	t5EstSheetReqdS=nlsStrDup(" ");	}
			printf("\n\t LHRH..t5EstSheetReqdS:%s",t5EstSheetReqdS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"CreationDate",&PartCreDateS));
			if(!nlsIsStrNull(PartCreDateS))
			{
				PartCreDateDupS=nlsStrDup(PartCreDateS);
			}
			else
			{
				PartCreDateDupS=nlsStrDup("-");
			}
			printf("\n\t LHRH..PartCreDateDupS:%s",PartCreDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"LastUpdate",&PartModDateS));
			if(!nlsIsStrNull(PartModDateS))
			{
				PartModDateDupS=nlsStrDup(PartModDateS);
			}
			else
			{
				PartModDateDupS=nlsStrDup("-");
			}
			printf("\n\t LHRH..PartModDateDupS:%s",PartModDateDupS); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"Creator",&PartCreator));
			PartCreatorDup=nlsStrDup(PartCreator);
			printf("\n\t LHRH..PartCreatorDup:%s",PartCreatorDup); fflush(stdout);

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdIntialAgency",&t5AhdIntialAgencyS));
			if(!nlsIsStrNull(t5AhdIntialAgencyS))
			{
				t5AhdIntialAgencySDup = nlsStrDup(t5AhdIntialAgencyS);
			}
			else
			{
				t5AhdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdMakeBuyIndicator",&t5AhdMakeBuyIndS));
			if(!nlsIsStrNull(t5AhdMakeBuyIndS))
			{
				t5AhdMakeBuyIndSDup = nlsStrDup(t5AhdMakeBuyIndS);
			}
			else
			{
				t5AhdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdIntialAgency",&t5DwdIntialAgencyS));
			if(!nlsIsStrNull(t5DwdIntialAgencyS))
			{
				t5DwdIntialAgencySDup = nlsStrDup(t5DwdIntialAgencyS);
			}
			else
			{
				t5DwdIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdMakeBuyIndicator",&t5DwdMakeBuyIndS));
			if(!nlsIsStrNull(t5DwdMakeBuyIndS))
			{
				t5DwdMakeBuyIndSDup = nlsStrDup(t5DwdMakeBuyIndS);
			}
			else
			{
				t5DwdMakeBuyIndSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlIntialAgency",&t5JdlIntialAgencyS));
			if(!nlsIsStrNull(t5JdlIntialAgencyS))
			{
				t5JdlIntialAgencySDup = nlsStrDup(t5JdlIntialAgencyS);
			}
			else
			{
				t5JdlIntialAgencySDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlMakeBuyIndicator",&t5JdlMakeBuyIndS));
			if(!nlsIsStrNull(t5JdlMakeBuyIndS))
			{
				t5JdlMakeBuyIndSDup = nlsStrDup(t5JdlMakeBuyIndS);
			}
			else
			{
				t5JdlMakeBuyIndSDup = nlsStrDup("");
			}

			t5CheckDstat(objGetAttribute(TCPartObjP,"t5AhdStoreLocation",&t5AhdStoreLocS));
			if(!nlsIsStrNull(t5AhdStoreLocS))
			{
				t5AhdStoreLocSDup = nlsStrDup(t5AhdStoreLocS);
			}
			else
			{
				t5AhdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarStoreLocation",&t5CarStoreLocS));
			if(!nlsIsStrNull(t5CarStoreLocS))
			{
				t5CarStoreLocSDup = nlsStrDup(t5CarStoreLocS);
			}
			else
			{
				t5CarStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5DwdStoreLocation",&t5DwdStoreLocS));
			if(!nlsIsStrNull(t5DwdStoreLocS))
			{
				t5DwdStoreLocSDup = nlsStrDup(t5DwdStoreLocS);
			}
			else
			{
				t5DwdStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JdlStoreLocation",&t5JdlStoreLocS));
			if(!nlsIsStrNull(t5JdlStoreLocS))
			{
				t5JdlStoreLocSDup = nlsStrDup(t5JdlStoreLocS);
			}
			else
			{
				t5JdlStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5JsrStoreLocation",&t5JsrStoreLocS));
			if(!nlsIsStrNull(t5JsrStoreLocS))
			{
				t5JsrStoreLocSDup = nlsStrDup(t5JsrStoreLocS);
			}
			else
			{
				t5JsrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5LkoStoreLocation",&t5LkoStoreLocS));
			if(!nlsIsStrNull(t5LkoStoreLocS))
			{
				t5LkoStoreLocSDup = nlsStrDup(t5LkoStoreLocS);
			}
			else
			{
				t5LkoStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PnrStoreLocation",&t5PnrStoreLocS));
			if(!nlsIsStrNull(t5PnrStoreLocS))
			{
				t5PnrStoreLocSDup = nlsStrDup(t5PnrStoreLocS);
			}
			else
			{
				t5PnrStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunPCBUStoreLocation",&t5PunPCBUStoreLocS));
			if(!nlsIsStrNull(t5PunPCBUStoreLocS))
			{
				t5PunPCBUStoreLocSDup = nlsStrDup(t5PunPCBUStoreLocS);
			}
			else
			{
				t5PunPCBUStoreLocSDup = nlsStrDup("");
			}
			t5CheckDstat(objGetAttribute(TCPartObjP,"t5SgrStoreLocation",&t5SgrStoreLocS));
			if(!nlsIsStrNull(t5SgrStoreLocS))
			{
				t5SgrStoreLocSDup = nlsStrDup(t5SgrStoreLocS);
			}
			else
			{
				t5SgrStoreLocSDup = nlsStrDup("");
			}

			printf("\n\t LHRH..DItype:%s",DItype); fflush(stdout);

			if (setSize(partMasterSO)>0)
			{
				if (nlsStrCmp(t5LeftRhDupS,"NA")==0)
				{
					LHRhPartNumberDup=nlsStrDup("NA");
				}
				else
				{
					LhRhPartExistFlag = 0;

					if (nlsStrStr(t5LeftRhDupS,"LH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
						if(SetFlagforScope(hasRHItmMster)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmLeftHasRight",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}

						if (setSize(hasRHItmMster) > 0)
						{
							t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
							if(!nlsIsStrNull(LHRhPartNumber))
							{
								LHRhPartNumberDup=nlsStrDup(LHRhPartNumber);
							}
							else
							{
								LHRhPartNumberDup=nlsStrDup("NA");
							}
						}
						else
						{
							LHRhPartNumberDup=nlsStrDup("NA");
						}
					}

					if (nlsStrStr(t5LeftRhDupS,"RH")!= NULL)
					{
						if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
						if(SetFlagforScope(hasRHItmMster)==1)
						{
							if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
							if(dstat=ExpandObject5(t5LRRelnClass,MasterObjOP,"t5AsmRightHasLeft",SC_SCOPE_OF_SESSION ,&hasRHItmMster,mfail)) goto CLEANUP;
							if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
						}

						if (setSize(hasRHItmMster) > 0)
						{
							t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),PartNumberAttr,&LHRhPartNumber));
							if(!nlsIsStrNull(LHRhPartNumber))
							{
								LHRhPartNumberDup=nlsStrDup(LHRhPartNumber);
							}
							else
							{
								LHRhPartNumberDup=nlsStrDup("NA");
							}
						}
						else
						{
							LHRhPartNumberDup=nlsStrDup("NA");
						}
					}
					/*if (( nlsStrCmp(LHRhPartNumberDup,"NA") !=0 ) && (setSize(hasRHItmMster) > 0) )
					{
						t5CheckDstat(objGetAttribute(setGet(hasRHItmMster,0),t5LeftRhAttr,&t5RightLH));
						if(!nlsIsStrNull(t5RightLH))
						{
							t5RightLHDupS=nlsStrDup(t5RightLH);
						}
						else
						{
							t5RightLHDupS=nlsStrDup("NA");
						}

						fprintf(LhRhfp,"%s",t5LeftRhDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",PartNumberDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",t5RightLHDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",LHRhPartNumberDup);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",RevisionDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"%s",SequenceDupS);
						fprintf(LhRhfp,"^");
						fprintf(LhRhfp,"\n");
						fflush(LhRhfp);

						LhRhPartExistFlag = 1;
					}*/
				}
				printf("\n\t LHRH..**LHRhPartNumberDup:%s",LHRhPartNumberDup); fflush(stdout);

				//query part again to get all attributes to copy in allpartsAllRev file

				//if((nlsStrCmp(LHRhPartNumberDup,"NA")!=0) && (!nlsIsStrNull(LHRhPartNumberDup)))
				//{
				//	t5CheckMfail(GetLhRhTCPartProEInfo(LHRhPartNumberDup,PartNumberDupS,fpAllRev,OutJtfp,LhRHErr,mfail));
				//}
			}

			//fprintf(fpAllRev,"%d^",*Prtlevel);				//0	//Prtlevel

			if (charFlag == 1)
			{
				fprintf(fpAllRev,"%s",InpPartNumberS);			//1		//In Function GetGenTCPartProEInfo
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"%s",PartNumberDupS);			//1		//In Function GetGenTCPartProEInfo
				fprintf(fpAllRev,"^");
			}
			fprintf(fpAllRev,"%s",RevisionDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SequenceDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",NomenclatureDupS);	//desc
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",PartTypeDupS);		//PartType
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",ProjectNameDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DesignGroupDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DocRemarkDupS);		//mod_desc
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5DrawingNoDupS)){
				fprintf(fpAllRev,"%s",t5DrawingNoDupS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			fprintf(fpAllRev,"%s",t5DrawingIndDupS);		//10
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MatlClassDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5MaterialInDrwDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",MaterialThickNessDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5LeftRhDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5DsgnOwnDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ModelIndicatorDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",UnitOfMeasureDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIndDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",LifeCycleStateDupS);
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",t5ColourIDDupS);				//20
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",WeightDupS);					//21
			fprintf(fpAllRev,"^");
			fprintf(fpAllRev,"%s",SpareIndDupS);				//22
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(t5CMVRCertificationS)){
				fprintf(fpAllRev,"%s",t5CMVRCertificationS);//23
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ClassificationHazS)){
				fprintf(fpAllRev,"%s",t5ClassificationHazS);
				fprintf(fpAllRev,"^");
			}else {
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ConfigIDS)){
				fprintf(fpAllRev,"%s",t5ConfigIDS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5DismantableS)){
				fprintf(fpAllRev,"%s",t5DismantableS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DsgnDeptS)){
				fprintf(fpAllRev,"%s",t5DsgnDeptS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5EnvelopeDimenS)){
				fprintf(fpAllRev,"%s",t5EnvelopeDimenS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HazardousContS)){
				fprintf(fpAllRev,"%s",t5HazardousContS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5HomologationReqdS)){
				fprintf(fpAllRev,"%s",t5HomologationReqdS);	//30
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ListRecSparess)){
				fprintf(fpAllRev,"%s",t5ListRecSparess);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5NcPartNoS)){
				fprintf(fpAllRev,"%s",t5NcPartNoS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartCodeS)){
				fprintf(fpAllRev,"%s",t5PartCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartPropertyS)){
				fprintf(fpAllRev,"%s",t5PartPropertyS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PartStatusS)){
				fprintf(fpAllRev,"%s",t5PartStatusS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PkgStdS)){
				fprintf(fpAllRev,"%s",t5PkgStdS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ProductS)){
				fprintf(fpAllRev,"%s",t5ProductS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtCatCodeS)){
				fprintf(fpAllRev,"%s",t5PrtCatCodeS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunIntialAgS)){
				fprintf(fpAllRev,"%s",t5PunIntialAgS);
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
				fprintf(fpAllRev,"%s",t5PunMakeBuyIndS);	//40
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecoverableS)){
				fprintf(fpAllRev,"%s",t5RecoverableS);		//41
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RecyclabilityS)){
				fprintf(fpAllRev,"%s",t5RecyclabilityS);	//42
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RefPartNumberS)){
				fprintf(fpAllRev,"%s",t5RefPartNumberS);	//43
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ReliabilityS)){
				fprintf(fpAllRev,"%s",t5ReliabilityS);		//44
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SpareCriteriaS)){
				fprintf(fpAllRev,"%s",t5SpareCriteriaS);	//45
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfPrtStdS)){
				fprintf(fpAllRev,"%s",t5SurfPrtStdS);		//46
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SamplesToApprS)){
				fprintf(fpAllRev,"%s",t5SamplesToApprS);	//47
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AsmDisposalS)){
				fprintf(fpAllRev,"%s",t5AsmDisposalS);		//48
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5FinDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5FinDisposalInstrS);	//49
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5RPDisposalInstrS);	//50
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5SPDisposalInstrS);	//51
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
				fprintf(fpAllRev,"%s",t5WIPDisposalInstrS);	//52
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5LastModByS)){
				fprintf(fpAllRev,"%s",t5LastModByS);		//53
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev,"loader^");
			}


			if(!nlsIsStrNull(t5VerCreatorS)){
				fprintf(fpAllRev,"%s",t5VerCreatorS);		//54
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CAEDocES)){
				fprintf(fpAllRev,"%s",t5CAEDocES);			//55
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CoatedS)){
				fprintf(fpAllRev,"%s",t5CoatedS);			//56
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5ConvDocS)){
				fprintf(fpAllRev,"%s",t5ConvDocS);			//57
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcRevS);	//58
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
				fprintf(fpAllRev,"%s",t5AplCopyOfErcSeqS);	//59
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AppCodeS)){
				fprintf(fpAllRev,"%s",t5AppCodeS);			//60
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RqstNumS)){
				fprintf(fpAllRev,"%s",t5RqstNumS);			//61
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5RsnCodeS)){
				fprintf(fpAllRev,"%s",t5RsnCodeS);			//62
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5SurfaceAreaS)){
				fprintf(fpAllRev,"%s",t5SurfaceAreaS);		//63
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5VolumeS)){
				fprintf(fpAllRev,"%s",t5VolumeS);			//64
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CarIntialAgencyS)){
				fprintf(fpAllRev,"%s",t5CarIntialAgencyS);	//65
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
				fprintf(fpAllRev,"%s",t5CarMakeBuyIndiS);	//66
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ErcIndNameS)){
				fprintf(fpAllRev,"%s",t5ErcIndNameS);		//67
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PostRelReqS)){
				fprintf(fpAllRev,"%s",t5PostRelReqS);		//68
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ItmCategoryS)){
				fprintf(fpAllRev,"%s",t5ItmCategoryS);		//69
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5CopReqS)){
				fprintf(fpAllRev,"%s",t5CopReqS);			//70
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AplInvalidateS)){
				fprintf(fpAllRev,"%s",t5AplInvalidateS);	//71
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PrtValiStatusS)){
				fprintf(fpAllRev,"%s",t5PrtValiStatusS);	//72
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5DRSubStateS)){
				fprintf(fpAllRev,"%s",t5DRSubStateS);		//73
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5KnxtDocIndS)){
				fprintf(fpAllRev,"%s",t5KnxtDocIndS);		//74
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5SimValS)){
				fprintf(fpAllRev,"%s",t5SimValS);			//75
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PerYieldS)){
				fprintf(fpAllRev,"%s",t5PerYieldS);			//76
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5PunStoreLocationS)){
				fprintf(fpAllRev,"%s",t5PunStoreLocationS);	//77
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5AltPartNoS)){
				fprintf(fpAllRev,"%s",t5AltPartNoS);		//78
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5RolledupWtS)){
				fprintf(fpAllRev,"%s",t5RolledupWtS);		//79
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(t5PFDModReqdS)){
				fprintf(fpAllRev,"%s",t5PFDModReqdS);		//80
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(t5ToolIndentReqdS)){
				fprintf(fpAllRev,"%s",t5ToolIndentReqdS);	//81
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(CategoryNameS)){
				fprintf(fpAllRev,"%s",CategoryNameS);		//82
				fprintf(fpAllRev,"^");
			}else
			{
				fprintf(fpAllRev," ^");
			}


			if(!nlsIsStrNull(ReveffDateFromDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateFromDup);	//83
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			if(!nlsIsStrNull(ReveffDateToDup))
			{
				fprintf(fpAllRev,"%s",ReveffDateToDup);		//84
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			//fprintf(fpAllRev,"NA^");						//85   //LHRhPartNumberDup
			fprintf(fpAllRev,"%s",LHRhPartNumberDup);		//85   //LHRhPartNumberDup	//added on 04.04.2017
			fprintf(fpAllRev,"^");

			if(!nlsIsStrNull(InstanceRevSeqS))
			{
				fprintf(fpAllRev,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //86   //InstanceRevSeqS
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}

			//below attributes are added by rrr on 14.10.2016
			if(!nlsIsStrNull(t5JsrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5JsrIntialAgencyS);		//87
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5JsrMakeBuyIndiS);		//88
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5LkoIntialAgencyS);		//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5LkoMakeBuyIndiS);		//90
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PnrIntialAgencyS);		//91
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PnrMakeBuyIndiS);		//92
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUIntialAgencyS);	//93
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUMakeBuyIndiS);	//94
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrIntialAgencyS))
			{
				fprintf(fpAllRev,"%s",t5SgrIntialAgencyS);		//95
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
			{
				fprintf(fpAllRev,"%s",t5SgrMakeBuyIndiS);		//96
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5EstSheetReqdS))
			{
				fprintf(fpAllRev,"%s",t5EstSheetReqdS);			//97
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(PartCreDateDupS))
			{
				fprintf(fpAllRev,"%s",PartCreDateDupS);			//98
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartModDateDupS))
			{
				fprintf(fpAllRev,"%s",PartModDateDupS);			//99
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"-^");
			}
			if(!nlsIsStrNull(PartCreatorDup))
			{
				fprintf(fpAllRev,"%s",PartCreatorDup);			//100
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"loader^");
			}
			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5AhdIntialAgencySDup);	//101
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5AhdMakeBuyIndSDup);		//102
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5DwdIntialAgencySDup);	//103
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5DwdMakeBuyIndSDup);		//104
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlIntialAgencySDup))
			{
				fprintf(fpAllRev,"%s",t5JdlIntialAgencySDup);	//105
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
			{
				fprintf(fpAllRev,"%s",t5JdlMakeBuyIndSDup);		//106
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5AhdStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5AhdStoreLocSDup);		//107
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5CarStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5CarStoreLocSDup);		//108
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5DwdStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5DwdStoreLocSDup);		//109
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JdlStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5JdlStoreLocSDup);		//110
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5JsrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5JsrStoreLocSDup);		//111
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5LkoStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5LkoStoreLocSDup);		//112
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PnrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5PnrStoreLocSDup);		//113
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5PunPCBUStoreLocSDup);	//114
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			if(!nlsIsStrNull(t5SgrStoreLocSDup))
			{
				fprintf(fpAllRev,"%s",t5SgrStoreLocSDup);		//115
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev," ^");
			}
			/*if(!nlsIsStrNull(DItype))
			{
				fprintf(fpAllRev,"%s",DItype);		//116
				fprintf(fpAllRev,"^");
			}
			else
			{
				fprintf(fpAllRev,"TYPE_INVALID^");
			}*/

			fprintf(fpAllRev,"\n");
			fflush(fpAllRev);

			printf("\n Inside fpAllRev --------------------------123\n"); fflush(stdout);

//			printf("\n Inside fp --------------------------125\n"); fflush(stdout);
//
//			fprintf(fp,"%d",*level);			//1
//			fprintf(fp,"^");
//			fprintf(fp,"%s",PartNumberDupS);	//2
//			fprintf(fp,"^");
//			fprintf(fp,"%s",RevisionDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",SequenceDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",NomenclatureDupS);	//desc
//			fprintf(fp,"^");
//			fprintf(fp,"%s",PartTypeDupS);		//PartType
//			fprintf(fp,"^");
//			fprintf(fp,"%s",ProjectNameDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DesignGroupDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DocRemarkDupS);		//mod_desc
//			fprintf(fp,"^");
//
//			if(!nlsIsStrNull(t5DrawingNoDupS)){
//				fprintf(fp,"%s",t5DrawingNoDupS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			fprintf(fp,"%s",t5DrawingIndDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5MatlClassDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5MaterialInDrwDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",MaterialThickNessDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5LeftRhDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5DsgnOwnDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ModelIndicatorDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",UnitOfMeasureDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ColourIndDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",LifeCycleStateDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",t5ColourIDDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",WeightDupS);
//			fprintf(fp,"^");
//			fprintf(fp,"%s",SpareIndDupS);
//			fprintf(fp,"^");
//
//			if(!nlsIsStrNull(t5CMVRCertificationS)){
//				fprintf(fp,"%s",t5CMVRCertificationS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ClassificationHazS)){
//				fprintf(fp,"%s",t5ClassificationHazS);
//				fprintf(fp,"^");
//			}else {
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ConfigIDS)){
//				fprintf(fp,"%s",t5ConfigIDS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5DismantableS)){
//				fprintf(fp,"%s",t5DismantableS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5DsgnDeptS)){
//				fprintf(fp,"%s",t5DsgnDeptS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5EnvelopeDimenS)){
//				fprintf(fp,"%s",t5EnvelopeDimenS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5HazardousContS)){
//				fprintf(fp,"%s",t5HazardousContS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5HomologationReqdS)){
//				fprintf(fp,"%s",t5HomologationReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ListRecSparess)){
//				fprintf(fp,"%s",t5ListRecSparess);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5NcPartNoS)){
//				fprintf(fp,"%s",t5NcPartNoS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartCodeS)){
//				fprintf(fp,"%s",t5PartCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartPropertyS)){
//				fprintf(fp,"%s",t5PartPropertyS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PartStatusS)){
//				fprintf(fp,"%s",t5PartStatusS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5PkgStdS)){
//				fprintf(fp,"%s",t5PkgStdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ProductS)){
//				fprintf(fp,"%s",t5ProductS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PrtCatCodeS)){
//				fprintf(fp,"%s",t5PrtCatCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunIntialAgS)){
//				fprintf(fp,"%s",t5PunIntialAgS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunMakeBuyIndS)){
//				fprintf(fp,"%s",t5PunMakeBuyIndS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RecoverableS)){
//				fprintf(fp,"%s",t5RecoverableS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RecyclabilityS)){
//				fprintf(fp,"%s",t5RecyclabilityS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RefPartNumberS)){
//				fprintf(fp,"%s",t5RefPartNumberS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ReliabilityS)){
//				fprintf(fp,"%s",t5ReliabilityS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SpareCriteriaS)){
//				fprintf(fp,"%s",t5SpareCriteriaS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SurfPrtStdS)){
//				fprintf(fp,"%s",t5SurfPrtStdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SamplesToApprS)){
//				fprintf(fp,"%s",t5SamplesToApprS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AsmDisposalS)){
//				fprintf(fp,"%s",t5AsmDisposalS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5FinDisposalInstrS)){
//				fprintf(fp,"%s",t5FinDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RPDisposalInstrS)){
//				fprintf(fp,"%s",t5RPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SPDisposalInstrS)){
//				fprintf(fp,"%s",t5SPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5WIPDisposalInstrS)){
//				fprintf(fp,"%s",t5WIPDisposalInstrS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5LastModByS)){
//				fprintf(fp,"%s",t5LastModByS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp,"loader^");
//			}
//
//
//			if(!nlsIsStrNull(t5VerCreatorS)){
//				fprintf(fp,"%s",t5VerCreatorS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CAEDocES)){
//				fprintf(fp,"%s",t5CAEDocES);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5CoatedS)){
//				fprintf(fp,"%s",t5CoatedS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5ConvDocS)){
//				fprintf(fp,"%s",t5ConvDocS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
//				fprintf(fp,"%s",t5AplCopyOfErcRevS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
//				fprintf(fp,"%s",t5AplCopyOfErcSeqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AppCodeS)){
//				fprintf(fp,"%s",t5AppCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RqstNumS)){
//				fprintf(fp,"%s",t5RqstNumS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5RsnCodeS)){
//				fprintf(fp,"%s",t5RsnCodeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5SurfaceAreaS)){
//				fprintf(fp,"%s",t5SurfaceAreaS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5VolumeS)){
//				fprintf(fp,"%s",t5VolumeS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CarIntialAgencyS)){
//				fprintf(fp,"%s",t5CarIntialAgencyS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
//				fprintf(fp,"%s",t5CarMakeBuyIndiS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ErcIndNameS)){
//				fprintf(fp,"%s",t5ErcIndNameS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PostRelReqS)){
//				fprintf(fp,"%s",t5PostRelReqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ItmCategoryS)){
//				fprintf(fp,"%s",t5ItmCategoryS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5CopReqS)){
//				fprintf(fp,"%s",t5CopReqS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AplInvalidateS)){
//				fprintf(fp,"%s",t5AplInvalidateS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PrtValiStatusS)){
//				fprintf(fp,"%s",t5PrtValiStatusS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5DRSubStateS)){
//				fprintf(fp,"%s",t5DRSubStateS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5KnxtDocIndS)){
//				fprintf(fp,"%s",t5KnxtDocIndS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5SimValS)){
//				fprintf(fp,"%s",t5SimValS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PerYieldS)){
//				fprintf(fp,"%s",t5PerYieldS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5PunStoreLocationS)){
//				fprintf(fp,"%s",t5PunStoreLocationS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5AltPartNoS)){
//				fprintf(fp,"%s",t5AltPartNoS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5RolledupWtS)){
//				fprintf(fp,"%s",t5RolledupWtS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(t5PFDModReqdS)){
//				fprintf(fp,"%s",t5PFDModReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5ToolIndentReqdS)){
//				fprintf(fp,"%s",t5ToolIndentReqdS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(CategoryNameS)){
//				fprintf(fp,"%s",CategoryNameS);
//				fprintf(fp,"^");
//			}else
//			{
//				fprintf(fp," ^");
//			}
//
//
//			if(!nlsIsStrNull(ReveffDateFromDup))
//			{
//				fprintf(fp,"%s",ReveffDateFromDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(ReveffDateToDup))
//			{
//				fprintf(fp,"%s",ReveffDateToDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			fprintf(fp,"NA^");					   //LhRhPartNumberDup
//
//			if(!nlsIsStrNull(InstanceRevSeqS))
//			{
//				fprintf(fp,"%s",InstanceRevSeqS); //Instance with semicolon separated Rev;Seq   //InstanceRevSeqS
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//
//			if(!nlsIsStrNull(t5JsrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5JsrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JsrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5JsrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5LkoIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5LkoMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5PnrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5PnrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5PunPCBUIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5PunPCBUMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrIntialAgencyS))
//			{
//				fprintf(fp,"%s",t5SgrIntialAgencyS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrMakeBuyIndiS))
//			{
//				fprintf(fp,"%s",t5SgrMakeBuyIndiS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5EstSheetReqdS))
//			{
//				fprintf(fp,"%s",t5EstSheetReqdS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(PartCreDateDupS))
//			{
//				fprintf(fp,"%s",PartCreDateDupS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"-^");
//			}
//			if(!nlsIsStrNull(PartModDateDupS))
//			{
//				fprintf(fp,"%s",PartModDateDupS);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"-^");
//			}
//
//			if(!nlsIsStrNull(PartCreatorDup))
//			{
//				fprintf(fp,"%s",PartCreatorDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"loader^");
//			}
//			if(!nlsIsStrNull(t5AhdIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5AhdIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5AhdMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5AhdMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5DwdIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5DwdMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlIntialAgencySDup))
//			{
//				fprintf(fp,"%s",t5JdlIntialAgencySDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlMakeBuyIndSDup))
//			{
//				fprintf(fp,"%s",t5JdlMakeBuyIndSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5AhdStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5AhdStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5CarStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5CarStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5DwdStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5DwdStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JdlStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5JdlStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5JsrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5JsrStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5LkoStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5LkoStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PnrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5PnrStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5PunPCBUStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5PunPCBUStoreLocSDup);
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(t5SgrStoreLocSDup))
//			{
//				fprintf(fp,"%s",t5SgrStoreLocSDup);		//116
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp," ^");
//			}
//			if(!nlsIsStrNull(DItype))
//			{
//				fprintf(fp,"%s",DItype);			//117
//				fprintf(fp,"^");
//			}
//			else
//			{
//				fprintf(fp,"TYPE_INVALID^");
//			}
//			fprintf(fp,"\n");
//			fflush(fp);

			if (charFlag == 1)
			{
				break;
			}

		} // for loop of setSize(PartSO)
	} //if condn end for setSize(PartSO)
	else
	{
		printf("\n Inside fpAllRev ---------GetGenTCPartProEInfo-----------------131\n"); fflush(stdout);

		//fprintf(fpAllRev,"%d^",*Prtlevel);		//0	//Prtlevel

		fprintf(fpAllRev,"%s",InpPartNumberS);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",InpPartRev);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s",InpPartSeq);
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","Dummy Part for Proe"); //NomenclatureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","D");		//PartTypeDupS		// Dummy PartType
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","1111");	//ProjectNameDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","11");	//t5DesignGroupDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//mod_desc   t5DocRemarkDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5DrawingNoDupS
		fprintf(fpAllRev,"%s","N");		//t5DrawingIndDupS			//10
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");	//t5MatlClassDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//t5MaterialInDrwDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//MaterialThickNessDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","NA");		//t5LeftRhDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","TELPUN");	//t5DsgnOwnDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","N");		//t5ModelIndicatorDupS;	 Y/N/blank
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","4");		//UnitOfMeasureDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","N");		//t5ColourIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","LcsReview");//LifeCycleStateDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5ColourIDDupS		//20
		fprintf(fpAllRev,"%s","0");		//WeightDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev,"%s","-");		//SpareIndDupS
		fprintf(fpAllRev,"^");
		fprintf(fpAllRev," ^");			//t5CMVRCertification
		fprintf(fpAllRev," ^");			//t5ClassificationHaz
		fprintf(fpAllRev," ^");			//t5ConfigID
		fprintf(fpAllRev," ^");			//t5Dismantable
		fprintf(fpAllRev," ^");			//t5DsgnDeptS
		fprintf(fpAllRev," ^");			//t5EnvelopeDimen
		fprintf(fpAllRev," ^");			//t5HazardousCont
		fprintf(fpAllRev," ^");			//t5HomologationReqd		//30
		fprintf(fpAllRev," ^");			//t5ListRecSpares
		fprintf(fpAllRev," ^");			//t5NcPartNoS
		fprintf(fpAllRev," ^");			//t5PartCodeS
		fprintf(fpAllRev," ^");			//t5PartPropertyS
		fprintf(fpAllRev," ^");			//t5PartStatusS
		fprintf(fpAllRev," ^");			//t5PkgStdS
		fprintf(fpAllRev," ^");			//t5ProductS
		fprintf(fpAllRev," ^");			//t5PrtCatCodeS
		fprintf(fpAllRev," ^");			//t5PunIntialAgS
		fprintf(fpAllRev," ^");			//t5PunMakeBuyIndS			//40
		fprintf(fpAllRev," ^");			//t5RecoverableS
		fprintf(fpAllRev," ^");			//t5RecyclabilityS
		fprintf(fpAllRev," ^");			//t5RefPartNumberS
		fprintf(fpAllRev," ^");			//t5ReliabilityS
		fprintf(fpAllRev," ^");			//t5SpareCriteriaS
		fprintf(fpAllRev," ^");			//t5SurfPrtStdS
		fprintf(fpAllRev," ^");			//t5SamplesToApprS
		fprintf(fpAllRev," ^");			//t5AsmDisposalS
		fprintf(fpAllRev," ^");			//t5FinDisposalInstrS
		fprintf(fpAllRev," ^");			//t5RPDisposalInstrS		//50
		fprintf(fpAllRev," ^");			//t5SPDisposalInstrS
		fprintf(fpAllRev," ^");			//t5WIPDisposalInstrS
		fprintf(fpAllRev,"loader^");	//t5LastModByS
		fprintf(fpAllRev," ^");			//t5VerCreatorS
		fprintf(fpAllRev," ^");			//t5CAEDocES

		fprintf(fpAllRev,"%s","N");		//t5CoatedS
		fprintf(fpAllRev,"^");

		fprintf(fpAllRev," ^");			//t5ConvDocS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcRevS
		fprintf(fpAllRev," ^");			//t5AplCopyOfErcSeqS
		fprintf(fpAllRev," ^");			//t5AppCodeS				//60
		fprintf(fpAllRev," ^");			//t5RqstNumS
		fprintf(fpAllRev," ^");			//t5RsnCodeS
		fprintf(fpAllRev," ^");			//t5SurfaceAreaS
		fprintf(fpAllRev," ^");			//t5VolumeS
		fprintf(fpAllRev," ^");			//t5CarIntialAgencyS
		fprintf(fpAllRev," ^");			//t5CarMakeBuyIndiS
		fprintf(fpAllRev," ^");			//t5ErcIndNameS
		fprintf(fpAllRev," ^");			//t5PostRelReqS
		fprintf(fpAllRev," ^");			//t5ItmCategoryS
		fprintf(fpAllRev," ^");			//t5CopReqS					//70
		fprintf(fpAllRev," ^");			//t5AplInvalidateS
		fprintf(fpAllRev," ^");			//t5PrtValiStatusS
		fprintf(fpAllRev," ^");			//t5DRSubStateS
		fprintf(fpAllRev," ^");			//t5KnxtDocIndS
		fprintf(fpAllRev," ^");			//t5SimValS
		fprintf(fpAllRev," ^");			//t5PerYieldS
		fprintf(fpAllRev," ^");			//t5PunStoreLocationS
		fprintf(fpAllRev," ^");			//t5AltPartNoS
		fprintf(fpAllRev," ^");			//t5RolledupWtS
		fprintf(fpAllRev," ^");			//t5PFDModReqdS				//80
		fprintf(fpAllRev," ^");			//t5ToolIndentReqdS
		fprintf(fpAllRev," ^");			//CategoryNameS
		fprintf(fpAllRev,"-^");			//ReveffDateFromDup
		fprintf(fpAllRev,"-^");			//ReveffDateToDup			//84
		fprintf(fpAllRev,"NA^");		//LeftRhPartDup				//85

		fprintf(fpAllRev," ^");			//Instance with semicolon separated Rev;Seq		//86

		fprintf(fpAllRev," ^");			//t5JsrIntialAgencyS		//87
		fprintf(fpAllRev," ^");			//t5JsrMakeBuyIndiS			//88
		fprintf(fpAllRev," ^");			//t5LkoIntialAgencyS		//99
		fprintf(fpAllRev," ^");			//t5LkoMakeBuyIndiS			//90
		fprintf(fpAllRev," ^");			//t5PnrIntialAgencyS		//91
		fprintf(fpAllRev," ^");			//t5PnrMakeBuyIndiS			//92
		fprintf(fpAllRev," ^");			//t5PunPCBUIntialAgencyS	//93
		fprintf(fpAllRev," ^");			//t5PunPCBUMakeBuyIndiS		//94
		fprintf(fpAllRev," ^");			//t5SgrIntialAgencyS		//95
		fprintf(fpAllRev," ^");			//t5SgrMakeBuyIndiS			//96
		fprintf(fpAllRev," ^");			//t5EstSheetReqdS			//97
		fprintf(fpAllRev,"-^");			//PartCreDateDupS			//98
		fprintf(fpAllRev,"-^");			//PartModDateDupS			//99
		fprintf(fpAllRev,"loader^");	//PartCreatorDup			//100
		fprintf(fpAllRev," ^");			//t5AhdIntialAgencySDup		//101
		fprintf(fpAllRev," ^");			//t5AhdMakeBuyIndSDup		//102
		fprintf(fpAllRev," ^");			//t5DwdIntialAgencySDup		//103
		fprintf(fpAllRev," ^");			//t5DwdMakeBuyIndSDup		//104
		fprintf(fpAllRev," ^");			//t5JdlIntialAgencySDup		//105
		fprintf(fpAllRev," ^");			//t5JdlMakeBuyIndSDup		//106
		fprintf(fpAllRev," ^");			//t5AhdStoreLocSDup			//107
		fprintf(fpAllRev," ^");			//t5CarStoreLocSDup			//108
		fprintf(fpAllRev," ^");			//t5DwdStoreLocSDup			//109
		fprintf(fpAllRev," ^");			//t5JdlStoreLocSDup			//110
		fprintf(fpAllRev," ^");			//t5JsrStoreLocSDup			//111
		fprintf(fpAllRev," ^");			//t5LkoStoreLocSDup			//112
		fprintf(fpAllRev," ^");			//t5PnrStoreLocSDup			//113
		fprintf(fpAllRev," ^");			//t5PunPCBUStoreLocSDup		//114
		fprintf(fpAllRev," ^");			//t5SgrStoreLocSDup			//115

		//fprintf(fpAllRev,"COMP_TYPE_UA^");//DItype					//116

		fprintf(fpAllRev,"\n"); fflush(fpAllRev);
	}
	//printf("\n");

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartSO);
		t5FreeSqlPtr(Sql_ptr);

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
int SetFlagforScope(SetOfObjects ScopeObjects)
{
	ObjectPtr ScopeObjectPtr = NULL;
	int counter = 0;
	string ScopeObjectclass = NULL;
	string ScopeObjectclassDup = NULL;
	status	dstat = OKAY;

	for(counter = 0; counter < setSize(ScopeObjects); counter ++)
	{
		ScopeObjectPtr = setGet(ScopeObjects,counter);
		if(dstat = objGetClass(ScopeObjectPtr, &ScopeObjectclass)) goto CLEANUP;
		if(!nlsIsStrNull(&ScopeObjectclass))
		{
			ScopeObjectclassDup = nlsStrDup(ScopeObjectclass);
		}

		if (nlsStrCmp(ScopeObjectclass,"OscItem")==0)
		{
			printf("\nObject Found %s hence again expanding by applying dbscope",ScopeObjectclass);
			return 1;
		}
	}
	CLEANUP:
	return 0;
}
