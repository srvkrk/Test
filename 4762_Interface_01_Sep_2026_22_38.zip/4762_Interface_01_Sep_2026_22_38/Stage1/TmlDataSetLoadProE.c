/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Raghavendra B T
*  Module		 :   TCUA DataSet Uploader
*  Code			 :   DataSetLoad.c
*  Created on	 :   March 25th, 2015
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>

#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
int setAttributesOnItemRev(tag_t* rev,char* desc)
{
	int status;

	printf("\nIn function setAttributesOnItemRev\n");
	//ITK_CALL(AOM_lock(*rev));
	ITK_CALL ( AOM_set_value_string(*rev,"object_desc",desc));
	ITK_CALL(AOM_save(*rev));
	//ITK_CALL(AOM_unlock(*rev));
}
extern int ITK_user_main (int argc, char ** argv )
{
	int status;
	int result = 0;
	int count = 0;
	int iCounter1 = 0;
	int i = 0;
	int x = 0;
	int ref_count;
	int iCountSecondary = 0;
	int nameRef_cnt;
	int ii,itemcount,j=0;
	int sPartNumberTokint=0;
	int c,t=0;
	int lengthMinus=0;
	int n_attchs;

	int n_tags_found = 0;
	int n_entries = 2;
	int n_entries_d = 1;
	int n_found = 1;
	int dd = 0;
	int org_seq_id_int=0;
	int resultCount=0;
	int resultCount_d=0;
	int ref_count_d=0;
	int dataset_RevNo=0;
	int dataset_NewRevNo=0;
	int DatasetFlag=0;
	int DatasetRelFlag = 0;
	int DatasetExistFlag = 0;
	int ApplnOwnerFlag = 0;

	char *JTid1_Name =  NULL;
	char *value =  NULL;
	char *argstring1 =  NULL;
	char *argstring2 =  NULL;
	char *argstring3 =  NULL;
	char *user =  NULL;
	char *pass =  NULL;
	char *group =  NULL;
	char *itemId =  NULL;
	char *revisionID =  NULL;
	char *ItmSeqID =  NULL;
	char *ItemDesc = NULL;
	char *JTFileSeq = NULL;
	char *ClassName = NULL;
	char *SubTypeNm = NULL;
	char *DataItem = NULL;
	char *DataItemTemp = NULL;
	char *ApplnOwner = NULL;
	char *ApplnOwnerStr = NULL;
	char *RevApplnOwner = NULL;
	char *CreatedDate = NULL;
	char *ModifyDate = NULL;
	char *fullPath =  NULL;
	char *VaultLocation = NULL;
	char *HostName = NULL;
	char *Owner = NULL;
	char *ProjectCode = NULL;
	char *vault = NULL;
	char *InDatabase = NULL;
	char *Randomized = NULL;
	char *Superseded = NULL;
	char *Frozen =  NULL;
	char *LifeCycleState = NULL;
	char *FileStatus =  NULL;
	char *Externallymanaged = NULL;
	char *FileRegisteredBy = NULL;
	char *ShadowCopy =  NULL;
	char *Categoryname = NULL;
	char *Sitename =  NULL;
	char *WorkingFileName = NULL;
	char *WorkingpathFormat = NULL;
	char *BulkdataLocation = NULL;
	char *Bulkdata =  NULL;
	char *DataBasename = NULL;
	char *PartSequence = NULL;
	char *Status =  NULL;
	char *relation_input = NULL;
	char *file_type =  NULL;
	char *error_Text =  NULL;
	char *object_type = NULL;
	char *relation_form = NULL;
	char *creation_date = NULL;
	char *text =  NULL;
	char *JtTemp =  NULL;

	char line[500] =  {'\0'};
	char pathbuff[1000];
	char result1 [ 10000 ] ;
	char result2 [ 10000 ] ;

	char **ref_list;
	char **ref_list_d;

	char *o = NULL;
	char *f = NULL;
	char *test11 = NULL;
	char *test12 = NULL;
	char *test13 = NULL;
	char *JTid = NULL;
	char *JTid1 = NULL;
	char *JTid2 = NULL;
	char *Creator = NULL;
	char *aDatasetId = NULL;
	char *aDatasetRev = NULL;
	char *format=NULL;
	char *StrWeightArrayMain1=NULL;
	char *dataset_name=NULL;
	char *named_ref2=NULL;
	char *named_ref=NULL;
	char *named_refTemp=NULL;
	char *named_refTemp2=NULL;
	char *PdfDataItem=NULL;
	char *PdfDataItem1=NULL;
	char *object_string=NULL;
	char *DataSetNm = NULL;
	char *DataSetNm2 = NULL;
	char *DataSetNm3 = NULL;
	char *DataSetTmp = NULL;
	char *DataSetNmOrg = NULL;
	char *DataSetNmOrgTemp = NULL;
	char *DSTemp1 = NULL;
	char *DSTemp2 = NULL;
	char *DataSetNmOrg3 = NULL;
	char *itemRevSeq = NULL;
	char *itemRevSeq2 = NULL;
	char *ItemRevStr = NULL;
	char *relationstr = NULL;
	char *parent_name = NULL;
	char *partType = NULL;
	char *DatasetDesc = NULL;

	char *inputfile=NULL;
	char *inputline=NULL;
	char *drawingnumber;
	char *drawingtype;
	char *DatasetName;
	char *DatasetType;
	char *DatasetSeq;

	char type_name[TCTYPE_name_size_c+1] ;
	char type_name2[TCTYPE_name_size_c+1];
	char type_name3[TCTYPE_name_size_c+1];

	char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
	char **values = (char **) MEM_alloc(2 * sizeof(char *));

	char **qry_entries = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
	char **qry_values_d = (char **) MEM_alloc(10 * sizeof(char *));

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	FILE *input =  NULL;

	tag_t *status_list = NULLTAG;
	tag_t *namRefObject = NULL;
	tag_t *namRefObject_d = NULL;
	tag_t *rev=NULLTAG;
	tag_t *revtag_d=NULLTAG;
	tag_t* secondary_objects = NULLTAG;

	tag_t t_item =  NULLTAG;
	tag_t revision =  NULLTAG;
	tag_t release_status = NULLTAG;
	tag_t revstatus =  NULLTAG;
	tag_t datasettype =  NULLTAG;
	tag_t Newdataset =  NULLTAG;
	tag_t tool =  NULLTAG;
	tag_t filetag =  NULLTAG;
	tag_t datasetAvl = NULLTAG;
	tag_t aDataset = NULLTAG;
	tag_t item = NULLTAG;
	tag_t relation_type, relation;
	tag_t secObjTypeTag	= NULLTAG;
	tag_t primary,objTypeTag,refobject=NULLTAG;
	tag_t datasetTag = NULLTAG;

	IMF_file_t fileDescriptor;
	AE_reference_type_t tagRefType =  1;

	date_t test = NULLDATE;
	date_t test1 = NULLDATE;

	tag_t query = NULLTAG;
	tag_t master = NULLTAG;
	tag_t latestrev	= NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t queryTag_d = NULLTAG;
	tag_t item_tag = NULLTAG;
	tag_t itemRevDataSet_tag = NULLTAG;
	tag_t itemRevDataSet_tag2 = NULLTAG;
	tag_t item_tag_data = NULLTAG;
	tag_t item_tag_data_rev = NULLTAG;
	tag_t RefObject_d = NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t attr_id ;
	tag_t latestDataset ;

	tag_t *cntr_objects = NULL;
	tag_t *t_item1 = NULLTAG;
	tag_t *tags_found = NULL;

	char *qry_entries4[2] = {"Revision","ID"},
		 *qry_values4[2]	= {"*","*"};

	char *qry_entries4_d[3] = {"Dataset Name"},
		 *qry_values4_d[3]	= {"*"};

	FILE* fp=NULL;

	char *qry_entries3[1] = {"ID"},
		 *qry_values3[1]	= {"*"};

	tag_t reln_type = NULLTAG;
	GRM_relation_t *rellist;
	int Flag_1 =0;
	char *itemId12 =NULL;
	char *itemId123 =NULL;

	struct stat buffer;

	inputfile = ITK_ask_cli_argument("-i=");

//	if( ITK_init_module("loader" ,"loader7","dba")!=ITK_ok) ;
//	//if( ITK_init_module("infodba" ,"infodba","dba")!=ITK_ok) ;
//	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//	printf("\n Auto login ");fflush(stdout);
//	ITK_CALL(ITK_auto_login( ));
//	ITK_CALL(ITK_set_journalling( TRUE ));
//	printf("\n Auto login .......");fflush(stdout);

	initialise();


	fp=fopen(inputfile,"r");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			printf("\n\n"); fflush(stdout);
			fputs(inputline,stdout);

			if (strlen(inputline) < 10)
			{
				printf("...........1 .....[%d] [%s]",strlen(inputline),inputline); fflush(stdout);
				printf("    inputline is blank hence skipping....\n"); fflush(stdout);
				break;
			}

			itemId=strtok(inputline,"^");	//1		//TCPart or self/Reference drawing number
			revisionID=strtok(NULL,"^");	//2
			ItmSeqID=strtok(NULL,"^");		//3
			JTid1=strtok(NULL,"^");			//4
			fullPath=strtok(NULL,"^");		//5
			JTFileSeq=strtok(NULL,"^");		//6
			ClassName=strtok(NULL,"^");		//7
			SubTypeNm=strtok(NULL,"^");		//8		// Generic/Instance
			DataItemTemp=strtok(NULL,"^");	//9
			ApplnOwner=strtok(NULL,"^");	//10

			if (strcmp(SubTypeNm,"Instance") !=0 )	//skipping file exist check for instance dataset [09.01.2017]
			{
				if (!stat(fullPath , &buffer))
				{
					//printf("\n\t File exist .......%s\n",fullPath);fflush(stdout);
					;
				}
				else
				{
					printf("\n\t File not exist for [%s,%s,%s,%s], %s \n\n",itemId,revisionID,ItmSeqID,JTid1,fullPath);fflush(stdout);
					continue;
				}
			}

			ApplnOwnerStr =(char *) MEM_alloc(20);

			//DataSetNm2 = (char*)MEM_alloc( 2 * sizeof( char ) );
			DataSetNmOrg=(char *) MEM_alloc(240);
			strcpy(DataSetNmOrg,JTid1);

			DataSetNmOrg3=(char *) MEM_alloc(240);
			strcpy(DataSetNmOrg3,JTid1);

			if(strstr(DataSetNmOrg3,"_")!=NULL)
			{
				DSTemp1 = strtok(DataSetNmOrg3,"_");
				DSTemp2 = strtok(NULL,"_");
				DSTemp2 = strtok(NULL,"_");

				printf("\n\t [%s] DSTemp1: %s  DSTemp2: %s ",JTid1, DSTemp1, DSTemp2); fflush(stdout);
			}

			DataSetNm2 = NULL;
			DataSetNm2=(char *) MEM_alloc(100);
			//strcpy(DataSetNm2,"");
			strcpy(DataSetNm2,JTid1);

			printf("\n\t DataSetNm2:%s  strlen(DataSetNm2):%d",DataSetNm2,strlen(DataSetNm2)); fflush(stdout);

			itemId123 = NULL;
			itemId123 =(char *) MEM_alloc(50);

			if(strlen(DataSetNm2)>30)
			{
				if((strstr(JTid1,".asm")!=NULL) || (strstr(JTid1,".prt")!=NULL) || (strstr(JTid1,".drw")!=NULL))
				{
					printf("\n\t ....1....");fflush(stdout);

					DatasetName=strtok(DataSetNm2,"."); //1
					DatasetType=strtok(NULL,".");		//2
					DatasetSeq=strtok(NULL,".");		//3

					printf(" DatasetName:%s  DatasetType:%s  DatasetSeq:%s",DatasetName,DatasetType,DatasetSeq); fflush(stdout);

					lengthMinus=strlen(DatasetType)+ strlen(DatasetSeq) + 3 ;
					//lengthMinus=strlen(DatasetType)+ strlen(DatasetSeq);

					//printf("\n\t DatasetName --->%s",DatasetName);
					printf("  lengthMinus --->%d  strlen(DataSetNm2):%d",lengthMinus,strlen(DataSetNm2)); fflush(stdout);

					JTid1 = NULL;
					JTid1=(char *) MEM_alloc(100);
					tc_strncpy(JTid1,DatasetName,((strlen(DataSetNm2))-lengthMinus));
					//strcpy(JTid1,DatasetName);

					JTid1[tc_strlen(JTid1)] = '\0';

					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetType);
					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetSeq);
				}
				else if((tc_strstr(JTid1,".jt")!=NULL) || (tc_strstr(JTid1,".pdf")!=NULL) )
				{
					printf("\n\t ....2....");fflush(stdout);

					DatasetName=strtok(DataSetNm2,"."); //1
					DatasetType=strtok(NULL,".");		//2

					printf(" DatasetName:%s  DatasetType:%s",DatasetName,DatasetType); fflush(stdout);

					//lengthMinus=strlen(DatasetType)+ 2 ;

					//printf("\n\t DatasetName --->%s",DatasetName);
					//printf("\n\t lengthMinus --->%d",lengthMinus);

					JTid1 = NULL;
					JTid1=(char *) MEM_alloc(100);
					//strncpy(JTid1,DatasetName,((strlen(DataSetNm2))-lengthMinus));
					tc_strcpy(JTid1,DatasetName);
					tc_strcat(JTid1,".");
					tc_strcat(JTid1,DatasetType);
				}
				printf("\n\t JTid1 truncated is --->%s",JTid1); fflush(stdout);
			}

			if(JTid1)
			{
				JTid2 = NULL;
				//JTid2=(char *) MEM_alloc(32);
				JTid2=(char *) MEM_alloc(100);
				tc_strncpy(JTid2,JTid1,(strlen(JTid1)+1));
			}

			DataSetTmp=NULL;
			DataSetTmp=(char *) MEM_alloc(100);
			tc_strcpy(DataSetTmp,JTid1);

			DataSetNm3=strtok(DataSetTmp,".");

			DataItem=NULL;
			//DataItem=(char *) MEM_alloc(30 * sizeof(char *));
			DataItem=(char *) MEM_alloc(30);
			//strcpy(DataItem,"");

			if(strlen(DataItemTemp)>30)
			{
				strncpy(DataItem,DataItemTemp,29);
				DataItem[30] = '\0';
				printf("\n\t ???????? DataItem is --->[%s]",DataItem); fflush(stdout);
				printf("\n\t ???????? DataItemTemp is ---> [%s]  ????????",DataItemTemp); fflush(stdout);
			}
			else
			{
				strcpy(DataItem,DataItemTemp);
				DataItem[30] = '\0';
			}
			//DataItem[strlen(DataItem)] = '\0';

			//printf("\n"); fflush(stdout);
			/*printf("\n\t itemId is --->%s",itemId); fflush(stdout);
			printf("\n\t revisionID is --->%s",revisionID); fflush(stdout);
			printf("\n\t Seq is --->%s",ItmSeqID); fflush(stdout);
			printf("\n\t Name is --->%s",JTid1); fflush(stdout);
			printf("\n\t FullPath is --->%s",fullPath); fflush(stdout);
			printf("\n\t CAD Sequence is --->%s",JTFileSeq); fflush(stdout);
			printf("\n\t ClassName is --->%s",ClassName); fflush(stdout);
			printf("\n\t SubTypeNm is --->%s",SubTypeNm); fflush(stdout);
			printf("\n\t DataSetNm3 is --->%s",DataSetNm3); fflush(stdout);
			printf("\n\t DataItem is --->%s",DataItem); fflush(stdout);*/

			itemRevSeq = NULL;
			itemRevSeq=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq,revisionID);
			tc_strcat(itemRevSeq,"*");
			tc_strcat(itemRevSeq,ItmSeqID);

			itemRevSeq2 = NULL;
			itemRevSeq2=(char *) MEM_alloc(32);
			tc_strcpy(itemRevSeq2,revisionID);
			tc_strcat(itemRevSeq2,";");
			tc_strcat(itemRevSeq2,ItmSeqID);

			//printf("\n\t %s   itemRevSeq is --->%s",itemId,itemRevSeq); fflush(stdout);

			printf("\n\t itemId is ---> %s , %s , %s , %s",itemId,itemRevSeq,JTid1,fullPath); fflush(stdout);
			printf("\n\t CAD Sequence is ---> %s , ClassName-> %s , SubTypeNm-> %s , ApplnOwner-> %s",JTFileSeq,ClassName,SubTypeNm,ApplnOwner); fflush(stdout);
			printf("\n\t DataSetNm3 is --->%s , DataItem-> [%s]   , strlen(DataItem)->[%d]",DataSetNm3,DataItem,strlen(DataItem)); fflush(stdout);

			if(QRY_find("DesignRevision Sequence", &queryTag));
			printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);

			if (queryTag)
			{
				printf("Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);
			}
			else
			{
				printf("Not Found Query 'DesignRevision Sequence' \n\t"); fflush(stdout);

				ITK_CALL(POM_logout(false));
				return status;
			}

			qry_values[0] = itemRevSeq ;
			qry_values[1] = itemId;

			if(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));

			printf(" [%s---%s]  n_entries:%d   resultCount:%d \n\t",itemRevSeq,itemId,n_entries,resultCount); fflush(stdout);

			if(resultCount>0)
			{
				printf(" Item Revision already exists in UA....resultCount:%d \n\t",resultCount); fflush(stdout);

				for (j=0;j<resultCount;j++ )
				{
					DatasetExistFlag = 0;
					ApplnOwnerFlag = 0;
					tc_strcpy(ApplnOwnerStr,"");

					item_tag = rev[j];

					printf(" ### j:[%d]    JTid1 is --->%s\n\t ",j, JTid1); fflush(stdout);

					//ITK_CALL(AOM_ask_value_string(item_tag,"object_string",&object_string));
					//printf("\n\t item_tag object_string==> [%s]\n\t",object_string);

					printf("\n\t "); fflush(stdout);
					ITK_CALL(AOM_ask_value_string(item_tag,"item_revision_id",&ItemRevStr));
					printf("\n\t item_tag [%s]  Item Revision==> [%s]",object_string,ItemRevStr); fflush(stdout);

					if (tc_strcmp(itemRevSeq2,ItemRevStr)!=0)		//check is added on 25.07.2016
					{
						printf("...ItemRevision is not matching hence continuing.. \n\t"); fflush(stdout);
						continue;
					}

					ITK_CALL(AOM_ask_value_string(item_tag,"object_desc",&ItemDesc));
					printf("\n\t ItemDesc--object_desc:: [%s]\n\t",ItemDesc);


					if(strstr(JTid1,".asm")!=NULL)
					{
						printf("\n\t************** asm ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"ProAsm Document");

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t asm..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEAsm");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Product");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t asm..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						if(tc_strstr(JTid1,"_swp") != NULL)
						{
							printf("\n\n\t **************swp-asm****************\n\t"); fflush(stdout);

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\n\t swp-asm..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-asm..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\n\t swp-asm..Type Name:%s ..............",type_name);fflush(stdout);

								if(strcmp(type_name,"ImanFile")==0)
									continue;

								result = AE_find_datasettype("ProAsm", &datasettype);
								//printf("\n\t swp-asm..Type found---->%d",result);fflush(stdout);

								printf("\n\t ");fflush(stdout);
								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n\t"); fflush(stdout);
								//printf("\n\t swp-asm..parent_name:%s ..............",parent_name);fflush(stdout);

								if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProAsm") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-asm..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-asm..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-asm..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-asm..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-asm..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-asm..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t swp-asm..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("ProAsm", &datasettype);
								printf("\n\t swp-asm..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-asm..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t swp-asm..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-asm..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-asm..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-asm..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-asm..File saved--->%d",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-asm..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-asm..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-asm..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-asm..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-asm..Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-asm..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-asm..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else
						{
							if(QRY_find("Dataset Name", &queryTag_d));
							printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
							if (queryTag_d)
							{
								printf("  Found Query 'Dataset Name'");fflush(stdout);
							}
							else
							{
								printf("  Not Found Query 'Dataset Name'");fflush(stdout);
							}
							qry_values_d[0] = itemId ;

							if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
							printf("\n\t asm..resultCount_d:[%d]",resultCount_d);fflush(stdout);

							if(resultCount_d > 0)
							{
								DatasetFlag = 0;

								for (j=0;j<resultCount_d;j++ )
								{
									itemRevDataSet_tag = revtag_d[j];

									if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
									if(TCTYPE_ask_name(datasetTag,type_name3));
									printf("\n\t asm..Part type_name3 :%s",type_name3); fflush(stdout);

									if (strcmp(type_name3,"ProAsm")==0)
									{
										result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
										printf("\n\t asm..AE_ask_dataset--->%d",result);fflush(stdout);

										result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
										printf("\n\t asm..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

										if(ref_count_d>0)
										{
											RefObject_d = namRefObject_d[0];

											ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref));
											printf("\n\t asm..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1);

											//if (strcmp(named_ref,JTid1)==0)
											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("...already present and match found.\n");
												break;
											}
											else
											{
												printf("...match not found hence continuing..\n");
												DatasetFlag = 0;
											}
										}
									}
								}
								printf("\n\t asm..DatasetFlag:%d ",DatasetFlag);

								/*if(DatasetFlag == 1)
								{
									if(relation_type)
									{
										printf("\n\t "); fflush(stdout);
										ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
										printf("\n\t 1.asm..Type Name:%s ..............",type_name);fflush(stdout);
									}

									result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
									printf("\n\t 1.asm..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										printf("\n\t 1.asm..Relation Already Exist.\n" );fflush(stdout);
									}
									else
									{
										ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
										printf("\n\t 1.asm..GRM_create_relation ---->%d\n",result); fflush(stdout);
										ITK_CALL(AOM_refresh (item_tag,0));
										ITK_CALL(AOM_refresh(relation,0));
										result = GRM_save_relation(relation);
										printf("\t 1.asm..GRM_save_relation ---->%d\n\n",result); fflush(stdout);
									}
								}*/

								if(DatasetFlag == 1)
								{
									if(relation_type)
									{
										printf("\n\t "); fflush(stdout);
										ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
										printf("\t asm..Type Name:%s ..............",type_name);fflush(stdout);
									}

									result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
									printf("\n\t asm..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										DatasetRelFlag = 0;

										if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
										printf("  1.asm..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

										if(n_attchs>0)
										{
											for (i=0; i < n_attchs; i++)
											{
												if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
												if(TCTYPE_ask_name(secObjTypeTag,type_name2));
												printf("    1.asm..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

												if (strcmp(type_name2,"ProAsm")==0)
												{
													printf("  1.asm..Dataset is already attached to Revision \n\t"); fflush(stdout);

													printf("\n\t 1.asm..Relation Already Exist.\n\t" );fflush(stdout);
													DatasetRelFlag = 1;
													DatasetExistFlag = 1;

													ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
													printf("     1.asm..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     1.asm..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														ITK_CALL(AOM_save(secondary_objects[i]));
														ITK_CALL(AOM_unlock(secondary_objects[i]));
													}

													break;
												}
											}
										}
									}
									else
									{
										DatasetRelFlag = 0;
									}

									if (DatasetRelFlag == 0)
									{
										ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
										printf("\n\t 1.asm..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
										ITK_CALL(AOM_refresh (item_tag,0));
										printf("\n\t ");
										ITK_CALL(AOM_refresh(relation,0));
										result = GRM_save_relation(relation);
										printf("\n\t 1.asm..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else  ///New create dataset
							{
								DatasetFlag = 0;
							}

							if(DatasetFlag == 0)
							{
								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype("ProAsm", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(itemId, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Dataset created for asm --->%s",itemId); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t Got reference list--->%d",result); fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t File Imported--->%d",result); fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}

								//result = POM_attr_id_of_attr("revision_number", "WorkspaceObject", &attr_id);
								//printf("\n\t POM_attr_id_of_attr--->%d",result); fflush(stdout);

								//result = AOM_lock(Newdataset);
								//printf("\n\t AOM_lock--->%d",result); fflush(stdout);

								//printf("\n\t dataset_NewRevNo --->%d",dataset_NewRevNo); fflush(stdout);

								//result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								//printf("\n\t POM_set_attr_int--->%d",result); fflush(stdout);

								//result = AOM_save(Newdataset);
								//printf("\n\t **AOM_save--->%d",result); fflush(stdout);

								//result = AOM_unlock(Newdataset);
								//printf("\n\t AOM_unlock--->%d",result); fflush(stdout);

								////if(AOM_lock(Newdataset));
								////if(POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo))  PrintErrorStack();
								////if(AOM_save(Newdataset))PrintErrorStack();
								////if(AOM_unlock(Newdataset))PrintErrorStack();

								////result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								////printf("\n\t NewRevNo set on Dataset--->%d",result); fflush(stdout);

								////result = AOM_save(Newdataset);
								////printf(" ......AOM_save--->%d",result); fflush(stdout);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.asm..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.asm..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProAsm")==0)
											{
												printf("  2.asm..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.asm..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
												printf("     2.asm..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);

												if (strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     2.asm..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													ITK_CALL(AOM_save(secondary_objects[i]));
													ITK_CALL(AOM_unlock(secondary_objects[i]));
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
									printf("\n\t 2.asm..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									printf("\n\t ");
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\n\t 2.asm..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					else if(tc_strstr(JTid1,".prt")!=NULL)
					{
						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"ProPrt Document");

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t prt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEPart");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Part");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t prt..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						if(tc_strstr(JTid1,"_swp") != NULL)
						{
							printf("\n\n\t **************swp-prt****************\n\t"); fflush(stdout);

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\n\t swp-prt..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-prt..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\n\t swp-prt..Type Name:%s ..............",type_name);fflush(stdout);

								if(strcmp(type_name,"ImanFile")==0)
									continue;

								result = AE_find_datasettype("ProPrt", &datasettype);
								//printf("\n\t swp-prt..Type found---->%d",result);fflush(stdout);

								printf("\n\t ");fflush(stdout);
								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								printf("\n\t"); fflush(stdout);
								//printf("\n\t swp-prt..parent_name:%s ..............",parent_name);fflush(stdout);

								if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"ProPrt") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-prt..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-prt..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-prt..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-prt..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-prt..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-prt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										printf("\n\t swp-prt..AOM_save--->%d",result);fflush(stdout);fflush(stdout);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								result = AE_find_datasettype("ProPrt", &datasettype);
								printf("\n\t swp-prt..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-prt..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t swp-prt..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-prt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-prt..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-prt..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-prt..File saved--->%d",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-prt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-prt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-prt..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-prt..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-prt..Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-prt..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-prt..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else
						{
							printf("\n\t************** prt ****************\n\t"); fflush(stdout);

							if(QRY_find("Dataset Name", &queryTag_d));
							printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
							if (queryTag_d)
							{
								printf("  Found Query 'Dataset Name'");fflush(stdout);
							}
							else
							{
								printf("  Not Found Query 'Dataset Name'");fflush(stdout);
							}
							qry_values_d[0] = itemId ;

							if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
							printf("\n\t prt..resultCount_d:[%d]",resultCount_d);fflush(stdout);

							if(resultCount_d > 0)
							{
								DatasetFlag = 0;

								for (j=0;j<resultCount_d;j++ )
								{
									itemRevDataSet_tag = revtag_d[j];

									if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
									if(TCTYPE_ask_name(datasetTag,type_name3));
									printf("\n\t prt..Part type_name3 :%s",type_name3); fflush(stdout);

									if (strcmp(type_name3,"ProPrt")==0)
									{
										result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
										printf("\n\t prt..AE_ask_dataset--->%d",result);fflush(stdout);

										result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
										printf("\n\t prt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

										if(ref_count_d>0)
										{
											RefObject_d = namRefObject_d[0];

											ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp));
											printf("\n\t ");fflush(stdout);
											ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp2));

											printf("\n\t prt..item_tag named_refTemp:[%s]  JTid1:[%s]",named_refTemp,JTid1); fflush(stdout);

											if(strlen(named_refTemp)>30)
											{
												if(strstr(named_refTemp,".prt")!=NULL)
												{
													char *tempN1=strtok(named_refTemp,"."); //1
													char *tempN2=strtok(NULL,".");		//2
													char *tempN3=strtok(NULL,".");		//3

													//printf(" tempN1:%s  tempN2:%s  tempN3:%s",tempN1,tempN2,tempN3); fflush(stdout);

													int lengthMinus1=strlen(tempN2)+ strlen(tempN3) + 3 ;
													//printf(" lengthMinus --->%d",lengthMinus); fflush(stdout);

													named_ref = NULL;
													named_ref=(char *) MEM_alloc(100);
													strncpy(named_ref,tempN1,((strlen(named_refTemp))-lengthMinus1));
													strcat(named_ref,".");
													strcat(named_ref,tempN2);
													strcat(named_ref,".");
													strcat(named_ref,tempN3);
												}
											}
											else
											{
												named_ref = NULL;
												named_ref=(char *) MEM_alloc(100);
												strcpy(named_ref,named_refTemp);
											}

											printf("  named_ref:%s = %s ",named_ref , named_refTemp2); fflush(stdout);

											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_refTemp2,DataSetNmOrg)==0))
											{
												DatasetFlag = 1;
												printf("...already present and match found.\n"); fflush(stdout);
												break;
											}
											else
											{
												printf("...match not found hence continuing..\n"); fflush(stdout);
												DatasetFlag = 0;
											}
										}
									}
								}
								printf("\n\t prt..DatasetFlag:%d ",DatasetFlag); fflush(stdout);

								if(DatasetFlag == 1)
								{
									if(relation_type)
									{
										printf("\n\t "); fflush(stdout);
										ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
										printf("\t prt..Type Name:%s ..............",type_name);fflush(stdout);
									}

									result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
									printf("\n\t prt..Fndrelation ---->%d \n\t",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										DatasetRelFlag = 0;

										if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
										printf("  1.prt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

										if(n_attchs>0)
										{
											for (i=0; i < n_attchs; i++)
											{
												if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
												if(TCTYPE_ask_name(secObjTypeTag,type_name2));
												printf("    1.prt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

												if (strcmp(type_name2,"ProPrt")==0)
												{
													printf("  1.prt..Dataset is already attached to Revision \n\t"); fflush(stdout);

													printf("\n\t 1.prt..Relation Already Exist.\n\t" );fflush(stdout);
													DatasetRelFlag = 1;
													DatasetExistFlag = 1;

													//if (strcmp(SubTypeNm,"Generic")!=0)
													if(strstr(ItemDesc,"Dummy ")==NULL)
													{
														ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
														printf("     1.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
														if (strcmp(ItemDesc,DatasetDesc) != 0)
														{
															printf("     1.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

															setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
															ITK_CALL(AOM_save(secondary_objects[i]));
															ITK_CALL(AOM_unlock(secondary_objects[i]));
														}
													}

													break;
												}
											}
										}
									}
									else
									{
										DatasetRelFlag = 0;
									}

									if (DatasetRelFlag == 0)
									{
										ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
										printf("\n\t 1.prt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
										ITK_CALL(AOM_refresh (item_tag,0));
										printf("\n\t ");
										ITK_CALL(AOM_refresh(relation,0));
										result = GRM_save_relation(relation);
										printf("\n\t 1.prt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else  ///New create dataset
							{
								DatasetFlag = 0;
							}

							if(DatasetFlag == 0)
							{
								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype("ProPrt", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								printf("\n\t Creating New Dataset..."); fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t Dataset created for prt --->%s",itemId); fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t Dataset format set--->%d",result); fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t Got reference list--->%d",result); fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t File Imported--->%d",result); fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}

								//result = POM_attr_id_of_attr("revision_number", "WorkspaceObject", &attr_id);
								//printf("\n\t POM_attr_id_of_attr--->%d",result); fflush(stdout);

								//result = AOM_lock(Newdataset);
								//printf("\n\t AOM_lock--->%d",result); fflush(stdout);

								//printf("\n\t dataset_NewRevNo --->%d",dataset_NewRevNo); fflush(stdout);

								//result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								//printf("\n\t POM_set_attr_int--->%d",result); fflush(stdout);

								//result = AOM_save(Newdataset);
								//printf("\n\t **AOM_save--->%d",result); fflush(stdout);

								//result = AOM_unlock(Newdataset);
								//printf("\n\t AOM_unlock--->%d",result); fflush(stdout);

								////if(AOM_lock(Newdataset));
								////if(POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo))  PrintErrorStack();
								////if(AOM_save(Newdataset))PrintErrorStack();
								////if(AOM_unlock(Newdataset))PrintErrorStack();

								////result = POM_set_attr_int( 1, &Newdataset, attr_id, dataset_NewRevNo);
								////printf("\n\t NewRevNo set on Dataset--->%d",result); fflush(stdout);

								////result = AOM_save(Newdataset);
								////printf(" ......AOM_save--->%d",result); fflush(stdout);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.prt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.prt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProPrt")==0)
											{
												printf("  2.prt..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.prt..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												//if (strcmp(SubTypeNm,"Generic")!=0)
												if(strstr(ItemDesc,"Dummy ")==NULL)
												{
													ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
													printf("     2.prt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     2.prt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														ITK_CALL(AOM_save(secondary_objects[i]));
														ITK_CALL(AOM_unlock(secondary_objects[i]));
													}
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
									printf("\n\t 2.prt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									printf("\n\t ");
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\n\t 2.prt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					else if(strstr(JTid1,".drw")!=NULL)
					{
						printf("\n\t************** drw ****************\n\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"Drawing Document");

						if (strcmp(itemId,DataSetNm3)==0)	//self-drawing
						{
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						else	//Reference-drawing
						{
							result = GRM_find_relation_type("IMAN_reference", &relation_type);
						}
						printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  drw..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;
							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    drw..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"ProDrw")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);

									printf("\n\t drw..AE_ask_dataset--->%d",result);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t drw..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref));
										printf("\n\t drw..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1); fflush(stdout);

										//if (strcmp(named_ref,JTid1)==0)
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("...already present and match found\n"); fflush(stdout);
											break;
										}
										else
										{
											printf("...match not found hence continuing..\n"); fflush(stdout);
											DatasetFlag = 0;
										}
									}
								}
							}
							printf("\n\t DatasetFlag:%d ",DatasetFlag); fflush(stdout);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t 1.drw..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProDrw")==0)
											{
												printf("  1.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.drw..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
									printf("\n\t 1.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\t 1.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}

							/*if(DatasetFlag == 0)
							{
								result = AE_find_datasettype("ProDrw", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(DataSetNm3, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);
									result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
									printf("\n\t Dataset created for prt --->%s",DataSetNm3); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t ****drw..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t Got reference list--->%d",result); fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t File Imported--->%d",result); fflush(stdout);

									result = AOM_save(filetag);
									printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}

								//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
								//printf("\n object_string iss :[%s]\n",object_string);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t 2.drw..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProDrw")==0)
											{
												printf("  2.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.drw..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
									printf("\n\t 2.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\t 2.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);
								}
							}*/
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}
						/*else  //New create Drawing drw dataset
						{
							//ItemDesc =(char *) MEM_alloc(20);
							//strcpy(ItemDesc,"Drawing Document");

							result = AE_find_datasettype("ProDrw", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							result = AE_find_dataset(DataSetNm3, &Newdataset);
							if(Newdataset)
							{
								printf("\n\t Dataset Found..."); fflush(stdout);
							}
							else
							{
								printf("\n\t Creating New Dataset..."); fflush(stdout);
								result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
								printf("\n\t Dataset created for prt --->%s",DataSetNm3); fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t Dataset format set--->%d",result); fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);
							}

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t nameRef_cnt Count--->%d",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d",result); fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t 3.Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  3.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    3.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"ProDrw")==0)
										{
											printf("  3.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 3.drw..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
								printf("\n\t 3.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								ITK_CALL(AOM_refresh (item_tag,0));
								ITK_CALL(AOM_refresh(relation,0));
								result = GRM_save_relation(relation);
								printf("\t 3.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);
							}
						}*/

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("ProDrw", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
							printf("\n\t Dataset created for prt --->%s",DataSetNm3); fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****drw..nameRef_cnt Count--->%d",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t drw..File Imported--->%d",result); fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t 2.drw..Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.drw..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"ProDrw")==0)
										{
											printf("  2.drw..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.drw..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
								printf("\n\t 2.drw..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								ITK_CALL(AOM_refresh (item_tag,0));
								ITK_CALL(AOM_refresh(relation,0));
								result = GRM_save_relation(relation);
								printf("\t 2.drw..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(strstr(JTid1,".pdf")!=NULL)
					{
						printf("\n\t************** pdf ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"PDF Document");

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t pdf..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  pdf..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    pdf..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"PDF")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									printf("\n\t pdf..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem));
									printf("\n\t pdf..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t pdf..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref));

										printf("\n\t pdf..item_tag named_ref:[%s] JTid1:[%s]  and ",named_ref,JTid1); fflush(stdout);
										printf(" PdfDataItem:[%s] DataItem:[%s]",PdfDataItem,DataItem); fflush(stdout);

										//if (strcmp(named_ref,JTid1)==0)
										//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))
										if( ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) ) && (strcmp(PdfDataItem,DataItem)==0))	//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("..already present and match found \n\t"); fflush(stdout);
											break;
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t pdf..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t pdf..DatasetFlag:%d ",DatasetFlag); fflush(stdout);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t pdf..Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t pdf..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.pdf..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.pdf..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"PDF")==0)
											{
												printf("  1.pdf..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.pdf..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
									printf("\n\t 1.pdf..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									printf("\n\t ");
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\n\t 1.pdf..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("PDF", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for prt --->%s \n\t\ ",DataSetNm3); fflush(stdout);

							////ITK_CALL(AOM_set_value_string(Newdataset,"object_application","282947610110.drw.31"));
							ITK_CALL(AOM_set_value_string(Newdataset,"object_application",DataItem));

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****pdf..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d",result); fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.pdf..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.pdf..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"PDF")==0)
										{
											printf("  2.pdf..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.pdf..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
								printf("\n\t 2.pdf..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								ITK_CALL(AOM_refresh (item_tag,0));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(AOM_refresh(relation,0));
								result = GRM_save_relation(relation);
								printf("\n\t 2.pdf..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
     					}
					}
					else if((strstr(JTid1,".jt")!=NULL) && ((strstr(JTid1,"_ALF")==NULL) && (strstr(JTid1,"_alf")==NULL) && (strstr(JTid1,"_WELD")==NULL)))
					{
						printf("\n\t************** jt ****************\n\t"); fflush(stdout);

						Flag_1=0;
						ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
						printf("\n\t jt..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");
						strcpy(itemId123,itemId12);
						printf("\t jt..Name is --->%s\n\t ",itemId123);

						for (i= 0; i < n_attchs; i++)
						{
							primary=rellist[i].secondary;
							relationstr=rellist[i].the_relation;

							ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
							printf("\n\t "); fflush(stdout);
							ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

							//printf("\n\t jt..Type Name:%s ..............",type_name);fflush(stdout);

							if(strcmp(type_name,"ImanFile")==0)
								continue;

							result = AE_find_datasettype("DirectModel", &datasettype);
							//printf("\n\t jt..Type found---->%d",result);fflush(stdout);

							printf("\n\t ");fflush(stdout);
							ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
							//printf("\n\t jt..parent_name:%s ..............",parent_name);fflush(stdout);

							if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"DirectModel") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t jt..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t jt..Relationship already exist !!!!.......\n");fflush(stdout);

									DatasetRelFlag = 1;
									DatasetExistFlag = 1;

									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t jt..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t jt..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t jt..File saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t jt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									{
										Flag_1 = 1;

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;
									}
								}
							}
						}

						if (Flag_1 == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t jt..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t jt..Dataset created--->%s",itemId123);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t jt..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t jt..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t jt..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t jt..File Imported--->%d",result);fflush(stdout);

								if (result == 41178)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								result = AOM_save(filetag);
								printf("\n\t jt..File saved--->%d",result);fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t jt..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								printf("\n\t jt..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							printf("\n\t jt..GRM_find_relation_type ---->%d",result);fflush(stdout);

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t jt..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								printf("\n\t jt..Relation Already Exist.\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t jt..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t jt..GRM_save_relation ---->%d\n",result);fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					/*else if((strstr(JTid1,".jt")!=NULL) && ((strstr(JTid1,"_ALF")==NULL) && (strstr(JTid1,"_alf")==NULL) && (strstr(JTid1,"_WELD")==NULL)))
					{
						printf("\n\t************** jt ****************\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"JT Document");

						//if (strcmp(ClassName,"ProAsm")==0)		// commented on 06.07.2016
						//{
						//	result = GRM_find_relation_type("IMAN_specification", &relation_type);
						//	printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);
						//}
						//else if (strcmp(ClassName,"ProPrt")==0)
						//{
						//	result = GRM_find_relation_type("IMAN_Rendering", &relation_type);
						//	printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);
						//}

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);			//added on 06.07.2016 for ViewJTAssembly option for Assy and child
						printf("\n\t jt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  jt..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"DirectModel")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									printf(" jt..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem));

									if(strlen(PdfDataItem)>30)
									{
										PdfDataItem1 = NULL;
										PdfDataItem1=(char *) MEM_alloc(30);
										//PdfDataItem1=(char *) MEM_alloc(30 * sizeof(char *));
										strncpy(PdfDataItem1,PdfDataItem,29);

										//PdfDataItem=(char *) MEM_alloc(30 * sizeof(char *));
										PdfDataItem=(char *) MEM_alloc(30);
										strcpy(PdfDataItem,PdfDataItem1);

										PdfDataItem[strlen(PdfDataItem)] = '\0';
									}
									printf("\n\t jt..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t jt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref2));

										printf("\t jt..item_tag named_ref2:[%s]...JTid1:[%s] ",named_ref2,JTid1);

										named_ref=(char *) MEM_alloc(100);
										strcpy(named_ref,"");

										//JtTemp=strtok(named_ref2,".");	//commented on 03.10.2016
										//////printf("  JtTemp:[%s]",JtTemp);
										//strcpy(named_ref,JtTemp);
										//strcat(named_ref,".jt");
										//

										if(strstr(named_ref2,"#")!=NULL)
										{
											JtTemp=strtok(named_ref2,"#");
											named_ref=strtok(NULL,"#");
											//printf("  JtTemp:[%s]",JtTemp);
										}
										else
										{
											strcpy(named_ref,named_ref2);
										}

										printf("  named_ref:[%s]  and PdfDataItem:[%s] DataItem:[%s]",named_ref,PdfDataItem,DataItem);

										if ((strcmp(ClassName,"ProPrtI")==0) || (strcmp(ClassName,"ProAsmI")==0) || ((strlen(itemId)==11) && (strcmp(ClassName,"ProPrt")==0)))
										{
											//if((strcmp(named_ref,JTid1)==0))
											if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("..1.already present and match found \n\t");
												break;
											}
										}
										else
										{
											//if (strcmp(named_ref,JTid1)==0)
											//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))
											if( ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0)) && (strcmp(PdfDataItem,DataItem)==0))	//Condition Changed on 05.04.2017
											{
												DatasetFlag = 1;
												printf("..2.already present and match found \n\t");
												break;
											}
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t jt..DatasetFlag:%d ",DatasetFlag);

							if(DatasetFlag == 1)
							{
								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\t jt..Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t jt..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"DirectModel")==0)
											{
												printf("  1.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.jt..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
												printf("     1.jt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
												if (strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     1.jt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													ITK_CALL(AOM_save(secondary_objects[i]));
													ITK_CALL(AOM_unlock(secondary_objects[i]));
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
									printf("\n\t 1.jt..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									printf("\n\t ");
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\n\t 1.jt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);

							//result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							//printf("\n\t Dataset created for jt --->%s \n\t\ ",DataSetNm3); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for jt --->%s \n\t ",itemId); fflush(stdout);

							////ITK_CALL(AOM_set_value_string(Newdataset,"object_application","282947610110.drw.31"));
							if (((strlen(itemId)==11) || (tc_strstr(DataItem,"<")!=NULL)) && (tc_strstr(ClassName,"ProPrt")!=NULL))
							{
								printf("\n\t .....111111",result); fflush(stdout);
							}
							else
							{
								printf("\n\t .....1122",result); fflush(stdout);
								ITK_CALL(AOM_set_value_string(Newdataset,"object_application",DataItem));
							}

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d \n\t ",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d  [%s]",result,fullPath); fflush(stdout);

								//if (result == 41178)
								if (result != 0)
								{
									ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
								}

								//ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));

								//if (result == 14101)	//added on 15.11.2016
								//{
								//	printf("\n\t File does not present on path [%s] hence unable to create dataset for [%s]",fullPath,itemId); fflush(stdout);
								//	break;
								//}

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);
							}

							//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.jt..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.jt..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"DirectModel")==0)
										{
											printf("  2.jt..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.jt..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
											printf("     1.jt..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
											if (strcmp(ItemDesc,DatasetDesc) != 0)
											{
												printf("     2.jt..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

												setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
												ITK_CALL(AOM_save(secondary_objects[i]));
												ITK_CALL(AOM_unlock(secondary_objects[i]));
											}

											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
								printf("\n\t 2.jt..GRM_create_relation ---->%d\n\t ",result); fflush(stdout);
								ITK_CALL(AOM_refresh (item_tag,0));
								printf("\n\t ");
								ITK_CALL(AOM_refresh(relation,0));
								result = GRM_save_relation(relation);
								printf("\n\t 2.jt..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
     					}

						//printf("    jt..DatasetFlag:%d  DatasetExistFlag:%d  DatasetRelFlag:%d \n\t",DatasetFlag,DatasetExistFlag,DatasetRelFlag); fflush(stdout);
						//if (DatasetExistFlag == 1)
						//{
						//	//printf("    jt..exit\n"); fflush(stdout);
						//	break;
						//}
					}*/
					else if((strstr(JTid1,".jt")!=NULL) && ((strstr(JTid1,"_ALF")!=NULL) || (strstr(JTid1,"_alf")!=NULL) || (strstr(JTid1,"_WELD")!=NULL)))
					{
						printf("\n\t************** ALF-jt ****************\n\t"); fflush(stdout);

						ItemDesc=NULL;
						ItemDesc =(char *) MEM_alloc(20);
						strcpy(ItemDesc,"iPEM Override JT");

						result = GRM_find_relation_type("IMAN_Rendering", &relation_type);	//added on 06.07.2016 for ViewJTAssembly option for Assy and child
						printf("\n\t ALF-jt..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = itemId ;
						//qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  ALF-jt..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;

							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								//printf("    ALF-jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"DirectModel")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
									//printf("\n\t ALF-jt..AE_ask_dataset--->%d\n\t ",result);fflush(stdout);

									ITK_CALL(AOM_ask_value_string(itemRevDataSet_tag,"object_application",&PdfDataItem));
									printf("\n\t ALF-jt..PdfDataItem--->%s",PdfDataItem);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									//printf("\n\t ALF-jt..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref2));

										printf("\n\t ALF-jt..item_tag named_ref2:[%s]...JTid1:[%s] ",named_ref2,JTid1);

										named_ref=(char *) MEM_alloc(100);
										strcpy(named_ref,"");
										JtTemp=strtok(named_ref2,".");
										//printf("  JtTemp:[%s]",JtTemp);
										strcpy(named_ref,JtTemp);
										strcat(named_ref,".jt");

										printf("  named_ref:[%s]",named_ref);
										//printf("  named_ref:[%s]  and PdfDataItem:[%s] DataItem:[%s]",named_ref,PdfDataItem,DataItem);

										//if( (strcmp(named_ref,JTid1)==0) && (strcmp(PdfDataItem,DataItem)==0))	//old Condition
										//if (strcmp(named_ref,JTid1)==0)	//commented on 05.04.2017
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;

											DatasetExistFlag = 1;

											printf("..already present and match found \n\t");
											break;
										}
									}
								}
								//else
								//{
								//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
								//	DatasetFlag = 0;
								//}
							}
							printf("\n\t ALF-jt..DatasetFlag:%d  already present",DatasetFlag);
						}
						else  ///New create dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("DirectModel", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							printf("\n\t Creating New Dataset..."); fflush(stdout);
							//result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);
							//printf("\n\t Dataset created for prt --->%s \n\t\ ",DataSetNm3); fflush(stdout);
							result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t Dataset created for prt --->%s \n\t\ ",itemId); fflush(stdout);

							////ITK_CALL(AOM_set_value_string(Newdataset,"object_application","281832308207_reinfbkt.prt.3"));
							//ITK_CALL(AOM_set_value_string(Newdataset,"object_application",DataItem));

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t Dataset format set--->%d",result); fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t Tool set--->%d",result); fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d \n\t ",result); fflush(stdout);

								//result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								//printf("\n\t File Imported--->%d  [%s]",result,fullPath); fflush(stdout);

								ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t ALF-jt..AE_add_dataset_named_ref--->%d",result); fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t ALF-jt..Tool set--->%d",result); fflush(stdout);

								result = AOM_save(Newdataset);
								printf("\n\t ALF-jt..AOM_save--->%d",result); fflush(stdout);
							}

							DatasetExistFlag = 1;
						}
					}
					else if(strstr(JTid1,".CATPart")!=NULL)
					{
						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t CATPart..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if(strstr(JTid1,"Spec")!=NULL)
						{
							if((strstr(JTid1,"Spec")!=NULL) && (strstr(JTid1,".CATPart")!=NULL) && (strstr(JTid1,".cgr")!=NULL))
							{
								printf("\n\n\t **************cgr Spec CATPart CMI2CacheCgr****************\n\t"); fflush(stdout);

								Flag_1=0;
								ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
								printf("\n\t Spec-cgr-CATPart..Total n attches =%d\n",n_attchs);

								itemId12 = strtok(JTid1,".");
								strcpy(itemId123,itemId12);
								strcat(itemId123,".cgr");
								printf("\t Spec-cgr-CATPart..Name is --->%s\n\t ",itemId123);

								for (i= 0; i < n_attchs; i++)
								{
									primary=rellist[i].secondary;
									relationstr=rellist[i].the_relation;

									ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

									//printf("\n\t Spec-cgr-CATPart..Type Name:%s ..............",type_name);fflush(stdout);

									if(strcmp(type_name,"ImanFile")==0)
										continue;

									result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
									//printf("\n\t Spec-cgr-CATPart..Type found---->%d",result);fflush(stdout);

									printf("\n\t ");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
									//printf("\n\t Spec-cgr-CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

									if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
									{
										result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
										printf("\n\t Spec-cgr-CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
										if(ref_count_d>0)
										{
											Flag_1 = 1;
											printf("\n\t Spec-cgr-CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											break;
										}
										else
										{
											result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
											printf("\n\t Spec-cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

											result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
											printf("\n\t Spec-cgr-CATPart..File Imported--->%d",result);fflush(stdout);

											if (result == 41178)
											{
												ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
											}

											result = AOM_save(filetag);
											printf("\n\t Spec-cgr-CATPart..File saved--->%d",result);fflush(stdout);

											result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
											printf("\n\t Spec-cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

											AE_set_dataset_tool(primary,tool);
											printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											//sPartNumberTokint = atoi(JTFileSeq);
											//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
											//WSOM_set_revision(primary,sPartNumberTokint);

											printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											result = AOM_save(primary);
											if(result == 0)
											{
												Flag_1 = 1;

												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
											}
										}
									}
								}
								if (Flag_1 == 0)
								{
									//ItemDesc =(char *) MEM_alloc(20);
									//strcpy(ItemDesc,"Spec CMI2CacheCgr Document");

									result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
									printf("\n\t Spec-cgr-CATPart..Type found---->%d",result);fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Spec-cgr-CATPart..Dataset created--->%s",itemId123);fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Spec-cgr-CATPart..Dataset format set--->%d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
									printf("\n\t Spec-cgr-CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

									if (nameRef_cnt == 0)
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Spec-cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t Spec-cgr-CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t Spec-cgr-CATPart..File saved--->%d",result);fflush(stdout);

										ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
										result = AOM_save(filetag);
										printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t Spec-cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										printf("\n\t Spec-cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(Newdataset);
									}

									printf("\n\t Spec-cgr-CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

									result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
									printf("\n\t Spec-cgr-CATPart..Fndrelation ---->%d",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										printf("\n\t Spec-cgr-CATPart..Relation Already Exist.\n" );fflush(stdout);
									}
									else
									{
										result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
										printf("\n\t Spec-cgr-CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
										result = GRM_save_relation(relation);
										printf("\n\t Spec-cgr-CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
							else
							{
								printf("\n\n\t **************Spec CATPart CMI2AuxPart****************\n\t"); fflush(stdout);

								Flag_1=0;
								ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
								printf("\n\t Spec-CATPart-CMI2AuxPart..Total n attches = %d",n_attchs);

								itemId12 = strtok(JTid1,".");
								strcpy(itemId123,itemId12);
								printf("\n\t Spec-CATPart-CMI2AuxPart..Name is ---> %s\n\t ",itemId123); fflush(stdout);

								for (i= 0; i < n_attchs; i++)
								{
									primary=rellist[i].secondary;
									relationstr=rellist[i].the_relation;

									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
									printf("\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

									//printf("\n\t Spec-CATPart-CMI2AuxPart..Type Name:%s ..............",type_name);fflush(stdout);

									if(strcmp(type_name,"ImanFile")==0)
										continue;

									result = AE_find_datasettype("CMI2AuxPart", &datasettype);
									//printf("\n\t Spec-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

									printf("\t ");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
									//printf("\n\t Spec-CATPart-CMI2AuxPart..parent_name:%s ..............",parent_name);fflush(stdout);

									if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
									{
										result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
										printf("\n\t Spec-CATPart-CMI2AuxPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
										if(ref_count_d>0)
										{
											Flag_1 = 1;
											printf("\n\t Spec-CATPart-CMI2AuxPart..Relationship already exist !!!!.......\n");fflush(stdout);

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;

											break;
										}
										else
										{
											result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

											result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..File Imported--->%d   [%s]",result,fullPath);fflush(stdout);

											if (result == 41178)
											{
												ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
											}

											result = AOM_save(filetag);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

											if (result == 7007)
											{
												Flag_1 = -1;

												break;
											}
											else
											{
												ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
												result = AOM_save(filetag);
												printf("\n\t 1.Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);
											}

											result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

											AE_set_dataset_tool(primary,tool);
											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											//sPartNumberTokint = atoi(JTFileSeq);
											//printf("\n Spec-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
											//WSOM_set_revision(primary,sPartNumberTokint);

											printf("\n\t 1.Spec-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

											result = AOM_save(primary);
											if(result == 0)
											{
												Flag_1 = 1;

												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
											}
										}
									}
								}
								if (Flag_1 == 0)
								{
									//ItemDesc =(char *) MEM_alloc(20);
									//strcpy(ItemDesc,"Spec CMI2AuxPart Document");

									result = AE_find_datasettype("CMI2AuxPart", &datasettype);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Type found----> %d",result);fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Dataset created---> %s",itemId123);fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Spec-CATPart-CMI2AuxPart..Dataset format set---> %d",result);fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

									result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
									printf("\n\t Spec-CATPart-CMI2AuxPart..nameRef_cnt Count---> %d",nameRef_cnt);fflush(stdout);

									if (nameRef_cnt == 0)
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Spec-CATPart-CMI2AuxPart..Got reference list---> %d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t Spec-CATPart-CMI2AuxPart..File Imported---> %d   [%s]",result,fullPath);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t Spec-CATPart-CMI2AuxPart..File saved---> %d",result);fflush(stdout);

										if (result == 7007)
										{
											break;
										}
										else
										{
											ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
											result = AOM_save(filetag);
											printf("\n\t Spec-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);
										}

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t Spec-CATPart-CMI2AuxPart..AE_add_dataset_named_ref---> %d",result);fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

										printf("\n\t Spec-CATPart-CMI2AuxPart..Tool set---> %d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(Newdataset);
									}

									printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_find_relation_type ----> %d",result);fflush(stdout);

									result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
									printf("\n\t Spec-CATPart-CMI2AuxPart..Fndrelation ----> %d",result); fflush(stdout);

									if(Fndrelation != NULLTAG)
									{
										printf("\n\t Spec-CATPart-CMI2AuxPart..Relation Already Exist.\n" );fflush(stdout);
									}
									else
									{
										result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
										printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_create_relation ----> %d",result);fflush(stdout);
										result = GRM_save_relation(relation);
										printf("\n\t Spec-CATPart-CMI2AuxPart..GRM_save_relation ----> %d\n",result);fflush(stdout);

										DatasetExistFlag = 1;
									}
								}
							}
						}
						else if((strstr(JTid1,".CATPart")!=NULL) && (strstr(JTid1,".cgr")!=NULL))
						{
							printf("\n\n\t **************cgr CMI2CacheCgr****************\n\t"); fflush(stdout);

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\n\t cgr-CATPart..Total n attches =%d\n",n_attchs); fflush(stdout);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							strcat(itemId123,".cgr");
							printf("\t cgr-CATPart..Name is --->%s\n\t ",itemId123); fflush(stdout);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\n\t cgr-CATPart..Type Name:%s ..............",type_name);fflush(stdout);

								if(strcmp(type_name,"ImanFile")==0)
									continue;

								result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
								//printf("\n\t cgr-CATPart..Type found---->%d",result);fflush(stdout);

								printf("\n\t ");fflush(stdout);
								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								//printf("\n\t cgr-CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

								if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2CacheCgr") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t cgr-CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t cgr-CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t cgr-CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t cgr-CATPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"CMI2CacheCgr Document");

								result = AE_find_datasettype("CMI2CacheCgr", &datasettype);
								printf("\n\t cgr-CATPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t cgr-CATPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t cgr-CATPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t cgr-CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t cgr-CATPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t cgr-CATPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t cgr-CATPart..File saved--->%d",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t cgr-CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t cgr-CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								result = GRM_find_relation_type("IMAN_specification", &relation_type);
								printf("\n\t cgr-CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);
								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t cgr-CATPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t cgr-CATPart..Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t cgr-CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t cgr-CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else if((strstr(JTid1,".CATPart")!=NULL) && (strstr(JTid1,"_swp")!=NULL))
						{
							printf("\n\n\t **************swp CATPart CMI2AuxPart****************\n\t"); fflush(stdout);

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\n\t swp-CATPart-CMI2AuxPart..Total n attches =%d\n",n_attchs);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t swp-CATPart-CMI2AuxPart..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\n\t swp-CATPart-CMI2AuxPart..Type Name:%s ..............",type_name);fflush(stdout);

								if(strcmp(type_name,"ImanFile")==0)
									continue;

								result = AE_find_datasettype("CMI2AuxPart", &datasettype);
								//printf("\n\t swp-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

								printf("\n\t ");fflush(stdout);
								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								//printf("\n\t swp-CATPart-CMI2AuxPart..parent_name:%s ..............",parent_name);fflush(stdout);

								if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2AuxPart") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t swp-CATPart-CMI2AuxPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t swp-CATPart-CMI2AuxPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t swp-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t swp-CATPart-CMI2AuxPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t swp-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t swp-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n swp-cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"swp CMI2AuxPart Document");

								result = AE_find_datasettype("CMI2AuxPart", &datasettype);
								printf("\n\t swp-CATPart-CMI2AuxPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t swp-CATPart-CMI2AuxPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t swp-CATPart-CMI2AuxPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t swp-CATPart-CMI2AuxPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t swp-CATPart-CMI2AuxPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t swp-CATPart-CMI2AuxPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t swp-CATPart-CMI2AuxPart..File saved--->%d",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t swp-cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t swp-CATPart-CMI2AuxPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t swp-CATPart-CMI2AuxPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t swp-CATPart-CMI2AuxPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t swp-CATPart-CMI2AuxPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t swp-CATPart-CMI2AuxPart..Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t swp-CATPart-CMI2AuxPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t swp-CATPart-CMI2AuxPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else //For NON Spec files
						{
							printf("\n\n\t ************** NON Spec/cgr/swp CATPart ****************\n\t"); fflush(stdout);

							if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
							{
								ApplnOwnerFlag = 1;

								if (strstr(ApplnOwner,"Proe")!=NULL)
								{
									strcpy(ApplnOwnerStr,"ProEPart");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else if (strstr(ApplnOwner,"Catia")!=NULL)
								{
									strcpy(ApplnOwnerStr,"Cat-Part");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else
								{
									strcpy(ApplnOwnerStr,"");

									printf("\n\t CATPart..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
								}
							}

							ITK_CALL ( AOM_ask_value_string(item_tag,"t5_PartType",&partType));

							if (tc_strcmp(partType,"C") != 0)
							//if (strcmp(partType,"C") == 0 )
							//{
							//	printf("\n %s has Part Type to component[%s]\n",itemId,partType); fflush(stdout);
							//}
							//else
							{
								printf("\n\t %s Stamping the Part Type to component[C] before was [%s]\n\t",itemId,partType); fflush(stdout);

								ITK_CALL(AOM_lock(item_tag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL ( AOM_set_value_string(item_tag,"t5_PartType","C"));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(AOM_save(item_tag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(AOM_unlock(item_tag));
							}
							else
							{
								printf("\n\t"); fflush(stdout);
							}

							Flag_1=0;
							ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
							printf("\n\t CATPart..Total n attches =%d\n",n_attchs); fflush(stdout);

							itemId12 = strtok(JTid1,".");
							strcpy(itemId123,itemId12);
							printf("\t CATPart..Name is --->%s\n\t ",itemId123);

							for (i= 0; i < n_attchs; i++)
							{
								primary=rellist[i].secondary;
								relationstr=rellist[i].the_relation;

								ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

								//printf("\n\t CATPart..Type Name:%s ..............",type_name);fflush(stdout);

								if(strcmp(type_name,"ImanFile")==0)
									continue;

								result = AE_find_datasettype("CMI2Part", &datasettype);
								//printf("\n\t CATPart..Type found---->%d",result);fflush(stdout);

								printf("\n\t "); fflush(stdout);
								ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
								//printf("\n\t CATPart..parent_name:%s ..............",parent_name);fflush(stdout);

								if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Part") ==0)
								{
									result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
									printf("\n\t CATPart..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
									if(ref_count_d>0)
									{
										Flag_1 = 1;
										printf("\n\t CATPart..Relationship already exist !!!!.......\n");fflush(stdout);

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;

										break;
									}
									else
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t CATPart..Got reference list--->%d",result);fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t CATPart..File Imported--->%d",result);fflush(stdout);

										if (result == 41178)
										{
											ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
										}

										result = AOM_save(filetag);
										printf("\n\t CATPart..File saved--->%d",result);fflush(stdout);

										result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
										printf("\n\t CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

										AE_set_dataset_tool(primary,tool);
										printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										//sPartNumberTokint = atoi(JTFileSeq);
										//printf("\n cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
										//WSOM_set_revision(primary,sPartNumberTokint);

										printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

										result = AOM_save(primary);
										if(result == 0)
										{
											Flag_1 = 1;

											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
										}
									}
								}
							}
							if (Flag_1 == 0)
							{
								//ItemDesc =(char *) MEM_alloc(20);
								//strcpy(ItemDesc,"CMI2Part Document");

								result = AE_find_datasettype("CMI2Part", &datasettype);
								printf("\n\t CATPart..Type found---->%d",result);fflush(stdout);

								result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
								printf("\n\t CATPart..Dataset created--->%s",itemId123);fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t CATPart..Dataset format set--->%d",result);fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t CATPart..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if (nameRef_cnt == 0)
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t CATPart..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t CATPart..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t CATPart..File saved--->%d",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
									result = AOM_save(filetag);
									printf("\n\t cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t CATPart..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									printf("\n\t CATPart..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(Newdataset);
								}

								printf("\n\t CATPart..GRM_find_relation_type ---->%d",result);fflush(stdout);

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t CATPart..Fndrelation ---->%d",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									printf("\n\t CATPart..Relation Already Exist.\n" );fflush(stdout);
								}
								else
								{
									result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
									printf("\n\t CATPart..GRM_create_relation ---->%d",result);fflush(stdout);
									result = GRM_save_relation(relation);
									printf("\n\t CATPart..GRM_save_relation ---->%d\n",result);fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					}
					else if(strstr(JTid1,".CATProduct")!=NULL)
					{
						printf("\n\n\t ************** CATProduct ****************\n\t"); fflush(stdout);

						if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
						{
							ApplnOwnerFlag = 1;

							if (strstr(ApplnOwner,"Proe")!=NULL)
							{
								strcpy(ApplnOwnerStr,"ProEAsm");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else if (strstr(ApplnOwner,"Catia")!=NULL)
							{
								strcpy(ApplnOwnerStr,"Cat-Product");
								ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
							}
							else
							{
								strcpy(ApplnOwnerStr,"");

								printf("\n\t CATPart..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
							}
						}

						Flag_1=0;
						ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
						printf("\n\t CATProduct..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");
						strcpy(itemId123,itemId12);
						printf("\t CATProduct..Name is --->%s\n\t ",itemId123);

						for (i= 0; i < n_attchs; i++)
						{
							primary=rellist[i].secondary;
							relationstr=rellist[i].the_relation;

							ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
							printf("\n\t "); fflush(stdout);
							ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

							//printf("\n\t CATProduct..Type Name:%s ..............",type_name);fflush(stdout);

							if(strcmp(type_name,"ImanFile")==0)
								continue;

							result = AE_find_datasettype("CMI2Product", &datasettype);
							//printf("\n\t CATProduct..Type found---->%d",result);fflush(stdout);

							printf("\n\t ");fflush(stdout);
							ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
							//printf("\n\t CATProduct..parent_name:%s ..............",parent_name);fflush(stdout);

							if(strcmp(parent_name,itemId123)==0 &&  strcmp(type_name,"CMI2Product") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t CATProduct..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t CATProduct..Relationship already exist !!!!.......\n");fflush(stdout);

									DatasetRelFlag = 1;
									DatasetExistFlag = 1;

									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t CATProduct..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t CATProduct..File Imported--->%d",result);fflush(stdout);

									if (result == 41178)
									{
										ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
									}

									result = AOM_save(filetag);
									printf("\n\t CATProduct..File saved--->%d",result);fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t CATProduct..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n cgr-Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									{
										Flag_1 = 1;

										DatasetRelFlag = 1;
										DatasetExistFlag = 1;
									}
								}
							}
						}
						if (Flag_1 == 0)
						{
							//ItemDesc =(char *) MEM_alloc(20);
							//strcpy(ItemDesc,"CMI2Product Document");

							result = AE_find_datasettype("CMI2Product", &datasettype);
							printf("\n\t CATProduct..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId123,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t CATProduct..Dataset created--->%s",itemId123);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t CATProduct..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t CATProduct..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t CATProduct..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t CATProduct..File Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t CATProduct..File saved--->%d",result);fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t cgr-File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t CATProduct..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								printf("\n\t CATProduct..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							printf("\n\t CATProduct..GRM_find_relation_type ---->%d",result);fflush(stdout);

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t CATProduct..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								printf("\n\t CATProduct..Relation Already Exist.\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t CATProduct..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t CATProduct..GRM_save_relation ---->%d\n",result);fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(strstr(JTid1,".CATDrawing")!=NULL)
					{
						printf("\n\t************** CATDrawing ****************\n\n\t"); fflush(stdout);

						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"CATDrawing Document");

						//result = GRM_find_relation_type("IMAN_specification", &relation_type);
						//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

						if (strcmp(itemId,DataSetNm3)==0)	//self-drawing
						{
							result = GRM_find_relation_type("IMAN_specification", &relation_type);
						}
						else	//Reference-drawing
						{
							result = GRM_find_relation_type("IMAN_reference", &relation_type);
						}
						printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);


						if(QRY_find("Dataset Name", &queryTag_d));
						printf("  After IFERR_REPORT : QRY_find ....");fflush(stdout);
						if (queryTag_d)
						{
							printf("  Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						else
						{
							printf("  Not Found Query 'Dataset Name' \n\t");fflush(stdout);
						}
						qry_values_d[0] = DataSetNm3 ;

						if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
						printf("  CATDrawing..resultCount_d:[%d] \n\t",resultCount_d);fflush(stdout);

						if(resultCount_d > 0)
						{
							DatasetFlag = 0;
							for (j=0;j<resultCount_d;j++ )
							{
								itemRevDataSet_tag = revtag_d[j];

								if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
								if(TCTYPE_ask_name(datasetTag,type_name3));
								printf("    CATDrawing..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

								if (strcmp(type_name3,"CMI2Drawing")==0)
								{
									result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);

									printf("\n\t CATDrawing..AE_ask_dataset--->%d",result);fflush(stdout);

									result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
									printf("\n\t CATDrawing..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

									if(ref_count_d>0)
									{
										RefObject_d = namRefObject_d[0];

										ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_ref));
										printf("\n\t CATDrawing..item_tag named_ref:[%s]  JTid1:[%s]",named_ref,JTid1);

										//if (strcmp(named_ref,JTid1)==0)
										if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_ref,DataSetNmOrg) == 0) )		//Condition Changed on 05.04.2017
										{
											DatasetFlag = 1;
											printf("...already present and match found\n");
											break;
										}
										else
										{
											printf("...match not found hence continuing..\n");
											DatasetFlag = 0;
										}
									}
								}
							}
							printf("\n\t DatasetFlag:%d ",DatasetFlag);

							if(DatasetFlag == 1)
							{
								if(relation_type)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
								printf("\n\t 1.CATDrawing..Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  1.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    1.CATDrawing..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"CMI2Drawing")==0)
											{
												printf("  1.CATDrawing..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 1.CATDrawing..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;
												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
									printf("\n\t 1.CATDrawing..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\t 1.CATDrawing..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
						else  //New create Drawing CATDrawing dataset
						{
							DatasetFlag = 0;
						}

						if(DatasetFlag == 0)
						{
							result = AE_find_datasettype("CMI2Drawing", &datasettype);
							printf("\n\t Type found---->%d",result);fflush(stdout);

							//result = AE_find_dataset(DataSetNm3, &Newdataset);
							//if(Newdataset)
							//{
							//	printf("\n\t Dataset Found..."); fflush(stdout);
							//}
							//else
							//{
								printf("\n\t Creating New Dataset..."); fflush(stdout);
								result = AE_create_dataset_with_id(datasettype,DataSetNm3,ItemDesc, NULL, NULL, &Newdataset);  //DataSetNm3
								printf("\n\t Dataset created for CATDrawing --->%s",DataSetNm3); fflush(stdout);

								result = AE_set_dataset_format(Newdataset, "BINARY_REF");
								printf("\n\t Dataset format set--->%d",result); fflush(stdout);

								result = AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t Tool set--->%d",result); fflush(stdout);
							//}

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****CATDrawing..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t Got reference list--->%d",result); fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t File Imported--->%d",result); fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);


								if(Newdataset)
								{
									result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
									printf("\n\t AE_add_dataset_named_ref--->%d\n\n",result); fflush(stdout);

									//AE_set_dataset_tool(Newdataset,tool);
									//printf("\n\t Tool set--->%d",result); fflush(stdout);

									result = AOM_save(Newdataset);
									printf("\n\t AOM_save--->%d",result); fflush(stdout);
								}
								else
								{
									printf("\n\t ??? Unable to create DATASET for --->%s",DataSetNm3); fflush(stdout);

									//break;
								}
							}

							//ITK_CALL(AOM_ask_value_string(Newdataset,"object_string",&object_string));
							//printf("\n object_string iss :[%s]\n",object_string);

							//result = GRM_find_relation_type("IMAN_specification", &relation_type);
							//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\n\t Type Name:%s ..............",type_name);fflush(stdout);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t 2.CATDrawing..Fndrelation ---->%d \n\t",result); fflush(stdout);

							if(Fndrelation != NULLTAG)
							{
								DatasetRelFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  2.item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    2.CATDrawing..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (strcmp(type_name2,"CMI2Drawing")==0)
										{
											printf("  2.CATDrawing..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 2.CATDrawing..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											break;
										}
									}
								}
							}
							else
							{
								DatasetRelFlag = 0;
							}

							if (DatasetRelFlag == 0)
							{
								ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
								printf("\n\t 2.CATDrawing..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
								ITK_CALL(AOM_refresh (item_tag,0));
								ITK_CALL(AOM_refresh(relation,0));
								result = GRM_save_relation(relation);
								printf("\t 2.CATDrawing..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

								DatasetExistFlag = 1;
							}
						}
					}
					else if(strstr(JTid1,".csv")!=NULL)
					{
						Flag_1=0;

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n csv..GRM_find_relation_type ---->%d",result);fflush(stdout);


						//ItemDesc =(char *) MEM_alloc(20);
						//strcpy(ItemDesc,"csv Ecxel Document");

						ITK_CALL(GRM_list_secondary_objects(item_tag,reln_type,&n_attchs,&rellist));
						printf("\n\t csv..Total n attches =%d\n",n_attchs);

						itemId12 = strtok(JTid1,".");  //1
						printf("  Name is --->%s \n\t ",itemId12);

						for (i= 0; i < n_attchs; i++)
						{
							//printf("\n Inside loop ..............");fflush(stdout);
							//primary=secondary_objects[i];

							primary=rellist[i].secondary;
							relationstr=rellist[i].the_relation;

							ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag));
							ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));

							printf("\n csv..Type Name:%s ..............",type_name);fflush(stdout);

							if(strcmp(type_name,"ImanFile")==0)
								continue;

							result = AE_find_datasettype("MSExcel", &datasettype);
							printf("\n\t csv..Type found---->%d",result);fflush(stdout);

							printf("\n\t ");fflush(stdout);
							ITK_CALL(AOM_ask_value_string(primary,"object_name",&parent_name));
							printf("\n\t csv..parent_name:%s ..............",parent_name);fflush(stdout);

							if(strcmp(parent_name,itemId12)==0 &&  strcmp(type_name,"MSExcel") ==0)
							{
								result = AE_ask_dataset_named_refs(primary,&ref_count_d, &namRefObject_d);
								printf("\n\t ****csv..ref_count_d Count--->%d\n",ref_count_d);fflush(stdout);
								if(ref_count_d>0)
								{
									Flag_1 = 1;
									printf("\n\t csv..Relationship already exist !!!!.......");fflush(stdout);
									break;
								}
								else
								{
									result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
									printf("\n\t csv..Got reference list--->%d",result);fflush(stdout);

									result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
									printf("\n\t csv..File Imported--->%d",result);fflush(stdout);

									result = AOM_save(filetag);
									printf("\n\t csv..File saved--->%d \n\t ",result);fflush(stdout);

									ITK_CALL(IMF_set_original_file_name(filetag,itemId12));
									result = AOM_save(filetag);
									printf("\n\t File saved--->%d  [%s]",result,itemId12); fflush(stdout);

									result = AE_add_dataset_named_ref(primary,ref_list[0],tagRefType,filetag);
									printf("\n\t csv..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

									AE_set_dataset_tool(primary,tool);
									printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									//sPartNumberTokint = atoi(JTFileSeq);
									//printf("\n\t csv..Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
									//WSOM_set_revision(primary,sPartNumberTokint);

									printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

									result = AOM_save(primary);
									if(result == 0)
									Flag_1 = 1;
								}
							}
						}

						if (Flag_1 == 0)
						{
							printf("\n\t csv..itemId12 found---->%s",itemId12);fflush(stdout);
							result = AE_find_datasettype("MSExcel", &datasettype);
							printf("\n\t csv..Type found---->%d",result);fflush(stdout);

							result = AE_create_dataset_with_id(datasettype,itemId12,ItemDesc, NULL, NULL, &Newdataset);
							printf("\n\t csv..Dataset Created---->%d",result);fflush(stdout);

							result = AE_set_dataset_format(Newdataset, "BINARY_REF");
							printf("\n\t csv..Dataset format set--->%d",result);fflush(stdout);

							result = AE_set_dataset_tool(Newdataset,tool);
							printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

							result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
							printf("\n\t ****csv..nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

							if (nameRef_cnt == 0)
							{
								result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
								printf("\n\t csv..Got reference list--->%d",result);fflush(stdout);

								result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
								printf("\n\t csv..File Imported--->%d",result);fflush(stdout);

								result = AOM_save(filetag);
								printf("\n\t csv..File saved--->%d \n\t ",result);fflush(stdout);

								ITK_CALL(IMF_set_original_file_name(filetag,itemId12));
								result = AOM_save(filetag);
								printf("\n\t File saved--->%d  [%s]",result,itemId12); fflush(stdout);

								result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
								printf("\n\t csv..AE_add_dataset_named_ref--->%d",result);fflush(stdout);

								AE_set_dataset_tool(Newdataset,tool);
								printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								//sPartNumberTokint = atoi(JTFileSeq);
								//printf("\n Sequece going to set is--->%d\n",sPartNumberTokint);fflush(stdout);
								//WSOM_set_revision(Newdataset,sPartNumberTokint);

								printf("\n\t csv..Tool set--->%d",result);fflush(stdout);fflush(stdout);

								result = AOM_save(Newdataset);
							}

							result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
							printf("\n\t csv..Fndrelation ---->%d",result); fflush(stdout);

							if(Fndrelation)
							{
								printf("\n\t csv..Relation Already Exist.\n" );fflush(stdout);
							}
							else
							{
								result = GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation);
								printf("\n\t csv..GRM_create_relation ---->%d",result);fflush(stdout);
								result = GRM_save_relation(relation);
								printf("\n\t csv..GRM_save_relation ---->%d",result);fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n\t******* Generic/Instance *********"); fflush(stdout);
						printf("\n\t SubTypeNm:[%s]",SubTypeNm);fflush(stdout);

						result = GRM_find_relation_type("IMAN_specification", &relation_type);
						printf("\n\t Generic/Instance..GRM_find_relation_type ---->%d",result); fflush(stdout);

						if( (strcmp(SubTypeNm,"Generic")==0) ||  (strcmp(SubTypeNm,"Instance")==0) )
						{
							//if( (strlen(ApplnOwner) > 3) /* && (strcmp(ApplnOwner,"-")!=0) && (strcmp(ApplnOwner," ")!=0) */)
							//{
								ApplnOwnerFlag = 1;

								if ( (strstr(ApplnOwner,"Proe")!=NULL) || (strcmp(ApplnOwner,"-")==0) && (strcmp(ApplnOwner,"")==0))
								{
									strcpy(ApplnOwnerStr,"ProEPart");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else if (strstr(ApplnOwner,"Catia")!=NULL)
								{
									strcpy(ApplnOwnerStr,"Cat-Part");
									ApplnOwnerStr[strlen(ApplnOwnerStr)] = '\0';
								}
								else
								{
									strcpy(ApplnOwnerStr,"");

									printf("\n\t Generic/Instance..ApplnOwner string is not Valid to Set ---->%s,%s , %s",itemId,itemRevSeq,JTid1); fflush(stdout);
								}
							//}

							if(relation_type)
							{
								printf("\n\t "); fflush(stdout);
								ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
								printf("\t Generic/Instance..Type Name:%s ..............",type_name);fflush(stdout);
							}

							if(tc_strcmp(SubTypeNm,"Instance")==0)
							{
								DatasetRelFlag = 0;
								DatasetFlag = 0;
								DatasetExistFlag = 0;

								if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
								printf("  1.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

								if(n_attchs>0)
								{
									for (i=0; i < n_attchs; i++)
									{
										if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
										if(TCTYPE_ask_name(secObjTypeTag,type_name2));
										printf("    1.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

										if (tc_strcmp(type_name2,"ProPrt")==0)
										{
											printf("  1.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

											printf("\n\t 1.Generic/Instance..Relation Already Exist.\n\t" );fflush(stdout);
											DatasetRelFlag = 1;
											DatasetExistFlag = 1;
											DatasetFlag = 1;

											if (tc_strcmp(SubTypeNm,"Instance")==0)
											{
												ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
												printf("     1.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
												if (tc_strcmp(ItemDesc,DatasetDesc) != 0)
												{
													printf("     1.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

													setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
													ITK_CALL(AOM_save(secondary_objects[i]));
													ITK_CALL(AOM_unlock(secondary_objects[i]));
												}
											}
											break;
										}
									}
								}
							}
							else
							{
								if(QRY_find("Dataset Name", &queryTag_d));
								printf("  After IFERR_REPORT : QRY_find....");fflush(stdout);
								if (queryTag_d)
								{
									printf("  Found Query 'Dataset Name'");fflush(stdout);
								}
								else
								{
									printf("  Not Found Query 'Dataset Name'");fflush(stdout);
								}
								qry_values_d[0] = itemId ;

								if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
								printf("\n\t Generic/Instance..resultCount_d:[%d]",resultCount_d);fflush(stdout);

								if(resultCount_d > 0)
								{
									DatasetFlag = 0;

									for (j=0;j<resultCount_d;j++ )
									{
										itemRevDataSet_tag = revtag_d[j];

										if(TCTYPE_ask_object_type(itemRevDataSet_tag,&datasetTag));
										if(TCTYPE_ask_name(datasetTag,type_name3));
										printf("\n\t Generic/Instance..Part type_name3 :%s",type_name3); fflush(stdout);

										if (strcmp(type_name3,"ProPrt")==0)
										{
											result = AE_ask_dataset (itemRevDataSet_tag,&item_tag_data_rev);
											printf("\n\t Generic/Instance..AE_ask_dataset--->%d",result);fflush(stdout);

											result = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
											printf("\n\t Generic/Instance..ref_count_d Count--->%d \n\t ",ref_count_d);fflush(stdout);

											if((ref_count_d>0) && (strcmp(SubTypeNm,"Generic")==0))
											{
												RefObject_d = namRefObject_d[0];

												ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp));
												ITK_CALL(AOM_ask_value_string(RefObject_d,"object_string",&named_refTemp2));
												printf("\n\t Generic/Instance..item_tag named_refTemp:[%s]  JTid1:[%s]",named_refTemp,JTid1);

												if(strlen(named_refTemp)>30)
												{
													if(strstr(named_refTemp,".prt")!=NULL)
													{
														char *tempN1=strtok(named_refTemp,"."); //1
														char *tempN2=strtok(NULL,".");		//2
														//char *tempN3=strtok(NULL,".");		//3

														//printf(" tempN1:%s  tempN2:%s  tempN3:%s",tempN1,tempN2,tempN3); fflush(stdout);
														printf(" tempN1:%s  tempN2:%s ",tempN1,tempN2); fflush(stdout);

														//int lengthMinus1=strlen(tempN2)+ strlen(tempN3) + 3 ;
														int lengthMinus1=strlen(tempN2) + 1 ;
														printf(" lengthMinus --->%d",lengthMinus);

														named_ref = NULL;
														named_ref=(char *) MEM_alloc(100);
														strncpy(named_ref,tempN1,((strlen(named_refTemp))-lengthMinus1));
														strcat(named_ref,".");
														strcat(named_ref,tempN2);
														//strcat(named_ref,".");
														//strcat(named_ref,tempN3);
													}
												}
												else
												{
													named_ref = NULL;
													named_ref=(char *) MEM_alloc(100);
													strcpy(named_ref,named_refTemp);
												}

												if ((strcmp(named_ref,JTid1)==0) || (strcmp(named_refTemp2,DataSetNmOrg)==0))
												{
													DatasetFlag = 1;
													printf("...already present and match found.\n");
													break;
												}
												else
												{
													printf("...match not found hence continuing..\n");
													DatasetFlag = 0;
												}
											}
											if (strcmp(SubTypeNm,"Instance")==0)
											{
												DatasetFlag = 1;
												printf("...Instance already present and match found.\n");
												break;
											}
											else
											{
												printf("...Instance match not found hence continuing..\n");
												DatasetFlag = 0;
											}
										}
									}
									printf("\n\t Generic/Instance..DatasetFlag:%d ",DatasetFlag);

									if(DatasetFlag == 1)
									{
										//result = GRM_find_relation_type("IMAN_specification", &relation_type);
										//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

										if(relation_type)
										{
											printf("\n\t "); fflush(stdout);
											ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
											printf("\t Generic/Instance..Type Name:%s ..............",type_name);fflush(stdout);
										}

										result = GRM_find_relation( item_tag, item_tag_data_rev, relation_type ,&Fndrelation);
										printf("\n\t Generic/Instance..Fndrelation ---->%d \n\t",result); fflush(stdout);

										if(Fndrelation != NULLTAG)
										{
											DatasetRelFlag = 0;

											if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
											printf("  1.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

											if(n_attchs>0)
											{
												for (i=0; i < n_attchs; i++)
												{
													if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
													if(TCTYPE_ask_name(secObjTypeTag,type_name2));
													printf("    1.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

													if (strcmp(type_name2,"ProPrt")==0)
													{
														printf("  1.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

														printf("\n\t 1.Generic/Instance..Relation Already Exist.\n\t" );fflush(stdout);
														DatasetRelFlag = 1;
														DatasetExistFlag = 1;

														if (strcmp(SubTypeNm,"Instance")==0)
														{
															ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
															printf("     1.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
															if (strcmp(ItemDesc,DatasetDesc) != 0)
															{
																printf("     1.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

																setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
																ITK_CALL(AOM_save(secondary_objects[i]));
																ITK_CALL(AOM_unlock(secondary_objects[i]));
															}
														}

														break;
													}
												}
											}
										}
										else
										{
											DatasetRelFlag = 0;
										}

										if (DatasetRelFlag == 0)
										{
											ITK_CALL(GRM_create_relation(item_tag, item_tag_data_rev, relation_type, NULL, &relation));
											printf("\n\t 1.Generic/Instance..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
											ITK_CALL(AOM_refresh (item_tag,0));
											printf("\n\t ");
											ITK_CALL(AOM_refresh(relation,0));
											result = GRM_save_relation(relation);
											printf("\n\t 1.Generic/Instance..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

											DatasetExistFlag = 1;
										}
									}
								}
								else  ///New create dataset
								{
									DatasetFlag = 0;
								}
							}

							if(DatasetFlag == 0)
							{
								//ItemDesc =(char *) MEM_alloc(50);
								//strcpy(ItemDesc,SubTypeNm);
								//strcat(ItemDesc," ProPrt Document");

								//dataset_NewRevNo = dataset_RevNo +1;

								result = AE_find_datasettype("ProPrt", &datasettype);
								printf("\n\t Type found---->%d",result);fflush(stdout);

								//result = AE_find_dataset(itemId, &Newdataset);
								//if(Newdataset)
								//{
								//	printf("\n\t Dataset Found..."); fflush(stdout);
								//}
								//else
								//{
									printf("\n\t Creating New Dataset..."); fflush(stdout);

									result = AE_create_dataset_with_id(datasettype,itemId,ItemDesc, NULL, NULL, &Newdataset);
									printf("\n\t Dataset created for Generic/Instance --->%s",itemId); fflush(stdout);

									result = AE_set_dataset_format(Newdataset, "BINARY_REF");
									printf("\n\t Dataset format set--->%d",result); fflush(stdout);

									result = AE_set_dataset_tool(Newdataset,tool);
									printf("\n\t Tool set--->%d",result); fflush(stdout);
								//}

								result = AE_ask_dataset_named_refs(Newdataset,&nameRef_cnt, &namRefObject);
								printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

								if(strcmp(SubTypeNm,"Generic")==0)
								{
									if ((nameRef_cnt == 0) && ((strcmp(fullPath,"")!=0) && (strcmp(fullPath,"-")!=0)) )
									{
										result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
										printf("\n\t Got reference list--->%d",result); fflush(stdout);

										result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
										printf("\n\t File Imported--->%d",result); fflush(stdout);

										result = AOM_save(filetag);
										printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

										ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
										result = AOM_save(filetag);
										printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

										result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
										printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

										AE_set_dataset_tool(Newdataset,tool);
										printf("\n\t Tool set--->%d",result); fflush(stdout);
									}
								}

								result = AOM_save(Newdataset);
								printf("\n\t AOM_save--->%d",result); fflush(stdout);

								//result = GRM_find_relation_type("IMAN_specification", &relation_type);
								//printf("\n\t GRM_find_relation_type ---->%d",result); fflush(stdout);

								if(relation_type != NULLTAG)
								{
									printf("\n\t "); fflush(stdout);
									ITK_CALL(TCTYPE_ask_name(relation_type,type_name));
									printf("\n\t Type Name: %s ..............",type_name);fflush(stdout);
								}

								result = GRM_find_relation( item_tag, Newdataset, relation_type ,&Fndrelation);
								printf("\n\t Fndrelation ---->%d \n\t",result); fflush(stdout);

								if(Fndrelation != NULLTAG)
								{
									DatasetRelFlag = 0;

									if(GRM_list_secondary_objects_only(item_tag , NULLTAG ,&n_attchs,&secondary_objects));
									printf("  2.Generic/Instance..item_tag secondary_objects list n_attchs: [%d] \n\t",n_attchs); fflush(stdout);

									if(n_attchs>0)
									{
										for (i=0; i < n_attchs; i++)
										{
											if(TCTYPE_ask_object_type(secondary_objects[i],&secObjTypeTag));
											if(TCTYPE_ask_name(secObjTypeTag,type_name2));
											printf("    2.Generic/Instance..Part type_name is  :%s \n\t",type_name2); fflush(stdout);

											if (strcmp(type_name2,"ProPrt")==0)
											{
												printf("  2.Generic/Instance..Dataset is already attached to Revision \n\t"); fflush(stdout);

												printf("\n\t 2.Generic/Instance..Relation Already Exist.\n\t" );fflush(stdout);
												DatasetRelFlag = 1;
												DatasetExistFlag = 1;

												if (strcmp(SubTypeNm,"Instance")==0)
												{
													ITK_CALL(AOM_ask_value_string(secondary_objects[i],"object_desc",&DatasetDesc));
													printf("     2.Generic/Instance..DatasetDesc--object_desc:: [%s]\n\t",DatasetDesc); fflush(stdout);
													if (strcmp(ItemDesc,DatasetDesc) != 0)
													{
														printf("     2.Generic/Instance..Setting Descrption on DatasetDesc...\n\t"); fflush(stdout);

														setAttributesOnItemRev(&secondary_objects[i],ItemDesc);
														ITK_CALL(AOM_save(secondary_objects[i]));
														ITK_CALL(AOM_unlock(secondary_objects[i]));
													}
												}

												break;
											}
										}
									}
								}
								else
								{
									DatasetRelFlag = 0;
								}

								if (DatasetRelFlag == 0)
								{
									ITK_CALL(GRM_create_relation(item_tag, Newdataset, relation_type, NULL, &relation));
									printf("\n\t 2.Generic/Instance..GRM_create_relation ---->%d\n\t",result); fflush(stdout);
									ITK_CALL(AOM_refresh (item_tag,0));
									printf("\n\t ");
									ITK_CALL(AOM_refresh(relation,0));
									result = GRM_save_relation(relation);
									printf("\n\t 2.Generic/Instance..GRM_save_relation ---->%d\n\n",result); fflush(stdout);

									DatasetExistFlag = 1;
								}
							}
						}
					} //end of else condn of generic/instance


					if (ApplnOwnerFlag == 1)
					{
						printf("\n\t"); fflush(stdout);
						ITK_CALL(AOM_ask_value_string(item_tag,"t5_ApplicationOwner",&RevApplnOwner));

						if( (tc_strcmp(RevApplnOwner,ApplnOwnerStr) != 0) || (tc_strcmp(RevApplnOwner,"") == 0) )
						{
							printf("\n\t Setting ApplicationOwner as '%s' instead of old '%s' for Part %s, %s , %s\n\n\t",ApplnOwnerStr,RevApplnOwner,itemId,itemRevSeq,JTid1); fflush(stdout);

							ITK_CALL(AOM_lock(item_tag));
							printf("\n\t "); fflush(stdout);
							ITK_CALL(AOM_set_value_string(item_tag,"t5_ApplicationOwner",ApplnOwnerStr));
							printf("\n\t "); fflush(stdout);
							ITK_CALL(AOM_save(item_tag));
							printf("\n\t "); fflush(stdout);
							ITK_CALL(AOM_unlock(item_tag));
						}
						//else
						//{
						//	printf("\n\t ApplicationOwner is already set as %s \n\n",RevApplnOwner); fflush(stdout);
						//}
					}

					if (DatasetExistFlag == 1)
					{
						//printf("    DatasetExistFlag exit Flag\n"); fflush(stdout);
						break;
					}

				} //end of for loop
			} // end of DesignRevision Sequence query resultant
			else
			{
				printf("Item Revision not Found for [%s :: %s] \n\t",itemId,itemRevSeq); fflush(stdout);
			}
		}  // while end
	}  // fp file end

	if (fp)
		fclose(fp);

	printf("\n ");
	ITK_CALL(POM_logout(false));
	return status;
}
