###################################################################################################
### Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
###
### This software is the confidential and proprietary information of TTL.
### You shall not disclose such confidential information and shall use it
### only in accordance with the terms of the license agreement.
###
###  File		 :   fetchMetaData_BomJtCad.sh
###  Author		 :   Raghavendra B T
###  Module		 :   TCUA Downloader
###  
###                             
###
### Modification History :
### S.No    Date			CR No     Modified By            Modification Notes
####################################################################################################



mkdir $1_$2_$3
cd $1_$2_$3

../TmetcGetPartList Loader 123loader $1 $1.TCPartList.txt

while read jline
do

   # LevelNum =`echo $jline | cut -d\^ -f1`
	PartNumber=`echo $jline | cut -d\^ -f2`
	Revision=`echo $jline | cut -d\^ -f3`
	Sequence=`echo $jline | cut -d\^ -f4`

	#echo "\n LevelNum is ---> $LevelNum"
	echo "\n Part Number is ---> $PartNumber"
	echo "\n Part Revision is ---> $Revision"
	echo "\n Part Sequence is ---> $Sequence"

../TmetcExpandAssyWthCxt Loader 123loader $PartNumber $Revision $Sequence "Latest From WIP And Release Vaults" $1.txt $1_LHRH.txt

done < "$1.TCPartList.txt"

sort -u $1.txt > $1.ChildFullList.txt

while read kline
do

    levelone=`echo $kline | cut -d\^ -f1`
	PartNumberone=`echo $kline | cut -d\^ -f2`	

	echo "\n levelone is ---> $levelone"
	echo "\n PartNumberone is ---> $PartNumberone"

	if [ $levelone = 0 ]
		then
				echo "i am not considering this part --->$PartNumberone"
		else
				
				echo "i am considering this part--->$PartNumberone"
				../TmetcGetPartList Loader 123loader $PartNumberone $1.TCPartList_Child.txt
		fi

	

done < "$1.ChildFullList.txt"

echo "\n Going for JT \n"

cp $1.txt $1_temp.txt
#grep -i COMP_TYPE_UA $1.txt > $1_sorted.txt
cat $1.txt > $1_sorted.txt

split -l100 $1_sorted.txt $1.split.
splitfiles=`ls $1.split.*`

for i in $splitfiles
do
	echo "\n Going in Parent JT Loop \n"
	../TmetcBomLevelJTList Loader 123loader "$i" $1_JTListParent.txt $1_JT_Physical_Par.txt $1_RefJTListParent.txt $1_RefJT_Physical_Par.txt
done



for j in $1.TCPartList_Child.txt
do
	echo "\n Going in Child JT Loop \n"
	../TmetcBomLevelJTList Loader 123loader "$j" $1_JTListChild.txt $1_JT_Physical_Chd.txt $1_RefJTListChild.txt $1_RefJT_Physical_Chd.txt
done


split -l100 $1.txt $1.catia.split.
splitfiles=`ls $1.catia.split.*`
for i in $splitfiles
do
	echo "\n Going for Parent CAD \n"
	../TmetcBomLevelCatiaList Loader 123loader "$i" $1_CatiaListPar.txt $1_CAD_Physical_Par.txt $1_RefCatiaListPar.txt $1_RefCAD_Physical_Par.txt
done

for k in $1.TCPartList_Child.txt
do
	echo "\n Going for Child CAD \n"
	../TmetcBomLevelCatiaList Loader 123loader "$k" $1_CatiaListChd.txt $1_CAD_Physical_Chd.txt $1_RefCatiaListChd.txt $1_RefCAD_Physical_Chd.txt
done

sleep 10

echo "\n PWD Command \n"
pwd
cat  $1_JTListParent.txt $1_JTListChild.txt > $1.JTList.txt
cat $1_JT_Physical_Par.txt $1_JT_Physical_Chd.txt $1_RefJT_Physical_Par.txt $1_RefJT_Physical_Chd.txt > $1_JT_Physical.txt

echo "\n PWD Command 111 \n"

cat $1_CatiaListPar.txt $1_CatiaListChd.txt > $1.CatiaList.txt
cat $1_CAD_Physical_Par.txt $1_CAD_Physical_Chd.txt $1_RefCAD_Physical_Par.txt $1_RefCAD_Physical_Chd.txt > $1_CAD_Physical.txt

echo "\n PWD Command 222 \n"

cat $1_RefJTListParent.txt $1_RefJTListChild.txt > $1.RefJTList.txt
cat $1_RefCatiaListPar.txt $1_RefCatiaListChd.txt > $1.RefCatiaList.txt

echo "\n PWD Command 333 \n"

sort  $1.CatiaList.txt | uniq > $1_UniCAD.txt
sort  $1.RefJTList.txt | uniq > $1_RefUniJT.txt
sort  $1.RefCatiaList.txt | uniq > $1_RefUniCAD.txt
sort  $1.JTList.txt | uniq > $1_UniJT.txt

echo "\n PWD Command 444 \n"

