/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   AttachSpecFiles.c
*  Author		 :   Aniket P. Kadu
*  Module		 :   TCUA Uploader
*                             
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>


#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


extern int ITK_user_main (int argc, char ** argv )
{
	int status;
	FILE* fp=NULL;
	FILE* fperror=NULL;
	char* inputline=NULL;
	char* inputfile=NULL;
	char* level=NULL;
    tag_t *tags_found = NULL;
    int n_tags_found= 0;
	tag_t   window = null_tag , window2, rule, item_tag = null_tag, top_line;
	tag_t rev=NULLTAG;
	char* item_id=NULLTAG;
	char* item_revision_id=NULLTAG;
	char* item_sequence_id=NULLTAG;
	tag_t item=NULLTAG;
	tag_t newline=NULLTAG;

	inputfile = ITK_ask_cli_argument("-i=");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

    char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
    char **values = (char **) MEM_alloc(1 * sizeof(char *));



	fp=fopen(inputfile,"r");
	fperror=fopen("error.log","a");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(500);
		while(fgets(inputline,500,fp)!=NULL)
		{
			fputs(inputline,stdout);
			
			level=strtok(inputline,"^");
			item_id=strtok(NULL,"^");
			item_revision_id=strtok(NULL,"^");
			item_sequence_id=strtok(NULL,"^");
			
			if(strcmp(level,"0")==0)
			{
			    attrs[0] ="item_id";
			    values[0] = item_id;

				if(window!=null_tag){
					printf("\n Saving window , Do this only once its a heavy function");
					BOM_save_window(window);
				}
				
		        attrs[0] ="item_id";
			    values[0] = item_id;
				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));				

				if (n_tags_found == 1)
				{
					
					item_tag = tags_found[0];		
					MEM_free(tags_found);
					ITK_CALL(BOM_create_window (&window));		
					ITK_CALL(CFM_find( "Latest Working", &rule ));		
					ITK_CALL(BOM_set_window_config_rule( window, rule ));		
					ITK_CALL(BOM_set_window_pack_all (window, true));
					ITK_CALL(BOM_set_window_top_line (window, item_tag, null_tag, null_tag, &top_line));



				}
				else if (n_tags_found > 1)
				{
					MEM_free(tags_found);
					EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
					printf ( "More than one items matched with id \n");
					fprintf(fperror,"Problem with part number:[%s]",item_id);

				}
			}else
			{
				
			        attrs[0] ="item_id";
				    values[0] = item_id;
					ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
					if (n_tags_found == 1)
					{
						item=tags_found[0];
						ITK_CALL(ITEM_find_revision(item,item_revision_id,&rev));
						ITK_CALL(BOM_line_add (top_line, NULLTAG,rev,NULLTAG, &newline));
					}else
					{
						printf ( "More than one items matched with id %s\n", item_id);
						fprintf(fperror,"Problem with part number:[%s]",item_id);
					}

			}

		}
	}
	
	if(fperror)fclose(fperror);fperror=NULL;
	return status;
}
