/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File				:   GetPartList.c
*  Author			:   Raghavendra B T
*  Module			:   TCUA Downloader.
*  Purpose			:   To get TC Part List
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <ReadFile.h>
#include <tel.h>
#include <Mtimsgh.h>
#define NUMBER 5000

char* t5ChngDateFormat(char *,char *,char *);

status GetTCPartInfo(ObjectPtr TCPartObjP,FILE* fp,integer* mfail )
{

	SetOfObjects  partMasterSO = NULL ;
	SetOfObjects  partMasterRelSO = NULL ;
	SqlPtr  MasterObjOP = NULL;
	string t5CMVRCertificationS =	NULL;
	string t5CMVRCertificationDupS =	NULL;
	string t5ClassificationHazDupS =	NULL;
	string PartTypeDupS=NULL;
				string PartTypeS=NULL;
	string t5ClassificationHazS =	NULL;
	string t5ColourIDS =	NULL;
	string t5ColourIDDupS =	NULL;
	string t5ConfigIDS =	NULL;
	string t5ConfigIDDupS =	NULL;
	string  DescriptionDupS=NULL;
	string  DescriptionS=NULL;
	string t5DismantableS =	NULL;
	string t5DismantableDupS =	NULL;
	string t5DsgnDeptS =	NULL;
	string t5DsgnDeptDupS =	NULL;
	string t5EnvelopeDimenS =	NULL;
	string t5EnvelopeDimenDupS =	NULL;
	string t5HazardousContS =	NULL;
	string t5HazardousContDupS =	NULL;
	string t5HomologationReqdS =	NULL;
	string t5HomologationReqdDupS =	NULL;
	string t5ListRecSparess =	NULL;
	string t5ListRecSparesDups =	NULL;
	string t5NcPartNoS =	NULL;
	string t5PartCodeS =	NULL;
	string t5NcPartNoDupS =	NULL;
	string t5PartCodeDupS =	NULL;
	string t5PartPropertyS =	NULL;
	string t5PartPropertyDupS =	NULL;
	string t5PartStatusS =	NULL;
	string t5PartStatusDupS =	NULL;
	string t5PkgStdS =	NULL;
	string t5PkgStdDupS =	NULL;
	string t5ProductS =	NULL;
	string t5ProductDupS =	NULL;
	string t5PrtCatCodeS =	NULL;
	string t5PrtCatCodeDupS =	NULL;
	string t5PunIntialAgS =	NULL;
	string t5PunIntialAgDupS =	NULL;
	string t5PunMakeBuyIndS =	NULL;
	string t5PunMakeBuyIndDupS =	NULL;
	string t5RecoverableS =	NULL;
	string t5RecoverableDupS =	NULL;
	string t5RecyclabilityS =	NULL;
	string t5RecyclabilityDupS =	NULL;
	string t5RefPartNumberS =	NULL;
	string t5RefPartNumberDupS =	NULL;
	string t5ReliabilityS =	NULL;
	string t5ReliabilityDupS =	NULL;
	string t5SpareCriteriaS =	NULL;
	string t5SpareCriteriaDupS =	NULL;
	string t5SpareIndS =	NULL;
	string t5SpareIndDupS =	NULL;
	string t5SurfPrtStdS =	NULL;
	string t5SurfPrtStdDupS =	NULL;
	string t5SamplesToApprS =	NULL;
	string t5SamplesToApprDupS =	NULL;
	string t5AsmDisposalS =	NULL;
	string t5AsmDisposalDupS =	NULL;
	string t5FinDisposalInstrS =	NULL;
	string t5FinDisposalInstrDupS =	NULL;
	string t5RPDisposalInstrS =	NULL;
	string t5RPDisposalInstrDupS =	NULL;
	string t5SPDisposalInstrS =	NULL;
	string t5SPDisposalInstrDupS =	NULL;
	string t5WIPDisposalInstrS =	NULL;
	string t5WIPDisposalInstrDupS =	NULL;
	string t5LastModByS =	NULL;
	string t5LastModByDupS =	NULL;
	string t5VerCreatorS =	NULL;
	string t5VerCreatorDupS =	NULL;
	string t5CAEDocES =	NULL;
	string t5CAEDocEDupS =	NULL;
	string t5CoatedS =	NULL;
	string t5CoatedDupS =	NULL;
	string t5ConvDocS =	NULL;
	string t5ConvDocDupS =	NULL;
	string t5AplCopyOfErcRevS =	NULL;
	string t5AplCopyOfErcRevDupS =	NULL;
	string t5AplCopyOfErcSeqS =	NULL;
	string t5AplCopyOfErcSeqDupS =	NULL;
	string t5AppCodeS =	NULL;
	string t5AppCodeDupS =	NULL;
	string t5RqstNumS =	NULL;
	string t5RqstNumDupS =	NULL;
	string t5RsnCodeS =	NULL;
	string t5RsnCodeDupS =	NULL;
	string t5SurfaceAreaS =	NULL;
	string t5SurfaceAreaDupS =	NULL;
	string t5VolumeS =	NULL;
	string t5VolumeDupS =	NULL;
	string t5CarIntialAgencyS =	NULL;
	string t5CarIntialAgencyDupS =	NULL;
	string t5CarMakeBuyIndiS =	NULL;
	string t5CarMakeBuyIndiDupS =	NULL;
	string t5ErcIndNameS =	NULL;
	string t5ErcIndNameDupS =	NULL;
	string t5PostRelReqS =	NULL;
	string t5PostRelReqDupS =	NULL;
	string t5ItmCategoryS =	NULL;
	string t5ItmCategoryDupS =	NULL;
	string t5CopReqS =	NULL;
	string t5CopReqDupS =	NULL;
	string t5AplInvalidateS =	NULL;
	string t5AplInvalidateDupS =	NULL;
	string t5PrtValiStatusS =	NULL;
	string t5PrtValiStatusDupS =	NULL;
	string t5DRSubStateS =	NULL;
	string t5DRSubStateDupS =	NULL;
	string t5KnxtDocIndS =	NULL;
	string t5KnxtDocIndDupS =	NULL;
	string t5SimValS =	NULL;
	string t5SimValDupS =	NULL;
	string t5PerYieldS =	NULL;
	string t5PerYieldDupS =	NULL;
	string t5PunStoreLocationS =	NULL;
	string t5PunStoreLocationDupS =	NULL;
	string t5AltPartNoS =	NULL;
	string t5AltPartNoDupS =	NULL;
	string t5RolledupWtS =	NULL;
	string t5RolledupWtDupS =	NULL;
	string t5EstSheetReqdS =	NULL;
	string t5EstSheetReqdDupS =	NULL;
	string t5PFDModReqdS =	NULL;
	string t5PFDModReqdDupS =	NULL;
	string t5ToolIndentReqdS =	NULL;
	string t5ToolIndentReqdDupS =	NULL;
	string CategoryNameDupS =	NULL;
	string CategoryNameS =	NULL;
	string ModDescriptionDupS=NULL;
	string ModDescriptionS=NULL;
	string DrawingNoDupS=NULL;
	string DrawingNoS=NULL;
	string DrawingIndDupS=NULL;
	string DrawingIndS=NULL;
	string MaterialDupS=NULL;
	string MaterialS=NULL;
	string MaterialInDrwDupS=NULL;
	string MaterialInDrwS=NULL;
	string LeftRhDupS=NULL;
	string LeftRhS=NULL;
	string DeignOwnUnitDupS=NULL;
	string DeignOwnUnitS=NULL;
	string ModelIndDupS=NULL;
	string ModelIndS=NULL;
	string UnitOfMeasureDupS=NULL;
	string UnitOfMeasureS=NULL;
	string ColourIndDupS=NULL;
	string ColourIndS=NULL;
	string WeightDupS=NULL;
	string WeightS=NULL;
	string MaterialThickNessDupS=NULL;
	string MaterialThickNessS=NULL;
	string ProjectCodeDupS=NULL;
	string ProjectCodeS=NULL;
	string DesignGroupDupS=NULL;
	string DesignGroupS=NULL;
	string LifeCycleStateDupS=NULL;
	string LifeCycleStateS=NULL;
	string          start_date=NULL;
	string          end_date=NULL;
	string          fromdate=NULL;
	string          todate=NULL;
	string from_date_s=NULL;
	string to_date_s=NULL;

	string  ChildPartNumberDupS=NULL;
	string  ChildPartNumberS=NULL;
	string  ChildPartRevisionDupS=NULL;
	string  ChildPartRevisionS=NULL;
	string  ChildPartSequenceDupS=NULL;
	string  ChildPartSequenceS=NULL;
	string  ChildPartOwnerNameDupS=NULL;
	string  ChildPartOwnerNameS=NULL;
	string  ReveffDateFrom=NULL;
	string  ReveffDateFromDup=NULL;
	string  ReveffDateTo=NULL;
	string  ReveffDateToDup=NULL;

	ObjectPtr		contextObj		= NULL;
	ObjectPtr		genContextObj	= NULL;
	SetOfObjects	soExpObj		= NULL;
	SetOfObjects	relObjSet		= NULL;


	t5MethodInit("GetTCPartInfo");




				t5CheckMfail(ExpandObject2(ItemRevClass,TCPartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&partMasterSO,&partMasterRelSO,mfail)) ;
				MasterObjOP=setGet(partMasterSO,0);

                // For effectivity extract
                t5CheckMfail(IntSetUpContext(objClass(TCPartObjP),TCPartObjP,&genContextObj,mfail));
				/* Get the configuration context object from the general context. */
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &contextObj, mfail));
				/* Set the option as "LkoCtxt" in the context object */
				t5CheckDstat(objSetAttribute(contextObj,CfgItemIdAttr,"GlobalCtxt"));
                t5CheckMfail(SetNavigateViewPref(contextObj,TRUE,"EAS","ERC",mfail));
				t5CheckDstat(objSetObject(genContextObj, ConfigCtxtBlobAttr, contextObj));
				t5CheckMfail(ExpandRelationWithCtxt(RevEffDClass,TCPartObjP,"RvfCfgItemInStrBIApc",genContextObj,SC_SCOPE_OF_SESSION ,NULL, &soExpObj, &relObjSet, mfail));
                 printf("\n  setSize(soExpObj:%d \n",setSize(soExpObj)); fflush(stdout);
				 if(setSize(soExpObj)>0)
				   {
					if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveFromAttr,&ReveffDateFrom)) goto EXIT;
					if(dstat = objGetAttribute(setGet(relObjSet,0),DateEffectiveToAttr,&ReveffDateTo)) goto EXIT;
					if(!nlsIsStrNull(ReveffDateFrom))
						ReveffDateFromDup = nlsStrDup(ReveffDateFrom);
					   else ReveffDateFromDup = nlsStrDup(ReveffDateTo);

					if(!nlsIsStrNull(ReveffDateTo))
						ReveffDateToDup = nlsStrDup(ReveffDateTo);
					    else ReveffDateToDup = nlsStrDup(ReveffDateFrom);
				   } else {
					   ReveffDateFromDup = nlsStrDup("-");
					   ReveffDateToDup = nlsStrDup("-");
			          }

				 printf("\n  ReveffDateFromDup:%s \n",ReveffDateFromDup); fflush(stdout);
				 printf("\n  ReveffDateToDup:%s \n",ReveffDateToDup); fflush(stdout);
				 ////end


				t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&ChildPartNumberDupS));
				ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&ChildPartRevisionDupS));
				ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&ChildPartSequenceDupS));
				ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
				ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&PartTypeDupS));
				PartTypeS=nlsStrDup(PartTypeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,NomenclatureAttr,&DescriptionDupS));
				DescriptionS=nlsStrDup(DescriptionDupS);
				DescriptionS=low_strssra(DescriptionS,"\n"," ");


				t5CheckDstat(objGetAttribute(TCPartObjP,t5DocRemarksAttr,&ModDescriptionDupS));
				ModDescriptionS=nlsStrDup(ModDescriptionDupS);
				ModDescriptionS=low_strssra(DescriptionS,"\n"," ");

				t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingNoAttr,&DrawingNoDupS));
				DrawingNoS=nlsStrDup(DrawingNoDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&DrawingIndDupS));
				DrawingIndS=nlsStrDup(DrawingIndDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,t5MatlClassAttr,&MaterialDupS));
				MaterialS=nlsStrDup(MaterialDupS);

				MaterialS=low_strssra(MaterialS,"\n"," ");

				t5CheckDstat(objGetAttribute(TCPartObjP,t5MaterialAttr,&MaterialInDrwDupS));
				MaterialInDrwS=nlsStrDup(MaterialInDrwDupS);

				MaterialInDrwS=low_strssra(MaterialInDrwS,"\n"," ");

				t5CheckDstat(objGetAttribute(TCPartObjP,t5MThicknessAttr,&MaterialThickNessDupS));
				MaterialThickNessS=nlsStrDup(MaterialThickNessDupS);

				t5CheckDstat(objGetAttribute(MasterObjOP,t5LeftRhAttr,&LeftRhDupS));
				LeftRhS=nlsStrDup(LeftRhDupS);

				t5CheckDstat(objGetAttribute(MasterObjOP,DefaultUnitOfMeasureAttr,&UnitOfMeasureDupS));
				UnitOfMeasureS=nlsStrDup(UnitOfMeasureDupS);


				t5CheckDstat(objGetAttribute(TCPartObjP,t5DsgnOwnAttr,&DeignOwnUnitDupS));
				DeignOwnUnitS=nlsStrDup(DeignOwnUnitDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,t5ModelIndicatorAttr,&ModelIndDupS));
				ModelIndS=nlsStrDup(ModelIndDupS);


				t5CheckDstat(objGetAttribute(TCPartObjP,t5ColourIndAttr,&ColourIndDupS));
				ColourIndS=nlsStrDup(ColourIndDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,t5WeightAttr,&WeightDupS));
				WeightS=nlsStrDup(WeightDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,ProjectNameAttr,&ProjectCodeDupS));
				ProjectCodeS=nlsStrDup(ProjectCodeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,t5DesignGroupAttr,&DesignGroupDupS));
				DesignGroupS=nlsStrDup(DesignGroupDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,LifeCycleStateAttr,&LifeCycleStateDupS));
				LifeCycleStateS=nlsStrDup(LifeCycleStateDupS);

				// Added By Raghavendra B T for more TC Part Attributes

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CMVRCertificationReqd",&t5CMVRCertificationDupS));
				t5CMVRCertificationS=nlsStrDup(t5CMVRCertificationDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ClassificationHazardous",&t5ClassificationHazDupS));
				t5ClassificationHazS=nlsStrDup(t5ClassificationHazDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ColourID",&t5ColourIDDupS));
				t5ColourIDS=nlsStrDup(t5ColourIDDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConfigID",&t5ConfigIDDupS));
				t5ConfigIDS=nlsStrDup(t5ConfigIDDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Dismantable",&t5DismantableDupS));
				t5DismantableS=nlsStrDup(t5DismantableDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5DsgnDept",&t5DsgnDeptDupS));
				t5DsgnDeptS=nlsStrDup(t5DsgnDeptDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5EnvelopeDimensions",&t5EnvelopeDimenDupS));
				t5EnvelopeDimenS=nlsStrDup(t5EnvelopeDimenDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5HazardousContents",&t5HazardousContDupS));
				t5HazardousContS=nlsStrDup(t5HazardousContDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5HomologationReqd",&t5HomologationReqdDupS));
				t5HomologationReqdS=nlsStrDup(t5HomologationReqdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ListRecSpares",&t5ListRecSparesDups));
				t5ListRecSparess=nlsStrDup(t5ListRecSparesDups);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5NcPartNo",&t5NcPartNoDupS));
				t5NcPartNoS=nlsStrDup(t5NcPartNoDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartCode",&t5PartCodeDupS));
				t5PartCodeS=nlsStrDup(t5PartCodeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartProperty",&t5PartPropertyDupS));
				t5PartPropertyS=nlsStrDup(t5PartPropertyDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PartStatus",&t5PartStatusDupS));
				t5PartStatusS=nlsStrDup(t5PartStatusDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PkgStd",&t5PkgStdDupS));
				t5PkgStdS=nlsStrDup(t5PkgStdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Product",&t5ProductDupS));
				t5ProductS=nlsStrDup(t5ProductDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtCatCode",&t5PrtCatCodeDupS));
				t5PrtCatCodeS=nlsStrDup(t5PrtCatCodeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunIntialAgency",&t5PunIntialAgDupS));
				t5PunIntialAgS=nlsStrDup(t5PunIntialAgDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunMakeBuyIndicator",&t5PunMakeBuyIndDupS));
				t5PunMakeBuyIndS=nlsStrDup(t5PunMakeBuyIndDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recoverable",&t5RecoverableDupS));
				t5RecoverableS=nlsStrDup(t5RecoverableDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Recyclability",&t5RecyclabilityDupS));
				t5RecyclabilityS=nlsStrDup(t5RecyclabilityDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RefPartNumber",&t5RefPartNumberDupS));
				t5RefPartNumberS=nlsStrDup(t5RefPartNumberDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Reliability",&t5ReliabilityDupS));
				t5ReliabilityS=nlsStrDup(t5ReliabilityDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareCriteria",&t5SpareCriteriaDupS));
				t5SpareCriteriaS=nlsStrDup(t5SpareCriteriaDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SpareInd",&t5SpareIndDupS));
				t5SpareIndS=nlsStrDup(t5SpareIndDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfPrtStd",&t5SurfPrtStdDupS));
				t5SurfPrtStdS=nlsStrDup(t5SurfPrtStdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SamplesToAppr",&t5SamplesToApprDupS));
				t5SamplesToApprS=nlsStrDup(t5SamplesToApprDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AsmDisposalInstr",&t5AsmDisposalDupS));
				t5AsmDisposalS=nlsStrDup(t5AsmDisposalDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5FinDisposalInstr",&t5FinDisposalInstrDupS));
				t5FinDisposalInstrS=nlsStrDup(t5FinDisposalInstrDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RPDisposalInstr",&t5RPDisposalInstrDupS));
				t5RPDisposalInstrS=nlsStrDup(t5RPDisposalInstrDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SPDisposalInstr",&t5SPDisposalInstrDupS));
				t5SPDisposalInstrS=nlsStrDup(t5SPDisposalInstrDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5WIPDisposalInstr",&t5WIPDisposalInstrDupS));
				t5WIPDisposalInstrS=nlsStrDup(t5WIPDisposalInstrDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5LastModBy",&t5LastModByDupS));
				t5LastModByS=nlsStrDup(t5LastModByDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5VerCreator",&t5VerCreatorDupS));
				t5VerCreatorS=nlsStrDup(t5VerCreatorDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CAEDocE",&t5CAEDocEDupS));
				t5CAEDocES=nlsStrDup(t5CAEDocEDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Coated",&t5CoatedDupS));
				t5CoatedS=nlsStrDup(t5CoatedDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ConvDoc",&t5ConvDocDupS));
				t5ConvDocS=nlsStrDup(t5ConvDocDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcRev",&t5AplCopyOfErcRevDupS));
				t5AplCopyOfErcRevS=nlsStrDup(t5AplCopyOfErcRevDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplCopyOfErcSeq",&t5AplCopyOfErcSeqDupS));
				t5AplCopyOfErcSeqS=nlsStrDup(t5AplCopyOfErcSeqDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AppCode",&t5AppCodeDupS));
				t5AppCodeS=nlsStrDup(t5AppCodeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RqstNum",&t5RqstNumDupS));
				t5RqstNumS=nlsStrDup(t5RqstNumDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RsnCode",&t5RsnCodeDupS));
				t5RsnCodeS=nlsStrDup(t5RsnCodeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SurfaceArea",&t5SurfaceAreaDupS));
				t5SurfaceAreaS=nlsStrDup(t5SurfaceAreaDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5Volume",&t5VolumeDupS));
				t5VolumeS=nlsStrDup(t5VolumeDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarIntialAgency",&t5CarIntialAgencyDupS));
				t5CarIntialAgencyS=nlsStrDup(t5CarIntialAgencyDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CarMakeBuyIndicator",&t5CarMakeBuyIndiDupS));
				t5CarMakeBuyIndiS=nlsStrDup(t5CarMakeBuyIndiDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ErcIndName",&t5ErcIndNameDupS));
				t5ErcIndNameS=nlsStrDup(t5ErcIndNameDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PostRelReq",&t5PostRelReqDupS));
				t5PostRelReqS=nlsStrDup(t5PostRelReqDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ItmCategory",&t5ItmCategoryDupS));
				t5ItmCategoryS=nlsStrDup(t5ItmCategoryDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5CopReq",&t5CopReqDupS));
				t5CopReqS=nlsStrDup(t5CopReqDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AplInvalidate",&t5AplInvalidateDupS));
				t5AplInvalidateS=nlsStrDup(t5AplInvalidateDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PrtValiStatus",&t5PrtValiStatusDupS));
				t5PrtValiStatusS=nlsStrDup(t5PrtValiStatusDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5DRSubState",&t5DRSubStateDupS));
				t5DRSubStateS=nlsStrDup(t5DRSubStateDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5KnxtDocInd",&t5KnxtDocIndDupS));
				t5KnxtDocIndS=nlsStrDup(t5KnxtDocIndDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5SimVal",&t5SimValDupS));
				t5SimValS=nlsStrDup(t5SimValDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PerYield",&t5PerYieldDupS));
				t5PerYieldS=nlsStrDup(t5PerYieldDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PunStoreLocation",&t5PunStoreLocationDupS));
				t5PunStoreLocationS=nlsStrDup(t5PunStoreLocationDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5AltPartNo",&t5AltPartNoDupS));
				t5AltPartNoS=nlsStrDup(t5AltPartNoDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5RolledupWt",&t5RolledupWtDupS));
				t5RolledupWtS=nlsStrDup(t5RolledupWtDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5EstSheetReqd",&t5EstSheetReqdDupS));
				t5EstSheetReqdS=nlsStrDup(t5EstSheetReqdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5PFDModReqd",&t5PFDModReqdDupS));
				t5PFDModReqdS=nlsStrDup(t5PFDModReqdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);

				t5CheckDstat(objGetAttribute(TCPartObjP,"t5ToolIndentReqd",&t5ToolIndentReqdDupS));
				t5ToolIndentReqdS=nlsStrDup(t5ToolIndentReqdDupS);


				t5CheckDstat(objGetAttribute(TCPartObjP,"CategoryName",&CategoryNameDupS));
				CategoryNameS=nlsStrDup(CategoryNameDupS);


				// Ended By Raghavendra B T for more TC Part Attributes

				from_date_s=nlsStrAlloc(20);
				to_date_s=nlsStrAlloc(20);
				if(nlsStrCmp(LifeCycleStateS,"LcsReview")==0)
				{
						printf("\n This is not a released Part.....");
						nlsStrCpy(from_date_s,"NONE");
						nlsStrCpy(to_date_s,"NONE");
				}else if(nlsStrCmp(LifeCycleStateS,"LcsWorking")==0)
				{
						printf("\n This is not a released Part.....");
						nlsStrCpy(from_date_s,"NONE");
						nlsStrCpy(to_date_s,"NONE");
				}

				fprintf(fp,"0");//(level);
					fprintf(fp,"^");
					fprintf(fp,"%s",ChildPartNumberS);
					fprintf(fp,"^");
					fprintf(fp,"%s",ChildPartRevisionS);
					fprintf(fp,"^");
					fprintf(fp,"%s",ChildPartSequenceS);
					//fprintf(fp,"%d",k);
					fprintf(fp,"^");
					fprintf(fp,"%s",DescriptionS);
					fprintf(fp,"^");
					fprintf(fp,"1^ASSY_TYPE_UA^%s^",PartTypeS);//(QuantityS);

					fprintf(fp,"%s",ProjectCodeS);
					fprintf(fp,"^");
					fprintf(fp,"%s",DesignGroupS);
					fprintf(fp,"^");


					if(!nlsIsStrNull(ModDescriptionS))
					{
						fprintf(fp,"%s",ModDescriptionS);
						fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(DrawingNoS))
					{
						fprintf(fp,"%s",DrawingNoS);
						fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(DrawingIndS))
					{
						fprintf(fp,"%s",DrawingIndS);
						fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(MaterialS)){
					fprintf(fp,"%s",MaterialS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(MaterialInDrwS)){
					fprintf(fp,"%s",MaterialInDrwS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(MaterialThickNessS)){
					fprintf(fp,"%s",MaterialThickNessS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(LeftRhS)){
					fprintf(fp,"%s",LeftRhS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(DeignOwnUnitS)){
					fprintf(fp,"%s",DeignOwnUnitS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(ModelIndS)){
					fprintf(fp,"%s",ModelIndS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(UnitOfMeasureS)){
					fprintf(fp,"%s",UnitOfMeasureS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(ColourIndS)){
					fprintf(fp,"%s",ColourIndS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}


					if(!nlsIsStrNull(LifeCycleStateS)){
					fprintf(fp,"%s",LifeCycleStateS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					// commented for TMETC bcoz of denis issue
//					if(!nlsIsStrNull(from_date_s)){
//					fprintf(fp,"%s to %s",from_date_s,to_date_s);
//					fprintf(fp,"^");
//					}else
//					{
//							fprintf(fp," ^");
//					}

					if(!nlsIsStrNull(WeightS)){
					fprintf(fp,"%s",WeightS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}


					// Added By Raghavendra B T for more TC Part Attributes
					if(!nlsIsStrNull(t5CMVRCertificationS)){
					fprintf(fp,"%s",t5CMVRCertificationS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ClassificationHazS)){
					fprintf(fp,"%s",t5ClassificationHazS);
					fprintf(fp,"^");
					}else
					{
							fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ColourIDS)){
					fprintf(fp,"%s",t5ColourIDS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ConfigIDS)){
					fprintf(fp,"%s",t5ConfigIDS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5DismantableS)){
					fprintf(fp,"%s",t5DismantableS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5DsgnDeptS)){
					fprintf(fp,"%s",t5DsgnDeptS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5EnvelopeDimenS)){
					fprintf(fp,"%s",t5EnvelopeDimenS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5HazardousContS)){
					fprintf(fp,"%s",t5HazardousContS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5HomologationReqdS)){
					fprintf(fp,"%s",t5HomologationReqdS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ListRecSparess)){
					fprintf(fp,"%s",t5ListRecSparess);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5NcPartNoS)){
					fprintf(fp,"%s",t5NcPartNoS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PartCodeS)){
					fprintf(fp,"%s",t5PartCodeS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PartPropertyS)){
					fprintf(fp,"%s",t5PartPropertyS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PartStatusS)){
					fprintf(fp,"%s",t5PartStatusS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5PkgStdS)){
					fprintf(fp,"%s",t5PkgStdS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ProductS)){
					fprintf(fp,"%s",t5ProductS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PrtCatCodeS)){
					fprintf(fp,"%s",t5PrtCatCodeS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PunIntialAgS)){
					fprintf(fp,"%s",t5PunIntialAgS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PunMakeBuyIndS)){
					fprintf(fp,"%s",t5PunMakeBuyIndS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RecoverableS)){
					fprintf(fp,"%s",t5RecoverableS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RecyclabilityS)){
					fprintf(fp,"%s",t5RecyclabilityS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RefPartNumberS)){
					fprintf(fp,"%s",t5RefPartNumberS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ReliabilityS)){
					fprintf(fp,"%s",t5ReliabilityS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SpareCriteriaS)){
					fprintf(fp,"%s",t5SpareCriteriaS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SpareIndS)){
					fprintf(fp,"%s",t5SpareIndS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SurfPrtStdS)){
					fprintf(fp,"%s",t5SurfPrtStdS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SamplesToApprS)){
					fprintf(fp,"%s",t5SamplesToApprS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5AsmDisposalS)){
					fprintf(fp,"%s",t5AsmDisposalS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5FinDisposalInstrS)){
					fprintf(fp,"%s",t5FinDisposalInstrS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RPDisposalInstrS)){
					fprintf(fp,"%s",t5RPDisposalInstrS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SPDisposalInstrS)){
					fprintf(fp,"%s",t5SPDisposalInstrS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5WIPDisposalInstrS)){
					fprintf(fp,"%s",t5WIPDisposalInstrS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5LastModByS)){
					fprintf(fp,"%s",t5LastModByS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5VerCreatorS)){
					fprintf(fp,"%s",t5VerCreatorS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5CAEDocES)){
					fprintf(fp,"%s",t5CAEDocES);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5CoatedS)){
					fprintf(fp,"%s",t5CoatedS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5ConvDocS)){
					fprintf(fp,"%s",t5ConvDocS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5AplCopyOfErcRevS)){
					fprintf(fp,"%s",t5AplCopyOfErcRevS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5AplCopyOfErcSeqS)){
					fprintf(fp,"%s",t5AplCopyOfErcSeqS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5AppCodeS)){
					fprintf(fp,"%s",t5AppCodeS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RqstNumS)){
					fprintf(fp,"%s",t5RqstNumS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5RsnCodeS)){
					fprintf(fp,"%s",t5RsnCodeS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5SurfaceAreaS)){
					fprintf(fp,"%s",t5SurfaceAreaS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5VolumeS)){
					fprintf(fp,"%s",t5VolumeS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5CarIntialAgencyS)){
					fprintf(fp,"%s",t5CarIntialAgencyS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5CarMakeBuyIndiS)){
					fprintf(fp,"%s",t5CarMakeBuyIndiS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ErcIndNameS)){
					fprintf(fp,"%s",t5ErcIndNameS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PostRelReqS)){
					fprintf(fp,"%s",t5PostRelReqS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ItmCategoryS)){
					fprintf(fp,"%s",t5ItmCategoryS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5CopReqS)){
					fprintf(fp,"%s",t5CopReqS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5AplInvalidateS)){
					fprintf(fp,"%s",t5AplInvalidateS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PrtValiStatusS)){
					fprintf(fp,"%s",t5PrtValiStatusS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5DRSubStateS)){
					fprintf(fp,"%s",t5DRSubStateS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5KnxtDocIndS)){
					fprintf(fp,"%s",t5KnxtDocIndS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5SimValS)){
					fprintf(fp,"%s",t5SimValS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PerYieldS)){
					fprintf(fp,"%s",t5PerYieldS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5PunStoreLocationS)){
					fprintf(fp,"%s",t5PunStoreLocationS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5AltPartNoS)){
					fprintf(fp,"%s",t5AltPartNoS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5RolledupWtS)){
					fprintf(fp,"%s",t5RolledupWtS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5PFDModReqdS)){
					fprintf(fp,"%s",t5PFDModReqdS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(t5ToolIndentReqdS)){
					fprintf(fp,"%s",t5ToolIndentReqdS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(CategoryNameS)){
					fprintf(fp,"%s",CategoryNameS);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(ReveffDateFromDup)){
					fprintf(fp,"%s",ReveffDateFromDup);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(ReveffDateToDup)){
					fprintf(fp,"%s",ReveffDateToDup);
					fprintf(fp,"^");
					}else
					{
						fprintf(fp," ^");
					}

					fprintf(fp,"\n");


					// Ended By Raghavendra B T for more TC Part Attributes
CLEANUP:

		t5PrintCleanUpModName;

EXIT:
		t5CheckDstatAndReturn;

};


status GetSupersededBy(ObjectPtr TCPartObjP,FILE* OrgFp,integer* mfail )
{

	SetOfObjects  successorSO = NULL ;
	string  ChildPartNumberDupS=NULL;
	string  ChildPartNumberS=NULL;
	string  ChildPartRevisionDupS=NULL;
	string  ChildPartRevisionS=NULL;
	string  ChildPartSequenceDupS=NULL;
	string  ChildPartSequenceS=NULL;
	ObjectPtr		NewObjP			= NULL;


	t5MethodInit("GetSupersededBy");

	ExpandObject5(SuccessrClass,TCPartObjP,"SuccessorOfItem",SC_SCOPE_OF_SESSION,&successorSO,mfail);

	if(setSize(successorSO)>0)
	{
			NewObjP=setGet(successorSO,0);


			t5CheckDstat(objGetAttribute(NewObjP,RevisionAttr,&ChildPartRevisionDupS));
			ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
			printf("\n  Func TC Part Revision:%s \n",ChildPartRevisionS); fflush(stdout);

			t5CheckDstat(objGetAttribute(NewObjP,PartNumberAttr,&ChildPartNumberDupS));
			ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
			printf("\n  Func TC Part Number:%s \n",ChildPartNumberS); fflush(stdout);

			t5CheckDstat(objGetAttribute(NewObjP,SequenceAttr,&ChildPartSequenceDupS));
			ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
			printf("\n Func TC Part Sequence:%s \n",ChildPartSequenceS); fflush(stdout);

			//fprintf(OrgFp,"%s,%s,%s\n",ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS);

			t5CheckMfail(GetTCPartInfo(NewObjP,OrgFp,mfail));

			t5CheckMfail(GetSupersededBy(NewObjP,OrgFp,mfail));

	}


CLEANUP:

		t5PrintCleanUpModName;

EXIT:
		t5CheckDstatAndReturn;

};


int main(int argc, char *argv[])
{
	int stat=0;

	string  ChildPartNumberDupS=NULL;
	string  ChildPartNumberS=NULL;
	string  ChildPartRevisionDupS=NULL;
	string  ChildPartRevisionDupS1=NULL;
	string  ChildPartRevisionS=NULL;
	string  ChildPartRevisionS1=NULL;
	string  ChildPartSequenceDupS=NULL;
	string  ChildPartSequenceS=NULL;
	string  ChildPartOwnerNameDupS=NULL;
	string  ChildPartOwnerNameDupS1=NULL;
	string  ChildPartOwnerNameS=NULL;
	string  ChildPartOwnerNameS1=NULL;
	string  LoginS=NULL;
	string  PasswordS=NULL;
	string  OutFileNameS=NULL;
	string  InpPartNumberS=NULL;
	string  ChildPartRevisionDupS22=NULL;
	string  ChildPartRevisionS22=NULL;
	string  ChildPartNumberDupS22=NULL;
	string  ChildPartNumberS22=NULL;
	string  ChildPartSequenceDupS22=NULL;
	string  ChildPartSequenceS22=NULL;
	string  Dmlclosure=NULL;
	string  DmlclosureDup=NULL;
	string  ToDate_Dup=NULL;
	string  DmlNoDup=NULL;
	string  DmlNo=NULL;

	SetOfObjects  PartResultSO = NULL ;
	SetOfObjects  InstResultSO = NULL ;
	SetOfObjects  PartResultSO11 = NULL ;
	SetOfObjects  Gen_Dmlobj = NULL ;
	SetOfObjects  Gen_DmlSet = NULL ;

	ObjectPtr TCPartObjP=NULL;
	ObjectPtr TCPartSupObjP=NULL;
	ObjectPtr oPrevPartObj1=NULL;
	ObjectPtr TCPartObjP22=NULL;
	SqlPtr  InputTCPartSqlPtr = NULL;
	SqlPtr  InputTCPartSqlPtr11 = NULL;
	SqlPtr  InputInstSqlPtr1 = NULL;

	string		docobjst	=	NULL;
	int		ii		=          0;
	int		orgSequence		=          0;
	int		k		=          0;
	SetOfStrings      dbScp	=          NULL;
	FILE	*fp	= NULL;

	t5MethodInitWMD("GetPartList");

	printf("\n Executing... GetPartList.c ... \n");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	InpPartNumberS=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	InpPartNumberS=argv[3];
	OutFileNameS=argv[4];


	//printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}


	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}

	fp=fopen(OutFileNameS,"a+");
	fflush(fp);

			if((dstat = oiSqlCreateSelect(&InputTCPartSqlPtr))||
		   (dstat = oiSqlWhereBegParen(InputTCPartSqlPtr))||
		   (dstat = oiSqlWhereEQ(InputTCPartSqlPtr,PartNumberAttr,InpPartNumberS))||
		   (dstat = oiSqlWhereEndParen(InputTCPartSqlPtr))||
		   (dstat = oiSqlAscOrder(InputTCPartSqlPtr,CreationDateAttr))) goto EXIT;
			if(dstat = QueryDbObject("Part",InputTCPartSqlPtr,0,TRUE,SC_SCOPE_OF_SESSION,&PartResultSO,mfail)) goto EXIT;


		printf("\n No:of Parts are :- %d\n",setSize(PartResultSO));


				if(setSize(PartResultSO)>0)
		{

				for(k=0;k<setSize(PartResultSO);k++)
				{
					TCPartObjP=setGet(PartResultSO,k);


					t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&ChildPartOwnerNameDupS));
					ChildPartOwnerNameS=nlsStrDup(ChildPartOwnerNameDupS);
					printf("\n  TC Part Owner Name is:%s \n",ChildPartOwnerNameS); fflush(stdout);

					t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&ChildPartRevisionDupS));
					ChildPartRevisionS=nlsStrDup(ChildPartRevisionDupS);
					printf("\n  TC Part Revision:%s \n",ChildPartRevisionS); fflush(stdout);


					if(nlsStrCmp(ChildPartOwnerNameS,"Release Vault")==0)
					{

							t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&ChildPartNumberDupS));
							ChildPartNumberS=nlsStrDup(ChildPartNumberDupS);
							printf("\n  TC Part Number:%s \n",ChildPartNumberS); fflush(stdout);


							t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&ChildPartSequenceDupS));
							ChildPartSequenceS=nlsStrDup(ChildPartSequenceDupS);
							printf("\n TC Part Sequence:%s \n",ChildPartSequenceS); fflush(stdout);

							t5CheckMfail(GetTCPartInfo(TCPartObjP,fp,mfail));

							//fprintf(fp,"%s,%s,%s\n",ChildPartNumberS,ChildPartRevisionS,ChildPartSequenceS);
					}



				}

				// go for latest part
				t5CheckDstat(oiSqlCreateSelect(&InputInstSqlPtr1));
				t5CheckDstat(oiSqlWhereEQ(InputInstSqlPtr1,PartNumberAttr,InpPartNumberS));
				t5CheckDstat(oiSqlWhereAND(InputInstSqlPtr1));
				t5CheckDstat(oiSqlWhereEQ(InputInstSqlPtr1,SupersededAttr,"-"));
				t5CheckMfail(QueryWhere("Part",InputInstSqlPtr1,&InstResultSO,mfail));

				if(setSize(InstResultSO)>0)
				{

					TCPartSupObjP=setGet(InstResultSO,0);

					t5CheckDstat(objGetAttribute(TCPartSupObjP,OwnerNameAttr,&ChildPartOwnerNameDupS1));
					ChildPartOwnerNameS1=nlsStrDup(ChildPartOwnerNameDupS1);
					printf("\n  TC Part Sup Owner Name is:%s \n",ChildPartOwnerNameS1); fflush(stdout);

					t5CheckDstat(objGetAttribute(TCPartSupObjP,RevisionAttr,&ChildPartRevisionDupS1));
					ChildPartRevisionS1=nlsStrDup(ChildPartRevisionDupS1);
					printf("\n  TC Part Sup Revision:%s \n",ChildPartRevisionS1); fflush(stdout);

					if(dstat=ExpandObject5(CmRsltsClass,TCPartSupObjP,"BusItemIsResultOfCMPrdPln",SC_SCOPE_OF_SESSION ,&Gen_Dmlobj,mfail)) goto CLEANUP;

						if(setSize(Gen_Dmlobj)>0)
						{
							if(dstat = ExpandObject5("CmPlRvRv",setGet(Gen_Dmlobj,0),"CMPlanRollsUpInTo",SC_SCOPE_OF_SESSION,&Gen_DmlSet,mfail)) goto EXIT;
							if(dstat= objGetAttribute(setGet(Gen_DmlSet,0),WbsIDAttr,&DmlNo)) goto  EXIT ;
							if(dstat= objGetAttribute(setGet(Gen_DmlSet,0),ClosureTimeStampAttr,&Dmlclosure)) goto  EXIT ;
							if(DmlNo) DmlNoDup=nlsStrDup(DmlNo);
							if(Dmlclosure) DmlclosureDup=nlsStrDup(Dmlclosure);


							if(!nlsIsStrNull(ToDate_Dup)) nlsStrFree(ToDate_Dup);
							ToDate_Dup = nlsStrAlloc(25);
						//	ToDate_Dup = nlsStrDup(t5ChngDateFormat(DmlclosureDup,"yyyy/mm/dd","dd/mmm/yyyy"));
							ToDate_Dup = ChangeDateFormat(DmlclosureDup, "YYYY/MM/DD", "DD-MON-YYYY", "/", "-");

							printf("\n...Dml : %s Dml Closure Date :: %s...New ::: %s",DmlNoDup,DmlclosureDup,ToDate_Dup);fflush(stdout);
						}



					if(nlsStrCmp(ChildPartOwnerNameS1,"Release Vault")!=0 && nlsStrCmp(ChildPartRevisionS1,"NR")!=0)
					{
						t5CheckMfail(GetPrevOfficialRev(TCPartSupObjP,&oPrevPartObj1,mfail)) ;

						t5CheckMfail(GetSupersededBy(oPrevPartObj1,fp,mfail));
						printf("\n.. inside loop");fflush(stdout);
					}

					if(nlsStrCmp(ChildPartOwnerNameS1,"Release Vault")!=0 && nlsStrCmp(ChildPartRevisionS1,"NR")==0)
					{
						if((dstat = oiSqlCreateSelect(&InputTCPartSqlPtr11))||
					   (dstat = oiSqlWhereBegParen(InputTCPartSqlPtr11))||
					   (dstat = oiSqlWhereEQ(InputTCPartSqlPtr11,PartNumberAttr,InpPartNumberS))||
					   (dstat = oiSqlWhereEndParen(InputTCPartSqlPtr11))||
					   (dstat = oiSqlAscOrder(InputTCPartSqlPtr11,CreationDateAttr))) goto EXIT;
						if(dstat = QueryDbObject("Part",InputTCPartSqlPtr11,0,TRUE,SC_SCOPE_OF_SESSION,&PartResultSO11,mfail)) goto EXIT;


						printf("\n No:of Parts are in NR are :- %d\n",setSize(PartResultSO11));

						for(k=0;k<setSize(PartResultSO11);k++)
						{
									TCPartObjP22=setGet(PartResultSO11,k);

									t5CheckDstat(objGetAttribute(TCPartObjP22,RevisionAttr,&ChildPartRevisionDupS22));
									ChildPartRevisionS22=nlsStrDup(ChildPartRevisionDupS22);
									printf("\n  TC Part Revision:%s \n",ChildPartRevisionS22); fflush(stdout);

									t5CheckDstat(objGetAttribute(TCPartObjP22,PartNumberAttr,&ChildPartNumberDupS22));
									ChildPartNumberS22=nlsStrDup(ChildPartNumberDupS22);
									printf("\n  TC Part Number:%s \n",ChildPartNumberS22); fflush(stdout);


									t5CheckDstat(objGetAttribute(TCPartObjP22,SequenceAttr,&ChildPartSequenceDupS22));
									ChildPartSequenceS22=nlsStrDup(ChildPartSequenceDupS22);
									printf("\n TC Part Sequence:%s \n",ChildPartSequenceS22); fflush(stdout);


									t5CheckMfail(GetTCPartInfo(TCPartObjP22,fp,mfail));

									//fprintf(fp,"%s,%s,%s\n",ChildPartNumberS22,ChildPartRevisionS22,ChildPartSequenceS22);
						}
					}
				}
		}

	fclose(fp);


CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);
		t5FreeSqlPtr(InputTCPartSqlPtr);


EXIT:
		t5CheckDstatAndReturn;
}
;

