var_path=`pwd`
echo $var_path
var_path2=`basename $var_path`
echo "var_path2: $var_path2"
if [ $var_path2 == "$1" ]
then
	echo "1..catFile.sh..var_path:::::::::: $var_path"
else
	cd "$1"
	var_path=`pwd`
	echo "2..catFile.sh..var_path:::::::::: $var_path"
fi
filename="to_load"
partfile=${filename}_parts.txt
partfileNew=${filename}_parts_new.txt
fullpath=`pwd`
while read lineFld
do
echo "2.******************Input: " $lineFld
directory=`echo $lineFld |awk -F',' '{print $5}'`
PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
DirPartNm=`echo $PartDirName | cut -d"_" -f1`
DirPartRev=`echo $PartDirName | cut -d"_" -f2`
DirPartSeq=`echo $PartDirName | cut -d"_" -f3`
if [ ! -d "$directory" ]; then
echo "$directory  not exist hence skipping."
continue
fi
cd "$directory"
echo "2.Working FolderName: $directory"
creoCnt=`cat allparts_"$directory".txt | wc -l`
if [ $creoCnt -gt 1 ]
then
echo ".................................... Generating File  to_load_parts.txt .........................."
echo "#DELIMITER ^" > $partfile
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile
while read line
do
	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	####qty=`echo $line |awk -F'^' '{print $6}'`
	unitofmes=`echo $line |awk -F'^' '{print $18}'`
	if [[ "$item" =~ "/" ]]
	then
		echo "Changing string for item:  $item"
		item=`basename $item`
	fi
	if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
		if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
			rev=$DirPartRev
			seq=$DirPartSeq
		fi
	fi
	parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
	parentChild="$parentAtr,$item"
	echo $parentChild
	qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	echo "qty:" $qty
	if [[ -z "$qty" ]]
	then
		qty=1
	fi
	cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
	if [[ $cntq > 1 ]]
	then
		echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
		#qty=9999
		qty=1
	else
		qty=`basename $qty`
	fi
	name=$item
	#unitofmes="-"
	quantity="1"
	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile
done < allparts_"$directory".txt
fi
if test -s  AssyBomSuperSet.txt
then
bomCnt=`cat AssyBomSuperSet.txt | wc -l`
if [ $bomCnt -gt 1 ]
then
echo ".................................... Generating File  to_load_parts_new.txt .........................."
echo "#DELIMITER ^" > $partfileNew
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty Suppressed" >> $partfileNew
while read line
do
	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	unitofmes=`echo $line |awk -F'^' '{print $8}'`
	cadQty=`echo $line |awk -F'^' '{print $9}'`
	suppressTmp=`echo $line |awk -F'^' '{print $10}'`
	suppress=`echo $suppressTmp |awk -F' ,' '{print $1}'`
	ImmParent=`echo $line |awk -F'^' '{print $11}'`
	if [[ "$item" =~ "/" ]]
	then
		echo "Changing string for item:  $item"
		item=`basename $item`
	fi
	if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
		if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
			rev=$DirPartRev
			seq=$DirPartSeq
		fi
	fi
	parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
	###parentChild="$parentAtr,$item"
	parentChild="$ImmParent,$item"
	echo $parentChild
	if test -s quantity.txt
	then
	qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	else
	qty=0
	fi
	echo "Before..qty:" $qty
	#if [[ $cadQty -gt 0 ]] || [[ $cadQty -gt $qty ]]
	if [[ $cadQty -gt  $qty ]]
	then
		qty=$cadQty
		echo "..qty:" $qty
	fi
	if [[ -z "$qty" ]]
	then
		qty=1
	fi
	cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
	if [[ $cntq -gt 1 ]]
	then
		echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
		#qty=9999
		qty=1
	else
		qty=`basename $qty`
	fi
	name=$item
	#unitofmes="-"
	quantity="1"
	if [[ "$cadQty" -eq 0 ]]
	then
		###Comment this condn for Multi-Qty Non-Bom parts Date- 24.06.2017 544231600137_B_3
		#qty=$cadQty
		###UnComment this condn for Multi-Qty Non-Bom parts Date- 24.06.2017 544231600137_B_3
		quantity="0"
	fi
	echo "After..qty:" $qty
	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$suppress^$ImmParent^" >>  $partfileNew
done < AssyBomSuperSet.txt
if test -s quantity.txt
then
	echo "....Creating File for null qty to 9999..."
	grep -F '^9999^' to_load_parts_new.txt > nullQtyParts.txt
	while read kline
	do
		prtnm=`echo $kline |awk -F'^' '{print $2}'`
		grep -w $prtnm quantity.txt >> quantityNullParts.txt
	done < nullQtyParts.txt
fi
fi
fi
#Creating DataSets For ProE_rrr Items
echo "....Creating DataSets For ProE_rrr Items..."
if test -s input.txt
then
rm -rf input.txt
fi
if test -s "$directory".proe
then
while read jline
do
	jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
	classNm=`echo $jline | cut -d\, -f11`
	fInstname=`echo $jline | cut -d\, -f1`
	fname=`echo $jline | cut -d\, -f2`
	#fname=`basename $fname`
	echo "fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  echo "Found / in string"
	  fname=`basename $fname`
	else
	  echo "Couldnt find it"
	fi
	echo "jtname: $fname"
	prtName=`echo $fname | cut -d"." -f1`
	echo "..prtName: $prtName"
	echo "fInstname: $fInstname"
	echo $fInstname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  echo "Found / in string"
	  fInstname=`basename $fInstname`
	else
	  echo "Couldnt find it"
	fi
	echo $fInstname | grep '<' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
		prtInstName=`echo $fInstname | cut -d"<" -f1`
		prtGenName2=`echo $fInstname | cut -d"<" -f2`
		prtGenName=`echo $prtGenName2 | cut -d">" -f1`
		echo "prtInstName: $prtInstName"
		echo "prtGenName: $prtGenName"
		#add here check for $prtGenName numeric/Alphanumeric for 12digitInstance<12digitGeneric>
		#if
		#else
		f_prt=`grep -iw $prtInstName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtInstName`
		echo "f_prt: $f_prt"
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^"
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^" >>  input.txt
			###echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			###echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
			#echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			#echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
			echo "$prtGenName^NR^1^$fname^$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			echo "$prtGenName^NR^1^$fname^$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
		fi
	else
		f_prt=`grep -iw $prtName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtName`
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			#echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^-^Proe Des.Doc^" >>  input.txt
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fname^1^$classNm^-^-^Proe Des.Doc^" >>  input.txt
		fi
	fi
done < "$directory".proe
fi
#Below while loop is added for Drawing and PDF-JT Dataset
if [[ -f "$directory".out.jt  &&  -s "$directory".out.jt ]]; then
while read jline
do
	classNm=`echo $jline | cut -d\, -f5`
	f_DataItem=`echo $jline | cut -d\, -f8`
	f_partNo=`echo $jline | cut -d\, -f7`
	f_partRevSeq=`echo $jline | cut -d\, -f6`
	f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
	f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
	fname=`echo $jline | cut -d\, -f2`
	fname=`basename $fname`
	#echo "out.jt..fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	# below fnameSuffix is added on 10.11.2016 and ALF-JT copy logic is added
	fnameSuffix=`echo $fname | cut -d\. -f2`
	if [ "$fnameSuffix" == "jt" ];then
		fnameJt=`echo $fname | cut -d\. -f1`
		#echo "fnameSuffix: $fnameSuffix"
		if [[ "$fnameJt" =~ "_ALF" ]]
		then
			echo "ALF is present found in string"
			f_partNo=`echo $jline | cut -d\, -f9`
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
			##echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			###echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
		elif [[ "$fnameJt" =~ "_WELD" ]]
		then
			echo "WELD is present found in string"
			f_partNo=`echo $jline | cut -d\, -f9`
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
			##echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			###echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
		elif [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile" -o "$classNm" == "ProPrt" -o "$classNm" == "ProAsm" -o "$classNm" == "ProAsmI" -o "$classNm" == "ProPrtI" ];then
			#echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^" >>  input.txt
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fname^1^$classNm^-^$f_DataItem^-^" >>  input.txt
		fi
	fi
done < "$directory".out.jt
sort -u input.txt > input.txt1
mv input.txt1 input.txt
fi
echo "**Going to download hidden data............................................"
grep -i "TRUE" *.pos | cut -d":" -f2 > suppressedTruePartListTemp.txt
while read pline
do
	ParentAssy=`echo $pline | cut -d\, -f1`
	SupPart=`echo $pline | cut -d\, -f2`
	SupAttrVal=`echo $pline | cut -d\, -f20`
	echo "1^$SupPart^ ^ ^ ^1^$SupPart^4^1^TRUE^$ParentAssy^" >>  suppressedTruePartList.txt
done < suppressedTruePartListTemp.txt
grep "TRUE" to_load_parts_new.txt >> suppressedTruePartList.txt
if test -s suppressedTruePartList.txt
then
sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
mv suppressedTruePartList.txt1 suppressedTruePartList.txt
fi
cd ..
done < $1.PartList.txt
#if [[ -f "$1.SubAssyPartList.txt"  &&  -s "$directory".out.jt ]]; then
if [[ -f "$1.SubAssyPartList.txt"  &&  -s "$1.SubAssyPartList.txt" ]]; then
echo "*******************************Downloading for subdirectories Data ********************************************"
ls -ltr "$1.SubAssyPartList.txt"
while read SubAssyPart
do
	if [[ "$SubAssyPart" =~ "/" ]]
	then
		continue
	fi
	if [ ! -d "$SubAssyPart" ]; then
		echo "$SubAssyPart  not exist hence skipping."
		continue
	fi
	echo "*******TmlGetSubAssyProeData...Input: " $SubAssyPart
	cd "$SubAssyPart"
	while read lineFld
	do
		echo "2.******************Input: " $lineFld
		directory=`echo $lineFld |awk -F',' '{print $5}'`
		PartDirName=`echo $lineFld |awk -F',' '{print $5}'`
		DirPartNm=`echo $PartDirName | cut -d"_" -f1`
		DirPartRev=`echo $PartDirName | cut -d"_" -f2`
		DirPartSeq=`echo $PartDirName | cut -d"_" -f3`
		if [ ! -d "$directory" ]; then
			echo "$directory  not exist hence skipping."
			continue
		fi
		cd "$directory"
		echo "2.Working FolderName: $directory"
echo ".................................... Generating File  to_load_parts.txt .........................."
echo "#DELIMITER ^" > $partfile
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile
while read line
do
	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	####qty=`echo $line |awk -F'^' '{print $6}'`
	unitofmes=`echo $line |awk -F'^' '{print $18}'`
	if [[ "$item" =~ "/" ]]
	then
		echo "Changing string for item:  $item"
		item=`basename $item`
	fi
	if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
		if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
			rev=$DirPartRev
			seq=$DirPartSeq
		fi
	fi
	parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
	parentChild="$parentAtr,$item"
	echo $parentChild
	qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	echo "qty:" $qty
	if [[ -z "$qty" ]]
	then
		qty=1
	fi
	cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
	if [[ $cntq > 1 ]]
	then
		echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
		#qty=9999
		qty=1
	else
		qty=`basename $qty`
	fi
	name=$item
	#unitofmes="-"
	quantity="1"
	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile
done < allparts_"$directory".txt
if test -s  AssyBomSuperSet.txt
then
echo ".................................... Generating File  to_load_parts_new.txt .........................."
echo "#DELIMITER ^" > $partfileNew
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty Suppressed" >> $partfileNew
while read line
do
	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	unitofmes=`echo $line |awk -F'^' '{print $8}'`
	cadQty=`echo $line |awk -F'^' '{print $9}'`
	suppressTmp=`echo $line |awk -F'^' '{print $10}'`
	suppress=`echo $suppressTmp |awk -F' ,' '{print $1}'`
	ImmParent=`echo $line |awk -F'^' '{print $11}'`
	if [[ "$item" =~ "/" ]]
	then
		echo "Changing string for item:  $item"
		item=`basename $item`
	fi
	if [[ "$level" == "0" ]] && [[ "$item" == "$DirPartNm" ]]; then
		if [[ "$rev" != "$DirPartRev" ]] && [[ "$seq" != "$DirPartSeq" ]]; then
			rev=$DirPartRev
			seq=$DirPartSeq
		fi
	fi
	parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
	###parentChild="$parentAtr,$item"
	parentChild="$ImmParent,$item"
	if test -s quantity.txt
	then
	qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	else
	qty=0
	fi
	echo "Before..qty:" $qty
	#if [[ $cadQty -gt 0 ]] || [[ $cadQty -gt $qty ]]
	if [[ $cadQty -gt  $qty ]]
	then
		qty=$cadQty
		echo "..qty:" $qty
	fi
	if [[ -z "$qty" ]]
	then
		qty=1
	fi
	cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
	if [[ $cntq -gt 1 ]]
	then
		echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
		#qty=9999
		qty=1
	else
		qty=`basename $qty`
	fi
	name=$item
	quantity="1"
	if [[ "$cadQty" -eq 0 ]]
	then
		quantity="0"
	fi
	echo "After..qty:" $qty
	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity^$suppress^$ImmParent^" >>  $partfileNew
done < AssyBomSuperSet.txt
if test -s quantity.txt
then
	echo "....Creating File for null qty to 9999..."
	grep -F '^9999^' to_load_parts_new.txt > nullQtyParts.txt
	while read kline
	do
		prtnm=`echo $kline |awk -F'^' '{print $2}'`
		grep -w $prtnm quantity.txt >> quantityNullParts.txt
	done < nullQtyParts.txt
fi
fi
#Creating DataSets For ProE_rrr Items
echo "....Creating DataSets For ProE_rrr Items..."
if test -s input.txt
then
rm -rf input.txt
fi
#Below is added for non-TC part CAD Dataset on 09.11.2016
if test -s "$directory".proe
then
while read jline
do
	jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
	classNm=`echo $jline | cut -d\, -f11`
	fInstname=`echo $jline | cut -d\, -f1`
	fname=`echo $jline | cut -d\, -f2`
	#fname=`basename $fname`
	echo "fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  #echo "Found / in string"
	  fname=`basename $fname`
	else
	  echo "Couldnt find it"
	fi
	echo "jtname: $fname"
	prtName=`echo $fname | cut -d"." -f1`
	echo "..prtName: $prtName"
	echo "fInstname: $fInstname"
	echo $fInstname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  #echo "Found / in string"
	  fInstname=`basename $fInstname`
	else
	  echo "Couldnt find it"
	fi
	echo $fInstname | grep '<' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
		prtInstName=`echo $fInstname | cut -d"<" -f1`
		prtGenName2=`echo $fInstname | cut -d"<" -f2`
		prtGenName=`echo $prtGenName2 | cut -d">" -f1`
		echo "prtInstName: $prtInstName"
		echo "prtGenName: $prtGenName"
		#add here check for $prtGenName numeric/Alphanumeric for 12digitInstance<12digitGeneric>
		#if
		#else
		f_prt=`grep -iw $prtInstName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtInstName`
		echo "f_prt: $f_prt"
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^"
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^-^Proe Des.Doc^" >>  input.txt
			###echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			###echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
			#echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			#echo "$prtGenName^NR^1^$fname^$fullpath/$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
			echo "$prtGenName^NR^1^$fname^$fname^1^$classNm^Generic^-^Proe Des.Doc^"
			echo "$prtGenName^NR^1^$fname^$fname^1^$classNm^Generic^-^Proe Des.Doc^" >>  input.txt
		fi
	else
		f_prt=`grep -iw $prtName allparts_"$directory".txt | awk ' { print $1 } ' | sort -u | grep -i $prtName`
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			#echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^-^Proe Des.Doc^" >>  input.txt
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fname^1^$classNm^-^-^Proe Des.Doc^" >>  input.txt
		fi
	fi
done < "$directory".proe
fi
#Below while loop is added for Drawing and PDF-JT Dataset
if [[ -f "$directory".out.jt  &&  -s "$directory".out.jt ]]; then
while read jline
do
	classNm=`echo $jline | cut -d\, -f5`
	f_DataItem=`echo $jline | cut -d\, -f8`
	f_partNo=`echo $jline | cut -d\, -f7`
	f_partRevSeq=`echo $jline | cut -d\, -f6`
	f_partRev=`echo $f_partRevSeq | cut -d";" -f1`
	f_partSeq=`echo $f_partRevSeq | cut -d";" -f2`
	fname=`echo $jline | cut -d\, -f2`
	fname=`basename $fname`
	#echo "out.jt..fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	# below fnameSuffix is added on 10.11.2016 and ALF-JT copy logic is added
	fnameSuffix=`echo $fname | cut -d\. -f2`
	if [ "$fnameSuffix" == "jt" ];then
		fnameJt=`echo $fname | cut -d\. -f1`
		#echo "fnameSuffix: $fnameSuffix"
		if [[ "$fnameJt" =~ "_ALF" ]]
		then
			echo "ALF is present found in string"
			f_partNo=`echo $jline | cut -d\, -f9`
			##echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			###echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
		elif [[ "$fnameJt" =~ "_WELD" ]]
		then
			echo "WELD is present found in string"
			f_partNo=`echo $jline | cut -d\, -f9`
			##echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			###echo "$f_partNo^NR^1^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^"
			echo "$f_partNo^NR^1^$fname^$fname^1^$classNm^-^$f_DataItem^-^Proe Des.Doc^" >>  input.txt
		elif [ "$classNm" == "ProDrw" -o "$classNm" == "x0CatDrw" -o "$classNm" == "PdfFile" -o "$classNm" == "ProPrt" -o "$classNm" == "ProAsm" -o "$classNm" == "ProAsmI" -o "$classNm" == "ProPrtI" ];then
			#echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^-^$f_DataItem^-^" >>  input.txt
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fname^1^$classNm^-^$f_DataItem^-^"
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fname^1^$classNm^-^$f_DataItem^-^" >>  input.txt
		fi
	fi
done < "$directory".out.jt
fi
sort -u input.txt > input.txt1
mv input.txt1 input.txt
if test -s suppressedTruePartList.txt
then
	rm -rf suppressedTruePartList.txt
fi
grep -i "TRUE" *.pos | cut -d":" -f2 > suppressedTruePartListTemp.txt
while read pline
do
	ParentAssy=`echo $pline | cut -d\, -f1`
	SupPart=`echo $pline | cut -d\, -f2`
	SupAttrVal=`echo $pline | cut -d\, -f20`
	echo "1^$SupPart^ ^ ^ ^1^$SupPart^4^1^TRUE^$ParentAssy^" >>  suppressedTruePartList.txt
done < suppressedTruePartListTemp.txt
grep "TRUE" to_load_parts_new.txt >> suppressedTruePartList.txt
if test -s suppressedTruePartList.txt
then
sort -u suppressedTruePartList.txt > suppressedTruePartList.txt1
mv suppressedTruePartList.txt1 suppressedTruePartList.txt
fi
	cd ..
	done < $SubAssyPart.PartList.txt
cd ..
done < "$1.SubAssyPartList.txt"
fi
