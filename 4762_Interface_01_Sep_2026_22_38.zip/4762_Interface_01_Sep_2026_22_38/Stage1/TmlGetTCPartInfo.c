/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Aniket P. Kadu
*  Module		 :   TCUA Proe Downloader
*  Code			 :   GetTCPartInfo.c
*  Created on	 :   Jan 10, 2012
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>

int main(int argc, char *argv[])
{
	int stat=0;
	int m=0;
	int i=0;
	int j=0;
	//int k=0;
	int ii = 0;
	int noOfDocs=0;
	int flagDocPartRev=0;

	string LoginS = NULL ;
	string PasswordS = NULL ;
	string DIClassNameS = NULL ;
	string VaultNameS = NULL ;
	string OutFileNameS=NULL;
	string OutFileNmAllRev=NULL;
	string DISequenceS=NULL;

	SetOfObjects DISO = NULL;
	SetOfObjects DIDocSO = NULL;
	SetOfObjects DIDocRelSO = NULL;
	SetOfObjects PartSO = NULL;
	//SetOfObjects ItmMstrSO = NULL;
	//SetOfObjects ItmMstrRelSO = NULL;
	SetOfObjects DocPartRelSO = NULL;
	SetOfObjects DocPartSO = NULL;
	SetOfObjects docObjs = NULL;
	SetOfObjects docRelObjs = NULL;
	SetOfObjects latestDocs = NULL;
	SetOfObjects latestRelDocs = NULL;

    SetOfStrings dbScpe =   NULL;

	ObjectPtr TCObjP = NULL ;
	ObjectPtr PartObjP = NULL ;
	//ObjectPtr PartMasterObjP = NULL ;
	ObjectPtr JTObjP = NULL ;
	ObjectPtr DocObjP = NULL ;
	ObjectPtr docOPtr = NULL ;

	FILE *fp = NULL;
	FILE *fpAllRev = NULL;

	SqlPtr DISqlPtr = NULL ;
	SqlPtr PartSqlPtr = NULL ;

	string docobjst =   NULL;
	string RelativePathS = NULL;
	string RelativePathDupS = NULL;
	string PartNumberDupSPrev = NULL;
	string PartNumberDupS2 = NULL;
	string PartNumberS2 = NULL;
	string RevisionDupS2 = NULL;
	string RevisionS2 = NULL;
	string SequenceDupS2 = NULL;
	string SequenceS2 = NULL;
	string PartNumberDupS = NULL;
	string PartNumberS = NULL;
	string RevisionDupS = NULL;
	string RevisionS = NULL;
	string SequenceDupS = NULL;
	string SequenceS = NULL;
	string OwnerNameDupS = NULL;
	string OwnerNameS = NULL;
	string NomenclatureDupS = NULL;
	string NomenclatureS = NULL;
	string PartTypeDupS = NULL;
	string PartTypeS = NULL;
	string t5DsgnOwnDupS = NULL;
	string t5DsgnOwnS = NULL;
	string ProjectNameDupS = NULL;
	string ProjectNameS = NULL;
	string WeightDupS = NULL;
	string WeightS = NULL;
	string SpareIndDupS = NULL;
	string SpareIndS = NULL;
	string t5LeftRhDupS = NULL;
	string t5LeftRhS = NULL;
	string t5MatlClassDupS = NULL;
	string t5MatlClassS = NULL;
	string t5DocumentTypeDupS = NULL;
	string t5DocumentTypeS = NULL;
	string t5SourceDataErrorsDupS = NULL;
	string t5SourceDataErrorsS = NULL;
	string t5DesignGroupDupS = NULL;
	string t5DesignGroupS = NULL;
	string t5DocRemarkS = NULL;
	string t5DocRemarkDupS = NULL;
	string t5DrawingIndDupS = NULL;
	string t5DrawingIndS = NULL;
	string t5DrawingNo = NULL;
	string t5DrawingNoDupS = NULL;
	string t5MaterialInDrwS = NULL;
	string t5MaterialInDrwDupS = NULL;
	string MaterialThickNessDupS = NULL;
	string MaterialThickNessS = NULL;
	string t5ModelIndicatorS = NULL;
	string t5ModelIndicatorDupS = NULL;
	string UnitOfMeasureS = NULL;
	string UnitOfMeasureDupS = NULL;
	string t5ColourIndS = NULL;
	string t5ColourIndDupS = NULL;
	string LifeCycleStateS = NULL;
	string LifeCycleStateDupS = NULL;
	string eff_dateDupS = NULL;
	string docClass = NULL;
	string OwnerDirS = NULL;
	string level = NULL;
	string dummypart = NULL;
	string t5DocumentName = NULL;
	string t5DocumentNameDupS = NULL;
	string t5DocumentRev = NULL;
	string t5DocumentRevDupS = NULL;
	string t5DocumentSeq = NULL;
	string t5DocumentSeqDupS = NULL;
	/*
	string OBIDS = NULL;
	string OBIDDupS = NULL;
	string MakeBuyIndicatorDupS = NULL;
	string StdPartIndicatorS = NULL;
	string StdPartIndicatorDupS = NULL;
	string t5DsgnDeptS = NULL;
	string t5DsgnDeptDupS = NULL;
	string t5SpareCriteriaS = NULL;
	string t5SpareCriteriaDupS = NULL;
	string t5SpareIndS = NULL;
	string t5SpareIndDupS = NULL;
	string t5RecoverableS = NULL;
	string t5RecoverableDupS = NULL;
	string t5ReliabilityS = NULL;
	string t5ReliabilityDupS = NULL;
	string t5DismantableS = NULL;
	string t5DismantableDupS = NULL;
	string t5ProductS = NULL;
	string t5ProductDupS = NULL;
	string t5PkgStdS = NULL;
	string t5PkgStdDupS = NULL;
	string t5CMVRCertificationReqdS = NULL;
	string t5CMVRCertificationReqdDupS = NULL;
	string t5HomologationReqdS = NULL;
	string t5HomologationReqdDupS = NULL;
	string t5HazardousContentsS = NULL;
	string t5HazardousContentsDupS = NULL;
	string t5RecyclabilityS = NULL;
	string t5RecyclabilityDupS = NULL;
	string t5ClassificationHazardousS = NULL;
	string t5ClassificationHazardousDupS = NULL;
	string t5EnvelopeDimensionsS = NULL;
	string t5EnvelopeDimensionsDupS = NULL;
	string t5PunIntialAgencyS = NULL;
	string t5PunIntialAgencyDupS = NULL;
	string t5PunMakeBuyIndicatorS = NULL;
	string t5PunMakeBuyIndicatorDupS = NULL;
	string t5JsrIntialAgencyS = NULL;
	string t5JsrIntialAgencyDupS = NULL;
	string t5JsrMakeBuyIndicatorS = NULL;
	string t5JsrMakeBuyIndicatorDupS = NULL;
	string t5LkoIntialAgencyS = NULL;
	string t5LkoIntialAgencyDupS = NULL;
	string t5LkoMakeBuyIndicatorS = NULL;
	string t5LkoMakeBuyIndicatorDupS = NULL;
	string t5SgrIntialAgencyS = NULL;
	string t5SgrIntialAgencyDupS = NULL;
	string t5SgrMakeBuyIndicatorS = NULL;
	string t5SgrMakeBuyIndicatorDupS = NULL;
	string t5PnrIntialAgencyS = NULL;
	string t5PnrIntialAgencyDupS = NULL;
	string t5PnrMakeBuyIndicatorS = NULL;
	string t5PnrMakeBuyIndicatorDupS = NULL;
	*/

	t5MethodInitWMD("WIPAndRELVault");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	DIClassNameS=nlsStrAlloc(200);
	VaultNameS=nlsStrAlloc(200);
	OutFileNameS=nlsStrAlloc(200);
	DISequenceS=nlsStrAlloc(100);
	OwnerDirS=nlsStrAlloc(100);
	dummypart=nlsStrAlloc(100);
	OutFileNmAllRev=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	DIClassNameS=argv[3];
	DISequenceS=argv[4];
	OwnerDirS=argv[5];
	VaultNameS=argv[6];
	OutFileNameS=argv[7];
	level=argv[8];
	dummypart=argv[9];
	OutFileNmAllRev=argv[10];

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());


	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

	fp=fopen(OutFileNameS,"a+");
	fflush(fp);

	fpAllRev=fopen(OutFileNmAllRev,"a+");
	fflush(fpAllRev);

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScpe,mfail));
	for (ii=0;ii<setSize(dbScpe) ; ii++)
	{
		docobjst=low_set_get(dbScpe,ii);
		//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	low_set_add_str_unique(dbScpe, "supprod");
	low_set_add_str_unique(dbScpe, "suhprod");
	low_set_add_str_unique(dbScpe, "sulprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScpe,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScpe,mfail));
	for (ii=0;ii<low_set_size(dbScpe) ; ii++)
	{
		docobjst=low_set_get(dbScpe,ii);
		//printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}

	t5CheckDstat(oiSqlCreateSelect(&DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerNameAttr,VaultNameS));
	t5CheckDstat(oiSqlWhereAND(DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,SequenceAttr,DISequenceS));
	t5CheckDstat(oiSqlWhereAND(DISqlPtr));
	t5CheckDstat(oiSqlWhereEQ(DISqlPtr,RelativePathAttr,DIClassNameS));

    if(nlsStrStr(DIClassNameS,"CATPart")!=NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		t5CheckMfail(QueryWhere(x0CatPrtClass,DISqlPtr,&DISO,mfail));
	}
	else if(nlsStrStr(DIClassNameS,"CATProduct")!=NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		t5CheckMfail(QueryWhere(x0CatPrdClass,DISqlPtr,&DISO,mfail));
	}
	else if(nlsStrStr(DIClassNameS,".prt.")!=NULL || nlsStrStr(DIClassNameS,".asm.")!=NULL)
	{
		t5CheckDstat(oiSqlWhereAND(DISqlPtr));
		t5CheckDstat(oiSqlWhereEQ(DISqlPtr,OwnerDirNameAttr,OwnerDirS));
		t5CheckMfail(QueryWhere(ProObjClass,DISqlPtr,&DISO,mfail));
	}
	else
	{
		t5CheckMfail(QueryWhere(ProInstClass,DISqlPtr,&DISO,mfail));
	}

	oiSqlPrint(DISqlPtr);
	printf("\nDISO objects are... :%d",setSize(DISO));fflush(stdout);

	if(setSize(DISO)==0)
	{
		goto EXIT;
	}

	if(setSize(DISO)>0)
    {
		for(j=0;j<setSize(DISO);j++)
		{
			JTObjP=setGet(DISO,j);
			t5CheckDstat(objGetAttribute(JTObjP,RelativePathAttr,&RelativePathS));
			RelativePathDupS=nlsStrDup(RelativePathS);
			printf("\n RelativePathDupS:%s",RelativePathDupS); fflush(stdout);
			t5CheckMfail(ExpandObject2(AttachClass,JTObjP,"BusItemsAttachingDataItem",SC_SCOPE_OF_SESSION,&DIDocSO,&DIDocRelSO,mfail));

			//sort by creation date function for DIDocSO and processing for latest part rev is added on 24.07.2015
			t5CheckMfail(t5SortBOMObjsByDate(&DIDocSO,&DIDocRelSO,mfail));

			if(setSize(DIDocSO)==0)
			{
				dummypart=strtok(dummypart,"./<");

				fprintf(fp,"%s",level);
				fprintf(fp,"^");
				fprintf(fp,"%s",dummypart);
				fprintf(fp,"^");
				fprintf(fp,"NR");
				fprintf(fp,"^");
				fprintf(fp,"1");
				fprintf(fp,"^");
				fprintf(fp,"Dummy Part for Proe.");
				fprintf(fp,"^");
				fprintf(fp,"D^"); // Dummy PartType
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^");
				fprintf(fp,"^\n");
				goto CLEANUP;
			}
	        printf("\n Document objects are... :%d\n",setSize(DIDocSO));fflush(stdout);

			if(setSize(DIDocSO)>0)
			{
				//for(k=0;k<setSize(DIDocSO);k++)	// commented on 24.07.2015
				//{
					//DocObjP=setGet(DIDocSO,k);
					DocObjP=setGet(DIDocSO,0);

					t5CheckDstat(objGetAttribute(DocObjP,t5DocumentType1Attr,&t5DocumentTypeS));
					t5DocumentTypeDupS=nlsStrDup(t5DocumentTypeS);
					printf("\n  t5DocumentTypeDupS:%s",t5DocumentTypeDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,DocumentNameAttr,&t5DocumentName));
					t5DocumentNameDupS=nlsStrDup(t5DocumentName);
					printf("\n  t5DocumentNameDupS:%s",t5DocumentNameDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,RevisionAttr,&t5DocumentRev));
					t5DocumentRevDupS=nlsStrDup(t5DocumentRev);
					printf("\n  t5DocumentRevDupS:%s",t5DocumentRevDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,SequenceAttr,&t5DocumentSeq));
					t5DocumentSeqDupS=nlsStrDup(t5DocumentSeq);
					printf("\n  t5DocumentSeqDupS:%s",t5DocumentSeqDupS); fflush(stdout);

					t5CheckDstat(objGetAttribute(DocObjP,t5SourceDataErrorsAttr,&t5SourceDataErrorsS));
					t5SourceDataErrorsDupS=nlsStrDup(t5SourceDataErrorsS);
					printf("\n  t5SourceDataErrorsDupS:%s",t5SourceDataErrorsDupS); fflush(stdout);

					t5CheckMfail(ExpandObject2(PartDocClass,DocObjP,"PartsDescribedByDocument",SC_SCOPE_OF_SESSION,&DocPartSO,&DocPartRelSO,mfail));
					printf("\n  Part objects:%d",setSize(DocPartSO));fflush(stdout);

					if(setSize(DocPartSO)>0)
					{
						for(i=0;i<setSize(DocPartSO);i++)
						{
							TCObjP=setGet(DocPartSO,i);

							t5CheckDstat(objGetAttribute(TCObjP,PartNumberAttr,&PartNumberS2));
							PartNumberDupS2=nlsStrDup(PartNumberS2);

							t5CheckDstat(objGetAttribute(TCObjP,RevisionAttr,&RevisionS2));
							RevisionDupS2=nlsStrDup(RevisionS2);

							t5CheckDstat(objGetAttribute(TCObjP,SequenceAttr,&SequenceS2));
							SequenceDupS2=nlsStrDup(SequenceS2);
							printf("\n\nAttached TCPartNumberDupS2:%s,%s,%s",PartNumberDupS2,RevisionDupS2,SequenceDupS2); fflush(stdout);

							if(i > 0)
							{
								PartNumberDupSPrev=nlsStrDup(PartNumberS2);
								if (nlsStrCmp(PartNumberDupSPrev,PartNumberDupS2) == 0)
								{
									continue;
								}
							}

                            /*if(nlsStrCmp(t5DocumentNameDupS,PartNumberDupS2) == 0 && nlsStrCmp(t5DocumentRevDupS,RevisionDupS2) == 0 && nlsStrCmp(t5DocumentSeqDupS,SequenceDupS2) == 0  || setSize(DocPartSO) == 1)
							{
                       			printf("\n **************matching DOC and parts rev");
							}else {
							printf("\n ************** Not matching DOC and parts rev");
							continue;
							}*/

							/*if((nlsStrCmp(t5DocumentNameDupS,PartNumberDupS2) == 0 && nlsStrCmp(t5DocumentRevDupS,RevisionDupS2) == 0 && nlsStrCmp(t5DocumentSeqDupS,SequenceDupS2) == 0)  || setSize(DocPartSO) == 1 )
							{
								printf("\n **************matching DOC and parts rev");
							}
							else if((setSize(DocPartSO) > 1) && (setSize(DocPartSO)-1) == i)
							{
								printf("\n ************else**matching DOC and parts rev");
							}
							else 
							{
								printf("\n ************** Not matching DOC and parts rev");
								continue;
							}*/

							printf("\n **************Querying all revisions of part");

							t5CheckDstat(oiSqlCreateSelect(&PartSqlPtr));
							t5CheckDstat(oiSqlWhereEQ(PartSqlPtr,PartNumberAttr,PartNumberDupS2));
							t5CheckDstat(oiSqlAscOrder(PartSqlPtr,CreationDateAttr));
							t5CheckMfail(QueryWhere(PartClass,PartSqlPtr,&PartSO,mfail));
							//oiSqlPrint(PartSqlPtr);
							printf("\n PartSO objects:%d",setSize(PartSO));fflush(stdout);

							if(setSize(PartSO)>0)
							{
								for(m=0;m<setSize(PartSO);m++)
								{
									PartObjP=setGet(PartSO,m);

									//if (dstat = ExpandObject2("ItemRev",PartObjP,"ItemMstrForStrucBIRev",SC_SCOPE_OF_SESSION,&ItmMstrSO,&ItmMstrRelSO,&mfail)) ;
									//PartMasterObjP=setGet(ItmMstrSO,0);

									t5CheckDstat(objGetAttribute(PartObjP,PartNumberAttr,&PartNumberS));
									PartNumberDupS=nlsStrDup(PartNumberS);
									printf("\n\n\t TCPartNumberDupS:%s",PartNumberDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,RevisionAttr,&RevisionS));
									RevisionDupS=nlsStrDup(RevisionS);
									printf("\n\t TCRevisionDupS :%s",RevisionDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,SequenceAttr,&SequenceS));
									SequenceDupS=nlsStrDup(SequenceS);
									printf("\n\t Sequence:%s",SequenceDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,NomenclatureAttr,&NomenclatureS));
									if(!nlsIsStrNull(NomenclatureS))
									{
										NomenclatureDupS=nlsStrDup(NomenclatureS);
									}
									else
									{
										NomenclatureDupS=nlsStrDup("-");
									}
									printf("\n\t NomenclatureDupS:%s",NomenclatureDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,PartTypeAttr,&PartTypeS));
									PartTypeDupS=nlsStrDup(PartTypeS);
									printf("\n\t PartTypeDupS:%s",PartTypeDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,OwnerNameAttr,&OwnerNameS));
									OwnerNameDupS=nlsStrDup(OwnerNameS);
									printf("\n\t OwnerNameDupS:%s",OwnerNameDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,ProjectNameAttr,&ProjectNameS));
									ProjectNameDupS=nlsStrDup(ProjectNameS);
									printf("\n\t ProjectNameDupS:%s",ProjectNameDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DesignGroupAttr,&t5DesignGroupS));
									t5DesignGroupDupS=nlsStrDup(t5DesignGroupS);
									printf("\n\t t5DesignGroupDupS:%s",t5DesignGroupDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DocRemarksAttr,&t5DocRemarkS));  //mod_desc
									if(!nlsIsStrNull(t5DocRemarkS))
									{
										t5DocRemarkDupS=nlsStrDup(t5DocRemarkS);
									}
									else
									{
										t5DocRemarkDupS=nlsStrDup("-");
									}
									printf("\n\t t5DocRemarkDupS:%s",t5DocRemarkDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DrawingIndAttr,&t5DrawingIndS));  //mod_desc
									t5DrawingIndDupS=nlsStrDup(t5DrawingIndS);
									printf("\n\t t5DrawingIndDupS:%s",t5DrawingIndDupS); fflush(stdout);

									if(nlsStrCmp(t5DrawingIndDupS,"D")==0)
									{
										docClass = low_getspace(20);

										if(dstat = ExpandObject2("PartDoc",PartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto EXIT;
										if(setSize(docObjs) <= 0)
										{
											if(dstat = ExpandObject2("InfoDwg",PartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;
										}
										if(setSize(docObjs) > 0)
										{
											if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
											if (setSize(latestDocs)>0)
											{
												for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
												{
													docOPtr = setGet(latestDocs, noOfDocs);
													if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
													if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
													{
														//Document Number = Drawing Document Number
														if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
														if(!nlsIsStrNull(t5DrawingNo))
														{
															t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
														}
														else
														{
															t5DrawingNoDupS = nlsStrDup("-");
														}
													}
												}
											}

											if(nlsIsStrNull(t5DrawingNoDupS))
											{
												if(dstat = ExpandObject2("InfoDwg",PartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&docObjs,&docRelObjs,mfail)) goto CLEANUP;

												if(setSize(docObjs) > 0)
												{
													if(dstat = t5GetLatestDocumnets(docObjs,docRelObjs,&latestDocs,&latestRelDocs,mfail)) goto CLEANUP;
													if (setSize(latestDocs)>0)
													{
														for(noOfDocs = 0; noOfDocs<setSize(latestDocs); noOfDocs++)
														{
															docOPtr = setGet(latestDocs, noOfDocs);
															if(dstat = objGetClass(docOPtr, &docClass)) goto CLEANUP;
															printf("\n\t ...51..%s",docClass);
															if((nlsStrCmp(docClass,"t5DrwDoc") == 0))
															{
																//Document Number = Drawing Document Number
																if(dstat = objGetAttribute (docOPtr, "DocumentName", &t5DrawingNo)) goto CLEANUP;
																if(!nlsIsStrNull(t5DrawingNo))
																{
																	t5DrawingNoDupS = nlsStrDup(t5DrawingNo);
																}
																else
																{
																	t5DrawingNoDupS = nlsStrDup("-");
																}
															}
														}
													}
												}
											}
										}

										if(nlsIsStrNull(t5DrawingNo))
										{
											t5DrawingNoDupS = nlsStrDup("-");
										}
									}
									else
									{
										t5DrawingNoDupS = nlsStrDup("-");
									}
									printf("\n\t t5DrawingNoDupS:%s",t5DrawingNoDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5MatlClassAttr,&t5MatlClassS));
									if(!nlsIsStrNull(t5MatlClassS))
									{
										t5MatlClassDupS=nlsStrDup(t5MatlClassS);
									}
									else
									{
										t5MatlClassDupS=nlsStrDup("-");
									}
									printf("\n\t t5MatlClassDupS:%s",t5MatlClassDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5MaterialAttr,&t5MaterialInDrwS));
									if(!nlsIsStrNull(t5MaterialInDrwS))
									{
										t5MaterialInDrwDupS=nlsStrDup(t5MaterialInDrwS);
									}
									else
									{
										t5MaterialInDrwDupS=nlsStrDup("-");
									}
									printf("\n\t t5MaterialInDrwDupS:%s",t5MaterialInDrwDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5MThicknessAttr,&MaterialThickNessS));
									if(!nlsIsStrNull(MaterialThickNessS))
									{
										MaterialThickNessDupS=nlsStrDup(MaterialThickNessS);
									}
									else
									{
										MaterialThickNessDupS=nlsStrDup("-");
									}
									printf("\n\t MaterialThickNessDupS:%s",MaterialThickNessDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5LeftRhAttr,&t5LeftRhS));
									//if (setSize(ItmMstrSO)>0)
									//{
										//t5CheckDstat(objGetAttribute(PartMasterObjP,t5LeftRhAttr,&t5LeftRhS));
										if(!nlsIsStrNull(t5LeftRhS))
										{
											t5LeftRhDupS=nlsStrDup(t5LeftRhS);
										}
										else
										{
											t5LeftRhDupS=nlsStrDup("NA");
										}
									//}
									//else
									//{
									//	t5LeftRhDupS=nlsStrDup("NA");
									//}
									printf("\n\t t5LeftRhDupS:%s",t5LeftRhDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DsgnOwnAttr,&t5DsgnOwnS));
									if(!nlsIsStrNull(t5DsgnOwnS))
									{
										t5DsgnOwnDupS=nlsStrDup(t5DsgnOwnS);
									}
									else
									{
										t5DsgnOwnDupS=nlsStrDup("TELPUN");
									}
									printf("\n\t t5DsgnOwnDupS:%s",t5DsgnOwnDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5ModelIndicatorAttr,&t5ModelIndicatorS));
									if(!nlsIsStrNull(t5ModelIndicatorS))
									{
										t5ModelIndicatorDupS=nlsStrDup(t5ModelIndicatorS);
									}
									else
									{
										t5ModelIndicatorDupS=nlsStrDup("-");
									}
									printf("\n\t t5ModelIndicatorDupS:%s",t5ModelIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5UQdupAttr,&UnitOfMeasureS));
									if(!nlsIsStrNull(UnitOfMeasureS))
									{
										UnitOfMeasureDupS=nlsStrDup(UnitOfMeasureS);
									}
									else
									{
										UnitOfMeasureDupS=nlsStrDup("4");
									}
									printf("\n\t UnitOfMeasureDupS:%s",UnitOfMeasureDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5ColourIndAttr,&t5ColourIndS));
									if(!nlsIsStrNull(t5ColourIndS))
									{
										t5ColourIndDupS=nlsStrDup(t5ColourIndS);
									}
									else
									{
										t5ColourIndDupS=nlsStrDup("N");
									}
									printf("\n\t t5ColourIndDupS:%s",t5ColourIndDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,LifeCycleStateAttr,&LifeCycleStateS));
									if(!nlsIsStrNull(LifeCycleStateS))
									{
										LifeCycleStateDupS=nlsStrDup(LifeCycleStateS);
									}
									else
									{
										LifeCycleStateDupS=nlsStrDup("LcsReview");
									}
									printf("\n\t LifeCycleStateDupS:%s",LifeCycleStateDupS); fflush(stdout);

									eff_dateDupS=nlsStrDup("-");

									t5CheckDstat(objGetAttribute(PartObjP,t5WeightAttr,&WeightS));
									if(!nlsIsStrNull(WeightS))
									{
										WeightDupS=nlsStrDup(WeightS);
									}
									else
									{
										WeightDupS=nlsStrDup("0");
									}
									printf("\n\t WeightDupS:%s",WeightDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5SpareIndAttr,&SpareIndS));
									if(!nlsIsStrNull(SpareIndS))
									{
										SpareIndDupS=nlsStrDup(SpareIndS);
									}
									else
									{
										SpareIndDupS=nlsStrDup("-");
									}
									printf("\n\t SpareIndDupS:%s",SpareIndDupS); fflush(stdout);

									/*t5CheckDstat(objGetAttribute(PartObjP,OBIDAttr,&OBIDS));
									OBIDDupS=nlsStrDup(OBIDS);
									printf("\n\t OBIDDupS:%s",OBIDDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,MakeBuyIndicatorAttr,&MakeBuyIndicatorS));
									MakeBuyIndicatorDupS=nlsStrDup(MakeBuyIndicatorS);
									printf("\n\t MakeBuyIndicatorDupS:%s",MakeBuyIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,StdPartIndicatorAttr,&StdPartIndicatorS));
									StdPartIndicatorDupS=nlsStrDup(StdPartIndicatorS);
									printf("\n\t StdPartIndicatorDupS:%s",StdPartIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DsgnDeptAttr,&t5DsgnDeptS));
									t5DsgnDeptDupS=nlsStrDup(t5DsgnDeptS);
									printf("\n\t t5DsgnDeptDupS:%s",t5DsgnDeptDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5SpareCriteriaAttr,&t5SpareCriteriaS));
									t5SpareCriteriaDupS=nlsStrDup(t5SpareCriteriaS);
									printf("\n\t t5SpareCriteriaDupS:%s",t5SpareCriteriaDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5RecoverableAttr,&t5RecoverableS));
									t5RecoverableDupS=nlsStrDup(t5RecoverableS);
									printf("\n\t t5RecoverableDupS:%s",t5RecoverableDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5ReliabilityAttr,&t5ReliabilityS));
									t5ReliabilityDupS=nlsStrDup(t5ReliabilityS);
									printf("\n\t t5ReliabilityDupS:%s",t5ReliabilityDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5DismantableAttr,&t5DismantableS));
									t5DismantableDupS=nlsStrDup(t5DismantableS);
									printf("\n\t t5DismantableDupS:%s",t5DismantableDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5ProductAttr,&t5ProductS));
									t5ProductDupS=nlsStrDup(t5ProductS);
									printf("\n\t t5ProductDupS:%s",t5ProductDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5PkgStdAttr,&t5PkgStdS));
									t5PkgStdDupS=nlsStrDup(t5PkgStdS);
									printf("\n\t t5PkgStdDupS:%s",t5PkgStdDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5CMVRCertificationReqdAttr,&t5CMVRCertificationReqdS));
									t5CMVRCertificationReqdDupS=nlsStrDup(t5CMVRCertificationReqdS);
									printf("\n\t t5CMVRCertificationReqdDupS:%s",t5CMVRCertificationReqdDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5HomologationReqdAttr,&t5HomologationReqdS));
									t5HomologationReqdDupS=nlsStrDup(t5HomologationReqdS);
									printf("\n\t t5HomologationReqdDupS:%s",t5HomologationReqdDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5HazardousContentsAttr,&t5HazardousContentsS));
									t5HazardousContentsDupS=nlsStrDup(t5HazardousContentsS);
									printf("\n\t t5HazardousContentsDupS:%s",t5HazardousContentsDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5RecyclabilityAttr,&t5RecyclabilityS));
									t5RecyclabilityDupS=nlsStrDup(t5RecyclabilityS);
									printf("\n\t t5RecyclabilityDupS:%s",t5RecyclabilityDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5ClassificationHazardousAttr,&t5ClassificationHazardousS));
									t5ClassificationHazardousDupS=nlsStrDup(t5ClassificationHazardousS);
									printf("\n\t t5ClassificationHazardousDupS:%s",t5ClassificationHazardousDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5EnvelopeDimensionsAttr,&t5EnvelopeDimensionsS));
									t5EnvelopeDimensionsDupS=nlsStrDup(t5EnvelopeDimensionsS);
									printf("\n\t t5EnvelopeDimensionsDupS:%s",t5EnvelopeDimensionsDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5PunIntialAgencyAttr,&t5PunIntialAgencyS));
									t5PunIntialAgencyDupS=nlsStrDup(t5PunIntialAgencyS);
									printf("\n\t t5PunIntialAgencyDupS:%s",t5PunIntialAgencyDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5PunMakeBuyIndicatorAttr,&t5PunMakeBuyIndicatorS));
									t5PunMakeBuyIndicatorDupS=nlsStrDup(t5PunMakeBuyIndicatorS);
									printf("\n\t t5PunMakeBuyIndicatorDupS:%s",t5PunMakeBuyIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5JsrIntialAgencyAttr,&t5JsrIntialAgencyS));
									t5JsrIntialAgencyDupS=nlsStrDup(t5JsrIntialAgencyS);
									printf("\n\t t5JsrIntialAgencySDupS:%s",t5JsrIntialAgencyDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5JsrMakeBuyIndicatorAttr,&t5JsrMakeBuyIndicatorS));
									t5JsrMakeBuyIndicatorDupS=nlsStrDup(t5JsrMakeBuyIndicatorS);
									printf("\n\t t5JsrMakeBuyIndicatorDupS:%s",t5JsrMakeBuyIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5LkoIntialAgencyAttr,&t5LkoIntialAgencyS));
									t5LkoIntialAgencyDupS=nlsStrDup(t5LkoIntialAgencyS);
									printf("\n\t t5LkoIntialAgencySDupS:%s",t5LkoIntialAgencyDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5LkoMakeBuyIndicatorAttr,&t5LkoMakeBuyIndicatorS));
									t5LkoMakeBuyIndicatorDupS=nlsStrDup(t5LkoMakeBuyIndicatorS);
									printf("\n\t t5LkoMakeBuyIndicatorDupS:%s",t5LkoMakeBuyIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5SgrIntialAgencyAttr,&t5SgrIntialAgencyS));
									t5SgrIntialAgencyDupS=nlsStrDup(t5SgrIntialAgencyS);
									printf("\n\t t5SgrIntialAgencyDupS:%s",t5SgrIntialAgencyDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5SgrMakeBuyIndicatorAttr,&t5SgrMakeBuyIndicatorS));
									t5SgrMakeBuyIndicatorDupS=nlsStrDup(t5SgrMakeBuyIndicatorS);
									printf("\n\t t5SgrMakeBuyIndicatorDupS:%s",t5SgrMakeBuyIndicatorDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5PnrIntialAgencyAttr,&t5PnrIntialAgencyS));
									t5PnrIntialAgencyDupS=nlsStrDup(t5PnrIntialAgencyS);
									printf("\n\t t5PnrIntialAgencyDupS:%s",t5PnrIntialAgencyDupS); fflush(stdout);

									t5CheckDstat(objGetAttribute(PartObjP,t5PnrMakeBuyIndicatorAttr,&t5PnrMakeBuyIndicatorS));
									t5PnrMakeBuyIndicatorDupS=nlsStrDup(t5PnrMakeBuyIndicatorS);
									printf("\n\t t5PnrMakeBuyIndicatorDupS:%s",t5PnrMakeBuyIndicatorDupS); fflush(stdout);
									*/

									//if((nlsStrCmp(PartNumberDupS,PartNumberDupS2)==0) && (nlsStrCmp(RevisionDupS,RevisionDupS2)==0) && (nlsStrCmp(SequenceDupS,SequenceDupS2)==0))
									if((nlsStrCmp(PartNumberDupS,PartNumberDupS2)==0) && (nlsStrCmp(RevisionDupS,t5DocumentRevDupS)==0) && (nlsStrCmp(SequenceDupS,t5DocumentSeqDupS)==0))
									{
										flagDocPartRev =1;

										fprintf(fp,"%s",level);
										fprintf(fp,"^");
										fprintf(fp,"%s",PartNumberDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",RevisionDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",SequenceDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",NomenclatureDupS); //desc
										fprintf(fp,"^");
										fprintf(fp,"%s",PartTypeDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",ProjectNameDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DesignGroupDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DocRemarkDupS); //mod_desc
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DrawingNoDupS);  //10
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DrawingIndDupS); //11
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MatlClassDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MaterialInDrwDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",MaterialThickNessDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5LeftRhDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DsgnOwnDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ModelIndicatorDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",UnitOfMeasureDupS); //18
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIndDupS);	//19
										fprintf(fp,"^");
										fprintf(fp,"%s",LifeCycleStateDupS);//20
										fprintf(fp,"^");
										fprintf(fp,"%s",eff_dateDupS);		//21
										fprintf(fp,"^");
										fprintf(fp,"%s",WeightDupS);		//22
										fprintf(fp,"^");
										fprintf(fp,"%s\n",SpareIndDupS);	//23
								    	printf("\n Inside fp --------------------------121");
										fflush(fp);
									}
									else if (((setSize(PartSO)-1) == m) && (flagDocPartRev == 0))
									{
										fprintf(fp,"%s",level);
										fprintf(fp,"^");
										fprintf(fp,"%s",PartNumberDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",RevisionDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",SequenceDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",NomenclatureDupS); //desc
										fprintf(fp,"^");
										fprintf(fp,"%s",PartTypeDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",ProjectNameDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DesignGroupDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DocRemarkDupS); //mod_desc
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DrawingNoDupS);  //10
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DrawingIndDupS); //11
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MatlClassDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5MaterialInDrwDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",MaterialThickNessDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5LeftRhDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5DsgnOwnDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ModelIndicatorDupS);
										fprintf(fp,"^");
										fprintf(fp,"%s",UnitOfMeasureDupS); //18
										fprintf(fp,"^");
										fprintf(fp,"%s",t5ColourIndDupS);	//19
										fprintf(fp,"^");
										fprintf(fp,"%s",LifeCycleStateDupS);//20
										fprintf(fp,"^");
										fprintf(fp,"%s",eff_dateDupS);		//21
										fprintf(fp,"^");
										fprintf(fp,"%s",WeightDupS);		//22
										fprintf(fp,"^");
										fprintf(fp,"%s\n",SpareIndDupS);	//23
								    	printf("\n Inside fp -----------else if------------121");
										fflush(fp);
									}

									//fprintf(fpAllRev,"%s",level);
									//fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",PartNumberDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",RevisionDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",SequenceDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",NomenclatureDupS); //desc
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",PartTypeDupS);  //PartType
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",ProjectNameDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5DesignGroupDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5DocRemarkDupS); //mod_desc
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5DrawingNoDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5DrawingIndDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5MatlClassDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5MaterialInDrwDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",MaterialThickNessDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5LeftRhDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5DsgnOwnDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5ModelIndicatorDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",UnitOfMeasureDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",t5ColourIndDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",LifeCycleStateDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",eff_dateDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s",WeightDupS);
									fprintf(fpAllRev,"^");
									fprintf(fpAllRev,"%s\n",SpareIndDupS);

									fflush(fpAllRev);
									printf("\n Inside fpAllRev --------------------------123");
								}
							}
						}
					}
					else
					{
						printf("\n Inside part not found");
						dummypart=strtok(dummypart,"./<");

						fprintf(fp,"%s",level);
						fprintf(fp,"^");
						fprintf(fp,"%s",dummypart);
						fprintf(fp,"^");
						fprintf(fp,"NR");
						fprintf(fp,"^");
						fprintf(fp,"1");
						fprintf(fp,"^");
						fprintf(fp,"Dummy Part for Proe.");
						fprintf(fp,"^");
						fprintf(fp,"D^"); // Dummy PartType
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^");
						fprintf(fp,"^\n");
						goto CLEANUP;
					}
				//}
			}
		}
	}

	if(fp)
	{
		fclose(fp);fp=NULL;
	}
	if(fpAllRev)
	{
		fclose(fpAllRev);fpAllRev=NULL;
	}

CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(DISO);

EXIT:
		if(fp)
		{
			fclose(fp);fp=NULL;
		}
		if(fpAllRev)
		{
			fclose(fpAllRev);fpAllRev=NULL;
		}

		t5CheckDstatAndReturn;
}
;
status T5SortBOMObjsByDate
(
	SetOfObjects *itemObjs,
	SetOfObjects *relObjs,
	integer* mfail
)
{
	status dstat = OKAY;
	char *mod_name = "t5SortBOMObjsByDate";
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpRelObjs = NULL;
	ObjectPtr relObj = NULL;
	ObjectPtr itemObj = NULL;
	ObjectPtr relTObj = NULL;
	ObjectPtr itemTObj = NULL;
	integer count = 0;
	integer cmpCount = 0;
	ObjectPtr tmpRelObj = 0;
	string curCreDate = NULL;
	string tmpcurCreDate = NULL;
	string cmpCreDate = NULL;
	string tmpcmpCreDate = NULL;
	*mfail = USC_OKAY;

	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		/* initalizing sorted object set */
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		/* get mainSerial */
		if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
		tmpcurCreDate = nlsStrDup(curCreDate);

		/* compare mainSerial with the new set of objects */
		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
			tmpcmpCreDate = nlsStrDup(cmpCreDate);

			if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) <= 0)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}
	/* free memory and assign to new set sorted objects */
	objDisposeAll(*itemObjs); *itemObjs = NULL;
	objDisposeAll(*relObjs); *relObjs = NULL;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}
