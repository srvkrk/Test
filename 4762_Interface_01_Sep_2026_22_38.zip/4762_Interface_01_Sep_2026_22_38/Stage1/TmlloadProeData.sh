######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author		: Aniket Kadu / Sharvari / BT / Rupali / Dayanand
# Created on	: Jan 10, 2012
# Project       : Teamcenter 8.3 Trilix to TC10.1
# Module		: TCUA Proe Uploader
# Code          : loadProeData.sh
# Modified on	: 11.07.2015 
#######################################################################################

cd "$1"
pwd
while read lineFld
do
	echo "******************Input: " $lineFld
#proedi=`echo $lineFld |awk -F',' '{print $1}'`
#directory=`basename $proedi`
directory=`echo $lineFld |awk -F',' '{print $5}'`
cd "$directory"
echo "Working FolderName: $directory"

filename="to_load"
fileNm=GenericInstance.txt
echo "fileNm: $fileNm"

/home/cmitest/TCUA/PROE_TCUA/TmlcreateRevForProe -i=allpartsAllRev_"$directory".txt -u=loader -p=abc
if [ $? != 0 ]
then
	echo "Problem in TmlcreateRevForProe"
	exit 1
fi
if [[ -f $fileNm ]] && [[ ! -s $fileNm ]]; then 
	echo "GenericInstance File is empty" ;
else
/home/cmitest/TCUA/PROE_TCUA/TmlcreateRevForProe -i=GenericInstance.txt -u=loader -p=abc
if [ $? != 0 ]
then
		echo "Problem in Generic TmlcreateRevForProe"
		exit 1
fi
fi

partfile=${filename}_parts.txt
echo "#DELIMITER ^" > $partfile
echo "#COL   Level  item  rev Seq desc occs Name Uom Qty" >> $partfile

while read line
do
	echo $line
	level=`echo $line |awk -F'^' '{print $1}'`
	item=`echo $line |awk -F'^' '{print $2}'`
	rev=`echo $line |awk -F'^' '{print $3}'`
	seq=`echo $line |awk -F'^' '{print $4}'`
	desc=`echo $line |awk -F'^' '{print $5}'`
	####qty=`echo $line |awk -F'^' '{print $6}'`
	#unitofmes=`echo $line |awk -F'^' '{print $18}'`

	parentAtr=`ls *."$item".* | awk -F'.' '{print $1}' | tr -d ' ' | sort -u`
	#echo $parentAtr
	parentChild="$parentAtr,$item"
	echo $parentChild

	#qty=`grep -w $item quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	qty=`grep -w "$parentChild" quantity.txt | awk -F',' '{print $3}' | tr -d ' ' | sort -u`
	echo "qty:" $qty

	if [[ -z "$qty" ]]
	then
		qty=1
	fi

	cntq=`echo "$qty" | sed 's/[^ ]//g' | wc -c`
	if [[ $cntq > 1 ]]
	then
		echo "Space Found..hence qty set to 9999 for $level^$item^$rev^$seq"
		qty=9999
	else
		qty=`basename $qty`
	fi

	name=$item
	unitofmes="-"
	quantity="1"

	echo "$level^$item^$rev^$seq^$desc^$qty^$name^$unitofmes^$quantity" >>  $partfile

done < allparts_"$directory".txt
echo "....Creating File for null qty to 9999..."
grep -F '^9999^' to_load_parts.txt > nullQtyParts.txt
while read kline
do
prtnm=`echo $kline |awk -F'^' '{print $2}'`
grep -w $prtnm quantity.txt >> quantityNullParts.txt
done < nullQtyParts.txt
#Creating DataSets For ProE Items
echo "....Creating DataSets For ProE Items..."
if test -s input.txt
then
rm -rf input.txt
fi
fullpath=`pwd`
#echo "fullpath: " $fullpath
while read jline
do
	jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
	classNm=`echo $jline | cut -d\, -f11`
	fInstname=`echo $jline | cut -d\, -f1`
	fname=`echo $jline | cut -d\, -f2`
	#fname=`basename $fname`
	echo "fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  echo "Found / in string"
	  fname=`basename $fname`
	else
	  echo "Couldnt find it"
	fi
	echo "jtname: $fname"
	prtName=`echo $fname | cut -d"." -f1`
	echo "..prtName: $prtName"
	echo "fInstname: $fInstname"
	echo $fInstname | grep '<' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
		prtInstName=`echo $fInstname | cut -d"<" -f1`
		prtGenName2=`echo $fInstname | cut -d"<" -f2`
		prtGenName=`echo $prtGenName2 | cut -d">" -f1`
		echo "prtInstName: $prtInstName"
		echo "prtGenName: $prtGenName"
		f_prt=`grep -iw $prtInstName allparts_"$directory".txt | sort -u`
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^"
			echo "$f_partNo^$f_partRev^$f_partSeq^$f_partNo^-^1^$classNm^Instance^" >>  input.txt

			echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^"
			echo "$prtGenName^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^Generic^" >>  input.txt
		fi
	else
		f_prt=`grep -iw $prtName allparts_"$directory".txt | sort -u`
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^^" >>  input.txt
		fi
	fi
done < "$directory".out.proe

/home/cmitest/TCUA/PROE_TCUA/TmlDataSetLoadProE -i=input.txt

#Creating DataSets For ProE Items
echo "....Creating DataSets For ProE Items..."
if test -s inputjt.txt
then
rm -rf inputjt.txt
fi
fullpath=`pwd`
#echo "fullpath: " $fullpath
while read jline
do
	jtname=`echo $jline | cut -d\, -f2 | sed 's/ /_/g'`
	classNm=`echo $jline | cut -d\, -f5`
	fInstname=`echo $jline | cut -d\, -f1`
	fname=`echo $jline | cut -d\, -f2`
	#fname=`basename $fname`
	echo "fname: $fname"
	echo $fname | grep '/' >/dev/null 2>&1
	if [ "$?" -eq "0" ]; then
	  echo "Found / in string"
	  fname=`basename $fname`
	else
	  echo "Couldnt find it"
	fi
	echo "jtname: $fname"
	prtName=`echo $fname | cut -d"." -f1`
	echo "..prtName: $prtName"

		f_prt=`grep -iw $prtName allparts_"$directory".txt | sort -u`
		if [ ! -z "$f_prt" ]; then
			f_partNo=`echo $f_prt | cut -d"^" -f2`
			f_partRev=`echo $f_prt | cut -d"^" -f3`
			f_partSeq=`echo $f_prt | cut -d"^" -f4`
			echo "$f_partNo^$f_partRev^$f_partSeq^$fname^$fullpath/$fname^1^$classNm^^" >>  inputjt.txt
		fi
done < "$directory".out.jt

/home/cmitest/TCUA/PROE_TCUA/TmlDataSetLoadProE -i=inputjt.txt

#if [ $? != 0 ]
#then
#	echo "Problem in TmlDataSetLoadProE"
#	exit 1
#fi
echo "**Going to load Structure.."
/home/cmitest/TCUA/PROE_TCUA/TmlloadParts -i=${filename}_parts.txt -u=loader -p=abc -o=on
if [ $? != 0 ]
then
	echo "Problem in TmlloadParts structure"
	exit 1
fi
echo "**Going to create generic-instance cad/dataset relation.."

if [[ -f $fileNm ]] && [[ ! -s $fileNm ]]; then 
	echo "11.GenericInstance File is empty" ;
else
/home/cmitest/TCUA/PROE_TCUA/TmlProEGeneric -i=GenericInstance.txt
if [ $? != 0 ]
then
	echo "Problem in TmlProEGeneric"
	exit 1
fi
#echo ".."
fi

filename=$directory.out.jt
echo "fileame of out.jt is:" $filename
if test -s jt_temp.txt
then
rm -rf jt_temp.txt
fi
while read line 
do
	classNm=`echo $line | cut -d"," -f5`
	echo "classNm:  $classNm *******"
	dataset=`echo $line |awk -F',' '{print $2}'`
	dataset=`echo $dataset | awk -F'.' '{print $1}'`
	dataset=`basename $dataset`
	echo "dataset is:" $dataset

	itemname=$dataset

	revision="NR"
    jtname=`echo $line |awk -F',' '{print $2}'`
	jtname=`basename $jtname`
	echo "jtname is:" $jtname
	echo "itemname is:" $itemname

	if [ "$itemname" = "" ];then		
		echo "No Jt File to Copy"
	else
		echo "jtname again is:" $jtname
		if [  "$jtname" = "" ];then
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
			
		else
			echo "Copying $jtname"
			if [ "$classNm" == "ProAsm" ];then
				echo "ProAsm line is here"
				echo "-f=$jtname -type=DirectModel -d="$dataset/$revision" -ref=JTPART -item=$itemname -revision=$revision -ie=y -de=u -desc=jt file -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >> jt_temp.txt
			else
				echo "ProPrt line is here"
				echo "-f=$jtname -type=DirectModel -d="$dataset/$revision" -ref=JTPART -item=$itemname -revision=$revision -ie=y -de=u -desc=jt file -use_ds_attached_to_rev_only -relationType=IMAN_Rendering -vb" >> jt_temp.txt
			fi
		fi	
	fi
done < $filename

#$TC_ROOT/bin/import_file -i=jt_temp.txt -u=loader -p=abc


filename=$directory.out.proe
echo "fileame of out.proe111 is:" $filename
if test -s proe_temp.txt
then
rm -rf proe_temp.txt
fi
while read line 
do
	ClassName=`echo $line |awk -F',' '{print $11}'`

	itemname=`echo $line |awk -F',' '{print $12}'`
	itemname=`echo $itemname |tr '[a-z]'  '[A-Z]' `

	echo "itemname converted to uppercase is:" $itemname

	if [ "$ClassName" = "ProPrtI" ]; then	
		echo "proprti line is here"
		dataset=`echo $line |awk -F',' '{print $1}'`
		echo "dataset is ProPrtI:" $dataset
	else	
		if [ "$ClassName" = "ProAsmI" ];then	
			echo "ProAsmI line is here"
			dataset=`echo $line |awk -F',' '{print $1}'`
			echo "dataset is ProAsmI:" $dataset
		else
			echo "Normal ProAsm and ProPrt classes"
		
			dataset=`echo $line |awk -F',' '{print $2}'`
			dataset=`echo $dataset | awk -F'.' '{print $1}'`
			dataset=`basename $dataset`
			echo "dataset is:" $dataset
		fi
	fi

	#itemname=$dataset

	revision="NR"
        cadname=`echo $line |awk -F',' '{print $2}'`
	cadname=`basename $cadname`
	echo "cadname is:" $cadname
	echo "itemname is:" $itemname

	if [ "$itemname" = "" ];then		
		echo "No cad File to Copy"
	else
		
		res=`echo $cadname | grep -i ".asm"`
		echo x$res

		if [ "x$res" = "x" ];then
			catType=ProPrt
			reference=PrtFile
		else
			catType=ProAsm
			reference=AsmFile
		fi 

		echo "cadname again is:" $cadname
		if [  "$cadname" = "" ];then
			echo "Not At OS:$cgrfile" >> NotAtOs.txt
			
		else
			echo "Copying PRO $cadname"
			echo "-f=$cadname -type=$catType -d="$dataset" -ref=$reference -item=$itemname -revision=NR -ie=y -de=u -desc=proe file -use_ds_attached_to_rev_only -relationType=IMAN_specification -vb" >>proe_temp.txt
		fi	
	fi
done < $filename
#echo "--------Importing ProE data-------------"
#$TC_ROOT/bin/import_file -i=proe_temp.txt -u=loader -p=abc

cd ..
done < $1.PartList.txt
