/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   rrr05503
*  Module		 :   TCUA Proe Downloader
*  Code			 :   TmlGetAllTCRevJTCadDrg.c
*  Created on	 :   July 09, 2016
*
* Modification History :
* S.No		Date		CR No	Modified By            Modification Notes
*
***************************************************************************/
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <Mtimsg.h>

SetOfStrings dbScopeStr = NULL;
SetOfStrings dbScopeBkp = NULL;

int SetFlagforScope(SetOfObjects ScopeObjects);
status t5GetLatestDocumnets_R
(
		SetOfObjects	docObjs,
		SetOfObjects	docRelObjs,
		SetOfObjects*	latestDocs,
		SetOfObjects*	latestRelDocs,
		integer*		mfail
);
status t0LatestBI
(
	SetOfObjects itemObj,
	SetOfObjects itemRel,
	ObjectPtr *returnedObj,
	ObjectPtr *returnedRel,
	integer *mfail
);

int main(int argc, char *argv[])
{
	t5MethodInitWMD("TmlGetAllTCRevJTCadDrg");

	int stat = 0;
	int ii = 0;
	int count = 0;
	int noOfDocs = 0;
	//int di = 0;
	int pi = 0;
	int i = 0;
	int tmpStrlen = 0;
	int charFlag = 0;
	int lcnt = 0;
	int GenericFlag = 0;
	int GenInstanceFlag = 0;
	int DesDocFlag = 0;
	//int jtcnt = 0;
	//int m = 0;

	char tempstr[50]={0};

	SetPtr filestr = NULL;

	string part_no = NULL ;
	//string part_noConv = NULL ;
	string PartRev = NULL ;
	string PartSeq = NULL ;
	string OutputFileNameS = NULL ;
	string OutputFileNameSAsm = NULL ;
	string OutputFileNameS2 = NULL ;
	string docobjst = NULL;
	string PartNumber = NULL;
	string PartNumberDup = NULL;
	string TCSequence = NULL;
	string TCSequenceDup = NULL;
	string TCRevision = NULL;
	string TCRevisionDup = NULL;
	string PartOwnerName = NULL;
	string PartOwnerNameDup = NULL;
	string docClass = NULL;
	string JTdocClass = NULL;
	string JTdocClassDup = NULL;
	string DesDoc = NULL;
	string DesDocDup = NULL;
	string DesDocRev = NULL;
	string DesDocRevDup = NULL;
	string ApplnOwner = NULL;
	string ApplnOwnerDup = NULL;
	string DataItemDisplayNm = NULL;
	string DataItemDisplayNmDup = NULL;
	string DataItemDisplayNmDup2 = NULL;
	string DIOwnerName = NULL;
	string DIOwnerNameDup = NULL;
	string cadRelativePath = NULL;
	string cadRelativePathDup = NULL;
	string cadWrelativepath = NULL;
	string cadWrelativepathDup = NULL;
	string cadOwnerDirName = NULL;
	string cadOwnerDirNameDup = NULL;
	string cadOwnerName = NULL;
	string cadOwnerNameDup = NULL;
	string DISeq = NULL;
	string DISeqDup = NULL;
	string InstClass = NULL;
	string InstClassDup = NULL;
	string JTRelativePath = NULL;
	string JTRelativePathDup = NULL;
	string JTWRelativePath = NULL;
	string JTWRelativePathDup = NULL;
	string OwnerDirNameJT = NULL;
	string OwnerDirNameJTDup = NULL;
	string JTOwnerName = NULL;
	string JTOwnerNameDup = NULL;
	string wrelativepath=NULL;
	string wrelativepathDup=NULL;
	string wrelativepathDup1=NULL;
	string asmInstanceS=NULL;
	string asmInstanceS2=NULL;
	string proAsmDisplayNmS=NULL;
	string proAsmDisplayNmDupS=NULL;
	string temp1 = NULL;
	string temp2 = NULL;
	string temp5 = NULL;
	string temp6 = NULL;
	string PDFRelativePath = NULL;
	string PDFRelativePathDup = NULL;
	string PDFWRelativePath = NULL;
	string PDFWRelativePathDup = NULL;
	string OwnerDirNamePDF = NULL;
	string OwnerDirNamePDFDup = NULL;
	string PDFOwnerName = NULL;
	string PDFOwnerNameDup = NULL;
	string PDFdocClass = NULL;
	string PDFdocClassDup = NULL;
	//string classNameS = NULL;
	//string classNameDupS = NULL;
	//string workingrelPath=NULL;
	//string workingrelPathDup=NULL;
	//string AlfJTRelativePath = NULL;
	//string AlfJTRelativePathDup = NULL;
	//string AlfJTWRelativePath = NULL;
	//string AlfJTWRelativePathDup = NULL;
	//string AlfJTOwnerDirName = NULL;
	//string AlfJTOwnerDirNameDup = NULL;
	//string AlfJTOwnerName = NULL;
	//string AlfJTOwnerNameDup = NULL;
	string cadfullPath = NULL;
	string cadfullPathDup = NULL;
	string CadHostNm = NULL;
	string CadHostNmDup = NULL;
	string CadSiteNm = NULL;
	string CadSiteNmDup = NULL;
	string JTfullPath = NULL;
	string JTfullPathDup = NULL;
	string JTHostNm = NULL;
	string JTHostNmDup = NULL;
	string JTSiteNm = NULL;
	string JTSiteNmDup = NULL;
	string PDFfullPath = NULL;
	string PDFfullPathDup = NULL;
	string PDFHostNm = NULL;
	string PDFHostNmDup = NULL;
	string PDFSiteNm = NULL;
	string PDFSiteNmDup = NULL;


	SetOfObjects PartSO = NULL;
	SetOfObjects LatestDocs = NULL;
	SetOfObjects LatestRelDocSO = NULL;
	SetOfObjects DataItemJtSO = NULL;
	SetOfObjects LatestRefDocSO = NULL;
	SetOfObjects LatestRefRelDocSO = NULL;
	SetOfObjects DocumentSO = NULL;
	SetOfObjects DocumentRelSO = NULL;
	SetOfObjects DocumentRefSO = NULL;
	SetOfObjects DocumentRefRelSO = NULL;
	SetOfObjects desDocJtObjs = NULL;
	//SetOfObjects JTAppDependOnSO = NULL;
	SetOfObjects ProeInstDepOnSO = NULL;
	SetOfObjects ProeInstDepOnRelSO = NULL;
	SetOfObjects ProeGenDataItemSO = NULL;
	SetOfObjects desDocPDFObjs = NULL;

	SetOfStrings GenInst = NULL;

	ObjectPtr TCPartObjP = NULL;
	ObjectPtr DocOPtr = NULL;
	ObjectPtr NewDataItemObjP = NULL;
	ObjectPtr JTPartObjP = NULL;
	ObjectPtr AsmIObjP = NULL;
	ObjectPtr PrtIObjP = NULL;
	ObjectPtr PDFPartObjP = NULL;
	//ObjectPtr appdepjtPtr = NULL;
	ObjectPtr GetInfoCADIObjP = NULL;
	ObjectPtr GetInfoJTPartObjP = NULL;
	ObjectPtr GetInfoPdfPartObjP = NULL;

	SqlPtr Sql_ptr = NULL;
	SqlPtr ProeObjSqlPtr = NULL;

	FILE *fp = NULL;
	FILE *fpCad = NULL;
	FILE *fpAsm = NULL;
	FILE *fpAsmJt = NULL;

	part_no = nlsStrAlloc(100);
	PartRev = nlsStrAlloc(5);
	PartSeq = nlsStrAlloc(5);
	OutputFileNameS = nlsStrAlloc(50);
	OutputFileNameSAsm = nlsStrAlloc(50);
	OutputFileNameS2 = nlsStrAlloc(50);

	docClass = low_getspace(20);
	JTdocClass = low_getspace(20);

	GenInst = low_set_create(10);

	part_no=argv[1];
	PartRev=argv[2];
	PartSeq=argv[3];
	OutputFileNameS=argv[4];
	OutputFileNameS2=argv[5];

	printf("\nInputFile:[%s,%s,%s]  [%s]  [%s]",part_no,PartRev,PartSeq,OutputFileNameS,OutputFileNameS2);

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session. */
	t5CheckDstat(clInitialize2 (FALSE));


	t5CheckDstat(clLogin2 ("Loader","123loader",&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS \n");  fflush(stdout);
		goto EXIT;
	}

	nlsStrCpy(OutputFileNameSAsm,OutputFileNameS);
	nlsStrCat(OutputFileNameSAsm,"1");

	fp=fopen(OutputFileNameS,"a+");
	fflush(fp);

	fpCad=fopen(OutputFileNameS2,"a+");
	fflush(fpCad);

	fpAsm=fopen("ConvertedProEBomDownloadForDataset.txt.proe","a+");
	fflush(fpAsm);

	fpAsmJt=fopen(OutputFileNameSAsm,"a+");		//Added on 30.08.2017
	fflush(fpAsmJt);

	//printf("\n\n Enter Inside...program....\n");

	dbScopeStr = low_set_create_str(2);
	dbScopeBkp = low_set_create_str(2);

	//DB preference added by Rupali
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	//for (ii=0;ii<setSize(dbScopeBkp) ; ii++)
	//{
	//	docobjst=low_set_get(dbScopeBkp,ii);
	//	//printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	//}
	low_set_add_str_unique(dbScopeBkp, "suhprod");
	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScopeBkp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScopeBkp,mfail));
	printf("\n DB pref check -after...:");fflush(stdout);
	for (ii=0;ii<low_set_size(dbScopeBkp) ; ii++)
	{
		docobjst=low_set_get(dbScopeBkp,ii);
		printf("\t[%s]",docobjst);fflush(stdout);
	}
	printf("\n\n");fflush(stdout);

	low_set_add_str_unique(dbScopeStr, "supprod");
	low_set_add_str_unique(dbScopeStr, "suhprod");
	low_set_add_str_unique(dbScopeStr, "sujprod");
	low_set_add_str_unique(dbScopeStr, "sulprod");


	printf("\n **************Querying all revisions of part");

	//t5CheckDstat(oiSqlCreateSelect(&Sql_ptr));
	//t5CheckDstat(oiSqlWhereEQ(Sql_ptr,PartNumberAttr,PartNumberDupS2));
	//t5CheckDstat(oiSqlAscOrder(Sql_ptr,CreationDateAttr));
	//t5CheckMfail(QueryWhere(PartClass,Sql_ptr,&PartSO,mfail));
	//oiSqlPrint(Sql_ptr);

	if ((dstat = oiSqlCreateSelect(&Sql_ptr)) ||
		(dstat = oiSqlWhereBegParen(Sql_ptr)) ||
		(dstat = oiSqlWhereEQ(Sql_ptr,"PartNumber",part_no)) ||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,"Revision",PartRev)) ||
		(dstat = oiSqlWhereAND(Sql_ptr))||
		(dstat = oiSqlWhereEQ(Sql_ptr,"Sequence",PartSeq)) ||
		(dstat = oiSqlDescOrder(Sql_ptr,"CreationDate")) ||
		(dstat = oiSqlWhereEndParen(Sql_ptr)) ||
		(dstat = QueryWhere("Part",Sql_ptr,&PartSO,mfail)) ) goto CLEANUP;

	printf("\n PartSO objects:%d",setSize(PartSO));fflush(stdout);

	if(setSize(PartSO) == 0)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;

		if ((dstat = oiSqlCreateSelect(&Sql_ptr)) ||
			(dstat = oiSqlWhereBegParen(Sql_ptr)) ||
			(dstat = oiSqlWhereEQ(Sql_ptr,"PartNumber",part_no)) ||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,"Revision",PartRev)) ||
			(dstat = oiSqlWhereAND(Sql_ptr))||
			(dstat = oiSqlWhereEQ(Sql_ptr,"Sequence",PartSeq)) ||
			(dstat = oiSqlDescOrder(Sql_ptr,"CreationDate")) ||
			(dstat = oiSqlWhereEndParen(Sql_ptr)) ||
			(dstat = QueryWhere("Part",Sql_ptr,&PartSO,mfail)) ) goto CLEANUP;

		printf("\n After setting all DBScopes....PartSO objects:%d",setSize(PartSO));fflush(stdout);

		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;

		if(setSize(PartSO)==0)
		{
			printf("\t %s,%s,%s",part_no,PartRev,PartSeq);fflush(stdout);
			goto EXIT;
		}
	}

	/*if(setSize(PartSO) == 0)	//if condn is added on 31.03.2017 for querying all generic tc parts revsions.
	{
		strcpy(tempstr,"");
		strcpy(tempstr,part_no);

		tmpStrlen = strlen(tempstr);
		//printf ("\n\t tmpStrlen  %d",tmpStrlen);
		for(i=0;i<tmpStrlen;i++)
		{
			if (!isdigit(tempstr[i]))
			{
				//printf ("\n\t alpha");
				charFlag = 1;
				printf ("\n\t charFlag %d found hence skipping\n\n",charFlag);
				break;
			}
		}

		if (charFlag == 1)
		{
			part_noConv = ConvertToLowerCase(part_no);

			if ((dstat = oiSqlCreateSelect(&Sql_ptr)) ||
				(dstat = oiSqlWhereBegParen(Sql_ptr)) ||
				(dstat = oiSqlWhereEQ(Sql_ptr,"PartNumber",part_noConv)) ||
				(dstat = oiSqlWhereAND(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,"Revision",PartRev)) ||
				(dstat = oiSqlWhereAND(Sql_ptr))||
				(dstat = oiSqlWhereEQ(Sql_ptr,"Sequence",PartSeq)) ||
				(dstat = oiSqlDescOrder(Sql_ptr,"CreationDate")) ||
				(dstat = oiSqlWhereEndParen(Sql_ptr)) ||
				(dstat = QueryWhere("Part",Sql_ptr,&PartSO,mfail)) ) goto CLEANUP;
		}
	}*/

	if(setSize(PartSO)>0)
	{
		//for(m=0;m<setSize(PartSO);m++)
		//{

			ApplnOwnerDup = nlsStrDup("-");

			TCPartObjP=setGet(PartSO,0);
			//TCPartObjP=setGet(PartSO,m);

		if(objGetAttribute(TCPartObjP,PartNumberAttr,&PartNumber)) goto CLEANUP;
		if(!nlsIsStrNull(PartNumber))
		{
			PartNumberDup=nlsStrDup(PartNumber);
		}
		else
		{
			PartNumberDup=nlsStrDup("");
		}

		if(objGetAttribute(TCPartObjP,SequenceAttr,&TCSequence)) goto CLEANUP;
		if(!nlsIsStrNull(TCSequence))
		{
			TCSequenceDup=nlsStrDup(TCSequence);
		}
		else
		{
			TCSequenceDup=nlsStrDup("");
		}

		if(objGetAttribute(TCPartObjP,RevisionAttr,&TCRevision)) goto CLEANUP;
		if(!nlsIsStrNull(TCRevision))
		{
			TCRevisionDup = nlsStrAlloc(50);
			TCRevisionDup=nlsStrDup(TCRevision);
			nlsStrCat(TCRevisionDup,";");
			nlsStrCat(TCRevisionDup,TCSequenceDup);
		}
		else
		{
			TCRevisionDup=nlsStrDup("NR;1");
		}

		t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&PartOwnerName));
		PartOwnerNameDup=nlsStrDup(PartOwnerName);
		if(nlsStrStr(PartOwnerNameDup,"Vault")==NULL)
		{
			printf("\n ??? Part: %s %s %s %s  is not present in vault hence skipping from download CAD/JT...\n",PartNumberDup,TCRevision,TCSequenceDup,PartOwnerNameDup);  fflush(stdout);
			goto CLEANUP;
		}

		if (setSize(LatestDocs)>0)
		{
			objDisposeAll(LatestDocs);
			LatestDocs = NULL;
		}
		if (setSize(LatestRelDocSO)>0)
		{
			objDisposeAll(LatestRelDocSO);
			LatestRelDocSO = NULL;
		}
		if (setSize(LatestRefDocSO)>0)
		{
			objDisposeAll(LatestRefDocSO);
			LatestRefDocSO = NULL;
		}
		if (setSize(LatestRefRelDocSO)>0)
		{
			objDisposeAll(LatestRefRelDocSO);
			LatestRefRelDocSO = NULL;
		}

		if(dstat = ExpandObject2(PartDocClass,TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
		if(SetFlagforScope(DocumentSO)==1)
		{
			if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
			if(dstat = ExpandObject2(PartDocClass,TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail)) goto CLEANUP;
			if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
		}
		printf("\n ???????????setSize(DocumentSO) : %d",setSize(DocumentSO));
		if (setSize(DocumentSO) > 0)
		{
			if(dstat = t5GetLatestDocumnets_R(DocumentSO,DocumentRelSO,&LatestDocs,&LatestRelDocSO,mfail)) goto CLEANUP;
		}
		printf("\n setSize(LatestDocs) : %d   ???????????",setSize(LatestDocs));

		if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentRefSO,&DocumentRefRelSO,mfail)) goto CLEANUP;
		if(SetFlagforScope(DocumentRefSO)==1)
		{
			if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
			if(dstat = ExpandObject2("InfoDwg",TCPartObjP,"t5AssmhasInfDwgL",SC_SCOPE_OF_SESSION,&DocumentRefSO,&DocumentRefRelSO,mfail)) goto CLEANUP;
			if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
		}
		if (setSize(DocumentRefSO) > 0)
		{
			if(dstat = t5GetLatestDocumnets_R(DocumentRefSO,DocumentRefRelSO,&LatestRefDocSO,&LatestRefRelDocSO,mfail)) goto CLEANUP;
		}

		if(setSize(LatestDocs) <= 0)
		{
			LatestDocs  = setCreate(10);
			for(count=0 ; count  < setSize(LatestRefDocSO) ; count++)
			{
				low_set_add(LatestDocs,setGet(LatestRefDocSO,count));
			}
		}
		else
		{
			low_set_cat(LatestDocs,LatestRefDocSO);
		}

		printf("\n setSize(LatestDocs) : %d",setSize(LatestDocs));

		if (setSize(LatestDocs)>0)
		{
			for(noOfDocs = 0; noOfDocs<setSize(LatestDocs); noOfDocs++)
			{
				DocOPtr = setGet(LatestDocs, noOfDocs);

				if(dstat = objGetClass(DocOPtr, &docClass)) goto CLEANUP;

				if((nlsStrCmp(docClass,"DesDoc") == 0) )
				{
					printf("\n 11..docClass:%s",docClass);

					if(dstat = ExpandObject5(AttachClass,DocOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP; //added on 16.01.2016
					if(SetFlagforScope(DataItemJtSO)==1)
					{
						if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
						if(dstat = ExpandObject5(AttachClass,DocOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP;
						if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
					}
					if (setSize(DataItemJtSO) > 0)
					{
						DesDocFlag = 1;
						break;
					}
				}
			}
			printf("\n DesDocFlag:%d ",DesDocFlag);

			if(!nlsIsStrNull(ApplnOwnerDup))
			{
				ApplnOwnerDup = nlsStrDup("-");
			}

			for(noOfDocs = 0; noOfDocs<setSize(LatestDocs); noOfDocs++)
			{
				DocOPtr = setGet(LatestDocs, noOfDocs);

				if(dstat = objGetClass(DocOPtr, &docClass)) goto CLEANUP;
				printf("\n docClass:%s",docClass);

				if (setSize(DataItemJtSO)>0)
				{
					objDisposeAll(DataItemJtSO);
				}
				DataItemJtSO = NULL;

				if(dstat = ExpandObject5(AttachClass,DocOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP;
				if(SetFlagforScope(DataItemJtSO)==1)
				{
					if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
					if(dstat = ExpandObject5(AttachClass,DocOPtr,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemJtSO,mfail)) goto CLEANUP;
					if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
				}
				printf("\t setSize(DataItemJtSO):%d",setSize(DataItemJtSO));

				if((nlsStrCmp(docClass,"DesDoc") == 0) )
				{
					if(dstat = objGetAttribute (DocOPtr, "DocumentName", &DesDoc)) goto CLEANUP;
					if(!nlsIsStrNull(DesDoc))
					{
						DesDocDup = nlsStrDup(DesDoc);
					}
					if(dstat = objGetAttribute (DocOPtr, RevisionAttr, &DesDocRev)) goto CLEANUP;
					if(!nlsIsStrNull(DesDocRev))
					{
						DesDocRevDup = nlsStrDup(DesDocRev);
					}

					if (setSize(DataItemJtSO) > 0)
					{
						if(dstat = objGetAttribute (DocOPtr, "t5DocumentType1", &ApplnOwner)) goto CLEANUP;
						if(!nlsIsStrNull(ApplnOwner))
						{
							ApplnOwnerDup = nlsStrDup(ApplnOwner);
						}

						printf("   ApplnOwnerDup:%s",ApplnOwnerDup); fflush(stdout);
					}

					if(setSize(DataItemJtSO)>0)
					{
						//CODE For Getting the Data Item Files
						//for(di=0;di<setSize(DataItemJtSO);di++)
						//{
						//	NewDataItemObjP=setGet(DataItemJtSO,di);
							NewDataItemObjP=setGet(DataItemJtSO,0);

							if(dstat = objGetAttribute(NewDataItemObjP,"DisplayedName",&DataItemDisplayNm)) goto CLEANUP;
							if(!nlsIsStrNull(DataItemDisplayNm))
							{
								DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
								DataItemDisplayNmDup2=nlsStrDup(DataItemDisplayNm);
							}
							else
							{
								DataItemDisplayNmDup=nlsStrDup("");
								DataItemDisplayNmDup2=nlsStrDup("");
							}
							printf("\n\t DesDoc..DataItemDisplayNmDup:[%s]",DataItemDisplayNmDup);fflush(stdout);

							t5CheckDstat(objGetAttribute(NewDataItemObjP,"OwnerName",&DIOwnerName));
							if(!nlsIsStrNull(DIOwnerName))
							{
								DIOwnerNameDup=nlsStrDup(DIOwnerName);
							}
							printf("   DIOwnerNameDup:[%s] ",DIOwnerNameDup);fflush(stdout);

							if((nlsStrCmp(DIOwnerNameDup,"Archive_Vault")==0) || (nlsStrStr(DIOwnerNameDup,"Archive") !=NULL))
							{
								printf("   .....Skipping from CAD/JT data downloading...");fflush(stdout);
								continue;
							}

							t5CheckDstat(objGetAttribute(NewDataItemObjP,"WorkingRelativePath",&wrelativepath));
							if(!nlsIsStrNull(wrelativepath))
							{
								wrelativepathDup=nlsStrDup(wrelativepath);
								wrelativepathDup1=nlsStrDup(wrelativepath);
							}

							if(dstat = objGetAttribute(NewDataItemObjP,"Class",&InstClass)) goto CLEANUP;
							if(!nlsIsStrNull(InstClass))
							{
								InstClassDup=nlsStrDup(InstClass);
							}
							else
							{
								InstClassDup=nlsStrDup("");
							}

							printf("\n\t DesDoc..InstClassDup:[%s]",InstClassDup);fflush(stdout);

							if (((nlsStrCmp(InstClassDup,"ProPrtI")==0) || (nlsStrCmp(InstClassDup,"ProAsmI")==0)) &&(!nlsIsStrNull(nlsStrStr(DataItemDisplayNmDup,"<"))))
							{
								if(nlsStrCmp(InstClassDup,"ProAsmI")==0)
								{
									t5CheckMfail(ExpandObject2(ProDepndClass,NewDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail));
									if(SetFlagforScope(ProeInstDepOnSO)==1)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										t5CheckMfail(ExpandObject2(ProDepndClass,NewDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail));
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
									}
									printf("\n\t Number of ProAsmI Generic Object After Expansion is: %d \n",setSize(ProeInstDepOnSO)); fflush(stdout);

									if(nlsStrStr(wrelativepathDup1,".") !=NULL)
									{
										asmInstanceS = strtok(wrelativepathDup1,".");
									}

									for(pi=0;pi<setSize(ProeInstDepOnSO);pi++)
									{
										t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
										proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);

										printf("\n\t ProAsmI...proAsmDisplayNmDupS:[%s] asmInstanceS:[%s]",proAsmDisplayNmDupS,asmInstanceS); fflush(stdout);
										if(nlsStrStr(proAsmDisplayNmDupS,asmInstanceS) !=NULL )
										{
											printf("\n\t ProAsmI...Match Found "); fflush(stdout);
											AsmIObjP=setGet(ProeInstDepOnSO,pi);
											break;
										}
									}

									if (AsmIObjP != NULL)
									{
										t5CheckDstat(objGetAttribute(AsmIObjP,"RelativePath",&cadRelativePath));
										if(!nlsIsStrNull(cadRelativePath))
										{
											cadRelativePathDup=nlsStrDup(cadRelativePath);
										}

										t5CheckDstat(objGetAttribute(AsmIObjP,"WorkingRelativePath",&cadWrelativepath));
										if(!nlsIsStrNull(cadWrelativepath))
										{
											cadWrelativepathDup=nlsStrDup(cadWrelativepath);
										}

										if(dstat = objGetAttribute(AsmIObjP,"OwnerDirName",&cadOwnerDirName)) goto CLEANUP;
										if(!nlsIsStrNull(cadOwnerDirName))
										{
											cadOwnerDirNameDup=nlsStrDup(cadOwnerDirName);
										}
										else
										{
											cadOwnerDirNameDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(AsmIObjP,"OwnerName",&cadOwnerName)) goto CLEANUP;
										if(!nlsIsStrNull(cadOwnerName))
										{
											cadOwnerNameDup=nlsStrDup(cadOwnerName);
										}
										else
										{
											cadOwnerNameDup=nlsStrDup("");
										}

										t5CheckDstat(GetInfoItem(AsmIObjP,&GetInfoCADIObjP,mfail));

										t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"FullPath",&cadfullPath)) ;
										if(!nlsIsStrNull(cadfullPath))
										{
											cadfullPathDup=nlsStrDup(cadfullPath);
										}
										else
										{
											cadfullPathDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"HostName",&CadHostNm)) ;
										if(!nlsIsStrNull(CadHostNm))
										{
											CadHostNmDup=nlsStrDup(CadHostNm);
										}
										else
										{
											CadHostNmDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"SiteName",&CadSiteNm)) ;
										if(!nlsIsStrNull(CadSiteNm))
										{
											CadSiteNmDup=nlsStrDup(CadSiteNm);
										}
										else
										{
											CadSiteNmDup=nlsStrDup("-");
										}
									}

									if(setSize(ProeInstDepOnSO)>0)
									{
										if((nlsStrCmp(docClass,"DesDoc") == 0) )
										{
											//if(dstat = ExpandObject5(GenVisClass,setGet(ProeInstDepOnSO,0),"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
											if(dstat = ExpandObject5(GenVisClass,AsmIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
											if(SetFlagforScope(desDocJtObjs)==1)
											{
												if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
												if(dstat = ExpandObject5(GenVisClass,AsmIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
												if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
											}
										}
										if(setSize(desDocJtObjs)>0)
										{
											JTPartObjP=setGet(desDocJtObjs,0);

											if(dstat = objGetAttribute(JTPartObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
											if(!nlsIsStrNull(JTRelativePath))
											{
												JTRelativePathDup=nlsStrDup(JTRelativePath);
											}
											else
											{
												JTRelativePathDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
											if(!nlsIsStrNull(JTWRelativePath))
											{
												JTWRelativePathDup=nlsStrDup(JTWRelativePath);
											}
											else
											{
												JTWRelativePathDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
											if(!nlsIsStrNull(OwnerDirNameJT))
											{
												OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
											}
											else
											{
												OwnerDirNameJTDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
											if(!nlsIsStrNull(JTOwnerName))
											{
												JTOwnerNameDup=nlsStrDup(JTOwnerName);
											}
											else
											{
												JTOwnerNameDup=nlsStrDup("");
											}

											t5CheckDstat(GetInfoItem(JTPartObjP,&GetInfoJTPartObjP,mfail));

											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
											if(!nlsIsStrNull(JTfullPath))
											{
												JTfullPathDup=nlsStrDup(JTfullPath);
											}
											else
											{
												JTfullPathDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
											if(!nlsIsStrNull(JTHostNm))
											{
												JTHostNmDup=nlsStrDup(JTHostNm);
											}
											else
											{
												JTHostNmDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
											if(!nlsIsStrNull(JTSiteNm))
											{
												JTSiteNmDup=nlsStrDup(JTSiteNm);
											}
											else
											{
												JTSiteNmDup=nlsStrDup("-");
											}
										}
										else
										{
											JTdocClass = low_getspace(20);

											//printf("\n\t .........................................\n");
											//objDump(AsmIObjP);
											//printf("\n\t .........................................");

											if (AsmIObjP != NULL)
											{
												//if(dstat = objGetAttribute(setGet(ProeInstDepOnSO,0),ClassAttr,&JTdocClassDup)) goto CLEANUP;
												if(dstat = objGetAttribute(AsmIObjP,ClassAttr,&JTdocClassDup)) goto CLEANUP;
												if(!nlsIsStrNull(JTdocClassDup))
												{
													JTdocClass = nlsStrDup(JTdocClassDup);
												}

												if((nlsStrCmp(JTdocClass,"JT")==0))
												{
													printf("\n\t JTdocClass: %s",JTdocClass);

													if(dstat = objGetAttribute(AsmIObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
													if(!nlsIsStrNull(JTRelativePath))
													{
														JTRelativePathDup=nlsStrDup(JTRelativePath);
													}
													else
													{
														JTRelativePathDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(AsmIObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
													if(!nlsIsStrNull(JTWRelativePath))
													{
														JTWRelativePathDup=nlsStrDup(JTWRelativePath);
													}
													else
													{
														JTWRelativePathDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(AsmIObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
													if(!nlsIsStrNull(OwnerDirNameJT))
													{
														OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
													}
													else
													{
														OwnerDirNameJTDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(AsmIObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
													if(!nlsIsStrNull(JTOwnerName))
													{
														JTOwnerNameDup=nlsStrDup(JTOwnerName);
													}
													else
													{
														JTOwnerNameDup=nlsStrDup("");
													}

													t5CheckDstat(GetInfoItem(AsmIObjP,&GetInfoJTPartObjP,mfail));

													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
													if(!nlsIsStrNull(JTfullPath))
													{
														JTfullPathDup=nlsStrDup(JTfullPath);
													}
													else
													{
														JTfullPathDup=nlsStrDup("-");
													}
													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
													if(!nlsIsStrNull(JTHostNm))
													{
														JTHostNmDup=nlsStrDup(JTHostNm);
													}
													else
													{
														JTHostNmDup=nlsStrDup("-");
													}
													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
													if(!nlsIsStrNull(JTSiteNm))
													{
														JTSiteNmDup=nlsStrDup(JTSiteNm);
													}
													else
													{
														JTSiteNmDup=nlsStrDup("-");
													}
												}
											}
											else
											{
												printf("\t....JTdocClass: %s.........no Cad data available in PLM",JTdocClass);

												JTRelativePathDup=nlsStrDup("");
											}
										}

										if(!nlsIsStrNull(JTRelativePathDup))
										{
											fprintf(fp,"%s,",JTRelativePathDup); fflush(fp);	//RelativePath		//1
											fprintf(fp,"%s,",JTWRelativePathDup); fflush(fp);	//WRelativePath		//2
											fprintf(fp,"%s,",OwnerDirNameJTDup); fflush(fp);	//OwnerDirNam		//3
											fprintf(fp,"%s,",JTOwnerNameDup); fflush(fp);		//OwnerName			//4
											fprintf(fp,"%s,",InstClassDup); fflush(fp);			//InstClass			//5
											fprintf(fp,"%s,",TCRevisionDup); fflush(fp);		//TCRevision		//6
											fprintf(fp,"%s,",PartNumberDup); fflush(fp);		//PartNumber		//7
											fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);	//proAsmDisplayNm	//8
											fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);		//ApplnOwner		//9
											fprintf(fp,"%s,",JTfullPathDup); fflush(fp);		//JTfullPath		//10
											fprintf(fp,"%s,",JTHostNmDup); fflush(fp);			//JTHostNm			//11
											fprintf(fp,"%s,",JTSiteNmDup); fflush(fp);			//JTSiteNm			//12
											fprintf(fp,"\n");
											fflush(fp);
										}
									}
									else
									{
										printf("\n\t ProeDataItemSO not Found"); fflush(stdout);
									}
								}
								else
								{
									printf("\n\t doubt 111111111111111111111111111"); fflush(stdout);

									if(dstat = ExpandObject2(ProDepndClass,NewDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail)) goto CLEANUP;
									if(SetFlagforScope(ProeInstDepOnSO)==1)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										if(dstat = ExpandObject2(ProDepndClass,NewDataItemObjP,"ProDependentOn",SC_SCOPE_OF_SESSION,&ProeInstDepOnSO,&ProeInstDepOnRelSO,mfail)) goto CLEANUP;
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
									}
									printf("\n\t Number of ProPrtI Generic Objects: %d",setSize(ProeInstDepOnSO)); fflush(stdout);

									temp1 = nlsStrAlloc(100);
									temp2 = nlsStrAlloc(100);	//PartNumberDup

									temp1 = strtok(DataItemDisplayNmDup2,"<");
									temp2 = strtok(NULL,">");	//PartNumberDup


									if(nlsStrStr(wrelativepathDup1,".") !=NULL)
									{
										asmInstanceS = strtok(wrelativepathDup1,".");
									}

									if(setSize(ProeInstDepOnSO)>0)
									{
										for(pi=0;pi<setSize(ProeInstDepOnSO);pi++)
										{
											t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
											proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);

											printf("\n\t ProPrtI...proAsmDisplayNmDupS:[%s] asmInstanceS:[%s]",proAsmDisplayNmDupS,asmInstanceS); fflush(stdout);
											if(nlsStrStr(proAsmDisplayNmDupS,asmInstanceS) !=NULL )
											{
												printf("\n\t ProPrtI...Match Found "); fflush(stdout);
												//Added on 02.10.2015 by RRR
												strcpy(tempstr,"");
												strcpy(tempstr,asmInstanceS);

												tmpStrlen = strlen(tempstr);
												//printf ("\n\t tmpStrlen  %d",tmpStrlen);
												for(i=0;i<tmpStrlen;i++)
												{
													if (!isdigit(tempstr[i]))
													{
														//printf ("\n\t alpha");
														charFlag = 1;
														printf ("\n\t charFlag %d found hence skipping\n\n",charFlag);
														break;
													}
												}

												if (charFlag == 1)
												{
													filestr = low_set_read_file("/user/omfprod/devgroups/UALoading/TMLtocmitest/ProE/ListofPLMGenericParts.txt");
													printf("\n\t Total content - %d\n",setSize(filestr));fflush(stdout);

													for(lcnt=0;lcnt<setSize(filestr);lcnt++)
													{
														if(nlsStrCmp(proAsmDisplayNmDupS,setGet(filestr,lcnt))==0)
														{
															printf("\n\t ProPrtI...Match Found in file for %s and %s ",proAsmDisplayNmDupS,setGet(filestr,lcnt)); fflush(stdout);
															GenericFlag = 1;

															break;
														}
														else if (nlsStrStr(setGet(filestr,lcnt),asmInstanceS)!=NULL)	//added on 26.10.2016 by RRR
														{
															//printf("\n In else "); fflush(stdout);
															low_set_add_str(GenInst, setGet(filestr,lcnt));
														}
													}
													printf("\n\t ProPrtI...GenericFlag:: %d",GenericFlag); fflush(stdout);

													if (low_set_size(GenInst) > 0)	//added on 26.10.2016 by RRR
													{
														GenInstanceFlag = 0;
														for (ii=0; ii<low_set_size(GenInst); ii++)
														{
															//docobjst=low_set_get(GenInst,ii);
															//printf("\n DB pref check -after... :%s",docobjst);fflush(stdout);
															printf("\n low_set_get(GenInst,ii):: %s",low_set_get(GenInst,ii));fflush(stdout);

															temp5 = nlsStrAlloc(50);
															temp6 = nlsStrAlloc(50);

															nlsStrCpy(temp5,low_set_get(GenInst,ii));
															nlsStrCpy(temp6,low_set_get(GenInst,ii));

															if (nlsStrCmp(strtok(temp5,"."),asmInstanceS)==0)
															{
																GenInstanceFlag = 1;
																printf("... ProPrtI...Match Found"); fflush(stdout);
																break;
															}
														}
													}

													if (GenericFlag ==0)
													{
														asmInstanceS2 = nlsStrAlloc(50);

														nlsStrCpy(asmInstanceS2,asmInstanceS);
														nlsStrCat(asmInstanceS2,"%");

														t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",asmInstanceS2));
														t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Superseded","-"));
														t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
														t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
														//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
														t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

														printf("\n\t ProeGenDataItemSO: %d\n",setSize(ProeGenDataItemSO));fflush(stdout);

														if(setSize(ProeGenDataItemSO) == 0)		//added on 26.10.2016 by RRR
														{
															if (GenInstanceFlag == 1)
															{
																t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
																t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",temp6));
																t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
																//t5CheckDstat(oiSqlWhereEQ(ProeObjSqlPtr,"Superseded","-"));
																//t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
																t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
																//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
																//t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
																//t5CheckMfail(QueryWhere(ProInstClass,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
																t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

																printf("\n 11.ProeGenDataItemSO: %d   \n",setSize(ProeGenDataItemSO));fflush(stdout);
															}
															else
															{
																t5CheckDstat(oiSqlCreateSelect(&ProeObjSqlPtr));
																t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"RelativePath",asmInstanceS2));
																//t5CheckDstat(oiSqlWhereAND(ProeObjSqlPtr));
																//t5CheckDstat(oiSqlWhereLike(ProeObjSqlPtr,"OwnerName","%Vault"));
																//t5CheckDstat(oiSqlDescOrder(ProeObjSqlPtr,"CreationDate"));
																//t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
																//t5CheckMfail(QueryWhere(ProInstClass,ProeObjSqlPtr,&ProeGenDataItemSO,mfail));
																t5CheckMfail(QueryWhere("ProObj",ProeObjSqlPtr,&ProeGenDataItemSO,mfail));

																printf("\n 12.ProeGenDataItemSO: %d   [%s]\n",setSize(ProeGenDataItemSO),asmInstanceS2);fflush(stdout);
															}
														}

														if(setSize(ProeGenDataItemSO)>0)
														{
															PrtIObjP=setGet(ProeGenDataItemSO,0);

															//if(dstat=objCopy(&PrtIObjP,PrtGObjP)) goto EXIT;
														}
													}
													else if (GenericFlag ==1)
													{
														printf("\n\t ....111...");fflush(stdout);

														PrtIObjP=setGet(ProeInstDepOnSO,pi);

														t5CheckDstat(objGetAttribute(setGet(ProeInstDepOnSO,pi),DisplayedNameAttr,&proAsmDisplayNmS));
														proAsmDisplayNmDupS=nlsStrDup(proAsmDisplayNmS);

														printf("\n\t 11.ProPrtI...proAsmDisplayNmDupS:[%s] asmInstanceS:[%s]",proAsmDisplayNmDupS,asmInstanceS); fflush(stdout);
													}
												}
												else
												{
													printf("\n\t ....122...");fflush(stdout);
													PrtIObjP=setGet(ProeInstDepOnSO,pi);
												}
												break;
											}
										}

										if (PrtIObjP != NULL)
										{
											t5CheckDstat(objGetAttribute(PrtIObjP,"RelativePath",&cadRelativePath));
											if(!nlsIsStrNull(cadRelativePath))
											{
												cadRelativePathDup=nlsStrDup(cadRelativePath);
											}

											t5CheckDstat(objGetAttribute(PrtIObjP,"WorkingRelativePath",&cadWrelativepath));
											if(!nlsIsStrNull(cadWrelativepath))
											{
												cadWrelativepathDup=nlsStrDup(cadWrelativepath);
											}

											if(dstat = objGetAttribute(PrtIObjP,"OwnerDirName",&cadOwnerDirName)) goto CLEANUP;
											if(!nlsIsStrNull(cadOwnerDirName))
											{
												cadOwnerDirNameDup=nlsStrDup(cadOwnerDirName);
											}
											else
											{
												cadOwnerDirNameDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(PrtIObjP,"OwnerName",&cadOwnerName)) goto CLEANUP;
											if(!nlsIsStrNull(cadOwnerName))
											{
												cadOwnerNameDup=nlsStrDup(cadOwnerName);
											}
											else
											{
												cadOwnerNameDup=nlsStrDup("");
											}

											t5CheckDstat(GetInfoItem(PrtIObjP,&GetInfoCADIObjP,mfail));

											t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"FullPath",&cadfullPath)) ;
											if(!nlsIsStrNull(cadfullPath))
											{
												cadfullPathDup=nlsStrDup(cadfullPath);
											}
											else
											{
												cadfullPathDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"HostName",&CadHostNm)) ;
											if(!nlsIsStrNull(CadHostNm))
											{
												CadHostNmDup=nlsStrDup(CadHostNm);
											}
											else
											{
												CadHostNmDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"SiteName",&CadSiteNm)) ;
											if(!nlsIsStrNull(CadSiteNm))
											{
												CadSiteNmDup=nlsStrDup(CadSiteNm);
											}
											else
											{
												CadSiteNmDup=nlsStrDup("-");
											}
										}

										if((nlsStrCmp(docClass,"DesDoc") == 0) )
										{
											printf("\n\t ....125...");fflush(stdout);
											if (PrtIObjP != NULL)
											{
												if(dstat = ExpandObject5(GenVisClass,PrtIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
												if(SetFlagforScope(desDocJtObjs)==1)
												{
													if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
													if(dstat = ExpandObject5(GenVisClass,PrtIObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
													if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
												}
											}
											printf("\t setSize(desDocJtObjs): %d",setSize(desDocJtObjs));fflush(stdout);
										}
										if(setSize(desDocJtObjs)>0)
										{
											JTPartObjP=setGet(desDocJtObjs,0);

											if(dstat = objGetAttribute(JTPartObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
											if(!nlsIsStrNull(JTRelativePath))
											{
												JTRelativePathDup=nlsStrDup(JTRelativePath);
											}
											else
											{
												JTRelativePathDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
											if(!nlsIsStrNull(JTWRelativePath))
											{
												JTWRelativePathDup=nlsStrDup(JTWRelativePath);
											}
											else
											{
												JTWRelativePathDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
											if(!nlsIsStrNull(OwnerDirNameJT))
											{
												OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
											}
											else
											{
												OwnerDirNameJTDup=nlsStrDup("");
											}

											if(dstat = objGetAttribute(JTPartObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
											if(!nlsIsStrNull(JTOwnerName))
											{
												JTOwnerNameDup=nlsStrDup(JTOwnerName);
											}
											else
											{
												JTOwnerNameDup=nlsStrDup("");
											}

											t5CheckDstat(GetInfoItem(JTPartObjP,&GetInfoJTPartObjP,mfail));

											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
											if(!nlsIsStrNull(JTfullPath))
											{
												JTfullPathDup=nlsStrDup(JTfullPath);
											}
											else
											{
												JTfullPathDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
											if(!nlsIsStrNull(JTHostNm))
											{
												JTHostNmDup=nlsStrDup(JTHostNm);
											}
											else
											{
												JTHostNmDup=nlsStrDup("-");
											}
											t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
											if(!nlsIsStrNull(JTSiteNm))
											{
												JTSiteNmDup=nlsStrDup(JTSiteNm);
											}
											else
											{
												JTSiteNmDup=nlsStrDup("-");
											}
										}
										else
										{
											JTdocClass = low_getspace(20);

											//printf("\n\t .........................................\n");
											//objDump(PrtIObjP);
											//printf("\n\t .........................................");

											if (PrtIObjP != NULL)
											{
												if(dstat = objGetAttribute(PrtIObjP,ClassAttr,&JTdocClassDup)) goto CLEANUP;
												if(!nlsIsStrNull(JTdocClassDup))
												{
													JTdocClass = nlsStrDup(JTdocClassDup);
												}

												if((nlsStrCmp(JTdocClass,"JT")==0))
												{
													printf("\n\t JTdocClass: %s",JTdocClass);

													if(dstat = objGetAttribute(PrtIObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
													if(!nlsIsStrNull(JTRelativePath))
													{
														JTRelativePathDup=nlsStrDup(JTRelativePath);
													}
													else
													{
														JTRelativePathDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(PrtIObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
													if(!nlsIsStrNull(JTWRelativePath))
													{
														JTWRelativePathDup=nlsStrDup(JTWRelativePath);
													}
													else
													{
														JTWRelativePathDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(PrtIObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
													if(!nlsIsStrNull(OwnerDirNameJT))
													{
														OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
													}
													else
													{
														OwnerDirNameJTDup=nlsStrDup("");
													}

													if(dstat = objGetAttribute(PrtIObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
													if(!nlsIsStrNull(JTOwnerName))
													{
														JTOwnerNameDup=nlsStrDup(JTOwnerName);
													}
													else
													{
														JTOwnerNameDup=nlsStrDup("");
													}

													t5CheckDstat(GetInfoItem(PrtIObjP,&GetInfoJTPartObjP,mfail));

													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
													if(!nlsIsStrNull(JTfullPath))
													{
														JTfullPathDup=nlsStrDup(JTfullPath);
													}
													else
													{
														JTfullPathDup=nlsStrDup("-");
													}
													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
													if(!nlsIsStrNull(JTHostNm))
													{
														JTHostNmDup=nlsStrDup(JTHostNm);
													}
													else
													{
														JTHostNmDup=nlsStrDup("-");
													}
													t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
													if(!nlsIsStrNull(JTSiteNm))
													{
														JTSiteNmDup=nlsStrDup(JTSiteNm);
													}
													else
													{
														JTSiteNmDup=nlsStrDup("-");
													}
												}
											}
											else
											{
												printf("\t....JTdocClass: %s.........no Cad data available in PLM",JTdocClass);

												JTRelativePathDup=nlsStrDup("");
											}
										}

										if(!nlsIsStrNull(JTRelativePathDup))
										{
											fprintf(fp,"%s,",JTRelativePathDup); fflush(fp);	//RelativePath		//1
											fprintf(fp,"%s,",JTWRelativePathDup); fflush(fp);	//WRelativePath		//2
											fprintf(fp,"%s,",OwnerDirNameJTDup); fflush(fp);	//OwnerDirNam		//3
											fprintf(fp,"%s,",JTOwnerNameDup); fflush(fp);		//OwnerName			//4
											fprintf(fp,"%s,",InstClassDup); fflush(fp);			//InstClass			//5
											fprintf(fp,"%s,",TCRevisionDup); fflush(fp);		//TCRevision		//6
											fprintf(fp,"%s,",temp2); fflush(fp);				//PartNumber		//7
											fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);	//proAsmDisplayNm	//8
											fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);		//ApplnOwner		//9
											fprintf(fp,"%s,",JTfullPathDup); fflush(fp);		//JTfullPath		//10
											fprintf(fp,"%s,",JTHostNmDup); fflush(fp);			//JTHostNm			//11
											fprintf(fp,"%s,",JTSiteNmDup); fflush(fp);			//JTSiteNm			//12
											fprintf(fp,"\n");
											fflush(fp);
										}
									}
								}
							}
							else
							{
								t5CheckDstat(objGetAttribute(NewDataItemObjP,"RelativePath",&cadRelativePath));
								if(!nlsIsStrNull(cadRelativePath))
								{
									cadRelativePathDup=nlsStrDup(cadRelativePath);
								}

								t5CheckDstat(objGetAttribute(NewDataItemObjP,"WorkingRelativePath",&cadWrelativepath));
								if(!nlsIsStrNull(cadWrelativepath))
								{
									cadWrelativepathDup=nlsStrDup(cadWrelativepath);
								}

								if(dstat = objGetAttribute(NewDataItemObjP,"OwnerDirName",&cadOwnerDirName)) goto CLEANUP;
								if(!nlsIsStrNull(cadOwnerDirName))
								{
									cadOwnerDirNameDup=nlsStrDup(cadOwnerDirName);
								}
								else
								{
									cadOwnerDirNameDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(NewDataItemObjP,"OwnerName",&cadOwnerName)) goto CLEANUP;
								if(!nlsIsStrNull(cadOwnerName))
								{
									cadOwnerNameDup=nlsStrDup(cadOwnerName);
								}
								else
								{
									cadOwnerNameDup=nlsStrDup("");
								}

								t5CheckDstat(GetInfoItem(NewDataItemObjP,&GetInfoCADIObjP,mfail));

								t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"FullPath",&cadfullPath)) ;
								if(!nlsIsStrNull(cadfullPath))
								{
									cadfullPathDup=nlsStrDup(cadfullPath);
								}
								else
								{
									cadfullPathDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"HostName",&CadHostNm)) ;
								if(!nlsIsStrNull(CadHostNm))
								{
									CadHostNmDup=nlsStrDup(CadHostNm);
								}
								else
								{
									CadHostNmDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"SiteName",&CadSiteNm)) ;
								if(!nlsIsStrNull(CadSiteNm))
								{
									CadSiteNmDup=nlsStrDup(CadSiteNm);
								}
								else
								{
									CadSiteNmDup=nlsStrDup("-");
								}
							}

							printf("\n\t CAD...%s,%s,%s,%s,%s,%s,%s,%s,%s",cadRelativePathDup,cadWrelativepathDup,cadOwnerDirNameDup,cadOwnerNameDup,InstClassDup,TCRevisionDup,PartNumberDup,DataItemDisplayNmDup,ApplnOwnerDup); fflush(stdout);

							if(!nlsIsStrNull(cadRelativePathDup))
							{
								fprintf(fpCad,"%s,",cadRelativePathDup); fflush(fpCad);		//CadRelativePath	//1
								fprintf(fpCad,"%s,",cadWrelativepathDup); fflush(fpCad);	//CadWRelativePath	//2
								fprintf(fpCad,"%s,",cadOwnerDirNameDup); fflush(fpCad);		//CadOwnerDirNam	//3
								fprintf(fpCad,"%s,",cadOwnerNameDup); fflush(fpCad);		//CadOwnerName		//4
								fprintf(fpCad,"%s,",InstClassDup); fflush(fpCad);			//InstClass			//5
								fprintf(fpCad,"%s,",TCRevisionDup); fflush(fpCad);			//TCRevision		//6
								fprintf(fpCad,"%s,",PartNumberDup); fflush(fpCad);			//PartNumber		//7
								fprintf(fpCad,"%s,",DataItemDisplayNmDup); fflush(fpCad);	//proAsmDisplayNm	//8
								fprintf(fpCad,"%s,",ApplnOwnerDup); fflush(fpCad);			//ApplnOwner		//9
								fprintf(fpCad,"%s,",cadfullPathDup); fflush(fpCad);			//CadfullPath		//10
								fprintf(fpCad,"%s,",CadHostNmDup); fflush(fpCad);			//CadHostNm			//11
								fprintf(fpCad,"%s,",CadSiteNmDup); fflush(fpCad);			//CadSiteNm			//12
								fprintf(fpCad,"\n");
								fflush(fpCad);
							}

							if((nlsStrStr(DataItemDisplayNmDup,".asm")!=NULL) || (nlsStrStr(DataItemDisplayNmDup,".prt")!=NULL) ||(nlsStrStr(DataItemDisplayNmDup,".CATProduct")!=NULL) || (nlsStrStr(DataItemDisplayNmDup,".CATPart")!=NULL) ||((nlsStrCmp(InstClassDup,"ProPrtI")==0) || (nlsStrCmp(InstClassDup,"ProAsmI")==0)))
							{
								if((nlsStrCmp(docClass,"DesDoc") == 0) )
								{
									if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
									if(SetFlagforScope(desDocJtObjs)==1)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
									}
								}
								if(setSize(desDocJtObjs)>0)
								{
									JTPartObjP=setGet(desDocJtObjs,0);

									if(dstat = objGetAttribute(JTPartObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
									if(!nlsIsStrNull(JTRelativePath))
									{
										JTRelativePathDup=nlsStrDup(JTRelativePath);
									}
									else
									{
										JTRelativePathDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(JTPartObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
									if(!nlsIsStrNull(JTWRelativePath))
									{
										JTWRelativePathDup=nlsStrDup(JTWRelativePath);
									}
									else
									{
										JTWRelativePathDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
									if(!nlsIsStrNull(OwnerDirNameJT))
									{
										OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
									}
									else
									{
										OwnerDirNameJTDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(JTPartObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
									if(!nlsIsStrNull(JTOwnerName))
									{
										JTOwnerNameDup=nlsStrDup(JTOwnerName);
									}
									else
									{
										JTOwnerNameDup=nlsStrDup("");
									}

									t5CheckDstat(GetInfoItem(JTPartObjP,&GetInfoJTPartObjP,mfail));

									t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
									if(!nlsIsStrNull(JTfullPath))
									{
										JTfullPathDup=nlsStrDup(JTfullPath);
									}
									else
									{
										JTfullPathDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
									if(!nlsIsStrNull(JTHostNm))
									{
										JTHostNmDup=nlsStrDup(JTHostNm);
									}
									else
									{
										JTHostNmDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
									if(!nlsIsStrNull(JTSiteNm))
									{
										JTSiteNmDup=nlsStrDup(JTSiteNm);
									}
									else
									{
										JTSiteNmDup=nlsStrDup("-");
									}

									//App Depends on JT download is commented on 30.08.2017 as it is already downloading in respective revision folder.
									/*if(dstat = ExpandObject5(AppDepndClass,JTPartObjP,"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&JTAppDependOnSO,mfail)) goto CLEANUP;
									if(SetFlagforScope(JTAppDependOnSO)==1)
									{
										if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
										if(dstat = ExpandObject5(AppDepndClass,JTPartObjP,"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&JTAppDependOnSO,mfail)) goto CLEANUP;
										if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
									}
									if(setSize(JTAppDependOnSO)>0)
									{
										jtcnt=setSize(JTAppDependOnSO);
										printf("\n JT App Depends On Found: [%d]",jtcnt); fflush(stdout);

										for(i=0;i<jtcnt;i++)
										{
											appdepjtPtr =setGet(JTAppDependOnSO,i);

											if(dstat = objGetAttribute(appdepjtPtr,ClassAttr,&classNameDupS)) goto CLEANUP;
											if(!nlsIsStrNull(classNameDupS))
											{
												classNameS = nlsStrDup(classNameDupS);
											}
											//printf("\nClass of Object= %s  ", classNameS); fflush(stdout);

											if(dstat = objGetAttribute(appdepjtPtr,WorkingRelativePathAttr,&workingrelPath)) goto CLEANUP;
											if(!nlsIsStrNull(workingrelPath))
											{
												workingrelPathDup=nlsStrDup(workingrelPath);
											}
											else
											{
												continue;
											}

											if((nlsStrStr(workingrelPathDup,"ALF") != NULL) || (nlsStrStr(workingrelPathDup,"WELD") != NULL))
											{
												printf("\nClass of Object= %s	  workingrelPathDup: %s",classNameS,workingrelPathDup); fflush(stdout);

												if(dstat = objGetAttribute(appdepjtPtr,"RelativePath",&AlfJTRelativePath)) goto CLEANUP;
												if(!nlsIsStrNull(JTRelativePath))
												{
													AlfJTRelativePathDup=nlsStrDup(AlfJTRelativePath);
												}
												else
												{
													AlfJTRelativePathDup=nlsStrDup("");
												}

												if(dstat = objGetAttribute(appdepjtPtr,"WorkingRelativePath",&AlfJTWRelativePath)) goto CLEANUP;
												if(!nlsIsStrNull(AlfJTWRelativePath))
												{
													AlfJTWRelativePathDup=nlsStrDup(AlfJTWRelativePath);
												}
												else
												{
													AlfJTWRelativePathDup=nlsStrDup("");
												}

												if(dstat = objGetAttribute(appdepjtPtr,"OwnerDirName",&AlfJTOwnerDirName)) goto CLEANUP;
												if(!nlsIsStrNull(AlfJTOwnerDirName))
												{
													AlfJTOwnerDirNameDup=nlsStrDup(AlfJTOwnerDirName);
												}
												else
												{
													AlfJTOwnerDirNameDup=nlsStrDup("");
												}

												if(dstat = objGetAttribute(appdepjtPtr,"OwnerName",&AlfJTOwnerName)) goto CLEANUP;
												if(!nlsIsStrNull(AlfJTOwnerName))
												{
													AlfJTOwnerNameDup=nlsStrDup(AlfJTOwnerName);
												}
												else
												{
													JTOwnerNameDup=nlsStrDup("");
												}

												t5CheckDstat(GetInfoItem(appdepjtPtr,&GetInfoJTPartObjP,mfail));

												t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
												if(!nlsIsStrNull(JTfullPath))
												{
													JTfullPathDup=nlsStrDup(JTfullPath);
												}
												else
												{
													JTfullPathDup=nlsStrDup("-");
												}
												t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
												if(!nlsIsStrNull(JTHostNm))
												{
													JTHostNmDup=nlsStrDup(JTHostNm);
												}
												else
												{
													JTHostNmDup=nlsStrDup("-");
												}
												t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
												if(!nlsIsStrNull(JTSiteNm))
												{
													JTSiteNmDup=nlsStrDup(JTSiteNm);
												}
												else
												{
													JTSiteNmDup=nlsStrDup("-");
												}

												if(!nlsIsStrNull(AlfJTRelativePathDup))
												{
													fprintf(fp,"%s,",AlfJTRelativePathDup); fflush(fp);		//RelativePath		//1
													fprintf(fp,"%s,",AlfJTWRelativePathDup); fflush(fp);	//WRelativePath		//2
													fprintf(fp,"%s,",AlfJTOwnerDirNameDup); fflush(fp);		//OwnerDirNam		//3
													fprintf(fp,"%s,",AlfJTOwnerNameDup); fflush(fp);		//OwnerName			//4
													fprintf(fp,"%s,",InstClassDup); fflush(fp);				//InstClass			//5
													fprintf(fp,"%s,",TCRevisionDup); fflush(fp);			//TCRevision		//6
													fprintf(fp,"%s,",PartNumberDup); fflush(fp);			//PartNumber		//7
													fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);		//proAsmDisplayNm	//8
													fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);			//ApplnOwner		//9
													fprintf(fp,"%s,",JTfullPathDup); fflush(fp);			//JTfullPath		//10
													fprintf(fp,"%s,",JTHostNmDup); fflush(fp);				//JTHostNm			//11
													fprintf(fp,"%s,",JTSiteNmDup); fflush(fp);				//JTSiteNm			//12
													fprintf(fp,"\n");
													fflush(fp);
												}
											}
										}
									}*/
								}
								else
								{
									JTdocClass = low_getspace(20);

									if(dstat = objGetAttribute(NewDataItemObjP,ClassAttr,&JTdocClassDup)) goto CLEANUP;
									if(!nlsIsStrNull(JTdocClassDup))
									{
										JTdocClass = nlsStrDup(JTdocClassDup);
									}

									if((nlsStrCmp(JTdocClass,"JT")==0))
									{
										printf("\n\t JTdocClass: %s",JTdocClass);

										if(dstat = objGetAttribute(NewDataItemObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
										if(!nlsIsStrNull(JTRelativePath))
										{
											JTRelativePathDup=nlsStrDup(JTRelativePath);
										}
										else
										{
											JTRelativePathDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(NewDataItemObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
										if(!nlsIsStrNull(JTWRelativePath))
										{
											JTWRelativePathDup=nlsStrDup(JTWRelativePath);
										}
										else
										{
											JTWRelativePathDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(NewDataItemObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
										if(!nlsIsStrNull(OwnerDirNameJT))
										{
											OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
										}
										else
										{
											OwnerDirNameJTDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(NewDataItemObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
										if(!nlsIsStrNull(JTOwnerName))
										{
											JTOwnerNameDup=nlsStrDup(JTOwnerName);
										}
										else
										{
											JTOwnerNameDup=nlsStrDup("");
										}

										t5CheckDstat(GetInfoItem(NewDataItemObjP,&GetInfoJTPartObjP,mfail));

										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
										if(!nlsIsStrNull(JTfullPath))
										{
											JTfullPathDup=nlsStrDup(JTfullPath);
										}
										else
										{
											JTfullPathDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
										if(!nlsIsStrNull(JTHostNm))
										{
											JTHostNmDup=nlsStrDup(JTHostNm);
										}
										else
										{
											JTHostNmDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
										if(!nlsIsStrNull(JTSiteNm))
										{
											JTSiteNmDup=nlsStrDup(JTSiteNm);
										}
										else
										{
											JTSiteNmDup=nlsStrDup("-");
										}
									}
								}

								if(!nlsIsStrNull(JTRelativePathDup))
								{
									if(nlsStrStr(DataItemDisplayNmDup,".asm.") != NULL)		//Added on 30.08.2017
									{
										fprintf(fpAsmJt,"%s,",JTRelativePathDup); fflush(fpAsmJt);		//RelativePath		//1
										fprintf(fpAsmJt,"%s,",JTWRelativePathDup); fflush(fpAsmJt);		//WRelativePath		//2
										fprintf(fpAsmJt,"%s,",OwnerDirNameJTDup); fflush(fpAsmJt);		//OwnerDirNam		//3
										fprintf(fpAsmJt,"%s,",JTOwnerNameDup); fflush(fpAsmJt);			//OwnerName			//4
										fprintf(fpAsmJt,"%s,",InstClassDup); fflush(fpAsmJt);			//InstClass			//5
										fprintf(fpAsmJt,"%s,",TCRevisionDup); fflush(fpAsmJt);			//TCRevision		//6
										fprintf(fpAsmJt,"%s,",PartNumberDup); fflush(fpAsmJt);			//PartNumber		//7
										fprintf(fpAsmJt,"%s,",DataItemDisplayNmDup); fflush(fpAsmJt);	//proAsmDisplayNm	//8
										fprintf(fpAsmJt,"%s,",ApplnOwnerDup); fflush(fpAsmJt);			//ApplnOwner		//9
										fprintf(fpAsmJt,"%s,",JTfullPathDup); fflush(fpAsmJt);			//JTfullPath		//10
										fprintf(fpAsmJt,"%s,",JTHostNmDup); fflush(fpAsmJt);			//JTHostNm			//11
										fprintf(fpAsmJt,"%s,",JTSiteNmDup); fflush(fpAsmJt);			//JTSiteNm			//12
										fprintf(fpAsmJt,"\n");
										fflush(fpAsmJt);
									}
									else
									{
										fprintf(fp,"%s,",JTRelativePathDup); fflush(fp);		//RelativePath		//1
										fprintf(fp,"%s,",JTWRelativePathDup); fflush(fp);		//WRelativePath		//2
										fprintf(fp,"%s,",OwnerDirNameJTDup); fflush(fp);		//OwnerDirNam		//3
										fprintf(fp,"%s,",JTOwnerNameDup); fflush(fp);			//OwnerName			//4
										fprintf(fp,"%s,",InstClassDup); fflush(fp);				//InstClass			//5
										fprintf(fp,"%s,",TCRevisionDup); fflush(fp);			//TCRevision		//6
										fprintf(fp,"%s,",PartNumberDup); fflush(fp);			//PartNumber		//7
										fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);		//proAsmDisplayNm	//8
										fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);			//ApplnOwner		//9
										fprintf(fp,"%s,",JTfullPathDup); fflush(fp);			//JTfullPath		//10
										fprintf(fp,"%s,",JTHostNmDup); fflush(fp);				//JTHostNm			//11
										fprintf(fp,"%s,",JTSiteNmDup); fflush(fp);				//JTSiteNm			//12
										fprintf(fp,"\n");
										fflush(fp);
									}
								}
								else
								{
									printf("\nJTRelativePathDup is null...for %s , %s , %s",DataItemDisplayNmDup,PartNumberDup,TCRevisionDup); fflush(stdout);
								}
							}
							else /*if (nlsStrStr(DataItemDisplayNmDup,"x0CatPrt")!=NULL)*/
							{
								continue;
							}
						//}
					}
					else
					{
						printf("  ....DataItemJtSO CAD data not Found attached for for [%s  ,%s , %s] \n",part_no,PartRev,PartSeq); fflush(stdout);
					}
				}
				else if((nlsStrCmp(docClass,"DesDoc") != 0) )
				{
					if(setSize(DataItemJtSO)>0)
					{
						NewDataItemObjP=setGet(DataItemJtSO,0);

						if(dstat = objGetAttribute(NewDataItemObjP,"DisplayedName",&DataItemDisplayNm)) goto CLEANUP;
						if(!nlsIsStrNull(DataItemDisplayNm))
						{
							DataItemDisplayNmDup=nlsStrDup(DataItemDisplayNm);
							DataItemDisplayNmDup2=nlsStrDup(DataItemDisplayNm);
						}
						else
						{
							DataItemDisplayNmDup=nlsStrDup("");
							DataItemDisplayNmDup2=nlsStrDup("");
						}
						printf("\n\t %s..DataItemDisplayNmDup:[%s]",docClass,DataItemDisplayNmDup);fflush(stdout);

						if(dstat = objGetAttribute(NewDataItemObjP,"Class",&InstClass)) goto CLEANUP;
						if(!nlsIsStrNull(InstClass))
						{
							InstClassDup=nlsStrDup(InstClass);
						}
						else
						{
							InstClassDup=nlsStrDup("");
						}

						printf("\n\t %s..InstClassDup:[%s]",docClass,InstClassDup);fflush(stdout);

						if((DesDocFlag == 0) && (nlsStrCmp(docClass,"x0PrdDoc") == 0) && (nlsStrCmp(InstClassDup,"x0CatPrd") == 0) ) // added on 16.01.2016
						{
							if(dstat = objGetAttribute (DocOPtr, "t5DocumentType1", &ApplnOwner)) goto CLEANUP;
							if(!nlsIsStrNull(ApplnOwner))
							{
								ApplnOwnerDup = nlsStrDup(ApplnOwner);
							}

							printf("   ApplnOwnerDup:%s",ApplnOwnerDup); fflush(stdout);
						}

						t5CheckDstat(objGetAttribute(NewDataItemObjP,"RelativePath",&cadRelativePath));
						if(!nlsIsStrNull(cadRelativePath))
						{
							cadRelativePathDup=nlsStrDup(cadRelativePath);
						}

						t5CheckDstat(objGetAttribute(NewDataItemObjP,"WorkingRelativePath",&cadWrelativepath));
						if(!nlsIsStrNull(cadWrelativepath))
						{
							cadWrelativepathDup=nlsStrDup(cadWrelativepath);
						}

						if(dstat = objGetAttribute(NewDataItemObjP,"OwnerDirName",&cadOwnerDirName)) goto CLEANUP;
						if(!nlsIsStrNull(cadOwnerDirName))
						{
							cadOwnerDirNameDup=nlsStrDup(cadOwnerDirName);
						}
						else
						{
							cadOwnerDirNameDup=nlsStrDup("");
						}

						if(dstat = objGetAttribute(NewDataItemObjP,"OwnerName",&cadOwnerName)) goto CLEANUP;
						if(!nlsIsStrNull(cadOwnerName))
						{
							cadOwnerNameDup=nlsStrDup(cadOwnerName);
						}
						else
						{
							cadOwnerNameDup=nlsStrDup("");
						}

						t5CheckDstat(GetInfoItem(NewDataItemObjP,&GetInfoCADIObjP,mfail));

						t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"FullPath",&cadfullPath)) ;
						if(!nlsIsStrNull(cadfullPath))
						{
							cadfullPathDup=nlsStrDup(cadfullPath);
						}
						else
						{
							cadfullPathDup=nlsStrDup("-");
						}
						t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"HostName",&CadHostNm)) ;
						if(!nlsIsStrNull(CadHostNm))
						{
							CadHostNmDup=nlsStrDup(CadHostNm);
						}
						else
						{
							CadHostNmDup=nlsStrDup("-");
						}
						t5CheckDstat(objGetAttribute(GetInfoCADIObjP,"SiteName",&CadSiteNm)) ;
						if(!nlsIsStrNull(CadSiteNm))
						{
							CadSiteNmDup=nlsStrDup(CadSiteNm);
						}
						else
						{
							CadSiteNmDup=nlsStrDup("-");
						}

						if(dstat = objGetAttribute(NewDataItemObjP,"Sequence",&DISeq)) goto CLEANUP;
						if(!nlsIsStrNull(DISeq))
						{
							DISeqDup = nlsStrDup(DISeq);
						}

						if(!nlsIsStrNull(cadRelativePathDup))
						{
							fprintf(fpCad,"%s,",cadRelativePathDup); fflush(fpCad);		//CadRelativePath	//1
							fprintf(fpCad,"%s,",cadWrelativepathDup); fflush(fpCad);	//CadWRelativePath	//2
							fprintf(fpCad,"%s,",cadOwnerDirNameDup); fflush(fpCad);		//CadOwnerDirNam	//3
							fprintf(fpCad,"%s,",cadOwnerNameDup); fflush(fpCad);		//CadOwnerName		//4
							fprintf(fpCad,"%s,",InstClassDup); fflush(fpCad);			//InstClass			//5
							fprintf(fpCad,"%s,",TCRevisionDup); fflush(fpCad);			//TCRevision		//6
							fprintf(fpCad,"%s,",PartNumberDup); fflush(fpCad);			//PartNumber		//7
							fprintf(fpCad,"%s,",DataItemDisplayNmDup); fflush(fpCad);	//proAsmDisplayNm	//8
							fprintf(fpCad,"%s,",ApplnOwnerDup); fflush(fpCad);			//ApplnOwner		//9
							fprintf(fpCad,"%s,",cadfullPathDup); fflush(fpCad);			//CadfullPath		//10
							fprintf(fpCad,"%s,",CadHostNmDup); fflush(fpCad);			//CadHostNm			//11
							fprintf(fpCad,"%s,",CadSiteNmDup); fflush(fpCad);			//CadSiteNm			//12
							fprintf(fpCad,"\n");
							fflush(fpCad);
						}

						printf("\n\t %s..DesDocFlag:[%d]  [%s]",docClass,DesDocFlag,InstClassDup);fflush(stdout);
						if((DesDocFlag == 0) && (nlsStrCmp(InstClassDup,"x0CatPrd") == 0) ) //original condition
						//if((DesDocFlag == 0) || (nlsStrCmp(docClass,"x0CatPrd") == 0) )	//changed on 16.01.2016 for part 277999000101 E 1 having descDoc and x0CatPrd
						{
							//add code to download JT file if attched to 'CATIA Product Document' and DesDoc is not avaible for assembly/TPL revision
 							//below logic is added on 16.01.2017

							if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
							if(SetFlagforScope(desDocJtObjs)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocJtObjs,mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}
							printf("\n\t %s..setSize(desDocJtObjs):[%d]",docClass,setSize(desDocJtObjs));fflush(stdout);

							if(setSize(desDocJtObjs)>0)
							{
								JTPartObjP=setGet(desDocJtObjs,0);

								if(dstat = objGetAttribute(JTPartObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(JTRelativePath))
								{
									JTRelativePathDup=nlsStrDup(JTRelativePath);
								}
								else
								{
									JTRelativePathDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(JTPartObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(JTWRelativePath))
								{
									JTWRelativePathDup=nlsStrDup(JTWRelativePath);
								}
								else
								{
									JTWRelativePathDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(JTPartObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
								if(!nlsIsStrNull(OwnerDirNameJT))
								{
									OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
								}
								else
								{
									OwnerDirNameJTDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(JTPartObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
								if(!nlsIsStrNull(JTOwnerName))
								{
									JTOwnerNameDup=nlsStrDup(JTOwnerName);
								}
								else
								{
									JTOwnerNameDup=nlsStrDup("");
								}

								t5CheckDstat(GetInfoItem(JTPartObjP,&GetInfoJTPartObjP,mfail));

								t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
								if(!nlsIsStrNull(JTfullPath))
								{
									JTfullPathDup=nlsStrDup(JTfullPath);
								}
								else
								{
									JTfullPathDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
								if(!nlsIsStrNull(JTHostNm))
								{
									JTHostNmDup=nlsStrDup(JTHostNm);
								}
								else
								{
									JTHostNmDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
								if(!nlsIsStrNull(JTSiteNm))
								{
									JTSiteNmDup=nlsStrDup(JTSiteNm);
								}
								else
								{
									JTSiteNmDup=nlsStrDup("-");
								}
							}
							else
							{
								JTdocClass = low_getspace(20);

								//printf("\n\t .........................................\n");
								//objDump(AsmIObjP);
								//printf("\n\t .........................................");

								if (AsmIObjP != NULL)
								{
									//if(dstat = objGetAttribute(setGet(ProeInstDepOnSO,0),ClassAttr,&JTdocClassDup)) goto CLEANUP;
									if(dstat = objGetAttribute(AsmIObjP,ClassAttr,&JTdocClassDup)) goto CLEANUP;
									if(!nlsIsStrNull(JTdocClassDup))
									{
										JTdocClass = nlsStrDup(JTdocClassDup);
									}

									if((nlsStrCmp(JTdocClass,"JT")==0))
									{
										printf("\n\t JTdocClass: %s",JTdocClass);

										if(dstat = objGetAttribute(AsmIObjP,"RelativePath",&JTRelativePath)) goto CLEANUP;
										if(!nlsIsStrNull(JTRelativePath))
										{
											JTRelativePathDup=nlsStrDup(JTRelativePath);
										}
										else
										{
											JTRelativePathDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(AsmIObjP,"WorkingRelativePath",&JTWRelativePath)) goto CLEANUP;
										if(!nlsIsStrNull(JTWRelativePath))
										{
											JTWRelativePathDup=nlsStrDup(JTWRelativePath);
										}
										else
										{
											JTWRelativePathDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(AsmIObjP,"OwnerDirName",&OwnerDirNameJT)) goto CLEANUP;
										if(!nlsIsStrNull(OwnerDirNameJT))
										{
											OwnerDirNameJTDup=nlsStrDup(OwnerDirNameJT);
										}
										else
										{
											OwnerDirNameJTDup=nlsStrDup("");
										}

										if(dstat = objGetAttribute(AsmIObjP,"OwnerName",&JTOwnerName)) goto CLEANUP;
										if(!nlsIsStrNull(JTOwnerName))
										{
											JTOwnerNameDup=nlsStrDup(JTOwnerName);
										}
										else
										{
											JTOwnerNameDup=nlsStrDup("");
										}

										t5CheckDstat(GetInfoItem(AsmIObjP,&GetInfoJTPartObjP,mfail));

										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"FullPath",&JTfullPath)) ;
										if(!nlsIsStrNull(JTfullPath))
										{
											JTfullPathDup=nlsStrDup(JTfullPath);
										}
										else
										{
											JTfullPathDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"HostName",&JTHostNm)) ;
										if(!nlsIsStrNull(JTHostNm))
										{
											JTHostNmDup=nlsStrDup(JTHostNm);
										}
										else
										{
											JTHostNmDup=nlsStrDup("-");
										}
										t5CheckDstat(objGetAttribute(GetInfoJTPartObjP,"SiteName",&JTSiteNm)) ;
										if(!nlsIsStrNull(JTSiteNm))
										{
											JTSiteNmDup=nlsStrDup(JTSiteNm);
										}
										else
										{
											JTSiteNmDup=nlsStrDup("-");
										}
									}
								}
							}

							printf("\n\n JTRelativePathDup:::::::::: %s,",JTRelativePathDup); fflush(stdout);

							if(!nlsIsStrNull(JTRelativePathDup))
							{
								fprintf(fp,"%s,",JTRelativePathDup); fflush(fp);		//RelativePath		//1
								fprintf(fp,"%s,",JTWRelativePathDup); fflush(fp);		//WRelativePath		//2
								fprintf(fp,"%s,",OwnerDirNameJTDup); fflush(fp);		//OwnerDirNam		//3
								fprintf(fp,"%s,",JTOwnerNameDup); fflush(fp);			//OwnerName			//4
								fprintf(fp,"%s,",InstClassDup); fflush(fp);				//InstClass			//5
								fprintf(fp,"%s,",TCRevisionDup); fflush(fp);			//TCRevision		//6
								fprintf(fp,"%s,",PartNumberDup); fflush(fp);			//PartNumber		//7
								fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);		//proAsmDisplayNm	//8
								fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);			//ApplnOwner		//9
								fprintf(fp,"%s,",JTfullPathDup); fflush(fp);			//JTfullPath		//10
								fprintf(fp,"%s,",JTHostNmDup); fflush(fp);				//JTHostNm			//11
								fprintf(fp,"%s,",JTSiteNmDup); fflush(fp);				//JTSiteNm			//12
								fprintf(fp,"\n");
								fflush(fp);
							}
						}

						if(nlsStrCmp(docClass,"t5DrwDoc") == 0)
						{
							if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocPDFObjs,mfail)) goto CLEANUP;
							if(SetFlagforScope(desDocPDFObjs)==1)
							{
								if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
								if(dstat = ExpandObject5(GenVisClass,NewDataItemObjP,"SourceOfVisualization",SC_SCOPE_OF_SESSION,&desDocPDFObjs,mfail)) goto CLEANUP;
								if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
							}

							if(setSize(desDocPDFObjs)>0)
							{
								PDFPartObjP=setGet(desDocPDFObjs,0);

								if(dstat = objGetAttribute(PDFPartObjP,"RelativePath",&PDFRelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(PDFRelativePath))
								{
									PDFRelativePathDup=nlsStrDup(PDFRelativePath);
								}
								else
								{
									PDFRelativePathDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(PDFPartObjP,"WorkingRelativePath",&PDFWRelativePath)) goto CLEANUP;
								if(!nlsIsStrNull(PDFWRelativePath))
								{
									PDFWRelativePathDup=nlsStrDup(PDFWRelativePath);
								}
								else
								{
									PDFWRelativePathDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(PDFPartObjP,"OwnerDirName",&OwnerDirNamePDF)) goto CLEANUP;
								if(!nlsIsStrNull(OwnerDirNamePDF))
								{
									OwnerDirNamePDFDup=nlsStrDup(OwnerDirNamePDF);
								}
								else
								{
									OwnerDirNamePDFDup=nlsStrDup("");
								}

								if(dstat = objGetAttribute(PDFPartObjP,"OwnerName",&PDFOwnerName)) goto CLEANUP;
								if(!nlsIsStrNull(PDFOwnerName))
								{
									PDFOwnerNameDup=nlsStrDup(PDFOwnerName);
								}
								else
								{
									PDFOwnerNameDup=nlsStrDup("");
								}

								t5CheckDstat(GetInfoItem(PDFPartObjP,&GetInfoPdfPartObjP,mfail));

								t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"FullPath",&PDFfullPath)) ;
								if(!nlsIsStrNull(PDFfullPath))
								{
									PDFfullPathDup=nlsStrDup(PDFfullPath);
								}
								else
								{
									PDFfullPathDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"HostName",&PDFHostNm)) ;
								if(!nlsIsStrNull(PDFHostNm))
								{
									PDFHostNmDup=nlsStrDup(PDFHostNm);
								}
								else
								{
									PDFHostNmDup=nlsStrDup("-");
								}
								t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"SiteName",&PDFSiteNm)) ;
								if(!nlsIsStrNull(PDFSiteNm))
								{
									PDFSiteNmDup=nlsStrDup(PDFSiteNm);
								}
								else
								{
									PDFSiteNmDup=nlsStrDup("-");
								}
							}
							else
							{
								PDFdocClass = low_getspace(20);

								if(dstat = objGetAttribute(NewDataItemObjP,ClassAttr,&PDFdocClassDup)) goto CLEANUP;
								if(!nlsIsStrNull(PDFdocClassDup))
								{
									PDFdocClass = nlsStrDup(PDFdocClassDup);
								}

								if((nlsStrCmp(PDFdocClass,"PdfFile")==0))
								{
									printf("\n\t PDFdocClass: %s",PDFdocClass);

									//objDump(NewDataItemObjP);

									if(dstat = objGetAttribute(NewDataItemObjP,"RelativePath",&PDFRelativePath)) goto CLEANUP;
									if(!nlsIsStrNull(PDFRelativePath))
									{
										PDFRelativePathDup=nlsStrDup(PDFRelativePath);
									}
									else
									{
										PDFRelativePathDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(NewDataItemObjP,"WorkingRelativePath",&PDFWRelativePath)) goto CLEANUP;
									if(!nlsIsStrNull(PDFWRelativePath))
									{
										PDFWRelativePathDup=nlsStrDup(PDFWRelativePath);
									}
									else
									{
										PDFWRelativePathDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(NewDataItemObjP,"OwnerDirName",&OwnerDirNamePDF)) goto CLEANUP;
									if(!nlsIsStrNull(OwnerDirNamePDF))
									{
										OwnerDirNamePDFDup=nlsStrDup(OwnerDirNamePDF);
									}
									else
									{
										OwnerDirNamePDFDup=nlsStrDup("");
									}

									if(dstat = objGetAttribute(NewDataItemObjP,"OwnerName",&PDFOwnerName)) goto CLEANUP;
									if(!nlsIsStrNull(PDFOwnerName))
									{
										PDFOwnerNameDup=nlsStrDup(PDFOwnerName);
									}
									else
									{
										PDFOwnerNameDup=nlsStrDup("");
									}

									t5CheckDstat(GetInfoItem(NewDataItemObjP,&GetInfoPdfPartObjP,mfail));

									//printf("\n\t GetInfoPdfPartObjP---------------------Before");
									//objDump(GetInfoPdfPartObjP);
									//printf("\n\t GetInfoPdfPartObjP---------------------After");

									t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"FullPath",&PDFfullPath)) ;
									if(!nlsIsStrNull(PDFfullPath))
									{
										PDFfullPathDup=nlsStrDup(PDFfullPath);
									}
									else
									{
										PDFfullPathDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"HostName",&PDFHostNm)) ;
									if(!nlsIsStrNull(PDFHostNm))
									{
										PDFHostNmDup=nlsStrDup(PDFHostNm);
									}
									else
									{
										PDFHostNmDup=nlsStrDup("-");
									}
									t5CheckDstat(objGetAttribute(GetInfoPdfPartObjP,"SiteName",&PDFSiteNm)) ;
									if(!nlsIsStrNull(PDFSiteNm))
									{
										PDFSiteNmDup=nlsStrDup(PDFSiteNm);
									}
									else
									{
										PDFSiteNmDup=nlsStrDup("-");
									}
								}
							}

							if((!nlsIsStrNull(PDFRelativePathDup)) && (!nlsIsStrNull(OwnerDirNamePDFDup)) && (!nlsIsStrNull(PDFOwnerNameDup)) )
							{
								fprintf(fp,"%s,",PDFRelativePathDup); fflush(fp);		//RelativePath		//1
								fprintf(fp,"%s,",PDFWRelativePathDup); fflush(fp);		//WRelativePath		//2
								fprintf(fp,"%s,",OwnerDirNamePDFDup); fflush(fp);		//OwnerDirNam		//3
								fprintf(fp,"%s,",PDFOwnerNameDup); fflush(fp);			//OwnerName			//4
								fprintf(fp,"%s,",InstClassDup); fflush(fp);				//InstClass			//5
								fprintf(fp,"%s,",TCRevisionDup); fflush(fp);			//TCRevision		//6
								fprintf(fp,"%s,",PartNumberDup); fflush(fp);			//PartNumber		//7
								fprintf(fp,"%s,",DataItemDisplayNmDup); fflush(fp);		//proAsmDisplayNm	//8
								fprintf(fp,"%s,",ApplnOwnerDup); fflush(fp);			//ApplnOwner		//9
								fprintf(fp,"%s,",PDFfullPathDup); fflush(fp);			//PDFfullPath		//10
								fprintf(fp,"%s,",PDFHostNmDup); fflush(fp);				//PDFHostNm			//11
								fprintf(fp,"%s,",PDFSiteNmDup); fflush(fp);				//PDFSiteNm			//12
								fprintf(fp,"\n");
								fflush(fp);
							}
						} //if(nlsStrCmp(docClass,"t5DrwDoc") == 0)
					} //if(setSize(DataItemJtSO)>0)
					else
					{
						InstClassDup=nlsStrDup("");
					}

					if(((nlsStrCmp(docClass,"t5MulCad") == 0) || (nlsStrCmp(docClass,"DesDoc") != 0)) && (nlsStrStr(InstClassDup,"ProAsm") != NULL))		//added on 18.11.2016
					{
						//download ProAssembly member bom for ProAsm to load in ProAssembly menber relation of dataset in UA

						fprintf(fpAsm,"%s,",cadRelativePathDup); fflush(fpAsm);
						fprintf(fpAsm,"%s,",cadWrelativepathDup); fflush(fpAsm);
						fprintf(fpAsm,"NULL,");fflush(fpAsm);
						fprintf(fpAsm,"%s,",DISeqDup);fflush(fpAsm);
						fprintf(fpAsm,"NULL,");fflush(fpAsm);
						fprintf(fpAsm,"%s,",cadOwnerDirNameDup); fflush(fpAsm);
						fprintf(fpAsm,"%s,",cadOwnerNameDup); fflush(fpAsm);
						fprintf(fpAsm,"NULL,");fflush(fpAsm);
						fprintf(fpAsm,"NULL,");fflush(fpAsm);
						fprintf(fpAsm,"0,");fflush(fpAsm);  //level
						fprintf(fpAsm,"%s,",InstClassDup); fflush(fpAsm);
						fprintf(fpAsm,"%s,",cadfullPathDup); fflush(fpAsm);
						fprintf(fpAsm,"%s,",CadHostNmDup); fflush(fpAsm);
						fprintf(fpAsm,"%s,",CadSiteNmDup); fflush(fpAsm);
						fprintf(fpAsm,"\n");
						fflush(fpAsm);
					} //if((nlsStrCmp(docClass,"t5MulCad") == 0) && (nlsStrStr(InstClassDup,"ProAsm") != NULL))
				}
			} // for loop end for setSize(LatestDocs)
		} //if end for setSize(LatestDocs)
		//} //for loop of setSize(PartSO)
	} //if(setSize(PartSO)>0)

	if(fp)
	{
		fclose(fp);
		fp = NULL;
	}
	if(fpCad)
	{
		fclose(fpCad);
		fpCad = NULL;
	}
	if(fpAsm)
	{
		fclose(fpAsm);
		fpAsm = NULL;
	}
	if(fpAsmJt)
	{
		fclose(fpAsmJt);
		fpAsmJt = NULL;
	}

CLEANUP:
	printf("\n"); fflush(stdout);
	//printf("\n CLEANUP at TmlGetAllTCRevJTCadDrg .\n");
	if(fp)
	{
		fclose(fp);
		fp = NULL;
	}
	if(fpCad)
	{
		fclose(fpCad);
		fpCad = NULL;
	}
	if(fpAsm)
	{
		fclose(fpAsm);
		fpAsm = NULL;
	}
	if(fpAsmJt)
	{
		fclose(fpAsmJt);
		fpAsmJt = NULL;
	}

	t5PrintCleanUpModName;

EXIT:
	//printf("\n EXIT at TmlGetAllTCRevJTCadDrg..\n");
	t5CheckDstatAndReturn;
};
/*status t5SortBOMObjsByDate(SetOfObjects *itemObjs,SetOfObjects *relObjs,integer* mfail)
{
	status dstat = OKAY;
	char *mod_name = "t5SortBOMObjsByDate";
	SetOfObjects tmpItemObjs = NULL;
	SetOfObjects tmpRelObjs = NULL;
	ObjectPtr relObj = NULL;
	ObjectPtr itemObj = NULL;
	ObjectPtr relTObj = NULL;
	ObjectPtr itemTObj = NULL;
	integer count = 0;
	integer cmpCount = 0;
	ObjectPtr tmpRelObj = 0;
	string curCreDate = NULL;
	string tmpcurCreDate = NULL;
	string cmpCreDate = NULL;
	string tmpcmpCreDate = NULL;
	*mfail = USC_OKAY;

	for(count=0; count<setSize(*relObjs); count++)
	{
		itemObj = setGet(*itemObjs, count);
		relObj = setGet(*relObjs, count);

		// initalizing sorted object set
		if(count == 0)
		{
			if(dstat = ulyCopyObjectToSet(itemObj, &tmpItemObjs)) goto CLEANUP;
			if(dstat = ulyCopyObjectToSet(relObj, &tmpRelObjs)) goto CLEANUP;
			continue;
		}

		if(dstat = objCopy(&relTObj, relObj)) goto CLEANUP;
		if(dstat = objCopy(&itemTObj, itemObj)) goto CLEANUP;

		// get mainSerial
		if(dstat = objGetAttribute(relObj, CreationDateAttr, &curCreDate)) goto CLEANUP;
		tmpcurCreDate = nlsStrDup(curCreDate);

		// compare mainSerial with the new set of objects
		for(cmpCount=0; cmpCount<setSize(tmpRelObjs); cmpCount++)
		{
			tmpRelObj = setGet(tmpRelObjs, cmpCount);

			if(dstat = objGetAttribute(tmpRelObj, CreationDateAttr, &cmpCreDate)) goto CLEANUP;
			tmpcmpCreDate = nlsStrDup(cmpCreDate);

			if(nlsStrCmp(tmpcurCreDate,tmpcmpCreDate) <= 0)
			{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
				break;
			}
		}
		if(cmpCount == setSize(tmpRelObjs))
		{
				low_set_insrt(tmpRelObjs, cmpCount, relTObj);
				low_set_insrt(tmpItemObjs, cmpCount, itemTObj);
		}
	}
	// free memory and assign to new set sorted objects
	objDisposeAll(*itemObjs); *itemObjs = NULL;
	objDisposeAll(*relObjs); *relObjs = NULL;

	*itemObjs = tmpItemObjs;
	*relObjs = tmpRelObjs;

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
	return( dstat );
}*/
/*void GetAppDependsOnJTList(ObjectPtr* obj, SetOfStrings* list, int* mfail)
{

	char* mod_name="GetAppDependsOnJTList";
	integer* kfail=OKAY;
	int dstat=OKAY;
	int i=0,jtcnt=0;
	int CheckOSCItemStatus = 0;
	SetOfObjects AppDependSO=NULL;
	SetOfStrings extraStr	= NULL;
	ObjectPtr appdepjt=NULL;
	ObjectPtr TrndialogObj=NULL;

	string workingrelPath=NULL;
	string workingrelPathDup=NULL;
	string OwnerNameS=NULL;
	string classNameDupS=NULL;
	string classNameS=NULL;

	//START:
	t5CheckMfail(ExpandObject5(AppDepndClass,*obj,"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&AppDependSO,mfail));
	if(SetFlagforScope(AppDependSO)==1)
	{
		if(dstat = smSetSessionDbScope(dbScopeStr)) goto CLEANUP;
		t5CheckMfail(ExpandObject5(AppDepndClass,*obj,"AppDependentOnOnlineItems",SC_SCOPE_OF_SESSION,&AppDependSO,mfail));
		if(dstat = smSetSessionDbScope(dbScopeBkp)) goto CLEANUP;
	}

	jtcnt=setSize(AppDependSO);

	if(setSize(AppDependSO)>0)
	{
		printf("\n App Depends On Found:[%d]",jtcnt); fflush(stdout);

		*list=setCreate(jtcnt);
		for(i=0;i<jtcnt;i++)
		{
			appdepjt=setGet(AppDependSO,i);

			//getting class of object
			t5CheckDstat(objGetAttribute(appdepjt,ClassAttr,&classNameDupS));
			if(classNameDupS) classNameS = nlsStrDup(classNameDupS);
			printf("\nClass of Object = %s\n", classNameS); fflush(stdout);

			if(nlsStrCmp(classNameS,"OscItem") == 0)
			{
				if(CheckOSCItemStatus < 4)
				{
					oscItemFoundChangeDatabaseScope(appdepjt, mfail);
					CheckOSCItemStatus++;
					//goto START;
				}
			}

			objGetAttribute(appdepjt,OwnerNameAttr,&OwnerNameS);
			//objDump(appdepjt);

			objGetAttribute(appdepjt,WorkingRelativePathAttr,&workingrelPath);
			if(!nlsIsStrNull(workingrelPath))
			{
				workingrelPathDup=nlsStrDup(workingrelPath);
			}
			else
			{
				continue;
			}

			printf("\n workingrelPathDup: %s",workingrelPathDup); fflush(stdout);
			if((nlsStrStr(workingrelPathDup,"ALF") != NULL) || (nlsStrStr(workingrelPathDup,"WELD") != NULL))
			{
				low_set_add_str_unique(*list,workingrelPathDup);
			}
		}
	}
	else
	{
		printf("App Depends On not Found"); fflush(stdout);
		// *list=setCreate(1);
		// low_set_add_str_unique(*list,"xyz");
	}

CLEANUP:
EXIT:
	printf("\nExiting GetAppDependsOnJTList.\n"); fflush(stdout);
	objDisposeAll(AppDependSO);
}
*/
int SetFlagforScope(SetOfObjects ScopeObjects)
{
	ObjectPtr ScopeObjectPtr = NULL;
	int counter = 0;
	string ScopeObjectclass = NULL;
	string ScopeObjectclassDup = NULL;
	status	dstat = OKAY;

	for(counter = 0; counter < setSize(ScopeObjects); counter ++)
	{
		ScopeObjectPtr = setGet(ScopeObjects,counter);
		if(dstat = objGetClass(ScopeObjectPtr, &ScopeObjectclass)) goto CLEANUP;
		if(!nlsIsStrNull(&ScopeObjectclass))
		{
			ScopeObjectclassDup = nlsStrDup(ScopeObjectclass);
		}

		if (nlsStrCmp(ScopeObjectclass,"OscItem")==0)
		{
			printf("\nObject Found %s hence again expanding by applying dbscope",ScopeObjectclass);
			return 1;
		}
	}
	CLEANUP:
	return 0;
}
// This function returns Latest Documents from the given Set Of Objects
status t5GetLatestDocumnets_R
(
		SetOfObjects	docObjs,
		SetOfObjects	docRelObjs,
		SetOfObjects*	latestDocs,
		SetOfObjects*	latestRelDocs,
		integer*		mfail
)
{
	status	dstat		= OKAY;
   	char	*mod_name 	= "t5GetLatestDocumnets_R";
	SetOfStrings	docTypes	= NULL;
	string	docType		= NULL;
	SetOfObjects	docTypeObjs	= NULL;
	SetOfObjects	docTypeRelObjs	= NULL;
	ObjectPtr		latestDoc	= NULL;
	ObjectPtr		latestRelDoc	= NULL;
	int		count		= 0;
   			*mfail 		= USC_OKAY;

	////printf("\n in t5GetLatestDocumnets_R" ); fflush(stdin);

	if( dstat = t5GetDocumentTypes(docObjs, &docTypes, mfail) )
		goto CLEANUP;
	if(*mfail)
		goto CLEANUP;

	//setDumpStr("Dump Str:", docTypes);

	if(*latestDocs)	objDisposeAll(*latestDocs);	*latestDocs = NULL;
	if(*latestRelDocs)	objDisposeAll(*latestRelDocs);	*latestRelDocs = NULL;

	for(count=0; count<setSize(docTypes); count++)
	{

		docType = setGetStr(docTypes, count);

		if( dstat = t5GetTypeDocuments(docObjs, docRelObjs, docType, &docTypeObjs, &docTypeRelObjs, mfail) )
			goto CLEANUP;
		if(*mfail)
			goto CLEANUP;

		////printf("\n no of documents, %d %d ", setSize(docTypeObjs), setSize(docTypeRelObjs) ); fflush(stdin);

		if(latestDoc)	objDispose(latestDoc);	latestDoc = NULL;
		if(latestRelDoc)	objDispose(latestRelDoc);	latestRelDoc = NULL;
		if(dstat = t0LatestBI(docTypeObjs, docTypeRelObjs, &latestDoc, &latestRelDoc, mfail))
			goto CLEANUP;
		if(*mfail)
			goto CLEANUP;

		if(dstat = ulyCopyObjectToSet(latestDoc, latestDocs)) goto CLEANUP;
		if(dstat = ulyCopyObjectToSet(latestRelDoc, latestRelDocs)) goto CLEANUP;

	}

CLEANUP:

EXIT:
	if( dstat != OKAY) dlow_return_trace( mod_name, dstat);
   	return( dstat );
}

status t0LatestBI
(
	SetOfObjects itemObj,
	SetOfObjects itemRel,
	ObjectPtr *returnedObj,
	ObjectPtr *returnedRel,
	integer *mfail
)
{
        char				*mod_name		=   "t0LatestBI";
        status			dstat =    OKAY;

	integer			count = 	0;

	SetOfObjects		successorObjSet	=	NULL;
	SetOfObjects		successorObjRelSet =	 NULL;
	ObjectPtr		tmpItemObj		= NULL;
   	ObjectPtr		tmpRelObj		= NULL;
   	ObjectPtr		tmpObjSuccessor		= NULL;
	int				setFinder =  0;

	//printf("\n Inisde Function for Latest doc ....");
	//printf("\n Size Of item Object ....%d\n",setSize(itemObj));

	for(count=0; count<setSize(itemObj); count++)
	{
		//printf("\n For Loop ....count....%d\n",count);

		tmpItemObj = setGet(itemObj,count);
		//objDump(tmpItemObj);
		tmpRelObj = setGet(itemRel,count);
		if(count !=0)
		{
			if(successorObjSet)
			{    objDisposeAll(successorObjSet);
				successorObjSet=NULL;
			}
			if(successorObjRelSet)
			{ objDisposeAll(successorObjRelSet);
				successorObjRelSet=NULL;
			}
		}
		if (dstat =ExpandObject2(SuccessrClass,tmpItemObj,"SuccessorOfItem",SC_SCOPE_OF_SESSION,&successorObjSet,&successorObjRelSet,mfail) ) goto CLEANUP;
		if(*mfail) goto CLEANUP;

		if (setSize(successorObjSet)>0)
		{
			//printf("\n For Loop ...In side check for next.\n");
			tmpObjSuccessor = setGet(successorObjSet,0);
			//objDump(tmpObjSuccessor);

			if(dstat = ulyFindObjectInSet(tmpObjSuccessor,itemObj,OBIDAttr,0,&setFinder)) goto CLEANUP;

			if(setFinder>=0)
			{
				continue;
			}
			else
			{
				if(dstat = objCopy(returnedObj, tmpItemObj)) goto CLEANUP;
				//printf("\n Inside first else.....\n");
				if(dstat = objCopy(returnedRel, tmpRelObj)) goto CLEANUP;
				break;
			}
		}
		else
		{
			//printf("\n Inside Second else.....\n");
			if(dstat = objCopy(returnedObj, tmpItemObj)) goto CLEANUP;
			if(dstat = objCopy(returnedRel, tmpRelObj)) goto CLEANUP;
			break;
		}
	}

CLEANUP:

	if(successorObjSet) objDisposeAll(successorObjSet);
	if(successorObjRelSet)objDisposeAll(successorObjRelSet);
	//printf("\nCLEANUP:t0LatestBI\n");

EXIT:
	if( dstat != OKAY) dlow_return_trace(mod_name, dstat);
return( dstat );
}
