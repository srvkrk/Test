echo "Input to shell TmlgetAllRevJTPDF.sh::  [$1]  [$2]"
#cd "$1"
var_path=`pwd`
echo $var_path
rm -rf "$1"_allRevJT.txt
rm -rf "$1"_allRevCad.txt
rm -rf "$1"_allRevJT.jt.temp*
#if [ -d "$SubAssyPart" ]; then
if [ -d "$1_allRevJT" ]; then
rm -rf "$1"_allRevJT
fi
while read l_line
do
echo "******* Input: " $l_line
directory=`echo $l_line |awk -F',' '{print $5}'`
if [ ! -d "$directory" ]; then
continue;
fi
cd "$directory"
#ls -ltr allpartsAllRev_"$directory".txt
#cat allparts_"$directory".txt >> $var_path/"$1"_allRevJT.jt.temp
#cat allpartsAllRev_"$directory".txt >> $var_path/"$1"_allRevJT.jt.temp
cat AllPartAllRevFile.txt >> $var_path/"$1"_allRevJT.jt.temp
cd ..
done < $1.PartList.txt
if test -s $1.SubAssyPartList.txt
then
while read SubAssyPart
do
if [ -d "$SubAssyPart" ]; then
cd "$SubAssyPart"
pwd
while read l_line
do
echo "*******SubAssyInput: " $l_line
directory=`echo $l_line |awk -F',' '{print $5}'`
if [ ! -d "$directory" ]; then
continue;
fi				
cd "$directory"
#ls -ltr allpartsAllRev_"$directory".txt
#cat allparts_"$directory".txt >> $var_path/"$1"_allRevJT.jt.temp2
#cat allpartsAllRev_"$directory".txt >> $var_path/"$1"_allRevJT.jt.temp2
cat AllPartAllRevFile.txt >> $var_path/"$1"_allRevJT.jt.temp2
cd ..
done < $SubAssyPart.PartList.txt
cd ..
fi
done < $1.SubAssyPartList.txt
fi
if test -s "$1"_allRevJT.jt.temp2
then
cat "$1"_allRevJT.jt.temp2 >> "$1"_allRevJT.jt.temp
fi
if test -s "$1"_allRevJT.jt.temp
then
	sort -u "$1"_allRevJT.jt.temp > "$1"_allRevJT.jt.temp1
	mv "$1"_allRevJT.jt.temp1 "$1"_allRevJT.jt.temp
	RecCnt=0
	while read j_line
	do
		RecCnt=$(expr "$RecCnt" + 1)
		echo "RecCnt: $RecCnt"
		prt=`echo $j_line |awk -F'^' '{print $1}'`
		rev=`echo $j_line |awk -F'^' '{print $2}'`
		seq=`echo $j_line |awk -F'^' '{print $3}'`
		/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlGetAllTCRevJTCadDrg "$prt" $rev $seq "$1"_allRevJT.txt "$1"_allRevCad.txt
	done < "$1"_allRevJT.jt.temp
	sort -u "$1"_allRevJT.txt > "$1"_allRevJT_2.txt
	mv "$1"_allRevJT_2.txt "$1"_allRevJT.txt
	sort -u "$1"_allRevCad.txt > "$1"_allRevCad_2.txt
	mv "$1"_allRevCad_2.txt "$1"_allRevCad.txt
	if [ -s "$1"_allRevJT.txt1 ] 
	then
		echo "$1_allRevJT.txt1 has some data."
		sort -u "$1"_allRevJT.txt1 > "$1"_allRevJT.txt12
		mv "$1"_allRevJT.txt12 "$1"_allRevJT.txt1
	fi
	mkdir "$1_allRevJT"
	cd "$1_allRevJT"
	pwd
	echo "Assembly JT files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevJT.txt1 .
	echo "JT files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevJT.txt .
	echo "CAD files Downloading..."
	/user/omfprod/devgroups/UALoading/TCEtoTCUADataXfr/TmlcopyJTItems_allrev.sh $var_path/"$1"_allRevCad.txt .
fi
cd ..
echo "AllRev JT Download is Finished.."
