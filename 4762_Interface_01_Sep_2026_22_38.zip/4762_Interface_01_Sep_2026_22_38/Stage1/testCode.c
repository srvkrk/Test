/*=============================================================================
                Copyright (c) 2003-2005 UGS Corporation
                   Unpublished - All Rights Reserved
===============================================================================
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;

static void initialise (void);
static void initialise_attribute (char *name,  int *attribute);
static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth);
static void print_bom (tag_t line, tag_t line1, int depth, char* AlfJTname, char* AlfJTnameCmp, char* AlfChildPart, char* Parent_name);

tag_t window = NULLTAG;
tag_t ParentBomLine = NULLTAG;
int Parentlevel = 0;
int ParentFlag = 0;

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	
	if (mode != BOM_attribute_mode_string)
	{	
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}
}
extern int ITK_user_main (int argc, char ** argv )
{
    int ifail;
	int status;
    int h=0;
    int t=0;
    int org_seq_id_int;
	int referencenumberfound=0;
	int kk=0;
	int *number_found;
	int currseq=0;
	int grm_Relcount=0;
	int resultCount_d=0;
	int DatasetFlag=0;
	int ref_count_d=0;
	int t_al_absocc_rootline_string = 0;
	int occAttrID = 0;
	int j = 0;

    char *req_item = NULL;
    char *seq_id = NULL;
    char *req_key = NULL;
	char *inputfile=NULL;
	char *vol_name=NULL;
	char *nod_name=NULL;
	char *revisionID = NULL;
	char *itemtype = NULL;
	char *AlfJTnameM = NULL;
	char *AlfJTnameCmp=NULL;
	char *AlfChildPart=NULL;
	char *ImmidiateParent=NULL;
	char* username = NULL;

	char refname[AE_reference_size_c + 1];
	char pathnamee[SS_MAXPATHLEN + 1];
	char orig_name[IMF_filename_size_c + 1];

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *grm_relation_type_list=NULLTAG;
	tag_t *revtag_d=NULLTAG;

	tag_t rev = NULLTAG;
	tag_t vol = NULLTAG;
	tag_t rev_zero_dset_tag;
    tag_t rule, item_tag = null_tag, top_line;
	//tag_t refobject = NULLTAG;
	tag_t AlfDataSet_tag = NULLTAG;

	WSO_search_criteria_t criteria;

	AE_reference_type_t reftype;

	char *qry_entries4_d[2] = {"Dataset Name","Type"},
		 *qry_values4_d[2]	= {"*","*"};

	char **qry_values_d = (char **) MEM_alloc(60 * sizeof(char *));

	int n_entries_d = 1;

	tag_t queryTag_d = NULLTAG;
	tag_t datasetTag = NULLTAG;
	tag_t item_tag_data_rev = NULLTAG;
	tag_t RefObject_d = NULLTAG;
	tag_t *namRefObject_d = NULL;
	tag_t config_rule = NULLTAG;
	tag_t absoccContext = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t alf_Relation = NULLTAG;
	tag_t user_tag = NULLTAG;

	char type_name3[TCTYPE_name_size_c+1];
	char *JTDataItem=NULL;
	char *named_ref=NULL;
	char *named_ref2=NULL;
	char *JtTemp =  NULL;
	char *occName = NULL;

	logical absOccEditMode;

	//FILE *fp1;

    (void)argc;
    (void)argv;

    initialise();

    req_item = ITK_ask_cli_argument("-i=");
	revisionID = ITK_ask_cli_argument("-j=");
	seq_id = ITK_ask_cli_argument("-k=");
	//inputfile = ITK_ask_cli_argument("-l=");
	itemtype = ITK_ask_cli_argument("-m=");
	AlfJTnameM = ITK_ask_cli_argument("-ajt=");
	AlfJTnameCmp = ITK_ask_cli_argument("-jt=");
	AlfChildPart = ITK_ask_cli_argument("-Child=");
	ImmidiateParent = ITK_ask_cli_argument("-Parent=");

	//fp1=fopen(inputfile,"a");

    if ( !req_item && !revisionID )
    {
        printf("Must supply the \"-i\" or \"-j\" option on command line\n"); fflush(stdout);
        exit(0);
    }

    ifail = BOM_create_window (&window);
    CHECK_FAIL;
    ifail = CFM_find( "Latest Working", &rule );
    CHECK_FAIL;
    ifail = BOM_set_window_config_rule( window, rule );
    CHECK_FAIL;

	printf("\n\n----------- AlfJTnameM:%s  AlfJTnameCmp:[%s]   AlfChildPart:[%s]  ImmidiateParent:[%s]",AlfJTnameM,AlfJTnameCmp,AlfChildPart,ImmidiateParent); fflush(stdout);

	if(strcmp(itemtype,"DirectModel")!=0)
	{
		if ( req_item )
		{
			tag_t *tags_found = NULL;
			tag_t *rev1 = NULL;
			int n_tags_found= 0;
			int n_rev= 0;
			int t= 0;
			char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
			char **values = (char **) MEM_alloc(1 * sizeof(char *));

			attrs[0] ="item_id";
			values[0] = (char *)req_item;
			ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

			MEM_free(attrs);
			MEM_free(values);
			CHECK_FAIL;

			if (n_tags_found == 0)
			{
				printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item); fflush(stdout);
				exit (0);
			}
			else if (n_tags_found > 1)
			{
				MEM_free(tags_found);
				EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
				printf ( "More than one items matched with id %s\n", req_item); fflush(stdout);
				exit (0);
			}

			item_tag = tags_found[0];
			ifail = ITEM_find_revisions(item_tag,revisionID,&n_rev,&rev1);
			for(h=0;h<n_rev;h++)
			{
				ifail = AOM_ask_value_int(rev1[h],"sequence_id",&org_seq_id_int);
				CHECK_FAIL;
				currseq = atoi(seq_id);

				//printf("\n org_seq_id_int:%d",org_seq_id_int); fflush(stdout);
				//printf("\n seq_id        :%s",seq_id); fflush(stdout);
				//printf("\n currseq       :%d",currseq); fflush(stdout);
				
				rev = rev1[h];  //uncomented on 23.06.2017
				
				/*if(org_seq_id_int == currseq)		// comented on 23.06.2017
				{
					rev = rev1[h];
					printf("\nInside tag assign"); fflush(stdout);
				}*/
			}

			MEM_free(tags_found);
			//MEM_free(rev);
		}
		else // req_key being used
		{		
			tag_t *tags_found = NULL;
			int n_tags_found = 0;
			ifail = ITEM_find_items_by_string(req_key, &n_tags_found, &tags_found);
			if (ifail == ITK_ok)
			{
				if (n_tags_found == 0)
				{
					printf ("\nITEM_find_items_by_string returns success,  but didn't find %s\n", req_key); fflush(stdout);
					exit (0);
				}
				else if (n_tags_found > 1)
				{
					MEM_free(tags_found);
					EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
					printf ( "More than one items matched with key %s\n", req_key); fflush(stdout);
					exit (0);
				}
				else
				{
					item_tag = tags_found[0];
					MEM_free(tags_found);
				}
			}		
		}

		if (item_tag == null_tag)
		{
			printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item); fflush(stdout);
			exit (0);
		}

		ifail = BOM_set_window_top_line (window, null_tag,rev, null_tag, &top_line);
		CHECK_FAIL;

		/*ifail = AOM_set_value_logical(window,"absocc_specific_edit_mode",TRUE);
		if(ifail == ITK_ok)
		{
			printf("\n Absolute mode for the BOM window is set to TRUE\n"); fflush(stdout);
		}
		else
		{
			printf("\n Absolute mode for the BOM window is not set to TRUE\n"); fflush(stdout);
		}*/

		//printf ("Calling BOM_line_unpack... \n"); fflush(stdout);
		//ifail = BOM_line_unpack (top_line);
		//CHECK_FAIL;

		ifail = GRM_list_relation_types(&grm_Relcount, &grm_relation_type_list);
		CHECK_FAIL;
		//printf("\n grm_Relcount:%d  \n",grm_Relcount); fflush(stdout);

		POM_get_user(&username,&user_tag);
		printf("\n Session User:[%s]\n",username); fflush(stdout);

		Get_unpack_bom (top_line, NULLTAG, 0);
		ifail = BOM_save_window (window);

		ifail = BOM_window_set_absocc_edit_mode(window, TRUE);
		if(ifail == ITK_ok)
		{
			printf("\n Absolute Occurence mode for the BOM window is set to TRUE\n"); fflush(stdout);
		}
		else
		{
			printf("\n ???? Absolute Occurence mode for the BOM window is not set......\n"); fflush(stdout);
		}

		ifail = BOM_window_set_absocc_context(window, top_line);
		if(ifail == ITK_ok)
		{
			printf("\n Absolute context is set to TRUE for the BOM window\n"); fflush(stdout);
		}
		else
		{
			printf("\n ???? Absolute contextfor is not set......\n"); fflush(stdout);
		}

		ParentFlag = 0;
		//print_bom (top_line, NULLTAG, 0,fp1, AlfJTnameM, AlfJTnameCmp);
		print_bom (top_line, NULLTAG, 0, AlfJTnameM, AlfJTnameCmp, AlfChildPart, ImmidiateParent);


		/*if(QRY_find("Dataset Name2", &queryTag_d));
		printf("\t\t After IFERR_REPORT : QRY_find....");fflush(stdout);
		if (queryTag_d)
		{
			printf("\t\t Found Query 'Dataset Name2'");fflush(stdout);
		}
		else
		{
			printf("\t\t Not Found Query 'Dataset Name2'");fflush(stdout);
		}
		qry_values_d[0] = AlfJTnameCmp ;
		qry_values_d[1] = "DirectModel" ;


		if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
		printf(".........resultCount_d:[%d] for AlfJTnameCmp:[%s] \n\t",resultCount_d,AlfJTnameCmp);fflush(stdout);

		if(resultCount_d > 0)
		{
			DatasetFlag = 0;

			for (j=0;j<resultCount_d;j++ )
			{
				AlfDataSet_tag = revtag_d[j];

				if(TCTYPE_ask_object_type(AlfDataSet_tag,&datasetTag));
				if(TCTYPE_ask_name(datasetTag,type_name3));
				//printf("    jt..Part type_name3 :%s \n\t",type_name3); fflush(stdout);

				if (strcmp(type_name3,"DirectModel")==0)
				{
					ifail =  AE_ask_dataset (AlfDataSet_tag,&item_tag_data_rev);
					CHECK_FAIL;

					ifail = AOM_ask_value_string(AlfDataSet_tag,"object_application",&JTDataItem);
					CHECK_FAIL;
					//printf("\n\t jt..JTDataItem--->%s",JTDataItem);fflush(stdout);

					ifail = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
					CHECK_FAIL;

					if(ref_count_d>0)
					{
						RefObject_d = namRefObject_d[0];

						ifail = AOM_ask_value_string(RefObject_d,"object_string",&named_ref2);
						CHECK_FAIL;

						//printf("\n\t jt..item_tag named_ref2:[%s]...AlfJTnameM:[%s] ",named_ref2,AlfJTnameM);

						named_ref=(char *) MEM_alloc(100);
						strcpy(named_ref,"");
						JtTemp=strtok(named_ref2,".");
						//printf("  JtTemp:[%s]",JtTemp);
						strcpy(named_ref,JtTemp);
						strcat(named_ref,".jt");


						if (strcmp(named_ref,AlfJTnameM)==0)
						//if( (strcmp(named_ref,AlfJTnameM)==0) && (strcmp(JTDataItem,AlfJTnameM)==0))
						{
							printf(" named_ref:[%s]  and JTDataItem:[%s] AlfJTnameM:[%s]",named_ref,JTDataItem,AlfJTnameM);
							DatasetFlag = 1;
							printf("..already present and match found \n\t");
							break;
						}
					}
				}
				//else
				//{
				//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t"); fflush(stdout);
				//	DatasetFlag = 0;
				//}
			}
			printf("\n\t jt..DatasetFlag:%d \n",DatasetFlag); fflush(stdout);
		}
		
		if (DatasetFlag == 1)
		{
			ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
			CHECK_FAIL;

			ifail = BOM_ask_window_config_rule(window,&config_rule);

			ifail = BOM_window_ask_absocc_context(window,&absoccContext);
			ifail = BOM_window_ask_absocc_edit_mode(window,&absOccEditMode);

			//if((absOccEditMode == 1) && (absoccContext != NULLTAG))
			if(absOccEditMode == 1)
			{
				printf("\t BOM_window_ask_absocc_edit_mode is on\n");

				if(absoccContext != NULLTAG)
				{
					printf("\t BOM_window_ask_absocc_context Found...\n");

					if (AlfDataSet_tag != NULLTAG)
					{
						printf("\n\t ALF-JT dataset tag found.....");
						//if (strstr(orig_name,AlfJTnameCmp)!=NULL)
						//{
						//	printf("Matched...");
						//	ITK_CALL(BOM_line_add_absocc_relation(top_line , relation_type , AlfDataSet_tag , &alf_Relation));
							//if( BOM_line_add_absocc_relation(bom_line_tag , relation_type , AlfDataSet_tag , &alf_Relation)!=ITK_ok);
							//CHECK_FAIL;
							//if (alf_Relation != NULLTAG)
							//{
							//	printf("ALF relation created\n");
							//	ifail = AOM_save( bom_line_tag );
							//	//ifail = BOM_save_window( window );
							//	CHECK_FAIL;
							//}
							//else
							//{
							//	printf("ALF relation NOT-CREATED\n");
							//}
						//}
					}
					else
					{
						printf("\n\t ALF-JT dataset tag NOT FOUND..... \n");
					}
				}
			}
			else
			{
				printf("\t BOM_window_ask_absocc_edit_mode is OFF ??\n");
			}

			//BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &k, &related_items);
		}*/

		if (ParentFlag == 0)
		{
			printf("\n\t ImmidiateParent: %s not found in Bom structure of  %s  %s\n",ImmidiateParent,req_item,revisionID); fflush(stdout);
		}
		printf ("================================================\n");

	}

    ITK_exit_module(true);

	return status;
}
static void Get_unpack_bom (tag_t bom_line_tag, tag_t line1, int depth)
{
	int ifail;
	int i, no_bom_lines , j , k=0;
	int n_tags_found= 0;
	int iChildItemTag;
	int status;
	int level0=0;
	int pack_count=0;
	int PartStatusInBom = 0;
	int bl_Suppress = 0;
	int charFlag = 0;
	int ti = 0;
	int tmpStrlen = 0;

	char *name, *sequence_no;
	char *Item_id_par=NULL;
	char *word=NULL;
	//char *BomLine_name=NULL;
	char *Parent_name=NULL;
	char *Parent_Rev=NULL;
	char* inputline = NULL;
	char* inputlineTemp = NULL;
	char* ChildLevel = NULL;
	char *p;
	char *tempstr=NULL;
	char *tempstrSup=NULL;
	//char tempstr[50]={0};

	tag_t *child_bom_lines;
	tag_t *tags_found = NULL;

	tag_t item=NULLTAG;
	tag_t reva=NULLTAG;
	tag_t t_ChildItemRev;

	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	logical bl_Suppress_log;

	depth ++;
	ifail = BOM_line_ask_attribute_string (bom_line_tag, name_attribute, &name);
	CHECK_FAIL;
	word = strtok(name, "/");
	/* note that I know name is always defined,  but sometimes sequence number is unset.
	If that happens it returns NULL,  not an error.
	*/
	ifail = BOM_line_ask_attribute_string (bom_line_tag, seqno_attribute, &sequence_no);
	CHECK_FAIL;

	ifail = BOM_line_look_up_attribute ( ( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
	ifail = BOM_line_ask_attribute_tag(bom_line_tag, iChildItemTag, &t_ChildItemRev);
	CHECK_FAIL;

	attrs[0] ="item_id";
	values[0] = (char *)word;
	ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
	CHECK_FAIL;

	item = tags_found[0];
	//printf("Item Found\n");

	if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);

	//for (i = 0; i < depth; i++)
	//	printf ("  ");

	ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines);
	CHECK_FAIL;

	if ((no_bom_lines == 0) && (level0 == 0) )
	{
		ifail = ITEM_ask_latest_rev(item,&reva);
		CHECK_FAIL;

		if( AOM_ask_value_string(reva,"item_id",&Item_id_par)!=ITK_ok);

		printf("\n\t ?????  ChildPart are not loaded found for Input Parent  %s  , Pls load Bom again ???\n",Item_id_par); fflush(stdout);
	}

	for (j = 0; j < no_bom_lines; j++)
	{
		ifail = BOM_line_unpack (child_bom_lines[j]);
        CHECK_FAIL;

		Get_unpack_bom (child_bom_lines[j], bom_line_tag, depth);
	}

	MEM_free (child_bom_lines);
	MEM_free (name);
	MEM_free (sequence_no);
}
//static void print_bom (tag_t bom_line_tag, tag_t line1, int depth,FILE *fdf, char* AlfJTname, char* AlfJTnameCmp)
static void print_bom (tag_t bom_line_tag, tag_t line1, int depth, char* AlfJTname, char* AlfJTnameCmp, char* AlfChildPart, char* ImmidiateParent)
{
    int ifail;
    int iChildItemTag;
    tag_t jtfile;
	int status;
    int cnt=0;
    int referencenumberfound=0;
    int i, no_bom_lines ,j;
	int k = 0;
	int n_Alfrel_item = 0;
	int AlfAttachedFlag = 0;
    int n_tags_found= 0;
    int level0 = 0;
    int level1 = 0;

    char *name, *sequence_no;
	char *Item_id_par=NULL;
	char *Item_id_par_des=NULL;
	char *vol_name=NULL;
	char *nod_name=NULL;
	char *word=NULL;
	char *refset_name=NULL;
	char *contextLineValue=NULL;
	char *BomLine_name=NULL;
	char *Parent_name=NULL;
	char *Parent_Rev=NULL;

	logical override;
	logical override1 = false;
	logical absOccEditMode;

    tag_t *child_bom_lines;
	tag_t item=NULLTAG;
	tag_t reva=NULLTAG;
	tag_t vol=NULLTAG;
	tag_t *tags_found = NULL;
	tag_t t_ChildItemRev;
	tag_t *attachments = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t datasetAlf = NULLTAG;
	tag_t refobject = NULLTAG;
	tag_t relation_type, relation;
	tag_t *related_occs = NULLTAG;
	tag_t *related_items =  NULLTAG;
	tag_t *Alfrel_items =  NULLTAG;
	tag_t line_tag =  NULLTAG;
	tag_t config_rule = NULLTAG;
	tag_t absoccContext = NULLTAG;
	tag_t alf_Relation = NULLTAG;

    char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
    char **values = (char **) MEM_alloc(1 * sizeof(char *));

	char refname[AE_reference_size_c + 1];
	char pathname[SS_MAXPATHLEN + 1];
	char pathnamee[SS_MAXPATHLEN + 1];
	char orig_name2[IMF_filename_size_c + 1];
	char Alforig_name[IMF_filename_size_c + 1];

	char *orig_name = NULL;

	AE_reference_type_t reftype;

	char *qry_entries4_d[2] = {"Dataset Name","Type"},
		 *qry_values4_d[2]	= {"*","*"};

	char **qry_values_d = (char **) MEM_alloc(60 * sizeof(char *));

	int n_entries_d = 1;
	int resultCount_d=0;
	int DatasetFlag=0;
	int ref_count_d=0;
	int t_al_absocc_rootline_string = 0;
	int occAttrID = 0;

	tag_t queryTag_d = NULLTAG;
	tag_t AlfDataSet_tag = NULLTAG;
	tag_t *revtag_d=NULLTAG;
	tag_t datasetTag = NULLTAG;
	tag_t item_tag_data_rev = NULLTAG;
	tag_t RefObject_d = NULLTAG;
	tag_t *namRefObject_d = NULL;

	char type_name3[TCTYPE_name_size_c+1];
	char *JTDataItem=NULL;
	char *named_ref=NULL;
	char *named_ref2=NULL;
	char *JtTemp =  NULL;
	char *occName = NULL;
	char *JTFileDesc = NULL;
	char **ref_list;

	tag_t datasettype =  NULLTAG;
	tag_t tool = NULLTAG;
	tag_t filetag =  NULLTAG;
	tag_t *namRefObject = NULL;

	IMF_file_t fileDescriptor;

	int result = 0;
	int nameRef_cnt = 0;
	int ref_count = 0;

	AE_reference_type_t tagRefType =  1;

	//FILE *fp2;
    //fp2=fopen("jtdetails.txt","a");

    depth ++;
    ifail = BOM_line_ask_attribute_string (bom_line_tag, name_attribute, &name);
    CHECK_FAIL;
	word = strtok(name, "/");

	ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
	CHECK_FAIL;

	attrs[0] ="item_id";
	values[0] = (char *)word;
    ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
	CHECK_FAIL;

	if (n_tags_found > 0)
	{
		item = tags_found[0];
		//printf("\t Item Found\n");
		
		ifail = ITEM_ask_latest_rev(item,&reva);
		CHECK_FAIL;
		if( AOM_ask_value_string(reva,"item_id",&Item_id_par)!=ITK_ok);
		//printf("\nrrrrrrrrrrrrr----------------Item ID is  ---->%s ",Item_id_par);

		if(relation_type != NULLTAG)
		{
			ifail = GRM_list_secondary_objects_only(reva,relation_type,&cnt,&attachments);
			CHECK_FAIL;

			if (cnt > 0)
			{
				for(j=0;j<cnt;j++)
				{
					dataset = attachments[j];

					if(AE_ask_dataset_ref_count(dataset,&referencenumberfound));

					for(k=0;k<referencenumberfound;k++)
					{
						ifail = AE_find_dataset_named_ref(dataset,k,refname,&reftype,&refobject);
						CHECK_FAIL;
						//printf("\n named ref. =%s",refname);

						ifail =  IMF_ask_original_file_name(refobject,orig_name2);

						//printf("\n JT_orig_name is :%s ",orig_name2); fflush(stdout);

						ifail =  IMF_ask_file_pathname(refobject,2,pathnamee);
						ifail =  IMF_ask_volume(refobject,&vol);
						if( AOM_ask_value_string(vol,"volume_name",&vol_name)!=ITK_ok);
						CHECK_FAIL;
						if( AOM_ask_value_string(vol,"node_name",&nod_name)!=ITK_ok);
						CHECK_FAIL;

						//printf("\t orig_name2 is :%s\n",orig_name2); fflush(stdout);
						//printf("\t pathnamee is :%s\n",pathnamee); fflush(stdout);
						//printf("\t pathnamee is :%s\n",vol_name); fflush(stdout);
						//fprintf(fdf,"%s,%s,%s,%s\n",orig_name2,pathnamee,nod_name,vol_name);fflush(stdout);

						if (tc_strstr(orig_name2,"")==NULL)
						{
							orig_name=strtok(orig_name2,".jt");
						}
					}
				}
			}
			else
			{
				//printf("\t Warning: Datasets are not attached to DesignRevision .....??"); fflush(stdout);
				printf("\n Warning: Datasets are not attached to DesignRevision  %s.....??",Item_id_par); fflush(stdout);

				strcpy(orig_name2,"");

				orig_name=(char *) MEM_alloc(100);
				strcpy(orig_name,"");
			}
		}
	}

	//printf("\n-------------------------------------------"); fflush(stdout);

	if( AOM_ask_value_string(bom_line_tag,"bl_item_item_id",&BomLine_name)!=ITK_ok);
	if( AOM_ask_value_int(bom_line_tag,"bl_level_starting_0",&level0)!=ITK_ok);

	if (tc_strcmp(Item_id_par,ImmidiateParent)==0)
	{
		ParentFlag = 1;

		printf("\n rrr----------------Item ID is  ---->%s ",Item_id_par); fflush(stdout);

		ifail = BOM_line_ask_all_child_lines( bom_line_tag , &no_bom_lines , &child_bom_lines );
		CHECK_FAIL;
		
		if (no_bom_lines > 0)
		{
			Parentlevel = level0;
			ParentBomLine = bom_line_tag;
		}
		
		for (i = 0; i < no_bom_lines; i++)
		{
			ifail = BOM_line_unpack (child_bom_lines[i]);
			CHECK_FAIL;
			print_bom (child_bom_lines[i], bom_line_tag, depth , AlfJTname, AlfJTnameCmp, AlfChildPart , ImmidiateParent);
		}
		MEM_free (child_bom_lines);
		MEM_free (name);
	
		exit(0);
	}
	else
	{
		ParentFlag = 0;
	}

	if (ParentBomLine != NULL)
	{
		if( AOM_ask_value_string(ParentBomLine,"bl_item_item_id",&Parent_name)!=ITK_ok);
		if( AOM_ask_value_string(ParentBomLine,"bl_rev_item_revision_id",&Parent_Rev)!=ITK_ok);
	}

	//printf("\n orig_name: [%s]   AlfChildPart: [%s]",orig_name,AlfChildPart); fflush(stdout);

	//if (strstr(orig_name,AlfChildPart) != NULL)
	if (tc_strcmp(orig_name,AlfChildPart) == 0)
	{
		printf("\n level:[%d]---BomLine_name:%s     Parentlevel:[%d]---Parent_name:[%s]--[%s]  orig_name: [%s]   AlfChildPart: [%s]\n",level0,BomLine_name,Parentlevel,Parent_name,Parent_Rev,orig_name,AlfChildPart); fflush(stdout);

		printf("\n      is :[%s]   [%s]\n",ImmidiateParent,Parent_name); fflush(stdout);

		printf("\n    AlfJTname:[%s]\n",AlfJTname); fflush(stdout);

		if((tc_strcmp(ImmidiateParent,Parent_name)==0) || (tc_strstr(AlfJTname,"_WELD")!=NULL))
		{
			printf("\n    Inside if condition");  fflush(stdout);

			//BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &k, &related_items);
			//printf("\t Total BOM_line_ask_absocc_relation :%d\n",k); fflush(stdout);

			//if (k > 0)
			//{
			//	for(j=0;j<k;j++)
			//	{
			//		printf("\n"); fflush(stdout);

					/*dataset = NULLTAG;

					GRM_ask_secondary (related_items[j], &dataset);

					if(AE_ask_dataset_ref_count(dataset,&referencenumberfound));
					printf("\t Dataset Reference Count %d\n", referencenumberfound); fflush(stdout);
					
					for(k=0;k<referencenumberfound;k++)
					{
						ifail = AE_find_dataset_named_ref(dataset,k,refname,&reftype,&refobject);
						CHECK_FAIL;
						
						ifail =  IMF_ask_original_file_name(refobject,orig_name);
						ifail =  IMF_ask_file_pathname(refobject,2,pathnamee);
						ifail =  IMF_ask_volume(refobject,&vol);

						if( AOM_ask_value_string(vol,"volume_name",&vol_name)!=ITK_ok);
						CHECK_FAIL;
						if( AOM_ask_value_string(vol,"node_name",&nod_name)!=ITK_ok);
						CHECK_FAIL;
						
						printf("\t 11..orig_name is :%s\n",orig_name); fflush(stdout);
						printf("\t 11..pathnamee is :%s\n",pathnamee); fflush(stdout);
						printf("\t 11..pathnamee is :%s\n",vol_name); fflush(stdout);
						//fprintf(fdf,"%s,%s,%s,%s\n",orig_name,pathnamee,nod_name,vol_name);fflush(stdout);
					}*/
			//	}
			//}
			//else
			//{
				printf("\t ALF JT not attached found to bom_line_tag\n"); fflush(stdout);

				if(QRY_find("Dataset Name2", &queryTag_d));
				printf("\t\t After IFERR_REPORT : QRY_find....");fflush(stdout);
				if (queryTag_d)
				{
					printf("\t\t Found Query 'Dataset Name2'");fflush(stdout);
				}
				else
				{
					printf("\t\t Not Found Query 'Dataset Name2'");fflush(stdout);
				}

				qry_values_d[0] = AlfChildPart ;
				qry_values_d[1] = "DirectModel" ;

				if(QRY_execute(queryTag_d, n_entries_d, qry_entries4_d, qry_values_d, &resultCount_d, &revtag_d));
				printf(".........resultCount_d:[%d] for AlfChildPart:[%s] \n\t",resultCount_d,AlfChildPart);fflush(stdout);

				if(resultCount_d > 0)
				{
					DatasetFlag = 0;

					for (j=0;j<resultCount_d;j++ )
					{
						AlfDataSet_tag = revtag_d[j];

						if(TCTYPE_ask_object_type(AlfDataSet_tag,&datasetTag));
						if(TCTYPE_ask_name(datasetTag,type_name3));

						if (strcmp(type_name3,"DirectModel")==0)
						{
							ifail =  AE_ask_dataset (AlfDataSet_tag,&item_tag_data_rev);
							CHECK_FAIL;

							ifail = AOM_ask_value_string(AlfDataSet_tag,"object_application",&JTDataItem);
							CHECK_FAIL;
							//printf("\n\t jt..JTDataItem--->%s",JTDataItem);fflush(stdout);

							ifail = AE_ask_dataset_named_refs(item_tag_data_rev,&ref_count_d, &namRefObject_d);
							CHECK_FAIL;

							if(ref_count_d>0)
							{
								RefObject_d = namRefObject_d[0];

								ifail = AOM_ask_value_string(RefObject_d,"object_string",&named_ref2);
								CHECK_FAIL;

								printf("\n\t jt..item_tag named_ref2:[%s]...AlfJTname:[%s] ",named_ref2,AlfJTname); fflush(stdout);

								named_ref=(char *) MEM_alloc(100);
								strcpy(named_ref,"");
								JtTemp=strtok(named_ref2,".");
								//printf("  JtTemp:[%s]",JtTemp);
								strcpy(named_ref,JtTemp);
								strcat(named_ref,".jt");

								if (strcmp(named_ref,AlfJTname)==0)
								//if( (strcmp(named_ref,AlfJTname)==0) && (strcmp(JTDataItem,AlfJTname)==0))
								{
									printf(" named_ref:[%s] and JTDataItem:[%s] AlfJTname:[%s]",named_ref,JTDataItem,AlfJTname); fflush(stdout);
									DatasetFlag = 1;
									printf("..already present and match found \n\t"); fflush(stdout);
									break;
								}
							}
						}
						//else
						//{
						//	printf("\n\t\t jt..item_tag named_ref match not found hence continuing....\n\t");
						//	DatasetFlag = 0;
						//}
					}
					printf("\n\t jt..DatasetFlag:%d \n",DatasetFlag); fflush(stdout);
				}

				/*if (DatasetFlag == 0)
				{
					JTFileDesc =(char *) MEM_alloc(20);
					strcpy(JTFileDesc,"iPEM Override JT");

					result = AE_find_datasettype("DirectModel", &datasettype);
					printf("\n\t Type found---->%d",result);fflush(stdout);

					printf("\n\t Creating New Dataset..."); fflush(stdout);
					//result = AE_create_dataset_with_id(datasettype,AlfJTnameCmp,JTFileDesc, NULL, NULL, &AlfDataSet_tag);
					result = AE_create_dataset_with_id(datasettype,AlfChildPart,JTFileDesc, NULL, NULL, &AlfDataSet_tag);
					printf("\n\t Dataset created for prt --->%s \n\t\ ",AlfChildPart); fflush(stdout);

					////ITK_CALL(AOM_set_value_string(AlfDataSet_tag,"object_application","282947610110.drw.31"));
					//ITK_CALL(AOM_set_value_string(AlfDataSet_tag,"object_application",DataItem));

					result = AE_set_dataset_format(AlfDataSet_tag, "BINARY_REF");
					printf("\n\t Dataset format set--->%d",result); fflush(stdout);

					result = AE_set_dataset_tool(AlfDataSet_tag,tool);
					printf("\n\t Tool set--->%d",result); fflush(stdout);

					result = AE_ask_dataset_named_refs(AlfDataSet_tag,&nameRef_cnt, &namRefObject);
					printf("\n\t nameRef_cnt Count--->%d\n",nameRef_cnt);fflush(stdout);

					if (nameRef_cnt == 0)
					{
						result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
						printf("\n\t Got reference list--->%d",result); fflush(stdout);

						//result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
						result = IMF_import_file(AlfJTname,NULL, SS_BINARY, &filetag, &fileDescriptor);
						printf("\n\t File Imported--->%d",result); fflush(stdout);

						result = AOM_save(filetag);
						printf("\n\t File saved--->%d",result); fflush(stdout);

						result = AE_add_dataset_named_ref(AlfDataSet_tag,ref_list[0],tagRefType,filetag);
						printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

						AE_set_dataset_tool(AlfDataSet_tag,tool);
						printf("\n\t Tool set--->%d",result); fflush(stdout);

						result = AOM_save(AlfDataSet_tag);
						printf("\n\t AOM_save--->%d",result); fflush(stdout);
					}

					DatasetFlag = 1 ;
				}*/

				if (DatasetFlag == 1)
				{
					ifail = BOM_ask_window_config_rule(window,&config_rule);
					ifail = BOM_window_ask_absocc_edit_mode(window,&absOccEditMode);

					ifail = BOM_window_ask_absocc_context(window, &absoccContext);
					CHECK_FAIL;
					if(ifail == ITK_ok)
					{
						printf("\n\t Absolute context is Found\n"); fflush(stdout);
					}
					else
					{
						printf("\n\t ???? Absolute context is not Found......\n"); fflush(stdout);
					}

					if(absoccContext != NULLTAG)
					{
						printf("\n\t BOM_window_ask_absocc_context Found.\n"); fflush(stdout);
					}

					if((absOccEditMode == 1) /*&& (config_rule != NULLTAG)*/)
					{
						printf("\n\t BOM_window_ask_absocc_edit_mode is on\n"); fflush(stdout);

						//if(absoccContext != NULLTAG)
						//{
						//	printf("\n\t BOM_window_ask_absocc_context Found.\n"); fflush(stdout);

							if (AlfDataSet_tag != NULLTAG)
							{
								printf("\n\t ALF-JT dataset tag found.....[%s]  [%s]  [%s]",orig_name,AlfJTnameCmp,AlfChildPart); fflush(stdout);
							
								if(((strstr(AlfJTnameCmp,"ALF")!=NULL) && (strstr(orig_name,AlfChildPart)!=NULL)) ||(strstr(orig_name,AlfJTnameCmp)!=NULL))
								{
									printf("\n\t Matched...\n\t "); fflush(stdout);

									ITK_CALL(BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &n_Alfrel_item, &Alfrel_items));
									printf("\t Total BOM_line_ask_absocc_relation n_Alfrel_item: %d\n",n_Alfrel_item); fflush(stdout);

									if (n_Alfrel_item > 0)
									{
										for(j=0;j<n_Alfrel_item;j++)
										{
											printf("\n\t ");

											datasetAlf = NULLTAG;

											ITK_CALL(GRM_ask_secondary (Alfrel_items[j], &datasetAlf));

											if(AE_ask_dataset_ref_count(datasetAlf,&referencenumberfound));
											printf("\t Dataset Reference Count %d\n", referencenumberfound); fflush(stdout);
											
											for(n_Alfrel_item=0;n_Alfrel_item<referencenumberfound;n_Alfrel_item++)
											{
												ifail = AE_find_dataset_named_ref(datasetAlf,n_Alfrel_item,refname,&reftype,&refobject);
												CHECK_FAIL;
												
												ifail =  IMF_ask_original_file_name(refobject,Alforig_name);
												//ifail =  IMF_ask_file_pathname(refobject,2,pathnamee);
												//ifail =  IMF_ask_volume(refobject,&vol);

												//if( AOM_ask_value_string(vol,"volume_name",&vol_name)!=ITK_ok);
												//CHECK_FAIL;
												//if( AOM_ask_value_string(vol,"node_name",&nod_name)!=ITK_ok);
												//CHECK_FAIL;
												
												printf("\t 11..Alforig_name is : %s   AlfJTname:%s",Alforig_name,AlfJTname); fflush(stdout);
												//printf("\t 11..pathnamee is :%s\n",pathnamee); fflush(stdout);
												//printf("\t 11..pathnamee is :%s\n",vol_name); fflush(stdout);

												if(tc_strcmp(AlfJTname,Alforig_name) == 0)
												{
													printf("\n\n\t ALF is already present in BomLine...\n"); fflush(stdout);
													AlfAttachedFlag = 1;
													break;
												}
											}
										}
									}

									if (AlfAttachedFlag == 0)
									{
										printf("\n\t AlfAttachedFlag: %d\n\t ",AlfAttachedFlag); fflush(stdout);

										ITK_CALL(BOM_line_add_absocc_relation(bom_line_tag , relation_type , AlfDataSet_tag , &alf_Relation));
										////if( BOM_line_add_absocc_relation(bom_line_tag , relation_type , AlfDataSet_tag , &alf_Relation)!=ITK_ok);
										////CHECK_FAIL;
										if (alf_Relation != NULLTAG)
										{
											printf("\n\t ALF relation created\n");
											//ifail = AOM_save( bom_line_tag );
											ifail = BOM_save_window( window );
											CHECK_FAIL;
											if(ifail == ITK_ok)
											{
												printf("\n\t BOM_save_window is set\n");
											}
											else
											{
												printf("\n\t ???? BOM_save_window is not set......\n");
											}
										}
										else
										{
											printf("\n\t ALF relation NOT-CREATED for  %s \n\n",orig_name);
										}
									}
								}
							}
							else
							{
								printf("\n\t ALF-JT dataset tag NOT FOUND..... \n");
							}
						//}
					}
					else
					{
						printf("\t BOM_window_ask_absocc_edit_mode is OFF ??\n");
					}

					//BOM_line_ask_absocc_relation ( bom_line_tag, NULLTAG, "IMAN_Rendering", TRUE, &k, &related_items);
				}
			//} //else
		}
	}
	//printf ("\n...1..."); fflush(stdout);

   // printf ("%3d", depth);
    //for (i = 0; i < depth; i++)      
	//	printf ("  ");
  //  printf ("%-20s %s\n", name, sequence_no == NULL ? "<null>" : sequence_no);

    //ifail = BOM_line_ask_child_lines (bom_line_tag, &no_bom_lines, &child_bom_lines);
    //CHECK_FAIL;
	ifail = BOM_line_ask_all_child_lines( bom_line_tag , &no_bom_lines , &child_bom_lines );
	CHECK_FAIL;
    
	//printf ("\n\n\n"); fflush(stdout);

	//printf ("  no_bom_lines:: %d",no_bom_lines); fflush(stdout);

	// (no_bom_lines > 0)
	if ((no_bom_lines > 0) && (tc_strcmp(Item_id_par,Parent_name)==0))
	{
		Parentlevel = level0;
		ParentBomLine = bom_line_tag;
	}
	
	for (i = 0; i < no_bom_lines; i++)
	{
		//printf ("\t **Calling BOM_line_unpack for child_bom_lines...[%d] \n",i);
		ifail = BOM_line_unpack (child_bom_lines[i]);
		CHECK_FAIL;
		print_bom (child_bom_lines[i], bom_line_tag, depth , AlfJTname, AlfJTnameCmp, AlfChildPart , ImmidiateParent);
	}
	//printf ("\n...2..."); fflush(stdout);
    MEM_free (child_bom_lines);
    MEM_free (name);
	//printf ("\n...3..."); fflush(stdout);
    //MEM_free (sequence_no);
	//printf ("\n...4..."); fflush(stdout);
}
