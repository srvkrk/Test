/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			:   BomLevelCatiaList.c
*  Author		:   Aniket P. Kadu
*  Module        :   TCUA Downloader.
*  Purpose       :   To Download Catia Parts.
*                             
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/


#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <ReadFile.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#define NUMBER 5000

//From TC Part Getting the Visualization Files...
status GetTCPartInfoForContextBOMViewJTCreationBOMLevel(ObjectPtr TCPartObjP,FILE *fp,FILE *catiafp,FILE* catiadrwfp,string OutputFileNameSDup,string partrevSeq,integer* mfail )
{

	int LatestDoc=0;
	int DataItem=0;
	int VisFile=0;
	int printedtofile=0;

	string  TCPartOwnerNameDupS=NULL;
	string  TCPartOwnerNameS=NULL;
	string  DocBIClassNameDupS=NULL;
	string  DocBIClassNameS=NULL;
	string  VisFileRelPathDupS=NULL;
	string  VisFileRelPathS=NULL;
	string  VisFileWorkingRelativePathDupS=NULL;
	string  VisFileWorkingRelativePathS=NULL;
	string  VisFileSequenceDupS=NULL;
	string  VisFileSequenceS=NULL;
	string  VisFileClassDupS=NULL;
	string  VisFileClassS=NULL;
	string  VisFileOwnerNameDupS=NULL;
	string  VisFileOwnerNameS=NULL;
	string  TCPartNumberDupS=NULL;
	string  TCPartNumberS=NULL;
	string  TCPartRevisionDupS=NULL;
	string  TCPartRevisionS=NULL;
	string  TCPartSequenceDupS=NULL;
	string  TCPartSequenceS=NULL;
	string  TCPartTypeDupS=NULL;
	string  TCPartTypeS=NULL;
	string  VisFileOwnerDirNameS=NULL;
	string  VisFileOwnerDirNameDupS=NULL;
	string  DiClassS=NULL;
	string  DiClassDupS=NULL;
	string CatiaWorkingPathDupS=NULL;
	string CatiaWorkingPathS=NULL;
	string CatiaRelPathS=NULL;
	string CatiaRelPathDupS=NULL;
	string CatiaSequenceDupS=NULL;
	string CatiaSequenceS=NULL;
	string CatiaOwnerDirNameDupS=NULL;
	string CatiaOwnerDirNameS=NULL;
	string CatiaOwnerNameDupS=NULL;
	string CatiaOwnerNameS=NULL;
	string DrawingIndDupS=NULL;
	string DrawingIndS=NULL;

	SetOfObjects  JTUsesPartFilePhyItemSO = NULL ;
	SetOfObjects  JTUsesPartFileRelSO = NULL ;
	SetOfObjects  DocumentSO = NULL ;
	SetOfObjects  DocumentRelSO = NULL ;
	SetOfObjects  LatestDocSO = NULL ;
	SetOfObjects  LatestRelDocSO = NULL ;
	SetOfObjects  DataItemSO = NULL ;
	SetOfObjects  VisualizationFileSO = NULL ;
	SetOfObjects allObjSet12=NULL;
	SetOfObjects allObjRels12=NULL;

	int printeddrwtofile=0;
	int size1=0;
	int size2=0;
	int i=0;
	ObjectPtr allObjP=0;
	ObjectPtr soObj1P=0;
	string DocClassS=NULL;
	string DrwDocNameDup=NULL;
	string DrwDocName=NULL;
	SET_PTR		ReqDrwSetObj;
	SetOfStrings		distDrwDocNamSOS	=	NULL;
	SetOfObjects soObj2=NULL;
	SetOfObjects soObj=NULL;
	string			sDocno			=	NULL;
	SqlPtr sql1=NULL;

	ObjectPtr LatestDocObjP=NULL;
	ObjectPtr NewDataItemObjP=NULL;
	ObjectPtr DataItemObjP=NULL;
	ObjectPtr NewVisFileObjP=NULL;
	ObjectPtr VisFileObjP=NULL;
	FILE *fperr=NULL;
	t5MethodInit("GetTCPartInfoForContextBOMViewJTCreationBOMLevel");

	//objDump(TCPartObjP);
	t5CheckDstat(objGetAttribute(TCPartObjP,OwnerNameAttr,&TCPartOwnerNameDupS));
	TCPartOwnerNameS=nlsStrDup(TCPartOwnerNameDupS);
	printf("\n Executing Function For Resultant TC Part OwnerNameS:%s \n",TCPartOwnerNameS); fflush(stdout);

	t5CheckDstat(objGetAttribute(TCPartObjP,PartTypeAttr,&TCPartTypeDupS));
	TCPartTypeS=nlsStrDup(TCPartTypeDupS);
	//-------
	t5CheckDstat(objGetAttribute(TCPartObjP,PartNumberAttr,&TCPartNumberDupS));
	TCPartNumberS=nlsStrDup(TCPartNumberDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,RevisionAttr,&TCPartRevisionDupS));
	TCPartRevisionS=nlsStrDup(TCPartRevisionDupS);
	t5CheckDstat(objGetAttribute(TCPartObjP,SequenceAttr,&TCPartSequenceDupS));
	TCPartSequenceS=nlsStrDup(TCPartSequenceDupS);

	printf("\n Executing Part Number:[%s]",TCPartNumberS);fflush(stdout);
	printf("\n Executing Function For Resultant TC Part TCPartTypeS:%s \n",TCPartTypeS); fflush(stdout);

	if (!nlsStrCmp(TCPartOwnerNameS,"WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"JSR WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"LKO WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"HNJ WIP Vault") ||!nlsStrCmp(TCPartOwnerNameS,"JSR Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"LKO Release Vault") ||!nlsStrCmp(TCPartOwnerNameS,"HNJ Release Vault") || nlsStrStr(TCPartOwnerNameS,"CE Vault")!=NULL)
	{
		printf("\n This Expand Object");fflush(stdout);
		t5CheckMfail(ExpandObject2(PartDocClass,TCPartObjP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&DocumentSO,&DocumentRelSO,mfail));

		if(setSize(DocumentSO)==0)
		{
			printf("\n There is no Qualified Documents for this part (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function)\n"); fflush(stdout);
			goto CLEANUP;
		}else
		{
					printf("\n This Expand Object 2");fflush(stdout);
					//fprintf(fp,"SKIPJT\n");
		}
		/* Get Latest documents from set */
		t5CheckMfail(t5GetLatestDocumnets(DocumentSO,DocumentRelSO,&LatestDocSO,&LatestRelDocSO,mfail));

		printf("\n This Expand Object 3");fflush(stdout);

		for(LatestDoc=0;LatestDoc<setSize(LatestDocSO);LatestDoc++)
		{
			LatestDocObjP=((ObjectPtr)setGet(LatestDocSO,LatestDoc));

			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Current Running serial of LatestDoc is:%d \n",LatestDoc); fflush(stdout);
			//objDump(LatestDocObjP);
			t5CheckDstat(objGetAttribute(LatestDocObjP,ClassAttr,&DocBIClassNameDupS));
			DocBIClassNameS=nlsStrDup(DocBIClassNameDupS);
			printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) Document (Business Item) Class Name is:%s \n",DocBIClassNameS); fflush(stdout);
			printf("\n Document Class:[%s]",DocBIClassNameS);
			if((nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0) || (nlsStrCmp(DocBIClassNameS,"DesDoc")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0) || (nlsStrCmp(DocBIClassNameS,"t5MulCad")==0) )
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));


				printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) NO OF Data Item available for this DocClass:%s and Count is:%d \n",DocBIClassNameS,setSize(DataItemSO)); fflush(stdout);

				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						if( (nlsStrCmp(DiClassS,"x0CatPrt")==0 || nlsStrCmp(DiClassS,"x0CatPrd")==0) && (nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0 || nlsStrCmp(DocBIClassNameS,"t5MulCad")==0 || nlsStrCmp(DocBIClassNameS,"x0PrdDoc")==0 || nlsStrCmp(DocBIClassNameS,"DesDoc")==0 ))
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);
								
								printf("\n Cad Relative Path :[%s]",CatiaRelPathS);

								if(nlsStrStr(CatiaRelPathS,"Spec")==NULL)
								{
									printf("\n This is not a spec file");
									if(printedtofile==0)
									{

										printf("\n This is not a spec file 111111111111\n\n");
										fprintf(catiafp,"%s",CatiaOwnerNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaWorkingPathS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaRelPathS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaSequenceS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s","UserSelectedTCPart");
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",CatiaOwnerDirNameS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",TCPartNumberS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",TCPartRevisionS);
										fprintf(catiafp,",");
										fprintf(catiafp,"%s",TCPartSequenceS);
										fprintf(catiafp,"\n");
										fflush(catiafp);
										printedtofile=1;
									}

									else
									{   
										
										//To handle non bom attached to Des doc.
										//This is other than spec file.
										//only for assembly............
										printf("\n This is not a spec file 22222222222\n\n");
										if(nlsStrCmp(DocBIClassNameS,"DesDoc")==0 )
										{
											printf("\n This is not a spec file 33333333333\n\n");
											fprintf(fp,"%s",CatiaOwnerNameS);
											fprintf(fp,",");
											fprintf(fp,"%s",CatiaWorkingPathS);
											fprintf(fp,",");
											fprintf(fp,"%s",CatiaRelPathS);
											fprintf(fp,",");
											fprintf(fp,"%s",CatiaSequenceS);
											fprintf(fp,",");
											fprintf(fp,"%s","UserSelectedTCPart");
											fprintf(fp,",");
											fprintf(fp,"%s,",CatiaOwnerDirNameS);
											fprintf(fp,"%s",partrevSeq);
											fprintf(fp,"\n");
											fflush(fp);
										}

										if(nlsStrCmp(DocBIClassNameS,"t5MulPrd")==0 || nlsStrCmp(DocBIClassNameS,"t5MulCad")==0)
										{
											printf("\n This is not a spec file 44444444\n\n");
											fprintf(catiafp,"%s",CatiaOwnerNameS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",CatiaWorkingPathS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",CatiaRelPathS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",CatiaSequenceS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s","UserSelectedTCPart");
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",CatiaOwnerDirNameS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",TCPartNumberS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",TCPartRevisionS);
											fprintf(catiafp,",");
											fprintf(catiafp,"%s",TCPartSequenceS);
											fprintf(catiafp,"\n");
											fflush(catiafp);
											printedtofile=1;
										}

									}

								}else
								{
										
										//This is for spec file attached to desc doc.....
										printf("\n Spec Spec... Spec Spec.... Spec.... Spec....");
										fprintf(fp,"%s",CatiaOwnerNameS);
										fprintf(fp,",");
										fprintf(fp,"%s",CatiaWorkingPathS);
										fprintf(fp,",");
										fprintf(fp,"%s",CatiaRelPathS);
										fprintf(fp,",");
										fprintf(fp,"%s",CatiaSequenceS);
										fprintf(fp,",");
										fprintf(fp,"%s","UserSelectedTCPart");
										fprintf(fp,",");
										fprintf(fp,"%s,",CatiaOwnerDirNameS);
										fprintf(fp,"%s",partrevSeq);
										fprintf(fp,"\n");
										fflush(fp);
								}
						}
					}

				  }
			}else if(nlsStrCmp(DocBIClassNameS,"t5DrwDoc")==0)
			{
				t5CheckMfail(ExpandObject5(AttachClass,LatestDocObjP,"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
				if (setSize(DataItemSO)==0)
				{
					//printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this Document..\n"); fflush(stdout);

				}
				if(setSize(DataItemSO)>0)
				  {
					//CODE For Getting the Data Item Files
					for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
					{
						NewDataItemObjP=setGet(DataItemSO,DataItem);

						t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
						DiClassS=nlsStrDup(DiClassDupS);
						printf("\n Data item class name:[%s]",DiClassS);
						if(nlsStrCmp(DiClassS,"x0CatDrw")==0)
						{
								printf("\n Found out an Catia Item");fflush(stdout);

								t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
								CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
								CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
								CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
								CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
								t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
								CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);

									if(printeddrwtofile==0)
									{
										fprintf(catiadrwfp,"%s",CatiaOwnerNameS);
										fprintf(catiadrwfp,",");
										fprintf(catiadrwfp,"%s",CatiaWorkingPathS);
										fprintf(catiadrwfp,",");
										fprintf(catiadrwfp,"%s",CatiaRelPathS);
										fprintf(catiadrwfp,",");
										fprintf(catiadrwfp,"%s",CatiaSequenceS);
										fprintf(catiadrwfp,",");
										fprintf(catiadrwfp,"%s","Specification");
										fprintf(catiadrwfp,",");
										fprintf(catiadrwfp,"%s,",CatiaOwnerDirNameS);
										fprintf(catiadrwfp,"%s",partrevSeq);
										fprintf(catiadrwfp,"\n");
										fflush(catiadrwfp);
										printeddrwtofile=1;
									}

						}
					}
				  }
			}
			else 
			{
				 //fprintf(fp,"SKIPJT\n");
			   printf("\n Not a Valid Doc class \n"); fflush(stdout);
			}
		}

		t5CheckDstat(objGetAttribute(TCPartObjP,t5DrawingIndAttr,&DrawingIndDupS));
		DrawingIndS=nlsStrDup(DrawingIndDupS);

		if(printeddrwtofile==0 && nlsStrCmp(DrawingIndS,"D")==0)
		{

			t5CheckMfail(ExpandObject2(InfoDwgClass,TCPartObjP,"t5AssmhasInfDwg",SC_SCOPE_OF_SESSION,&allObjSet12,&allObjRels12,mfail));

			ReqDrwSetObj		=	low_set_create(100);
			distDrwDocNamSOS=setCreate(1);

			size1 = setSize(allObjSet12);
			printf("\n Number of docs in Ref Link=%d\n",size1);
			if (size1>0)
			{

				for (i=0;i<setSize(allObjSet12);i++)
				{
					allObjP=setGet(allObjSet12,i);
					if(dstat = objGetClass(allObjP,&DocClassS))   goto EXIT;

					if(nlsStrCmp(DocClassS,"t5DrwDoc")==0)
							low_set_add (ReqDrwSetObj,allObjP);					
				}

				size2 = setSize(ReqDrwSetObj);

				if (size2 > 0)
				{
					//printf("\n''''''''''''''''''''Inside DrwDoc''''''''''''''\n");
					for(i=0; i<size2; i++)
					{
					t5CheckDstat(objGetAttribute(setGet(ReqDrwSetObj, i), DocumentNameAttr, &DrwDocNameDup) );
					DrwDocName = nlsStrDup(DrwDocNameDup);
					set_add_str_unique(distDrwDocNamSOS, DrwDocName);
					}
					
					for (i=0; i<setSize(distDrwDocNamSOS); i++ )
					{
						sDocno=setGetStr(distDrwDocNamSOS,i);
						
						// Querying for Latest Drawing Document
						if((dstat = oiSqlCreateSelect(&sql1)) ||
						(dstat = oiSqlWhereBegParen(sql1)) ||
						(dstat = oiSqlWhereEQ(sql1,DocumentNameAttr,sDocno)) ||
						(dstat = oiSqlWhereAND(sql1)) ||
						(dstat = oiSqlWhereLike(sql1,SupersededAttr,"-")) ||
						(dstat = oiSqlWhereEndParen(sql1))) goto CLEANUP;

						if(dstat = QueryWhere(t5DrwDocClass, sql1, &soObj2, mfail)) goto CLEANUP;

						if (setSize(soObj2)>0) 
						{
							if (setSize(soObj)==0)
								soObj=setCreate(5);
									
								soObj1P=setGet(soObj2,0);
								setAdd(soObj,soObj1P);
						}
					}
				}
			}

				printf("\n No of Reference Document found is :[%d]",setSize(soObj));

				if(setSize(soObj)>0)
				{

					t5CheckMfail(ExpandObject5(AttachClass,setGet(soObj,0),"DataItemsAttachedToBusItem",SC_SCOPE_OF_SESSION,&DataItemSO,mfail));
					if (setSize(DataItemSO)==0)
					{
						printf("\n (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) There is no Qualified Data Items for this reference Document..\n"); fflush(stdout);

					}
					if(setSize(DataItemSO)>0)
					{

						for(DataItem=0;DataItem<setSize(DataItemSO);DataItem++)
						{
							NewDataItemObjP=setGet(DataItemSO,DataItem);

							t5CheckDstat(objGetAttribute(NewDataItemObjP,ClassAttr,&DiClassDupS));
							DiClassS=nlsStrDup(DiClassDupS);
							printf("\n Data item class name:[%s]",DiClassS);
							if(nlsStrCmp(DiClassS,"x0CatDrw")==0)
							{
									printf("\n Found out an Catia Item");fflush(stdout);

									t5CheckDstat(objGetAttribute(NewDataItemObjP,RelativePathAttr,&CatiaRelPathDupS));
									CatiaRelPathS=nlsStrDup(CatiaRelPathDupS);
									t5CheckDstat(objGetAttribute(NewDataItemObjP,WorkingRelativePathAttr,&CatiaWorkingPathDupS));
									CatiaWorkingPathS=nlsStrDup(CatiaWorkingPathDupS);
									t5CheckDstat(objGetAttribute(NewDataItemObjP,SequenceAttr,&CatiaSequenceDupS));
									CatiaSequenceS=nlsStrDup(CatiaSequenceDupS);
									t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerNameAttr,&CatiaOwnerNameDupS));
									CatiaOwnerNameS=nlsStrDup(CatiaOwnerNameDupS);
									t5CheckDstat(objGetAttribute(NewDataItemObjP,OwnerDirNameAttr,&CatiaOwnerDirNameDupS));
									CatiaOwnerDirNameS=nlsStrDup(CatiaOwnerDirNameDupS);

									fprintf(catiadrwfp,"%s",CatiaOwnerNameS);
									fprintf(catiadrwfp,",");
									fprintf(catiadrwfp,"%s",CatiaWorkingPathS);
									fprintf(catiadrwfp,",");
									fprintf(catiadrwfp,"%s",CatiaRelPathS);
									fprintf(catiadrwfp,",");
									fprintf(catiadrwfp,"%s",CatiaSequenceS);
									fprintf(catiadrwfp,",");
									fprintf(catiadrwfp,"%s","Reference");
									fprintf(catiadrwfp,",");
									fprintf(catiadrwfp,"%s,",CatiaOwnerDirNameS);
									fprintf(catiadrwfp,"%s",partrevSeq);
									fprintf(catiadrwfp,"\n");
									fflush(catiadrwfp);

							}
						}

					}
				}
		}
	}
	else
	{
		printf("\n The Resultant TC Part is not in Vault(Func)..\n"); fflush(stdout);

	}

CLEANUP:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) CLEANUP..\n"); fflush(stdout);
		t5PrintCleanUpModName;

		t5FreeSetOfObjects(DocumentSO);
		t5FreeSetOfObjects(DocumentRelSO);
		t5FreeSetOfObjects(LatestDocSO);
		t5FreeSetOfObjects(LatestRelDocSO);
		t5FreeSetOfObjects(DataItemSO);


EXIT:
		//printf("\n Function GetTCPartInfoForContextBOMViewJTCreationBOMLevel (Executing GetTCPartInfoForContextBOMViewJTCreationBOMLevel Function) EXIT..\n"); fflush(stdout);
		t5CheckDstatAndReturn;

};

struct func
 {
   char InpPartNumberS[40]   ;  

  } InputDataFileS[4000];


//Main Program for ContextBOMViewJTCreationBOMLevel
int main(int argc, char *argv[])
{
	int stat=0;
	int i, elmt1=0;
	int c1=0;
	int c2=0;
	int c4=0;

	string  LoginS=NULL;
	string  PasswordS=NULL;
	string  InputFileNameS=NULL;
	string  OutHideJTNameS=NULL;
	string  OutHideTCNameS=NULL;
	string  selectedVaultS=NULL;
	string  CatiaFileS=NULL;
	string  partrevSeq=NULL;

	char	store[2000];

	SetOfObjects  PartResultSO = NULL ;

	ObjectPtr TCPartObjP=NULL;

	SqlPtr  InputTCPartSqlPtr = NULL;

	//File Declaration
	FILE	*fp	= NULL;
	FILE	*fpInputDataFile	= NULL;
	FILE	*fperr	= NULL;
	FILE    *catiafp=NULL;
	FILE    *catdrwfp=NULL;

	///         ///
	string		docobjst	=	NULL;
	string		DrawingFileS	=	NULL;
	int		ii		=          0;
	SetOfStrings      dbScp	=          NULL;



	t5MethodInitWMD("HidePartsAndJT");

	//printf("\n Executing... main:ContextBOMViewJTCreationBOMLevel.c ... \n");

	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	InputFileNameS=nlsStrAlloc(200);
	OutHideJTNameS=nlsStrAlloc(200);
	OutHideTCNameS=nlsStrAlloc(200);
	

	LoginS=argv[1];
	PasswordS=argv[2];
	InputFileNameS=argv[3];
	OutHideJTNameS=argv[4];
	OutHideTCNameS=argv[5];
	
	//printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}


	///////////////////////////////////////
            t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
							docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	//t5CheckDstat(getDataBaseSetByUser(&dbScp,selectedVaultS,mfail));
	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}
	//////////////////////////////////////////////////////////

	/***   To Get the Input Details From Reading Input Text File ***/

	fpInputDataFile = fopen(InputFileNameS,"r");

	 while(fgets(store, NUMBER, fpInputDataFile)!=NULL)
		{
			c1  =0;
			for(i=1; i<=5 ; i++)
			{
				c2=0;
				switch(i)
				{
                   
				   /*** Getting Part Level***/
				   case 1:
                   for(c2=0;store[c1]!=','; c1++)
                   {
					InputDataFileS[elmt1].InpPartNumberS[c2]=store[c1];
					c2++;
                   }
                                  
				}
                c1++;
			}
			 elmt1++;
		 }

	printf("\n File Read is get completed in Hide \n");


	catiafp=fopen(OutHideJTNameS,"w");	fflush(catiafp);	
	catdrwfp=fopen(OutHideTCNameS,"w");	fflush(fp);
		
	for(c4=0; c4<elmt1; c4++)
	{

	printf("\n Going into next loop");fflush(stdout);
	printf("\n\n\n Reading From Buffer and Processing the Line Number:%d \n\n",c4+1); fflush(stdout);
	printf("\n From Data File Input Part Number is:%s \n",InputDataFileS[c4].InpPartNumberS); fflush(stdout);
	
	//Code For Handling Assembly and Component in the Collection
	t5CheckDstat(oiSqlCreateSelect(&InputTCPartSqlPtr));
	t5CheckDstat(oiSqlWhereEQ(InputTCPartSqlPtr,RelativePathAttr,InputDataFileS[c4].InpPartNumberS));	
	t5CheckMfail(QueryWhere(ProObjClass,InputTCPartSqlPtr,&PartResultSO,mfail));
	printf("\nthe setsize of PartResultSO is ---->%d\n",setSize(PartResultSO));
		
	if(setSize(PartResultSO)==1)
	{
		TCPartObjP=setGet(PartResultSO,0);
		printf("\n Calling the Function for GetJTHideList Starts\n"); fflush(stdout);
		//t5CheckMfail(GetJTHideList(TCPartObjP,catiafp,mfail));
		printf("\n Calling the Function for GetJTHideList Endsss\n"); fflush(stdout);

		printf("\n Calling the Function for GetTCHideList Starts\n"); fflush(stdout);
		//t5CheckMfail(GetTCHideList(TCPartObjP,catdrwfp,mfail));
		printf("\n Calling the Function for GetTCHideList Endsss\n"); fflush(stdout);
		
	}
	else if(setSize(PartResultSO)>1)
	{
		printf("\n so,This is not Possible Use Case now in Hide\n");
		//goto EXIT;
	}
	else
	{
		//goto CLEANUP;
	}

	}	

fclose(fp);
fclose(catiafp);
fclose(catdrwfp);


CLEANUP:
		t5PrintCleanUpModName;
		t5FreeSetOfObjects(PartResultSO);


EXIT:
		t5CheckDstatAndReturn;
}
;
