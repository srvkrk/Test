/****************************************************************************************************
*  File                 :		Save_validation.c
*  Created By     :		Sudhir Srivastava
*  Created On    :		05-Sept-2011
*  Purpose         :		 Remove extra character from Desciption of Design and Design Revision.
*					This is called at pre action of save.
*   Modification History :  Added save_method_5 and save_method_4 for Attribute Mapping of Design Reision/CMI2Drawing
*   Modification Date     : 15/06/2012 Modification  By	      :Sharvari Karale

*   Modification Date     : 04/05/2016 Modification  By	      :Muktesh Girdhani
	Purpose         : Removed file createpost (createpost.so) and added code in this file, Updation of NR;1 Revision done in this file.

******************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/project.h>
#include <tccore/tc_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <bom/bom_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <sa/workcontext.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/sa_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 919006
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_errStore (EMH_USER_error_base + 3)
#define ITK_errStore1 (EMH_USER_error_base + 7)

/************************* Adi ****************/

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

/************************* Adi ****************/

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
//Vitthal :START: Validate Part Creation
int Validate_On_Creation(tag_t DesignRevision)
{
	char* sPartType;
	char* sStartPrtProd;
	char *sUserInfoVal = NULL;
	char *sDesGrp = NULL;

	tag_t
		TagQryContObjDsgGrp = NULLTAG,
		*cntr_objects = NULL;
	int	n_entries = 2;
	int n_found = 0;

	char *qry_entries[2] = {"SYSCD", "SUBSYSCD"};
    char *qry_values[2] = {"TOOLTYPE", "DESIGNGROUP"};

	if (AOM_ask_value_string(DesignRevision,"t5_PartType",&sPartType)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(DesignRevision,"t5_StartPartProduct",&sStartPrtProd)!=ITK_ok)   PrintErrorStack();
	if(	AOM_ask_value_string(DesignRevision,"t5_DesignGrp",&sDesGrp)!=ITK_ok);PrintErrorStack();

	printf("\n AOM_ask_value_string sPartType  %s sStartPrtProd  %s \n",sPartType,sStartPrtProd);fflush(stdout);

	 if(QRY_find2("ControlObjFindCadToolBasedOnDesGrp", &TagQryContObjDsgGrp));

	 if(QRY_execute(TagQryContObjDsgGrp, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	 printf("\n Objects for Query ControlObjFindCadToolBasedOnDesGrp == %d", n_found);fflush(stdout);

	 if(n_found==1)
	 {
		if( AOM_ask_value_string(cntr_objects[0],"t5_userinfo10",&sUserInfoVal));
		 printf("\n Information 10 Value == [%s] and User Enter Design Group :[%s]", sUserInfoVal,sDesGrp);fflush(stdout);
		if(tc_strstr(sUserInfoVal, sDesGrp) != NULL)
		{
			if(((strcmp(sPartType,"A")==0) ||(strcmp(sPartType,"C")==0) ||(strcmp(sPartType,"T")==0) ||(strcmp(sPartType,"G")==0)) && (tc_strcmp(sStartPrtProd,"")==0))return 1;
		}
	 }
	return 0;
}
//Vitthal :END: Validate Part Creation

extern DLLAPI int  save_method_3(METHOD_message_t *msg, va_list args)
{

      int error_code = ITK_ok;
      tag_t objTag = va_arg(args, tag_t);
      //logical flag = va_arg(args, logical);
      tag_t objTypeTag = NULLTAG;
      char   type_name[TCTYPE_name_size_c+1];

      char   *desid=NULL;

      char   *DesRevDesc=NULL;
      char   *ReplacedDesRevDesc=NULL;
      char   *NewReplacedDescription=NULL;
	char   *ItemMaterial=NULL;

int desclength= 0;
int revdesccnt= 0;


      EPM_decision_t decision=EPM_go;

      printf("\n save_method_3::It's the time to save ItemRevision \n");fflush(stdout);


      if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
      if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
      if(strcmp(type_name,"Design")==0)
      {
            if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();

            if( AOM_ask_value_string(objTag,"object_desc",&DesRevDesc)!=ITK_ok);PrintErrorStack();

	  // if( AOM_ask_value_string(objTag,"t5Material",&ItemMaterial)!=ITK_ok);

            printf("\n save_method_3::Design Revision Item ID %s and ItemMaterial :%s\n", desid,ItemMaterial);fflush(stdout);


		if(strcmp(DesRevDesc,"")!=0)
		{
		desclength = strlen(DesRevDesc);
		for(revdesccnt=0;revdesccnt<desclength;revdesccnt++)
		{
			if(DesRevDesc[revdesccnt]=='\n')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='`')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='~')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='|')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='$')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='#')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='@')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='^')
				DesRevDesc[revdesccnt] =' ';

			if(DesRevDesc[revdesccnt]=='!')
				DesRevDesc[revdesccnt] =' ';
			printf("\n [%c]\n",DesRevDesc[revdesccnt]);fflush(stdout);
		}
		ReplacedDesRevDesc = (char *)MEM_alloc (desclength * sizeof(char));
		strcpy(ReplacedDesRevDesc,DesRevDesc);



			printf("\n AFTER SET SAVE_METHOD_1::ReplacedDesRevDesc=====>[%s]\n",ReplacedDesRevDesc);fflush(stdout);
			if(ReplacedDesRevDesc)
			{
			if(AOM_set_value_string(objTag,"object_desc",ReplacedDesRevDesc)!=ITK_ok);PrintErrorStack();
			if(AOM_save(objTag)!=ITK_ok);PrintErrorStack();
			if( AOM_ask_value_string(objTag,"object_desc",&NewReplacedDescription)!=ITK_ok);PrintErrorStack();
			printf("\n AFTER SET SAVE_METHOD_1::NewReplacedDescription==>[%s]\n", NewReplacedDescription);fflush(stdout);
			}
	 }

      }
      return error_code;
}


extern DLLAPI int  save_method_4(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag,item_tag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *desid = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *DerRoleNme = NULL;
	char *DerRoleNme1 = NULL;
	char *NewDescription = NULL;
	tag_t rev=NULLTAG;
	char *objname = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	char *ActGmName = NULL;
	char *ActGmName1 = NULL;
	double objWeight ;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));
	tag_t	queryTag	= NULLTAG;

	tag_t*	resultTags =NULLTAG;
	char *DrwName		= NULL;
	char *DrwName1		= NULL;
	char *parent_name	= NULL;
	char *group_name	= NULL;
	char *Role_name		= NULL;
	char *Grp_name		= NULL;
	char *Desc_obj2		= NULL;
	char *item_rev_id	= NULL;
	char *currpro		= NULL;
	tag_t attr_id ;
	int				cnt=0;
	int				Rolflag1=0;
	int				Gmcnt=0;
	int				Gmcnt1=0;
	int				Gmcnt2=0;
	int				Gmcnt3=0;
	tag_t			*attachments								= NULLTAG;
	tag_t			*GmFound								= NULLTAG;
	tag_t			*GmFound1								= NULLTAG;
	tag_t			*GmFound2								= NULLTAG;
	tag_t			*GmFound3								= NULLTAG;
	int				ij=0;
	int				jk=0;
	int				jkl=0;
	int				Rolflag=0;
	int				dsflag=0;
	char
        *qry_entries[2] = {"Name","Type"},
        *qry_values[2]	= {"*","CMI2Drawing"};
	int     index,resultCount=0,j=0;
	char		   *ObjectClassType		= NULL;
	char		   *ObjectName		= NULL;
	char		   *desi_grp		= NULL;
	 char* oojname = NULL;
tag_t form_attr_id ;
tag_t			relation_type								= NULLTAG;
tag_t			DesRolTag								= NULLTAG;
tag_t			Currproj								= NULLTAG;
tag_t			GroupMem								= NULLTAG;
tag_t			Roletag								= NULLTAG;
tag_t			grptag								= NULLTAG;
tag_t   projobj;
tag_t			dataset		= NULLTAG;
tag_t			ActGm		= NULLTAG;
tag_t			ActGm1		= NULLTAG;
tag_t			status_rel					= NULLTAG;
tag_t			projid					= NULLTAG;
tag_t    tagItem=NULLTAG;
logical	checkout				= 0;
logical	checkoutp				= 0;
logical			retain							= 0;

logical	promem				= 0;

 tag_t reln_type =NULLTAG;
   tag_t*      secondary_objects=NULLTAG;
   char* username;
        tag_t user_tag=NULLTAG;
	const char	   reason;
	const char	   reason1;
	const char     change_id;
	const char     change_id1;
	const char     dir_name;
	const char     dir_name1;
	char	*ObjProject= NULL;
	 char *dst_name = NULL;
	char *objPartType = NULL;
	char		   *object_typeDS		= NULL;

	char type_name2[TCTYPE_name_size_c+1];
	double objWeightVal ;
	double roundedWtVal ;
	char wgtstr[100];

	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";//Adi
	char *DesignGrpCatia = NULL;//Adi
		char *Rev_id			= NULL;//Adi
	char *Rev_Sub			= NULL;//Adi
	char *Rev_Sub1			= NULL;//Adi
	int   Rev_idlength		= 0;	   //Adi
	char *PartTypeDR		= 0;	   //Adi

	/************ Adi 1.35 ***********/
	//tag_t	Attdataset		= NULLTAG;
	tag_t  *DiAttached		= NULLTAG;
	int	    pp				= 0;
	int     catcnt			= 0;
	char   *ObjectTypeX		= NULL;
	tag_t	rev1			= NULLTAG;
	char	*Desc_obj		= NULL;
	tag_t   relation_typeX  = NULLTAG;
	int		PrtChkFlag		=	0;
	int		PrdChkFlag		=	0;

	/************ Adi 1.35 ***********/

	//1.25
	tag_t   qryTag     = NULLTAG;
	int     n_entry    = 1;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	int     rsltCount      =  0;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char	*DesgTyp	= NULL;
	char	*info1	= NULL;
	char	*MPart_Desg	= NULL;
	char	*Part_DegGrp	= NULL;
	char	*Part_prj	= NULL;
	char	*DesgNo	= NULL;
	char	*sDesgNoG	= NULL;
	char	*sDesgNoT	= NULL;
	char	*sDesgNoVC	= NULL;
	char	*sDesgNoV	= NULL;
	char	*sDesgNoVCCR	= NULL;
	char	*PrtProj	= NULL;
	char	*info2	= NULL;
	char	*Prttyp	= NULL;
	char	*PrtDR	= NULL;
	char	*sDesgNoD	= NULL;
	char	*Part_Desg	= NULL;
	char	*Part_Proj	= NULL;
	char 	*Proj_typ		= NULL;
	char    *ThirdBarrel    = NULL;
	char    *SpareCrit      = NULL;
	tag_t	Project_t		= NULLTAG;
	tag_t	ObjTypProj	= NULLTAG;
	char   type_Proj[TCTYPE_name_size_c+1];
	//1.25
	//char **val=NULL;
		//Amol
	tag_t TagQryContObjSite = NULLTAG;
	//tag_t *cntr_objects = NULL;
	char   *desidForTRL=NULL;
	char   *sLastThreeChar=NULL;
	char   *NewIDTRL=NULL;
	int CntrCount = 0;
	int	n_Input = 2;
	char *qry_Input[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_InputVal[2] = {"TRILIX", "TRILIX"};
	char   *RepalcedID=NULL;
	char	*DesgTypTRL	= NULL;
	//Amol
	char	*info4	= NULL;
	char *PrtCol = NULL;
	char *PrtClass = NULL;
	tag_t  	PrtCls =	NULLTAG;
	int DRValiFlag=0;
	int iTemp=0;
	char *release_status = NULL;
	int desclength = 0,index1=0;
	int desccnt = 0,n_entries=2;
	int c_attchs = 0,p=0;
	tag_t			primary					= NULLTAG;
	tag_t latest_datas=NULLTAG;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t  CurrentRoleTag = NULLTAG;
	char roleName[SA_name_size_c+1];

	tag_t query = NULLTAG, *cntr_objects = NULL;
	//int n_found = 0;
	char
         *qry_entries1[2] = {"SUBSYSCD", "SYSCD"},
        *qry_values1[2] =  {"*", "MATCLS"};


	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);


	if(strcmp(type_name,"Design Revision")==0)
	{
		printf("\n Inside preaction type Save Validation 4 design revison Session user %s \n",username);fflush(stdout);
		char *projcodeList=NULL;
		char *projcode=NULL;
		tag_t   projobj1;
		if( AOM_ask_value_string(objTag,"project_ids",&projcodeList)==ITK_ok)
		if( AOM_ask_value_string(objTag,"t5_ProjectCode",&projcode)==ITK_ok)
		printf("\n Save Validation 4 Project : <%s> ProjectList : <%s> %d\n",projcode,projcodeList,strlen(projcodeList));fflush(stdout);
		if(strcmp(projcodeList,"")==0 || strlen(projcodeList) < 4) //project_list
		{
			if(strcmp(projcode,"")==0) //project_list
			{
				printf("\n Save Validation 4 Project is  NULL \n");fflush(stdout);
			}
			else
			{
				printf("\n Save Validation 4 TCDCProject from Object in else : %s\n",projcode);fflush(stdout);

				if (PROJ_find(projcode,&projobj1) !=ITK_ok)PrintErrorStack();

				if(projobj1 != NULLTAG)
				{
	//				printf("\nTCDCGetting Master Object for Project\n");fflush(stdout);
	//				if (ITEM_ask_item_of_rev( objTag,&objMasterTag)!=ITK_ok)PrintErrorStack();
	//				printf("\nTCDCAfter Master Object for Project\n");fflush(stdout);
					if (PROJ_assign_objects(1 ,&projobj1 ,1 ,&objTag )!=ITK_ok)PrintErrorStack();
					printf("\n Save Validation 4 Assigned to Project\n");fflush(stdout);
				}
				else
				{
					printf("\n Save Validation 4 Project not found\n");fflush(stdout);
				}
			}
		}
		else
		{
				printf("\n Projectlist already assigned Project : <%s> ProjectList : <%s>\n",projcode,projcodeList);fflush(stdout);
		}
		if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		{
			
			//char   *sPartType1	 =NULL;
			//char   *sCatName	 =NULL;
			//char   *sDesignGrp	 =NULL;
			//if( AOM_ask_value_string(objTag,"t5_PartType",&sPartType1)!=ITK_ok);PrintErrorStack();
			//if( AOM_ask_value_string(objTag,"t5_CategoryName",&sCatName)!=ITK_ok);PrintErrorStack();
			//if(	AOM_UIF_ask_value(objTag,"t5_DesignGrp",&sDesignGrp)!=ITK_ok);PrintErrorStack();

			//if((tc_strcmp(sPartType1,"A")==0 || tc_strcmp(sPartType1,"C")==0))
			//{
				//printf("\n	Keyword description :%s",sCatName);fflush(stdout);				
				//if(tc_strcmp(sCatName,"")==0)
				//{
					
					//printf("\n For  Part [%s]  Keyword description cannot be NULL\n");fflush(stdout);
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description cannot be NULL for parttype Assembly and Component");	
					//return ITK_err;
				//}
				//else
				//{
					//printf("\n	Keyword description :%s, Design Group : %s",sCatName,sDesignGrp);fflush(stdout);
					//char *qry_entries[2] = {"Name","ext_1"};
					//int n_entries= 2,n_found;
					//tag_t query = NULLTAG, *cntr_objects = NULL;
					//char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

					//qry_values[0] = sCatName ;
					//qry_values[1] = sDesignGrp;
					//QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &query);
					//QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects);
					//printf("\nKeyword n_found:%d", n_found);fflush(stdout);
					//if(n_found==0)
					//{
						//EMH_store_error_s1(EMH_severity_error,ITK_err,"Keyword Description for Design Revision is not matched as per given Design Group of Design Revision");
						//return ITK_err;
					//}
				//}
			//}
			if(QRY_find2("ControlObjQry", &TagQryContObjSite));
			if(TagQryContObjSite)
			  {
				 if(QRY_execute(TagQryContObjSite, n_Input, qry_Input, qry_InputVal, &CntrCount, &cntr_objects));
				 printf("\n Objects for Query ControlBasedOnSite == %d", CntrCount);fflush(stdout);
			  }
			  else
			  {
				  printf("\n ContrlObjQry query not found");fflush(stdout);
			  }

				 if(CntrCount >0)
				 {
					 if( AOM_ask_value_string(objTag,"item_id",&desidForTRL)!=ITK_ok);PrintErrorStack();
					 sLastThreeChar=subString(desidForTRL, strlen(desidForTRL)-4,4);
					 printf("\n sLastThreeChar == %s", sLastThreeChar);fflush(stdout);
					 if(tc_strcmp(sLastThreeChar,"_TRL")!=0)
					 {
						  printf("\n For TRILIX SITE part number should end with _TRL: \n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part number should end with '_TRL'.");
						return ITK_err;

					 }

				if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTypTRL)!=ITK_ok)   PrintErrorStack();
				 printf("\n DesgTyp is  = [%s]\n", DesgTypTRL);fflush(stdout);
				  if(tc_strcmp(DesgTypTRL,"D")!=0)
					 {
						  printf("\n For TRILIX site, Part Type should be 'Dummy'\n");fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For TRILIX site, Part Type should be 'Dummy'.");
						return ITK_err;

					 }


				 }


			if(QRY_find("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n CREVali:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n CREVali:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "CREVali" ;
			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n CREVali:rsltCount :%d:", rsltCount); fflush(stdout);
			if(rsltCount>0)
			{
				if (AOM_ask_value_string(objTag,"item_id",&DesgNo)!=ITK_ok)   PrintErrorStack();
				printf("\n DesgNo is  = [%s]\n", DesgNo);fflush(stdout);

				if (AOM_ask_value_string(objTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
				printf("\n DesgTyp is  = [%s]\n", DesgTyp);fflush(stdout);
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
				printf("\n info1 is  = [%s]\n", info1);fflush(stdout);
				ITKCALL(SA_ask_current_role(&CurrentRoleTag));
				ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
				printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

				if(tc_strcmp(info1,"ON")==0)
				{
					if(((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0))&& (strlen(DesgNo) !=12) &&  (!strstr(roleName,"APL")) )
					{
						printf("\n Assembly or component must be 12 digit: [%s]\n", DesgNo);fflush(stdout);
						EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type assembly or component, part number must be 12 digit.");
						return ITK_err;
					}
					if (tc_strcmp(DesgTyp,"T")==0)
					{
						//TPL should be 11 digit and end with R/L
						sDesgNoT=subString(DesgNo, 10, 1);
						printf("\n TPL last digit: [%s]\n", sDesgNoT);fflush(stdout);
						if ((strlen(DesgNo) ==11)&& ((tc_strcmp(sDesgNoT,"R")==0)||(tc_strcmp(sDesgNoT,"L")==0)))
						{
							printf("\n TPL is 11 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n TPL is not 11 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For part type TPL, part number must be 11 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"M")==0)
					{
						//Module should be 14 digit.
						printf("\n TPL last digit\n");fflush(stdout);
						if (strlen(DesgNo) ==14)
						{
							printf("\n Module is 14 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n Module is not 14 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Module must be 14 digit.");
							return ITK_err;
						}
					}
					//if (strcmp(DesgTyp,"G")==0)
					//{
					//	//Work for frist digit should be G and and part length should be 7 digit
					//	sDesgNoG=subString(DesgNo, 0, 1);
					//	printf("\n Group ID first digit: [%s]\n", sDesgNoG);fflush(stdout);
					//	if ((strlen(DesgNo) ==7)&& (strcmp(sDesgNoG,"G")==0))
					//	{
					//		printf("\n Group ID is 7 digit: [%s]\n", DesgNo);fflush(stdout);
					//	}
					//	else
					//	{
					//		printf("\n Group Id is not 7 digit: [%s]\n", DesgNo);fflush(stdout);
					//		EMH_store_error_s1(EMH_severity_error,ITK_err,"For Group Id, part number must be 7 digit and Start with G.");
					//		return ITK_err;
					//	}
					//}
					if (tc_strcmp(DesgTyp,"V")==0)
					{
						//vehicle should be 9 digit and end with R/L
						sDesgNoV=subString(DesgNo, 8, 1);
						printf("\n Vehicle last digit: [%s]\n", sDesgNoV);fflush(stdout);
						if ((strlen(DesgNo) ==9)&& ((tc_strcmp(sDesgNoV,"R")==0)||(tc_strcmp(sDesgNoV,"L")==0)))
						{
							printf("\n Vehicle is 9 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n Vehicle is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For vehicle, part number must be 9 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VC")==0)
					{
						//VC should be 12 digit and end with R/L
						sDesgNoVC=subString(DesgNo, 11, 1);
						printf("\n VC last digit: [%s]\n", sDesgNoVC);fflush(stdout);
						if ((strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVC,"R")==0)||(tc_strcmp(sDesgNoVC,"L")==0)))
						{
							printf("\n VC is 12 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n VC is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For VC, part number must be 12 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"VCCR")==0)
					{
						//VCCR should be 12 digit and end with R/L
						sDesgNoVCCR=subString(DesgNo, 11, 1);
						printf("\n VCCR last digit: [%s]\n", sDesgNoVCCR);fflush(stdout);
						if ((strlen(DesgNo) ==12)&& ((tc_strcmp(sDesgNoVCCR,"R")==0)||(tc_strcmp(sDesgNoVCCR,"L")==0)))
						{
							printf("\n VCCR is 12 digit: [%s]\n", DesgNo);fflush(stdout);
						}
						else
						{
							printf("\n VCCR is not 9 digit: [%s]\n", DesgNo);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"For VCCR, part number must be 12 digit and end with R/L.");
							return ITK_err;
						}
					}
					if (tc_strcmp(DesgTyp,"D")==0 && CntrCount==0 )//bypassed for trilix site
					{
						//Dummy part should be 12 digit and 9th and 10th digit should be 00/04
						sDesgNoD=subString(DesgNo, 8, 2);
						printf("\n VCCR last digit: [%s]\n", sDesgNoD);fflush(stdout);
						if (strlen(DesgNo) ==12)
						{
							if ((tc_strcmp(sDesgNoD,"04")!=0)&&(tc_strcmp(sDesgNoD,"00")!=0))
							{
								printf("\n Dummy is 12 digit: [%s]\n", DesgNo);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_err,"For 12 digit Dummy part, 9th and 10th digit of part number must be 00/04.");
								return ITK_err;
							}
						}
					}

					if((tc_strcmp(DesgTyp,"A")==0 || tc_strcmp(DesgTyp,"C")==0 || tc_strcmp(DesgTyp,"D")==0) && strlen(DesgNo)==12)
					{
						// If Design Revision Number - XXXX XX 16 XX XX
						ThirdBarrel = subString(DesgNo,6,2);
						if (AOM_ask_value_string(objTag,"t5_SpareCriteria",&SpareCrit)!=ITK_ok)   PrintErrorStack();
						printf("\nPart [%s] ThirdBarrel [%s] SpareCriteria [%s]\n", DesgNo,ThirdBarrel,SpareCrit);fflush(stdout);

						if(tc_strcmp(ThirdBarrel,"16")==0 && (tc_strcmp(SpareCrit,"TSD")!=0 || strlen(SpareCrit)==0))
						{
							//Hard Check To Select TSD
							printf("\nIf Part [%s] and ThirdBarrel [%s] Please select SpareCriteria Value : TSD\n",DesgNo,ThirdBarrel);fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"Parts Numbers Third Barrel is 16, SpareCriteria Value Should be TSD : TML specification drawing");
							return ITK_err;
						}
					}

					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_DesignGrp",&Part_DegGrp)!=ITK_ok)   PrintErrorStack();
					printf("\n Part Project code is  = [%s] DsgGrp [%s]\n", Part_prj,Part_DegGrp);fflush(stdout);
					Part_Proj=subString(DesgNo, 0, 4);
					Part_Desg=subString(DesgNo, 4, 2);
					printf("\n Part first 4 digit: [%s], 5 and 6th digit [%s]\n", Part_Proj,Part_Desg);fflush(stdout);
					//Checking project/design group Start
					if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)|| (tc_strcmp(DesgTyp,"CM")==0)||(tc_strcmp(DesgTyp,"M")==0))
					{
						if (tc_strcmp(Part_Proj,Part_prj)!=0)
						{
							printf("\n Part first 4 digit are not same as project code.\n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"First 4 digits of part number should be same as project code.");
							return ITK_err;
						}
					}
					//Design group check.
					if((tc_strcmp(DesgTyp,"A")==0) || (tc_strcmp(DesgTyp,"C")==0)||(tc_strcmp(DesgTyp,"CM")==0))
					{
						if (tc_strcmp(Part_Desg,Part_DegGrp)!=0)
						{
							printf("\n Part 5th and 6th digit are not same as Desgin group.\n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"5th and 6th digits of part number should be same as design group.");
							return ITK_err;
						}
					}
					else if (tc_strcmp(DesgTyp,"M")==0)
					{
						MPart_Desg=subString(DesgNo, 9, 2);
						printf("\n MPart_Desg: [%s]\n", MPart_Desg);fflush(stdout);
						if (tc_strcmp(MPart_Desg,Part_DegGrp)!=0)
						{
							printf("\n Part 5th and 6th digit are not same as Desgin group.\n");fflush(stdout);
							EMH_store_error_s1(EMH_severity_error,ITK_err,"10th and 11th digits of part number should be same as design group.");
							return ITK_err;
						}
					}
					//Checking project/design group end.
				}
				else
				{
					printf("\n CREVali:is OFF. \n");fflush(stdout);
				}
				//DR Validation 1.30 start..
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
				printf("\n DRVali:info2 is  = [%s]\n", info2);fflush(stdout);
				if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4)!=ITK_ok)   PrintErrorStack();
				printf("\n info4 is  = [%s]\n", info4);fflush(stdout);
				if(tc_strcmp(info2,"ON")==0)
				{
					if (AOM_ask_value_string(objTag,"t5_ColourInd",&PrtCol)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_PartType",&Prttyp)!=ITK_ok)   PrintErrorStack();
					if (AOM_ask_value_string(objTag,"t5_PartStatus",&PrtDR)!=ITK_ok)   PrintErrorStack();
					if (AOM_UIF_ask_value(objTag,"release_status_list",&release_status)!=ITK_ok)   PrintErrorStack();
					printf("\n DRVali:Prttyp: [%s] PrtDR: [%s] PrtCol:[%s] release_status:[%s]\n",Prttyp,PrtDR,PrtCol,release_status);fflush(stdout);
					if(POM_class_of_instance(objTag,&PrtCls)!=ITK_ok) PrintErrorStack();
					if(POM_name_of_class(PrtCls,&PrtClass)!=ITK_ok) PrintErrorStack();
					printf("\n DRVali:PrtClass :%s",PrtClass); fflush(stdout);
					if (AOM_ask_value_string(objTag,"t5_ProjectCode",&PrtProj)!=ITK_ok)   PrintErrorStack();
					printf("\n DRVali:PrtProj is  = [%s]\n", PrtProj);fflush(stdout);
					DRValiFlag=0;
					if(tc_strcmp(release_status,"")!=0)
					{
						if(tc_strstr(info4,release_status) != NULL)
						{
							DRValiFlag=1;
							printf("\n DRVali:DRValiFlag..:[%d]\n", DRValiFlag);fflush(stdout);
						}
					}
					else
					{
						printf("\n DRVali:DRValiFlag:[%d]\n", DRValiFlag);fflush(stdout);
					}
					if((tc_strcmp(PrtProj,"")!=0)&&(DRValiFlag==0))
					{
						if(ITEM_find_item(PrtProj,&Project_t)!=ITK_ok)PrintErrorStack();
						if (Project_t!=NULLTAG)
						{
							if(TCTYPE_ask_object_type(Project_t,&ObjTypProj));
							if(TCTYPE_ask_name(ObjTypProj,type_Proj));
							printf("\n DRVali:DML: type_Proj :: %s\n", type_Proj);fflush(stdout);
							if (strcmp(type_Proj,"T5_Project")==0)
							{
								if(AOM_ask_value_string(Project_t,"t5_ProjectType",&Proj_typ)!=ITK_ok)PrintErrorStack();
								printf("\n DRVali:Proj_typ :[%s]\n",Proj_typ);   fflush(stdout);
								if((tc_strcmp(PrtDR,"")!=0) && (tc_strcmp(PrtDR,"NA")!=0))
								{
									if((tc_strcmp(Proj_typ,"E")==0)||(tc_strcmp(Proj_typ,"G")==0)||(tc_strcmp(Proj_typ,"H")==0)||(tc_strcmp(Proj_typ,"A")==0))
									{
										if((tc_strcmp(PrtDR,"AR0")!=0) && (tc_strcmp(PrtDR,"AR1")!=0)  && (tc_strcmp(PrtDR,"AR2")!=0) &&
										(tc_strcmp(PrtDR,"AR3")!=0) && (tc_strcmp(PrtDR,"AR4")!=0)  &&  (tc_strcmp(PrtDR,"AR5")!=0))
										{
											printf("\n DRVali:ERROR:1.\n"); fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid AR-status from AR0/AR1/AR2/AR3/AR4/AR5.\n Part project type-Engine/GearBox/Clutch/Axles should have AR-value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
											return ITK_err;
										}
									}
									else
									{
										if((tc_strcmp(PrtDR,"DR0")!=0) && (tc_strcmp(PrtDR,"DR1")!=0)  && (tc_strcmp(PrtDR,"DR2")!=0) &&
										(tc_strcmp(PrtDR,"DR3")!=0) && (tc_strcmp(PrtDR,"DR4")!=0)  &&  (tc_strcmp(PrtDR,"DR5")!=0))
										{
											printf("\n DRVali:ERROR:2.\n"); fflush(stdout);
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from DR0/DR1/DR2/DR3/DR4/DR5 instead of AR value.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
											return ITK_err;
										}
									}
								}
								else
								{
									//Check Part type
									if(((tc_strcmp(Prttyp,"V")==0) || (tc_strcmp(Prttyp,"VCCR")==0)|| (tc_strcmp(Prttyp,"A")==0) || (tc_strcmp(Prttyp,"T")==0) || (tc_strcmp(Prttyp,"C")==0) ||
									(tc_strcmp(Prttyp,"M")==0)||(tc_strcmp(Prttyp,"G")==0)) && ((tc_strcmp(PrtCol,"Y")==0) || (tc_strcmp(PrtCol,"N")==0)) && (tc_strcmp(PrtClass,"t5SpKit")!=0))
									{
										printf("\n DRVali:ERROR:3..\n"); fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"Please select valid DR-status from drop down list.\n To update DR-status for ERC Review parts,select latest revision and use below option.\n Option- Tools-> Product Structure Classes-> Update Non Cad Attributes.");
										return ITK_err;
									}
								}
							}
						}
					}
				}
				//DR Validation 1.30 End
			}
			else
			{
				// skip as control object is not present.
				printf("\n Validation skiped as control object is not present. \n");fflush(stdout);
			}

		//Vitthal :START: Validate Part Creation
			if (AOM_ask_value_string(objTag,"item_revision_id",&item_rev_id)!=ITK_ok)   PrintErrorStack();
			printf("\n item_rev_id  = [%s]\n", item_rev_id);fflush(stdout);
			if(strcmp(item_rev_id,"NR")==0)
			{
				printf("\n item_rev_id  is NR so inside if \n");fflush(stdout);
				iTemp=Validate_On_Creation(objTag);
				if(iTemp>0)
				{
					if(iTemp==1)EMH_store_error_s1(EMH_severity_error,ITK_err,"Start Part/Product is Mandatory for Part Type Assembly,Component,TPL and GID for CATIA Design group");
					return ITK_err;
				}
			}
		//Vitthal :END: Validate Part Creation

	/****************Adi TZ 1.32 Validation on Design Rev creation *************************/

				if(AOM_ask_value_string(objTag,"item_revision_id",&Rev_id));
			printf("\n Rev_id  => %s\n", Rev_id);fflush(stdout);

		    if(AOM_ask_value_string(objTag,"t5_DesignGrp",&DesignGrpCatia));
			printf("\n DesignGrpCatia => %s\n",DesignGrpCatia);fflush(stdout);

			if(AOM_ask_value_string(objTag,"t5_PartType",&PartTypeDR));
			printf("\n PartTypeDR => %s\n",PartTypeDR);fflush(stdout);

			printf("\n DesignGrp => %s\n",DesignGrp);fflush(stdout);

            if(tc_strstr(DesignGrp,DesignGrpCatia)!=NULL)
			  {
			   printf("\n catia design group so proceed => %s\n",DesignGrpCatia);fflush(stdout);

			    //if((strcmp(PartTypeDR,"A")==0)||(strcmp(PartTypeDR,"C")==0)||(strcmp(PartTypeDR,"M")==0)) //Adi 1.35 commented to extend functionality to all part types
				//{																							//Adi 1.35 commented
					if(tc_strstr(Rev_id,"NR")!=NULL)
					{
						Rev_idlength = strlen(Rev_id);

						if((Rev_idlength)>2)
						{
							Rev_Sub=subString(Rev_id,0,3);
							printf("\n Rev_Sub => %s\n",Rev_Sub);fflush(stdout);

							if(tc_strcmp(Rev_Sub,"NR;")==0) //&& checked out ==Y OR erc REVIEW LIFECYCLE STATE ?
							{
								printf("\n PROCEED   2222222222 \n");fflush(stdout);
							}
							else
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
								return ITK_err;
							}

						}
						else if((Rev_idlength)==2)
						{
						   Rev_Sub1=subString(Rev_id,0,2);
						   printf("\n Rev_Sub1 is => %s\n",Rev_Sub1);fflush(stdout);

							if(tc_strcmp(Rev_Sub1,"NR")==0)
							{
								printf("\n PROCEED   3333333333 \n");fflush(stdout);
							}
							else
							{
								EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter Revision value either as NR; followed by sequence OR simply NR");
								return ITK_err;
							}
						}
						printf("\n PROCEED   44444444 \n");fflush(stdout);
					}										
				   else /************* Adi TZ 1.35 Begin do not allow creation of higher rev if NR does not exist*********************/
				    {
					   if(ITEM_ask_latest_rev(objTag,&rev1));
					   
					   if (AOM_ask_value_string(rev1,"item_revision_id",&Desc_obj)!=ITK_ok);
					   printf("\n revision present   = [%s]\n", Desc_obj);fflush(stdout); 

					   if((Desc_obj)!=NULL)
					   {
						   printf("\n PROCEED  XXXXXXXXX  \n");fflush(stdout); 
					   }
					   else
					   {
						   EMH_store_error_s1(EMH_severity_error,ITK_err,"Please create initial revision as NR. Please enter Revision value either as NR; followed by sequence OR simply NR");	
						   return ITK_err;
					   }
				    } /*************Adi TZ 1.35 End do not allow creation of higher rev if NR does not exist*********************/						
				//}																							//Adi 1.35 commented

			}
			else
			{
				printf("\n not a catia design group so continue===== \n");fflush(stdout);
			}


		/****************Adi TZ 1.32  Validation on Design Rev creation ENDS ***********************/
		}
		//1.25 t5_PartType

		if (AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\n Desc_obj2  = [%s]\n", Desc_obj2);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "ItemRevision", &attr_id))PrintErrorStack();
		 printf("\n before NR check\n");fflush(stdout);
		 //weight rounding
		 if( AOM_ask_value_double(objTag,"t5_Weight",&objWeightVal)==ITK_ok)
			  printf("\n user entered weight :%f\n",objWeightVal);fflush(stdout);
		  if (objWeightVal > 0)
			{
			 sprintf(wgtstr,"%0.3f",objWeightVal);
				roundedWtVal = atof(wgtstr);
			  printf("\n rounded weight :%f\n",roundedWtVal);fflush(stdout);

			if(AOM_lock(objTag))PrintErrorStack();
			printf("\n Before weight update\n");fflush(stdout);
			if( AOM_set_value_double(objTag,"t5_Weight",roundedWtVal)!=ITK_ok);PrintErrorStack();
			printf("\n After weight update\n");fflush(stdout);
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag));PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();
			}

		 //weight rounding

		if(strcmp(Desc_obj2,"NR;1")==0 )
		{
			if(AOM_lock(objTag))PrintErrorStack();
			printf("\n Before Modification Description for NR;1\n");fflush(stdout);
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
			printf("\n After Modification Description for NR;1\n");fflush(stdout);
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag));PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();
		}

		if(strcmp(Desc_obj2,"NR")==0 )
		{

			 if(AOM_lock(objTag))PrintErrorStack();
			printf("\n Before Modification Description\n");fflush(stdout);
			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
			printf("\n After Modification Description\n");fflush(stdout);
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag));PrintErrorStack();
			if(AOM_refresh(objTag,1))PrintErrorStack();


			 printf("\n inside NR check\n");fflush(stdout);
			if(AOM_lock(objTag));
			if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")) PrintErrorStack();
			if(AOM_save(objTag))PrintErrorStack();
			if(AOM_unlock(objTag))PrintErrorStack();
			printf("\n  NR;1 updated\n");fflush(stdout);


			if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments))PrintErrorStack();
			printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);

			for(ij=0;ij<cnt;ij++)
			{
					dataset = attachments[ij];
					if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)   PrintErrorStack();
					printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

					if (strcmp(ObjectClassType,"Design Revision Master")==0)
					{
						if (AOM_ask_value_string(dataset,"object_name",&ObjectName)!=ITK_ok)   PrintErrorStack();
						printf("\n\n Revision Master Name :%s\n",ObjectName);fflush(stdout);
							oojname=strtok(ObjectName,"/");
							strcat(oojname,"/");
							strcat(oojname,"NR;1");
							printf("\n\n Name of Revision Master:%s\n",oojname);fflush(stdout);


							if(POM_attr_id_of_attr("object_name", "Form", &form_attr_id))PrintErrorStack();

							if(AOM_lock(dataset));
							if(POM_set_attr_string(1, &dataset, form_attr_id,oojname)) PrintErrorStack();
							if(AOM_save(dataset))PrintErrorStack();
							if(AOM_unlock(dataset))PrintErrorStack();
							break;
					}
			}


			if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
			if(EPM_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();




			// bhaskar starts

			SA_ask_current_groupmember(&GroupMem);
			 if(GroupMem !=NULLTAG)
								{
								if (AOM_ask_value_string(GroupMem,"object_name",&group_name)!=ITK_ok)PrintErrorStack();
								printf("\ngroup_name session is pare  : %s\n",group_name);fflush(stdout);

									if (SA_ask_groupmember_role(GroupMem,&Roletag) !=ITK_ok)PrintErrorStack();
									if (SA_ask_groupmember_group(GroupMem,&grptag) !=ITK_ok)PrintErrorStack();
									 if((Roletag !=NULLTAG) && (Roletag !=NULLTAG))
								{
								if (AOM_ask_value_string(Roletag,"object_name",&Role_name)!=ITK_ok)PrintErrorStack();
								if (AOM_ask_value_string(grptag,"object_name",&Grp_name)!=ITK_ok)PrintErrorStack();
								printf("\nRole_name session is pare  : %s %s\n",Role_name,Grp_name);fflush(stdout);
								    if (AOM_ask_value_string(objTag,"t5_DesignGrp",&desi_grp)!=ITK_ok)   PrintErrorStack();

									printf("\n Design group  = [%s]\n", desi_grp);fflush(stdout);

									DerRoleNme=NULL;DerRoleNme=malloc(50);
									strcpy(DerRoleNme,desi_grp);
									strcat(DerRoleNme,"_Designers");
									printf("\n Role name required   = [%s]\n", DerRoleNme);fflush(stdout);

									if (SA_find_role(DerRoleNme,&DesRolTag)!=ITK_ok)PrintErrorStack();

									if (SA_find_groupmember_by_user(user_tag,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();

									//if (SA_find_groupmember_by_rolename (DerRoleNme,"Engineering",username,&Gmcnt,&GmFound)!=ITK_ok)PrintErrorStack();
									printf("\n count of  Gmcnt = [%d]\n", Gmcnt);fflush(stdout);


									ITKCALL(SA_ask_current_role(&CurrentRoleTag));
									ITKCALL(SA_ask_role_name(CurrentRoleTag,roleName))
									printf("\n\n  roleName : %s\n",roleName); fflush(stdout);


									for(jk=0;jk<Gmcnt;jk++)
										{
											ActGm = GmFound[jk];
											if (AOM_ask_value_string(ActGm,"object_name",&ActGmName)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name  = [%s]\n", ActGmName);fflush(stdout);
											if (strstr(ActGmName,DerRoleNme)|| strstr(roleName,"APL") )
											{
                                             Rolflag++;
                                             DerRoleNme1=NULL;DerRoleNme1=malloc(100);
											 strcpy(DerRoleNme1,ActGmName);
											 //break;
											}

										}
										printf("\n count of  Rolflag = [%d]\n", Rolflag);fflush(stdout);
										printf("\n DerRoleNme1 is  = [%s]\n", DerRoleNme1);fflush(stdout);
										if ((Rolflag==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}
								}
								}

			if (AOM_get_value_string(objTag,"t5_ProjectCode",&ObjProject))PrintErrorStack();
			 printf("\nProject stamped is  : %s\n",ObjProject);fflush(stdout);

			if(strcmp(ObjProject,"")!=0)
						 {
							if (PROJ_find(ObjProject,&projobj) !=ITK_ok)PrintErrorStack();

							if(projobj !=NULLTAG)
							{
								//if (TCTYPE_ask_object_type(projobj,&projobj1)!=ITK_ok)PrintErrorStack();

								//if (TCTYPE_ask_name(projobj1,Ptype_name1)!=ITK_ok)PrintErrorStack();
								//printf("\n Proj type_name = %s\n", Ptype_name1);
								printf("\nAssigned to Projecttttttt33\n");fflush(stdout);



								SA_ask_current_project(&Currproj);

                                 if(Currproj !=NULLTAG)
								{
								if (AOM_ask_value_string(Currproj,"object_name",&parent_name)!=ITK_ok)PrintErrorStack();
								printf("\nProject session is pare  : %s\n",parent_name);fflush(stdout);
								//if (AOM_UIF_ask_value(Currproj,"workcontext_name",&currpro)!=ITK_ok)PrintErrorStack();
								// if (POM_attr_id_of_attr( "project", "TC_WorkContext", &projid )!=ITK_ok)PrintErrorStack();



			//							if (strcmp(parent_name,ObjProject)==0)
			//							{
			//								printf("\nAssigned to Projecttttttt\n");fflush(stdout);
			//							}
			//							else
							{
  								if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

								 if(promem==1)
						              {
						                printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
										//return ITK_err;
										SA_set_current_project(projobj);
									if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

								       for(jkl=0;jkl<Gmcnt1;jkl++)
										{
											ActGm1 = GmFound1[jkl];
											if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name1  = [%s]\n", ActGmName1);fflush(stdout);
                                        if(DerRoleNme1)
											{
											if (strcmp (ActGmName1,DerRoleNme1) == 0)
											{
                                               printf("\nValid user to create the part\n");fflush(stdout);
											   Rolflag1++;
											}
											}
										}
											if ((Rolflag1==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}

						              }
									  else
						              {
						                      printf("\ncall error ITK ok2\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
										return ITK_err;
						              }



							}
							printf("\nAssigned to Project\n");fflush(stdout);
							}
							else
							 {
							if (PROJ_is_user_a_member(projobj,user_tag,&promem)!=ITK_ok)PrintErrorStack();

								 if(promem==1)
						              {
						                printf("\nsetting session project as t5_projectcode attribute\n");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_error,ITK_err,"Kindly set same project in session details as per entered project code for Part");
										//return ITK_err;
										SA_set_current_project(projobj);

										if (PROJ_ask_team(projobj,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok)PrintErrorStack();

								       for(jkl=0;jkl<Gmcnt1;jkl++)
										{
											ActGm1 = GmFound1[jkl];
											if (AOM_ask_value_string(ActGm1,"object_name",&ActGmName1)!=ITK_ok)   PrintErrorStack();
											printf("\n Actual Group Member name1  = [%s]\n", ActGmName1);fflush(stdout);
                                        if(DerRoleNme1)
											{
											if (strcmp (ActGmName1,DerRoleNme1) == 0)
											{
                                               printf("\nValid user to create the part\n");fflush(stdout);
											   Rolflag1++;
											}
											}
										}
											if ((Rolflag1 == 0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
											{
											EMH_store_error_s1(EMH_severity_error,ITK_err,"Your login Doesn't have access for Entered Design group for project. kindly get access from TCUA Admin and set same project in session details");
											return ITK_err;
											}


						              }
									  else
						              {
						                      printf("\ncall error ITK ok2\n");fflush(stdout);
										EMH_store_error_s1(EMH_severity_error,ITK_err,"You are not member for this project. kindly get access from TCUA Admin and set same project in session details");
										return ITK_err;
						              }
							 }

						}
						 }
						else
								{
									printf("\ncall error ITK ok2\n");fflush(stdout);
									EMH_store_error_s1(EMH_severity_error,ITK_err,"Please enter the Project code and set the same project in session details");
									   return ITK_err;
								}
// bhaskar ends

//			if(AOM_load(objTag))PrintErrorStack();
//			if(AOM_lock(objTag))PrintErrorStack();
//			printf("\n Before Modification Description\n");fflush(stdout);
//			if( AOM_set_value_string(objTag,"t5_DocRemarks","NEW RELEASE"))PrintErrorStack();
//			printf("\n After Modification Description\n");fflush(stdout);
//			if(AOM_save(objTag))PrintErrorStack();
//			if(AOM_unlock(objTag));PrintErrorStack();
//			if(AOM_unload(objTag))PrintErrorStack();
//			if(AOM_refresh(objTag,1))PrintErrorStack();

//			if(RES_is_checked_out(objTag,&checkout))PrintErrorStack();
//			if (checkout==0)
//			{
//				if (RES_checkout(objTag,&reason,&change_id,&dir_name,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
//
//				printf("\n**********After Check Out DR in createpost***************\n");fflush(stdout);
//				if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
//				printf("\nc_attchs :%d\n",c_attchs);fflush(stdout);
//				if(c_attchs>0)
//				{
//					for (p= 0; p < c_attchs; p++)
//					{
//						primary=secondary_objects[p];
//						if(TCTYPE_ask_object_type(primary,&objTypeTagDi))PrintErrorStack();
//						if(TCTYPE_ask_name(objTypeTagDi,type_name2))PrintErrorStack();
//						if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0)
//						{
//							  if(RES_is_checked_out(primary,&checkoutp))PrintErrorStack();
//							   if (checkoutp==0)
//							 {
//								if (RES_checkout(primary,&reason1,&change_id1,&dir_name1,RES_EXCLUSIVE_RESERVE))PrintErrorStack();
//								printf("\n**********After Check Out Dataset in createpost***************\n");fflush(stdout);
//							 }
//
//						}
//
//
//					}
//				}
//			}
		}

		if( AOM_ask_value_string(objTag,"item_id",&desid)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok);PrintErrorStack();


		if(strcmp(Desc,"")!=0)
		{
		desclength = strlen(Desc);
		for(desccnt=0;desccnt<desclength;desccnt++)
		{
			if(Desc[desccnt]=='\n')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='`')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='~')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='|')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='$')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='#')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='@')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='^')
				Desc[desccnt] =' ';

			if(Desc[desccnt]=='!')
				Desc[desccnt] =' ';
			printf("\n [%c]\n",Desc[desccnt]);fflush(stdout);
		}
		//val=(char **)MEM_alloc(sizeof(char **));
		NewDesc = (char *)MEM_alloc (desclength * sizeof(char));
		strcpy(NewDesc,Desc);

		printf("\n !!!!!!!!!!!!!!!!! save_method_4:::::::NewDesc[%s]!!!!!!!!!!!!!!!!!!!\n", NewDesc);fflush(stdout);

		if(NewDesc)
		{
			//AOM_lock(objTag);
			if(AOM_set_value_string(objTag,"object_desc",NewDesc)!=ITK_ok);PrintErrorStack();
			if(AOM_save(objTag)!=ITK_ok);PrintErrorStack();
			//AOM_unlock(objTag);
			if( AOM_ask_value_string(objTag,"object_desc",&NewDescription)!=ITK_ok);PrintErrorStack();
			printf("\n !!!!!!!!!!!!!!!!! save_method_4:::::::NewDescription[%s]!!!!!!!!!!!!!!!!!!!\n", NewDescription);fflush(stdout);
		}
	}

	//Added by hanuman
	if(AOM_ask_value_string(objTag,"t5_PartType", &objPartType)!=ITK_ok); PrintErrorStack();
	printf("\n Create Design Revision of Type :: [%s]\n", objPartType);fflush(stdout);

	if(tc_strcmp(objPartType,"T")==0)
	{
		if((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0))
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"TPL creation should not be allowed from front end.");
			return ITK_err;
		}
	}

	//	if(desid)
	//	{
//
//				printf("\n before  QRY_find : QRY_find \n");
//				 if(QRY_find("Dataset1", &queryTag));PrintErrorStack();
//				printf("\n After IFERR_REPORT : QRY_find \n");
//				if (queryTag)
//				{
//					printf("Found Query\n");
//
//				}
//				else
//				{
//					printf("Not Found Query");
//				}
//
//			    if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &resultTags));PrintErrorStack();
//			    printf("resultCount **** %d", resultCount);


		 printf("After mem1 alloc\n");
				 dst_name = NULL;
				 dst_name=(char *) MEM_alloc(200);
				 printf("After mem alloc\n");

									tc_strcpy (dst_name, desid);
									strcat(dst_name,"/");
									strcat(dst_name,"NR;1");

					//
							// if ( AE_find_datasettype (dst_name, &a_datasettype)!=ITK_ok);PrintErrorStack();
							 printf("After find  dataset\n");


								 //printf("drawign name %s,%s",DrwName1,DrwName);
					//if( AE_find_all_datasets_by_id(a_datasettype, "000138", &resultCount, &resultTags)!=ITK_ok);PrintErrorStack();
					if( AE_find_all_datasets(dst_name, &resultCount, &resultTags)!=ITK_ok);PrintErrorStack();
					 printf("resultCount **** %d", resultCount);

						if (resultCount  > 0 )
						{

							for (j=0;j<resultCount;j++ )
							{

								item_tag = resultTags[j];


								if( AE_ask_dataset_latest_rev(item_tag, &latest_datas)!=ITK_ok);PrintErrorStack();


								if( AOM_ask_value_string(latest_datas,"object_name",&DrwName)!=ITK_ok);PrintErrorStack();
								DrwName1=strtok(DrwName,"/");
								printf ( "DrwName%s and desid :%s\n", DrwName1,desid);fflush(stdout);
								if( AOM_ask_value_string(latest_datas,"object_type",&object_typeDS)!=ITK_ok);PrintErrorStack();

								//if( AE_ask_dataset_id_rev(latest_datas, &dataset_id, &dataset_rev )!=ITK_ok);PrintErrorStack();
								printf ( "dataset object_typeDS :%s\n", object_typeDS);fflush(stdout);

								if(tc_strcmp(object_typeDS,"CMI2Drawing")==0)
								{

								if ((dsflag == 0) && (strcmp(DrwName1,desid) ==0))
								{

									if( AOM_ask_value_string(objTag,"t5_Material",&objname)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_MThickness",&objMatThickness)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_RefDrawing",&objRefDrw)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_string(objTag,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok);PrintErrorStack();
									if( AOM_ask_value_double(objTag,"t5_Weight",&objWeight)!=ITK_ok);PrintErrorStack();

									printf ( "t5_PartMaterial for rev is  %s , t5_OppHandDrg :%s and objRefDrw :%s and objMatThickness :%s \n", objname,objOppHandDrg,objRefDrw,objMatThickness);fflush(stdout);
									AOM_lock(item_tag);
									if( AOM_set_value_string(item_tag,"t5_PartMaterial",objname)!=ITK_ok);PrintErrorStack();
									if( AOM_set_value_string(item_tag,"t5_MThickness",objMatThickness)!=ITK_ok);PrintErrorStack();
									// if(strcmp(objOppHandDrg,"")==0)
									//{
										if( AOM_set_value_string(item_tag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok);PrintErrorStack();
									//}
									// if(strcmp(objRefDrw,"")==0)
									//{
										if( AOM_set_value_string(item_tag,"t5_RefDrawing",objRefDrw)!=ITK_ok);PrintErrorStack();
									//}
									if( AOM_set_value_string(item_tag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok);PrintErrorStack();
									if( AOM_set_value_double(item_tag,"t5_Weight",objWeight)!=ITK_ok);PrintErrorStack();
									if(AOM_save(item_tag))PrintErrorStack();
									if(AOM_unlock(item_tag))PrintErrorStack();
									dsflag++;
									break;
								}

								}
							}

						}
		//}


	}

	return error_code;
}



extern DLLAPI int  save_method_5(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *desid = NULL;
	char *objname = NULL;
	char *Desc = NULL;
	char *NewDesc = NULL;
	char *NewDescription = NULL;
	const char *item_name = NULL;
	char *object_type = NULL;
	char *ItemName = NULL;
	char *objdesc	   = NULL;
	char *objMat = NULL;
	char *objMatThickness = NULL;
	char *objOppHandDrg = NULL;
	char *objRefDrw = NULL;
	char *objSurfStd = NULL;
	double  objWeight ;
	tag_t rev=NULLTAG;
	char* item_revision_id=NULL;
	char* item_name_copy=NULL;
	int ItmNamelength = 0;
	const char *cTemp="item_id";
	WSO_description_t     desc;

	//char **val=NULL;

	int desclength = 0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_5:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"CMI2Drawing")==0)
	{

		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		if( AOM_ask_value_string(objTag,"current_name",&item_name)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_type",&object_type)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&Desc)!=ITK_ok);PrintErrorStack();

		ItmNamelength = strlen(item_name);
		item_name_copy = (char *)MEM_alloc (ItmNamelength * sizeof(char));
		strcpy(item_name_copy,item_name);
		printf("\n item_name_copy  :%s and item_name :%s\n",item_name_copy,item_name);fflush(stdout);

		item_name=strtok(item_name_copy,"/");

		if(item_name)
		{
						tag_t *tags_found = NULL;
						int n_tags_found= 0;
						printf("\n values[0] for parent is  :%s\n",item_name);fflush(stdout);
						//if(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();
						if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();

						if (n_tags_found > 1)
						{
							MEM_free(tags_found);
							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
							printf ( "More than one items matched with id %s\n", item_name);fflush(stdout);
							exit (0);
						}
						else if (n_tags_found == 1)
						{
								printf ( "only one items matched with id %s\n", item_name);fflush(stdout);

							item_tag = tags_found[0];

							if(ITEM_find_revision(item_tag,item_name,&rev));PrintErrorStack();
							if(ITEM_ask_latest_rev(item_tag,&rev));PrintErrorStack();

							if(rev != NULLTAG)
							{


								if( AOM_ask_value_string(rev,"t5_Material",&objname)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"object_desc",&objdesc)!=ITK_ok);PrintErrorStack();

								if( AOM_ask_value_string(rev,"t5_MThickness",&objMatThickness)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_OppHandDrg",&objOppHandDrg)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_RefDrawing",&objRefDrw)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_string(rev,"t5_SurfPrtStd",&objSurfStd)!=ITK_ok);PrintErrorStack();
								if( AOM_ask_value_double(rev,"t5_Weight",&objWeight)!=ITK_ok);PrintErrorStack();

								//AOM_save(objTag);
								if( AOM_set_value_string(objTag,"t5_PartMaterial",objname)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"object_desc",objdesc)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_MThickness",objMatThickness)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_OppHandDrg",objOppHandDrg)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_RefDrawing",objRefDrw)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_string(objTag,"t5_SurfPrtStd",objSurfStd)!=ITK_ok);PrintErrorStack();
								if( AOM_set_value_double(objTag,"t5_Weight",objWeight)!=ITK_ok);PrintErrorStack();


							}
							else
							{
									 printf(" Null rev tag \n");fflush(stdout);
							}
						}
						else if (n_tags_found == 0)
						{
							printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", item_name);fflush(stdout);
							//exit (0);
						}

          }


	}

	return error_code;
}

///saurabh
extern DLLAPI int  save_method_SVR(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag ,item_tag= NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	char *objname = NULL;
	char *Desc = NULL;
	const char *item_name = NULL;
	char *objdesc	   = NULL;
	char *VcNos	   = NULL;
	char *Svr_Token	   = NULL;
	char *Svr_Rev	   = NULL;
	char *Svr_VC_Suffix	   = NULL;
	int ItmNamelength = 0;
	tag_t*    status_list_SVR=NULLTAG;

	//char **val=NULL;

	int desclength = 0,st_count_SVR=0;
	int desccnt = 0,n_tags_found=0;

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();

	printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::type_name[%s]\n",type_name);fflush(stdout);

	if(strcmp(type_name,"VariantRule")==0)
	{
		//object_desc
		//object_name
		if( AOM_ask_value_string(objTag,"object_name",&objname)!=ITK_ok);PrintErrorStack();
		if( AOM_ask_value_string(objTag,"object_desc",&objdesc)!=ITK_ok);PrintErrorStack();
		ItmNamelength = strlen(objname);
		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] obj_desc [%s]\n Item length%d \n",objname,objdesc,ItmNamelength);fflush(stdout);

		if (ItmNamelength > 15 )
		{
			/// 21826536000R_NR 21826536000R_A
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else if (ItmNamelength < 14)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
			return ITK_err;
		}
		else
		{
			VcNos=subString(objname,0,12);      // "21826536000R"
			Svr_Token=subString(objname,12,1);  // "_"
			Svr_VC_Suffix=subString(objname,8,4); // "000R" or "000L"
			printf("\n save_method_SVR VcNos [%s] Svr_Token [%s]  Svr_VC_Suffix [%s]\n",VcNos,Svr_Token,Svr_VC_Suffix);fflush(stdout);
			if(strcmp(Svr_VC_Suffix,"000R") &&  strcmp(Svr_VC_Suffix,"000L") && strcmp(Svr_Token,"_") )
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
				return ITK_err;
			}
			if (ItmNamelength == 15)
			{

				Svr_Rev=subString(objname,13,2);
				printf("\nInside Character SVR %s\n",Svr_Rev);fflush(stdout);
				if(strcmp(Svr_Rev,"NR")  )
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}

			}
			else if (ItmNamelength == 14)
			{
				Svr_Rev=subString(objname,13,1);
				printf("\nInside Character SVR %s %c %d\n",Svr_Rev,Svr_Rev[0],Svr_Rev[0]);fflush(stdout);
				if (Svr_Rev[0] >= 'A' && Svr_Rev[0] <= 'Z')
				{
					printf("\nInside Character SVR\n");fflush(stdout);
				}
				else
				{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please give SVR name as VC_Revision eg: 21826536000R_NR or 21826536000R_A... so on");
					return ITK_err;
				}
			}
		}

		desclength = strlen(objdesc);
		if (desclength > 27 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"SVR Description is greater than 27 character.");
			return ITK_err;
		}

		if( WSOM_ask_release_status_list(objTag,&st_count_SVR,&status_list_SVR)!=ITK_ok);PrintErrorStack();
		logical			retain							= 0;
		tag_t			primary					= NULLTAG;
		tag_t			status_rel					= NULLTAG;
		tag_t			objTypeTagDi					= NULLTAG;
		char*			WSO_Name					= NULL;
		char   type_name3[TCTYPE_name_size_c+1];
		int				cnt=0,countDep=0,k;
		tag_t  *secondary_objects1	= NULLTAG;

		printf("\n!!!!!!!!!!!!!!!!! save_method_SVR:::::::::obj_name[%s] Status count [%d]\n",objname,st_count_SVR);fflush(stdout);

		if( GRM_list_primary_objects_only(objTag,NULLTAG,&countDep,&secondary_objects1)!=ITK_ok)PrintErrorStack();
		printf("\n count found %d \n ",countDep);fflush(stdout);

			for (k=0;k<countDep;k++)
			{

				primary=secondary_objects1[k];
				if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok)PrintErrorStack();
				if(TCTYPE_ask_name(objTypeTagDi,type_name3)!=ITK_ok)PrintErrorStack();
				printf( "\n type_name3 :%s ..\n",type_name3);
			}

		if(st_count_SVR>0)
		{
			for (cnt=0;cnt< st_count_SVR;cnt++ )
			{
				if(AOM_ask_name(status_list_SVR[cnt],&WSO_Name)!=ITK_ok)PrintErrorStack();
				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			}
		}
		else
		{
			printf("\n count found %d \n ",countDep);fflush(stdout);
			if (countDep == 0)
			{
//				printf("\n >>>>>>>>>>>>>>>>>>>>Inside Creating ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//				if (CR_create_release_status("ERC Review",&status_rel))PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> Adding ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
//	//			if(EPM_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
//				if(RELSTAT_add_release_status(status_rel,1,&objTag,retain))PrintErrorStack();
//				printf("\n >>>>>>>>>>>>>>>>>>> After ERC Review status<<<<<<<<<<<<<<<<<<\n");fflush(stdout);
			}
		}


	}

	return error_code;
}

//extern DLLAPI int  save_method_6(METHOD_message_t *msg, va_list args)
//{
//
//	int error_code = ITK_ok;
//	tag_t objTag = va_arg(args, tag_t);
//	//logical flag = va_arg(args, logical);
//	tag_t objTypeTag = NULLTAG;
//	char   type_name[TCTYPE_name_size_c+1];
//
//
//	int checked_out_user = 0;
//	//logical	checkoutp				= 0;
//
//	char *username;
//	char *cp_ChildChkOutValue = NULL;
//	char *Item_ID_str = NULL;
//	char *ischek = NULL;
//	char *Item_ID_Rev_str = NULL;
//	int    Item_ID,Item_Revision = 0;
//	tag_t user_tag=NULLTAG;
//	tag_t rev_tag=NULLTAG;
//	tag_t paritem=NULLTAG;
//	char *objecttype = NULL;
//	char *PartType = NULL;
//	int n_parents = 0;
//	int index = 0;
//	int *levels = 0;
//	tag_t *parents = NULL;
//	int	chkflg=0;
//
//	//char **val=NULL;
//
//	//int desclength = 0;
//	//int desccnt = 0,n_tags_found=0;
//
//	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
//	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
//	POM_get_user(&username,&user_tag);
//
//	printf("\n!!!!!!!!!!!!!!!!! save_method_6:::::::::type_name[%s]\n",type_name);fflush(stdout);
//
//	if(strcmp(type_name,"BOMLine")==0)
//	{
//
//		//item_name = (char *)MEM_alloc (50 * sizeof(char));
//		// if(RES_is_checked_out(objTag,&checkoutp))PrintErrorStack();
//
//			if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user))PrintErrorStack();
//			if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue))PrintErrorStack();
//
//		if(  BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision))PrintErrorStack();
//	    if(  BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID))PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str))PrintErrorStack();
//		if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str))PrintErrorStack();
//
//		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
//		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag))PrintErrorStack();
//
//		if(PS_where_used_all(rev_tag,1,&n_parents,&levels,&parents))PrintErrorStack();
//
//		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
//		printf("\n\t object type => %s\n",objecttype);fflush(stdout);
//
//		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
//		printf("\n\t PartType => %s\n",PartType);fflush(stdout);
//		printf("\n\t no of parents and levels => %d,%d\n",n_parents,levels);fflush(stdout);
//
//		if(strcmp(objecttype,"Design Revision")==0)
//		{
//
//		 if(n_parents > 0)
//				 {
//					 for( index=0; index<=1; index++)
//					 {
//                        paritem = parents[index];
//						if( AOM_ask_value_string(paritem,"checked_out",&ischek)!=ITK_ok);
//						printf("\n\t parent checkout status => %s\n",ischek);fflush(stdout);
//						if(strcmp(ischek,"Y")==0)
//						 {
//                              chkflg++;
//						 }
//					 }
//				 }
//				 printf("\n\t chkflg => %d\n",chkflg);fflush(stdout);
//
//				 if ((chkflg==0) && ((strcmp(username,"infodba")!=0) && (strcmp(username,"loader")!=0)))
//				{
//				EMH_store_error_s1(EMH_severity_error,ITK_err,"Parent is not checked out, so you cannot delete the child from BOM");
//				return ITK_err;
//				}
//		}
//
//
//
//	}
//
//	return error_code;
//}
//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
int BomLineModuleValidaion(tag_t tag_bomLineParent,tag_t tag_child)
{
	int   Status			 = ITK_ok;
	char *sDesModuleAddress  = NULL;
	char *sArModAddress		 = NULL;
	char *sPartType			 = NULL;
	char *sObjectTypeArch	 = NULL;
	char *sObjectTypeModule	 = NULL;
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(tag_child,&ChildTagLatestRev));
	if((tag_bomLineParent) && (ChildTagLatestRev))
	{
		if(AOM_ask_value_string(tag_bomLineParent,"object_type",&sObjectTypeArch));
		if(AOM_ask_value_string(ChildTagLatestRev,"object_type",&sObjectTypeModule));
		if(AOM_ask_value_string(ChildTagLatestRev,"t5_PartType",&sPartType));
		printf("\n FILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n sObjectTypeArch => %s\n sObjectTypeModule=>%s\n Module t5_PartType=>%s",sObjectTypeArch,sObjectTypeModule,sPartType);fflush(stdout);
		if((tc_strcmp(sObjectTypeArch,"T5_ArchModuleRevision")==0) && (tc_strcmp(sObjectTypeModule,"Design Revision")==0) &&  (tc_strcmp(sPartType,"M")==0))
		{
			if(AOM_ask_value_string(tag_bomLineParent,"t5_ArchModuleAddress",&sArModAddress));
			if(AOM_ask_value_string(ChildTagLatestRev,"t5_ModuleAddress",&sDesModuleAddress));
			printf("\nFILE NAME:BOMLineValidation.c, FUNCTION NAME:BomLineModuleValidaion(), \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
			if(tc_strcmp(sArModAddress,sDesModuleAddress)!=0)
			{
				return 1;
			}
		}
	}
	printf("\n Architecture Module Revision Address and Module Address is same, \n t5_ArchModuleAddress => %s\n t5_ModuleAddress=>%s",sArModAddress,sDesModuleAddress);fflush(stdout);
	return 0;
}
//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.
extern DLLAPI int  save_method_7(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t  item_tag		= va_arg(args, tag_t);
	//logical flag = va_arg(args, logical);
	tag_t objTypeTag = NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	int checked_out_user = 0;
	//logical	checkoutp				= 0;
	char *username;
	char *cp_ChildChkOutValue = NULL;
	char *Item_ID_str = NULL;
	char *Item_ID_Rev_str = NULL;
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";
	int   Item_ID,Item_Revision = 0;
	tag_t user_tag=NULLTAG;
	tag_t rev_tag=NULLTAG;
	char *objecttype = NULL;
	char *PartType = NULL;
	char *t5_DesignGrp = NULL;
	char *ChildPartType = NULL;
	//int ItmNamelength = 0;
	//const char *cTemp="item_id";
	//WSO_description_t     desc;
	//char **val=NULL;
	//int desclength = 0;
	//int desccnt = 0,n_tags_found=0;

	//added by ajinkya on 2 march//
	char *objecttypeRight = NULL;
	tag_t ChildTagLatestRevt	 = NULLTAG;
	char *sObjectTypeModulet	 = NULL;
	char *Item_id_par=NULL;
	char   *ninethteenth=NULL;
	char	*designRev_id	= NULL;
	int item_idlength =0;

	//end

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name)!=ITK_ok);PrintErrorStack();
	POM_get_user(&username,&user_tag);

	printf("\n!!!!!!!!!!!!!!!!! save_method_7:::::::::type_name[%s]\n",type_name);fflush(stdout);
	printf("\n  Printf added for testing [%s]\n",type_name);fflush(stdout);


	if(strcmp(type_name,"BOMLine")==0)
	{
		//item_name = (char *)MEM_alloc (50 * sizeof(char));
		// if(RES_is_checked_out(objTag,&checkoutp))PrintErrorStack();

		if(BOM_line_look_up_attribute ("bl_rev_checked_out",&checked_out_user))PrintErrorStack();
		if(BOM_line_ask_attribute_string (objTag, checked_out_user, &cp_ChildChkOutValue))PrintErrorStack();
		if(BOM_line_look_up_attribute ("bl_rev_item_revision_id",&Item_Revision))PrintErrorStack();
	    if(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID))PrintErrorStack();
		if(BOM_line_ask_attribute_string(objTag, Item_ID, &Item_ID_str))PrintErrorStack();
		if(BOM_line_ask_attribute_string(objTag, Item_Revision, &Item_ID_Rev_str))PrintErrorStack();

		printf("\n ItemRevision is [%s] and ItemID is: [%s]\n",Item_ID_Rev_str,Item_ID_str);
		if(ITEM_find_rev(Item_ID_str,Item_ID_Rev_str,&rev_tag))PrintErrorStack();

		if(AOM_ask_value_string(rev_tag,"object_type",&objecttype));
		printf("\n\t object type at 1657 line **************** => %s\n",objecttype);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_PartType",&PartType));
		printf("\n\t PartType => %s\n",PartType);fflush(stdout);

		if(AOM_ask_value_string(rev_tag,"t5_DesignGrp",&t5_DesignGrp));
		printf("\n\t t5_DesignGrp => %s\n",t5_DesignGrp);fflush(stdout);

		//added in TZ 1.34
		if(AOM_ask_value_string(rev_tag,"item_id",&designRev_id));
		printf("\n\t designRev_id => %s\n",designRev_id);fflush(stdout);

		ninethteenth = subString(designRev_id, 8, 2);
		printf("\n\t 9th & 10th digit is :: [%s]\n", ninethteenth);fflush(stdout);

		item_idlength = strlen(designRev_id);
		printf("\n\t Lenght of ItemID is => %d\n",item_idlength);fflush(stdout);

		printf ("logged in user,status of BOMLine :: %s,%s\n",username,cp_ChildChkOutValue);fflush(stdout);

		if(item_tag != NULLTAG)
		{
			// added by ajinkya on 2 march//
			if(AOM_ask_value_string(item_tag,"object_type",&objecttypeRight));
			printf("\n\t Finding Right object type => %s\n",objecttypeRight);fflush(stdout);

			//added on 20 march //

			if(ITEM_ask_latest_rev(item_tag,&ChildTagLatestRevt));
		}
		else
		{
			//Added by Prachi
			printf("\n\tinside else\n");fflush(stdout);
			ChildTagLatestRevt = va_arg(args, tag_t);
			if(ChildTagLatestRevt != NULLTAG)
			{
				printf("\ngot ChildTagLatestRev not null\n");fflush(stdout);
			}
			else
			{
				printf("\nnull revision tag\n");fflush(stdout);
			}

		}
		if(AOM_ask_value_string(ChildTagLatestRevt,"object_type",&sObjectTypeModulet));
		printf("\n\t Added for finding latest Arch Revision => %s\n",sObjectTypeModulet);fflush(stdout);

		if(AOM_ask_value_string(ChildTagLatestRevt,"t5_PartType",&ChildPartType));
		printf("\n\t ChildPartType => %s\n",ChildPartType);fflush(stdout);

		if( AOM_ask_value_string(ChildTagLatestRevt,"item_id",&Item_id_par)!=ITK_ok);
		printf("\n  Dropping Right Object Item ID is  ---->%s \n",Item_id_par); fflush(stdout);

		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"Design Revision")==0)
			{
				if((tc_strcmp(PartType,"CM")==0))
				{
					printf("\n Inside CM  \n");fflush(stdout);
					if(tc_strcmp(ChildPartType,"M") && tc_strcmp(ChildPartType,"D"))
					{
						printf("\n Contextual Product can have only module or dummy parts  \n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"CAD Module should  contain Module or Dummy Parts only");
						return ITK_err;
					}
				}
			}
			if(tc_strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);

			 //if(tc_strcmp(objecttypeRight,"T5_ArchModule")!=0)
			 if((tc_strcmp(sObjectTypeModulet,"T5_ArchModuleRevision")!=0))
				{
					printf("\n Inside the error -Platform shall have only Architecture Modules as immediate child \n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Platform shall have only Architecture Modules as immediate child");
					//EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
					return ITK_err;

				}
			}
		}
		
		//Added by kalpesh(21st_June_2018)//23rd_june

		if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
		{
			if(tc_strcmp(objecttype,"T5_ArchModuleRevision")==0)
			{
				printf("\n\t Inside the left object at ------------------->>>>>>>>=> %s\n",objecttype);fflush(stdout);
				
				char* child_type = NULL;
				if(AOM_UIF_ask_value(ChildTagLatestRevt,"t5_PartType",&child_type));
				printf("\n\t ChildPartType => %s sObjectTypeModulet => %s\n",child_type,sObjectTypeModulet);fflush(stdout);
				
				if((tc_strcmp(sObjectTypeModulet,"Design Revision")==0) && (tc_strcmp(child_type, "Module") == 0))
				{
				}
				else
				{
					printf("\n Inside the error-Arch_Module Rev. shall have only Module as immediate child \n");fflush(stdout);
					EMH_clear_errors();
					EMH_store_error_s1(EMH_severity_error,ITK_err, "Only Module can be attached to Arch Module as immediate child");
					return ITK_err;
				}
			}
		}
		//End (kalpesh)

		if(tc_strcmp(objecttype,"Design Revision")==0)
		{
			if(tc_strcmp(cp_ChildChkOutValue,"Y")==0)
			{
				printf("\nPart is already checked-out...........\n");fflush(stdout);
				if((tc_strcmp(PartType,"C")==0) && ((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0)))
				{
					printf("\nPartType is Cmponent & username is ---> %s\n",username);fflush(stdout);
					if(tc_strstr(DesignGrp,t5_DesignGrp)!=NULL) //go inside
					{						
						printf("\nDesignGrp of part found in set of String..\n");fflush(stdout);
						EMH_clear_errors();
						EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
						return ITK_err;						
					}else
					{
						if(tc_strcmp(ChildPartType,"D")!=0)
						{
							EMH_clear_errors();
							EMH_store_error_s3(EMH_severity_error,ITK_err,"\n Component can't have structure","please check PartType of",Item_id_par);
							return ITK_err;	
						}else
						{	
							printf("\ncomponent for Barrel-3 with part designation is 69..\n");fflush(stdout);
						}
					}
				}
			}else if ((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
			{
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Child parts can't be added to Checked-in/ERC Review part");
					return ITK_err;
			}
		}
	}

	//Vitthal :START: Validation on Architecture Module Revision Address and Module Address.
	//POM_get_user(&username,&user_tag);
	if((tc_strcmp(username,"loader")!=0) && (tc_strcmp(username,"infodba")!=0))
	{
		if((rev_tag != NULLTAG) && (BomLineModuleValidaion(rev_tag,item_tag)>0) )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"\n Architecture Module Revision Address and Module Address is not same.");
			return ITK_errStore;
		}
	}
	else
	{
		printf("\n\t BYPASS:Architecture Module Revision Address and Module Address Validaion for infodba and loader Login\n Cureent Login:%s ",username);fflush(stdout);
	}
	//Vitthal :END: Validation on Architecture Module Revision Address and Module Address.


	return error_code;
}

extern DLLAPI int  save_method_8(METHOD_message_t *msg, va_list args)
{

	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char   *type_name = NULL;
	char* username = NULL;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );
	tag_t 	newDataset = va_arg(args, tag_t );

	//tag_t	LatestRev = NULLTAG;  //Adi Alias         // commented by Adi
	//tag_t	ref_item = NULLTAG;   //Adi Alias        // commented by Adi
	//char* RevL = NULL;			  //Adi Alias   // commented by Adi
	//char *AliasTransFileName=NULL;//Adi Alias    // commented by Adi
	char* ObjNum1 = NULL;		  //Adi CMI
	char* username1 = NULL;		  //Adi CMI

	tag_t *tags_found = NULL;
	tag_t item_tag= NULLTAG, rev=NULLTAG;
	const char *item_name = NULL;
	char *SetType = NULL;
	char *USetType = NULL;
	const char *cTemp="item_id";
	int n_tags_found=0,len=0;
	char* itemName = NULL;
	char* startPart = NULL;
//	char* PartTypeCAT = NULL; //Adi 1.35

	printf("\nsave_method_8 ::  Inside Function\n");

	ObjNum1 =malloc(150);		  //Adi CMI

	if(newDataset != NULLTAG)
	{
		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag != NULLTAG)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("\nsave_method_8 :: objTypeTag is NULLTAG\n");
		}

		AOM_get_value_string(newDataset, "object_name", &object_name);

		printf("\n!!!!!!!!!!!!!!!!! save_method_8:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		if(strcmp(type_name,"ProPrt")==0 || strcmp(type_name,"ProAsm")==0 || strcmp(type_name,"ProDrw")==0)
		{
			POM_get_user(&username,&user_tag);
			printf("\nSession username == %s\n", username);
			if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
			{
				printf("\nsave_method_8 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");
				if(RES_is_checked_out(newDataset,&checkout1) !=ITK_ok) PrintErrorStack();
				if (checkout1==0)
				{
					if (RES_checkout(newDataset,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
					printf("\nsave_method_8 :: DataSet Checked Out \n");

				}
				else
				{
					printf("\nsave_method_8 ::  Skipping as DataSet already Checked Out\n");
				}
			}
		}
		/**************************** Adi CATIA 1.32 CMI dataset should not have rev or seq **********************************/

		else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)))
		{
			POM_get_user(&username1,&user_tag);
			printf("\n Session username1 == %s\n", username1);
			//if((tc_strcmp(username1,"infodba")!=0) && (tc_strcmp(username1,"loader")!=0))
			if(tc_strcmp(username,"loader")!=0)
			{
				if(tc_strcmp(type_name,"CMI2Drawing")!=0)	//skiping for CMI2Drawing
				{
					item_name=strtok(object_name,"/");
					if(item_name)
					{
						printf("\nItem Name %s ",item_name);fflush(stdout);

						if(ITEM_find_items_by_key_attributes(1,&cTemp, &item_name, &n_tags_found, &tags_found) !=ITK_ok);PrintErrorStack();

						if (n_tags_found > 1)
						{
							MEM_free(tags_found);
							EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
							printf("More than one items matched with id %s\n", item_name);fflush(stdout);
							exit (0);
						}
						else if (n_tags_found == 1)
						{
							printf("only one items matched with id %s\n", item_name);fflush(stdout);
							item_tag = tags_found[0];
							if(ITEM_ask_latest_rev(item_tag,&rev)); PrintErrorStack();

							if(rev != NULLTAG)
							{
								if( AOM_ask_value_string(rev,"item_id",&itemName)!=ITK_ok);
								if( AOM_ask_value_string(rev,"t5_StartPartProduct",&startPart)!=ITK_ok);
								printf("\nt5_Material %s StartPartProduct %s \n",itemName,startPart);fflush(stdout);
								//if( AOM_ask_value_string(rev,"t5_PartType",&PartTypeCAT));  //Adi 1.35 commented
								if(strcmp(startPart,"")!=0)
								{
									SetType=strtok(type_name,"CMI2");
									tc_strupr(SetType,&USetType);
									printf("\n*****DataSet Type [%s] \n",USetType);

									if(tc_strstr(startPart,USetType)!=NULL)
									{
										printf("\nStartPart and DataSet Type Match..[%s] \n",USetType);
									}
									else
									{
										printf("\nStartPart %s and DataSet Type %s Not Matching\n",startPart,USetType);
										EMH_store_error_s4(EMH_severity_error,ITK_err,"Start Part of Design Revision and Dataset Type Not Matching..", startPart," Not Matching with Dataset", type_name);
										return ITK_err;
									}
									//if((tc_strcmp(PartTypeCAT,"A")==0)&&(tc_strcmp(USetType,"PART")==0)) //Adi 1.35 
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Assembly cannot have CMI2Part as an attachment");	//Adi 1.35
									//	return ITK_err;

									//}
									//else if((tc_strcmp(PartTypeCAT,"C")==0)&&(tc_strcmp(USetType,"PRODUCT")==0))//Adi 1.35 
									//{
									//	EMH_store_error_s1(EMH_severity_error,ITK_err,"Part type Component cannot have CMI2Product as an attachment"); //Adi 1.35	
									//	return ITK_err;
									//}
								}
							}

						}
					}
				}

				printf("\n save_method_8:: Inside CMI Condition \n");fflush(stdout);

				ObjNum1=strtok(object_name,"/");

				if(AOM_lock(newDataset));
				printf("\n after locking catia dataset \n");fflush(stdout);

				AOM_set_value_string(newDataset,"object_name", ObjNum1);

				if(AOM_save(newDataset));
				if(AOM_unlock(newDataset));
				printf("\n after unlocking catia dataset \n");fflush(stdout);
			}
		}
		  /******************************* Adi CATIA 1.32 ends *************************************/

		  /********************************* Adi ALIAS 1.32 *************************************/
       // commented by Adi
		/*else if (((strcmp(type_name,"T5_Alias")==0) || (strcmp(type_name,"WIRE")==0)||(strcmp(type_name,"T5_Wire")==0)))
		{
			printf("\n DATASET NAME IS [%s] , [%s]\n" ,object_name,type_name);fflush(stdout);

			if(ITEM_find_item(object_name,&ref_item));
			printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

			if(ITEM_ask_latest_rev(ref_item,&LatestRev));
			printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

			if( AOM_ask_value_string(LatestRev,"item_revision_id",&RevL)==ITK_ok)
			printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(primaryA,"object_name",&DatasetNameAlias));
			AliasTransFileName=malloc(2000);
			strcpy(AliasTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=");
			//strcpy(JTTransFileName,"dispatcher_create_rqst -u=dcproxy -p=dcproxy -g=dba -i=282960203301  -r='A;5' -dn=282960203301/NR -dt=CMI2Part -pr=1 -pn=SIEMENS -tn=catiav5tojt -ty=COMMAND_LINE");

			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName," ");
			strcat(AliasTransFileName,"-r='");

			strcat(AliasTransFileName,RevL);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-dt=T5_Alias  -dn='");
			strcat(AliasTransFileName,object_name);
			strcat(AliasTransFileName,"'");
			strcat(AliasTransFileName," ");

			strcat(AliasTransFileName,"-pr=1 -pn=SIEMENS   -tn=aliastocatpart -ty=COMMAND_LINE");
			printf("\n AliasTransFileName  T5_Alias before system is  =>%s\n", AliasTransFileName);fflush(stdout);

			system(AliasTransFileName);

			printf("\n After T5_Alias dispatcher_create_rqst shell =>%s\n", AliasTransFileName);fflush(stdout);*/

		//}   /****************************** Adi ALIAS 1.32  ***************************************/
	}
	printf("\nsave_method_8 ::  Exiting Function\n");
	return error_code;
}

/*********** Adi for CREO AND CATIA ********************/

extern DLLAPI int  save_method_9(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	int i = 0;
	tag_t objTypeTag = NULLTAG;
	tag_t user_tag=NULLTAG;

	logical	checkout1 = 0;

	char *object_name = NULL;
	char *object_type = NULL;
	char   *type_name = NULL;
	char   *type_name3 = NULL;
	char   *ObjNum = NULL;
	char   *ObjNum1 = NULL;
	char* username = NULL;

	const char		*reason	= "";
	const char		*change_id	= "";
	const char		*dir_name = "";

	char * catiasynch	 = NULL;
	tag_t	queryTag	 = NULLTAG;
	int		n_entries	 = 1;
	int		countDep	 = 0;
	char *qry_entries[1] = {"SYSCD"};
	char **qry_values    = (char **) MEM_alloc(10 * sizeof(char *));
	int		resultCount	 = 0;
	int		k			= 0;
	tag_t	*rev		 = NULLTAG;
	char	*itemId		 = NULL;
	char	*RevL		 = NULL;
	tag_t			objTypeTagDi				= NULLTAG;
	tag_t *CntrlObjectTag=NULLTAG;
	tag_t			primary					= NULLTAG;
	tag_t  *secondary_objects3	= NULLTAG;
	tag_t	LatestRev = NULLTAG;
	tag_t	LatestRev1 = NULLTAG;
	tag_t	ref_item = NULLTAG;

	//char cmi_name[TCTYPE_name_size_c+1];

	/*tag_t datasetTypeTag = va_arg(args, tag_t);
	const 	char* datasetName = va_arg(args, const 	char* );
	const 	char* datasetDescription = va_arg(args, const 	char* );
	const 	char* datasetID = va_arg(args, const 	char* );
	const 	char* datasetRevision = va_arg(args, const 	char* );*/
	tag_t 	newDataset = va_arg(args, tag_t );
	ObjNum =malloc(150);
	ObjNum1 =malloc(150);
	//ObjNum1 =malloc(100);


	//printf("\n save_method_9 ::  Inside Function \n");

		if (TCTYPE_ask_object_type(newDataset,&objTypeTag)!=ITK_ok) PrintErrorStack();
		if(objTypeTag != NULLTAG)
		{
			if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
		}
		else
		{
			printf("\n save_method_9 :: objTypeTag is NULLTAG\n");
		}

		AOM_get_value_string(newDataset,"object_name", &object_name);

		printf("\n!!!!!!!!!!!!!!!!! save_method_9:::::::::type_name[%s] -- %s\n",type_name, object_name);fflush(stdout);

		POM_get_user(&username,&user_tag);

		printf("\n Session username == %s\n", username);

		//if((tc_strcmp(username,"infodba")!=0) && (tc_strcmp(username,"loader")!=0))
		if(tc_strcmp(username,"loader")!=0)
		{
			if(((tc_strcmp(type_name,"ProPrt")==0) || (tc_strcmp(type_name,"ProAsm")==0) || (tc_strcmp(type_name,"ProDrw")==0)))
			{

				printf("\n save_method_9 :: Inside ProPrt | ProAsm | ProDrw Condition.\n");

				if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
				{
					printf("\n ERROR: save_method_9 :: DataSet  \n");
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Please remove '/' , ';' ,Revision and Seq from Object Name ");
					return ITK_err;

				}
				else
				{
					printf("\n save_method_9 ::  Skipping as DataSet \n");fflush(stdout);
				}

			}
			/*else if(((tc_strcmp(type_name,"CMI2Product")==0)|| (tc_strcmp(type_name,"CMI2Part")==0)|| (tc_strcmp(type_name,"CMI2Drawing")==0)))
			{
				printf("\n ADI for CATIA datasets \n");

				if(QRY_find("ControlObjects", &queryTag));

				if (queryTag)
				{
					printf("\n Found Query CMI \n");fflush(stdout);
				}
				else
				{
					printf("\n Not Found Query CMI \n");fflush(stdout);
				}

				qry_values[0] = "CatData" ;

				ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &CntrlObjectTag));

				printf(" \n resultCount :%d:", resultCount); fflush(stdout);

				if(resultCount>0)
				{
					printf("\n CatData control object found-------------- \n");fflush(stdout);

					//if( GRM_list_primary_objects_only(newDataset,NULLTAG,&countDep,&secondary_objects3)!=ITK_ok)PrintErrorStack();
					//printf("\n count found %d \n ",countDep);fflush(stdout);

					strcpy(ObjNum,object_name);
					ObjNum1=strtok(ObjNum,"/");

					if(ITEM_find_item(ObjNum1,&ref_item));
					//printf("\n ITEM_find_item AAA-------------- \n");fflush(stdout);

					if(ITEM_ask_latest_rev(ref_item,&LatestRev));
					printf("\n ITEM_ask_latest_rev AAA------------- \n");fflush(stdout);

					if( AOM_ask_value_string(LatestRev,"item_id",&RevL)==ITK_ok)
					printf("\n RevL AAA--------------%s \n",RevL);fflush(stdout);

					AOM_get_value_string(LatestRev,"object_type", &object_type);
					printf("\n object_type AAA--------------%s \n",object_type);fflush(stdout);

					if(tc_strcmp(object_type,"Design Revision")==0 )
					{
						if( AOM_ask_value_string(LatestRev,"t5_IsCatSynch",&catiasynch)==ITK_ok)

						printf("\n catiasynch value is -------------- %s \n",catiasynch);fflush(stdout);

						if(tc_strcmp(catiasynch ,"Y")==0)
						{
						    printf("\n part has been synched from catia--- so no issues \n");fflush(stdout);
						}
						else
						{
							printf("\n catiasynch VALUE IS N OR NULL \n");fflush(stdout);

							if (tc_strstr(object_name,"/") || (tc_strstr(object_name,";")))
							{
								printf("\n Part has not been synchronised from Catia \n");fflush(stdout);
								//EMH_store_error_s1(EMH_severity_warning,ITK_err,"Please synchronize the part from Catia");
								EMH_store_error_s1(EMH_severity_error,ITK_errStore, "Please remove '/' , ';' ,Revision and Seq from Object Name");

								return ITK_errStore;
							}
							else
							{
								printf("\n / OR ; does not exist for Catia dataset \n");fflush(stdout);
							}
						}
					}
				}
				else
				{
					 printf("\n Pl create CatData control object  -------------- \n");fflush(stdout);
				}
			}*/
		}


	printf("\nsave_method_9 ::  Exiting Function\n");
	return error_code;
}

/*************Adi for CREO AND CATIA ********************/




//upp Start

extern DLLAPI int qauntity_handled_as_per_uom (METHOD_message_t *msg, va_list args)
{
	//tag_t    object;
	int ifail = ITK_ok;
	char  object_type[WSO_name_size_c+1] ;
	char* uomValue;
	char* sPartType;
	char	*sDesgNoD	= NULL;
	char	*DesgNo	= NULL;


	tag_t parent_bvr=va_arg(args, tag_t);
	tag_t child_item=va_arg(args, tag_t);
	tag_t child_bom_view=va_arg(args, tag_t);
	int n_occurrences=va_arg(args, int);
	tag_t** occ_thread_tags=va_arg(args, tag_t**);

	printf("Upendra...99=====n_occurrences=%d",n_occurrences);
	WSOM_ask_object_type  (child_item, object_type);
	printf("Object Name upp=%s",object_type);

	if( AOM_UIF_ask_value(child_item,"t5_uom",&uomValue)!=ITK_ok);PrintErrorStack();
	printf("\nUOM name=%s",uomValue);
	if( AOM_UIF_ask_value(child_item,"t5_RevPartType",&sPartType)!=ITK_ok);PrintErrorStack();
	printf("\nPart Type :%s",sPartType);fflush(stdout);
	if( AOM_UIF_ask_value(child_item,"item_id",&DesgNo)!=ITK_ok);PrintErrorStack();
	printf("\nComponent part Num :%s",DesgNo);fflush(stdout);


if ((strcmp(sPartType,"Dummy")==0) || (strcmp(sPartType,"Information Fitment Drawing")==0))
	{
        //IFD-Dummy part should be 12 digit and 9th and 10th digit should be 00/04
	    sDesgNoD=subString(DesgNo, 8, 2);
		printf("\n IFD-Dummy part 9th and 10th digit [%s]\n", sDesgNoD);fflush(stdout);

		if ((strlen(DesgNo) ==12) && ((tc_strcmp(sDesgNoD,"04")==0) || (tc_strcmp(sDesgNoD,"00")==0)))
		{
			printf("\n 12 digit Dummy part-9th and 10th digit is 00/04: [%s]\n", DesgNo);fflush(stdout);
		    if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok);PrintErrorStack();
		}
		else
		{
		   printf("Dummy part is other than IFD");
		   if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
		}
	}
	else if (strcmp(uomValue,"4-Nos")==0)
	{
		printf("UOM is 4-nos and Qty=1 ...");
		if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],1)!=ITK_ok);PrintErrorStack();
	}
	else
	{
		printf("UOM is other than 4-nos and Qty=0 ...");
		if( PS_set_occurrence_qty(parent_bvr,*occ_thread_tags[0],0)!=ITK_ok);PrintErrorStack();
	}

	return ifail ;
}

//upp End

extern int t8save_design_custom_exit(int *decision, va_list args)
{
	int ifail = ITK_ok;
	METHOD_id_t  method ;
	METHOD_id_t  method1 ;
	METHOD_id_t  method2 ;
	METHOD_id_t  method3 ;
	METHOD_id_t  method4 ; //Adi
	METHOD_id_t  methodSVR ;
	METHOD_id_t  methodBOM ;

	*decision = ALL_CUSTOMIZATIONS;

	/* do something useful here, for now just return */
	printf("\n\n CreateDesign.c:it, via Custom User Exit.\n");fflush(stdout);
	if ( METHOD_find_method("Design", IMAN_save_msg, &method) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("Design Revision", IMAN_save_msg, &method1) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("CMI2Drawing", AE_save_dataset_msg, &method2) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("BOMLine", BOMLine_add_msg, &method3) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("VariantRule", IMAN_save_msg, &methodSVR) !=ITK_ok);PrintErrorStack();
	if ( METHOD_find_method("BOMView Revision","PS_bvr_create_occs",&methodBOM) !=ITK_ok);PrintErrorStack();//uppp

    if (method.id != NULLTAG)
	{
		if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) save_method_3, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");
	    }

	if (method1.id != NULLTAG)
	{
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) save_method_4, NULL)!=ITK_ok);PrintErrorStack();
		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
	    else
	    {
			printf("\n !!!!!!!!!!!Method not found!!!!!!!!!!\n");
	    }
    	if (method2.id != NULLTAG)
	{
		if( METHOD_add_action(method2, METHOD_pre_action_type, (METHOD_function_t) save_method_5, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 not found!!!!!!!!!!\n");
    }

	if (methodSVR.id != NULLTAG)
	{
		if( METHOD_add_action(methodSVR, METHOD_pre_action_type, (METHOD_function_t) save_method_SVR, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!! methodSVR not found!!!!!!!!!!\n");
    }

	//Pro-E specific Customization to Check-Out Dataset on Create.
	if ( METHOD_find_method("Dataset", AE_create_dataset_msg , &method2) !=ITK_ok) PrintErrorStack();
    if (method2.id != NULLTAG)
	{
		printf("\nInside Method 2\n");
		if( METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) save_method_8, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method2 for AE_create_dataset_msg Post not found!!!!!!!!!!\n");
    }
	//End of Pro-E specific Customization to Check-Out Dataset on Create.

	 if (method3.id != NULLTAG)
	{
		if( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) save_method_7, NULL)!=ITK_ok);PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method3 not found!!!!!!!!!!\n");
    }

	/* Adi for CREO  */

	if ( METHOD_find_method("Dataset", AE_save_dataset_msg , &method4) !=ITK_ok) PrintErrorStack();
    if (method4.id != NULLTAG)
	{
		printf("\nInside Method 2\n");

		if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_9, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n !!!!!!!!!!!Method4 for AE_save_dataset_msg Post not found!!!!!!!!!!\n");
    }


	    if (methodBOM.id != NULLTAG)///upp
	{
		printf("\nInside methodBOM\n");
		if( METHOD_add_action(methodBOM, METHOD_post_action_type, (METHOD_function_t) qauntity_handled_as_per_uom, NULL)!=ITK_ok) PrintErrorStack();

		if( ifail != ITK_ok )
		{
				EMH_store_error( EMH_severity_error, ifail );
		}
	}
    else
    {
		printf("\n methodBOM not found\n");
    }

	/* Adi for CREO  */


//       if (method4.id != NULLTAG)
//	{
//		if( METHOD_add_action(method4, METHOD_pre_action_type, (METHOD_function_t) save_method_6, NULL)!=ITK_ok);PrintErrorStack();
//
//		if( ifail != ITK_ok )
//		{
//				EMH_store_error( EMH_severity_error, ifail );
//		}
//	}
//    else
//    {
//		printf("\n !!!!!!!!!!!Method4 not found!!!!!!!!!!\n");
//    }
	   printf("\n\n CreateDesign.c:it, t8save_design_custom_exit end .\n");fflush(stdout);

    return ifail;
}


extern DLLAPI int Save_validation_register_callbacks ()
{
     printf("\n \n Save_validation.c:::Hello Teamcenter, via Custom User Exit\n");fflush(stdout);

      CUSTOM_register_exit ( "Save_validation", "USER_init_module", (CUSTOM_EXIT_ftn_t) t8save_design_custom_exit);
      return ( ITK_ok );
}
