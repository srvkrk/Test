cd /tmp/uaprod && 
grep $1 $(ls -rt uaprodmgrstart_*.log |tail -1)|  grep Server| awk -F "Server" '{print $2}'| awk -F"@" '{print $1}' |grep tcserver|
while read line ; do 
	ps -ef|grep "$line@"|grep -v grep|awk '{print $2}'
done|
while read line1 ; do 
  	kill -9 $line1
done

ssh uaprod@172.22.97.26 -n "/user/uaprod/muktesh/SessionKill/SessionKill2.sh $1 "
