cd /tmp/cvprod &&
grep $1 $(ls -rt cvprodmgrstart_*.log |tail -1)|  grep Server| awk -F "Server" '{print $2}'| awk -F"@" '{print $1}' |grep tcserver|
while read line ; do
        ps -ef|grep "$line@"|grep -v grep|awk '{print $2}'
done|
while read line1 ; do
        kill -9 $line1
done

#ssh 172.22.97.30 "cd /user/cvprod/muktesh/SessionKill ; $PWD/SessionKill.sh $1"
ssh cvprod@172.22.97.30 -n "/user/cvprod/muktesh/SessionKill/SessionKill2.sh $1 "
