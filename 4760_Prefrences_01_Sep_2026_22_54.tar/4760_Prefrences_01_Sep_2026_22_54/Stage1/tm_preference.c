Preference Name -->Value
TC_Customization_Library-->tm_projdatamgmt
T5_ChnDlg_DefaultChildProperties-->t5_ChassisTypeforAssm T5_HasChassisTypeNo
T5_ChnDlg_Design_default_relation-->T5_HasChassisTypeNo
T5_ChnDlg_PseudoFolder-->t5_ChassisTypeforAssm
Design_T5_ChnDlg_default_relation-->T5_HasChassisTypeNo
Design_PseudoFolder-->T5_HasChassisTypeNo