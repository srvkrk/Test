
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:tm_Certification.c
*
* Description		: > This is related to STN Module in TCUA .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 10/12/2024   	Sanjoy Mondal			    change as per Teamcenter 14.3
* 

* -----------------------------------------------------------------------------
*
*****************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128


#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>
#include <property/idgeneration.h>
#include <Fnd0Participant/participant.h>
#include <tccore/item_msg.h>

#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}	



#define ITK_err 919002
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define PLM_error (EMH_USER_error_base+26)
#define ITEM_CHECKED_OUT  EMH_USER_error_base + 5
#define JT_PDF_NOT_FOUND  EMH_USER_error_base + 8
#define BU_is_ntSame  EMH_USER_error_base + 28
#define ITEMS_NOTFOUND_INDENT  EMH_USER_error_base+24
#define DESREV_CONTLIMIT  EMH_USER_error_base+25
#define Not_Item_Revision  EMH_USER_error_base + 6
#define Non_PLM_Parts  EMH_USER_error_base + 7
#define T5_WorkFlowSTNHandlerErr (EMH_USER_error_base + 612)
#define T5_SpareKitDmlHandlerErr (EMH_USER_error_base + 1012)
#define T5_SpKitNotAttachToDMLTask (EMH_USER_error_base + 1013)


 char* t5STN_SubString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
//function added //

/*******************Sanjoy utility functions ***************************************/

int t5STN_RelatePrimaryWithSecondaryObj(tag_t primaryTag, tag_t secondaryTag, char* relation )
{
	int ifail = ITK_ok;
	tag_t relation_type = NULLTAG;
	tag_t primSecRelation = NULLTAG;
	if(GRM_find_relation_type(relation,&relation_type));
	if(relation_type!=NULLTAG)
	{
		if(GRM_create_relation(primaryTag, secondaryTag, relation_type,  NULLTAG, &primSecRelation));
		ifail = AOM_unlock(primSecRelation);
		if(GRM_save_relation(primSecRelation));
		ifail = AOM_refresh(primSecRelation,0);
	}
	else
	{
		printf("\nSTN:No relation %s exists...Please check. Very serious error.\n",relation);fflush(stdout);
	}
	 
	return ifail;
}

/* Function to add string into a set of string */
void t5STN_SetAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\nSTN: setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\nSTN: setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5STN_SetAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\nSTN: ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\nSTN: ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/************************* Utility functions *************************************************/

int getSTNGroupControlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	printf("\nSTN:In function  getSTNGroupControlTag...\nCheck for control object STNGrp-STNGrp....\n");fflush(stdout);
	//*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "STNGrp";
	qry_values[1] = "STNGrp";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN: Control objects STNGrp-STNGrp: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			printf("\nSTN:Name:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			
			
			//*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}

int getReleaseSTNCtrl(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	printf("\nSTN:In function  getReleaseSTNCtrl...\nCheck for control object STNRelzGrp-STNRelzGrp....\n");fflush(stdout);
	//*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "STNRelzGrp";
	qry_values[1] = "STNRelzGrp";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN: Control objects STNRelzGrp-STNRelzGrp: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo4 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			printf("\nSTN:Name:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			
			
			//*result = TRUE;
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}
int getSTNReportControlTag(tag_t *contrlTag)
{
	int ifail = ITK_ok;
	//printf("\nSTN:In function  getSTNReportControlTag...\nCheck for control object STNReport-STNReport....\n");fflush(stdout);
	//*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	
	qry_values[0] = "STNReport";
	qry_values[1] = "STNReport";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN: Control objects STNReport-STNReport: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		
		if(cntrlObj!=NULLTAG)
		{
			logical delInd = FALSE;
			char* name = NULL;
			char* userInfo1 = NULL;
			char* userInfo2 = NULL;
			char* userInfo3 = NULL;
			char* userInfo4 = NULL;
			char* userInfo5 = NULL;
			char* userInfo6 = NULL;
			char* userInfo7 = NULL;
			char* userInfo8 = NULL;
			char* userInfo9 = NULL;
			
			if(AOM_ask_value_string(cntrlObj,"object_string",&name));
			if(AOM_ask_value_logical(cntrlObj,"t5_DelInd",&delInd));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			printf("\nSTN:Name:%s\nDelete Indicator:%d\nUser Info1:%s\nUser Info2:%s\nUser Info3:%s\nUser Info4:%s\nUser Info5:%s\nUser Info6:%s\nUser Info7:%s\nUser Info8:%s\nUser Info9:%s",name,delInd,userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
			
			*contrlTag = cntrlObj;
		}

	}

	return ifail;
}

int getDeptMasterObject(char *deptNo, tag_t *deptMasterTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\nSTN:\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = "T5_DeptMaster";
	qry_values[1] = deptNo;
		
	if(QRY_find2("Item...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\nSTN: getDeptMasterObject: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*deptMasterTag = itemObj[count-1];
	}
	
	return ifail;
}

int getDeptMasterRevTag(char* deptNo, tag_t* deptMasterRevTag)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULL;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\nSTN:\n object_type ===> [%s]\n",object_type);fflush(stdout);
	tag_t DeptMstrTag = NULLTAG;
	tag_t Final_DeptTag = NULLTAG;
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = "T5_DeptMaster";
	qry_values[1] = deptNo;
		
	if(QRY_find2("Item...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	//printf("\nSTN: getDeptMasterObject: count==>%d", count);fflush(stdout);

	if(count > 0) 
	{
		DeptMstrTag = itemObj[0];
		if(ITEM_ask_latest_rev(DeptMstrTag, &Final_DeptTag)!=ITK_ok)PrintErrorStack();
	}
	
	*deptMasterRevTag = Final_DeptTag;
	
	return ifail;
}

int isEligibleToCreUpdSTNHeader(logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for STN Creation updation access\n");fflush(stdout);
	
	char* userName = NULL;
	tag_t userTag = NULLTAG;
	char* groupName = NULL;
	tag_t groupTag = NULLTAG;
	*result = FALSE;
	
	POM_get_user(&userName,&userTag);	
	POM_ask_group(&groupName, &groupTag);
	
	printf("\nSTN:Session user:[%s], Group Name:[%s]\n", userName,groupName);fflush(stdout);
	if(groupTag != NULLTAG)
	{
		 if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"DML_Participants_Group")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0 || tc_strcmp(groupName,"DML_Participants_Group_CV")==0 || tc_strcmp(groupName,"STN_Participant_Group")==0 || tc_strcmp(groupName,"STN_Participants_Group")==0)
		 {
			tag_t roleTag = NULLTAG;
			SA_ask_current_role(&roleTag);
			if(roleTag != NULLTAG)
			{
				char* roleName = NULL;
				SA_ask_role_name2(roleTag, &roleName);
				printf("\nSTN:Session user:[%s], Group Name:[%s], RoleName[%s]\n", userName,groupName,roleName);fflush(stdout);
				if(tc_strcmp(roleName,"CertificationGrp")==0 || tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0)
				{
					printf("\n\n\tSTN: isEligibleToCreUpdSTNHeader 00*********************PLM CertificationGrp, dba and support user having access*********************\n");fflush(stdout);
					*result = TRUE;
					return ifail;
					
				}
				else 
				{
					
					
					printf("\n\n\tSTN: isEligibleToCreUpdSTNHeader 111*********************You Don't Have access to create STN *********************\n");fflush(stdout);
					*result = FALSE;
					//return(PLM_error);
					
				}
			}
			else
			{
				printf("\n\n\tSTN: isEligibleToCreUpdSTNHeader 222*********************Should not have come here . Fatal error*********************\n");fflush(stdout);
			}
			 
			
		 }
		 else
		 {
			
			 printf("\n\n\t 333*********************isEligibleToCreUpdSTNHeader You Don't Have access to create STN *********************\n");fflush(stdout);
			 //return(PLM_error);
			 *result = FALSE;
			 
		 }
	}
	else
	{
		printf("\n\n\tSTN: 22 isEligibleToCreUpdSTNHeader *********************Should not have come here . Fatal error*********************\n");fflush(stdout);
		*result = FALSE;
	}	
	
	return ifail;
	
}

int isAllowedToUpdateSTNClause(tag_t clauseRevTag, logical *result)
{
	int ifail = ITK_ok;
	
	char* userName = NULL;
	tag_t userTag = NULLTAG;
	char* groupName = NULL;
	tag_t groupTag = NULLTAG;
	*result = FALSE;
	tag_t roleTag = NULLTAG;
	
	SA_ask_current_role(&roleTag);
	
	POM_get_user(&userName,&userTag);	
	POM_ask_group(&groupName, &groupTag);
	
	char* roleName = NULL;
	if(roleTag != NULLTAG)
	{
		SA_ask_role_name2(roleTag, &roleName);
	}
	
	
	printf("\nSTN:Session user:[%s], Group Name:[%s]\n", userName,groupName);fflush(stdout);
	if(groupTag != NULLTAG)
	{
	
			
			printf("\nSTN:Session user:[%s], Group Name:[%s], RoleName[%s]\n", userName,groupName,roleName);fflush(stdout);
			if(tc_strcmp(roleName,"CertificationGrp")==0  || tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0)
			{
				printf("\n\n\tSTN: isAllowedToUpdateSTNClause 00*********************PLM CertificationGrp, dba and support user having access*********************\n");fflush(stdout);
				*result = TRUE;
				return ifail;
				
			}
			else 
			{
				
				printf("\nSTN:Check if the Department doc is in Lifeccycle and anaylst is the session user.");fflush(stdout);
				
				//Get the department Tag.
				//For CAR/SUV
				tag_t deptDocClsRelType = NULLTAG;
				ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptDocClsRelType);
				
				if(deptDocClsRelType != NULLTAG)
				{
					int i = 0;
					tag_t* deptDocTags = NULL;
					int deptDocCnt = 0;
					tag_t deptDocTag = NULLTAG;
					ifail = GRM_list_primary_objects_only(clauseRevTag,deptDocClsRelType,&deptDocCnt,&deptDocTags);
					printf("\nSTN:STN:deptDocCnt [%d]", deptDocCnt);fflush(stdout);
					for (i=0;i<deptDocCnt ;i++ )
					{
						logical is_latest = false;
						
						if(ITEM_rev_sequence_is_latest(deptDocTags[i],&is_latest));
						printf("\nSTN:is_latest : %d\n",is_latest);fflush(stdout);

						if(is_latest != true)
						{
							printf("\nSTN:is_latest is not true .....\n");fflush(stdout);
						}
						else
						{
							deptDocTag = deptDocTags[i];

						}
					}
					
					if(deptDocTag != NULLTAG)
					{
						char* deptDocWFStep = NULL;
						
						ifail = AOM_UIF_ask_value(deptDocTag,"fnd0ActuatedInteractiveTsks",&deptDocWFStep);
						printf("\nSTN:Workflow step of Department Tag: [%s]",deptDocWFStep);fflush(stdout);
						if(tc_strstr(deptDocWFStep,"Expand Departmnt Object,Update Clause Objects")!=NULL)
						{
							printf("\nSTN:In Correct workflow step. Allowed\n");fflush(stdout);
							*result = TRUE;
							return ifail;
						}
						else
						{
							
							printf("\nSTN:isAllowedToUpdateSTNClause 111*********************You Don't Have access to update STN Clause *********************\n");fflush(stdout);
							//*result = FALSE;
						}
					}
					
					
					
				}
				
				
				
				//return(PLM_error);
				
			}
		
		
	}
	else
	{
		printf("\nSTN:22 isAllowedToUpdateSTNClause *********************Should not have come here . Fatal error*********************\n");fflush(stdout);
		*result = FALSE;
	}	
	
	
	return ifail;
}

int ClauseToDept(char* item_id_dup,tag_t STNHeaderRev, tag_t Latest_Deptrev )
{
	int ifail = ITK_ok;
	tag_t DeptMstrTag = NULLTAG;
	char* StnHdrNum = NULL;
	char* StnHdrDesc = NULL;
	char* DeptDocNum = NULL;
	char* StnPlant = NULL;
	
	printf("\nSTN:Inside the function of ClauseToDept -Department master -- START \n");fflush(stdout);
	ifail = getDeptMasterObject(item_id_dup,&DeptMstrTag);
	
	if(DeptMstrTag == NULLTAG)
	{
		printf("\nSTN:No department found [%s]....\n",item_id_dup);fflush(stdout);
		return ITK_ok;
	}
	
	
	/*******************Get STN HEader and Dept Doc  related properties *******************/
	if (AOM_ask_value_string(STNHeaderRev,"item_id",&StnHdrNum)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(STNHeaderRev,"object_desc",&StnHdrDesc)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(STNHeaderRev,"t5_StnArPlant",&StnPlant)!=ITK_ok)   PrintErrorStack();
	
	if (AOM_ask_value_string(Latest_Deptrev,"item_id",&DeptDocNum)!=ITK_ok)   PrintErrorStack();
	
	
	/***********Logic start *************************/
	
	char* DeptNumFind = NULL;
	tag_t Final_DeptTag = NULLTAG;
	char* ItemNameW = NULL;
	char* vehType = NULL;
	tag_t ReferencesCCVTag = NULLTAG;
	
	int VCcnt = 0;
	tag_t* VCattachments = NULLTAG;
	
	
	//printf("\nSTN: Inside - No of Department Master found case- :%d \n",deptCount);fflush(stdout);
	
	//DeptMstrTag = DeptmasterData[0];
	
	//if (AOM_ask_value_string(DeptMstrTag,"item_id",&DeptNumFind)!=ITK_ok)   PrintErrorStack();
	//printf("\nSTN:Department master id - :%s \n",DeptNumFind);fflush(stdout);

	if (AOM_ask_value_string(DeptMstrTag,"object_name",&DeptNumFind)!=ITK_ok)   PrintErrorStack();
	printf("\nSTN:Department master id - :%s \n",DeptNumFind);fflush(stdout);

	if(ITEM_ask_latest_rev(DeptMstrTag, &Final_DeptTag)!=ITK_ok)PrintErrorStack();

	if (AOM_ask_value_string(Final_DeptTag,"object_name",&ItemNameW)!=ITK_ok)   PrintErrorStack();
	printf("\nSTN:Master Revision Object  name -----------> Item ID: %s \n",ItemNameW);fflush(stdout);
	
	
	//Get the vehicle type from STN Header Revision
	if (AOM_ask_value_string(STNHeaderRev,"t5_VehicleType",&vehType)!=ITK_ok)   PrintErrorStack();
	printf("\nSTN:Vehicle Type - :%s \n",vehType);fflush(stdout);
	if(tc_strlen(vehType)<=0)
	{
		printf("\nSTN:No Vehicle type selected. Exit...\n");fflush(stdout);
		return ITK_ok;
	}
	if(tc_strcmp(vehType,"Cars/SUV")==0)
	{
		if(GRM_find_relation_type("T5_hasClauseMaster", &ReferencesCCVTag)!=ITK_ok)PrintErrorStack();
		
	}
	else if(tc_strcmp(vehType,"FBV")==0)
	{
		if(GRM_find_relation_type("T5_hasFBVClause", &ReferencesCCVTag)!=ITK_ok)PrintErrorStack();
			
	}
	else if(tc_strcmp(vehType,"HCV")==0)
	{
		if(GRM_find_relation_type("T5_hasHCVClause", &ReferencesCCVTag)!=ITK_ok)PrintErrorStack();
			
	}
	else if(tc_strcmp(vehType,"MUV/LCV ABOVE 3.5 Ton")==0)
	{
		if(GRM_find_relation_type("T5_hasAbvClause", &ReferencesCCVTag)!=ITK_ok)PrintErrorStack();
				
	}
	else if(tc_strcmp(vehType,"MUV/LCV UPTO 3.5 Ton")==0)
	{
		if(GRM_find_relation_type("T5_hasBelowClause", &ReferencesCCVTag)!=ITK_ok)PrintErrorStack();
			
	}
	else
	{
		printf("\nSTN:Invalid Veh Type[%s]. Exit...\n",vehType);fflush(stdout);
		return ITK_ok;
	}
	
	if(GRM_list_secondary_objects_only(Final_DeptTag,ReferencesCCVTag,&VCcnt,&VCattachments)!=ITK_ok)PrintErrorStack();
	printf("\nSTN:VCcnt is ============= [%d]  \n",VCcnt); fflush(stdout);
	
	
	if (VCcnt > 0)
	{
		int ccv = 0;
		tag_t ClauseMstrTag = NULLTAG;
		char* ClauseDes = NULL;
		char* ClauseNo = NULL;
		char* ClsDataType = NULL;
		char* ClsFurthClassification = NULL;
		char* ClsIsLable = NULL;
		char* ClsRefClause = NULL;
		char* ClsRefClsDesc = NULL;
		char* ClsEnterColms = NULL;
		char* ClsEnterRows = NULL;
		char* ClsOldClNum = NULL;
		char* ClsOldUpd = NULL;
		char* ClsExtSort = NULL;
		
		for (ccv=0;ccv<VCcnt;ccv++ )
		{
			//printf("\nSTN: Inside 00000000  VCcnt is ============= [%d]  \n",VCcnt); fflush(stdout);
			ClauseMstrTag = VCattachments[ccv];
			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemDes",&ClauseDes)!=ITK_ok);
			//printf("\nSTN:ClauseDes============ [%s]  \n",ClauseDes); fflush(stdout);
			
			if( AOM_ask_value_string(ClauseMstrTag,"object_name",&ClauseNo)!=ITK_ok);
			//printf("\nSTN:Clause No============ [%s]  \n",ClauseNo); fflush(stdout);
			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemType",&ClsDataType)!=ITK_ok);
			//printf("\nSTN:Clause Data Type============ [%s]  \n",ClsDataType); fflush(stdout);

			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClasuemClassification",&ClsFurthClassification)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemIslable",&ClsIsLable)!=ITK_ok);				
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemRefCl",&ClsRefClause)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemRefClDes",&ClsRefClsDesc)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArTbCol",&ClsEnterColms)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArTbRow",&ClsEnterRows)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemOldClNum",&ClsOldClNum)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArUpdate",&ClsOldUpd)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemExtSort",&ClsExtSort)!=ITK_ok);
					
			
			/************Create Clause Revision ***************************/
			tag_t ClauseRevTagType = NULLTAG;
			tag_t ClaRevCreInp = NULLTAG;
			tag_t ClgTagType = NULLTAG;
			tag_t ClgTagItm = NULLTAG;
			tag_t MainClauseObj = NULLTAG;
			tag_t Latest_Clauserev = NULLTAG;
			
			TCTYPE_find_type("T5_ClauseRevision", NULL, &ClauseRevTagType);
			
			if(ClauseRevTagType == NULLTAG)
			{
				printf("\nSTN:ClauseRevTagType is NULLTAG");
				continue;
			}
				
			
			TCTYPE_construct_create_input(ClauseRevTagType, &ClaRevCreInp);
			
			if(ClaRevCreInp == NULLTAG)
			{
				printf("\nSTN:ClaRevCreInp is NULLTAG. Skip");
				continue;
			}

			ifail = AOM_set_value_string(ClaRevCreInp, "item_revision_id", "A;1");
			ifail = AOM_set_value_string(ClaRevCreInp, "sequence_id", "1"); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClaDes", ClauseDes);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArHNum", StnHdrNum); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseHeaderDesc", StnHdrDesc); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArDNum", DeptDocNum); 
			ifail = AOM_set_value_string(ClaRevCreInp, "object_desc", ClauseDes); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_IsClassified", ClsFurthClassification); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseRefDesc", ClsRefClsDesc); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseRefClNum", ClsRefClause); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_DummyClNum", ClsRefClause);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_DummyClauseNum", ClsRefClause);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArPlant", StnPlant); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseNum", ClauseNo);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseType", ClsDataType);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_IsLable", ClsIsLable);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ArTbCol", ClsEnterColms);
			
			
			

			TCTYPE_find_type("T5_Clause", NULL, &ClgTagType);    
			if(ClgTagType == NULLTAG)
			{
				printf("\nSTN:ClgTagType Tag is NULLTAG. \n");fflush(stdout);
				continue;
			}
			TCTYPE_construct_create_input(ClgTagType, &ClgTagItm);
			
			//printf("\nSTN:Now set propertied on Clause Item \n ");fflush(stdout);
			ifail = AOM_set_value_string(ClgTagItm, "object_name", ClauseNo);
			//printf("\nSTN:Now Object Creation of Clause  started  \n ");fflush(stdout);
			
			TCTYPE_create_object(ClgTagItm, &MainClauseObj);

			//printf("\nSTN:Executin for Clause ---  \n ");fflush(stdout);

			if(MainClauseObj != NULLTAG)
			{
				//printf("\nSTN:**** Main Clause Doc Object Created successfully. **** \n\n \n ");fflush(stdout);
				
				//if(AOM_save(MainClauseObj));
				ifail = AOM_save_with_extensions(MainClauseObj);						
				if(AOM_refresh(MainClauseObj,0));
				if(AOM_unlock(MainClauseObj));
					
			}				
			

			if(ITEM_ask_latest_rev(MainClauseObj, &Latest_Clauserev)!=ITK_ok)PrintErrorStack();

			if(Latest_Clauserev != NULLTAG)
			{
				ifail = AOM_lock(Latest_Clauserev);
				//printf("\nSTN: 7676 Inside the latest Latest_Clauserev tag Exists   \n");fflush(stdout);
				
				//If revision is NR then set as A
				char* ClauseRevStr = NULL;
				ifail = AOM_ask_value_string(Latest_Clauserev, "item_revision_id", &ClauseRevStr);
				//printf("\n Before set: Clause Revision : %s\n",ClauseRevStr);fflush(stdout);
				//Set initial revision as A
				ifail = AOM_set_value_string(Latest_Clauserev,"item_revision_id", "A;1");
				
				ifail = AOM_ask_value_string(Latest_Clauserev, "item_revision_id", &ClauseRevStr);
				//printf("\nSTN:After Set: Clause Revision : %s\n",ClauseRevStr);fflush(stdout);
				
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClaDes", ClauseDes);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArHNum", StnHdrNum); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseHeaderDesc", StnHdrDesc); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArDNum", DeptDocNum); 
				ifail = AOM_set_value_string(Latest_Clauserev, "object_desc", ClauseDes); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_IsClassified", ClsFurthClassification); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseRefDesc", ClsRefClsDesc); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseRefClNum", ClsRefClause); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClNum", ClsRefClause);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClauseNum", ClsRefClause);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArPlant", StnPlant);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseNum", ClauseNo);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseType", ClsDataType);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_IsLable", ClsIsLable);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ArTbCol", ClsEnterColms);
				
				if(tc_strcmp(ClsDataType,"String")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5StrACl");
					if(tc_strcmp(ClsIsLable,"Y")==0) 
					{
						ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseValue", "IsLable");
					}					
				}
				else if(tc_strcmp(ClsDataType,"Table")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5FtbACl");
				}
				else if(tc_strcmp(ClsDataType,"Dummy")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5DtACl");
					if(tc_strcmp(ClsIsLable,"Y")==0) 
					{
						ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseValue", "IsLable");
					}					
					
				}
				else if(tc_strcmp(ClsDataType,"Attachment")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5PctACl");
				}
				else
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5StrACl");
				}
				
				
				//################################## t5DummyClNum setting for report sorting #####
				
				char* sClNum2 = NULL;
				int xlength = 0;
				char* sClNum3 = NULL;
				char* sClNum4 = NULL;
				int flag = 0;
				tc_strdup(ClauseNo,&sClNum2);
				xlength=tc_strlen(sClNum2)+1;
				
				sClNum3=(char*)MEM_alloc(xlength*sizeof(char)+5);
				sClNum4=(char*)MEM_alloc(xlength*sizeof(char)+5);
				
				if ((*(sClNum2+0) == 'D' && *(sClNum2+1) == '1' && 	*(sClNum2+2) == '.' &&  *(sClNum2+3) == '5' && *(sClNum2+4) == '.') && 
				(*(sClNum2+6) == '.'|| *(sClNum2+6) == '\0' ) )
				{
					//printf("\n\nCondition is true for the below clause\n\n\n",*(sClNum2));
					flag=1;
					//clausecounter ++;
					//printf("clausecounter =%d",clausecounter);
					//printf("\nSTN:==1==");fflush(stdout);
				}
				else
				{
					//printf("\nSTN:==2==");fflush(stdout);
				}	
				if(*(sClNum2+2) == '.' || xlength==3)
				{
					//printf("\nSTN:==3==");fflush(stdout);
					int i=0;
					sClNum4=sClNum3;	    	   		
					for(i=0;i<xlength;i++)
					{
						if(i==1)
						{
							*sClNum3='0';      		    	   		   
							sClNum3++;
						}
						if(i==5 && flag==1)
						{
						   *sClNum3='0';      		    	   		   
								   sClNum3++;
						   flag=0;
						}
						else 
						{
							*sClNum3=*sClNum2;    
							sClNum2++;
							sClNum3++; 
						}      		    	   		     		    	   		  
					}
					*sClNum3='\0';   
				}
				else if((tc_strcmp(ClsFurthClassification,"DUMMY FOR TABLE 8")==0) && (tc_strcmp(ClsDataType,"Dummy")==0))
				{
					//printf("\nSTN:==4==");fflush(stdout);
					tc_strcpy(sClNum4,ClsExtSort);
				}
				else
				{
					//printf("\nSTN:==5==");fflush(stdout);
					tc_strcpy(sClNum4,sClNum2);
				}
				//printf("\nSTN:sClNum3:[%s] sClNum4:[%s]",sClNum3,sClNum4);fflush(stdout);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClNum", sClNum4);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClauseNum", sClNum4);
				
				
				if(sClNum3!=NULL)
				{
					if(tc_strlen(sClNum3)>0) MEM_free(sClNum3);
				}
				if(sClNum4!=NULL)
				{
					if(tc_strlen(sClNum4)>0) MEM_free(sClNum4);
				}
					
				
				//dummyclause no set end
				
				
				//if(AOM_save(Latest_Clauserev));
				ifail = AOM_save_without_extensions(Latest_Clauserev);
				if(AOM_refresh(Latest_Clauserev,0));
				if(AOM_unlock(Latest_Clauserev));		
				
				
				
				/***************** Start - Table property insert*****************************/
				
				if(tc_strcmp(ClsDataType,"Table")==0)
				{
					//printf("\nSTN:Sanjoy - update table row....\n");fflush(stdout);
					ifail = AOM_refresh(Latest_Clauserev, TRUE);
					
					int num_rows_to_insert = 0;
					int row_new_index = 0;
					tag_t* table_rows_tag = NULL;
					int property_index = 0;
					
					
					char* stnRow = NULL;
					
					//stnRow = (char*)MEM_alloc(tc_strlen(ClsEnterRows)*sizeof(char) + 50*sizeof(char));
					stnRow = (char*)MEM_alloc(1000*sizeof(char));
					
					if(ClsEnterRows == NULL) ClsEnterRows = "";
					//printf("\nSTN:sClsEnterRows==>[%s]\n",ClsEnterRows);fflush(stdout);
					if(tc_strlen(ClsEnterRows)>0)
					{
						
						tc_strcpy(stnRow,ClsEnterRows);
						
						//printf("\nSTN:stnRow==>[%s]\n",stnRow);fflush(stdout);
						char ** rowList = NULL;
						int rowCnt = 0;
						
						char *token = tc_strtok(stnRow, ",");
						while(token != NULL) {
							//printf("token[%s]\n", token);fflush(stdout);
							if(token !=NULL) 
							{
								if(!(tc_strcmp(token,"")==0)) t5STN_SetAddStr(&rowCnt,&rowList,token);
							}
							token = tc_strtok(NULL, ",");
							
							
						}
						
						
						//printf("\nSTN:rowCnt ===> %d\n",rowCnt);fflush(stdout);
						
						num_rows_to_insert = rowCnt;
						//printf("\n num_rows_to_insert ===> %d\n",num_rows_to_insert);fflush(stdout);
						//ifail = AOM_append_table_rows(Latest_Clauserev, "t5_colset",num_rows_to_append, &row_new_index, &table_rows_tag );
						ifail = AOM_refresh(Latest_Clauserev, TRUE);
						//printf("STN:ifail-refresh is %d\n",ifail);fflush(stdout);
						ifail = (AOM_insert_table_rows(Latest_Clauserev,"t5_colset",0,num_rows_to_insert,&table_rows_tag ));
						//TC_write_syslog (" \n ifail is %s\n",ifail);
						//printf("STN:ifail is %d\n",ifail);
						

						for ( property_index = 0 ; property_index < num_rows_to_insert; property_index++ )
						{
							//printf("\n rowList[%d]==> [%s]\n",property_index,rowList[property_index]);fflush(stdout);
							
							if(table_rows_tag [ property_index ] != NULLTAG)
							{
								//printf("\nSTN:Table row tag is NOT NULLTAG.\n");fflush(stdout);
								//set value on table row tag
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_col1", rowList[property_index] );
								ifail = AOM_save_with_extensions(table_rows_tag[property_index]);
								//printf("STN:ifail11 is %d\n",ifail);fflush(stdout);								
								
							}
							else
							{
								//printf("\nSTN:Table row tag is NULLTAG.\n");fflush(stdout);
							}

						}
											
						
												
						
						ifail = AOM_refresh(Latest_Clauserev, FALSE);
					}

				
					MEM_free(stnRow);
					
					ifail = AOM_refresh(Latest_Clauserev, FALSE);
				}

				
							
							
				/***************** End - Table property insert*****************************/					

			}

		
			if(Latest_Deptrev != NULLTAG)
			{
				//printf("\nSTN:Inside the latest Department Doc Tag Exists   \n");fflush(stdout);

			}

			//printf("\n \n\nSTN:Creating Relationship between Depart Doc and Clause Rev **** \n\n \n ");fflush(stdout);
							
			ifail = t5STN_RelatePrimaryWithSecondaryObj(Latest_Deptrev,Latest_Clauserev,"T5_DeptDocHasClause");
			
			if(ifail == ITK_ok)
			{
				printf("\nSTN:Rel created: [%d - [%s%s] - [%s]",ccv+1,ItemNameW,StnHdrNum,ClauseNo);fflush(stdout);
			}
			else
			{
				printf("\nSTN:RELATIONSHIP NOT CREATED between department doc and Clause Rev \n");fflush(stdout);
			}
			
					

			
			
			
		}
	}
	
	
	printf("\nSTN:Inside the function of ClauseToDept -Department master --- END \n");fflush(stdout);
	return ifail;	
}


int isLiveForSTNIDgeneration(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN: Check for control object STNIDGen....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "STNIDGen";
	qry_values[1] = "STNIDGen";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN:STNIDGen:Control objects STNIDGen: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		char* usrInfo3 = NULL;
		
		if(cntrlObj!=NULLTAG)
		{			
			printf("\nSTN:STNIDGen: Live for STNIDGen\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}

int getLatestSTNTag(tag_t* stnTag)
{
	int ifail = ITK_ok;
	
	printf("\nSTN:Get Latest STN Tag in PLM Database \n");fflush(stdout);
	
	
	return ITK_ok;
	
	
	
}


int getNextSTNNumber(char * info1 ,char **nextvalue)
{
    int ifail = 0;
	
	
    const char * select_attrs[]={"puid"};
	const char *pSelectExprs[] = { "likeExpr" };
	int n_stns = 0;
	int n_cols = 0;
	void ***values = NULL;

	char *newid;
	char *item_idval=NULL;

	newid=(char *) MEM_alloc (20);		
	tc_strcpy(newid,"STN*");
	const char *stnId={newid};
	const char *attr="item_id";	
	
	//Step 1-   Creates a new enquiry.
	ifail = POM_enquiry_create ("find_stn_objs" );
	ifail = POM_enquiry_add_select_attrs ("find_stn_objs","T5_STNHeader",1,select_attrs);
	
	ifail = POM_enquiry_set_string_value("find_stn_objs", "value", 1, &stnId,POM_enquiry_bind_value);
	ifail = POM_enquiry_set_attr_expr ("find_stn_objs", pSelectExprs[0], "T5_STNHeader", attr, POM_enquiry_like, "value");
	
	ifail = POM_enquiry_set_where_expr ("find_stn_objs",pSelectExprs[0]);
	ifail = POM_enquiry_add_order_attr ("find_stn_objs","T5_STNHeader", "item_id", POM_enquiry_desc_order);
	
	ifail = POM_enquiry_execute("find_stn_objs", &n_stns ,&n_cols, &values );
	ifail = POM_enquiry_delete("find_stn_objs");
	
	printf("\nSTN: No of STNs==>%d\n",n_stns);fflush(stdout);
	
	char* latestSTNNo = NULL;
	tag_t LatestStnTag = NULLTAG;
	if(n_stns > 0)
	{
		
		LatestStnTag  = *(tag_t*)(values[0][0]);		
		
		if(LatestStnTag != NULLTAG)
		{
			latestSTNNo = NULL;
			ifail = AOM_ask_value_string(LatestStnTag,"item_id",&latestSTNNo);
			
			printf("\nSTN: Latest STN No:[%s]\n",latestSTNNo);fflush(stdout);
			
		}
	}
	
	char* nextSTNNo = NULL;
	char* latestSTNNoDup = NULL;
	char* curStnNo = NULL;
	long int curStnNoInt = 0;
	long int nextStnNoInt = 0;
	
	tc_strcpy(nextSTNNo,"");
	nextSTNNo = (char*)MEM_alloc(50*sizeof(char*));
	if(latestSTNNo!=NULL)
	{
		char* nextStnbuf = NULL;
		char* nextStnStr = (char*)MEM_alloc(30*sizeof(char));
		int len = 0;
		nextStnbuf = (char*)MEM_alloc(30*sizeof(char));
		latestSTNNoDup = (char*)MEM_alloc(50*sizeof(char*));
		
		
		tc_strcpy(latestSTNNoDup,"");
		tc_strcat(latestSTNNoDup,latestSTNNo);
		
		printf("\nSTN: Latest STN No Dup:[%s]\n",latestSTNNoDup);fflush(stdout);
		
		curStnNo = t5STN_SubString(latestSTNNoDup,3,5);
		
		printf("\nSTN: Curr STN No:[%s]\n",curStnNo);fflush(stdout);
		curStnNoInt = atoi(curStnNo);
		printf("\nSTN: Curr STN No Int:[%d]\n",curStnNoInt);fflush(stdout);
		
		int ctrlInfoInt = 0;
		ctrlInfoInt = atoi(info1);
		
		if(curStnNoInt < ctrlInfoInt)
		{
			nextStnNoInt = ctrlInfoInt + 1;
		}
		else
		{
			nextStnNoInt = curStnNoInt + 1;
		}
		
		
		
		
		
		
		sprintf(nextStnbuf,"%d",nextStnNoInt);
		
		printf("\nSTN: Next STN No Buf:[%s], length = [%d]\n",nextStnbuf,tc_strlen(nextStnbuf));fflush(stdout);
		
		
		len = tc_strlen(nextStnbuf);
		
		
		if(len == 1)
		{
			tc_strcpy(nextStnStr,"");
			tc_strcat(nextStnStr,"0000");
			tc_strcat(nextStnStr,nextStnbuf);
		}
		else if(len == 2)
		{
			tc_strcpy(nextStnStr,"");
			tc_strcat(nextStnStr,"000");
			tc_strcat(nextStnStr,nextStnbuf);
		}
		else if(len == 3)
		{
			tc_strcpy(nextStnStr,"");
			tc_strcat(nextStnStr,"00");
			tc_strcat(nextStnStr,nextStnbuf);
		}
		else if(len == 4)
		{
			tc_strcpy(nextStnStr,"");
			tc_strcat(nextStnStr,"0");
			tc_strcat(nextStnStr,nextStnbuf);
		}
		else
		{
			tc_strcpy(nextStnStr,"");
			tc_strcat(nextStnStr,nextStnbuf);
		}
		
		
		printf("\nSTN: Next STN No:[%s]\n",nextStnStr);fflush(stdout);
		
		tc_strcat(nextSTNNo,"STN");
		tc_strcat(nextSTNNo,nextStnStr);
		
		MEM_free(nextStnbuf);
		MEM_free(nextStnStr);
		
	}
	
	
	
	
	*nextvalue = nextSTNNo;
	
	return ITK_ok;
}


int tm_updSTNMasterFormName(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;
	
	printf("\nSTN:Inside tm_updSTNMasterFormName");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\nSTN:Item ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;
	if(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
	if(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;

			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\nSTN: Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\nSTN: secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_STNHeaderMaster")==0)
			{
				printf("\nSTN:Inside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				//ITKCALL(AOM_save(secondary));
				ITKCALL(AOM_save_with_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,FALSE));
			}
		}
	}
	return 0;
}

int tm_updSTNRevMasterFormName(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nSTN:Inside tm_updSTNRevMasterFormName ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\nSTN: dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;

			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\nSTN: mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\nSTN: Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\nSTN: secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_STNHeaderRevisionMaster")==0)
			{
				printf("\nSTN:Inside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				//ITKCALL(AOM_save(secondary));
				ITKCALL(AOM_save_with_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,FALSE));
			}
		}
	}
	return 0;
}


int isLiveForSTNPartAssign(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for control object for isLiveForSTNPartAssign....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "STNParticip";
	qry_values[1] = "STNParticip";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN:STNParticip:Control objects STNParticip: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{			
			printf("\nSTN:STNParticip: Live for STNParticipant assignment\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}


int isLiveForSTNReleaseStamp(tag_t *contrlTag, logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for control object for isLiveForSTNReleaseStamp....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "STNRelStamp";
	qry_values[1] = "STNRelStamp";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSTN:STNRelStamp:Control objects STNRelStamp: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{			
			printf("\nSTN:STNRelStamp: Live for STNRelStamp assignment\n");fflush(stdout);
			*result = TRUE;			
			*contrlTag = cntrlObj;			
		}
		
	}
	
	return ITK_ok;
}

int tm_assignSTNParticipants(tag_t STNRevisionTag)
{
	int ifail = ITK_ok;
	char* ErcGroupNameC = NULL;
	char* info1 = NULL;
	char* info2 = NULL;	
	char* Arai_DesignerC = NULL;
	tag_t ErcGroup_tagC = NULLTAG;
	tag_t DML_PrincipleEng_tagC = NULLTAG;
	int No_PrincipleEngC = 0;
	tag_t * PrincipleEngineeringC = NULL;	
	
	ErcGroupNameC = (char *) MEM_alloc( 100 * sizeof(char) );
	/* Get the correct Group - STNGrp */
	tag_t cntrlTag = NULLTAG;
	ifail = getSTNGroupControlTag(&cntrlTag);
	if(cntrlTag == NULLTAG)
	{
		tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
	}
	else
	{
		
		ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo1", &info1);
		ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
		if(tc_strlen(info2) > 0)
		{
			tc_strcpy(ErcGroupNameC,info2);
		}
		else
		{
			tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
		}
		
	}
	Arai_DesignerC = (char	*)MEM_alloc(100);
	tc_strcpy(Arai_DesignerC,"CertificationGrp");
	
	printf("\nSTN:tm_assignSTNParticipants --Arai CertificationGrp group name to be set  -(%s)  \n",Arai_DesignerC);fflush(stdout);
	
	if(SA_find_group(ErcGroupNameC, &ErcGroup_tagC)!=ITK_ok)PrintErrorStack();
	if(SA_find_role2(Arai_DesignerC,&DML_PrincipleEng_tagC)!=ITK_ok)PrintErrorStack();
	
	MEM_free(ErcGroupNameC);
	MEM_free(Arai_DesignerC);		
	
	if(ErcGroup_tagC!=NULLTAG && DML_PrincipleEng_tagC!=NULLTAG)
	{
		//printf("\nSTN:  Now at  !\n");fflush(stdout);
		if(SA_find_groupmember_by_role(DML_PrincipleEng_tagC,ErcGroup_tagC,&No_PrincipleEngC,&PrincipleEngineeringC)!=ITK_ok)PrintErrorStack();
		//printf("\nSTN: Arai CertificationGrp group name_Func:>>  :[%d]\n",No_PrincipleEngC);fflush(stdout);
	}
	

	
	if(No_PrincipleEngC>0)
	{
		int ck =0;
		tag_t PrincipleEngineer_TypeC = NULLTAG;
		tag_t PrincipleEngineer_PartyC = NULLTAG;
		
		for(ck=0;ck<No_PrincipleEngC;ck++)
		{
			//printf("\nSTN: Inside for loop - Arai CertificationGrp group name  no: %d \n",ck);fflush(stdout);
			if(EPM_get_participanttype ("T5_CertificationGrp",&PrincipleEngineer_TypeC)!=ITK_ok)PrintErrorStack();
			if(EPM_create_participant(PrincipleEngineeringC[ck],PrincipleEngineer_TypeC,&PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
			
			ifail = AOM_lock(STNRevisionTag);
			//if(ITEM_rev_add_participant(STNRevisionTag,PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
			ifail = PARTICIPANT_add_participant(STNRevisionTag,TRUE,PrincipleEngineer_PartyC);
			//ifail = AOM_save(STNRevisionTag);
			ifail = AOM_save_without_extensions(STNRevisionTag);
			ifail = AOM_unlock(STNRevisionTag);				
		}
		//printf("\nSTN: In the end of for loop Arai CertificationGrp group \n");fflush(stdout);
		ifail = AOM_refresh (STNRevisionTag,FALSE);
	}
	
	//Assigning participants for design document
	
	tag_t* deptRevTags = NULL;
	int cnt =0;
	int i = 0;
	ifail = AOM_ask_value_tags(STNRevisionTag,"T5_StnHasDeptDoc",&cnt,&deptRevTags);
	printf("\nSTN: No of dept doc attached to STN Header: [%d]\n",cnt);fflush(stdout);
	
	for(i = 0; i< cnt ; i++)
	{
		tag_t DeptDocRevTag = NULLTAG;
		DeptDocRevTag = deptRevTags[i];
		
		if(DeptDocRevTag != NULLTAG)
		{
			char* DeptDocRevS = NULL;
			char* ErcGroupName = NULL;
			char* Arai_Designer = NULL;
			tag_t ErcGroup_tag = NULLTAG;
			tag_t DML_PrincipleEng_tag = NULLTAG;
			
			int No_PrincipleEng = 0;
			tag_t * PrincipleEngineering = NULL;
			
			char* ErcGroupNameM = NULL;
			char* Arai_DesignerM = NULL;
			tag_t ErcGroup_tagM = NULLTAG;
			tag_t DML_PrincipleEng_tagM = NULLTAG;
			
			int No_PrincipleEngM = 0;
			tag_t * PrincipleEngineeringM = NULL;
			
			char* item_id_dup = NULL;
			ifail = AOM_ask_value_string(DeptDocRevTag, "t5_Department", &item_id_dup);
			
			printf("\nSTN: Department(%s)  \n",item_id_dup);fflush(stdout);
			

			
			
			/***********Set the Designer to the Department Document *********************/
			
			ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );							
			//tc_strcpy(ErcGroupName,"STN_Participants_Group");
			
			if(cntrlTag == NULLTAG)
			{
				//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
				tc_strcpy(ErcGroupName,"STN_Participants_Group");
			}
			else
			{
				
				ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
				if(tc_strlen(info2) > 0)
				{
					tc_strcpy(ErcGroupName,info2);
				}
				else
				{
					tc_strcpy(ErcGroupName,"STN_Participants_Group");
				}
									
			}
			
			Arai_Designer = (char*)MEM_alloc(100);
			tc_strcpy(Arai_Designer,item_id_dup);
			tc_strcat(Arai_Designer,"AraiDesigner");
			
			printf("\nSTN: Arai designer group name to be set  -(%s)  \n",Arai_Designer);fflush(stdout);
			
			if(SA_find_group(ErcGroupName, &ErcGroup_tag)!=ITK_ok)PrintErrorStack();
			if(SA_find_role2(Arai_Designer,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();
			
			MEM_free(ErcGroupName);
			MEM_free(Arai_Designer);
			
			if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
			{
				//printf("\nSTN:  Now at 5555 !\n");fflush(stdout);
				if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
				//printf("\nSTN: Arai designer group name_Func:>>  :[%d]\n",No_PrincipleEng);fflush(stdout);								
			}
			
			if(No_PrincipleEng>0)
			{
				int ik =0;
				tag_t PrincipleEngineer_Type = NULLTAG;
				tag_t PrincipleEngineer_Party = NULLTAG;
				
				for(ik=0;ik<No_PrincipleEng;ik++)
				{
					//printf("\nSTN: Inside for loop - Arai designer group name  no: %d \n",ik);fflush(stdout);
					if(EPM_get_participanttype ("T5_AraiDesignerGrp",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
					ifail = AOM_lock(DeptDocRevTag);			
					//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
					ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_Party);
					ifail = AOM_save_without_extensions(DeptDocRevTag);
					ifail = AOM_unlock(DeptDocRevTag);									
				}
				//printf("\nSTN: In the end of for loop Arai designer group \n");fflush(stdout);
				ifail = AOM_refresh (DeptDocRevTag,FALSE);								
			}
			
			//printf("\nSTN: outide arai designer grp condition true \n");fflush(stdout);
			
			
			/************Set Manager to Department Doc ************************************/
			
			ErcGroupNameM = (char *)MEM_alloc( 100 * sizeof(char) );
			//tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
			
			if(cntrlTag == NULLTAG)
			{
				//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
				tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
			}
			else
			{
				
				ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
				if(tc_strlen(info2) > 0)
				{
					tc_strcpy(ErcGroupNameM,info2);
				}
				else
				{
					tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
				}								
				
			}
			
			Arai_DesignerM = (char	*)MEM_alloc(100);
			tc_strcpy(Arai_DesignerM,item_id_dup);
			tc_strcat(Arai_DesignerM,"AraiManager");
			
			//printf("\nSTN: Arai Manager group name to be set  -(%s)  \n",Arai_DesignerM);fflush(stdout);
			
			if(SA_find_group(ErcGroupNameM, &ErcGroup_tagM)!=ITK_ok)PrintErrorStack();
			if(SA_find_role2(Arai_DesignerM,&DML_PrincipleEng_tagM)!=ITK_ok)PrintErrorStack();
			
			MEM_free(ErcGroupNameM);
			MEM_free(Arai_DesignerM);
			
			if(ErcGroup_tagM!=NULLTAG && DML_PrincipleEng_tagM!=NULLTAG)
			{
				//printf("\nSTN:  Now at 5555-M !\n");fflush(stdout);
				if(SA_find_groupmember_by_role(DML_PrincipleEng_tagM,ErcGroup_tagM,&No_PrincipleEngM,&PrincipleEngineeringM)!=ITK_ok)PrintErrorStack();
				//printf("\nSTN: Arai Manager group name_Func:>>  :[%d]\n",No_PrincipleEngM);fflush(stdout);
			}
			
			
			if(No_PrincipleEngM>0)
			{
				int mk = 0;
				tag_t PrincipleEngineer_TypeM = NULLTAG;
				tag_t PrincipleEngineer_PartyM = NULLTAG;
				
				for(mk=0;mk<No_PrincipleEngM;mk++)
				{
					//printf("\nSTN: Inside for loop - Arai Manager group name  no: %d \n",mk);fflush(stdout);
					if(EPM_get_participanttype ("T5_AraiManagerGrp",&PrincipleEngineer_TypeM)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(PrincipleEngineeringM[mk],PrincipleEngineer_TypeM,&PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
					ifail = AOM_lock(DeptDocRevTag);			
					//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
					ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_PartyM);					
					ifail = AOM_save_without_extensions(DeptDocRevTag);
					ifail = AOM_unlock(DeptDocRevTag);									
				}
				//printf("\nSTN: In the end of for loop Arai Manager group \n");fflush(stdout);
				ifail = AOM_refresh (DeptDocRevTag,FALSE);								
				
			}
			
			printf("\nSTN:STN Participant assigned of Dept Doc - complete \n"); fflush(stdout);
			
		}
								
				
		
	}
	
	
	printf("\nSTN: tm_assignSTNParticipants - Finished...\n");fflush(stdout);
	return ifail;
}


int tm_assignAraiDesignerToSTNDepartment(tag_t DeptDocRevTag)
{
	int ifail = ITK_ok;
	
	if(DeptDocRevTag != NULLTAG)
	{
		char* DeptDocRevS = NULL;
		char* ErcGroupName = NULL;
		char* Arai_Designer = NULL;
		tag_t ErcGroup_tag = NULLTAG;
		tag_t DML_PrincipleEng_tag = NULLTAG;
		
		int No_PrincipleEng = 0;
		tag_t * PrincipleEngineering = NULL;
		
		char* ErcGroupNameM = NULL;
		char* Arai_DesignerM = NULL;
		tag_t ErcGroup_tagM = NULLTAG;
		tag_t DML_PrincipleEng_tagM = NULLTAG;
		
		int No_PrincipleEngM = 0;
		tag_t * PrincipleEngineeringM = NULL;
		
		char* item_id_dup = NULL;
		ifail = AOM_ask_value_string(DeptDocRevTag, "t5_Department", &item_id_dup);
		
		printf("\nSTN: Department(%s)  \n",item_id_dup);fflush(stdout);
		

		
		
		/***********Set the Designer to the Department Document *********************/
		
		ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );							
		//tc_strcpy(ErcGroupName,"DML_Participants_Group");
		
		tag_t cntrlTag = NULLTAG;
		char* info2 = NULL;
		ifail = getSTNGroupControlTag(&cntrlTag);
		
		if(cntrlTag == NULLTAG)
		{
			//tc_strcpy(ErcGroupNameC,"DML_Participants_Group");
			tc_strcpy(ErcGroupName,"DML_Participants_Group");
		}
		else
		{
			
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strlen(info2) > 0)
			{
				tc_strcpy(ErcGroupName,info2);
			}
			else
			{
				tc_strcpy(ErcGroupName,"STN_Participants_Group");
			}
								
		}
		
		Arai_Designer = (char*)MEM_alloc(100);
		tc_strcpy(Arai_Designer,item_id_dup);
		tc_strcat(Arai_Designer,"AraiDesigner");
		
		printf("\nSTN: Arai designer group name to be set  -(%s)  \n",Arai_Designer);fflush(stdout);
		
		if(SA_find_group(ErcGroupName, &ErcGroup_tag)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(Arai_Designer,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();
		
		MEM_free(ErcGroupName);
		MEM_free(Arai_Designer);
		
		if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
		{
			//printf("\nSTN:  Now at 5555 !\n");fflush(stdout);
			if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
			//printf("\nSTN: Arai designer group name_Func:>>  :[%d]\n",No_PrincipleEng);fflush(stdout);								
		}
		
		if(No_PrincipleEng>0)
		{
			int ik =0;
			tag_t PrincipleEngineer_Type = NULLTAG;
			tag_t PrincipleEngineer_Party = NULLTAG;
			
			for(ik=0;ik<No_PrincipleEng;ik++)
			{
				//printf("\nSTN: Inside for loop - Arai designer group name  no: %d \n",ik);fflush(stdout);
				if(EPM_get_participanttype ("T5_AraiDesignerGrp",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
				ifail = AOM_lock(DeptDocRevTag);			
				//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
				ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_Party);
				ifail = AOM_save_without_extensions(DeptDocRevTag);
				ifail = AOM_unlock(DeptDocRevTag);									
			}
			//printf("\nSTN: In the end of for loop Arai designer group \n");fflush(stdout);
			ifail = AOM_refresh (DeptDocRevTag,FALSE);								
		}
		
		//printf("\nSTN: outide arai designer grp condition true \n");fflush(stdout);
		
		
		/************Set Manager to Department Doc ************************************/
		
		ErcGroupNameM = (char *)MEM_alloc( 100 * sizeof(char) );
		//tc_strcpy(ErcGroupNameM,"DML_Participants_Group");
		
		if(cntrlTag == NULLTAG)
		{
			//tc_strcpy(ErcGroupNameC,"DML_Participants_Group");
			tc_strcpy(ErcGroupNameM,"DML_Participants_Group");
		}
		else
		{
			
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strlen(info2) > 0)
			{
				tc_strcpy(ErcGroupNameM,info2);
			}
			else
			{
				tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
			}								
			
		}
		
		Arai_DesignerM = (char	*)MEM_alloc(100);
		tc_strcpy(Arai_DesignerM,item_id_dup);
		tc_strcat(Arai_DesignerM,"AraiManager");
		
		//printf("\nSTN: Arai Manager group name to be set  -(%s)  \n",Arai_DesignerM);fflush(stdout);
		
		if(SA_find_group(ErcGroupNameM, &ErcGroup_tagM)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(Arai_DesignerM,&DML_PrincipleEng_tagM)!=ITK_ok)PrintErrorStack();
		
		MEM_free(ErcGroupNameM);
		MEM_free(Arai_DesignerM);
		
		if(ErcGroup_tagM!=NULLTAG && DML_PrincipleEng_tagM!=NULLTAG)
		{
			//printf("\nSTN:  Now at 5555-M !\n");fflush(stdout);
			if(SA_find_groupmember_by_role(DML_PrincipleEng_tagM,ErcGroup_tagM,&No_PrincipleEngM,&PrincipleEngineeringM)!=ITK_ok)PrintErrorStack();
			//printf("\nSTN: Arai Manager group name_Func:>>  :[%d]\n",No_PrincipleEngM);fflush(stdout);
		}
		
		
		if(No_PrincipleEngM>0)
		{
			int mk = 0;
			tag_t PrincipleEngineer_TypeM = NULLTAG;
			tag_t PrincipleEngineer_PartyM = NULLTAG;
			
			for(mk=0;mk<No_PrincipleEngM;mk++)
			{
				//printf("\nSTN: Inside for loop - Arai Manager group name  no: %d \n",mk);fflush(stdout);
				if(EPM_get_participanttype ("T5_AraiManagerGrp",&PrincipleEngineer_TypeM)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(PrincipleEngineeringM[mk],PrincipleEngineer_TypeM,&PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
				ifail = AOM_lock(DeptDocRevTag);			
				//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
				ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_PartyM);
				ifail = AOM_save_without_extensions(DeptDocRevTag);
				ifail = AOM_unlock(DeptDocRevTag);									
			}
			//printf("\nSTN: In the end of for loop Arai Manager group \n");fflush(stdout);
			ifail = AOM_refresh (DeptDocRevTag,FALSE);								
			
		}
		
		printf("\nSTN:STN Participant assigned of Dept Doc - complete \n"); fflush(stdout);
		
	}
							
		
	
	return ITK_ok;
	
}

int t5STN_IsallowedToDeleteRel(logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for STN doc delete relation access\n");fflush(stdout);
	
	char* userName = NULL;
	tag_t userTag = NULLTAG;
	char* groupName = NULL;
	tag_t groupTag = NULLTAG;
	*result = FALSE;
	
	POM_get_user(&userName,&userTag);	
	POM_ask_group(&groupName, &groupTag);
	
	printf("\nSTN:Session user:[%s], Group Name:[%s]\n", userName,groupName);fflush(stdout);
	if(groupTag != NULLTAG)
	{
		 if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0)
		 {
			 
			 printf("\n\n\tSTN: t5STN_IsallowedToDeleteRel 00*********************PLM CertificationGrp, dba and support user having access*********************\n");fflush(stdout);
			 *result = TRUE;

			
		 }
		 else
		 {
			
			 printf("\n\n\tSTN: 111*********************t5STN_IsallowedToDeleteRel You Don't Have access to delete STN doc relation *********************\n");fflush(stdout);
			 *result = FALSE;
			 
		 }
	}
	else
	{
		printf("\n\n\tSTN: 22 t5STN_IsallowedToDeleteRel *********************Should not have come here . Fatal error*********************\n");fflush(stdout);
		*result = FALSE;
	}	
	
	return ifail;
	
}

int t5STN_IsallowedToDeleteClauseRel(logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for STN Clause delete relation access\n");fflush(stdout);
	
	char* userName = NULL;
	tag_t userTag = NULLTAG;
	char* groupName = NULL;
	tag_t groupTag = NULLTAG;
	*result = FALSE;
	tag_t roleTag = NULLTAG;
	
	SA_ask_current_role(&roleTag);
	char* roleName = NULL;
	if(roleTag != NULLTAG)
	{
		SA_ask_role_name2(roleTag, &roleName);
	}
	
	POM_get_user(&userName,&userTag);	
	POM_ask_group(&groupName, &groupTag);
	
	printf("\nSTN:Session user:[%s], Group Name:[%s], Role Name:[%s]\n", userName,groupName,roleName);fflush(stdout);
	if(groupTag != NULLTAG)
	{
		 if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0 || tc_strcmp(roleName,"CertificationGrp")==0 )
		 {
			 
			 printf("\n\n\tSTN: t5STN_IsallowedToDeleteClauseRel 00*********************PLM dba,CertificationGrp and support user having access*********************\n");fflush(stdout);
			 *result = TRUE;

			
		 }
		 else
		 {
			
			 printf("\n\n\tSTN: 111*********************t5STN_IsallowedToDeleteClauseRel You Don't Have access to delete STN doc relation *********************\n");fflush(stdout);
			 *result = FALSE;
			 
		 }
	}
	else
	{
		printf("\n\n\tSTN: 22 t5STN_IsallowedToDeleteRel *********************Should not have come here . Fatal error*********************\n");fflush(stdout);
		*result = FALSE;
	}	
	
	return ifail;
	
}


int isallowedToReviseSTN(logical *result)
{
	int ifail = ITK_ok;
	printf("\nSTN:Check for STN doc delete relation access\n");fflush(stdout);
	
	char* userName = NULL;
	tag_t userTag = NULLTAG;
	char* groupName = NULL;
	tag_t groupTag = NULLTAG;
	*result = FALSE;
	
	POM_get_user(&userName,&userTag);	
	POM_ask_group(&groupName, &groupTag);
	
	printf("\nSTN:Session user:[%s], Group Name:[%s]\n", userName,groupName);fflush(stdout);
	if(groupTag != NULLTAG)
	{
		 if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0)
		 {
			 
			 printf("\n\n\tSTN: isallowedToReviseSTN 00*********************PLM CertificationGrp, dba and support user having access*********************\n");fflush(stdout);
			 *result = TRUE;

			
		 }
		 else
		 {
			
			 printf("\n\n\tSTN: 111*********************isallowedToReviseSTN You Don't Have access to delete STN doc relation *********************\n");fflush(stdout);
			 *result = FALSE;
			 
		 }
	}
	else
	{
		printf("\n\n\tSTN: 22 isallowedToReviseSTN *********************Should not have come here . Fatal error*********************\n");fflush(stdout);
		*result = FALSE;
	}	
	
	return ifail;
	
}


int getSTNDeptDocObj(char* partnumber,tag_t *partObj)
{
	int ifail = ITK_ok;
	
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "Item ID";
	qry_entries[1] = "Type";
	
	qry_values[0] = partnumber;
	qry_values[1] = "T5_DeptDoc";
	
	
	if(QRY_find2("Item...", &query));
	if(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	printf("\nSTN:getSTNDeptDocObj: count==>%d", count);fflush(stdout);

	if(count>0)
	{
		*partObj = itemObjs[0];
		
	}
	
	return ifail;	

}


/************************ Action Handler *****************************/



int  tm_AssignAraiDesignerFn(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULLTAG;
	int targetobjects_count = 0;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	logical isLive = FALSE;
	ifail = isLiveForSTNPartAssign(&cntrlObj,&liveFlag);
	
	if(cntrlObj != NULLTAG)
	{
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;



		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));



		printf("\nSTN: STNParticip-STNParticip Control object information:\nSTN:t5_Userinfo1:[%s]\nSTN:t5_Userinfo2:[%s]\nSTN:t5_Userinfo3:[%s]\nSTN:t5_Userinfo4:[%s]\nSTN:t5_Userinfo5:[%s]\nSTN:t5_Userinfo6:[%s]\nSTN:t5_Userinfo7:[%s]\nSTN:t5_Userinfo8:[%s]\nSTN:t5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
		
		if(tc_strstr(userInfo3,",DEPTDOCASSIGN,")!= NULL)
		{
			printf("\nSTN: Live..\n");fflush(stdout);
			isLive = TRUE;
		}
		
		
		
	}
	
	if(!isLive)
	{
		printf("\nSTN: Not Live STN Dept Doc Assign...\n");fflush(stdout);
		return ITK_ok;
	}
	
	printf("\nSTN:tm_AssignAraiDesignerFn function statrs....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSTN:SAN:tm_AssignAraiDesignerFn:username :%s....\n",username);fflush(stdout);
	
	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSTN:SAN:tm_AssignAraiDesignerFn:Root task found");fflush(stdout);
	
	if(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSTN:SAN:tm_AssignAraiDesignerFn:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	
	if(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSTN:SAN:tm_AssignAraiDesignerFn:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	

	if(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	
	printf("\nSTN:SAN:tm_AssignAraiDesignerFn:targetobjects_count:%d\n",targetobjects_count);fflush(stdout);
	
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		//char  	type_name[TCTYPE_name_size_c+1];
		char* type_name = NULL;
		
		for(i=0;i<targetobjects_count;i++)
		{
			
			ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
			if(objectTypeTag != NULLTAG) {
				ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
			}
			printf("\nSTN: type_name ==> %s\n", type_name);fflush(stdout);
			
			if(tc_strcmp(type_name,"T5_DeptDocRevision")==0)
			{
				tag_t deptTag = NULLTAG;
				deptTag = targetobjects[i];
				
				
				
				
				ifail = tm_assignAraiDesignerToSTNDepartment(deptTag);
				
			}
			
			
		}
	}
	

	
	return ifail;
}



int  tm_AssignSTNParticipantsFn(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	logical isLive = FALSE;
	ifail = isLiveForSTNPartAssign(&cntrlObj,&liveFlag);
	
	if(cntrlObj != NULLTAG)
	{
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;



		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));



		printf("\nSTN: STNParticip-STNParticip Control object information:\nSTN:t5_Userinfo1:[%s]\nSTN:t5_Userinfo2:[%s]\nSTN:t5_Userinfo3:[%s]\nSTN:t5_Userinfo4:[%s]\nSTN:t5_Userinfo5:[%s]\nSTN:t5_Userinfo6:[%s]\nSTN:t5_Userinfo7:[%s]\nSTN:t5_Userinfo8:[%s]\nSTN:t5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
		
		if(tc_strstr(userInfo3,",STNHEADERASSIGN,")!= NULL)
		{
			printf("\nSTN: Live..\n");fflush(stdout);
			isLive = TRUE;
		}
		
		
		
	}
	
	if(!isLive)
	{
		printf("\nSTN: Not Live STN Participant Assign...\n");fflush(stdout);
		return ITK_ok;
	}
	
	printf("\nSTN:tm_AssignSTNParticipantsFn function statrs....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSTN:SAN:tm_AssignSTNParticipantsFn:username :%s....\n",username);fflush(stdout);
	
	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSTN:SAN:tm_AssignSTNParticipantsFn:Root task found");fflush(stdout);
	
	if(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSTN:SAN:tm_AssignSTNParticipantsFn:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	
	if(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSTN:SAN:tm_AssignSTNParticipantsFn:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	

	if(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	
	printf("\nSTN:SAN:tm_AssignSTNParticipantsFn:targetobjects_count:%d\n",targetobjects_count);fflush(stdout);
	
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		//char  	type_name[TCTYPE_name_size_c+1];
		char* type_name = NULL;
		
		for(i=0;i<targetobjects_count;i++)
		{
			
			ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
			if(objectTypeTag != NULLTAG) {
				ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
			}
			printf("\nSTN: type_name ==> %s\n", type_name);fflush(stdout);
			
			if(tc_strcmp(type_name,"T5_STNHeaderRevision")==0)
			{
				tag_t stnRevTag = NULLTAG;
				stnRevTag = targetobjects[i];
				
				ifail = tm_assignSTNParticipants(stnRevTag);
				
			}
			
			
		}
	}
	

	
	return ifail;
}


/**********************Rule Handler *****************************/
EPM_decision_t tm_IsValdSTNHeaderObject( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_nogo;
	int ifail = ITK_ok;
	int arg_cnt = 0;
	int indx = 0;
	char *value = NULL;
	char *flag  = NULL;
	char* object_class = NULL;
	tag_t	rootTask = NULLTAG;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	
	const char * prog_name ="tm_IsValdSTNHeaderObject";	
	if(ifail == ITK_ok)
	{
		arg_cnt = TC_number_of_arguments(msg.arguments);
	}
	
	if((arg_cnt > 1) && (ifail == ITK_ok) )
	{
		printf("\nSTN:Wrong number of arguments..");fflush(stdout);
		ifail=T5_WorkFlowSTNHandlerErr;
		EMH_store_error_s1(EMH_severity_error,ifail,"Wrong number of arguments");
		decision = EPM_nogo;
		return decision;
	}
	
	for(indx = 0; indx < arg_cnt && ifail == ITK_ok; indx++ )
	{
		ifail = ITK_ask_argument_named_value( TC_next_argument(msg.arguments), &flag, &value );
		if(ifail == ITK_ok)
		{
			if(tc_strcasecmp(flag, "object_class") == 0)
			{
				if( value != NULL )
                {
                    object_class = (char*) MEM_alloc(( strlen(value) + 1) * sizeof(char));
                    tc_strcpy(object_class,value);
                }
			}
			else
			{
				printf("\nSTN:Invalid argument..");fflush(stdout);
				ifail=T5_WorkFlowSTNHandlerErr;
				EMH_store_error_s1(EMH_severity_error,ifail,"Invalid argument..");
				decision = EPM_nogo;
				return decision;
			}
			if( value != NULL )
            {
                MEM_free(value);
            }
            
            if( flag != NULL )
            {
                MEM_free(flag);
            }
		}
		ifail = EPM_ask_root_task(msg.task,&rootTask);

		ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects);
		
		if(targetobjects_count > 0)
		{
			int i =0;
			tag_t objectTypeTag = NULLTAG;
			char  	*type_name = NULL;
			for(i=0;i<targetobjects_count;i++)
			{
				ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
				ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
				printf("\nSTN:type_name ==> %s\n", type_name);fflush(stdout);
				
				if((tc_strcmp(type_name,object_class)!=0))
				{
					printf("\nSTN:This [%s] is not valid object. Not allowed to be submit.", type_name);fflush(stdout);
					char* buff = NULL;
					ifail=T5_WorkFlowSTNHandlerErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					sprintf(buff, "This[%s] is not valid object. Not allowed to be submit.", type_name);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;
				}
				else
				{
					decision = EPM_go;
				}
			}
		}
		
	}
	
	
	return decision;
}


int t5STN_AddERCReleasedStatusToMyTag(tag_t myTag)
{
	int ifail = ITK_ok;
	tag_t   release_status =NULLTAG;
	char* ReleaseStatus = NULL;
	logical retain_released_date = TRUE;
	
	ifail = RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status);
	ifail =  AOM_ask_name(release_status, &ReleaseStatus);

	if((tc_strcmp(ReleaseStatus,"ERC Released")==0)||tc_strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		ifail = RELSTAT_add_release_status(release_status,1,&myTag,retain_released_date); 
	}	
	
	return ifail;
}

int tm_releaseStampSTN(tag_t stnHeaderRevTag)
{
	int ifail = ITK_ok;
	printf("\nSTN:tm_releaseStampSTN-Start\n");fflush(stdout);
	
	if(stnHeaderRevTag!=NULLTAG)
	{
		logical chkOut = FALSE;
		char* stnName = NULL;
		ifail = AOM_ask_value_string(stnHeaderRevTag,"object_string",&stnName);
		printf("\nSTN: STN no==>%s\n",stnName);fflush(stdout);
		ifail = t5STN_AddERCReleasedStatusToMyTag(stnHeaderRevTag);
		
		//Get Department Doc
		
		//Get the Department Doc
		tag_t stnToDeptRelType = NULLTAG;
		
		ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
		
		if(stnToDeptRelType != NULLTAG)
		{
			int deptDocRevCnt = 0;
			tag_t *deptDocRevTags = NULL;
			int i = 0;
			ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
			for(i=0;i<deptDocRevCnt;i++)
			{
				tag_t deptDocObj = NULLTAG;		
			
				deptDocObj = deptDocRevTags[i];
				
				//Get Clause Revisions.
				tag_t deptToClauseRelType = NULLTAG;
				ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
				
				if(deptToClauseRelType != NULLTAG)
				{
					tag_t* clsRevTags = NULL;
					int clsRevTagCnt = 0;
					ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
						
					printf("\n Clause Rev Tag count: [%d]\n", clsRevTagCnt);fflush(stdout);
					ifail = t5STN_AddERCReleasedStatusToMyTag(deptDocObj);
					int j = 0;
					for(j=0; j<clsRevTagCnt;j++)
					{
						tag_t clauseObj = NULLTAG;
						char* clauseNoStr = "";
						clauseObj = clsRevTags[j];
						ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
						ifail = t5STN_AddERCReleasedStatusToMyTag(clauseObj);
					}
					
				}
			}
		}
		
		
		
		
		
	}
	
	
	printf("\nSTN:tm_releaseStampSTN-Finish\n");fflush(stdout);
	return ITK_ok;
}


int  tm_stnReleaseStampFn(EPM_action_message_t  msg)
{
	int ifail = ITK_ok;
	char*	username				=NULL;
	tag_t	user_tag				=NULLTAG;
	tag_t	rootTask = NULLTAG;
	char* currentTaskName = NULL;
	char* parentTaskName = NULL;
	tag_t *targetobjects = NULL;
	int targetobjects_count = 0;
	
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = FALSE;
	logical isLive = FALSE;
	ifail = isLiveForSTNReleaseStamp(&cntrlObj,&liveFlag);
	
	if(cntrlObj != NULLTAG)
	{
		char* userInfo1	=	NULL;
		char* userInfo2	= 	NULL;
		char* userInfo3	=	NULL;
		char* userInfo4	=	NULL;
		char* userInfo5	=	NULL;
		char* userInfo6	=	NULL;
		char* userInfo7	=	NULL;
		char* userInfo8	=	NULL;
		char* userInfo9	=	NULL;



		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
		if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));



		printf("\nSTN: STNRelStamp-STNRelStamp Control object information:\nSTN:t5_Userinfo1:[%s]\nSTN:t5_Userinfo2:[%s]\nSTN:t5_Userinfo3:[%s]\nSTN:t5_Userinfo4:[%s]\nSTN:t5_Userinfo5:[%s]\nSTN:t5_Userinfo6:[%s]\nSTN:t5_Userinfo7:[%s]\nSTN:t5_Userinfo8:[%s]\nSTN:t5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);
		
		if(tc_strstr(userInfo1,",STNRELSTAMP,")!= NULL)
		{
			printf("\nSTN:RelStamp Live..\n");fflush(stdout);
			isLive = TRUE;
		}
		
		
		
	}
	
	if(!isLive)
	{
		printf("\nSTN: Not Live STN Release Stamp...\n");fflush(stdout);
		return ITK_ok;
	}
	
	printf("\nSTN:tm_stnReleaseStampFn function statrs....\n",username);fflush(stdout);
	POM_get_user(&username,&user_tag);
	printf("\nSTN:SAN:tm_stnReleaseStampFn:username :%s....\n",username);fflush(stdout);
	
	if(EPM_ask_root_task(msg.task,&rootTask));
	printf("\nSTN:SAN:tm_stnReleaseStampFn:Root task found");fflush(stdout);
	
	if(AOM_ask_value_string(msg.task,"object_name",&currentTaskName));
	printf("\nSTN:SAN:tm_stnReleaseStampFn:Current Task:%s\n",currentTaskName);fflush(stdout);
	
	
	if(AOM_ask_value_string(rootTask,"object_name",&parentTaskName));
	printf("\nSTN:SAN:tm_stnReleaseStampFn:Parent Name:%s\n",parentTaskName);fflush(stdout);	
	

	if(EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects))
	
	printf("\nSTN:SAN:tm_stnReleaseStampFn:targetobjects_count:%d\n",targetobjects_count);fflush(stdout);
	
	if(targetobjects_count > 0)
	{
		int i=0;
		tag_t objectTypeTag = NULLTAG;
		//char  	type_name[TCTYPE_name_size_c+1];
		char* type_name = NULL;
		
		for(i=0;i<targetobjects_count;i++)
		{
			
			ifail = TCTYPE_ask_object_type (targetobjects[i], &objectTypeTag);
			if(objectTypeTag != NULLTAG) {
				ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
			}
			printf("\nSTN: type_name ==> %s\n", type_name);fflush(stdout);
			
			if(tc_strcmp(type_name,"T5_STNHeaderRevision")==0)
			{
				tag_t stnRevTag = NULLTAG;
				stnRevTag = targetobjects[i];
				
				ifail = tm_releaseStampSTN(stnRevTag);
				
			}
			
			
		}
	}
	printf("\nSTN:Release stamp completed\n");fflush(stdout);

	return ifail;
}



//Pre action of ITEM_create_msg of T5_STNHeader - check if allowed to create - 1-cre
extern DLLAPI int  Stn_PreValidationCreation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	
	printf("\nSTN: **** Inside the Stn_PreValidationCreation  - pre creation**** \n");fflush(stdout);
	
	logical isAllowed = FALSE;
	
	ifail = isEligibleToCreUpdSTNHeader(&isAllowed);
	
	printf("\nSTN: Is Allowed for creation of STN Header: [%d]\n", isAllowed);fflush(stdout);
	
	if(!isAllowed)
	{
		EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create STN Header. Only CertificationGrp Role can create STN Header. Kindly contact PLM Admin.");
		printf("\n\n\tSTN: Stn_PreValidationCreation 111*********************You Don't Have access to create STN *********************\n");fflush(stdout);
		return ITK_err;
	}
	else
	{
		printf("\nSTN: Allowed for creation of STN Header\n");fflush(stdout);
		
		

		
	}

	
	printf("\nSTN: **** Exit Stn_PreValidationCreation **** \n");fflush(stdout);
	return ifail;
	
}

//Override pre -condition of IMAN_save_msg of T5_STNHeader - check if allowed to create - 2-cre
extern DLLAPI int  Stn_PreValidation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	int isnew   = 0;
	isnew  = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	char* type_name = NULL;
	
	printf("\nSTN: **** Inside the Stn_PreValidation  - pre creation**** \n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\nSTN: Pre- Validation check- Inside the STN Header function check Object type :%s \n", type_name);fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_STNHeader")==0)
	{
		
		logical isAllowed = FALSE;
		
		ifail = isEligibleToCreUpdSTNHeader(&isAllowed);
		
		printf("\nSTN: Is Allowed for creation of STN Header: [%d]\n", isAllowed);fflush(stdout);
		
		if(!isAllowed)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create STN Header. Only CertificationGrp Role can create STN Header. Kindly contact PLM Admin..");
			printf("\n\n\tSTN: Stn_PreValidation 111*********************You Don't Have access to create STN *********************\n");fflush(stdout);
			return ITK_err;
		}
		else
		{
			printf("\nSTN: Allowed for creation of STN Header\n");fflush(stdout);
			
			printf("\nSTN: STN Header Master Object ....\n");fflush(stdout);
			
			
			//Set ID as next id
			//STN number generation
			logical isliveForID = FALSE;
			tag_t cntrlObj = NULLTAG;
			printf("\nSTN: Is STN Header New %d ",isnew);fflush(stdout);
			ifail = isLiveForSTNIDgeneration(&cntrlObj,&isliveForID);
		
			
			if(cntrlObj != NULLTAG && isliveForID && isnew == 1)
			{
				char* userInfo1 = NULL;
				char* newSTNID = NULL;
				
				printf("\nSTN: STN ID Generation Logic .... start ...\n");fflush(stdout);
				//ifail = AOM_set_value_string(objTag, "item_id", "STN03000");
				ifail = AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1);
				printf("\nSTN: userInfo1: [%s] \n",userInfo1);fflush(stdout);
				
				
				char* stnNo = NULL;
				char* stnNoDup = NULL;
				char* curSTNNo = NULL;
				long int curStnNoInt = 0;
				long int ctrlStnNoInt = 0;
				stnNoDup = (char*)MEM_alloc(50*sizeof(char));
				
				
	
				ifail = AOM_ask_value_string(objTag,"item_id",&stnNo);
				printf("\nSTN: Current STN No pre :[%s]\n",stnNo);fflush(stdout);
				
				tc_strcpy(stnNoDup,"");
				tc_strcat(stnNoDup,stnNo);
				
				printf("\nSTN: Current STN No Dup pre:[%s]\n",stnNoDup);fflush(stdout);
				
				curSTNNo = t5STN_SubString(stnNoDup,3,5);
				printf("\nSTN: Current STN No Dup value pre:[%s]\n",curSTNNo);fflush(stdout);
				curStnNoInt = atoi(curSTNNo);
				
				ctrlStnNoInt = atoi(userInfo1);
				printf("\nSTN: Current STN No Dup value Int :[%d]\n Cntrl Info1 int: [%d]",curStnNoInt,ctrlStnNoInt);fflush(stdout);
				
				if(curStnNoInt < ctrlStnNoInt)
				{
				
					//ifail = getNewSTNID(objTag,userInfo1,&newSTNID);
					ifail = getNextSTNNumber(userInfo1,&newSTNID);
					printf("\nSTN: Next STN ID : [%s]\n",newSTNID);fflush(stdout);
					if(newSTNID!=NULL)
					{
						ifail = AOM_set_value_string(objTag, "item_id", newSTNID);
						
						//Update the form object - To do
					}
				}
				else
				{
					printf("\nSTN: curStnNoInt > ctrlStnNoInt . Use default OOTB logic\n");fflush(stdout);
				}
				if(stnNoDup) MEM_free(stnNoDup);
				
	
			}
			else
			{
				printf("\nSTN:Not Live for ID generation or is Not New STN. Use default ootb logic \n");fflush(stdout);
			}
			
		}		
		

	}
	
	printf("\nSTN: **** Exit Stn_PreValidation **** \n");fflush(stdout);
	return ifail;
	
}

/****************STN Revision post create method *************************/
//Post action of ITEM_create_msg of T5_STNHeaderRevision - updating the Master of STNs - 3-cre and 6-cre
extern  DLLAPI int createSTNRevObjectPostFun(METHOD_message_t *m, va_list args)
{
	int ifail = ITK_ok;
	tag_t	stnTag				 = va_arg (args, const tag_t);
	
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char* type_name = NULL;
	printf("\nSTN: In STN Rev Creation post method ************************************\n");fflush(stdout);
	if(TCTYPE_ask_object_type(stnTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_STNHeader")==0)
	{
		tag_t stnRevTag = NULLTAG;
		char* item_id = NULL;
		if(ITEM_ask_latest_rev(stnTag,&stnRevTag));
		
		ifail = AOM_ask_value_string( stnRevTag, "item_id", &item_id);
		
		//ifail = tm_updSTNID(stnTag, item_id);
		
		/*Master Update STN and Revision*/
		ifail = tm_updSTNMasterFormName(stnTag, item_id);//Update MASTER
		ifail = tm_updSTNRevMasterFormName(stnRevTag, item_id);//Update MASTER
		
		if(ifail == ITK_ok)
		{
			printf("\nSTN:Updated Master of STN and Rev successfully\n");fflush(stdout);
		}
		else
		{
			printf("\nSTN: Error!!!- Not Updated Master of STN and Rev \n");fflush(stdout);
		}
		
	}
	
	printf("\nSTN: In STN Rev Creation post method......END*********************************\n");fflush(stdout);
	return ifail;
}


//IMAN_Save post action of STN Header Revision (T5_STNHeaderRevision) - creating Dept Doc and Clauses - 4-cre
int tm_create_stndeptdoc( METHOD_message_t *msg, va_list args )
{
	
	int ifail = ITK_ok;
	int isnew              = 0;
	tag_t STNRevisionTag = va_arg(args, tag_t);
	isnew   = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	char* type_name = NULL;
	
	printf("\nSTN:**** Inside the STN Header Revision Creation Post (tm_create_stndeptdoc) **** \n");fflush(stdout);
	
	printf("\nSTN:Is STN Revision New %d ",isnew);fflush(stdout);
	


	if(TCTYPE_ask_object_type(STNRevisionTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\nSTN:Inside the STN Header Revision function check Object type :%s \n", type_name);fflush(stdout);
	
	if(tc_strcmp(type_name,"T5_STNHeaderRevision")==0 && isnew == 0)
	{
		//tag_t STNRevisionTag = NULLTAG;
		char* StnObjectName = NULL;
		char* Itemname = NULL;
		char* description = NULL;
		char* stnPlant = NULL;
		char **DeptDocname = NULL;
		int num =0;
		char* StnRevName = NULL;
		char* ErcGroupNameC = NULL;
		char* Arai_DesignerC = NULL;
		tag_t ErcGroup_tagC = NULLTAG;
		tag_t DML_PrincipleEng_tagC = NULLTAG;
		int No_PrincipleEngC = 0;
		tag_t * PrincipleEngineeringC = NULL;
		char* info1 = NULL;
		char* info2 = NULL;
		
		printf("\nSTN:Inside the condition as object type is - (%s)\n", type_name);fflush(stdout);
		
		//ifail = ITEM_ask_latest_rev(objTag,&STNRevisionTag);
		
		if(STNRevisionTag == NULLTAG || ifail !=ITK_ok)
		{
			printf("\nSTN:Error!!!!. No STN Rev Tag found. Check with Admin. Exiting......\n");fflush(stdout);
		}
		printf("\nSTN:Now get the attributes on STN Revision \n");fflush(stdout);
		
		ifail = AOM_ask_value_string(STNRevisionTag,"object_name",&StnObjectName);
		ifail = AOM_ask_value_string(STNRevisionTag,"item_id",&Itemname);
		ifail = AOM_ask_value_string(STNRevisionTag,"object_desc",&description);
		ifail = AOM_ask_value_string(STNRevisionTag,"t5_StnArPlant",&stnPlant);
		if(stnPlant == NULL)
		{
			stnPlant="PUNE";
		}
		else
		{
			if(tc_strlen(stnPlant) <=0)
			{
				stnPlant="PUNE";
			}
		}
		printf("\nSTN:stnPlant:[%s]",stnPlant);fflush(stdout);
		ifail = AOM_ask_value_strings(STNRevisionTag,"t5_SelectDeptDoc",&num,&DeptDocname);
		
		
		/********* Set Revision of STN Header to A;1       ****************/
		
		ifail = AOM_lock(STNRevisionTag);
		ifail = AOM_set_value_string(STNRevisionTag,"item_revision_id", "A;1");
		ifail = AOM_set_value_string(STNRevisionTag,"t5_StnArPlant", stnPlant);
		ifail = AOM_save_without_extensions(STNRevisionTag);
		//ifail = AOM_unlock(STNRevisionTag);
		ifail = AOM_refresh(STNRevisionTag, FALSE);
		ifail = AOM_unlock(STNRevisionTag);
		//printf("\nSTN:Now revision of STN header set\n");
		
		
		ifail = AOM_ask_value_string(STNRevisionTag,"item_revision_id",&StnRevName);
		//printf("\nSTN:Revision of STN Header -- %s \n",StnRevName);fflush(stdout);
		
		
		/******************** Set the Certification Grp ***********************/
		
		ErcGroupNameC = (char *) MEM_alloc( 100 * sizeof(char) );
		/* Get the correct Group - STNGrp */
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNGroupControlTag(&cntrlTag);
		if(cntrlTag == NULLTAG)
		{
			tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
		}
		else
		{
			
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo1", &info1);
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strlen(info2) > 0)
			{
				tc_strcpy(ErcGroupNameC,info2);
			}
			else
			{
				tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
			}
			
		}
		
		
		
		Arai_DesignerC = (char	*)MEM_alloc(100);
		tc_strcpy(Arai_DesignerC,"CertificationGrp");
		
		printf("\nSTN:Arai CertificationGrp group name to be set  -(%s)  \n",Arai_DesignerC);fflush(stdout);
		
		if(SA_find_group(ErcGroupNameC, &ErcGroup_tagC)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(Arai_DesignerC,&DML_PrincipleEng_tagC)!=ITK_ok)PrintErrorStack();
		
		MEM_free(ErcGroupNameC);
		MEM_free(Arai_DesignerC);		
		
		if(ErcGroup_tagC!=NULLTAG && DML_PrincipleEng_tagC!=NULLTAG)
		{
			printf("\nSTN:  Now at  !\n");fflush(stdout);
			if(SA_find_groupmember_by_role(DML_PrincipleEng_tagC,ErcGroup_tagC,&No_PrincipleEngC,&PrincipleEngineeringC)!=ITK_ok)PrintErrorStack();
			printf("\nSTN: Arai CertificationGrp group name_Func:>>  :[%d]\n",No_PrincipleEngC);fflush(stdout);
		}
		

		
		if(No_PrincipleEngC>0)
		{
			int ck =0;
			tag_t PrincipleEngineer_TypeC = NULLTAG;
			tag_t PrincipleEngineer_PartyC = NULLTAG;
			
			for(ck=0;ck<No_PrincipleEngC;ck++)
			{
				printf("\nSTN: Inside for loop - Arai CertificationGrp group name  no: %d \n",ck);fflush(stdout);
				if(EPM_get_participanttype ("T5_CertificationGrp",&PrincipleEngineer_TypeC)!=ITK_ok)PrintErrorStack();
				if(EPM_create_participant(PrincipleEngineeringC[ck],PrincipleEngineer_TypeC,&PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
				
				ifail = AOM_lock(STNRevisionTag);
				//if(ITEM_rev_add_participant(STNRevisionTag,PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
				ifail = PARTICIPANT_add_participant(STNRevisionTag,TRUE,PrincipleEngineer_PartyC);
				ifail = AOM_save_without_extensions(STNRevisionTag);
				ifail = AOM_unlock(STNRevisionTag);				
			}
			printf("\nSTN: In the end of for loop Arai CertificationGrp group \n");fflush(stdout);
			ifail = AOM_refresh (STNRevisionTag,FALSE);
		}
		
		/**********Set some other properties of STN Header Revision **************************/
		ifail = AOM_lock(STNRevisionTag);
		ifail = AOM_set_value_string(STNRevisionTag,"t5_HeaderId", Itemname);
		ifail = AOM_set_value_string(STNRevisionTag,"t5_StnDescription", description);
		ifail = AOM_save_without_extensions(STNRevisionTag);
		ifail = AOM_refresh(STNRevisionTag, FALSE);
		ifail = AOM_unlock(STNRevisionTag);
		printf("\nSTN:Other properties are set for STN Header\n");
		
		
		
		/**************Creation of STN Doc **********************/
		
		if(num > 0)
		{
			int yi =0;
			char *item_id_dup = NULL;
			char* DeptName_dup = NULL;
			for(yi=0;yi<num;yi++)
			{
				int Dept_items = 0;
				tag_t* Dept_tag = NULL;
				
				
				item_id_dup = (char*)MEM_alloc(100*sizeof(char));
				DeptName_dup = (char*)MEM_alloc(100*sizeof(char));
				tc_strcpy(item_id_dup,DeptDocname[yi]);
				printf("\nSTN: First two digit of Dept number  :%s\n",item_id_dup);fflush(stdout);
				
				tc_strcpy(DeptName_dup,item_id_dup);
				tc_strcat(DeptName_dup,Itemname);
						
				printf("\nSTN: Final Department Document Number -----> :%s \n",DeptName_dup);fflush(stdout);
				
				//ifail = ITEM_find(DeptName_dup, &Dept_items, &Dept_tag);
				
				
				const char *attrs2[2];
				const char *values2[2];
				attrs2[0] ="item_id";
				attrs2[1] ="object_type";
				values2[0] = (char *)DeptName_dup;
				values2[1] = "T5_DeptDoc";
		
				ifail = ITEM_find_items_by_key_attributes(2,attrs2, values2, &Dept_items, &Dept_tag);
				printf("\nSTN:Dept_items==>[%d]\n",Dept_items);fflush(stdout);
				if(Dept_items == 0)
				{
					tag_t DeptDocRevType = NULLTAG;
					tag_t DeptDocRevCreI = NULLTAG;
					tag_t DeptDocTagType = NULLTAG;
					tag_t DeptDocTagCreI = NULLTAG;
					tag_t DepDocObj = NULLTAG;
					tag_t DeptDocItem = NULLTAG;
					tag_t DeptDocRevTag = NULLTAG;					
					printf("\nSTN: Creating New Department Doc \n" );fflush(stdout);
					ifail = TCTYPE_find_type("T5_DeptDocRevision", NULL, &DeptDocRevType);
					if(DeptDocRevType != NULLTAG)
					{
						printf("\nSTN: 111 DeptDocRevType Tag Found.");fflush(stdout);
						ifail = TCTYPE_construct_create_input(DeptDocRevType, &DeptDocRevCreI);
						
						ifail = AOM_set_value_string(DeptDocRevCreI, "object_name", DeptName_dup);
						ifail = AOM_set_value_string(DeptDocRevCreI, "item_revision_id", "A;1");
						ifail = AOM_set_value_string(DeptDocRevCreI, "sequence_id", "1");
						ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArHNum", Itemname);
						ifail = AOM_set_value_string(DeptDocRevCreI, "object_desc", description);
						ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptHeaderDesc", description);
						ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArDNum", DeptName_dup);
						ifail = AOM_set_value_string(DeptDocRevCreI, "t5_Department", item_id_dup);
						ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArPlant", stnPlant);
						
						ifail = TCTYPE_find_type("T5_DeptDoc", NULL, &DeptDocTagType);
						
						if(DeptDocTagType != NULLTAG)
						{
							printf("\nSTN: 2222DeptDocTag Tag Found. \n");fflush(stdout);
							
							ifail = TCTYPE_construct_create_input(DeptDocTagType, &DeptDocTagCreI);
							
							ifail = AOM_set_value_string(DeptDocTagCreI, "item_id", DeptName_dup);
							ifail = AOM_set_value_string(DeptDocTagCreI, "object_name", DeptName_dup);
							ifail = TCTYPE_create_object(DeptDocTagCreI, &DepDocObj);
							
							
						}
						
						if(DepDocObj != NULLTAG)
						{
							printf("\nSTN: Main STN Department Document Object is created successfully. \n");fflush(stdout);
							
							ifail = AOM_save_with_extensions(DepDocObj);
							//ifail = AOM_unlock(DepDocObj);
							ifail = AOM_refresh(DepDocObj,0);
							ifail = AOM_unlock(DepDocObj);
						}
						else
						{
							printf("\nSTN: Main STN Department Document Object is NOT  created  \n");fflush(stdout);
							continue;
						}

						
						ifail = getSTNDeptDocObj(DeptName_dup,&DeptDocItem);
						if(DeptDocItem != NULLTAG)
						{
							ifail = ITEM_ask_latest_rev(DeptDocItem,&DeptDocRevTag);
						}
						else
						{
							printf("\nSTN:XXX:Null Value of Dept Doc\n");fflush(stdout);
						}
						
						if(DeptDocRevTag != NULLTAG)
						{
							char* DeptDocRevS = NULL;
							char* ErcGroupName = NULL;
							char* Arai_Designer = NULL;
							tag_t ErcGroup_tag = NULLTAG;
							tag_t DML_PrincipleEng_tag = NULLTAG;
							
							int No_PrincipleEng = 0;
							tag_t * PrincipleEngineering = NULL;
							
							char* ErcGroupNameM = NULL;
							char* Arai_DesignerM = NULL;
							tag_t ErcGroup_tagM = NULLTAG;
							tag_t DML_PrincipleEng_tagM = NULLTAG;
							
							int No_PrincipleEngM = 0;
							tag_t * PrincipleEngineeringM = NULL;
							
							
							
							//printf("\nSTN: Inside the latest Department Doc Tag Exists   \n");fflush(stdout);
							printf("\nSTN: Inside the latest Department Doc Tag Exists -(%s)  \n",item_id_dup);fflush(stdout);
							
							/****Set the Revision to A;1 ************/
							ifail = AOM_lock(DeptDocRevTag);
							ifail = AOM_set_value_string(DeptDocRevTag,"item_revision_id", "A;1");
							
							//Set other properties
							ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArHNum", Itemname);
							ifail = AOM_set_value_string(DeptDocRevTag, "object_desc", description);
							ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptHeaderDesc", description);
							ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArDNum", DeptName_dup);
							ifail = AOM_set_value_string(DeptDocRevTag, "t5_Department", item_id_dup);
							ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArPlant", stnPlant);
							
							ifail = AOM_save_without_extensions(DeptDocRevTag);
							ifail = AOM_refresh(DeptDocRevTag, FALSE);
							//printf("\nSTN: Now revision of Department Document set \n");
							ifail = AOM_ask_value_string(DeptDocRevTag,"item_revision_id",&DeptDocRevS);
							printf("\nSTN: Revision of Department Document is -- %s \n",DeptDocRevS);fflush(stdout);
							
							
							/***********Set the Designer to the Department Document *********************/
							
							ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );							
							//tc_strcpy(ErcGroupName,"STN_Participants_Group");
							
							if(cntrlTag == NULLTAG)
							{
								//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
								tc_strcpy(ErcGroupName,"STN_Participants_Group");
							}
							else
							{
								
								ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
								if(tc_strlen(info2) > 0)
								{
									tc_strcpy(ErcGroupName,info2);
								}
								else
								{
									tc_strcpy(ErcGroupName,"STN_Participants_Group");
								}
													
							}
							
							Arai_Designer = (char*)MEM_alloc(100);
							tc_strcpy(Arai_Designer,item_id_dup);
							tc_strcat(Arai_Designer,"AraiDesigner");
							
							printf("\nSTN: Arai designer group name to be set  -(%s)  \n",Arai_Designer);fflush(stdout);
							
							if(SA_find_group(ErcGroupName, &ErcGroup_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(Arai_Designer,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();
							
							MEM_free(ErcGroupName);
							MEM_free(Arai_Designer);
							
							if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
							{
								printf("\nSTN:  Now at 5555 !\n");fflush(stdout);
								if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
								printf("\nSTN: Arai designer group name_Func:>>  :[%d]\n",No_PrincipleEng);fflush(stdout);								
							}
							
							if(No_PrincipleEng>0)
							{
								int ik =0;
								tag_t PrincipleEngineer_Type = NULLTAG;
								tag_t PrincipleEngineer_Party = NULLTAG;
								
								for(ik=0;ik<No_PrincipleEng;ik++)
								{
									printf("\nSTN: Inside for loop - Arai designer group name  no: %d \n",ik);fflush(stdout);
									if(EPM_get_participanttype ("T5_AraiDesignerGrp",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
									ifail = AOM_lock(DeptDocRevTag);			
									//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
									ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_Party);
									ifail = AOM_save_without_extensions(DeptDocRevTag);
									ifail = AOM_unlock(DeptDocRevTag);									
								}
								printf("\nSTN: In the end of for loop Arai designer group \n");fflush(stdout);
								ifail = AOM_refresh (DeptDocRevTag,FALSE);								
							}
							
							printf("\nSTN: outide arai designer grp condition true \n");fflush(stdout);
							
							
							/************Set Manager to Department Doc ************************************/
							
							ErcGroupNameM = (char *)MEM_alloc( 100 * sizeof(char) );
							//tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
							
							if(cntrlTag == NULLTAG)
							{
								//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
								tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
							}
							else
							{
								
								ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
								if(tc_strlen(info2) > 0)
								{
									tc_strcpy(ErcGroupNameM,info2);
								}
								else
								{
									tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
								}								
								
							}
							
							Arai_DesignerM = (char	*)MEM_alloc(100);
							tc_strcpy(Arai_DesignerM,item_id_dup);
							tc_strcat(Arai_DesignerM,"AraiManager");
							
							printf("\nSTN: Arai Manager group name to be set  -(%s)  \n",Arai_DesignerM);fflush(stdout);
							
							if(SA_find_group(ErcGroupNameM, &ErcGroup_tagM)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(Arai_DesignerM,&DML_PrincipleEng_tagM)!=ITK_ok)PrintErrorStack();
							
							MEM_free(ErcGroupNameM);
							MEM_free(Arai_DesignerM);
							
							if(ErcGroup_tagM!=NULLTAG && DML_PrincipleEng_tagM!=NULLTAG)
							{
								printf("\nSTN:  Now at 5555-M !\n");fflush(stdout);
								if(SA_find_groupmember_by_role(DML_PrincipleEng_tagM,ErcGroup_tagM,&No_PrincipleEngM,&PrincipleEngineeringM)!=ITK_ok)PrintErrorStack();
								printf("\nSTN: Arai Manager group name_Func:>>  :[%d]\n",No_PrincipleEngM);fflush(stdout);
							}
							
							
							if(No_PrincipleEngM>0)
							{
								int mk = 0;
								tag_t PrincipleEngineer_TypeM = NULLTAG;
								tag_t PrincipleEngineer_PartyM = NULLTAG;
								
								for(mk=0;mk<No_PrincipleEngM;mk++)
								{
									printf("\nSTN: Inside for loop - Arai Manager group name  no: %d \n",mk);fflush(stdout);
									if(EPM_get_participanttype ("T5_AraiManagerGrp",&PrincipleEngineer_TypeM)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(PrincipleEngineeringM[mk],PrincipleEngineer_TypeM,&PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
									ifail = AOM_lock(DeptDocRevTag);			
									//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
									ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_PartyM);
									ifail = AOM_save_without_extensions(DeptDocRevTag);
									ifail = AOM_unlock(DeptDocRevTag);									
								}
								printf("\nSTN: In the end of for loop Arai Manager group \n");fflush(stdout);
								ifail = AOM_refresh (DeptDocRevTag,FALSE);								
								
							}
							
							printf("\nSTN:Creating Relationship between Depart Doc and STN **** \n\n \n ");fflush(stdout);
							
							ifail = t5STN_RelatePrimaryWithSecondaryObj(STNRevisionTag,DeptDocRevTag,"T5_StnHasDeptDoc");
							
							if(ifail == ITK_ok)
							{
								printf("\nSTN:RELATIONSHIP CREATED between department doc and STN header \n");fflush(stdout);
							}
							else
							{
								printf("\nSTN:RELATIONSHIP NOT CREATED between department doc and STN header \n");fflush(stdout);
							}
							
							printf("\nSTN: For creating clause and dept relationship  First two digit of Dept number  :%s\n",item_id_dup);fflush(stdout);

							ClauseToDept(item_id_dup,STNRevisionTag,DeptDocRevTag);
							printf("\nSTN: Outside main function   \n"); fflush(stdout);
							
						}
												
						
					}
					
					
				}
				else
				{
					printf("\nSTN: In Else as No. of Department already find :%d with number -%s \n", Dept_items,DeptName_dup );fflush(stdout);
				}				
				
				
				
				
				MEM_free(item_id_dup);
				MEM_free(DeptName_dup);
			}
		}
		
		
		
		
	}
	printf("\nSTN: **** Exit STN Header Revison function Creation Post **** \n");fflush(stdout);
	
	return ITK_ok;
	
}



//Post action of IMAN_save_msg of T5_STNHeader - If new then create department doc and clause - 5-cre
extern DLLAPI int Stn_Department_relation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	int isnew              = 0;
	tag_t objTag = va_arg(args, tag_t);
	isnew   = va_arg(args, int);
	tag_t objTypeTag = NULLTAG;
	char* type_name = NULL;
	
	printf("\nSTN: **** Inside the STN Header Creation Post(Stn_Department_relation) **** \n");fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\nSTN: Inside the STN Header function check Object type :%s \n", type_name);fflush(stdout);
	printf("\nSTN:isNew===> [%d]\n",isnew);fflush(stdout);
	if(tc_strcmp(type_name,"T5_STNHeader")==0 && isnew == 1)
	{
		tag_t STNRevisionTag = NULLTAG;
		char* StnObjectName = NULL;
		char* Itemname = NULL;
		char* description = NULL;
		char* stnPlant = NULL;
		char **DeptDocname = NULL;
		int num =0;
		char* StnRevName = NULL;
		char* ErcGroupNameC = NULL;
		char* Arai_DesignerC = NULL;
		tag_t ErcGroup_tagC = NULLTAG;
		tag_t DML_PrincipleEng_tagC = NULLTAG;
		int No_PrincipleEngC = 0;
		tag_t * PrincipleEngineeringC = NULL;
		char* info1 = NULL;
		char* info2 = NULL;
		char* info3 = NULL;
		
		printf("\nSTN: Inside the condition as object type is - (%s)\n", type_name);fflush(stdout);
		
		ifail = ITEM_ask_latest_rev(objTag,&STNRevisionTag);
		
		if(STNRevisionTag == NULLTAG || ifail !=ITK_ok)
		{
			printf("\nSTN:Error!!!!. No STN Rev Tag found. Check with Admin. Exiting......\n");fflush(stdout);
		}
		printf("\nSTN:Now get the attributes on STN Revision \n");fflush(stdout);
		
		ifail = AOM_ask_value_string(STNRevisionTag,"object_name",&StnObjectName);
		ifail = AOM_ask_value_string(STNRevisionTag,"item_id",&Itemname);
		ifail = AOM_ask_value_string(STNRevisionTag,"object_desc",&description);
		ifail = AOM_ask_value_string(STNRevisionTag,"t5_StnArPlant",&stnPlant);
		if(stnPlant == NULL)
		{
			stnPlant="PUNE";
		}
		else
		{
			if(tc_strlen(stnPlant) <=0)
			{
				stnPlant="PUNE";
			}
		}
		printf("\nSTN:stnPlant:[%s]",stnPlant);fflush(stdout);
		ifail = AOM_ask_value_strings(STNRevisionTag,"t5_SelectDeptDoc",&num,&DeptDocname);
		
		/********* Set Revision of STN Header to A;1       ****************/
		
		ifail = AOM_lock(STNRevisionTag);
		ifail = AOM_set_value_string(STNRevisionTag,"item_revision_id", "A;1");
		ifail = AOM_set_value_string(STNRevisionTag,"t5_StnArPlant", stnPlant);
		ifail = AOM_save_without_extensions(STNRevisionTag);
		ifail = AOM_refresh(STNRevisionTag, FALSE);
		ifail = AOM_unlock(STNRevisionTag);
		printf("\nSTN:Now revision of STN header set\n");
		
		
		ifail = AOM_ask_value_string(STNRevisionTag,"item_revision_id",&StnRevName);
		printf("\nSTN:Revision of STN Header -- %s \n",StnRevName);fflush(stdout);
		
		
		/******************** Set the Certification Grp ***********************/
		
		ErcGroupNameC = (char *) MEM_alloc( 100 * sizeof(char) );
		/* Get the correct Group - STNGrp */
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNGroupControlTag(&cntrlTag);
		if(cntrlTag == NULLTAG)
		{
			tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
		}
		else
		{
			
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo1", &info1);
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo3", &info3);
			if(tc_strlen(info2) > 0)
			{
				tc_strcpy(ErcGroupNameC,info2);
			}
			else
			{
				tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
			}
			
		}
		
		
		
		Arai_DesignerC = (char	*)MEM_alloc(100);
		tc_strcpy(Arai_DesignerC,"CertificationGrp");
		
		printf("\nSTN:Arai CertificationGrp group name to be set  -(%s)  \n",Arai_DesignerC);fflush(stdout);
		
		if(SA_find_group(ErcGroupNameC, &ErcGroup_tagC)!=ITK_ok)PrintErrorStack();
		if(SA_find_role2(Arai_DesignerC,&DML_PrincipleEng_tagC)!=ITK_ok)PrintErrorStack();
		
		MEM_free(ErcGroupNameC);
		MEM_free(Arai_DesignerC);
		
		if(info3 == NULL) info3 = "";
		
		if(info3!= NULL)
		{
			if(tc_strcmp(info3,"LIVESTNMaster")==0)
			{
				
				if(ErcGroup_tagC!=NULLTAG && DML_PrincipleEng_tagC!=NULLTAG)
				{
					printf("\nSTN:Now at  !\n");fflush(stdout);
					if(SA_find_groupmember_by_role(DML_PrincipleEng_tagC,ErcGroup_tagC,&No_PrincipleEngC,&PrincipleEngineeringC)!=ITK_ok)PrintErrorStack();
					printf("\nSTN:Arai CertificationGrp group name_Func:>>  :[%d]\n",No_PrincipleEngC);fflush(stdout);
				}
				

				
				if(No_PrincipleEngC>0)
				{
					int ck =0;
					tag_t PrincipleEngineer_TypeC = NULLTAG;
					tag_t PrincipleEngineer_PartyC = NULLTAG;
					
					for(ck=0;ck<No_PrincipleEngC;ck++)
					{
						printf("\nSTN:Inside for loop - Arai CertificationGrp group name  no: %d \n",ck);fflush(stdout);
						if(EPM_get_participanttype ("T5_CertificationGrp",&PrincipleEngineer_TypeC)!=ITK_ok)PrintErrorStack();
						if(EPM_create_participant(PrincipleEngineeringC[ck],PrincipleEngineer_TypeC,&PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
						
						ifail = AOM_lock(STNRevisionTag);
						//if(ITEM_rev_add_participant(STNRevisionTag,PrincipleEngineer_PartyC)!=ITK_ok)PrintErrorStack();
						ifail = PARTICIPANT_add_participant(STNRevisionTag,TRUE,PrincipleEngineer_PartyC);
						ifail = AOM_save_without_extensions(STNRevisionTag);
						ifail = AOM_unlock(STNRevisionTag);				
					}
					printf("\nSTN: In the end of for loop Arai CertificationGrp group \n");fflush(stdout);
					ifail = AOM_refresh (STNRevisionTag,FALSE);
				}
				
				/**********Set some other properties of STN Header Revision **************************/
				ifail = AOM_lock(STNRevisionTag);
				ifail = AOM_set_value_string(STNRevisionTag,"t5_HeaderId", Itemname);
				ifail = AOM_set_value_string(STNRevisionTag,"t5_StnDescription", description);
				ifail = AOM_save_without_extensions(STNRevisionTag);
				ifail = AOM_refresh(STNRevisionTag, FALSE);
				ifail = AOM_unlock(STNRevisionTag);
				printf("\nSTN:Other properties are set for STN Header\n");fflush(stdout);
				
				
				
				/**************Creation of STN Doc **********************/
				
				if(num > 0)
				{
					int yi =0;
					char *item_id_dup = NULL;
					char* DeptName_dup = NULL;
					for(yi=0;yi<num;yi++)
					{
						int Dept_items = 0;
						tag_t* Dept_tag = NULL;
						
						
						item_id_dup = (char*)MEM_alloc(100*sizeof(char));
						DeptName_dup = (char*)MEM_alloc(100*sizeof(char));
						tc_strcpy(item_id_dup,DeptDocname[yi]);
						printf("\nSTN: First two digit of Dept number  :%s\n",item_id_dup);fflush(stdout);
						
						tc_strcpy(DeptName_dup,item_id_dup);
						tc_strcat(DeptName_dup,Itemname);
								
						printf("\nSTN: Final Department Document Number -----> :%s \n",DeptName_dup);fflush(stdout);
						
						//ifail = ITEM_find(DeptName_dup, &Dept_items, &Dept_tag);
										const char *attrs2[2];
						const char *values2[2];
						attrs2[0] ="item_id";
						attrs2[1] ="object_type";
						values2[0] = (char *)DeptName_dup;
						values2[1] = "T5_DeptDoc";
				
						ifail = ITEM_find_items_by_key_attributes(2,attrs2, values2, &Dept_items, &Dept_tag);
						printf("\nSTN:Dept_items==>[%d]\n",Dept_items);fflush(stdout);
						if(Dept_items == 0)
						{
							tag_t DeptDocRevType = NULLTAG;
							tag_t DeptDocRevCreI = NULLTAG;
							tag_t DeptDocTagType = NULLTAG;
							tag_t DeptDocTagCreI = NULLTAG;
							tag_t DepDocObj = NULLTAG;
							tag_t DeptDocItem = NULLTAG;
							tag_t DeptDocRevTag = NULLTAG;					
							printf("\nSTN: Creating New Department Doc \n" );fflush(stdout);
							ifail = TCTYPE_find_type("T5_DeptDocRevision", NULL, &DeptDocRevType);
							if(DeptDocRevType != NULLTAG)
							{
								printf("\nSTN: 111 DeptDocRevType Tag Found.");fflush(stdout);
								ifail = TCTYPE_construct_create_input(DeptDocRevType, &DeptDocRevCreI);
								
								ifail = AOM_set_value_string(DeptDocRevCreI, "object_name", DeptName_dup);
								ifail = AOM_set_value_string(DeptDocRevCreI, "item_revision_id", "A;1");
								ifail = AOM_set_value_string(DeptDocRevCreI, "sequence_id", "1");
								ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArHNum", Itemname);
								ifail = AOM_set_value_string(DeptDocRevCreI, "object_desc", description);
								ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptHeaderDesc", description);
								ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArDNum", DeptName_dup);
								ifail = AOM_set_value_string(DeptDocRevCreI, "t5_Department", item_id_dup);
								ifail = AOM_set_value_string(DeptDocRevCreI, "t5_DeptArPlant", stnPlant);
								
								ifail = TCTYPE_find_type("T5_DeptDoc", NULL, &DeptDocTagType);
								
								if(DeptDocTagType != NULLTAG)
								{
									printf("\nSTN: 2222DeptDocTag Tag Found. \n");fflush(stdout);
									
									ifail = TCTYPE_construct_create_input(DeptDocTagType, &DeptDocTagCreI);
									
									ifail = AOM_set_value_string(DeptDocTagCreI, "item_id", DeptName_dup);
									ifail = AOM_set_value_string(DeptDocTagCreI, "object_name", DeptName_dup);
									ifail = TCTYPE_create_object(DeptDocTagCreI, &DepDocObj);
									
									
								}
								
								if(DepDocObj != NULLTAG)
								{
									printf("\nSTN: Main STN Department Document Object is created successfully. \n");fflush(stdout);
									
									ifail = AOM_save_without_extensions(DepDocObj);
									
									ifail = AOM_refresh(DepDocObj,0);
									ifail = AOM_unlock(DepDocObj);
								}
								else
								{
									printf("\nSTN: Main STN Department Document Object is NOT  created  \n");fflush(stdout);
									continue;
								}

								ifail = getSTNDeptDocObj(DeptName_dup,&DeptDocItem);
								if(DeptDocItem != NULLTAG)
								{
									ifail = ITEM_ask_latest_rev(DeptDocItem,&DeptDocRevTag);
								}
								else
								{
									printf("\nSTN:XXX:Null Value of Dept Doc\n");fflush(stdout);
								}
								
								if(DeptDocItem != NULLTAG)
								{
									ifail = ITEM_ask_latest_rev(DeptDocItem,&DeptDocRevTag);
								}
								
								if(DeptDocRevTag != NULLTAG)
								{
									char* DeptDocRevS = NULL;
									char* ErcGroupName = NULL;
									char* Arai_Designer = NULL;
									tag_t ErcGroup_tag = NULLTAG;
									tag_t DML_PrincipleEng_tag = NULLTAG;
									
									int No_PrincipleEng = 0;
									tag_t * PrincipleEngineering = NULL;
									
									char* ErcGroupNameM = NULL;
									char* Arai_DesignerM = NULL;
									tag_t ErcGroup_tagM = NULLTAG;
									tag_t DML_PrincipleEng_tagM = NULLTAG;
									
									int No_PrincipleEngM = 0;
									tag_t * PrincipleEngineeringM = NULL;
									
									
									
									printf("\nSTN: Inside the latest Department Doc Tag Exists   \n");fflush(stdout);
									printf("\nSTN: Inside the latest Department Doc Tag Exists -(%s)  \n",item_id_dup);fflush(stdout);
									
									/****Set the Revision to A;1 ************/
									ifail = AOM_lock(DeptDocRevTag);
									ifail = AOM_set_value_string(DeptDocRevTag,"item_revision_id", "A;1");
									
									//Set other properties
									ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArHNum", Itemname);
									ifail = AOM_set_value_string(DeptDocRevTag, "object_desc", description);
									ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptHeaderDesc", description);
									ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArDNum", DeptName_dup);
									ifail = AOM_set_value_string(DeptDocRevTag, "t5_Department", item_id_dup);
									ifail = AOM_set_value_string(DeptDocRevTag, "t5_DeptArPlant", stnPlant);
									
									ifail = AOM_save_without_extensions(DeptDocRevTag);
									ifail = AOM_refresh(DeptDocRevTag, FALSE);
									ifail = AOM_unlock(DeptDocRevTag);
									printf("\nSTN: Now revision of Department Document set \n");
									ifail = AOM_ask_value_string(DeptDocRevTag,"item_revision_id",&DeptDocRevS);
									printf("\nSTN: Revision of Department Document is -- %s \n",DeptDocRevS);fflush(stdout);
									
									
									/***********Set the Designer to the Department Document *********************/
									
									ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );							
									//tc_strcpy(ErcGroupName,"STN_Participants_Group");
									
									if(cntrlTag == NULLTAG)
									{
										//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
										tc_strcpy(ErcGroupName,"STN_Participants_Group");
									}
									else
									{
										
										ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
										if(tc_strlen(info2) > 0)
										{
											tc_strcpy(ErcGroupName,info2);
										}
										else
										{
											tc_strcpy(ErcGroupName,"STN_Participants_Group");
										}
															
									}
									
									Arai_Designer = (char*)MEM_alloc(100);
									tc_strcpy(Arai_Designer,item_id_dup);
									tc_strcat(Arai_Designer,"AraiDesigner");
									
									printf("\nSTN: Arai designer group name to be set  -(%s)  \n",Arai_Designer);fflush(stdout);
									
									if(SA_find_group(ErcGroupName, &ErcGroup_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_role2(Arai_Designer,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();
									
									MEM_free(ErcGroupName);
									MEM_free(Arai_Designer);
									
									if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
									{
										printf("\nSTN:  Now at 5555 !\n");fflush(stdout);
										if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
										printf("\nSTN: Arai designer group name_Func:>>  :[%d]\n",No_PrincipleEng);fflush(stdout);								
									}
									
									if(No_PrincipleEng>0)
									{
										int ik =0;
										tag_t PrincipleEngineer_Type = NULLTAG;
										tag_t PrincipleEngineer_Party = NULLTAG;
										
										for(ik=0;ik<No_PrincipleEng;ik++)
										{
											printf("\nSTN: Inside for loop - Arai designer group name  no: %d \n",ik);fflush(stdout);
											if(EPM_get_participanttype ("T5_AraiDesignerGrp",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
											ifail = AOM_lock(DeptDocRevTag);			
											//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
											ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_Party);
											ifail = AOM_save_without_extensions(DeptDocRevTag);
											ifail = AOM_unlock(DeptDocRevTag);									
										}
										printf("\nSTN: In the end of for loop Arai designer group \n");fflush(stdout);
										ifail = AOM_refresh (DeptDocRevTag,FALSE);								
									}
									
									printf("\nSTN: outide arai designer grp condition true \n");fflush(stdout);
									
									
									/************Set Manager to Department Doc ************************************/
									
									ErcGroupNameM = (char *)MEM_alloc( 100 * sizeof(char) );
									//tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
									
									if(cntrlTag == NULLTAG)
									{
										//tc_strcpy(ErcGroupNameC,"STN_Participants_Group");
										tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
									}
									else
									{
										
										ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
										if(tc_strlen(info2) > 0)
										{
											tc_strcpy(ErcGroupNameM,info2);
										}
										else
										{
											tc_strcpy(ErcGroupNameM,"STN_Participants_Group");
										}								
										
									}
									
									Arai_DesignerM = (char	*)MEM_alloc(100);
									tc_strcpy(Arai_DesignerM,item_id_dup);
									tc_strcat(Arai_DesignerM,"AraiManager");
									
									printf("\nSTN: Arai Manager group name to be set  -(%s)  \n",Arai_DesignerM);fflush(stdout);
									
									if(SA_find_group(ErcGroupNameM, &ErcGroup_tagM)!=ITK_ok)PrintErrorStack();
									if(SA_find_role2(Arai_DesignerM,&DML_PrincipleEng_tagM)!=ITK_ok)PrintErrorStack();
									
									MEM_free(ErcGroupNameM);
									MEM_free(Arai_DesignerM);
									
									if(ErcGroup_tagM!=NULLTAG && DML_PrincipleEng_tagM!=NULLTAG)
									{
										printf("\nSTN:  Now at 5555-M !\n");fflush(stdout);
										if(SA_find_groupmember_by_role(DML_PrincipleEng_tagM,ErcGroup_tagM,&No_PrincipleEngM,&PrincipleEngineeringM)!=ITK_ok)PrintErrorStack();
										printf("\nSTN: Arai Manager group name_Func:>>  :[%d]\n",No_PrincipleEngM);fflush(stdout);
									}
									
									
									if(No_PrincipleEngM>0)
									{
										int mk = 0;
										tag_t PrincipleEngineer_TypeM = NULLTAG;
										tag_t PrincipleEngineer_PartyM = NULLTAG;
										
										for(mk=0;mk<No_PrincipleEngM;mk++)
										{
											printf("\nSTN: Inside for loop - Arai Manager group name  no: %d \n",mk);fflush(stdout);
											if(EPM_get_participanttype ("T5_AraiManagerGrp",&PrincipleEngineer_TypeM)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(PrincipleEngineeringM[mk],PrincipleEngineer_TypeM,&PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
											ifail = AOM_lock(DeptDocRevTag);			
											//if(ITEM_rev_add_participant(DeptDocRevTag,PrincipleEngineer_PartyM)!=ITK_ok)PrintErrorStack();
											ifail = PARTICIPANT_add_participant(DeptDocRevTag,TRUE,PrincipleEngineer_PartyM);
											ifail = AOM_save_without_extensions(DeptDocRevTag);
											ifail = AOM_unlock(DeptDocRevTag);									
										}
										printf("\nSTN: In the end of for loop Arai Manager group \n");fflush(stdout);
										ifail = AOM_refresh (DeptDocRevTag,FALSE);								
										
									}
									
									printf("\n \n\nSTN: Creating Relationship between Depart Doc and STN **** \n\n \n ");fflush(stdout);
									
									ifail = t5STN_RelatePrimaryWithSecondaryObj(STNRevisionTag,DeptDocRevTag,"T5_StnHasDeptDoc");
									
									if(ifail == ITK_ok)
									{
										printf("\nSTN:RELATIONSHIP CREATED between department doc and STN header \n");fflush(stdout);
									}
									else
									{
										printf("\nSTN:RELATIONSHIP NOT CREATED between department doc and STN header \n");fflush(stdout);
									}
									
									printf("\nSTN: For creating clause and dept relationship  First two digit of Dept number  :%s\n",item_id_dup);fflush(stdout);

									ClauseToDept(item_id_dup,STNRevisionTag,DeptDocRevTag);
									printf("\nSTN: Outside main function   \n"); fflush(stdout);
									
								}
														
								
							}
							
							
						}
						else
						{
							printf("\nSTN: In Else as No. of Department already find :%d with number -%s \n", Dept_items,DeptName_dup );fflush(stdout);
						}				
						
						
						
						
						MEM_free(item_id_dup);
						MEM_free(DeptName_dup);
					}
				}
				
									
				
			}
			else
			{
				printf("\nSTN: STNGrp-STNGrp ,Not live for department creation post action info3 is [%s]\n",info3);fflush(stdout);
			}
		
			
		}
		
		

		
		
	}
	
	printf("\nSTN: **** Exit STN Header function Creation Post **** \n");fflush(stdout);
	return ITK_ok;
}



// Override of RES_checkout_msg - Validations for Check out of STN, STN Rev, Dept Doc, Dept Doc Rev
extern DLLAPI int stnCheckOutValidation(METHOD_message_t *msg, va_list args)
{
	int ifail = ITK_ok;
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag,item_tag = NULLTAG;

	//char	type_name[TCTYPE_name_size_c+1];
	char* type_name = NULL;
	char	*esoPartNum		= NULL;
	char	*esoParRevSeq		= NULL;
	char	*esoPartRelzState	= NULL;


	if(TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok);
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
	//printf("\nSTN:stnCheckOutValidation PreAction objTypeTag [%s]\n",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_STNHeader")==0 || tc_strcmp(type_name,"T5_STNHeaderRevision")==0 || tc_strcmp(type_name,"T5_DeptDoc")==0 || tc_strcmp(type_name,"T5_DeptDocRevision")==0)
	{
		logical isAllowed = FALSE;
		
		ifail = isEligibleToCreUpdSTNHeader(&isAllowed);
		printf("\nSTN: Is Allowed for Update of STN Header/STN Doc: [%d]\n", isAllowed);fflush(stdout);
		
		if(!isAllowed)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to Update STN Header/STN Document. Only CertificationGrp Role can Update. Kindly contact PLM Admin..");
			printf("\n\n\tSTN: Stn_PreValidation 111*********************You Don't Have access to create STN *********************\n");fflush(stdout);
			return ITK_err;
		}
		else
		{
			printf("\nSTN: Allowed for Update of STN Header/STN Doc\n");fflush(stdout);
		}		
		
		
	}
	
	//For STN Clause validation.
	
	if(tc_strcmp(type_name,"T5_ClauseRevision")==0)
	{
		printf("\nSTN: Validation for STN Clause updation....\n");fflush(stdout); 
		
		logical isAllowed = FALSE;
		ifail = isAllowedToUpdateSTNClause(objTag, &isAllowed);
		printf("\nSTN: Is Allowed for Update of STN Clause [%d]\n", isAllowed);fflush(stdout);
		
		if(!isAllowed)
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to Update STN Clause or the STN Department doc is not in the correct step of Workflow.\nThe STN Doc should be in \"Expand Departmnt Object,Update Clause Objects\" step. Kindly contact PLM Admin..");
			printf("\n\n\tSTN: Stn_PreValidation 222*********************You Don't Have access to update STN Clause *********************\n");fflush(stdout);
			return ITK_err;
		}
		else
		{
			printf("\nSTN: Allowed for Update of STN Clause\n");fflush(stdout);
		}
		
		
	}
	
	return ITK_ok;
}


int getNextSTNRev_bkp(char* currRev, char** nextRev)
{
	int ifail = ITK_ok;
	
	if(tc_strcmp(currRev,"A")==0)
	{
		*nextRev = "B";
	}
	else if(tc_strcmp(currRev,"B")==0)
	{
		*nextRev = "C";
	}
	else if(tc_strcmp(currRev,"C")==0)
	{
		*nextRev = "D";
	}
	else if(tc_strcmp(currRev,"D")==0)
	{
		*nextRev = "E";
	}
	
	return ITK_ok;
}

int getNextSTNRev(char* currRev, char** nextRev)
{
	int ifail = ITK_ok;	
	char *revArr[52] ={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a1","b1","c1","d1","e1","f1","g1","h1","i1","j1","k1","l1","m1","n1","o1","p1","q1","r1","s1","t1","u1","v1","w1","x1","y1","z1"};	
	int i = 0;
	for(i=0;i<51;i++)
	{
		//printf("\n[%s]",revArr[i]);fflush(stdout);
		if(tc_strcmp(revArr[i],currRev)==0)
		{
			*nextRev = revArr[i+1];
			break;
		}
	}
	
	return ITK_ok;
}


int createDeptDocandClauses(tag_t oldSTNRevTag, tag_t newSTNRevTag)
{
	int ifail = ITK_ok;
	char* stnRev = NULL;
	printf("\nSTN:createDeptDocandClauses - START\n");fflush(stdout);
	
	
	ifail = AOM_ask_value_string(newSTNRevTag,"item_revision_id", &stnRev);
	//Get Department Doc of prev rev STN Tag
	tag_t stnToDeptRelType = NULLTAG;		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(oldSTNRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t oldDeptDocRevTag = NULLTAG;
			tag_t newDeptDocRevTag = NULLTAG;
			
			oldDeptDocRevTag = deptDocRevTags[i];
			
			ifail = ITEM_copy_rev(oldDeptDocRevTag,stnRev,&newDeptDocRevTag);
			
			if(newDeptDocRevTag != NULLTAG)
			{
				//create clause and relate to new Dept Doc.
				
				//Get Clause Revisions.
				tag_t deptToClauseRelType = NULLTAG;
				ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
				if(deptToClauseRelType != NULLTAG)
				{
					tag_t* oldClsRevTags = NULL;
					int oldClsRevTagCnt = 0;
					ifail = GRM_list_secondary_objects_only(oldDeptDocRevTag,deptToClauseRelType,&oldClsRevTagCnt,&oldClsRevTags);

					printf("\nSTN: Old Clause Rev Tag count: [%d]\n", oldClsRevTagCnt);fflush(stdout);

					int j = 0;
					
					for(j=0; j<oldClsRevTagCnt;j++)
					{
						tag_t oldClauseObj = NULLTAG;
						tag_t newClauseObj = NULLTAG;
						
						oldClauseObj = oldClsRevTags[j];
						
						ifail = ITEM_copy_rev(oldClauseObj,stnRev,&newClauseObj);
						
						if(newClauseObj != NULLTAG)
						{
							ifail = t5STN_RelatePrimaryWithSecondaryObj(newDeptDocRevTag,newClauseObj,"T5_DeptDocHasClause");
						}
						
						
					}
				}
				
				
				ifail = t5STN_RelatePrimaryWithSecondaryObj(newSTNRevTag,newDeptDocRevTag,"T5_StnHasDeptDoc");
				
				
			}
			
			
			
		}
		
	}
	
	
	printf("\nSTN:createDeptDocandClauses - END\n");fflush(stdout);
	return ITK_ok;
}
/****************STN Revise post/pre method *************************/
//Post action of ITEM_copy_rev of T5_STNHeaderRevision
extern  DLLAPI int STN_Revise_method_post(METHOD_message_t *m, va_list args)
{
	int ifail = ITK_ok;
	tag_t	source_rev				 = va_arg (args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	char* type_name = NULL;
	tag_t objTypeTag = NULLTAG;
	
	
	printf("\nSTN: In Revise post method......\n");fflush(stdout);
	if(TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	
	printf("\nSTN:Start- STN_Revise_method_post-check Object type of source :%s \n", type_name);fflush(stdout);
	
	if(new_rev[0] == NULLTAG)
	{
		printf("\nSTN: ERROR!!!! -New Revion is NULL TAG\n");fflush(stdout);
		return ifail;
	}
	
	char* sourceId = NULL;
	char* sourceRevId = NULL;
	char* newStnId = NULL;
	char* newStnRevId = NULL;
	tag_t newStnRev = NULLTAG;
	
	newStnRev = new_rev[0];
	
	ifail = AOM_ask_value_string(source_rev,"item_id",&sourceId);
	ifail = AOM_ask_value_string(source_rev,"item_revision_id",&sourceRevId);
	

	ifail = AOM_ask_value_string(newStnRev,"item_id",&newStnId);
	ifail = AOM_ask_value_string(newStnRev,"item_revision_id",&newStnRevId);
	
	
	
	printf("\nSTN: Source_Rev[%s/%s], New STN[%s/%s], rev_id = [%s]\n",sourceId,sourceRevId,newStnId,newStnRevId,rev_id);fflush(stdout);
		
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
	char* nextRev = NULL;	
	if(tc_strstr(sourceRevId,";") != NULL)
	{
		revStr = tc_strtok ( sourceRevId,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}
	
	if(revStr != NULL)
	{
		ifail = getNextSTNRev(revStr, &nextRev);
	}
	printf("\nSTN:Next Rev:[%s]",nextRev);fflush(stdout);
	if(nextRev != NULL)
	{
		char* nextRevStr = (char*)MEM_alloc(50*sizeof(char*));
		tc_strcpy(nextRevStr,nextRev);
		tc_strcat(nextRevStr,";1");
		printf("\nSTN:Next Rev Str:[%s]",nextRevStr);fflush(stdout);
		
		ifail = AOM_lock(newStnRev);
		ifail = AOM_set_value_string(newStnRev,"item_id", sourceId);
		ifail = AOM_set_value_string(newStnRev,"item_revision_id", nextRevStr);
		ifail = AOM_save_without_extensions(newStnRev);
		ifail = AOM_refresh(newStnRev, FALSE);
		ifail = AOM_unlock(newStnRev);
		
		MEM_free(nextRevStr);
		
		ifail = tm_updSTNRevMasterFormName(newStnRev, sourceId); //Update the MasterForm
		
		//Create the Department doc and clauses.
		
		ifail = createDeptDocandClauses(source_rev,newStnRev);
		
	}
	
	return ifail;
}


//Pre action of ITEM_copy_rev of T5_STNHeaderRevision
extern  DLLAPI int STN_Revise_method_pre(METHOD_message_t *m, va_list args)
{
	int ifail = ITK_ok;
	tag_t	source_rev				 = va_arg (args, tag_t);
	char*	rev_id					 = va_arg(args, char*);
	tag_t*	new_rev					 = va_arg(args, tag_t*);
	tag_t	item_rev_master_form	 = va_arg(args, tag_t);
	char* type_name = NULL;
	tag_t objTypeTag = NULLTAG;
	
	
	printf("\nSTN: In Revise pre method......\n");fflush(stdout);
	if(TCTYPE_ask_object_type(source_rev,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	
	printf("\nSTN:Start- STN_Revise_method_pre-check Object type of source :%s \n", type_name);fflush(stdout);
	
	char* relStatus = NULL;
	
	ifail = AOM_UIF_ask_value(source_rev,"release_status_list", &relStatus);
	printf("\nSTN:Release Status of STN: [%s]",relStatus);fflush(stdout);
	
	logical res = FALSE;
	ifail = isallowedToReviseSTN(&res);
	
	if(res)
	{
		//bypass for Admin support team
		printf("\nSTN:bypass for Admin support team for Revise");fflush(stdout);
	}
	else
	{
		if(tc_strstr(relStatus,"Released")!= NULL)
		{
			//Check for proper access
			char* groupName = NULL;
			tag_t groupTag = NULLTAG;
			
			char* roleName = NULL;
			char* userName = NULL;
			tag_t userTag = NULLTAG;
			tag_t roleTag = NULLTAG;
			
			POM_get_user(&userName,&userTag);
			POM_ask_group(&groupName, &groupTag);
			SA_ask_current_role(&roleTag);
			
			if(roleTag != NULLTAG)
			{
				SA_ask_role_name2(roleTag, &roleName);
			}
			
			
			printf("\nSTN:Session user:[%s], Group Name:[%s], RoleName[%s]\n", userName,groupName,roleName);fflush(stdout);

			if(tc_strcmp(groupName,"dba")==0 || tc_strcmp(groupName,"PLM_Support_Group")==0 || tc_strcmp(roleName,"CertificationGrp")==0 )
			{
				printf("\nSTN:OK to revise\n");fflush(stdout);
			}
			else
			{
				EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to revise STN. Only CertificationGrp role can revise STN.");
				printf("\nSTN: You don't have access to revise STN. Only CertificationGrp role can revise STN.\n");fflush(stdout);
				return ITK_err;
			}
			
			
		}
		else
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"You cannot revise as this STN Header is not Released.");
			printf("\nSTN: You cannot revise as this STN Header is not Released\n");fflush(stdout);
			return ITK_err;
		}
	}

	
	return ifail;
}





//Validation during Delete Relation of STN Header Rev and Depart Doc Rev

//Override pre action of TC_delete_msg of T5_StnHasDeptDoc
int T5StnHasDeptDocDeleteVal( METHOD_message_t *msg, va_list  args )
{
	
	int ifail = ITK_ok;
	
	tag_t relObj = va_arg(args, const tag_t);
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char* type_name = NULL;
	printf("\nSTN: Validation during Delete Relation of STN Header Rev and Depart Doc Rev*************\n");fflush(stdout);
	if(TCTYPE_ask_object_type(relObj,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\nSTN:     type_name [%s]\n", type_name);fflush(stdout);
	
	logical res = FALSE;
	ifail = t5STN_IsallowedToDeleteRel(&res);
	
		
	if(!res)
	{
		EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to delete STN Doc relation. Kindly contact PLM Admin..");
		printf("\n\n\tSTN: T5StnHasDeptDocDeleteVal 111*********************You don't have access to delete STN Doc relation *********************\n");fflush(stdout);
		return ITK_err;
	}
	
	return ifail;
	
}

//Override pre action of TC_delete_msg of T5_DeptDocHasClause
int T5DeptDocHasClauseDeleteVal( METHOD_message_t *msg, va_list  args )
{
	
	int ifail = ITK_ok;
	
	tag_t relObj = va_arg(args, const tag_t);
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char* type_name = NULL;
	printf("\nSTN: Validation during Delete Relation of STN Clause  and Depart Doc Rev*************\n");fflush(stdout);
	if(TCTYPE_ask_object_type(relObj,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\nSTN:     type_name [%s]\n", type_name);fflush(stdout);
	
	logical res = FALSE;
	ifail = t5STN_IsallowedToDeleteClauseRel(&res);
	
		
	if(!res)
	{
		EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to delete STN Clause relation. Kindly contact PLM Admin..");
		printf("\n\n\tSTN: T5DeptDocHasClauseDeleteVal XXXX*********************You don't have access to delete STN Clause relation *********************\n");fflush(stdout);
		return ITK_err;
	}
	
	return ifail;
	
}

//Override pre action of TC_save_msg of T5_DeptDocHasClause
int T5DeptDocHasClauseCreVal( METHOD_message_t *msg, va_list  args )
{
	
	int ifail = ITK_ok;
	
	tag_t relObj = va_arg(args, const tag_t);
	tag_t objTypeTag = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	char* type_name = NULL;
	printf("\nSTN: Validation during Paste Relation of STN Clause  and Depart Doc Rev*************\n");fflush(stdout);
	if(TCTYPE_ask_object_type(relObj,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\nSTN:     type_name [%s]\n", type_name);fflush(stdout);
	
	logical res = FALSE;
	ifail = t5STN_IsallowedToDeleteClauseRel(&res);
	
		
	if(!res)
	{
		EMH_store_error_s1(EMH_severity_error,ITK_err,"You don't have access to create STN Clause relation. Kindly contact PLM Admin..");
		printf("\n\n\tSTN: T5DeptDocHasClauseCreVal YYYY*********************You don't have access to create STN Clause relation *********************\n");fflush(stdout);
		return ITK_err;
	}
	
	return ifail;
	
}


/**********Ashis Das ************************/

/*-----------------------------------------------------------
 * FUNCTION:0 OPTIONAL
 *-----------------------------------------------------------*/
char* safe_ask_value_string(tag_t obj, const char* prop_name) {
    char* value = NULL;
    if (AOM_ask_value_string(obj, prop_name, &value) != ITK_ok) return NULL;
    return value;
}

/*-----------------------------------------------------------
 * FUNCTION:1 Get type name of object
 *-----------------------------------------------------------*/
char* get_object_type_name(tag_t obj) {
    tag_t type_tag = NULLTAG;
    char *type_name = NULL;
	int ifail = ITK_ok;
    ifail = TCTYPE_ask_object_type(obj, &type_tag);
    if (type_tag != NULLTAG) 
	{
		ifail = TCTYPE_ask_name2(type_tag, &type_name);
	}
    return type_name;
}


/*-----------------------------------------------------------
 * FUNCTION:2 Find DML (ChangeRequestRevision) from Change Task
 *-----------------------------------------------------------*/
void find_DML_from_task(tag_t taskRev, tag_t *dmlRev) {
    *dmlRev = NULLTAG;
    int n_refs = 0;
    tag_t *referencers = NULL;
	int ifail = ITK_ok;

    printf("\n[INFO] Finding DML referencing the Change Task...");fflush(stdout);
    ifail = GRM_list_primary_objects_only(taskRev, NULLTAG, &n_refs, &referencers);

    for (int i = 0; i < n_refs; i++) {
        char *type_name = get_object_type_name(referencers[i]);
        if (type_name && tc_strcmp(type_name, "ChangeRequestRevision") == 0) {
            *dmlRev = referencers[i];
            tag_t dmlItem = NULLTAG;
            char *dml_id = NULL, *dml_rev_id = NULL;

            ifail = ITEM_ask_item_of_rev(*dmlRev, &dmlItem);
            dml_id = safe_ask_value_string(dmlItem, "item_id");
            ifail = ITEM_ask_rev_id2(*dmlRev, &dml_rev_id);

            printf("\n[DEBUG]  Found DML: %s / %s", dml_id ? dml_id : "N/A", dml_rev_id ? dml_rev_id : "N/A");fflush(stdout);

            if (dml_id) MEM_free(dml_id);
            if (dml_rev_id) MEM_free(dml_rev_id);
            MEM_free(type_name);
            break;
        }
        if (type_name) MEM_free(type_name);
    }

    if (*dmlRev == NULLTAG)
        printf("\n[WARN] No ChangeRequestRevision found referencing this task.");fflush(stdout);

    if (referencers) MEM_free(referencers);
}

/*-----------------------------------------------------------
 * FUNCTION:3 Check if Solution Folder lookup is required - Whether correct rel type
 *-----------------------------------------------------------*/
int is_solution_folder_required(tag_t dmlRev) {
    char *rlstype = safe_ask_value_string(dmlRev, "t5_rlstype");
    int result = 0;

    if (rlstype) {
        if (tc_strcmp(rlstype, "KSP") == 0 || tc_strcmp(rlstype, "TSKR") == 0) {
            result = 1;
            printf("\n[INFO] DML Release Type: %s → Solution Folder required.", rlstype);fflush(stdout);
        } else {
            printf("\n[INFO] DML Release Type: %s → Solution Folder NOT required.", rlstype);fflush(stdout);
        }
        MEM_free(rlstype);
    } else {
        printf("Unable to read Release Type (t5_rlstype) from DML.");
    }
    return result;
}


/*-----------------------------------------------------------
 * FUNCTION:4 Get Solution Folder or directly linked SpareKits
 *-----------------------------------------------------------*/
void get_solution_items(tag_t taskRev, tag_t *solutionFolder, int *n_spares, tag_t **spareRevs) {
    *solutionFolder = NULLTAG;
    *n_spares = 0;
    *spareRevs = NULL;
	int stat = ITK_ok;

    tag_t relType = NULLTAG;
    stat = GRM_find_relation_type("CMHasSolutionItem", &relType);

    printf("\n[INFO] Finding Solution Items (Folder or SpareKit) from Change Task...");fflush(stdout);

    if (stat != ITK_ok || relType == NULLTAG) {
        printf("\n[WARN] Relation type 'CMHasSolutionItem' not found.");fflush(stdout);
        relType = NULLTAG;
    }

    int n_secondary_refs = 0;
    tag_t *secondaryObjs = NULL;
    stat = GRM_list_secondary_objects_only(taskRev, relType, &n_secondary_refs, &secondaryObjs);

    printf("\n[DEBUG]  Found %d secondary objects via CMHasSolutionItem.", n_secondary_refs);fflush(stdout);

    for (int i = 0; i < n_secondary_refs; i++) 
	{
        char *type_name = get_object_type_name(secondaryObjs[i]);
        char *obj_name  = safe_ask_value_string(secondaryObjs[i], "object_name");

        char *item_id = NULL, *rev_id = NULL;
        if (type_name && tc_strstr(type_name, "Revision")) 
		{
            tag_t item_tag = NULLTAG;
            if (ITEM_ask_item_of_rev(secondaryObjs[i], &item_tag) == ITK_ok && item_tag != NULLTAG)
                item_id = safe_ask_value_string(item_tag, "item_id");
            rev_id = safe_ask_value_string(secondaryObjs[i], "item_revision_id");
        }

        printf("\n[DEBUG]  Secondary object: Type=%s, ItemID=%s, RevID=%s, Name=%s",
              type_name ? type_name : "N/A",
              item_id ? item_id : "N/A",
              rev_id ? rev_id : "N/A",
              obj_name ? obj_name : "N/A");fflush(stdout);

        if (type_name && tc_strcmp(type_name, "Folder") == 0 && *solutionFolder == NULLTAG) {
            *solutionFolder = secondaryObjs[i];
            printf("\n[DEBUG]  Found Solution Folder: %s", obj_name ? obj_name : "N/A");
        }

        if (type_name && (tc_strcmp(type_name, "T5_SparKitRevision") == 0 || tc_strcmp(type_name, "Spare Kit Revision") == 0)) {
            (*n_spares)++;
            *spareRevs = (tag_t *) MEM_realloc(*spareRevs, (*n_spares) * sizeof(tag_t));
            (*spareRevs)[(*n_spares) - 1] = secondaryObjs[i];
            printf("\n[DEBUG]  Found SpareKit Revision directly linked: %s / %s",
                  item_id ? item_id : "N/A", rev_id ? rev_id : "N/A");
        }

        if (obj_name) MEM_free(obj_name);
        if (type_name) MEM_free(type_name);
        if (item_id) MEM_free(item_id);
        if (rev_id) MEM_free(rev_id);
    }

    if (secondaryObjs) MEM_free(secondaryObjs);

    if (*solutionFolder == NULLTAG && *n_spares == 0)
        printf("\n[WARN] No Folder or SpareKit Revisions found linked to Change Task.");fflush(stdout);
}


/*-----------------------------------------------------------
 * FUNCTION:5 Find SpareKit Revisions in Folder (if Folder exists)
 *-----------------------------------------------------------*/
void get_sparekit_revisions_from_folder(tag_t folder, int *n_spares, tag_t **spareRevs) {
    if (folder == NULLTAG) return;
    int n_contents = 0;
    tag_t *contents = NULL;
	int ifail = ITK_ok;

    ifail = AOM_ask_value_tags(folder, "contents", &n_contents, &contents);
    for (int i = 0; i < n_contents; i++) 
	{
        char *type_name = get_object_type_name(contents[i]);
        if (type_name && tc_strstr(type_name, "T5_SparKitRevision") != NULL) 
		{
            (*n_spares)++;
            *spareRevs = (tag_t *) MEM_realloc(*spareRevs, (*n_spares) * sizeof(tag_t));
            (*spareRevs)[(*n_spares) - 1] = contents[i];
        }
        if (type_name) MEM_free(type_name);
    }
    if (contents) MEM_free(contents);
}

/*-----------------------------------------------------------
 * FUNCTION:6 Hanging check only for 'ERC Review' parts
 *-----------------------------------------------------------*/
/*-----------------------------------------------------------
 * FUNCTION: check_where_used_design
 * PURPOSE : For a child part in ERC Review (T5_LcsReview),
 *           check if it's a Design Revision and if it has
 *           any Design Revision parent. If not → Hanging.
             if found design Revision parent then print Parent item number and revision id
 *-----------------------------------------------------------*/
int check_where_used_design(tag_t itemrev, const char* PartNo, const char* RevId)
{
    int is_hanging = 0;

    /* ------------------------------------------------------
       STEP 1: Check if child has 'T5_LcsReview' (ERC Review)
     ------------------------------------------------------ */
	 printf("\nSTEP 1: Check if child has 'T5_LcsReview' (ERC Review)\n");fflush(stdout);
    int n_status = 0;
    tag_t *status_list = NULL;
	int ifail = ITK_ok;
    ifail = AOM_ask_value_tags(itemrev, "release_status_list", &n_status, &status_list);

    int has_erc_status = 0;
    for (int i = 0; i < n_status; i++) {
        char *status_name = NULL;
        ifail = AOM_ask_value_string(status_list[i], "object_name", &status_name);

        if (status_name &&
           (tc_strcmp(status_name, "T5_LcsReview") == 0 ||
            tc_strcmp(status_name, "ERC Review") == 0)) {
            has_erc_status = 1;
        }

        if (status_name) MEM_free(status_name);
    }
    if (status_list) MEM_free(status_list);

    if (!has_erc_status) {
        printf("\n[INFO] Skipping %s / %s - not in 'T5_LcsReview' (ERC Review) status.\n",
               PartNo, RevId);fflush(stdout);
        return 0;
    }

    /* ------------------------------------------------------
       STEP 2: Check if child itself is a Design Revision
     ------------------------------------------------------ */
	printf("\nSTEP 2: Check if child itself is a Design Revision\n");fflush(stdout);
    tag_t type_tag = NULLTAG;
    char *type_name = NULL;

    ifail = TCTYPE_ask_object_type(itemrev, &type_tag);
    if (type_tag)
        ifail = TCTYPE_ask_name2(type_tag, &type_name);

    int is_design_child = 0;
    if (type_name &&
        (tc_strcmp(type_name, "Design Revision") == 0 ||
         tc_strcmp(type_name, "T5_DesignRevision") == 0)) {
        is_design_child = 1;
    }

    if (!is_design_child) {
        printf("\n[INFO] Skipping %s / %s - not a Design Revision type (type=%s)\n",
               PartNo, RevId, type_name ? type_name : "UNKNOWN");fflush(stdout);
        if (type_name) MEM_free(type_name);
        return 0;
    }

    if (type_name) MEM_free(type_name);

    /* ------------------------------------------------------
       STEP 3: Check if Design child has Design Revision parent(s)
     ------------------------------------------------------ */
	 
	printf("\nSTEP 3:Check if Design child has Design Revision parent(s)\n");fflush(stdout);
    int n_parents = 0;
    tag_t *parents = NULL;
    tag_t RevRuleObjTag = NULLTAG;
	int   *levels = 0;
    ifail = CFM_find("Latest Working", &RevRuleObjTag);

    ifail = PS_where_used_configured(itemrev, RevRuleObjTag, 1, &n_parents, &levels, &parents);

    if (n_parents <= 0) {
        printf("\n\033[1;31m [DEBUG]  Hanging Part (no parent found): %s / %s\033[0m\n", PartNo, RevId);fflush(stdout);
        if (parents) MEM_free(parents);
        return 1;
    }

    /* ------------------------------------------------------
       STEP 4: Verify if any parent is a Design Revision
       ------------------------------------------------------ */
    int has_design_parent = 0;
    for (int i = 0; i < n_parents; i++) {
        tag_t parent_type_tag = NULLTAG;
        char *parent_type_name = NULL;
        ifail = TCTYPE_ask_object_type(parents[i], &parent_type_tag);
        if (parent_type_tag)
            ifail = TCTYPE_ask_name2(parent_type_tag, &parent_type_name);

        if (parent_type_name &&
           (tc_strcmp(parent_type_name, "Design Revision") == 0 ||
            tc_strcmp(parent_type_name, "T5_DesignRevision") == 0)) {
            has_design_parent = 1;
        }

        if (parent_type_name) MEM_free(parent_type_name);
        if (has_design_parent) break;
    }

    if (!has_design_parent) {
        printf("\n\033[1;31m [DEBUG]  Hanging Part (no Design parent): %s / %s\033[0m\n", PartNo, RevId);fflush(stdout);
        is_hanging = 1;
    } else {
        printf("\n\033[1;32m [INFO]  %s / %s - used in Design Revision parent.\033[0m\n", PartNo, RevId);fflush(stdout);
    }

    if (parents) MEM_free(parents);
    return is_hanging;
}


/*-----------------------------------------------------------
 * FUNCTION:7 Traverse SpareKit BOM, print details, and check hanging and check if the child sp kit is attached to same DML
 *-----------------------------------------------------------*/
int process_sparekit_children(tag_t spareKitRev, int* hangingPartListCnt, char*** hangingPartList, int parntSpCnt, tag_t* parntSpRev,int* spChildAttachCnt, char*** spChildAttachCntList) {
    
    tag_t bom_window = NULLTAG, top_line = NULLTAG;
    int stat = ITK_ok;

    /* --- Print SpareKit details before expanding ---*/
    tag_t spare_item = NULLTAG;
    char *spare_id = NULL, *spare_rev_id = NULL, *spare_name = NULL;
    ITEM_ask_item_of_rev(spareKitRev, &spare_item);
    spare_id = safe_ask_value_string(spare_item, "item_id");
    spare_rev_id = safe_ask_value_string(spareKitRev, "item_revision_id");
    spare_name = safe_ask_value_string(spareKitRev, "object_name");

    printf("\n[INFO] Expanding BOM for SpareKit: %s / %s (%s)",
         spare_id ? spare_id : "N/A",
         spare_rev_id ? spare_rev_id : "N/A",
         spare_name ? spare_name : "N/A");fflush(stdout);

    stat = BOM_create_window(&bom_window);
    if (stat != ITK_ok || bom_window == NULLTAG) {
        printf("\n[ERROR]  Failed to create BOM window.");
        goto cleanup;
    }
	tag_t rule = NULLTAG;
	stat = CFM_find( "Latest Working", &rule );
	
	if(rule != NULLTAG)
	{
		stat = BOM_set_window_config_rule( bom_window, rule );
	}
	stat = BOM_set_window_pack_all (bom_window, false);
	
    stat = BOM_set_window_top_line(bom_window, NULLTAG, spareKitRev, NULLTAG, &top_line);
    if (stat != ITK_ok || top_line == NULLTAG) {
        printf("\n[WARN] Could not set top line for SpareKit. Skipping BOM traversal.");fflush(stdout);
        goto cleanup;
    }

    int n_children = 0;
    tag_t *children = NULL;
    stat = BOM_line_ask_child_lines(top_line, &n_children, &children);
    if (stat != ITK_ok) {
        printf("\n[WARN] Failed to get child lines for SpareKit.");fflush(stdout);
        goto cleanup;
    }

    printf("\n[DEBUG]  Found %d child(ren) under SpareKit.", n_children);fflush(stdout);

	
    /* --- Loop through each child --- */
    for (int i = 0; i < n_children; i++) 
	{
        if (children[i] == NULLTAG) continue;

        tag_t childRev = NULLTAG, childItem = NULLTAG;
        AOM_ask_value_tag(children[i], "bl_revision", &childRev);
        if (childRev == NULLTAG) continue;
        ITEM_ask_item_of_rev(childRev, &childItem);
        if (childItem == NULLTAG) continue;

		char *PartNo = safe_ask_value_string(childItem, "item_id");
        char *RevId  = safe_ask_value_string(childRev, "item_revision_id");
        char *ChildName = safe_ask_value_string(childRev, "object_name");
		char *ChildType = safe_ask_value_string(childRev, "object_type");

        printf("\n[INFO]  → Child[%d]: %-20s  Rev: %-5s  Name: %s Type: %s",
             i + 1,
             PartNo ? PartNo : "N/A",
             RevId ? RevId : "N/A",
             ChildName ? ChildName : "N/A",
			 ChildType ? ChildType : "N/A");fflush(stdout);

        /* --- Print all release statuses --- */
        //int n_status = 0;
        char *status_list = NULL;
        stat = AOM_UIF_ask_value(childRev, "release_status_list", &status_list);
		printf("\n Released status:[%s]\n",status_list);fflush(stdout);
		
		
		int flag = 0;		
		if(tc_strcmp(ChildType,"T5_SparKitRevision")==0)
		{
			if(tc_strstr(RevId,"NR")!=NULL && tc_strstr(spare_rev_id,"NR")!=NULL && (tc_strcmp(status_list,"T5_LcsReview")==0 || tc_strcmp(status_list,"ERC Review")==0))
			{
				//check whether this part is attached to task_rev
				flag = 0;
				for(int j=0;j<parntSpCnt;j++)
				{
					tag_t spPart = NULLTAG;
					spPart = parntSpRev[j];
					char *PrntPartNo = safe_ask_value_string(spPart, "item_id");
					char *PrntRevId  = safe_ask_value_string(spPart, "item_revision_id");
					
					 printf("\n[INFO]  → Parent[%d]: %-20s  Rev: %-5s",
					 i + 1,
					 PrntPartNo ? PrntPartNo : "N/A",
					 PrntRevId ? PrntRevId : "N/A");fflush(stdout);
					
					if(tc_strcmp(PrntPartNo,PartNo)==0 && tc_strcmp(PrntRevId,RevId)==0)
					{
						printf("\n Part[%s] is attached to DML Task\n",PartNo);fflush(stdout);
						//t5STN_SetAddStr(spChildAttachCnt,spChildAttachCntList,PartNo);
						flag++;
						break;
					}
					
					
					if (PrntPartNo) MEM_free(PrntPartNo);
					if (PrntRevId) MEM_free(PrntRevId);
					
				}
				if(flag<=0)
				{
					//not attached
					printf("\n Part[%s] is not attached to DML Task. Adding to the set\n",PartNo);fflush(stdout);
					t5STN_SetAddStr(spChildAttachCnt,spChildAttachCntList,PartNo);
				}
			}
			

		
		}

        


		int cnt = check_where_used_design(childRev, PartNo, RevId);
		
		if(cnt > 0)
		{
			t5STN_SetAddStr(hangingPartListCnt,hangingPartList,PartNo);
		}
        
        //total_hanging += check_where_used_design(childRev, PartNo, RevId);

        if (PartNo) MEM_free(PartNo);
        if (RevId) MEM_free(RevId);
        if (ChildName) MEM_free(ChildName);
		if (ChildType) MEM_free(ChildType);
    }
	
	


    if (children) MEM_free(children);

cleanup:
    if (bom_window) BOM_close_window(bom_window);
    if (spare_id) MEM_free(spare_id);
    if (spare_rev_id) MEM_free(spare_rev_id);
    if (spare_name) MEM_free(spare_name);

    return stat;
}



int perform_DML_hierarchy_check(tag_t task_rev , int *hangingPartListCnt, char*** hangingPartList,int* spChildAttachCnt, char*** spChildAttachCntList)
{
	int ifail = ITK_ok;
	tag_t dml_rev = NULLTAG;
	char* task_id = NULL;

	ifail = AOM_ask_value_string(task_rev,"item_id",&task_id);
	printf("\n[INFO] Starting DML hierarchy check for Task: %s", task_id);fflush(stdout);
    
	//Get the dml rev
    find_DML_from_task(task_rev, &dml_rev);
	//check applicable DML type
	if (dml_rev != NULLTAG && is_solution_folder_required(dml_rev))
	{
		 //applicable
		tag_t solution_folder = NULLTAG;
		int n_spares = 0;
		tag_t *spareRevs = NULL;
		 
		//printf("\nGetting the spare kit parts under solution folder of DML Task:[%s]\n",task_id);fflush(stdout);
		get_solution_items(task_rev, &solution_folder, &n_spares, &spareRevs);
		
		printf("\nNo of the spare kit parts under solution folder of DML Task:[%s]==> [%d]\n",task_id,n_spares);fflush(stdout);
		if (solution_folder != NULLTAG && n_spares == 0)
		{
			//Getting sp kit parts if solution folder exists.
			get_sparekit_revisions_from_folder(solution_folder, &n_spares, &spareRevs);
			printf("\nXXX:No of the spare kit parts under solution folder of DML Task:[%s]==> [%d]\n",task_id,n_spares);fflush(stdout);
		}
		else 
		{
			printf("\n[INFO] Solution Folder check skipped for this DML release type.");fflush(stdout);
		}
		
		//int total_hanging = 0;
		for (int i = 0; i < n_spares; i++) 
		{
			process_sparekit_children(spareRevs[i],hangingPartListCnt,hangingPartList,n_spares,spareRevs,spChildAttachCnt,spChildAttachCntList);
		}
		
		//*hangingPartCnt = total_hanging;
	}
	else 
	{
        printf("\n[INFO] Solution Folder check skipped for this DML release type.");fflush(stdout);
    }
	
	return ifail;
}

int isliveValidateSpKitHanging(tag_t *cntrlTag, logical *result)
{
	
	int ifail = ITK_ok;
	
	printf("\nCheck for control object for isliveValidateSpKitHanging....\n");fflush(stdout);
	*result = FALSE;
	int  count 	= 0;
	tag_t *contrlObjs = NULL;	
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	tag_t query = NULLTAG;
	
	qry_entries[0] = "SYSCD";
	qry_entries[1] = "SUBSYSCD";
	qry_entries[2] = "Delete Indicator";
	
	qry_values[0] = "HangVldSpKit";
	qry_values[1] = "HangVldSpKit";
	qry_values[2] = "FALSE";
		
	if(QRY_find2("Control Objects...", &query));
	if(QRY_execute(query, 3, qry_entries, qry_values, &count, &contrlObjs));
	printf("\nSPK:HangVldSpKit:Control objects HangVldSpKit: count==>%d", count);fflush(stdout);

		
	if(count>0)
	{
		tag_t cntrlObj = NULLTAG;
		cntrlObj = contrlObjs[0];
		
		if(cntrlObj!=NULLTAG)
		{			
			printf("\nSPK:HangVldSpKit: Live for STNRelStamp assignment\n");fflush(stdout);
			*result = TRUE;			
			*cntrlTag = cntrlObj;			
		}
		
	}
		
	
	return ifail;
}

EPM_decision_t tm_ValidateHangingChildSpKit( EPM_rule_message_t msg)
{
	EPM_decision_t	decision = EPM_go;
	int ifail = ITK_ok;
	const char * prog_name ="tm_ValidateHangingChildSpKit";
	tag_t rootTask = NULLTAG;
	tag_t* targetobjects = NULL;
	int targetobjects_count = 0;
	
	tag_t cntrlTag = NULLTAG;
	logical live = FALSE;
	ifail = isliveValidateSpKitHanging(&cntrlTag,&live);
	printf("\nSPK:tm_ValidateHangingChildSpKit is Live:[%d]",live);fflush(stdout);
	if(cntrlTag == NULLTAG || !live)
	{
		printf("\nNot Live: tm_ValidateHangingChildSpKit\n");fflush(stdout);
		return EPM_go;
	}
	
	ifail = EPM_ask_root_task(msg.task,&rootTask);

	ifail = EPM_ask_attachments(rootTask, EPM_target_attachment,&targetobjects_count, &targetobjects);
	
	if(targetobjects_count > 0)
	{
		int i = 0;
		tag_t objectTypeTag = NULLTAG;
		char  	*type_name = NULL;		
		for(i=0;i<targetobjects_count;i++)
		{
			tag_t DmlTaskObj = NULLTAG;
			char* task_id = NULL;
			DmlTaskObj = targetobjects[i];
			ifail = TCTYPE_ask_object_type (DmlTaskObj, &objectTypeTag);
			ifail = TCTYPE_ask_name2( objectTypeTag, &type_name);
		    printf("\nSPK:type_name ==> %s\n", type_name);fflush(stdout);
			TC_write_syslog("\nSPK:type_name ==> %s\n", type_name);
			
			if((tc_strcmp(type_name,"T5_ChangeTaskRevision")==0))
			{
				
				ifail = AOM_ask_value_string(DmlTaskObj,"item_id",&task_id);
				printf("\n DML Task ID:[%s]",task_id);fflush(stdout);
				
				int hangingPartListCnt =0;
				char** hangingPartList = NULL;
				
				int spChildAttachCnt =0;
				char** spChildAttachCntList = NULL;
				
				//perform_DML_hierarchy_check(tag_t task_rev, int* hangingPartCnt);
				//ifail = perform_DML_hierarchy_check(DmlTaskObj, &hangingPartListCnt,&hangingPartList);
				
				ifail = perform_DML_hierarchy_check(DmlTaskObj, &hangingPartListCnt,&hangingPartList,&spChildAttachCnt,&spChildAttachCntList);
				
				if(hangingPartListCnt > 0)
				{
					//show the error message;
					char* hangPartStr = (char*)MEM_alloc(hangingPartListCnt*sizeof(char)*40);
					tc_strcpy(hangPartStr,"");
					for(int j =0;j<hangingPartListCnt;j++)
					{
						
						tc_strcat(hangPartStr,hangingPartList[j]);
						tc_strcat(hangPartStr,",");
					}
					
					char* buff = NULL;
					ifail=T5_SpareKitDmlHandlerErr;
					buff = (char*)MEM_alloc(200*sizeof(char));
					printf("\nSPK:These parts[%s] under the spare kit structure is hanging.Please check with Admin",hangPartStr);fflush(stdout);
					sprintf(buff, "These parts[%s]under the spare kit structure is hanging.Please check with Admin", hangPartStr);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;
				}
				
				if(spChildAttachCnt > 0)
				{
					//show the error message;
					char* spKitPartStr = (char*)MEM_alloc(spChildAttachCnt*sizeof(char)*40);
					
					tc_strcpy(spKitPartStr,"");
					for(int j =0;j<spChildAttachCnt;j++)
					{
						
						tc_strcat(spKitPartStr,spChildAttachCntList[j]);
						tc_strcat(spKitPartStr,",");
					}
					
					char* buff = NULL;
					ifail=T5_SpKitNotAttachToDMLTask;
					buff = (char*)MEM_alloc(200*sizeof(char));
					printf("\nSPK:These NR and ERC Review spare kit parts[%s] under the spare kit structure is not attached to the same DML.Please check with Admin",spKitPartStr);fflush(stdout);
					sprintf(buff, "The child spare kit parts[%s] under the spare kit structure is not attached to the DML Task:[%s].Please check with Admin", spKitPartStr,task_id);
					EMH_store_error_s1(EMH_severity_error,ifail,buff);
					decision = EPM_nogo;
					if(buff)MEM_free(buff);
					return decision;
				}
				
				
				
			}
			
			
		}
	}
	
	return decision;
}

/**********Ashis Das ************************/


extern int certification_custom_exit(int *decision, va_list args)
{
    int ifail = ITK_ok;
  
	METHOD_id_t  method ;
	METHOD_id_t  method1 ;
	METHOD_id_t  stnCheckOutValMethod ;
	METHOD_id_t  method_STNRevise ;
	METHOD_id_t  method2 ;
	METHOD_id_t  methodDelRel ;
	METHOD_id_t  methodDelClauseRel ;
	METHOD_id_t  methodCreClauseRel ;
	METHOD_id_t  methodStnRev ;
	
    *decision = ALL_CUSTOMIZATIONS;  

	//printf("\nSTN: tm_Certification.c:it, via Custom Exits.\n");fflush(stdout);

	//if ( METHOD_find_method("T5_STNHeader", IMAN_save_msg, &method) !=ITK_ok);
	if ( METHOD_find_method("T5_STNHeader", "IMAN_save", &method) !=ITK_ok);//TC_save_msg
	
	
	if ( METHOD_find_method("T5_STNHeader", ITEM_create_msg, &method1) !=ITK_ok);
	if (method1.id != NULL)
	{
		
		
		if( METHOD_add_action(method1, METHOD_pre_action_type, (METHOD_function_t) Stn_PreValidationCreation, NULL)!=ITK_ok);

		if( ifail != ITK_ok )
		{

			EMH_store_error( EMH_severity_error, ifail );

		}

	}
	
	//Validation for updation 
	if(METHOD_find_method(RES_Type, RES_checkout_msg,&stnCheckOutValMethod) !=ITK_ok);
  
	if (stnCheckOutValMethod.id != NULL)
	{
		//printf("\nSTN:Inside stnCheckOutValMethod\n");	fflush(stdout);
		if( METHOD_add_action(stnCheckOutValMethod, METHOD_pre_action_type, (METHOD_function_t) stnCheckOutValidation, NULL)!=ITK_ok);
	}
	
  
	
	if (method.id != NULL)
	{
		
		
		//if( METHOD_add_action(method, METHOD_pre_action_type, (METHOD_function_t) Stn_PreValidation, NULL)!=ITK_ok);//Pre validation for STN id generation logic
		if( METHOD_add_pre_condition(method, (METHOD_function_t) Stn_PreValidation, NULL)!=ITK_ok);
		
		if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) Stn_Department_relation, NULL)!=ITK_ok);

		if( ifail != ITK_ok )
		{

			EMH_store_error( EMH_severity_error, ifail );

		}

	}
	
	//Action Handler 
	
	ifail = EPM_register_action_handler("tm_AssignAraiDesigner", "tm_AssignAraiDesigner",tm_AssignAraiDesignerFn);
	
	
	
	ifail = EPM_register_action_handler("tm_AssignAraiParticipants", "tm_AssignAraiParticipants",tm_AssignSTNParticipantsFn);
	//Action Handler to assigning Reviewer for STN Header/Dept Doc 
	
	//Stamp ERC Released on STN and its related departments and clauses.
	ifail = EPM_register_action_handler("tm_stnReleaseStamp", "tm_stnReleaseStamp",tm_stnReleaseStampFn);
	
	
	//For Revise of STN Header
	if(METHOD_find_method("T5_STNHeaderRevision", "ITEM_copy_rev", &method_STNRevise));
	 if (method_STNRevise.id != NULL)
    {
        if(METHOD_add_action(method_STNRevise, METHOD_post_action_type,(METHOD_function_t)STN_Revise_method_post,NULL));
		//printf("\nSTN: Registered as Revise_Post_Action method_STNRevise for Creation \n");fflush(stdout);
		
		 if(METHOD_add_action(method_STNRevise, METHOD_pre_action_type,(METHOD_function_t)STN_Revise_method_pre,NULL));
		//printf("\nSTN: Registered as Revise_Pre_Action method_STNRevise for Creation \n");fflush(stdout);
    }
	else
	{
        //printf("\nSTN: Method MatEngg not found! \n");fflush(stdout);
	}
	
	// Post action of STN Rev creation
	
	ifail = METHOD_find_method("T5_STNHeaderRevision", ITEM_create_msg, &method2);
   if (method2.id != NULL)
   {
		ifail = METHOD_add_action(method2, METHOD_post_action_type, (METHOD_function_t) createSTNRevObjectPostFun, NULL)!=ITK_ok;
		
		//printf("\nSTN:rrrrrrrrRegistered as Post-Action for T5_STNHeaderRevision Creation\n");fflush(stdout);
   }
   else
	{
		printf("\nSTN:Method not found!ITEM_create_msg\n");fflush(stdout);
	}
	
	
	//Restrict Delete Relation of STN Doc with STN Header
	
   ifail = METHOD_find_method("T5_StnHasDeptDoc", TC_delete_msg, &methodDelRel);
   if( ifail == ITK_ok )
   {
		if (methodDelRel.id != NULL)
		{
			if( METHOD_add_action(methodDelRel, METHOD_pre_action_type, (METHOD_function_t) T5StnHasDeptDocDeleteVal, NULL)!=ITK_ok)
			{
				//printf("Registered as METHOD_pre_action_type for T5StnHasDeptDocDeleteVal \n");fflush(stdout);
			}
				
		}
		else
		{
			printf("\nSTN:Method not found!TC_delete_msg... for T5_StnHasDeptDoc\n");fflush(stdout);
		}
   }

	//Restrict Delete Relation of STN Clause with STN Doc
	
   ifail = METHOD_find_method("T5_DeptDocHasClause", TC_delete_msg, &methodCreClauseRel);
   if( ifail == ITK_ok )
   {
		if (methodCreClauseRel.id != NULL)
		{
			if( METHOD_add_action(methodCreClauseRel, METHOD_pre_action_type, (METHOD_function_t) T5DeptDocHasClauseDeleteVal, NULL)!=ITK_ok)
			{
				//printf("Registered as METHOD_pre_action_type for T5DeptDocHasClauseDeleteVal \n");fflush(stdout);
			}
				
		}
		else
		{
			printf("\nSTN:Method not found!TC_delete_msg... for T5_DeptDocHasClause\n");fflush(stdout);
		}
   }
   
   //Restrict Paste Relation of STN Clause with STN Doc
   ifail = METHOD_find_method("T5_DeptDocHasClause", TC_save_msg, &methodDelClauseRel);
   if( ifail == ITK_ok )
   {
		if (methodDelClauseRel.id != NULL)
		{
			if( METHOD_add_action(methodDelClauseRel, METHOD_pre_action_type, (METHOD_function_t) T5DeptDocHasClauseCreVal, NULL)!=ITK_ok)
			{
				//printf("Registered as METHOD_pre_action_type for T5DeptDocHasClauseCreVal \n");fflush(stdout);
			}
				
		}
		else
		{
			printf("\nSTN:Method not found!TC_save_msg... for T5_DeptDocHasClause\n");fflush(stdout);
		}
   }


/* Overriding IMAN_Save of STN Header Revision for creating the department doc and relation with STN while creation */	
	ifail = METHOD_find_method("T5_STNHeaderRevision", "IMAN_save", &methodStnRev);		
	if (methodStnRev.id != NULL)
    {	
		//printf("\nSTN: before Rigister tm_create_stndeptdoc");fflush(stdout);
		ifail = METHOD_add_action(methodStnRev, METHOD_post_action_type,(METHOD_function_t)tm_create_stndeptdoc,NULL);
		//printf("\nSTN:  After Rigister tm_create_stndeptdoc");fflush(stdout);
    }
	else
	{
		printf("\nSTN: IMAN_save not found - NULL");fflush(stdout);
	}   

/****************Only STN Header revison should be allowed to submit *******************/

	ifail = EPM_register_rule_handler (
							"tm_IsValdSTNHeaderObject",
							"tm_IsValdSTNHeaderObject",
							(EPM_rule_handler_t)tm_IsValdSTNHeaderObject
							);	

/************CR - CR-FY26-0108-Enhancement Validation for Hanging ERC Review part under Spare kit_TCUA */

	ifail = EPM_register_rule_handler (
							"tm_ValidateHangingChildSpKit",
							"tm_ValidateHangingChildSpKit",
							(EPM_rule_handler_t)tm_ValidateHangingChildSpKit
							);	

/********************************* End CR-FY26-0108 *************************/
	
    return ifail;
}

/*****************assign stn participants  update **********************************/


int tm_assignSTNParticipantsServFunc(void *retValue)
{
	printf("\nSTN: SAN:Assign STN Participants:Start----tm_assignSTNParticipantsServFunc....\n");fflush(stdout);
	const char	*prog_name 	="tm_assignSTNParticipantsServFunc";	
	int ifail = ITK_ok;
	tag_t stnRevTag = NULLTAG;
	tag_t cntrlObj = NULLTAG;
	logical liveFlag = false;
	USERARG_get_tag_argument(&stnRevTag);
	
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	if(stnRevTag !=NULLTAG)
	{
		
		printf("\nSTN:Got STN Rev Tag....\n");fflush(stdout);
		
		isLiveForSTNPartAssign(&cntrlObj,&liveFlag);
		if(liveFlag && cntrlObj != NULLTAG)
		{
			
			char* userInfo1	=	NULL;
			char* userInfo2	= 	NULL;
			char* userInfo3	=	NULL;
			char* userInfo4	=	NULL;
			char* userInfo5	=	NULL;
			char* userInfo6	=	NULL;
			char* userInfo7	=	NULL;
			char* userInfo8	=	NULL;
			char* userInfo9	=	NULL;
			
			
			
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&userInfo1));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&userInfo2));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&userInfo3));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&userInfo4));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&userInfo5));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&userInfo6));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&userInfo7));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&userInfo8));
			if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&userInfo9));
			
			
			
			printf("\nSTN: STNParticip-STNParticip Control object information:\nSTN:t5_Userinfo1:[%s]\nSTN:t5_Userinfo2:[%s]\nSTN:t5_Userinfo3:[%s]\nSTN:t5_Userinfo4:[%s]\nSTN:t5_Userinfo5:[%s]\nSTN:t5_Userinfo6:[%s]\nSTN:t5_Userinfo7:[%s]\nSTN:t5_Userinfo8:[%s]\nSTN:t5_Userinfo9:[%s]\n",userInfo1,userInfo2,userInfo3,userInfo4,userInfo5,userInfo6,userInfo7,userInfo8,userInfo9);fflush(stdout);

			
			if(tc_strcmp(userInfo1,"LIVE")==0)
			{
				ifail = tm_assignSTNParticipants(stnRevTag);
				if(ifail == ITK_ok)
				{
					tc_strcpy(resultStr,"PASS");
				}
				else
				{
					tc_strcpy(resultStr,"FAILTOASSIGN");
				}
			}
			else
			{
				tc_strcpy(resultStr,"NOTLIVE");
			}
			
			

			

			
		}
		else
		{
			tc_strcpy(resultStr,"NOTLIVE");
		}
		
		
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:ANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("STNAssign - After returning Value\n");fflush(stdout);	

	printf("\nSTN: SAN:STN Participant Assign :End----tm_assignSTNParticipantsServFunc....\n");fflush(stdout);
	return ifail;	
	
}

/*************************Update Clause Table Attr from RAC *******************************/

int tmUpdateClauseTableServ(void *retValue)
{
	printf("\nSTN: SAN:Update Clause Table:Start----tmUpdateClauseTableServ....\n");fflush(stdout);
	const char	*prog_name 	="tmUpdateClauseTableServ";	
	int ifail = ITK_ok;
	tag_t clauseRevTag = NULLTAG;
	int colHeadSize = 0;
	char** colmnHeader = NULL;
	char** col1 = NULL;
	char** col2 = NULL;
	char** col3 = NULL;
	char** col4 = NULL;
	char** col5 = NULL;
	char** col6 = NULL;
	char** col7 = NULL;
	char** col8 = NULL;
	char** col9 = NULL;
	char** col10 = NULL;
	int colsize1 = 0;
	int colsize2 = 0;
	int colsize3 = 0;
	int colsize4 = 0;
	int colsize5 = 0;
	int colsize6 = 0;
	int colsize7 = 0;
	int colsize8 = 0;
	int colsize9 = 0;
	int colsize10 = 0;

	USERARG_get_tag_argument(&clauseRevTag);
	USERARG_get_string_array_argument(&colHeadSize,&colmnHeader);
	USERARG_get_string_array_argument(&colsize1, &col1);
	USERARG_get_string_array_argument(&colsize2, &col2);
	USERARG_get_string_array_argument(&colsize3, &col3);
	USERARG_get_string_array_argument(&colsize4, &col4);
	USERARG_get_string_array_argument(&colsize5, &col5);
	USERARG_get_string_array_argument(&colsize6, &col6);
	USERARG_get_string_array_argument(&colsize7, &col7);
	USERARG_get_string_array_argument(&colsize8, &col8);
	USERARG_get_string_array_argument(&colsize9, &col9);
	USERARG_get_string_array_argument(&colsize10, &col10);

	printf("\nSTN: colHeadSize[%d], colsize1[%d], colsize2[%d], colsize3[%d], colsize4[%d], colsize5[%d],colsize6[%d],colsize7[%d], colsize8[%d], colsize9[%d], colsize10[%d]\n", colHeadSize,colsize1,colsize2,colsize3,colsize4,colsize5,colsize6,colsize7,colsize8,colsize9,colsize10);fflush(stdout);
	
	int i =0;
	for(i=0;i<colsize2;i++)
	{
		printf("\nSTN: %s",col2[i]);fflush(stdout);
	}
	
	int n_table_rows = 0;
	tag_t* table_rowsTag = NULLTAG;
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );	
	
	ifail = AOM_ask_table_rows(clauseRevTag,"t5_colset", &n_table_rows,&table_rowsTag);
	if(n_table_rows > 0)
	{
		printf("no of table rows are %d \n", n_table_rows);
		int i=0;
		int j =0;
		char* colVal1 = NULL;
		char* colVal2 = NULL;
		char* colVal3 = NULL;
		char* colVal4 = NULL;
		char* colVal5 = NULL;
		char* colVal6 = NULL;
		char* colVal7 = NULL;
		char* colVal8 = NULL;
		char* colVal9 = NULL;
		char* colVal10 = NULL;
		
		for(i=0;i<n_table_rows;i++)
		{
			ifail = AOM_ask_value_string(table_rowsTag[i], "t5_col1", &colVal1);
			for(j=0;j<colsize1;j++)
			{
				printf("\nSTN: colVal1:[%s], col1[%d]: [%s]\n", colVal1,j,col1[j]);fflush(stdout);
				if(tc_strcmp(colVal1,col1[j])==0)
				{
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col2", &colVal2);
					printf("Old Value colVal2 for row no %d is %s\n",j,colVal2);
					printf("New Value colVal2 for row no %d is %s\n",j,col2[j]);
					
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col3", &colVal3);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col4", &colVal4);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col5", &colVal5);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col6", &colVal6);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col7", &colVal7);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col8", &colVal8);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col9", &colVal9);
					ifail = AOM_ask_value_string(table_rowsTag[j], "t5_col10", &colVal10);

					if(AOM_refresh(table_rowsTag[i], TRUE));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col2", col2[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col3", col3[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col4", col4[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col5", col5[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col6", col6[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col7", col7[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col8", col8[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col9", col9[j]));
					if(AOM_set_value_string(table_rowsTag[i], "t5_col10", col10[j]));
					//if(AOM_save(table_rowsTag[i]));
					if(AOM_save_with_extensions(table_rowsTag[i]));
					if(AOM_refresh(table_rowsTag[i], FALSE));
					printf("\nSTN:Update Success ..");fflush(stdout);
					break;
				}
			}
			
			
		}
		
		
		tc_strcpy(resultStr,"PASS");
	}
	else
	{
		printf("\nSTN:No Table Row found....No need to update.Exiting...\n");fflush(stdout);
		
		tc_strcpy(resultStr,"NOROW");
	}
	

	


	
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:ANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("Update Clause Table - After returning Value\n");fflush(stdout);	

	printf("\nSTN: SAN:Update Clause Table:END----tmUpdateClauseTableServ....\n");fflush(stdout);
	return ifail;	
	
}

/******************End Update Clause Table **********************************************/



/******************Copy Dept Doc to Other Logic **********************************/


int tmCopyDeptDocToOtherServ(void *retValue)
{
	printf("\nSTN: SAN:Copy Dept Doc to other:Start----tmCopyDeptDocToOtherServ....\n");fflush(stdout);
	const char	*prog_name 	="tmCopyDeptDocToOtherServ";	
	int ifail = ITK_ok;
	tag_t srcDeptTag = NULLTAG;
	tag_t destDeptTag = NULLTAG;

	USERARG_get_tag_argument(&srcDeptTag);
	USERARG_get_tag_argument(&destDeptTag);

	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	if(srcDeptTag !=NULLTAG && destDeptTag != NULLTAG)
	{
		
		printf("\nSTN:Got the source  and Target Dept Doc Tag.... \n");fflush(stdout);
		
		//Implement the logic
		tag_t depToClsRelType = NULLTAG;
		int srcClauseCnt = 0;
		tag_t* srcClauseTags = NULLTAG;
		
		int destClauseCnt = 0;
		tag_t* destClauseTags = NULLTAG;
		
		if(GRM_find_relation_type("T5_DeptDocHasClause", &depToClsRelType)!=ITK_ok)PrintErrorStack();
		
		//Get the clauses of source dept doc
		if(GRM_list_secondary_objects_only(srcDeptTag,depToClsRelType,&srcClauseCnt,&srcClauseTags)!=ITK_ok)PrintErrorStack();
		
		//Get the clauses of target dept doc		
		if(GRM_list_secondary_objects_only(destDeptTag,depToClsRelType,&destClauseCnt,&destClauseTags)!=ITK_ok)PrintErrorStack();
		
		if(destClauseCnt > 0)
		{
			int i=0;
			
			for(i=0;i<destClauseCnt;i++)
			{
				tag_t destClauseTag = NULLTAG;
				char* destClsNo = NULL;
				char* destClsType = NULL;
				int j =0;
				
				destClauseTag = destClauseTags[i];
				
				ifail = AOM_ask_value_string(destClauseTag,"object_name",&destClsNo);
				ifail = AOM_ask_value_string(destClauseTag,"t5_ClauseType",&destClsType);
				
				for(j=0;j<srcClauseCnt;j++)
				{
					tag_t srcClauseTag = NULLTAG;
					char* srcClsNo = NULL;
					char* srcClsType = NULL;
					
					srcClauseTag = srcClauseTags[j];
					
				
					ifail = AOM_ask_value_string(srcClauseTag,"object_name",&srcClsNo);
					
					ifail = AOM_ask_value_string(srcClauseTag,"t5_ClauseType",&srcClsType);
					
					if(tc_strcmp(destClsNo,srcClsNo)==0)
					{

						char* srcClsValue = NULL;
						ifail = AOM_ask_value_string(srcClauseTag,"t5_ClauseValue",&srcClsValue);
						
						ifail = AOM_lock(destClauseTag);
						ifail = AOM_set_value_string(destClauseTag,"t5_ClauseValue",srcClsValue);						
						ifail = AOM_save_without_extensions(destClauseTag);
						
						ifail = AOM_refresh(destClauseTag,0);
						ifail = AOM_unlock(destClauseTag);
						
						if(tc_strcmp(srcClsType,"Table")==0 && tc_strcmp(destClsType,"Table")==0)
						{
							int src_n_table_rows = 0;
							tag_t* src_table_rowsTag = NULLTAG;
							int dest_n_table_rows = 0;
							tag_t* dest_table_rowsTag = NULLTAG;
							printf("\nSTN: Coying Table Clause Value of %s \n",srcClsNo);fflush(stdout);
							
							ifail = AOM_ask_table_rows(srcClauseTag,"t5_colset", &src_n_table_rows,&src_table_rowsTag);
							printf("\nSTN: Src: no of table rows are %d \n", src_n_table_rows);
							
							ifail = AOM_ask_table_rows(destClauseTag,"t5_colset", &dest_n_table_rows,&dest_table_rowsTag);
							printf("\nSTN: dest: no of table rows are %d \n", dest_n_table_rows);
							
							if(src_n_table_rows > 0)
							{
								int ii =0;
								char* colVal1 = NULL;
								char* colVal2 = NULL;
								char* colVal3 = NULL;
								char* colVal4 = NULL;
								char* colVal5 = NULL;
								char* colVal6 = NULL;
								char* colVal7 = NULL;
								char* colVal8 = NULL;
								char* colVal9 = NULL;
								char* colVal10 = NULL;								
								
								for(ii=0;ii<src_n_table_rows;ii++)
								{
									ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col1", &colVal1);
									printf("\nSTN: Src: colVal1[%s] \n", colVal1);
									
									int jj =0;
									char* dcolVal1 = NULL;
									
									for(jj=0;jj<dest_n_table_rows;jj++)
									{
										ifail = AOM_ask_value_string(dest_table_rowsTag[jj], "t5_col1", &dcolVal1);
										printf("\nSTN: dest: dcolVal1[%s] \n", dcolVal1);
										
										if(tc_strcmp(colVal1,dcolVal1)==0)
										{
											
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col2", &colVal2);
											printf("Old Value colVal2 for row no %d is %s\n",j,colVal2);
											

											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col3", &colVal3);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col4", &colVal4);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col5", &colVal5);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col6", &colVal6);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col7", &colVal7);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col8", &colVal8);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col9", &colVal9);
											ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col10", &colVal10);
											
											if(AOM_refresh(dest_table_rowsTag[jj], TRUE));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col2", colVal2));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col3", colVal3));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col4", colVal4));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col5", colVal5));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col6", colVal6));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col7", colVal7));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col8", colVal8));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col9", colVal9));
											if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col10", colVal10));
											//if(AOM_save(dest_table_rowsTag[jj]));
											if(AOM_save_with_extensions(dest_table_rowsTag[jj]));
											if(AOM_refresh(dest_table_rowsTag[jj], FALSE));
											printf("\nSTN: Update Success ..");fflush(stdout);
											break;											
											
										}
									}
								}
							}
						}
						
						ifail = AOM_refresh(destClauseTag,FALSE);
					}
					
				}
				
			}
		}
		
		
	
		tc_strcpy(resultStr,"PASS");
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:ANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("Copy Dept Doc - After returning Value\n");fflush(stdout);	

	printf("\nSTN: SAN:Copy Dept Doc to other:END----tmCopyDeptDocToOtherServ....\n");fflush(stdout);
	return ifail;	
	
}





/***********************Copy STN Header to Other Logic ************************************/

int tmCopySTNHeaderToOtherServ(void *retValue)
{
	printf("\nSTN: SAN:Copy Dept Doc to other:Start----tmCopySTNHeaderToOtherServ....\n");fflush(stdout);
	const char	*prog_name 	="tmCopySTNHeaderToOtherServ";	
	int ifail = ITK_ok;
	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	
	tag_t srcSTNRevTag = NULLTAG;
	tag_t destSTNRevTag = NULLTAG;

	USERARG_get_tag_argument(&srcSTNRevTag);
	USERARG_get_tag_argument(&destSTNRevTag);
	
	

	if(srcSTNRevTag !=NULLTAG && destSTNRevTag != NULLTAG)
	{
		printf("\nSTN: Inside STN copy logic ..\n");fflush(stdout);
		
		//Get the Department docs
		
		tag_t stnToDeptRelType = NULLTAG;
		
		ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
		
		if(stnToDeptRelType != NULLTAG)
		{
			int srcDeptDocRevCnt = 0;
			tag_t *srcDeptDocRevTags = NULL;
			
			int destDeptDocRevCnt = 0;
			tag_t *destDeptDocRevTags = NULL;
			
			ifail = GRM_list_secondary_objects_only(srcSTNRevTag,stnToDeptRelType,&srcDeptDocRevCnt,&srcDeptDocRevTags);
			
			
			ifail = GRM_list_secondary_objects_only(destSTNRevTag,stnToDeptRelType,&destDeptDocRevCnt,&destDeptDocRevTags);
			
			
			printf("\nSTN: No of Department doc of Src STN: [%d]\n",srcDeptDocRevCnt);fflush(stdout);
			printf("\nSTN: No of Department doc of Dest STN: [%d]\n",destDeptDocRevCnt);fflush(stdout);
			
			int srcCnt = 0;
			int destCnt = 0;
			
			for(srcCnt = 0; srcCnt < srcDeptDocRevCnt ; srcCnt++)
			{
				tag_t srcDeptTag = NULLTAG;
				tag_t destDeptTag = NULLTAG;
				char* srcDeptNo = NULL;
				srcDeptTag = srcDeptDocRevTags[srcCnt];
				
				ifail = AOM_ask_value_string(srcDeptTag,"t5_Department", &srcDeptNo);
				
				
				for(destCnt = 0; destCnt < destDeptDocRevCnt ; destCnt++)
				{
					char* destDeptNo = NULL;
					destDeptTag = destDeptDocRevTags[destCnt];
					
					ifail = AOM_ask_value_string(destDeptTag,"t5_Department", &destDeptNo);
					
					if(tc_strcmp(srcDeptNo,destDeptNo)==0)
					{
						printf("\nSTN: Copying the department[%s] from Src to target\n",srcDeptNo);fflush(stdout);
						if(srcDeptTag !=NULLTAG && destDeptTag != NULLTAG)
						{
							
							
							//Implement the logic
							tag_t depToClsRelType = NULLTAG;
							int srcClauseCnt = 0;
							tag_t* srcClauseTags = NULL;
							
							int destClauseCnt = 0;
							tag_t* destClauseTags = NULL;
							
							if(GRM_find_relation_type("T5_DeptDocHasClause", &depToClsRelType)!=ITK_ok)PrintErrorStack();
							
							//Get the clauses of source dept doc
							if(GRM_list_secondary_objects_only(srcDeptTag,depToClsRelType,&srcClauseCnt,&srcClauseTags)!=ITK_ok)PrintErrorStack();
							
							//Get the clauses of target dept doc		
							if(GRM_list_secondary_objects_only(destDeptTag,depToClsRelType,&destClauseCnt,&destClauseTags)!=ITK_ok)PrintErrorStack();
							
							if(destClauseCnt > 0)
							{
								int i=0;
								
								for(i=0;i<destClauseCnt;i++)
								{
									tag_t destClauseTag = NULLTAG;
									char* destClsNo = NULL;
									char* destClsType = NULL;
									int j =0;
									
									destClauseTag = destClauseTags[i];
									
									ifail = AOM_ask_value_string(destClauseTag,"object_name",&destClsNo);
									ifail = AOM_ask_value_string(destClauseTag,"t5_ClauseType",&destClsType);
									
									for(j=0;j<srcClauseCnt;j++)
									{
										tag_t srcClauseTag = NULLTAG;
										char* srcClsNo = NULL;
										char* srcClsType = NULL;
										
										srcClauseTag = srcClauseTags[j];
										
									
										ifail = AOM_ask_value_string(srcClauseTag,"object_name",&srcClsNo);
										
										ifail = AOM_ask_value_string(srcClauseTag,"t5_ClauseType",&srcClsType);
										
										if(tc_strcmp(destClsNo,srcClsNo)==0)
										{

											char* srcClsValue = NULL;
											ifail = AOM_ask_value_string(srcClauseTag,"t5_ClauseValue",&srcClsValue);
											
											ifail = AOM_lock(destClauseTag);
											ifail = AOM_set_value_string(destClauseTag,"t5_ClauseValue",srcClsValue);						
											ifail = AOM_save_without_extensions(destClauseTag);
											
											ifail = AOM_refresh(destClauseTag,0);
											ifail = AOM_unlock(destClauseTag);
											if(tc_strcmp(srcClsType,"Table")==0 && tc_strcmp(destClsType,"Table")==0)
											{
												int src_n_table_rows = 0;
												tag_t* src_table_rowsTag = NULL;
												int dest_n_table_rows = 0;
												tag_t* dest_table_rowsTag = NULL;
												printf("\nSTN: Coying Table Clause Value of %s \n",srcClsNo);fflush(stdout);
												
												ifail = AOM_ask_table_rows(srcClauseTag,"t5_colset", &src_n_table_rows,&src_table_rowsTag);
												printf("\nSTN: Src: no of table rows are %d \n", src_n_table_rows);
												
												ifail = AOM_ask_table_rows(destClauseTag,"t5_colset", &dest_n_table_rows,&dest_table_rowsTag);
												printf("\nSTN: dest: no of table rows are %d \n", dest_n_table_rows);
												
												if(src_n_table_rows > 0)
												{
													int ii =0;
													char* colVal1 = NULL;
													char* colVal2 = NULL;
													char* colVal3 = NULL;
													char* colVal4 = NULL;
													char* colVal5 = NULL;
													char* colVal6 = NULL;
													char* colVal7 = NULL;
													char* colVal8 = NULL;
													char* colVal9 = NULL;
													char* colVal10 = NULL;								
													
													for(ii=0;ii<src_n_table_rows;ii++)
													{
														ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col1", &colVal1);
														printf("\nSTN: Src: colVal1[%s] \n", colVal1);
														
														int jj =0;
														char* dcolVal1 = NULL;
														
														for(jj=0;jj<dest_n_table_rows;jj++)
														{
															ifail = AOM_ask_value_string(dest_table_rowsTag[jj], "t5_col1", &dcolVal1);
															printf("\nSTN: dest: dcolVal1[%s] \n", dcolVal1);
															
															if(tc_strcmp(colVal1,dcolVal1)==0)
															{
																
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col2", &colVal2);
																printf("Old Value colVal2 for row no %d is %s\n",j,colVal2);
																

																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col3", &colVal3);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col4", &colVal4);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col5", &colVal5);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col6", &colVal6);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col7", &colVal7);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col8", &colVal8);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col9", &colVal9);
																ifail = AOM_ask_value_string(src_table_rowsTag[ii], "t5_col10", &colVal10);
																
																if(AOM_refresh(dest_table_rowsTag[jj], TRUE));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col2", colVal2));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col3", colVal3));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col4", colVal4));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col5", colVal5));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col6", colVal6));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col7", colVal7));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col8", colVal8));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col9", colVal9));
																if(AOM_set_value_string(dest_table_rowsTag[jj], "t5_col10", colVal10));
																//if(AOM_save(dest_table_rowsTag[jj]));
																if(AOM_save_with_extensions(dest_table_rowsTag[jj]));
																if(AOM_refresh(dest_table_rowsTag[jj], FALSE));
																printf("\nSTN: Update Success ..");fflush(stdout);
																break;											
																
															}
														}
													}
												}
											}
											
											ifail = AOM_refresh(destClauseTag,FALSE);
										}
										
									}
									
								}
							}
							
							
						
							tc_strcpy(resultStr,"PASS");
						}
						else
						{
							tc_strcpy(resultStr,"FAIL");
						}
					
					}
					
				}
			}
			
		}
		
		
		
		
	
		
		
	}
	
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:ANX: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("Copy Dept Doc - After returning Value\n");fflush(stdout);	

	printf("\nSTN: SAN:Copy STN Headerto other:END----tmCopySTNHeaderToOtherServ....\n");fflush(stdout);
	return ifail;	
	
}



/*******************************Old STN Update ********************************************/
int CreateMissingClause(tag_t* clsMstrTagList, int clsMstrTagListCnt,tag_t STNHeaderRev, tag_t Latest_Deptrev )
{
	int ifail = ITK_ok;
	char* StnHdrNum = NULL;
	char* StnHdrDesc = NULL;
	char* DeptDocNum = NULL;
	char* StnPlant = NULL;
	
/*******************Get STN HEader and Dept Doc  related properties *******************/
	if (AOM_ask_value_string(STNHeaderRev,"item_id",&StnHdrNum)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(STNHeaderRev,"object_desc",&StnHdrDesc)!=ITK_ok)   PrintErrorStack();
	if (AOM_ask_value_string(STNHeaderRev,"t5_StnArPlant",&StnPlant)!=ITK_ok)   PrintErrorStack();
	
	if (AOM_ask_value_string(Latest_Deptrev,"item_id",&DeptDocNum)!=ITK_ok)   PrintErrorStack();
	
	if (clsMstrTagListCnt > 0)
	{
		int ccv = 0;
		tag_t ClauseMstrTag = NULLTAG;
		char* ClauseDes = NULL;
		char* ClauseNo = NULL;
		char* ClsDataType = NULL;
		char* ClsFurthClassification = NULL;
		char* ClsIsLable = NULL;
		char* ClsRefClause = NULL;
		char* ClsRefClsDesc = NULL;
		char* ClsEnterColms = NULL;
		char* ClsEnterRows = NULL;
		char* ClsOldClNum = NULL;
		char* ClsOldUpd = NULL;
		char* ClsExtSort = NULL;
		
		for (ccv=0;ccv<clsMstrTagListCnt;ccv++ )
		{
			//printf("\nSTN: Inside 00000000  VCcnt is ============= [%d]  \n",VCcnt); fflush(stdout);
			ClauseMstrTag = clsMstrTagList[ccv];
			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemDes",&ClauseDes)!=ITK_ok);
			printf("\nSTN: ClauseDes============ [%s]  \n",ClauseDes); fflush(stdout);
			
			if( AOM_ask_value_string(ClauseMstrTag,"object_name",&ClauseNo)!=ITK_ok);
			printf("\nSTN: Clause No============ [%s]  \n",ClauseNo); fflush(stdout);
			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemType",&ClsDataType)!=ITK_ok);
			printf("\nSTN: Clause Data Type============ [%s]  \n",ClsDataType); fflush(stdout);

			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClasuemClassification",&ClsFurthClassification)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemIslable",&ClsIsLable)!=ITK_ok);				
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemRefCl",&ClsRefClause)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemRefClDes",&ClsRefClsDesc)!=ITK_ok);			
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArTbCol",&ClsEnterColms)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArTbRow",&ClsEnterRows)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemOldClNum",&ClsOldClNum)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemArUpdate",&ClsOldUpd)!=ITK_ok);
			if( AOM_ask_value_string(ClauseMstrTag,"t5_ClausemExtSort",&ClsExtSort)!=ITK_ok);
					
			
			/************Create Clause Revision ***************************/
			tag_t ClauseRevTagType = NULLTAG;
			tag_t ClaRevCreInp = NULLTAG;
			tag_t ClgTagType = NULLTAG;
			tag_t ClgTagItm = NULLTAG;
			tag_t MainClauseObj = NULLTAG;
			tag_t Latest_Clauserev = NULLTAG;
			
			TCTYPE_find_type("T5_ClauseRevision", NULL, &ClauseRevTagType);
			
			if(ClauseRevTagType != NULLTAG)
			{
				//printf("\nSTN: ClauseRevTagType Tag Found.");
			}
			
			TCTYPE_construct_create_input(ClauseRevTagType, &ClaRevCreInp);   

			ifail = AOM_set_value_string(ClaRevCreInp, "item_revision_id", "A;1");
			ifail = AOM_set_value_string(ClaRevCreInp, "sequence_id", "1"); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClaDes", ClauseDes);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArHNum", StnHdrNum); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseHeaderDesc", StnHdrDesc); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArDNum", DeptDocNum); 
			ifail = AOM_set_value_string(ClaRevCreInp, "object_desc", ClauseDes); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_IsClassified", ClsFurthClassification); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseRefDesc", ClsRefClsDesc); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseRefClNum", ClsRefClause); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_DummyClNum", ClsRefClause); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseArPlant", StnPlant); 
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseNum", ClauseNo);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ClauseType", ClsDataType);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_IsLable", ClsIsLable);
			ifail = AOM_set_value_string(ClaRevCreInp, "t5_ArTbCol", ClsEnterColms);
			
			
			

			TCTYPE_find_type("T5_Clause", NULL, &ClgTagType);    
			if(ClgTagType != NULLTAG)
			{
				printf("\nSTN:  ClgTagType Tag Found. \n");fflush(stdout);
			}
			TCTYPE_construct_create_input(ClgTagType, &ClgTagItm);
			
			printf("\nSTN:  Now set propertied on Clause Item \n ");fflush(stdout);
			ifail = AOM_set_value_string(ClgTagItm, "object_name", ClauseNo);
			printf("\nSTN: Now Object Creation of Clause  started  \n ");fflush(stdout);
			
			TCTYPE_create_object(ClgTagItm, &MainClauseObj);

			printf("\nSTN:  Executin for Clause ---  \n ");fflush(stdout);

			if(MainClauseObj != NULLTAG)
			{
				printf("\n \n\nSTN: **** Main Clause Doc Object Created successfully. **** \n\n \n ");fflush(stdout);
				
				if(AOM_save_with_extensions(MainClauseObj));
				if(AOM_refresh(MainClauseObj,0));
				if(AOM_unlock(MainClauseObj));		
				//if(AOM_refresh(MainClauseObj,1));
					
			}				
			

			if(ITEM_ask_latest_rev(MainClauseObj, &Latest_Clauserev)!=ITK_ok)PrintErrorStack();

			if(Latest_Clauserev != NULLTAG)
			{
				ifail = AOM_lock(Latest_Clauserev);
				printf("\nSTN: 7676 Inside the latest Latest_Clauserev tag Exists   \n");fflush(stdout);
				
				//If revision is NR then set as A
				char* ClauseRevStr = NULL;
				ifail = AOM_ask_value_string(Latest_Clauserev, "item_revision_id", &ClauseRevStr);
				printf("\nSTN: Before set: Clause Revision : %s\n",ClauseRevStr);fflush(stdout);
				//Set initial revision as A
				ifail = AOM_set_value_string(Latest_Clauserev,"item_revision_id", "A;1");
				
				ifail = AOM_ask_value_string(Latest_Clauserev, "item_revision_id", &ClauseRevStr);
				printf("\nSTN: After Set: Clause Revision : %s\n",ClauseRevStr);fflush(stdout);
				
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClaDes", ClauseDes);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArHNum", StnHdrNum); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseHeaderDesc", StnHdrDesc); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArDNum", DeptDocNum); 
				ifail = AOM_set_value_string(Latest_Clauserev, "object_desc", ClauseDes); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_IsClassified", ClsFurthClassification); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseRefDesc", ClsRefClsDesc); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseRefClNum", ClsRefClause); 
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClNum", ClsRefClause);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClauseNum", ClsRefClause);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseArPlant", StnPlant);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseNum", ClauseNo);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseType", ClsDataType);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_IsLable", ClsIsLable);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_ArTbCol", ClsEnterColms);
				
				if(tc_strcmp(ClsDataType,"String")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5StrACl");
					if(tc_strcmp(ClsIsLable,"Y")==0) 
					{
						ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseValue", "IsLable");
					}					
				}
				else if(tc_strcmp(ClsDataType,"Table")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5FtbACl");
				}
				else if(tc_strcmp(ClsDataType,"Dummy")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5DtACl");
					if(tc_strcmp(ClsIsLable,"Y")==0) 
					{
						ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseValue", "IsLable");
					}					
					
				}
				else if(tc_strcmp(ClsDataType,"Attachment")==0)
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5PctACl");
				}
				else
				{
					ifail = AOM_set_value_string(Latest_Clauserev, "t5_ClauseClass", "t5StrACl");
				}
				
				
				//################################## t5DummyClNum setting for report sorting #####
				
				char* sClNum2 = NULL;
				int xlength = 0;
				char* sClNum3 = NULL;
				char* sClNum4 = NULL;
				int flag = 0;
				tc_strdup(ClauseNo,&sClNum2);
				xlength=tc_strlen(sClNum2)+1;
				
				sClNum3=(char*)MEM_alloc(xlength*sizeof(char) + 5);
				sClNum4=(char*)MEM_alloc(xlength*sizeof(char) + 5);
				
				if ((*(sClNum2+0) == 'D' && *(sClNum2+1) == '1' && 	*(sClNum2+2) == '.' &&  *(sClNum2+3) == '5' && *(sClNum2+4) == '.') && 
				(*(sClNum2+6) == '.'|| *(sClNum2+6) == '\0' ) )
				{
					//printf("\nSTN:\nCondition is true for the below clause\n\n\n",*(sClNum2));
					flag=1;
					//clausecounter ++;
					//printf("clausecounter =%d",clausecounter);
				}
				else
				{
					
				}	
				if(*(sClNum2+2) == '.' || xlength==3)
				{
					int i=0;
					sClNum4=sClNum3;	    	   		
					for(i=0;i<xlength;i++)
					{
						if(i==1)
						{
							*sClNum3='0';      		    	   		   
							sClNum3++;
						}
						if(i==5 && flag==1)
						{
						   *sClNum3='0';      		    	   		   
								   sClNum3++;
						   flag=0;
						}
						else 
						{
							*sClNum3=*sClNum2;    
							sClNum2++;
							sClNum3++; 
						}      		    	   		     		    	   		  
					}
					*sClNum3='\0';   
				}
				else if((tc_strcmp(ClsFurthClassification,"DUMMY FOR TABLE 8")==0) && (tc_strcmp(ClsDataType,"Dummy")==0))
				{
					tc_strcpy(sClNum4,ClsExtSort);
				}
				else
				{
					tc_strcpy(sClNum4,sClNum2);
				}
				
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClNum", sClNum4);
				ifail = AOM_set_value_string(Latest_Clauserev, "t5_DummyClauseNum", sClNum4);
				
				//if(sClNum3!=NULL)MEM_free(sClNum3);
				//if(sClNum4!=NULL)MEM_free(sClNum4);
				if(sClNum3!=NULL)
				{
					if(tc_strlen(sClNum3)>0) MEM_free(sClNum3);
				}
				if(sClNum4!=NULL)
				{
					if(tc_strlen(sClNum4)>0) MEM_free(sClNum4);
				}				
				
				//dummyclause no set end
				
				
				if(AOM_save_with_extensions(Latest_Clauserev));
				if(AOM_refresh(Latest_Clauserev,0));
				if(AOM_unlock(Latest_Clauserev));		
				//if(AOM_refresh(Latest_Clauserev,1));
				
				
				/***************** Start - Table property insert*****************************/
				
				if(tc_strcmp(ClsDataType,"Table")==0)
				{
					printf("\nSTN:Sanjoy - update table row....\n");fflush(stdout);
					ifail = AOM_refresh(Latest_Clauserev, TRUE);
					
					int num_rows_to_insert = 0;
					int row_new_index = 0;
					tag_t* table_rows_tag = NULL;
					int property_index = 0;
					
					
					char* stnRow = NULL;
					
					//stnRow = (char*)MEM_alloc(tc_strlen(ClsEnterRows)*sizeof(char) + 50*sizeof(char));
					stnRow = (char*)MEM_alloc(1000*sizeof(char));
					
					if(ClsEnterRows == NULL) ClsEnterRows = "";
					printf("\nSTN:sClsEnterRows==>[%s]\n",ClsEnterRows);fflush(stdout);
					if(tc_strlen(ClsEnterRows)>0)
					{
						
						tc_strcpy(stnRow,ClsEnterRows);
						
						printf("\nSTN:stnRow==>[%s]\n",stnRow);fflush(stdout);
						char ** rowList = NULL;
						int rowCnt = 0;
						
						char *token = tc_strtok(stnRow, ",");
						while(token != NULL) {
							printf("token[%s]\n", token);fflush(stdout);
							if(token !=NULL) 
							{
								if(!(tc_strcmp(token,"")==0)) t5STN_SetAddStr(&rowCnt,&rowList,token);
							}
							token = tc_strtok(NULL, ",");
							
							
						}
						
						
						printf("\nSTN: rowCnt ===> %d\n",rowCnt);fflush(stdout);
						
						num_rows_to_insert = rowCnt;
						printf("\nSTN: num_rows_to_insert ===> %d\n",num_rows_to_insert);fflush(stdout);
						//ifail = AOM_append_table_rows(Latest_Clauserev, "t5_colset",num_rows_to_append, &row_new_index, &table_rows_tag );
						ifail = AOM_refresh(Latest_Clauserev, TRUE);
						printf("ifail-refresh is %d\n",ifail);
						ifail = (AOM_insert_table_rows(Latest_Clauserev,"t5_colset",0,num_rows_to_insert,&table_rows_tag ));
						//TC_write_syslog (" \n ifail is %s\n",ifail);
						printf("ifail is %d\n",ifail);
						

						for ( property_index = 0 ; property_index < num_rows_to_insert; property_index++ )
						{
							printf("\nSTN: rowList[%d]==> [%s]\n",property_index,rowList[property_index]);fflush(stdout);
							
							if(table_rows_tag [ property_index ] != NULLTAG)
							{
								printf("\nSTN:Table row tag is NOT NULLTAG.\n");fflush(stdout);
								//set value on table row tag
								ifail = AOM_set_value_string(table_rows_tag [ property_index ], "t5_col1", rowList[property_index] );
								ifail = AOM_save_with_extensions(table_rows_tag[property_index]);
								printf("ifail11 is %d\n",ifail);fflush(stdout);								
								
							}
							else
							{
								printf("\nSTN:Table row tag is NULLTAG.\n");fflush(stdout);
							}

						}
											
						
												
						
					}

				
					MEM_free(stnRow);
					
					ifail = AOM_refresh(Latest_Clauserev, FALSE);
				}

				
							
							
				/***************** End - Table property insert*****************************/					

			}

		
			if(Latest_Deptrev != NULLTAG)
			{
				printf("\nSTN: Inside the latest Department Doc Tag Exists   \n");fflush(stdout);

			}

			printf("\nSTN:Creating Relationship between Depart Doc and Clause Rev **** \n\n \n ");fflush(stdout);
							
			ifail = t5STN_RelatePrimaryWithSecondaryObj(Latest_Deptrev,Latest_Clauserev,"T5_DeptDocHasClause");
			
			if(ifail == ITK_ok)
			{
				//printf("\nSTN:RELATIONSHIP CREATED between department doc and Clause Rev \n");fflush(stdout);
				printf("\nSTN:Rel created: [%d - [%s%s] - [%s]",ccv+1,DeptDocNum,StnHdrNum,ClauseNo);fflush(stdout);
			}
			else
			{
				printf("\nSTN:RELATIONSHIP NOT CREATED between department doc and Clause Rev \n");fflush(stdout);
			}
			
					

			
			
			
		}
	}
	
	
	
	return ifail;	
}

int oldStnUpdateFun_old(tag_t stnHeaderRevTag)
{
	int ifail = ITK_ok;
	printf("\nSTN:Old STN Update main funtion logic starts here.....\n");fflush(stdout);
	
	//Get the STN Type.
	char* stnNo = NULL;
	char* vehType = NULL;
	
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNo);
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType", &vehType);
	
	if(tc_strlen(vehType) > 0)
	{
		//Get the department docs
		tag_t stnToDeptRelType = NULLTAG;
		
		ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
		if(stnToDeptRelType != NULLTAG)
		{
			int deptDocRevCnt = 0;
			tag_t *deptDocRevTags = NULL;
			int i = 0;
			ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
			
			for(i=0; i<deptDocRevCnt; i++)
			{
				tag_t deptDocRevTag = NULLTAG;
				char* deptNo = NULL;
				char* deptDocNo = NULL;
				tag_t deptToClauseRelType = NULLTAG;
				deptDocRevTag = deptDocRevTags[i];
				
				//Get the department no.
				ifail = AOM_ask_value_string(deptDocRevTag,"t5_Department",&deptNo);
				ifail = AOM_ask_value_string(deptDocRevTag,"item_id",&deptDocNo);
				
				printf("\nSTN:Department Doc [%s] - Dept No:[%s]\n",deptDocNo,deptNo);fflush(stdout);
				
				//Get Clause Revisions.
				ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
				
				if(deptToClauseRelType != NULLTAG)
				{
					tag_t* clsRevTags = NULL;
					int clsRevTagCnt = 0;
					ifail = GRM_list_secondary_objects_only(deptDocRevTag,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
					printf("\nSTN: Clause Rev Tag count: [%d]\n", clsRevTagCnt);fflush(stdout);
					//ifail = updateOldClause(deptDocRevTag,vehType,clsRevTagCnt,clsRevTags);
					
					
					//Get the Deartment Master Rev Tag.
					tag_t deptMasterRevTag = NULLTAG;
					ifail = getDeptMasterRevTag(deptNo, &deptMasterRevTag);					
					
					tag_t DeptMasterClsRelType = NULLTAG;
				    if(tc_strcmp(vehType,"Cars/SUV")==0)
					{
						//Get the Clause Master Tags.
						
						ifail = GRM_find_relation_type("T5_hasClauseMaster", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"HCV")==0)
					{
						ifail = GRM_find_relation_type("T5_hasHCVClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"FBV")==0)
					{
						ifail = GRM_find_relation_type("T5_hasFBVClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"MUV/LCV ABOVE 3.5 Ton")==0)
					{
						ifail = GRM_find_relation_type("T5_hasAbvClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"MUV/LCV UPTO 3.5 Ton")==0)
					{
						ifail = GRM_find_relation_type("T5_hasBelowClause", &DeptMasterClsRelType);
					}
					else
					{
						printf("\nSTN: Wrong Relation Type...\n");fflush(stdout);
					}					
					
					
					if(DeptMasterClsRelType != NULLTAG && deptMasterRevTag != NULLTAG)
					{
						int clsMstrCnt = 0;
						tag_t* clsMstrRevTags = NULL;
						ifail = GRM_list_secondary_objects_only(deptMasterRevTag,DeptMasterClsRelType,&clsMstrCnt,&clsMstrRevTags);
						
						printf("\nSTN: Clause Master Rev Tag count: [%d]\n", clsMstrCnt);fflush(stdout);
						
						//object_name
						
						int k = 0;
						int k1=0;
						int clsMstrListCnt = 0;
						char** clsMstrList = NULL;
						int clsMstrTagListCnt = 0;
						tag_t* clsMstrTagList = NULL;
						int clsRevListCnt = 0;
						char** clsRevList = NULL;
						int clsRevTagListCnt = 0;
						tag_t* clsRevTagList = NULL;						
						for(k =0; k<clsMstrCnt ; k++)
						{
							tag_t clsMstrTag = NULLTAG;							
							char* clsMstrNo = NULL;
							int l = 0;
							int flag = 0;
							clsMstrTag = clsMstrRevTags[k];
							ifail = AOM_ask_value_string(clsMstrTag,"object_name",&clsMstrNo);
							
							for(l=0; l<clsRevTagCnt;l++)
							{
								tag_t clsRevTag = NULLTAG;
								char* clsRevNo = NULL;
								
								clsRevTag = clsRevTags[l];								
								ifail = AOM_ask_value_string(clsRevTag,"object_name",&clsRevNo);
								
								if(tc_strcmp(clsMstrNo,clsRevNo)==0)
								{
									//printf("\nSTN:SAN:clsMstrNo:[%s], clsRevNo:[%s]",clsMstrNo,clsRevNo);fflush(stdout);
									//check if any description is changed
									
									flag = 1;
									break;
								}
								
								
								
							}
						
							if(flag == 1)
							{
								t5STN_SetAddStr(&clsMstrListCnt,&clsMstrList,clsMstrNo);
							}
							else
							{
								//The below clause Master are not present
								t5STN_SetAddTagObj(&clsMstrTagListCnt, &clsMstrTagList,clsMstrTag);
							}
							
							
							
						}
						
						
						
						for(k1 =0; k1<clsRevTagCnt ; k1++)
						{

							int l1 = 0;
							int flag = 0;							
							tag_t clsRevTag = NULLTAG;
							char* clsRevNo = NULL;
							char* clsRevDesc = NULL;
							
							clsRevTag = clsRevTags[k1];								
							ifail = AOM_ask_value_string(clsRevTag,"object_name",&clsRevNo);
							ifail = AOM_ask_value_string(clsRevTag,"t5_ClaDes",&clsRevDesc);
							
							for(l1=0; l1<clsMstrCnt;l1++)
							{
								tag_t clsMstrTag = NULLTAG;							
								char* clsMstrNo = NULL;								
								clsMstrTag = clsMstrRevTags[l1];
								ifail = AOM_ask_value_string(clsMstrTag,"object_name",&clsMstrNo);							
								if(tc_strcmp(clsMstrNo,clsRevNo)==0)
								{
									//printf("\nSTN:SAN:clsMstrNo1:[%s], clsRevNo1:[%s]",clsMstrNo,clsRevNo);fflush(stdout);
									//check if any description is changed
									char* clsMstrDesc = NULL;
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemDes",&clsMstrDesc);
									
									if(tc_strcmp(clsMstrDesc,clsRevDesc)!=0)
									{
										printf("\nSTN:Update the Clause revision with new description.\n");fflush(stdout);
										ifail = AOM_lock(clsRevTag);										
										ifail = AOM_set_value_string(clsRevTag,"t5_ClaDes",clsMstrDesc);										
										ifail = AOM_save_without_extensions(clsRevTag);
										
										ifail = AOM_refresh(clsRevTag,0);
										ifail = AOM_unlock(clsRevTag);
									}
									
									flag = 1;
									break;
								}
								
								
								
							}
						
							if(flag == 1)
							{
								t5STN_SetAddStr(&clsRevListCnt,&clsRevList,clsRevNo);
							}
							else
							{
								//The below clause Master are not present
								t5STN_SetAddTagObj(&clsRevTagListCnt, &clsRevTagList,clsRevTag);
							}
							
							
						}
						
						printf("\nSTN: clsMstrListCnt ==> [%d] \n", clsMstrListCnt);fflush(stdout);
						
						printf("\nSTN: New Master: clsMstrTagListCnt ==> [%d] \n", clsMstrTagListCnt);fflush(stdout);
						
						if(clsMstrTagListCnt > 0)
						{
							printf("\nSTN: Create New Clauses and relate to the STN Doc\n");fflush(stdout);
							//To be done.
							
							ifail = CreateMissingClause(clsMstrTagList, clsMstrTagListCnt,stnHeaderRevTag,deptDocRevTag );
						}
							
						printf("\nSTN: clsRevListCnt ==> [%d] \n", clsRevListCnt);fflush(stdout);
						
						printf("\nSTN: Extra Cls Rev: clsRevTagListCnt ==> [%d] \n", clsRevTagListCnt);fflush(stdout);
						
						if(clsRevTagListCnt > 0)
						{
							printf("\nSTN: Delete Extra Clauses of the STN Doc\n");fflush(stdout);
							int m = 0;
							for(m=0;m<clsRevTagListCnt;m++)
							{
								tag_t clsRelTag = NULLTAG;
								
								ifail = GRM_find_relation(deptDocRevTag,clsRevTagList[m],deptToClauseRelType,&clsRelTag);
					
								if(clsRelTag != NULLTAG)
								{
									ifail = GRM_delete_relation(clsRelTag);
								}
								
								//Get Item
								tag_t clsRevObjMstr = NULLTAG;
								ifail = ITEM_ask_item_of_rev(clsRevTagList[m], &clsRevObjMstr);
								if(clsRevObjMstr!=NULLTAG)
								{
									ifail = ITEM_delete_item(clsRevObjMstr);
									printf("\nSTN:Deleted successfull...\n");fflush(stdout);
								}
								else
								{
									printf("\nSTN:Not deleted...\n");fflush(stdout);
								}								

								
							}
						}
							
						
					}
					
					
					
				}
				
			}
			
		}
		
		
		
	}
	else
	{
		printf("\nSTN:SAN:Error!!!!. Check with admin, Vehicle Type of STN[%s] is blank or null\n",stnNo);fflush(stdout);
	}
	
	
	return ifail;
}

int isAnyChangeInTableRow(int clsRevRowListCnt,char**clsRevRowList, char* ClsEnterRows,logical *flagRow)
{
	int ifail = ITK_ok;
	*flagRow = FALSE;
	char* stnRow = NULL;
					
	//stnRow = (char*)MEM_alloc(tc_strlen(ClsEnterRows)*sizeof(char) + 50*sizeof(char));
	stnRow = (char*)MEM_alloc(3000*sizeof(char));
	if(ClsEnterRows == NULL) ClsEnterRows = "";
	//printf("\nSTN:sClsEnterRows==>[%s]\n",ClsEnterRows);fflush(stdout);
	if(tc_strlen(ClsEnterRows)>0)
	{
		
		tc_strcpy(stnRow,ClsEnterRows);
		
		printf("\nSTN:STN Clause Master Row values==>[%s]\n",stnRow);fflush(stdout);
		char ** rowList = NULL;
		int rowCnt = 0;
		
		char *token = tc_strtok(stnRow, ",");
		while(token != NULL) {
			//printf("STN:token[%s]\n", token);fflush(stdout);
			if(token !=NULL) 
			{
				if(!(tc_strcmp(token,"")==0)) t5STN_SetAddStr(&rowCnt,&rowList,token);
			}
			token = tc_strtok(NULL, ",");
			
			
		}
		
		if(rowCnt != clsRevRowListCnt)
		{
			printf("\nSTN:diffenrent counts: rowCnt[%d], clsRevRowListCnt[%d]",rowCnt,clsRevRowListCnt);fflush(stdout);
			*flagRow = TRUE;
			return ifail;
		}
		
		int i=0;
		int j = 0;
		int flag = 0;
		for(i=0;i<rowCnt;i++)
		{
			char* rowVal = NULL;
			rowVal = rowList[i];
			flag = 0;
			for(j=0;j<clsRevRowListCnt;j++)
			{
				char *clsRowVal = NULL;
				clsRowVal = clsRevRowList[j];
				flag = 0;
				
				if(tc_strcmp(rowVal,clsRowVal)==0)
				{
					flag = 1;
					break;
				}
			}
			
			if(flag == 0)
			{
				printf("\nPerfect match table property\n");fflush(stdout);
				*flagRow = TRUE;
				break;
			}
		}
		
		if(flag == 1)
		{
			*flagRow = FALSE;
		}
	}

	
	return ifail;
}

int oldStnUpdateFun(tag_t stnHeaderRevTag)
{
	int ifail = ITK_ok;
	printf("\nSTN: 111.. Old STN Update main funtion logic starts here.....\n");fflush(stdout);
	
	//Get the STN Type.
	char* stnNo = NULL;
	char* vehType = NULL;
	char* StnHdrDesc = NULL;
	
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNo);
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType", &vehType);
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&StnHdrDesc);
	
	if(tc_strlen(vehType) > 0)
	{
		//Get the department docs
		tag_t stnToDeptRelType = NULLTAG;
		
		ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
		if(stnToDeptRelType != NULLTAG)
		{
			int deptDocRevCnt = 0;
			tag_t *deptDocRevTags = NULLTAG;
			int i = 0;
			ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
			
			for(i=0; i<deptDocRevCnt; i++)
			{
				tag_t deptDocRevTag = NULLTAG;
				char* deptNo = NULL;
				char* deptDocNo = NULL;
				tag_t deptToClauseRelType = NULLTAG;
				deptDocRevTag = deptDocRevTags[i];
				
				//Get the department no.
				ifail = AOM_ask_value_string(deptDocRevTag,"t5_Department",&deptNo);
				ifail = AOM_ask_value_string(deptDocRevTag,"item_id",&deptDocNo);
				
				printf("\nSTN:Department Doc [%s] - Dept No:[%s]\n",deptDocNo,deptNo);fflush(stdout);
				
				//Get Clause Revisions.
				ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
				
				if(deptToClauseRelType != NULLTAG)
				{
					tag_t* clsRevTags = NULLTAG;
					int clsRevTagCnt = 0;
					ifail = GRM_list_secondary_objects_only(deptDocRevTag,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
					printf("\nSTN: Clause Rev Tag count: [%d]\n", clsRevTagCnt);fflush(stdout);
					//ifail = updateOldClause(deptDocRevTag,vehType,clsRevTagCnt,clsRevTags);
					
					
					//Get the Deartment Master Rev Tag.
					tag_t deptMasterRevTag = NULLTAG;
					ifail = getDeptMasterRevTag(deptNo, &deptMasterRevTag);					
					
					tag_t DeptMasterClsRelType = NULLTAG;
				    if(tc_strcmp(vehType,"Cars/SUV")==0)
					{
						//Get the Clause Master Tags.
						
						ifail = GRM_find_relation_type("T5_hasClauseMaster", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"HCV")==0)
					{
						ifail = GRM_find_relation_type("T5_hasHCVClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"FBV")==0)
					{
						ifail = GRM_find_relation_type("T5_hasFBVClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"MUV/LCV ABOVE 3.5 Ton")==0)
					{
						ifail = GRM_find_relation_type("T5_hasAbvClause", &DeptMasterClsRelType);
					}
					else if(tc_strcmp(vehType,"MUV/LCV UPTO 3.5 Ton")==0)
					{
						ifail = GRM_find_relation_type("T5_hasBelowClause", &DeptMasterClsRelType);
					}
					else
					{
						printf("\nSTN: Wrong Relation Type...\n");fflush(stdout);
					}					
					
					
					if(DeptMasterClsRelType != NULLTAG && deptMasterRevTag != NULLTAG)
					{
						int clsMstrCnt = 0;
						tag_t* clsMstrRevTags = NULLTAG;
						ifail = GRM_list_secondary_objects_only(deptMasterRevTag,DeptMasterClsRelType,&clsMstrCnt,&clsMstrRevTags);
						
						printf("\nSTN: Clause Master Rev Tag count: [%d]\n", clsMstrCnt);fflush(stdout);
						
						//object_name
						
						int k = 0;
						int k1=0;
						int clsMstrListCnt = 0;
						char** clsMstrList = NULL;
						int clsMstrTagListCnt = 0;
						tag_t* clsMstrTagList = NULLTAG;
						int clsRevListCnt = 0;
						char** clsRevList = NULL;
						int clsRevTagListCnt = 0;
						tag_t* clsRevTagList = NULLTAG;
						
						char** clsRevTblCls = NULL;
						int clsRevTblClsCnt = 0;
						
						char** clsMstrTblCls = NULL;
						int clsMstrTblClsCnt = 0;
						
						for(k =0; k<clsMstrCnt ; k++)
						{
							tag_t clsMstrTag = NULLTAG;							
							char* clsMstrNo = NULL;
							int l = 0;
							int flag = 0;
							clsMstrTag = clsMstrRevTags[k];
							ifail = AOM_ask_value_string(clsMstrTag,"object_name",&clsMstrNo);
							
							for(l=0; l<clsRevTagCnt;l++)
							{
								tag_t clsRevTag = NULLTAG;
								char* clsRevNo = NULL;
								
								clsRevTag = clsRevTags[l];								
								ifail = AOM_ask_value_string(clsRevTag,"object_name",&clsRevNo);
								
								if(tc_strcmp(clsMstrNo,clsRevNo)==0)
								{

									flag = 1;
									break;
								}
								
								
								
							}
						
							if(flag == 1)
							{
								t5STN_SetAddStr(&clsMstrListCnt,&clsMstrList,clsMstrNo);
							}
							else
							{
								//The below clause Master are not present
								t5STN_SetAddTagObj(&clsMstrTagListCnt, &clsMstrTagList,clsMstrTag);
							}
							
							
							
						}
						
						
						
						for(k1 =0; k1<clsRevTagCnt ; k1++)
						{

							int l1 = 0;
							int flag = 0;
							int tableFlag = 0;
							tag_t clsRevTag = NULLTAG;
							char* clsRevNo = NULL;
							char* clsRevDesc = NULL;
							char* clsRevType = NULL;
							char* clsRevValue = NULL;
							
							char* clsRevRowValue = NULL;
							char* clsRevColValue = NULL;
							
							clsRevTag = clsRevTags[k1];								
							ifail = AOM_ask_value_string(clsRevTag,"object_name",&clsRevNo);
							ifail = AOM_ask_value_string(clsRevTag,"t5_ClaDes",&clsRevDesc);
							ifail = AOM_ask_value_string(clsRevTag, "t5_ClauseType", &clsRevType);
							ifail = AOM_ask_value_string(clsRevTag, "t5_ClauseValue", &clsRevValue);
							
							ifail = AOM_ask_value_string(clsRevTag, "t5_ArTbCol", &clsRevColValue);
							ifail = AOM_ask_value_string(clsRevTag, "t5_colset", &clsRevRowValue);
							//printf("\nSTN:clsRevRowValue: [%s]",clsRevRowValue);fflush(stdout);
							
							int n_table_rows = 0;
							tag_t* table_rowsTag = NULLTAG;

							ifail = AOM_ask_table_rows(clsRevTag,"t5_colset", &n_table_rows,&table_rowsTag);
							int p = 0;
							char** clsRevRowList = NULL;
							int clsRevRowListCnt = 0;
							for(p=0;p<n_table_rows;p++)
							{
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[p];
								char* colVal1 = NULL;
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								t5STN_SetAddStr(&clsRevRowListCnt,&clsRevRowList,colVal1);
							}
							
							
							
							for(l1=0; l1<clsMstrCnt;l1++)
							{
								tableFlag = 0;
								tag_t clsMstrTag = NULLTAG;							
								char* clsMstrNo = NULL;								
								clsMstrTag = clsMstrRevTags[l1];
								ifail = AOM_ask_value_string(clsMstrTag,"object_name",&clsMstrNo);							
								if(tc_strcmp(clsMstrNo,clsRevNo)==0)
								{
									char* clsMstrDesc = NULL;
									char* ClsDataType = NULL;
									char* ClsFurthClassification = NULL;
									char* ClsIsLable = NULL;
									char* ClsRefClause = NULL;
									char* ClsRefClsDesc = NULL;
									char* ClsEnterColms = NULL;
									char* ClsEnterRows = NULL;
									char* ClsOldClNum = NULL;
									char* ClsOldUpd = NULL;
									char* ClsExtSort = NULL;									
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemDes",&clsMstrDesc);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClasuemClassification",&ClsFurthClassification);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemType",&ClsDataType);		
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemIslable",&ClsIsLable);				
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemRefCl",&ClsRefClause);			
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemRefClDes",&ClsRefClsDesc);			
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemArTbCol",&ClsEnterColms);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemArTbRow",&ClsEnterRows);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemOldClNum",&ClsOldClNum);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemArUpdate",&ClsOldUpd);
									ifail = AOM_ask_value_string(clsMstrTag,"t5_ClausemExtSort",&ClsExtSort);							
									
									//printf("\nSTN:Update the Clause revision with new description.\n");fflush(stdout);
									ifail = AOM_lock(clsRevTag);										
									ifail = AOM_set_value_string(clsRevTag,"t5_ClaDes",clsMstrDesc);
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseArHNum", stnNo); 
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseHeaderDesc", StnHdrDesc); 
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseArDNum", deptDocNo); 
									ifail = AOM_set_value_string(clsRevTag, "object_desc", clsMstrDesc); 
									ifail = AOM_set_value_string(clsRevTag, "t5_IsClassified", ClsFurthClassification); 
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseRefDesc", ClsRefClsDesc); 
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseRefClNum", ClsRefClause); 
									ifail = AOM_set_value_string(clsRevTag, "t5_DummyClNum", ClsRefClause); 
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseArPlant", "PUNE");
									ifail = AOM_set_value_string(clsRevTag, "t5_ClauseNum", clsMstrNo);
									//
									ifail = AOM_set_value_string(clsRevTag, "t5_IsLable", ClsIsLable);
									ifail = AOM_set_value_string(clsRevTag, "t5_ArTbCol", ClsEnterColms);
									
									if(tc_strcmp(ClsDataType,"String")==0)
									{
										ifail = AOM_set_value_string(clsRevTag, "t5_ClauseClass", "t5StrACl");
										if(tc_strcmp(ClsIsLable,"Y")==0) 
										{
											ifail = AOM_set_value_string(clsRevTag, "t5_ClauseValue", "IsLable");
										}
										else if(tc_strcmp(ClsIsLable,"N")==0) 
										{
											if(tc_strcmp(clsRevValue,"IsLable")==0)
											{
												ifail = AOM_set_value_string(clsRevTag, "t5_ClauseValue", "");
											}
											
										}										
									}
									else if(tc_strcmp(ClsDataType,"Table")==0)
									{
										ifail = AOM_set_value_string(clsRevTag, "t5_ClauseClass", "t5FtbACl");
									}
									else if(tc_strcmp(ClsDataType,"Dummy")==0)
									{
										ifail = AOM_set_value_string(clsRevTag, "t5_ClauseClass", "t5DtACl");
										if(tc_strcmp(ClsIsLable,"Y")==0) 
										{
											ifail = AOM_set_value_string(clsRevTag, "t5_ClauseValue", "IsLable");
										}
										else if(tc_strcmp(ClsIsLable,"N")==0) 
										{
											if(tc_strcmp(clsRevValue,"IsLable")==0)
											{
												ifail = AOM_set_value_string(clsRevTag, "t5_ClauseValue", "");
											}
											
										}										
										
									}
									else if(tc_strcmp(ClsDataType,"Attachment")==0)
									{
										ifail = AOM_set_value_string(clsRevTag, "t5_ClauseClass", "t5PctACl");
									}
									else
									{
										ifail = AOM_set_value_string(clsRevTag, "t5_ClauseClass", "t5StrACl");
									}

									
									//################################## t5DummyClNum setting for report sorting #####
				
									char* sClNum2 = NULL;
									int xlength = 0;
									char* sClNum3 = NULL;
									char* sClNum4 = NULL;
									int flag1 = 0;
									tc_strdup(clsRevNo,&sClNum2);
									xlength=tc_strlen(sClNum2)+1;
									
									sClNum3=(char*)MEM_alloc(xlength*sizeof(char));
									sClNum4=(char*)MEM_alloc(xlength*sizeof(char));
									
									if ((*(sClNum2+0) == 'D' && *(sClNum2+1) == '1' && 	*(sClNum2+2) == '.' &&  *(sClNum2+3) == '5' && *(sClNum2+4) == '.') && 
									(*(sClNum2+6) == '.'|| *(sClNum2+6) == '\0' ) )
									{
										//printf("\nSTN:\nCondition is true for the below clause\n\n\n",*(sClNum2));
										flag1=1;
										//clausecounter ++;
										//printf("clausecounter =%d",clausecounter);
									}
									else
									{
										
									}	
									if(*(sClNum2+2) == '.' || xlength==3)
									{
										int i=0;
										sClNum4=sClNum3;	    	   		
										for(i=0;i<xlength;i++)
										{
											if(i==1)
											{
												*sClNum3='0';      		    	   		   
												sClNum3++;
											}
											if(i==5 && flag1==1)
											{
											   *sClNum3='0';      		    	   		   
													   sClNum3++;
											   flag1=0;
											}
											else 
											{
												*sClNum3=*sClNum2;    
												sClNum2++;
												sClNum3++; 
											}      		    	   		     		    	   		  
										}
										*sClNum3='\0';   
									}
									else if((tc_strcmp(ClsFurthClassification,"DUMMY FOR TABLE 8")==0) && (tc_strcmp(ClsDataType,"Dummy")==0))
									{
										tc_strcpy(sClNum4,ClsExtSort);
									}
									else
									{
										tc_strcpy(sClNum4,sClNum2);
									}
									
									ifail = AOM_set_value_string(clsRevTag, "t5_DummyClNum", sClNum4);
									ifail = AOM_set_value_string(clsRevTag, "t5_DummyClauseNum", sClNum4);
																		
									if(tc_strcmp(ClsDataType,clsRevType)==0)
									{
										//printf("\nSTN: Same Data Type...\n");fflush(stdout);
										
										//check if any row is modified. If yes then delete the table clause and create a new one.
										if(tc_strcmp(ClsDataType,"Table")==0)
										{
											logical flagRow = FALSE;
											
											ifail = isAnyChangeInTableRow(clsRevRowListCnt,clsRevRowList,ClsEnterRows,&flagRow);
											
											if(flagRow)
											{
												printf("\nSTN:Sanjoy 111 - delete the table clause and create a new one ....\n");fflush(stdout);
												t5STN_SetAddTagObj(&clsMstrTagListCnt, &clsMstrTagList,clsMstrTag);
												tableFlag = 1;
												t5STN_SetAddStr(&clsMstrTblClsCnt,&clsMstrTblCls,clsMstrNo);
											}
											
											
											
												
										}
										
									}
									else
									{
										/***************** Start - Table property insert*****************************/
										
										if(tc_strcmp(ClsDataType,"Table")==0)
										{
											printf("\nSTN:Sanjoy - delete the table clause and create a new one ....\n");fflush(stdout);
											t5STN_SetAddTagObj(&clsMstrTagListCnt, &clsMstrTagList,clsMstrTag);
											tableFlag = 1;
											t5STN_SetAddStr(&clsMstrTblClsCnt,&clsMstrTblCls,clsMstrNo);
										}
										else
										{
											ifail = AOM_set_value_string(clsRevTag, "t5_ClauseType", ClsDataType);
										}

									}
																		
									ifail = AOM_save_with_extensions(clsRevTag);
									ifail = AOM_unlock(clsRevTag);
									ifail = AOM_refresh(clsRevTag,0);
									
									flag = 1;
									break;
								}
								
								
								
							}
						
							if(flag == 1)
							{
								t5STN_SetAddStr(&clsRevListCnt,&clsRevList,clsRevNo);
								if(tableFlag == 1)
								{
									t5STN_SetAddStr(&clsRevTblClsCnt,&clsRevTblCls,clsRevNo);
									
									t5STN_SetAddTagObj(&clsRevTagListCnt, &clsRevTagList,clsRevTag);
								}
							}
							else
							{
								//The below clause Master are not present
								t5STN_SetAddTagObj(&clsRevTagListCnt, &clsRevTagList,clsRevTag);
							}
							
							
						}
						
						if(clsRevTblClsCnt > 0)
						printf("\nSTN:SAN: Below Table Clause data change to be deleted---");fflush(stdout);
						
						for(k=0;k<clsRevTblClsCnt;k++)
						{
							printf("\nSTN:[%s]",clsRevTblCls[k]);fflush(stdout);
						}
						
						if(clsMstrTblClsCnt > 0)
						printf("\nSTN:SAN: Below Table Clause data change to be created---");fflush(stdout);
						
						for(k=0;k<clsMstrTblClsCnt;k++)
						{
							printf("\nSTN:[%s]",clsMstrTblCls[k]);fflush(stdout);
						}
						
						
						printf("\nSTN: clsMstrListCnt ==> [%d] \n", clsMstrListCnt);fflush(stdout);
						
						printf("\nSTN: New Master: clsMstrTagListCnt ==> [%d] \n", clsMstrTagListCnt);fflush(stdout);
						
						if(clsMstrTagListCnt > 0)
						{
							printf("\nSTN: Create New Clauses and relate to the STN Doc\n");fflush(stdout);
							//To be done.
							
							ifail = CreateMissingClause(clsMstrTagList, clsMstrTagListCnt,stnHeaderRevTag,deptDocRevTag );
						}
							
						printf("\nSTN: clsRevListCnt ==> [%d] \n", clsRevListCnt);fflush(stdout);
						
						printf("\nSTN: Extra Cls Rev: clsRevTagListCnt ==> [%d] \n", clsRevTagListCnt);fflush(stdout);
						
						if(clsRevTagListCnt > 0)
						{
							printf("\nSTN: Delete Extra Clauses of the STN Doc\n");fflush(stdout);
							int m = 0;
							for(m=0;m<clsRevTagListCnt;m++)
							{
								tag_t clsRelTag = NULLTAG;
								
								ifail = GRM_find_relation(deptDocRevTag,clsRevTagList[m],deptToClauseRelType,&clsRelTag);
					
								if(clsRelTag != NULLTAG)
								{
									ifail = GRM_delete_relation(clsRelTag);
								}
								
								//Get Item
								tag_t clsRevObjMstr = NULLTAG;
								ifail = ITEM_ask_item_of_rev(clsRevTagList[m], &clsRevObjMstr);
								if(clsRevObjMstr!=NULLTAG)
								{
									ifail = ITEM_delete_item(clsRevObjMstr);
									printf("\nSTN:Deleted successfull...\n");fflush(stdout);
								}
								else
								{
									printf("\nSTN:Not deleted...\n");fflush(stdout);
								}								

								
							}
						}
							
						
					}
					
					
					
				}
				
			}
			
		}
		
		
		
	}
	else
	{
		printf("\nSTN:SAN:Error!!!!. Check with admin, Vehicle Type of STN[%s] is blank or null\n",stnNo);fflush(stdout);
	}
	
	
	return ifail;
}


/***************************ARAI Report logic *******************/

int generateARAIReportLogic(tag_t stnHeaderRevTag,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN: Generate ARAI logic .................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* stnNoStr = "";
	char* stnRevStr = "";
	char* stnDescStr = ""; //object_desc
	char* stnDesc1Str = ""; //t5_StnDescription
	char* vehTypeStr = ""; //t5_VehicleType
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArHdr\">");
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNoStr);
	ifail = AOM_UIF_ask_value(stnHeaderRevTag,"item_revision_id",&stnRevStr);	
	
	//STN No 
	char* stnNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnNoStrBuff,"<DBE:String>%s</DBE:String>",stnNoStr);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArHNum\" type=\"String\" displayAs=\"ARAI Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnNoStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnNoStrBuff);
	
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
		
	if(tc_strstr(stnRevStr,";") != NULL)
	{
		revStr = tc_strtok ( stnRevStr,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}

	char* stnRevStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",revStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Revision\" type=\"String\" displayAs=\"Rev.\" length=\"3\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnRevStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnRevStrBuff);
	
	//STN Desc
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&stnDescStr);
	
	if(stnDescStr != NULL)
	{
		STRNG_replace_str(stnDescStr,"&","&amp;",&stnDescStr);
		STRNG_replace_str(stnDescStr,"<","&lt;",&stnDescStr);
		STRNG_replace_str(stnDescStr,">","&gt;",&stnDescStr);
	}
	
	
	
	char* stnDescStrBuff = (char *)MEM_alloc(1300 * sizeof(char));
	sprintf(stnDescStrBuff,"<DBE:String>%s</DBE:String>",stnDescStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnDescStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnDescStrBuff);
	
	
	
	//vehicle Type
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType",&vehTypeStr);
	
	char* vehTypeStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(vehTypeStrBuff,"<DBE:String>%s</DBE:String>",vehTypeStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_VehTyp\" type=\"String\" displayAs=\"Vehicle Type\" length=\"25\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,vehTypeStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(vehTypeStrBuff);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");//End of STN Header
	
	
	//Get the Department Doc
	tag_t stnToDeptRelType = NULLTAG;
		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t deptDocObj = NULLTAG;		
			
			deptDocObj = deptDocRevTags[i];
			
			char* deptNoStr = "";
			char* deptDocDesc = "";
			
			ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
			
			ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
			
			if(deptDocDesc !=NULL)
			{
				STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
			}
			
	
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5HdToDt\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");				
			
			
			//deptNo
			char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
			sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptNoStrBuff);
			
			//deptDesc
			
			char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
			sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
		
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptDocDescBuff);

			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			//End of Department Doc
			
			printf("\nSTN:[%d] - Department Doc:[%s]\n", i+1,deptNoStr);fflush(stdout);
			
			//Get Clause Revisions.
			tag_t deptToClauseRelType = NULLTAG;
			ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
			
			if(deptToClauseRelType != NULLTAG)
			{
				tag_t* clsRevTags = NULL;
				int clsRevTagCnt = 0;
				ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
				printf("\nSTN: Clause Rev Tag count: [%d]", clsRevTagCnt);fflush(stdout);
				
				int j = 0;
				for(j=0; j<clsRevTagCnt;j++)
				{
					tag_t clauseObj = NULLTAG;
					
					clauseObj = clsRevTags[j];
					
					char* clauseNoStr = "";
					char* clauseNo1Str = "";
					char* clauseDescStr = "";
					char* clauseValueStr = "";
					char* clauseTypeStr = "";
					char* clauseIsLblStr = "";
					char* clauseIsClassifiedStr = "";
					char* columnHeaderStr = "";
					char* clauseDummyStr = "";
					char* clauseClassStr = "";
					char* clauseRefDesc = "";
					char* refClauseNo = "";
					char* objTypeStr = "";
					ifail = AOM_ask_value_string(clauseObj,"object_type", &objTypeStr);
					//printf("\nSTN:Class of Clause :[%s]",objTypeStr);fflush(stdout);
					if(tc_strcmp(objTypeStr,"T5_ClauseRevision")==0)
					{
						//ok
					}
					else
					{
						printf("\nSTN:Skip it. Not a clause rev");fflush(stdout);
						continue;
					}
					
					ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
					if(clauseDescStr !=NULL)
					{
						STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
					
					if(clauseValueStr != NULL)
					{
						STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
					
					if(clauseRefDesc !=NULL)
					{
						STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
					}

					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
					char* isClassifiedStr = "";
					
					if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
					{
						isClassifiedStr="NC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
					{
						isClassifiedStr="PC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
					{
						isClassifiedStr="D8";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
					{
						isClassifiedStr="PD";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
					{
						isClassifiedStr="AX";
					}
					else
					{
						isClassifiedStr="-";
					}
					
					if(tc_strcmp(clauseTypeStr,"Table") ==0 )
					{
						//Implement for Table logic
						
						//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						//Clause No				
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						//Clause Desc
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
						
						
						//Table property
						ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
						if(columnHeaderStr !=NULL)
						{
							STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
						}
						
						
						//Column Header
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
						
						char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
						sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(columnHeaderStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
						
						char** rowHeaderList = NULL;
						int rowHeaderListCnt = 0;
						int n_table_rows = 0;
						tag_t* table_rowsTag = NULL;

						ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
						if(n_table_rows > 0)
						{
							//printf("no of table rows are %d \n", n_table_rows);
							int ii=0;
							int jj =0;
							char* colVal1 = NULL;
							char* colVal2 = NULL;
							char* colVal3 = NULL;
							char* colVal4 = NULL;
							char* colVal5 = NULL;
							char* colVal6 = NULL;
							char* colVal7 = NULL;
							char* colVal8 = NULL;
							char* colVal9 = NULL;
							char* colVal10 = NULL;
							
							for(ii=0;ii<n_table_rows;ii++)
							{
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[ii];
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
								ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
								ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
								ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
								ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
								ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
								ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
								ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
								ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);
								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}								
								
								
								char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
								MEM_free(colVal1Buff);
								
								char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
								MEM_free(colVal2Buff);
								
								char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
								MEM_free(colVal3Buff);
								
								char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
								MEM_free(colVal4Buff);

								char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
								MEM_free(colVal5Buff);

								char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
								MEM_free(colVal6Buff);

								char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
								MEM_free(colVal7Buff);

								char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
								MEM_free(colVal8Buff);

								char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
								MEM_free(colVal9Buff);

								char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
								MEM_free(colVal10Buff);
								
								
								t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

								
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
							}
							
							
							
						}
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						char* rowHeaderStr = NULL;
						int r = 0;
						
						rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
						for(r=0;r<rowHeaderListCnt;r++)
						{
							if(r==0)
							{
								//rowHeaderStr = rowHeaderList[r];
								tc_strcpy(rowHeaderStr,rowHeaderList[r]);
							}
							else
							{
								tc_strcat(rowHeaderStr,",");
								tc_strcat(rowHeaderStr,rowHeaderList[r]);
								//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
							}
						}
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
						
						char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
						sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
						
							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(rowHeaderStr);
						MEM_free(rowHeaderStrBuff);
						
						
						
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
					}
					else
					{
						//Other than Table clause
									
						char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
						MEM_free(clauseClassStrBuff);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						
						char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
						MEM_free(clauseClassStrBuff1);
						
						
						char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
						MEM_free(clauseClassStrBuff2);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
																							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
						
					}

					
					
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
					
				}//End of Clause Loop
			
			
			}
			
			
			
			
			
			
		}
	}
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	
	printf("\nSTN: End of Generate ARAI logic .................\n");fflush(stdout);
	return ITK_ok;
}


int generateARAIReportLogicString(tag_t stnHeaderRevTag,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN: Generate ARAI logic String.................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* stnNoStr = "";
	char* stnRevStr = "";
	char* stnDescStr = ""; //object_desc
	char* stnDesc1Str = ""; //t5_StnDescription
	char* vehTypeStr = ""; //t5_VehicleType
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArHdr\">");
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNoStr);
	ifail = AOM_UIF_ask_value(stnHeaderRevTag,"item_revision_id",&stnRevStr);	
	
	//STN No 
	char* stnNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnNoStrBuff,"<DBE:String>%s</DBE:String>",stnNoStr);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArHNum\" type=\"String\" displayAs=\"ARAI Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnNoStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnNoStrBuff);
	
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
		
	if(tc_strstr(stnRevStr,";") != NULL)
	{
		revStr = tc_strtok ( stnRevStr,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}

	char* stnRevStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",revStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Revision\" type=\"String\" displayAs=\"Rev.\" length=\"3\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnRevStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnRevStrBuff);
	
	//STN Desc
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&stnDescStr);
	
	if(stnDescStr!=NULL)
	{
		STRNG_replace_str(stnDescStr,"&","&amp;",&stnDescStr);
		STRNG_replace_str(stnDescStr,"<","&lt;",&stnDescStr);
		STRNG_replace_str(stnDescStr,">","&gt;",&stnDescStr);
	}
	

	
	char* stnDescStrBuff = (char *)MEM_alloc(1300 * sizeof(char));
	sprintf(stnDescStrBuff,"<DBE:String>%s</DBE:String>",stnDescStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnDescStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnDescStrBuff);
	
	
	
	//vehicle Type
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType",&vehTypeStr);
	
	char* vehTypeStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(vehTypeStrBuff,"<DBE:String>%s</DBE:String>",vehTypeStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_VehTyp\" type=\"String\" displayAs=\"Vehicle Type\" length=\"25\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,vehTypeStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(vehTypeStrBuff);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");//End of STN Header
	
	
	//Get the Department Doc
	tag_t stnToDeptRelType = NULLTAG;
		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t deptDocObj = NULLTAG;		
			
			deptDocObj = deptDocRevTags[i];
			
			char* deptNoStr = "";
			char* deptDocDesc = "";
			
			ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
			
			ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
			
			if(deptDocDesc != NULL)
			{
				STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
			}
			
			
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5HdToDt\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");				
			
			
			//deptNo
			char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
			sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptNoStrBuff);
			
			//deptDesc
			
			char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
			sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
		
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptDocDescBuff);

			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			//End of Department Doc
			
			printf("\nSTN:[%d] - Department Doc:[%s]\n", i+1,deptNoStr);fflush(stdout);
			
			//Get Clause Revisions.
			tag_t deptToClauseRelType = NULLTAG;
			ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
			
			if(deptToClauseRelType != NULLTAG)
			{
				tag_t* clsRevTags = NULL;
				int clsRevTagCnt = 0;
				ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
				printf("\nSTN: Clause Rev Tag count: [%d]", clsRevTagCnt);fflush(stdout);
				
				int j = 0;
				for(j=0; j<clsRevTagCnt;j++)
				{
					tag_t clauseObj = NULLTAG;
					
					clauseObj = clsRevTags[j];
					
					char* clauseNoStr = "";
					char* clauseNo1Str = "";
					char* clauseDescStr = "";
					char* clauseValueStr = "";
					char* clauseTypeStr = "";
					char* clauseIsLblStr = "";
					char* clauseIsClassifiedStr = "";
					char* columnHeaderStr = "";
					char* clauseDummyStr = "";
					char* clauseClassStr = "";
					char* clauseRefDesc = "";
					char* refClauseNo = "";
					char* objTypeStr = "";
					ifail = AOM_ask_value_string(clauseObj,"object_type", &objTypeStr);
					//printf("\nSTN:Class of Clause :[%s]",objTypeStr);fflush(stdout);
					if(tc_strcmp(objTypeStr,"T5_ClauseRevision")==0)
					{
						//ok
					}
					else
					{
						printf("\nSTN:Skip it. Not a clause rev");fflush(stdout);
						continue;
					}					
					
					
					ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
					if(clauseDescStr != NULL)
					{
						STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
					}
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
					if(clauseValueStr != NULL)
					{
						STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
					}
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
					//ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
					if(clauseRefDesc != NULL)
					{
						STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
					}
					
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
					char* isClassifiedStr = "";
					
					if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
					{
						isClassifiedStr="NC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
					{
						isClassifiedStr="PC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
					{
						isClassifiedStr="D8";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
					{
						isClassifiedStr="PD";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
					{
						isClassifiedStr="AX";
					}
					else
					{
						isClassifiedStr="-";
					}
					
					if(tc_strcmp(clauseTypeStr,"Table") ==0 )
					{
						//Implement for Table logic
						
						//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						//Clause No				
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						//Clause Desc
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
						
						
						//Table property
						ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
						if(columnHeaderStr !=NULL)
						{
							STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
						}						
						
						//Column Header
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
						
						char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
						sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(columnHeaderStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
						
						char** rowHeaderList = NULL;
						int rowHeaderListCnt = 0;
						int n_table_rows = 0;
						tag_t* table_rowsTag = NULL;

						ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
						if(n_table_rows > 0)
						{
							//printf("no of table rows are %d \n", n_table_rows);
							int ii=0;
							int jj =0;
							char* colVal1 = NULL;
							char* colVal2 = NULL;
							char* colVal3 = NULL;
							char* colVal4 = NULL;
							char* colVal5 = NULL;
							char* colVal6 = NULL;
							char* colVal7 = NULL;
							char* colVal8 = NULL;
							char* colVal9 = NULL;
							char* colVal10 = NULL;
							
							for(ii=0;ii<n_table_rows;ii++)
							{
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[ii];
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
								ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
								ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
								ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
								ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
								ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
								ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
								ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
								ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);

								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}								
																
								
								char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
								MEM_free(colVal1Buff);
								
								char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
								MEM_free(colVal2Buff);
								
								char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
								MEM_free(colVal3Buff);
								
								char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
								MEM_free(colVal4Buff);

								char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
								MEM_free(colVal5Buff);

								char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
								MEM_free(colVal6Buff);

								char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
								MEM_free(colVal7Buff);

								char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
								MEM_free(colVal8Buff);

								char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
								MEM_free(colVal9Buff);

								char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
								MEM_free(colVal10Buff);
								
								
								t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

								
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
							}
							
							
							
						}
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						char* rowHeaderStr = NULL;
						int r = 0;
						
						rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
						for(r=0;r<rowHeaderListCnt;r++)
						{
							if(r==0)
							{
								//rowHeaderStr = rowHeaderList[r];
								tc_strcpy(rowHeaderStr,rowHeaderList[r]);
							}
							else
							{
								tc_strcat(rowHeaderStr,",");
								tc_strcat(rowHeaderStr,rowHeaderList[r]);
								//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
							}
						}
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
						
						char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
						sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
						
							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(rowHeaderStr);
						MEM_free(rowHeaderStrBuff);
						
						
						
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
					}
					else
					{
						//Other than Table clause
						clauseClassStr = "t5StrACl";			
						char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
						MEM_free(clauseClassStrBuff);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						
						char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
						MEM_free(clauseClassStrBuff1);
						
						
						char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
						MEM_free(clauseClassStrBuff2);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
																							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
						
					}

					
					
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
					
				}//End of Clause Loop
			
			
			}
			
			
			
			
			
			
		}
	}
	
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	printf("\nSTN: End of Generate ARAI logic String.................\n");fflush(stdout);
	
	return ITK_ok;
}


/***********Reqd Rev logic ******************/

int generateARAIReportLogicReqdRev(tag_t stnHeaderRevTag,char* reqdRevStr,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN:Upd-Generate ARAI logic Reqd Rev .................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* stnNoStr = "";
	char* stnRevStr = "";
	char* stnDescStr = ""; //object_desc
	char* stnDesc1Str = ""; //t5_StnDescription
	char* vehTypeStr = ""; //t5_VehicleType
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArHdr\">");
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNoStr);
	ifail = AOM_UIF_ask_value(stnHeaderRevTag,"item_revision_id",&stnRevStr);	
	
	//STN No 
	char* stnNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnNoStrBuff,"<DBE:String>%s</DBE:String>",stnNoStr);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArHNum\" type=\"String\" displayAs=\"ARAI Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnNoStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnNoStrBuff[%s]",stnNoStrBuff);fflush(stdout);
	MEM_free(stnNoStrBuff);
	
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
		
	if(tc_strstr(stnRevStr,";") != NULL)
	{
		revStr = tc_strtok ( stnRevStr,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}

	char* stnRevStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	//sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",revStr);
	sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",reqdRevStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Revision\" type=\"String\" displayAs=\"Rev.\" length=\"3\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnRevStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnRevStrBuff[%s]",stnRevStrBuff);fflush(stdout);
	MEM_free(stnRevStrBuff);
	
	//STN Desc
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&stnDescStr);
	
	if(stnDescStr != NULL)
	{
		STRNG_replace_str(stnDescStr,"&","&amp;",&stnDescStr);
		STRNG_replace_str(stnDescStr,"<","&lt;",&stnDescStr);
		STRNG_replace_str(stnDescStr,">","&gt;",&stnDescStr);
	}
	
	
	
	char* stnDescStrBuff = (char *)MEM_alloc(1300 * sizeof(char));
	sprintf(stnDescStrBuff,"<DBE:String>%s</DBE:String>",stnDescStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnDescStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnDescStrBuff[%s]",stnDescStrBuff);fflush(stdout);
	MEM_free(stnDescStrBuff);
	
	
	
	//vehicle Type
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType",&vehTypeStr);
	
	char* vehTypeStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(vehTypeStrBuff,"<DBE:String>%s</DBE:String>",vehTypeStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_VehTyp\" type=\"String\" displayAs=\"Vehicle Type\" length=\"25\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,vehTypeStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: vehTypeStrBuff[%s]",vehTypeStrBuff);fflush(stdout);
	MEM_free(vehTypeStrBuff);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");//End of STN Header
	
	
	//Get the Department Doc
	tag_t stnToDeptRelType = NULLTAG;
		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		
		//printf("\nSTN: Dept Doc Count:[%d]",deptDocRevCnt);fflush(stdout);
		
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t deptDocObj = NULLTAG;		
			
			deptDocObj = deptDocRevTags[i];
			
			char* deptNoStr = "";
			char* deptDocDesc = "";
			
			ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
			
			ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
			
			if(deptDocDesc !=NULL)
			{
				STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
			}
			
	
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5HdToDt\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");				
			
			
			//deptNo
			char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
			sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			//printf("\nSTN:Upd: deptNoStrBuff[%s]",deptNoStrBuff);fflush(stdout);
			MEM_free(deptNoStrBuff);
			
			//deptDesc
			
			char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
			sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
		
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			//printf("\nSTN:Upd: deptDocDescBuff[%s]",deptDocDescBuff);fflush(stdout);
			MEM_free(deptDocDescBuff);

			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			//End of Department Doc
			
			printf("\nSTN:[%d] - Department Doc:[%s]", i+1,deptNoStr);fflush(stdout);
			
			//Get Clause Revisions.
			tag_t deptToClauseRelType = NULLTAG;
			ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
			
			if(deptToClauseRelType != NULLTAG)
			{
				tag_t* clsRevTags = NULL;
				int clsRevTagCnt = 0;
				ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
				printf("\nSTN:Clause Rev Tag count: [%d]", clsRevTagCnt);fflush(stdout);
				
				int j = 0;
				for(j=0; j<clsRevTagCnt;j++)
				{
					tag_t clauseObj = NULLTAG;
					
					clauseObj = clsRevTags[j];
					
					char* clauseNoStr = "";
					char* clauseNo1Str = "";
					char* clauseDescStr = "";
					char* clauseValueStr = "";
					char* clauseTypeStr = "";
					char* clauseIsLblStr = "";
					char* clauseIsClassifiedStr = "";
					char* columnHeaderStr = "";
					char* clauseDummyStr = "";
					char* clauseClassStr = "";
					char* clauseRefDesc = "";
					char* refClauseNo = "";
					char* objTypeStr = "";
					ifail = AOM_ask_value_string(clauseObj,"object_type", &objTypeStr);
					//printf("\nSTN:Class of Clause :[%s]",objTypeStr);fflush(stdout);
					if(tc_strcmp(objTypeStr,"T5_ClauseRevision")==0)
					{
						//ok
					}
					else
					{
						printf("\nSTN:Skip it. Not a clause rev");fflush(stdout);
						continue;
					}					
					
					
					ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
					if(clauseDescStr !=NULL)
					{
						STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
					
					if(clauseValueStr != NULL)
					{
						STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
					
					if(clauseRefDesc !=NULL)
					{
						STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
					}

					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
					char* isClassifiedStr = "";
					
					if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
					{
						isClassifiedStr="NC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
					{
						isClassifiedStr="PC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
					{
						isClassifiedStr="D8";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
					{
						isClassifiedStr="PD";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
					{
						isClassifiedStr="AX";
					}
					else
					{
						isClassifiedStr="-";
					}
					
					if(tc_strcmp(clauseTypeStr,"Table") ==0 )
					{
						//Implement for Table logic
						
						//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						//Clause No				
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						//Clause Desc
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
						
						
						//Table property
						ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
						if(columnHeaderStr !=NULL)
						{
							STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
						}
						
						
						//Column Header
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
						
						char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
						sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(columnHeaderStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
						
						char** rowHeaderList = NULL;
						int rowHeaderListCnt = 0;
						int n_table_rows = 0;
						tag_t* table_rowsTag = NULL;

						ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
						if(n_table_rows > 0)
						{
							//printf("no of table rows are %d \n", n_table_rows);
							int ii=0;
							int jj =0;
							char* colVal1 = NULL;
							char* colVal2 = NULL;
							char* colVal3 = NULL;
							char* colVal4 = NULL;
							char* colVal5 = NULL;
							char* colVal6 = NULL;
							char* colVal7 = NULL;
							char* colVal8 = NULL;
							char* colVal9 = NULL;
							char* colVal10 = NULL;
							
							for(ii=0;ii<n_table_rows;ii++)
							{
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[ii];
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
								ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
								ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
								ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
								ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
								ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
								ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
								ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
								ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);
								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}								
								
								
								char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
								MEM_free(colVal1Buff);
								
								char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
								MEM_free(colVal2Buff);
								
								char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
								MEM_free(colVal3Buff);
								
								char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
								MEM_free(colVal4Buff);

								char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
								MEM_free(colVal5Buff);

								char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
								MEM_free(colVal6Buff);

								char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
								MEM_free(colVal7Buff);

								char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
								MEM_free(colVal8Buff);

								char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
								MEM_free(colVal9Buff);

								char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
								MEM_free(colVal10Buff);
								
								
								t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

								
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
							}
							
							
							
						}
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						char* rowHeaderStr = NULL;
						int r = 0;
						
						rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
						for(r=0;r<rowHeaderListCnt;r++)
						{
							if(r==0)
							{
								//rowHeaderStr = rowHeaderList[r];
								tc_strcpy(rowHeaderStr,rowHeaderList[r]);
							}
							else
							{
								tc_strcat(rowHeaderStr,",");
								tc_strcat(rowHeaderStr,rowHeaderList[r]);
								//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
							}
						}
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
						
						char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
						sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
						
							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(rowHeaderStr);
						MEM_free(rowHeaderStrBuff);
						
						
						
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
					}
					else
					{
						//Other than Table clause
									
						char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
						MEM_free(clauseClassStrBuff);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						
						char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
						MEM_free(clauseClassStrBuff1);
						
						
						char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
						MEM_free(clauseClassStrBuff2);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
																							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
						
					}

					
					
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
					
				}//End of Clause Loop
			
			
			}
			
			
			
			
			
			
		}
	}
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	
	printf("\nSTN: End of Generate ARAI logic Reqd Rev .................\n");fflush(stdout);
	return ITK_ok;
}

int generateARAIReportLogicStringReqdRevBkp(tag_t stnHeaderRevTag,char* reqdRevStr, char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN: Generate ARAI logic Reqd Rev String.................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* stnNoStr = "";
	char* stnRevStr = "";
	char* stnDescStr = ""; //object_desc
	char* stnDesc1Str = ""; //t5_StnDescription
	char* vehTypeStr = ""; //t5_VehicleType
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArHdr\">");
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNoStr);
	ifail = AOM_UIF_ask_value(stnHeaderRevTag,"item_revision_id",&stnRevStr);	
	
	//STN No 
	char* stnNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(stnNoStrBuff,"<DBE:String>%s</DBE:String>",stnNoStr);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArHNum\" type=\"String\" displayAs=\"ARAI Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnNoStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnNoStrBuff);
	
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
		
	if(tc_strstr(stnRevStr,";") != NULL)
	{
		revStr = tc_strtok ( stnRevStr,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}

	char* stnRevStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	//sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",revStr);
	sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",reqdRevStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Revision\" type=\"String\" displayAs=\"Rev.\" length=\"3\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnRevStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnRevStrBuff);
	
	//STN Desc
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&stnDescStr);
	
	if(stnDescStr!=NULL)
	{
		STRNG_replace_str(stnDescStr,"&","&amp;",&stnDescStr);
		STRNG_replace_str(stnDescStr,"<","&lt;",&stnDescStr);
		STRNG_replace_str(stnDescStr,">","&gt;",&stnDescStr);
	}
	

	
	char* stnDescStrBuff = (char *)MEM_alloc(1300 * sizeof(char));
	sprintf(stnDescStrBuff,"<DBE:String>%s</DBE:String>",stnDescStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnDescStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(stnDescStrBuff);
	
	
	
	//vehicle Type
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType",&vehTypeStr);
	
	char* vehTypeStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(vehTypeStrBuff,"<DBE:String>%s</DBE:String>",vehTypeStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_VehTyp\" type=\"String\" displayAs=\"Vehicle Type\" length=\"25\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,vehTypeStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(vehTypeStrBuff);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");//End of STN Header
	
	
	//Get the Department Doc
	tag_t stnToDeptRelType = NULLTAG;
		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t deptDocObj = NULLTAG;		
			
			deptDocObj = deptDocRevTags[i];
			
			char* deptNoStr = "";
			char* deptDocDesc = "";
			
			ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
			
			ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
			
			if(deptDocDesc != NULL)
			{
				STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
			}
			
			
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5HdToDt\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");				
			
			
			//deptNo
			char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
			sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptNoStrBuff);
			
			//deptDesc
			
			char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
			sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
		
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			MEM_free(deptDocDescBuff);

			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			//End of Department Doc
			
			printf("\nSTN:[%d] - Department Doc:[%s]\n", i+1,deptNoStr);fflush(stdout);
			
			//Get Clause Revisions.
			tag_t deptToClauseRelType = NULLTAG;
			ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
			
			if(deptToClauseRelType != NULLTAG)
			{
				tag_t* clsRevTags = NULL;
				int clsRevTagCnt = 0;
				ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
				printf("\nSTN:Clause Rev Tag count: [%d]", clsRevTagCnt);fflush(stdout);
				
				int j = 0;
				for(j=0; j<clsRevTagCnt;j++)
				{
					tag_t clauseObj = NULLTAG;
					
					clauseObj = clsRevTags[j];
					
					char* clauseNoStr = "";
					char* clauseNo1Str = "";
					char* clauseDescStr = "";
					char* clauseValueStr = "";
					char* clauseTypeStr = "";
					char* clauseIsLblStr = "";
					char* clauseIsClassifiedStr = "";
					char* columnHeaderStr = "";
					char* clauseDummyStr = "";
					char* clauseClassStr = "";
					char* clauseRefDesc = "";
					char* refClauseNo = "";
					char* objTypeStr = "";
					ifail = AOM_ask_value_string(clauseObj,"object_type", &objTypeStr);
					//printf("\nSTN:Class of Clause :[%s]",objTypeStr);fflush(stdout);
					if(tc_strcmp(objTypeStr,"T5_ClauseRevision")==0)
					{
						//ok
					}
					else
					{
						printf("\nSTN:Skip it. Not a clause rev");fflush(stdout);
						continue;
					}					
					
					
					ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
					if(clauseDescStr != NULL)
					{
						STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
					}
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
					if(clauseValueStr != NULL)
					{
						STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
					}
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
					//ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
					if(clauseRefDesc != NULL)
					{
						STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
					}
					
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
					char* isClassifiedStr = "";
					
					if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
					{
						isClassifiedStr="NC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
					{
						isClassifiedStr="PC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
					{
						isClassifiedStr="D8";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
					{
						isClassifiedStr="PD";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
					{
						isClassifiedStr="AX";
					}
					else
					{
						isClassifiedStr="-";
					}
					
					if(tc_strcmp(clauseTypeStr,"Table") ==0 )
					{
						//Implement for Table logic
						
						//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						//Clause No				
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						//Clause Desc
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
						
						
						//Table property
						ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
						if(columnHeaderStr !=NULL)
						{
							STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
						}						
						
						//Column Header
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
						
						char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
						sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(columnHeaderStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
						
						char** rowHeaderList = NULL;
						int rowHeaderListCnt = 0;
						int n_table_rows = 0;
						tag_t* table_rowsTag = NULL;

						ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
						if(n_table_rows > 0)
						{
							//printf("no of table rows are %d \n", n_table_rows);
							int ii=0;
							int jj =0;
							char* colVal1 = NULL;
							char* colVal2 = NULL;
							char* colVal3 = NULL;
							char* colVal4 = NULL;
							char* colVal5 = NULL;
							char* colVal6 = NULL;
							char* colVal7 = NULL;
							char* colVal8 = NULL;
							char* colVal9 = NULL;
							char* colVal10 = NULL;
							
							for(ii=0;ii<n_table_rows;ii++)
							{
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[ii];
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
								ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
								ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
								ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
								ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
								ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
								ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
								ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
								ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);

								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}								
																
								
								char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
								MEM_free(colVal1Buff);
								
								char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
								MEM_free(colVal2Buff);
								
								char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
								MEM_free(colVal3Buff);
								
								char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
								MEM_free(colVal4Buff);

								char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
								MEM_free(colVal5Buff);

								char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
								MEM_free(colVal6Buff);

								char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
								MEM_free(colVal7Buff);

								char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
								MEM_free(colVal8Buff);

								char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
								MEM_free(colVal9Buff);

								char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
								sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
								MEM_free(colVal10Buff);
								
								
								t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

								
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
							}
							
							
							
						}
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						char* rowHeaderStr = NULL;
						int r = 0;
						
						rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
						for(r=0;r<rowHeaderListCnt;r++)
						{
							if(r==0)
							{
								//rowHeaderStr = rowHeaderList[r];
								tc_strcpy(rowHeaderStr,rowHeaderList[r]);
							}
							else
							{
								tc_strcat(rowHeaderStr,",");
								tc_strcat(rowHeaderStr,rowHeaderList[r]);
								//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
							}
						}
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
						
						char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
						sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
						
							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(rowHeaderStr);
						MEM_free(rowHeaderStrBuff);
						
						
						
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
					}
					else
					{
						//Other than Table clause
						clauseClassStr = "t5StrACl";			
						char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
						MEM_free(clauseClassStrBuff);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						
						char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
						MEM_free(clauseClassStrBuff1);
						
						
						char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
						sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
						MEM_free(clauseClassStrBuff2);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
																							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
						
					}

					
					
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
					
				}//End of Clause Loop
			
			
			}
			
			
			
			
			
			
		}
	}
	
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	printf("\nSTN: End of Generate ARAI logic Reqd Rev String.................\n");fflush(stdout);
	
	return ITK_ok;
}

int generateARAIReportLogicStringReqdRev(tag_t stnHeaderRevTag,char* reqdRevStr,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN:Upd-Generate ARAI logic Reqd Rev String New .................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* stnNoStr = "";
	char* stnRevStr = "";
	char* stnDescStr = ""; //object_desc
	char* stnDesc1Str = ""; //t5_StnDescription
	char* vehTypeStr = ""; //t5_VehicleType
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArHdr\">");
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"item_id",&stnNoStr);
	ifail = AOM_UIF_ask_value(stnHeaderRevTag,"item_revision_id",&stnRevStr);	
	
	//STN No 
	char* stnNoStrBuff = (char *)MEM_alloc(200 * sizeof(char) + tc_strlen(stnNoStr)* sizeof(char));
	sprintf(stnNoStrBuff,"<DBE:String>%s</DBE:String>",stnNoStr);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArHNum\" type=\"String\" displayAs=\"ARAI Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnNoStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnNoStrBuff[%s]",stnNoStrBuff);fflush(stdout);
	MEM_free(stnNoStrBuff);
	
	//STN Revision
	char* revStr = NULL;
	char* seqStr = NULL;
		
	if(tc_strstr(stnRevStr,";") != NULL)
	{
		revStr = tc_strtok ( stnRevStr,";") ;
		seqStr = tc_strtok ( NULL,";") ;	
	}

	char* stnRevStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	//sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",revStr);
	sprintf(stnRevStrBuff,"<DBE:String>%s</DBE:String>",reqdRevStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Revision\" type=\"String\" displayAs=\"Rev.\" length=\"3\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnRevStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnRevStrBuff[%s]",stnRevStrBuff);fflush(stdout);
	MEM_free(stnRevStrBuff);
	
	//STN Desc
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"object_desc",&stnDescStr);
	
	if(stnDescStr != NULL)
	{
		STRNG_replace_str(stnDescStr,"&","&amp;",&stnDescStr);
		STRNG_replace_str(stnDescStr,"<","&lt;",&stnDescStr);
		STRNG_replace_str(stnDescStr,">","&gt;",&stnDescStr);
	}
	
	
	
	char* stnDescStrBuff = (char *)MEM_alloc(1300 * sizeof(char) + tc_strlen(stnDescStr)* sizeof(char));
	sprintf(stnDescStrBuff,"<DBE:String>%s</DBE:String>",stnDescStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,stnDescStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: stnDescStrBuff[%s]",stnDescStrBuff);fflush(stdout);
	MEM_free(stnDescStrBuff);
	
	
	
	//vehicle Type
	
	ifail = AOM_ask_value_string(stnHeaderRevTag,"t5_VehicleType",&vehTypeStr);
	
	char* vehTypeStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(vehTypeStrBuff,"<DBE:String>%s</DBE:String>",vehTypeStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_VehTyp\" type=\"String\" displayAs=\"Vehicle Type\" length=\"25\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,vehTypeStrBuff);			
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	//printf("\nSTN:Upd: vehTypeStrBuff[%s]",vehTypeStrBuff);fflush(stdout);
	MEM_free(vehTypeStrBuff);
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");//End of STN Header
	
	
	//Get the Department Doc
	tag_t stnToDeptRelType = NULLTAG;
		
	ifail = GRM_find_relation_type("T5_StnHasDeptDoc", &stnToDeptRelType);
	
	if(stnToDeptRelType != NULLTAG)
	{
		int deptDocRevCnt = 0;
		tag_t *deptDocRevTags = NULL;
		int i = 0;
		ifail = GRM_list_secondary_objects_only(stnHeaderRevTag,stnToDeptRelType,&deptDocRevCnt,&deptDocRevTags);
		
		//printf("\nSTN: Dept Doc Count:[%d]",deptDocRevCnt);fflush(stdout);
		
		for(i=0;i<deptDocRevCnt;i++)
		{
			tag_t deptDocObj = NULLTAG;		
			
			deptDocObj = deptDocRevTags[i];
			
			char* deptNoStr = "";
			char* deptDocDesc = "";
			
			ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
			
			ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
			
			if(deptDocDesc !=NULL)
			{
				STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
				STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
			}
			
	
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5HdToDt\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");				
			
			
			//deptNo
			char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
			sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			//printf("\nSTN:Upd: deptNoStrBuff[%s]",deptNoStrBuff);fflush(stdout);
			MEM_free(deptNoStrBuff);
			
			//deptDesc
			
			char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char) + tc_strlen(deptDocDesc)* sizeof(char));
			sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
		
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			//printf("\nSTN:Upd: deptDocDescBuff[%s]",deptDocDescBuff);fflush(stdout);
			MEM_free(deptDocDescBuff);

			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			//End of Department Doc
			
			printf("\nSTN:[%d] - Department Doc:[%s]", i+1,deptNoStr);fflush(stdout);
			
			//Get Clause Revisions.
			tag_t deptToClauseRelType = NULLTAG;
			ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
			
			if(deptToClauseRelType != NULLTAG)
			{
				tag_t* clsRevTags = NULL;
				int clsRevTagCnt = 0;
				ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
					
				printf("\nSTN:Clause Rev Tag count: [%d]", clsRevTagCnt);fflush(stdout);
				
				int j = 0;
				for(j=0; j<clsRevTagCnt;j++)
				{
					tag_t clauseObj = NULLTAG;
					
					clauseObj = clsRevTags[j];
					
					char* clauseNoStr = "";
					char* clauseNo1Str = "";
					char* clauseDescStr = "";
					char* clauseValueStr = "";
					char* clauseTypeStr = "";
					char* clauseIsLblStr = "";
					char* clauseIsClassifiedStr = "";
					char* columnHeaderStr = "";
					char* clauseDummyStr = "";
					char* clauseClassStr = "";
					char* clauseRefDesc = "";
					char* refClauseNo = "";
					char* objTypeStr = "";
					ifail = AOM_ask_value_string(clauseObj,"object_type", &objTypeStr);
					//printf("\nSTN:Class of Clause :[%s]",objTypeStr);fflush(stdout);
					if(tc_strcmp(objTypeStr,"T5_ClauseRevision")==0)
					{
						//ok
					}
					else
					{
						printf("\nSTN:Skip it. Not a clause rev");fflush(stdout);
						continue;
					}					
					
					
					ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
					if(clauseDescStr !=NULL)
					{
						STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
						STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
					}
					else
					{
						clauseDescStr = "";
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
					
					if(clauseValueStr != NULL)
					{
						STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
						STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
					}
					else
					{
						clauseValueStr = "";
					}

					
					ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
					
					if(clauseRefDesc !=NULL)
					{
						STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
						STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
					}
					else
					{
						clauseRefDesc = "";
					}

					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
					
					
					ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
					char* isClassifiedStr = "";
					
					if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
					{
						isClassifiedStr="NC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
					{
						isClassifiedStr="PC";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
					{
						isClassifiedStr="D8";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
					{
						isClassifiedStr="PD";
					}
					else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
					{
						isClassifiedStr="AX";
					}
					else
					{
						isClassifiedStr="-";
					}
					
					if(tc_strcmp(clauseTypeStr,"Table") ==0 )
					{
						//Implement for Table logic
						
						//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						//Clause No				
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						//Clause Desc
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char) + tc_strlen(clauseDescStr)*sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char) + tc_strlen(clauseRefDesc)*sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char)+ tc_strlen(clauseValueStr)*sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
						
						
						//Table property
						ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
						if(columnHeaderStr !=NULL)
						{
							STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
							STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
						}
						else
						{
							columnHeaderStr = "";
						}
						
						
						//Column Header
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
						
						char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char) + tc_strlen(columnHeaderStr)*sizeof(char));
						sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(columnHeaderStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
						
						char** rowHeaderList = NULL;
						int rowHeaderListCnt = 0;
						int n_table_rows = 0;
						tag_t* table_rowsTag = NULL;

						ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
						if(n_table_rows > 0)
						{
							//printf("no of table rows are %d \n", n_table_rows);
							int ii=0;
							int jj =0;
							char* colVal1 = NULL;
							char* colVal2 = NULL;
							char* colVal3 = NULL;
							char* colVal4 = NULL;
							char* colVal5 = NULL;
							char* colVal6 = NULL;
							char* colVal7 = NULL;
							char* colVal8 = NULL;
							char* colVal9 = NULL;
							char* colVal10 = NULL;
							
							for(ii=0;ii<n_table_rows;ii++)
							{
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
								tag_t tableObj = NULLTAG;
								tableObj = table_rowsTag[ii];
								ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
								ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
								ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
								ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
								ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
								ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
								ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
								ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
								ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
								ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);
								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								else
								{
									colVal1 = "";
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								else
								{
									colVal2 = "";
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								else
								{
									colVal3 = "";
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								else
								{
									colVal4 = "";
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								else
								{
									colVal5 = "";
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								else
								{
									colVal6 = "";
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								else
								{
									colVal7 = "";
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								else
								{
									colVal8 = "";
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								else
								{
									colVal9 = "";
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}
								else
								{
									colVal10 = "";
								}
								
								
								
								char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal1)*sizeof(char));
								sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
								MEM_free(colVal1Buff);
								
								char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal2)*sizeof(char));
								sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
								MEM_free(colVal2Buff);
								
								char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal3)*sizeof(char));
								sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
								MEM_free(colVal3Buff);
								
								char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal4)*sizeof(char));
								sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
								MEM_free(colVal4Buff);

								char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal5)*sizeof(char));
								sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
								MEM_free(colVal5Buff);

								char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal6)*sizeof(char));
								sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
								MEM_free(colVal6Buff);

								char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal7)*sizeof(char));
								sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
								MEM_free(colVal7Buff);

								char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal8)*sizeof(char));
								sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
								MEM_free(colVal8Buff);

								char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal9)*sizeof(char));
								sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
								MEM_free(colVal9Buff);

								char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char) + tc_strlen(colVal10)*sizeof(char));
								sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
								MEM_free(colVal10Buff);
								
								
								t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

								
								t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
							}
							
							
							
						}
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						
						char* rowHeaderStr = NULL;
						int r = 0;
						
						rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
						for(r=0;r<rowHeaderListCnt;r++)
						{
							if(r==0)
							{
								//rowHeaderStr = rowHeaderList[r];
								tc_strcpy(rowHeaderStr,rowHeaderList[r]);
							}
							else
							{
								tc_strcat(rowHeaderStr,",");
								tc_strcat(rowHeaderStr,rowHeaderList[r]);
								//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
							}
						}
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
						
						char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800 + tc_strlen(rowHeaderStr)*sizeof(char));
						sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
						
							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(rowHeaderStr);
						MEM_free(rowHeaderStrBuff);
						
						
						
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
					}
					else
					{
						//Other than Table clause
									
						char* clauseClassStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
						MEM_free(clauseClassStrBuff);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
						
						char* clauseClassStrBuff1 = (char *)MEM_alloc(100 * sizeof(char));
						sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
						MEM_free(clauseClassStrBuff1);
						
						
						char* clauseClassStrBuff2 = (char *)MEM_alloc(100 * sizeof(char));
						sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
						MEM_free(clauseClassStrBuff2);
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
						
						//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
						
						char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						
						MEM_free(clauseNoStrBuff);
						
						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
						
						char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char) + tc_strlen(clauseDescStr)*sizeof(char));
						sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDescStrBuff);
						
						
						
						char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char) + tc_strlen(clauseRefDesc)*sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
						sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseRefDescBuff);
						
						
						char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char) + tc_strlen(clauseValueStr)*sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
						sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseValueStrBuff);
						
						char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
						sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(clauseDummyStrBuff);
						
						
						char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
						sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(refClauseNoBuff);
						
						char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
						sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
						MEM_free(isClassifiedStrBuff);
																							
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
						
						
						
					}

					
					
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
					
					t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
					
				}//End of Clause Loop
			
			
			}
			
			
			
			
			
			
		}
	}
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	
	printf("\nSTN: End of Generate ARAI logic Reqd Rev String New .................\n");fflush(stdout);
	return ITK_ok;
}


/***************************Department Doc Report **********************/

int generateDeptReportLogic(tag_t deptDocObj,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN: Generate Department Doc logic .................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* deptNoStr = "";
	char* deptDocDesc = "";
	
	ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
	
	ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
	
	if(deptDocDesc != NULL)
	{
		STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
		STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
		STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
	}
	
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DocumentDescription\" type=\"String\" displayAs=\"Document Description\" length=\"240\"><DBE:String/></DBE:Attribute>");
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	
	//deptDesc
	char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
	sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(deptDocDescBuff);
		
	
	
	//deptNo
	char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(deptNoStrBuff);

	

	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
	
	//End of Department Doc
	
	
	
	//Get Clause Revisions.
	tag_t deptToClauseRelType = NULLTAG;
	ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
	
	if(deptToClauseRelType != NULLTAG)
	{
		tag_t* clsRevTags = NULL;
		int clsRevTagCnt = 0;
		ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
			
		printf("\nSTN: Clause Rev Tag count: [%d]\n", clsRevTagCnt);fflush(stdout);
		
		int j = 0;
		for(j=0; j<clsRevTagCnt;j++)
		{
			tag_t clauseObj = NULLTAG;
			
			clauseObj = clsRevTags[j];
			
			char* clauseNoStr = "";
			char* clauseNo1Str = "";
			char* clauseDescStr = "";
			char* clauseValueStr = "";
			char* clauseTypeStr = "";
			char* clauseIsLblStr = "";
			char* clauseIsClassifiedStr = "";
			char* columnHeaderStr = "";
			char* clauseDummyStr = "";
			char* clauseClassStr = "";
			char* clauseRefDesc = "";
			char* refClauseNo = "";
			
			
			ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
			ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
			
			if(clauseDescStr != NULL)
			{
				STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
				STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
				STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
			}
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
			if(clauseValueStr != NULL)
			{
				STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
				STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
				STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);
			}
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
			
			if(clauseRefDesc != NULL)
			{
				STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
				STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
				STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
			}
			
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
			char* isClassifiedStr = "";
			
			if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
			{
				isClassifiedStr="NC";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
			{
				isClassifiedStr="PC";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
			{
				isClassifiedStr="D8";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
			{
				isClassifiedStr="PD";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
			{
				isClassifiedStr="AX";
			}
			else
			{
				isClassifiedStr="-";
			}
			
			if(tc_strcmp(clauseTypeStr,"Table") ==0 )
			{
				//Implement for Table logic
				
				//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				
				//Clause No				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
				
				//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
				
				char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
				sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(clauseNoStrBuff);
				
				
				//Clause Desc
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
				
				char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
				sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDescStrBuff);
				
				
				
				char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
				sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseRefDescBuff);
				
				char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
				sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseValueStrBuff);
				
				char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
				sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDummyStrBuff);
				
				
				char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
				sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(refClauseNoBuff);
				
				char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
				sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(isClassifiedStrBuff);
				
				
				//Table property
				ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
				if(columnHeaderStr !=NULL)
				{
					STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
					STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
					STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
				}				
				
				//Column Header
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
				
				char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
				sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(columnHeaderStrBuff);
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
				
				char** rowHeaderList = NULL;
				int rowHeaderListCnt = 0;
				int n_table_rows = 0;
				tag_t* table_rowsTag = NULL;

				ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
				if(n_table_rows > 0)
				{
					//printf("no of table rows are %d \n", n_table_rows);
					int ii=0;
					int jj =0;
					char* colVal1 = NULL;
					char* colVal2 = NULL;
					char* colVal3 = NULL;
					char* colVal4 = NULL;
					char* colVal5 = NULL;
					char* colVal6 = NULL;
					char* colVal7 = NULL;
					char* colVal8 = NULL;
					char* colVal9 = NULL;
					char* colVal10 = NULL;
					
					for(ii=0;ii<n_table_rows;ii++)
					{
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
						tag_t tableObj = NULLTAG;
						tableObj = table_rowsTag[ii];
						ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
						ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
						ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
						ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
						ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
						ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
						ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
						ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
						ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
						ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);
								if(colVal1 != NULL)
								{
									STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
									STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
									STRNG_replace_str(colVal1,">","&gt;",&colVal1);
								}
								if(colVal2 != NULL)
								{
									STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
									STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
									STRNG_replace_str(colVal2,">","&gt;",&colVal2);
								}
								if(colVal3 != NULL)
								{
									STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
									STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
									STRNG_replace_str(colVal3,">","&gt;",&colVal3);
								}
								if(colVal4 != NULL)
								{
									STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
									STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
									STRNG_replace_str(colVal4,">","&gt;",&colVal4);
								}
								if(colVal5 != NULL)
								{
									STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
									STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
									STRNG_replace_str(colVal5,">","&gt;",&colVal5);
								}
								if(colVal6 != NULL)
								{
									STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
									STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
									STRNG_replace_str(colVal6,">","&gt;",&colVal6);
								}
								if(colVal7 != NULL)
								{
									STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
									STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
									STRNG_replace_str(colVal7,">","&gt;",&colVal7);
								}
								if(colVal8 != NULL)
								{
									STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
									STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
									STRNG_replace_str(colVal8,">","&gt;",&colVal8);
								}
								if(colVal9 != NULL)
								{
									STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
									STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
									STRNG_replace_str(colVal9,">","&gt;",&colVal9);
								}
								if(colVal10 != NULL)
								{
									STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
									STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
									STRNG_replace_str(colVal10,">","&gt;",&colVal10);
								}								
														
						
						char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
						MEM_free(colVal1Buff);
						
						char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
						MEM_free(colVal2Buff);
						
						char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
						MEM_free(colVal3Buff);
						
						char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
						MEM_free(colVal4Buff);

						char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
						MEM_free(colVal5Buff);

						char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
						MEM_free(colVal6Buff);

						char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
						MEM_free(colVal7Buff);

						char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
						MEM_free(colVal8Buff);

						char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
						MEM_free(colVal9Buff);

						char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
						MEM_free(colVal10Buff);
						
						
						t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
					}
					
					
					
				}
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				
				char* rowHeaderStr = NULL;
				int r = 0;
				
				rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
				for(r=0;r<rowHeaderListCnt;r++)
				{
					if(r==0)
					{
						//rowHeaderStr = rowHeaderList[r];
						tc_strcpy(rowHeaderStr,rowHeaderList[r]);
					}
					else
					{
						tc_strcat(rowHeaderStr,",");
						tc_strcat(rowHeaderStr,rowHeaderList[r]);
						//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
					}
				}
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
				
				char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
				sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
				
					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(rowHeaderStr);
				MEM_free(rowHeaderStrBuff);
				
				
				
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
				
			}
			else
			{
				//Other than Table clause
							
				char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
				MEM_free(clauseClassStrBuff);
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
				
				char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
				MEM_free(clauseClassStrBuff1);
				
				
				char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
				MEM_free(clauseClassStrBuff2);
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
				
				//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
				
				char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
				sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(clauseNoStrBuff);
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
				
				char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
				sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDescStrBuff);
				
				
				
				char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
				sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseRefDescBuff);
				
				
				char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
				sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseValueStrBuff);
				
				char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
				sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDummyStrBuff);
				
				
				char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
				sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(refClauseNoBuff);
				
				char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
				sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(isClassifiedStrBuff);
																					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
				
				
			}

			
			
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			
		}//End of Clause Loop
	
	
	}
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	
	printf("\nSTN: End of Generate Department Doc logic.................\n");fflush(stdout);
	return ITK_ok;
}


int generateDeptReportLogicString(tag_t deptDocObj,char*** bufferedXmlStrOut, int *buff_cnt)
{
	int ifail = ITK_ok;
	printf("\nSTN: Generate Department Doc logic String.................\n");fflush(stdout);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<?xml version=\"1.0\" encoding = \"UTF-8\" ?>");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:ObjectSetRoot xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.sdrc.com/metaphase/cf11bd /user/omfprod/xml/bd2.xsd\">\r\n");
	
	
	char* deptNoStr = "";
	char* deptDocDesc = "";
	
	ifail = AOM_ask_value_string(deptDocObj,"item_id",&deptNoStr);
	
	ifail = AOM_ask_value_string(deptDocObj,"object_desc",&deptDocDesc);
	
	if(deptDocDesc != NULL)
	{
		STRNG_replace_str(deptDocDesc,"&","&amp;",&deptDocDesc);
		STRNG_replace_str(deptDocDesc,"<","&lt;",&deptDocDesc);
		STRNG_replace_str(deptDocDesc,">","&gt;",&deptDocDesc);
	}

	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5ArDDoc\">");
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DocumentDescription\" type=\"String\" displayAs=\"Document Description\" length=\"240\"><DBE:String/></DBE:Attribute>");
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
	
	//deptDesc
	char* deptDocDescBuff = (char *)MEM_alloc(2000 * sizeof(char));
	sprintf(deptDocDescBuff,"<DBE:String>%s</DBE:String>",deptDocDesc);
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptDocDescBuff);	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(deptDocDescBuff);
		
	
	
	//deptNo
	char* deptNoStrBuff = (char *)MEM_alloc(200 * sizeof(char));
	sprintf(deptNoStrBuff,"<DBE:String>%s</DBE:String>",deptNoStr);
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArDNum\" type=\"String\" displayAs=\"Dept Document No\" length=\"20\">");
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,deptNoStrBuff);
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
	MEM_free(deptNoStrBuff);

	

	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
	
	//End of Department Doc
	
	
	
	//Get Clause Revisions.
	tag_t deptToClauseRelType = NULLTAG;
	ifail = GRM_find_relation_type("T5_DeptDocHasClause", &deptToClauseRelType);
	
	if(deptToClauseRelType != NULLTAG)
	{
		tag_t* clsRevTags = NULL;
		int clsRevTagCnt = 0;
		ifail = GRM_list_secondary_objects_only(deptDocObj,deptToClauseRelType,&clsRevTagCnt,&clsRevTags);
			
		printf("\nSTN: Clause Rev Tag count: [%d]\n", clsRevTagCnt);fflush(stdout);
		
		int j = 0;
		for(j=0; j<clsRevTagCnt;j++)
		{
			printf("\nSTN: clsRevTagCnt[%d] \n ",j+1);fflush(stdout);
			tag_t clauseObj = NULLTAG;
			
			clauseObj = clsRevTags[j];
			
			char* clauseNoStr = "";
			char* clauseNo1Str = "";
			char* clauseDescStr = "";
			char* clauseValueStr = "";
			char* clauseTypeStr = "";
			char* clauseIsLblStr = "";
			char* clauseIsClassifiedStr = "";
			char* columnHeaderStr = "";
			char* clauseDummyStr = "";
			char* clauseClassStr = "";
			char* clauseRefDesc = "";
			char* refClauseNo = "";
			
			
			ifail = AOM_ask_value_string(clauseObj,"object_name", &clauseNoStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseNum",&clauseNo1Str);
			ifail = AOM_ask_value_string(clauseObj,"t5_ClaDes",&clauseDescStr);
			
			if(clauseDescStr != NULL)
			{
				STRNG_replace_str(clauseDescStr,"&","&amp;",&clauseDescStr);
				STRNG_replace_str(clauseDescStr,"<","&lt;",&clauseDescStr);
				STRNG_replace_str(clauseDescStr,">","&gt;",&clauseDescStr);
			}

			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseValue",&clauseValueStr);
			
			if(clauseValueStr != NULL)
			{
				STRNG_replace_str(clauseValueStr,"&","&amp;",&clauseValueStr);
				STRNG_replace_str(clauseValueStr,"<","&lt;",&clauseValueStr);
				STRNG_replace_str(clauseValueStr,">","&gt;",&clauseValueStr);				
			}
			
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_IsLable",&clauseIsLblStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_IsClassified",&clauseIsClassifiedStr);
			ifail = AOM_ask_value_string(clauseObj,"t5_DummyClNum",&clauseDummyStr);
			//ifail = AOM_ask_value_string(clauseObj,"t5_ClauseClass",&clauseClassStr);
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefDesc",&clauseRefDesc);
			
			if(clauseRefDesc != NULL)
			{
				STRNG_replace_str(clauseRefDesc,"&","&amp;",&clauseRefDesc);
				STRNG_replace_str(clauseRefDesc,"<","&lt;",&clauseRefDesc);
				STRNG_replace_str(clauseRefDesc,">","&gt;",&clauseRefDesc);
			}

			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseRefClNum",&refClauseNo);
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5DtToGn\">");					
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"RightMember\" type=\"Object\" displayAs=\"RightMember\">");
			
			
			ifail = AOM_ask_value_string(clauseObj,"t5_ClauseType",&clauseTypeStr);
			char* isClassifiedStr = "";
			
			if(tc_strcmp(clauseIsClassifiedStr,"IN FULL ARAI REPORT") == 0)
			{
				isClassifiedStr="NC";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"IN FULL & BRIEF TECH SPEC REPORT")==0)
			{
				isClassifiedStr="PC";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR TABLE 8") == 0)
			{
				isClassifiedStr="D8";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"DUMMY FOR BRIEF TECH SPEC") == 0)
			{
				isClassifiedStr="PD";
			}
			else if(tc_strcmp(clauseIsClassifiedStr,"ANNEXURES") == 0)
			{
				isClassifiedStr="AX";
			}
			else
			{
				isClassifiedStr="-";
			}
			
			if(tc_strcmp(clauseTypeStr,"Table") ==0 )
			{
				//Implement for Table logic
				
				//printf("\nSTN: Implement for Table logic \n ");fflush(stdout);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Object Class=\"t5FtbACl\">");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:String>t5FtbACl</DBE:String>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>t5FtbACl</DBE:Translation>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				
				//Clause No				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
				
				//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
				
				char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
				sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(clauseNoStrBuff);
				
				
				//Clause Desc
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
				
				char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
				sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDescStrBuff);
				
				
				
				char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
				sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseRefDescBuff);
				
				char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
				sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseValueStrBuff);
				
				char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
				sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDummyStrBuff);
				
				
				char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
				sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(refClauseNoBuff);
				
				char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
				sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(isClassifiedStrBuff);
				
				
				//Table property
				ifail = AOM_ask_value_string(clauseObj,"t5_ArTbCol",&columnHeaderStr);
				if(columnHeaderStr !=NULL)
				{
					STRNG_replace_str(columnHeaderStr,"&","&amp;",&columnHeaderStr);
					STRNG_replace_str(columnHeaderStr,"<","&lt;",&columnHeaderStr);
					STRNG_replace_str(columnHeaderStr,">","&gt;",&columnHeaderStr);
				}						
				
				//Column Header
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbCol\" type=\"String\" displayAs=\"Enter Coloumn&apos;s:\" length=\"500\">");
				
				char* columnHeaderStrBuff = (char *)MEM_alloc(1700 * sizeof(char));
				sprintf(columnHeaderStrBuff,"<DBE:String>%s</DBE:String>",columnHeaderStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,columnHeaderStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(columnHeaderStrBuff);
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"colset\" type=\"Table\" displayAs=\"SET OF VALUES\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Table>");



				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableHeader>");

				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col01</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col02</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col03</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col04</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col5</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col6</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col7</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col8</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col9</DBE:TableColumn>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableColumn>col10</DBE:TableColumn>");

				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableHeader>");
				
				char** rowHeaderList = NULL;
				int rowHeaderListCnt = 0;
				int n_table_rows = 0;
				tag_t* table_rowsTag = NULL;

				ifail = AOM_ask_table_rows(clauseObj,"t5_colset", &n_table_rows,&table_rowsTag);
				if(n_table_rows > 0)
				{
					//printf("no of table rows are %d \n", n_table_rows);
					int ii=0;
					int jj =0;
					char* colVal1 = NULL;
					char* colVal2 = NULL;
					char* colVal3 = NULL;
					char* colVal4 = NULL;
					char* colVal5 = NULL;
					char* colVal6 = NULL;
					char* colVal7 = NULL;
					char* colVal8 = NULL;
					char* colVal9 = NULL;
					char* colVal10 = NULL;
					
					for(ii=0;ii<n_table_rows;ii++)
					{
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:TableRow>");
						tag_t tableObj = NULLTAG;
						tableObj = table_rowsTag[ii];
						ifail = AOM_ask_value_string(tableObj, "t5_col1", &colVal1);
						ifail = AOM_ask_value_string(tableObj, "t5_col2", &colVal2);
						ifail = AOM_ask_value_string(tableObj, "t5_col3", &colVal3);
						ifail = AOM_ask_value_string(tableObj, "t5_col4", &colVal4);
						ifail = AOM_ask_value_string(tableObj, "t5_col5", &colVal5);
						ifail = AOM_ask_value_string(tableObj, "t5_col6", &colVal6);
						ifail = AOM_ask_value_string(tableObj, "t5_col7", &colVal7);
						ifail = AOM_ask_value_string(tableObj, "t5_col8", &colVal8);
						ifail = AOM_ask_value_string(tableObj, "t5_col9", &colVal9);
						ifail = AOM_ask_value_string(tableObj, "t5_col10", &colVal10);

						if(colVal1 != NULL)
						{
							STRNG_replace_str(colVal1,"&","&amp;",&colVal1);
							STRNG_replace_str(colVal1,"<","&lt;",&colVal1);
							STRNG_replace_str(colVal1,">","&gt;",&colVal1);
						}
						if(colVal2 != NULL)
						{
							STRNG_replace_str(colVal2,"&","&amp;",&colVal2);
							STRNG_replace_str(colVal2,"<","&lt;",&colVal2);
							STRNG_replace_str(colVal2,">","&gt;",&colVal2);
						}
						if(colVal3 != NULL)
						{
							STRNG_replace_str(colVal3,"&","&amp;",&colVal3);
							STRNG_replace_str(colVal3,"<","&lt;",&colVal3);
							STRNG_replace_str(colVal3,">","&gt;",&colVal3);
						}
						if(colVal4 != NULL)
						{
							STRNG_replace_str(colVal4,"&","&amp;",&colVal4);
							STRNG_replace_str(colVal4,"<","&lt;",&colVal4);
							STRNG_replace_str(colVal4,">","&gt;",&colVal4);
						}
						if(colVal5 != NULL)
						{
							STRNG_replace_str(colVal5,"&","&amp;",&colVal5);
							STRNG_replace_str(colVal5,"<","&lt;",&colVal5);
							STRNG_replace_str(colVal5,">","&gt;",&colVal5);
						}
						if(colVal6 != NULL)
						{
							STRNG_replace_str(colVal6,"&","&amp;",&colVal6);
							STRNG_replace_str(colVal6,"<","&lt;",&colVal6);
							STRNG_replace_str(colVal6,">","&gt;",&colVal6);
						}
						if(colVal7 != NULL)
						{
							STRNG_replace_str(colVal7,"&","&amp;",&colVal7);
							STRNG_replace_str(colVal7,"<","&lt;",&colVal7);
							STRNG_replace_str(colVal7,">","&gt;",&colVal7);
						}
						if(colVal8 != NULL)
						{
							STRNG_replace_str(colVal8,"&","&amp;",&colVal8);
							STRNG_replace_str(colVal8,"<","&lt;",&colVal8);
							STRNG_replace_str(colVal8,">","&gt;",&colVal8);
						}
						if(colVal9 != NULL)
						{
							STRNG_replace_str(colVal9,"&","&amp;",&colVal9);
							STRNG_replace_str(colVal9,"<","&lt;",&colVal9);
							STRNG_replace_str(colVal9,">","&gt;",&colVal9);
						}
						if(colVal10 != NULL)
						{
							STRNG_replace_str(colVal10,"&","&amp;",&colVal10);
							STRNG_replace_str(colVal10,"<","&lt;",&colVal10);
							STRNG_replace_str(colVal10,">","&gt;",&colVal10);
						}								
														
						
						char* colVal1Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal1Buff,"<DBE:TableData>%s</DBE:TableData>",colVal1);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal1Buff);
						MEM_free(colVal1Buff);
						
						char* colVal2Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal2Buff,"<DBE:TableData>%s</DBE:TableData>",colVal2);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal2Buff);
						MEM_free(colVal2Buff);
						
						char* colVal3Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal3Buff,"<DBE:TableData>%s</DBE:TableData>",colVal3);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal3Buff);
						MEM_free(colVal3Buff);
						
						char* colVal4Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal4Buff,"<DBE:TableData>%s</DBE:TableData>",colVal4);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal4Buff);
						MEM_free(colVal4Buff);

						char* colVal5Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal5Buff,"<DBE:TableData>%s</DBE:TableData>",colVal5);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal5Buff);
						MEM_free(colVal5Buff);

						char* colVal6Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal6Buff,"<DBE:TableData>%s</DBE:TableData>",colVal6);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal6Buff);
						MEM_free(colVal6Buff);

						char* colVal7Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal7Buff,"<DBE:TableData>%s</DBE:TableData>",colVal7);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal7Buff);
						MEM_free(colVal7Buff);

						char* colVal8Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal8Buff,"<DBE:TableData>%s</DBE:TableData>",colVal8);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal8Buff);
						MEM_free(colVal8Buff);

						char* colVal9Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal9Buff,"<DBE:TableData>%s</DBE:TableData>",colVal9);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal9Buff);
						MEM_free(colVal9Buff);

						char* colVal10Buff = (char *)MEM_alloc(500 * sizeof(char));
						sprintf(colVal10Buff,"<DBE:TableData>%s</DBE:TableData>",colVal10);
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,colVal10Buff);
						MEM_free(colVal10Buff);
						
						
						t5STN_SetAddStr(&rowHeaderListCnt,&rowHeaderList,colVal1);

						
						t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:TableRow>");
					}
					
					
					
				}
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Table>");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				
				char* rowHeaderStr = NULL;
				int r = 0;
				
				rowHeaderStr = (char*)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 500);
				for(r=0;r<rowHeaderListCnt;r++)
				{
					if(r==0)
					{
						//rowHeaderStr = rowHeaderList[r];
						tc_strcpy(rowHeaderStr,rowHeaderList[r]);
					}
					else
					{
						tc_strcat(rowHeaderStr,",");
						tc_strcat(rowHeaderStr,rowHeaderList[r]);
						//rowHeaderStr = rowHeaderStr + "," + rowHeaderList[r];
					}
				}
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArTbRow\" type=\"String\" displayAs=\"Enter Row&apos;s    :\" length=\"600\">");
				
				char* rowHeaderStrBuff = (char *)MEM_alloc(rowHeaderListCnt*500*sizeof(char) + 800);
				sprintf(rowHeaderStrBuff,"<DBE:String>%s</DBE:String>",rowHeaderStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,rowHeaderStrBuff);
				
					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(rowHeaderStr);
				MEM_free(rowHeaderStrBuff);
				
				
				
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
				
			}
			else
			{
				//Other than Table clause
				clauseClassStr = "t5StrACl";			
				char* clauseClassStrBuff = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff,"<DBE:Object Class=\"%s\">",clauseClassStr);			
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff);
				MEM_free(clauseClassStrBuff);
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"Class\" type=\"String\" displayAs=\"Class\" length=\"20\">");
				
				char* clauseClassStrBuff1 = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff1,"<DBE:String>%s</DBE:String>",clauseClassStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff1);
				MEM_free(clauseClassStrBuff1);
				
				
				char* clauseClassStrBuff2 = (char *)MEM_alloc(50 * sizeof(char));
				sprintf(clauseClassStrBuff2,"<DBE:Translation>%s</DBE:Translation>",clauseClassStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseClassStrBuff2);
				MEM_free(clauseClassStrBuff2);
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"DisplayedName\" type=\"String\" displayAs=\"Name\" length=\"120\">");
				
				//outputStrLst.add("<DBE:String>" + clauseNoStr + "</DBE:String>");
				
				char* clauseNoStrBuff = (char *)MEM_alloc(500 * sizeof(char));
				sprintf(clauseNoStrBuff,"<DBE:String>%s</DBE:String>",clauseNoStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5ArClNum\" type=\"String\" displayAs=\"Clause Number\" length=\"50\">");
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseNoStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				
				MEM_free(clauseNoStrBuff);
				
				
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"dv2_Desc\" type=\"String\" displayAs=\"Description\" length=\"1300\">");
				
				char* clauseDescStrBuff = (char *)MEM_alloc(1500 * sizeof(char));
				sprintf(clauseDescStrBuff,"<DBE:String>%s</DBE:String>",clauseDescStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDescStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDescStrBuff);
				
				
				
				char* clauseRefDescBuff = (char *)MEM_alloc(1500 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefDesc\" type=\"String\" displayAs=\"Reference Description:\" length=\"500\">");
				sprintf(clauseRefDescBuff,"<DBE:String>%s</DBE:String>",clauseRefDesc);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseRefDescBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseRefDescBuff);
				
				
				char* clauseValueStrBuff = (char *)MEM_alloc(3100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5StrVal\" type=\"String\" displayAs=\"Value (String)\" length=\"3000\">");
				sprintf(clauseValueStrBuff,"<DBE:String>%s</DBE:String>",clauseValueStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseValueStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseValueStrBuff);
				
				char* clauseDummyStrBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5DummyClNum\" type=\"String\" displayAs=\"t5DummyClNum\" length=\"50\">");
				sprintf(clauseDummyStrBuff,"<DBE:String>%s</DBE:String>",clauseDummyStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,clauseDummyStrBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(clauseDummyStrBuff);
				
				
				char* refClauseNoBuff = (char *)MEM_alloc(300 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5RefClNum\" type=\"String\" displayAs=\"Reference Clause (if any):\" length=\"50\">");
				sprintf(refClauseNoBuff,"<DBE:String>%s</DBE:String>",refClauseNo);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,refClauseNoBuff);										
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(refClauseNoBuff);
				
				char* isClassifiedStrBuff = (char *)MEM_alloc(100 * sizeof(char));
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Attribute name=\"t5IsBTSpe\" type=\"String\" displayAs=\"Further Classification ?\" length=\"2\">");
				sprintf(isClassifiedStrBuff,"<DBE:String>%s</DBE:String>",isClassifiedStr);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,isClassifiedStrBuff);
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"<DBE:Translation>IN FULL ARAI REPORT</DBE:Translation>");					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");
				MEM_free(isClassifiedStrBuff);
																					
				t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
				
				
				
			}

	
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Attribute>");//right member
			
			t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:Object>");
			
		}//End of Clause Loop
	
	
	}
	
	
	t5STN_SetAddStr(buff_cnt,bufferedXmlStrOut,"</DBE:ObjectSetRoot>");
	
	printf("\nSTN: End of Generate Department Doc logic String.................\n");fflush(stdout);
	return ITK_ok;
}

int tmOldStnUpdateServ(void *retValue)
{
	printf("\nSTN:SAN:Old STN Update : Start----tmOldStnUpdateServ....\n");fflush(stdout);
	const char	*prog_name 	="tmOldStnUpdateServ";	
	int ifail = ITK_ok;
	tag_t stnHeaderRevTag = NULLTAG;


	USERARG_get_tag_argument(&stnHeaderRevTag);

	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	if(stnHeaderRevTag !=NULLTAG)
	{
		
		printf("\nSTN:SAN:Got the STN Header Revision Tag.... \n");fflush(stdout);
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNGroupControlTag(&cntrlTag);
		
		if(cntrlTag!= NULLTAG)
		{
			char* info10 = NULL;
			ifail = AOM_ask_value_string(cntrlTag,"t5_userinfo10", &info10);
			printf("\nSTN:SAN:info10[%s]\n",info10);fflush(stdout);
			if(info10 != NULL)
			{
				if(tc_strcmp(info10,"OLDLOGIC")==0)
				{
					printf("\nSTN:SAN:OLDLOGIC\n");fflush(stdout);
					ifail = oldStnUpdateFun_old(stnHeaderRevTag);
				}
				else
				{
					printf("\nSTN:SAN:NEWLOGIC\n");fflush(stdout);
					ifail = oldStnUpdateFun(stnHeaderRevTag);
				}
			}
			else
			{
				printf("\nSTN:SAN:NEWLOGIC\n");fflush(stdout);
				ifail = oldStnUpdateFun(stnHeaderRevTag);
			}
		}
		else
		{
			printf("\nSTN:SAN:NEWLOGIC\n");fflush(stdout);
			ifail = oldStnUpdateFun(stnHeaderRevTag);
		}
				
		tc_strcpy(resultStr,"PASS");
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:SAN: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("Old STN Update- After returning Value\n");fflush(stdout);	

	printf("\nSTN:SAN:Old STN Update:END----tmOldStnUpdateServ....\n");fflush(stdout);
	return ifail;	
	
}



int tmReleaseSTNServ(void *retValue)
{
	printf("\nSTN:Release Stampinp of STN. Start----tmReleaseSTNServ....\n");fflush(stdout);
	const char	*prog_name 	="tmReleaseSTNServ";	
	int ifail = ITK_ok;
	tag_t stnHeaderRevTag = NULLTAG;


	USERARG_get_tag_argument(&stnHeaderRevTag);

	
	char *resultStr = NULL;
	char * resultStr1 = NULL;
	resultStr = (char *) MEM_alloc( 100 * sizeof(char) );
	resultStr1 = (char *) MEM_alloc( 100 * sizeof(char) );
	if(stnHeaderRevTag !=NULLTAG)
	{
		
		printf("\nSTN:SAN:Got the STN Header Revision Tag.... \n");fflush(stdout);
		tag_t cntrlTag = NULLTAG;
		ifail = getReleaseSTNCtrl(&cntrlTag);
		
		if(cntrlTag!= NULLTAG)
		{
			ifail = tm_releaseStampSTN(stnHeaderRevTag);
			tc_strcpy(resultStr,"PASS");
		}
		else
		{
			printf("\nSTN:No Access\n");fflush(stdout);
			tc_strcpy(resultStr,"NOACCESS");
		}
				
	}
	else
	{
		tc_strcpy(resultStr,"FAIL");
	}
	
	
	tc_strcpy(resultStr1,"");
	tc_strcat(resultStr1,resultStr);
	
	printf("\nSTN:SAN: Output result string1: %s", resultStr1);fflush(stdout);
	*((char **) retValue) =    (char *) MEM_alloc( (strlen(resultStr1 ) + 1) * sizeof(char));

	strcpy( *((char **) retValue), resultStr1);
	
	MEM_free(resultStr);
	MEM_free(resultStr1);
	printf("\nSTN:Release Stamp of STN- After returning Value\n");fflush(stdout);	

	printf("\nSTN:Release Stamp of STN: END----tmReleaseSTNServ....\n");fflush(stdout);
	return ifail;	
	
}



int tmAraiReportServFn(void *retValue)
{
	const char	*prog_name 	="tmAraiReportServFn";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nSTN: Start----tmAraiReportServFn....\n");fflush(stdout);
	
	tag_t stnHeaderRevTag = NULLTAG;


	USERARG_get_tag_argument(&stnHeaderRevTag);
	
	//end print input parameters
	
	if(stnHeaderRevTag !=NULLTAG)
	{
		
		printf("\nSTN:SAN:Got the STN Header Revision Tag.... \n");fflush(stdout);
		
		/* Get report logic */
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNReportControlTag(&cntrlTag);
		if(cntrlTag != NULLTAG)
		{
			char* info2 = NULL;
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strstr(info2,",StringLogic,")!=NULL)
			{
				printf("\nSTN:String logic ITK...\n");fflush(stdout);
				ifail = generateARAIReportLogicString(stnHeaderRevTag,&bufferedXmlStrOut, &buff_cnt);
			}
			else
			{
				printf("\nSTN:Defaultlogic ITK...\n");fflush(stdout);
				ifail = generateARAIReportLogic(stnHeaderRevTag,&bufferedXmlStrOut, &buff_cnt);
			}
		}
		else
		{
			printf("\nSTN:String logic ITK...\n");fflush(stdout);
			ifail = generateARAIReportLogicString(stnHeaderRevTag,&bufferedXmlStrOut, &buff_cnt);
		}
		
		
	}
	
	//CALLAPI(executeESOStatusReportLogic( Datefrom, Dateto, &bufferedXmlStrOut, &buff_cnt ));
	
	
	int m =0;
	
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nSTN:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nSTN: End----tmAraiReportServFn....\n");fflush(stdout);
	return ifail;
}



int tmAraiReportReqdRevServFn(void *retValue)
{
	const char	*prog_name 	="tmAraiReportReqdRevServFn";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nSTN: Start----tmAraiReportReqdRevServFn....\n");fflush(stdout);
	
	tag_t stnHeaderRevTag = NULLTAG;
	char* reqdRevStr = NULL;


	USERARG_get_tag_argument(&stnHeaderRevTag);
	USERARG_get_string_argument(&reqdRevStr);
	
	//end print input parameters
	
	if(stnHeaderRevTag !=NULLTAG)
	{
		
		//printf("\nSTN:SAN:Got the STN Header Revision Tag. Required Rev:[%s]\n",reqdRevStr);fflush(stdout);
		
		/* Get report logic */
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNReportControlTag(&cntrlTag);
		if(cntrlTag != NULLTAG)
		{
			char* info2 = NULL;
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strstr(info2,",StringLogic,")!=NULL)
			{
				printf("\nSTN:String logic ITK...\n");fflush(stdout);
				ifail = generateARAIReportLogicStringReqdRev(stnHeaderRevTag,reqdRevStr,&bufferedXmlStrOut, &buff_cnt);
			}
			else
			{
				printf("\nSTN:Defaultlogic ITK...\n");fflush(stdout);
				ifail = generateARAIReportLogicReqdRev(stnHeaderRevTag,reqdRevStr,&bufferedXmlStrOut, &buff_cnt);
			}
		}
		else
		{
			printf("\nSTN:String logic ITK...\n");fflush(stdout);
			ifail = generateARAIReportLogicStringReqdRev(stnHeaderRevTag,reqdRevStr,&bufferedXmlStrOut, &buff_cnt);
		}
		
		
	}
	
	//CALLAPI(executeESOStatusReportLogic( Datefrom, Dateto, &bufferedXmlStrOut, &buff_cnt ));
	
	
	int m =0;
	
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nSTN:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nSTN: End----tmAraiReportServFn....\n");fflush(stdout);
	return ifail;
}

//Department wise Report logic (pdf)

int tmDeptReportServFn(void *retValue)
{
	const char	*prog_name 	="tmDeptReportServFn";
	int ifail = ITK_ok;
	int array_size = 0; 
	char **string_array 	= NULL;
	USERSERVICE_array_t 	array_struct;
	int buff_cnt=0;
	char** bufferedXmlStrOut = NULL;;	
	printf("\nSTN: Start----tmDeptReportServFn....\n");fflush(stdout);
	
	tag_t stnDocRevTag = NULLTAG;


	USERARG_get_tag_argument(&stnDocRevTag);
	
	//end print input parameters
	
	if(stnDocRevTag !=NULLTAG)
	{
		
		printf("\nSTN:SAN:Got the STN Doc Revision Tag.... \n");fflush(stdout);
		
		/* Get report logic */
		tag_t cntrlTag = NULLTAG;
		ifail = getSTNReportControlTag(&cntrlTag);
		if(cntrlTag != NULLTAG)
		{
			char* info2 = NULL;
			ifail = AOM_ask_value_string(cntrlTag,"t5_Userinfo2", &info2);
			if(tc_strstr(info2,",StringLogic,")!=NULL)
			{
				printf("\nSTN:String logic ITK...\n");fflush(stdout);
				ifail = generateDeptReportLogicString(stnDocRevTag,&bufferedXmlStrOut, &buff_cnt);
			}
			else
			{
				printf("\nSTN:Defaultlogic ITK...\n");fflush(stdout);
				ifail = generateDeptReportLogic(stnDocRevTag,&bufferedXmlStrOut, &buff_cnt);
			}
		}
		else
		{
			printf("\nSTN:String logic ITK...\n");fflush(stdout);
			ifail = generateDeptReportLogicString(stnDocRevTag,&bufferedXmlStrOut, &buff_cnt);
		}
		
		
	}
	
	//CALLAPI(executeESOStatusReportLogic( Datefrom, Dateto, &bufferedXmlStrOut, &buff_cnt ));
	
	
	int m =0;
	
	array_size = buff_cnt;
	string_array =  (char **) MEM_alloc(array_size * sizeof(char*));
	
	for(m=0;m<buff_cnt;m++)
	{
		//printf("\nSTN:%s",bufferedXmlStrOut[m]);fflush(stdout);
		string_array[m] = bufferedXmlStrOut[m];
	}

	

	ifail = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

	if (array_struct.length != 0)
	*((USERSERVICE_array_t*) retValue) = array_struct;				

	//printf("After returning Value\n");fflush(stdout);	
	printf("\nSTN: End----tmDeptReportServFn....\n");fflush(stdout);
	return ifail;
}



/******************************End Old STN Update ***************************************/


extern int CertificationFn(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	/***********Assign STN Participants User function *************************/
	int n_args = 1;
	int ret_value_type;
	int *input_arg_type;
	input_arg_type=(int *)MEM_alloc(n_args * sizeof(int));
	
	input_arg_type[0]=USERARG_TAG_TYPE;//STN Revision Object
	ret_value_type = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tm_assignSTNParticipantsServ",(USER_function_t)tm_assignSTNParticipantsServFunc,n_args,input_arg_type,ret_value_type);
	
	/********** Copy Department doc to other **************************/
	int n_args1 = 2;
	int ret_value_type1;
	int *input_arg_type1;
	input_arg_type1=(int *)MEM_alloc(n_args1 * sizeof(int));
	
	input_arg_type1[0]=USERARG_TAG_TYPE;//Source Dept Doc
	input_arg_type1[1]=USERARG_TAG_TYPE;//Target Dept Doc
	ret_value_type1 = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tmCopyDeptDocToOther",(USER_function_t)tmCopyDeptDocToOtherServ,n_args1,input_arg_type1,ret_value_type1);
	
	
	/********** Copy Department doc to other **************************/
	
	/*******************Update Table Properties of a Clause *********************/
	int n_args2 = 12;
	int ret_value_type2;
	int *input_arg_type2;
	input_arg_type2=(int *)MEM_alloc(n_args2 * sizeof(int));
	
	input_arg_type2[0]=USERARG_TAG_TYPE;//Clause Revision Tag
	input_arg_type2[1]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//column header
	input_arg_type2[2]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;//col1
	input_arg_type2[3]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[4]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[5]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[6]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[7]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[8]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[9]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[10]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	input_arg_type2[11]=USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	
	
	ret_value_type2 = USERARG_STRING_TYPE;
	
	ifail=USERSERVICE_register_method("tmUpdateClauseTableServ",(USER_function_t)tmUpdateClauseTableServ,n_args2,input_arg_type2,ret_value_type2);
	
	/*******************Update Table Properties of a Clause *********************/
	
	/**********************Old STN Update *************************************/
	
	int n_args3 = 1;
	int ret_value_type3;
	int *input_arg_type3;
	input_arg_type3=(int *)MEM_alloc(n_args3 * sizeof(int));
	
	input_arg_type3[0]=USERARG_TAG_TYPE;//STN Header Revision Tag
	ret_value_type3 = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tmOldStnUpdateServ",(USER_function_t)tmOldStnUpdateServ,n_args3,input_arg_type3,ret_value_type3);
	
	
	/**********************Old STN Update ************************************/
	
	/***********************Generate ARAI Report Service ***********************/
	int n_args4 = 1;
	int ret_value_type4;
	int *input_arg_type4;
	input_arg_type4=(int *)MEM_alloc(n_args4 * sizeof(int));
	
	input_arg_type4[0]=USERARG_TAG_TYPE;//STN Header Revision Tag
	ret_value_type4 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	ifail=USERSERVICE_register_method("tmAraiReportServ",(USER_function_t)tmAraiReportServFn,n_args4,input_arg_type4,ret_value_type4);
	
	/**********************Finish Generate ARAI Report Service *********************/
	
	/***********************Generate Department Doc Report Service ***********************/
	int n_args5 = 1;
	int ret_value_type5;
	int *input_arg_type5;
	input_arg_type5=(int *)MEM_alloc(n_args5 * sizeof(int));
	
	input_arg_type5[0]=USERARG_TAG_TYPE;//STN Header Revision Tag
	ret_value_type5 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	ifail=USERSERVICE_register_method("tmDeptReportServ",(USER_function_t)tmDeptReportServFn,n_args5,input_arg_type5,ret_value_type5);
	
	/**********************Finish Generate Department Doc Report Service *********************/
	
	
	/********** Copy STN Header to other **************************/
	int n_args6 = 2;
	int ret_value_type6;
	int *input_arg_type6;
	input_arg_type6=(int *)MEM_alloc(n_args6 * sizeof(int));
	
	input_arg_type6[0]=USERARG_TAG_TYPE;//Source STN Header Rev
	input_arg_type6[1]=USERARG_TAG_TYPE;//Target STN Header Rev
	ret_value_type6 = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tmCopySTNHeaderToOther",(USER_function_t)tmCopySTNHeaderToOtherServ,n_args6,input_arg_type6,ret_value_type6);
	
	
	/********** Copy STN Header to other Finish **************************/
	
	/***********************Generate ARAI Report Service - New ***********************/
	int n_args7 = 2;
	int ret_value_type7;
	int *input_arg_type7;
	input_arg_type7=(int *)MEM_alloc(n_args7 * sizeof(int));
	
	input_arg_type7[0]=USERARG_TAG_TYPE;//STN Header Revision Tag
	input_arg_type7[1]=USERARG_STRING_TYPE;//Required Revision
	ret_value_type7 = USERARG_STRING_TYPE+USERARG_ARRAY_TYPE;
	
	ifail=USERSERVICE_register_method("tmAraiReportReqdRevServ",(USER_function_t)tmAraiReportReqdRevServFn,n_args7,input_arg_type7,ret_value_type7);
	
	/**********************Finish Generate ARAI Report Service - New*********************/
	
	
	/**********************Release STN Service *************************************/
	
	int n_args8 = 1;
	int ret_value_type8;
	int *input_arg_type8;
	input_arg_type8=(int *)MEM_alloc(n_args8 * sizeof(int));
	
	input_arg_type8[0]=USERARG_TAG_TYPE;//STN Header Revision Tag
	ret_value_type8 = USERARG_STRING_TYPE;
 	
	
	ifail=USERSERVICE_register_method("tmReleaseSTNServ",(USER_function_t)tmReleaseSTNServ,n_args8,input_arg_type8,ret_value_type8);
	
	
	/**********************End Release STN Service ************************************/
	
	return ITK_ok;
}



extern DLLAPI int tm_Certification_register_callbacks ()
{
     //printf("\nSTN:tm_Certification.c:::Hello Teamcenter, via Custom Exit\n");fflush(stdout);

     CUSTOM_register_exit ( "tm_Certification", "USER_init_module", (CUSTOM_EXIT_ftn_t) certification_custom_exit);
	 
	 
	 CUSTOM_register_exit ( "tm_Certification", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)CertificationFn);

     return ( ITK_ok );
}
